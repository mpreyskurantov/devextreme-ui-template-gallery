import * as i0 from '@angular/core';
import { PLATFORM_ID, Output, Input, Inject, Component, NgModule } from '@angular/core';
import DxBullet from 'devextreme/viz/bullet';
import * as i1 from 'devextreme-angular/core';
import { DxComponent, DxIntegrationModule, DxTemplateHost, WatcherHelper, NestedOptionHost, DxTemplateModule } from 'devextreme-angular/core';
import { DxoMarginModule, DxoSizeModule, DxoTooltipModule, DxoBorderModule, DxoFontModule, DxoFormatModule, DxoShadowModule } from 'devextreme-angular/ui/nested';
import { DxoBulletBorderModule, DxoBulletFontModule, DxoBulletFormatModule, DxoBulletMarginModule, DxoBulletShadowModule, DxoBulletSizeModule, DxoBulletTooltipModule } from 'devextreme-angular/ui/bullet/nested';
export * from 'devextreme-angular/ui/bullet/nested';

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
/**
 * [descr:dxBullet]

 */
class DxBulletComponent extends DxComponent {
    /**
     * [descr:dxBulletOptions.color]
    
     */
    get color() {
        return this._getOption('color');
    }
    set color(value) {
        this._setOption('color', value);
    }
    /**
     * [descr:BaseWidgetOptions.disabled]
    
     */
    get disabled() {
        return this._getOption('disabled');
    }
    set disabled(value) {
        this._setOption('disabled', value);
    }
    /**
     * [descr:DOMComponentOptions.elementAttr]
    
     */
    get elementAttr() {
        return this._getOption('elementAttr');
    }
    set elementAttr(value) {
        this._setOption('elementAttr', value);
    }
    /**
     * [descr:BaseWidgetOptions.encodeHtml]
    
     */
    get encodeHtml() {
        return this._getOption('encodeHtml');
    }
    set encodeHtml(value) {
        this._setOption('encodeHtml', value);
    }
    /**
     * [descr:dxBulletOptions.endScaleValue]
    
     */
    get endScaleValue() {
        return this._getOption('endScaleValue');
    }
    set endScaleValue(value) {
        this._setOption('endScaleValue', value);
    }
    /**
     * [descr:BaseWidgetOptions.margin]
    
     */
    get margin() {
        return this._getOption('margin');
    }
    set margin(value) {
        this._setOption('margin', value);
    }
    /**
     * [descr:BaseWidgetOptions.pathModified]
    
     */
    get pathModified() {
        return this._getOption('pathModified');
    }
    set pathModified(value) {
        this._setOption('pathModified', value);
    }
    /**
     * [descr:BaseWidgetOptions.rtlEnabled]
    
     */
    get rtlEnabled() {
        return this._getOption('rtlEnabled');
    }
    set rtlEnabled(value) {
        this._setOption('rtlEnabled', value);
    }
    /**
     * [descr:dxBulletOptions.showTarget]
    
     */
    get showTarget() {
        return this._getOption('showTarget');
    }
    set showTarget(value) {
        this._setOption('showTarget', value);
    }
    /**
     * [descr:dxBulletOptions.showZeroLevel]
    
     */
    get showZeroLevel() {
        return this._getOption('showZeroLevel');
    }
    set showZeroLevel(value) {
        this._setOption('showZeroLevel', value);
    }
    /**
     * [descr:BaseWidgetOptions.size]
    
     */
    get size() {
        return this._getOption('size');
    }
    set size(value) {
        this._setOption('size', value);
    }
    /**
     * [descr:dxBulletOptions.startScaleValue]
    
     */
    get startScaleValue() {
        return this._getOption('startScaleValue');
    }
    set startScaleValue(value) {
        this._setOption('startScaleValue', value);
    }
    /**
     * [descr:dxBulletOptions.target]
    
     */
    get target() {
        return this._getOption('target');
    }
    set target(value) {
        this._setOption('target', value);
    }
    /**
     * [descr:dxBulletOptions.targetColor]
    
     */
    get targetColor() {
        return this._getOption('targetColor');
    }
    set targetColor(value) {
        this._setOption('targetColor', value);
    }
    /**
     * [descr:dxBulletOptions.targetWidth]
    
     */
    get targetWidth() {
        return this._getOption('targetWidth');
    }
    set targetWidth(value) {
        this._setOption('targetWidth', value);
    }
    /**
     * [descr:BaseWidgetOptions.theme]
    
     */
    get theme() {
        return this._getOption('theme');
    }
    set theme(value) {
        this._setOption('theme', value);
    }
    /**
     * [descr:BaseSparklineOptions.tooltip]
    
     */
    get tooltip() {
        return this._getOption('tooltip');
    }
    set tooltip(value) {
        this._setOption('tooltip', value);
    }
    /**
     * [descr:dxBulletOptions.value]
    
     */
    get value() {
        return this._getOption('value');
    }
    set value(value) {
        this._setOption('value', value);
    }
    constructor(elementRef, ngZone, templateHost, _watcherHelper, optionHost, transferState, platformId) {
        super(elementRef, ngZone, templateHost, _watcherHelper, transferState, platformId);
        this.instance = null;
        this._createEventEmitters([
            { subscribe: 'disposing', emit: 'onDisposing' },
            { subscribe: 'drawn', emit: 'onDrawn' },
            { subscribe: 'exported', emit: 'onExported' },
            { subscribe: 'exporting', emit: 'onExporting' },
            { subscribe: 'fileSaving', emit: 'onFileSaving' },
            { subscribe: 'incidentOccurred', emit: 'onIncidentOccurred' },
            { subscribe: 'initialized', emit: 'onInitialized' },
            { subscribe: 'optionChanged', emit: 'onOptionChanged' },
            { subscribe: 'tooltipHidden', emit: 'onTooltipHidden' },
            { subscribe: 'tooltipShown', emit: 'onTooltipShown' },
            { emit: 'colorChange' },
            { emit: 'disabledChange' },
            { emit: 'elementAttrChange' },
            { emit: 'encodeHtmlChange' },
            { emit: 'endScaleValueChange' },
            { emit: 'marginChange' },
            { emit: 'pathModifiedChange' },
            { emit: 'rtlEnabledChange' },
            { emit: 'showTargetChange' },
            { emit: 'showZeroLevelChange' },
            { emit: 'sizeChange' },
            { emit: 'startScaleValueChange' },
            { emit: 'targetChange' },
            { emit: 'targetColorChange' },
            { emit: 'targetWidthChange' },
            { emit: 'themeChange' },
            { emit: 'tooltipChange' },
            { emit: 'valueChange' }
        ]);
        optionHost.setHost(this);
    }
    _createInstance(element, options) {
        return new DxBullet(element, options);
    }
    ngOnDestroy() {
        this._destroyWidget();
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxBulletComponent, deps: [{ token: i0.ElementRef }, { token: i0.NgZone }, { token: i1.DxTemplateHost }, { token: i1.WatcherHelper }, { token: i1.NestedOptionHost }, { token: i0.TransferState }, { token: PLATFORM_ID }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxBulletComponent, isStandalone: true, selector: "dx-bullet", inputs: { color: "color", disabled: "disabled", elementAttr: "elementAttr", encodeHtml: "encodeHtml", endScaleValue: "endScaleValue", margin: "margin", pathModified: "pathModified", rtlEnabled: "rtlEnabled", showTarget: "showTarget", showZeroLevel: "showZeroLevel", size: "size", startScaleValue: "startScaleValue", target: "target", targetColor: "targetColor", targetWidth: "targetWidth", theme: "theme", tooltip: "tooltip", value: "value" }, outputs: { onDisposing: "onDisposing", onDrawn: "onDrawn", onExported: "onExported", onExporting: "onExporting", onFileSaving: "onFileSaving", onIncidentOccurred: "onIncidentOccurred", onInitialized: "onInitialized", onOptionChanged: "onOptionChanged", onTooltipHidden: "onTooltipHidden", onTooltipShown: "onTooltipShown", colorChange: "colorChange", disabledChange: "disabledChange", elementAttrChange: "elementAttrChange", encodeHtmlChange: "encodeHtmlChange", endScaleValueChange: "endScaleValueChange", marginChange: "marginChange", pathModifiedChange: "pathModifiedChange", rtlEnabledChange: "rtlEnabledChange", showTargetChange: "showTargetChange", showZeroLevelChange: "showZeroLevelChange", sizeChange: "sizeChange", startScaleValueChange: "startScaleValueChange", targetChange: "targetChange", targetColorChange: "targetColorChange", targetWidthChange: "targetWidthChange", themeChange: "themeChange", tooltipChange: "tooltipChange", valueChange: "valueChange" }, host: { attributes: { "ngSkipHydration": "true" } }, providers: [
            DxTemplateHost,
            WatcherHelper,
            NestedOptionHost
        ], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [":host{display:block}\n"], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxBulletComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dx-bullet', template: '', host: { ngSkipHydration: 'true' }, imports: [DxIntegrationModule], providers: [
                        DxTemplateHost,
                        WatcherHelper,
                        NestedOptionHost
                    ], styles: [":host{display:block}\n"] }]
        }], ctorParameters: () => [{ type: i0.ElementRef }, { type: i0.NgZone }, { type: i1.DxTemplateHost }, { type: i1.WatcherHelper }, { type: i1.NestedOptionHost }, { type: i0.TransferState }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [PLATFORM_ID]
                }] }], propDecorators: { color: [{
                type: Input
            }], disabled: [{
                type: Input
            }], elementAttr: [{
                type: Input
            }], encodeHtml: [{
                type: Input
            }], endScaleValue: [{
                type: Input
            }], margin: [{
                type: Input
            }], pathModified: [{
                type: Input
            }], rtlEnabled: [{
                type: Input
            }], showTarget: [{
                type: Input
            }], showZeroLevel: [{
                type: Input
            }], size: [{
                type: Input
            }], startScaleValue: [{
                type: Input
            }], target: [{
                type: Input
            }], targetColor: [{
                type: Input
            }], targetWidth: [{
                type: Input
            }], theme: [{
                type: Input
            }], tooltip: [{
                type: Input
            }], value: [{
                type: Input
            }], onDisposing: [{
                type: Output
            }], onDrawn: [{
                type: Output
            }], onExported: [{
                type: Output
            }], onExporting: [{
                type: Output
            }], onFileSaving: [{
                type: Output
            }], onIncidentOccurred: [{
                type: Output
            }], onInitialized: [{
                type: Output
            }], onOptionChanged: [{
                type: Output
            }], onTooltipHidden: [{
                type: Output
            }], onTooltipShown: [{
                type: Output
            }], colorChange: [{
                type: Output
            }], disabledChange: [{
                type: Output
            }], elementAttrChange: [{
                type: Output
            }], encodeHtmlChange: [{
                type: Output
            }], endScaleValueChange: [{
                type: Output
            }], marginChange: [{
                type: Output
            }], pathModifiedChange: [{
                type: Output
            }], rtlEnabledChange: [{
                type: Output
            }], showTargetChange: [{
                type: Output
            }], showZeroLevelChange: [{
                type: Output
            }], sizeChange: [{
                type: Output
            }], startScaleValueChange: [{
                type: Output
            }], targetChange: [{
                type: Output
            }], targetColorChange: [{
                type: Output
            }], targetWidthChange: [{
                type: Output
            }], themeChange: [{
                type: Output
            }], tooltipChange: [{
                type: Output
            }], valueChange: [{
                type: Output
            }] } });
class DxBulletModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxBulletModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxBulletModule, imports: [DxBulletComponent, DxoMarginModule,
            DxoSizeModule,
            DxoTooltipModule,
            DxoBorderModule,
            DxoFontModule,
            DxoFormatModule,
            DxoShadowModule,
            DxoBulletBorderModule,
            DxoBulletFontModule,
            DxoBulletFormatModule,
            DxoBulletMarginModule,
            DxoBulletShadowModule,
            DxoBulletSizeModule,
            DxoBulletTooltipModule,
            DxIntegrationModule,
            DxTemplateModule], exports: [DxBulletComponent, DxoMarginModule,
            DxoSizeModule,
            DxoTooltipModule,
            DxoBorderModule,
            DxoFontModule,
            DxoFormatModule,
            DxoShadowModule,
            DxoBulletBorderModule,
            DxoBulletFontModule,
            DxoBulletFormatModule,
            DxoBulletMarginModule,
            DxoBulletShadowModule,
            DxoBulletSizeModule,
            DxoBulletTooltipModule,
            DxTemplateModule] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxBulletModule, imports: [DxBulletComponent,
            DxoMarginModule,
            DxoSizeModule,
            DxoTooltipModule,
            DxoBorderModule,
            DxoFontModule,
            DxoFormatModule,
            DxoShadowModule,
            DxoBulletBorderModule,
            DxoBulletFontModule,
            DxoBulletFormatModule,
            DxoBulletMarginModule,
            DxoBulletShadowModule,
            DxoBulletSizeModule,
            DxoBulletTooltipModule,
            DxIntegrationModule,
            DxTemplateModule, DxoMarginModule,
            DxoSizeModule,
            DxoTooltipModule,
            DxoBorderModule,
            DxoFontModule,
            DxoFormatModule,
            DxoShadowModule,
            DxoBulletBorderModule,
            DxoBulletFontModule,
            DxoBulletFormatModule,
            DxoBulletMarginModule,
            DxoBulletShadowModule,
            DxoBulletSizeModule,
            DxoBulletTooltipModule,
            DxTemplateModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxBulletModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxBulletComponent,
                        DxoMarginModule,
                        DxoSizeModule,
                        DxoTooltipModule,
                        DxoBorderModule,
                        DxoFontModule,
                        DxoFormatModule,
                        DxoShadowModule,
                        DxoBulletBorderModule,
                        DxoBulletFontModule,
                        DxoBulletFormatModule,
                        DxoBulletMarginModule,
                        DxoBulletShadowModule,
                        DxoBulletSizeModule,
                        DxoBulletTooltipModule,
                        DxIntegrationModule,
                        DxTemplateModule
                    ],
                    exports: [
                        DxBulletComponent,
                        DxoMarginModule,
                        DxoSizeModule,
                        DxoTooltipModule,
                        DxoBorderModule,
                        DxoFontModule,
                        DxoFormatModule,
                        DxoShadowModule,
                        DxoBulletBorderModule,
                        DxoBulletFontModule,
                        DxoBulletFormatModule,
                        DxoBulletMarginModule,
                        DxoBulletShadowModule,
                        DxoBulletSizeModule,
                        DxoBulletTooltipModule,
                        DxTemplateModule
                    ]
                }]
        }] });

/**
 * Generated bundle index. Do not edit.
 */

export { DxBulletComponent, DxBulletModule };
//# sourceMappingURL=devextreme-angular-ui-bullet.mjs.map
