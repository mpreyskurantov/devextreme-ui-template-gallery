import * as i0 from '@angular/core';
import { Input, SkipSelf, Host, Component, NgModule, Inject, Output } from '@angular/core';
import * as i1 from 'devextreme-angular/core';
import { NestedOption, DxIntegrationModule, NestedOptionHost, CollectionNestedOption, extractTemplate, DxTemplateHost } from 'devextreme-angular/core';
import { DOCUMENT } from '@angular/common';
import { PROPERTY_TOKEN_annotations, PROPERTY_TOKEN_layers, PROPERTY_TOKEN_legends } from 'devextreme-angular/core/tokens';

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoVectorMapAnnotationBorderComponent extends NestedOption {
    get color() {
        return this._getOption('color');
    }
    set color(value) {
        this._setOption('color', value);
    }
    get cornerRadius() {
        return this._getOption('cornerRadius');
    }
    set cornerRadius(value) {
        this._setOption('cornerRadius', value);
    }
    get dashStyle() {
        return this._getOption('dashStyle');
    }
    set dashStyle(value) {
        this._setOption('dashStyle', value);
    }
    get opacity() {
        return this._getOption('opacity');
    }
    set opacity(value) {
        this._setOption('opacity', value);
    }
    get visible() {
        return this._getOption('visible');
    }
    set visible(value) {
        this._setOption('visible', value);
    }
    get width() {
        return this._getOption('width');
    }
    set width(value) {
        this._setOption('width', value);
    }
    get _optionPath() {
        return 'border';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoVectorMapAnnotationBorderComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoVectorMapAnnotationBorderComponent, isStandalone: true, selector: "dxo-vector-map-annotation-border", inputs: { color: "color", cornerRadius: "cornerRadius", dashStyle: "dashStyle", opacity: "opacity", visible: "visible", width: "width" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoVectorMapAnnotationBorderComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-vector-map-annotation-border', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { color: [{
                type: Input
            }], cornerRadius: [{
                type: Input
            }], dashStyle: [{
                type: Input
            }], opacity: [{
                type: Input
            }], visible: [{
                type: Input
            }], width: [{
                type: Input
            }] } });
class DxoVectorMapAnnotationBorderModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoVectorMapAnnotationBorderModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoVectorMapAnnotationBorderModule, imports: [DxoVectorMapAnnotationBorderComponent], exports: [DxoVectorMapAnnotationBorderComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoVectorMapAnnotationBorderModule, imports: [DxoVectorMapAnnotationBorderComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoVectorMapAnnotationBorderModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoVectorMapAnnotationBorderComponent
                    ],
                    exports: [
                        DxoVectorMapAnnotationBorderComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxiVectorMapAnnotationComponent extends CollectionNestedOption {
    get allowDragging() {
        return this._getOption('allowDragging');
    }
    set allowDragging(value) {
        this._setOption('allowDragging', value);
    }
    get arrowLength() {
        return this._getOption('arrowLength');
    }
    set arrowLength(value) {
        this._setOption('arrowLength', value);
    }
    get arrowWidth() {
        return this._getOption('arrowWidth');
    }
    set arrowWidth(value) {
        this._setOption('arrowWidth', value);
    }
    get border() {
        return this._getOption('border');
    }
    set border(value) {
        this._setOption('border', value);
    }
    get color() {
        return this._getOption('color');
    }
    set color(value) {
        this._setOption('color', value);
    }
    get coordinates() {
        return this._getOption('coordinates');
    }
    set coordinates(value) {
        this._setOption('coordinates', value);
    }
    get customizeTooltip() {
        return this._getOption('customizeTooltip');
    }
    set customizeTooltip(value) {
        this._setOption('customizeTooltip', value);
    }
    get data() {
        return this._getOption('data');
    }
    set data(value) {
        this._setOption('data', value);
    }
    get description() {
        return this._getOption('description');
    }
    set description(value) {
        this._setOption('description', value);
    }
    get font() {
        return this._getOption('font');
    }
    set font(value) {
        this._setOption('font', value);
    }
    get height() {
        return this._getOption('height');
    }
    set height(value) {
        this._setOption('height', value);
    }
    get image() {
        return this._getOption('image');
    }
    set image(value) {
        this._setOption('image', value);
    }
    get name() {
        return this._getOption('name');
    }
    set name(value) {
        this._setOption('name', value);
    }
    get offsetX() {
        return this._getOption('offsetX');
    }
    set offsetX(value) {
        this._setOption('offsetX', value);
    }
    get offsetY() {
        return this._getOption('offsetY');
    }
    set offsetY(value) {
        this._setOption('offsetY', value);
    }
    get opacity() {
        return this._getOption('opacity');
    }
    set opacity(value) {
        this._setOption('opacity', value);
    }
    get paddingLeftRight() {
        return this._getOption('paddingLeftRight');
    }
    set paddingLeftRight(value) {
        this._setOption('paddingLeftRight', value);
    }
    get paddingTopBottom() {
        return this._getOption('paddingTopBottom');
    }
    set paddingTopBottom(value) {
        this._setOption('paddingTopBottom', value);
    }
    get shadow() {
        return this._getOption('shadow');
    }
    set shadow(value) {
        this._setOption('shadow', value);
    }
    get template() {
        return this._getOption('template');
    }
    set template(value) {
        this._setOption('template', value);
    }
    get text() {
        return this._getOption('text');
    }
    set text(value) {
        this._setOption('text', value);
    }
    get textOverflow() {
        return this._getOption('textOverflow');
    }
    set textOverflow(value) {
        this._setOption('textOverflow', value);
    }
    get tooltipEnabled() {
        return this._getOption('tooltipEnabled');
    }
    set tooltipEnabled(value) {
        this._setOption('tooltipEnabled', value);
    }
    get tooltipTemplate() {
        return this._getOption('tooltipTemplate');
    }
    set tooltipTemplate(value) {
        this._setOption('tooltipTemplate', value);
    }
    get type() {
        return this._getOption('type');
    }
    set type(value) {
        this._setOption('type', value);
    }
    get width() {
        return this._getOption('width');
    }
    set width(value) {
        this._setOption('width', value);
    }
    get wordWrap() {
        return this._getOption('wordWrap');
    }
    set wordWrap(value) {
        this._setOption('wordWrap', value);
    }
    get x() {
        return this._getOption('x');
    }
    set x(value) {
        this._setOption('x', value);
    }
    get y() {
        return this._getOption('y');
    }
    set y(value) {
        this._setOption('y', value);
    }
    get _optionPath() {
        return 'annotations';
    }
    constructor(parentOptionHost, optionHost, renderer, document, templateHost, element) {
        super();
        this.renderer = renderer;
        this.document = document;
        this.element = element;
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
        templateHost.setHost(this);
    }
    setTemplate(template) {
        this.template = template;
    }
    ngAfterViewInit() {
        extractTemplate(this, this.element, this.renderer, this.document);
    }
    ngOnDestroy() {
        this._deleteRemovedOptions(this._fullOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiVectorMapAnnotationComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }, { token: i0.Renderer2 }, { token: DOCUMENT }, { token: i1.DxTemplateHost, host: true }, { token: i0.ElementRef }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxiVectorMapAnnotationComponent, isStandalone: true, selector: "dxi-vector-map-annotation", inputs: { allowDragging: "allowDragging", arrowLength: "arrowLength", arrowWidth: "arrowWidth", border: "border", color: "color", coordinates: "coordinates", customizeTooltip: "customizeTooltip", data: "data", description: "description", font: "font", height: "height", image: "image", name: "name", offsetX: "offsetX", offsetY: "offsetY", opacity: "opacity", paddingLeftRight: "paddingLeftRight", paddingTopBottom: "paddingTopBottom", shadow: "shadow", template: "template", text: "text", textOverflow: "textOverflow", tooltipEnabled: "tooltipEnabled", tooltipTemplate: "tooltipTemplate", type: "type", width: "width", wordWrap: "wordWrap", x: "x", y: "y" }, providers: [
            NestedOptionHost,
            DxTemplateHost,
            {
                provide: PROPERTY_TOKEN_annotations,
                useExisting: DxiVectorMapAnnotationComponent,
            }
        ], usesInheritance: true, ngImport: i0, template: '<ng-content></ng-content>', isInline: true, styles: [":host{display:block}\n"], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiVectorMapAnnotationComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxi-vector-map-annotation', template: '<ng-content></ng-content>', imports: [DxIntegrationModule], providers: [
                        NestedOptionHost,
                        DxTemplateHost,
                        {
                            provide: PROPERTY_TOKEN_annotations,
                            useExisting: DxiVectorMapAnnotationComponent,
                        }
                    ], styles: [":host{display:block}\n"] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }, { type: i0.Renderer2 }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [DOCUMENT]
                }] }, { type: i1.DxTemplateHost, decorators: [{
                    type: Host
                }] }, { type: i0.ElementRef }], propDecorators: { allowDragging: [{
                type: Input
            }], arrowLength: [{
                type: Input
            }], arrowWidth: [{
                type: Input
            }], border: [{
                type: Input
            }], color: [{
                type: Input
            }], coordinates: [{
                type: Input
            }], customizeTooltip: [{
                type: Input
            }], data: [{
                type: Input
            }], description: [{
                type: Input
            }], font: [{
                type: Input
            }], height: [{
                type: Input
            }], image: [{
                type: Input
            }], name: [{
                type: Input
            }], offsetX: [{
                type: Input
            }], offsetY: [{
                type: Input
            }], opacity: [{
                type: Input
            }], paddingLeftRight: [{
                type: Input
            }], paddingTopBottom: [{
                type: Input
            }], shadow: [{
                type: Input
            }], template: [{
                type: Input
            }], text: [{
                type: Input
            }], textOverflow: [{
                type: Input
            }], tooltipEnabled: [{
                type: Input
            }], tooltipTemplate: [{
                type: Input
            }], type: [{
                type: Input
            }], width: [{
                type: Input
            }], wordWrap: [{
                type: Input
            }], x: [{
                type: Input
            }], y: [{
                type: Input
            }] } });
class DxiVectorMapAnnotationModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiVectorMapAnnotationModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxiVectorMapAnnotationModule, imports: [DxiVectorMapAnnotationComponent], exports: [DxiVectorMapAnnotationComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiVectorMapAnnotationModule, imports: [DxiVectorMapAnnotationComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiVectorMapAnnotationModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxiVectorMapAnnotationComponent
                    ],
                    exports: [
                        DxiVectorMapAnnotationComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoVectorMapBackgroundComponent extends NestedOption {
    get borderColor() {
        return this._getOption('borderColor');
    }
    set borderColor(value) {
        this._setOption('borderColor', value);
    }
    get color() {
        return this._getOption('color');
    }
    set color(value) {
        this._setOption('color', value);
    }
    get _optionPath() {
        return 'background';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoVectorMapBackgroundComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoVectorMapBackgroundComponent, isStandalone: true, selector: "dxo-vector-map-background", inputs: { borderColor: "borderColor", color: "color" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoVectorMapBackgroundComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-vector-map-background', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { borderColor: [{
                type: Input
            }], color: [{
                type: Input
            }] } });
class DxoVectorMapBackgroundModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoVectorMapBackgroundModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoVectorMapBackgroundModule, imports: [DxoVectorMapBackgroundComponent], exports: [DxoVectorMapBackgroundComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoVectorMapBackgroundModule, imports: [DxoVectorMapBackgroundComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoVectorMapBackgroundModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoVectorMapBackgroundComponent
                    ],
                    exports: [
                        DxoVectorMapBackgroundComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoVectorMapBorderComponent extends NestedOption {
    get color() {
        return this._getOption('color');
    }
    set color(value) {
        this._setOption('color', value);
    }
    get cornerRadius() {
        return this._getOption('cornerRadius');
    }
    set cornerRadius(value) {
        this._setOption('cornerRadius', value);
    }
    get dashStyle() {
        return this._getOption('dashStyle');
    }
    set dashStyle(value) {
        this._setOption('dashStyle', value);
    }
    get opacity() {
        return this._getOption('opacity');
    }
    set opacity(value) {
        this._setOption('opacity', value);
    }
    get visible() {
        return this._getOption('visible');
    }
    set visible(value) {
        this._setOption('visible', value);
    }
    get width() {
        return this._getOption('width');
    }
    set width(value) {
        this._setOption('width', value);
    }
    get _optionPath() {
        return 'border';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoVectorMapBorderComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoVectorMapBorderComponent, isStandalone: true, selector: "dxo-vector-map-border", inputs: { color: "color", cornerRadius: "cornerRadius", dashStyle: "dashStyle", opacity: "opacity", visible: "visible", width: "width" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoVectorMapBorderComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-vector-map-border', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { color: [{
                type: Input
            }], cornerRadius: [{
                type: Input
            }], dashStyle: [{
                type: Input
            }], opacity: [{
                type: Input
            }], visible: [{
                type: Input
            }], width: [{
                type: Input
            }] } });
class DxoVectorMapBorderModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoVectorMapBorderModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoVectorMapBorderModule, imports: [DxoVectorMapBorderComponent], exports: [DxoVectorMapBorderComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoVectorMapBorderModule, imports: [DxoVectorMapBorderComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoVectorMapBorderModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoVectorMapBorderComponent
                    ],
                    exports: [
                        DxoVectorMapBorderComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoVectorMapCommonAnnotationSettingsComponent extends NestedOption {
    get allowDragging() {
        return this._getOption('allowDragging');
    }
    set allowDragging(value) {
        this._setOption('allowDragging', value);
    }
    get arrowLength() {
        return this._getOption('arrowLength');
    }
    set arrowLength(value) {
        this._setOption('arrowLength', value);
    }
    get arrowWidth() {
        return this._getOption('arrowWidth');
    }
    set arrowWidth(value) {
        this._setOption('arrowWidth', value);
    }
    get border() {
        return this._getOption('border');
    }
    set border(value) {
        this._setOption('border', value);
    }
    get color() {
        return this._getOption('color');
    }
    set color(value) {
        this._setOption('color', value);
    }
    get coordinates() {
        return this._getOption('coordinates');
    }
    set coordinates(value) {
        this._setOption('coordinates', value);
    }
    get customizeTooltip() {
        return this._getOption('customizeTooltip');
    }
    set customizeTooltip(value) {
        this._setOption('customizeTooltip', value);
    }
    get data() {
        return this._getOption('data');
    }
    set data(value) {
        this._setOption('data', value);
    }
    get description() {
        return this._getOption('description');
    }
    set description(value) {
        this._setOption('description', value);
    }
    get font() {
        return this._getOption('font');
    }
    set font(value) {
        this._setOption('font', value);
    }
    get height() {
        return this._getOption('height');
    }
    set height(value) {
        this._setOption('height', value);
    }
    get image() {
        return this._getOption('image');
    }
    set image(value) {
        this._setOption('image', value);
    }
    get offsetX() {
        return this._getOption('offsetX');
    }
    set offsetX(value) {
        this._setOption('offsetX', value);
    }
    get offsetY() {
        return this._getOption('offsetY');
    }
    set offsetY(value) {
        this._setOption('offsetY', value);
    }
    get opacity() {
        return this._getOption('opacity');
    }
    set opacity(value) {
        this._setOption('opacity', value);
    }
    get paddingLeftRight() {
        return this._getOption('paddingLeftRight');
    }
    set paddingLeftRight(value) {
        this._setOption('paddingLeftRight', value);
    }
    get paddingTopBottom() {
        return this._getOption('paddingTopBottom');
    }
    set paddingTopBottom(value) {
        this._setOption('paddingTopBottom', value);
    }
    get shadow() {
        return this._getOption('shadow');
    }
    set shadow(value) {
        this._setOption('shadow', value);
    }
    get template() {
        return this._getOption('template');
    }
    set template(value) {
        this._setOption('template', value);
    }
    get text() {
        return this._getOption('text');
    }
    set text(value) {
        this._setOption('text', value);
    }
    get textOverflow() {
        return this._getOption('textOverflow');
    }
    set textOverflow(value) {
        this._setOption('textOverflow', value);
    }
    get tooltipEnabled() {
        return this._getOption('tooltipEnabled');
    }
    set tooltipEnabled(value) {
        this._setOption('tooltipEnabled', value);
    }
    get tooltipTemplate() {
        return this._getOption('tooltipTemplate');
    }
    set tooltipTemplate(value) {
        this._setOption('tooltipTemplate', value);
    }
    get type() {
        return this._getOption('type');
    }
    set type(value) {
        this._setOption('type', value);
    }
    get width() {
        return this._getOption('width');
    }
    set width(value) {
        this._setOption('width', value);
    }
    get wordWrap() {
        return this._getOption('wordWrap');
    }
    set wordWrap(value) {
        this._setOption('wordWrap', value);
    }
    get x() {
        return this._getOption('x');
    }
    set x(value) {
        this._setOption('x', value);
    }
    get y() {
        return this._getOption('y');
    }
    set y(value) {
        this._setOption('y', value);
    }
    get _optionPath() {
        return 'commonAnnotationSettings';
    }
    constructor(parentOptionHost, optionHost, renderer, document, templateHost, element) {
        super();
        this.renderer = renderer;
        this.document = document;
        this.element = element;
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
        templateHost.setHost(this);
    }
    setTemplate(template) {
        this.template = template;
    }
    ngAfterViewInit() {
        extractTemplate(this, this.element, this.renderer, this.document);
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoVectorMapCommonAnnotationSettingsComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }, { token: i0.Renderer2 }, { token: DOCUMENT }, { token: i1.DxTemplateHost, host: true }, { token: i0.ElementRef }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoVectorMapCommonAnnotationSettingsComponent, isStandalone: true, selector: "dxo-vector-map-common-annotation-settings", inputs: { allowDragging: "allowDragging", arrowLength: "arrowLength", arrowWidth: "arrowWidth", border: "border", color: "color", coordinates: "coordinates", customizeTooltip: "customizeTooltip", data: "data", description: "description", font: "font", height: "height", image: "image", offsetX: "offsetX", offsetY: "offsetY", opacity: "opacity", paddingLeftRight: "paddingLeftRight", paddingTopBottom: "paddingTopBottom", shadow: "shadow", template: "template", text: "text", textOverflow: "textOverflow", tooltipEnabled: "tooltipEnabled", tooltipTemplate: "tooltipTemplate", type: "type", width: "width", wordWrap: "wordWrap", x: "x", y: "y" }, providers: [NestedOptionHost, DxTemplateHost], usesInheritance: true, ngImport: i0, template: '<ng-content></ng-content>', isInline: true, styles: [":host{display:block}\n"], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoVectorMapCommonAnnotationSettingsComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-vector-map-common-annotation-settings', template: '<ng-content></ng-content>', imports: [DxIntegrationModule], providers: [NestedOptionHost, DxTemplateHost], styles: [":host{display:block}\n"] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }, { type: i0.Renderer2 }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [DOCUMENT]
                }] }, { type: i1.DxTemplateHost, decorators: [{
                    type: Host
                }] }, { type: i0.ElementRef }], propDecorators: { allowDragging: [{
                type: Input
            }], arrowLength: [{
                type: Input
            }], arrowWidth: [{
                type: Input
            }], border: [{
                type: Input
            }], color: [{
                type: Input
            }], coordinates: [{
                type: Input
            }], customizeTooltip: [{
                type: Input
            }], data: [{
                type: Input
            }], description: [{
                type: Input
            }], font: [{
                type: Input
            }], height: [{
                type: Input
            }], image: [{
                type: Input
            }], offsetX: [{
                type: Input
            }], offsetY: [{
                type: Input
            }], opacity: [{
                type: Input
            }], paddingLeftRight: [{
                type: Input
            }], paddingTopBottom: [{
                type: Input
            }], shadow: [{
                type: Input
            }], template: [{
                type: Input
            }], text: [{
                type: Input
            }], textOverflow: [{
                type: Input
            }], tooltipEnabled: [{
                type: Input
            }], tooltipTemplate: [{
                type: Input
            }], type: [{
                type: Input
            }], width: [{
                type: Input
            }], wordWrap: [{
                type: Input
            }], x: [{
                type: Input
            }], y: [{
                type: Input
            }] } });
class DxoVectorMapCommonAnnotationSettingsModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoVectorMapCommonAnnotationSettingsModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoVectorMapCommonAnnotationSettingsModule, imports: [DxoVectorMapCommonAnnotationSettingsComponent], exports: [DxoVectorMapCommonAnnotationSettingsComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoVectorMapCommonAnnotationSettingsModule, imports: [DxoVectorMapCommonAnnotationSettingsComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoVectorMapCommonAnnotationSettingsModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoVectorMapCommonAnnotationSettingsComponent
                    ],
                    exports: [
                        DxoVectorMapCommonAnnotationSettingsComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoVectorMapControlBarComponent extends NestedOption {
    get borderColor() {
        return this._getOption('borderColor');
    }
    set borderColor(value) {
        this._setOption('borderColor', value);
    }
    get color() {
        return this._getOption('color');
    }
    set color(value) {
        this._setOption('color', value);
    }
    get enabled() {
        return this._getOption('enabled');
    }
    set enabled(value) {
        this._setOption('enabled', value);
    }
    get horizontalAlignment() {
        return this._getOption('horizontalAlignment');
    }
    set horizontalAlignment(value) {
        this._setOption('horizontalAlignment', value);
    }
    get margin() {
        return this._getOption('margin');
    }
    set margin(value) {
        this._setOption('margin', value);
    }
    get opacity() {
        return this._getOption('opacity');
    }
    set opacity(value) {
        this._setOption('opacity', value);
    }
    get panVisible() {
        return this._getOption('panVisible');
    }
    set panVisible(value) {
        this._setOption('panVisible', value);
    }
    get verticalAlignment() {
        return this._getOption('verticalAlignment');
    }
    set verticalAlignment(value) {
        this._setOption('verticalAlignment', value);
    }
    get zoomVisible() {
        return this._getOption('zoomVisible');
    }
    set zoomVisible(value) {
        this._setOption('zoomVisible', value);
    }
    get _optionPath() {
        return 'controlBar';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoVectorMapControlBarComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoVectorMapControlBarComponent, isStandalone: true, selector: "dxo-vector-map-control-bar", inputs: { borderColor: "borderColor", color: "color", enabled: "enabled", horizontalAlignment: "horizontalAlignment", margin: "margin", opacity: "opacity", panVisible: "panVisible", verticalAlignment: "verticalAlignment", zoomVisible: "zoomVisible" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoVectorMapControlBarComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-vector-map-control-bar', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { borderColor: [{
                type: Input
            }], color: [{
                type: Input
            }], enabled: [{
                type: Input
            }], horizontalAlignment: [{
                type: Input
            }], margin: [{
                type: Input
            }], opacity: [{
                type: Input
            }], panVisible: [{
                type: Input
            }], verticalAlignment: [{
                type: Input
            }], zoomVisible: [{
                type: Input
            }] } });
class DxoVectorMapControlBarModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoVectorMapControlBarModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoVectorMapControlBarModule, imports: [DxoVectorMapControlBarComponent], exports: [DxoVectorMapControlBarComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoVectorMapControlBarModule, imports: [DxoVectorMapControlBarComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoVectorMapControlBarModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoVectorMapControlBarComponent
                    ],
                    exports: [
                        DxoVectorMapControlBarComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoVectorMapExportComponent extends NestedOption {
    get backgroundColor() {
        return this._getOption('backgroundColor');
    }
    set backgroundColor(value) {
        this._setOption('backgroundColor', value);
    }
    get enabled() {
        return this._getOption('enabled');
    }
    set enabled(value) {
        this._setOption('enabled', value);
    }
    get fileName() {
        return this._getOption('fileName');
    }
    set fileName(value) {
        this._setOption('fileName', value);
    }
    get formats() {
        return this._getOption('formats');
    }
    set formats(value) {
        this._setOption('formats', value);
    }
    get margin() {
        return this._getOption('margin');
    }
    set margin(value) {
        this._setOption('margin', value);
    }
    get printingEnabled() {
        return this._getOption('printingEnabled');
    }
    set printingEnabled(value) {
        this._setOption('printingEnabled', value);
    }
    get svgToCanvas() {
        return this._getOption('svgToCanvas');
    }
    set svgToCanvas(value) {
        this._setOption('svgToCanvas', value);
    }
    get _optionPath() {
        return 'export';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoVectorMapExportComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoVectorMapExportComponent, isStandalone: true, selector: "dxo-vector-map-export", inputs: { backgroundColor: "backgroundColor", enabled: "enabled", fileName: "fileName", formats: "formats", margin: "margin", printingEnabled: "printingEnabled", svgToCanvas: "svgToCanvas" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoVectorMapExportComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-vector-map-export', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { backgroundColor: [{
                type: Input
            }], enabled: [{
                type: Input
            }], fileName: [{
                type: Input
            }], formats: [{
                type: Input
            }], margin: [{
                type: Input
            }], printingEnabled: [{
                type: Input
            }], svgToCanvas: [{
                type: Input
            }] } });
class DxoVectorMapExportModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoVectorMapExportModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoVectorMapExportModule, imports: [DxoVectorMapExportComponent], exports: [DxoVectorMapExportComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoVectorMapExportModule, imports: [DxoVectorMapExportComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoVectorMapExportModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoVectorMapExportComponent
                    ],
                    exports: [
                        DxoVectorMapExportComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoVectorMapFontComponent extends NestedOption {
    get color() {
        return this._getOption('color');
    }
    set color(value) {
        this._setOption('color', value);
    }
    get family() {
        return this._getOption('family');
    }
    set family(value) {
        this._setOption('family', value);
    }
    get opacity() {
        return this._getOption('opacity');
    }
    set opacity(value) {
        this._setOption('opacity', value);
    }
    get size() {
        return this._getOption('size');
    }
    set size(value) {
        this._setOption('size', value);
    }
    get weight() {
        return this._getOption('weight');
    }
    set weight(value) {
        this._setOption('weight', value);
    }
    get _optionPath() {
        return 'font';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoVectorMapFontComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoVectorMapFontComponent, isStandalone: true, selector: "dxo-vector-map-font", inputs: { color: "color", family: "family", opacity: "opacity", size: "size", weight: "weight" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoVectorMapFontComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-vector-map-font', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { color: [{
                type: Input
            }], family: [{
                type: Input
            }], opacity: [{
                type: Input
            }], size: [{
                type: Input
            }], weight: [{
                type: Input
            }] } });
class DxoVectorMapFontModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoVectorMapFontModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoVectorMapFontModule, imports: [DxoVectorMapFontComponent], exports: [DxoVectorMapFontComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoVectorMapFontModule, imports: [DxoVectorMapFontComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoVectorMapFontModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoVectorMapFontComponent
                    ],
                    exports: [
                        DxoVectorMapFontComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoVectorMapImageComponent extends NestedOption {
    get height() {
        return this._getOption('height');
    }
    set height(value) {
        this._setOption('height', value);
    }
    get url() {
        return this._getOption('url');
    }
    set url(value) {
        this._setOption('url', value);
    }
    get width() {
        return this._getOption('width');
    }
    set width(value) {
        this._setOption('width', value);
    }
    get _optionPath() {
        return 'image';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoVectorMapImageComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoVectorMapImageComponent, isStandalone: true, selector: "dxo-vector-map-image", inputs: { height: "height", url: "url", width: "width" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoVectorMapImageComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-vector-map-image', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { height: [{
                type: Input
            }], url: [{
                type: Input
            }], width: [{
                type: Input
            }] } });
class DxoVectorMapImageModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoVectorMapImageModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoVectorMapImageModule, imports: [DxoVectorMapImageComponent], exports: [DxoVectorMapImageComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoVectorMapImageModule, imports: [DxoVectorMapImageComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoVectorMapImageModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoVectorMapImageComponent
                    ],
                    exports: [
                        DxoVectorMapImageComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoVectorMapLabelComponent extends NestedOption {
    get dataField() {
        return this._getOption('dataField');
    }
    set dataField(value) {
        this._setOption('dataField', value);
    }
    get enabled() {
        return this._getOption('enabled');
    }
    set enabled(value) {
        this._setOption('enabled', value);
    }
    get font() {
        return this._getOption('font');
    }
    set font(value) {
        this._setOption('font', value);
    }
    get _optionPath() {
        return 'label';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoVectorMapLabelComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoVectorMapLabelComponent, isStandalone: true, selector: "dxo-vector-map-label", inputs: { dataField: "dataField", enabled: "enabled", font: "font" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoVectorMapLabelComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-vector-map-label', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { dataField: [{
                type: Input
            }], enabled: [{
                type: Input
            }], font: [{
                type: Input
            }] } });
class DxoVectorMapLabelModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoVectorMapLabelModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoVectorMapLabelModule, imports: [DxoVectorMapLabelComponent], exports: [DxoVectorMapLabelComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoVectorMapLabelModule, imports: [DxoVectorMapLabelComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoVectorMapLabelModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoVectorMapLabelComponent
                    ],
                    exports: [
                        DxoVectorMapLabelComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxiVectorMapLayerComponent extends CollectionNestedOption {
    get borderColor() {
        return this._getOption('borderColor');
    }
    set borderColor(value) {
        this._setOption('borderColor', value);
    }
    get borderWidth() {
        return this._getOption('borderWidth');
    }
    set borderWidth(value) {
        this._setOption('borderWidth', value);
    }
    get color() {
        return this._getOption('color');
    }
    set color(value) {
        this._setOption('color', value);
    }
    get colorGroupingField() {
        return this._getOption('colorGroupingField');
    }
    set colorGroupingField(value) {
        this._setOption('colorGroupingField', value);
    }
    get colorGroups() {
        return this._getOption('colorGroups');
    }
    set colorGroups(value) {
        this._setOption('colorGroups', value);
    }
    get customize() {
        return this._getOption('customize');
    }
    set customize(value) {
        this._setOption('customize', value);
    }
    get dataField() {
        return this._getOption('dataField');
    }
    set dataField(value) {
        this._setOption('dataField', value);
    }
    get dataSource() {
        return this._getOption('dataSource');
    }
    set dataSource(value) {
        this._setOption('dataSource', value);
    }
    get elementType() {
        return this._getOption('elementType');
    }
    set elementType(value) {
        this._setOption('elementType', value);
    }
    get hoveredBorderColor() {
        return this._getOption('hoveredBorderColor');
    }
    set hoveredBorderColor(value) {
        this._setOption('hoveredBorderColor', value);
    }
    get hoveredBorderWidth() {
        return this._getOption('hoveredBorderWidth');
    }
    set hoveredBorderWidth(value) {
        this._setOption('hoveredBorderWidth', value);
    }
    get hoveredColor() {
        return this._getOption('hoveredColor');
    }
    set hoveredColor(value) {
        this._setOption('hoveredColor', value);
    }
    get hoverEnabled() {
        return this._getOption('hoverEnabled');
    }
    set hoverEnabled(value) {
        this._setOption('hoverEnabled', value);
    }
    get label() {
        return this._getOption('label');
    }
    set label(value) {
        this._setOption('label', value);
    }
    get maxSize() {
        return this._getOption('maxSize');
    }
    set maxSize(value) {
        this._setOption('maxSize', value);
    }
    get minSize() {
        return this._getOption('minSize');
    }
    set minSize(value) {
        this._setOption('minSize', value);
    }
    get name() {
        return this._getOption('name');
    }
    set name(value) {
        this._setOption('name', value);
    }
    get opacity() {
        return this._getOption('opacity');
    }
    set opacity(value) {
        this._setOption('opacity', value);
    }
    get palette() {
        return this._getOption('palette');
    }
    set palette(value) {
        this._setOption('palette', value);
    }
    get paletteIndex() {
        return this._getOption('paletteIndex');
    }
    set paletteIndex(value) {
        this._setOption('paletteIndex', value);
    }
    get paletteSize() {
        return this._getOption('paletteSize');
    }
    set paletteSize(value) {
        this._setOption('paletteSize', value);
    }
    get selectedBorderColor() {
        return this._getOption('selectedBorderColor');
    }
    set selectedBorderColor(value) {
        this._setOption('selectedBorderColor', value);
    }
    get selectedBorderWidth() {
        return this._getOption('selectedBorderWidth');
    }
    set selectedBorderWidth(value) {
        this._setOption('selectedBorderWidth', value);
    }
    get selectedColor() {
        return this._getOption('selectedColor');
    }
    set selectedColor(value) {
        this._setOption('selectedColor', value);
    }
    get selectionMode() {
        return this._getOption('selectionMode');
    }
    set selectionMode(value) {
        this._setOption('selectionMode', value);
    }
    get size() {
        return this._getOption('size');
    }
    set size(value) {
        this._setOption('size', value);
    }
    get sizeGroupingField() {
        return this._getOption('sizeGroupingField');
    }
    set sizeGroupingField(value) {
        this._setOption('sizeGroupingField', value);
    }
    get sizeGroups() {
        return this._getOption('sizeGroups');
    }
    set sizeGroups(value) {
        this._setOption('sizeGroups', value);
    }
    get type() {
        return this._getOption('type');
    }
    set type(value) {
        this._setOption('type', value);
    }
    get _optionPath() {
        return 'layers';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnDestroy() {
        this._deleteRemovedOptions(this._fullOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiVectorMapLayerComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxiVectorMapLayerComponent, isStandalone: true, selector: "dxi-vector-map-layer", inputs: { borderColor: "borderColor", borderWidth: "borderWidth", color: "color", colorGroupingField: "colorGroupingField", colorGroups: "colorGroups", customize: "customize", dataField: "dataField", dataSource: "dataSource", elementType: "elementType", hoveredBorderColor: "hoveredBorderColor", hoveredBorderWidth: "hoveredBorderWidth", hoveredColor: "hoveredColor", hoverEnabled: "hoverEnabled", label: "label", maxSize: "maxSize", minSize: "minSize", name: "name", opacity: "opacity", palette: "palette", paletteIndex: "paletteIndex", paletteSize: "paletteSize", selectedBorderColor: "selectedBorderColor", selectedBorderWidth: "selectedBorderWidth", selectedColor: "selectedColor", selectionMode: "selectionMode", size: "size", sizeGroupingField: "sizeGroupingField", sizeGroups: "sizeGroups", type: "type" }, providers: [
            NestedOptionHost,
            {
                provide: PROPERTY_TOKEN_layers,
                useExisting: DxiVectorMapLayerComponent,
            }
        ], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiVectorMapLayerComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxi-vector-map-layer', template: '', imports: [DxIntegrationModule], providers: [
                        NestedOptionHost,
                        {
                            provide: PROPERTY_TOKEN_layers,
                            useExisting: DxiVectorMapLayerComponent,
                        }
                    ] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { borderColor: [{
                type: Input
            }], borderWidth: [{
                type: Input
            }], color: [{
                type: Input
            }], colorGroupingField: [{
                type: Input
            }], colorGroups: [{
                type: Input
            }], customize: [{
                type: Input
            }], dataField: [{
                type: Input
            }], dataSource: [{
                type: Input
            }], elementType: [{
                type: Input
            }], hoveredBorderColor: [{
                type: Input
            }], hoveredBorderWidth: [{
                type: Input
            }], hoveredColor: [{
                type: Input
            }], hoverEnabled: [{
                type: Input
            }], label: [{
                type: Input
            }], maxSize: [{
                type: Input
            }], minSize: [{
                type: Input
            }], name: [{
                type: Input
            }], opacity: [{
                type: Input
            }], palette: [{
                type: Input
            }], paletteIndex: [{
                type: Input
            }], paletteSize: [{
                type: Input
            }], selectedBorderColor: [{
                type: Input
            }], selectedBorderWidth: [{
                type: Input
            }], selectedColor: [{
                type: Input
            }], selectionMode: [{
                type: Input
            }], size: [{
                type: Input
            }], sizeGroupingField: [{
                type: Input
            }], sizeGroups: [{
                type: Input
            }], type: [{
                type: Input
            }] } });
class DxiVectorMapLayerModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiVectorMapLayerModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxiVectorMapLayerModule, imports: [DxiVectorMapLayerComponent], exports: [DxiVectorMapLayerComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiVectorMapLayerModule, imports: [DxiVectorMapLayerComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiVectorMapLayerModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxiVectorMapLayerComponent
                    ],
                    exports: [
                        DxiVectorMapLayerComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxiVectorMapLegendComponent extends CollectionNestedOption {
    get backgroundColor() {
        return this._getOption('backgroundColor');
    }
    set backgroundColor(value) {
        this._setOption('backgroundColor', value);
    }
    get border() {
        return this._getOption('border');
    }
    set border(value) {
        this._setOption('border', value);
    }
    get columnCount() {
        return this._getOption('columnCount');
    }
    set columnCount(value) {
        this._setOption('columnCount', value);
    }
    get columnItemSpacing() {
        return this._getOption('columnItemSpacing');
    }
    set columnItemSpacing(value) {
        this._setOption('columnItemSpacing', value);
    }
    get customizeHint() {
        return this._getOption('customizeHint');
    }
    set customizeHint(value) {
        this._setOption('customizeHint', value);
    }
    get customizeItems() {
        return this._getOption('customizeItems');
    }
    set customizeItems(value) {
        this._setOption('customizeItems', value);
    }
    get customizeText() {
        return this._getOption('customizeText');
    }
    set customizeText(value) {
        this._setOption('customizeText', value);
    }
    get font() {
        return this._getOption('font');
    }
    set font(value) {
        this._setOption('font', value);
    }
    get horizontalAlignment() {
        return this._getOption('horizontalAlignment');
    }
    set horizontalAlignment(value) {
        this._setOption('horizontalAlignment', value);
    }
    get itemsAlignment() {
        return this._getOption('itemsAlignment');
    }
    set itemsAlignment(value) {
        this._setOption('itemsAlignment', value);
    }
    get itemTextPosition() {
        return this._getOption('itemTextPosition');
    }
    set itemTextPosition(value) {
        this._setOption('itemTextPosition', value);
    }
    get margin() {
        return this._getOption('margin');
    }
    set margin(value) {
        this._setOption('margin', value);
    }
    get markerColor() {
        return this._getOption('markerColor');
    }
    set markerColor(value) {
        this._setOption('markerColor', value);
    }
    get markerShape() {
        return this._getOption('markerShape');
    }
    set markerShape(value) {
        this._setOption('markerShape', value);
    }
    get markerSize() {
        return this._getOption('markerSize');
    }
    set markerSize(value) {
        this._setOption('markerSize', value);
    }
    get markerTemplate() {
        return this._getOption('markerTemplate');
    }
    set markerTemplate(value) {
        this._setOption('markerTemplate', value);
    }
    get orientation() {
        return this._getOption('orientation');
    }
    set orientation(value) {
        this._setOption('orientation', value);
    }
    get paddingLeftRight() {
        return this._getOption('paddingLeftRight');
    }
    set paddingLeftRight(value) {
        this._setOption('paddingLeftRight', value);
    }
    get paddingTopBottom() {
        return this._getOption('paddingTopBottom');
    }
    set paddingTopBottom(value) {
        this._setOption('paddingTopBottom', value);
    }
    get rowCount() {
        return this._getOption('rowCount');
    }
    set rowCount(value) {
        this._setOption('rowCount', value);
    }
    get rowItemSpacing() {
        return this._getOption('rowItemSpacing');
    }
    set rowItemSpacing(value) {
        this._setOption('rowItemSpacing', value);
    }
    get source() {
        return this._getOption('source');
    }
    set source(value) {
        this._setOption('source', value);
    }
    get title() {
        return this._getOption('title');
    }
    set title(value) {
        this._setOption('title', value);
    }
    get verticalAlignment() {
        return this._getOption('verticalAlignment');
    }
    set verticalAlignment(value) {
        this._setOption('verticalAlignment', value);
    }
    get visible() {
        return this._getOption('visible');
    }
    set visible(value) {
        this._setOption('visible', value);
    }
    get _optionPath() {
        return 'legends';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnDestroy() {
        this._deleteRemovedOptions(this._fullOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiVectorMapLegendComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxiVectorMapLegendComponent, isStandalone: true, selector: "dxi-vector-map-legend", inputs: { backgroundColor: "backgroundColor", border: "border", columnCount: "columnCount", columnItemSpacing: "columnItemSpacing", customizeHint: "customizeHint", customizeItems: "customizeItems", customizeText: "customizeText", font: "font", horizontalAlignment: "horizontalAlignment", itemsAlignment: "itemsAlignment", itemTextPosition: "itemTextPosition", margin: "margin", markerColor: "markerColor", markerShape: "markerShape", markerSize: "markerSize", markerTemplate: "markerTemplate", orientation: "orientation", paddingLeftRight: "paddingLeftRight", paddingTopBottom: "paddingTopBottom", rowCount: "rowCount", rowItemSpacing: "rowItemSpacing", source: "source", title: "title", verticalAlignment: "verticalAlignment", visible: "visible" }, providers: [
            NestedOptionHost,
            {
                provide: PROPERTY_TOKEN_legends,
                useExisting: DxiVectorMapLegendComponent,
            }
        ], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiVectorMapLegendComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxi-vector-map-legend', template: '', imports: [DxIntegrationModule], providers: [
                        NestedOptionHost,
                        {
                            provide: PROPERTY_TOKEN_legends,
                            useExisting: DxiVectorMapLegendComponent,
                        }
                    ] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { backgroundColor: [{
                type: Input
            }], border: [{
                type: Input
            }], columnCount: [{
                type: Input
            }], columnItemSpacing: [{
                type: Input
            }], customizeHint: [{
                type: Input
            }], customizeItems: [{
                type: Input
            }], customizeText: [{
                type: Input
            }], font: [{
                type: Input
            }], horizontalAlignment: [{
                type: Input
            }], itemsAlignment: [{
                type: Input
            }], itemTextPosition: [{
                type: Input
            }], margin: [{
                type: Input
            }], markerColor: [{
                type: Input
            }], markerShape: [{
                type: Input
            }], markerSize: [{
                type: Input
            }], markerTemplate: [{
                type: Input
            }], orientation: [{
                type: Input
            }], paddingLeftRight: [{
                type: Input
            }], paddingTopBottom: [{
                type: Input
            }], rowCount: [{
                type: Input
            }], rowItemSpacing: [{
                type: Input
            }], source: [{
                type: Input
            }], title: [{
                type: Input
            }], verticalAlignment: [{
                type: Input
            }], visible: [{
                type: Input
            }] } });
class DxiVectorMapLegendModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiVectorMapLegendModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxiVectorMapLegendModule, imports: [DxiVectorMapLegendComponent], exports: [DxiVectorMapLegendComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiVectorMapLegendModule, imports: [DxiVectorMapLegendComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiVectorMapLegendModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxiVectorMapLegendComponent
                    ],
                    exports: [
                        DxiVectorMapLegendComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoVectorMapLegendTitleSubtitleComponent extends NestedOption {
    get font() {
        return this._getOption('font');
    }
    set font(value) {
        this._setOption('font', value);
    }
    get offset() {
        return this._getOption('offset');
    }
    set offset(value) {
        this._setOption('offset', value);
    }
    get text() {
        return this._getOption('text');
    }
    set text(value) {
        this._setOption('text', value);
    }
    get _optionPath() {
        return 'subtitle';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoVectorMapLegendTitleSubtitleComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoVectorMapLegendTitleSubtitleComponent, isStandalone: true, selector: "dxo-vector-map-legend-title-subtitle", inputs: { font: "font", offset: "offset", text: "text" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoVectorMapLegendTitleSubtitleComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-vector-map-legend-title-subtitle', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { font: [{
                type: Input
            }], offset: [{
                type: Input
            }], text: [{
                type: Input
            }] } });
class DxoVectorMapLegendTitleSubtitleModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoVectorMapLegendTitleSubtitleModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoVectorMapLegendTitleSubtitleModule, imports: [DxoVectorMapLegendTitleSubtitleComponent], exports: [DxoVectorMapLegendTitleSubtitleComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoVectorMapLegendTitleSubtitleModule, imports: [DxoVectorMapLegendTitleSubtitleComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoVectorMapLegendTitleSubtitleModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoVectorMapLegendTitleSubtitleComponent
                    ],
                    exports: [
                        DxoVectorMapLegendTitleSubtitleComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoVectorMapLegendTitleComponent extends NestedOption {
    get font() {
        return this._getOption('font');
    }
    set font(value) {
        this._setOption('font', value);
    }
    get horizontalAlignment() {
        return this._getOption('horizontalAlignment');
    }
    set horizontalAlignment(value) {
        this._setOption('horizontalAlignment', value);
    }
    get margin() {
        return this._getOption('margin');
    }
    set margin(value) {
        this._setOption('margin', value);
    }
    get placeholderSize() {
        return this._getOption('placeholderSize');
    }
    set placeholderSize(value) {
        this._setOption('placeholderSize', value);
    }
    get subtitle() {
        return this._getOption('subtitle');
    }
    set subtitle(value) {
        this._setOption('subtitle', value);
    }
    get text() {
        return this._getOption('text');
    }
    set text(value) {
        this._setOption('text', value);
    }
    get verticalAlignment() {
        return this._getOption('verticalAlignment');
    }
    set verticalAlignment(value) {
        this._setOption('verticalAlignment', value);
    }
    get _optionPath() {
        return 'title';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoVectorMapLegendTitleComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoVectorMapLegendTitleComponent, isStandalone: true, selector: "dxo-vector-map-legend-title", inputs: { font: "font", horizontalAlignment: "horizontalAlignment", margin: "margin", placeholderSize: "placeholderSize", subtitle: "subtitle", text: "text", verticalAlignment: "verticalAlignment" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoVectorMapLegendTitleComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-vector-map-legend-title', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { font: [{
                type: Input
            }], horizontalAlignment: [{
                type: Input
            }], margin: [{
                type: Input
            }], placeholderSize: [{
                type: Input
            }], subtitle: [{
                type: Input
            }], text: [{
                type: Input
            }], verticalAlignment: [{
                type: Input
            }] } });
class DxoVectorMapLegendTitleModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoVectorMapLegendTitleModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoVectorMapLegendTitleModule, imports: [DxoVectorMapLegendTitleComponent], exports: [DxoVectorMapLegendTitleComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoVectorMapLegendTitleModule, imports: [DxoVectorMapLegendTitleComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoVectorMapLegendTitleModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoVectorMapLegendTitleComponent
                    ],
                    exports: [
                        DxoVectorMapLegendTitleComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoVectorMapLoadingIndicatorComponent extends NestedOption {
    get backgroundColor() {
        return this._getOption('backgroundColor');
    }
    set backgroundColor(value) {
        this._setOption('backgroundColor', value);
    }
    get enabled() {
        return this._getOption('enabled');
    }
    set enabled(value) {
        this._setOption('enabled', value);
    }
    get font() {
        return this._getOption('font');
    }
    set font(value) {
        this._setOption('font', value);
    }
    get show() {
        return this._getOption('show');
    }
    set show(value) {
        this._setOption('show', value);
    }
    get text() {
        return this._getOption('text');
    }
    set text(value) {
        this._setOption('text', value);
    }
    get _optionPath() {
        return 'loadingIndicator';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        this._createEventEmitters([
            { emit: 'showChange' }
        ]);
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoVectorMapLoadingIndicatorComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoVectorMapLoadingIndicatorComponent, isStandalone: true, selector: "dxo-vector-map-loading-indicator", inputs: { backgroundColor: "backgroundColor", enabled: "enabled", font: "font", show: "show", text: "text" }, outputs: { showChange: "showChange" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoVectorMapLoadingIndicatorComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-vector-map-loading-indicator', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { backgroundColor: [{
                type: Input
            }], enabled: [{
                type: Input
            }], font: [{
                type: Input
            }], show: [{
                type: Input
            }], text: [{
                type: Input
            }], showChange: [{
                type: Output
            }] } });
class DxoVectorMapLoadingIndicatorModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoVectorMapLoadingIndicatorModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoVectorMapLoadingIndicatorModule, imports: [DxoVectorMapLoadingIndicatorComponent], exports: [DxoVectorMapLoadingIndicatorComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoVectorMapLoadingIndicatorModule, imports: [DxoVectorMapLoadingIndicatorComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoVectorMapLoadingIndicatorModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoVectorMapLoadingIndicatorComponent
                    ],
                    exports: [
                        DxoVectorMapLoadingIndicatorComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoVectorMapMarginComponent extends NestedOption {
    get bottom() {
        return this._getOption('bottom');
    }
    set bottom(value) {
        this._setOption('bottom', value);
    }
    get left() {
        return this._getOption('left');
    }
    set left(value) {
        this._setOption('left', value);
    }
    get right() {
        return this._getOption('right');
    }
    set right(value) {
        this._setOption('right', value);
    }
    get top() {
        return this._getOption('top');
    }
    set top(value) {
        this._setOption('top', value);
    }
    get _optionPath() {
        return 'margin';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoVectorMapMarginComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoVectorMapMarginComponent, isStandalone: true, selector: "dxo-vector-map-margin", inputs: { bottom: "bottom", left: "left", right: "right", top: "top" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoVectorMapMarginComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-vector-map-margin', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { bottom: [{
                type: Input
            }], left: [{
                type: Input
            }], right: [{
                type: Input
            }], top: [{
                type: Input
            }] } });
class DxoVectorMapMarginModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoVectorMapMarginModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoVectorMapMarginModule, imports: [DxoVectorMapMarginComponent], exports: [DxoVectorMapMarginComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoVectorMapMarginModule, imports: [DxoVectorMapMarginComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoVectorMapMarginModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoVectorMapMarginComponent
                    ],
                    exports: [
                        DxoVectorMapMarginComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoVectorMapProjectionComponent extends NestedOption {
    get aspectRatio() {
        return this._getOption('aspectRatio');
    }
    set aspectRatio(value) {
        this._setOption('aspectRatio', value);
    }
    get from() {
        return this._getOption('from');
    }
    set from(value) {
        this._setOption('from', value);
    }
    get to() {
        return this._getOption('to');
    }
    set to(value) {
        this._setOption('to', value);
    }
    get _optionPath() {
        return 'projection';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoVectorMapProjectionComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoVectorMapProjectionComponent, isStandalone: true, selector: "dxo-vector-map-projection", inputs: { aspectRatio: "aspectRatio", from: "from", to: "to" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoVectorMapProjectionComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-vector-map-projection', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { aspectRatio: [{
                type: Input
            }], from: [{
                type: Input
            }], to: [{
                type: Input
            }] } });
class DxoVectorMapProjectionModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoVectorMapProjectionModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoVectorMapProjectionModule, imports: [DxoVectorMapProjectionComponent], exports: [DxoVectorMapProjectionComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoVectorMapProjectionModule, imports: [DxoVectorMapProjectionComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoVectorMapProjectionModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoVectorMapProjectionComponent
                    ],
                    exports: [
                        DxoVectorMapProjectionComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoVectorMapShadowComponent extends NestedOption {
    get blur() {
        return this._getOption('blur');
    }
    set blur(value) {
        this._setOption('blur', value);
    }
    get color() {
        return this._getOption('color');
    }
    set color(value) {
        this._setOption('color', value);
    }
    get offsetX() {
        return this._getOption('offsetX');
    }
    set offsetX(value) {
        this._setOption('offsetX', value);
    }
    get offsetY() {
        return this._getOption('offsetY');
    }
    set offsetY(value) {
        this._setOption('offsetY', value);
    }
    get opacity() {
        return this._getOption('opacity');
    }
    set opacity(value) {
        this._setOption('opacity', value);
    }
    get _optionPath() {
        return 'shadow';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoVectorMapShadowComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoVectorMapShadowComponent, isStandalone: true, selector: "dxo-vector-map-shadow", inputs: { blur: "blur", color: "color", offsetX: "offsetX", offsetY: "offsetY", opacity: "opacity" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoVectorMapShadowComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-vector-map-shadow', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { blur: [{
                type: Input
            }], color: [{
                type: Input
            }], offsetX: [{
                type: Input
            }], offsetY: [{
                type: Input
            }], opacity: [{
                type: Input
            }] } });
class DxoVectorMapShadowModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoVectorMapShadowModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoVectorMapShadowModule, imports: [DxoVectorMapShadowComponent], exports: [DxoVectorMapShadowComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoVectorMapShadowModule, imports: [DxoVectorMapShadowComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoVectorMapShadowModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoVectorMapShadowComponent
                    ],
                    exports: [
                        DxoVectorMapShadowComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoVectorMapSizeComponent extends NestedOption {
    get height() {
        return this._getOption('height');
    }
    set height(value) {
        this._setOption('height', value);
    }
    get width() {
        return this._getOption('width');
    }
    set width(value) {
        this._setOption('width', value);
    }
    get _optionPath() {
        return 'size';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoVectorMapSizeComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoVectorMapSizeComponent, isStandalone: true, selector: "dxo-vector-map-size", inputs: { height: "height", width: "width" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoVectorMapSizeComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-vector-map-size', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { height: [{
                type: Input
            }], width: [{
                type: Input
            }] } });
class DxoVectorMapSizeModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoVectorMapSizeModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoVectorMapSizeModule, imports: [DxoVectorMapSizeComponent], exports: [DxoVectorMapSizeComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoVectorMapSizeModule, imports: [DxoVectorMapSizeComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoVectorMapSizeModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoVectorMapSizeComponent
                    ],
                    exports: [
                        DxoVectorMapSizeComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoVectorMapSourceComponent extends NestedOption {
    get grouping() {
        return this._getOption('grouping');
    }
    set grouping(value) {
        this._setOption('grouping', value);
    }
    get layer() {
        return this._getOption('layer');
    }
    set layer(value) {
        this._setOption('layer', value);
    }
    get _optionPath() {
        return 'source';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoVectorMapSourceComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoVectorMapSourceComponent, isStandalone: true, selector: "dxo-vector-map-source", inputs: { grouping: "grouping", layer: "layer" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoVectorMapSourceComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-vector-map-source', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { grouping: [{
                type: Input
            }], layer: [{
                type: Input
            }] } });
class DxoVectorMapSourceModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoVectorMapSourceModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoVectorMapSourceModule, imports: [DxoVectorMapSourceComponent], exports: [DxoVectorMapSourceComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoVectorMapSourceModule, imports: [DxoVectorMapSourceComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoVectorMapSourceModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoVectorMapSourceComponent
                    ],
                    exports: [
                        DxoVectorMapSourceComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoVectorMapSubtitleComponent extends NestedOption {
    get font() {
        return this._getOption('font');
    }
    set font(value) {
        this._setOption('font', value);
    }
    get offset() {
        return this._getOption('offset');
    }
    set offset(value) {
        this._setOption('offset', value);
    }
    get text() {
        return this._getOption('text');
    }
    set text(value) {
        this._setOption('text', value);
    }
    get textOverflow() {
        return this._getOption('textOverflow');
    }
    set textOverflow(value) {
        this._setOption('textOverflow', value);
    }
    get wordWrap() {
        return this._getOption('wordWrap');
    }
    set wordWrap(value) {
        this._setOption('wordWrap', value);
    }
    get _optionPath() {
        return 'subtitle';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoVectorMapSubtitleComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoVectorMapSubtitleComponent, isStandalone: true, selector: "dxo-vector-map-subtitle", inputs: { font: "font", offset: "offset", text: "text", textOverflow: "textOverflow", wordWrap: "wordWrap" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoVectorMapSubtitleComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-vector-map-subtitle', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { font: [{
                type: Input
            }], offset: [{
                type: Input
            }], text: [{
                type: Input
            }], textOverflow: [{
                type: Input
            }], wordWrap: [{
                type: Input
            }] } });
class DxoVectorMapSubtitleModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoVectorMapSubtitleModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoVectorMapSubtitleModule, imports: [DxoVectorMapSubtitleComponent], exports: [DxoVectorMapSubtitleComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoVectorMapSubtitleModule, imports: [DxoVectorMapSubtitleComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoVectorMapSubtitleModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoVectorMapSubtitleComponent
                    ],
                    exports: [
                        DxoVectorMapSubtitleComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoVectorMapTitleComponent extends NestedOption {
    get font() {
        return this._getOption('font');
    }
    set font(value) {
        this._setOption('font', value);
    }
    get horizontalAlignment() {
        return this._getOption('horizontalAlignment');
    }
    set horizontalAlignment(value) {
        this._setOption('horizontalAlignment', value);
    }
    get margin() {
        return this._getOption('margin');
    }
    set margin(value) {
        this._setOption('margin', value);
    }
    get placeholderSize() {
        return this._getOption('placeholderSize');
    }
    set placeholderSize(value) {
        this._setOption('placeholderSize', value);
    }
    get subtitle() {
        return this._getOption('subtitle');
    }
    set subtitle(value) {
        this._setOption('subtitle', value);
    }
    get text() {
        return this._getOption('text');
    }
    set text(value) {
        this._setOption('text', value);
    }
    get verticalAlignment() {
        return this._getOption('verticalAlignment');
    }
    set verticalAlignment(value) {
        this._setOption('verticalAlignment', value);
    }
    get textOverflow() {
        return this._getOption('textOverflow');
    }
    set textOverflow(value) {
        this._setOption('textOverflow', value);
    }
    get wordWrap() {
        return this._getOption('wordWrap');
    }
    set wordWrap(value) {
        this._setOption('wordWrap', value);
    }
    get _optionPath() {
        return 'title';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoVectorMapTitleComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoVectorMapTitleComponent, isStandalone: true, selector: "dxo-vector-map-title", inputs: { font: "font", horizontalAlignment: "horizontalAlignment", margin: "margin", placeholderSize: "placeholderSize", subtitle: "subtitle", text: "text", verticalAlignment: "verticalAlignment", textOverflow: "textOverflow", wordWrap: "wordWrap" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoVectorMapTitleComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-vector-map-title', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { font: [{
                type: Input
            }], horizontalAlignment: [{
                type: Input
            }], margin: [{
                type: Input
            }], placeholderSize: [{
                type: Input
            }], subtitle: [{
                type: Input
            }], text: [{
                type: Input
            }], verticalAlignment: [{
                type: Input
            }], textOverflow: [{
                type: Input
            }], wordWrap: [{
                type: Input
            }] } });
class DxoVectorMapTitleModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoVectorMapTitleModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoVectorMapTitleModule, imports: [DxoVectorMapTitleComponent], exports: [DxoVectorMapTitleComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoVectorMapTitleModule, imports: [DxoVectorMapTitleComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoVectorMapTitleModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoVectorMapTitleComponent
                    ],
                    exports: [
                        DxoVectorMapTitleComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoVectorMapTooltipBorderComponent extends NestedOption {
    get color() {
        return this._getOption('color');
    }
    set color(value) {
        this._setOption('color', value);
    }
    get dashStyle() {
        return this._getOption('dashStyle');
    }
    set dashStyle(value) {
        this._setOption('dashStyle', value);
    }
    get opacity() {
        return this._getOption('opacity');
    }
    set opacity(value) {
        this._setOption('opacity', value);
    }
    get visible() {
        return this._getOption('visible');
    }
    set visible(value) {
        this._setOption('visible', value);
    }
    get width() {
        return this._getOption('width');
    }
    set width(value) {
        this._setOption('width', value);
    }
    get _optionPath() {
        return 'border';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoVectorMapTooltipBorderComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoVectorMapTooltipBorderComponent, isStandalone: true, selector: "dxo-vector-map-tooltip-border", inputs: { color: "color", dashStyle: "dashStyle", opacity: "opacity", visible: "visible", width: "width" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoVectorMapTooltipBorderComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-vector-map-tooltip-border', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { color: [{
                type: Input
            }], dashStyle: [{
                type: Input
            }], opacity: [{
                type: Input
            }], visible: [{
                type: Input
            }], width: [{
                type: Input
            }] } });
class DxoVectorMapTooltipBorderModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoVectorMapTooltipBorderModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoVectorMapTooltipBorderModule, imports: [DxoVectorMapTooltipBorderComponent], exports: [DxoVectorMapTooltipBorderComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoVectorMapTooltipBorderModule, imports: [DxoVectorMapTooltipBorderComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoVectorMapTooltipBorderModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoVectorMapTooltipBorderComponent
                    ],
                    exports: [
                        DxoVectorMapTooltipBorderComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoVectorMapTooltipComponent extends NestedOption {
    get arrowLength() {
        return this._getOption('arrowLength');
    }
    set arrowLength(value) {
        this._setOption('arrowLength', value);
    }
    get border() {
        return this._getOption('border');
    }
    set border(value) {
        this._setOption('border', value);
    }
    get color() {
        return this._getOption('color');
    }
    set color(value) {
        this._setOption('color', value);
    }
    get container() {
        return this._getOption('container');
    }
    set container(value) {
        this._setOption('container', value);
    }
    get contentTemplate() {
        return this._getOption('contentTemplate');
    }
    set contentTemplate(value) {
        this._setOption('contentTemplate', value);
    }
    get cornerRadius() {
        return this._getOption('cornerRadius');
    }
    set cornerRadius(value) {
        this._setOption('cornerRadius', value);
    }
    get customizeTooltip() {
        return this._getOption('customizeTooltip');
    }
    set customizeTooltip(value) {
        this._setOption('customizeTooltip', value);
    }
    get enabled() {
        return this._getOption('enabled');
    }
    set enabled(value) {
        this._setOption('enabled', value);
    }
    get font() {
        return this._getOption('font');
    }
    set font(value) {
        this._setOption('font', value);
    }
    get opacity() {
        return this._getOption('opacity');
    }
    set opacity(value) {
        this._setOption('opacity', value);
    }
    get paddingLeftRight() {
        return this._getOption('paddingLeftRight');
    }
    set paddingLeftRight(value) {
        this._setOption('paddingLeftRight', value);
    }
    get paddingTopBottom() {
        return this._getOption('paddingTopBottom');
    }
    set paddingTopBottom(value) {
        this._setOption('paddingTopBottom', value);
    }
    get shadow() {
        return this._getOption('shadow');
    }
    set shadow(value) {
        this._setOption('shadow', value);
    }
    get zIndex() {
        return this._getOption('zIndex');
    }
    set zIndex(value) {
        this._setOption('zIndex', value);
    }
    get _optionPath() {
        return 'tooltip';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoVectorMapTooltipComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoVectorMapTooltipComponent, isStandalone: true, selector: "dxo-vector-map-tooltip", inputs: { arrowLength: "arrowLength", border: "border", color: "color", container: "container", contentTemplate: "contentTemplate", cornerRadius: "cornerRadius", customizeTooltip: "customizeTooltip", enabled: "enabled", font: "font", opacity: "opacity", paddingLeftRight: "paddingLeftRight", paddingTopBottom: "paddingTopBottom", shadow: "shadow", zIndex: "zIndex" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoVectorMapTooltipComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-vector-map-tooltip', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { arrowLength: [{
                type: Input
            }], border: [{
                type: Input
            }], color: [{
                type: Input
            }], container: [{
                type: Input
            }], contentTemplate: [{
                type: Input
            }], cornerRadius: [{
                type: Input
            }], customizeTooltip: [{
                type: Input
            }], enabled: [{
                type: Input
            }], font: [{
                type: Input
            }], opacity: [{
                type: Input
            }], paddingLeftRight: [{
                type: Input
            }], paddingTopBottom: [{
                type: Input
            }], shadow: [{
                type: Input
            }], zIndex: [{
                type: Input
            }] } });
class DxoVectorMapTooltipModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoVectorMapTooltipModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoVectorMapTooltipModule, imports: [DxoVectorMapTooltipComponent], exports: [DxoVectorMapTooltipComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoVectorMapTooltipModule, imports: [DxoVectorMapTooltipComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoVectorMapTooltipModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoVectorMapTooltipComponent
                    ],
                    exports: [
                        DxoVectorMapTooltipComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoVectorMapVectorMapTitleSubtitleComponent extends NestedOption {
    get font() {
        return this._getOption('font');
    }
    set font(value) {
        this._setOption('font', value);
    }
    get offset() {
        return this._getOption('offset');
    }
    set offset(value) {
        this._setOption('offset', value);
    }
    get text() {
        return this._getOption('text');
    }
    set text(value) {
        this._setOption('text', value);
    }
    get textOverflow() {
        return this._getOption('textOverflow');
    }
    set textOverflow(value) {
        this._setOption('textOverflow', value);
    }
    get wordWrap() {
        return this._getOption('wordWrap');
    }
    set wordWrap(value) {
        this._setOption('wordWrap', value);
    }
    get _optionPath() {
        return 'subtitle';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoVectorMapVectorMapTitleSubtitleComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoVectorMapVectorMapTitleSubtitleComponent, isStandalone: true, selector: "dxo-vector-map-vector-map-title-subtitle", inputs: { font: "font", offset: "offset", text: "text", textOverflow: "textOverflow", wordWrap: "wordWrap" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoVectorMapVectorMapTitleSubtitleComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-vector-map-vector-map-title-subtitle', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { font: [{
                type: Input
            }], offset: [{
                type: Input
            }], text: [{
                type: Input
            }], textOverflow: [{
                type: Input
            }], wordWrap: [{
                type: Input
            }] } });
class DxoVectorMapVectorMapTitleSubtitleModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoVectorMapVectorMapTitleSubtitleModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoVectorMapVectorMapTitleSubtitleModule, imports: [DxoVectorMapVectorMapTitleSubtitleComponent], exports: [DxoVectorMapVectorMapTitleSubtitleComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoVectorMapVectorMapTitleSubtitleModule, imports: [DxoVectorMapVectorMapTitleSubtitleComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoVectorMapVectorMapTitleSubtitleModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoVectorMapVectorMapTitleSubtitleComponent
                    ],
                    exports: [
                        DxoVectorMapVectorMapTitleSubtitleComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoVectorMapVectorMapTitleComponent extends NestedOption {
    get font() {
        return this._getOption('font');
    }
    set font(value) {
        this._setOption('font', value);
    }
    get horizontalAlignment() {
        return this._getOption('horizontalAlignment');
    }
    set horizontalAlignment(value) {
        this._setOption('horizontalAlignment', value);
    }
    get margin() {
        return this._getOption('margin');
    }
    set margin(value) {
        this._setOption('margin', value);
    }
    get placeholderSize() {
        return this._getOption('placeholderSize');
    }
    set placeholderSize(value) {
        this._setOption('placeholderSize', value);
    }
    get subtitle() {
        return this._getOption('subtitle');
    }
    set subtitle(value) {
        this._setOption('subtitle', value);
    }
    get text() {
        return this._getOption('text');
    }
    set text(value) {
        this._setOption('text', value);
    }
    get textOverflow() {
        return this._getOption('textOverflow');
    }
    set textOverflow(value) {
        this._setOption('textOverflow', value);
    }
    get verticalAlignment() {
        return this._getOption('verticalAlignment');
    }
    set verticalAlignment(value) {
        this._setOption('verticalAlignment', value);
    }
    get wordWrap() {
        return this._getOption('wordWrap');
    }
    set wordWrap(value) {
        this._setOption('wordWrap', value);
    }
    get _optionPath() {
        return 'title';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoVectorMapVectorMapTitleComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoVectorMapVectorMapTitleComponent, isStandalone: true, selector: "dxo-vector-map-vector-map-title", inputs: { font: "font", horizontalAlignment: "horizontalAlignment", margin: "margin", placeholderSize: "placeholderSize", subtitle: "subtitle", text: "text", textOverflow: "textOverflow", verticalAlignment: "verticalAlignment", wordWrap: "wordWrap" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoVectorMapVectorMapTitleComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-vector-map-vector-map-title', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { font: [{
                type: Input
            }], horizontalAlignment: [{
                type: Input
            }], margin: [{
                type: Input
            }], placeholderSize: [{
                type: Input
            }], subtitle: [{
                type: Input
            }], text: [{
                type: Input
            }], textOverflow: [{
                type: Input
            }], verticalAlignment: [{
                type: Input
            }], wordWrap: [{
                type: Input
            }] } });
class DxoVectorMapVectorMapTitleModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoVectorMapVectorMapTitleModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoVectorMapVectorMapTitleModule, imports: [DxoVectorMapVectorMapTitleComponent], exports: [DxoVectorMapVectorMapTitleComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoVectorMapVectorMapTitleModule, imports: [DxoVectorMapVectorMapTitleComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoVectorMapVectorMapTitleModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoVectorMapVectorMapTitleComponent
                    ],
                    exports: [
                        DxoVectorMapVectorMapTitleComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

/**
 * Generated bundle index. Do not edit.
 */

export { DxiVectorMapAnnotationComponent, DxiVectorMapAnnotationModule, DxiVectorMapLayerComponent, DxiVectorMapLayerModule, DxiVectorMapLegendComponent, DxiVectorMapLegendModule, DxoVectorMapAnnotationBorderComponent, DxoVectorMapAnnotationBorderModule, DxoVectorMapBackgroundComponent, DxoVectorMapBackgroundModule, DxoVectorMapBorderComponent, DxoVectorMapBorderModule, DxoVectorMapCommonAnnotationSettingsComponent, DxoVectorMapCommonAnnotationSettingsModule, DxoVectorMapControlBarComponent, DxoVectorMapControlBarModule, DxoVectorMapExportComponent, DxoVectorMapExportModule, DxoVectorMapFontComponent, DxoVectorMapFontModule, DxoVectorMapImageComponent, DxoVectorMapImageModule, DxoVectorMapLabelComponent, DxoVectorMapLabelModule, DxoVectorMapLegendTitleComponent, DxoVectorMapLegendTitleModule, DxoVectorMapLegendTitleSubtitleComponent, DxoVectorMapLegendTitleSubtitleModule, DxoVectorMapLoadingIndicatorComponent, DxoVectorMapLoadingIndicatorModule, DxoVectorMapMarginComponent, DxoVectorMapMarginModule, DxoVectorMapProjectionComponent, DxoVectorMapProjectionModule, DxoVectorMapShadowComponent, DxoVectorMapShadowModule, DxoVectorMapSizeComponent, DxoVectorMapSizeModule, DxoVectorMapSourceComponent, DxoVectorMapSourceModule, DxoVectorMapSubtitleComponent, DxoVectorMapSubtitleModule, DxoVectorMapTitleComponent, DxoVectorMapTitleModule, DxoVectorMapTooltipBorderComponent, DxoVectorMapTooltipBorderModule, DxoVectorMapTooltipComponent, DxoVectorMapTooltipModule, DxoVectorMapVectorMapTitleComponent, DxoVectorMapVectorMapTitleModule, DxoVectorMapVectorMapTitleSubtitleComponent, DxoVectorMapVectorMapTitleSubtitleModule };
//# sourceMappingURL=devextreme-angular-ui-vector-map-nested.mjs.map
