export { ArrayStore, CustomStore, DataSource, EdmLiteral, EndpointSelector, LocalStore, ODataContext, ODataStore, applyChanges, base64_encode, compileGetter, compileSetter, errorHandler, isGroupItemsArray, isItemsArray, isLoadResultObject, keyConverters, query, setErrorHandler } from 'devextreme/common/data';

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

/**
 * Generated bundle index. Do not edit.
 */
//# sourceMappingURL=devextreme-angular-common-data.mjs.map
