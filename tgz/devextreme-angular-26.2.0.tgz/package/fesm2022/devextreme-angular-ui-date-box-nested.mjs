import * as i0 from '@angular/core';
import { Input, SkipSelf, Host, Component, NgModule, Output, ContentChildren, Inject } from '@angular/core';
import * as i1 from 'devextreme-angular/core';
import { NestedOption, DxIntegrationModule, NestedOptionHost, CollectionNestedOption, extractTemplate, DxTemplateHost } from 'devextreme-angular/core';
import { PROPERTY_TOKEN_buttons, PROPERTY_TOKEN_toolbarItems } from 'devextreme-angular/core/tokens';
import { DOCUMENT } from '@angular/common';

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoDateBoxAnimationComponent extends NestedOption {
    get hide() {
        return this._getOption('hide');
    }
    set hide(value) {
        this._setOption('hide', value);
    }
    get show() {
        return this._getOption('show');
    }
    set show(value) {
        this._setOption('show', value);
    }
    get _optionPath() {
        return 'animation';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDateBoxAnimationComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoDateBoxAnimationComponent, isStandalone: true, selector: "dxo-date-box-animation", inputs: { hide: "hide", show: "show" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDateBoxAnimationComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-date-box-animation', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { hide: [{
                type: Input
            }], show: [{
                type: Input
            }] } });
class DxoDateBoxAnimationModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDateBoxAnimationModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoDateBoxAnimationModule, imports: [DxoDateBoxAnimationComponent], exports: [DxoDateBoxAnimationComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDateBoxAnimationModule, imports: [DxoDateBoxAnimationComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDateBoxAnimationModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoDateBoxAnimationComponent
                    ],
                    exports: [
                        DxoDateBoxAnimationComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoDateBoxAtComponent extends NestedOption {
    get x() {
        return this._getOption('x');
    }
    set x(value) {
        this._setOption('x', value);
    }
    get y() {
        return this._getOption('y');
    }
    set y(value) {
        this._setOption('y', value);
    }
    get _optionPath() {
        return 'at';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDateBoxAtComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoDateBoxAtComponent, isStandalone: true, selector: "dxo-date-box-at", inputs: { x: "x", y: "y" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDateBoxAtComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-date-box-at', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { x: [{
                type: Input
            }], y: [{
                type: Input
            }] } });
class DxoDateBoxAtModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDateBoxAtModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoDateBoxAtModule, imports: [DxoDateBoxAtComponent], exports: [DxoDateBoxAtComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDateBoxAtModule, imports: [DxoDateBoxAtComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDateBoxAtModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoDateBoxAtComponent
                    ],
                    exports: [
                        DxoDateBoxAtComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoDateBoxBoundaryOffsetComponent extends NestedOption {
    get x() {
        return this._getOption('x');
    }
    set x(value) {
        this._setOption('x', value);
    }
    get y() {
        return this._getOption('y');
    }
    set y(value) {
        this._setOption('y', value);
    }
    get _optionPath() {
        return 'boundaryOffset';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDateBoxBoundaryOffsetComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoDateBoxBoundaryOffsetComponent, isStandalone: true, selector: "dxo-date-box-boundary-offset", inputs: { x: "x", y: "y" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDateBoxBoundaryOffsetComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-date-box-boundary-offset', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { x: [{
                type: Input
            }], y: [{
                type: Input
            }] } });
class DxoDateBoxBoundaryOffsetModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDateBoxBoundaryOffsetModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoDateBoxBoundaryOffsetModule, imports: [DxoDateBoxBoundaryOffsetComponent], exports: [DxoDateBoxBoundaryOffsetComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDateBoxBoundaryOffsetModule, imports: [DxoDateBoxBoundaryOffsetComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDateBoxBoundaryOffsetModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoDateBoxBoundaryOffsetComponent
                    ],
                    exports: [
                        DxoDateBoxBoundaryOffsetComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxiDateBoxButtonComponent extends CollectionNestedOption {
    get location() {
        return this._getOption('location');
    }
    set location(value) {
        this._setOption('location', value);
    }
    get name() {
        return this._getOption('name');
    }
    set name(value) {
        this._setOption('name', value);
    }
    get options() {
        return this._getOption('options');
    }
    set options(value) {
        this._setOption('options', value);
    }
    get _optionPath() {
        return 'buttons';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnDestroy() {
        this._deleteRemovedOptions(this._fullOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiDateBoxButtonComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxiDateBoxButtonComponent, isStandalone: true, selector: "dxi-date-box-button", inputs: { location: "location", name: "name", options: "options" }, providers: [
            NestedOptionHost,
            {
                provide: PROPERTY_TOKEN_buttons,
                useExisting: DxiDateBoxButtonComponent,
            }
        ], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiDateBoxButtonComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxi-date-box-button', template: '', imports: [DxIntegrationModule], providers: [
                        NestedOptionHost,
                        {
                            provide: PROPERTY_TOKEN_buttons,
                            useExisting: DxiDateBoxButtonComponent,
                        }
                    ] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { location: [{
                type: Input
            }], name: [{
                type: Input
            }], options: [{
                type: Input
            }] } });
class DxiDateBoxButtonModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiDateBoxButtonModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxiDateBoxButtonModule, imports: [DxiDateBoxButtonComponent], exports: [DxiDateBoxButtonComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiDateBoxButtonModule, imports: [DxiDateBoxButtonComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiDateBoxButtonModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxiDateBoxButtonComponent
                    ],
                    exports: [
                        DxiDateBoxButtonComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoDateBoxCalendarOptionsComponent extends NestedOption {
    get accessKey() {
        return this._getOption('accessKey');
    }
    set accessKey(value) {
        this._setOption('accessKey', value);
    }
    get activeStateEnabled() {
        return this._getOption('activeStateEnabled');
    }
    set activeStateEnabled(value) {
        this._setOption('activeStateEnabled', value);
    }
    get cellTemplate() {
        return this._getOption('cellTemplate');
    }
    set cellTemplate(value) {
        this._setOption('cellTemplate', value);
    }
    get dateSerializationFormat() {
        return this._getOption('dateSerializationFormat');
    }
    set dateSerializationFormat(value) {
        this._setOption('dateSerializationFormat', value);
    }
    get disabled() {
        return this._getOption('disabled');
    }
    set disabled(value) {
        this._setOption('disabled', value);
    }
    get disabledDates() {
        return this._getOption('disabledDates');
    }
    set disabledDates(value) {
        this._setOption('disabledDates', value);
    }
    get elementAttr() {
        return this._getOption('elementAttr');
    }
    set elementAttr(value) {
        this._setOption('elementAttr', value);
    }
    get firstDayOfWeek() {
        return this._getOption('firstDayOfWeek');
    }
    set firstDayOfWeek(value) {
        this._setOption('firstDayOfWeek', value);
    }
    get focusStateEnabled() {
        return this._getOption('focusStateEnabled');
    }
    set focusStateEnabled(value) {
        this._setOption('focusStateEnabled', value);
    }
    get height() {
        return this._getOption('height');
    }
    set height(value) {
        this._setOption('height', value);
    }
    get hint() {
        return this._getOption('hint');
    }
    set hint(value) {
        this._setOption('hint', value);
    }
    get hoverStateEnabled() {
        return this._getOption('hoverStateEnabled');
    }
    set hoverStateEnabled(value) {
        this._setOption('hoverStateEnabled', value);
    }
    get isDirty() {
        return this._getOption('isDirty');
    }
    set isDirty(value) {
        this._setOption('isDirty', value);
    }
    get isValid() {
        return this._getOption('isValid');
    }
    set isValid(value) {
        this._setOption('isValid', value);
    }
    get max() {
        return this._getOption('max');
    }
    set max(value) {
        this._setOption('max', value);
    }
    get maxZoomLevel() {
        return this._getOption('maxZoomLevel');
    }
    set maxZoomLevel(value) {
        this._setOption('maxZoomLevel', value);
    }
    get min() {
        return this._getOption('min');
    }
    set min(value) {
        this._setOption('min', value);
    }
    get minZoomLevel() {
        return this._getOption('minZoomLevel');
    }
    set minZoomLevel(value) {
        this._setOption('minZoomLevel', value);
    }
    get name() {
        return this._getOption('name');
    }
    set name(value) {
        this._setOption('name', value);
    }
    get onDisposing() {
        return this._getOption('onDisposing');
    }
    set onDisposing(value) {
        this._setOption('onDisposing', value);
    }
    get onInitialized() {
        return this._getOption('onInitialized');
    }
    set onInitialized(value) {
        this._setOption('onInitialized', value);
    }
    get onOptionChanged() {
        return this._getOption('onOptionChanged');
    }
    set onOptionChanged(value) {
        this._setOption('onOptionChanged', value);
    }
    get onValueChanged() {
        return this._getOption('onValueChanged');
    }
    set onValueChanged(value) {
        this._setOption('onValueChanged', value);
    }
    get readOnly() {
        return this._getOption('readOnly');
    }
    set readOnly(value) {
        this._setOption('readOnly', value);
    }
    get rtlEnabled() {
        return this._getOption('rtlEnabled');
    }
    set rtlEnabled(value) {
        this._setOption('rtlEnabled', value);
    }
    get selectionMode() {
        return this._getOption('selectionMode');
    }
    set selectionMode(value) {
        this._setOption('selectionMode', value);
    }
    get selectWeekOnClick() {
        return this._getOption('selectWeekOnClick');
    }
    set selectWeekOnClick(value) {
        this._setOption('selectWeekOnClick', value);
    }
    get showTodayButton() {
        return this._getOption('showTodayButton');
    }
    set showTodayButton(value) {
        this._setOption('showTodayButton', value);
    }
    get showWeekNumbers() {
        return this._getOption('showWeekNumbers');
    }
    set showWeekNumbers(value) {
        this._setOption('showWeekNumbers', value);
    }
    get tabIndex() {
        return this._getOption('tabIndex');
    }
    set tabIndex(value) {
        this._setOption('tabIndex', value);
    }
    get todayButtonText() {
        return this._getOption('todayButtonText');
    }
    set todayButtonText(value) {
        this._setOption('todayButtonText', value);
    }
    get validationError() {
        return this._getOption('validationError');
    }
    set validationError(value) {
        this._setOption('validationError', value);
    }
    get validationErrors() {
        return this._getOption('validationErrors');
    }
    set validationErrors(value) {
        this._setOption('validationErrors', value);
    }
    get validationMessageMode() {
        return this._getOption('validationMessageMode');
    }
    set validationMessageMode(value) {
        this._setOption('validationMessageMode', value);
    }
    get validationMessagePosition() {
        return this._getOption('validationMessagePosition');
    }
    set validationMessagePosition(value) {
        this._setOption('validationMessagePosition', value);
    }
    get validationStatus() {
        return this._getOption('validationStatus');
    }
    set validationStatus(value) {
        this._setOption('validationStatus', value);
    }
    get value() {
        return this._getOption('value');
    }
    set value(value) {
        this._setOption('value', value);
    }
    get visible() {
        return this._getOption('visible');
    }
    set visible(value) {
        this._setOption('visible', value);
    }
    get weekNumberRule() {
        return this._getOption('weekNumberRule');
    }
    set weekNumberRule(value) {
        this._setOption('weekNumberRule', value);
    }
    get width() {
        return this._getOption('width');
    }
    set width(value) {
        this._setOption('width', value);
    }
    get zoomLevel() {
        return this._getOption('zoomLevel');
    }
    set zoomLevel(value) {
        this._setOption('zoomLevel', value);
    }
    get _optionPath() {
        return 'calendarOptions';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        this._createEventEmitters([
            { emit: 'valueChange' },
            { emit: 'zoomLevelChange' }
        ]);
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDateBoxCalendarOptionsComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoDateBoxCalendarOptionsComponent, isStandalone: true, selector: "dxo-date-box-calendar-options", inputs: { accessKey: "accessKey", activeStateEnabled: "activeStateEnabled", cellTemplate: "cellTemplate", dateSerializationFormat: "dateSerializationFormat", disabled: "disabled", disabledDates: "disabledDates", elementAttr: "elementAttr", firstDayOfWeek: "firstDayOfWeek", focusStateEnabled: "focusStateEnabled", height: "height", hint: "hint", hoverStateEnabled: "hoverStateEnabled", isDirty: "isDirty", isValid: "isValid", max: "max", maxZoomLevel: "maxZoomLevel", min: "min", minZoomLevel: "minZoomLevel", name: "name", onDisposing: "onDisposing", onInitialized: "onInitialized", onOptionChanged: "onOptionChanged", onValueChanged: "onValueChanged", readOnly: "readOnly", rtlEnabled: "rtlEnabled", selectionMode: "selectionMode", selectWeekOnClick: "selectWeekOnClick", showTodayButton: "showTodayButton", showWeekNumbers: "showWeekNumbers", tabIndex: "tabIndex", todayButtonText: "todayButtonText", validationError: "validationError", validationErrors: "validationErrors", validationMessageMode: "validationMessageMode", validationMessagePosition: "validationMessagePosition", validationStatus: "validationStatus", value: "value", visible: "visible", weekNumberRule: "weekNumberRule", width: "width", zoomLevel: "zoomLevel" }, outputs: { valueChange: "valueChange", zoomLevelChange: "zoomLevelChange" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDateBoxCalendarOptionsComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-date-box-calendar-options', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { accessKey: [{
                type: Input
            }], activeStateEnabled: [{
                type: Input
            }], cellTemplate: [{
                type: Input
            }], dateSerializationFormat: [{
                type: Input
            }], disabled: [{
                type: Input
            }], disabledDates: [{
                type: Input
            }], elementAttr: [{
                type: Input
            }], firstDayOfWeek: [{
                type: Input
            }], focusStateEnabled: [{
                type: Input
            }], height: [{
                type: Input
            }], hint: [{
                type: Input
            }], hoverStateEnabled: [{
                type: Input
            }], isDirty: [{
                type: Input
            }], isValid: [{
                type: Input
            }], max: [{
                type: Input
            }], maxZoomLevel: [{
                type: Input
            }], min: [{
                type: Input
            }], minZoomLevel: [{
                type: Input
            }], name: [{
                type: Input
            }], onDisposing: [{
                type: Input
            }], onInitialized: [{
                type: Input
            }], onOptionChanged: [{
                type: Input
            }], onValueChanged: [{
                type: Input
            }], readOnly: [{
                type: Input
            }], rtlEnabled: [{
                type: Input
            }], selectionMode: [{
                type: Input
            }], selectWeekOnClick: [{
                type: Input
            }], showTodayButton: [{
                type: Input
            }], showWeekNumbers: [{
                type: Input
            }], tabIndex: [{
                type: Input
            }], todayButtonText: [{
                type: Input
            }], validationError: [{
                type: Input
            }], validationErrors: [{
                type: Input
            }], validationMessageMode: [{
                type: Input
            }], validationMessagePosition: [{
                type: Input
            }], validationStatus: [{
                type: Input
            }], value: [{
                type: Input
            }], visible: [{
                type: Input
            }], weekNumberRule: [{
                type: Input
            }], width: [{
                type: Input
            }], zoomLevel: [{
                type: Input
            }], valueChange: [{
                type: Output
            }], zoomLevelChange: [{
                type: Output
            }] } });
class DxoDateBoxCalendarOptionsModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDateBoxCalendarOptionsModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoDateBoxCalendarOptionsModule, imports: [DxoDateBoxCalendarOptionsComponent], exports: [DxoDateBoxCalendarOptionsComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDateBoxCalendarOptionsModule, imports: [DxoDateBoxCalendarOptionsComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDateBoxCalendarOptionsModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoDateBoxCalendarOptionsComponent
                    ],
                    exports: [
                        DxoDateBoxCalendarOptionsComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoDateBoxCollisionComponent extends NestedOption {
    get x() {
        return this._getOption('x');
    }
    set x(value) {
        this._setOption('x', value);
    }
    get y() {
        return this._getOption('y');
    }
    set y(value) {
        this._setOption('y', value);
    }
    get _optionPath() {
        return 'collision';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDateBoxCollisionComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoDateBoxCollisionComponent, isStandalone: true, selector: "dxo-date-box-collision", inputs: { x: "x", y: "y" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDateBoxCollisionComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-date-box-collision', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { x: [{
                type: Input
            }], y: [{
                type: Input
            }] } });
class DxoDateBoxCollisionModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDateBoxCollisionModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoDateBoxCollisionModule, imports: [DxoDateBoxCollisionComponent], exports: [DxoDateBoxCollisionComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDateBoxCollisionModule, imports: [DxoDateBoxCollisionComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDateBoxCollisionModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoDateBoxCollisionComponent
                    ],
                    exports: [
                        DxoDateBoxCollisionComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoDateBoxDisplayFormatComponent extends NestedOption {
    get currency() {
        return this._getOption('currency');
    }
    set currency(value) {
        this._setOption('currency', value);
    }
    get formatter() {
        return this._getOption('formatter');
    }
    set formatter(value) {
        this._setOption('formatter', value);
    }
    get parser() {
        return this._getOption('parser');
    }
    set parser(value) {
        this._setOption('parser', value);
    }
    get precision() {
        return this._getOption('precision');
    }
    set precision(value) {
        this._setOption('precision', value);
    }
    get type() {
        return this._getOption('type');
    }
    set type(value) {
        this._setOption('type', value);
    }
    get useCurrencyAccountingStyle() {
        return this._getOption('useCurrencyAccountingStyle');
    }
    set useCurrencyAccountingStyle(value) {
        this._setOption('useCurrencyAccountingStyle', value);
    }
    get _optionPath() {
        return 'displayFormat';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDateBoxDisplayFormatComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoDateBoxDisplayFormatComponent, isStandalone: true, selector: "dxo-date-box-display-format", inputs: { currency: "currency", formatter: "formatter", parser: "parser", precision: "precision", type: "type", useCurrencyAccountingStyle: "useCurrencyAccountingStyle" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDateBoxDisplayFormatComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-date-box-display-format', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { currency: [{
                type: Input
            }], formatter: [{
                type: Input
            }], parser: [{
                type: Input
            }], precision: [{
                type: Input
            }], type: [{
                type: Input
            }], useCurrencyAccountingStyle: [{
                type: Input
            }] } });
class DxoDateBoxDisplayFormatModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDateBoxDisplayFormatModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoDateBoxDisplayFormatModule, imports: [DxoDateBoxDisplayFormatComponent], exports: [DxoDateBoxDisplayFormatComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDateBoxDisplayFormatModule, imports: [DxoDateBoxDisplayFormatComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDateBoxDisplayFormatModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoDateBoxDisplayFormatComponent
                    ],
                    exports: [
                        DxoDateBoxDisplayFormatComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoDateBoxDropDownOptionsComponent extends NestedOption {
    set _toolbarItemsContentChildren(value) {
        this.setChildren('toolbarItems', value);
    }
    get accessKey() {
        return this._getOption('accessKey');
    }
    set accessKey(value) {
        this._setOption('accessKey', value);
    }
    get animation() {
        return this._getOption('animation');
    }
    set animation(value) {
        this._setOption('animation', value);
    }
    get container() {
        return this._getOption('container');
    }
    set container(value) {
        this._setOption('container', value);
    }
    get contentTemplate() {
        return this._getOption('contentTemplate');
    }
    set contentTemplate(value) {
        this._setOption('contentTemplate', value);
    }
    get deferRendering() {
        return this._getOption('deferRendering');
    }
    set deferRendering(value) {
        this._setOption('deferRendering', value);
    }
    get disabled() {
        return this._getOption('disabled');
    }
    set disabled(value) {
        this._setOption('disabled', value);
    }
    get dragAndResizeArea() {
        return this._getOption('dragAndResizeArea');
    }
    set dragAndResizeArea(value) {
        this._setOption('dragAndResizeArea', value);
    }
    get dragEnabled() {
        return this._getOption('dragEnabled');
    }
    set dragEnabled(value) {
        this._setOption('dragEnabled', value);
    }
    get dragOutsideBoundary() {
        return this._getOption('dragOutsideBoundary');
    }
    set dragOutsideBoundary(value) {
        this._setOption('dragOutsideBoundary', value);
    }
    get enableBodyScroll() {
        return this._getOption('enableBodyScroll');
    }
    set enableBodyScroll(value) {
        this._setOption('enableBodyScroll', value);
    }
    get focusStateEnabled() {
        return this._getOption('focusStateEnabled');
    }
    set focusStateEnabled(value) {
        this._setOption('focusStateEnabled', value);
    }
    get fullScreen() {
        return this._getOption('fullScreen');
    }
    set fullScreen(value) {
        this._setOption('fullScreen', value);
    }
    get height() {
        return this._getOption('height');
    }
    set height(value) {
        this._setOption('height', value);
    }
    get hideOnOutsideClick() {
        return this._getOption('hideOnOutsideClick');
    }
    set hideOnOutsideClick(value) {
        this._setOption('hideOnOutsideClick', value);
    }
    get hideOnParentScroll() {
        return this._getOption('hideOnParentScroll');
    }
    set hideOnParentScroll(value) {
        this._setOption('hideOnParentScroll', value);
    }
    get hint() {
        return this._getOption('hint');
    }
    set hint(value) {
        this._setOption('hint', value);
    }
    get hoverStateEnabled() {
        return this._getOption('hoverStateEnabled');
    }
    set hoverStateEnabled(value) {
        this._setOption('hoverStateEnabled', value);
    }
    get maxHeight() {
        return this._getOption('maxHeight');
    }
    set maxHeight(value) {
        this._setOption('maxHeight', value);
    }
    get maxWidth() {
        return this._getOption('maxWidth');
    }
    set maxWidth(value) {
        this._setOption('maxWidth', value);
    }
    get minHeight() {
        return this._getOption('minHeight');
    }
    set minHeight(value) {
        this._setOption('minHeight', value);
    }
    get minWidth() {
        return this._getOption('minWidth');
    }
    set minWidth(value) {
        this._setOption('minWidth', value);
    }
    get onContentReady() {
        return this._getOption('onContentReady');
    }
    set onContentReady(value) {
        this._setOption('onContentReady', value);
    }
    get onDisposing() {
        return this._getOption('onDisposing');
    }
    set onDisposing(value) {
        this._setOption('onDisposing', value);
    }
    get onHidden() {
        return this._getOption('onHidden');
    }
    set onHidden(value) {
        this._setOption('onHidden', value);
    }
    get onHiding() {
        return this._getOption('onHiding');
    }
    set onHiding(value) {
        this._setOption('onHiding', value);
    }
    get onInitialized() {
        return this._getOption('onInitialized');
    }
    set onInitialized(value) {
        this._setOption('onInitialized', value);
    }
    get onOptionChanged() {
        return this._getOption('onOptionChanged');
    }
    set onOptionChanged(value) {
        this._setOption('onOptionChanged', value);
    }
    get onResize() {
        return this._getOption('onResize');
    }
    set onResize(value) {
        this._setOption('onResize', value);
    }
    get onResizeEnd() {
        return this._getOption('onResizeEnd');
    }
    set onResizeEnd(value) {
        this._setOption('onResizeEnd', value);
    }
    get onResizeStart() {
        return this._getOption('onResizeStart');
    }
    set onResizeStart(value) {
        this._setOption('onResizeStart', value);
    }
    get onShowing() {
        return this._getOption('onShowing');
    }
    set onShowing(value) {
        this._setOption('onShowing', value);
    }
    get onShown() {
        return this._getOption('onShown');
    }
    set onShown(value) {
        this._setOption('onShown', value);
    }
    get onTitleRendered() {
        return this._getOption('onTitleRendered');
    }
    set onTitleRendered(value) {
        this._setOption('onTitleRendered', value);
    }
    get position() {
        return this._getOption('position');
    }
    set position(value) {
        this._setOption('position', value);
    }
    get resizeEnabled() {
        return this._getOption('resizeEnabled');
    }
    set resizeEnabled(value) {
        this._setOption('resizeEnabled', value);
    }
    get restorePosition() {
        return this._getOption('restorePosition');
    }
    set restorePosition(value) {
        this._setOption('restorePosition', value);
    }
    get rtlEnabled() {
        return this._getOption('rtlEnabled');
    }
    set rtlEnabled(value) {
        this._setOption('rtlEnabled', value);
    }
    get shading() {
        return this._getOption('shading');
    }
    set shading(value) {
        this._setOption('shading', value);
    }
    get shadingColor() {
        return this._getOption('shadingColor');
    }
    set shadingColor(value) {
        this._setOption('shadingColor', value);
    }
    get showCloseButton() {
        return this._getOption('showCloseButton');
    }
    set showCloseButton(value) {
        this._setOption('showCloseButton', value);
    }
    get showTitle() {
        return this._getOption('showTitle');
    }
    set showTitle(value) {
        this._setOption('showTitle', value);
    }
    get tabFocusLoopEnabled() {
        return this._getOption('tabFocusLoopEnabled');
    }
    set tabFocusLoopEnabled(value) {
        this._setOption('tabFocusLoopEnabled', value);
    }
    get tabIndex() {
        return this._getOption('tabIndex');
    }
    set tabIndex(value) {
        this._setOption('tabIndex', value);
    }
    get title() {
        return this._getOption('title');
    }
    set title(value) {
        this._setOption('title', value);
    }
    get titleTemplate() {
        return this._getOption('titleTemplate');
    }
    set titleTemplate(value) {
        this._setOption('titleTemplate', value);
    }
    get toolbarItems() {
        return this._getOption('toolbarItems');
    }
    set toolbarItems(value) {
        this._setOption('toolbarItems', value);
    }
    get visible() {
        return this._getOption('visible');
    }
    set visible(value) {
        this._setOption('visible', value);
    }
    get width() {
        return this._getOption('width');
    }
    set width(value) {
        this._setOption('width', value);
    }
    get wrapperAttr() {
        return this._getOption('wrapperAttr');
    }
    set wrapperAttr(value) {
        this._setOption('wrapperAttr', value);
    }
    get _optionPath() {
        return 'dropDownOptions';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        this._createEventEmitters([
            { emit: 'heightChange' },
            { emit: 'positionChange' },
            { emit: 'visibleChange' },
            { emit: 'widthChange' }
        ]);
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDateBoxDropDownOptionsComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoDateBoxDropDownOptionsComponent, isStandalone: true, selector: "dxo-date-box-drop-down-options", inputs: { accessKey: "accessKey", animation: "animation", container: "container", contentTemplate: "contentTemplate", deferRendering: "deferRendering", disabled: "disabled", dragAndResizeArea: "dragAndResizeArea", dragEnabled: "dragEnabled", dragOutsideBoundary: "dragOutsideBoundary", enableBodyScroll: "enableBodyScroll", focusStateEnabled: "focusStateEnabled", fullScreen: "fullScreen", height: "height", hideOnOutsideClick: "hideOnOutsideClick", hideOnParentScroll: "hideOnParentScroll", hint: "hint", hoverStateEnabled: "hoverStateEnabled", maxHeight: "maxHeight", maxWidth: "maxWidth", minHeight: "minHeight", minWidth: "minWidth", onContentReady: "onContentReady", onDisposing: "onDisposing", onHidden: "onHidden", onHiding: "onHiding", onInitialized: "onInitialized", onOptionChanged: "onOptionChanged", onResize: "onResize", onResizeEnd: "onResizeEnd", onResizeStart: "onResizeStart", onShowing: "onShowing", onShown: "onShown", onTitleRendered: "onTitleRendered", position: "position", resizeEnabled: "resizeEnabled", restorePosition: "restorePosition", rtlEnabled: "rtlEnabled", shading: "shading", shadingColor: "shadingColor", showCloseButton: "showCloseButton", showTitle: "showTitle", tabFocusLoopEnabled: "tabFocusLoopEnabled", tabIndex: "tabIndex", title: "title", titleTemplate: "titleTemplate", toolbarItems: "toolbarItems", visible: "visible", width: "width", wrapperAttr: "wrapperAttr" }, outputs: { heightChange: "heightChange", positionChange: "positionChange", visibleChange: "visibleChange", widthChange: "widthChange" }, providers: [NestedOptionHost], queries: [{ propertyName: "_toolbarItemsContentChildren", predicate: PROPERTY_TOKEN_toolbarItems }], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDateBoxDropDownOptionsComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-date-box-drop-down-options', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { _toolbarItemsContentChildren: [{
                type: ContentChildren,
                args: [PROPERTY_TOKEN_toolbarItems]
            }], accessKey: [{
                type: Input
            }], animation: [{
                type: Input
            }], container: [{
                type: Input
            }], contentTemplate: [{
                type: Input
            }], deferRendering: [{
                type: Input
            }], disabled: [{
                type: Input
            }], dragAndResizeArea: [{
                type: Input
            }], dragEnabled: [{
                type: Input
            }], dragOutsideBoundary: [{
                type: Input
            }], enableBodyScroll: [{
                type: Input
            }], focusStateEnabled: [{
                type: Input
            }], fullScreen: [{
                type: Input
            }], height: [{
                type: Input
            }], hideOnOutsideClick: [{
                type: Input
            }], hideOnParentScroll: [{
                type: Input
            }], hint: [{
                type: Input
            }], hoverStateEnabled: [{
                type: Input
            }], maxHeight: [{
                type: Input
            }], maxWidth: [{
                type: Input
            }], minHeight: [{
                type: Input
            }], minWidth: [{
                type: Input
            }], onContentReady: [{
                type: Input
            }], onDisposing: [{
                type: Input
            }], onHidden: [{
                type: Input
            }], onHiding: [{
                type: Input
            }], onInitialized: [{
                type: Input
            }], onOptionChanged: [{
                type: Input
            }], onResize: [{
                type: Input
            }], onResizeEnd: [{
                type: Input
            }], onResizeStart: [{
                type: Input
            }], onShowing: [{
                type: Input
            }], onShown: [{
                type: Input
            }], onTitleRendered: [{
                type: Input
            }], position: [{
                type: Input
            }], resizeEnabled: [{
                type: Input
            }], restorePosition: [{
                type: Input
            }], rtlEnabled: [{
                type: Input
            }], shading: [{
                type: Input
            }], shadingColor: [{
                type: Input
            }], showCloseButton: [{
                type: Input
            }], showTitle: [{
                type: Input
            }], tabFocusLoopEnabled: [{
                type: Input
            }], tabIndex: [{
                type: Input
            }], title: [{
                type: Input
            }], titleTemplate: [{
                type: Input
            }], toolbarItems: [{
                type: Input
            }], visible: [{
                type: Input
            }], width: [{
                type: Input
            }], wrapperAttr: [{
                type: Input
            }], heightChange: [{
                type: Output
            }], positionChange: [{
                type: Output
            }], visibleChange: [{
                type: Output
            }], widthChange: [{
                type: Output
            }] } });
class DxoDateBoxDropDownOptionsModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDateBoxDropDownOptionsModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoDateBoxDropDownOptionsModule, imports: [DxoDateBoxDropDownOptionsComponent], exports: [DxoDateBoxDropDownOptionsComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDateBoxDropDownOptionsModule, imports: [DxoDateBoxDropDownOptionsComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDateBoxDropDownOptionsModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoDateBoxDropDownOptionsComponent
                    ],
                    exports: [
                        DxoDateBoxDropDownOptionsComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoDateBoxFromComponent extends NestedOption {
    get left() {
        return this._getOption('left');
    }
    set left(value) {
        this._setOption('left', value);
    }
    get opacity() {
        return this._getOption('opacity');
    }
    set opacity(value) {
        this._setOption('opacity', value);
    }
    get position() {
        return this._getOption('position');
    }
    set position(value) {
        this._setOption('position', value);
    }
    get scale() {
        return this._getOption('scale');
    }
    set scale(value) {
        this._setOption('scale', value);
    }
    get top() {
        return this._getOption('top');
    }
    set top(value) {
        this._setOption('top', value);
    }
    get _optionPath() {
        return 'from';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDateBoxFromComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoDateBoxFromComponent, isStandalone: true, selector: "dxo-date-box-from", inputs: { left: "left", opacity: "opacity", position: "position", scale: "scale", top: "top" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDateBoxFromComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-date-box-from', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { left: [{
                type: Input
            }], opacity: [{
                type: Input
            }], position: [{
                type: Input
            }], scale: [{
                type: Input
            }], top: [{
                type: Input
            }] } });
class DxoDateBoxFromModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDateBoxFromModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoDateBoxFromModule, imports: [DxoDateBoxFromComponent], exports: [DxoDateBoxFromComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDateBoxFromModule, imports: [DxoDateBoxFromComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDateBoxFromModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoDateBoxFromComponent
                    ],
                    exports: [
                        DxoDateBoxFromComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoDateBoxHideComponent extends NestedOption {
    get complete() {
        return this._getOption('complete');
    }
    set complete(value) {
        this._setOption('complete', value);
    }
    get delay() {
        return this._getOption('delay');
    }
    set delay(value) {
        this._setOption('delay', value);
    }
    get direction() {
        return this._getOption('direction');
    }
    set direction(value) {
        this._setOption('direction', value);
    }
    get duration() {
        return this._getOption('duration');
    }
    set duration(value) {
        this._setOption('duration', value);
    }
    get easing() {
        return this._getOption('easing');
    }
    set easing(value) {
        this._setOption('easing', value);
    }
    get from() {
        return this._getOption('from');
    }
    set from(value) {
        this._setOption('from', value);
    }
    get staggerDelay() {
        return this._getOption('staggerDelay');
    }
    set staggerDelay(value) {
        this._setOption('staggerDelay', value);
    }
    get start() {
        return this._getOption('start');
    }
    set start(value) {
        this._setOption('start', value);
    }
    get to() {
        return this._getOption('to');
    }
    set to(value) {
        this._setOption('to', value);
    }
    get type() {
        return this._getOption('type');
    }
    set type(value) {
        this._setOption('type', value);
    }
    get _optionPath() {
        return 'hide';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDateBoxHideComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoDateBoxHideComponent, isStandalone: true, selector: "dxo-date-box-hide", inputs: { complete: "complete", delay: "delay", direction: "direction", duration: "duration", easing: "easing", from: "from", staggerDelay: "staggerDelay", start: "start", to: "to", type: "type" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDateBoxHideComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-date-box-hide', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { complete: [{
                type: Input
            }], delay: [{
                type: Input
            }], direction: [{
                type: Input
            }], duration: [{
                type: Input
            }], easing: [{
                type: Input
            }], from: [{
                type: Input
            }], staggerDelay: [{
                type: Input
            }], start: [{
                type: Input
            }], to: [{
                type: Input
            }], type: [{
                type: Input
            }] } });
class DxoDateBoxHideModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDateBoxHideModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoDateBoxHideModule, imports: [DxoDateBoxHideComponent], exports: [DxoDateBoxHideComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDateBoxHideModule, imports: [DxoDateBoxHideComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDateBoxHideModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoDateBoxHideComponent
                    ],
                    exports: [
                        DxoDateBoxHideComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoDateBoxMyComponent extends NestedOption {
    get x() {
        return this._getOption('x');
    }
    set x(value) {
        this._setOption('x', value);
    }
    get y() {
        return this._getOption('y');
    }
    set y(value) {
        this._setOption('y', value);
    }
    get _optionPath() {
        return 'my';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDateBoxMyComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoDateBoxMyComponent, isStandalone: true, selector: "dxo-date-box-my", inputs: { x: "x", y: "y" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDateBoxMyComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-date-box-my', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { x: [{
                type: Input
            }], y: [{
                type: Input
            }] } });
class DxoDateBoxMyModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDateBoxMyModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoDateBoxMyModule, imports: [DxoDateBoxMyComponent], exports: [DxoDateBoxMyComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDateBoxMyModule, imports: [DxoDateBoxMyComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDateBoxMyModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoDateBoxMyComponent
                    ],
                    exports: [
                        DxoDateBoxMyComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoDateBoxOffsetComponent extends NestedOption {
    get x() {
        return this._getOption('x');
    }
    set x(value) {
        this._setOption('x', value);
    }
    get y() {
        return this._getOption('y');
    }
    set y(value) {
        this._setOption('y', value);
    }
    get _optionPath() {
        return 'offset';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDateBoxOffsetComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoDateBoxOffsetComponent, isStandalone: true, selector: "dxo-date-box-offset", inputs: { x: "x", y: "y" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDateBoxOffsetComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-date-box-offset', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { x: [{
                type: Input
            }], y: [{
                type: Input
            }] } });
class DxoDateBoxOffsetModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDateBoxOffsetModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoDateBoxOffsetModule, imports: [DxoDateBoxOffsetComponent], exports: [DxoDateBoxOffsetComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDateBoxOffsetModule, imports: [DxoDateBoxOffsetComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDateBoxOffsetModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoDateBoxOffsetComponent
                    ],
                    exports: [
                        DxoDateBoxOffsetComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoDateBoxOptionsComponent extends NestedOption {
    get accessKey() {
        return this._getOption('accessKey');
    }
    set accessKey(value) {
        this._setOption('accessKey', value);
    }
    get activeStateEnabled() {
        return this._getOption('activeStateEnabled');
    }
    set activeStateEnabled(value) {
        this._setOption('activeStateEnabled', value);
    }
    get disabled() {
        return this._getOption('disabled');
    }
    set disabled(value) {
        this._setOption('disabled', value);
    }
    get elementAttr() {
        return this._getOption('elementAttr');
    }
    set elementAttr(value) {
        this._setOption('elementAttr', value);
    }
    get focusStateEnabled() {
        return this._getOption('focusStateEnabled');
    }
    set focusStateEnabled(value) {
        this._setOption('focusStateEnabled', value);
    }
    get height() {
        return this._getOption('height');
    }
    set height(value) {
        this._setOption('height', value);
    }
    get hint() {
        return this._getOption('hint');
    }
    set hint(value) {
        this._setOption('hint', value);
    }
    get hoverStateEnabled() {
        return this._getOption('hoverStateEnabled');
    }
    set hoverStateEnabled(value) {
        this._setOption('hoverStateEnabled', value);
    }
    get icon() {
        return this._getOption('icon');
    }
    set icon(value) {
        this._setOption('icon', value);
    }
    get onClick() {
        return this._getOption('onClick');
    }
    set onClick(value) {
        this._setOption('onClick', value);
    }
    get onContentReady() {
        return this._getOption('onContentReady');
    }
    set onContentReady(value) {
        this._setOption('onContentReady', value);
    }
    get onDisposing() {
        return this._getOption('onDisposing');
    }
    set onDisposing(value) {
        this._setOption('onDisposing', value);
    }
    get onInitialized() {
        return this._getOption('onInitialized');
    }
    set onInitialized(value) {
        this._setOption('onInitialized', value);
    }
    get onOptionChanged() {
        return this._getOption('onOptionChanged');
    }
    set onOptionChanged(value) {
        this._setOption('onOptionChanged', value);
    }
    get rtlEnabled() {
        return this._getOption('rtlEnabled');
    }
    set rtlEnabled(value) {
        this._setOption('rtlEnabled', value);
    }
    get stylingMode() {
        return this._getOption('stylingMode');
    }
    set stylingMode(value) {
        this._setOption('stylingMode', value);
    }
    get tabIndex() {
        return this._getOption('tabIndex');
    }
    set tabIndex(value) {
        this._setOption('tabIndex', value);
    }
    get template() {
        return this._getOption('template');
    }
    set template(value) {
        this._setOption('template', value);
    }
    get text() {
        return this._getOption('text');
    }
    set text(value) {
        this._setOption('text', value);
    }
    get type() {
        return this._getOption('type');
    }
    set type(value) {
        this._setOption('type', value);
    }
    get useSubmitBehavior() {
        return this._getOption('useSubmitBehavior');
    }
    set useSubmitBehavior(value) {
        this._setOption('useSubmitBehavior', value);
    }
    get validationGroup() {
        return this._getOption('validationGroup');
    }
    set validationGroup(value) {
        this._setOption('validationGroup', value);
    }
    get visible() {
        return this._getOption('visible');
    }
    set visible(value) {
        this._setOption('visible', value);
    }
    get width() {
        return this._getOption('width');
    }
    set width(value) {
        this._setOption('width', value);
    }
    get _optionPath() {
        return 'options';
    }
    constructor(parentOptionHost, optionHost, renderer, document, templateHost, element) {
        super();
        this.renderer = renderer;
        this.document = document;
        this.element = element;
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
        templateHost.setHost(this);
    }
    setTemplate(template) {
        this.template = template;
    }
    ngAfterViewInit() {
        extractTemplate(this, this.element, this.renderer, this.document);
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDateBoxOptionsComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }, { token: i0.Renderer2 }, { token: DOCUMENT }, { token: i1.DxTemplateHost, host: true }, { token: i0.ElementRef }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoDateBoxOptionsComponent, isStandalone: true, selector: "dxo-date-box-options", inputs: { accessKey: "accessKey", activeStateEnabled: "activeStateEnabled", disabled: "disabled", elementAttr: "elementAttr", focusStateEnabled: "focusStateEnabled", height: "height", hint: "hint", hoverStateEnabled: "hoverStateEnabled", icon: "icon", onClick: "onClick", onContentReady: "onContentReady", onDisposing: "onDisposing", onInitialized: "onInitialized", onOptionChanged: "onOptionChanged", rtlEnabled: "rtlEnabled", stylingMode: "stylingMode", tabIndex: "tabIndex", template: "template", text: "text", type: "type", useSubmitBehavior: "useSubmitBehavior", validationGroup: "validationGroup", visible: "visible", width: "width" }, providers: [NestedOptionHost, DxTemplateHost], usesInheritance: true, ngImport: i0, template: '<ng-content></ng-content>', isInline: true, styles: [":host{display:block}\n"], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDateBoxOptionsComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-date-box-options', template: '<ng-content></ng-content>', imports: [DxIntegrationModule], providers: [NestedOptionHost, DxTemplateHost], styles: [":host{display:block}\n"] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }, { type: i0.Renderer2 }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [DOCUMENT]
                }] }, { type: i1.DxTemplateHost, decorators: [{
                    type: Host
                }] }, { type: i0.ElementRef }], propDecorators: { accessKey: [{
                type: Input
            }], activeStateEnabled: [{
                type: Input
            }], disabled: [{
                type: Input
            }], elementAttr: [{
                type: Input
            }], focusStateEnabled: [{
                type: Input
            }], height: [{
                type: Input
            }], hint: [{
                type: Input
            }], hoverStateEnabled: [{
                type: Input
            }], icon: [{
                type: Input
            }], onClick: [{
                type: Input
            }], onContentReady: [{
                type: Input
            }], onDisposing: [{
                type: Input
            }], onInitialized: [{
                type: Input
            }], onOptionChanged: [{
                type: Input
            }], rtlEnabled: [{
                type: Input
            }], stylingMode: [{
                type: Input
            }], tabIndex: [{
                type: Input
            }], template: [{
                type: Input
            }], text: [{
                type: Input
            }], type: [{
                type: Input
            }], useSubmitBehavior: [{
                type: Input
            }], validationGroup: [{
                type: Input
            }], visible: [{
                type: Input
            }], width: [{
                type: Input
            }] } });
class DxoDateBoxOptionsModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDateBoxOptionsModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoDateBoxOptionsModule, imports: [DxoDateBoxOptionsComponent], exports: [DxoDateBoxOptionsComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDateBoxOptionsModule, imports: [DxoDateBoxOptionsComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDateBoxOptionsModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoDateBoxOptionsComponent
                    ],
                    exports: [
                        DxoDateBoxOptionsComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoDateBoxPositionComponent extends NestedOption {
    get at() {
        return this._getOption('at');
    }
    set at(value) {
        this._setOption('at', value);
    }
    get boundary() {
        return this._getOption('boundary');
    }
    set boundary(value) {
        this._setOption('boundary', value);
    }
    get boundaryOffset() {
        return this._getOption('boundaryOffset');
    }
    set boundaryOffset(value) {
        this._setOption('boundaryOffset', value);
    }
    get collision() {
        return this._getOption('collision');
    }
    set collision(value) {
        this._setOption('collision', value);
    }
    get my() {
        return this._getOption('my');
    }
    set my(value) {
        this._setOption('my', value);
    }
    get of() {
        return this._getOption('of');
    }
    set of(value) {
        this._setOption('of', value);
    }
    get offset() {
        return this._getOption('offset');
    }
    set offset(value) {
        this._setOption('offset', value);
    }
    get _optionPath() {
        return 'position';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDateBoxPositionComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoDateBoxPositionComponent, isStandalone: true, selector: "dxo-date-box-position", inputs: { at: "at", boundary: "boundary", boundaryOffset: "boundaryOffset", collision: "collision", my: "my", of: "of", offset: "offset" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDateBoxPositionComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-date-box-position', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { at: [{
                type: Input
            }], boundary: [{
                type: Input
            }], boundaryOffset: [{
                type: Input
            }], collision: [{
                type: Input
            }], my: [{
                type: Input
            }], of: [{
                type: Input
            }], offset: [{
                type: Input
            }] } });
class DxoDateBoxPositionModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDateBoxPositionModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoDateBoxPositionModule, imports: [DxoDateBoxPositionComponent], exports: [DxoDateBoxPositionComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDateBoxPositionModule, imports: [DxoDateBoxPositionComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDateBoxPositionModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoDateBoxPositionComponent
                    ],
                    exports: [
                        DxoDateBoxPositionComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoDateBoxShowComponent extends NestedOption {
    get complete() {
        return this._getOption('complete');
    }
    set complete(value) {
        this._setOption('complete', value);
    }
    get delay() {
        return this._getOption('delay');
    }
    set delay(value) {
        this._setOption('delay', value);
    }
    get direction() {
        return this._getOption('direction');
    }
    set direction(value) {
        this._setOption('direction', value);
    }
    get duration() {
        return this._getOption('duration');
    }
    set duration(value) {
        this._setOption('duration', value);
    }
    get easing() {
        return this._getOption('easing');
    }
    set easing(value) {
        this._setOption('easing', value);
    }
    get from() {
        return this._getOption('from');
    }
    set from(value) {
        this._setOption('from', value);
    }
    get staggerDelay() {
        return this._getOption('staggerDelay');
    }
    set staggerDelay(value) {
        this._setOption('staggerDelay', value);
    }
    get start() {
        return this._getOption('start');
    }
    set start(value) {
        this._setOption('start', value);
    }
    get to() {
        return this._getOption('to');
    }
    set to(value) {
        this._setOption('to', value);
    }
    get type() {
        return this._getOption('type');
    }
    set type(value) {
        this._setOption('type', value);
    }
    get _optionPath() {
        return 'show';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDateBoxShowComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoDateBoxShowComponent, isStandalone: true, selector: "dxo-date-box-show", inputs: { complete: "complete", delay: "delay", direction: "direction", duration: "duration", easing: "easing", from: "from", staggerDelay: "staggerDelay", start: "start", to: "to", type: "type" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDateBoxShowComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-date-box-show', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { complete: [{
                type: Input
            }], delay: [{
                type: Input
            }], direction: [{
                type: Input
            }], duration: [{
                type: Input
            }], easing: [{
                type: Input
            }], from: [{
                type: Input
            }], staggerDelay: [{
                type: Input
            }], start: [{
                type: Input
            }], to: [{
                type: Input
            }], type: [{
                type: Input
            }] } });
class DxoDateBoxShowModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDateBoxShowModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoDateBoxShowModule, imports: [DxoDateBoxShowComponent], exports: [DxoDateBoxShowComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDateBoxShowModule, imports: [DxoDateBoxShowComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDateBoxShowModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoDateBoxShowComponent
                    ],
                    exports: [
                        DxoDateBoxShowComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoDateBoxToComponent extends NestedOption {
    get left() {
        return this._getOption('left');
    }
    set left(value) {
        this._setOption('left', value);
    }
    get opacity() {
        return this._getOption('opacity');
    }
    set opacity(value) {
        this._setOption('opacity', value);
    }
    get position() {
        return this._getOption('position');
    }
    set position(value) {
        this._setOption('position', value);
    }
    get scale() {
        return this._getOption('scale');
    }
    set scale(value) {
        this._setOption('scale', value);
    }
    get top() {
        return this._getOption('top');
    }
    set top(value) {
        this._setOption('top', value);
    }
    get _optionPath() {
        return 'to';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDateBoxToComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoDateBoxToComponent, isStandalone: true, selector: "dxo-date-box-to", inputs: { left: "left", opacity: "opacity", position: "position", scale: "scale", top: "top" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDateBoxToComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-date-box-to', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { left: [{
                type: Input
            }], opacity: [{
                type: Input
            }], position: [{
                type: Input
            }], scale: [{
                type: Input
            }], top: [{
                type: Input
            }] } });
class DxoDateBoxToModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDateBoxToModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoDateBoxToModule, imports: [DxoDateBoxToComponent], exports: [DxoDateBoxToComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDateBoxToModule, imports: [DxoDateBoxToComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDateBoxToModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoDateBoxToComponent
                    ],
                    exports: [
                        DxoDateBoxToComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxiDateBoxToolbarItemComponent extends CollectionNestedOption {
    get cssClass() {
        return this._getOption('cssClass');
    }
    set cssClass(value) {
        this._setOption('cssClass', value);
    }
    get disabled() {
        return this._getOption('disabled');
    }
    set disabled(value) {
        this._setOption('disabled', value);
    }
    get html() {
        return this._getOption('html');
    }
    set html(value) {
        this._setOption('html', value);
    }
    get locateInMenu() {
        return this._getOption('locateInMenu');
    }
    set locateInMenu(value) {
        this._setOption('locateInMenu', value);
    }
    get location() {
        return this._getOption('location');
    }
    set location(value) {
        this._setOption('location', value);
    }
    get menuItemTemplate() {
        return this._getOption('menuItemTemplate');
    }
    set menuItemTemplate(value) {
        this._setOption('menuItemTemplate', value);
    }
    get options() {
        return this._getOption('options');
    }
    set options(value) {
        this._setOption('options', value);
    }
    get showText() {
        return this._getOption('showText');
    }
    set showText(value) {
        this._setOption('showText', value);
    }
    get template() {
        return this._getOption('template');
    }
    set template(value) {
        this._setOption('template', value);
    }
    get text() {
        return this._getOption('text');
    }
    set text(value) {
        this._setOption('text', value);
    }
    get toolbar() {
        return this._getOption('toolbar');
    }
    set toolbar(value) {
        this._setOption('toolbar', value);
    }
    get visible() {
        return this._getOption('visible');
    }
    set visible(value) {
        this._setOption('visible', value);
    }
    get widget() {
        return this._getOption('widget');
    }
    set widget(value) {
        this._setOption('widget', value);
    }
    get _optionPath() {
        return 'toolbarItems';
    }
    constructor(parentOptionHost, optionHost, renderer, document, templateHost, element) {
        super();
        this.renderer = renderer;
        this.document = document;
        this.element = element;
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
        templateHost.setHost(this);
    }
    setTemplate(template) {
        this.template = template;
    }
    ngAfterViewInit() {
        extractTemplate(this, this.element, this.renderer, this.document);
    }
    ngOnDestroy() {
        this._deleteRemovedOptions(this._fullOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiDateBoxToolbarItemComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }, { token: i0.Renderer2 }, { token: DOCUMENT }, { token: i1.DxTemplateHost, host: true }, { token: i0.ElementRef }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxiDateBoxToolbarItemComponent, isStandalone: true, selector: "dxi-date-box-toolbar-item", inputs: { cssClass: "cssClass", disabled: "disabled", html: "html", locateInMenu: "locateInMenu", location: "location", menuItemTemplate: "menuItemTemplate", options: "options", showText: "showText", template: "template", text: "text", toolbar: "toolbar", visible: "visible", widget: "widget" }, providers: [
            NestedOptionHost,
            DxTemplateHost,
            {
                provide: PROPERTY_TOKEN_toolbarItems,
                useExisting: DxiDateBoxToolbarItemComponent,
            }
        ], usesInheritance: true, ngImport: i0, template: '<ng-content></ng-content>', isInline: true, styles: [":host{display:block}\n"], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiDateBoxToolbarItemComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxi-date-box-toolbar-item', template: '<ng-content></ng-content>', imports: [DxIntegrationModule], providers: [
                        NestedOptionHost,
                        DxTemplateHost,
                        {
                            provide: PROPERTY_TOKEN_toolbarItems,
                            useExisting: DxiDateBoxToolbarItemComponent,
                        }
                    ], styles: [":host{display:block}\n"] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }, { type: i0.Renderer2 }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [DOCUMENT]
                }] }, { type: i1.DxTemplateHost, decorators: [{
                    type: Host
                }] }, { type: i0.ElementRef }], propDecorators: { cssClass: [{
                type: Input
            }], disabled: [{
                type: Input
            }], html: [{
                type: Input
            }], locateInMenu: [{
                type: Input
            }], location: [{
                type: Input
            }], menuItemTemplate: [{
                type: Input
            }], options: [{
                type: Input
            }], showText: [{
                type: Input
            }], template: [{
                type: Input
            }], text: [{
                type: Input
            }], toolbar: [{
                type: Input
            }], visible: [{
                type: Input
            }], widget: [{
                type: Input
            }] } });
class DxiDateBoxToolbarItemModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiDateBoxToolbarItemModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxiDateBoxToolbarItemModule, imports: [DxiDateBoxToolbarItemComponent], exports: [DxiDateBoxToolbarItemComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiDateBoxToolbarItemModule, imports: [DxiDateBoxToolbarItemComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiDateBoxToolbarItemModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxiDateBoxToolbarItemComponent
                    ],
                    exports: [
                        DxiDateBoxToolbarItemComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

/**
 * Generated bundle index. Do not edit.
 */

export { DxiDateBoxButtonComponent, DxiDateBoxButtonModule, DxiDateBoxToolbarItemComponent, DxiDateBoxToolbarItemModule, DxoDateBoxAnimationComponent, DxoDateBoxAnimationModule, DxoDateBoxAtComponent, DxoDateBoxAtModule, DxoDateBoxBoundaryOffsetComponent, DxoDateBoxBoundaryOffsetModule, DxoDateBoxCalendarOptionsComponent, DxoDateBoxCalendarOptionsModule, DxoDateBoxCollisionComponent, DxoDateBoxCollisionModule, DxoDateBoxDisplayFormatComponent, DxoDateBoxDisplayFormatModule, DxoDateBoxDropDownOptionsComponent, DxoDateBoxDropDownOptionsModule, DxoDateBoxFromComponent, DxoDateBoxFromModule, DxoDateBoxHideComponent, DxoDateBoxHideModule, DxoDateBoxMyComponent, DxoDateBoxMyModule, DxoDateBoxOffsetComponent, DxoDateBoxOffsetModule, DxoDateBoxOptionsComponent, DxoDateBoxOptionsModule, DxoDateBoxPositionComponent, DxoDateBoxPositionModule, DxoDateBoxShowComponent, DxoDateBoxShowModule, DxoDateBoxToComponent, DxoDateBoxToModule };
//# sourceMappingURL=devextreme-angular-ui-date-box-nested.mjs.map
