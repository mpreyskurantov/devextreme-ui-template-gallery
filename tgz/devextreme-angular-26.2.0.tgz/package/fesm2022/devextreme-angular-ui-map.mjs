import * as i0 from '@angular/core';
import { PLATFORM_ID, Output, Input, ContentChildren, Inject, Component, NgModule } from '@angular/core';
import DxMap from 'devextreme/ui/map';
import * as i1 from 'devextreme-angular/core';
import { DxComponent, DxIntegrationModule, DxTemplateHost, WatcherHelper, NestedOptionHost, IterableDifferHelper, DxTemplateModule } from 'devextreme-angular/core';
import { DxoApiKeyModule, DxiCenterModule, DxiMarkerModule, DxiLocationModule, DxoTooltipModule, DxoProviderConfigModule, DxiRouteModule } from 'devextreme-angular/ui/nested';
import { DxoMapApiKeyModule, DxoMapCenterModule, DxoMapLocationModule, DxiMapMarkerModule, DxoMapProviderConfigModule, DxiMapRouteModule, DxoMapTooltipModule, DxiMapLocationModule } from 'devextreme-angular/ui/map/nested';
export * from 'devextreme-angular/ui/map/nested';
import { PROPERTY_TOKEN_markers, PROPERTY_TOKEN_routes, PROPERTY_TOKEN_locations, PROPERTY_TOKEN_center } from 'devextreme-angular/core/tokens';

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
/**
 * [descr:dxMap]

 */
class DxMapComponent extends DxComponent {
    set _markersContentChildren(value) {
        this.setChildren('markers', value);
    }
    set _routesContentChildren(value) {
        this.setChildren('routes', value);
    }
    set _locationsContentChildren(value) {
        this.setChildren('locations', value);
    }
    set _centerContentChildren(value) {
        this.setChildren('center', value);
    }
    /**
     * [descr:WidgetOptions.accessKey]
    
     */
    get accessKey() {
        return this._getOption('accessKey');
    }
    set accessKey(value) {
        this._setOption('accessKey', value);
    }
    /**
     * [descr:WidgetOptions.activeStateEnabled]
    
     */
    get activeStateEnabled() {
        return this._getOption('activeStateEnabled');
    }
    set activeStateEnabled(value) {
        this._setOption('activeStateEnabled', value);
    }
    /**
     * [descr:dxMapOptions.apiKey]
    
     */
    get apiKey() {
        return this._getOption('apiKey');
    }
    set apiKey(value) {
        this._setOption('apiKey', value);
    }
    /**
     * [descr:dxMapOptions.autoAdjust]
    
     */
    get autoAdjust() {
        return this._getOption('autoAdjust');
    }
    set autoAdjust(value) {
        this._setOption('autoAdjust', value);
    }
    /**
     * [descr:dxMapOptions.center]
    
     */
    get center() {
        return this._getOption('center');
    }
    set center(value) {
        this._setOption('center', value);
    }
    /**
     * [descr:dxMapOptions.controls]
    
     */
    get controls() {
        return this._getOption('controls');
    }
    set controls(value) {
        this._setOption('controls', value);
    }
    /**
     * [descr:WidgetOptions.disabled]
    
     */
    get disabled() {
        return this._getOption('disabled');
    }
    set disabled(value) {
        this._setOption('disabled', value);
    }
    /**
     * [descr:DOMComponentOptions.elementAttr]
    
     */
    get elementAttr() {
        return this._getOption('elementAttr');
    }
    set elementAttr(value) {
        this._setOption('elementAttr', value);
    }
    /**
     * [descr:dxMapOptions.focusStateEnabled]
    
     */
    get focusStateEnabled() {
        return this._getOption('focusStateEnabled');
    }
    set focusStateEnabled(value) {
        this._setOption('focusStateEnabled', value);
    }
    /**
     * [descr:dxMapOptions.height]
    
     */
    get height() {
        return this._getOption('height');
    }
    set height(value) {
        this._setOption('height', value);
    }
    /**
     * [descr:WidgetOptions.hint]
    
     */
    get hint() {
        return this._getOption('hint');
    }
    set hint(value) {
        this._setOption('hint', value);
    }
    /**
     * [descr:WidgetOptions.hoverStateEnabled]
    
     */
    get hoverStateEnabled() {
        return this._getOption('hoverStateEnabled');
    }
    set hoverStateEnabled(value) {
        this._setOption('hoverStateEnabled', value);
    }
    /**
     * [descr:dxMapOptions.markerIconSrc]
    
     */
    get markerIconSrc() {
        return this._getOption('markerIconSrc');
    }
    set markerIconSrc(value) {
        this._setOption('markerIconSrc', value);
    }
    /**
     * [descr:dxMapOptions.markers]
    
     */
    get markers() {
        return this._getOption('markers');
    }
    set markers(value) {
        this._setOption('markers', value);
    }
    /**
     * [descr:dxMapOptions.provider]
    
     */
    get provider() {
        return this._getOption('provider');
    }
    set provider(value) {
        this._setOption('provider', value);
    }
    /**
     * [descr:dxMapOptions.providerConfig]
    
     */
    get providerConfig() {
        return this._getOption('providerConfig');
    }
    set providerConfig(value) {
        this._setOption('providerConfig', value);
    }
    /**
     * [descr:dxMapOptions.routes]
    
     */
    get routes() {
        return this._getOption('routes');
    }
    set routes(value) {
        this._setOption('routes', value);
    }
    /**
     * [descr:DOMComponentOptions.rtlEnabled]
    
     */
    get rtlEnabled() {
        return this._getOption('rtlEnabled');
    }
    set rtlEnabled(value) {
        this._setOption('rtlEnabled', value);
    }
    /**
     * [descr:WidgetOptions.tabIndex]
    
     */
    get tabIndex() {
        return this._getOption('tabIndex');
    }
    set tabIndex(value) {
        this._setOption('tabIndex', value);
    }
    /**
     * [descr:dxMapOptions.type]
    
     */
    get type() {
        return this._getOption('type');
    }
    set type(value) {
        this._setOption('type', value);
    }
    /**
     * [descr:WidgetOptions.visible]
    
     */
    get visible() {
        return this._getOption('visible');
    }
    set visible(value) {
        this._setOption('visible', value);
    }
    /**
     * [descr:dxMapOptions.width]
    
     */
    get width() {
        return this._getOption('width');
    }
    set width(value) {
        this._setOption('width', value);
    }
    /**
     * [descr:dxMapOptions.zoom]
    
     */
    get zoom() {
        return this._getOption('zoom');
    }
    set zoom(value) {
        this._setOption('zoom', value);
    }
    constructor(elementRef, ngZone, templateHost, _watcherHelper, _idh, optionHost, transferState, platformId) {
        super(elementRef, ngZone, templateHost, _watcherHelper, transferState, platformId);
        this._watcherHelper = _watcherHelper;
        this._idh = _idh;
        this.instance = null;
        this._createEventEmitters([
            { subscribe: 'click', emit: 'onClick' },
            { subscribe: 'disposing', emit: 'onDisposing' },
            { subscribe: 'initialized', emit: 'onInitialized' },
            { subscribe: 'markerAdded', emit: 'onMarkerAdded' },
            { subscribe: 'markerRemoved', emit: 'onMarkerRemoved' },
            { subscribe: 'optionChanged', emit: 'onOptionChanged' },
            { subscribe: 'ready', emit: 'onReady' },
            { subscribe: 'routeAdded', emit: 'onRouteAdded' },
            { subscribe: 'routeRemoved', emit: 'onRouteRemoved' },
            { emit: 'accessKeyChange' },
            { emit: 'activeStateEnabledChange' },
            { emit: 'apiKeyChange' },
            { emit: 'autoAdjustChange' },
            { emit: 'centerChange' },
            { emit: 'controlsChange' },
            { emit: 'disabledChange' },
            { emit: 'elementAttrChange' },
            { emit: 'focusStateEnabledChange' },
            { emit: 'heightChange' },
            { emit: 'hintChange' },
            { emit: 'hoverStateEnabledChange' },
            { emit: 'markerIconSrcChange' },
            { emit: 'markersChange' },
            { emit: 'providerChange' },
            { emit: 'providerConfigChange' },
            { emit: 'routesChange' },
            { emit: 'rtlEnabledChange' },
            { emit: 'tabIndexChange' },
            { emit: 'typeChange' },
            { emit: 'visibleChange' },
            { emit: 'widthChange' },
            { emit: 'zoomChange' }
        ]);
        this._idh.setHost(this);
        optionHost.setHost(this);
    }
    _createInstance(element, options) {
        return new DxMap(element, options);
    }
    ngOnDestroy() {
        this._destroyWidget();
    }
    ngOnChanges(changes) {
        super.ngOnChanges(changes);
        this.setupChanges('center', changes);
        this.setupChanges('markers', changes);
        this.setupChanges('routes', changes);
    }
    setupChanges(prop, changes) {
        if (!(prop in this._optionsToUpdate)) {
            this._idh.setup(prop, changes);
        }
    }
    ngDoCheck() {
        this._idh.doCheck('center');
        this._idh.doCheck('markers');
        this._idh.doCheck('routes');
        this._watcherHelper.checkWatchers();
        super.ngDoCheck();
        super.clearChangedOptions();
    }
    _setOption(name, value) {
        let isSetup = this._idh.setupSingle(name, value);
        let isChanged = this._idh.getChanges(name, value) !== null;
        if (isSetup || isChanged) {
            super._setOption(name, value);
        }
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxMapComponent, deps: [{ token: i0.ElementRef }, { token: i0.NgZone }, { token: i1.DxTemplateHost }, { token: i1.WatcherHelper }, { token: i1.IterableDifferHelper }, { token: i1.NestedOptionHost }, { token: i0.TransferState }, { token: PLATFORM_ID }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxMapComponent, isStandalone: true, selector: "dx-map", inputs: { accessKey: "accessKey", activeStateEnabled: "activeStateEnabled", apiKey: "apiKey", autoAdjust: "autoAdjust", center: "center", controls: "controls", disabled: "disabled", elementAttr: "elementAttr", focusStateEnabled: "focusStateEnabled", height: "height", hint: "hint", hoverStateEnabled: "hoverStateEnabled", markerIconSrc: "markerIconSrc", markers: "markers", provider: "provider", providerConfig: "providerConfig", routes: "routes", rtlEnabled: "rtlEnabled", tabIndex: "tabIndex", type: "type", visible: "visible", width: "width", zoom: "zoom" }, outputs: { onClick: "onClick", onDisposing: "onDisposing", onInitialized: "onInitialized", onMarkerAdded: "onMarkerAdded", onMarkerRemoved: "onMarkerRemoved", onOptionChanged: "onOptionChanged", onReady: "onReady", onRouteAdded: "onRouteAdded", onRouteRemoved: "onRouteRemoved", accessKeyChange: "accessKeyChange", activeStateEnabledChange: "activeStateEnabledChange", apiKeyChange: "apiKeyChange", autoAdjustChange: "autoAdjustChange", centerChange: "centerChange", controlsChange: "controlsChange", disabledChange: "disabledChange", elementAttrChange: "elementAttrChange", focusStateEnabledChange: "focusStateEnabledChange", heightChange: "heightChange", hintChange: "hintChange", hoverStateEnabledChange: "hoverStateEnabledChange", markerIconSrcChange: "markerIconSrcChange", markersChange: "markersChange", providerChange: "providerChange", providerConfigChange: "providerConfigChange", routesChange: "routesChange", rtlEnabledChange: "rtlEnabledChange", tabIndexChange: "tabIndexChange", typeChange: "typeChange", visibleChange: "visibleChange", widthChange: "widthChange", zoomChange: "zoomChange" }, host: { attributes: { "ngSkipHydration": "true" } }, providers: [
            DxTemplateHost,
            WatcherHelper,
            NestedOptionHost,
            IterableDifferHelper
        ], queries: [{ propertyName: "_markersContentChildren", predicate: PROPERTY_TOKEN_markers }, { propertyName: "_routesContentChildren", predicate: PROPERTY_TOKEN_routes }, { propertyName: "_locationsContentChildren", predicate: PROPERTY_TOKEN_locations }, { propertyName: "_centerContentChildren", predicate: PROPERTY_TOKEN_center }], usesInheritance: true, usesOnChanges: true, ngImport: i0, template: '', isInline: true, dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxMapComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'dx-map',
                    template: '',
                    host: { ngSkipHydration: 'true' },
                    imports: [DxIntegrationModule],
                    providers: [
                        DxTemplateHost,
                        WatcherHelper,
                        NestedOptionHost,
                        IterableDifferHelper
                    ]
                }]
        }], ctorParameters: () => [{ type: i0.ElementRef }, { type: i0.NgZone }, { type: i1.DxTemplateHost }, { type: i1.WatcherHelper }, { type: i1.IterableDifferHelper }, { type: i1.NestedOptionHost }, { type: i0.TransferState }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [PLATFORM_ID]
                }] }], propDecorators: { _markersContentChildren: [{
                type: ContentChildren,
                args: [PROPERTY_TOKEN_markers]
            }], _routesContentChildren: [{
                type: ContentChildren,
                args: [PROPERTY_TOKEN_routes]
            }], _locationsContentChildren: [{
                type: ContentChildren,
                args: [PROPERTY_TOKEN_locations]
            }], _centerContentChildren: [{
                type: ContentChildren,
                args: [PROPERTY_TOKEN_center]
            }], accessKey: [{
                type: Input
            }], activeStateEnabled: [{
                type: Input
            }], apiKey: [{
                type: Input
            }], autoAdjust: [{
                type: Input
            }], center: [{
                type: Input
            }], controls: [{
                type: Input
            }], disabled: [{
                type: Input
            }], elementAttr: [{
                type: Input
            }], focusStateEnabled: [{
                type: Input
            }], height: [{
                type: Input
            }], hint: [{
                type: Input
            }], hoverStateEnabled: [{
                type: Input
            }], markerIconSrc: [{
                type: Input
            }], markers: [{
                type: Input
            }], provider: [{
                type: Input
            }], providerConfig: [{
                type: Input
            }], routes: [{
                type: Input
            }], rtlEnabled: [{
                type: Input
            }], tabIndex: [{
                type: Input
            }], type: [{
                type: Input
            }], visible: [{
                type: Input
            }], width: [{
                type: Input
            }], zoom: [{
                type: Input
            }], onClick: [{
                type: Output
            }], onDisposing: [{
                type: Output
            }], onInitialized: [{
                type: Output
            }], onMarkerAdded: [{
                type: Output
            }], onMarkerRemoved: [{
                type: Output
            }], onOptionChanged: [{
                type: Output
            }], onReady: [{
                type: Output
            }], onRouteAdded: [{
                type: Output
            }], onRouteRemoved: [{
                type: Output
            }], accessKeyChange: [{
                type: Output
            }], activeStateEnabledChange: [{
                type: Output
            }], apiKeyChange: [{
                type: Output
            }], autoAdjustChange: [{
                type: Output
            }], centerChange: [{
                type: Output
            }], controlsChange: [{
                type: Output
            }], disabledChange: [{
                type: Output
            }], elementAttrChange: [{
                type: Output
            }], focusStateEnabledChange: [{
                type: Output
            }], heightChange: [{
                type: Output
            }], hintChange: [{
                type: Output
            }], hoverStateEnabledChange: [{
                type: Output
            }], markerIconSrcChange: [{
                type: Output
            }], markersChange: [{
                type: Output
            }], providerChange: [{
                type: Output
            }], providerConfigChange: [{
                type: Output
            }], routesChange: [{
                type: Output
            }], rtlEnabledChange: [{
                type: Output
            }], tabIndexChange: [{
                type: Output
            }], typeChange: [{
                type: Output
            }], visibleChange: [{
                type: Output
            }], widthChange: [{
                type: Output
            }], zoomChange: [{
                type: Output
            }] } });
class DxMapModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxMapModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxMapModule, imports: [DxMapComponent, DxoApiKeyModule,
            DxiCenterModule,
            DxiMarkerModule,
            DxiLocationModule,
            DxoTooltipModule,
            DxoProviderConfigModule,
            DxiRouteModule,
            DxoMapApiKeyModule,
            DxoMapCenterModule,
            DxoMapLocationModule,
            DxiMapMarkerModule,
            DxoMapProviderConfigModule,
            DxiMapRouteModule,
            DxoMapTooltipModule,
            DxiMapLocationModule,
            DxIntegrationModule,
            DxTemplateModule], exports: [DxMapComponent, DxoApiKeyModule,
            DxiCenterModule,
            DxiMarkerModule,
            DxiLocationModule,
            DxoTooltipModule,
            DxoProviderConfigModule,
            DxiRouteModule,
            DxoMapApiKeyModule,
            DxoMapCenterModule,
            DxoMapLocationModule,
            DxiMapMarkerModule,
            DxoMapProviderConfigModule,
            DxiMapRouteModule,
            DxoMapTooltipModule,
            DxiMapLocationModule,
            DxTemplateModule] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxMapModule, imports: [DxMapComponent,
            DxoApiKeyModule,
            DxiCenterModule,
            DxiMarkerModule,
            DxiLocationModule,
            DxoTooltipModule,
            DxoProviderConfigModule,
            DxiRouteModule,
            DxoMapApiKeyModule,
            DxoMapCenterModule,
            DxoMapLocationModule,
            DxiMapMarkerModule,
            DxoMapProviderConfigModule,
            DxiMapRouteModule,
            DxoMapTooltipModule,
            DxiMapLocationModule,
            DxIntegrationModule,
            DxTemplateModule, DxoApiKeyModule,
            DxiCenterModule,
            DxiMarkerModule,
            DxiLocationModule,
            DxoTooltipModule,
            DxoProviderConfigModule,
            DxiRouteModule,
            DxoMapApiKeyModule,
            DxoMapCenterModule,
            DxoMapLocationModule,
            DxiMapMarkerModule,
            DxoMapProviderConfigModule,
            DxiMapRouteModule,
            DxoMapTooltipModule,
            DxiMapLocationModule,
            DxTemplateModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxMapModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxMapComponent,
                        DxoApiKeyModule,
                        DxiCenterModule,
                        DxiMarkerModule,
                        DxiLocationModule,
                        DxoTooltipModule,
                        DxoProviderConfigModule,
                        DxiRouteModule,
                        DxoMapApiKeyModule,
                        DxoMapCenterModule,
                        DxoMapLocationModule,
                        DxiMapMarkerModule,
                        DxoMapProviderConfigModule,
                        DxiMapRouteModule,
                        DxoMapTooltipModule,
                        DxiMapLocationModule,
                        DxIntegrationModule,
                        DxTemplateModule
                    ],
                    exports: [
                        DxMapComponent,
                        DxoApiKeyModule,
                        DxiCenterModule,
                        DxiMarkerModule,
                        DxiLocationModule,
                        DxoTooltipModule,
                        DxoProviderConfigModule,
                        DxiRouteModule,
                        DxoMapApiKeyModule,
                        DxoMapCenterModule,
                        DxoMapLocationModule,
                        DxiMapMarkerModule,
                        DxoMapProviderConfigModule,
                        DxiMapRouteModule,
                        DxoMapTooltipModule,
                        DxiMapLocationModule,
                        DxTemplateModule
                    ]
                }]
        }] });

/**
 * Generated bundle index. Do not edit.
 */

export { DxMapComponent, DxMapModule };
//# sourceMappingURL=devextreme-angular-ui-map.mjs.map
