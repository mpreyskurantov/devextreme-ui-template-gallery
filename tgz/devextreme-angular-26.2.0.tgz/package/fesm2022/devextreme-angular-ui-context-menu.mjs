import * as i0 from '@angular/core';
import { PLATFORM_ID, Output, Input, ContentChildren, Inject, Component, NgModule } from '@angular/core';
import DxContextMenu from 'devextreme/ui/context_menu';
import * as i1 from 'devextreme-angular/core';
import { DxComponent, DxIntegrationModule, DxTemplateHost, WatcherHelper, NestedOptionHost, IterableDifferHelper, DxTemplateModule } from 'devextreme-angular/core';
import { DxoAnimationModule, DxoHideModule, DxoFromModule, DxoPositionModule, DxoAtModule, DxoBoundaryOffsetModule, DxoCollisionModule, DxoMyModule, DxoOffsetModule, DxoToModule, DxoShowModule, DxiItemModule, DxoShowEventModule, DxoShowSubmenuModeModule, DxoDelayModule } from 'devextreme-angular/ui/nested';
import { DxoContextMenuAnimationModule, DxoContextMenuAtModule, DxoContextMenuBoundaryOffsetModule, DxoContextMenuCollisionModule, DxoContextMenuDelayModule, DxoContextMenuFromModule, DxoContextMenuHideModule, DxiContextMenuItemModule, DxoContextMenuMyModule, DxoContextMenuOffsetModule, DxoContextMenuPositionModule, DxoContextMenuShowModule, DxoContextMenuShowEventModule, DxoContextMenuShowSubmenuModeModule, DxoContextMenuToModule } from 'devextreme-angular/ui/context-menu/nested';
export * from 'devextreme-angular/ui/context-menu/nested';
import { PROPERTY_TOKEN_items } from 'devextreme-angular/core/tokens';

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
/**
 * [descr:dxContextMenu]

 */
class DxContextMenuComponent extends DxComponent {
    set _itemsContentChildren(value) {
        this.setChildren('items', value);
    }
    /**
     * [descr:WidgetOptions.accessKey]
    
     */
    get accessKey() {
        return this._getOption('accessKey');
    }
    set accessKey(value) {
        this._setOption('accessKey', value);
    }
    /**
     * [descr:dxMenuBaseOptions.activeStateEnabled]
    
     */
    get activeStateEnabled() {
        return this._getOption('activeStateEnabled');
    }
    set activeStateEnabled(value) {
        this._setOption('activeStateEnabled', value);
    }
    /**
     * [descr:dxMenuBaseOptions.animation]
    
     */
    get animation() {
        return this._getOption('animation');
    }
    set animation(value) {
        this._setOption('animation', value);
    }
    /**
     * [descr:dxMenuBaseOptions.cssClass]
    
     */
    get cssClass() {
        return this._getOption('cssClass');
    }
    set cssClass(value) {
        this._setOption('cssClass', value);
    }
    /**
     * [descr:dxContextMenuOptions.dataSource]
    
     */
    get dataSource() {
        return this._getOption('dataSource');
    }
    set dataSource(value) {
        this._setOption('dataSource', value);
    }
    /**
     * [descr:WidgetOptions.disabled]
    
     */
    get disabled() {
        return this._getOption('disabled');
    }
    set disabled(value) {
        this._setOption('disabled', value);
    }
    /**
     * [descr:HierarchicalCollectionWidgetOptions.disabledExpr]
    
     */
    get disabledExpr() {
        return this._getOption('disabledExpr');
    }
    set disabledExpr(value) {
        this._setOption('disabledExpr', value);
    }
    /**
     * [descr:HierarchicalCollectionWidgetOptions.displayExpr]
    
     */
    get displayExpr() {
        return this._getOption('displayExpr');
    }
    set displayExpr(value) {
        this._setOption('displayExpr', value);
    }
    /**
     * [descr:DOMComponentOptions.elementAttr]
    
     */
    get elementAttr() {
        return this._getOption('elementAttr');
    }
    set elementAttr(value) {
        this._setOption('elementAttr', value);
    }
    /**
     * [descr:HierarchicalCollectionWidgetOptions.focusStateEnabled]
    
     */
    get focusStateEnabled() {
        return this._getOption('focusStateEnabled');
    }
    set focusStateEnabled(value) {
        this._setOption('focusStateEnabled', value);
    }
    /**
     * [descr:DOMComponentOptions.height]
    
     */
    get height() {
        return this._getOption('height');
    }
    set height(value) {
        this._setOption('height', value);
    }
    /**
     * [descr:dxContextMenuOptions.hideOnOutsideClick]
    
     */
    get hideOnOutsideClick() {
        return this._getOption('hideOnOutsideClick');
    }
    set hideOnOutsideClick(value) {
        this._setOption('hideOnOutsideClick', value);
    }
    /**
     * [descr:WidgetOptions.hint]
    
     */
    get hint() {
        return this._getOption('hint');
    }
    set hint(value) {
        this._setOption('hint', value);
    }
    /**
     * [descr:HierarchicalCollectionWidgetOptions.hoverStateEnabled]
    
     */
    get hoverStateEnabled() {
        return this._getOption('hoverStateEnabled');
    }
    set hoverStateEnabled(value) {
        this._setOption('hoverStateEnabled', value);
    }
    /**
     * [descr:dxContextMenuOptions.items]
    
     */
    get items() {
        return this._getOption('items');
    }
    set items(value) {
        this._setOption('items', value);
    }
    /**
     * [descr:HierarchicalCollectionWidgetOptions.itemsExpr]
    
     */
    get itemsExpr() {
        return this._getOption('itemsExpr');
    }
    set itemsExpr(value) {
        this._setOption('itemsExpr', value);
    }
    /**
     * [descr:CollectionWidgetOptions.itemTemplate]
    
     */
    get itemTemplate() {
        return this._getOption('itemTemplate');
    }
    set itemTemplate(value) {
        this._setOption('itemTemplate', value);
    }
    /**
     * [descr:dxContextMenuOptions.position]
    
     */
    get position() {
        return this._getOption('position');
    }
    set position(value) {
        this._setOption('position', value);
    }
    /**
     * [descr:DOMComponentOptions.rtlEnabled]
    
     */
    get rtlEnabled() {
        return this._getOption('rtlEnabled');
    }
    set rtlEnabled(value) {
        this._setOption('rtlEnabled', value);
    }
    /**
     * [descr:dxMenuBaseOptions.selectByClick]
    
     */
    get selectByClick() {
        return this._getOption('selectByClick');
    }
    set selectByClick(value) {
        this._setOption('selectByClick', value);
    }
    /**
     * [descr:HierarchicalCollectionWidgetOptions.selectedExpr]
    
     */
    get selectedExpr() {
        return this._getOption('selectedExpr');
    }
    set selectedExpr(value) {
        this._setOption('selectedExpr', value);
    }
    /**
     * [descr:CollectionWidgetOptions.selectedItem]
    
     */
    get selectedItem() {
        return this._getOption('selectedItem');
    }
    set selectedItem(value) {
        this._setOption('selectedItem', value);
    }
    /**
     * [descr:dxMenuBaseOptions.selectionMode]
    
     */
    get selectionMode() {
        return this._getOption('selectionMode');
    }
    set selectionMode(value) {
        this._setOption('selectionMode', value);
    }
    /**
     * [descr:dxContextMenuOptions.showEvent]
    
     */
    get showEvent() {
        return this._getOption('showEvent');
    }
    set showEvent(value) {
        this._setOption('showEvent', value);
    }
    /**
     * [descr:dxMenuBaseOptions.showSubmenuMode]
    
     */
    get showSubmenuMode() {
        return this._getOption('showSubmenuMode');
    }
    set showSubmenuMode(value) {
        this._setOption('showSubmenuMode', value);
    }
    /**
     * [descr:dxContextMenuOptions.submenuDirection]
    
     */
    get submenuDirection() {
        return this._getOption('submenuDirection');
    }
    set submenuDirection(value) {
        this._setOption('submenuDirection', value);
    }
    /**
     * [descr:WidgetOptions.tabIndex]
    
     */
    get tabIndex() {
        return this._getOption('tabIndex');
    }
    set tabIndex(value) {
        this._setOption('tabIndex', value);
    }
    /**
     * [descr:dxContextMenuOptions.target]
    
     */
    get target() {
        return this._getOption('target');
    }
    set target(value) {
        this._setOption('target', value);
    }
    /**
     * [descr:dxContextMenuOptions.visible]
    
     */
    get visible() {
        return this._getOption('visible');
    }
    set visible(value) {
        this._setOption('visible', value);
    }
    /**
     * [descr:DOMComponentOptions.width]
    
     */
    get width() {
        return this._getOption('width');
    }
    set width(value) {
        this._setOption('width', value);
    }
    constructor(elementRef, ngZone, templateHost, _watcherHelper, _idh, optionHost, transferState, platformId) {
        super(elementRef, ngZone, templateHost, _watcherHelper, transferState, platformId);
        this._watcherHelper = _watcherHelper;
        this._idh = _idh;
        this.instance = null;
        this._createEventEmitters([
            { subscribe: 'contentReady', emit: 'onContentReady' },
            { subscribe: 'disposing', emit: 'onDisposing' },
            { subscribe: 'hidden', emit: 'onHidden' },
            { subscribe: 'hiding', emit: 'onHiding' },
            { subscribe: 'initialized', emit: 'onInitialized' },
            { subscribe: 'itemClick', emit: 'onItemClick' },
            { subscribe: 'itemContextMenu', emit: 'onItemContextMenu' },
            { subscribe: 'itemRendered', emit: 'onItemRendered' },
            { subscribe: 'optionChanged', emit: 'onOptionChanged' },
            { subscribe: 'positioning', emit: 'onPositioning' },
            { subscribe: 'selectionChanged', emit: 'onSelectionChanged' },
            { subscribe: 'showing', emit: 'onShowing' },
            { subscribe: 'shown', emit: 'onShown' },
            { emit: 'accessKeyChange' },
            { emit: 'activeStateEnabledChange' },
            { emit: 'animationChange' },
            { emit: 'cssClassChange' },
            { emit: 'dataSourceChange' },
            { emit: 'disabledChange' },
            { emit: 'disabledExprChange' },
            { emit: 'displayExprChange' },
            { emit: 'elementAttrChange' },
            { emit: 'focusStateEnabledChange' },
            { emit: 'heightChange' },
            { emit: 'hideOnOutsideClickChange' },
            { emit: 'hintChange' },
            { emit: 'hoverStateEnabledChange' },
            { emit: 'itemsChange' },
            { emit: 'itemsExprChange' },
            { emit: 'itemTemplateChange' },
            { emit: 'positionChange' },
            { emit: 'rtlEnabledChange' },
            { emit: 'selectByClickChange' },
            { emit: 'selectedExprChange' },
            { emit: 'selectedItemChange' },
            { emit: 'selectionModeChange' },
            { emit: 'showEventChange' },
            { emit: 'showSubmenuModeChange' },
            { emit: 'submenuDirectionChange' },
            { emit: 'tabIndexChange' },
            { emit: 'targetChange' },
            { emit: 'visibleChange' },
            { emit: 'widthChange' }
        ]);
        this._idh.setHost(this);
        optionHost.setHost(this);
    }
    _createInstance(element, options) {
        return new DxContextMenu(element, options);
    }
    ngOnDestroy() {
        this._destroyWidget();
    }
    ngOnChanges(changes) {
        super.ngOnChanges(changes);
        this.setupChanges('dataSource', changes);
        this.setupChanges('items', changes);
    }
    setupChanges(prop, changes) {
        if (!(prop in this._optionsToUpdate)) {
            this._idh.setup(prop, changes);
        }
    }
    ngDoCheck() {
        this._idh.doCheck('dataSource');
        this._idh.doCheck('items');
        this._watcherHelper.checkWatchers();
        super.ngDoCheck();
        super.clearChangedOptions();
    }
    _setOption(name, value) {
        let isSetup = this._idh.setupSingle(name, value);
        let isChanged = this._idh.getChanges(name, value) !== null;
        if (isSetup || isChanged) {
            super._setOption(name, value);
        }
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxContextMenuComponent, deps: [{ token: i0.ElementRef }, { token: i0.NgZone }, { token: i1.DxTemplateHost }, { token: i1.WatcherHelper }, { token: i1.IterableDifferHelper }, { token: i1.NestedOptionHost }, { token: i0.TransferState }, { token: PLATFORM_ID }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxContextMenuComponent, isStandalone: true, selector: "dx-context-menu", inputs: { accessKey: "accessKey", activeStateEnabled: "activeStateEnabled", animation: "animation", cssClass: "cssClass", dataSource: "dataSource", disabled: "disabled", disabledExpr: "disabledExpr", displayExpr: "displayExpr", elementAttr: "elementAttr", focusStateEnabled: "focusStateEnabled", height: "height", hideOnOutsideClick: "hideOnOutsideClick", hint: "hint", hoverStateEnabled: "hoverStateEnabled", items: "items", itemsExpr: "itemsExpr", itemTemplate: "itemTemplate", position: "position", rtlEnabled: "rtlEnabled", selectByClick: "selectByClick", selectedExpr: "selectedExpr", selectedItem: "selectedItem", selectionMode: "selectionMode", showEvent: "showEvent", showSubmenuMode: "showSubmenuMode", submenuDirection: "submenuDirection", tabIndex: "tabIndex", target: "target", visible: "visible", width: "width" }, outputs: { onContentReady: "onContentReady", onDisposing: "onDisposing", onHidden: "onHidden", onHiding: "onHiding", onInitialized: "onInitialized", onItemClick: "onItemClick", onItemContextMenu: "onItemContextMenu", onItemRendered: "onItemRendered", onOptionChanged: "onOptionChanged", onPositioning: "onPositioning", onSelectionChanged: "onSelectionChanged", onShowing: "onShowing", onShown: "onShown", accessKeyChange: "accessKeyChange", activeStateEnabledChange: "activeStateEnabledChange", animationChange: "animationChange", cssClassChange: "cssClassChange", dataSourceChange: "dataSourceChange", disabledChange: "disabledChange", disabledExprChange: "disabledExprChange", displayExprChange: "displayExprChange", elementAttrChange: "elementAttrChange", focusStateEnabledChange: "focusStateEnabledChange", heightChange: "heightChange", hideOnOutsideClickChange: "hideOnOutsideClickChange", hintChange: "hintChange", hoverStateEnabledChange: "hoverStateEnabledChange", itemsChange: "itemsChange", itemsExprChange: "itemsExprChange", itemTemplateChange: "itemTemplateChange", positionChange: "positionChange", rtlEnabledChange: "rtlEnabledChange", selectByClickChange: "selectByClickChange", selectedExprChange: "selectedExprChange", selectedItemChange: "selectedItemChange", selectionModeChange: "selectionModeChange", showEventChange: "showEventChange", showSubmenuModeChange: "showSubmenuModeChange", submenuDirectionChange: "submenuDirectionChange", tabIndexChange: "tabIndexChange", targetChange: "targetChange", visibleChange: "visibleChange", widthChange: "widthChange" }, host: { attributes: { "ngSkipHydration": "true" } }, providers: [
            DxTemplateHost,
            WatcherHelper,
            NestedOptionHost,
            IterableDifferHelper
        ], queries: [{ propertyName: "_itemsContentChildren", predicate: PROPERTY_TOKEN_items }], usesInheritance: true, usesOnChanges: true, ngImport: i0, template: '', isInline: true, dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxContextMenuComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'dx-context-menu',
                    template: '',
                    host: { ngSkipHydration: 'true' },
                    imports: [DxIntegrationModule],
                    providers: [
                        DxTemplateHost,
                        WatcherHelper,
                        NestedOptionHost,
                        IterableDifferHelper
                    ]
                }]
        }], ctorParameters: () => [{ type: i0.ElementRef }, { type: i0.NgZone }, { type: i1.DxTemplateHost }, { type: i1.WatcherHelper }, { type: i1.IterableDifferHelper }, { type: i1.NestedOptionHost }, { type: i0.TransferState }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [PLATFORM_ID]
                }] }], propDecorators: { _itemsContentChildren: [{
                type: ContentChildren,
                args: [PROPERTY_TOKEN_items]
            }], accessKey: [{
                type: Input
            }], activeStateEnabled: [{
                type: Input
            }], animation: [{
                type: Input
            }], cssClass: [{
                type: Input
            }], dataSource: [{
                type: Input
            }], disabled: [{
                type: Input
            }], disabledExpr: [{
                type: Input
            }], displayExpr: [{
                type: Input
            }], elementAttr: [{
                type: Input
            }], focusStateEnabled: [{
                type: Input
            }], height: [{
                type: Input
            }], hideOnOutsideClick: [{
                type: Input
            }], hint: [{
                type: Input
            }], hoverStateEnabled: [{
                type: Input
            }], items: [{
                type: Input
            }], itemsExpr: [{
                type: Input
            }], itemTemplate: [{
                type: Input
            }], position: [{
                type: Input
            }], rtlEnabled: [{
                type: Input
            }], selectByClick: [{
                type: Input
            }], selectedExpr: [{
                type: Input
            }], selectedItem: [{
                type: Input
            }], selectionMode: [{
                type: Input
            }], showEvent: [{
                type: Input
            }], showSubmenuMode: [{
                type: Input
            }], submenuDirection: [{
                type: Input
            }], tabIndex: [{
                type: Input
            }], target: [{
                type: Input
            }], visible: [{
                type: Input
            }], width: [{
                type: Input
            }], onContentReady: [{
                type: Output
            }], onDisposing: [{
                type: Output
            }], onHidden: [{
                type: Output
            }], onHiding: [{
                type: Output
            }], onInitialized: [{
                type: Output
            }], onItemClick: [{
                type: Output
            }], onItemContextMenu: [{
                type: Output
            }], onItemRendered: [{
                type: Output
            }], onOptionChanged: [{
                type: Output
            }], onPositioning: [{
                type: Output
            }], onSelectionChanged: [{
                type: Output
            }], onShowing: [{
                type: Output
            }], onShown: [{
                type: Output
            }], accessKeyChange: [{
                type: Output
            }], activeStateEnabledChange: [{
                type: Output
            }], animationChange: [{
                type: Output
            }], cssClassChange: [{
                type: Output
            }], dataSourceChange: [{
                type: Output
            }], disabledChange: [{
                type: Output
            }], disabledExprChange: [{
                type: Output
            }], displayExprChange: [{
                type: Output
            }], elementAttrChange: [{
                type: Output
            }], focusStateEnabledChange: [{
                type: Output
            }], heightChange: [{
                type: Output
            }], hideOnOutsideClickChange: [{
                type: Output
            }], hintChange: [{
                type: Output
            }], hoverStateEnabledChange: [{
                type: Output
            }], itemsChange: [{
                type: Output
            }], itemsExprChange: [{
                type: Output
            }], itemTemplateChange: [{
                type: Output
            }], positionChange: [{
                type: Output
            }], rtlEnabledChange: [{
                type: Output
            }], selectByClickChange: [{
                type: Output
            }], selectedExprChange: [{
                type: Output
            }], selectedItemChange: [{
                type: Output
            }], selectionModeChange: [{
                type: Output
            }], showEventChange: [{
                type: Output
            }], showSubmenuModeChange: [{
                type: Output
            }], submenuDirectionChange: [{
                type: Output
            }], tabIndexChange: [{
                type: Output
            }], targetChange: [{
                type: Output
            }], visibleChange: [{
                type: Output
            }], widthChange: [{
                type: Output
            }] } });
class DxContextMenuModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxContextMenuModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxContextMenuModule, imports: [DxContextMenuComponent, DxoAnimationModule,
            DxoHideModule,
            DxoFromModule,
            DxoPositionModule,
            DxoAtModule,
            DxoBoundaryOffsetModule,
            DxoCollisionModule,
            DxoMyModule,
            DxoOffsetModule,
            DxoToModule,
            DxoShowModule,
            DxiItemModule,
            DxoShowEventModule,
            DxoShowSubmenuModeModule,
            DxoDelayModule,
            DxoContextMenuAnimationModule,
            DxoContextMenuAtModule,
            DxoContextMenuBoundaryOffsetModule,
            DxoContextMenuCollisionModule,
            DxoContextMenuDelayModule,
            DxoContextMenuFromModule,
            DxoContextMenuHideModule,
            DxiContextMenuItemModule,
            DxoContextMenuMyModule,
            DxoContextMenuOffsetModule,
            DxoContextMenuPositionModule,
            DxoContextMenuShowModule,
            DxoContextMenuShowEventModule,
            DxoContextMenuShowSubmenuModeModule,
            DxoContextMenuToModule,
            DxIntegrationModule,
            DxTemplateModule], exports: [DxContextMenuComponent, DxoAnimationModule,
            DxoHideModule,
            DxoFromModule,
            DxoPositionModule,
            DxoAtModule,
            DxoBoundaryOffsetModule,
            DxoCollisionModule,
            DxoMyModule,
            DxoOffsetModule,
            DxoToModule,
            DxoShowModule,
            DxiItemModule,
            DxoShowEventModule,
            DxoShowSubmenuModeModule,
            DxoDelayModule,
            DxoContextMenuAnimationModule,
            DxoContextMenuAtModule,
            DxoContextMenuBoundaryOffsetModule,
            DxoContextMenuCollisionModule,
            DxoContextMenuDelayModule,
            DxoContextMenuFromModule,
            DxoContextMenuHideModule,
            DxiContextMenuItemModule,
            DxoContextMenuMyModule,
            DxoContextMenuOffsetModule,
            DxoContextMenuPositionModule,
            DxoContextMenuShowModule,
            DxoContextMenuShowEventModule,
            DxoContextMenuShowSubmenuModeModule,
            DxoContextMenuToModule,
            DxTemplateModule] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxContextMenuModule, imports: [DxContextMenuComponent,
            DxoAnimationModule,
            DxoHideModule,
            DxoFromModule,
            DxoPositionModule,
            DxoAtModule,
            DxoBoundaryOffsetModule,
            DxoCollisionModule,
            DxoMyModule,
            DxoOffsetModule,
            DxoToModule,
            DxoShowModule,
            DxiItemModule,
            DxoShowEventModule,
            DxoShowSubmenuModeModule,
            DxoDelayModule,
            DxoContextMenuAnimationModule,
            DxoContextMenuAtModule,
            DxoContextMenuBoundaryOffsetModule,
            DxoContextMenuCollisionModule,
            DxoContextMenuDelayModule,
            DxoContextMenuFromModule,
            DxoContextMenuHideModule,
            DxiContextMenuItemModule,
            DxoContextMenuMyModule,
            DxoContextMenuOffsetModule,
            DxoContextMenuPositionModule,
            DxoContextMenuShowModule,
            DxoContextMenuShowEventModule,
            DxoContextMenuShowSubmenuModeModule,
            DxoContextMenuToModule,
            DxIntegrationModule,
            DxTemplateModule, DxoAnimationModule,
            DxoHideModule,
            DxoFromModule,
            DxoPositionModule,
            DxoAtModule,
            DxoBoundaryOffsetModule,
            DxoCollisionModule,
            DxoMyModule,
            DxoOffsetModule,
            DxoToModule,
            DxoShowModule,
            DxiItemModule,
            DxoShowEventModule,
            DxoShowSubmenuModeModule,
            DxoDelayModule,
            DxoContextMenuAnimationModule,
            DxoContextMenuAtModule,
            DxoContextMenuBoundaryOffsetModule,
            DxoContextMenuCollisionModule,
            DxoContextMenuDelayModule,
            DxoContextMenuFromModule,
            DxoContextMenuHideModule,
            DxiContextMenuItemModule,
            DxoContextMenuMyModule,
            DxoContextMenuOffsetModule,
            DxoContextMenuPositionModule,
            DxoContextMenuShowModule,
            DxoContextMenuShowEventModule,
            DxoContextMenuShowSubmenuModeModule,
            DxoContextMenuToModule,
            DxTemplateModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxContextMenuModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxContextMenuComponent,
                        DxoAnimationModule,
                        DxoHideModule,
                        DxoFromModule,
                        DxoPositionModule,
                        DxoAtModule,
                        DxoBoundaryOffsetModule,
                        DxoCollisionModule,
                        DxoMyModule,
                        DxoOffsetModule,
                        DxoToModule,
                        DxoShowModule,
                        DxiItemModule,
                        DxoShowEventModule,
                        DxoShowSubmenuModeModule,
                        DxoDelayModule,
                        DxoContextMenuAnimationModule,
                        DxoContextMenuAtModule,
                        DxoContextMenuBoundaryOffsetModule,
                        DxoContextMenuCollisionModule,
                        DxoContextMenuDelayModule,
                        DxoContextMenuFromModule,
                        DxoContextMenuHideModule,
                        DxiContextMenuItemModule,
                        DxoContextMenuMyModule,
                        DxoContextMenuOffsetModule,
                        DxoContextMenuPositionModule,
                        DxoContextMenuShowModule,
                        DxoContextMenuShowEventModule,
                        DxoContextMenuShowSubmenuModeModule,
                        DxoContextMenuToModule,
                        DxIntegrationModule,
                        DxTemplateModule
                    ],
                    exports: [
                        DxContextMenuComponent,
                        DxoAnimationModule,
                        DxoHideModule,
                        DxoFromModule,
                        DxoPositionModule,
                        DxoAtModule,
                        DxoBoundaryOffsetModule,
                        DxoCollisionModule,
                        DxoMyModule,
                        DxoOffsetModule,
                        DxoToModule,
                        DxoShowModule,
                        DxiItemModule,
                        DxoShowEventModule,
                        DxoShowSubmenuModeModule,
                        DxoDelayModule,
                        DxoContextMenuAnimationModule,
                        DxoContextMenuAtModule,
                        DxoContextMenuBoundaryOffsetModule,
                        DxoContextMenuCollisionModule,
                        DxoContextMenuDelayModule,
                        DxoContextMenuFromModule,
                        DxoContextMenuHideModule,
                        DxiContextMenuItemModule,
                        DxoContextMenuMyModule,
                        DxoContextMenuOffsetModule,
                        DxoContextMenuPositionModule,
                        DxoContextMenuShowModule,
                        DxoContextMenuShowEventModule,
                        DxoContextMenuShowSubmenuModeModule,
                        DxoContextMenuToModule,
                        DxTemplateModule
                    ]
                }]
        }] });

/**
 * Generated bundle index. Do not edit.
 */

export { DxContextMenuComponent, DxContextMenuModule };
//# sourceMappingURL=devextreme-angular-ui-context-menu.mjs.map
