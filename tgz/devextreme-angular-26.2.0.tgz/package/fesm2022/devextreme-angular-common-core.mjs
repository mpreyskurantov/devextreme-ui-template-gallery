import { TransitionExecutor, animationPresets, cancelAnimationFrame, fx, requestAnimationFrame } from 'devextreme/common/core/animation';
import { getTimeZones, hideTopOverlay, initMobileViewport } from 'devextreme/common/core/environment';
import { off, on, one, trigger } from 'devextreme/common/core/events';
import { formatDate, formatMessage, formatNumber, loadMessages, locale, parseDate, parseNumber } from 'devextreme/common/core/localization';

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

var index$3 = /*#__PURE__*/Object.freeze({
	__proto__: null,
	TransitionExecutor: TransitionExecutor,
	animationPresets: animationPresets,
	cancelAnimationFrame: cancelAnimationFrame,
	fx: fx,
	requestAnimationFrame: requestAnimationFrame
});

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

var index$2 = /*#__PURE__*/Object.freeze({
	__proto__: null,
	getTimeZones: getTimeZones,
	hideTopOverlay: hideTopOverlay,
	initMobileViewport: initMobileViewport
});

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

var index$1 = /*#__PURE__*/Object.freeze({
	__proto__: null,
	off: off,
	on: on,
	one: one,
	trigger: trigger
});

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

var index = /*#__PURE__*/Object.freeze({
	__proto__: null,
	formatDate: formatDate,
	formatMessage: formatMessage,
	formatNumber: formatNumber,
	loadMessages: loadMessages,
	locale: locale,
	parseDate: parseDate,
	parseNumber: parseNumber
});

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

/**
 * Generated bundle index. Do not edit.
 */

export { index$3 as Animation, index$2 as Environment, index$1 as Events, index as Localization };
//# sourceMappingURL=devextreme-angular-common-core.mjs.map
