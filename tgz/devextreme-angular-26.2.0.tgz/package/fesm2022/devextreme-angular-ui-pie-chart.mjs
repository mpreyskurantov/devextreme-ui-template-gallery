import * as i0 from '@angular/core';
import { PLATFORM_ID, Output, Input, ContentChildren, Inject, Component, NgModule } from '@angular/core';
import DxPieChart from 'devextreme/viz/pie_chart';
import * as i1 from 'devextreme-angular/core';
import { DxComponent, DxIntegrationModule, DxTemplateHost, WatcherHelper, NestedOptionHost, IterableDifferHelper, DxTemplateModule } from 'devextreme-angular/core';
import { DxoAdaptiveLayoutModule, DxoAnimationModule, DxiAnnotationModule, DxoBorderModule, DxoFontModule, DxoImageModule, DxoShadowModule, DxoCommonAnnotationSettingsModule, DxoCommonSeriesSettingsModule, DxoColorModule, DxoHoverStyleModule, DxoHatchingModule, DxoLabelModule, DxoArgumentFormatModule, DxoConnectorModule, DxoFormatModule, DxoSelectionStyleModule, DxoSmallValuesGroupingModule, DxoExportModule, DxoLegendModule, DxoMarginModule, DxoTitleModule, DxoSubtitleModule, DxoLoadingIndicatorModule, DxiSeriesModule, DxoSeriesTemplateModule, DxoSizeModule, DxoTooltipModule } from 'devextreme-angular/ui/nested';
import { DxoPieChartAdaptiveLayoutModule, DxoPieChartAnimationModule, DxiPieChartAnnotationModule, DxoPieChartAnnotationBorderModule, DxoPieChartArgumentFormatModule, DxoPieChartBorderModule, DxoPieChartColorModule, DxoPieChartCommonAnnotationSettingsModule, DxoPieChartCommonSeriesSettingsModule, DxoPieChartConnectorModule, DxoPieChartExportModule, DxoPieChartFontModule, DxoPieChartFormatModule, DxoPieChartHatchingModule, DxoPieChartHoverStyleModule, DxoPieChartImageModule, DxoPieChartLabelModule, DxoPieChartLegendModule, DxoPieChartLegendTitleModule, DxoPieChartLegendTitleSubtitleModule, DxoPieChartLoadingIndicatorModule, DxoPieChartMarginModule, DxoPieChartPieChartTitleModule, DxoPieChartPieChartTitleSubtitleModule, DxoPieChartSelectionStyleModule, DxiPieChartSeriesModule, DxoPieChartSeriesBorderModule, DxoPieChartSeriesTemplateModule, DxoPieChartShadowModule, DxoPieChartSizeModule, DxoPieChartSmallValuesGroupingModule, DxoPieChartSubtitleModule, DxoPieChartTitleModule, DxoPieChartTooltipModule, DxoPieChartTooltipBorderModule } from 'devextreme-angular/ui/pie-chart/nested';
export * from 'devextreme-angular/ui/pie-chart/nested';
import { PROPERTY_TOKEN_annotations, PROPERTY_TOKEN_series } from 'devextreme-angular/core/tokens';

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
/**
 * [descr:dxPieChart]

 */
class DxPieChartComponent extends DxComponent {
    set _annotationsContentChildren(value) {
        this.setChildren('annotations', value);
    }
    set _seriesContentChildren(value) {
        this.setChildren('series', value);
    }
    /**
     * [descr:dxPieChartOptions.adaptiveLayout]
    
     */
    get adaptiveLayout() {
        return this._getOption('adaptiveLayout');
    }
    set adaptiveLayout(value) {
        this._setOption('adaptiveLayout', value);
    }
    /**
     * [descr:BaseChartOptions.animation]
    
     */
    get animation() {
        return this._getOption('animation');
    }
    set animation(value) {
        this._setOption('animation', value);
    }
    /**
     * [descr:dxPieChartOptions.annotations]
    
     */
    get annotations() {
        return this._getOption('annotations');
    }
    set annotations(value) {
        this._setOption('annotations', value);
    }
    /**
     * [descr:dxPieChartOptions.centerTemplate]
    
     */
    get centerTemplate() {
        return this._getOption('centerTemplate');
    }
    set centerTemplate(value) {
        this._setOption('centerTemplate', value);
    }
    /**
     * [descr:dxPieChartOptions.commonAnnotationSettings]
    
     */
    get commonAnnotationSettings() {
        return this._getOption('commonAnnotationSettings');
    }
    set commonAnnotationSettings(value) {
        this._setOption('commonAnnotationSettings', value);
    }
    /**
     * [descr:dxPieChartOptions.commonSeriesSettings]
    
     */
    get commonSeriesSettings() {
        return this._getOption('commonSeriesSettings');
    }
    set commonSeriesSettings(value) {
        this._setOption('commonSeriesSettings', value);
    }
    /**
     * [descr:dxPieChartOptions.customizeAnnotation]
    
     */
    get customizeAnnotation() {
        return this._getOption('customizeAnnotation');
    }
    set customizeAnnotation(value) {
        this._setOption('customizeAnnotation', value);
    }
    /**
     * [descr:BaseChartOptions.customizeLabel]
    
     */
    get customizeLabel() {
        return this._getOption('customizeLabel');
    }
    set customizeLabel(value) {
        this._setOption('customizeLabel', value);
    }
    /**
     * [descr:BaseChartOptions.customizePoint]
    
     */
    get customizePoint() {
        return this._getOption('customizePoint');
    }
    set customizePoint(value) {
        this._setOption('customizePoint', value);
    }
    /**
     * [descr:BaseChartOptions.dataSource]
    
     */
    get dataSource() {
        return this._getOption('dataSource');
    }
    set dataSource(value) {
        this._setOption('dataSource', value);
    }
    /**
     * [descr:dxPieChartOptions.diameter]
    
     */
    get diameter() {
        return this._getOption('diameter');
    }
    set diameter(value) {
        this._setOption('diameter', value);
    }
    /**
     * [descr:BaseWidgetOptions.disabled]
    
     */
    get disabled() {
        return this._getOption('disabled');
    }
    set disabled(value) {
        this._setOption('disabled', value);
    }
    /**
     * [descr:DOMComponentOptions.elementAttr]
    
     */
    get elementAttr() {
        return this._getOption('elementAttr');
    }
    set elementAttr(value) {
        this._setOption('elementAttr', value);
    }
    /**
     * [descr:BaseWidgetOptions.encodeHtml]
    
     */
    get encodeHtml() {
        return this._getOption('encodeHtml');
    }
    set encodeHtml(value) {
        this._setOption('encodeHtml', value);
    }
    /**
     * [descr:BaseWidgetOptions.export]
    
     */
    get export() {
        return this._getOption('export');
    }
    set export(value) {
        this._setOption('export', value);
    }
    /**
     * [descr:dxPieChartOptions.innerRadius]
    
     */
    get innerRadius() {
        return this._getOption('innerRadius');
    }
    set innerRadius(value) {
        this._setOption('innerRadius', value);
    }
    /**
     * [descr:dxPieChartOptions.legend]
    
     */
    get legend() {
        return this._getOption('legend');
    }
    set legend(value) {
        this._setOption('legend', value);
    }
    /**
     * [descr:BaseWidgetOptions.loadingIndicator]
    
     */
    get loadingIndicator() {
        return this._getOption('loadingIndicator');
    }
    set loadingIndicator(value) {
        this._setOption('loadingIndicator', value);
    }
    /**
     * [descr:BaseWidgetOptions.margin]
    
     */
    get margin() {
        return this._getOption('margin');
    }
    set margin(value) {
        this._setOption('margin', value);
    }
    /**
     * [descr:dxPieChartOptions.minDiameter]
    
     */
    get minDiameter() {
        return this._getOption('minDiameter');
    }
    set minDiameter(value) {
        this._setOption('minDiameter', value);
    }
    /**
     * [descr:dxPieChartOptions.palette]
    
     */
    get palette() {
        return this._getOption('palette');
    }
    set palette(value) {
        this._setOption('palette', value);
    }
    /**
     * [descr:BaseChartOptions.paletteExtensionMode]
    
     */
    get paletteExtensionMode() {
        return this._getOption('paletteExtensionMode');
    }
    set paletteExtensionMode(value) {
        this._setOption('paletteExtensionMode', value);
    }
    /**
     * [descr:BaseWidgetOptions.pathModified]
    
     */
    get pathModified() {
        return this._getOption('pathModified');
    }
    set pathModified(value) {
        this._setOption('pathModified', value);
    }
    /**
     * [descr:BaseChartOptions.pointSelectionMode]
    
     */
    get pointSelectionMode() {
        return this._getOption('pointSelectionMode');
    }
    set pointSelectionMode(value) {
        this._setOption('pointSelectionMode', value);
    }
    /**
     * [descr:BaseWidgetOptions.redrawOnResize]
    
     */
    get redrawOnResize() {
        return this._getOption('redrawOnResize');
    }
    set redrawOnResize(value) {
        this._setOption('redrawOnResize', value);
    }
    /**
     * [descr:dxPieChartOptions.resolveLabelOverlapping]
    
     */
    get resolveLabelOverlapping() {
        return this._getOption('resolveLabelOverlapping');
    }
    set resolveLabelOverlapping(value) {
        this._setOption('resolveLabelOverlapping', value);
    }
    /**
     * [descr:BaseWidgetOptions.rtlEnabled]
    
     */
    get rtlEnabled() {
        return this._getOption('rtlEnabled');
    }
    set rtlEnabled(value) {
        this._setOption('rtlEnabled', value);
    }
    /**
     * [descr:dxPieChartOptions.segmentsDirection]
    
     */
    get segmentsDirection() {
        return this._getOption('segmentsDirection');
    }
    set segmentsDirection(value) {
        this._setOption('segmentsDirection', value);
    }
    /**
     * [descr:dxPieChartOptions.series]
    
     */
    get series() {
        return this._getOption('series');
    }
    set series(value) {
        this._setOption('series', value);
    }
    /**
     * [descr:dxPieChartOptions.seriesTemplate]
    
     */
    get seriesTemplate() {
        return this._getOption('seriesTemplate');
    }
    set seriesTemplate(value) {
        this._setOption('seriesTemplate', value);
    }
    /**
     * [descr:BaseWidgetOptions.size]
    
     */
    get size() {
        return this._getOption('size');
    }
    set size(value) {
        this._setOption('size', value);
    }
    /**
     * [descr:dxPieChartOptions.sizeGroup]
    
     */
    get sizeGroup() {
        return this._getOption('sizeGroup');
    }
    set sizeGroup(value) {
        this._setOption('sizeGroup', value);
    }
    /**
     * [descr:dxPieChartOptions.startAngle]
    
     */
    get startAngle() {
        return this._getOption('startAngle');
    }
    set startAngle(value) {
        this._setOption('startAngle', value);
    }
    /**
     * [descr:BaseWidgetOptions.theme]
    
     */
    get theme() {
        return this._getOption('theme');
    }
    set theme(value) {
        this._setOption('theme', value);
    }
    /**
     * [descr:BaseWidgetOptions.title]
    
     */
    get title() {
        return this._getOption('title');
    }
    set title(value) {
        this._setOption('title', value);
    }
    /**
     * [descr:dxPieChartOptions.tooltip]
    
     */
    get tooltip() {
        return this._getOption('tooltip');
    }
    set tooltip(value) {
        this._setOption('tooltip', value);
    }
    /**
     * [descr:dxPieChartOptions.type]
    
     */
    get type() {
        return this._getOption('type');
    }
    set type(value) {
        this._setOption('type', value);
    }
    constructor(elementRef, ngZone, templateHost, _watcherHelper, _idh, optionHost, transferState, platformId) {
        super(elementRef, ngZone, templateHost, _watcherHelper, transferState, platformId);
        this._watcherHelper = _watcherHelper;
        this._idh = _idh;
        this.instance = null;
        this._createEventEmitters([
            { subscribe: 'disposing', emit: 'onDisposing' },
            { subscribe: 'done', emit: 'onDone' },
            { subscribe: 'drawn', emit: 'onDrawn' },
            { subscribe: 'exported', emit: 'onExported' },
            { subscribe: 'exporting', emit: 'onExporting' },
            { subscribe: 'fileSaving', emit: 'onFileSaving' },
            { subscribe: 'incidentOccurred', emit: 'onIncidentOccurred' },
            { subscribe: 'initialized', emit: 'onInitialized' },
            { subscribe: 'legendClick', emit: 'onLegendClick' },
            { subscribe: 'optionChanged', emit: 'onOptionChanged' },
            { subscribe: 'pointClick', emit: 'onPointClick' },
            { subscribe: 'pointHoverChanged', emit: 'onPointHoverChanged' },
            { subscribe: 'pointSelectionChanged', emit: 'onPointSelectionChanged' },
            { subscribe: 'tooltipHidden', emit: 'onTooltipHidden' },
            { subscribe: 'tooltipShown', emit: 'onTooltipShown' },
            { emit: 'adaptiveLayoutChange' },
            { emit: 'animationChange' },
            { emit: 'annotationsChange' },
            { emit: 'centerTemplateChange' },
            { emit: 'commonAnnotationSettingsChange' },
            { emit: 'commonSeriesSettingsChange' },
            { emit: 'customizeAnnotationChange' },
            { emit: 'customizeLabelChange' },
            { emit: 'customizePointChange' },
            { emit: 'dataSourceChange' },
            { emit: 'diameterChange' },
            { emit: 'disabledChange' },
            { emit: 'elementAttrChange' },
            { emit: 'encodeHtmlChange' },
            { emit: 'exportChange' },
            { emit: 'innerRadiusChange' },
            { emit: 'legendChange' },
            { emit: 'loadingIndicatorChange' },
            { emit: 'marginChange' },
            { emit: 'minDiameterChange' },
            { emit: 'paletteChange' },
            { emit: 'paletteExtensionModeChange' },
            { emit: 'pathModifiedChange' },
            { emit: 'pointSelectionModeChange' },
            { emit: 'redrawOnResizeChange' },
            { emit: 'resolveLabelOverlappingChange' },
            { emit: 'rtlEnabledChange' },
            { emit: 'segmentsDirectionChange' },
            { emit: 'seriesChange' },
            { emit: 'seriesTemplateChange' },
            { emit: 'sizeChange' },
            { emit: 'sizeGroupChange' },
            { emit: 'startAngleChange' },
            { emit: 'themeChange' },
            { emit: 'titleChange' },
            { emit: 'tooltipChange' },
            { emit: 'typeChange' }
        ]);
        this._idh.setHost(this);
        optionHost.setHost(this);
    }
    _createInstance(element, options) {
        return new DxPieChart(element, options);
    }
    ngOnDestroy() {
        this._destroyWidget();
    }
    ngOnChanges(changes) {
        super.ngOnChanges(changes);
        this.setupChanges('annotations', changes);
        this.setupChanges('dataSource', changes);
        this.setupChanges('palette', changes);
        this.setupChanges('series', changes);
    }
    setupChanges(prop, changes) {
        if (!(prop in this._optionsToUpdate)) {
            this._idh.setup(prop, changes);
        }
    }
    ngDoCheck() {
        this._idh.doCheck('annotations');
        this._idh.doCheck('dataSource');
        this._idh.doCheck('palette');
        this._idh.doCheck('series');
        this._watcherHelper.checkWatchers();
        super.ngDoCheck();
        super.clearChangedOptions();
    }
    _setOption(name, value) {
        let isSetup = this._idh.setupSingle(name, value);
        let isChanged = this._idh.getChanges(name, value) !== null;
        if (isSetup || isChanged) {
            super._setOption(name, value);
        }
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxPieChartComponent, deps: [{ token: i0.ElementRef }, { token: i0.NgZone }, { token: i1.DxTemplateHost }, { token: i1.WatcherHelper }, { token: i1.IterableDifferHelper }, { token: i1.NestedOptionHost }, { token: i0.TransferState }, { token: PLATFORM_ID }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxPieChartComponent, isStandalone: true, selector: "dx-pie-chart", inputs: { adaptiveLayout: "adaptiveLayout", animation: "animation", annotations: "annotations", centerTemplate: "centerTemplate", commonAnnotationSettings: "commonAnnotationSettings", commonSeriesSettings: "commonSeriesSettings", customizeAnnotation: "customizeAnnotation", customizeLabel: "customizeLabel", customizePoint: "customizePoint", dataSource: "dataSource", diameter: "diameter", disabled: "disabled", elementAttr: "elementAttr", encodeHtml: "encodeHtml", export: "export", innerRadius: "innerRadius", legend: "legend", loadingIndicator: "loadingIndicator", margin: "margin", minDiameter: "minDiameter", palette: "palette", paletteExtensionMode: "paletteExtensionMode", pathModified: "pathModified", pointSelectionMode: "pointSelectionMode", redrawOnResize: "redrawOnResize", resolveLabelOverlapping: "resolveLabelOverlapping", rtlEnabled: "rtlEnabled", segmentsDirection: "segmentsDirection", series: "series", seriesTemplate: "seriesTemplate", size: "size", sizeGroup: "sizeGroup", startAngle: "startAngle", theme: "theme", title: "title", tooltip: "tooltip", type: "type" }, outputs: { onDisposing: "onDisposing", onDone: "onDone", onDrawn: "onDrawn", onExported: "onExported", onExporting: "onExporting", onFileSaving: "onFileSaving", onIncidentOccurred: "onIncidentOccurred", onInitialized: "onInitialized", onLegendClick: "onLegendClick", onOptionChanged: "onOptionChanged", onPointClick: "onPointClick", onPointHoverChanged: "onPointHoverChanged", onPointSelectionChanged: "onPointSelectionChanged", onTooltipHidden: "onTooltipHidden", onTooltipShown: "onTooltipShown", adaptiveLayoutChange: "adaptiveLayoutChange", animationChange: "animationChange", annotationsChange: "annotationsChange", centerTemplateChange: "centerTemplateChange", commonAnnotationSettingsChange: "commonAnnotationSettingsChange", commonSeriesSettingsChange: "commonSeriesSettingsChange", customizeAnnotationChange: "customizeAnnotationChange", customizeLabelChange: "customizeLabelChange", customizePointChange: "customizePointChange", dataSourceChange: "dataSourceChange", diameterChange: "diameterChange", disabledChange: "disabledChange", elementAttrChange: "elementAttrChange", encodeHtmlChange: "encodeHtmlChange", exportChange: "exportChange", innerRadiusChange: "innerRadiusChange", legendChange: "legendChange", loadingIndicatorChange: "loadingIndicatorChange", marginChange: "marginChange", minDiameterChange: "minDiameterChange", paletteChange: "paletteChange", paletteExtensionModeChange: "paletteExtensionModeChange", pathModifiedChange: "pathModifiedChange", pointSelectionModeChange: "pointSelectionModeChange", redrawOnResizeChange: "redrawOnResizeChange", resolveLabelOverlappingChange: "resolveLabelOverlappingChange", rtlEnabledChange: "rtlEnabledChange", segmentsDirectionChange: "segmentsDirectionChange", seriesChange: "seriesChange", seriesTemplateChange: "seriesTemplateChange", sizeChange: "sizeChange", sizeGroupChange: "sizeGroupChange", startAngleChange: "startAngleChange", themeChange: "themeChange", titleChange: "titleChange", tooltipChange: "tooltipChange", typeChange: "typeChange" }, host: { attributes: { "ngSkipHydration": "true" } }, providers: [
            DxTemplateHost,
            WatcherHelper,
            NestedOptionHost,
            IterableDifferHelper
        ], queries: [{ propertyName: "_annotationsContentChildren", predicate: PROPERTY_TOKEN_annotations }, { propertyName: "_seriesContentChildren", predicate: PROPERTY_TOKEN_series }], usesInheritance: true, usesOnChanges: true, ngImport: i0, template: '', isInline: true, styles: [":host{display:block}\n"], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxPieChartComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dx-pie-chart', template: '', host: { ngSkipHydration: 'true' }, imports: [DxIntegrationModule], providers: [
                        DxTemplateHost,
                        WatcherHelper,
                        NestedOptionHost,
                        IterableDifferHelper
                    ], styles: [":host{display:block}\n"] }]
        }], ctorParameters: () => [{ type: i0.ElementRef }, { type: i0.NgZone }, { type: i1.DxTemplateHost }, { type: i1.WatcherHelper }, { type: i1.IterableDifferHelper }, { type: i1.NestedOptionHost }, { type: i0.TransferState }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [PLATFORM_ID]
                }] }], propDecorators: { _annotationsContentChildren: [{
                type: ContentChildren,
                args: [PROPERTY_TOKEN_annotations]
            }], _seriesContentChildren: [{
                type: ContentChildren,
                args: [PROPERTY_TOKEN_series]
            }], adaptiveLayout: [{
                type: Input
            }], animation: [{
                type: Input
            }], annotations: [{
                type: Input
            }], centerTemplate: [{
                type: Input
            }], commonAnnotationSettings: [{
                type: Input
            }], commonSeriesSettings: [{
                type: Input
            }], customizeAnnotation: [{
                type: Input
            }], customizeLabel: [{
                type: Input
            }], customizePoint: [{
                type: Input
            }], dataSource: [{
                type: Input
            }], diameter: [{
                type: Input
            }], disabled: [{
                type: Input
            }], elementAttr: [{
                type: Input
            }], encodeHtml: [{
                type: Input
            }], export: [{
                type: Input
            }], innerRadius: [{
                type: Input
            }], legend: [{
                type: Input
            }], loadingIndicator: [{
                type: Input
            }], margin: [{
                type: Input
            }], minDiameter: [{
                type: Input
            }], palette: [{
                type: Input
            }], paletteExtensionMode: [{
                type: Input
            }], pathModified: [{
                type: Input
            }], pointSelectionMode: [{
                type: Input
            }], redrawOnResize: [{
                type: Input
            }], resolveLabelOverlapping: [{
                type: Input
            }], rtlEnabled: [{
                type: Input
            }], segmentsDirection: [{
                type: Input
            }], series: [{
                type: Input
            }], seriesTemplate: [{
                type: Input
            }], size: [{
                type: Input
            }], sizeGroup: [{
                type: Input
            }], startAngle: [{
                type: Input
            }], theme: [{
                type: Input
            }], title: [{
                type: Input
            }], tooltip: [{
                type: Input
            }], type: [{
                type: Input
            }], onDisposing: [{
                type: Output
            }], onDone: [{
                type: Output
            }], onDrawn: [{
                type: Output
            }], onExported: [{
                type: Output
            }], onExporting: [{
                type: Output
            }], onFileSaving: [{
                type: Output
            }], onIncidentOccurred: [{
                type: Output
            }], onInitialized: [{
                type: Output
            }], onLegendClick: [{
                type: Output
            }], onOptionChanged: [{
                type: Output
            }], onPointClick: [{
                type: Output
            }], onPointHoverChanged: [{
                type: Output
            }], onPointSelectionChanged: [{
                type: Output
            }], onTooltipHidden: [{
                type: Output
            }], onTooltipShown: [{
                type: Output
            }], adaptiveLayoutChange: [{
                type: Output
            }], animationChange: [{
                type: Output
            }], annotationsChange: [{
                type: Output
            }], centerTemplateChange: [{
                type: Output
            }], commonAnnotationSettingsChange: [{
                type: Output
            }], commonSeriesSettingsChange: [{
                type: Output
            }], customizeAnnotationChange: [{
                type: Output
            }], customizeLabelChange: [{
                type: Output
            }], customizePointChange: [{
                type: Output
            }], dataSourceChange: [{
                type: Output
            }], diameterChange: [{
                type: Output
            }], disabledChange: [{
                type: Output
            }], elementAttrChange: [{
                type: Output
            }], encodeHtmlChange: [{
                type: Output
            }], exportChange: [{
                type: Output
            }], innerRadiusChange: [{
                type: Output
            }], legendChange: [{
                type: Output
            }], loadingIndicatorChange: [{
                type: Output
            }], marginChange: [{
                type: Output
            }], minDiameterChange: [{
                type: Output
            }], paletteChange: [{
                type: Output
            }], paletteExtensionModeChange: [{
                type: Output
            }], pathModifiedChange: [{
                type: Output
            }], pointSelectionModeChange: [{
                type: Output
            }], redrawOnResizeChange: [{
                type: Output
            }], resolveLabelOverlappingChange: [{
                type: Output
            }], rtlEnabledChange: [{
                type: Output
            }], segmentsDirectionChange: [{
                type: Output
            }], seriesChange: [{
                type: Output
            }], seriesTemplateChange: [{
                type: Output
            }], sizeChange: [{
                type: Output
            }], sizeGroupChange: [{
                type: Output
            }], startAngleChange: [{
                type: Output
            }], themeChange: [{
                type: Output
            }], titleChange: [{
                type: Output
            }], tooltipChange: [{
                type: Output
            }], typeChange: [{
                type: Output
            }] } });
class DxPieChartModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxPieChartModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxPieChartModule, imports: [DxPieChartComponent, DxoAdaptiveLayoutModule,
            DxoAnimationModule,
            DxiAnnotationModule,
            DxoBorderModule,
            DxoFontModule,
            DxoImageModule,
            DxoShadowModule,
            DxoCommonAnnotationSettingsModule,
            DxoCommonSeriesSettingsModule,
            DxoColorModule,
            DxoHoverStyleModule,
            DxoHatchingModule,
            DxoLabelModule,
            DxoArgumentFormatModule,
            DxoConnectorModule,
            DxoFormatModule,
            DxoSelectionStyleModule,
            DxoSmallValuesGroupingModule,
            DxoExportModule,
            DxoLegendModule,
            DxoMarginModule,
            DxoTitleModule,
            DxoSubtitleModule,
            DxoLoadingIndicatorModule,
            DxiSeriesModule,
            DxoSeriesTemplateModule,
            DxoSizeModule,
            DxoTooltipModule,
            DxoPieChartAdaptiveLayoutModule,
            DxoPieChartAnimationModule,
            DxiPieChartAnnotationModule,
            DxoPieChartAnnotationBorderModule,
            DxoPieChartArgumentFormatModule,
            DxoPieChartBorderModule,
            DxoPieChartColorModule,
            DxoPieChartCommonAnnotationSettingsModule,
            DxoPieChartCommonSeriesSettingsModule,
            DxoPieChartConnectorModule,
            DxoPieChartExportModule,
            DxoPieChartFontModule,
            DxoPieChartFormatModule,
            DxoPieChartHatchingModule,
            DxoPieChartHoverStyleModule,
            DxoPieChartImageModule,
            DxoPieChartLabelModule,
            DxoPieChartLegendModule,
            DxoPieChartLegendTitleModule,
            DxoPieChartLegendTitleSubtitleModule,
            DxoPieChartLoadingIndicatorModule,
            DxoPieChartMarginModule,
            DxoPieChartPieChartTitleModule,
            DxoPieChartPieChartTitleSubtitleModule,
            DxoPieChartSelectionStyleModule,
            DxiPieChartSeriesModule,
            DxoPieChartSeriesBorderModule,
            DxoPieChartSeriesTemplateModule,
            DxoPieChartShadowModule,
            DxoPieChartSizeModule,
            DxoPieChartSmallValuesGroupingModule,
            DxoPieChartSubtitleModule,
            DxoPieChartTitleModule,
            DxoPieChartTooltipModule,
            DxoPieChartTooltipBorderModule,
            DxIntegrationModule,
            DxTemplateModule], exports: [DxPieChartComponent, DxoAdaptiveLayoutModule,
            DxoAnimationModule,
            DxiAnnotationModule,
            DxoBorderModule,
            DxoFontModule,
            DxoImageModule,
            DxoShadowModule,
            DxoCommonAnnotationSettingsModule,
            DxoCommonSeriesSettingsModule,
            DxoColorModule,
            DxoHoverStyleModule,
            DxoHatchingModule,
            DxoLabelModule,
            DxoArgumentFormatModule,
            DxoConnectorModule,
            DxoFormatModule,
            DxoSelectionStyleModule,
            DxoSmallValuesGroupingModule,
            DxoExportModule,
            DxoLegendModule,
            DxoMarginModule,
            DxoTitleModule,
            DxoSubtitleModule,
            DxoLoadingIndicatorModule,
            DxiSeriesModule,
            DxoSeriesTemplateModule,
            DxoSizeModule,
            DxoTooltipModule,
            DxoPieChartAdaptiveLayoutModule,
            DxoPieChartAnimationModule,
            DxiPieChartAnnotationModule,
            DxoPieChartAnnotationBorderModule,
            DxoPieChartArgumentFormatModule,
            DxoPieChartBorderModule,
            DxoPieChartColorModule,
            DxoPieChartCommonAnnotationSettingsModule,
            DxoPieChartCommonSeriesSettingsModule,
            DxoPieChartConnectorModule,
            DxoPieChartExportModule,
            DxoPieChartFontModule,
            DxoPieChartFormatModule,
            DxoPieChartHatchingModule,
            DxoPieChartHoverStyleModule,
            DxoPieChartImageModule,
            DxoPieChartLabelModule,
            DxoPieChartLegendModule,
            DxoPieChartLegendTitleModule,
            DxoPieChartLegendTitleSubtitleModule,
            DxoPieChartLoadingIndicatorModule,
            DxoPieChartMarginModule,
            DxoPieChartPieChartTitleModule,
            DxoPieChartPieChartTitleSubtitleModule,
            DxoPieChartSelectionStyleModule,
            DxiPieChartSeriesModule,
            DxoPieChartSeriesBorderModule,
            DxoPieChartSeriesTemplateModule,
            DxoPieChartShadowModule,
            DxoPieChartSizeModule,
            DxoPieChartSmallValuesGroupingModule,
            DxoPieChartSubtitleModule,
            DxoPieChartTitleModule,
            DxoPieChartTooltipModule,
            DxoPieChartTooltipBorderModule,
            DxTemplateModule] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxPieChartModule, imports: [DxPieChartComponent,
            DxoAdaptiveLayoutModule,
            DxoAnimationModule,
            DxiAnnotationModule,
            DxoBorderModule,
            DxoFontModule,
            DxoImageModule,
            DxoShadowModule,
            DxoCommonAnnotationSettingsModule,
            DxoCommonSeriesSettingsModule,
            DxoColorModule,
            DxoHoverStyleModule,
            DxoHatchingModule,
            DxoLabelModule,
            DxoArgumentFormatModule,
            DxoConnectorModule,
            DxoFormatModule,
            DxoSelectionStyleModule,
            DxoSmallValuesGroupingModule,
            DxoExportModule,
            DxoLegendModule,
            DxoMarginModule,
            DxoTitleModule,
            DxoSubtitleModule,
            DxoLoadingIndicatorModule,
            DxiSeriesModule,
            DxoSeriesTemplateModule,
            DxoSizeModule,
            DxoTooltipModule,
            DxoPieChartAdaptiveLayoutModule,
            DxoPieChartAnimationModule,
            DxiPieChartAnnotationModule,
            DxoPieChartAnnotationBorderModule,
            DxoPieChartArgumentFormatModule,
            DxoPieChartBorderModule,
            DxoPieChartColorModule,
            DxoPieChartCommonAnnotationSettingsModule,
            DxoPieChartCommonSeriesSettingsModule,
            DxoPieChartConnectorModule,
            DxoPieChartExportModule,
            DxoPieChartFontModule,
            DxoPieChartFormatModule,
            DxoPieChartHatchingModule,
            DxoPieChartHoverStyleModule,
            DxoPieChartImageModule,
            DxoPieChartLabelModule,
            DxoPieChartLegendModule,
            DxoPieChartLegendTitleModule,
            DxoPieChartLegendTitleSubtitleModule,
            DxoPieChartLoadingIndicatorModule,
            DxoPieChartMarginModule,
            DxoPieChartPieChartTitleModule,
            DxoPieChartPieChartTitleSubtitleModule,
            DxoPieChartSelectionStyleModule,
            DxiPieChartSeriesModule,
            DxoPieChartSeriesBorderModule,
            DxoPieChartSeriesTemplateModule,
            DxoPieChartShadowModule,
            DxoPieChartSizeModule,
            DxoPieChartSmallValuesGroupingModule,
            DxoPieChartSubtitleModule,
            DxoPieChartTitleModule,
            DxoPieChartTooltipModule,
            DxoPieChartTooltipBorderModule,
            DxIntegrationModule,
            DxTemplateModule, DxoAdaptiveLayoutModule,
            DxoAnimationModule,
            DxiAnnotationModule,
            DxoBorderModule,
            DxoFontModule,
            DxoImageModule,
            DxoShadowModule,
            DxoCommonAnnotationSettingsModule,
            DxoCommonSeriesSettingsModule,
            DxoColorModule,
            DxoHoverStyleModule,
            DxoHatchingModule,
            DxoLabelModule,
            DxoArgumentFormatModule,
            DxoConnectorModule,
            DxoFormatModule,
            DxoSelectionStyleModule,
            DxoSmallValuesGroupingModule,
            DxoExportModule,
            DxoLegendModule,
            DxoMarginModule,
            DxoTitleModule,
            DxoSubtitleModule,
            DxoLoadingIndicatorModule,
            DxiSeriesModule,
            DxoSeriesTemplateModule,
            DxoSizeModule,
            DxoTooltipModule,
            DxoPieChartAdaptiveLayoutModule,
            DxoPieChartAnimationModule,
            DxiPieChartAnnotationModule,
            DxoPieChartAnnotationBorderModule,
            DxoPieChartArgumentFormatModule,
            DxoPieChartBorderModule,
            DxoPieChartColorModule,
            DxoPieChartCommonAnnotationSettingsModule,
            DxoPieChartCommonSeriesSettingsModule,
            DxoPieChartConnectorModule,
            DxoPieChartExportModule,
            DxoPieChartFontModule,
            DxoPieChartFormatModule,
            DxoPieChartHatchingModule,
            DxoPieChartHoverStyleModule,
            DxoPieChartImageModule,
            DxoPieChartLabelModule,
            DxoPieChartLegendModule,
            DxoPieChartLegendTitleModule,
            DxoPieChartLegendTitleSubtitleModule,
            DxoPieChartLoadingIndicatorModule,
            DxoPieChartMarginModule,
            DxoPieChartPieChartTitleModule,
            DxoPieChartPieChartTitleSubtitleModule,
            DxoPieChartSelectionStyleModule,
            DxiPieChartSeriesModule,
            DxoPieChartSeriesBorderModule,
            DxoPieChartSeriesTemplateModule,
            DxoPieChartShadowModule,
            DxoPieChartSizeModule,
            DxoPieChartSmallValuesGroupingModule,
            DxoPieChartSubtitleModule,
            DxoPieChartTitleModule,
            DxoPieChartTooltipModule,
            DxoPieChartTooltipBorderModule,
            DxTemplateModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxPieChartModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxPieChartComponent,
                        DxoAdaptiveLayoutModule,
                        DxoAnimationModule,
                        DxiAnnotationModule,
                        DxoBorderModule,
                        DxoFontModule,
                        DxoImageModule,
                        DxoShadowModule,
                        DxoCommonAnnotationSettingsModule,
                        DxoCommonSeriesSettingsModule,
                        DxoColorModule,
                        DxoHoverStyleModule,
                        DxoHatchingModule,
                        DxoLabelModule,
                        DxoArgumentFormatModule,
                        DxoConnectorModule,
                        DxoFormatModule,
                        DxoSelectionStyleModule,
                        DxoSmallValuesGroupingModule,
                        DxoExportModule,
                        DxoLegendModule,
                        DxoMarginModule,
                        DxoTitleModule,
                        DxoSubtitleModule,
                        DxoLoadingIndicatorModule,
                        DxiSeriesModule,
                        DxoSeriesTemplateModule,
                        DxoSizeModule,
                        DxoTooltipModule,
                        DxoPieChartAdaptiveLayoutModule,
                        DxoPieChartAnimationModule,
                        DxiPieChartAnnotationModule,
                        DxoPieChartAnnotationBorderModule,
                        DxoPieChartArgumentFormatModule,
                        DxoPieChartBorderModule,
                        DxoPieChartColorModule,
                        DxoPieChartCommonAnnotationSettingsModule,
                        DxoPieChartCommonSeriesSettingsModule,
                        DxoPieChartConnectorModule,
                        DxoPieChartExportModule,
                        DxoPieChartFontModule,
                        DxoPieChartFormatModule,
                        DxoPieChartHatchingModule,
                        DxoPieChartHoverStyleModule,
                        DxoPieChartImageModule,
                        DxoPieChartLabelModule,
                        DxoPieChartLegendModule,
                        DxoPieChartLegendTitleModule,
                        DxoPieChartLegendTitleSubtitleModule,
                        DxoPieChartLoadingIndicatorModule,
                        DxoPieChartMarginModule,
                        DxoPieChartPieChartTitleModule,
                        DxoPieChartPieChartTitleSubtitleModule,
                        DxoPieChartSelectionStyleModule,
                        DxiPieChartSeriesModule,
                        DxoPieChartSeriesBorderModule,
                        DxoPieChartSeriesTemplateModule,
                        DxoPieChartShadowModule,
                        DxoPieChartSizeModule,
                        DxoPieChartSmallValuesGroupingModule,
                        DxoPieChartSubtitleModule,
                        DxoPieChartTitleModule,
                        DxoPieChartTooltipModule,
                        DxoPieChartTooltipBorderModule,
                        DxIntegrationModule,
                        DxTemplateModule
                    ],
                    exports: [
                        DxPieChartComponent,
                        DxoAdaptiveLayoutModule,
                        DxoAnimationModule,
                        DxiAnnotationModule,
                        DxoBorderModule,
                        DxoFontModule,
                        DxoImageModule,
                        DxoShadowModule,
                        DxoCommonAnnotationSettingsModule,
                        DxoCommonSeriesSettingsModule,
                        DxoColorModule,
                        DxoHoverStyleModule,
                        DxoHatchingModule,
                        DxoLabelModule,
                        DxoArgumentFormatModule,
                        DxoConnectorModule,
                        DxoFormatModule,
                        DxoSelectionStyleModule,
                        DxoSmallValuesGroupingModule,
                        DxoExportModule,
                        DxoLegendModule,
                        DxoMarginModule,
                        DxoTitleModule,
                        DxoSubtitleModule,
                        DxoLoadingIndicatorModule,
                        DxiSeriesModule,
                        DxoSeriesTemplateModule,
                        DxoSizeModule,
                        DxoTooltipModule,
                        DxoPieChartAdaptiveLayoutModule,
                        DxoPieChartAnimationModule,
                        DxiPieChartAnnotationModule,
                        DxoPieChartAnnotationBorderModule,
                        DxoPieChartArgumentFormatModule,
                        DxoPieChartBorderModule,
                        DxoPieChartColorModule,
                        DxoPieChartCommonAnnotationSettingsModule,
                        DxoPieChartCommonSeriesSettingsModule,
                        DxoPieChartConnectorModule,
                        DxoPieChartExportModule,
                        DxoPieChartFontModule,
                        DxoPieChartFormatModule,
                        DxoPieChartHatchingModule,
                        DxoPieChartHoverStyleModule,
                        DxoPieChartImageModule,
                        DxoPieChartLabelModule,
                        DxoPieChartLegendModule,
                        DxoPieChartLegendTitleModule,
                        DxoPieChartLegendTitleSubtitleModule,
                        DxoPieChartLoadingIndicatorModule,
                        DxoPieChartMarginModule,
                        DxoPieChartPieChartTitleModule,
                        DxoPieChartPieChartTitleSubtitleModule,
                        DxoPieChartSelectionStyleModule,
                        DxiPieChartSeriesModule,
                        DxoPieChartSeriesBorderModule,
                        DxoPieChartSeriesTemplateModule,
                        DxoPieChartShadowModule,
                        DxoPieChartSizeModule,
                        DxoPieChartSmallValuesGroupingModule,
                        DxoPieChartSubtitleModule,
                        DxoPieChartTitleModule,
                        DxoPieChartTooltipModule,
                        DxoPieChartTooltipBorderModule,
                        DxTemplateModule
                    ]
                }]
        }] });

/**
 * Generated bundle index. Do not edit.
 */

export { DxPieChartComponent, DxPieChartModule };
//# sourceMappingURL=devextreme-angular-ui-pie-chart.mjs.map
