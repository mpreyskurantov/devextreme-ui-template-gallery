import * as i0 from '@angular/core';
import { PLATFORM_ID, Output, Input, Inject, Component, NgModule } from '@angular/core';
import DxPivotGrid from 'devextreme/ui/pivot_grid';
import * as i1 from 'devextreme-angular/core';
import { DxComponent, DxIntegrationModule, DxTemplateHost, WatcherHelper, NestedOptionHost, IterableDifferHelper, DxTemplateModule } from 'devextreme-angular/core';
import { DxoExportModule, DxoFieldChooserModule, DxoTextsModule, DxoFieldPanelModule, DxoHeaderFilterModule, DxoSearchModule, DxoLoadPanelModule, DxoScrollingModule, DxoStateStoringModule } from 'devextreme-angular/ui/nested';
import { DxoPivotGridExportModule, DxoPivotGridFieldChooserModule, DxoPivotGridFieldChooserTextsModule, DxoPivotGridFieldPanelModule, DxoPivotGridFieldPanelTextsModule, DxoPivotGridHeaderFilterModule, DxoPivotGridHeaderFilterTextsModule, DxoPivotGridLoadPanelModule, DxoPivotGridPivotGridTextsModule, DxoPivotGridScrollingModule, DxoPivotGridSearchModule, DxoPivotGridStateStoringModule, DxoPivotGridTextsModule } from 'devextreme-angular/ui/pivot-grid/nested';
export * from 'devextreme-angular/ui/pivot-grid/nested';

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
/**
 * [descr:dxPivotGrid]

 */
class DxPivotGridComponent extends DxComponent {
    /**
     * [descr:dxPivotGridOptions.allowExpandAll]
    
     */
    get allowExpandAll() {
        return this._getOption('allowExpandAll');
    }
    set allowExpandAll(value) {
        this._setOption('allowExpandAll', value);
    }
    /**
     * [descr:dxPivotGridOptions.allowFiltering]
    
     */
    get allowFiltering() {
        return this._getOption('allowFiltering');
    }
    set allowFiltering(value) {
        this._setOption('allowFiltering', value);
    }
    /**
     * [descr:dxPivotGridOptions.allowSorting]
    
     */
    get allowSorting() {
        return this._getOption('allowSorting');
    }
    set allowSorting(value) {
        this._setOption('allowSorting', value);
    }
    /**
     * [descr:dxPivotGridOptions.allowSortingBySummary]
    
     */
    get allowSortingBySummary() {
        return this._getOption('allowSortingBySummary');
    }
    set allowSortingBySummary(value) {
        this._setOption('allowSortingBySummary', value);
    }
    /**
     * [descr:dxPivotGridOptions.dataFieldArea]
    
     */
    get dataFieldArea() {
        return this._getOption('dataFieldArea');
    }
    set dataFieldArea(value) {
        this._setOption('dataFieldArea', value);
    }
    /**
     * [descr:dxPivotGridOptions.dataSource]
    
     */
    get dataSource() {
        return this._getOption('dataSource');
    }
    set dataSource(value) {
        this._setOption('dataSource', value);
    }
    /**
     * [descr:WidgetOptions.disabled]
    
     */
    get disabled() {
        return this._getOption('disabled');
    }
    set disabled(value) {
        this._setOption('disabled', value);
    }
    /**
     * [descr:DOMComponentOptions.elementAttr]
    
     */
    get elementAttr() {
        return this._getOption('elementAttr');
    }
    set elementAttr(value) {
        this._setOption('elementAttr', value);
    }
    /**
     * [descr:dxPivotGridOptions.encodeHtml]
    
     */
    get encodeHtml() {
        return this._getOption('encodeHtml');
    }
    set encodeHtml(value) {
        this._setOption('encodeHtml', value);
    }
    /**
     * [descr:dxPivotGridOptions.export]
    
     */
    get export() {
        return this._getOption('export');
    }
    set export(value) {
        this._setOption('export', value);
    }
    /**
     * [descr:dxPivotGridOptions.fieldChooser]
    
     */
    get fieldChooser() {
        return this._getOption('fieldChooser');
    }
    set fieldChooser(value) {
        this._setOption('fieldChooser', value);
    }
    /**
     * [descr:dxPivotGridOptions.fieldPanel]
    
     */
    get fieldPanel() {
        return this._getOption('fieldPanel');
    }
    set fieldPanel(value) {
        this._setOption('fieldPanel', value);
    }
    /**
     * [descr:dxPivotGridOptions.headerFilter]
    
     */
    get headerFilter() {
        return this._getOption('headerFilter');
    }
    set headerFilter(value) {
        this._setOption('headerFilter', value);
    }
    /**
     * [descr:DOMComponentOptions.height]
    
     */
    get height() {
        return this._getOption('height');
    }
    set height(value) {
        this._setOption('height', value);
    }
    /**
     * [descr:dxPivotGridOptions.hideEmptySummaryCells]
    
     */
    get hideEmptySummaryCells() {
        return this._getOption('hideEmptySummaryCells');
    }
    set hideEmptySummaryCells(value) {
        this._setOption('hideEmptySummaryCells', value);
    }
    /**
     * [descr:WidgetOptions.hint]
    
     */
    get hint() {
        return this._getOption('hint');
    }
    set hint(value) {
        this._setOption('hint', value);
    }
    /**
     * [descr:dxPivotGridOptions.loadPanel]
    
     */
    get loadPanel() {
        return this._getOption('loadPanel');
    }
    set loadPanel(value) {
        this._setOption('loadPanel', value);
    }
    /**
     * [descr:dxPivotGridOptions.rowHeaderLayout]
    
     */
    get rowHeaderLayout() {
        return this._getOption('rowHeaderLayout');
    }
    set rowHeaderLayout(value) {
        this._setOption('rowHeaderLayout', value);
    }
    /**
     * [descr:DOMComponentOptions.rtlEnabled]
    
     */
    get rtlEnabled() {
        return this._getOption('rtlEnabled');
    }
    set rtlEnabled(value) {
        this._setOption('rtlEnabled', value);
    }
    /**
     * [descr:dxPivotGridOptions.scrolling]
    
     */
    get scrolling() {
        return this._getOption('scrolling');
    }
    set scrolling(value) {
        this._setOption('scrolling', value);
    }
    /**
     * [descr:dxPivotGridOptions.showBorders]
    
     */
    get showBorders() {
        return this._getOption('showBorders');
    }
    set showBorders(value) {
        this._setOption('showBorders', value);
    }
    /**
     * [descr:dxPivotGridOptions.showColumnGrandTotals]
    
     */
    get showColumnGrandTotals() {
        return this._getOption('showColumnGrandTotals');
    }
    set showColumnGrandTotals(value) {
        this._setOption('showColumnGrandTotals', value);
    }
    /**
     * [descr:dxPivotGridOptions.showColumnTotals]
    
     */
    get showColumnTotals() {
        return this._getOption('showColumnTotals');
    }
    set showColumnTotals(value) {
        this._setOption('showColumnTotals', value);
    }
    /**
     * [descr:dxPivotGridOptions.showRowGrandTotals]
    
     */
    get showRowGrandTotals() {
        return this._getOption('showRowGrandTotals');
    }
    set showRowGrandTotals(value) {
        this._setOption('showRowGrandTotals', value);
    }
    /**
     * [descr:dxPivotGridOptions.showRowTotals]
    
     */
    get showRowTotals() {
        return this._getOption('showRowTotals');
    }
    set showRowTotals(value) {
        this._setOption('showRowTotals', value);
    }
    /**
     * [descr:dxPivotGridOptions.showTotalsPrior]
    
     */
    get showTotalsPrior() {
        return this._getOption('showTotalsPrior');
    }
    set showTotalsPrior(value) {
        this._setOption('showTotalsPrior', value);
    }
    /**
     * [descr:dxPivotGridOptions.stateStoring]
    
     */
    get stateStoring() {
        return this._getOption('stateStoring');
    }
    set stateStoring(value) {
        this._setOption('stateStoring', value);
    }
    /**
     * [descr:WidgetOptions.tabIndex]
    
     */
    get tabIndex() {
        return this._getOption('tabIndex');
    }
    set tabIndex(value) {
        this._setOption('tabIndex', value);
    }
    /**
     * [descr:dxPivotGridOptions.texts]
    
     */
    get texts() {
        return this._getOption('texts');
    }
    set texts(value) {
        this._setOption('texts', value);
    }
    /**
     * [descr:WidgetOptions.visible]
    
     */
    get visible() {
        return this._getOption('visible');
    }
    set visible(value) {
        this._setOption('visible', value);
    }
    /**
     * [descr:DOMComponentOptions.width]
    
     */
    get width() {
        return this._getOption('width');
    }
    set width(value) {
        this._setOption('width', value);
    }
    /**
     * [descr:dxPivotGridOptions.wordWrapEnabled]
    
     */
    get wordWrapEnabled() {
        return this._getOption('wordWrapEnabled');
    }
    set wordWrapEnabled(value) {
        this._setOption('wordWrapEnabled', value);
    }
    constructor(elementRef, ngZone, templateHost, _watcherHelper, _idh, optionHost, transferState, platformId) {
        super(elementRef, ngZone, templateHost, _watcherHelper, transferState, platformId);
        this._watcherHelper = _watcherHelper;
        this._idh = _idh;
        this.instance = null;
        this._createEventEmitters([
            { subscribe: 'cellClick', emit: 'onCellClick' },
            { subscribe: 'cellPrepared', emit: 'onCellPrepared' },
            { subscribe: 'contentReady', emit: 'onContentReady' },
            { subscribe: 'contextMenuPreparing', emit: 'onContextMenuPreparing' },
            { subscribe: 'disposing', emit: 'onDisposing' },
            { subscribe: 'exporting', emit: 'onExporting' },
            { subscribe: 'initialized', emit: 'onInitialized' },
            { subscribe: 'optionChanged', emit: 'onOptionChanged' },
            { emit: 'allowExpandAllChange' },
            { emit: 'allowFilteringChange' },
            { emit: 'allowSortingChange' },
            { emit: 'allowSortingBySummaryChange' },
            { emit: 'dataFieldAreaChange' },
            { emit: 'dataSourceChange' },
            { emit: 'disabledChange' },
            { emit: 'elementAttrChange' },
            { emit: 'encodeHtmlChange' },
            { emit: 'exportChange' },
            { emit: 'fieldChooserChange' },
            { emit: 'fieldPanelChange' },
            { emit: 'headerFilterChange' },
            { emit: 'heightChange' },
            { emit: 'hideEmptySummaryCellsChange' },
            { emit: 'hintChange' },
            { emit: 'loadPanelChange' },
            { emit: 'rowHeaderLayoutChange' },
            { emit: 'rtlEnabledChange' },
            { emit: 'scrollingChange' },
            { emit: 'showBordersChange' },
            { emit: 'showColumnGrandTotalsChange' },
            { emit: 'showColumnTotalsChange' },
            { emit: 'showRowGrandTotalsChange' },
            { emit: 'showRowTotalsChange' },
            { emit: 'showTotalsPriorChange' },
            { emit: 'stateStoringChange' },
            { emit: 'tabIndexChange' },
            { emit: 'textsChange' },
            { emit: 'visibleChange' },
            { emit: 'widthChange' },
            { emit: 'wordWrapEnabledChange' }
        ]);
        this._idh.setHost(this);
        optionHost.setHost(this);
    }
    _createInstance(element, options) {
        return new DxPivotGrid(element, options);
    }
    ngOnDestroy() {
        this._destroyWidget();
    }
    ngOnChanges(changes) {
        super.ngOnChanges(changes);
        this.setupChanges('dataSource', changes);
    }
    setupChanges(prop, changes) {
        if (!(prop in this._optionsToUpdate)) {
            this._idh.setup(prop, changes);
        }
    }
    ngDoCheck() {
        this._idh.doCheck('dataSource');
        this._watcherHelper.checkWatchers();
        super.ngDoCheck();
        super.clearChangedOptions();
    }
    _setOption(name, value) {
        let isSetup = this._idh.setupSingle(name, value);
        let isChanged = this._idh.getChanges(name, value) !== null;
        if (isSetup || isChanged) {
            super._setOption(name, value);
        }
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxPivotGridComponent, deps: [{ token: i0.ElementRef }, { token: i0.NgZone }, { token: i1.DxTemplateHost }, { token: i1.WatcherHelper }, { token: i1.IterableDifferHelper }, { token: i1.NestedOptionHost }, { token: i0.TransferState }, { token: PLATFORM_ID }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxPivotGridComponent, isStandalone: true, selector: "dx-pivot-grid", inputs: { allowExpandAll: "allowExpandAll", allowFiltering: "allowFiltering", allowSorting: "allowSorting", allowSortingBySummary: "allowSortingBySummary", dataFieldArea: "dataFieldArea", dataSource: "dataSource", disabled: "disabled", elementAttr: "elementAttr", encodeHtml: "encodeHtml", export: "export", fieldChooser: "fieldChooser", fieldPanel: "fieldPanel", headerFilter: "headerFilter", height: "height", hideEmptySummaryCells: "hideEmptySummaryCells", hint: "hint", loadPanel: "loadPanel", rowHeaderLayout: "rowHeaderLayout", rtlEnabled: "rtlEnabled", scrolling: "scrolling", showBorders: "showBorders", showColumnGrandTotals: "showColumnGrandTotals", showColumnTotals: "showColumnTotals", showRowGrandTotals: "showRowGrandTotals", showRowTotals: "showRowTotals", showTotalsPrior: "showTotalsPrior", stateStoring: "stateStoring", tabIndex: "tabIndex", texts: "texts", visible: "visible", width: "width", wordWrapEnabled: "wordWrapEnabled" }, outputs: { onCellClick: "onCellClick", onCellPrepared: "onCellPrepared", onContentReady: "onContentReady", onContextMenuPreparing: "onContextMenuPreparing", onDisposing: "onDisposing", onExporting: "onExporting", onInitialized: "onInitialized", onOptionChanged: "onOptionChanged", allowExpandAllChange: "allowExpandAllChange", allowFilteringChange: "allowFilteringChange", allowSortingChange: "allowSortingChange", allowSortingBySummaryChange: "allowSortingBySummaryChange", dataFieldAreaChange: "dataFieldAreaChange", dataSourceChange: "dataSourceChange", disabledChange: "disabledChange", elementAttrChange: "elementAttrChange", encodeHtmlChange: "encodeHtmlChange", exportChange: "exportChange", fieldChooserChange: "fieldChooserChange", fieldPanelChange: "fieldPanelChange", headerFilterChange: "headerFilterChange", heightChange: "heightChange", hideEmptySummaryCellsChange: "hideEmptySummaryCellsChange", hintChange: "hintChange", loadPanelChange: "loadPanelChange", rowHeaderLayoutChange: "rowHeaderLayoutChange", rtlEnabledChange: "rtlEnabledChange", scrollingChange: "scrollingChange", showBordersChange: "showBordersChange", showColumnGrandTotalsChange: "showColumnGrandTotalsChange", showColumnTotalsChange: "showColumnTotalsChange", showRowGrandTotalsChange: "showRowGrandTotalsChange", showRowTotalsChange: "showRowTotalsChange", showTotalsPriorChange: "showTotalsPriorChange", stateStoringChange: "stateStoringChange", tabIndexChange: "tabIndexChange", textsChange: "textsChange", visibleChange: "visibleChange", widthChange: "widthChange", wordWrapEnabledChange: "wordWrapEnabledChange" }, host: { attributes: { "ngSkipHydration": "true" } }, providers: [
            DxTemplateHost,
            WatcherHelper,
            NestedOptionHost,
            IterableDifferHelper
        ], usesInheritance: true, usesOnChanges: true, ngImport: i0, template: '', isInline: true, dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxPivotGridComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'dx-pivot-grid',
                    template: '',
                    host: { ngSkipHydration: 'true' },
                    imports: [DxIntegrationModule],
                    providers: [
                        DxTemplateHost,
                        WatcherHelper,
                        NestedOptionHost,
                        IterableDifferHelper
                    ]
                }]
        }], ctorParameters: () => [{ type: i0.ElementRef }, { type: i0.NgZone }, { type: i1.DxTemplateHost }, { type: i1.WatcherHelper }, { type: i1.IterableDifferHelper }, { type: i1.NestedOptionHost }, { type: i0.TransferState }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [PLATFORM_ID]
                }] }], propDecorators: { allowExpandAll: [{
                type: Input
            }], allowFiltering: [{
                type: Input
            }], allowSorting: [{
                type: Input
            }], allowSortingBySummary: [{
                type: Input
            }], dataFieldArea: [{
                type: Input
            }], dataSource: [{
                type: Input
            }], disabled: [{
                type: Input
            }], elementAttr: [{
                type: Input
            }], encodeHtml: [{
                type: Input
            }], export: [{
                type: Input
            }], fieldChooser: [{
                type: Input
            }], fieldPanel: [{
                type: Input
            }], headerFilter: [{
                type: Input
            }], height: [{
                type: Input
            }], hideEmptySummaryCells: [{
                type: Input
            }], hint: [{
                type: Input
            }], loadPanel: [{
                type: Input
            }], rowHeaderLayout: [{
                type: Input
            }], rtlEnabled: [{
                type: Input
            }], scrolling: [{
                type: Input
            }], showBorders: [{
                type: Input
            }], showColumnGrandTotals: [{
                type: Input
            }], showColumnTotals: [{
                type: Input
            }], showRowGrandTotals: [{
                type: Input
            }], showRowTotals: [{
                type: Input
            }], showTotalsPrior: [{
                type: Input
            }], stateStoring: [{
                type: Input
            }], tabIndex: [{
                type: Input
            }], texts: [{
                type: Input
            }], visible: [{
                type: Input
            }], width: [{
                type: Input
            }], wordWrapEnabled: [{
                type: Input
            }], onCellClick: [{
                type: Output
            }], onCellPrepared: [{
                type: Output
            }], onContentReady: [{
                type: Output
            }], onContextMenuPreparing: [{
                type: Output
            }], onDisposing: [{
                type: Output
            }], onExporting: [{
                type: Output
            }], onInitialized: [{
                type: Output
            }], onOptionChanged: [{
                type: Output
            }], allowExpandAllChange: [{
                type: Output
            }], allowFilteringChange: [{
                type: Output
            }], allowSortingChange: [{
                type: Output
            }], allowSortingBySummaryChange: [{
                type: Output
            }], dataFieldAreaChange: [{
                type: Output
            }], dataSourceChange: [{
                type: Output
            }], disabledChange: [{
                type: Output
            }], elementAttrChange: [{
                type: Output
            }], encodeHtmlChange: [{
                type: Output
            }], exportChange: [{
                type: Output
            }], fieldChooserChange: [{
                type: Output
            }], fieldPanelChange: [{
                type: Output
            }], headerFilterChange: [{
                type: Output
            }], heightChange: [{
                type: Output
            }], hideEmptySummaryCellsChange: [{
                type: Output
            }], hintChange: [{
                type: Output
            }], loadPanelChange: [{
                type: Output
            }], rowHeaderLayoutChange: [{
                type: Output
            }], rtlEnabledChange: [{
                type: Output
            }], scrollingChange: [{
                type: Output
            }], showBordersChange: [{
                type: Output
            }], showColumnGrandTotalsChange: [{
                type: Output
            }], showColumnTotalsChange: [{
                type: Output
            }], showRowGrandTotalsChange: [{
                type: Output
            }], showRowTotalsChange: [{
                type: Output
            }], showTotalsPriorChange: [{
                type: Output
            }], stateStoringChange: [{
                type: Output
            }], tabIndexChange: [{
                type: Output
            }], textsChange: [{
                type: Output
            }], visibleChange: [{
                type: Output
            }], widthChange: [{
                type: Output
            }], wordWrapEnabledChange: [{
                type: Output
            }] } });
class DxPivotGridModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxPivotGridModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxPivotGridModule, imports: [DxPivotGridComponent, DxoExportModule,
            DxoFieldChooserModule,
            DxoTextsModule,
            DxoFieldPanelModule,
            DxoHeaderFilterModule,
            DxoSearchModule,
            DxoLoadPanelModule,
            DxoScrollingModule,
            DxoStateStoringModule,
            DxoPivotGridExportModule,
            DxoPivotGridFieldChooserModule,
            DxoPivotGridFieldChooserTextsModule,
            DxoPivotGridFieldPanelModule,
            DxoPivotGridFieldPanelTextsModule,
            DxoPivotGridHeaderFilterModule,
            DxoPivotGridHeaderFilterTextsModule,
            DxoPivotGridLoadPanelModule,
            DxoPivotGridPivotGridTextsModule,
            DxoPivotGridScrollingModule,
            DxoPivotGridSearchModule,
            DxoPivotGridStateStoringModule,
            DxoPivotGridTextsModule,
            DxIntegrationModule,
            DxTemplateModule], exports: [DxPivotGridComponent, DxoExportModule,
            DxoFieldChooserModule,
            DxoTextsModule,
            DxoFieldPanelModule,
            DxoHeaderFilterModule,
            DxoSearchModule,
            DxoLoadPanelModule,
            DxoScrollingModule,
            DxoStateStoringModule,
            DxoPivotGridExportModule,
            DxoPivotGridFieldChooserModule,
            DxoPivotGridFieldChooserTextsModule,
            DxoPivotGridFieldPanelModule,
            DxoPivotGridFieldPanelTextsModule,
            DxoPivotGridHeaderFilterModule,
            DxoPivotGridHeaderFilterTextsModule,
            DxoPivotGridLoadPanelModule,
            DxoPivotGridPivotGridTextsModule,
            DxoPivotGridScrollingModule,
            DxoPivotGridSearchModule,
            DxoPivotGridStateStoringModule,
            DxoPivotGridTextsModule,
            DxTemplateModule] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxPivotGridModule, imports: [DxPivotGridComponent,
            DxoExportModule,
            DxoFieldChooserModule,
            DxoTextsModule,
            DxoFieldPanelModule,
            DxoHeaderFilterModule,
            DxoSearchModule,
            DxoLoadPanelModule,
            DxoScrollingModule,
            DxoStateStoringModule,
            DxoPivotGridExportModule,
            DxoPivotGridFieldChooserModule,
            DxoPivotGridFieldChooserTextsModule,
            DxoPivotGridFieldPanelModule,
            DxoPivotGridFieldPanelTextsModule,
            DxoPivotGridHeaderFilterModule,
            DxoPivotGridHeaderFilterTextsModule,
            DxoPivotGridLoadPanelModule,
            DxoPivotGridPivotGridTextsModule,
            DxoPivotGridScrollingModule,
            DxoPivotGridSearchModule,
            DxoPivotGridStateStoringModule,
            DxoPivotGridTextsModule,
            DxIntegrationModule,
            DxTemplateModule, DxoExportModule,
            DxoFieldChooserModule,
            DxoTextsModule,
            DxoFieldPanelModule,
            DxoHeaderFilterModule,
            DxoSearchModule,
            DxoLoadPanelModule,
            DxoScrollingModule,
            DxoStateStoringModule,
            DxoPivotGridExportModule,
            DxoPivotGridFieldChooserModule,
            DxoPivotGridFieldChooserTextsModule,
            DxoPivotGridFieldPanelModule,
            DxoPivotGridFieldPanelTextsModule,
            DxoPivotGridHeaderFilterModule,
            DxoPivotGridHeaderFilterTextsModule,
            DxoPivotGridLoadPanelModule,
            DxoPivotGridPivotGridTextsModule,
            DxoPivotGridScrollingModule,
            DxoPivotGridSearchModule,
            DxoPivotGridStateStoringModule,
            DxoPivotGridTextsModule,
            DxTemplateModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxPivotGridModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxPivotGridComponent,
                        DxoExportModule,
                        DxoFieldChooserModule,
                        DxoTextsModule,
                        DxoFieldPanelModule,
                        DxoHeaderFilterModule,
                        DxoSearchModule,
                        DxoLoadPanelModule,
                        DxoScrollingModule,
                        DxoStateStoringModule,
                        DxoPivotGridExportModule,
                        DxoPivotGridFieldChooserModule,
                        DxoPivotGridFieldChooserTextsModule,
                        DxoPivotGridFieldPanelModule,
                        DxoPivotGridFieldPanelTextsModule,
                        DxoPivotGridHeaderFilterModule,
                        DxoPivotGridHeaderFilterTextsModule,
                        DxoPivotGridLoadPanelModule,
                        DxoPivotGridPivotGridTextsModule,
                        DxoPivotGridScrollingModule,
                        DxoPivotGridSearchModule,
                        DxoPivotGridStateStoringModule,
                        DxoPivotGridTextsModule,
                        DxIntegrationModule,
                        DxTemplateModule
                    ],
                    exports: [
                        DxPivotGridComponent,
                        DxoExportModule,
                        DxoFieldChooserModule,
                        DxoTextsModule,
                        DxoFieldPanelModule,
                        DxoHeaderFilterModule,
                        DxoSearchModule,
                        DxoLoadPanelModule,
                        DxoScrollingModule,
                        DxoStateStoringModule,
                        DxoPivotGridExportModule,
                        DxoPivotGridFieldChooserModule,
                        DxoPivotGridFieldChooserTextsModule,
                        DxoPivotGridFieldPanelModule,
                        DxoPivotGridFieldPanelTextsModule,
                        DxoPivotGridHeaderFilterModule,
                        DxoPivotGridHeaderFilterTextsModule,
                        DxoPivotGridLoadPanelModule,
                        DxoPivotGridPivotGridTextsModule,
                        DxoPivotGridScrollingModule,
                        DxoPivotGridSearchModule,
                        DxoPivotGridStateStoringModule,
                        DxoPivotGridTextsModule,
                        DxTemplateModule
                    ]
                }]
        }] });

/**
 * Generated bundle index. Do not edit.
 */

export { DxPivotGridComponent, DxPivotGridModule };
//# sourceMappingURL=devextreme-angular-ui-pivot-grid.mjs.map
