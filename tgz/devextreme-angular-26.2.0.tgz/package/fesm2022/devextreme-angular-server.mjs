import * as i0 from '@angular/core';
import { PLATFORM_ID, Inject, NgModule } from '@angular/core';
import { isPlatformServer } from '@angular/common';
import infernoRenderer from 'devextreme/core/inferno_renderer';
import { renderToString } from 'inferno-server';

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
class DxServerModule {
    constructor(platformId) {
        if (isPlatformServer(platformId)) {
            infernoRenderer.inject({
                render: (component, props, container) => {
                    const el = infernoRenderer.createElement(component, props);
                    const document = container.ownerDocument;
                    const temp = document.createElement(container.tagName);
                    temp.innerHTML = renderToString(el);
                    const mainElement = temp.childNodes[0];
                    if (!mainElement) {
                        return;
                    }
                    const childString = mainElement.innerHTML;
                    for (let i = 0; i < mainElement.attributes.length; i++) {
                        const attr = mainElement.attributes[i];
                        if (!container.hasAttribute(attr.name)) {
                            container.setAttribute(attr.name, attr.value);
                        }
                    }
                    container.innerHTML = childString;
                },
                renderIntoContainer: (jsx, container) => {
                    if (jsx === null) {
                        container.innerHTML = '';
                        return;
                    }
                    container.innerHTML = renderToString(jsx);
                },
            });
        }
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxServerModule, deps: [{ token: PLATFORM_ID }], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxServerModule }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxServerModule }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxServerModule, decorators: [{
            type: NgModule,
            args: [{
                    exports: [],
                    imports: [],
                    providers: [],
                }]
        }], ctorParameters: () => [{ type: undefined, decorators: [{
                    type: Inject,
                    args: [PLATFORM_ID]
                }] }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

/**
 * Generated bundle index. Do not edit.
 */

export { DxServerModule };
//# sourceMappingURL=devextreme-angular-server.mjs.map
