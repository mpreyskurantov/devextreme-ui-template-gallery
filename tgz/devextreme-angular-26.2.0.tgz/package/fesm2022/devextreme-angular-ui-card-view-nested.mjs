import * as i0 from '@angular/core';
import { Input, SkipSelf, Host, Component, NgModule, Inject, ContentChildren, Output } from '@angular/core';
import * as i1 from 'devextreme-angular/core';
import { NestedOption, DxIntegrationModule, NestedOptionHost, CollectionNestedOption, extractTemplate, DxTemplateHost } from 'devextreme-angular/core';
import { PROPERTY_TOKEN_validationRules, PROPERTY_TOKEN_items, PROPERTY_TOKEN_changes, PROPERTY_TOKEN_columns, PROPERTY_TOKEN_customOperations, PROPERTY_TOKEN_fields, PROPERTY_TOKEN_tabs } from 'devextreme-angular/core/tokens';
import { DOCUMENT } from '@angular/common';

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoCardViewAIOptionsComponent extends NestedOption {
    get disabled() {
        return this._getOption('disabled');
    }
    set disabled(value) {
        this._setOption('disabled', value);
    }
    get instruction() {
        return this._getOption('instruction');
    }
    set instruction(value) {
        this._setOption('instruction', value);
    }
    get _optionPath() {
        return 'aiOptions';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewAIOptionsComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoCardViewAIOptionsComponent, isStandalone: true, selector: "dxo-card-view-ai-options", inputs: { disabled: "disabled", instruction: "instruction" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewAIOptionsComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-card-view-ai-options', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { disabled: [{
                type: Input
            }], instruction: [{
                type: Input
            }] } });
class DxoCardViewAIOptionsModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewAIOptionsModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewAIOptionsModule, imports: [DxoCardViewAIOptionsComponent], exports: [DxoCardViewAIOptionsComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewAIOptionsModule, imports: [DxoCardViewAIOptionsComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewAIOptionsModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoCardViewAIOptionsComponent
                    ],
                    exports: [
                        DxoCardViewAIOptionsComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoCardViewAnimationComponent extends NestedOption {
    get hide() {
        return this._getOption('hide');
    }
    set hide(value) {
        this._setOption('hide', value);
    }
    get show() {
        return this._getOption('show');
    }
    set show(value) {
        this._setOption('show', value);
    }
    get _optionPath() {
        return 'animation';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewAnimationComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoCardViewAnimationComponent, isStandalone: true, selector: "dxo-card-view-animation", inputs: { hide: "hide", show: "show" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewAnimationComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-card-view-animation', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { hide: [{
                type: Input
            }], show: [{
                type: Input
            }] } });
class DxoCardViewAnimationModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewAnimationModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewAnimationModule, imports: [DxoCardViewAnimationComponent], exports: [DxoCardViewAnimationComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewAnimationModule, imports: [DxoCardViewAnimationComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewAnimationModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoCardViewAnimationComponent
                    ],
                    exports: [
                        DxoCardViewAnimationComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxiCardViewAsyncRuleComponent extends CollectionNestedOption {
    get ignoreEmptyValue() {
        return this._getOption('ignoreEmptyValue');
    }
    set ignoreEmptyValue(value) {
        this._setOption('ignoreEmptyValue', value);
    }
    get message() {
        return this._getOption('message');
    }
    set message(value) {
        this._setOption('message', value);
    }
    get reevaluate() {
        return this._getOption('reevaluate');
    }
    set reevaluate(value) {
        this._setOption('reevaluate', value);
    }
    get type() {
        return this._getOption('type');
    }
    set type(value) {
        this._setOption('type', value);
    }
    get validationCallback() {
        return this._getOption('validationCallback');
    }
    set validationCallback(value) {
        this._setOption('validationCallback', value);
    }
    get _optionPath() {
        return 'validationRules';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
        this.type = 'async';
    }
    ngOnDestroy() {
        this._deleteRemovedOptions(this._fullOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiCardViewAsyncRuleComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxiCardViewAsyncRuleComponent, isStandalone: true, selector: "dxi-card-view-async-rule", inputs: { ignoreEmptyValue: "ignoreEmptyValue", message: "message", reevaluate: "reevaluate", type: "type", validationCallback: "validationCallback" }, providers: [
            NestedOptionHost,
            {
                provide: PROPERTY_TOKEN_validationRules,
                useExisting: DxiCardViewAsyncRuleComponent,
            }
        ], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiCardViewAsyncRuleComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxi-card-view-async-rule', template: '', imports: [DxIntegrationModule], providers: [
                        NestedOptionHost,
                        {
                            provide: PROPERTY_TOKEN_validationRules,
                            useExisting: DxiCardViewAsyncRuleComponent,
                        }
                    ] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { ignoreEmptyValue: [{
                type: Input
            }], message: [{
                type: Input
            }], reevaluate: [{
                type: Input
            }], type: [{
                type: Input
            }], validationCallback: [{
                type: Input
            }] } });
class DxiCardViewAsyncRuleModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiCardViewAsyncRuleModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxiCardViewAsyncRuleModule, imports: [DxiCardViewAsyncRuleComponent], exports: [DxiCardViewAsyncRuleComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiCardViewAsyncRuleModule, imports: [DxiCardViewAsyncRuleComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiCardViewAsyncRuleModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxiCardViewAsyncRuleComponent
                    ],
                    exports: [
                        DxiCardViewAsyncRuleComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoCardViewAtComponent extends NestedOption {
    get x() {
        return this._getOption('x');
    }
    set x(value) {
        this._setOption('x', value);
    }
    get y() {
        return this._getOption('y');
    }
    set y(value) {
        this._setOption('y', value);
    }
    get _optionPath() {
        return 'at';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewAtComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoCardViewAtComponent, isStandalone: true, selector: "dxo-card-view-at", inputs: { x: "x", y: "y" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewAtComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-card-view-at', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { x: [{
                type: Input
            }], y: [{
                type: Input
            }] } });
class DxoCardViewAtModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewAtModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewAtModule, imports: [DxoCardViewAtComponent], exports: [DxoCardViewAtComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewAtModule, imports: [DxoCardViewAtComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewAtModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoCardViewAtComponent
                    ],
                    exports: [
                        DxoCardViewAtComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoCardViewBoundaryOffsetComponent extends NestedOption {
    get x() {
        return this._getOption('x');
    }
    set x(value) {
        this._setOption('x', value);
    }
    get y() {
        return this._getOption('y');
    }
    set y(value) {
        this._setOption('y', value);
    }
    get _optionPath() {
        return 'boundaryOffset';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewBoundaryOffsetComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoCardViewBoundaryOffsetComponent, isStandalone: true, selector: "dxo-card-view-boundary-offset", inputs: { x: "x", y: "y" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewBoundaryOffsetComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-card-view-boundary-offset', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { x: [{
                type: Input
            }], y: [{
                type: Input
            }] } });
class DxoCardViewBoundaryOffsetModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewBoundaryOffsetModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewBoundaryOffsetModule, imports: [DxoCardViewBoundaryOffsetComponent], exports: [DxoCardViewBoundaryOffsetComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewBoundaryOffsetModule, imports: [DxoCardViewBoundaryOffsetComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewBoundaryOffsetModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoCardViewBoundaryOffsetComponent
                    ],
                    exports: [
                        DxoCardViewBoundaryOffsetComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxiCardViewButtonItemComponent extends CollectionNestedOption {
    get buttonOptions() {
        return this._getOption('buttonOptions');
    }
    set buttonOptions(value) {
        this._setOption('buttonOptions', value);
    }
    get colSpan() {
        return this._getOption('colSpan');
    }
    set colSpan(value) {
        this._setOption('colSpan', value);
    }
    get cssClass() {
        return this._getOption('cssClass');
    }
    set cssClass(value) {
        this._setOption('cssClass', value);
    }
    get horizontalAlignment() {
        return this._getOption('horizontalAlignment');
    }
    set horizontalAlignment(value) {
        this._setOption('horizontalAlignment', value);
    }
    get itemType() {
        return this._getOption('itemType');
    }
    set itemType(value) {
        this._setOption('itemType', value);
    }
    get name() {
        return this._getOption('name');
    }
    set name(value) {
        this._setOption('name', value);
    }
    get verticalAlignment() {
        return this._getOption('verticalAlignment');
    }
    set verticalAlignment(value) {
        this._setOption('verticalAlignment', value);
    }
    get visible() {
        return this._getOption('visible');
    }
    set visible(value) {
        this._setOption('visible', value);
    }
    get visibleIndex() {
        return this._getOption('visibleIndex');
    }
    set visibleIndex(value) {
        this._setOption('visibleIndex', value);
    }
    get _optionPath() {
        return 'items';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
        this.itemType = 'button';
    }
    ngOnDestroy() {
        this._deleteRemovedOptions(this._fullOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiCardViewButtonItemComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxiCardViewButtonItemComponent, isStandalone: true, selector: "dxi-card-view-button-item", inputs: { buttonOptions: "buttonOptions", colSpan: "colSpan", cssClass: "cssClass", horizontalAlignment: "horizontalAlignment", itemType: "itemType", name: "name", verticalAlignment: "verticalAlignment", visible: "visible", visibleIndex: "visibleIndex" }, providers: [
            NestedOptionHost,
            {
                provide: PROPERTY_TOKEN_items,
                useExisting: DxiCardViewButtonItemComponent,
            }
        ], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiCardViewButtonItemComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxi-card-view-button-item', template: '', imports: [DxIntegrationModule], providers: [
                        NestedOptionHost,
                        {
                            provide: PROPERTY_TOKEN_items,
                            useExisting: DxiCardViewButtonItemComponent,
                        }
                    ] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { buttonOptions: [{
                type: Input
            }], colSpan: [{
                type: Input
            }], cssClass: [{
                type: Input
            }], horizontalAlignment: [{
                type: Input
            }], itemType: [{
                type: Input
            }], name: [{
                type: Input
            }], verticalAlignment: [{
                type: Input
            }], visible: [{
                type: Input
            }], visibleIndex: [{
                type: Input
            }] } });
class DxiCardViewButtonItemModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiCardViewButtonItemModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxiCardViewButtonItemModule, imports: [DxiCardViewButtonItemComponent], exports: [DxiCardViewButtonItemComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiCardViewButtonItemModule, imports: [DxiCardViewButtonItemComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiCardViewButtonItemModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxiCardViewButtonItemComponent
                    ],
                    exports: [
                        DxiCardViewButtonItemComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoCardViewButtonOptionsComponent extends NestedOption {
    get accessKey() {
        return this._getOption('accessKey');
    }
    set accessKey(value) {
        this._setOption('accessKey', value);
    }
    get activeStateEnabled() {
        return this._getOption('activeStateEnabled');
    }
    set activeStateEnabled(value) {
        this._setOption('activeStateEnabled', value);
    }
    get disabled() {
        return this._getOption('disabled');
    }
    set disabled(value) {
        this._setOption('disabled', value);
    }
    get elementAttr() {
        return this._getOption('elementAttr');
    }
    set elementAttr(value) {
        this._setOption('elementAttr', value);
    }
    get focusStateEnabled() {
        return this._getOption('focusStateEnabled');
    }
    set focusStateEnabled(value) {
        this._setOption('focusStateEnabled', value);
    }
    get height() {
        return this._getOption('height');
    }
    set height(value) {
        this._setOption('height', value);
    }
    get hint() {
        return this._getOption('hint');
    }
    set hint(value) {
        this._setOption('hint', value);
    }
    get hoverStateEnabled() {
        return this._getOption('hoverStateEnabled');
    }
    set hoverStateEnabled(value) {
        this._setOption('hoverStateEnabled', value);
    }
    get icon() {
        return this._getOption('icon');
    }
    set icon(value) {
        this._setOption('icon', value);
    }
    get onClick() {
        return this._getOption('onClick');
    }
    set onClick(value) {
        this._setOption('onClick', value);
    }
    get onContentReady() {
        return this._getOption('onContentReady');
    }
    set onContentReady(value) {
        this._setOption('onContentReady', value);
    }
    get onDisposing() {
        return this._getOption('onDisposing');
    }
    set onDisposing(value) {
        this._setOption('onDisposing', value);
    }
    get onInitialized() {
        return this._getOption('onInitialized');
    }
    set onInitialized(value) {
        this._setOption('onInitialized', value);
    }
    get onOptionChanged() {
        return this._getOption('onOptionChanged');
    }
    set onOptionChanged(value) {
        this._setOption('onOptionChanged', value);
    }
    get rtlEnabled() {
        return this._getOption('rtlEnabled');
    }
    set rtlEnabled(value) {
        this._setOption('rtlEnabled', value);
    }
    get stylingMode() {
        return this._getOption('stylingMode');
    }
    set stylingMode(value) {
        this._setOption('stylingMode', value);
    }
    get tabIndex() {
        return this._getOption('tabIndex');
    }
    set tabIndex(value) {
        this._setOption('tabIndex', value);
    }
    get template() {
        return this._getOption('template');
    }
    set template(value) {
        this._setOption('template', value);
    }
    get text() {
        return this._getOption('text');
    }
    set text(value) {
        this._setOption('text', value);
    }
    get type() {
        return this._getOption('type');
    }
    set type(value) {
        this._setOption('type', value);
    }
    get useSubmitBehavior() {
        return this._getOption('useSubmitBehavior');
    }
    set useSubmitBehavior(value) {
        this._setOption('useSubmitBehavior', value);
    }
    get validationGroup() {
        return this._getOption('validationGroup');
    }
    set validationGroup(value) {
        this._setOption('validationGroup', value);
    }
    get visible() {
        return this._getOption('visible');
    }
    set visible(value) {
        this._setOption('visible', value);
    }
    get width() {
        return this._getOption('width');
    }
    set width(value) {
        this._setOption('width', value);
    }
    get _optionPath() {
        return 'buttonOptions';
    }
    constructor(parentOptionHost, optionHost, renderer, document, templateHost, element) {
        super();
        this.renderer = renderer;
        this.document = document;
        this.element = element;
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
        templateHost.setHost(this);
    }
    setTemplate(template) {
        this.template = template;
    }
    ngAfterViewInit() {
        extractTemplate(this, this.element, this.renderer, this.document);
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewButtonOptionsComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }, { token: i0.Renderer2 }, { token: DOCUMENT }, { token: i1.DxTemplateHost, host: true }, { token: i0.ElementRef }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoCardViewButtonOptionsComponent, isStandalone: true, selector: "dxo-card-view-button-options", inputs: { accessKey: "accessKey", activeStateEnabled: "activeStateEnabled", disabled: "disabled", elementAttr: "elementAttr", focusStateEnabled: "focusStateEnabled", height: "height", hint: "hint", hoverStateEnabled: "hoverStateEnabled", icon: "icon", onClick: "onClick", onContentReady: "onContentReady", onDisposing: "onDisposing", onInitialized: "onInitialized", onOptionChanged: "onOptionChanged", rtlEnabled: "rtlEnabled", stylingMode: "stylingMode", tabIndex: "tabIndex", template: "template", text: "text", type: "type", useSubmitBehavior: "useSubmitBehavior", validationGroup: "validationGroup", visible: "visible", width: "width" }, providers: [NestedOptionHost, DxTemplateHost], usesInheritance: true, ngImport: i0, template: '<ng-content></ng-content>', isInline: true, styles: [":host{display:block}\n"], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewButtonOptionsComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-card-view-button-options', template: '<ng-content></ng-content>', imports: [DxIntegrationModule], providers: [NestedOptionHost, DxTemplateHost], styles: [":host{display:block}\n"] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }, { type: i0.Renderer2 }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [DOCUMENT]
                }] }, { type: i1.DxTemplateHost, decorators: [{
                    type: Host
                }] }, { type: i0.ElementRef }], propDecorators: { accessKey: [{
                type: Input
            }], activeStateEnabled: [{
                type: Input
            }], disabled: [{
                type: Input
            }], elementAttr: [{
                type: Input
            }], focusStateEnabled: [{
                type: Input
            }], height: [{
                type: Input
            }], hint: [{
                type: Input
            }], hoverStateEnabled: [{
                type: Input
            }], icon: [{
                type: Input
            }], onClick: [{
                type: Input
            }], onContentReady: [{
                type: Input
            }], onDisposing: [{
                type: Input
            }], onInitialized: [{
                type: Input
            }], onOptionChanged: [{
                type: Input
            }], rtlEnabled: [{
                type: Input
            }], stylingMode: [{
                type: Input
            }], tabIndex: [{
                type: Input
            }], template: [{
                type: Input
            }], text: [{
                type: Input
            }], type: [{
                type: Input
            }], useSubmitBehavior: [{
                type: Input
            }], validationGroup: [{
                type: Input
            }], visible: [{
                type: Input
            }], width: [{
                type: Input
            }] } });
class DxoCardViewButtonOptionsModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewButtonOptionsModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewButtonOptionsModule, imports: [DxoCardViewButtonOptionsComponent], exports: [DxoCardViewButtonOptionsComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewButtonOptionsModule, imports: [DxoCardViewButtonOptionsComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewButtonOptionsModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoCardViewButtonOptionsComponent
                    ],
                    exports: [
                        DxoCardViewButtonOptionsComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoCardViewCardCoverComponent extends NestedOption {
    get altExpr() {
        return this._getOption('altExpr');
    }
    set altExpr(value) {
        this._setOption('altExpr', value);
    }
    get aspectRatio() {
        return this._getOption('aspectRatio');
    }
    set aspectRatio(value) {
        this._setOption('aspectRatio', value);
    }
    get imageExpr() {
        return this._getOption('imageExpr');
    }
    set imageExpr(value) {
        this._setOption('imageExpr', value);
    }
    get maxHeight() {
        return this._getOption('maxHeight');
    }
    set maxHeight(value) {
        this._setOption('maxHeight', value);
    }
    get template() {
        return this._getOption('template');
    }
    set template(value) {
        this._setOption('template', value);
    }
    get _optionPath() {
        return 'cardCover';
    }
    constructor(parentOptionHost, optionHost, renderer, document, templateHost, element) {
        super();
        this.renderer = renderer;
        this.document = document;
        this.element = element;
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
        templateHost.setHost(this);
    }
    setTemplate(template) {
        this.template = template;
    }
    ngAfterViewInit() {
        extractTemplate(this, this.element, this.renderer, this.document);
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewCardCoverComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }, { token: i0.Renderer2 }, { token: DOCUMENT }, { token: i1.DxTemplateHost, host: true }, { token: i0.ElementRef }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoCardViewCardCoverComponent, isStandalone: true, selector: "dxo-card-view-card-cover", inputs: { altExpr: "altExpr", aspectRatio: "aspectRatio", imageExpr: "imageExpr", maxHeight: "maxHeight", template: "template" }, providers: [NestedOptionHost, DxTemplateHost], usesInheritance: true, ngImport: i0, template: '<ng-content></ng-content>', isInline: true, styles: [":host{display:block}\n"], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewCardCoverComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-card-view-card-cover', template: '<ng-content></ng-content>', imports: [DxIntegrationModule], providers: [NestedOptionHost, DxTemplateHost], styles: [":host{display:block}\n"] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }, { type: i0.Renderer2 }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [DOCUMENT]
                }] }, { type: i1.DxTemplateHost, decorators: [{
                    type: Host
                }] }, { type: i0.ElementRef }], propDecorators: { altExpr: [{
                type: Input
            }], aspectRatio: [{
                type: Input
            }], imageExpr: [{
                type: Input
            }], maxHeight: [{
                type: Input
            }], template: [{
                type: Input
            }] } });
class DxoCardViewCardCoverModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewCardCoverModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewCardCoverModule, imports: [DxoCardViewCardCoverComponent], exports: [DxoCardViewCardCoverComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewCardCoverModule, imports: [DxoCardViewCardCoverComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewCardCoverModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoCardViewCardCoverComponent
                    ],
                    exports: [
                        DxoCardViewCardCoverComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxiCardViewCardHeaderItemComponent extends CollectionNestedOption {
    get cssClass() {
        return this._getOption('cssClass');
    }
    set cssClass(value) {
        this._setOption('cssClass', value);
    }
    get disabled() {
        return this._getOption('disabled');
    }
    set disabled(value) {
        this._setOption('disabled', value);
    }
    get html() {
        return this._getOption('html');
    }
    set html(value) {
        this._setOption('html', value);
    }
    get locateInMenu() {
        return this._getOption('locateInMenu');
    }
    set locateInMenu(value) {
        this._setOption('locateInMenu', value);
    }
    get location() {
        return this._getOption('location');
    }
    set location(value) {
        this._setOption('location', value);
    }
    get menuItemTemplate() {
        return this._getOption('menuItemTemplate');
    }
    set menuItemTemplate(value) {
        this._setOption('menuItemTemplate', value);
    }
    get name() {
        return this._getOption('name');
    }
    set name(value) {
        this._setOption('name', value);
    }
    get options() {
        return this._getOption('options');
    }
    set options(value) {
        this._setOption('options', value);
    }
    get showText() {
        return this._getOption('showText');
    }
    set showText(value) {
        this._setOption('showText', value);
    }
    get template() {
        return this._getOption('template');
    }
    set template(value) {
        this._setOption('template', value);
    }
    get text() {
        return this._getOption('text');
    }
    set text(value) {
        this._setOption('text', value);
    }
    get visible() {
        return this._getOption('visible');
    }
    set visible(value) {
        this._setOption('visible', value);
    }
    get widget() {
        return this._getOption('widget');
    }
    set widget(value) {
        this._setOption('widget', value);
    }
    get _optionPath() {
        return 'items';
    }
    constructor(parentOptionHost, optionHost, renderer, document, templateHost, element) {
        super();
        this.renderer = renderer;
        this.document = document;
        this.element = element;
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
        templateHost.setHost(this);
    }
    setTemplate(template) {
        this.template = template;
    }
    ngAfterViewInit() {
        extractTemplate(this, this.element, this.renderer, this.document);
    }
    ngOnDestroy() {
        this._deleteRemovedOptions(this._fullOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiCardViewCardHeaderItemComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }, { token: i0.Renderer2 }, { token: DOCUMENT }, { token: i1.DxTemplateHost, host: true }, { token: i0.ElementRef }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxiCardViewCardHeaderItemComponent, isStandalone: true, selector: "dxi-card-view-card-header-item", inputs: { cssClass: "cssClass", disabled: "disabled", html: "html", locateInMenu: "locateInMenu", location: "location", menuItemTemplate: "menuItemTemplate", name: "name", options: "options", showText: "showText", template: "template", text: "text", visible: "visible", widget: "widget" }, providers: [
            NestedOptionHost,
            DxTemplateHost,
            {
                provide: PROPERTY_TOKEN_items,
                useExisting: DxiCardViewCardHeaderItemComponent,
            }
        ], usesInheritance: true, ngImport: i0, template: '<ng-content></ng-content>', isInline: true, styles: [":host{display:block}\n"], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiCardViewCardHeaderItemComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxi-card-view-card-header-item', template: '<ng-content></ng-content>', imports: [DxIntegrationModule], providers: [
                        NestedOptionHost,
                        DxTemplateHost,
                        {
                            provide: PROPERTY_TOKEN_items,
                            useExisting: DxiCardViewCardHeaderItemComponent,
                        }
                    ], styles: [":host{display:block}\n"] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }, { type: i0.Renderer2 }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [DOCUMENT]
                }] }, { type: i1.DxTemplateHost, decorators: [{
                    type: Host
                }] }, { type: i0.ElementRef }], propDecorators: { cssClass: [{
                type: Input
            }], disabled: [{
                type: Input
            }], html: [{
                type: Input
            }], locateInMenu: [{
                type: Input
            }], location: [{
                type: Input
            }], menuItemTemplate: [{
                type: Input
            }], name: [{
                type: Input
            }], options: [{
                type: Input
            }], showText: [{
                type: Input
            }], template: [{
                type: Input
            }], text: [{
                type: Input
            }], visible: [{
                type: Input
            }], widget: [{
                type: Input
            }] } });
class DxiCardViewCardHeaderItemModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiCardViewCardHeaderItemModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxiCardViewCardHeaderItemModule, imports: [DxiCardViewCardHeaderItemComponent], exports: [DxiCardViewCardHeaderItemComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiCardViewCardHeaderItemModule, imports: [DxiCardViewCardHeaderItemComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiCardViewCardHeaderItemModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxiCardViewCardHeaderItemComponent
                    ],
                    exports: [
                        DxiCardViewCardHeaderItemComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoCardViewCardHeaderComponent extends NestedOption {
    set _itemsContentChildren(value) {
        this.setChildren('items', value);
    }
    get items() {
        return this._getOption('items');
    }
    set items(value) {
        this._setOption('items', value);
    }
    get template() {
        return this._getOption('template');
    }
    set template(value) {
        this._setOption('template', value);
    }
    get visible() {
        return this._getOption('visible');
    }
    set visible(value) {
        this._setOption('visible', value);
    }
    get _optionPath() {
        return 'cardHeader';
    }
    constructor(parentOptionHost, optionHost, renderer, document, templateHost, element) {
        super();
        this.renderer = renderer;
        this.document = document;
        this.element = element;
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
        templateHost.setHost(this);
    }
    setTemplate(template) {
        this.template = template;
    }
    ngAfterViewInit() {
        extractTemplate(this, this.element, this.renderer, this.document);
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewCardHeaderComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }, { token: i0.Renderer2 }, { token: DOCUMENT }, { token: i1.DxTemplateHost, host: true }, { token: i0.ElementRef }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoCardViewCardHeaderComponent, isStandalone: true, selector: "dxo-card-view-card-header", inputs: { items: "items", template: "template", visible: "visible" }, providers: [NestedOptionHost, DxTemplateHost], queries: [{ propertyName: "_itemsContentChildren", predicate: PROPERTY_TOKEN_items }], usesInheritance: true, ngImport: i0, template: '<ng-content></ng-content>', isInline: true, styles: [":host{display:block}\n"], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewCardHeaderComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-card-view-card-header', template: '<ng-content></ng-content>', imports: [DxIntegrationModule], providers: [NestedOptionHost, DxTemplateHost], styles: [":host{display:block}\n"] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }, { type: i0.Renderer2 }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [DOCUMENT]
                }] }, { type: i1.DxTemplateHost, decorators: [{
                    type: Host
                }] }, { type: i0.ElementRef }], propDecorators: { _itemsContentChildren: [{
                type: ContentChildren,
                args: [PROPERTY_TOKEN_items]
            }], items: [{
                type: Input
            }], template: [{
                type: Input
            }], visible: [{
                type: Input
            }] } });
class DxoCardViewCardHeaderModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewCardHeaderModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewCardHeaderModule, imports: [DxoCardViewCardHeaderComponent], exports: [DxoCardViewCardHeaderComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewCardHeaderModule, imports: [DxoCardViewCardHeaderComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewCardHeaderModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoCardViewCardHeaderComponent
                    ],
                    exports: [
                        DxoCardViewCardHeaderComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoCardViewCardViewHeaderFilterSearchComponent extends NestedOption {
    get editorOptions() {
        return this._getOption('editorOptions');
    }
    set editorOptions(value) {
        this._setOption('editorOptions', value);
    }
    get enabled() {
        return this._getOption('enabled');
    }
    set enabled(value) {
        this._setOption('enabled', value);
    }
    get mode() {
        return this._getOption('mode');
    }
    set mode(value) {
        this._setOption('mode', value);
    }
    get timeout() {
        return this._getOption('timeout');
    }
    set timeout(value) {
        this._setOption('timeout', value);
    }
    get _optionPath() {
        return 'search';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewCardViewHeaderFilterSearchComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoCardViewCardViewHeaderFilterSearchComponent, isStandalone: true, selector: "dxo-card-view-card-view-header-filter-search", inputs: { editorOptions: "editorOptions", enabled: "enabled", mode: "mode", timeout: "timeout" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewCardViewHeaderFilterSearchComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-card-view-card-view-header-filter-search', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { editorOptions: [{
                type: Input
            }], enabled: [{
                type: Input
            }], mode: [{
                type: Input
            }], timeout: [{
                type: Input
            }] } });
class DxoCardViewCardViewHeaderFilterSearchModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewCardViewHeaderFilterSearchModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewCardViewHeaderFilterSearchModule, imports: [DxoCardViewCardViewHeaderFilterSearchComponent], exports: [DxoCardViewCardViewHeaderFilterSearchComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewCardViewHeaderFilterSearchModule, imports: [DxoCardViewCardViewHeaderFilterSearchComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewCardViewHeaderFilterSearchModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoCardViewCardViewHeaderFilterSearchComponent
                    ],
                    exports: [
                        DxoCardViewCardViewHeaderFilterSearchComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoCardViewCardViewHeaderFilterTextsComponent extends NestedOption {
    get cancel() {
        return this._getOption('cancel');
    }
    set cancel(value) {
        this._setOption('cancel', value);
    }
    get emptyValue() {
        return this._getOption('emptyValue');
    }
    set emptyValue(value) {
        this._setOption('emptyValue', value);
    }
    get ok() {
        return this._getOption('ok');
    }
    set ok(value) {
        this._setOption('ok', value);
    }
    get _optionPath() {
        return 'texts';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewCardViewHeaderFilterTextsComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoCardViewCardViewHeaderFilterTextsComponent, isStandalone: true, selector: "dxo-card-view-card-view-header-filter-texts", inputs: { cancel: "cancel", emptyValue: "emptyValue", ok: "ok" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewCardViewHeaderFilterTextsComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-card-view-card-view-header-filter-texts', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { cancel: [{
                type: Input
            }], emptyValue: [{
                type: Input
            }], ok: [{
                type: Input
            }] } });
class DxoCardViewCardViewHeaderFilterTextsModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewCardViewHeaderFilterTextsModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewCardViewHeaderFilterTextsModule, imports: [DxoCardViewCardViewHeaderFilterTextsComponent], exports: [DxoCardViewCardViewHeaderFilterTextsComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewCardViewHeaderFilterTextsModule, imports: [DxoCardViewCardViewHeaderFilterTextsComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewCardViewHeaderFilterTextsModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoCardViewCardViewHeaderFilterTextsComponent
                    ],
                    exports: [
                        DxoCardViewCardViewHeaderFilterTextsComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoCardViewCardViewHeaderFilterComponent extends NestedOption {
    get allowSearch() {
        return this._getOption('allowSearch');
    }
    set allowSearch(value) {
        this._setOption('allowSearch', value);
    }
    get allowSelectAll() {
        return this._getOption('allowSelectAll');
    }
    set allowSelectAll(value) {
        this._setOption('allowSelectAll', value);
    }
    get height() {
        return this._getOption('height');
    }
    set height(value) {
        this._setOption('height', value);
    }
    get search() {
        return this._getOption('search');
    }
    set search(value) {
        this._setOption('search', value);
    }
    get searchTimeout() {
        return this._getOption('searchTimeout');
    }
    set searchTimeout(value) {
        this._setOption('searchTimeout', value);
    }
    get texts() {
        return this._getOption('texts');
    }
    set texts(value) {
        this._setOption('texts', value);
    }
    get visible() {
        return this._getOption('visible');
    }
    set visible(value) {
        this._setOption('visible', value);
    }
    get width() {
        return this._getOption('width');
    }
    set width(value) {
        this._setOption('width', value);
    }
    get _optionPath() {
        return 'headerFilter';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewCardViewHeaderFilterComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoCardViewCardViewHeaderFilterComponent, isStandalone: true, selector: "dxo-card-view-card-view-header-filter", inputs: { allowSearch: "allowSearch", allowSelectAll: "allowSelectAll", height: "height", search: "search", searchTimeout: "searchTimeout", texts: "texts", visible: "visible", width: "width" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewCardViewHeaderFilterComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-card-view-card-view-header-filter', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { allowSearch: [{
                type: Input
            }], allowSelectAll: [{
                type: Input
            }], height: [{
                type: Input
            }], search: [{
                type: Input
            }], searchTimeout: [{
                type: Input
            }], texts: [{
                type: Input
            }], visible: [{
                type: Input
            }], width: [{
                type: Input
            }] } });
class DxoCardViewCardViewHeaderFilterModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewCardViewHeaderFilterModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewCardViewHeaderFilterModule, imports: [DxoCardViewCardViewHeaderFilterComponent], exports: [DxoCardViewCardViewHeaderFilterComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewCardViewHeaderFilterModule, imports: [DxoCardViewCardViewHeaderFilterComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewCardViewHeaderFilterModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoCardViewCardViewHeaderFilterComponent
                    ],
                    exports: [
                        DxoCardViewCardViewHeaderFilterComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoCardViewCardViewSelectionComponent extends NestedOption {
    get allowSelectAll() {
        return this._getOption('allowSelectAll');
    }
    set allowSelectAll(value) {
        this._setOption('allowSelectAll', value);
    }
    get mode() {
        return this._getOption('mode');
    }
    set mode(value) {
        this._setOption('mode', value);
    }
    get selectAllMode() {
        return this._getOption('selectAllMode');
    }
    set selectAllMode(value) {
        this._setOption('selectAllMode', value);
    }
    get showCheckBoxesMode() {
        return this._getOption('showCheckBoxesMode');
    }
    set showCheckBoxesMode(value) {
        this._setOption('showCheckBoxesMode', value);
    }
    get _optionPath() {
        return 'selection';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewCardViewSelectionComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoCardViewCardViewSelectionComponent, isStandalone: true, selector: "dxo-card-view-card-view-selection", inputs: { allowSelectAll: "allowSelectAll", mode: "mode", selectAllMode: "selectAllMode", showCheckBoxesMode: "showCheckBoxesMode" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewCardViewSelectionComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-card-view-card-view-selection', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { allowSelectAll: [{
                type: Input
            }], mode: [{
                type: Input
            }], selectAllMode: [{
                type: Input
            }], showCheckBoxesMode: [{
                type: Input
            }] } });
class DxoCardViewCardViewSelectionModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewCardViewSelectionModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewCardViewSelectionModule, imports: [DxoCardViewCardViewSelectionComponent], exports: [DxoCardViewCardViewSelectionComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewCardViewSelectionModule, imports: [DxoCardViewCardViewSelectionComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewCardViewSelectionModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoCardViewCardViewSelectionComponent
                    ],
                    exports: [
                        DxoCardViewCardViewSelectionComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxiCardViewChangeComponent extends CollectionNestedOption {
    get data() {
        return this._getOption('data');
    }
    set data(value) {
        this._setOption('data', value);
    }
    get insertAfterKey() {
        return this._getOption('insertAfterKey');
    }
    set insertAfterKey(value) {
        this._setOption('insertAfterKey', value);
    }
    get insertBeforeKey() {
        return this._getOption('insertBeforeKey');
    }
    set insertBeforeKey(value) {
        this._setOption('insertBeforeKey', value);
    }
    get key() {
        return this._getOption('key');
    }
    set key(value) {
        this._setOption('key', value);
    }
    get type() {
        return this._getOption('type');
    }
    set type(value) {
        this._setOption('type', value);
    }
    get _optionPath() {
        return 'changes';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnDestroy() {
        this._deleteRemovedOptions(this._fullOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiCardViewChangeComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxiCardViewChangeComponent, isStandalone: true, selector: "dxi-card-view-change", inputs: { data: "data", insertAfterKey: "insertAfterKey", insertBeforeKey: "insertBeforeKey", key: "key", type: "type" }, providers: [
            NestedOptionHost,
            {
                provide: PROPERTY_TOKEN_changes,
                useExisting: DxiCardViewChangeComponent,
            }
        ], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiCardViewChangeComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxi-card-view-change', template: '', imports: [DxIntegrationModule], providers: [
                        NestedOptionHost,
                        {
                            provide: PROPERTY_TOKEN_changes,
                            useExisting: DxiCardViewChangeComponent,
                        }
                    ] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { data: [{
                type: Input
            }], insertAfterKey: [{
                type: Input
            }], insertBeforeKey: [{
                type: Input
            }], key: [{
                type: Input
            }], type: [{
                type: Input
            }] } });
class DxiCardViewChangeModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiCardViewChangeModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxiCardViewChangeModule, imports: [DxiCardViewChangeComponent], exports: [DxiCardViewChangeComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiCardViewChangeModule, imports: [DxiCardViewChangeComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiCardViewChangeModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxiCardViewChangeComponent
                    ],
                    exports: [
                        DxiCardViewChangeComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoCardViewColCountByScreenComponent extends NestedOption {
    get lg() {
        return this._getOption('lg');
    }
    set lg(value) {
        this._setOption('lg', value);
    }
    get md() {
        return this._getOption('md');
    }
    set md(value) {
        this._setOption('md', value);
    }
    get sm() {
        return this._getOption('sm');
    }
    set sm(value) {
        this._setOption('sm', value);
    }
    get xs() {
        return this._getOption('xs');
    }
    set xs(value) {
        this._setOption('xs', value);
    }
    get _optionPath() {
        return 'colCountByScreen';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewColCountByScreenComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoCardViewColCountByScreenComponent, isStandalone: true, selector: "dxo-card-view-col-count-by-screen", inputs: { lg: "lg", md: "md", sm: "sm", xs: "xs" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewColCountByScreenComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-card-view-col-count-by-screen', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { lg: [{
                type: Input
            }], md: [{
                type: Input
            }], sm: [{
                type: Input
            }], xs: [{
                type: Input
            }] } });
class DxoCardViewColCountByScreenModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewColCountByScreenModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewColCountByScreenModule, imports: [DxoCardViewColCountByScreenComponent], exports: [DxoCardViewColCountByScreenComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewColCountByScreenModule, imports: [DxoCardViewColCountByScreenComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewColCountByScreenModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoCardViewColCountByScreenComponent
                    ],
                    exports: [
                        DxoCardViewColCountByScreenComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoCardViewCollisionComponent extends NestedOption {
    get x() {
        return this._getOption('x');
    }
    set x(value) {
        this._setOption('x', value);
    }
    get y() {
        return this._getOption('y');
    }
    set y(value) {
        this._setOption('y', value);
    }
    get _optionPath() {
        return 'collision';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewCollisionComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoCardViewCollisionComponent, isStandalone: true, selector: "dxo-card-view-collision", inputs: { x: "x", y: "y" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewCollisionComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-card-view-collision', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { x: [{
                type: Input
            }], y: [{
                type: Input
            }] } });
class DxoCardViewCollisionModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewCollisionModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewCollisionModule, imports: [DxoCardViewCollisionComponent], exports: [DxoCardViewCollisionComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewCollisionModule, imports: [DxoCardViewCollisionComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewCollisionModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoCardViewCollisionComponent
                    ],
                    exports: [
                        DxoCardViewCollisionComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoCardViewColumnChooserSearchComponent extends NestedOption {
    get editorOptions() {
        return this._getOption('editorOptions');
    }
    set editorOptions(value) {
        this._setOption('editorOptions', value);
    }
    get enabled() {
        return this._getOption('enabled');
    }
    set enabled(value) {
        this._setOption('enabled', value);
    }
    get timeout() {
        return this._getOption('timeout');
    }
    set timeout(value) {
        this._setOption('timeout', value);
    }
    get _optionPath() {
        return 'search';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewColumnChooserSearchComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoCardViewColumnChooserSearchComponent, isStandalone: true, selector: "dxo-card-view-column-chooser-search", inputs: { editorOptions: "editorOptions", enabled: "enabled", timeout: "timeout" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewColumnChooserSearchComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-card-view-column-chooser-search', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { editorOptions: [{
                type: Input
            }], enabled: [{
                type: Input
            }], timeout: [{
                type: Input
            }] } });
class DxoCardViewColumnChooserSearchModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewColumnChooserSearchModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewColumnChooserSearchModule, imports: [DxoCardViewColumnChooserSearchComponent], exports: [DxoCardViewColumnChooserSearchComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewColumnChooserSearchModule, imports: [DxoCardViewColumnChooserSearchComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewColumnChooserSearchModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoCardViewColumnChooserSearchComponent
                    ],
                    exports: [
                        DxoCardViewColumnChooserSearchComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoCardViewColumnChooserSelectionComponent extends NestedOption {
    get allowSelectAll() {
        return this._getOption('allowSelectAll');
    }
    set allowSelectAll(value) {
        this._setOption('allowSelectAll', value);
    }
    get recursive() {
        return this._getOption('recursive');
    }
    set recursive(value) {
        this._setOption('recursive', value);
    }
    get selectByClick() {
        return this._getOption('selectByClick');
    }
    set selectByClick(value) {
        this._setOption('selectByClick', value);
    }
    get _optionPath() {
        return 'selection';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewColumnChooserSelectionComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoCardViewColumnChooserSelectionComponent, isStandalone: true, selector: "dxo-card-view-column-chooser-selection", inputs: { allowSelectAll: "allowSelectAll", recursive: "recursive", selectByClick: "selectByClick" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewColumnChooserSelectionComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-card-view-column-chooser-selection', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { allowSelectAll: [{
                type: Input
            }], recursive: [{
                type: Input
            }], selectByClick: [{
                type: Input
            }] } });
class DxoCardViewColumnChooserSelectionModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewColumnChooserSelectionModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewColumnChooserSelectionModule, imports: [DxoCardViewColumnChooserSelectionComponent], exports: [DxoCardViewColumnChooserSelectionComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewColumnChooserSelectionModule, imports: [DxoCardViewColumnChooserSelectionComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewColumnChooserSelectionModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoCardViewColumnChooserSelectionComponent
                    ],
                    exports: [
                        DxoCardViewColumnChooserSelectionComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoCardViewColumnChooserComponent extends NestedOption {
    get allowSearch() {
        return this._getOption('allowSearch');
    }
    set allowSearch(value) {
        this._setOption('allowSearch', value);
    }
    get container() {
        return this._getOption('container');
    }
    set container(value) {
        this._setOption('container', value);
    }
    get emptyPanelText() {
        return this._getOption('emptyPanelText');
    }
    set emptyPanelText(value) {
        this._setOption('emptyPanelText', value);
    }
    get enabled() {
        return this._getOption('enabled');
    }
    set enabled(value) {
        this._setOption('enabled', value);
    }
    get height() {
        return this._getOption('height');
    }
    set height(value) {
        this._setOption('height', value);
    }
    get mode() {
        return this._getOption('mode');
    }
    set mode(value) {
        this._setOption('mode', value);
    }
    get position() {
        return this._getOption('position');
    }
    set position(value) {
        this._setOption('position', value);
    }
    get search() {
        return this._getOption('search');
    }
    set search(value) {
        this._setOption('search', value);
    }
    get searchTimeout() {
        return this._getOption('searchTimeout');
    }
    set searchTimeout(value) {
        this._setOption('searchTimeout', value);
    }
    get selection() {
        return this._getOption('selection');
    }
    set selection(value) {
        this._setOption('selection', value);
    }
    get sortOrder() {
        return this._getOption('sortOrder');
    }
    set sortOrder(value) {
        this._setOption('sortOrder', value);
    }
    get title() {
        return this._getOption('title');
    }
    set title(value) {
        this._setOption('title', value);
    }
    get width() {
        return this._getOption('width');
    }
    set width(value) {
        this._setOption('width', value);
    }
    get _optionPath() {
        return 'columnChooser';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewColumnChooserComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoCardViewColumnChooserComponent, isStandalone: true, selector: "dxo-card-view-column-chooser", inputs: { allowSearch: "allowSearch", container: "container", emptyPanelText: "emptyPanelText", enabled: "enabled", height: "height", mode: "mode", position: "position", search: "search", searchTimeout: "searchTimeout", selection: "selection", sortOrder: "sortOrder", title: "title", width: "width" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewColumnChooserComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-card-view-column-chooser', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { allowSearch: [{
                type: Input
            }], container: [{
                type: Input
            }], emptyPanelText: [{
                type: Input
            }], enabled: [{
                type: Input
            }], height: [{
                type: Input
            }], mode: [{
                type: Input
            }], position: [{
                type: Input
            }], search: [{
                type: Input
            }], searchTimeout: [{
                type: Input
            }], selection: [{
                type: Input
            }], sortOrder: [{
                type: Input
            }], title: [{
                type: Input
            }], width: [{
                type: Input
            }] } });
class DxoCardViewColumnChooserModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewColumnChooserModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewColumnChooserModule, imports: [DxoCardViewColumnChooserComponent], exports: [DxoCardViewColumnChooserComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewColumnChooserModule, imports: [DxoCardViewColumnChooserComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewColumnChooserModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoCardViewColumnChooserComponent
                    ],
                    exports: [
                        DxoCardViewColumnChooserComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxiCardViewColumnComponent extends CollectionNestedOption {
    set _validationRulesContentChildren(value) {
        this.setChildren('validationRules', value);
    }
    get alignment() {
        return this._getOption('alignment');
    }
    set alignment(value) {
        this._setOption('alignment', value);
    }
    get allowEditing() {
        return this._getOption('allowEditing');
    }
    set allowEditing(value) {
        this._setOption('allowEditing', value);
    }
    get allowFiltering() {
        return this._getOption('allowFiltering');
    }
    set allowFiltering(value) {
        this._setOption('allowFiltering', value);
    }
    get allowHeaderFiltering() {
        return this._getOption('allowHeaderFiltering');
    }
    set allowHeaderFiltering(value) {
        this._setOption('allowHeaderFiltering', value);
    }
    get allowHiding() {
        return this._getOption('allowHiding');
    }
    set allowHiding(value) {
        this._setOption('allowHiding', value);
    }
    get allowReordering() {
        return this._getOption('allowReordering');
    }
    set allowReordering(value) {
        this._setOption('allowReordering', value);
    }
    get allowSearch() {
        return this._getOption('allowSearch');
    }
    set allowSearch(value) {
        this._setOption('allowSearch', value);
    }
    get allowSorting() {
        return this._getOption('allowSorting');
    }
    set allowSorting(value) {
        this._setOption('allowSorting', value);
    }
    get calculateDisplayValue() {
        return this._getOption('calculateDisplayValue');
    }
    set calculateDisplayValue(value) {
        this._setOption('calculateDisplayValue', value);
    }
    get calculateFieldValue() {
        return this._getOption('calculateFieldValue');
    }
    set calculateFieldValue(value) {
        this._setOption('calculateFieldValue', value);
    }
    get calculateFilterExpression() {
        return this._getOption('calculateFilterExpression');
    }
    set calculateFilterExpression(value) {
        this._setOption('calculateFilterExpression', value);
    }
    get calculateSortValue() {
        return this._getOption('calculateSortValue');
    }
    set calculateSortValue(value) {
        this._setOption('calculateSortValue', value);
    }
    get caption() {
        return this._getOption('caption');
    }
    set caption(value) {
        this._setOption('caption', value);
    }
    get customizeText() {
        return this._getOption('customizeText');
    }
    set customizeText(value) {
        this._setOption('customizeText', value);
    }
    get dataField() {
        return this._getOption('dataField');
    }
    set dataField(value) {
        this._setOption('dataField', value);
    }
    get dataType() {
        return this._getOption('dataType');
    }
    set dataType(value) {
        this._setOption('dataType', value);
    }
    get editorOptions() {
        return this._getOption('editorOptions');
    }
    set editorOptions(value) {
        this._setOption('editorOptions', value);
    }
    get falseText() {
        return this._getOption('falseText');
    }
    set falseText(value) {
        this._setOption('falseText', value);
    }
    get fieldCaptionTemplate() {
        return this._getOption('fieldCaptionTemplate');
    }
    set fieldCaptionTemplate(value) {
        this._setOption('fieldCaptionTemplate', value);
    }
    get fieldTemplate() {
        return this._getOption('fieldTemplate');
    }
    set fieldTemplate(value) {
        this._setOption('fieldTemplate', value);
    }
    get fieldValueTemplate() {
        return this._getOption('fieldValueTemplate');
    }
    set fieldValueTemplate(value) {
        this._setOption('fieldValueTemplate', value);
    }
    get filterType() {
        return this._getOption('filterType');
    }
    set filterType(value) {
        this._setOption('filterType', value);
    }
    get filterValue() {
        return this._getOption('filterValue');
    }
    set filterValue(value) {
        this._setOption('filterValue', value);
    }
    get filterValues() {
        return this._getOption('filterValues');
    }
    set filterValues(value) {
        this._setOption('filterValues', value);
    }
    get format() {
        return this._getOption('format');
    }
    set format(value) {
        this._setOption('format', value);
    }
    get formItem() {
        return this._getOption('formItem');
    }
    set formItem(value) {
        this._setOption('formItem', value);
    }
    get headerFilter() {
        return this._getOption('headerFilter');
    }
    set headerFilter(value) {
        this._setOption('headerFilter', value);
    }
    get headerItemCssClass() {
        return this._getOption('headerItemCssClass');
    }
    set headerItemCssClass(value) {
        this._setOption('headerItemCssClass', value);
    }
    get headerItemTemplate() {
        return this._getOption('headerItemTemplate');
    }
    set headerItemTemplate(value) {
        this._setOption('headerItemTemplate', value);
    }
    get name() {
        return this._getOption('name');
    }
    set name(value) {
        this._setOption('name', value);
    }
    get setFieldValue() {
        return this._getOption('setFieldValue');
    }
    set setFieldValue(value) {
        this._setOption('setFieldValue', value);
    }
    get showInColumnChooser() {
        return this._getOption('showInColumnChooser');
    }
    set showInColumnChooser(value) {
        this._setOption('showInColumnChooser', value);
    }
    get sortIndex() {
        return this._getOption('sortIndex');
    }
    set sortIndex(value) {
        this._setOption('sortIndex', value);
    }
    get sortingMethod() {
        return this._getOption('sortingMethod');
    }
    set sortingMethod(value) {
        this._setOption('sortingMethod', value);
    }
    get sortOrder() {
        return this._getOption('sortOrder');
    }
    set sortOrder(value) {
        this._setOption('sortOrder', value);
    }
    get trueText() {
        return this._getOption('trueText');
    }
    set trueText(value) {
        this._setOption('trueText', value);
    }
    get validationRules() {
        return this._getOption('validationRules');
    }
    set validationRules(value) {
        this._setOption('validationRules', value);
    }
    get visible() {
        return this._getOption('visible');
    }
    set visible(value) {
        this._setOption('visible', value);
    }
    get visibleIndex() {
        return this._getOption('visibleIndex');
    }
    set visibleIndex(value) {
        this._setOption('visibleIndex', value);
    }
    get _optionPath() {
        return 'columns';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        this._createEventEmitters([
            { emit: 'filterValueChange' },
            { emit: 'filterValuesChange' },
            { emit: 'sortIndexChange' },
            { emit: 'sortOrderChange' },
            { emit: 'visibleChange' },
            { emit: 'visibleIndexChange' }
        ]);
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnDestroy() {
        this._deleteRemovedOptions(this._fullOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiCardViewColumnComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxiCardViewColumnComponent, isStandalone: true, selector: "dxi-card-view-column", inputs: { alignment: "alignment", allowEditing: "allowEditing", allowFiltering: "allowFiltering", allowHeaderFiltering: "allowHeaderFiltering", allowHiding: "allowHiding", allowReordering: "allowReordering", allowSearch: "allowSearch", allowSorting: "allowSorting", calculateDisplayValue: "calculateDisplayValue", calculateFieldValue: "calculateFieldValue", calculateFilterExpression: "calculateFilterExpression", calculateSortValue: "calculateSortValue", caption: "caption", customizeText: "customizeText", dataField: "dataField", dataType: "dataType", editorOptions: "editorOptions", falseText: "falseText", fieldCaptionTemplate: "fieldCaptionTemplate", fieldTemplate: "fieldTemplate", fieldValueTemplate: "fieldValueTemplate", filterType: "filterType", filterValue: "filterValue", filterValues: "filterValues", format: "format", formItem: "formItem", headerFilter: "headerFilter", headerItemCssClass: "headerItemCssClass", headerItemTemplate: "headerItemTemplate", name: "name", setFieldValue: "setFieldValue", showInColumnChooser: "showInColumnChooser", sortIndex: "sortIndex", sortingMethod: "sortingMethod", sortOrder: "sortOrder", trueText: "trueText", validationRules: "validationRules", visible: "visible", visibleIndex: "visibleIndex" }, outputs: { filterValueChange: "filterValueChange", filterValuesChange: "filterValuesChange", sortIndexChange: "sortIndexChange", sortOrderChange: "sortOrderChange", visibleChange: "visibleChange", visibleIndexChange: "visibleIndexChange" }, providers: [
            NestedOptionHost,
            {
                provide: PROPERTY_TOKEN_columns,
                useExisting: DxiCardViewColumnComponent,
            }
        ], queries: [{ propertyName: "_validationRulesContentChildren", predicate: PROPERTY_TOKEN_validationRules }], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiCardViewColumnComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxi-card-view-column', template: '', imports: [DxIntegrationModule], providers: [
                        NestedOptionHost,
                        {
                            provide: PROPERTY_TOKEN_columns,
                            useExisting: DxiCardViewColumnComponent,
                        }
                    ] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { _validationRulesContentChildren: [{
                type: ContentChildren,
                args: [PROPERTY_TOKEN_validationRules]
            }], alignment: [{
                type: Input
            }], allowEditing: [{
                type: Input
            }], allowFiltering: [{
                type: Input
            }], allowHeaderFiltering: [{
                type: Input
            }], allowHiding: [{
                type: Input
            }], allowReordering: [{
                type: Input
            }], allowSearch: [{
                type: Input
            }], allowSorting: [{
                type: Input
            }], calculateDisplayValue: [{
                type: Input
            }], calculateFieldValue: [{
                type: Input
            }], calculateFilterExpression: [{
                type: Input
            }], calculateSortValue: [{
                type: Input
            }], caption: [{
                type: Input
            }], customizeText: [{
                type: Input
            }], dataField: [{
                type: Input
            }], dataType: [{
                type: Input
            }], editorOptions: [{
                type: Input
            }], falseText: [{
                type: Input
            }], fieldCaptionTemplate: [{
                type: Input
            }], fieldTemplate: [{
                type: Input
            }], fieldValueTemplate: [{
                type: Input
            }], filterType: [{
                type: Input
            }], filterValue: [{
                type: Input
            }], filterValues: [{
                type: Input
            }], format: [{
                type: Input
            }], formItem: [{
                type: Input
            }], headerFilter: [{
                type: Input
            }], headerItemCssClass: [{
                type: Input
            }], headerItemTemplate: [{
                type: Input
            }], name: [{
                type: Input
            }], setFieldValue: [{
                type: Input
            }], showInColumnChooser: [{
                type: Input
            }], sortIndex: [{
                type: Input
            }], sortingMethod: [{
                type: Input
            }], sortOrder: [{
                type: Input
            }], trueText: [{
                type: Input
            }], validationRules: [{
                type: Input
            }], visible: [{
                type: Input
            }], visibleIndex: [{
                type: Input
            }], filterValueChange: [{
                type: Output
            }], filterValuesChange: [{
                type: Output
            }], sortIndexChange: [{
                type: Output
            }], sortOrderChange: [{
                type: Output
            }], visibleChange: [{
                type: Output
            }], visibleIndexChange: [{
                type: Output
            }] } });
class DxiCardViewColumnModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiCardViewColumnModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxiCardViewColumnModule, imports: [DxiCardViewColumnComponent], exports: [DxiCardViewColumnComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiCardViewColumnModule, imports: [DxiCardViewColumnComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiCardViewColumnModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxiCardViewColumnComponent
                    ],
                    exports: [
                        DxiCardViewColumnComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoCardViewColumnHeaderFilterSearchComponent extends NestedOption {
    get editorOptions() {
        return this._getOption('editorOptions');
    }
    set editorOptions(value) {
        this._setOption('editorOptions', value);
    }
    get enabled() {
        return this._getOption('enabled');
    }
    set enabled(value) {
        this._setOption('enabled', value);
    }
    get mode() {
        return this._getOption('mode');
    }
    set mode(value) {
        this._setOption('mode', value);
    }
    get searchExpr() {
        return this._getOption('searchExpr');
    }
    set searchExpr(value) {
        this._setOption('searchExpr', value);
    }
    get timeout() {
        return this._getOption('timeout');
    }
    set timeout(value) {
        this._setOption('timeout', value);
    }
    get _optionPath() {
        return 'search';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewColumnHeaderFilterSearchComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoCardViewColumnHeaderFilterSearchComponent, isStandalone: true, selector: "dxo-card-view-column-header-filter-search", inputs: { editorOptions: "editorOptions", enabled: "enabled", mode: "mode", searchExpr: "searchExpr", timeout: "timeout" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewColumnHeaderFilterSearchComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-card-view-column-header-filter-search', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { editorOptions: [{
                type: Input
            }], enabled: [{
                type: Input
            }], mode: [{
                type: Input
            }], searchExpr: [{
                type: Input
            }], timeout: [{
                type: Input
            }] } });
class DxoCardViewColumnHeaderFilterSearchModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewColumnHeaderFilterSearchModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewColumnHeaderFilterSearchModule, imports: [DxoCardViewColumnHeaderFilterSearchComponent], exports: [DxoCardViewColumnHeaderFilterSearchComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewColumnHeaderFilterSearchModule, imports: [DxoCardViewColumnHeaderFilterSearchComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewColumnHeaderFilterSearchModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoCardViewColumnHeaderFilterSearchComponent
                    ],
                    exports: [
                        DxoCardViewColumnHeaderFilterSearchComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoCardViewColumnHeaderFilterComponent extends NestedOption {
    get allowSearch() {
        return this._getOption('allowSearch');
    }
    set allowSearch(value) {
        this._setOption('allowSearch', value);
    }
    get allowSelectAll() {
        return this._getOption('allowSelectAll');
    }
    set allowSelectAll(value) {
        this._setOption('allowSelectAll', value);
    }
    get dataSource() {
        return this._getOption('dataSource');
    }
    set dataSource(value) {
        this._setOption('dataSource', value);
    }
    get groupInterval() {
        return this._getOption('groupInterval');
    }
    set groupInterval(value) {
        this._setOption('groupInterval', value);
    }
    get height() {
        return this._getOption('height');
    }
    set height(value) {
        this._setOption('height', value);
    }
    get search() {
        return this._getOption('search');
    }
    set search(value) {
        this._setOption('search', value);
    }
    get searchMode() {
        return this._getOption('searchMode');
    }
    set searchMode(value) {
        this._setOption('searchMode', value);
    }
    get width() {
        return this._getOption('width');
    }
    set width(value) {
        this._setOption('width', value);
    }
    get _optionPath() {
        return 'headerFilter';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewColumnHeaderFilterComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoCardViewColumnHeaderFilterComponent, isStandalone: true, selector: "dxo-card-view-column-header-filter", inputs: { allowSearch: "allowSearch", allowSelectAll: "allowSelectAll", dataSource: "dataSource", groupInterval: "groupInterval", height: "height", search: "search", searchMode: "searchMode", width: "width" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewColumnHeaderFilterComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-card-view-column-header-filter', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { allowSearch: [{
                type: Input
            }], allowSelectAll: [{
                type: Input
            }], dataSource: [{
                type: Input
            }], groupInterval: [{
                type: Input
            }], height: [{
                type: Input
            }], search: [{
                type: Input
            }], searchMode: [{
                type: Input
            }], width: [{
                type: Input
            }] } });
class DxoCardViewColumnHeaderFilterModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewColumnHeaderFilterModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewColumnHeaderFilterModule, imports: [DxoCardViewColumnHeaderFilterComponent], exports: [DxoCardViewColumnHeaderFilterComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewColumnHeaderFilterModule, imports: [DxoCardViewColumnHeaderFilterComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewColumnHeaderFilterModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoCardViewColumnHeaderFilterComponent
                    ],
                    exports: [
                        DxoCardViewColumnHeaderFilterComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxiCardViewCompareRuleComponent extends CollectionNestedOption {
    get comparisonTarget() {
        return this._getOption('comparisonTarget');
    }
    set comparisonTarget(value) {
        this._setOption('comparisonTarget', value);
    }
    get comparisonType() {
        return this._getOption('comparisonType');
    }
    set comparisonType(value) {
        this._setOption('comparisonType', value);
    }
    get ignoreEmptyValue() {
        return this._getOption('ignoreEmptyValue');
    }
    set ignoreEmptyValue(value) {
        this._setOption('ignoreEmptyValue', value);
    }
    get message() {
        return this._getOption('message');
    }
    set message(value) {
        this._setOption('message', value);
    }
    get type() {
        return this._getOption('type');
    }
    set type(value) {
        this._setOption('type', value);
    }
    get _optionPath() {
        return 'validationRules';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
        this.type = 'compare';
    }
    ngOnDestroy() {
        this._deleteRemovedOptions(this._fullOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiCardViewCompareRuleComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxiCardViewCompareRuleComponent, isStandalone: true, selector: "dxi-card-view-compare-rule", inputs: { comparisonTarget: "comparisonTarget", comparisonType: "comparisonType", ignoreEmptyValue: "ignoreEmptyValue", message: "message", type: "type" }, providers: [
            NestedOptionHost,
            {
                provide: PROPERTY_TOKEN_validationRules,
                useExisting: DxiCardViewCompareRuleComponent,
            }
        ], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiCardViewCompareRuleComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxi-card-view-compare-rule', template: '', imports: [DxIntegrationModule], providers: [
                        NestedOptionHost,
                        {
                            provide: PROPERTY_TOKEN_validationRules,
                            useExisting: DxiCardViewCompareRuleComponent,
                        }
                    ] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { comparisonTarget: [{
                type: Input
            }], comparisonType: [{
                type: Input
            }], ignoreEmptyValue: [{
                type: Input
            }], message: [{
                type: Input
            }], type: [{
                type: Input
            }] } });
class DxiCardViewCompareRuleModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiCardViewCompareRuleModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxiCardViewCompareRuleModule, imports: [DxiCardViewCompareRuleComponent], exports: [DxiCardViewCompareRuleComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiCardViewCompareRuleModule, imports: [DxiCardViewCompareRuleComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiCardViewCompareRuleModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxiCardViewCompareRuleComponent
                    ],
                    exports: [
                        DxiCardViewCompareRuleComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxiCardViewCustomOperationComponent extends CollectionNestedOption {
    get calculateFilterExpression() {
        return this._getOption('calculateFilterExpression');
    }
    set calculateFilterExpression(value) {
        this._setOption('calculateFilterExpression', value);
    }
    get caption() {
        return this._getOption('caption');
    }
    set caption(value) {
        this._setOption('caption', value);
    }
    get customizeText() {
        return this._getOption('customizeText');
    }
    set customizeText(value) {
        this._setOption('customizeText', value);
    }
    get dataTypes() {
        return this._getOption('dataTypes');
    }
    set dataTypes(value) {
        this._setOption('dataTypes', value);
    }
    get editorTemplate() {
        return this._getOption('editorTemplate');
    }
    set editorTemplate(value) {
        this._setOption('editorTemplate', value);
    }
    get hasValue() {
        return this._getOption('hasValue');
    }
    set hasValue(value) {
        this._setOption('hasValue', value);
    }
    get icon() {
        return this._getOption('icon');
    }
    set icon(value) {
        this._setOption('icon', value);
    }
    get name() {
        return this._getOption('name');
    }
    set name(value) {
        this._setOption('name', value);
    }
    get _optionPath() {
        return 'customOperations';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnDestroy() {
        this._deleteRemovedOptions(this._fullOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiCardViewCustomOperationComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxiCardViewCustomOperationComponent, isStandalone: true, selector: "dxi-card-view-custom-operation", inputs: { calculateFilterExpression: "calculateFilterExpression", caption: "caption", customizeText: "customizeText", dataTypes: "dataTypes", editorTemplate: "editorTemplate", hasValue: "hasValue", icon: "icon", name: "name" }, providers: [
            NestedOptionHost,
            {
                provide: PROPERTY_TOKEN_customOperations,
                useExisting: DxiCardViewCustomOperationComponent,
            }
        ], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiCardViewCustomOperationComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxi-card-view-custom-operation', template: '', imports: [DxIntegrationModule], providers: [
                        NestedOptionHost,
                        {
                            provide: PROPERTY_TOKEN_customOperations,
                            useExisting: DxiCardViewCustomOperationComponent,
                        }
                    ] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { calculateFilterExpression: [{
                type: Input
            }], caption: [{
                type: Input
            }], customizeText: [{
                type: Input
            }], dataTypes: [{
                type: Input
            }], editorTemplate: [{
                type: Input
            }], hasValue: [{
                type: Input
            }], icon: [{
                type: Input
            }], name: [{
                type: Input
            }] } });
class DxiCardViewCustomOperationModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiCardViewCustomOperationModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxiCardViewCustomOperationModule, imports: [DxiCardViewCustomOperationComponent], exports: [DxiCardViewCustomOperationComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiCardViewCustomOperationModule, imports: [DxiCardViewCustomOperationComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiCardViewCustomOperationModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxiCardViewCustomOperationComponent
                    ],
                    exports: [
                        DxiCardViewCustomOperationComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxiCardViewCustomRuleComponent extends CollectionNestedOption {
    get ignoreEmptyValue() {
        return this._getOption('ignoreEmptyValue');
    }
    set ignoreEmptyValue(value) {
        this._setOption('ignoreEmptyValue', value);
    }
    get message() {
        return this._getOption('message');
    }
    set message(value) {
        this._setOption('message', value);
    }
    get reevaluate() {
        return this._getOption('reevaluate');
    }
    set reevaluate(value) {
        this._setOption('reevaluate', value);
    }
    get type() {
        return this._getOption('type');
    }
    set type(value) {
        this._setOption('type', value);
    }
    get validationCallback() {
        return this._getOption('validationCallback');
    }
    set validationCallback(value) {
        this._setOption('validationCallback', value);
    }
    get _optionPath() {
        return 'validationRules';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
        this.type = 'custom';
    }
    ngOnDestroy() {
        this._deleteRemovedOptions(this._fullOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiCardViewCustomRuleComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxiCardViewCustomRuleComponent, isStandalone: true, selector: "dxi-card-view-custom-rule", inputs: { ignoreEmptyValue: "ignoreEmptyValue", message: "message", reevaluate: "reevaluate", type: "type", validationCallback: "validationCallback" }, providers: [
            NestedOptionHost,
            {
                provide: PROPERTY_TOKEN_validationRules,
                useExisting: DxiCardViewCustomRuleComponent,
            }
        ], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiCardViewCustomRuleComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxi-card-view-custom-rule', template: '', imports: [DxIntegrationModule], providers: [
                        NestedOptionHost,
                        {
                            provide: PROPERTY_TOKEN_validationRules,
                            useExisting: DxiCardViewCustomRuleComponent,
                        }
                    ] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { ignoreEmptyValue: [{
                type: Input
            }], message: [{
                type: Input
            }], reevaluate: [{
                type: Input
            }], type: [{
                type: Input
            }], validationCallback: [{
                type: Input
            }] } });
class DxiCardViewCustomRuleModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiCardViewCustomRuleModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxiCardViewCustomRuleModule, imports: [DxiCardViewCustomRuleComponent], exports: [DxiCardViewCustomRuleComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiCardViewCustomRuleModule, imports: [DxiCardViewCustomRuleComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiCardViewCustomRuleModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxiCardViewCustomRuleComponent
                    ],
                    exports: [
                        DxiCardViewCustomRuleComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoCardViewDraggingComponent extends NestedOption {
    get dropFeedbackMode() {
        return this._getOption('dropFeedbackMode');
    }
    set dropFeedbackMode(value) {
        this._setOption('dropFeedbackMode', value);
    }
    get onDragChange() {
        return this._getOption('onDragChange');
    }
    set onDragChange(value) {
        this._setOption('onDragChange', value);
    }
    get onDragEnd() {
        return this._getOption('onDragEnd');
    }
    set onDragEnd(value) {
        this._setOption('onDragEnd', value);
    }
    get onDragMove() {
        return this._getOption('onDragMove');
    }
    set onDragMove(value) {
        this._setOption('onDragMove', value);
    }
    get onDragStart() {
        return this._getOption('onDragStart');
    }
    set onDragStart(value) {
        this._setOption('onDragStart', value);
    }
    get onRemove() {
        return this._getOption('onRemove');
    }
    set onRemove(value) {
        this._setOption('onRemove', value);
    }
    get onReorder() {
        return this._getOption('onReorder');
    }
    set onReorder(value) {
        this._setOption('onReorder', value);
    }
    get scrollSensitivity() {
        return this._getOption('scrollSensitivity');
    }
    set scrollSensitivity(value) {
        this._setOption('scrollSensitivity', value);
    }
    get scrollSpeed() {
        return this._getOption('scrollSpeed');
    }
    set scrollSpeed(value) {
        this._setOption('scrollSpeed', value);
    }
    get _optionPath() {
        return 'dragging';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewDraggingComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoCardViewDraggingComponent, isStandalone: true, selector: "dxo-card-view-dragging", inputs: { dropFeedbackMode: "dropFeedbackMode", onDragChange: "onDragChange", onDragEnd: "onDragEnd", onDragMove: "onDragMove", onDragStart: "onDragStart", onRemove: "onRemove", onReorder: "onReorder", scrollSensitivity: "scrollSensitivity", scrollSpeed: "scrollSpeed" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewDraggingComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-card-view-dragging', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { dropFeedbackMode: [{
                type: Input
            }], onDragChange: [{
                type: Input
            }], onDragEnd: [{
                type: Input
            }], onDragMove: [{
                type: Input
            }], onDragStart: [{
                type: Input
            }], onRemove: [{
                type: Input
            }], onReorder: [{
                type: Input
            }], scrollSensitivity: [{
                type: Input
            }], scrollSpeed: [{
                type: Input
            }] } });
class DxoCardViewDraggingModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewDraggingModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewDraggingModule, imports: [DxoCardViewDraggingComponent], exports: [DxoCardViewDraggingComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewDraggingModule, imports: [DxoCardViewDraggingComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewDraggingModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoCardViewDraggingComponent
                    ],
                    exports: [
                        DxoCardViewDraggingComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoCardViewEditingTextsComponent extends NestedOption {
    get addCard() {
        return this._getOption('addCard');
    }
    set addCard(value) {
        this._setOption('addCard', value);
    }
    get confirmDeleteMessage() {
        return this._getOption('confirmDeleteMessage');
    }
    set confirmDeleteMessage(value) {
        this._setOption('confirmDeleteMessage', value);
    }
    get confirmDeleteTitle() {
        return this._getOption('confirmDeleteTitle');
    }
    set confirmDeleteTitle(value) {
        this._setOption('confirmDeleteTitle', value);
    }
    get deleteCard() {
        return this._getOption('deleteCard');
    }
    set deleteCard(value) {
        this._setOption('deleteCard', value);
    }
    get editCard() {
        return this._getOption('editCard');
    }
    set editCard(value) {
        this._setOption('editCard', value);
    }
    get saveCard() {
        return this._getOption('saveCard');
    }
    set saveCard(value) {
        this._setOption('saveCard', value);
    }
    get _optionPath() {
        return 'texts';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewEditingTextsComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoCardViewEditingTextsComponent, isStandalone: true, selector: "dxo-card-view-editing-texts", inputs: { addCard: "addCard", confirmDeleteMessage: "confirmDeleteMessage", confirmDeleteTitle: "confirmDeleteTitle", deleteCard: "deleteCard", editCard: "editCard", saveCard: "saveCard" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewEditingTextsComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-card-view-editing-texts', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { addCard: [{
                type: Input
            }], confirmDeleteMessage: [{
                type: Input
            }], confirmDeleteTitle: [{
                type: Input
            }], deleteCard: [{
                type: Input
            }], editCard: [{
                type: Input
            }], saveCard: [{
                type: Input
            }] } });
class DxoCardViewEditingTextsModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewEditingTextsModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewEditingTextsModule, imports: [DxoCardViewEditingTextsComponent], exports: [DxoCardViewEditingTextsComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewEditingTextsModule, imports: [DxoCardViewEditingTextsComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewEditingTextsModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoCardViewEditingTextsComponent
                    ],
                    exports: [
                        DxoCardViewEditingTextsComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoCardViewEditingComponent extends NestedOption {
    set _changesContentChildren(value) {
        this.setChildren('changes', value);
    }
    get allowAdding() {
        return this._getOption('allowAdding');
    }
    set allowAdding(value) {
        this._setOption('allowAdding', value);
    }
    get allowDeleting() {
        return this._getOption('allowDeleting');
    }
    set allowDeleting(value) {
        this._setOption('allowDeleting', value);
    }
    get allowUpdating() {
        return this._getOption('allowUpdating');
    }
    set allowUpdating(value) {
        this._setOption('allowUpdating', value);
    }
    get changes() {
        return this._getOption('changes');
    }
    set changes(value) {
        this._setOption('changes', value);
    }
    get confirmDelete() {
        return this._getOption('confirmDelete');
    }
    set confirmDelete(value) {
        this._setOption('confirmDelete', value);
    }
    get editCardKey() {
        return this._getOption('editCardKey');
    }
    set editCardKey(value) {
        this._setOption('editCardKey', value);
    }
    get form() {
        return this._getOption('form');
    }
    set form(value) {
        this._setOption('form', value);
    }
    get popup() {
        return this._getOption('popup');
    }
    set popup(value) {
        this._setOption('popup', value);
    }
    get texts() {
        return this._getOption('texts');
    }
    set texts(value) {
        this._setOption('texts', value);
    }
    get _optionPath() {
        return 'editing';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewEditingComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoCardViewEditingComponent, isStandalone: true, selector: "dxo-card-view-editing", inputs: { allowAdding: "allowAdding", allowDeleting: "allowDeleting", allowUpdating: "allowUpdating", changes: "changes", confirmDelete: "confirmDelete", editCardKey: "editCardKey", form: "form", popup: "popup", texts: "texts" }, providers: [NestedOptionHost], queries: [{ propertyName: "_changesContentChildren", predicate: PROPERTY_TOKEN_changes }], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewEditingComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-card-view-editing', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { _changesContentChildren: [{
                type: ContentChildren,
                args: [PROPERTY_TOKEN_changes]
            }], allowAdding: [{
                type: Input
            }], allowDeleting: [{
                type: Input
            }], allowUpdating: [{
                type: Input
            }], changes: [{
                type: Input
            }], confirmDelete: [{
                type: Input
            }], editCardKey: [{
                type: Input
            }], form: [{
                type: Input
            }], popup: [{
                type: Input
            }], texts: [{
                type: Input
            }] } });
class DxoCardViewEditingModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewEditingModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewEditingModule, imports: [DxoCardViewEditingComponent], exports: [DxoCardViewEditingComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewEditingModule, imports: [DxoCardViewEditingComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewEditingModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoCardViewEditingComponent
                    ],
                    exports: [
                        DxoCardViewEditingComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxiCardViewEmailRuleComponent extends CollectionNestedOption {
    get ignoreEmptyValue() {
        return this._getOption('ignoreEmptyValue');
    }
    set ignoreEmptyValue(value) {
        this._setOption('ignoreEmptyValue', value);
    }
    get message() {
        return this._getOption('message');
    }
    set message(value) {
        this._setOption('message', value);
    }
    get type() {
        return this._getOption('type');
    }
    set type(value) {
        this._setOption('type', value);
    }
    get _optionPath() {
        return 'validationRules';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
        this.type = 'email';
    }
    ngOnDestroy() {
        this._deleteRemovedOptions(this._fullOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiCardViewEmailRuleComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxiCardViewEmailRuleComponent, isStandalone: true, selector: "dxi-card-view-email-rule", inputs: { ignoreEmptyValue: "ignoreEmptyValue", message: "message", type: "type" }, providers: [
            NestedOptionHost,
            {
                provide: PROPERTY_TOKEN_validationRules,
                useExisting: DxiCardViewEmailRuleComponent,
            }
        ], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiCardViewEmailRuleComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxi-card-view-email-rule', template: '', imports: [DxIntegrationModule], providers: [
                        NestedOptionHost,
                        {
                            provide: PROPERTY_TOKEN_validationRules,
                            useExisting: DxiCardViewEmailRuleComponent,
                        }
                    ] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { ignoreEmptyValue: [{
                type: Input
            }], message: [{
                type: Input
            }], type: [{
                type: Input
            }] } });
class DxiCardViewEmailRuleModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiCardViewEmailRuleModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxiCardViewEmailRuleModule, imports: [DxiCardViewEmailRuleComponent], exports: [DxiCardViewEmailRuleComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiCardViewEmailRuleModule, imports: [DxiCardViewEmailRuleComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiCardViewEmailRuleModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxiCardViewEmailRuleComponent
                    ],
                    exports: [
                        DxiCardViewEmailRuleComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxiCardViewEmptyItemComponent extends CollectionNestedOption {
    get colSpan() {
        return this._getOption('colSpan');
    }
    set colSpan(value) {
        this._setOption('colSpan', value);
    }
    get cssClass() {
        return this._getOption('cssClass');
    }
    set cssClass(value) {
        this._setOption('cssClass', value);
    }
    get itemType() {
        return this._getOption('itemType');
    }
    set itemType(value) {
        this._setOption('itemType', value);
    }
    get name() {
        return this._getOption('name');
    }
    set name(value) {
        this._setOption('name', value);
    }
    get visible() {
        return this._getOption('visible');
    }
    set visible(value) {
        this._setOption('visible', value);
    }
    get visibleIndex() {
        return this._getOption('visibleIndex');
    }
    set visibleIndex(value) {
        this._setOption('visibleIndex', value);
    }
    get _optionPath() {
        return 'items';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
        this.itemType = 'empty';
    }
    ngOnDestroy() {
        this._deleteRemovedOptions(this._fullOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiCardViewEmptyItemComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxiCardViewEmptyItemComponent, isStandalone: true, selector: "dxi-card-view-empty-item", inputs: { colSpan: "colSpan", cssClass: "cssClass", itemType: "itemType", name: "name", visible: "visible", visibleIndex: "visibleIndex" }, providers: [
            NestedOptionHost,
            {
                provide: PROPERTY_TOKEN_items,
                useExisting: DxiCardViewEmptyItemComponent,
            }
        ], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiCardViewEmptyItemComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxi-card-view-empty-item', template: '', imports: [DxIntegrationModule], providers: [
                        NestedOptionHost,
                        {
                            provide: PROPERTY_TOKEN_items,
                            useExisting: DxiCardViewEmptyItemComponent,
                        }
                    ] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { colSpan: [{
                type: Input
            }], cssClass: [{
                type: Input
            }], itemType: [{
                type: Input
            }], name: [{
                type: Input
            }], visible: [{
                type: Input
            }], visibleIndex: [{
                type: Input
            }] } });
class DxiCardViewEmptyItemModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiCardViewEmptyItemModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxiCardViewEmptyItemModule, imports: [DxiCardViewEmptyItemComponent], exports: [DxiCardViewEmptyItemComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiCardViewEmptyItemModule, imports: [DxiCardViewEmptyItemComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiCardViewEmptyItemModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxiCardViewEmptyItemComponent
                    ],
                    exports: [
                        DxiCardViewEmptyItemComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxiCardViewFieldComponent extends CollectionNestedOption {
    get calculateFilterExpression() {
        return this._getOption('calculateFilterExpression');
    }
    set calculateFilterExpression(value) {
        this._setOption('calculateFilterExpression', value);
    }
    get caption() {
        return this._getOption('caption');
    }
    set caption(value) {
        this._setOption('caption', value);
    }
    get customizeText() {
        return this._getOption('customizeText');
    }
    set customizeText(value) {
        this._setOption('customizeText', value);
    }
    get dataField() {
        return this._getOption('dataField');
    }
    set dataField(value) {
        this._setOption('dataField', value);
    }
    get dataType() {
        return this._getOption('dataType');
    }
    set dataType(value) {
        this._setOption('dataType', value);
    }
    get editorOptions() {
        return this._getOption('editorOptions');
    }
    set editorOptions(value) {
        this._setOption('editorOptions', value);
    }
    get editorTemplate() {
        return this._getOption('editorTemplate');
    }
    set editorTemplate(value) {
        this._setOption('editorTemplate', value);
    }
    get falseText() {
        return this._getOption('falseText');
    }
    set falseText(value) {
        this._setOption('falseText', value);
    }
    get filterOperations() {
        return this._getOption('filterOperations');
    }
    set filterOperations(value) {
        this._setOption('filterOperations', value);
    }
    get format() {
        return this._getOption('format');
    }
    set format(value) {
        this._setOption('format', value);
    }
    get lookup() {
        return this._getOption('lookup');
    }
    set lookup(value) {
        this._setOption('lookup', value);
    }
    get name() {
        return this._getOption('name');
    }
    set name(value) {
        this._setOption('name', value);
    }
    get trueText() {
        return this._getOption('trueText');
    }
    set trueText(value) {
        this._setOption('trueText', value);
    }
    get _optionPath() {
        return 'fields';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnDestroy() {
        this._deleteRemovedOptions(this._fullOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiCardViewFieldComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxiCardViewFieldComponent, isStandalone: true, selector: "dxi-card-view-field", inputs: { calculateFilterExpression: "calculateFilterExpression", caption: "caption", customizeText: "customizeText", dataField: "dataField", dataType: "dataType", editorOptions: "editorOptions", editorTemplate: "editorTemplate", falseText: "falseText", filterOperations: "filterOperations", format: "format", lookup: "lookup", name: "name", trueText: "trueText" }, providers: [
            NestedOptionHost,
            {
                provide: PROPERTY_TOKEN_fields,
                useExisting: DxiCardViewFieldComponent,
            }
        ], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiCardViewFieldComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxi-card-view-field', template: '', imports: [DxIntegrationModule], providers: [
                        NestedOptionHost,
                        {
                            provide: PROPERTY_TOKEN_fields,
                            useExisting: DxiCardViewFieldComponent,
                        }
                    ] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { calculateFilterExpression: [{
                type: Input
            }], caption: [{
                type: Input
            }], customizeText: [{
                type: Input
            }], dataField: [{
                type: Input
            }], dataType: [{
                type: Input
            }], editorOptions: [{
                type: Input
            }], editorTemplate: [{
                type: Input
            }], falseText: [{
                type: Input
            }], filterOperations: [{
                type: Input
            }], format: [{
                type: Input
            }], lookup: [{
                type: Input
            }], name: [{
                type: Input
            }], trueText: [{
                type: Input
            }] } });
class DxiCardViewFieldModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiCardViewFieldModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxiCardViewFieldModule, imports: [DxiCardViewFieldComponent], exports: [DxiCardViewFieldComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiCardViewFieldModule, imports: [DxiCardViewFieldComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiCardViewFieldModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxiCardViewFieldComponent
                    ],
                    exports: [
                        DxiCardViewFieldComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoCardViewFilterBuilderComponent extends NestedOption {
    set _customOperationsContentChildren(value) {
        this.setChildren('customOperations', value);
    }
    set _fieldsContentChildren(value) {
        this.setChildren('fields', value);
    }
    get accessKey() {
        return this._getOption('accessKey');
    }
    set accessKey(value) {
        this._setOption('accessKey', value);
    }
    get activeStateEnabled() {
        return this._getOption('activeStateEnabled');
    }
    set activeStateEnabled(value) {
        this._setOption('activeStateEnabled', value);
    }
    get allowHierarchicalFields() {
        return this._getOption('allowHierarchicalFields');
    }
    set allowHierarchicalFields(value) {
        this._setOption('allowHierarchicalFields', value);
    }
    get customOperations() {
        return this._getOption('customOperations');
    }
    set customOperations(value) {
        this._setOption('customOperations', value);
    }
    get disabled() {
        return this._getOption('disabled');
    }
    set disabled(value) {
        this._setOption('disabled', value);
    }
    get elementAttr() {
        return this._getOption('elementAttr');
    }
    set elementAttr(value) {
        this._setOption('elementAttr', value);
    }
    get fields() {
        return this._getOption('fields');
    }
    set fields(value) {
        this._setOption('fields', value);
    }
    get filterOperationDescriptions() {
        return this._getOption('filterOperationDescriptions');
    }
    set filterOperationDescriptions(value) {
        this._setOption('filterOperationDescriptions', value);
    }
    get focusStateEnabled() {
        return this._getOption('focusStateEnabled');
    }
    set focusStateEnabled(value) {
        this._setOption('focusStateEnabled', value);
    }
    get groupOperationDescriptions() {
        return this._getOption('groupOperationDescriptions');
    }
    set groupOperationDescriptions(value) {
        this._setOption('groupOperationDescriptions', value);
    }
    get groupOperations() {
        return this._getOption('groupOperations');
    }
    set groupOperations(value) {
        this._setOption('groupOperations', value);
    }
    get height() {
        return this._getOption('height');
    }
    set height(value) {
        this._setOption('height', value);
    }
    get hint() {
        return this._getOption('hint');
    }
    set hint(value) {
        this._setOption('hint', value);
    }
    get hoverStateEnabled() {
        return this._getOption('hoverStateEnabled');
    }
    set hoverStateEnabled(value) {
        this._setOption('hoverStateEnabled', value);
    }
    get maxGroupLevel() {
        return this._getOption('maxGroupLevel');
    }
    set maxGroupLevel(value) {
        this._setOption('maxGroupLevel', value);
    }
    get onContentReady() {
        return this._getOption('onContentReady');
    }
    set onContentReady(value) {
        this._setOption('onContentReady', value);
    }
    get onDisposing() {
        return this._getOption('onDisposing');
    }
    set onDisposing(value) {
        this._setOption('onDisposing', value);
    }
    get onEditorPrepared() {
        return this._getOption('onEditorPrepared');
    }
    set onEditorPrepared(value) {
        this._setOption('onEditorPrepared', value);
    }
    get onEditorPreparing() {
        return this._getOption('onEditorPreparing');
    }
    set onEditorPreparing(value) {
        this._setOption('onEditorPreparing', value);
    }
    get onInitialized() {
        return this._getOption('onInitialized');
    }
    set onInitialized(value) {
        this._setOption('onInitialized', value);
    }
    get onOptionChanged() {
        return this._getOption('onOptionChanged');
    }
    set onOptionChanged(value) {
        this._setOption('onOptionChanged', value);
    }
    get onValueChanged() {
        return this._getOption('onValueChanged');
    }
    set onValueChanged(value) {
        this._setOption('onValueChanged', value);
    }
    get rtlEnabled() {
        return this._getOption('rtlEnabled');
    }
    set rtlEnabled(value) {
        this._setOption('rtlEnabled', value);
    }
    get tabIndex() {
        return this._getOption('tabIndex');
    }
    set tabIndex(value) {
        this._setOption('tabIndex', value);
    }
    get value() {
        return this._getOption('value');
    }
    set value(value) {
        this._setOption('value', value);
    }
    get visible() {
        return this._getOption('visible');
    }
    set visible(value) {
        this._setOption('visible', value);
    }
    get width() {
        return this._getOption('width');
    }
    set width(value) {
        this._setOption('width', value);
    }
    get _optionPath() {
        return 'filterBuilder';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        this._createEventEmitters([
            { emit: 'valueChange' }
        ]);
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewFilterBuilderComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoCardViewFilterBuilderComponent, isStandalone: true, selector: "dxo-card-view-filter-builder", inputs: { accessKey: "accessKey", activeStateEnabled: "activeStateEnabled", allowHierarchicalFields: "allowHierarchicalFields", customOperations: "customOperations", disabled: "disabled", elementAttr: "elementAttr", fields: "fields", filterOperationDescriptions: "filterOperationDescriptions", focusStateEnabled: "focusStateEnabled", groupOperationDescriptions: "groupOperationDescriptions", groupOperations: "groupOperations", height: "height", hint: "hint", hoverStateEnabled: "hoverStateEnabled", maxGroupLevel: "maxGroupLevel", onContentReady: "onContentReady", onDisposing: "onDisposing", onEditorPrepared: "onEditorPrepared", onEditorPreparing: "onEditorPreparing", onInitialized: "onInitialized", onOptionChanged: "onOptionChanged", onValueChanged: "onValueChanged", rtlEnabled: "rtlEnabled", tabIndex: "tabIndex", value: "value", visible: "visible", width: "width" }, outputs: { valueChange: "valueChange" }, providers: [NestedOptionHost], queries: [{ propertyName: "_customOperationsContentChildren", predicate: PROPERTY_TOKEN_customOperations }, { propertyName: "_fieldsContentChildren", predicate: PROPERTY_TOKEN_fields }], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewFilterBuilderComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-card-view-filter-builder', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { _customOperationsContentChildren: [{
                type: ContentChildren,
                args: [PROPERTY_TOKEN_customOperations]
            }], _fieldsContentChildren: [{
                type: ContentChildren,
                args: [PROPERTY_TOKEN_fields]
            }], accessKey: [{
                type: Input
            }], activeStateEnabled: [{
                type: Input
            }], allowHierarchicalFields: [{
                type: Input
            }], customOperations: [{
                type: Input
            }], disabled: [{
                type: Input
            }], elementAttr: [{
                type: Input
            }], fields: [{
                type: Input
            }], filterOperationDescriptions: [{
                type: Input
            }], focusStateEnabled: [{
                type: Input
            }], groupOperationDescriptions: [{
                type: Input
            }], groupOperations: [{
                type: Input
            }], height: [{
                type: Input
            }], hint: [{
                type: Input
            }], hoverStateEnabled: [{
                type: Input
            }], maxGroupLevel: [{
                type: Input
            }], onContentReady: [{
                type: Input
            }], onDisposing: [{
                type: Input
            }], onEditorPrepared: [{
                type: Input
            }], onEditorPreparing: [{
                type: Input
            }], onInitialized: [{
                type: Input
            }], onOptionChanged: [{
                type: Input
            }], onValueChanged: [{
                type: Input
            }], rtlEnabled: [{
                type: Input
            }], tabIndex: [{
                type: Input
            }], value: [{
                type: Input
            }], visible: [{
                type: Input
            }], width: [{
                type: Input
            }], valueChange: [{
                type: Output
            }] } });
class DxoCardViewFilterBuilderModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewFilterBuilderModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewFilterBuilderModule, imports: [DxoCardViewFilterBuilderComponent], exports: [DxoCardViewFilterBuilderComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewFilterBuilderModule, imports: [DxoCardViewFilterBuilderComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewFilterBuilderModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoCardViewFilterBuilderComponent
                    ],
                    exports: [
                        DxoCardViewFilterBuilderComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoCardViewFilterOperationDescriptionsComponent extends NestedOption {
    get between() {
        return this._getOption('between');
    }
    set between(value) {
        this._setOption('between', value);
    }
    get contains() {
        return this._getOption('contains');
    }
    set contains(value) {
        this._setOption('contains', value);
    }
    get endsWith() {
        return this._getOption('endsWith');
    }
    set endsWith(value) {
        this._setOption('endsWith', value);
    }
    get equal() {
        return this._getOption('equal');
    }
    set equal(value) {
        this._setOption('equal', value);
    }
    get greaterThan() {
        return this._getOption('greaterThan');
    }
    set greaterThan(value) {
        this._setOption('greaterThan', value);
    }
    get greaterThanOrEqual() {
        return this._getOption('greaterThanOrEqual');
    }
    set greaterThanOrEqual(value) {
        this._setOption('greaterThanOrEqual', value);
    }
    get isBlank() {
        return this._getOption('isBlank');
    }
    set isBlank(value) {
        this._setOption('isBlank', value);
    }
    get isNotBlank() {
        return this._getOption('isNotBlank');
    }
    set isNotBlank(value) {
        this._setOption('isNotBlank', value);
    }
    get lessThan() {
        return this._getOption('lessThan');
    }
    set lessThan(value) {
        this._setOption('lessThan', value);
    }
    get lessThanOrEqual() {
        return this._getOption('lessThanOrEqual');
    }
    set lessThanOrEqual(value) {
        this._setOption('lessThanOrEqual', value);
    }
    get notContains() {
        return this._getOption('notContains');
    }
    set notContains(value) {
        this._setOption('notContains', value);
    }
    get notEqual() {
        return this._getOption('notEqual');
    }
    set notEqual(value) {
        this._setOption('notEqual', value);
    }
    get startsWith() {
        return this._getOption('startsWith');
    }
    set startsWith(value) {
        this._setOption('startsWith', value);
    }
    get _optionPath() {
        return 'filterOperationDescriptions';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewFilterOperationDescriptionsComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoCardViewFilterOperationDescriptionsComponent, isStandalone: true, selector: "dxo-card-view-filter-operation-descriptions", inputs: { between: "between", contains: "contains", endsWith: "endsWith", equal: "equal", greaterThan: "greaterThan", greaterThanOrEqual: "greaterThanOrEqual", isBlank: "isBlank", isNotBlank: "isNotBlank", lessThan: "lessThan", lessThanOrEqual: "lessThanOrEqual", notContains: "notContains", notEqual: "notEqual", startsWith: "startsWith" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewFilterOperationDescriptionsComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-card-view-filter-operation-descriptions', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { between: [{
                type: Input
            }], contains: [{
                type: Input
            }], endsWith: [{
                type: Input
            }], equal: [{
                type: Input
            }], greaterThan: [{
                type: Input
            }], greaterThanOrEqual: [{
                type: Input
            }], isBlank: [{
                type: Input
            }], isNotBlank: [{
                type: Input
            }], lessThan: [{
                type: Input
            }], lessThanOrEqual: [{
                type: Input
            }], notContains: [{
                type: Input
            }], notEqual: [{
                type: Input
            }], startsWith: [{
                type: Input
            }] } });
class DxoCardViewFilterOperationDescriptionsModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewFilterOperationDescriptionsModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewFilterOperationDescriptionsModule, imports: [DxoCardViewFilterOperationDescriptionsComponent], exports: [DxoCardViewFilterOperationDescriptionsComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewFilterOperationDescriptionsModule, imports: [DxoCardViewFilterOperationDescriptionsComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewFilterOperationDescriptionsModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoCardViewFilterOperationDescriptionsComponent
                    ],
                    exports: [
                        DxoCardViewFilterOperationDescriptionsComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoCardViewFilterPanelTextsComponent extends NestedOption {
    get clearFilter() {
        return this._getOption('clearFilter');
    }
    set clearFilter(value) {
        this._setOption('clearFilter', value);
    }
    get createFilter() {
        return this._getOption('createFilter');
    }
    set createFilter(value) {
        this._setOption('createFilter', value);
    }
    get filterEnabledHint() {
        return this._getOption('filterEnabledHint');
    }
    set filterEnabledHint(value) {
        this._setOption('filterEnabledHint', value);
    }
    get _optionPath() {
        return 'texts';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewFilterPanelTextsComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoCardViewFilterPanelTextsComponent, isStandalone: true, selector: "dxo-card-view-filter-panel-texts", inputs: { clearFilter: "clearFilter", createFilter: "createFilter", filterEnabledHint: "filterEnabledHint" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewFilterPanelTextsComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-card-view-filter-panel-texts', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { clearFilter: [{
                type: Input
            }], createFilter: [{
                type: Input
            }], filterEnabledHint: [{
                type: Input
            }] } });
class DxoCardViewFilterPanelTextsModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewFilterPanelTextsModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewFilterPanelTextsModule, imports: [DxoCardViewFilterPanelTextsComponent], exports: [DxoCardViewFilterPanelTextsComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewFilterPanelTextsModule, imports: [DxoCardViewFilterPanelTextsComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewFilterPanelTextsModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoCardViewFilterPanelTextsComponent
                    ],
                    exports: [
                        DxoCardViewFilterPanelTextsComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoCardViewFilterPanelComponent extends NestedOption {
    get customizeText() {
        return this._getOption('customizeText');
    }
    set customizeText(value) {
        this._setOption('customizeText', value);
    }
    get filterEnabled() {
        return this._getOption('filterEnabled');
    }
    set filterEnabled(value) {
        this._setOption('filterEnabled', value);
    }
    get texts() {
        return this._getOption('texts');
    }
    set texts(value) {
        this._setOption('texts', value);
    }
    get visible() {
        return this._getOption('visible');
    }
    set visible(value) {
        this._setOption('visible', value);
    }
    get _optionPath() {
        return 'filterPanel';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        this._createEventEmitters([
            { emit: 'filterEnabledChange' }
        ]);
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewFilterPanelComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoCardViewFilterPanelComponent, isStandalone: true, selector: "dxo-card-view-filter-panel", inputs: { customizeText: "customizeText", filterEnabled: "filterEnabled", texts: "texts", visible: "visible" }, outputs: { filterEnabledChange: "filterEnabledChange" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewFilterPanelComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-card-view-filter-panel', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { customizeText: [{
                type: Input
            }], filterEnabled: [{
                type: Input
            }], texts: [{
                type: Input
            }], visible: [{
                type: Input
            }], filterEnabledChange: [{
                type: Output
            }] } });
class DxoCardViewFilterPanelModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewFilterPanelModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewFilterPanelModule, imports: [DxoCardViewFilterPanelComponent], exports: [DxoCardViewFilterPanelComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewFilterPanelModule, imports: [DxoCardViewFilterPanelComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewFilterPanelModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoCardViewFilterPanelComponent
                    ],
                    exports: [
                        DxoCardViewFilterPanelComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoCardViewFormItemComponent extends NestedOption {
    set _validationRulesContentChildren(value) {
        this.setChildren('validationRules', value);
    }
    get aiOptions() {
        return this._getOption('aiOptions');
    }
    set aiOptions(value) {
        this._setOption('aiOptions', value);
    }
    get colSpan() {
        return this._getOption('colSpan');
    }
    set colSpan(value) {
        this._setOption('colSpan', value);
    }
    get cssClass() {
        return this._getOption('cssClass');
    }
    set cssClass(value) {
        this._setOption('cssClass', value);
    }
    get dataField() {
        return this._getOption('dataField');
    }
    set dataField(value) {
        this._setOption('dataField', value);
    }
    get editorOptions() {
        return this._getOption('editorOptions');
    }
    set editorOptions(value) {
        this._setOption('editorOptions', value);
    }
    get editorType() {
        return this._getOption('editorType');
    }
    set editorType(value) {
        this._setOption('editorType', value);
    }
    get helpText() {
        return this._getOption('helpText');
    }
    set helpText(value) {
        this._setOption('helpText', value);
    }
    get isRequired() {
        return this._getOption('isRequired');
    }
    set isRequired(value) {
        this._setOption('isRequired', value);
    }
    get itemType() {
        return this._getOption('itemType');
    }
    set itemType(value) {
        this._setOption('itemType', value);
    }
    get label() {
        return this._getOption('label');
    }
    set label(value) {
        this._setOption('label', value);
    }
    get name() {
        return this._getOption('name');
    }
    set name(value) {
        this._setOption('name', value);
    }
    get template() {
        return this._getOption('template');
    }
    set template(value) {
        this._setOption('template', value);
    }
    get validationRules() {
        return this._getOption('validationRules');
    }
    set validationRules(value) {
        this._setOption('validationRules', value);
    }
    get visible() {
        return this._getOption('visible');
    }
    set visible(value) {
        this._setOption('visible', value);
    }
    get visibleIndex() {
        return this._getOption('visibleIndex');
    }
    set visibleIndex(value) {
        this._setOption('visibleIndex', value);
    }
    get _optionPath() {
        return 'formItem';
    }
    constructor(parentOptionHost, optionHost, renderer, document, templateHost, element) {
        super();
        this.renderer = renderer;
        this.document = document;
        this.element = element;
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
        templateHost.setHost(this);
    }
    setTemplate(template) {
        this.template = template;
    }
    ngAfterViewInit() {
        extractTemplate(this, this.element, this.renderer, this.document);
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewFormItemComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }, { token: i0.Renderer2 }, { token: DOCUMENT }, { token: i1.DxTemplateHost, host: true }, { token: i0.ElementRef }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoCardViewFormItemComponent, isStandalone: true, selector: "dxo-card-view-form-item", inputs: { aiOptions: "aiOptions", colSpan: "colSpan", cssClass: "cssClass", dataField: "dataField", editorOptions: "editorOptions", editorType: "editorType", helpText: "helpText", isRequired: "isRequired", itemType: "itemType", label: "label", name: "name", template: "template", validationRules: "validationRules", visible: "visible", visibleIndex: "visibleIndex" }, providers: [NestedOptionHost, DxTemplateHost], queries: [{ propertyName: "_validationRulesContentChildren", predicate: PROPERTY_TOKEN_validationRules }], usesInheritance: true, ngImport: i0, template: '<ng-content></ng-content>', isInline: true, styles: [":host{display:block}\n"], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewFormItemComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-card-view-form-item', template: '<ng-content></ng-content>', imports: [DxIntegrationModule], providers: [NestedOptionHost, DxTemplateHost], styles: [":host{display:block}\n"] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }, { type: i0.Renderer2 }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [DOCUMENT]
                }] }, { type: i1.DxTemplateHost, decorators: [{
                    type: Host
                }] }, { type: i0.ElementRef }], propDecorators: { _validationRulesContentChildren: [{
                type: ContentChildren,
                args: [PROPERTY_TOKEN_validationRules]
            }], aiOptions: [{
                type: Input
            }], colSpan: [{
                type: Input
            }], cssClass: [{
                type: Input
            }], dataField: [{
                type: Input
            }], editorOptions: [{
                type: Input
            }], editorType: [{
                type: Input
            }], helpText: [{
                type: Input
            }], isRequired: [{
                type: Input
            }], itemType: [{
                type: Input
            }], label: [{
                type: Input
            }], name: [{
                type: Input
            }], template: [{
                type: Input
            }], validationRules: [{
                type: Input
            }], visible: [{
                type: Input
            }], visibleIndex: [{
                type: Input
            }] } });
class DxoCardViewFormItemModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewFormItemModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewFormItemModule, imports: [DxoCardViewFormItemComponent], exports: [DxoCardViewFormItemComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewFormItemModule, imports: [DxoCardViewFormItemComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewFormItemModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoCardViewFormItemComponent
                    ],
                    exports: [
                        DxoCardViewFormItemComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoCardViewFormComponent extends NestedOption {
    set _itemsContentChildren(value) {
        this.setChildren('items', value);
    }
    get accessKey() {
        return this._getOption('accessKey');
    }
    set accessKey(value) {
        this._setOption('accessKey', value);
    }
    get activeStateEnabled() {
        return this._getOption('activeStateEnabled');
    }
    set activeStateEnabled(value) {
        this._setOption('activeStateEnabled', value);
    }
    get aiIntegration() {
        return this._getOption('aiIntegration');
    }
    set aiIntegration(value) {
        this._setOption('aiIntegration', value);
    }
    get alignItemLabels() {
        return this._getOption('alignItemLabels');
    }
    set alignItemLabels(value) {
        this._setOption('alignItemLabels', value);
    }
    get alignItemLabelsInAllGroups() {
        return this._getOption('alignItemLabelsInAllGroups');
    }
    set alignItemLabelsInAllGroups(value) {
        this._setOption('alignItemLabelsInAllGroups', value);
    }
    get colCount() {
        return this._getOption('colCount');
    }
    set colCount(value) {
        this._setOption('colCount', value);
    }
    get colCountByScreen() {
        return this._getOption('colCountByScreen');
    }
    set colCountByScreen(value) {
        this._setOption('colCountByScreen', value);
    }
    get customizeItem() {
        return this._getOption('customizeItem');
    }
    set customizeItem(value) {
        this._setOption('customizeItem', value);
    }
    get disabled() {
        return this._getOption('disabled');
    }
    set disabled(value) {
        this._setOption('disabled', value);
    }
    get elementAttr() {
        return this._getOption('elementAttr');
    }
    set elementAttr(value) {
        this._setOption('elementAttr', value);
    }
    get focusStateEnabled() {
        return this._getOption('focusStateEnabled');
    }
    set focusStateEnabled(value) {
        this._setOption('focusStateEnabled', value);
    }
    get formData() {
        return this._getOption('formData');
    }
    set formData(value) {
        this._setOption('formData', value);
    }
    get height() {
        return this._getOption('height');
    }
    set height(value) {
        this._setOption('height', value);
    }
    get hint() {
        return this._getOption('hint');
    }
    set hint(value) {
        this._setOption('hint', value);
    }
    get hoverStateEnabled() {
        return this._getOption('hoverStateEnabled');
    }
    set hoverStateEnabled(value) {
        this._setOption('hoverStateEnabled', value);
    }
    get isDirty() {
        return this._getOption('isDirty');
    }
    set isDirty(value) {
        this._setOption('isDirty', value);
    }
    get items() {
        return this._getOption('items');
    }
    set items(value) {
        this._setOption('items', value);
    }
    get labelLocation() {
        return this._getOption('labelLocation');
    }
    set labelLocation(value) {
        this._setOption('labelLocation', value);
    }
    get labelMode() {
        return this._getOption('labelMode');
    }
    set labelMode(value) {
        this._setOption('labelMode', value);
    }
    get minColWidth() {
        return this._getOption('minColWidth');
    }
    set minColWidth(value) {
        this._setOption('minColWidth', value);
    }
    get onContentReady() {
        return this._getOption('onContentReady');
    }
    set onContentReady(value) {
        this._setOption('onContentReady', value);
    }
    get onDisposing() {
        return this._getOption('onDisposing');
    }
    set onDisposing(value) {
        this._setOption('onDisposing', value);
    }
    get onEditorEnterKey() {
        return this._getOption('onEditorEnterKey');
    }
    set onEditorEnterKey(value) {
        this._setOption('onEditorEnterKey', value);
    }
    get onFieldDataChanged() {
        return this._getOption('onFieldDataChanged');
    }
    set onFieldDataChanged(value) {
        this._setOption('onFieldDataChanged', value);
    }
    get onInitialized() {
        return this._getOption('onInitialized');
    }
    set onInitialized(value) {
        this._setOption('onInitialized', value);
    }
    get onOptionChanged() {
        return this._getOption('onOptionChanged');
    }
    set onOptionChanged(value) {
        this._setOption('onOptionChanged', value);
    }
    get onSmartPasted() {
        return this._getOption('onSmartPasted');
    }
    set onSmartPasted(value) {
        this._setOption('onSmartPasted', value);
    }
    get onSmartPasting() {
        return this._getOption('onSmartPasting');
    }
    set onSmartPasting(value) {
        this._setOption('onSmartPasting', value);
    }
    get optionalMark() {
        return this._getOption('optionalMark');
    }
    set optionalMark(value) {
        this._setOption('optionalMark', value);
    }
    get readOnly() {
        return this._getOption('readOnly');
    }
    set readOnly(value) {
        this._setOption('readOnly', value);
    }
    get requiredMark() {
        return this._getOption('requiredMark');
    }
    set requiredMark(value) {
        this._setOption('requiredMark', value);
    }
    get requiredMessage() {
        return this._getOption('requiredMessage');
    }
    set requiredMessage(value) {
        this._setOption('requiredMessage', value);
    }
    get rtlEnabled() {
        return this._getOption('rtlEnabled');
    }
    set rtlEnabled(value) {
        this._setOption('rtlEnabled', value);
    }
    get screenByWidth() {
        return this._getOption('screenByWidth');
    }
    set screenByWidth(value) {
        this._setOption('screenByWidth', value);
    }
    get scrollingEnabled() {
        return this._getOption('scrollingEnabled');
    }
    set scrollingEnabled(value) {
        this._setOption('scrollingEnabled', value);
    }
    get showColonAfterLabel() {
        return this._getOption('showColonAfterLabel');
    }
    set showColonAfterLabel(value) {
        this._setOption('showColonAfterLabel', value);
    }
    get showOptionalMark() {
        return this._getOption('showOptionalMark');
    }
    set showOptionalMark(value) {
        this._setOption('showOptionalMark', value);
    }
    get showRequiredMark() {
        return this._getOption('showRequiredMark');
    }
    set showRequiredMark(value) {
        this._setOption('showRequiredMark', value);
    }
    get showValidationSummary() {
        return this._getOption('showValidationSummary');
    }
    set showValidationSummary(value) {
        this._setOption('showValidationSummary', value);
    }
    get tabIndex() {
        return this._getOption('tabIndex');
    }
    set tabIndex(value) {
        this._setOption('tabIndex', value);
    }
    get validationGroup() {
        return this._getOption('validationGroup');
    }
    set validationGroup(value) {
        this._setOption('validationGroup', value);
    }
    get visible() {
        return this._getOption('visible');
    }
    set visible(value) {
        this._setOption('visible', value);
    }
    get width() {
        return this._getOption('width');
    }
    set width(value) {
        this._setOption('width', value);
    }
    get _optionPath() {
        return 'form';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        this._createEventEmitters([
            { emit: 'formDataChange' }
        ]);
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewFormComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoCardViewFormComponent, isStandalone: true, selector: "dxo-card-view-form", inputs: { accessKey: "accessKey", activeStateEnabled: "activeStateEnabled", aiIntegration: "aiIntegration", alignItemLabels: "alignItemLabels", alignItemLabelsInAllGroups: "alignItemLabelsInAllGroups", colCount: "colCount", colCountByScreen: "colCountByScreen", customizeItem: "customizeItem", disabled: "disabled", elementAttr: "elementAttr", focusStateEnabled: "focusStateEnabled", formData: "formData", height: "height", hint: "hint", hoverStateEnabled: "hoverStateEnabled", isDirty: "isDirty", items: "items", labelLocation: "labelLocation", labelMode: "labelMode", minColWidth: "minColWidth", onContentReady: "onContentReady", onDisposing: "onDisposing", onEditorEnterKey: "onEditorEnterKey", onFieldDataChanged: "onFieldDataChanged", onInitialized: "onInitialized", onOptionChanged: "onOptionChanged", onSmartPasted: "onSmartPasted", onSmartPasting: "onSmartPasting", optionalMark: "optionalMark", readOnly: "readOnly", requiredMark: "requiredMark", requiredMessage: "requiredMessage", rtlEnabled: "rtlEnabled", screenByWidth: "screenByWidth", scrollingEnabled: "scrollingEnabled", showColonAfterLabel: "showColonAfterLabel", showOptionalMark: "showOptionalMark", showRequiredMark: "showRequiredMark", showValidationSummary: "showValidationSummary", tabIndex: "tabIndex", validationGroup: "validationGroup", visible: "visible", width: "width" }, outputs: { formDataChange: "formDataChange" }, providers: [NestedOptionHost], queries: [{ propertyName: "_itemsContentChildren", predicate: PROPERTY_TOKEN_items }], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewFormComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-card-view-form', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { _itemsContentChildren: [{
                type: ContentChildren,
                args: [PROPERTY_TOKEN_items]
            }], accessKey: [{
                type: Input
            }], activeStateEnabled: [{
                type: Input
            }], aiIntegration: [{
                type: Input
            }], alignItemLabels: [{
                type: Input
            }], alignItemLabelsInAllGroups: [{
                type: Input
            }], colCount: [{
                type: Input
            }], colCountByScreen: [{
                type: Input
            }], customizeItem: [{
                type: Input
            }], disabled: [{
                type: Input
            }], elementAttr: [{
                type: Input
            }], focusStateEnabled: [{
                type: Input
            }], formData: [{
                type: Input
            }], height: [{
                type: Input
            }], hint: [{
                type: Input
            }], hoverStateEnabled: [{
                type: Input
            }], isDirty: [{
                type: Input
            }], items: [{
                type: Input
            }], labelLocation: [{
                type: Input
            }], labelMode: [{
                type: Input
            }], minColWidth: [{
                type: Input
            }], onContentReady: [{
                type: Input
            }], onDisposing: [{
                type: Input
            }], onEditorEnterKey: [{
                type: Input
            }], onFieldDataChanged: [{
                type: Input
            }], onInitialized: [{
                type: Input
            }], onOptionChanged: [{
                type: Input
            }], onSmartPasted: [{
                type: Input
            }], onSmartPasting: [{
                type: Input
            }], optionalMark: [{
                type: Input
            }], readOnly: [{
                type: Input
            }], requiredMark: [{
                type: Input
            }], requiredMessage: [{
                type: Input
            }], rtlEnabled: [{
                type: Input
            }], screenByWidth: [{
                type: Input
            }], scrollingEnabled: [{
                type: Input
            }], showColonAfterLabel: [{
                type: Input
            }], showOptionalMark: [{
                type: Input
            }], showRequiredMark: [{
                type: Input
            }], showValidationSummary: [{
                type: Input
            }], tabIndex: [{
                type: Input
            }], validationGroup: [{
                type: Input
            }], visible: [{
                type: Input
            }], width: [{
                type: Input
            }], formDataChange: [{
                type: Output
            }] } });
class DxoCardViewFormModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewFormModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewFormModule, imports: [DxoCardViewFormComponent], exports: [DxoCardViewFormComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewFormModule, imports: [DxoCardViewFormComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewFormModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoCardViewFormComponent
                    ],
                    exports: [
                        DxoCardViewFormComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoCardViewFormatComponent extends NestedOption {
    get currency() {
        return this._getOption('currency');
    }
    set currency(value) {
        this._setOption('currency', value);
    }
    get formatter() {
        return this._getOption('formatter');
    }
    set formatter(value) {
        this._setOption('formatter', value);
    }
    get parser() {
        return this._getOption('parser');
    }
    set parser(value) {
        this._setOption('parser', value);
    }
    get precision() {
        return this._getOption('precision');
    }
    set precision(value) {
        this._setOption('precision', value);
    }
    get type() {
        return this._getOption('type');
    }
    set type(value) {
        this._setOption('type', value);
    }
    get useCurrencyAccountingStyle() {
        return this._getOption('useCurrencyAccountingStyle');
    }
    set useCurrencyAccountingStyle(value) {
        this._setOption('useCurrencyAccountingStyle', value);
    }
    get _optionPath() {
        return 'format';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewFormatComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoCardViewFormatComponent, isStandalone: true, selector: "dxo-card-view-format", inputs: { currency: "currency", formatter: "formatter", parser: "parser", precision: "precision", type: "type", useCurrencyAccountingStyle: "useCurrencyAccountingStyle" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewFormatComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-card-view-format', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { currency: [{
                type: Input
            }], formatter: [{
                type: Input
            }], parser: [{
                type: Input
            }], precision: [{
                type: Input
            }], type: [{
                type: Input
            }], useCurrencyAccountingStyle: [{
                type: Input
            }] } });
class DxoCardViewFormatModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewFormatModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewFormatModule, imports: [DxoCardViewFormatComponent], exports: [DxoCardViewFormatComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewFormatModule, imports: [DxoCardViewFormatComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewFormatModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoCardViewFormatComponent
                    ],
                    exports: [
                        DxoCardViewFormatComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoCardViewFromComponent extends NestedOption {
    get left() {
        return this._getOption('left');
    }
    set left(value) {
        this._setOption('left', value);
    }
    get opacity() {
        return this._getOption('opacity');
    }
    set opacity(value) {
        this._setOption('opacity', value);
    }
    get position() {
        return this._getOption('position');
    }
    set position(value) {
        this._setOption('position', value);
    }
    get scale() {
        return this._getOption('scale');
    }
    set scale(value) {
        this._setOption('scale', value);
    }
    get top() {
        return this._getOption('top');
    }
    set top(value) {
        this._setOption('top', value);
    }
    get _optionPath() {
        return 'from';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewFromComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoCardViewFromComponent, isStandalone: true, selector: "dxo-card-view-from", inputs: { left: "left", opacity: "opacity", position: "position", scale: "scale", top: "top" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewFromComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-card-view-from', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { left: [{
                type: Input
            }], opacity: [{
                type: Input
            }], position: [{
                type: Input
            }], scale: [{
                type: Input
            }], top: [{
                type: Input
            }] } });
class DxoCardViewFromModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewFromModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewFromModule, imports: [DxoCardViewFromComponent], exports: [DxoCardViewFromComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewFromModule, imports: [DxoCardViewFromComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewFromModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoCardViewFromComponent
                    ],
                    exports: [
                        DxoCardViewFromComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxiCardViewGroupItemComponent extends CollectionNestedOption {
    set _itemsContentChildren(value) {
        this.setChildren('items', value);
    }
    get alignItemLabels() {
        return this._getOption('alignItemLabels');
    }
    set alignItemLabels(value) {
        this._setOption('alignItemLabels', value);
    }
    get caption() {
        return this._getOption('caption');
    }
    set caption(value) {
        this._setOption('caption', value);
    }
    get captionTemplate() {
        return this._getOption('captionTemplate');
    }
    set captionTemplate(value) {
        this._setOption('captionTemplate', value);
    }
    get colCount() {
        return this._getOption('colCount');
    }
    set colCount(value) {
        this._setOption('colCount', value);
    }
    get colCountByScreen() {
        return this._getOption('colCountByScreen');
    }
    set colCountByScreen(value) {
        this._setOption('colCountByScreen', value);
    }
    get colSpan() {
        return this._getOption('colSpan');
    }
    set colSpan(value) {
        this._setOption('colSpan', value);
    }
    get cssClass() {
        return this._getOption('cssClass');
    }
    set cssClass(value) {
        this._setOption('cssClass', value);
    }
    get items() {
        return this._getOption('items');
    }
    set items(value) {
        this._setOption('items', value);
    }
    get itemType() {
        return this._getOption('itemType');
    }
    set itemType(value) {
        this._setOption('itemType', value);
    }
    get name() {
        return this._getOption('name');
    }
    set name(value) {
        this._setOption('name', value);
    }
    get template() {
        return this._getOption('template');
    }
    set template(value) {
        this._setOption('template', value);
    }
    get visible() {
        return this._getOption('visible');
    }
    set visible(value) {
        this._setOption('visible', value);
    }
    get visibleIndex() {
        return this._getOption('visibleIndex');
    }
    set visibleIndex(value) {
        this._setOption('visibleIndex', value);
    }
    get _optionPath() {
        return 'items';
    }
    constructor(parentOptionHost, optionHost, renderer, document, templateHost, element) {
        super();
        this.renderer = renderer;
        this.document = document;
        this.element = element;
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
        templateHost.setHost(this);
        this.itemType = 'group';
    }
    setTemplate(template) {
        this.template = template;
    }
    ngAfterViewInit() {
        extractTemplate(this, this.element, this.renderer, this.document);
    }
    ngOnDestroy() {
        this._deleteRemovedOptions(this._fullOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiCardViewGroupItemComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }, { token: i0.Renderer2 }, { token: DOCUMENT }, { token: i1.DxTemplateHost, host: true }, { token: i0.ElementRef }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxiCardViewGroupItemComponent, isStandalone: true, selector: "dxi-card-view-group-item", inputs: { alignItemLabels: "alignItemLabels", caption: "caption", captionTemplate: "captionTemplate", colCount: "colCount", colCountByScreen: "colCountByScreen", colSpan: "colSpan", cssClass: "cssClass", items: "items", itemType: "itemType", name: "name", template: "template", visible: "visible", visibleIndex: "visibleIndex" }, providers: [
            NestedOptionHost,
            DxTemplateHost,
            {
                provide: PROPERTY_TOKEN_items,
                useExisting: DxiCardViewGroupItemComponent,
            }
        ], queries: [{ propertyName: "_itemsContentChildren", predicate: PROPERTY_TOKEN_items }], usesInheritance: true, ngImport: i0, template: '<ng-content></ng-content>', isInline: true, styles: [":host{display:block}\n"], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiCardViewGroupItemComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxi-card-view-group-item', template: '<ng-content></ng-content>', imports: [DxIntegrationModule], providers: [
                        NestedOptionHost,
                        DxTemplateHost,
                        {
                            provide: PROPERTY_TOKEN_items,
                            useExisting: DxiCardViewGroupItemComponent,
                        }
                    ], styles: [":host{display:block}\n"] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }, { type: i0.Renderer2 }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [DOCUMENT]
                }] }, { type: i1.DxTemplateHost, decorators: [{
                    type: Host
                }] }, { type: i0.ElementRef }], propDecorators: { _itemsContentChildren: [{
                type: ContentChildren,
                args: [PROPERTY_TOKEN_items]
            }], alignItemLabels: [{
                type: Input
            }], caption: [{
                type: Input
            }], captionTemplate: [{
                type: Input
            }], colCount: [{
                type: Input
            }], colCountByScreen: [{
                type: Input
            }], colSpan: [{
                type: Input
            }], cssClass: [{
                type: Input
            }], items: [{
                type: Input
            }], itemType: [{
                type: Input
            }], name: [{
                type: Input
            }], template: [{
                type: Input
            }], visible: [{
                type: Input
            }], visibleIndex: [{
                type: Input
            }] } });
class DxiCardViewGroupItemModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiCardViewGroupItemModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxiCardViewGroupItemModule, imports: [DxiCardViewGroupItemComponent], exports: [DxiCardViewGroupItemComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiCardViewGroupItemModule, imports: [DxiCardViewGroupItemComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiCardViewGroupItemModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxiCardViewGroupItemComponent
                    ],
                    exports: [
                        DxiCardViewGroupItemComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoCardViewGroupOperationDescriptionsComponent extends NestedOption {
    get and() {
        return this._getOption('and');
    }
    set and(value) {
        this._setOption('and', value);
    }
    get notAnd() {
        return this._getOption('notAnd');
    }
    set notAnd(value) {
        this._setOption('notAnd', value);
    }
    get notOr() {
        return this._getOption('notOr');
    }
    set notOr(value) {
        this._setOption('notOr', value);
    }
    get or() {
        return this._getOption('or');
    }
    set or(value) {
        this._setOption('or', value);
    }
    get _optionPath() {
        return 'groupOperationDescriptions';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewGroupOperationDescriptionsComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoCardViewGroupOperationDescriptionsComponent, isStandalone: true, selector: "dxo-card-view-group-operation-descriptions", inputs: { and: "and", notAnd: "notAnd", notOr: "notOr", or: "or" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewGroupOperationDescriptionsComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-card-view-group-operation-descriptions', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { and: [{
                type: Input
            }], notAnd: [{
                type: Input
            }], notOr: [{
                type: Input
            }], or: [{
                type: Input
            }] } });
class DxoCardViewGroupOperationDescriptionsModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewGroupOperationDescriptionsModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewGroupOperationDescriptionsModule, imports: [DxoCardViewGroupOperationDescriptionsComponent], exports: [DxoCardViewGroupOperationDescriptionsComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewGroupOperationDescriptionsModule, imports: [DxoCardViewGroupOperationDescriptionsComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewGroupOperationDescriptionsModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoCardViewGroupOperationDescriptionsComponent
                    ],
                    exports: [
                        DxoCardViewGroupOperationDescriptionsComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoCardViewHeaderFilterComponent extends NestedOption {
    get allowSearch() {
        return this._getOption('allowSearch');
    }
    set allowSearch(value) {
        this._setOption('allowSearch', value);
    }
    get allowSelectAll() {
        return this._getOption('allowSelectAll');
    }
    set allowSelectAll(value) {
        this._setOption('allowSelectAll', value);
    }
    get dataSource() {
        return this._getOption('dataSource');
    }
    set dataSource(value) {
        this._setOption('dataSource', value);
    }
    get groupInterval() {
        return this._getOption('groupInterval');
    }
    set groupInterval(value) {
        this._setOption('groupInterval', value);
    }
    get height() {
        return this._getOption('height');
    }
    set height(value) {
        this._setOption('height', value);
    }
    get search() {
        return this._getOption('search');
    }
    set search(value) {
        this._setOption('search', value);
    }
    get searchMode() {
        return this._getOption('searchMode');
    }
    set searchMode(value) {
        this._setOption('searchMode', value);
    }
    get width() {
        return this._getOption('width');
    }
    set width(value) {
        this._setOption('width', value);
    }
    get searchTimeout() {
        return this._getOption('searchTimeout');
    }
    set searchTimeout(value) {
        this._setOption('searchTimeout', value);
    }
    get texts() {
        return this._getOption('texts');
    }
    set texts(value) {
        this._setOption('texts', value);
    }
    get visible() {
        return this._getOption('visible');
    }
    set visible(value) {
        this._setOption('visible', value);
    }
    get _optionPath() {
        return 'headerFilter';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewHeaderFilterComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoCardViewHeaderFilterComponent, isStandalone: true, selector: "dxo-card-view-header-filter", inputs: { allowSearch: "allowSearch", allowSelectAll: "allowSelectAll", dataSource: "dataSource", groupInterval: "groupInterval", height: "height", search: "search", searchMode: "searchMode", width: "width", searchTimeout: "searchTimeout", texts: "texts", visible: "visible" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewHeaderFilterComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-card-view-header-filter', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { allowSearch: [{
                type: Input
            }], allowSelectAll: [{
                type: Input
            }], dataSource: [{
                type: Input
            }], groupInterval: [{
                type: Input
            }], height: [{
                type: Input
            }], search: [{
                type: Input
            }], searchMode: [{
                type: Input
            }], width: [{
                type: Input
            }], searchTimeout: [{
                type: Input
            }], texts: [{
                type: Input
            }], visible: [{
                type: Input
            }] } });
class DxoCardViewHeaderFilterModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewHeaderFilterModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewHeaderFilterModule, imports: [DxoCardViewHeaderFilterComponent], exports: [DxoCardViewHeaderFilterComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewHeaderFilterModule, imports: [DxoCardViewHeaderFilterComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewHeaderFilterModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoCardViewHeaderFilterComponent
                    ],
                    exports: [
                        DxoCardViewHeaderFilterComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoCardViewHeaderPanelComponent extends NestedOption {
    get dragging() {
        return this._getOption('dragging');
    }
    set dragging(value) {
        this._setOption('dragging', value);
    }
    get itemCssClass() {
        return this._getOption('itemCssClass');
    }
    set itemCssClass(value) {
        this._setOption('itemCssClass', value);
    }
    get itemTemplate() {
        return this._getOption('itemTemplate');
    }
    set itemTemplate(value) {
        this._setOption('itemTemplate', value);
    }
    get visible() {
        return this._getOption('visible');
    }
    set visible(value) {
        this._setOption('visible', value);
    }
    get _optionPath() {
        return 'headerPanel';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewHeaderPanelComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoCardViewHeaderPanelComponent, isStandalone: true, selector: "dxo-card-view-header-panel", inputs: { dragging: "dragging", itemCssClass: "itemCssClass", itemTemplate: "itemTemplate", visible: "visible" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewHeaderPanelComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-card-view-header-panel', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { dragging: [{
                type: Input
            }], itemCssClass: [{
                type: Input
            }], itemTemplate: [{
                type: Input
            }], visible: [{
                type: Input
            }] } });
class DxoCardViewHeaderPanelModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewHeaderPanelModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewHeaderPanelModule, imports: [DxoCardViewHeaderPanelComponent], exports: [DxoCardViewHeaderPanelComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewHeaderPanelModule, imports: [DxoCardViewHeaderPanelComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewHeaderPanelModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoCardViewHeaderPanelComponent
                    ],
                    exports: [
                        DxoCardViewHeaderPanelComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoCardViewHideComponent extends NestedOption {
    get complete() {
        return this._getOption('complete');
    }
    set complete(value) {
        this._setOption('complete', value);
    }
    get delay() {
        return this._getOption('delay');
    }
    set delay(value) {
        this._setOption('delay', value);
    }
    get direction() {
        return this._getOption('direction');
    }
    set direction(value) {
        this._setOption('direction', value);
    }
    get duration() {
        return this._getOption('duration');
    }
    set duration(value) {
        this._setOption('duration', value);
    }
    get easing() {
        return this._getOption('easing');
    }
    set easing(value) {
        this._setOption('easing', value);
    }
    get from() {
        return this._getOption('from');
    }
    set from(value) {
        this._setOption('from', value);
    }
    get staggerDelay() {
        return this._getOption('staggerDelay');
    }
    set staggerDelay(value) {
        this._setOption('staggerDelay', value);
    }
    get start() {
        return this._getOption('start');
    }
    set start(value) {
        this._setOption('start', value);
    }
    get to() {
        return this._getOption('to');
    }
    set to(value) {
        this._setOption('to', value);
    }
    get type() {
        return this._getOption('type');
    }
    set type(value) {
        this._setOption('type', value);
    }
    get _optionPath() {
        return 'hide';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewHideComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoCardViewHideComponent, isStandalone: true, selector: "dxo-card-view-hide", inputs: { complete: "complete", delay: "delay", direction: "direction", duration: "duration", easing: "easing", from: "from", staggerDelay: "staggerDelay", start: "start", to: "to", type: "type" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewHideComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-card-view-hide', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { complete: [{
                type: Input
            }], delay: [{
                type: Input
            }], direction: [{
                type: Input
            }], duration: [{
                type: Input
            }], easing: [{
                type: Input
            }], from: [{
                type: Input
            }], staggerDelay: [{
                type: Input
            }], start: [{
                type: Input
            }], to: [{
                type: Input
            }], type: [{
                type: Input
            }] } });
class DxoCardViewHideModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewHideModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewHideModule, imports: [DxoCardViewHideComponent], exports: [DxoCardViewHideComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewHideModule, imports: [DxoCardViewHideComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewHideModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoCardViewHideComponent
                    ],
                    exports: [
                        DxoCardViewHideComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoCardViewIndicatorOptionsComponent extends NestedOption {
    get animationType() {
        return this._getOption('animationType');
    }
    set animationType(value) {
        this._setOption('animationType', value);
    }
    get height() {
        return this._getOption('height');
    }
    set height(value) {
        this._setOption('height', value);
    }
    get src() {
        return this._getOption('src');
    }
    set src(value) {
        this._setOption('src', value);
    }
    get width() {
        return this._getOption('width');
    }
    set width(value) {
        this._setOption('width', value);
    }
    get _optionPath() {
        return 'indicatorOptions';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewIndicatorOptionsComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoCardViewIndicatorOptionsComponent, isStandalone: true, selector: "dxo-card-view-indicator-options", inputs: { animationType: "animationType", height: "height", src: "src", width: "width" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewIndicatorOptionsComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-card-view-indicator-options', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { animationType: [{
                type: Input
            }], height: [{
                type: Input
            }], src: [{
                type: Input
            }], width: [{
                type: Input
            }] } });
class DxoCardViewIndicatorOptionsModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewIndicatorOptionsModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewIndicatorOptionsModule, imports: [DxoCardViewIndicatorOptionsComponent], exports: [DxoCardViewIndicatorOptionsComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewIndicatorOptionsModule, imports: [DxoCardViewIndicatorOptionsComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewIndicatorOptionsModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoCardViewIndicatorOptionsComponent
                    ],
                    exports: [
                        DxoCardViewIndicatorOptionsComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxiCardViewItemComponent extends CollectionNestedOption {
    set _validationRulesContentChildren(value) {
        this.setChildren('validationRules', value);
    }
    set _tabsContentChildren(value) {
        this.setChildren('tabs', value);
    }
    set _itemsContentChildren(value) {
        this.setChildren('items', value);
    }
    get cssClass() {
        return this._getOption('cssClass');
    }
    set cssClass(value) {
        this._setOption('cssClass', value);
    }
    get disabled() {
        return this._getOption('disabled');
    }
    set disabled(value) {
        this._setOption('disabled', value);
    }
    get html() {
        return this._getOption('html');
    }
    set html(value) {
        this._setOption('html', value);
    }
    get locateInMenu() {
        return this._getOption('locateInMenu');
    }
    set locateInMenu(value) {
        this._setOption('locateInMenu', value);
    }
    get location() {
        return this._getOption('location');
    }
    set location(value) {
        this._setOption('location', value);
    }
    get menuItemTemplate() {
        return this._getOption('menuItemTemplate');
    }
    set menuItemTemplate(value) {
        this._setOption('menuItemTemplate', value);
    }
    get name() {
        return this._getOption('name');
    }
    set name(value) {
        this._setOption('name', value);
    }
    get options() {
        return this._getOption('options');
    }
    set options(value) {
        this._setOption('options', value);
    }
    get showText() {
        return this._getOption('showText');
    }
    set showText(value) {
        this._setOption('showText', value);
    }
    get template() {
        return this._getOption('template');
    }
    set template(value) {
        this._setOption('template', value);
    }
    get text() {
        return this._getOption('text');
    }
    set text(value) {
        this._setOption('text', value);
    }
    get visible() {
        return this._getOption('visible');
    }
    set visible(value) {
        this._setOption('visible', value);
    }
    get widget() {
        return this._getOption('widget');
    }
    set widget(value) {
        this._setOption('widget', value);
    }
    get badge() {
        return this._getOption('badge');
    }
    set badge(value) {
        this._setOption('badge', value);
    }
    get icon() {
        return this._getOption('icon');
    }
    set icon(value) {
        this._setOption('icon', value);
    }
    get tabTemplate() {
        return this._getOption('tabTemplate');
    }
    set tabTemplate(value) {
        this._setOption('tabTemplate', value);
    }
    get title() {
        return this._getOption('title');
    }
    set title(value) {
        this._setOption('title', value);
    }
    get aiOptions() {
        return this._getOption('aiOptions');
    }
    set aiOptions(value) {
        this._setOption('aiOptions', value);
    }
    get colSpan() {
        return this._getOption('colSpan');
    }
    set colSpan(value) {
        this._setOption('colSpan', value);
    }
    get dataField() {
        return this._getOption('dataField');
    }
    set dataField(value) {
        this._setOption('dataField', value);
    }
    get editorOptions() {
        return this._getOption('editorOptions');
    }
    set editorOptions(value) {
        this._setOption('editorOptions', value);
    }
    get editorType() {
        return this._getOption('editorType');
    }
    set editorType(value) {
        this._setOption('editorType', value);
    }
    get helpText() {
        return this._getOption('helpText');
    }
    set helpText(value) {
        this._setOption('helpText', value);
    }
    get isRequired() {
        return this._getOption('isRequired');
    }
    set isRequired(value) {
        this._setOption('isRequired', value);
    }
    get itemType() {
        return this._getOption('itemType');
    }
    set itemType(value) {
        this._setOption('itemType', value);
    }
    get label() {
        return this._getOption('label');
    }
    set label(value) {
        this._setOption('label', value);
    }
    get validationRules() {
        return this._getOption('validationRules');
    }
    set validationRules(value) {
        this._setOption('validationRules', value);
    }
    get visibleIndex() {
        return this._getOption('visibleIndex');
    }
    set visibleIndex(value) {
        this._setOption('visibleIndex', value);
    }
    get alignItemLabels() {
        return this._getOption('alignItemLabels');
    }
    set alignItemLabels(value) {
        this._setOption('alignItemLabels', value);
    }
    get caption() {
        return this._getOption('caption');
    }
    set caption(value) {
        this._setOption('caption', value);
    }
    get captionTemplate() {
        return this._getOption('captionTemplate');
    }
    set captionTemplate(value) {
        this._setOption('captionTemplate', value);
    }
    get colCount() {
        return this._getOption('colCount');
    }
    set colCount(value) {
        this._setOption('colCount', value);
    }
    get colCountByScreen() {
        return this._getOption('colCountByScreen');
    }
    set colCountByScreen(value) {
        this._setOption('colCountByScreen', value);
    }
    get items() {
        return this._getOption('items');
    }
    set items(value) {
        this._setOption('items', value);
    }
    get tabPanelOptions() {
        return this._getOption('tabPanelOptions');
    }
    set tabPanelOptions(value) {
        this._setOption('tabPanelOptions', value);
    }
    get tabs() {
        return this._getOption('tabs');
    }
    set tabs(value) {
        this._setOption('tabs', value);
    }
    get buttonOptions() {
        return this._getOption('buttonOptions');
    }
    set buttonOptions(value) {
        this._setOption('buttonOptions', value);
    }
    get horizontalAlignment() {
        return this._getOption('horizontalAlignment');
    }
    set horizontalAlignment(value) {
        this._setOption('horizontalAlignment', value);
    }
    get verticalAlignment() {
        return this._getOption('verticalAlignment');
    }
    set verticalAlignment(value) {
        this._setOption('verticalAlignment', value);
    }
    get _optionPath() {
        return 'items';
    }
    constructor(parentOptionHost, optionHost, renderer, document, templateHost, element) {
        super();
        this.renderer = renderer;
        this.document = document;
        this.element = element;
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
        templateHost.setHost(this);
    }
    setTemplate(template) {
        this.template = template;
    }
    ngAfterViewInit() {
        extractTemplate(this, this.element, this.renderer, this.document);
    }
    ngOnDestroy() {
        this._deleteRemovedOptions(this._fullOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiCardViewItemComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }, { token: i0.Renderer2 }, { token: DOCUMENT }, { token: i1.DxTemplateHost, host: true }, { token: i0.ElementRef }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxiCardViewItemComponent, isStandalone: true, selector: "dxi-card-view-item", inputs: { cssClass: "cssClass", disabled: "disabled", html: "html", locateInMenu: "locateInMenu", location: "location", menuItemTemplate: "menuItemTemplate", name: "name", options: "options", showText: "showText", template: "template", text: "text", visible: "visible", widget: "widget", badge: "badge", icon: "icon", tabTemplate: "tabTemplate", title: "title", aiOptions: "aiOptions", colSpan: "colSpan", dataField: "dataField", editorOptions: "editorOptions", editorType: "editorType", helpText: "helpText", isRequired: "isRequired", itemType: "itemType", label: "label", validationRules: "validationRules", visibleIndex: "visibleIndex", alignItemLabels: "alignItemLabels", caption: "caption", captionTemplate: "captionTemplate", colCount: "colCount", colCountByScreen: "colCountByScreen", items: "items", tabPanelOptions: "tabPanelOptions", tabs: "tabs", buttonOptions: "buttonOptions", horizontalAlignment: "horizontalAlignment", verticalAlignment: "verticalAlignment" }, providers: [
            NestedOptionHost,
            DxTemplateHost,
            {
                provide: PROPERTY_TOKEN_items,
                useExisting: DxiCardViewItemComponent,
            }
        ], queries: [{ propertyName: "_validationRulesContentChildren", predicate: PROPERTY_TOKEN_validationRules }, { propertyName: "_tabsContentChildren", predicate: PROPERTY_TOKEN_tabs }, { propertyName: "_itemsContentChildren", predicate: PROPERTY_TOKEN_items }], usesInheritance: true, ngImport: i0, template: '<ng-content></ng-content>', isInline: true, styles: [":host{display:block}\n"], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiCardViewItemComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxi-card-view-item', template: '<ng-content></ng-content>', imports: [DxIntegrationModule], providers: [
                        NestedOptionHost,
                        DxTemplateHost,
                        {
                            provide: PROPERTY_TOKEN_items,
                            useExisting: DxiCardViewItemComponent,
                        }
                    ], styles: [":host{display:block}\n"] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }, { type: i0.Renderer2 }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [DOCUMENT]
                }] }, { type: i1.DxTemplateHost, decorators: [{
                    type: Host
                }] }, { type: i0.ElementRef }], propDecorators: { _validationRulesContentChildren: [{
                type: ContentChildren,
                args: [PROPERTY_TOKEN_validationRules]
            }], _tabsContentChildren: [{
                type: ContentChildren,
                args: [PROPERTY_TOKEN_tabs]
            }], _itemsContentChildren: [{
                type: ContentChildren,
                args: [PROPERTY_TOKEN_items]
            }], cssClass: [{
                type: Input
            }], disabled: [{
                type: Input
            }], html: [{
                type: Input
            }], locateInMenu: [{
                type: Input
            }], location: [{
                type: Input
            }], menuItemTemplate: [{
                type: Input
            }], name: [{
                type: Input
            }], options: [{
                type: Input
            }], showText: [{
                type: Input
            }], template: [{
                type: Input
            }], text: [{
                type: Input
            }], visible: [{
                type: Input
            }], widget: [{
                type: Input
            }], badge: [{
                type: Input
            }], icon: [{
                type: Input
            }], tabTemplate: [{
                type: Input
            }], title: [{
                type: Input
            }], aiOptions: [{
                type: Input
            }], colSpan: [{
                type: Input
            }], dataField: [{
                type: Input
            }], editorOptions: [{
                type: Input
            }], editorType: [{
                type: Input
            }], helpText: [{
                type: Input
            }], isRequired: [{
                type: Input
            }], itemType: [{
                type: Input
            }], label: [{
                type: Input
            }], validationRules: [{
                type: Input
            }], visibleIndex: [{
                type: Input
            }], alignItemLabels: [{
                type: Input
            }], caption: [{
                type: Input
            }], captionTemplate: [{
                type: Input
            }], colCount: [{
                type: Input
            }], colCountByScreen: [{
                type: Input
            }], items: [{
                type: Input
            }], tabPanelOptions: [{
                type: Input
            }], tabs: [{
                type: Input
            }], buttonOptions: [{
                type: Input
            }], horizontalAlignment: [{
                type: Input
            }], verticalAlignment: [{
                type: Input
            }] } });
class DxiCardViewItemModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiCardViewItemModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxiCardViewItemModule, imports: [DxiCardViewItemComponent], exports: [DxiCardViewItemComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiCardViewItemModule, imports: [DxiCardViewItemComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiCardViewItemModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxiCardViewItemComponent
                    ],
                    exports: [
                        DxiCardViewItemComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoCardViewLabelComponent extends NestedOption {
    get alignment() {
        return this._getOption('alignment');
    }
    set alignment(value) {
        this._setOption('alignment', value);
    }
    get location() {
        return this._getOption('location');
    }
    set location(value) {
        this._setOption('location', value);
    }
    get showColon() {
        return this._getOption('showColon');
    }
    set showColon(value) {
        this._setOption('showColon', value);
    }
    get template() {
        return this._getOption('template');
    }
    set template(value) {
        this._setOption('template', value);
    }
    get text() {
        return this._getOption('text');
    }
    set text(value) {
        this._setOption('text', value);
    }
    get visible() {
        return this._getOption('visible');
    }
    set visible(value) {
        this._setOption('visible', value);
    }
    get _optionPath() {
        return 'label';
    }
    constructor(parentOptionHost, optionHost, renderer, document, templateHost, element) {
        super();
        this.renderer = renderer;
        this.document = document;
        this.element = element;
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
        templateHost.setHost(this);
    }
    setTemplate(template) {
        this.template = template;
    }
    ngAfterViewInit() {
        extractTemplate(this, this.element, this.renderer, this.document);
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewLabelComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }, { token: i0.Renderer2 }, { token: DOCUMENT }, { token: i1.DxTemplateHost, host: true }, { token: i0.ElementRef }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoCardViewLabelComponent, isStandalone: true, selector: "dxo-card-view-label", inputs: { alignment: "alignment", location: "location", showColon: "showColon", template: "template", text: "text", visible: "visible" }, providers: [NestedOptionHost, DxTemplateHost], usesInheritance: true, ngImport: i0, template: '<ng-content></ng-content>', isInline: true, styles: [":host{display:block}\n"], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewLabelComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-card-view-label', template: '<ng-content></ng-content>', imports: [DxIntegrationModule], providers: [NestedOptionHost, DxTemplateHost], styles: [":host{display:block}\n"] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }, { type: i0.Renderer2 }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [DOCUMENT]
                }] }, { type: i1.DxTemplateHost, decorators: [{
                    type: Host
                }] }, { type: i0.ElementRef }], propDecorators: { alignment: [{
                type: Input
            }], location: [{
                type: Input
            }], showColon: [{
                type: Input
            }], template: [{
                type: Input
            }], text: [{
                type: Input
            }], visible: [{
                type: Input
            }] } });
class DxoCardViewLabelModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewLabelModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewLabelModule, imports: [DxoCardViewLabelComponent], exports: [DxoCardViewLabelComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewLabelModule, imports: [DxoCardViewLabelComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewLabelModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoCardViewLabelComponent
                    ],
                    exports: [
                        DxoCardViewLabelComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoCardViewLoadPanelComponent extends NestedOption {
    get animation() {
        return this._getOption('animation');
    }
    set animation(value) {
        this._setOption('animation', value);
    }
    get container() {
        return this._getOption('container');
    }
    set container(value) {
        this._setOption('container', value);
    }
    get deferRendering() {
        return this._getOption('deferRendering');
    }
    set deferRendering(value) {
        this._setOption('deferRendering', value);
    }
    get delay() {
        return this._getOption('delay');
    }
    set delay(value) {
        this._setOption('delay', value);
    }
    get focusStateEnabled() {
        return this._getOption('focusStateEnabled');
    }
    set focusStateEnabled(value) {
        this._setOption('focusStateEnabled', value);
    }
    get height() {
        return this._getOption('height');
    }
    set height(value) {
        this._setOption('height', value);
    }
    get hideOnOutsideClick() {
        return this._getOption('hideOnOutsideClick');
    }
    set hideOnOutsideClick(value) {
        this._setOption('hideOnOutsideClick', value);
    }
    get hideOnParentScroll() {
        return this._getOption('hideOnParentScroll');
    }
    set hideOnParentScroll(value) {
        this._setOption('hideOnParentScroll', value);
    }
    get hint() {
        return this._getOption('hint');
    }
    set hint(value) {
        this._setOption('hint', value);
    }
    get hoverStateEnabled() {
        return this._getOption('hoverStateEnabled');
    }
    set hoverStateEnabled(value) {
        this._setOption('hoverStateEnabled', value);
    }
    get indicatorOptions() {
        return this._getOption('indicatorOptions');
    }
    set indicatorOptions(value) {
        this._setOption('indicatorOptions', value);
    }
    get indicatorSrc() {
        return this._getOption('indicatorSrc');
    }
    set indicatorSrc(value) {
        this._setOption('indicatorSrc', value);
    }
    get maxHeight() {
        return this._getOption('maxHeight');
    }
    set maxHeight(value) {
        this._setOption('maxHeight', value);
    }
    get maxWidth() {
        return this._getOption('maxWidth');
    }
    set maxWidth(value) {
        this._setOption('maxWidth', value);
    }
    get message() {
        return this._getOption('message');
    }
    set message(value) {
        this._setOption('message', value);
    }
    get minHeight() {
        return this._getOption('minHeight');
    }
    set minHeight(value) {
        this._setOption('minHeight', value);
    }
    get minWidth() {
        return this._getOption('minWidth');
    }
    set minWidth(value) {
        this._setOption('minWidth', value);
    }
    get onContentReady() {
        return this._getOption('onContentReady');
    }
    set onContentReady(value) {
        this._setOption('onContentReady', value);
    }
    get onDisposing() {
        return this._getOption('onDisposing');
    }
    set onDisposing(value) {
        this._setOption('onDisposing', value);
    }
    get onHidden() {
        return this._getOption('onHidden');
    }
    set onHidden(value) {
        this._setOption('onHidden', value);
    }
    get onHiding() {
        return this._getOption('onHiding');
    }
    set onHiding(value) {
        this._setOption('onHiding', value);
    }
    get onInitialized() {
        return this._getOption('onInitialized');
    }
    set onInitialized(value) {
        this._setOption('onInitialized', value);
    }
    get onOptionChanged() {
        return this._getOption('onOptionChanged');
    }
    set onOptionChanged(value) {
        this._setOption('onOptionChanged', value);
    }
    get onShowing() {
        return this._getOption('onShowing');
    }
    set onShowing(value) {
        this._setOption('onShowing', value);
    }
    get onShown() {
        return this._getOption('onShown');
    }
    set onShown(value) {
        this._setOption('onShown', value);
    }
    get position() {
        return this._getOption('position');
    }
    set position(value) {
        this._setOption('position', value);
    }
    get rtlEnabled() {
        return this._getOption('rtlEnabled');
    }
    set rtlEnabled(value) {
        this._setOption('rtlEnabled', value);
    }
    get shading() {
        return this._getOption('shading');
    }
    set shading(value) {
        this._setOption('shading', value);
    }
    get shadingColor() {
        return this._getOption('shadingColor');
    }
    set shadingColor(value) {
        this._setOption('shadingColor', value);
    }
    get showIndicator() {
        return this._getOption('showIndicator');
    }
    set showIndicator(value) {
        this._setOption('showIndicator', value);
    }
    get showPane() {
        return this._getOption('showPane');
    }
    set showPane(value) {
        this._setOption('showPane', value);
    }
    get visible() {
        return this._getOption('visible');
    }
    set visible(value) {
        this._setOption('visible', value);
    }
    get width() {
        return this._getOption('width');
    }
    set width(value) {
        this._setOption('width', value);
    }
    get wrapperAttr() {
        return this._getOption('wrapperAttr');
    }
    set wrapperAttr(value) {
        this._setOption('wrapperAttr', value);
    }
    get _optionPath() {
        return 'loadPanel';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        this._createEventEmitters([
            { emit: 'positionChange' },
            { emit: 'visibleChange' }
        ]);
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewLoadPanelComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoCardViewLoadPanelComponent, isStandalone: true, selector: "dxo-card-view-load-panel", inputs: { animation: "animation", container: "container", deferRendering: "deferRendering", delay: "delay", focusStateEnabled: "focusStateEnabled", height: "height", hideOnOutsideClick: "hideOnOutsideClick", hideOnParentScroll: "hideOnParentScroll", hint: "hint", hoverStateEnabled: "hoverStateEnabled", indicatorOptions: "indicatorOptions", indicatorSrc: "indicatorSrc", maxHeight: "maxHeight", maxWidth: "maxWidth", message: "message", minHeight: "minHeight", minWidth: "minWidth", onContentReady: "onContentReady", onDisposing: "onDisposing", onHidden: "onHidden", onHiding: "onHiding", onInitialized: "onInitialized", onOptionChanged: "onOptionChanged", onShowing: "onShowing", onShown: "onShown", position: "position", rtlEnabled: "rtlEnabled", shading: "shading", shadingColor: "shadingColor", showIndicator: "showIndicator", showPane: "showPane", visible: "visible", width: "width", wrapperAttr: "wrapperAttr" }, outputs: { positionChange: "positionChange", visibleChange: "visibleChange" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewLoadPanelComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-card-view-load-panel', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { animation: [{
                type: Input
            }], container: [{
                type: Input
            }], deferRendering: [{
                type: Input
            }], delay: [{
                type: Input
            }], focusStateEnabled: [{
                type: Input
            }], height: [{
                type: Input
            }], hideOnOutsideClick: [{
                type: Input
            }], hideOnParentScroll: [{
                type: Input
            }], hint: [{
                type: Input
            }], hoverStateEnabled: [{
                type: Input
            }], indicatorOptions: [{
                type: Input
            }], indicatorSrc: [{
                type: Input
            }], maxHeight: [{
                type: Input
            }], maxWidth: [{
                type: Input
            }], message: [{
                type: Input
            }], minHeight: [{
                type: Input
            }], minWidth: [{
                type: Input
            }], onContentReady: [{
                type: Input
            }], onDisposing: [{
                type: Input
            }], onHidden: [{
                type: Input
            }], onHiding: [{
                type: Input
            }], onInitialized: [{
                type: Input
            }], onOptionChanged: [{
                type: Input
            }], onShowing: [{
                type: Input
            }], onShown: [{
                type: Input
            }], position: [{
                type: Input
            }], rtlEnabled: [{
                type: Input
            }], shading: [{
                type: Input
            }], shadingColor: [{
                type: Input
            }], showIndicator: [{
                type: Input
            }], showPane: [{
                type: Input
            }], visible: [{
                type: Input
            }], width: [{
                type: Input
            }], wrapperAttr: [{
                type: Input
            }], positionChange: [{
                type: Output
            }], visibleChange: [{
                type: Output
            }] } });
class DxoCardViewLoadPanelModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewLoadPanelModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewLoadPanelModule, imports: [DxoCardViewLoadPanelComponent], exports: [DxoCardViewLoadPanelComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewLoadPanelModule, imports: [DxoCardViewLoadPanelComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewLoadPanelModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoCardViewLoadPanelComponent
                    ],
                    exports: [
                        DxoCardViewLoadPanelComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoCardViewLookupComponent extends NestedOption {
    get allowClearing() {
        return this._getOption('allowClearing');
    }
    set allowClearing(value) {
        this._setOption('allowClearing', value);
    }
    get dataSource() {
        return this._getOption('dataSource');
    }
    set dataSource(value) {
        this._setOption('dataSource', value);
    }
    get displayExpr() {
        return this._getOption('displayExpr');
    }
    set displayExpr(value) {
        this._setOption('displayExpr', value);
    }
    get valueExpr() {
        return this._getOption('valueExpr');
    }
    set valueExpr(value) {
        this._setOption('valueExpr', value);
    }
    get _optionPath() {
        return 'lookup';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewLookupComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoCardViewLookupComponent, isStandalone: true, selector: "dxo-card-view-lookup", inputs: { allowClearing: "allowClearing", dataSource: "dataSource", displayExpr: "displayExpr", valueExpr: "valueExpr" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewLookupComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-card-view-lookup', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { allowClearing: [{
                type: Input
            }], dataSource: [{
                type: Input
            }], displayExpr: [{
                type: Input
            }], valueExpr: [{
                type: Input
            }] } });
class DxoCardViewLookupModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewLookupModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewLookupModule, imports: [DxoCardViewLookupComponent], exports: [DxoCardViewLookupComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewLookupModule, imports: [DxoCardViewLookupComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewLookupModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoCardViewLookupComponent
                    ],
                    exports: [
                        DxoCardViewLookupComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoCardViewMyComponent extends NestedOption {
    get x() {
        return this._getOption('x');
    }
    set x(value) {
        this._setOption('x', value);
    }
    get y() {
        return this._getOption('y');
    }
    set y(value) {
        this._setOption('y', value);
    }
    get _optionPath() {
        return 'my';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewMyComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoCardViewMyComponent, isStandalone: true, selector: "dxo-card-view-my", inputs: { x: "x", y: "y" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewMyComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-card-view-my', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { x: [{
                type: Input
            }], y: [{
                type: Input
            }] } });
class DxoCardViewMyModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewMyModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewMyModule, imports: [DxoCardViewMyComponent], exports: [DxoCardViewMyComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewMyModule, imports: [DxoCardViewMyComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewMyModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoCardViewMyComponent
                    ],
                    exports: [
                        DxoCardViewMyComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxiCardViewNumericRuleComponent extends CollectionNestedOption {
    get ignoreEmptyValue() {
        return this._getOption('ignoreEmptyValue');
    }
    set ignoreEmptyValue(value) {
        this._setOption('ignoreEmptyValue', value);
    }
    get message() {
        return this._getOption('message');
    }
    set message(value) {
        this._setOption('message', value);
    }
    get type() {
        return this._getOption('type');
    }
    set type(value) {
        this._setOption('type', value);
    }
    get _optionPath() {
        return 'validationRules';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
        this.type = 'numeric';
    }
    ngOnDestroy() {
        this._deleteRemovedOptions(this._fullOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiCardViewNumericRuleComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxiCardViewNumericRuleComponent, isStandalone: true, selector: "dxi-card-view-numeric-rule", inputs: { ignoreEmptyValue: "ignoreEmptyValue", message: "message", type: "type" }, providers: [
            NestedOptionHost,
            {
                provide: PROPERTY_TOKEN_validationRules,
                useExisting: DxiCardViewNumericRuleComponent,
            }
        ], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiCardViewNumericRuleComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxi-card-view-numeric-rule', template: '', imports: [DxIntegrationModule], providers: [
                        NestedOptionHost,
                        {
                            provide: PROPERTY_TOKEN_validationRules,
                            useExisting: DxiCardViewNumericRuleComponent,
                        }
                    ] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { ignoreEmptyValue: [{
                type: Input
            }], message: [{
                type: Input
            }], type: [{
                type: Input
            }] } });
class DxiCardViewNumericRuleModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiCardViewNumericRuleModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxiCardViewNumericRuleModule, imports: [DxiCardViewNumericRuleComponent], exports: [DxiCardViewNumericRuleComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiCardViewNumericRuleModule, imports: [DxiCardViewNumericRuleComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiCardViewNumericRuleModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxiCardViewNumericRuleComponent
                    ],
                    exports: [
                        DxiCardViewNumericRuleComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoCardViewOffsetComponent extends NestedOption {
    get x() {
        return this._getOption('x');
    }
    set x(value) {
        this._setOption('x', value);
    }
    get y() {
        return this._getOption('y');
    }
    set y(value) {
        this._setOption('y', value);
    }
    get _optionPath() {
        return 'offset';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewOffsetComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoCardViewOffsetComponent, isStandalone: true, selector: "dxo-card-view-offset", inputs: { x: "x", y: "y" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewOffsetComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-card-view-offset', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { x: [{
                type: Input
            }], y: [{
                type: Input
            }] } });
class DxoCardViewOffsetModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewOffsetModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewOffsetModule, imports: [DxoCardViewOffsetComponent], exports: [DxoCardViewOffsetComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewOffsetModule, imports: [DxoCardViewOffsetComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewOffsetModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoCardViewOffsetComponent
                    ],
                    exports: [
                        DxoCardViewOffsetComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoCardViewPagerComponent extends NestedOption {
    get allowedPageSizes() {
        return this._getOption('allowedPageSizes');
    }
    set allowedPageSizes(value) {
        this._setOption('allowedPageSizes', value);
    }
    get displayMode() {
        return this._getOption('displayMode');
    }
    set displayMode(value) {
        this._setOption('displayMode', value);
    }
    get infoText() {
        return this._getOption('infoText');
    }
    set infoText(value) {
        this._setOption('infoText', value);
    }
    get label() {
        return this._getOption('label');
    }
    set label(value) {
        this._setOption('label', value);
    }
    get showInfo() {
        return this._getOption('showInfo');
    }
    set showInfo(value) {
        this._setOption('showInfo', value);
    }
    get showNavigationButtons() {
        return this._getOption('showNavigationButtons');
    }
    set showNavigationButtons(value) {
        this._setOption('showNavigationButtons', value);
    }
    get showPageSizeSelector() {
        return this._getOption('showPageSizeSelector');
    }
    set showPageSizeSelector(value) {
        this._setOption('showPageSizeSelector', value);
    }
    get visible() {
        return this._getOption('visible');
    }
    set visible(value) {
        this._setOption('visible', value);
    }
    get _optionPath() {
        return 'pager';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewPagerComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoCardViewPagerComponent, isStandalone: true, selector: "dxo-card-view-pager", inputs: { allowedPageSizes: "allowedPageSizes", displayMode: "displayMode", infoText: "infoText", label: "label", showInfo: "showInfo", showNavigationButtons: "showNavigationButtons", showPageSizeSelector: "showPageSizeSelector", visible: "visible" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewPagerComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-card-view-pager', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { allowedPageSizes: [{
                type: Input
            }], displayMode: [{
                type: Input
            }], infoText: [{
                type: Input
            }], label: [{
                type: Input
            }], showInfo: [{
                type: Input
            }], showNavigationButtons: [{
                type: Input
            }], showPageSizeSelector: [{
                type: Input
            }], visible: [{
                type: Input
            }] } });
class DxoCardViewPagerModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewPagerModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewPagerModule, imports: [DxoCardViewPagerComponent], exports: [DxoCardViewPagerComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewPagerModule, imports: [DxoCardViewPagerComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewPagerModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoCardViewPagerComponent
                    ],
                    exports: [
                        DxoCardViewPagerComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoCardViewPagingComponent extends NestedOption {
    get enabled() {
        return this._getOption('enabled');
    }
    set enabled(value) {
        this._setOption('enabled', value);
    }
    get pageIndex() {
        return this._getOption('pageIndex');
    }
    set pageIndex(value) {
        this._setOption('pageIndex', value);
    }
    get pageSize() {
        return this._getOption('pageSize');
    }
    set pageSize(value) {
        this._setOption('pageSize', value);
    }
    get _optionPath() {
        return 'paging';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        this._createEventEmitters([
            { emit: 'pageIndexChange' },
            { emit: 'pageSizeChange' }
        ]);
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewPagingComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoCardViewPagingComponent, isStandalone: true, selector: "dxo-card-view-paging", inputs: { enabled: "enabled", pageIndex: "pageIndex", pageSize: "pageSize" }, outputs: { pageIndexChange: "pageIndexChange", pageSizeChange: "pageSizeChange" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewPagingComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-card-view-paging', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { enabled: [{
                type: Input
            }], pageIndex: [{
                type: Input
            }], pageSize: [{
                type: Input
            }], pageIndexChange: [{
                type: Output
            }], pageSizeChange: [{
                type: Output
            }] } });
class DxoCardViewPagingModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewPagingModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewPagingModule, imports: [DxoCardViewPagingComponent], exports: [DxoCardViewPagingComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewPagingModule, imports: [DxoCardViewPagingComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewPagingModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoCardViewPagingComponent
                    ],
                    exports: [
                        DxoCardViewPagingComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxiCardViewPatternRuleComponent extends CollectionNestedOption {
    get ignoreEmptyValue() {
        return this._getOption('ignoreEmptyValue');
    }
    set ignoreEmptyValue(value) {
        this._setOption('ignoreEmptyValue', value);
    }
    get message() {
        return this._getOption('message');
    }
    set message(value) {
        this._setOption('message', value);
    }
    get pattern() {
        return this._getOption('pattern');
    }
    set pattern(value) {
        this._setOption('pattern', value);
    }
    get type() {
        return this._getOption('type');
    }
    set type(value) {
        this._setOption('type', value);
    }
    get _optionPath() {
        return 'validationRules';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
        this.type = 'pattern';
    }
    ngOnDestroy() {
        this._deleteRemovedOptions(this._fullOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiCardViewPatternRuleComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxiCardViewPatternRuleComponent, isStandalone: true, selector: "dxi-card-view-pattern-rule", inputs: { ignoreEmptyValue: "ignoreEmptyValue", message: "message", pattern: "pattern", type: "type" }, providers: [
            NestedOptionHost,
            {
                provide: PROPERTY_TOKEN_validationRules,
                useExisting: DxiCardViewPatternRuleComponent,
            }
        ], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiCardViewPatternRuleComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxi-card-view-pattern-rule', template: '', imports: [DxIntegrationModule], providers: [
                        NestedOptionHost,
                        {
                            provide: PROPERTY_TOKEN_validationRules,
                            useExisting: DxiCardViewPatternRuleComponent,
                        }
                    ] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { ignoreEmptyValue: [{
                type: Input
            }], message: [{
                type: Input
            }], pattern: [{
                type: Input
            }], type: [{
                type: Input
            }] } });
class DxiCardViewPatternRuleModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiCardViewPatternRuleModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxiCardViewPatternRuleModule, imports: [DxiCardViewPatternRuleComponent], exports: [DxiCardViewPatternRuleComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiCardViewPatternRuleModule, imports: [DxiCardViewPatternRuleComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiCardViewPatternRuleModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxiCardViewPatternRuleComponent
                    ],
                    exports: [
                        DxiCardViewPatternRuleComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoCardViewPositionComponent extends NestedOption {
    get at() {
        return this._getOption('at');
    }
    set at(value) {
        this._setOption('at', value);
    }
    get boundary() {
        return this._getOption('boundary');
    }
    set boundary(value) {
        this._setOption('boundary', value);
    }
    get boundaryOffset() {
        return this._getOption('boundaryOffset');
    }
    set boundaryOffset(value) {
        this._setOption('boundaryOffset', value);
    }
    get collision() {
        return this._getOption('collision');
    }
    set collision(value) {
        this._setOption('collision', value);
    }
    get my() {
        return this._getOption('my');
    }
    set my(value) {
        this._setOption('my', value);
    }
    get of() {
        return this._getOption('of');
    }
    set of(value) {
        this._setOption('of', value);
    }
    get offset() {
        return this._getOption('offset');
    }
    set offset(value) {
        this._setOption('offset', value);
    }
    get _optionPath() {
        return 'position';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewPositionComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoCardViewPositionComponent, isStandalone: true, selector: "dxo-card-view-position", inputs: { at: "at", boundary: "boundary", boundaryOffset: "boundaryOffset", collision: "collision", my: "my", of: "of", offset: "offset" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewPositionComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-card-view-position', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { at: [{
                type: Input
            }], boundary: [{
                type: Input
            }], boundaryOffset: [{
                type: Input
            }], collision: [{
                type: Input
            }], my: [{
                type: Input
            }], of: [{
                type: Input
            }], offset: [{
                type: Input
            }] } });
class DxoCardViewPositionModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewPositionModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewPositionModule, imports: [DxoCardViewPositionComponent], exports: [DxoCardViewPositionComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewPositionModule, imports: [DxoCardViewPositionComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewPositionModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoCardViewPositionComponent
                    ],
                    exports: [
                        DxoCardViewPositionComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxiCardViewRangeRuleComponent extends CollectionNestedOption {
    get ignoreEmptyValue() {
        return this._getOption('ignoreEmptyValue');
    }
    set ignoreEmptyValue(value) {
        this._setOption('ignoreEmptyValue', value);
    }
    get max() {
        return this._getOption('max');
    }
    set max(value) {
        this._setOption('max', value);
    }
    get message() {
        return this._getOption('message');
    }
    set message(value) {
        this._setOption('message', value);
    }
    get min() {
        return this._getOption('min');
    }
    set min(value) {
        this._setOption('min', value);
    }
    get reevaluate() {
        return this._getOption('reevaluate');
    }
    set reevaluate(value) {
        this._setOption('reevaluate', value);
    }
    get type() {
        return this._getOption('type');
    }
    set type(value) {
        this._setOption('type', value);
    }
    get _optionPath() {
        return 'validationRules';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
        this.type = 'range';
    }
    ngOnDestroy() {
        this._deleteRemovedOptions(this._fullOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiCardViewRangeRuleComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxiCardViewRangeRuleComponent, isStandalone: true, selector: "dxi-card-view-range-rule", inputs: { ignoreEmptyValue: "ignoreEmptyValue", max: "max", message: "message", min: "min", reevaluate: "reevaluate", type: "type" }, providers: [
            NestedOptionHost,
            {
                provide: PROPERTY_TOKEN_validationRules,
                useExisting: DxiCardViewRangeRuleComponent,
            }
        ], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiCardViewRangeRuleComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxi-card-view-range-rule', template: '', imports: [DxIntegrationModule], providers: [
                        NestedOptionHost,
                        {
                            provide: PROPERTY_TOKEN_validationRules,
                            useExisting: DxiCardViewRangeRuleComponent,
                        }
                    ] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { ignoreEmptyValue: [{
                type: Input
            }], max: [{
                type: Input
            }], message: [{
                type: Input
            }], min: [{
                type: Input
            }], reevaluate: [{
                type: Input
            }], type: [{
                type: Input
            }] } });
class DxiCardViewRangeRuleModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiCardViewRangeRuleModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxiCardViewRangeRuleModule, imports: [DxiCardViewRangeRuleComponent], exports: [DxiCardViewRangeRuleComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiCardViewRangeRuleModule, imports: [DxiCardViewRangeRuleComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiCardViewRangeRuleModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxiCardViewRangeRuleComponent
                    ],
                    exports: [
                        DxiCardViewRangeRuleComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoCardViewRemoteOperationsComponent extends NestedOption {
    get filtering() {
        return this._getOption('filtering');
    }
    set filtering(value) {
        this._setOption('filtering', value);
    }
    get grouping() {
        return this._getOption('grouping');
    }
    set grouping(value) {
        this._setOption('grouping', value);
    }
    get paging() {
        return this._getOption('paging');
    }
    set paging(value) {
        this._setOption('paging', value);
    }
    get sorting() {
        return this._getOption('sorting');
    }
    set sorting(value) {
        this._setOption('sorting', value);
    }
    get _optionPath() {
        return 'remoteOperations';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewRemoteOperationsComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoCardViewRemoteOperationsComponent, isStandalone: true, selector: "dxo-card-view-remote-operations", inputs: { filtering: "filtering", grouping: "grouping", paging: "paging", sorting: "sorting" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewRemoteOperationsComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-card-view-remote-operations', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { filtering: [{
                type: Input
            }], grouping: [{
                type: Input
            }], paging: [{
                type: Input
            }], sorting: [{
                type: Input
            }] } });
class DxoCardViewRemoteOperationsModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewRemoteOperationsModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewRemoteOperationsModule, imports: [DxoCardViewRemoteOperationsComponent], exports: [DxoCardViewRemoteOperationsComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewRemoteOperationsModule, imports: [DxoCardViewRemoteOperationsComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewRemoteOperationsModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoCardViewRemoteOperationsComponent
                    ],
                    exports: [
                        DxoCardViewRemoteOperationsComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxiCardViewRequiredRuleComponent extends CollectionNestedOption {
    get message() {
        return this._getOption('message');
    }
    set message(value) {
        this._setOption('message', value);
    }
    get trim() {
        return this._getOption('trim');
    }
    set trim(value) {
        this._setOption('trim', value);
    }
    get type() {
        return this._getOption('type');
    }
    set type(value) {
        this._setOption('type', value);
    }
    get _optionPath() {
        return 'validationRules';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
        this.type = 'required';
    }
    ngOnDestroy() {
        this._deleteRemovedOptions(this._fullOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiCardViewRequiredRuleComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxiCardViewRequiredRuleComponent, isStandalone: true, selector: "dxi-card-view-required-rule", inputs: { message: "message", trim: "trim", type: "type" }, providers: [
            NestedOptionHost,
            {
                provide: PROPERTY_TOKEN_validationRules,
                useExisting: DxiCardViewRequiredRuleComponent,
            }
        ], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiCardViewRequiredRuleComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxi-card-view-required-rule', template: '', imports: [DxIntegrationModule], providers: [
                        NestedOptionHost,
                        {
                            provide: PROPERTY_TOKEN_validationRules,
                            useExisting: DxiCardViewRequiredRuleComponent,
                        }
                    ] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { message: [{
                type: Input
            }], trim: [{
                type: Input
            }], type: [{
                type: Input
            }] } });
class DxiCardViewRequiredRuleModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiCardViewRequiredRuleModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxiCardViewRequiredRuleModule, imports: [DxiCardViewRequiredRuleComponent], exports: [DxiCardViewRequiredRuleComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiCardViewRequiredRuleModule, imports: [DxiCardViewRequiredRuleComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiCardViewRequiredRuleModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxiCardViewRequiredRuleComponent
                    ],
                    exports: [
                        DxiCardViewRequiredRuleComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoCardViewScrollingComponent extends NestedOption {
    get scrollByContent() {
        return this._getOption('scrollByContent');
    }
    set scrollByContent(value) {
        this._setOption('scrollByContent', value);
    }
    get scrollByThumb() {
        return this._getOption('scrollByThumb');
    }
    set scrollByThumb(value) {
        this._setOption('scrollByThumb', value);
    }
    get showScrollbar() {
        return this._getOption('showScrollbar');
    }
    set showScrollbar(value) {
        this._setOption('showScrollbar', value);
    }
    get useNative() {
        return this._getOption('useNative');
    }
    set useNative(value) {
        this._setOption('useNative', value);
    }
    get _optionPath() {
        return 'scrolling';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewScrollingComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoCardViewScrollingComponent, isStandalone: true, selector: "dxo-card-view-scrolling", inputs: { scrollByContent: "scrollByContent", scrollByThumb: "scrollByThumb", showScrollbar: "showScrollbar", useNative: "useNative" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewScrollingComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-card-view-scrolling', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { scrollByContent: [{
                type: Input
            }], scrollByThumb: [{
                type: Input
            }], showScrollbar: [{
                type: Input
            }], useNative: [{
                type: Input
            }] } });
class DxoCardViewScrollingModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewScrollingModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewScrollingModule, imports: [DxoCardViewScrollingComponent], exports: [DxoCardViewScrollingComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewScrollingModule, imports: [DxoCardViewScrollingComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewScrollingModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoCardViewScrollingComponent
                    ],
                    exports: [
                        DxoCardViewScrollingComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoCardViewSearchPanelComponent extends NestedOption {
    get highlightCaseSensitive() {
        return this._getOption('highlightCaseSensitive');
    }
    set highlightCaseSensitive(value) {
        this._setOption('highlightCaseSensitive', value);
    }
    get highlightSearchText() {
        return this._getOption('highlightSearchText');
    }
    set highlightSearchText(value) {
        this._setOption('highlightSearchText', value);
    }
    get placeholder() {
        return this._getOption('placeholder');
    }
    set placeholder(value) {
        this._setOption('placeholder', value);
    }
    get searchVisibleColumnsOnly() {
        return this._getOption('searchVisibleColumnsOnly');
    }
    set searchVisibleColumnsOnly(value) {
        this._setOption('searchVisibleColumnsOnly', value);
    }
    get text() {
        return this._getOption('text');
    }
    set text(value) {
        this._setOption('text', value);
    }
    get visible() {
        return this._getOption('visible');
    }
    set visible(value) {
        this._setOption('visible', value);
    }
    get width() {
        return this._getOption('width');
    }
    set width(value) {
        this._setOption('width', value);
    }
    get _optionPath() {
        return 'searchPanel';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        this._createEventEmitters([
            { emit: 'textChange' }
        ]);
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewSearchPanelComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoCardViewSearchPanelComponent, isStandalone: true, selector: "dxo-card-view-search-panel", inputs: { highlightCaseSensitive: "highlightCaseSensitive", highlightSearchText: "highlightSearchText", placeholder: "placeholder", searchVisibleColumnsOnly: "searchVisibleColumnsOnly", text: "text", visible: "visible", width: "width" }, outputs: { textChange: "textChange" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewSearchPanelComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-card-view-search-panel', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { highlightCaseSensitive: [{
                type: Input
            }], highlightSearchText: [{
                type: Input
            }], placeholder: [{
                type: Input
            }], searchVisibleColumnsOnly: [{
                type: Input
            }], text: [{
                type: Input
            }], visible: [{
                type: Input
            }], width: [{
                type: Input
            }], textChange: [{
                type: Output
            }] } });
class DxoCardViewSearchPanelModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewSearchPanelModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewSearchPanelModule, imports: [DxoCardViewSearchPanelComponent], exports: [DxoCardViewSearchPanelComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewSearchPanelModule, imports: [DxoCardViewSearchPanelComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewSearchPanelModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoCardViewSearchPanelComponent
                    ],
                    exports: [
                        DxoCardViewSearchPanelComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoCardViewSearchComponent extends NestedOption {
    get editorOptions() {
        return this._getOption('editorOptions');
    }
    set editorOptions(value) {
        this._setOption('editorOptions', value);
    }
    get enabled() {
        return this._getOption('enabled');
    }
    set enabled(value) {
        this._setOption('enabled', value);
    }
    get timeout() {
        return this._getOption('timeout');
    }
    set timeout(value) {
        this._setOption('timeout', value);
    }
    get mode() {
        return this._getOption('mode');
    }
    set mode(value) {
        this._setOption('mode', value);
    }
    get searchExpr() {
        return this._getOption('searchExpr');
    }
    set searchExpr(value) {
        this._setOption('searchExpr', value);
    }
    get _optionPath() {
        return 'search';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewSearchComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoCardViewSearchComponent, isStandalone: true, selector: "dxo-card-view-search", inputs: { editorOptions: "editorOptions", enabled: "enabled", timeout: "timeout", mode: "mode", searchExpr: "searchExpr" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewSearchComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-card-view-search', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { editorOptions: [{
                type: Input
            }], enabled: [{
                type: Input
            }], timeout: [{
                type: Input
            }], mode: [{
                type: Input
            }], searchExpr: [{
                type: Input
            }] } });
class DxoCardViewSearchModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewSearchModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewSearchModule, imports: [DxoCardViewSearchComponent], exports: [DxoCardViewSearchComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewSearchModule, imports: [DxoCardViewSearchComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewSearchModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoCardViewSearchComponent
                    ],
                    exports: [
                        DxoCardViewSearchComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoCardViewSelectionComponent extends NestedOption {
    get allowSelectAll() {
        return this._getOption('allowSelectAll');
    }
    set allowSelectAll(value) {
        this._setOption('allowSelectAll', value);
    }
    get recursive() {
        return this._getOption('recursive');
    }
    set recursive(value) {
        this._setOption('recursive', value);
    }
    get selectByClick() {
        return this._getOption('selectByClick');
    }
    set selectByClick(value) {
        this._setOption('selectByClick', value);
    }
    get mode() {
        return this._getOption('mode');
    }
    set mode(value) {
        this._setOption('mode', value);
    }
    get selectAllMode() {
        return this._getOption('selectAllMode');
    }
    set selectAllMode(value) {
        this._setOption('selectAllMode', value);
    }
    get showCheckBoxesMode() {
        return this._getOption('showCheckBoxesMode');
    }
    set showCheckBoxesMode(value) {
        this._setOption('showCheckBoxesMode', value);
    }
    get _optionPath() {
        return 'selection';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewSelectionComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoCardViewSelectionComponent, isStandalone: true, selector: "dxo-card-view-selection", inputs: { allowSelectAll: "allowSelectAll", recursive: "recursive", selectByClick: "selectByClick", mode: "mode", selectAllMode: "selectAllMode", showCheckBoxesMode: "showCheckBoxesMode" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewSelectionComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-card-view-selection', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { allowSelectAll: [{
                type: Input
            }], recursive: [{
                type: Input
            }], selectByClick: [{
                type: Input
            }], mode: [{
                type: Input
            }], selectAllMode: [{
                type: Input
            }], showCheckBoxesMode: [{
                type: Input
            }] } });
class DxoCardViewSelectionModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewSelectionModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewSelectionModule, imports: [DxoCardViewSelectionComponent], exports: [DxoCardViewSelectionComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewSelectionModule, imports: [DxoCardViewSelectionComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewSelectionModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoCardViewSelectionComponent
                    ],
                    exports: [
                        DxoCardViewSelectionComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoCardViewShowComponent extends NestedOption {
    get complete() {
        return this._getOption('complete');
    }
    set complete(value) {
        this._setOption('complete', value);
    }
    get delay() {
        return this._getOption('delay');
    }
    set delay(value) {
        this._setOption('delay', value);
    }
    get direction() {
        return this._getOption('direction');
    }
    set direction(value) {
        this._setOption('direction', value);
    }
    get duration() {
        return this._getOption('duration');
    }
    set duration(value) {
        this._setOption('duration', value);
    }
    get easing() {
        return this._getOption('easing');
    }
    set easing(value) {
        this._setOption('easing', value);
    }
    get from() {
        return this._getOption('from');
    }
    set from(value) {
        this._setOption('from', value);
    }
    get staggerDelay() {
        return this._getOption('staggerDelay');
    }
    set staggerDelay(value) {
        this._setOption('staggerDelay', value);
    }
    get start() {
        return this._getOption('start');
    }
    set start(value) {
        this._setOption('start', value);
    }
    get to() {
        return this._getOption('to');
    }
    set to(value) {
        this._setOption('to', value);
    }
    get type() {
        return this._getOption('type');
    }
    set type(value) {
        this._setOption('type', value);
    }
    get _optionPath() {
        return 'show';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewShowComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoCardViewShowComponent, isStandalone: true, selector: "dxo-card-view-show", inputs: { complete: "complete", delay: "delay", direction: "direction", duration: "duration", easing: "easing", from: "from", staggerDelay: "staggerDelay", start: "start", to: "to", type: "type" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewShowComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-card-view-show', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { complete: [{
                type: Input
            }], delay: [{
                type: Input
            }], direction: [{
                type: Input
            }], duration: [{
                type: Input
            }], easing: [{
                type: Input
            }], from: [{
                type: Input
            }], staggerDelay: [{
                type: Input
            }], start: [{
                type: Input
            }], to: [{
                type: Input
            }], type: [{
                type: Input
            }] } });
class DxoCardViewShowModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewShowModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewShowModule, imports: [DxoCardViewShowComponent], exports: [DxoCardViewShowComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewShowModule, imports: [DxoCardViewShowComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewShowModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoCardViewShowComponent
                    ],
                    exports: [
                        DxoCardViewShowComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxiCardViewSimpleItemComponent extends CollectionNestedOption {
    set _validationRulesContentChildren(value) {
        this.setChildren('validationRules', value);
    }
    get aiOptions() {
        return this._getOption('aiOptions');
    }
    set aiOptions(value) {
        this._setOption('aiOptions', value);
    }
    get colSpan() {
        return this._getOption('colSpan');
    }
    set colSpan(value) {
        this._setOption('colSpan', value);
    }
    get cssClass() {
        return this._getOption('cssClass');
    }
    set cssClass(value) {
        this._setOption('cssClass', value);
    }
    get dataField() {
        return this._getOption('dataField');
    }
    set dataField(value) {
        this._setOption('dataField', value);
    }
    get editorOptions() {
        return this._getOption('editorOptions');
    }
    set editorOptions(value) {
        this._setOption('editorOptions', value);
    }
    get editorType() {
        return this._getOption('editorType');
    }
    set editorType(value) {
        this._setOption('editorType', value);
    }
    get helpText() {
        return this._getOption('helpText');
    }
    set helpText(value) {
        this._setOption('helpText', value);
    }
    get isRequired() {
        return this._getOption('isRequired');
    }
    set isRequired(value) {
        this._setOption('isRequired', value);
    }
    get itemType() {
        return this._getOption('itemType');
    }
    set itemType(value) {
        this._setOption('itemType', value);
    }
    get label() {
        return this._getOption('label');
    }
    set label(value) {
        this._setOption('label', value);
    }
    get name() {
        return this._getOption('name');
    }
    set name(value) {
        this._setOption('name', value);
    }
    get template() {
        return this._getOption('template');
    }
    set template(value) {
        this._setOption('template', value);
    }
    get validationRules() {
        return this._getOption('validationRules');
    }
    set validationRules(value) {
        this._setOption('validationRules', value);
    }
    get visible() {
        return this._getOption('visible');
    }
    set visible(value) {
        this._setOption('visible', value);
    }
    get visibleIndex() {
        return this._getOption('visibleIndex');
    }
    set visibleIndex(value) {
        this._setOption('visibleIndex', value);
    }
    get _optionPath() {
        return 'items';
    }
    constructor(parentOptionHost, optionHost, renderer, document, templateHost, element) {
        super();
        this.renderer = renderer;
        this.document = document;
        this.element = element;
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
        templateHost.setHost(this);
        this.itemType = 'simple';
    }
    setTemplate(template) {
        this.template = template;
    }
    ngAfterViewInit() {
        extractTemplate(this, this.element, this.renderer, this.document);
    }
    ngOnDestroy() {
        this._deleteRemovedOptions(this._fullOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiCardViewSimpleItemComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }, { token: i0.Renderer2 }, { token: DOCUMENT }, { token: i1.DxTemplateHost, host: true }, { token: i0.ElementRef }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxiCardViewSimpleItemComponent, isStandalone: true, selector: "dxi-card-view-simple-item", inputs: { aiOptions: "aiOptions", colSpan: "colSpan", cssClass: "cssClass", dataField: "dataField", editorOptions: "editorOptions", editorType: "editorType", helpText: "helpText", isRequired: "isRequired", itemType: "itemType", label: "label", name: "name", template: "template", validationRules: "validationRules", visible: "visible", visibleIndex: "visibleIndex" }, providers: [
            NestedOptionHost,
            DxTemplateHost,
            {
                provide: PROPERTY_TOKEN_items,
                useExisting: DxiCardViewSimpleItemComponent,
            }
        ], queries: [{ propertyName: "_validationRulesContentChildren", predicate: PROPERTY_TOKEN_validationRules }], usesInheritance: true, ngImport: i0, template: '<ng-content></ng-content>', isInline: true, styles: [":host{display:block}\n"], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiCardViewSimpleItemComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxi-card-view-simple-item', template: '<ng-content></ng-content>', imports: [DxIntegrationModule], providers: [
                        NestedOptionHost,
                        DxTemplateHost,
                        {
                            provide: PROPERTY_TOKEN_items,
                            useExisting: DxiCardViewSimpleItemComponent,
                        }
                    ], styles: [":host{display:block}\n"] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }, { type: i0.Renderer2 }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [DOCUMENT]
                }] }, { type: i1.DxTemplateHost, decorators: [{
                    type: Host
                }] }, { type: i0.ElementRef }], propDecorators: { _validationRulesContentChildren: [{
                type: ContentChildren,
                args: [PROPERTY_TOKEN_validationRules]
            }], aiOptions: [{
                type: Input
            }], colSpan: [{
                type: Input
            }], cssClass: [{
                type: Input
            }], dataField: [{
                type: Input
            }], editorOptions: [{
                type: Input
            }], editorType: [{
                type: Input
            }], helpText: [{
                type: Input
            }], isRequired: [{
                type: Input
            }], itemType: [{
                type: Input
            }], label: [{
                type: Input
            }], name: [{
                type: Input
            }], template: [{
                type: Input
            }], validationRules: [{
                type: Input
            }], visible: [{
                type: Input
            }], visibleIndex: [{
                type: Input
            }] } });
class DxiCardViewSimpleItemModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiCardViewSimpleItemModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxiCardViewSimpleItemModule, imports: [DxiCardViewSimpleItemComponent], exports: [DxiCardViewSimpleItemComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiCardViewSimpleItemModule, imports: [DxiCardViewSimpleItemComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiCardViewSimpleItemModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxiCardViewSimpleItemComponent
                    ],
                    exports: [
                        DxiCardViewSimpleItemComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoCardViewSortingComponent extends NestedOption {
    get ascendingText() {
        return this._getOption('ascendingText');
    }
    set ascendingText(value) {
        this._setOption('ascendingText', value);
    }
    get clearText() {
        return this._getOption('clearText');
    }
    set clearText(value) {
        this._setOption('clearText', value);
    }
    get descendingText() {
        return this._getOption('descendingText');
    }
    set descendingText(value) {
        this._setOption('descendingText', value);
    }
    get mode() {
        return this._getOption('mode');
    }
    set mode(value) {
        this._setOption('mode', value);
    }
    get showSortIndexes() {
        return this._getOption('showSortIndexes');
    }
    set showSortIndexes(value) {
        this._setOption('showSortIndexes', value);
    }
    get _optionPath() {
        return 'sorting';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewSortingComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoCardViewSortingComponent, isStandalone: true, selector: "dxo-card-view-sorting", inputs: { ascendingText: "ascendingText", clearText: "clearText", descendingText: "descendingText", mode: "mode", showSortIndexes: "showSortIndexes" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewSortingComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-card-view-sorting', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { ascendingText: [{
                type: Input
            }], clearText: [{
                type: Input
            }], descendingText: [{
                type: Input
            }], mode: [{
                type: Input
            }], showSortIndexes: [{
                type: Input
            }] } });
class DxoCardViewSortingModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewSortingModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewSortingModule, imports: [DxoCardViewSortingComponent], exports: [DxoCardViewSortingComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewSortingModule, imports: [DxoCardViewSortingComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewSortingModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoCardViewSortingComponent
                    ],
                    exports: [
                        DxoCardViewSortingComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxiCardViewStringLengthRuleComponent extends CollectionNestedOption {
    get ignoreEmptyValue() {
        return this._getOption('ignoreEmptyValue');
    }
    set ignoreEmptyValue(value) {
        this._setOption('ignoreEmptyValue', value);
    }
    get max() {
        return this._getOption('max');
    }
    set max(value) {
        this._setOption('max', value);
    }
    get message() {
        return this._getOption('message');
    }
    set message(value) {
        this._setOption('message', value);
    }
    get min() {
        return this._getOption('min');
    }
    set min(value) {
        this._setOption('min', value);
    }
    get trim() {
        return this._getOption('trim');
    }
    set trim(value) {
        this._setOption('trim', value);
    }
    get type() {
        return this._getOption('type');
    }
    set type(value) {
        this._setOption('type', value);
    }
    get _optionPath() {
        return 'validationRules';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
        this.type = 'stringLength';
    }
    ngOnDestroy() {
        this._deleteRemovedOptions(this._fullOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiCardViewStringLengthRuleComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxiCardViewStringLengthRuleComponent, isStandalone: true, selector: "dxi-card-view-string-length-rule", inputs: { ignoreEmptyValue: "ignoreEmptyValue", max: "max", message: "message", min: "min", trim: "trim", type: "type" }, providers: [
            NestedOptionHost,
            {
                provide: PROPERTY_TOKEN_validationRules,
                useExisting: DxiCardViewStringLengthRuleComponent,
            }
        ], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiCardViewStringLengthRuleComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxi-card-view-string-length-rule', template: '', imports: [DxIntegrationModule], providers: [
                        NestedOptionHost,
                        {
                            provide: PROPERTY_TOKEN_validationRules,
                            useExisting: DxiCardViewStringLengthRuleComponent,
                        }
                    ] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { ignoreEmptyValue: [{
                type: Input
            }], max: [{
                type: Input
            }], message: [{
                type: Input
            }], min: [{
                type: Input
            }], trim: [{
                type: Input
            }], type: [{
                type: Input
            }] } });
class DxiCardViewStringLengthRuleModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiCardViewStringLengthRuleModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxiCardViewStringLengthRuleModule, imports: [DxiCardViewStringLengthRuleComponent], exports: [DxiCardViewStringLengthRuleComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiCardViewStringLengthRuleModule, imports: [DxiCardViewStringLengthRuleComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiCardViewStringLengthRuleModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxiCardViewStringLengthRuleComponent
                    ],
                    exports: [
                        DxiCardViewStringLengthRuleComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxiCardViewTabComponent extends CollectionNestedOption {
    set _itemsContentChildren(value) {
        this.setChildren('items', value);
    }
    get alignItemLabels() {
        return this._getOption('alignItemLabels');
    }
    set alignItemLabels(value) {
        this._setOption('alignItemLabels', value);
    }
    get badge() {
        return this._getOption('badge');
    }
    set badge(value) {
        this._setOption('badge', value);
    }
    get colCount() {
        return this._getOption('colCount');
    }
    set colCount(value) {
        this._setOption('colCount', value);
    }
    get colCountByScreen() {
        return this._getOption('colCountByScreen');
    }
    set colCountByScreen(value) {
        this._setOption('colCountByScreen', value);
    }
    get disabled() {
        return this._getOption('disabled');
    }
    set disabled(value) {
        this._setOption('disabled', value);
    }
    get icon() {
        return this._getOption('icon');
    }
    set icon(value) {
        this._setOption('icon', value);
    }
    get items() {
        return this._getOption('items');
    }
    set items(value) {
        this._setOption('items', value);
    }
    get tabTemplate() {
        return this._getOption('tabTemplate');
    }
    set tabTemplate(value) {
        this._setOption('tabTemplate', value);
    }
    get template() {
        return this._getOption('template');
    }
    set template(value) {
        this._setOption('template', value);
    }
    get title() {
        return this._getOption('title');
    }
    set title(value) {
        this._setOption('title', value);
    }
    get _optionPath() {
        return 'tabs';
    }
    constructor(parentOptionHost, optionHost, renderer, document, templateHost, element) {
        super();
        this.renderer = renderer;
        this.document = document;
        this.element = element;
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
        templateHost.setHost(this);
    }
    setTemplate(template) {
        this.template = template;
    }
    ngAfterViewInit() {
        extractTemplate(this, this.element, this.renderer, this.document);
    }
    ngOnDestroy() {
        this._deleteRemovedOptions(this._fullOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiCardViewTabComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }, { token: i0.Renderer2 }, { token: DOCUMENT }, { token: i1.DxTemplateHost, host: true }, { token: i0.ElementRef }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxiCardViewTabComponent, isStandalone: true, selector: "dxi-card-view-tab", inputs: { alignItemLabels: "alignItemLabels", badge: "badge", colCount: "colCount", colCountByScreen: "colCountByScreen", disabled: "disabled", icon: "icon", items: "items", tabTemplate: "tabTemplate", template: "template", title: "title" }, providers: [
            NestedOptionHost,
            DxTemplateHost,
            {
                provide: PROPERTY_TOKEN_tabs,
                useExisting: DxiCardViewTabComponent,
            }
        ], queries: [{ propertyName: "_itemsContentChildren", predicate: PROPERTY_TOKEN_items }], usesInheritance: true, ngImport: i0, template: '<ng-content></ng-content>', isInline: true, styles: [":host{display:block}\n"], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiCardViewTabComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxi-card-view-tab', template: '<ng-content></ng-content>', imports: [DxIntegrationModule], providers: [
                        NestedOptionHost,
                        DxTemplateHost,
                        {
                            provide: PROPERTY_TOKEN_tabs,
                            useExisting: DxiCardViewTabComponent,
                        }
                    ], styles: [":host{display:block}\n"] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }, { type: i0.Renderer2 }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [DOCUMENT]
                }] }, { type: i1.DxTemplateHost, decorators: [{
                    type: Host
                }] }, { type: i0.ElementRef }], propDecorators: { _itemsContentChildren: [{
                type: ContentChildren,
                args: [PROPERTY_TOKEN_items]
            }], alignItemLabels: [{
                type: Input
            }], badge: [{
                type: Input
            }], colCount: [{
                type: Input
            }], colCountByScreen: [{
                type: Input
            }], disabled: [{
                type: Input
            }], icon: [{
                type: Input
            }], items: [{
                type: Input
            }], tabTemplate: [{
                type: Input
            }], template: [{
                type: Input
            }], title: [{
                type: Input
            }] } });
class DxiCardViewTabModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiCardViewTabModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxiCardViewTabModule, imports: [DxiCardViewTabComponent], exports: [DxiCardViewTabComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiCardViewTabModule, imports: [DxiCardViewTabComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiCardViewTabModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxiCardViewTabComponent
                    ],
                    exports: [
                        DxiCardViewTabComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxiCardViewTabPanelOptionsItemComponent extends CollectionNestedOption {
    get badge() {
        return this._getOption('badge');
    }
    set badge(value) {
        this._setOption('badge', value);
    }
    get disabled() {
        return this._getOption('disabled');
    }
    set disabled(value) {
        this._setOption('disabled', value);
    }
    get html() {
        return this._getOption('html');
    }
    set html(value) {
        this._setOption('html', value);
    }
    get icon() {
        return this._getOption('icon');
    }
    set icon(value) {
        this._setOption('icon', value);
    }
    get tabTemplate() {
        return this._getOption('tabTemplate');
    }
    set tabTemplate(value) {
        this._setOption('tabTemplate', value);
    }
    get template() {
        return this._getOption('template');
    }
    set template(value) {
        this._setOption('template', value);
    }
    get text() {
        return this._getOption('text');
    }
    set text(value) {
        this._setOption('text', value);
    }
    get title() {
        return this._getOption('title');
    }
    set title(value) {
        this._setOption('title', value);
    }
    get visible() {
        return this._getOption('visible');
    }
    set visible(value) {
        this._setOption('visible', value);
    }
    get _optionPath() {
        return 'items';
    }
    constructor(parentOptionHost, optionHost, renderer, document, templateHost, element) {
        super();
        this.renderer = renderer;
        this.document = document;
        this.element = element;
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
        templateHost.setHost(this);
    }
    setTemplate(template) {
        this.template = template;
    }
    ngAfterViewInit() {
        extractTemplate(this, this.element, this.renderer, this.document);
    }
    ngOnDestroy() {
        this._deleteRemovedOptions(this._fullOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiCardViewTabPanelOptionsItemComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }, { token: i0.Renderer2 }, { token: DOCUMENT }, { token: i1.DxTemplateHost, host: true }, { token: i0.ElementRef }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxiCardViewTabPanelOptionsItemComponent, isStandalone: true, selector: "dxi-card-view-tab-panel-options-item", inputs: { badge: "badge", disabled: "disabled", html: "html", icon: "icon", tabTemplate: "tabTemplate", template: "template", text: "text", title: "title", visible: "visible" }, providers: [
            NestedOptionHost,
            DxTemplateHost,
            {
                provide: PROPERTY_TOKEN_items,
                useExisting: DxiCardViewTabPanelOptionsItemComponent,
            }
        ], usesInheritance: true, ngImport: i0, template: '<ng-content></ng-content>', isInline: true, styles: [":host{display:block}\n"], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiCardViewTabPanelOptionsItemComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxi-card-view-tab-panel-options-item', template: '<ng-content></ng-content>', imports: [DxIntegrationModule], providers: [
                        NestedOptionHost,
                        DxTemplateHost,
                        {
                            provide: PROPERTY_TOKEN_items,
                            useExisting: DxiCardViewTabPanelOptionsItemComponent,
                        }
                    ], styles: [":host{display:block}\n"] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }, { type: i0.Renderer2 }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [DOCUMENT]
                }] }, { type: i1.DxTemplateHost, decorators: [{
                    type: Host
                }] }, { type: i0.ElementRef }], propDecorators: { badge: [{
                type: Input
            }], disabled: [{
                type: Input
            }], html: [{
                type: Input
            }], icon: [{
                type: Input
            }], tabTemplate: [{
                type: Input
            }], template: [{
                type: Input
            }], text: [{
                type: Input
            }], title: [{
                type: Input
            }], visible: [{
                type: Input
            }] } });
class DxiCardViewTabPanelOptionsItemModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiCardViewTabPanelOptionsItemModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxiCardViewTabPanelOptionsItemModule, imports: [DxiCardViewTabPanelOptionsItemComponent], exports: [DxiCardViewTabPanelOptionsItemComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiCardViewTabPanelOptionsItemModule, imports: [DxiCardViewTabPanelOptionsItemComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiCardViewTabPanelOptionsItemModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxiCardViewTabPanelOptionsItemComponent
                    ],
                    exports: [
                        DxiCardViewTabPanelOptionsItemComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoCardViewTabPanelOptionsComponent extends NestedOption {
    set _itemsContentChildren(value) {
        this.setChildren('items', value);
    }
    get accessKey() {
        return this._getOption('accessKey');
    }
    set accessKey(value) {
        this._setOption('accessKey', value);
    }
    get activeStateEnabled() {
        return this._getOption('activeStateEnabled');
    }
    set activeStateEnabled(value) {
        this._setOption('activeStateEnabled', value);
    }
    get animationEnabled() {
        return this._getOption('animationEnabled');
    }
    set animationEnabled(value) {
        this._setOption('animationEnabled', value);
    }
    get dataSource() {
        return this._getOption('dataSource');
    }
    set dataSource(value) {
        this._setOption('dataSource', value);
    }
    get deferRendering() {
        return this._getOption('deferRendering');
    }
    set deferRendering(value) {
        this._setOption('deferRendering', value);
    }
    get disabled() {
        return this._getOption('disabled');
    }
    set disabled(value) {
        this._setOption('disabled', value);
    }
    get elementAttr() {
        return this._getOption('elementAttr');
    }
    set elementAttr(value) {
        this._setOption('elementAttr', value);
    }
    get focusStateEnabled() {
        return this._getOption('focusStateEnabled');
    }
    set focusStateEnabled(value) {
        this._setOption('focusStateEnabled', value);
    }
    get height() {
        return this._getOption('height');
    }
    set height(value) {
        this._setOption('height', value);
    }
    get hint() {
        return this._getOption('hint');
    }
    set hint(value) {
        this._setOption('hint', value);
    }
    get hoverStateEnabled() {
        return this._getOption('hoverStateEnabled');
    }
    set hoverStateEnabled(value) {
        this._setOption('hoverStateEnabled', value);
    }
    get iconPosition() {
        return this._getOption('iconPosition');
    }
    set iconPosition(value) {
        this._setOption('iconPosition', value);
    }
    get itemHoldTimeout() {
        return this._getOption('itemHoldTimeout');
    }
    set itemHoldTimeout(value) {
        this._setOption('itemHoldTimeout', value);
    }
    get items() {
        return this._getOption('items');
    }
    set items(value) {
        this._setOption('items', value);
    }
    get itemTemplate() {
        return this._getOption('itemTemplate');
    }
    set itemTemplate(value) {
        this._setOption('itemTemplate', value);
    }
    get itemTitleTemplate() {
        return this._getOption('itemTitleTemplate');
    }
    set itemTitleTemplate(value) {
        this._setOption('itemTitleTemplate', value);
    }
    get keyExpr() {
        return this._getOption('keyExpr');
    }
    set keyExpr(value) {
        this._setOption('keyExpr', value);
    }
    get loop() {
        return this._getOption('loop');
    }
    set loop(value) {
        this._setOption('loop', value);
    }
    get noDataText() {
        return this._getOption('noDataText');
    }
    set noDataText(value) {
        this._setOption('noDataText', value);
    }
    get onContentReady() {
        return this._getOption('onContentReady');
    }
    set onContentReady(value) {
        this._setOption('onContentReady', value);
    }
    get onDisposing() {
        return this._getOption('onDisposing');
    }
    set onDisposing(value) {
        this._setOption('onDisposing', value);
    }
    get onInitialized() {
        return this._getOption('onInitialized');
    }
    set onInitialized(value) {
        this._setOption('onInitialized', value);
    }
    get onItemClick() {
        return this._getOption('onItemClick');
    }
    set onItemClick(value) {
        this._setOption('onItemClick', value);
    }
    get onItemContextMenu() {
        return this._getOption('onItemContextMenu');
    }
    set onItemContextMenu(value) {
        this._setOption('onItemContextMenu', value);
    }
    get onItemHold() {
        return this._getOption('onItemHold');
    }
    set onItemHold(value) {
        this._setOption('onItemHold', value);
    }
    get onItemRendered() {
        return this._getOption('onItemRendered');
    }
    set onItemRendered(value) {
        this._setOption('onItemRendered', value);
    }
    get onOptionChanged() {
        return this._getOption('onOptionChanged');
    }
    set onOptionChanged(value) {
        this._setOption('onOptionChanged', value);
    }
    get onSelectionChanged() {
        return this._getOption('onSelectionChanged');
    }
    set onSelectionChanged(value) {
        this._setOption('onSelectionChanged', value);
    }
    get onSelectionChanging() {
        return this._getOption('onSelectionChanging');
    }
    set onSelectionChanging(value) {
        this._setOption('onSelectionChanging', value);
    }
    get onTitleClick() {
        return this._getOption('onTitleClick');
    }
    set onTitleClick(value) {
        this._setOption('onTitleClick', value);
    }
    get onTitleHold() {
        return this._getOption('onTitleHold');
    }
    set onTitleHold(value) {
        this._setOption('onTitleHold', value);
    }
    get onTitleRendered() {
        return this._getOption('onTitleRendered');
    }
    set onTitleRendered(value) {
        this._setOption('onTitleRendered', value);
    }
    get repaintChangesOnly() {
        return this._getOption('repaintChangesOnly');
    }
    set repaintChangesOnly(value) {
        this._setOption('repaintChangesOnly', value);
    }
    get rtlEnabled() {
        return this._getOption('rtlEnabled');
    }
    set rtlEnabled(value) {
        this._setOption('rtlEnabled', value);
    }
    get scrollByContent() {
        return this._getOption('scrollByContent');
    }
    set scrollByContent(value) {
        this._setOption('scrollByContent', value);
    }
    get scrollingEnabled() {
        return this._getOption('scrollingEnabled');
    }
    set scrollingEnabled(value) {
        this._setOption('scrollingEnabled', value);
    }
    get selectedIndex() {
        return this._getOption('selectedIndex');
    }
    set selectedIndex(value) {
        this._setOption('selectedIndex', value);
    }
    get selectedItem() {
        return this._getOption('selectedItem');
    }
    set selectedItem(value) {
        this._setOption('selectedItem', value);
    }
    get showNavButtons() {
        return this._getOption('showNavButtons');
    }
    set showNavButtons(value) {
        this._setOption('showNavButtons', value);
    }
    get stylingMode() {
        return this._getOption('stylingMode');
    }
    set stylingMode(value) {
        this._setOption('stylingMode', value);
    }
    get swipeEnabled() {
        return this._getOption('swipeEnabled');
    }
    set swipeEnabled(value) {
        this._setOption('swipeEnabled', value);
    }
    get tabIndex() {
        return this._getOption('tabIndex');
    }
    set tabIndex(value) {
        this._setOption('tabIndex', value);
    }
    get tabsPosition() {
        return this._getOption('tabsPosition');
    }
    set tabsPosition(value) {
        this._setOption('tabsPosition', value);
    }
    get visible() {
        return this._getOption('visible');
    }
    set visible(value) {
        this._setOption('visible', value);
    }
    get width() {
        return this._getOption('width');
    }
    set width(value) {
        this._setOption('width', value);
    }
    get _optionPath() {
        return 'tabPanelOptions';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        this._createEventEmitters([
            { emit: 'itemsChange' },
            { emit: 'selectedIndexChange' },
            { emit: 'selectedItemChange' }
        ]);
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewTabPanelOptionsComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoCardViewTabPanelOptionsComponent, isStandalone: true, selector: "dxo-card-view-tab-panel-options", inputs: { accessKey: "accessKey", activeStateEnabled: "activeStateEnabled", animationEnabled: "animationEnabled", dataSource: "dataSource", deferRendering: "deferRendering", disabled: "disabled", elementAttr: "elementAttr", focusStateEnabled: "focusStateEnabled", height: "height", hint: "hint", hoverStateEnabled: "hoverStateEnabled", iconPosition: "iconPosition", itemHoldTimeout: "itemHoldTimeout", items: "items", itemTemplate: "itemTemplate", itemTitleTemplate: "itemTitleTemplate", keyExpr: "keyExpr", loop: "loop", noDataText: "noDataText", onContentReady: "onContentReady", onDisposing: "onDisposing", onInitialized: "onInitialized", onItemClick: "onItemClick", onItemContextMenu: "onItemContextMenu", onItemHold: "onItemHold", onItemRendered: "onItemRendered", onOptionChanged: "onOptionChanged", onSelectionChanged: "onSelectionChanged", onSelectionChanging: "onSelectionChanging", onTitleClick: "onTitleClick", onTitleHold: "onTitleHold", onTitleRendered: "onTitleRendered", repaintChangesOnly: "repaintChangesOnly", rtlEnabled: "rtlEnabled", scrollByContent: "scrollByContent", scrollingEnabled: "scrollingEnabled", selectedIndex: "selectedIndex", selectedItem: "selectedItem", showNavButtons: "showNavButtons", stylingMode: "stylingMode", swipeEnabled: "swipeEnabled", tabIndex: "tabIndex", tabsPosition: "tabsPosition", visible: "visible", width: "width" }, outputs: { itemsChange: "itemsChange", selectedIndexChange: "selectedIndexChange", selectedItemChange: "selectedItemChange" }, providers: [NestedOptionHost], queries: [{ propertyName: "_itemsContentChildren", predicate: PROPERTY_TOKEN_items }], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewTabPanelOptionsComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-card-view-tab-panel-options', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { _itemsContentChildren: [{
                type: ContentChildren,
                args: [PROPERTY_TOKEN_items]
            }], accessKey: [{
                type: Input
            }], activeStateEnabled: [{
                type: Input
            }], animationEnabled: [{
                type: Input
            }], dataSource: [{
                type: Input
            }], deferRendering: [{
                type: Input
            }], disabled: [{
                type: Input
            }], elementAttr: [{
                type: Input
            }], focusStateEnabled: [{
                type: Input
            }], height: [{
                type: Input
            }], hint: [{
                type: Input
            }], hoverStateEnabled: [{
                type: Input
            }], iconPosition: [{
                type: Input
            }], itemHoldTimeout: [{
                type: Input
            }], items: [{
                type: Input
            }], itemTemplate: [{
                type: Input
            }], itemTitleTemplate: [{
                type: Input
            }], keyExpr: [{
                type: Input
            }], loop: [{
                type: Input
            }], noDataText: [{
                type: Input
            }], onContentReady: [{
                type: Input
            }], onDisposing: [{
                type: Input
            }], onInitialized: [{
                type: Input
            }], onItemClick: [{
                type: Input
            }], onItemContextMenu: [{
                type: Input
            }], onItemHold: [{
                type: Input
            }], onItemRendered: [{
                type: Input
            }], onOptionChanged: [{
                type: Input
            }], onSelectionChanged: [{
                type: Input
            }], onSelectionChanging: [{
                type: Input
            }], onTitleClick: [{
                type: Input
            }], onTitleHold: [{
                type: Input
            }], onTitleRendered: [{
                type: Input
            }], repaintChangesOnly: [{
                type: Input
            }], rtlEnabled: [{
                type: Input
            }], scrollByContent: [{
                type: Input
            }], scrollingEnabled: [{
                type: Input
            }], selectedIndex: [{
                type: Input
            }], selectedItem: [{
                type: Input
            }], showNavButtons: [{
                type: Input
            }], stylingMode: [{
                type: Input
            }], swipeEnabled: [{
                type: Input
            }], tabIndex: [{
                type: Input
            }], tabsPosition: [{
                type: Input
            }], visible: [{
                type: Input
            }], width: [{
                type: Input
            }], itemsChange: [{
                type: Output
            }], selectedIndexChange: [{
                type: Output
            }], selectedItemChange: [{
                type: Output
            }] } });
class DxoCardViewTabPanelOptionsModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewTabPanelOptionsModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewTabPanelOptionsModule, imports: [DxoCardViewTabPanelOptionsComponent], exports: [DxoCardViewTabPanelOptionsComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewTabPanelOptionsModule, imports: [DxoCardViewTabPanelOptionsComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewTabPanelOptionsModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoCardViewTabPanelOptionsComponent
                    ],
                    exports: [
                        DxoCardViewTabPanelOptionsComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxiCardViewTabbedItemComponent extends CollectionNestedOption {
    set _tabsContentChildren(value) {
        this.setChildren('tabs', value);
    }
    get colSpan() {
        return this._getOption('colSpan');
    }
    set colSpan(value) {
        this._setOption('colSpan', value);
    }
    get cssClass() {
        return this._getOption('cssClass');
    }
    set cssClass(value) {
        this._setOption('cssClass', value);
    }
    get itemType() {
        return this._getOption('itemType');
    }
    set itemType(value) {
        this._setOption('itemType', value);
    }
    get name() {
        return this._getOption('name');
    }
    set name(value) {
        this._setOption('name', value);
    }
    get tabPanelOptions() {
        return this._getOption('tabPanelOptions');
    }
    set tabPanelOptions(value) {
        this._setOption('tabPanelOptions', value);
    }
    get tabs() {
        return this._getOption('tabs');
    }
    set tabs(value) {
        this._setOption('tabs', value);
    }
    get visible() {
        return this._getOption('visible');
    }
    set visible(value) {
        this._setOption('visible', value);
    }
    get visibleIndex() {
        return this._getOption('visibleIndex');
    }
    set visibleIndex(value) {
        this._setOption('visibleIndex', value);
    }
    get _optionPath() {
        return 'items';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
        this.itemType = 'tabbed';
    }
    ngOnDestroy() {
        this._deleteRemovedOptions(this._fullOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiCardViewTabbedItemComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxiCardViewTabbedItemComponent, isStandalone: true, selector: "dxi-card-view-tabbed-item", inputs: { colSpan: "colSpan", cssClass: "cssClass", itemType: "itemType", name: "name", tabPanelOptions: "tabPanelOptions", tabs: "tabs", visible: "visible", visibleIndex: "visibleIndex" }, providers: [
            NestedOptionHost,
            {
                provide: PROPERTY_TOKEN_items,
                useExisting: DxiCardViewTabbedItemComponent,
            }
        ], queries: [{ propertyName: "_tabsContentChildren", predicate: PROPERTY_TOKEN_tabs }], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiCardViewTabbedItemComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxi-card-view-tabbed-item', template: '', imports: [DxIntegrationModule], providers: [
                        NestedOptionHost,
                        {
                            provide: PROPERTY_TOKEN_items,
                            useExisting: DxiCardViewTabbedItemComponent,
                        }
                    ] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { _tabsContentChildren: [{
                type: ContentChildren,
                args: [PROPERTY_TOKEN_tabs]
            }], colSpan: [{
                type: Input
            }], cssClass: [{
                type: Input
            }], itemType: [{
                type: Input
            }], name: [{
                type: Input
            }], tabPanelOptions: [{
                type: Input
            }], tabs: [{
                type: Input
            }], visible: [{
                type: Input
            }], visibleIndex: [{
                type: Input
            }] } });
class DxiCardViewTabbedItemModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiCardViewTabbedItemModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxiCardViewTabbedItemModule, imports: [DxiCardViewTabbedItemComponent], exports: [DxiCardViewTabbedItemComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiCardViewTabbedItemModule, imports: [DxiCardViewTabbedItemComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiCardViewTabbedItemModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxiCardViewTabbedItemComponent
                    ],
                    exports: [
                        DxiCardViewTabbedItemComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoCardViewTextsComponent extends NestedOption {
    get addCard() {
        return this._getOption('addCard');
    }
    set addCard(value) {
        this._setOption('addCard', value);
    }
    get confirmDeleteMessage() {
        return this._getOption('confirmDeleteMessage');
    }
    set confirmDeleteMessage(value) {
        this._setOption('confirmDeleteMessage', value);
    }
    get confirmDeleteTitle() {
        return this._getOption('confirmDeleteTitle');
    }
    set confirmDeleteTitle(value) {
        this._setOption('confirmDeleteTitle', value);
    }
    get deleteCard() {
        return this._getOption('deleteCard');
    }
    set deleteCard(value) {
        this._setOption('deleteCard', value);
    }
    get editCard() {
        return this._getOption('editCard');
    }
    set editCard(value) {
        this._setOption('editCard', value);
    }
    get saveCard() {
        return this._getOption('saveCard');
    }
    set saveCard(value) {
        this._setOption('saveCard', value);
    }
    get clearFilter() {
        return this._getOption('clearFilter');
    }
    set clearFilter(value) {
        this._setOption('clearFilter', value);
    }
    get createFilter() {
        return this._getOption('createFilter');
    }
    set createFilter(value) {
        this._setOption('createFilter', value);
    }
    get filterEnabledHint() {
        return this._getOption('filterEnabledHint');
    }
    set filterEnabledHint(value) {
        this._setOption('filterEnabledHint', value);
    }
    get cancel() {
        return this._getOption('cancel');
    }
    set cancel(value) {
        this._setOption('cancel', value);
    }
    get emptyValue() {
        return this._getOption('emptyValue');
    }
    set emptyValue(value) {
        this._setOption('emptyValue', value);
    }
    get ok() {
        return this._getOption('ok');
    }
    set ok(value) {
        this._setOption('ok', value);
    }
    get _optionPath() {
        return 'texts';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewTextsComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoCardViewTextsComponent, isStandalone: true, selector: "dxo-card-view-texts", inputs: { addCard: "addCard", confirmDeleteMessage: "confirmDeleteMessage", confirmDeleteTitle: "confirmDeleteTitle", deleteCard: "deleteCard", editCard: "editCard", saveCard: "saveCard", clearFilter: "clearFilter", createFilter: "createFilter", filterEnabledHint: "filterEnabledHint", cancel: "cancel", emptyValue: "emptyValue", ok: "ok" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewTextsComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-card-view-texts', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { addCard: [{
                type: Input
            }], confirmDeleteMessage: [{
                type: Input
            }], confirmDeleteTitle: [{
                type: Input
            }], deleteCard: [{
                type: Input
            }], editCard: [{
                type: Input
            }], saveCard: [{
                type: Input
            }], clearFilter: [{
                type: Input
            }], createFilter: [{
                type: Input
            }], filterEnabledHint: [{
                type: Input
            }], cancel: [{
                type: Input
            }], emptyValue: [{
                type: Input
            }], ok: [{
                type: Input
            }] } });
class DxoCardViewTextsModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewTextsModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewTextsModule, imports: [DxoCardViewTextsComponent], exports: [DxoCardViewTextsComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewTextsModule, imports: [DxoCardViewTextsComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewTextsModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoCardViewTextsComponent
                    ],
                    exports: [
                        DxoCardViewTextsComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoCardViewToComponent extends NestedOption {
    get left() {
        return this._getOption('left');
    }
    set left(value) {
        this._setOption('left', value);
    }
    get opacity() {
        return this._getOption('opacity');
    }
    set opacity(value) {
        this._setOption('opacity', value);
    }
    get position() {
        return this._getOption('position');
    }
    set position(value) {
        this._setOption('position', value);
    }
    get scale() {
        return this._getOption('scale');
    }
    set scale(value) {
        this._setOption('scale', value);
    }
    get top() {
        return this._getOption('top');
    }
    set top(value) {
        this._setOption('top', value);
    }
    get _optionPath() {
        return 'to';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewToComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoCardViewToComponent, isStandalone: true, selector: "dxo-card-view-to", inputs: { left: "left", opacity: "opacity", position: "position", scale: "scale", top: "top" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewToComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-card-view-to', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { left: [{
                type: Input
            }], opacity: [{
                type: Input
            }], position: [{
                type: Input
            }], scale: [{
                type: Input
            }], top: [{
                type: Input
            }] } });
class DxoCardViewToModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewToModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewToModule, imports: [DxoCardViewToComponent], exports: [DxoCardViewToComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewToModule, imports: [DxoCardViewToComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewToModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoCardViewToComponent
                    ],
                    exports: [
                        DxoCardViewToComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxiCardViewToolbarItemComponent extends CollectionNestedOption {
    get cssClass() {
        return this._getOption('cssClass');
    }
    set cssClass(value) {
        this._setOption('cssClass', value);
    }
    get disabled() {
        return this._getOption('disabled');
    }
    set disabled(value) {
        this._setOption('disabled', value);
    }
    get html() {
        return this._getOption('html');
    }
    set html(value) {
        this._setOption('html', value);
    }
    get locateInMenu() {
        return this._getOption('locateInMenu');
    }
    set locateInMenu(value) {
        this._setOption('locateInMenu', value);
    }
    get location() {
        return this._getOption('location');
    }
    set location(value) {
        this._setOption('location', value);
    }
    get menuItemTemplate() {
        return this._getOption('menuItemTemplate');
    }
    set menuItemTemplate(value) {
        this._setOption('menuItemTemplate', value);
    }
    get name() {
        return this._getOption('name');
    }
    set name(value) {
        this._setOption('name', value);
    }
    get options() {
        return this._getOption('options');
    }
    set options(value) {
        this._setOption('options', value);
    }
    get showText() {
        return this._getOption('showText');
    }
    set showText(value) {
        this._setOption('showText', value);
    }
    get template() {
        return this._getOption('template');
    }
    set template(value) {
        this._setOption('template', value);
    }
    get text() {
        return this._getOption('text');
    }
    set text(value) {
        this._setOption('text', value);
    }
    get visible() {
        return this._getOption('visible');
    }
    set visible(value) {
        this._setOption('visible', value);
    }
    get widget() {
        return this._getOption('widget');
    }
    set widget(value) {
        this._setOption('widget', value);
    }
    get _optionPath() {
        return 'items';
    }
    constructor(parentOptionHost, optionHost, renderer, document, templateHost, element) {
        super();
        this.renderer = renderer;
        this.document = document;
        this.element = element;
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
        templateHost.setHost(this);
    }
    setTemplate(template) {
        this.template = template;
    }
    ngAfterViewInit() {
        extractTemplate(this, this.element, this.renderer, this.document);
    }
    ngOnDestroy() {
        this._deleteRemovedOptions(this._fullOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiCardViewToolbarItemComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }, { token: i0.Renderer2 }, { token: DOCUMENT }, { token: i1.DxTemplateHost, host: true }, { token: i0.ElementRef }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxiCardViewToolbarItemComponent, isStandalone: true, selector: "dxi-card-view-toolbar-item", inputs: { cssClass: "cssClass", disabled: "disabled", html: "html", locateInMenu: "locateInMenu", location: "location", menuItemTemplate: "menuItemTemplate", name: "name", options: "options", showText: "showText", template: "template", text: "text", visible: "visible", widget: "widget" }, providers: [
            NestedOptionHost,
            DxTemplateHost,
            {
                provide: PROPERTY_TOKEN_items,
                useExisting: DxiCardViewToolbarItemComponent,
            }
        ], usesInheritance: true, ngImport: i0, template: '<ng-content></ng-content>', isInline: true, styles: [":host{display:block}\n"], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiCardViewToolbarItemComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxi-card-view-toolbar-item', template: '<ng-content></ng-content>', imports: [DxIntegrationModule], providers: [
                        NestedOptionHost,
                        DxTemplateHost,
                        {
                            provide: PROPERTY_TOKEN_items,
                            useExisting: DxiCardViewToolbarItemComponent,
                        }
                    ], styles: [":host{display:block}\n"] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }, { type: i0.Renderer2 }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [DOCUMENT]
                }] }, { type: i1.DxTemplateHost, decorators: [{
                    type: Host
                }] }, { type: i0.ElementRef }], propDecorators: { cssClass: [{
                type: Input
            }], disabled: [{
                type: Input
            }], html: [{
                type: Input
            }], locateInMenu: [{
                type: Input
            }], location: [{
                type: Input
            }], menuItemTemplate: [{
                type: Input
            }], name: [{
                type: Input
            }], options: [{
                type: Input
            }], showText: [{
                type: Input
            }], template: [{
                type: Input
            }], text: [{
                type: Input
            }], visible: [{
                type: Input
            }], widget: [{
                type: Input
            }] } });
class DxiCardViewToolbarItemModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiCardViewToolbarItemModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxiCardViewToolbarItemModule, imports: [DxiCardViewToolbarItemComponent], exports: [DxiCardViewToolbarItemComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiCardViewToolbarItemModule, imports: [DxiCardViewToolbarItemComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiCardViewToolbarItemModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxiCardViewToolbarItemComponent
                    ],
                    exports: [
                        DxiCardViewToolbarItemComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoCardViewToolbarComponent extends NestedOption {
    set _itemsContentChildren(value) {
        this.setChildren('items', value);
    }
    get disabled() {
        return this._getOption('disabled');
    }
    set disabled(value) {
        this._setOption('disabled', value);
    }
    get items() {
        return this._getOption('items');
    }
    set items(value) {
        this._setOption('items', value);
    }
    get multiline() {
        return this._getOption('multiline');
    }
    set multiline(value) {
        this._setOption('multiline', value);
    }
    get visible() {
        return this._getOption('visible');
    }
    set visible(value) {
        this._setOption('visible', value);
    }
    get _optionPath() {
        return 'toolbar';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewToolbarComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoCardViewToolbarComponent, isStandalone: true, selector: "dxo-card-view-toolbar", inputs: { disabled: "disabled", items: "items", multiline: "multiline", visible: "visible" }, providers: [NestedOptionHost], queries: [{ propertyName: "_itemsContentChildren", predicate: PROPERTY_TOKEN_items }], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewToolbarComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-card-view-toolbar', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { _itemsContentChildren: [{
                type: ContentChildren,
                args: [PROPERTY_TOKEN_items]
            }], disabled: [{
                type: Input
            }], items: [{
                type: Input
            }], multiline: [{
                type: Input
            }], visible: [{
                type: Input
            }] } });
class DxoCardViewToolbarModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewToolbarModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewToolbarModule, imports: [DxoCardViewToolbarComponent], exports: [DxoCardViewToolbarComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewToolbarModule, imports: [DxoCardViewToolbarComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoCardViewToolbarModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoCardViewToolbarComponent
                    ],
                    exports: [
                        DxoCardViewToolbarComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxiCardViewValidationRuleComponent extends CollectionNestedOption {
    get message() {
        return this._getOption('message');
    }
    set message(value) {
        this._setOption('message', value);
    }
    get trim() {
        return this._getOption('trim');
    }
    set trim(value) {
        this._setOption('trim', value);
    }
    get type() {
        return this._getOption('type');
    }
    set type(value) {
        this._setOption('type', value);
    }
    get ignoreEmptyValue() {
        return this._getOption('ignoreEmptyValue');
    }
    set ignoreEmptyValue(value) {
        this._setOption('ignoreEmptyValue', value);
    }
    get max() {
        return this._getOption('max');
    }
    set max(value) {
        this._setOption('max', value);
    }
    get min() {
        return this._getOption('min');
    }
    set min(value) {
        this._setOption('min', value);
    }
    get reevaluate() {
        return this._getOption('reevaluate');
    }
    set reevaluate(value) {
        this._setOption('reevaluate', value);
    }
    get validationCallback() {
        return this._getOption('validationCallback');
    }
    set validationCallback(value) {
        this._setOption('validationCallback', value);
    }
    get comparisonTarget() {
        return this._getOption('comparisonTarget');
    }
    set comparisonTarget(value) {
        this._setOption('comparisonTarget', value);
    }
    get comparisonType() {
        return this._getOption('comparisonType');
    }
    set comparisonType(value) {
        this._setOption('comparisonType', value);
    }
    get pattern() {
        return this._getOption('pattern');
    }
    set pattern(value) {
        this._setOption('pattern', value);
    }
    get _optionPath() {
        return 'validationRules';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
        this.type = 'required';
    }
    ngOnDestroy() {
        this._deleteRemovedOptions(this._fullOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiCardViewValidationRuleComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxiCardViewValidationRuleComponent, isStandalone: true, selector: "dxi-card-view-validation-rule", inputs: { message: "message", trim: "trim", type: "type", ignoreEmptyValue: "ignoreEmptyValue", max: "max", min: "min", reevaluate: "reevaluate", validationCallback: "validationCallback", comparisonTarget: "comparisonTarget", comparisonType: "comparisonType", pattern: "pattern" }, providers: [
            NestedOptionHost,
            {
                provide: PROPERTY_TOKEN_validationRules,
                useExisting: DxiCardViewValidationRuleComponent,
            }
        ], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiCardViewValidationRuleComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxi-card-view-validation-rule', template: '', imports: [DxIntegrationModule], providers: [
                        NestedOptionHost,
                        {
                            provide: PROPERTY_TOKEN_validationRules,
                            useExisting: DxiCardViewValidationRuleComponent,
                        }
                    ] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { message: [{
                type: Input
            }], trim: [{
                type: Input
            }], type: [{
                type: Input
            }], ignoreEmptyValue: [{
                type: Input
            }], max: [{
                type: Input
            }], min: [{
                type: Input
            }], reevaluate: [{
                type: Input
            }], validationCallback: [{
                type: Input
            }], comparisonTarget: [{
                type: Input
            }], comparisonType: [{
                type: Input
            }], pattern: [{
                type: Input
            }] } });
class DxiCardViewValidationRuleModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiCardViewValidationRuleModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxiCardViewValidationRuleModule, imports: [DxiCardViewValidationRuleComponent], exports: [DxiCardViewValidationRuleComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiCardViewValidationRuleModule, imports: [DxiCardViewValidationRuleComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiCardViewValidationRuleModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxiCardViewValidationRuleComponent
                    ],
                    exports: [
                        DxiCardViewValidationRuleComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

/**
 * Generated bundle index. Do not edit.
 */

export { DxiCardViewAsyncRuleComponent, DxiCardViewAsyncRuleModule, DxiCardViewButtonItemComponent, DxiCardViewButtonItemModule, DxiCardViewCardHeaderItemComponent, DxiCardViewCardHeaderItemModule, DxiCardViewChangeComponent, DxiCardViewChangeModule, DxiCardViewColumnComponent, DxiCardViewColumnModule, DxiCardViewCompareRuleComponent, DxiCardViewCompareRuleModule, DxiCardViewCustomOperationComponent, DxiCardViewCustomOperationModule, DxiCardViewCustomRuleComponent, DxiCardViewCustomRuleModule, DxiCardViewEmailRuleComponent, DxiCardViewEmailRuleModule, DxiCardViewEmptyItemComponent, DxiCardViewEmptyItemModule, DxiCardViewFieldComponent, DxiCardViewFieldModule, DxiCardViewGroupItemComponent, DxiCardViewGroupItemModule, DxiCardViewItemComponent, DxiCardViewItemModule, DxiCardViewNumericRuleComponent, DxiCardViewNumericRuleModule, DxiCardViewPatternRuleComponent, DxiCardViewPatternRuleModule, DxiCardViewRangeRuleComponent, DxiCardViewRangeRuleModule, DxiCardViewRequiredRuleComponent, DxiCardViewRequiredRuleModule, DxiCardViewSimpleItemComponent, DxiCardViewSimpleItemModule, DxiCardViewStringLengthRuleComponent, DxiCardViewStringLengthRuleModule, DxiCardViewTabComponent, DxiCardViewTabModule, DxiCardViewTabPanelOptionsItemComponent, DxiCardViewTabPanelOptionsItemModule, DxiCardViewTabbedItemComponent, DxiCardViewTabbedItemModule, DxiCardViewToolbarItemComponent, DxiCardViewToolbarItemModule, DxiCardViewValidationRuleComponent, DxiCardViewValidationRuleModule, DxoCardViewAIOptionsComponent, DxoCardViewAIOptionsModule, DxoCardViewAnimationComponent, DxoCardViewAnimationModule, DxoCardViewAtComponent, DxoCardViewAtModule, DxoCardViewBoundaryOffsetComponent, DxoCardViewBoundaryOffsetModule, DxoCardViewButtonOptionsComponent, DxoCardViewButtonOptionsModule, DxoCardViewCardCoverComponent, DxoCardViewCardCoverModule, DxoCardViewCardHeaderComponent, DxoCardViewCardHeaderModule, DxoCardViewCardViewHeaderFilterComponent, DxoCardViewCardViewHeaderFilterModule, DxoCardViewCardViewHeaderFilterSearchComponent, DxoCardViewCardViewHeaderFilterSearchModule, DxoCardViewCardViewHeaderFilterTextsComponent, DxoCardViewCardViewHeaderFilterTextsModule, DxoCardViewCardViewSelectionComponent, DxoCardViewCardViewSelectionModule, DxoCardViewColCountByScreenComponent, DxoCardViewColCountByScreenModule, DxoCardViewCollisionComponent, DxoCardViewCollisionModule, DxoCardViewColumnChooserComponent, DxoCardViewColumnChooserModule, DxoCardViewColumnChooserSearchComponent, DxoCardViewColumnChooserSearchModule, DxoCardViewColumnChooserSelectionComponent, DxoCardViewColumnChooserSelectionModule, DxoCardViewColumnHeaderFilterComponent, DxoCardViewColumnHeaderFilterModule, DxoCardViewColumnHeaderFilterSearchComponent, DxoCardViewColumnHeaderFilterSearchModule, DxoCardViewDraggingComponent, DxoCardViewDraggingModule, DxoCardViewEditingComponent, DxoCardViewEditingModule, DxoCardViewEditingTextsComponent, DxoCardViewEditingTextsModule, DxoCardViewFilterBuilderComponent, DxoCardViewFilterBuilderModule, DxoCardViewFilterOperationDescriptionsComponent, DxoCardViewFilterOperationDescriptionsModule, DxoCardViewFilterPanelComponent, DxoCardViewFilterPanelModule, DxoCardViewFilterPanelTextsComponent, DxoCardViewFilterPanelTextsModule, DxoCardViewFormComponent, DxoCardViewFormItemComponent, DxoCardViewFormItemModule, DxoCardViewFormModule, DxoCardViewFormatComponent, DxoCardViewFormatModule, DxoCardViewFromComponent, DxoCardViewFromModule, DxoCardViewGroupOperationDescriptionsComponent, DxoCardViewGroupOperationDescriptionsModule, DxoCardViewHeaderFilterComponent, DxoCardViewHeaderFilterModule, DxoCardViewHeaderPanelComponent, DxoCardViewHeaderPanelModule, DxoCardViewHideComponent, DxoCardViewHideModule, DxoCardViewIndicatorOptionsComponent, DxoCardViewIndicatorOptionsModule, DxoCardViewLabelComponent, DxoCardViewLabelModule, DxoCardViewLoadPanelComponent, DxoCardViewLoadPanelModule, DxoCardViewLookupComponent, DxoCardViewLookupModule, DxoCardViewMyComponent, DxoCardViewMyModule, DxoCardViewOffsetComponent, DxoCardViewOffsetModule, DxoCardViewPagerComponent, DxoCardViewPagerModule, DxoCardViewPagingComponent, DxoCardViewPagingModule, DxoCardViewPositionComponent, DxoCardViewPositionModule, DxoCardViewRemoteOperationsComponent, DxoCardViewRemoteOperationsModule, DxoCardViewScrollingComponent, DxoCardViewScrollingModule, DxoCardViewSearchComponent, DxoCardViewSearchModule, DxoCardViewSearchPanelComponent, DxoCardViewSearchPanelModule, DxoCardViewSelectionComponent, DxoCardViewSelectionModule, DxoCardViewShowComponent, DxoCardViewShowModule, DxoCardViewSortingComponent, DxoCardViewSortingModule, DxoCardViewTabPanelOptionsComponent, DxoCardViewTabPanelOptionsModule, DxoCardViewTextsComponent, DxoCardViewTextsModule, DxoCardViewToComponent, DxoCardViewToModule, DxoCardViewToolbarComponent, DxoCardViewToolbarModule };
//# sourceMappingURL=devextreme-angular-ui-card-view-nested.mjs.map
