import * as i0 from '@angular/core';
import { PLATFORM_ID, Output, Input, Inject, Component, NgModule } from '@angular/core';
import DxPivotGridFieldChooser from 'devextreme/ui/pivot_grid_field_chooser';
import * as i1 from 'devextreme-angular/core';
import { DxComponent, DxIntegrationModule, DxTemplateHost, WatcherHelper, NestedOptionHost, IterableDifferHelper, DxTemplateModule } from 'devextreme-angular/core';
import { DxoHeaderFilterModule, DxoSearchModule, DxoTextsModule } from 'devextreme-angular/ui/nested';
import { DxoPivotGridFieldChooserHeaderFilterModule, DxoPivotGridFieldChooserHeaderFilterTextsModule, DxoPivotGridFieldChooserPivotGridFieldChooserTextsModule, DxoPivotGridFieldChooserSearchModule, DxoPivotGridFieldChooserTextsModule } from 'devextreme-angular/ui/pivot-grid-field-chooser/nested';
export * from 'devextreme-angular/ui/pivot-grid-field-chooser/nested';

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
/**
 * [descr:dxPivotGridFieldChooser]

 */
class DxPivotGridFieldChooserComponent extends DxComponent {
    /**
     * [descr:WidgetOptions.accessKey]
    
     */
    get accessKey() {
        return this._getOption('accessKey');
    }
    set accessKey(value) {
        this._setOption('accessKey', value);
    }
    /**
     * [descr:WidgetOptions.activeStateEnabled]
    
     */
    get activeStateEnabled() {
        return this._getOption('activeStateEnabled');
    }
    set activeStateEnabled(value) {
        this._setOption('activeStateEnabled', value);
    }
    /**
     * [descr:dxPivotGridFieldChooserOptions.allowSearch]
    
     */
    get allowSearch() {
        return this._getOption('allowSearch');
    }
    set allowSearch(value) {
        this._setOption('allowSearch', value);
    }
    /**
     * [descr:dxPivotGridFieldChooserOptions.applyChangesMode]
    
     */
    get applyChangesMode() {
        return this._getOption('applyChangesMode');
    }
    set applyChangesMode(value) {
        this._setOption('applyChangesMode', value);
    }
    /**
     * [descr:dxPivotGridFieldChooserOptions.dataSource]
    
     */
    get dataSource() {
        return this._getOption('dataSource');
    }
    set dataSource(value) {
        this._setOption('dataSource', value);
    }
    /**
     * [descr:WidgetOptions.disabled]
    
     */
    get disabled() {
        return this._getOption('disabled');
    }
    set disabled(value) {
        this._setOption('disabled', value);
    }
    /**
     * [descr:DOMComponentOptions.elementAttr]
    
     */
    get elementAttr() {
        return this._getOption('elementAttr');
    }
    set elementAttr(value) {
        this._setOption('elementAttr', value);
    }
    /**
     * [descr:dxPivotGridFieldChooserOptions.encodeHtml]
    
     */
    get encodeHtml() {
        return this._getOption('encodeHtml');
    }
    set encodeHtml(value) {
        this._setOption('encodeHtml', value);
    }
    /**
     * [descr:WidgetOptions.focusStateEnabled]
    
     */
    get focusStateEnabled() {
        return this._getOption('focusStateEnabled');
    }
    set focusStateEnabled(value) {
        this._setOption('focusStateEnabled', value);
    }
    /**
     * [descr:dxPivotGridFieldChooserOptions.headerFilter]
    
     */
    get headerFilter() {
        return this._getOption('headerFilter');
    }
    set headerFilter(value) {
        this._setOption('headerFilter', value);
    }
    /**
     * [descr:dxPivotGridFieldChooserOptions.height]
    
     */
    get height() {
        return this._getOption('height');
    }
    set height(value) {
        this._setOption('height', value);
    }
    /**
     * [descr:WidgetOptions.hint]
    
     */
    get hint() {
        return this._getOption('hint');
    }
    set hint(value) {
        this._setOption('hint', value);
    }
    /**
     * [descr:WidgetOptions.hoverStateEnabled]
    
     */
    get hoverStateEnabled() {
        return this._getOption('hoverStateEnabled');
    }
    set hoverStateEnabled(value) {
        this._setOption('hoverStateEnabled', value);
    }
    /**
     * [descr:dxPivotGridFieldChooserOptions.layout]
    
     */
    get layout() {
        return this._getOption('layout');
    }
    set layout(value) {
        this._setOption('layout', value);
    }
    /**
     * [descr:DOMComponentOptions.rtlEnabled]
    
     */
    get rtlEnabled() {
        return this._getOption('rtlEnabled');
    }
    set rtlEnabled(value) {
        this._setOption('rtlEnabled', value);
    }
    /**
     * [descr:dxPivotGridFieldChooserOptions.searchTimeout]
    
     */
    get searchTimeout() {
        return this._getOption('searchTimeout');
    }
    set searchTimeout(value) {
        this._setOption('searchTimeout', value);
    }
    /**
     * [descr:dxPivotGridFieldChooserOptions.state]
    
     */
    get state() {
        return this._getOption('state');
    }
    set state(value) {
        this._setOption('state', value);
    }
    /**
     * [descr:WidgetOptions.tabIndex]
    
     */
    get tabIndex() {
        return this._getOption('tabIndex');
    }
    set tabIndex(value) {
        this._setOption('tabIndex', value);
    }
    /**
     * [descr:dxPivotGridFieldChooserOptions.texts]
    
     */
    get texts() {
        return this._getOption('texts');
    }
    set texts(value) {
        this._setOption('texts', value);
    }
    /**
     * [descr:WidgetOptions.visible]
    
     */
    get visible() {
        return this._getOption('visible');
    }
    set visible(value) {
        this._setOption('visible', value);
    }
    /**
     * [descr:DOMComponentOptions.width]
    
     */
    get width() {
        return this._getOption('width');
    }
    set width(value) {
        this._setOption('width', value);
    }
    constructor(elementRef, ngZone, templateHost, _watcherHelper, _idh, optionHost, transferState, platformId) {
        super(elementRef, ngZone, templateHost, _watcherHelper, transferState, platformId);
        this._watcherHelper = _watcherHelper;
        this._idh = _idh;
        this.instance = null;
        this._createEventEmitters([
            { subscribe: 'contentReady', emit: 'onContentReady' },
            { subscribe: 'contextMenuPreparing', emit: 'onContextMenuPreparing' },
            { subscribe: 'disposing', emit: 'onDisposing' },
            { subscribe: 'initialized', emit: 'onInitialized' },
            { subscribe: 'optionChanged', emit: 'onOptionChanged' },
            { emit: 'accessKeyChange' },
            { emit: 'activeStateEnabledChange' },
            { emit: 'allowSearchChange' },
            { emit: 'applyChangesModeChange' },
            { emit: 'dataSourceChange' },
            { emit: 'disabledChange' },
            { emit: 'elementAttrChange' },
            { emit: 'encodeHtmlChange' },
            { emit: 'focusStateEnabledChange' },
            { emit: 'headerFilterChange' },
            { emit: 'heightChange' },
            { emit: 'hintChange' },
            { emit: 'hoverStateEnabledChange' },
            { emit: 'layoutChange' },
            { emit: 'rtlEnabledChange' },
            { emit: 'searchTimeoutChange' },
            { emit: 'stateChange' },
            { emit: 'tabIndexChange' },
            { emit: 'textsChange' },
            { emit: 'visibleChange' },
            { emit: 'widthChange' }
        ]);
        this._idh.setHost(this);
        optionHost.setHost(this);
    }
    _createInstance(element, options) {
        return new DxPivotGridFieldChooser(element, options);
    }
    ngOnDestroy() {
        this._destroyWidget();
    }
    ngOnChanges(changes) {
        super.ngOnChanges(changes);
        this.setupChanges('dataSource', changes);
    }
    setupChanges(prop, changes) {
        if (!(prop in this._optionsToUpdate)) {
            this._idh.setup(prop, changes);
        }
    }
    ngDoCheck() {
        this._idh.doCheck('dataSource');
        this._watcherHelper.checkWatchers();
        super.ngDoCheck();
        super.clearChangedOptions();
    }
    _setOption(name, value) {
        let isSetup = this._idh.setupSingle(name, value);
        let isChanged = this._idh.getChanges(name, value) !== null;
        if (isSetup || isChanged) {
            super._setOption(name, value);
        }
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxPivotGridFieldChooserComponent, deps: [{ token: i0.ElementRef }, { token: i0.NgZone }, { token: i1.DxTemplateHost }, { token: i1.WatcherHelper }, { token: i1.IterableDifferHelper }, { token: i1.NestedOptionHost }, { token: i0.TransferState }, { token: PLATFORM_ID }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxPivotGridFieldChooserComponent, isStandalone: true, selector: "dx-pivot-grid-field-chooser", inputs: { accessKey: "accessKey", activeStateEnabled: "activeStateEnabled", allowSearch: "allowSearch", applyChangesMode: "applyChangesMode", dataSource: "dataSource", disabled: "disabled", elementAttr: "elementAttr", encodeHtml: "encodeHtml", focusStateEnabled: "focusStateEnabled", headerFilter: "headerFilter", height: "height", hint: "hint", hoverStateEnabled: "hoverStateEnabled", layout: "layout", rtlEnabled: "rtlEnabled", searchTimeout: "searchTimeout", state: "state", tabIndex: "tabIndex", texts: "texts", visible: "visible", width: "width" }, outputs: { onContentReady: "onContentReady", onContextMenuPreparing: "onContextMenuPreparing", onDisposing: "onDisposing", onInitialized: "onInitialized", onOptionChanged: "onOptionChanged", accessKeyChange: "accessKeyChange", activeStateEnabledChange: "activeStateEnabledChange", allowSearchChange: "allowSearchChange", applyChangesModeChange: "applyChangesModeChange", dataSourceChange: "dataSourceChange", disabledChange: "disabledChange", elementAttrChange: "elementAttrChange", encodeHtmlChange: "encodeHtmlChange", focusStateEnabledChange: "focusStateEnabledChange", headerFilterChange: "headerFilterChange", heightChange: "heightChange", hintChange: "hintChange", hoverStateEnabledChange: "hoverStateEnabledChange", layoutChange: "layoutChange", rtlEnabledChange: "rtlEnabledChange", searchTimeoutChange: "searchTimeoutChange", stateChange: "stateChange", tabIndexChange: "tabIndexChange", textsChange: "textsChange", visibleChange: "visibleChange", widthChange: "widthChange" }, host: { attributes: { "ngSkipHydration": "true" } }, providers: [
            DxTemplateHost,
            WatcherHelper,
            NestedOptionHost,
            IterableDifferHelper
        ], usesInheritance: true, usesOnChanges: true, ngImport: i0, template: '', isInline: true, dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxPivotGridFieldChooserComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'dx-pivot-grid-field-chooser',
                    template: '',
                    host: { ngSkipHydration: 'true' },
                    imports: [DxIntegrationModule],
                    providers: [
                        DxTemplateHost,
                        WatcherHelper,
                        NestedOptionHost,
                        IterableDifferHelper
                    ]
                }]
        }], ctorParameters: () => [{ type: i0.ElementRef }, { type: i0.NgZone }, { type: i1.DxTemplateHost }, { type: i1.WatcherHelper }, { type: i1.IterableDifferHelper }, { type: i1.NestedOptionHost }, { type: i0.TransferState }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [PLATFORM_ID]
                }] }], propDecorators: { accessKey: [{
                type: Input
            }], activeStateEnabled: [{
                type: Input
            }], allowSearch: [{
                type: Input
            }], applyChangesMode: [{
                type: Input
            }], dataSource: [{
                type: Input
            }], disabled: [{
                type: Input
            }], elementAttr: [{
                type: Input
            }], encodeHtml: [{
                type: Input
            }], focusStateEnabled: [{
                type: Input
            }], headerFilter: [{
                type: Input
            }], height: [{
                type: Input
            }], hint: [{
                type: Input
            }], hoverStateEnabled: [{
                type: Input
            }], layout: [{
                type: Input
            }], rtlEnabled: [{
                type: Input
            }], searchTimeout: [{
                type: Input
            }], state: [{
                type: Input
            }], tabIndex: [{
                type: Input
            }], texts: [{
                type: Input
            }], visible: [{
                type: Input
            }], width: [{
                type: Input
            }], onContentReady: [{
                type: Output
            }], onContextMenuPreparing: [{
                type: Output
            }], onDisposing: [{
                type: Output
            }], onInitialized: [{
                type: Output
            }], onOptionChanged: [{
                type: Output
            }], accessKeyChange: [{
                type: Output
            }], activeStateEnabledChange: [{
                type: Output
            }], allowSearchChange: [{
                type: Output
            }], applyChangesModeChange: [{
                type: Output
            }], dataSourceChange: [{
                type: Output
            }], disabledChange: [{
                type: Output
            }], elementAttrChange: [{
                type: Output
            }], encodeHtmlChange: [{
                type: Output
            }], focusStateEnabledChange: [{
                type: Output
            }], headerFilterChange: [{
                type: Output
            }], heightChange: [{
                type: Output
            }], hintChange: [{
                type: Output
            }], hoverStateEnabledChange: [{
                type: Output
            }], layoutChange: [{
                type: Output
            }], rtlEnabledChange: [{
                type: Output
            }], searchTimeoutChange: [{
                type: Output
            }], stateChange: [{
                type: Output
            }], tabIndexChange: [{
                type: Output
            }], textsChange: [{
                type: Output
            }], visibleChange: [{
                type: Output
            }], widthChange: [{
                type: Output
            }] } });
class DxPivotGridFieldChooserModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxPivotGridFieldChooserModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxPivotGridFieldChooserModule, imports: [DxPivotGridFieldChooserComponent, DxoHeaderFilterModule,
            DxoSearchModule,
            DxoTextsModule,
            DxoPivotGridFieldChooserHeaderFilterModule,
            DxoPivotGridFieldChooserHeaderFilterTextsModule,
            DxoPivotGridFieldChooserPivotGridFieldChooserTextsModule,
            DxoPivotGridFieldChooserSearchModule,
            DxoPivotGridFieldChooserTextsModule,
            DxIntegrationModule,
            DxTemplateModule], exports: [DxPivotGridFieldChooserComponent, DxoHeaderFilterModule,
            DxoSearchModule,
            DxoTextsModule,
            DxoPivotGridFieldChooserHeaderFilterModule,
            DxoPivotGridFieldChooserHeaderFilterTextsModule,
            DxoPivotGridFieldChooserPivotGridFieldChooserTextsModule,
            DxoPivotGridFieldChooserSearchModule,
            DxoPivotGridFieldChooserTextsModule,
            DxTemplateModule] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxPivotGridFieldChooserModule, imports: [DxPivotGridFieldChooserComponent,
            DxoHeaderFilterModule,
            DxoSearchModule,
            DxoTextsModule,
            DxoPivotGridFieldChooserHeaderFilterModule,
            DxoPivotGridFieldChooserHeaderFilterTextsModule,
            DxoPivotGridFieldChooserPivotGridFieldChooserTextsModule,
            DxoPivotGridFieldChooserSearchModule,
            DxoPivotGridFieldChooserTextsModule,
            DxIntegrationModule,
            DxTemplateModule, DxoHeaderFilterModule,
            DxoSearchModule,
            DxoTextsModule,
            DxoPivotGridFieldChooserHeaderFilterModule,
            DxoPivotGridFieldChooserHeaderFilterTextsModule,
            DxoPivotGridFieldChooserPivotGridFieldChooserTextsModule,
            DxoPivotGridFieldChooserSearchModule,
            DxoPivotGridFieldChooserTextsModule,
            DxTemplateModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxPivotGridFieldChooserModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxPivotGridFieldChooserComponent,
                        DxoHeaderFilterModule,
                        DxoSearchModule,
                        DxoTextsModule,
                        DxoPivotGridFieldChooserHeaderFilterModule,
                        DxoPivotGridFieldChooserHeaderFilterTextsModule,
                        DxoPivotGridFieldChooserPivotGridFieldChooserTextsModule,
                        DxoPivotGridFieldChooserSearchModule,
                        DxoPivotGridFieldChooserTextsModule,
                        DxIntegrationModule,
                        DxTemplateModule
                    ],
                    exports: [
                        DxPivotGridFieldChooserComponent,
                        DxoHeaderFilterModule,
                        DxoSearchModule,
                        DxoTextsModule,
                        DxoPivotGridFieldChooserHeaderFilterModule,
                        DxoPivotGridFieldChooserHeaderFilterTextsModule,
                        DxoPivotGridFieldChooserPivotGridFieldChooserTextsModule,
                        DxoPivotGridFieldChooserSearchModule,
                        DxoPivotGridFieldChooserTextsModule,
                        DxTemplateModule
                    ]
                }]
        }] });

/**
 * Generated bundle index. Do not edit.
 */

export { DxPivotGridFieldChooserComponent, DxPivotGridFieldChooserModule };
//# sourceMappingURL=devextreme-angular-ui-pivot-grid-field-chooser.mjs.map
