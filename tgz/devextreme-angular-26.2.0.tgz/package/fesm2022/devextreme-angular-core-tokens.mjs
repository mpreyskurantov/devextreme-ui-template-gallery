import { InjectionToken } from '@angular/core';

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
const PROPERTY_TOKEN_items = new InjectionToken('property-token-items');
const PROPERTY_TOKEN_buttons = new InjectionToken('property-token-buttons');
const PROPERTY_TOKEN_toolbarItems = new InjectionToken('property-token-toolbarItems');
const PROPERTY_TOKEN_validationRules = new InjectionToken('property-token-validationRules');
const PROPERTY_TOKEN_changes = new InjectionToken('property-token-changes');
const PROPERTY_TOKEN_columns = new InjectionToken('property-token-columns');
const PROPERTY_TOKEN_customOperations = new InjectionToken('property-token-customOperations');
const PROPERTY_TOKEN_fields = new InjectionToken('property-token-fields');
const PROPERTY_TOKEN_tabs = new InjectionToken('property-token-tabs');
const PROPERTY_TOKEN_annotations = new InjectionToken('property-token-annotations');
const PROPERTY_TOKEN_breaks = new InjectionToken('property-token-breaks');
const PROPERTY_TOKEN_constantLines = new InjectionToken('property-token-constantLines');
const PROPERTY_TOKEN_panes = new InjectionToken('property-token-panes');
const PROPERTY_TOKEN_series = new InjectionToken('property-token-series');
const PROPERTY_TOKEN_strips = new InjectionToken('property-token-strips');
const PROPERTY_TOKEN_valueAxis = new InjectionToken('property-token-valueAxis');
const PROPERTY_TOKEN_alerts = new InjectionToken('property-token-alerts');
const PROPERTY_TOKEN_attachments = new InjectionToken('property-token-attachments');
const PROPERTY_TOKEN_typingUsers = new InjectionToken('property-token-typingUsers');
const PROPERTY_TOKEN_ranges = new InjectionToken('property-token-ranges');
const PROPERTY_TOKEN_groupItems = new InjectionToken('property-token-groupItems');
const PROPERTY_TOKEN_sortByGroupSummaryInfo = new InjectionToken('property-token-sortByGroupSummaryInfo');
const PROPERTY_TOKEN_totalItems = new InjectionToken('property-token-totalItems');
const PROPERTY_TOKEN_commands = new InjectionToken('property-token-commands');
const PROPERTY_TOKEN_connectionPoints = new InjectionToken('property-token-connectionPoints');
const PROPERTY_TOKEN_customShapes = new InjectionToken('property-token-customShapes');
const PROPERTY_TOKEN_groups = new InjectionToken('property-token-groups');
const PROPERTY_TOKEN_fileSelectionItems = new InjectionToken('property-token-fileSelectionItems');
const PROPERTY_TOKEN_stripLines = new InjectionToken('property-token-stripLines');
const PROPERTY_TOKEN_mentions = new InjectionToken('property-token-mentions');
const PROPERTY_TOKEN_menuItems = new InjectionToken('property-token-menuItems');
const PROPERTY_TOKEN_locations = new InjectionToken('property-token-locations');
const PROPERTY_TOKEN_markers = new InjectionToken('property-token-markers');
const PROPERTY_TOKEN_routes = new InjectionToken('property-token-routes');
const PROPERTY_TOKEN_cols = new InjectionToken('property-token-cols');
const PROPERTY_TOKEN_location = new InjectionToken('property-token-location');
const PROPERTY_TOKEN_rows = new InjectionToken('property-token-rows');
const PROPERTY_TOKEN_resources = new InjectionToken('property-token-resources');
const PROPERTY_TOKEN_views = new InjectionToken('property-token-views');
const PROPERTY_TOKEN_layers = new InjectionToken('property-token-layers');
const PROPERTY_TOKEN_legends = new InjectionToken('property-token-legends');
const PROPERTY_TOKEN_center = new InjectionToken('property-token-center');

/**
 * Generated bundle index. Do not edit.
 */

export { PROPERTY_TOKEN_alerts, PROPERTY_TOKEN_annotations, PROPERTY_TOKEN_attachments, PROPERTY_TOKEN_breaks, PROPERTY_TOKEN_buttons, PROPERTY_TOKEN_center, PROPERTY_TOKEN_changes, PROPERTY_TOKEN_cols, PROPERTY_TOKEN_columns, PROPERTY_TOKEN_commands, PROPERTY_TOKEN_connectionPoints, PROPERTY_TOKEN_constantLines, PROPERTY_TOKEN_customOperations, PROPERTY_TOKEN_customShapes, PROPERTY_TOKEN_fields, PROPERTY_TOKEN_fileSelectionItems, PROPERTY_TOKEN_groupItems, PROPERTY_TOKEN_groups, PROPERTY_TOKEN_items, PROPERTY_TOKEN_layers, PROPERTY_TOKEN_legends, PROPERTY_TOKEN_location, PROPERTY_TOKEN_locations, PROPERTY_TOKEN_markers, PROPERTY_TOKEN_mentions, PROPERTY_TOKEN_menuItems, PROPERTY_TOKEN_panes, PROPERTY_TOKEN_ranges, PROPERTY_TOKEN_resources, PROPERTY_TOKEN_routes, PROPERTY_TOKEN_rows, PROPERTY_TOKEN_series, PROPERTY_TOKEN_sortByGroupSummaryInfo, PROPERTY_TOKEN_stripLines, PROPERTY_TOKEN_strips, PROPERTY_TOKEN_tabs, PROPERTY_TOKEN_toolbarItems, PROPERTY_TOKEN_totalItems, PROPERTY_TOKEN_typingUsers, PROPERTY_TOKEN_validationRules, PROPERTY_TOKEN_valueAxis, PROPERTY_TOKEN_views };
//# sourceMappingURL=devextreme-angular-core-tokens.mjs.map
