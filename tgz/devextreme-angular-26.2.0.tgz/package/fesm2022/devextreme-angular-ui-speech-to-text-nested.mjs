import * as i0 from '@angular/core';
import { Input, SkipSelf, Host, Component, NgModule } from '@angular/core';
import * as i1 from 'devextreme-angular/core';
import { NestedOption, DxIntegrationModule, NestedOptionHost } from 'devextreme-angular/core';

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoSpeechToTextCustomSpeechRecognizerComponent extends NestedOption {
    get enabled() {
        return this._getOption('enabled');
    }
    set enabled(value) {
        this._setOption('enabled', value);
    }
    get isListening() {
        return this._getOption('isListening');
    }
    set isListening(value) {
        this._setOption('isListening', value);
    }
    get _optionPath() {
        return 'customSpeechRecognizer';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoSpeechToTextCustomSpeechRecognizerComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoSpeechToTextCustomSpeechRecognizerComponent, isStandalone: true, selector: "dxo-speech-to-text-custom-speech-recognizer", inputs: { enabled: "enabled", isListening: "isListening" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoSpeechToTextCustomSpeechRecognizerComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-speech-to-text-custom-speech-recognizer', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { enabled: [{
                type: Input
            }], isListening: [{
                type: Input
            }] } });
class DxoSpeechToTextCustomSpeechRecognizerModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoSpeechToTextCustomSpeechRecognizerModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoSpeechToTextCustomSpeechRecognizerModule, imports: [DxoSpeechToTextCustomSpeechRecognizerComponent], exports: [DxoSpeechToTextCustomSpeechRecognizerComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoSpeechToTextCustomSpeechRecognizerModule, imports: [DxoSpeechToTextCustomSpeechRecognizerComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoSpeechToTextCustomSpeechRecognizerModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoSpeechToTextCustomSpeechRecognizerComponent
                    ],
                    exports: [
                        DxoSpeechToTextCustomSpeechRecognizerComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoSpeechToTextSpeechRecognitionConfigComponent extends NestedOption {
    get continuous() {
        return this._getOption('continuous');
    }
    set continuous(value) {
        this._setOption('continuous', value);
    }
    get grammars() {
        return this._getOption('grammars');
    }
    set grammars(value) {
        this._setOption('grammars', value);
    }
    get interimResults() {
        return this._getOption('interimResults');
    }
    set interimResults(value) {
        this._setOption('interimResults', value);
    }
    get lang() {
        return this._getOption('lang');
    }
    set lang(value) {
        this._setOption('lang', value);
    }
    get maxAlternatives() {
        return this._getOption('maxAlternatives');
    }
    set maxAlternatives(value) {
        this._setOption('maxAlternatives', value);
    }
    get _optionPath() {
        return 'speechRecognitionConfig';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoSpeechToTextSpeechRecognitionConfigComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoSpeechToTextSpeechRecognitionConfigComponent, isStandalone: true, selector: "dxo-speech-to-text-speech-recognition-config", inputs: { continuous: "continuous", grammars: "grammars", interimResults: "interimResults", lang: "lang", maxAlternatives: "maxAlternatives" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoSpeechToTextSpeechRecognitionConfigComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-speech-to-text-speech-recognition-config', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { continuous: [{
                type: Input
            }], grammars: [{
                type: Input
            }], interimResults: [{
                type: Input
            }], lang: [{
                type: Input
            }], maxAlternatives: [{
                type: Input
            }] } });
class DxoSpeechToTextSpeechRecognitionConfigModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoSpeechToTextSpeechRecognitionConfigModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoSpeechToTextSpeechRecognitionConfigModule, imports: [DxoSpeechToTextSpeechRecognitionConfigComponent], exports: [DxoSpeechToTextSpeechRecognitionConfigComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoSpeechToTextSpeechRecognitionConfigModule, imports: [DxoSpeechToTextSpeechRecognitionConfigComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoSpeechToTextSpeechRecognitionConfigModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoSpeechToTextSpeechRecognitionConfigComponent
                    ],
                    exports: [
                        DxoSpeechToTextSpeechRecognitionConfigComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

/**
 * Generated bundle index. Do not edit.
 */

export { DxoSpeechToTextCustomSpeechRecognizerComponent, DxoSpeechToTextCustomSpeechRecognizerModule, DxoSpeechToTextSpeechRecognitionConfigComponent, DxoSpeechToTextSpeechRecognitionConfigModule };
//# sourceMappingURL=devextreme-angular-ui-speech-to-text-nested.mjs.map
