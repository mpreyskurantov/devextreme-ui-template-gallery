import * as i0 from '@angular/core';
import { PLATFORM_ID, Output, Input, ContentChildren, Inject, Component, NgModule } from '@angular/core';
import DxResponsiveBox from 'devextreme/ui/responsive_box';
import * as i1 from 'devextreme-angular/core';
import { DxComponent, DxIntegrationModule, DxTemplateHost, WatcherHelper, NestedOptionHost, IterableDifferHelper, DxTemplateModule } from 'devextreme-angular/core';
import { DxiColModule, DxiItemModule, DxiLocationModule, DxiRowModule } from 'devextreme-angular/ui/nested';
import { DxiResponsiveBoxColModule, DxiResponsiveBoxItemModule, DxiResponsiveBoxLocationModule, DxiResponsiveBoxRowModule } from 'devextreme-angular/ui/responsive-box/nested';
export * from 'devextreme-angular/ui/responsive-box/nested';
import { PROPERTY_TOKEN_cols, PROPERTY_TOKEN_items, PROPERTY_TOKEN_location, PROPERTY_TOKEN_rows } from 'devextreme-angular/core/tokens';

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
/**
 * [descr:dxResponsiveBox]

 */
class DxResponsiveBoxComponent extends DxComponent {
    set _colsContentChildren(value) {
        this.setChildren('cols', value);
    }
    set _itemsContentChildren(value) {
        this.setChildren('items', value);
    }
    set _locationContentChildren(value) {
        this.setChildren('location', value);
    }
    set _rowsContentChildren(value) {
        this.setChildren('rows', value);
    }
    /**
     * [descr:dxResponsiveBoxOptions.cols]
    
     */
    get cols() {
        return this._getOption('cols');
    }
    set cols(value) {
        this._setOption('cols', value);
    }
    /**
     * [descr:dxResponsiveBoxOptions.dataSource]
    
     */
    get dataSource() {
        return this._getOption('dataSource');
    }
    set dataSource(value) {
        this._setOption('dataSource', value);
    }
    /**
     * [descr:WidgetOptions.disabled]
    
     */
    get disabled() {
        return this._getOption('disabled');
    }
    set disabled(value) {
        this._setOption('disabled', value);
    }
    /**
     * [descr:DOMComponentOptions.elementAttr]
    
     */
    get elementAttr() {
        return this._getOption('elementAttr');
    }
    set elementAttr(value) {
        this._setOption('elementAttr', value);
    }
    /**
     * [descr:dxResponsiveBoxOptions.height]
    
     */
    get height() {
        return this._getOption('height');
    }
    set height(value) {
        this._setOption('height', value);
    }
    /**
     * [descr:WidgetOptions.hoverStateEnabled]
    
     */
    get hoverStateEnabled() {
        return this._getOption('hoverStateEnabled');
    }
    set hoverStateEnabled(value) {
        this._setOption('hoverStateEnabled', value);
    }
    /**
     * [descr:CollectionWidgetOptions.itemHoldTimeout]
    
     */
    get itemHoldTimeout() {
        return this._getOption('itemHoldTimeout');
    }
    set itemHoldTimeout(value) {
        this._setOption('itemHoldTimeout', value);
    }
    /**
     * [descr:dxResponsiveBoxOptions.items]
    
     */
    get items() {
        return this._getOption('items');
    }
    set items(value) {
        this._setOption('items', value);
    }
    /**
     * [descr:CollectionWidgetOptions.itemTemplate]
    
     */
    get itemTemplate() {
        return this._getOption('itemTemplate');
    }
    set itemTemplate(value) {
        this._setOption('itemTemplate', value);
    }
    /**
     * [descr:dxResponsiveBoxOptions.rows]
    
     */
    get rows() {
        return this._getOption('rows');
    }
    set rows(value) {
        this._setOption('rows', value);
    }
    /**
     * [descr:DOMComponentOptions.rtlEnabled]
    
     */
    get rtlEnabled() {
        return this._getOption('rtlEnabled');
    }
    set rtlEnabled(value) {
        this._setOption('rtlEnabled', value);
    }
    /**
     * [descr:dxResponsiveBoxOptions.screenByWidth]
    
     */
    get screenByWidth() {
        return this._getOption('screenByWidth');
    }
    set screenByWidth(value) {
        this._setOption('screenByWidth', value);
    }
    /**
     * [descr:dxResponsiveBoxOptions.singleColumnScreen]
    
     */
    get singleColumnScreen() {
        return this._getOption('singleColumnScreen');
    }
    set singleColumnScreen(value) {
        this._setOption('singleColumnScreen', value);
    }
    /**
     * [descr:WidgetOptions.visible]
    
     */
    get visible() {
        return this._getOption('visible');
    }
    set visible(value) {
        this._setOption('visible', value);
    }
    /**
     * [descr:dxResponsiveBoxOptions.width]
    
     */
    get width() {
        return this._getOption('width');
    }
    set width(value) {
        this._setOption('width', value);
    }
    constructor(elementRef, ngZone, templateHost, _watcherHelper, _idh, optionHost, transferState, platformId) {
        super(elementRef, ngZone, templateHost, _watcherHelper, transferState, platformId);
        this._watcherHelper = _watcherHelper;
        this._idh = _idh;
        this.instance = null;
        this._createEventEmitters([
            { subscribe: 'contentReady', emit: 'onContentReady' },
            { subscribe: 'disposing', emit: 'onDisposing' },
            { subscribe: 'initialized', emit: 'onInitialized' },
            { subscribe: 'itemClick', emit: 'onItemClick' },
            { subscribe: 'itemContextMenu', emit: 'onItemContextMenu' },
            { subscribe: 'itemHold', emit: 'onItemHold' },
            { subscribe: 'itemRendered', emit: 'onItemRendered' },
            { subscribe: 'optionChanged', emit: 'onOptionChanged' },
            { emit: 'colsChange' },
            { emit: 'dataSourceChange' },
            { emit: 'disabledChange' },
            { emit: 'elementAttrChange' },
            { emit: 'heightChange' },
            { emit: 'hoverStateEnabledChange' },
            { emit: 'itemHoldTimeoutChange' },
            { emit: 'itemsChange' },
            { emit: 'itemTemplateChange' },
            { emit: 'rowsChange' },
            { emit: 'rtlEnabledChange' },
            { emit: 'screenByWidthChange' },
            { emit: 'singleColumnScreenChange' },
            { emit: 'visibleChange' },
            { emit: 'widthChange' }
        ]);
        this._idh.setHost(this);
        optionHost.setHost(this);
    }
    _createInstance(element, options) {
        return new DxResponsiveBox(element, options);
    }
    ngOnDestroy() {
        this._destroyWidget();
    }
    ngOnChanges(changes) {
        super.ngOnChanges(changes);
        this.setupChanges('cols', changes);
        this.setupChanges('dataSource', changes);
        this.setupChanges('items', changes);
        this.setupChanges('rows', changes);
    }
    setupChanges(prop, changes) {
        if (!(prop in this._optionsToUpdate)) {
            this._idh.setup(prop, changes);
        }
    }
    ngDoCheck() {
        this._idh.doCheck('cols');
        this._idh.doCheck('dataSource');
        this._idh.doCheck('items');
        this._idh.doCheck('rows');
        this._watcherHelper.checkWatchers();
        super.ngDoCheck();
        super.clearChangedOptions();
    }
    _setOption(name, value) {
        let isSetup = this._idh.setupSingle(name, value);
        let isChanged = this._idh.getChanges(name, value) !== null;
        if (isSetup || isChanged) {
            super._setOption(name, value);
        }
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxResponsiveBoxComponent, deps: [{ token: i0.ElementRef }, { token: i0.NgZone }, { token: i1.DxTemplateHost }, { token: i1.WatcherHelper }, { token: i1.IterableDifferHelper }, { token: i1.NestedOptionHost }, { token: i0.TransferState }, { token: PLATFORM_ID }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxResponsiveBoxComponent, isStandalone: true, selector: "dx-responsive-box", inputs: { cols: "cols", dataSource: "dataSource", disabled: "disabled", elementAttr: "elementAttr", height: "height", hoverStateEnabled: "hoverStateEnabled", itemHoldTimeout: "itemHoldTimeout", items: "items", itemTemplate: "itemTemplate", rows: "rows", rtlEnabled: "rtlEnabled", screenByWidth: "screenByWidth", singleColumnScreen: "singleColumnScreen", visible: "visible", width: "width" }, outputs: { onContentReady: "onContentReady", onDisposing: "onDisposing", onInitialized: "onInitialized", onItemClick: "onItemClick", onItemContextMenu: "onItemContextMenu", onItemHold: "onItemHold", onItemRendered: "onItemRendered", onOptionChanged: "onOptionChanged", colsChange: "colsChange", dataSourceChange: "dataSourceChange", disabledChange: "disabledChange", elementAttrChange: "elementAttrChange", heightChange: "heightChange", hoverStateEnabledChange: "hoverStateEnabledChange", itemHoldTimeoutChange: "itemHoldTimeoutChange", itemsChange: "itemsChange", itemTemplateChange: "itemTemplateChange", rowsChange: "rowsChange", rtlEnabledChange: "rtlEnabledChange", screenByWidthChange: "screenByWidthChange", singleColumnScreenChange: "singleColumnScreenChange", visibleChange: "visibleChange", widthChange: "widthChange" }, host: { attributes: { "ngSkipHydration": "true" } }, providers: [
            DxTemplateHost,
            WatcherHelper,
            NestedOptionHost,
            IterableDifferHelper
        ], queries: [{ propertyName: "_colsContentChildren", predicate: PROPERTY_TOKEN_cols }, { propertyName: "_itemsContentChildren", predicate: PROPERTY_TOKEN_items }, { propertyName: "_locationContentChildren", predicate: PROPERTY_TOKEN_location }, { propertyName: "_rowsContentChildren", predicate: PROPERTY_TOKEN_rows }], usesInheritance: true, usesOnChanges: true, ngImport: i0, template: '', isInline: true, dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxResponsiveBoxComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'dx-responsive-box',
                    template: '',
                    host: { ngSkipHydration: 'true' },
                    imports: [DxIntegrationModule],
                    providers: [
                        DxTemplateHost,
                        WatcherHelper,
                        NestedOptionHost,
                        IterableDifferHelper
                    ]
                }]
        }], ctorParameters: () => [{ type: i0.ElementRef }, { type: i0.NgZone }, { type: i1.DxTemplateHost }, { type: i1.WatcherHelper }, { type: i1.IterableDifferHelper }, { type: i1.NestedOptionHost }, { type: i0.TransferState }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [PLATFORM_ID]
                }] }], propDecorators: { _colsContentChildren: [{
                type: ContentChildren,
                args: [PROPERTY_TOKEN_cols]
            }], _itemsContentChildren: [{
                type: ContentChildren,
                args: [PROPERTY_TOKEN_items]
            }], _locationContentChildren: [{
                type: ContentChildren,
                args: [PROPERTY_TOKEN_location]
            }], _rowsContentChildren: [{
                type: ContentChildren,
                args: [PROPERTY_TOKEN_rows]
            }], cols: [{
                type: Input
            }], dataSource: [{
                type: Input
            }], disabled: [{
                type: Input
            }], elementAttr: [{
                type: Input
            }], height: [{
                type: Input
            }], hoverStateEnabled: [{
                type: Input
            }], itemHoldTimeout: [{
                type: Input
            }], items: [{
                type: Input
            }], itemTemplate: [{
                type: Input
            }], rows: [{
                type: Input
            }], rtlEnabled: [{
                type: Input
            }], screenByWidth: [{
                type: Input
            }], singleColumnScreen: [{
                type: Input
            }], visible: [{
                type: Input
            }], width: [{
                type: Input
            }], onContentReady: [{
                type: Output
            }], onDisposing: [{
                type: Output
            }], onInitialized: [{
                type: Output
            }], onItemClick: [{
                type: Output
            }], onItemContextMenu: [{
                type: Output
            }], onItemHold: [{
                type: Output
            }], onItemRendered: [{
                type: Output
            }], onOptionChanged: [{
                type: Output
            }], colsChange: [{
                type: Output
            }], dataSourceChange: [{
                type: Output
            }], disabledChange: [{
                type: Output
            }], elementAttrChange: [{
                type: Output
            }], heightChange: [{
                type: Output
            }], hoverStateEnabledChange: [{
                type: Output
            }], itemHoldTimeoutChange: [{
                type: Output
            }], itemsChange: [{
                type: Output
            }], itemTemplateChange: [{
                type: Output
            }], rowsChange: [{
                type: Output
            }], rtlEnabledChange: [{
                type: Output
            }], screenByWidthChange: [{
                type: Output
            }], singleColumnScreenChange: [{
                type: Output
            }], visibleChange: [{
                type: Output
            }], widthChange: [{
                type: Output
            }] } });
class DxResponsiveBoxModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxResponsiveBoxModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxResponsiveBoxModule, imports: [DxResponsiveBoxComponent, DxiColModule,
            DxiItemModule,
            DxiLocationModule,
            DxiRowModule,
            DxiResponsiveBoxColModule,
            DxiResponsiveBoxItemModule,
            DxiResponsiveBoxLocationModule,
            DxiResponsiveBoxRowModule,
            DxIntegrationModule,
            DxTemplateModule], exports: [DxResponsiveBoxComponent, DxiColModule,
            DxiItemModule,
            DxiLocationModule,
            DxiRowModule,
            DxiResponsiveBoxColModule,
            DxiResponsiveBoxItemModule,
            DxiResponsiveBoxLocationModule,
            DxiResponsiveBoxRowModule,
            DxTemplateModule] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxResponsiveBoxModule, imports: [DxResponsiveBoxComponent,
            DxiColModule,
            DxiItemModule,
            DxiLocationModule,
            DxiRowModule,
            DxiResponsiveBoxColModule,
            DxiResponsiveBoxItemModule,
            DxiResponsiveBoxLocationModule,
            DxiResponsiveBoxRowModule,
            DxIntegrationModule,
            DxTemplateModule, DxiColModule,
            DxiItemModule,
            DxiLocationModule,
            DxiRowModule,
            DxiResponsiveBoxColModule,
            DxiResponsiveBoxItemModule,
            DxiResponsiveBoxLocationModule,
            DxiResponsiveBoxRowModule,
            DxTemplateModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxResponsiveBoxModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxResponsiveBoxComponent,
                        DxiColModule,
                        DxiItemModule,
                        DxiLocationModule,
                        DxiRowModule,
                        DxiResponsiveBoxColModule,
                        DxiResponsiveBoxItemModule,
                        DxiResponsiveBoxLocationModule,
                        DxiResponsiveBoxRowModule,
                        DxIntegrationModule,
                        DxTemplateModule
                    ],
                    exports: [
                        DxResponsiveBoxComponent,
                        DxiColModule,
                        DxiItemModule,
                        DxiLocationModule,
                        DxiRowModule,
                        DxiResponsiveBoxColModule,
                        DxiResponsiveBoxItemModule,
                        DxiResponsiveBoxLocationModule,
                        DxiResponsiveBoxRowModule,
                        DxTemplateModule
                    ]
                }]
        }] });

/**
 * Generated bundle index. Do not edit.
 */

export { DxResponsiveBoxComponent, DxResponsiveBoxModule };
//# sourceMappingURL=devextreme-angular-ui-responsive-box.mjs.map
