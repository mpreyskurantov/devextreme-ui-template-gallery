import * as i0 from '@angular/core';
import { forwardRef, PLATFORM_ID, HostListener, Output, Input, ContentChildren, Inject, Component, NgModule } from '@angular/core';
import DxRangeSelector from 'devextreme/viz/range_selector';
import { NG_VALUE_ACCESSOR } from '@angular/forms';
import * as i1 from 'devextreme-angular/core';
import { DxComponent, DxIntegrationModule, DxTemplateHost, WatcherHelper, NestedOptionHost, IterableDifferHelper, DxTemplateModule } from 'devextreme-angular/core';
import { DxoBackgroundModule, DxoImageModule, DxoBehaviorModule, DxoChartModule, DxoCommonSeriesSettingsModule, DxoAggregationModule, DxoAreaModule, DxoBorderModule, DxoHoverStyleModule, DxoHatchingModule, DxoLabelModule, DxoConnectorModule, DxoPointModule, DxoHeightModule, DxoUrlModule, DxoWidthModule, DxoSelectionStyleModule, DxoReductionModule, DxoValueErrorBarModule, DxoBarModule, DxoBubbleModule, DxoCandlestickModule, DxoColorModule, DxoFullstackedareaModule, DxoFullstackedbarModule, DxoFullstackedlineModule, DxoFullstackedsplineModule, DxoFullstackedsplineareaModule, DxoArgumentFormatModule, DxoFontModule, DxoFormatModule, DxoLineModule, DxoRangeareaModule, DxoRangebarModule, DxoScatterModule, DxoSplineModule, DxoSplineareaModule, DxoStackedareaModule, DxoStackedbarModule, DxoStackedlineModule, DxoStackedsplineModule, DxoStackedsplineareaModule, DxoStepareaModule, DxoSteplineModule, DxoStockModule, DxoDataPrepareSettingsModule, DxiSeriesModule, DxoSeriesTemplateModule, DxoValueAxisModule, DxoExportModule, DxoIndentModule, DxoLoadingIndicatorModule, DxoMarginModule, DxoScaleModule, DxoAggregationIntervalModule, DxiBreakModule, DxoBreakStyleModule, DxoMarkerModule, DxoMaxRangeModule, DxoMinorTickModule, DxoMinorTickIntervalModule, DxoMinRangeModule, DxoTickModule, DxoTickIntervalModule, DxoShutterModule, DxoSizeModule, DxoSliderHandleModule, DxoSliderMarkerModule, DxoTitleModule, DxoSubtitleModule } from 'devextreme-angular/ui/nested';
import { DxoRangeSelectorAggregationModule, DxoRangeSelectorAggregationIntervalModule, DxoRangeSelectorArgumentFormatModule, DxoRangeSelectorBackgroundModule, DxoRangeSelectorBackgroundImageModule, DxoRangeSelectorBehaviorModule, DxoRangeSelectorBorderModule, DxiRangeSelectorBreakModule, DxoRangeSelectorBreakStyleModule, DxoRangeSelectorChartModule, DxoRangeSelectorColorModule, DxoRangeSelectorCommonSeriesSettingsModule, DxoRangeSelectorCommonSeriesSettingsHoverStyleModule, DxoRangeSelectorCommonSeriesSettingsLabelModule, DxoRangeSelectorCommonSeriesSettingsSelectionStyleModule, DxoRangeSelectorConnectorModule, DxoRangeSelectorDataPrepareSettingsModule, DxoRangeSelectorExportModule, DxoRangeSelectorFontModule, DxoRangeSelectorFormatModule, DxoRangeSelectorHatchingModule, DxoRangeSelectorHeightModule, DxoRangeSelectorHoverStyleModule, DxoRangeSelectorImageModule, DxoRangeSelectorIndentModule, DxoRangeSelectorLabelModule, DxoRangeSelectorLengthModule, DxoRangeSelectorLoadingIndicatorModule, DxoRangeSelectorMarginModule, DxoRangeSelectorMarkerModule, DxoRangeSelectorMarkerLabelModule, DxoRangeSelectorMaxRangeModule, DxoRangeSelectorMinorTickModule, DxoRangeSelectorMinorTickIntervalModule, DxoRangeSelectorMinRangeModule, DxoRangeSelectorPointModule, DxoRangeSelectorPointBorderModule, DxoRangeSelectorPointHoverStyleModule, DxoRangeSelectorPointImageModule, DxoRangeSelectorPointSelectionStyleModule, DxoRangeSelectorReductionModule, DxoRangeSelectorScaleModule, DxoRangeSelectorScaleLabelModule, DxoRangeSelectorSelectionStyleModule, DxiRangeSelectorSeriesModule, DxoRangeSelectorSeriesBorderModule, DxoRangeSelectorSeriesTemplateModule, DxoRangeSelectorShutterModule, DxoRangeSelectorSizeModule, DxoRangeSelectorSliderHandleModule, DxoRangeSelectorSliderMarkerModule, DxoRangeSelectorSubtitleModule, DxoRangeSelectorTickModule, DxoRangeSelectorTickIntervalModule, DxoRangeSelectorTitleModule, DxoRangeSelectorUrlModule, DxoRangeSelectorValueModule, DxoRangeSelectorValueAxisModule, DxoRangeSelectorValueErrorBarModule, DxoRangeSelectorWidthModule } from 'devextreme-angular/ui/range-selector/nested';
export * from 'devextreme-angular/ui/range-selector/nested';
import { PROPERTY_TOKEN_breaks, PROPERTY_TOKEN_series } from 'devextreme-angular/core/tokens';

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
const CUSTOM_VALUE_ACCESSOR_PROVIDER = {
    provide: NG_VALUE_ACCESSOR,
    useExisting: forwardRef(() => DxRangeSelectorComponent),
    multi: true
};
/**
 * [descr:dxRangeSelector]

 */
class DxRangeSelectorComponent extends DxComponent {
    set _breaksContentChildren(value) {
        this.setChildren('breaks', value);
    }
    set _seriesContentChildren(value) {
        this.setChildren('series', value);
    }
    /**
     * [descr:dxRangeSelectorOptions.background]
    
     */
    get background() {
        return this._getOption('background');
    }
    set background(value) {
        this._setOption('background', value);
    }
    /**
     * [descr:dxRangeSelectorOptions.behavior]
    
     */
    get behavior() {
        return this._getOption('behavior');
    }
    set behavior(value) {
        this._setOption('behavior', value);
    }
    /**
     * [descr:dxRangeSelectorOptions.chart]
    
     */
    get chart() {
        return this._getOption('chart');
    }
    set chart(value) {
        this._setOption('chart', value);
    }
    /**
     * [descr:dxRangeSelectorOptions.containerBackgroundColor]
    
     */
    get containerBackgroundColor() {
        return this._getOption('containerBackgroundColor');
    }
    set containerBackgroundColor(value) {
        this._setOption('containerBackgroundColor', value);
    }
    /**
     * [descr:dxRangeSelectorOptions.dataSource]
    
     */
    get dataSource() {
        return this._getOption('dataSource');
    }
    set dataSource(value) {
        this._setOption('dataSource', value);
    }
    /**
     * [descr:dxRangeSelectorOptions.dataSourceField]
    
     */
    get dataSourceField() {
        return this._getOption('dataSourceField');
    }
    set dataSourceField(value) {
        this._setOption('dataSourceField', value);
    }
    /**
     * [descr:BaseWidgetOptions.disabled]
    
     */
    get disabled() {
        return this._getOption('disabled');
    }
    set disabled(value) {
        this._setOption('disabled', value);
    }
    /**
     * [descr:DOMComponentOptions.elementAttr]
    
     */
    get elementAttr() {
        return this._getOption('elementAttr');
    }
    set elementAttr(value) {
        this._setOption('elementAttr', value);
    }
    /**
     * [descr:BaseWidgetOptions.encodeHtml]
    
     */
    get encodeHtml() {
        return this._getOption('encodeHtml');
    }
    set encodeHtml(value) {
        this._setOption('encodeHtml', value);
    }
    /**
     * [descr:BaseWidgetOptions.export]
    
     */
    get export() {
        return this._getOption('export');
    }
    set export(value) {
        this._setOption('export', value);
    }
    /**
     * [descr:dxRangeSelectorOptions.indent]
    
     */
    get indent() {
        return this._getOption('indent');
    }
    set indent(value) {
        this._setOption('indent', value);
    }
    /**
     * [descr:BaseWidgetOptions.loadingIndicator]
    
     */
    get loadingIndicator() {
        return this._getOption('loadingIndicator');
    }
    set loadingIndicator(value) {
        this._setOption('loadingIndicator', value);
    }
    /**
     * [descr:BaseWidgetOptions.margin]
    
     */
    get margin() {
        return this._getOption('margin');
    }
    set margin(value) {
        this._setOption('margin', value);
    }
    /**
     * [descr:BaseWidgetOptions.pathModified]
    
     */
    get pathModified() {
        return this._getOption('pathModified');
    }
    set pathModified(value) {
        this._setOption('pathModified', value);
    }
    /**
     * [descr:BaseWidgetOptions.redrawOnResize]
    
     */
    get redrawOnResize() {
        return this._getOption('redrawOnResize');
    }
    set redrawOnResize(value) {
        this._setOption('redrawOnResize', value);
    }
    /**
     * [descr:BaseWidgetOptions.rtlEnabled]
    
     */
    get rtlEnabled() {
        return this._getOption('rtlEnabled');
    }
    set rtlEnabled(value) {
        this._setOption('rtlEnabled', value);
    }
    /**
     * [descr:dxRangeSelectorOptions.scale]
    
     */
    get scale() {
        return this._getOption('scale');
    }
    set scale(value) {
        this._setOption('scale', value);
    }
    /**
     * [descr:dxRangeSelectorOptions.selectedRangeColor]
    
     */
    get selectedRangeColor() {
        return this._getOption('selectedRangeColor');
    }
    set selectedRangeColor(value) {
        this._setOption('selectedRangeColor', value);
    }
    /**
     * [descr:dxRangeSelectorOptions.selectedRangeUpdateMode]
    
     */
    get selectedRangeUpdateMode() {
        return this._getOption('selectedRangeUpdateMode');
    }
    set selectedRangeUpdateMode(value) {
        this._setOption('selectedRangeUpdateMode', value);
    }
    /**
     * [descr:dxRangeSelectorOptions.shutter]
    
     */
    get shutter() {
        return this._getOption('shutter');
    }
    set shutter(value) {
        this._setOption('shutter', value);
    }
    /**
     * [descr:BaseWidgetOptions.size]
    
     */
    get size() {
        return this._getOption('size');
    }
    set size(value) {
        this._setOption('size', value);
    }
    /**
     * [descr:dxRangeSelectorOptions.sliderHandle]
    
     */
    get sliderHandle() {
        return this._getOption('sliderHandle');
    }
    set sliderHandle(value) {
        this._setOption('sliderHandle', value);
    }
    /**
     * [descr:dxRangeSelectorOptions.sliderMarker]
    
     */
    get sliderMarker() {
        return this._getOption('sliderMarker');
    }
    set sliderMarker(value) {
        this._setOption('sliderMarker', value);
    }
    /**
     * [descr:BaseWidgetOptions.theme]
    
     */
    get theme() {
        return this._getOption('theme');
    }
    set theme(value) {
        this._setOption('theme', value);
    }
    /**
     * [descr:BaseWidgetOptions.title]
    
     */
    get title() {
        return this._getOption('title');
    }
    set title(value) {
        this._setOption('title', value);
    }
    /**
     * [descr:dxRangeSelectorOptions.value]
    
     */
    get value() {
        return this._getOption('value');
    }
    set value(value) {
        this._setOption('value', value);
    }
    change(_) { }
    constructor(elementRef, ngZone, templateHost, _watcherHelper, _idh, optionHost, transferState, platformId) {
        super(elementRef, ngZone, templateHost, _watcherHelper, transferState, platformId);
        this._watcherHelper = _watcherHelper;
        this._idh = _idh;
        this.instance = null;
        this.touched = (_) => { };
        this._createEventEmitters([
            { subscribe: 'disposing', emit: 'onDisposing' },
            { subscribe: 'drawn', emit: 'onDrawn' },
            { subscribe: 'exported', emit: 'onExported' },
            { subscribe: 'exporting', emit: 'onExporting' },
            { subscribe: 'fileSaving', emit: 'onFileSaving' },
            { subscribe: 'incidentOccurred', emit: 'onIncidentOccurred' },
            { subscribe: 'initialized', emit: 'onInitialized' },
            { subscribe: 'optionChanged', emit: 'onOptionChanged' },
            { subscribe: 'valueChanged', emit: 'onValueChanged' },
            { emit: 'backgroundChange' },
            { emit: 'behaviorChange' },
            { emit: 'chartChange' },
            { emit: 'containerBackgroundColorChange' },
            { emit: 'dataSourceChange' },
            { emit: 'dataSourceFieldChange' },
            { emit: 'disabledChange' },
            { emit: 'elementAttrChange' },
            { emit: 'encodeHtmlChange' },
            { emit: 'exportChange' },
            { emit: 'indentChange' },
            { emit: 'loadingIndicatorChange' },
            { emit: 'marginChange' },
            { emit: 'pathModifiedChange' },
            { emit: 'redrawOnResizeChange' },
            { emit: 'rtlEnabledChange' },
            { emit: 'scaleChange' },
            { emit: 'selectedRangeColorChange' },
            { emit: 'selectedRangeUpdateModeChange' },
            { emit: 'shutterChange' },
            { emit: 'sizeChange' },
            { emit: 'sliderHandleChange' },
            { emit: 'sliderMarkerChange' },
            { emit: 'themeChange' },
            { emit: 'titleChange' },
            { emit: 'valueChange' },
            { emit: 'onBlur' }
        ]);
        this._idh.setHost(this);
        optionHost.setHost(this);
    }
    _createInstance(element, options) {
        return new DxRangeSelector(element, options);
    }
    writeValue(value) {
        this.eventHelper.lockedValueChangeEvent = true;
        this.value = value;
        this.eventHelper.lockedValueChangeEvent = false;
    }
    registerOnChange(fn) { this.change = fn; }
    registerOnTouched(fn) { this.touched = fn; }
    _createWidget(element) {
        super._createWidget(element);
        this.instance.on('focusOut', (e) => {
            this.eventHelper.fireNgEvent('onBlur', [e]);
        });
    }
    ngOnDestroy() {
        this._destroyWidget();
    }
    ngOnChanges(changes) {
        super.ngOnChanges(changes);
        this.setupChanges('dataSource', changes);
        this.setupChanges('value', changes);
    }
    setupChanges(prop, changes) {
        if (!(prop in this._optionsToUpdate)) {
            this._idh.setup(prop, changes);
        }
    }
    ngDoCheck() {
        this._idh.doCheck('dataSource');
        this._idh.doCheck('value');
        this._watcherHelper.checkWatchers();
        super.ngDoCheck();
        super.clearChangedOptions();
    }
    _setOption(name, value) {
        let isSetup = this._idh.setupSingle(name, value);
        let isChanged = this._idh.getChanges(name, value) !== null;
        if (isSetup || isChanged) {
            super._setOption(name, value);
        }
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxRangeSelectorComponent, deps: [{ token: i0.ElementRef }, { token: i0.NgZone }, { token: i1.DxTemplateHost }, { token: i1.WatcherHelper }, { token: i1.IterableDifferHelper }, { token: i1.NestedOptionHost }, { token: i0.TransferState }, { token: PLATFORM_ID }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxRangeSelectorComponent, isStandalone: true, selector: "dx-range-selector", inputs: { background: "background", behavior: "behavior", chart: "chart", containerBackgroundColor: "containerBackgroundColor", dataSource: "dataSource", dataSourceField: "dataSourceField", disabled: "disabled", elementAttr: "elementAttr", encodeHtml: "encodeHtml", export: "export", indent: "indent", loadingIndicator: "loadingIndicator", margin: "margin", pathModified: "pathModified", redrawOnResize: "redrawOnResize", rtlEnabled: "rtlEnabled", scale: "scale", selectedRangeColor: "selectedRangeColor", selectedRangeUpdateMode: "selectedRangeUpdateMode", shutter: "shutter", size: "size", sliderHandle: "sliderHandle", sliderMarker: "sliderMarker", theme: "theme", title: "title", value: "value" }, outputs: { onDisposing: "onDisposing", onDrawn: "onDrawn", onExported: "onExported", onExporting: "onExporting", onFileSaving: "onFileSaving", onIncidentOccurred: "onIncidentOccurred", onInitialized: "onInitialized", onOptionChanged: "onOptionChanged", onValueChanged: "onValueChanged", backgroundChange: "backgroundChange", behaviorChange: "behaviorChange", chartChange: "chartChange", containerBackgroundColorChange: "containerBackgroundColorChange", dataSourceChange: "dataSourceChange", dataSourceFieldChange: "dataSourceFieldChange", disabledChange: "disabledChange", elementAttrChange: "elementAttrChange", encodeHtmlChange: "encodeHtmlChange", exportChange: "exportChange", indentChange: "indentChange", loadingIndicatorChange: "loadingIndicatorChange", marginChange: "marginChange", pathModifiedChange: "pathModifiedChange", redrawOnResizeChange: "redrawOnResizeChange", rtlEnabledChange: "rtlEnabledChange", scaleChange: "scaleChange", selectedRangeColorChange: "selectedRangeColorChange", selectedRangeUpdateModeChange: "selectedRangeUpdateModeChange", shutterChange: "shutterChange", sizeChange: "sizeChange", sliderHandleChange: "sliderHandleChange", sliderMarkerChange: "sliderMarkerChange", themeChange: "themeChange", titleChange: "titleChange", valueChange: "valueChange", onBlur: "onBlur" }, host: { attributes: { "ngSkipHydration": "true" }, listeners: { "valueChange": "change($event)", "onBlur": "touched($event)" } }, providers: [
            DxTemplateHost,
            WatcherHelper,
            CUSTOM_VALUE_ACCESSOR_PROVIDER,
            NestedOptionHost,
            IterableDifferHelper
        ], queries: [{ propertyName: "_breaksContentChildren", predicate: PROPERTY_TOKEN_breaks }, { propertyName: "_seriesContentChildren", predicate: PROPERTY_TOKEN_series }], usesInheritance: true, usesOnChanges: true, ngImport: i0, template: '', isInline: true, styles: [":host{display:block}\n"], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxRangeSelectorComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dx-range-selector', template: '', host: { ngSkipHydration: 'true' }, imports: [DxIntegrationModule], providers: [
                        DxTemplateHost,
                        WatcherHelper,
                        CUSTOM_VALUE_ACCESSOR_PROVIDER,
                        NestedOptionHost,
                        IterableDifferHelper
                    ], styles: [":host{display:block}\n"] }]
        }], ctorParameters: () => [{ type: i0.ElementRef }, { type: i0.NgZone }, { type: i1.DxTemplateHost }, { type: i1.WatcherHelper }, { type: i1.IterableDifferHelper }, { type: i1.NestedOptionHost }, { type: i0.TransferState }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [PLATFORM_ID]
                }] }], propDecorators: { _breaksContentChildren: [{
                type: ContentChildren,
                args: [PROPERTY_TOKEN_breaks]
            }], _seriesContentChildren: [{
                type: ContentChildren,
                args: [PROPERTY_TOKEN_series]
            }], background: [{
                type: Input
            }], behavior: [{
                type: Input
            }], chart: [{
                type: Input
            }], containerBackgroundColor: [{
                type: Input
            }], dataSource: [{
                type: Input
            }], dataSourceField: [{
                type: Input
            }], disabled: [{
                type: Input
            }], elementAttr: [{
                type: Input
            }], encodeHtml: [{
                type: Input
            }], export: [{
                type: Input
            }], indent: [{
                type: Input
            }], loadingIndicator: [{
                type: Input
            }], margin: [{
                type: Input
            }], pathModified: [{
                type: Input
            }], redrawOnResize: [{
                type: Input
            }], rtlEnabled: [{
                type: Input
            }], scale: [{
                type: Input
            }], selectedRangeColor: [{
                type: Input
            }], selectedRangeUpdateMode: [{
                type: Input
            }], shutter: [{
                type: Input
            }], size: [{
                type: Input
            }], sliderHandle: [{
                type: Input
            }], sliderMarker: [{
                type: Input
            }], theme: [{
                type: Input
            }], title: [{
                type: Input
            }], value: [{
                type: Input
            }], onDisposing: [{
                type: Output
            }], onDrawn: [{
                type: Output
            }], onExported: [{
                type: Output
            }], onExporting: [{
                type: Output
            }], onFileSaving: [{
                type: Output
            }], onIncidentOccurred: [{
                type: Output
            }], onInitialized: [{
                type: Output
            }], onOptionChanged: [{
                type: Output
            }], onValueChanged: [{
                type: Output
            }], backgroundChange: [{
                type: Output
            }], behaviorChange: [{
                type: Output
            }], chartChange: [{
                type: Output
            }], containerBackgroundColorChange: [{
                type: Output
            }], dataSourceChange: [{
                type: Output
            }], dataSourceFieldChange: [{
                type: Output
            }], disabledChange: [{
                type: Output
            }], elementAttrChange: [{
                type: Output
            }], encodeHtmlChange: [{
                type: Output
            }], exportChange: [{
                type: Output
            }], indentChange: [{
                type: Output
            }], loadingIndicatorChange: [{
                type: Output
            }], marginChange: [{
                type: Output
            }], pathModifiedChange: [{
                type: Output
            }], redrawOnResizeChange: [{
                type: Output
            }], rtlEnabledChange: [{
                type: Output
            }], scaleChange: [{
                type: Output
            }], selectedRangeColorChange: [{
                type: Output
            }], selectedRangeUpdateModeChange: [{
                type: Output
            }], shutterChange: [{
                type: Output
            }], sizeChange: [{
                type: Output
            }], sliderHandleChange: [{
                type: Output
            }], sliderMarkerChange: [{
                type: Output
            }], themeChange: [{
                type: Output
            }], titleChange: [{
                type: Output
            }], valueChange: [{
                type: Output
            }], onBlur: [{
                type: Output
            }], change: [{
                type: HostListener,
                args: ['valueChange', ['$event']]
            }], touched: [{
                type: HostListener,
                args: ['onBlur', ['$event']]
            }] } });
class DxRangeSelectorModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxRangeSelectorModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxRangeSelectorModule, imports: [DxRangeSelectorComponent, DxoBackgroundModule,
            DxoImageModule,
            DxoBehaviorModule,
            DxoChartModule,
            DxoCommonSeriesSettingsModule,
            DxoAggregationModule,
            DxoAreaModule,
            DxoBorderModule,
            DxoHoverStyleModule,
            DxoHatchingModule,
            DxoLabelModule,
            DxoConnectorModule,
            DxoPointModule,
            DxoHeightModule,
            DxoUrlModule,
            DxoWidthModule,
            DxoSelectionStyleModule,
            DxoReductionModule,
            DxoValueErrorBarModule,
            DxoBarModule,
            DxoBubbleModule,
            DxoCandlestickModule,
            DxoColorModule,
            DxoFullstackedareaModule,
            DxoFullstackedbarModule,
            DxoFullstackedlineModule,
            DxoFullstackedsplineModule,
            DxoFullstackedsplineareaModule,
            DxoArgumentFormatModule,
            DxoFontModule,
            DxoFormatModule,
            DxoLineModule,
            DxoRangeareaModule,
            DxoRangebarModule,
            DxoScatterModule,
            DxoSplineModule,
            DxoSplineareaModule,
            DxoStackedareaModule,
            DxoStackedbarModule,
            DxoStackedlineModule,
            DxoStackedsplineModule,
            DxoStackedsplineareaModule,
            DxoStepareaModule,
            DxoSteplineModule,
            DxoStockModule,
            DxoDataPrepareSettingsModule,
            DxiSeriesModule,
            DxoSeriesTemplateModule,
            DxoValueAxisModule,
            DxoExportModule,
            DxoIndentModule,
            DxoLoadingIndicatorModule,
            DxoMarginModule,
            DxoScaleModule,
            DxoAggregationIntervalModule,
            DxiBreakModule,
            DxoBreakStyleModule,
            DxoMarkerModule,
            DxoMaxRangeModule,
            DxoMinorTickModule,
            DxoMinorTickIntervalModule,
            DxoMinRangeModule,
            DxoTickModule,
            DxoTickIntervalModule,
            DxoShutterModule,
            DxoSizeModule,
            DxoSliderHandleModule,
            DxoSliderMarkerModule,
            DxoTitleModule,
            DxoSubtitleModule,
            DxoRangeSelectorAggregationModule,
            DxoRangeSelectorAggregationIntervalModule,
            DxoRangeSelectorArgumentFormatModule,
            DxoRangeSelectorBackgroundModule,
            DxoRangeSelectorBackgroundImageModule,
            DxoRangeSelectorBehaviorModule,
            DxoRangeSelectorBorderModule,
            DxiRangeSelectorBreakModule,
            DxoRangeSelectorBreakStyleModule,
            DxoRangeSelectorChartModule,
            DxoRangeSelectorColorModule,
            DxoRangeSelectorCommonSeriesSettingsModule,
            DxoRangeSelectorCommonSeriesSettingsHoverStyleModule,
            DxoRangeSelectorCommonSeriesSettingsLabelModule,
            DxoRangeSelectorCommonSeriesSettingsSelectionStyleModule,
            DxoRangeSelectorConnectorModule,
            DxoRangeSelectorDataPrepareSettingsModule,
            DxoRangeSelectorExportModule,
            DxoRangeSelectorFontModule,
            DxoRangeSelectorFormatModule,
            DxoRangeSelectorHatchingModule,
            DxoRangeSelectorHeightModule,
            DxoRangeSelectorHoverStyleModule,
            DxoRangeSelectorImageModule,
            DxoRangeSelectorIndentModule,
            DxoRangeSelectorLabelModule,
            DxoRangeSelectorLengthModule,
            DxoRangeSelectorLoadingIndicatorModule,
            DxoRangeSelectorMarginModule,
            DxoRangeSelectorMarkerModule,
            DxoRangeSelectorMarkerLabelModule,
            DxoRangeSelectorMaxRangeModule,
            DxoRangeSelectorMinorTickModule,
            DxoRangeSelectorMinorTickIntervalModule,
            DxoRangeSelectorMinRangeModule,
            DxoRangeSelectorPointModule,
            DxoRangeSelectorPointBorderModule,
            DxoRangeSelectorPointHoverStyleModule,
            DxoRangeSelectorPointImageModule,
            DxoRangeSelectorPointSelectionStyleModule,
            DxoRangeSelectorReductionModule,
            DxoRangeSelectorScaleModule,
            DxoRangeSelectorScaleLabelModule,
            DxoRangeSelectorSelectionStyleModule,
            DxiRangeSelectorSeriesModule,
            DxoRangeSelectorSeriesBorderModule,
            DxoRangeSelectorSeriesTemplateModule,
            DxoRangeSelectorShutterModule,
            DxoRangeSelectorSizeModule,
            DxoRangeSelectorSliderHandleModule,
            DxoRangeSelectorSliderMarkerModule,
            DxoRangeSelectorSubtitleModule,
            DxoRangeSelectorTickModule,
            DxoRangeSelectorTickIntervalModule,
            DxoRangeSelectorTitleModule,
            DxoRangeSelectorUrlModule,
            DxoRangeSelectorValueModule,
            DxoRangeSelectorValueAxisModule,
            DxoRangeSelectorValueErrorBarModule,
            DxoRangeSelectorWidthModule,
            DxIntegrationModule,
            DxTemplateModule], exports: [DxRangeSelectorComponent, DxoBackgroundModule,
            DxoImageModule,
            DxoBehaviorModule,
            DxoChartModule,
            DxoCommonSeriesSettingsModule,
            DxoAggregationModule,
            DxoAreaModule,
            DxoBorderModule,
            DxoHoverStyleModule,
            DxoHatchingModule,
            DxoLabelModule,
            DxoConnectorModule,
            DxoPointModule,
            DxoHeightModule,
            DxoUrlModule,
            DxoWidthModule,
            DxoSelectionStyleModule,
            DxoReductionModule,
            DxoValueErrorBarModule,
            DxoBarModule,
            DxoBubbleModule,
            DxoCandlestickModule,
            DxoColorModule,
            DxoFullstackedareaModule,
            DxoFullstackedbarModule,
            DxoFullstackedlineModule,
            DxoFullstackedsplineModule,
            DxoFullstackedsplineareaModule,
            DxoArgumentFormatModule,
            DxoFontModule,
            DxoFormatModule,
            DxoLineModule,
            DxoRangeareaModule,
            DxoRangebarModule,
            DxoScatterModule,
            DxoSplineModule,
            DxoSplineareaModule,
            DxoStackedareaModule,
            DxoStackedbarModule,
            DxoStackedlineModule,
            DxoStackedsplineModule,
            DxoStackedsplineareaModule,
            DxoStepareaModule,
            DxoSteplineModule,
            DxoStockModule,
            DxoDataPrepareSettingsModule,
            DxiSeriesModule,
            DxoSeriesTemplateModule,
            DxoValueAxisModule,
            DxoExportModule,
            DxoIndentModule,
            DxoLoadingIndicatorModule,
            DxoMarginModule,
            DxoScaleModule,
            DxoAggregationIntervalModule,
            DxiBreakModule,
            DxoBreakStyleModule,
            DxoMarkerModule,
            DxoMaxRangeModule,
            DxoMinorTickModule,
            DxoMinorTickIntervalModule,
            DxoMinRangeModule,
            DxoTickModule,
            DxoTickIntervalModule,
            DxoShutterModule,
            DxoSizeModule,
            DxoSliderHandleModule,
            DxoSliderMarkerModule,
            DxoTitleModule,
            DxoSubtitleModule,
            DxoRangeSelectorAggregationModule,
            DxoRangeSelectorAggregationIntervalModule,
            DxoRangeSelectorArgumentFormatModule,
            DxoRangeSelectorBackgroundModule,
            DxoRangeSelectorBackgroundImageModule,
            DxoRangeSelectorBehaviorModule,
            DxoRangeSelectorBorderModule,
            DxiRangeSelectorBreakModule,
            DxoRangeSelectorBreakStyleModule,
            DxoRangeSelectorChartModule,
            DxoRangeSelectorColorModule,
            DxoRangeSelectorCommonSeriesSettingsModule,
            DxoRangeSelectorCommonSeriesSettingsHoverStyleModule,
            DxoRangeSelectorCommonSeriesSettingsLabelModule,
            DxoRangeSelectorCommonSeriesSettingsSelectionStyleModule,
            DxoRangeSelectorConnectorModule,
            DxoRangeSelectorDataPrepareSettingsModule,
            DxoRangeSelectorExportModule,
            DxoRangeSelectorFontModule,
            DxoRangeSelectorFormatModule,
            DxoRangeSelectorHatchingModule,
            DxoRangeSelectorHeightModule,
            DxoRangeSelectorHoverStyleModule,
            DxoRangeSelectorImageModule,
            DxoRangeSelectorIndentModule,
            DxoRangeSelectorLabelModule,
            DxoRangeSelectorLengthModule,
            DxoRangeSelectorLoadingIndicatorModule,
            DxoRangeSelectorMarginModule,
            DxoRangeSelectorMarkerModule,
            DxoRangeSelectorMarkerLabelModule,
            DxoRangeSelectorMaxRangeModule,
            DxoRangeSelectorMinorTickModule,
            DxoRangeSelectorMinorTickIntervalModule,
            DxoRangeSelectorMinRangeModule,
            DxoRangeSelectorPointModule,
            DxoRangeSelectorPointBorderModule,
            DxoRangeSelectorPointHoverStyleModule,
            DxoRangeSelectorPointImageModule,
            DxoRangeSelectorPointSelectionStyleModule,
            DxoRangeSelectorReductionModule,
            DxoRangeSelectorScaleModule,
            DxoRangeSelectorScaleLabelModule,
            DxoRangeSelectorSelectionStyleModule,
            DxiRangeSelectorSeriesModule,
            DxoRangeSelectorSeriesBorderModule,
            DxoRangeSelectorSeriesTemplateModule,
            DxoRangeSelectorShutterModule,
            DxoRangeSelectorSizeModule,
            DxoRangeSelectorSliderHandleModule,
            DxoRangeSelectorSliderMarkerModule,
            DxoRangeSelectorSubtitleModule,
            DxoRangeSelectorTickModule,
            DxoRangeSelectorTickIntervalModule,
            DxoRangeSelectorTitleModule,
            DxoRangeSelectorUrlModule,
            DxoRangeSelectorValueModule,
            DxoRangeSelectorValueAxisModule,
            DxoRangeSelectorValueErrorBarModule,
            DxoRangeSelectorWidthModule,
            DxTemplateModule] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxRangeSelectorModule, imports: [DxRangeSelectorComponent,
            DxoBackgroundModule,
            DxoImageModule,
            DxoBehaviorModule,
            DxoChartModule,
            DxoCommonSeriesSettingsModule,
            DxoAggregationModule,
            DxoAreaModule,
            DxoBorderModule,
            DxoHoverStyleModule,
            DxoHatchingModule,
            DxoLabelModule,
            DxoConnectorModule,
            DxoPointModule,
            DxoHeightModule,
            DxoUrlModule,
            DxoWidthModule,
            DxoSelectionStyleModule,
            DxoReductionModule,
            DxoValueErrorBarModule,
            DxoBarModule,
            DxoBubbleModule,
            DxoCandlestickModule,
            DxoColorModule,
            DxoFullstackedareaModule,
            DxoFullstackedbarModule,
            DxoFullstackedlineModule,
            DxoFullstackedsplineModule,
            DxoFullstackedsplineareaModule,
            DxoArgumentFormatModule,
            DxoFontModule,
            DxoFormatModule,
            DxoLineModule,
            DxoRangeareaModule,
            DxoRangebarModule,
            DxoScatterModule,
            DxoSplineModule,
            DxoSplineareaModule,
            DxoStackedareaModule,
            DxoStackedbarModule,
            DxoStackedlineModule,
            DxoStackedsplineModule,
            DxoStackedsplineareaModule,
            DxoStepareaModule,
            DxoSteplineModule,
            DxoStockModule,
            DxoDataPrepareSettingsModule,
            DxiSeriesModule,
            DxoSeriesTemplateModule,
            DxoValueAxisModule,
            DxoExportModule,
            DxoIndentModule,
            DxoLoadingIndicatorModule,
            DxoMarginModule,
            DxoScaleModule,
            DxoAggregationIntervalModule,
            DxiBreakModule,
            DxoBreakStyleModule,
            DxoMarkerModule,
            DxoMaxRangeModule,
            DxoMinorTickModule,
            DxoMinorTickIntervalModule,
            DxoMinRangeModule,
            DxoTickModule,
            DxoTickIntervalModule,
            DxoShutterModule,
            DxoSizeModule,
            DxoSliderHandleModule,
            DxoSliderMarkerModule,
            DxoTitleModule,
            DxoSubtitleModule,
            DxoRangeSelectorAggregationModule,
            DxoRangeSelectorAggregationIntervalModule,
            DxoRangeSelectorArgumentFormatModule,
            DxoRangeSelectorBackgroundModule,
            DxoRangeSelectorBackgroundImageModule,
            DxoRangeSelectorBehaviorModule,
            DxoRangeSelectorBorderModule,
            DxiRangeSelectorBreakModule,
            DxoRangeSelectorBreakStyleModule,
            DxoRangeSelectorChartModule,
            DxoRangeSelectorColorModule,
            DxoRangeSelectorCommonSeriesSettingsModule,
            DxoRangeSelectorCommonSeriesSettingsHoverStyleModule,
            DxoRangeSelectorCommonSeriesSettingsLabelModule,
            DxoRangeSelectorCommonSeriesSettingsSelectionStyleModule,
            DxoRangeSelectorConnectorModule,
            DxoRangeSelectorDataPrepareSettingsModule,
            DxoRangeSelectorExportModule,
            DxoRangeSelectorFontModule,
            DxoRangeSelectorFormatModule,
            DxoRangeSelectorHatchingModule,
            DxoRangeSelectorHeightModule,
            DxoRangeSelectorHoverStyleModule,
            DxoRangeSelectorImageModule,
            DxoRangeSelectorIndentModule,
            DxoRangeSelectorLabelModule,
            DxoRangeSelectorLengthModule,
            DxoRangeSelectorLoadingIndicatorModule,
            DxoRangeSelectorMarginModule,
            DxoRangeSelectorMarkerModule,
            DxoRangeSelectorMarkerLabelModule,
            DxoRangeSelectorMaxRangeModule,
            DxoRangeSelectorMinorTickModule,
            DxoRangeSelectorMinorTickIntervalModule,
            DxoRangeSelectorMinRangeModule,
            DxoRangeSelectorPointModule,
            DxoRangeSelectorPointBorderModule,
            DxoRangeSelectorPointHoverStyleModule,
            DxoRangeSelectorPointImageModule,
            DxoRangeSelectorPointSelectionStyleModule,
            DxoRangeSelectorReductionModule,
            DxoRangeSelectorScaleModule,
            DxoRangeSelectorScaleLabelModule,
            DxoRangeSelectorSelectionStyleModule,
            DxiRangeSelectorSeriesModule,
            DxoRangeSelectorSeriesBorderModule,
            DxoRangeSelectorSeriesTemplateModule,
            DxoRangeSelectorShutterModule,
            DxoRangeSelectorSizeModule,
            DxoRangeSelectorSliderHandleModule,
            DxoRangeSelectorSliderMarkerModule,
            DxoRangeSelectorSubtitleModule,
            DxoRangeSelectorTickModule,
            DxoRangeSelectorTickIntervalModule,
            DxoRangeSelectorTitleModule,
            DxoRangeSelectorUrlModule,
            DxoRangeSelectorValueModule,
            DxoRangeSelectorValueAxisModule,
            DxoRangeSelectorValueErrorBarModule,
            DxoRangeSelectorWidthModule,
            DxIntegrationModule,
            DxTemplateModule, DxoBackgroundModule,
            DxoImageModule,
            DxoBehaviorModule,
            DxoChartModule,
            DxoCommonSeriesSettingsModule,
            DxoAggregationModule,
            DxoAreaModule,
            DxoBorderModule,
            DxoHoverStyleModule,
            DxoHatchingModule,
            DxoLabelModule,
            DxoConnectorModule,
            DxoPointModule,
            DxoHeightModule,
            DxoUrlModule,
            DxoWidthModule,
            DxoSelectionStyleModule,
            DxoReductionModule,
            DxoValueErrorBarModule,
            DxoBarModule,
            DxoBubbleModule,
            DxoCandlestickModule,
            DxoColorModule,
            DxoFullstackedareaModule,
            DxoFullstackedbarModule,
            DxoFullstackedlineModule,
            DxoFullstackedsplineModule,
            DxoFullstackedsplineareaModule,
            DxoArgumentFormatModule,
            DxoFontModule,
            DxoFormatModule,
            DxoLineModule,
            DxoRangeareaModule,
            DxoRangebarModule,
            DxoScatterModule,
            DxoSplineModule,
            DxoSplineareaModule,
            DxoStackedareaModule,
            DxoStackedbarModule,
            DxoStackedlineModule,
            DxoStackedsplineModule,
            DxoStackedsplineareaModule,
            DxoStepareaModule,
            DxoSteplineModule,
            DxoStockModule,
            DxoDataPrepareSettingsModule,
            DxiSeriesModule,
            DxoSeriesTemplateModule,
            DxoValueAxisModule,
            DxoExportModule,
            DxoIndentModule,
            DxoLoadingIndicatorModule,
            DxoMarginModule,
            DxoScaleModule,
            DxoAggregationIntervalModule,
            DxiBreakModule,
            DxoBreakStyleModule,
            DxoMarkerModule,
            DxoMaxRangeModule,
            DxoMinorTickModule,
            DxoMinorTickIntervalModule,
            DxoMinRangeModule,
            DxoTickModule,
            DxoTickIntervalModule,
            DxoShutterModule,
            DxoSizeModule,
            DxoSliderHandleModule,
            DxoSliderMarkerModule,
            DxoTitleModule,
            DxoSubtitleModule,
            DxoRangeSelectorAggregationModule,
            DxoRangeSelectorAggregationIntervalModule,
            DxoRangeSelectorArgumentFormatModule,
            DxoRangeSelectorBackgroundModule,
            DxoRangeSelectorBackgroundImageModule,
            DxoRangeSelectorBehaviorModule,
            DxoRangeSelectorBorderModule,
            DxiRangeSelectorBreakModule,
            DxoRangeSelectorBreakStyleModule,
            DxoRangeSelectorChartModule,
            DxoRangeSelectorColorModule,
            DxoRangeSelectorCommonSeriesSettingsModule,
            DxoRangeSelectorCommonSeriesSettingsHoverStyleModule,
            DxoRangeSelectorCommonSeriesSettingsLabelModule,
            DxoRangeSelectorCommonSeriesSettingsSelectionStyleModule,
            DxoRangeSelectorConnectorModule,
            DxoRangeSelectorDataPrepareSettingsModule,
            DxoRangeSelectorExportModule,
            DxoRangeSelectorFontModule,
            DxoRangeSelectorFormatModule,
            DxoRangeSelectorHatchingModule,
            DxoRangeSelectorHeightModule,
            DxoRangeSelectorHoverStyleModule,
            DxoRangeSelectorImageModule,
            DxoRangeSelectorIndentModule,
            DxoRangeSelectorLabelModule,
            DxoRangeSelectorLengthModule,
            DxoRangeSelectorLoadingIndicatorModule,
            DxoRangeSelectorMarginModule,
            DxoRangeSelectorMarkerModule,
            DxoRangeSelectorMarkerLabelModule,
            DxoRangeSelectorMaxRangeModule,
            DxoRangeSelectorMinorTickModule,
            DxoRangeSelectorMinorTickIntervalModule,
            DxoRangeSelectorMinRangeModule,
            DxoRangeSelectorPointModule,
            DxoRangeSelectorPointBorderModule,
            DxoRangeSelectorPointHoverStyleModule,
            DxoRangeSelectorPointImageModule,
            DxoRangeSelectorPointSelectionStyleModule,
            DxoRangeSelectorReductionModule,
            DxoRangeSelectorScaleModule,
            DxoRangeSelectorScaleLabelModule,
            DxoRangeSelectorSelectionStyleModule,
            DxiRangeSelectorSeriesModule,
            DxoRangeSelectorSeriesBorderModule,
            DxoRangeSelectorSeriesTemplateModule,
            DxoRangeSelectorShutterModule,
            DxoRangeSelectorSizeModule,
            DxoRangeSelectorSliderHandleModule,
            DxoRangeSelectorSliderMarkerModule,
            DxoRangeSelectorSubtitleModule,
            DxoRangeSelectorTickModule,
            DxoRangeSelectorTickIntervalModule,
            DxoRangeSelectorTitleModule,
            DxoRangeSelectorUrlModule,
            DxoRangeSelectorValueModule,
            DxoRangeSelectorValueAxisModule,
            DxoRangeSelectorValueErrorBarModule,
            DxoRangeSelectorWidthModule,
            DxTemplateModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxRangeSelectorModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxRangeSelectorComponent,
                        DxoBackgroundModule,
                        DxoImageModule,
                        DxoBehaviorModule,
                        DxoChartModule,
                        DxoCommonSeriesSettingsModule,
                        DxoAggregationModule,
                        DxoAreaModule,
                        DxoBorderModule,
                        DxoHoverStyleModule,
                        DxoHatchingModule,
                        DxoLabelModule,
                        DxoConnectorModule,
                        DxoPointModule,
                        DxoHeightModule,
                        DxoUrlModule,
                        DxoWidthModule,
                        DxoSelectionStyleModule,
                        DxoReductionModule,
                        DxoValueErrorBarModule,
                        DxoBarModule,
                        DxoBubbleModule,
                        DxoCandlestickModule,
                        DxoColorModule,
                        DxoFullstackedareaModule,
                        DxoFullstackedbarModule,
                        DxoFullstackedlineModule,
                        DxoFullstackedsplineModule,
                        DxoFullstackedsplineareaModule,
                        DxoArgumentFormatModule,
                        DxoFontModule,
                        DxoFormatModule,
                        DxoLineModule,
                        DxoRangeareaModule,
                        DxoRangebarModule,
                        DxoScatterModule,
                        DxoSplineModule,
                        DxoSplineareaModule,
                        DxoStackedareaModule,
                        DxoStackedbarModule,
                        DxoStackedlineModule,
                        DxoStackedsplineModule,
                        DxoStackedsplineareaModule,
                        DxoStepareaModule,
                        DxoSteplineModule,
                        DxoStockModule,
                        DxoDataPrepareSettingsModule,
                        DxiSeriesModule,
                        DxoSeriesTemplateModule,
                        DxoValueAxisModule,
                        DxoExportModule,
                        DxoIndentModule,
                        DxoLoadingIndicatorModule,
                        DxoMarginModule,
                        DxoScaleModule,
                        DxoAggregationIntervalModule,
                        DxiBreakModule,
                        DxoBreakStyleModule,
                        DxoMarkerModule,
                        DxoMaxRangeModule,
                        DxoMinorTickModule,
                        DxoMinorTickIntervalModule,
                        DxoMinRangeModule,
                        DxoTickModule,
                        DxoTickIntervalModule,
                        DxoShutterModule,
                        DxoSizeModule,
                        DxoSliderHandleModule,
                        DxoSliderMarkerModule,
                        DxoTitleModule,
                        DxoSubtitleModule,
                        DxoRangeSelectorAggregationModule,
                        DxoRangeSelectorAggregationIntervalModule,
                        DxoRangeSelectorArgumentFormatModule,
                        DxoRangeSelectorBackgroundModule,
                        DxoRangeSelectorBackgroundImageModule,
                        DxoRangeSelectorBehaviorModule,
                        DxoRangeSelectorBorderModule,
                        DxiRangeSelectorBreakModule,
                        DxoRangeSelectorBreakStyleModule,
                        DxoRangeSelectorChartModule,
                        DxoRangeSelectorColorModule,
                        DxoRangeSelectorCommonSeriesSettingsModule,
                        DxoRangeSelectorCommonSeriesSettingsHoverStyleModule,
                        DxoRangeSelectorCommonSeriesSettingsLabelModule,
                        DxoRangeSelectorCommonSeriesSettingsSelectionStyleModule,
                        DxoRangeSelectorConnectorModule,
                        DxoRangeSelectorDataPrepareSettingsModule,
                        DxoRangeSelectorExportModule,
                        DxoRangeSelectorFontModule,
                        DxoRangeSelectorFormatModule,
                        DxoRangeSelectorHatchingModule,
                        DxoRangeSelectorHeightModule,
                        DxoRangeSelectorHoverStyleModule,
                        DxoRangeSelectorImageModule,
                        DxoRangeSelectorIndentModule,
                        DxoRangeSelectorLabelModule,
                        DxoRangeSelectorLengthModule,
                        DxoRangeSelectorLoadingIndicatorModule,
                        DxoRangeSelectorMarginModule,
                        DxoRangeSelectorMarkerModule,
                        DxoRangeSelectorMarkerLabelModule,
                        DxoRangeSelectorMaxRangeModule,
                        DxoRangeSelectorMinorTickModule,
                        DxoRangeSelectorMinorTickIntervalModule,
                        DxoRangeSelectorMinRangeModule,
                        DxoRangeSelectorPointModule,
                        DxoRangeSelectorPointBorderModule,
                        DxoRangeSelectorPointHoverStyleModule,
                        DxoRangeSelectorPointImageModule,
                        DxoRangeSelectorPointSelectionStyleModule,
                        DxoRangeSelectorReductionModule,
                        DxoRangeSelectorScaleModule,
                        DxoRangeSelectorScaleLabelModule,
                        DxoRangeSelectorSelectionStyleModule,
                        DxiRangeSelectorSeriesModule,
                        DxoRangeSelectorSeriesBorderModule,
                        DxoRangeSelectorSeriesTemplateModule,
                        DxoRangeSelectorShutterModule,
                        DxoRangeSelectorSizeModule,
                        DxoRangeSelectorSliderHandleModule,
                        DxoRangeSelectorSliderMarkerModule,
                        DxoRangeSelectorSubtitleModule,
                        DxoRangeSelectorTickModule,
                        DxoRangeSelectorTickIntervalModule,
                        DxoRangeSelectorTitleModule,
                        DxoRangeSelectorUrlModule,
                        DxoRangeSelectorValueModule,
                        DxoRangeSelectorValueAxisModule,
                        DxoRangeSelectorValueErrorBarModule,
                        DxoRangeSelectorWidthModule,
                        DxIntegrationModule,
                        DxTemplateModule
                    ],
                    exports: [
                        DxRangeSelectorComponent,
                        DxoBackgroundModule,
                        DxoImageModule,
                        DxoBehaviorModule,
                        DxoChartModule,
                        DxoCommonSeriesSettingsModule,
                        DxoAggregationModule,
                        DxoAreaModule,
                        DxoBorderModule,
                        DxoHoverStyleModule,
                        DxoHatchingModule,
                        DxoLabelModule,
                        DxoConnectorModule,
                        DxoPointModule,
                        DxoHeightModule,
                        DxoUrlModule,
                        DxoWidthModule,
                        DxoSelectionStyleModule,
                        DxoReductionModule,
                        DxoValueErrorBarModule,
                        DxoBarModule,
                        DxoBubbleModule,
                        DxoCandlestickModule,
                        DxoColorModule,
                        DxoFullstackedareaModule,
                        DxoFullstackedbarModule,
                        DxoFullstackedlineModule,
                        DxoFullstackedsplineModule,
                        DxoFullstackedsplineareaModule,
                        DxoArgumentFormatModule,
                        DxoFontModule,
                        DxoFormatModule,
                        DxoLineModule,
                        DxoRangeareaModule,
                        DxoRangebarModule,
                        DxoScatterModule,
                        DxoSplineModule,
                        DxoSplineareaModule,
                        DxoStackedareaModule,
                        DxoStackedbarModule,
                        DxoStackedlineModule,
                        DxoStackedsplineModule,
                        DxoStackedsplineareaModule,
                        DxoStepareaModule,
                        DxoSteplineModule,
                        DxoStockModule,
                        DxoDataPrepareSettingsModule,
                        DxiSeriesModule,
                        DxoSeriesTemplateModule,
                        DxoValueAxisModule,
                        DxoExportModule,
                        DxoIndentModule,
                        DxoLoadingIndicatorModule,
                        DxoMarginModule,
                        DxoScaleModule,
                        DxoAggregationIntervalModule,
                        DxiBreakModule,
                        DxoBreakStyleModule,
                        DxoMarkerModule,
                        DxoMaxRangeModule,
                        DxoMinorTickModule,
                        DxoMinorTickIntervalModule,
                        DxoMinRangeModule,
                        DxoTickModule,
                        DxoTickIntervalModule,
                        DxoShutterModule,
                        DxoSizeModule,
                        DxoSliderHandleModule,
                        DxoSliderMarkerModule,
                        DxoTitleModule,
                        DxoSubtitleModule,
                        DxoRangeSelectorAggregationModule,
                        DxoRangeSelectorAggregationIntervalModule,
                        DxoRangeSelectorArgumentFormatModule,
                        DxoRangeSelectorBackgroundModule,
                        DxoRangeSelectorBackgroundImageModule,
                        DxoRangeSelectorBehaviorModule,
                        DxoRangeSelectorBorderModule,
                        DxiRangeSelectorBreakModule,
                        DxoRangeSelectorBreakStyleModule,
                        DxoRangeSelectorChartModule,
                        DxoRangeSelectorColorModule,
                        DxoRangeSelectorCommonSeriesSettingsModule,
                        DxoRangeSelectorCommonSeriesSettingsHoverStyleModule,
                        DxoRangeSelectorCommonSeriesSettingsLabelModule,
                        DxoRangeSelectorCommonSeriesSettingsSelectionStyleModule,
                        DxoRangeSelectorConnectorModule,
                        DxoRangeSelectorDataPrepareSettingsModule,
                        DxoRangeSelectorExportModule,
                        DxoRangeSelectorFontModule,
                        DxoRangeSelectorFormatModule,
                        DxoRangeSelectorHatchingModule,
                        DxoRangeSelectorHeightModule,
                        DxoRangeSelectorHoverStyleModule,
                        DxoRangeSelectorImageModule,
                        DxoRangeSelectorIndentModule,
                        DxoRangeSelectorLabelModule,
                        DxoRangeSelectorLengthModule,
                        DxoRangeSelectorLoadingIndicatorModule,
                        DxoRangeSelectorMarginModule,
                        DxoRangeSelectorMarkerModule,
                        DxoRangeSelectorMarkerLabelModule,
                        DxoRangeSelectorMaxRangeModule,
                        DxoRangeSelectorMinorTickModule,
                        DxoRangeSelectorMinorTickIntervalModule,
                        DxoRangeSelectorMinRangeModule,
                        DxoRangeSelectorPointModule,
                        DxoRangeSelectorPointBorderModule,
                        DxoRangeSelectorPointHoverStyleModule,
                        DxoRangeSelectorPointImageModule,
                        DxoRangeSelectorPointSelectionStyleModule,
                        DxoRangeSelectorReductionModule,
                        DxoRangeSelectorScaleModule,
                        DxoRangeSelectorScaleLabelModule,
                        DxoRangeSelectorSelectionStyleModule,
                        DxiRangeSelectorSeriesModule,
                        DxoRangeSelectorSeriesBorderModule,
                        DxoRangeSelectorSeriesTemplateModule,
                        DxoRangeSelectorShutterModule,
                        DxoRangeSelectorSizeModule,
                        DxoRangeSelectorSliderHandleModule,
                        DxoRangeSelectorSliderMarkerModule,
                        DxoRangeSelectorSubtitleModule,
                        DxoRangeSelectorTickModule,
                        DxoRangeSelectorTickIntervalModule,
                        DxoRangeSelectorTitleModule,
                        DxoRangeSelectorUrlModule,
                        DxoRangeSelectorValueModule,
                        DxoRangeSelectorValueAxisModule,
                        DxoRangeSelectorValueErrorBarModule,
                        DxoRangeSelectorWidthModule,
                        DxTemplateModule
                    ]
                }]
        }] });

/**
 * Generated bundle index. Do not edit.
 */

export { DxRangeSelectorComponent, DxRangeSelectorModule };
//# sourceMappingURL=devextreme-angular-ui-range-selector.mjs.map
