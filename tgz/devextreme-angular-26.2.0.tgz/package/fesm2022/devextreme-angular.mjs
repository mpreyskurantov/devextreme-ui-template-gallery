import * as AiIntegrationModule from 'devextreme/common/ai-integration';
import { AIIntegration } from 'devextreme/common/ai-integration';
import * as ChartsModule from 'devextreme/common/charts';
import { registerGradient, registerPattern } from 'devextreme/common/charts';
import * as CoreAnimationModule from 'devextreme/common/core/animation';
import { animationPresets, cancelAnimationFrame, fx, requestAnimationFrame, TransitionExecutor } from 'devextreme/common/core/animation';
import * as CoreEnvironmentModule from 'devextreme/common/core/environment';
import { getTimeZones, hideTopOverlay, initMobileViewport } from 'devextreme/common/core/environment';
import * as CoreEventsModule from 'devextreme/common/core/events';
import { off, on, one, trigger } from 'devextreme/common/core/events';
import * as CoreLocalizationModule from 'devextreme/common/core/localization';
import { formatDate, formatMessage, formatNumber, loadMessages, locale, parseDate, parseNumber } from 'devextreme/common/core/localization';
import * as DataModule from 'devextreme/common/data';
import { applyChanges, ArrayStore, base64_encode, compileGetter, compileSetter, CustomStore, DataSource, EdmLiteral, EndpointSelector, errorHandler, isGroupItemsArray, isItemsArray, isLoadResultObject, keyConverters, LocalStore, ODataContext, ODataStore, query, setErrorHandler } from 'devextreme/common/data';
import * as ExportExcelModule from 'devextreme/common/export/excel';
import { exportDataGrid, exportPivotGrid } from 'devextreme/common/export/excel';
import * as ExportPdfModule from 'devextreme/common/export/pdf';
import { exportDataGrid as exportDataGrid$1, exportGantt } from 'devextreme/common/export/pdf';
import { config, Guid, setTemplateEngine } from 'devextreme/common';
import { DxTemplateModule } from 'devextreme-angular/core';
export * from 'devextreme-angular/core';
import * as i0 from '@angular/core';
import { NgModule } from '@angular/core';
import { DxAccordionModule } from 'devextreme-angular/ui/accordion';
export { DxAccordionComponent, DxAccordionModule } from 'devextreme-angular/ui/accordion';
import { DxActionSheetModule } from 'devextreme-angular/ui/action-sheet';
export { DxActionSheetComponent, DxActionSheetModule } from 'devextreme-angular/ui/action-sheet';
import { DxAutocompleteModule } from 'devextreme-angular/ui/autocomplete';
export { DxAutocompleteComponent, DxAutocompleteModule } from 'devextreme-angular/ui/autocomplete';
import { DxBarGaugeModule } from 'devextreme-angular/ui/bar-gauge';
export { DxBarGaugeComponent, DxBarGaugeModule } from 'devextreme-angular/ui/bar-gauge';
import { DxBoxModule } from 'devextreme-angular/ui/box';
export { DxBoxComponent, DxBoxModule } from 'devextreme-angular/ui/box';
import { DxBulletModule } from 'devextreme-angular/ui/bullet';
export { DxBulletComponent, DxBulletModule } from 'devextreme-angular/ui/bullet';
import { DxButtonModule } from 'devextreme-angular/ui/button';
export { DxButtonComponent, DxButtonModule } from 'devextreme-angular/ui/button';
import { DxButtonGroupModule } from 'devextreme-angular/ui/button-group';
export { DxButtonGroupComponent, DxButtonGroupModule } from 'devextreme-angular/ui/button-group';
import { DxCalendarModule } from 'devextreme-angular/ui/calendar';
export { DxCalendarComponent, DxCalendarModule } from 'devextreme-angular/ui/calendar';
import { DxCardViewModule } from 'devextreme-angular/ui/card-view';
export { DxCardViewComponent, DxCardViewModule } from 'devextreme-angular/ui/card-view';
import { DxChartModule } from 'devextreme-angular/ui/chart';
export { DxChartComponent, DxChartModule } from 'devextreme-angular/ui/chart';
import { DxChatModule } from 'devextreme-angular/ui/chat';
export { DxChatComponent, DxChatModule } from 'devextreme-angular/ui/chat';
import { DxCheckBoxModule } from 'devextreme-angular/ui/check-box';
export { DxCheckBoxComponent, DxCheckBoxModule } from 'devextreme-angular/ui/check-box';
import { DxCircularGaugeModule } from 'devextreme-angular/ui/circular-gauge';
export { DxCircularGaugeComponent, DxCircularGaugeModule } from 'devextreme-angular/ui/circular-gauge';
import { DxColorBoxModule } from 'devextreme-angular/ui/color-box';
export { DxColorBoxComponent, DxColorBoxModule } from 'devextreme-angular/ui/color-box';
import { DxContextMenuModule } from 'devextreme-angular/ui/context-menu';
export { DxContextMenuComponent, DxContextMenuModule } from 'devextreme-angular/ui/context-menu';
import { DxDataGridModule } from 'devextreme-angular/ui/data-grid';
export { DxDataGridComponent, DxDataGridModule } from 'devextreme-angular/ui/data-grid';
import { DxDateBoxModule } from 'devextreme-angular/ui/date-box';
export { DxDateBoxComponent, DxDateBoxModule } from 'devextreme-angular/ui/date-box';
import { DxDateRangeBoxModule } from 'devextreme-angular/ui/date-range-box';
export { DxDateRangeBoxComponent, DxDateRangeBoxModule } from 'devextreme-angular/ui/date-range-box';
import { DxDiagramModule } from 'devextreme-angular/ui/diagram';
export { DxDiagramComponent, DxDiagramModule } from 'devextreme-angular/ui/diagram';
import { DxDraggableModule } from 'devextreme-angular/ui/draggable';
export { DxDraggableComponent, DxDraggableModule } from 'devextreme-angular/ui/draggable';
import { DxDrawerModule } from 'devextreme-angular/ui/drawer';
export { DxDrawerComponent, DxDrawerModule } from 'devextreme-angular/ui/drawer';
import { DxDropDownBoxModule } from 'devextreme-angular/ui/drop-down-box';
export { DxDropDownBoxComponent, DxDropDownBoxModule } from 'devextreme-angular/ui/drop-down-box';
import { DxDropDownButtonModule } from 'devextreme-angular/ui/drop-down-button';
export { DxDropDownButtonComponent, DxDropDownButtonModule } from 'devextreme-angular/ui/drop-down-button';
import { DxFileManagerModule } from 'devextreme-angular/ui/file-manager';
export { DxFileManagerComponent, DxFileManagerModule } from 'devextreme-angular/ui/file-manager';
import { DxFileUploaderModule } from 'devextreme-angular/ui/file-uploader';
export { DxFileUploaderComponent, DxFileUploaderModule } from 'devextreme-angular/ui/file-uploader';
import { DxFilterBuilderModule } from 'devextreme-angular/ui/filter-builder';
export { DxFilterBuilderComponent, DxFilterBuilderModule } from 'devextreme-angular/ui/filter-builder';
import { DxFormModule } from 'devextreme-angular/ui/form';
export { DxFormComponent, DxFormModule } from 'devextreme-angular/ui/form';
import { DxFunnelModule } from 'devextreme-angular/ui/funnel';
export { DxFunnelComponent, DxFunnelModule } from 'devextreme-angular/ui/funnel';
import { DxGalleryModule } from 'devextreme-angular/ui/gallery';
export { DxGalleryComponent, DxGalleryModule } from 'devextreme-angular/ui/gallery';
import { DxGanttModule } from 'devextreme-angular/ui/gantt';
export { DxGanttComponent, DxGanttModule } from 'devextreme-angular/ui/gantt';
import { DxHtmlEditorModule } from 'devextreme-angular/ui/html-editor';
export { DxHtmlEditorComponent, DxHtmlEditorModule } from 'devextreme-angular/ui/html-editor';
import { DxLinearGaugeModule } from 'devextreme-angular/ui/linear-gauge';
export { DxLinearGaugeComponent, DxLinearGaugeModule } from 'devextreme-angular/ui/linear-gauge';
import { DxListModule } from 'devextreme-angular/ui/list';
export { DxListComponent, DxListModule } from 'devextreme-angular/ui/list';
import { DxLoadIndicatorModule } from 'devextreme-angular/ui/load-indicator';
export { DxLoadIndicatorComponent, DxLoadIndicatorModule } from 'devextreme-angular/ui/load-indicator';
import { DxLoadPanelModule } from 'devextreme-angular/ui/load-panel';
export { DxLoadPanelComponent, DxLoadPanelModule } from 'devextreme-angular/ui/load-panel';
import { DxLookupModule } from 'devextreme-angular/ui/lookup';
export { DxLookupComponent, DxLookupModule } from 'devextreme-angular/ui/lookup';
import { DxMapModule } from 'devextreme-angular/ui/map';
export { DxMapComponent, DxMapModule } from 'devextreme-angular/ui/map';
import { DxMenuModule } from 'devextreme-angular/ui/menu';
export { DxMenuComponent, DxMenuModule } from 'devextreme-angular/ui/menu';
import { DxMultiViewModule } from 'devextreme-angular/ui/multi-view';
export { DxMultiViewComponent, DxMultiViewModule } from 'devextreme-angular/ui/multi-view';
import { DxNumberBoxModule } from 'devextreme-angular/ui/number-box';
export { DxNumberBoxComponent, DxNumberBoxModule } from 'devextreme-angular/ui/number-box';
import { DxPaginationModule } from 'devextreme-angular/ui/pagination';
export { DxPaginationComponent, DxPaginationModule } from 'devextreme-angular/ui/pagination';
import { DxPieChartModule } from 'devextreme-angular/ui/pie-chart';
export { DxPieChartComponent, DxPieChartModule } from 'devextreme-angular/ui/pie-chart';
import { DxPivotGridModule } from 'devextreme-angular/ui/pivot-grid';
export { DxPivotGridComponent, DxPivotGridModule } from 'devextreme-angular/ui/pivot-grid';
import { DxPivotGridFieldChooserModule } from 'devextreme-angular/ui/pivot-grid-field-chooser';
export { DxPivotGridFieldChooserComponent, DxPivotGridFieldChooserModule } from 'devextreme-angular/ui/pivot-grid-field-chooser';
import { DxPolarChartModule } from 'devextreme-angular/ui/polar-chart';
export { DxPolarChartComponent, DxPolarChartModule } from 'devextreme-angular/ui/polar-chart';
import { DxPopoverModule } from 'devextreme-angular/ui/popover';
export { DxPopoverComponent, DxPopoverModule } from 'devextreme-angular/ui/popover';
import { DxPopupModule } from 'devextreme-angular/ui/popup';
export { DxPopupComponent, DxPopupModule } from 'devextreme-angular/ui/popup';
import { DxProgressBarModule } from 'devextreme-angular/ui/progress-bar';
export { DxProgressBarComponent, DxProgressBarModule } from 'devextreme-angular/ui/progress-bar';
import { DxRadioGroupModule } from 'devextreme-angular/ui/radio-group';
export { DxRadioGroupComponent, DxRadioGroupModule } from 'devextreme-angular/ui/radio-group';
import { DxRangeSelectorModule } from 'devextreme-angular/ui/range-selector';
export { DxRangeSelectorComponent, DxRangeSelectorModule } from 'devextreme-angular/ui/range-selector';
import { DxRangeSliderModule } from 'devextreme-angular/ui/range-slider';
export { DxRangeSliderComponent, DxRangeSliderModule } from 'devextreme-angular/ui/range-slider';
import { DxResizableModule } from 'devextreme-angular/ui/resizable';
export { DxResizableComponent, DxResizableModule } from 'devextreme-angular/ui/resizable';
import { DxResponsiveBoxModule } from 'devextreme-angular/ui/responsive-box';
export { DxResponsiveBoxComponent, DxResponsiveBoxModule } from 'devextreme-angular/ui/responsive-box';
import { DxSankeyModule } from 'devextreme-angular/ui/sankey';
export { DxSankeyComponent, DxSankeyModule } from 'devextreme-angular/ui/sankey';
import { DxSchedulerModule } from 'devextreme-angular/ui/scheduler';
export { DxSchedulerComponent, DxSchedulerModule } from 'devextreme-angular/ui/scheduler';
import { DxScrollViewModule } from 'devextreme-angular/ui/scroll-view';
export { DxScrollViewComponent, DxScrollViewModule } from 'devextreme-angular/ui/scroll-view';
import { DxSelectBoxModule } from 'devextreme-angular/ui/select-box';
export { DxSelectBoxComponent, DxSelectBoxModule } from 'devextreme-angular/ui/select-box';
import { DxSliderModule } from 'devextreme-angular/ui/slider';
export { DxSliderComponent, DxSliderModule } from 'devextreme-angular/ui/slider';
import { DxSortableModule } from 'devextreme-angular/ui/sortable';
export { DxSortableComponent, DxSortableModule } from 'devextreme-angular/ui/sortable';
import { DxSparklineModule } from 'devextreme-angular/ui/sparkline';
export { DxSparklineComponent, DxSparklineModule } from 'devextreme-angular/ui/sparkline';
import { DxSpeechToTextModule } from 'devextreme-angular/ui/speech-to-text';
export { DxSpeechToTextComponent, DxSpeechToTextModule } from 'devextreme-angular/ui/speech-to-text';
import { DxSpeedDialActionModule } from 'devextreme-angular/ui/speed-dial-action';
export { DxSpeedDialActionComponent, DxSpeedDialActionModule } from 'devextreme-angular/ui/speed-dial-action';
import { DxSplitterModule } from 'devextreme-angular/ui/splitter';
export { DxSplitterComponent, DxSplitterModule } from 'devextreme-angular/ui/splitter';
import { DxStepperModule } from 'devextreme-angular/ui/stepper';
export { DxStepperComponent, DxStepperModule } from 'devextreme-angular/ui/stepper';
import { DxSwitchModule } from 'devextreme-angular/ui/switch';
export { DxSwitchComponent, DxSwitchModule } from 'devextreme-angular/ui/switch';
import { DxTabPanelModule } from 'devextreme-angular/ui/tab-panel';
export { DxTabPanelComponent, DxTabPanelModule } from 'devextreme-angular/ui/tab-panel';
import { DxTabsModule } from 'devextreme-angular/ui/tabs';
export { DxTabsComponent, DxTabsModule } from 'devextreme-angular/ui/tabs';
import { DxTagBoxModule } from 'devextreme-angular/ui/tag-box';
export { DxTagBoxComponent, DxTagBoxModule } from 'devextreme-angular/ui/tag-box';
import { DxTextAreaModule } from 'devextreme-angular/ui/text-area';
export { DxTextAreaComponent, DxTextAreaModule } from 'devextreme-angular/ui/text-area';
import { DxTextBoxModule } from 'devextreme-angular/ui/text-box';
export { DxTextBoxComponent, DxTextBoxModule } from 'devextreme-angular/ui/text-box';
import { DxTileViewModule } from 'devextreme-angular/ui/tile-view';
export { DxTileViewComponent, DxTileViewModule } from 'devextreme-angular/ui/tile-view';
import { DxToastModule } from 'devextreme-angular/ui/toast';
export { DxToastComponent, DxToastModule } from 'devextreme-angular/ui/toast';
import { DxToolbarModule } from 'devextreme-angular/ui/toolbar';
export { DxToolbarComponent, DxToolbarModule } from 'devextreme-angular/ui/toolbar';
import { DxTooltipModule } from 'devextreme-angular/ui/tooltip';
export { DxTooltipComponent, DxTooltipModule } from 'devextreme-angular/ui/tooltip';
import { DxTreeListModule } from 'devextreme-angular/ui/tree-list';
export { DxTreeListComponent, DxTreeListModule } from 'devextreme-angular/ui/tree-list';
import { DxTreeMapModule } from 'devextreme-angular/ui/tree-map';
export { DxTreeMapComponent, DxTreeMapModule } from 'devextreme-angular/ui/tree-map';
import { DxTreeViewModule } from 'devextreme-angular/ui/tree-view';
export { DxTreeViewComponent, DxTreeViewModule } from 'devextreme-angular/ui/tree-view';
import { DxValidationGroupModule } from 'devextreme-angular/ui/validation-group';
export { DxValidationGroupComponent, DxValidationGroupModule } from 'devextreme-angular/ui/validation-group';
import { DxValidationSummaryModule } from 'devextreme-angular/ui/validation-summary';
export { DxValidationSummaryComponent, DxValidationSummaryModule } from 'devextreme-angular/ui/validation-summary';
import { DxValidatorModule } from 'devextreme-angular/ui/validator';
export { DxValidatorComponent, DxValidatorModule } from 'devextreme-angular/ui/validator';
import { DxVectorMapModule } from 'devextreme-angular/ui/vector-map';
export { DxVectorMapComponent, DxVectorMapModule } from 'devextreme-angular/ui/vector-map';

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
var AiIntegration;
(function (AiIntegration) {
    AiIntegration.AIIntegration = AiIntegrationModule.AIIntegration;
})(AiIntegration || (AiIntegration = {}));
var Charts;
(function (Charts) {
    Charts.registerGradient = ChartsModule.registerGradient;
    Charts.registerPattern = ChartsModule.registerPattern;
})(Charts || (Charts = {}));
var Core;
(function (Core) {
    let Animation;
    (function (Animation) {
        Animation.animationPresets = CoreAnimationModule.animationPresets;
        Animation.cancelAnimationFrame = CoreAnimationModule.cancelAnimationFrame;
        Animation.fx = CoreAnimationModule.fx;
        Animation.requestAnimationFrame = CoreAnimationModule.requestAnimationFrame;
        Animation.TransitionExecutor = CoreAnimationModule.TransitionExecutor;
    })(Animation = Core.Animation || (Core.Animation = {}));
    let Environment;
    (function (Environment) {
        Environment.getTimeZones = CoreEnvironmentModule.getTimeZones;
        Environment.hideTopOverlay = CoreEnvironmentModule.hideTopOverlay;
        Environment.initMobileViewport = CoreEnvironmentModule.initMobileViewport;
    })(Environment = Core.Environment || (Core.Environment = {}));
    let Events;
    (function (Events) {
        Events.off = CoreEventsModule.off;
        Events.on = CoreEventsModule.on;
        Events.one = CoreEventsModule.one;
        Events.trigger = CoreEventsModule.trigger;
    })(Events = Core.Events || (Core.Events = {}));
    let Localization;
    (function (Localization) {
        Localization.formatDate = CoreLocalizationModule.formatDate;
        Localization.formatMessage = CoreLocalizationModule.formatMessage;
        Localization.formatNumber = CoreLocalizationModule.formatNumber;
        Localization.loadMessages = CoreLocalizationModule.loadMessages;
        Localization.locale = CoreLocalizationModule.locale;
        Localization.parseDate = CoreLocalizationModule.parseDate;
        Localization.parseNumber = CoreLocalizationModule.parseNumber;
    })(Localization = Core.Localization || (Core.Localization = {}));
})(Core || (Core = {}));
var Data;
(function (Data) {
    Data.applyChanges = DataModule.applyChanges;
    Data.ArrayStore = DataModule.ArrayStore;
    Data.base64_encode = DataModule.base64_encode;
    Data.compileGetter = DataModule.compileGetter;
    Data.compileSetter = DataModule.compileSetter;
    Data.CustomStore = DataModule.CustomStore;
    Data.DataSource = DataModule.DataSource;
    Data.EdmLiteral = DataModule.EdmLiteral;
    Data.EndpointSelector = DataModule.EndpointSelector;
    Data.errorHandler = DataModule.errorHandler;
    Data.isGroupItemsArray = DataModule.isGroupItemsArray;
    Data.isItemsArray = DataModule.isItemsArray;
    Data.isLoadResultObject = DataModule.isLoadResultObject;
    Data.keyConverters = DataModule.keyConverters;
    Data.LocalStore = DataModule.LocalStore;
    Data.ODataContext = DataModule.ODataContext;
    Data.ODataStore = DataModule.ODataStore;
    Data.query = DataModule.query;
    Data.setErrorHandler = DataModule.setErrorHandler;
})(Data || (Data = {}));
var Export;
(function (Export) {
    let Excel;
    (function (Excel) {
        Excel.exportDataGrid = ExportExcelModule.exportDataGrid;
        Excel.exportPivotGrid = ExportExcelModule.exportPivotGrid;
    })(Excel = Export.Excel || (Export.Excel = {}));
    let Pdf;
    (function (Pdf) {
        Pdf.exportDataGrid = ExportPdfModule.exportDataGrid;
        Pdf.exportGantt = ExportPdfModule.exportGantt;
    })(Pdf = Export.Pdf || (Export.Pdf = {}));
})(Export || (Export = {}));
function Grids() { }

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
class DevExtremeModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DevExtremeModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DevExtremeModule, imports: [DxAccordionModule,
            DxActionSheetModule,
            DxAutocompleteModule,
            DxBarGaugeModule,
            DxBoxModule,
            DxBulletModule,
            DxButtonModule,
            DxButtonGroupModule,
            DxCalendarModule,
            DxCardViewModule,
            DxChartModule,
            DxChatModule,
            DxCheckBoxModule,
            DxCircularGaugeModule,
            DxColorBoxModule,
            DxContextMenuModule,
            DxDataGridModule,
            DxDateBoxModule,
            DxDateRangeBoxModule,
            DxDiagramModule,
            DxDraggableModule,
            DxDrawerModule,
            DxDropDownBoxModule,
            DxDropDownButtonModule,
            DxFileManagerModule,
            DxFileUploaderModule,
            DxFilterBuilderModule,
            DxFormModule,
            DxFunnelModule,
            DxGalleryModule,
            DxGanttModule,
            DxHtmlEditorModule,
            DxLinearGaugeModule,
            DxListModule,
            DxLoadIndicatorModule,
            DxLoadPanelModule,
            DxLookupModule,
            DxMapModule,
            DxMenuModule,
            DxMultiViewModule,
            DxNumberBoxModule,
            DxPaginationModule,
            DxPieChartModule,
            DxPivotGridModule,
            DxPivotGridFieldChooserModule,
            DxPolarChartModule,
            DxPopoverModule,
            DxPopupModule,
            DxProgressBarModule,
            DxRadioGroupModule,
            DxRangeSelectorModule,
            DxRangeSliderModule,
            DxResizableModule,
            DxResponsiveBoxModule,
            DxSankeyModule,
            DxSchedulerModule,
            DxScrollViewModule,
            DxSelectBoxModule,
            DxSliderModule,
            DxSortableModule,
            DxSparklineModule,
            DxSpeechToTextModule,
            DxSpeedDialActionModule,
            DxSplitterModule,
            DxStepperModule,
            DxSwitchModule,
            DxTabPanelModule,
            DxTabsModule,
            DxTagBoxModule,
            DxTextAreaModule,
            DxTextBoxModule,
            DxTileViewModule,
            DxToastModule,
            DxToolbarModule,
            DxTooltipModule,
            DxTreeListModule,
            DxTreeMapModule,
            DxTreeViewModule,
            DxValidationGroupModule,
            DxValidationSummaryModule,
            DxValidatorModule,
            DxVectorMapModule,
            DxTemplateModule], exports: [DxAccordionModule,
            DxActionSheetModule,
            DxAutocompleteModule,
            DxBarGaugeModule,
            DxBoxModule,
            DxBulletModule,
            DxButtonModule,
            DxButtonGroupModule,
            DxCalendarModule,
            DxCardViewModule,
            DxChartModule,
            DxChatModule,
            DxCheckBoxModule,
            DxCircularGaugeModule,
            DxColorBoxModule,
            DxContextMenuModule,
            DxDataGridModule,
            DxDateBoxModule,
            DxDateRangeBoxModule,
            DxDiagramModule,
            DxDraggableModule,
            DxDrawerModule,
            DxDropDownBoxModule,
            DxDropDownButtonModule,
            DxFileManagerModule,
            DxFileUploaderModule,
            DxFilterBuilderModule,
            DxFormModule,
            DxFunnelModule,
            DxGalleryModule,
            DxGanttModule,
            DxHtmlEditorModule,
            DxLinearGaugeModule,
            DxListModule,
            DxLoadIndicatorModule,
            DxLoadPanelModule,
            DxLookupModule,
            DxMapModule,
            DxMenuModule,
            DxMultiViewModule,
            DxNumberBoxModule,
            DxPaginationModule,
            DxPieChartModule,
            DxPivotGridModule,
            DxPivotGridFieldChooserModule,
            DxPolarChartModule,
            DxPopoverModule,
            DxPopupModule,
            DxProgressBarModule,
            DxRadioGroupModule,
            DxRangeSelectorModule,
            DxRangeSliderModule,
            DxResizableModule,
            DxResponsiveBoxModule,
            DxSankeyModule,
            DxSchedulerModule,
            DxScrollViewModule,
            DxSelectBoxModule,
            DxSliderModule,
            DxSortableModule,
            DxSparklineModule,
            DxSpeechToTextModule,
            DxSpeedDialActionModule,
            DxSplitterModule,
            DxStepperModule,
            DxSwitchModule,
            DxTabPanelModule,
            DxTabsModule,
            DxTagBoxModule,
            DxTextAreaModule,
            DxTextBoxModule,
            DxTileViewModule,
            DxToastModule,
            DxToolbarModule,
            DxTooltipModule,
            DxTreeListModule,
            DxTreeMapModule,
            DxTreeViewModule,
            DxValidationGroupModule,
            DxValidationSummaryModule,
            DxValidatorModule,
            DxVectorMapModule,
            DxTemplateModule] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DevExtremeModule, imports: [DxAccordionModule,
            DxActionSheetModule,
            DxAutocompleteModule,
            DxBarGaugeModule,
            DxBoxModule,
            DxBulletModule,
            DxButtonModule,
            DxButtonGroupModule,
            DxCalendarModule,
            DxCardViewModule,
            DxChartModule,
            DxChatModule,
            DxCheckBoxModule,
            DxCircularGaugeModule,
            DxColorBoxModule,
            DxContextMenuModule,
            DxDataGridModule,
            DxDateBoxModule,
            DxDateRangeBoxModule,
            DxDiagramModule,
            DxDraggableModule,
            DxDrawerModule,
            DxDropDownBoxModule,
            DxDropDownButtonModule,
            DxFileManagerModule,
            DxFileUploaderModule,
            DxFilterBuilderModule,
            DxFormModule,
            DxFunnelModule,
            DxGalleryModule,
            DxGanttModule,
            DxHtmlEditorModule,
            DxLinearGaugeModule,
            DxListModule,
            DxLoadIndicatorModule,
            DxLoadPanelModule,
            DxLookupModule,
            DxMapModule,
            DxMenuModule,
            DxMultiViewModule,
            DxNumberBoxModule,
            DxPaginationModule,
            DxPieChartModule,
            DxPivotGridModule,
            DxPivotGridFieldChooserModule,
            DxPolarChartModule,
            DxPopoverModule,
            DxPopupModule,
            DxProgressBarModule,
            DxRadioGroupModule,
            DxRangeSelectorModule,
            DxRangeSliderModule,
            DxResizableModule,
            DxResponsiveBoxModule,
            DxSankeyModule,
            DxSchedulerModule,
            DxScrollViewModule,
            DxSelectBoxModule,
            DxSliderModule,
            DxSortableModule,
            DxSparklineModule,
            DxSpeechToTextModule,
            DxSpeedDialActionModule,
            DxSplitterModule,
            DxStepperModule,
            DxSwitchModule,
            DxTabPanelModule,
            DxTabsModule,
            DxTagBoxModule,
            DxTextAreaModule,
            DxTextBoxModule,
            DxTileViewModule,
            DxToastModule,
            DxToolbarModule,
            DxTooltipModule,
            DxTreeListModule,
            DxTreeMapModule,
            DxTreeViewModule,
            DxValidationGroupModule,
            DxValidationSummaryModule,
            DxValidatorModule,
            DxVectorMapModule,
            DxTemplateModule, DxAccordionModule,
            DxActionSheetModule,
            DxAutocompleteModule,
            DxBarGaugeModule,
            DxBoxModule,
            DxBulletModule,
            DxButtonModule,
            DxButtonGroupModule,
            DxCalendarModule,
            DxCardViewModule,
            DxChartModule,
            DxChatModule,
            DxCheckBoxModule,
            DxCircularGaugeModule,
            DxColorBoxModule,
            DxContextMenuModule,
            DxDataGridModule,
            DxDateBoxModule,
            DxDateRangeBoxModule,
            DxDiagramModule,
            DxDraggableModule,
            DxDrawerModule,
            DxDropDownBoxModule,
            DxDropDownButtonModule,
            DxFileManagerModule,
            DxFileUploaderModule,
            DxFilterBuilderModule,
            DxFormModule,
            DxFunnelModule,
            DxGalleryModule,
            DxGanttModule,
            DxHtmlEditorModule,
            DxLinearGaugeModule,
            DxListModule,
            DxLoadIndicatorModule,
            DxLoadPanelModule,
            DxLookupModule,
            DxMapModule,
            DxMenuModule,
            DxMultiViewModule,
            DxNumberBoxModule,
            DxPaginationModule,
            DxPieChartModule,
            DxPivotGridModule,
            DxPivotGridFieldChooserModule,
            DxPolarChartModule,
            DxPopoverModule,
            DxPopupModule,
            DxProgressBarModule,
            DxRadioGroupModule,
            DxRangeSelectorModule,
            DxRangeSliderModule,
            DxResizableModule,
            DxResponsiveBoxModule,
            DxSankeyModule,
            DxSchedulerModule,
            DxScrollViewModule,
            DxSelectBoxModule,
            DxSliderModule,
            DxSortableModule,
            DxSparklineModule,
            DxSpeechToTextModule,
            DxSpeedDialActionModule,
            DxSplitterModule,
            DxStepperModule,
            DxSwitchModule,
            DxTabPanelModule,
            DxTabsModule,
            DxTagBoxModule,
            DxTextAreaModule,
            DxTextBoxModule,
            DxTileViewModule,
            DxToastModule,
            DxToolbarModule,
            DxTooltipModule,
            DxTreeListModule,
            DxTreeMapModule,
            DxTreeViewModule,
            DxValidationGroupModule,
            DxValidationSummaryModule,
            DxValidatorModule,
            DxVectorMapModule,
            DxTemplateModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DevExtremeModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxAccordionModule,
                        DxActionSheetModule,
                        DxAutocompleteModule,
                        DxBarGaugeModule,
                        DxBoxModule,
                        DxBulletModule,
                        DxButtonModule,
                        DxButtonGroupModule,
                        DxCalendarModule,
                        DxCardViewModule,
                        DxChartModule,
                        DxChatModule,
                        DxCheckBoxModule,
                        DxCircularGaugeModule,
                        DxColorBoxModule,
                        DxContextMenuModule,
                        DxDataGridModule,
                        DxDateBoxModule,
                        DxDateRangeBoxModule,
                        DxDiagramModule,
                        DxDraggableModule,
                        DxDrawerModule,
                        DxDropDownBoxModule,
                        DxDropDownButtonModule,
                        DxFileManagerModule,
                        DxFileUploaderModule,
                        DxFilterBuilderModule,
                        DxFormModule,
                        DxFunnelModule,
                        DxGalleryModule,
                        DxGanttModule,
                        DxHtmlEditorModule,
                        DxLinearGaugeModule,
                        DxListModule,
                        DxLoadIndicatorModule,
                        DxLoadPanelModule,
                        DxLookupModule,
                        DxMapModule,
                        DxMenuModule,
                        DxMultiViewModule,
                        DxNumberBoxModule,
                        DxPaginationModule,
                        DxPieChartModule,
                        DxPivotGridModule,
                        DxPivotGridFieldChooserModule,
                        DxPolarChartModule,
                        DxPopoverModule,
                        DxPopupModule,
                        DxProgressBarModule,
                        DxRadioGroupModule,
                        DxRangeSelectorModule,
                        DxRangeSliderModule,
                        DxResizableModule,
                        DxResponsiveBoxModule,
                        DxSankeyModule,
                        DxSchedulerModule,
                        DxScrollViewModule,
                        DxSelectBoxModule,
                        DxSliderModule,
                        DxSortableModule,
                        DxSparklineModule,
                        DxSpeechToTextModule,
                        DxSpeedDialActionModule,
                        DxSplitterModule,
                        DxStepperModule,
                        DxSwitchModule,
                        DxTabPanelModule,
                        DxTabsModule,
                        DxTagBoxModule,
                        DxTextAreaModule,
                        DxTextBoxModule,
                        DxTileViewModule,
                        DxToastModule,
                        DxToolbarModule,
                        DxTooltipModule,
                        DxTreeListModule,
                        DxTreeMapModule,
                        DxTreeViewModule,
                        DxValidationGroupModule,
                        DxValidationSummaryModule,
                        DxValidatorModule,
                        DxVectorMapModule,
                        DxTemplateModule
                    ],
                    exports: [
                        DxAccordionModule,
                        DxActionSheetModule,
                        DxAutocompleteModule,
                        DxBarGaugeModule,
                        DxBoxModule,
                        DxBulletModule,
                        DxButtonModule,
                        DxButtonGroupModule,
                        DxCalendarModule,
                        DxCardViewModule,
                        DxChartModule,
                        DxChatModule,
                        DxCheckBoxModule,
                        DxCircularGaugeModule,
                        DxColorBoxModule,
                        DxContextMenuModule,
                        DxDataGridModule,
                        DxDateBoxModule,
                        DxDateRangeBoxModule,
                        DxDiagramModule,
                        DxDraggableModule,
                        DxDrawerModule,
                        DxDropDownBoxModule,
                        DxDropDownButtonModule,
                        DxFileManagerModule,
                        DxFileUploaderModule,
                        DxFilterBuilderModule,
                        DxFormModule,
                        DxFunnelModule,
                        DxGalleryModule,
                        DxGanttModule,
                        DxHtmlEditorModule,
                        DxLinearGaugeModule,
                        DxListModule,
                        DxLoadIndicatorModule,
                        DxLoadPanelModule,
                        DxLookupModule,
                        DxMapModule,
                        DxMenuModule,
                        DxMultiViewModule,
                        DxNumberBoxModule,
                        DxPaginationModule,
                        DxPieChartModule,
                        DxPivotGridModule,
                        DxPivotGridFieldChooserModule,
                        DxPolarChartModule,
                        DxPopoverModule,
                        DxPopupModule,
                        DxProgressBarModule,
                        DxRadioGroupModule,
                        DxRangeSelectorModule,
                        DxRangeSliderModule,
                        DxResizableModule,
                        DxResponsiveBoxModule,
                        DxSankeyModule,
                        DxSchedulerModule,
                        DxScrollViewModule,
                        DxSelectBoxModule,
                        DxSliderModule,
                        DxSortableModule,
                        DxSparklineModule,
                        DxSpeechToTextModule,
                        DxSpeedDialActionModule,
                        DxSplitterModule,
                        DxStepperModule,
                        DxSwitchModule,
                        DxTabPanelModule,
                        DxTabsModule,
                        DxTagBoxModule,
                        DxTextAreaModule,
                        DxTextBoxModule,
                        DxTileViewModule,
                        DxToastModule,
                        DxToolbarModule,
                        DxTooltipModule,
                        DxTreeListModule,
                        DxTreeMapModule,
                        DxTreeViewModule,
                        DxValidationGroupModule,
                        DxValidationSummaryModule,
                        DxValidatorModule,
                        DxVectorMapModule,
                        DxTemplateModule
                    ]
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
var Common;
(function (Common) {
    Common.config = config;
    Common.Guid = Guid;
    Common.setTemplateEngine = setTemplateEngine;
    let AiIntegration;
    (function (AiIntegration) {
        AiIntegration.AIIntegration = AIIntegration;
    })(AiIntegration = Common.AiIntegration || (Common.AiIntegration = {}));
    let Charts;
    (function (Charts) {
        Charts.registerGradient = registerGradient;
        Charts.registerPattern = registerPattern;
    })(Charts = Common.Charts || (Common.Charts = {}));
    let Core;
    (function (Core) {
        let Animation;
        (function (Animation) {
            Animation.animationPresets = animationPresets;
            Animation.cancelAnimationFrame = cancelAnimationFrame;
            Animation.fx = fx;
            Animation.requestAnimationFrame = requestAnimationFrame;
            Animation.TransitionExecutor = TransitionExecutor;
        })(Animation = Core.Animation || (Core.Animation = {}));
        let Environment;
        (function (Environment) {
            Environment.getTimeZones = getTimeZones;
            Environment.hideTopOverlay = hideTopOverlay;
            Environment.initMobileViewport = initMobileViewport;
        })(Environment = Core.Environment || (Core.Environment = {}));
        let Events;
        (function (Events) {
            Events.off = off;
            Events.on = on;
            Events.one = one;
            Events.trigger = trigger;
        })(Events = Core.Events || (Core.Events = {}));
        let Localization;
        (function (Localization) {
            Localization.formatDate = formatDate;
            Localization.formatMessage = formatMessage;
            Localization.formatNumber = formatNumber;
            Localization.loadMessages = loadMessages;
            Localization.locale = locale;
            Localization.parseDate = parseDate;
            Localization.parseNumber = parseNumber;
        })(Localization = Core.Localization || (Core.Localization = {}));
    })(Core = Common.Core || (Common.Core = {}));
    let Data;
    (function (Data) {
        Data.applyChanges = applyChanges;
        Data.ArrayStore = ArrayStore;
        Data.base64_encode = base64_encode;
        Data.compileGetter = compileGetter;
        Data.compileSetter = compileSetter;
        Data.CustomStore = CustomStore;
        Data.DataSource = DataSource;
        Data.EdmLiteral = EdmLiteral;
        Data.EndpointSelector = EndpointSelector;
        Data.errorHandler = errorHandler;
        Data.isGroupItemsArray = isGroupItemsArray;
        Data.isItemsArray = isItemsArray;
        Data.isLoadResultObject = isLoadResultObject;
        Data.keyConverters = keyConverters;
        Data.LocalStore = LocalStore;
        Data.ODataContext = ODataContext;
        Data.ODataStore = ODataStore;
        Data.query = query;
        Data.setErrorHandler = setErrorHandler;
    })(Data = Common.Data || (Common.Data = {}));
    let Export;
    (function (Export) {
        let Excel;
        (function (Excel) {
            Excel.exportDataGrid = exportDataGrid;
            Excel.exportPivotGrid = exportPivotGrid;
        })(Excel = Export.Excel || (Export.Excel = {}));
        let Pdf;
        (function (Pdf) {
            Pdf.exportDataGrid = exportDataGrid$1;
            Pdf.exportGantt = exportGantt;
        })(Pdf = Export.Pdf || (Export.Pdf = {}));
    })(Export = Common.Export || (Common.Export = {}));
    function Grids() { }
    Common.Grids = Grids;
})(Common || (Common = {}));

/**
 * Generated bundle index. Do not edit.
 */

export { Common, DevExtremeModule };
//# sourceMappingURL=devextreme-angular.mjs.map
