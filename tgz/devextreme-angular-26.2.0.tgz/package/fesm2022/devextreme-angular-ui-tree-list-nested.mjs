import * as i0 from '@angular/core';
import { Input, SkipSelf, Host, Component, NgModule, Inject, Output, ContentChildren } from '@angular/core';
import * as i1 from 'devextreme-angular/core';
import { NestedOption, DxIntegrationModule, NestedOptionHost, CollectionNestedOption, extractTemplate, DxTemplateHost } from 'devextreme-angular/core';
import { PROPERTY_TOKEN_validationRules, PROPERTY_TOKEN_buttons, PROPERTY_TOKEN_items, PROPERTY_TOKEN_changes, PROPERTY_TOKEN_columns, PROPERTY_TOKEN_customOperations, PROPERTY_TOKEN_fields, PROPERTY_TOKEN_toolbarItems, PROPERTY_TOKEN_tabs } from 'devextreme-angular/core/tokens';
import { DOCUMENT } from '@angular/common';

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoTreeListAIAssistantComponent extends NestedOption {
    get aiIntegration() {
        return this._getOption('aiIntegration');
    }
    set aiIntegration(value) {
        this._setOption('aiIntegration', value);
    }
    get chat() {
        return this._getOption('chat');
    }
    set chat(value) {
        this._setOption('chat', value);
    }
    get customizeResponseText() {
        return this._getOption('customizeResponseText');
    }
    set customizeResponseText(value) {
        this._setOption('customizeResponseText', value);
    }
    get customizeResponseTitle() {
        return this._getOption('customizeResponseTitle');
    }
    set customizeResponseTitle(value) {
        this._setOption('customizeResponseTitle', value);
    }
    get enabled() {
        return this._getOption('enabled');
    }
    set enabled(value) {
        this._setOption('enabled', value);
    }
    get popup() {
        return this._getOption('popup');
    }
    set popup(value) {
        this._setOption('popup', value);
    }
    get title() {
        return this._getOption('title');
    }
    set title(value) {
        this._setOption('title', value);
    }
    get _optionPath() {
        return 'aiAssistant';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListAIAssistantComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoTreeListAIAssistantComponent, isStandalone: true, selector: "dxo-tree-list-ai-assistant", inputs: { aiIntegration: "aiIntegration", chat: "chat", customizeResponseText: "customizeResponseText", customizeResponseTitle: "customizeResponseTitle", enabled: "enabled", popup: "popup", title: "title" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListAIAssistantComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-tree-list-ai-assistant', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { aiIntegration: [{
                type: Input
            }], chat: [{
                type: Input
            }], customizeResponseText: [{
                type: Input
            }], customizeResponseTitle: [{
                type: Input
            }], enabled: [{
                type: Input
            }], popup: [{
                type: Input
            }], title: [{
                type: Input
            }] } });
class DxoTreeListAIAssistantModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListAIAssistantModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListAIAssistantModule, imports: [DxoTreeListAIAssistantComponent], exports: [DxoTreeListAIAssistantComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListAIAssistantModule, imports: [DxoTreeListAIAssistantComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListAIAssistantModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoTreeListAIAssistantComponent
                    ],
                    exports: [
                        DxoTreeListAIAssistantComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoTreeListAIOptionsComponent extends NestedOption {
    get disabled() {
        return this._getOption('disabled');
    }
    set disabled(value) {
        this._setOption('disabled', value);
    }
    get instruction() {
        return this._getOption('instruction');
    }
    set instruction(value) {
        this._setOption('instruction', value);
    }
    get _optionPath() {
        return 'aiOptions';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListAIOptionsComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoTreeListAIOptionsComponent, isStandalone: true, selector: "dxo-tree-list-ai-options", inputs: { disabled: "disabled", instruction: "instruction" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListAIOptionsComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-tree-list-ai-options', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { disabled: [{
                type: Input
            }], instruction: [{
                type: Input
            }] } });
class DxoTreeListAIOptionsModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListAIOptionsModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListAIOptionsModule, imports: [DxoTreeListAIOptionsComponent], exports: [DxoTreeListAIOptionsComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListAIOptionsModule, imports: [DxoTreeListAIOptionsComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListAIOptionsModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoTreeListAIOptionsComponent
                    ],
                    exports: [
                        DxoTreeListAIOptionsComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoTreeListAIComponent extends NestedOption {
    get aiIntegration() {
        return this._getOption('aiIntegration');
    }
    set aiIntegration(value) {
        this._setOption('aiIntegration', value);
    }
    get editorOptions() {
        return this._getOption('editorOptions');
    }
    set editorOptions(value) {
        this._setOption('editorOptions', value);
    }
    get emptyText() {
        return this._getOption('emptyText');
    }
    set emptyText(value) {
        this._setOption('emptyText', value);
    }
    get mode() {
        return this._getOption('mode');
    }
    set mode(value) {
        this._setOption('mode', value);
    }
    get noDataText() {
        return this._getOption('noDataText');
    }
    set noDataText(value) {
        this._setOption('noDataText', value);
    }
    get popup() {
        return this._getOption('popup');
    }
    set popup(value) {
        this._setOption('popup', value);
    }
    get prompt() {
        return this._getOption('prompt');
    }
    set prompt(value) {
        this._setOption('prompt', value);
    }
    get showHeaderMenu() {
        return this._getOption('showHeaderMenu');
    }
    set showHeaderMenu(value) {
        this._setOption('showHeaderMenu', value);
    }
    get _optionPath() {
        return 'ai';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListAIComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoTreeListAIComponent, isStandalone: true, selector: "dxo-tree-list-ai", inputs: { aiIntegration: "aiIntegration", editorOptions: "editorOptions", emptyText: "emptyText", mode: "mode", noDataText: "noDataText", popup: "popup", prompt: "prompt", showHeaderMenu: "showHeaderMenu" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListAIComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-tree-list-ai', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { aiIntegration: [{
                type: Input
            }], editorOptions: [{
                type: Input
            }], emptyText: [{
                type: Input
            }], mode: [{
                type: Input
            }], noDataText: [{
                type: Input
            }], popup: [{
                type: Input
            }], prompt: [{
                type: Input
            }], showHeaderMenu: [{
                type: Input
            }] } });
class DxoTreeListAIModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListAIModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListAIModule, imports: [DxoTreeListAIComponent], exports: [DxoTreeListAIComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListAIModule, imports: [DxoTreeListAIComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListAIModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoTreeListAIComponent
                    ],
                    exports: [
                        DxoTreeListAIComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoTreeListAnimationComponent extends NestedOption {
    get hide() {
        return this._getOption('hide');
    }
    set hide(value) {
        this._setOption('hide', value);
    }
    get show() {
        return this._getOption('show');
    }
    set show(value) {
        this._setOption('show', value);
    }
    get _optionPath() {
        return 'animation';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListAnimationComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoTreeListAnimationComponent, isStandalone: true, selector: "dxo-tree-list-animation", inputs: { hide: "hide", show: "show" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListAnimationComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-tree-list-animation', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { hide: [{
                type: Input
            }], show: [{
                type: Input
            }] } });
class DxoTreeListAnimationModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListAnimationModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListAnimationModule, imports: [DxoTreeListAnimationComponent], exports: [DxoTreeListAnimationComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListAnimationModule, imports: [DxoTreeListAnimationComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListAnimationModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoTreeListAnimationComponent
                    ],
                    exports: [
                        DxoTreeListAnimationComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxiTreeListAsyncRuleComponent extends CollectionNestedOption {
    get ignoreEmptyValue() {
        return this._getOption('ignoreEmptyValue');
    }
    set ignoreEmptyValue(value) {
        this._setOption('ignoreEmptyValue', value);
    }
    get message() {
        return this._getOption('message');
    }
    set message(value) {
        this._setOption('message', value);
    }
    get reevaluate() {
        return this._getOption('reevaluate');
    }
    set reevaluate(value) {
        this._setOption('reevaluate', value);
    }
    get type() {
        return this._getOption('type');
    }
    set type(value) {
        this._setOption('type', value);
    }
    get validationCallback() {
        return this._getOption('validationCallback');
    }
    set validationCallback(value) {
        this._setOption('validationCallback', value);
    }
    get _optionPath() {
        return 'validationRules';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
        this.type = 'async';
    }
    ngOnDestroy() {
        this._deleteRemovedOptions(this._fullOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiTreeListAsyncRuleComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxiTreeListAsyncRuleComponent, isStandalone: true, selector: "dxi-tree-list-async-rule", inputs: { ignoreEmptyValue: "ignoreEmptyValue", message: "message", reevaluate: "reevaluate", type: "type", validationCallback: "validationCallback" }, providers: [
            NestedOptionHost,
            {
                provide: PROPERTY_TOKEN_validationRules,
                useExisting: DxiTreeListAsyncRuleComponent,
            }
        ], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiTreeListAsyncRuleComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxi-tree-list-async-rule', template: '', imports: [DxIntegrationModule], providers: [
                        NestedOptionHost,
                        {
                            provide: PROPERTY_TOKEN_validationRules,
                            useExisting: DxiTreeListAsyncRuleComponent,
                        }
                    ] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { ignoreEmptyValue: [{
                type: Input
            }], message: [{
                type: Input
            }], reevaluate: [{
                type: Input
            }], type: [{
                type: Input
            }], validationCallback: [{
                type: Input
            }] } });
class DxiTreeListAsyncRuleModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiTreeListAsyncRuleModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxiTreeListAsyncRuleModule, imports: [DxiTreeListAsyncRuleComponent], exports: [DxiTreeListAsyncRuleComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiTreeListAsyncRuleModule, imports: [DxiTreeListAsyncRuleComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiTreeListAsyncRuleModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxiTreeListAsyncRuleComponent
                    ],
                    exports: [
                        DxiTreeListAsyncRuleComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoTreeListAtComponent extends NestedOption {
    get x() {
        return this._getOption('x');
    }
    set x(value) {
        this._setOption('x', value);
    }
    get y() {
        return this._getOption('y');
    }
    set y(value) {
        this._setOption('y', value);
    }
    get _optionPath() {
        return 'at';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListAtComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoTreeListAtComponent, isStandalone: true, selector: "dxo-tree-list-at", inputs: { x: "x", y: "y" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListAtComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-tree-list-at', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { x: [{
                type: Input
            }], y: [{
                type: Input
            }] } });
class DxoTreeListAtModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListAtModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListAtModule, imports: [DxoTreeListAtComponent], exports: [DxoTreeListAtComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListAtModule, imports: [DxoTreeListAtComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListAtModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoTreeListAtComponent
                    ],
                    exports: [
                        DxoTreeListAtComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoTreeListBoundaryOffsetComponent extends NestedOption {
    get x() {
        return this._getOption('x');
    }
    set x(value) {
        this._setOption('x', value);
    }
    get y() {
        return this._getOption('y');
    }
    set y(value) {
        this._setOption('y', value);
    }
    get _optionPath() {
        return 'boundaryOffset';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListBoundaryOffsetComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoTreeListBoundaryOffsetComponent, isStandalone: true, selector: "dxo-tree-list-boundary-offset", inputs: { x: "x", y: "y" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListBoundaryOffsetComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-tree-list-boundary-offset', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { x: [{
                type: Input
            }], y: [{
                type: Input
            }] } });
class DxoTreeListBoundaryOffsetModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListBoundaryOffsetModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListBoundaryOffsetModule, imports: [DxoTreeListBoundaryOffsetComponent], exports: [DxoTreeListBoundaryOffsetComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListBoundaryOffsetModule, imports: [DxoTreeListBoundaryOffsetComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListBoundaryOffsetModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoTreeListBoundaryOffsetComponent
                    ],
                    exports: [
                        DxoTreeListBoundaryOffsetComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxiTreeListButtonComponent extends CollectionNestedOption {
    get cssClass() {
        return this._getOption('cssClass');
    }
    set cssClass(value) {
        this._setOption('cssClass', value);
    }
    get disabled() {
        return this._getOption('disabled');
    }
    set disabled(value) {
        this._setOption('disabled', value);
    }
    get hint() {
        return this._getOption('hint');
    }
    set hint(value) {
        this._setOption('hint', value);
    }
    get icon() {
        return this._getOption('icon');
    }
    set icon(value) {
        this._setOption('icon', value);
    }
    get name() {
        return this._getOption('name');
    }
    set name(value) {
        this._setOption('name', value);
    }
    get onClick() {
        return this._getOption('onClick');
    }
    set onClick(value) {
        this._setOption('onClick', value);
    }
    get template() {
        return this._getOption('template');
    }
    set template(value) {
        this._setOption('template', value);
    }
    get text() {
        return this._getOption('text');
    }
    set text(value) {
        this._setOption('text', value);
    }
    get visible() {
        return this._getOption('visible');
    }
    set visible(value) {
        this._setOption('visible', value);
    }
    get location() {
        return this._getOption('location');
    }
    set location(value) {
        this._setOption('location', value);
    }
    get options() {
        return this._getOption('options');
    }
    set options(value) {
        this._setOption('options', value);
    }
    get _optionPath() {
        return 'buttons';
    }
    constructor(parentOptionHost, optionHost, renderer, document, templateHost, element) {
        super();
        this.renderer = renderer;
        this.document = document;
        this.element = element;
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
        templateHost.setHost(this);
    }
    setTemplate(template) {
        this.template = template;
    }
    ngAfterViewInit() {
        extractTemplate(this, this.element, this.renderer, this.document);
    }
    ngOnDestroy() {
        this._deleteRemovedOptions(this._fullOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiTreeListButtonComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }, { token: i0.Renderer2 }, { token: DOCUMENT }, { token: i1.DxTemplateHost, host: true }, { token: i0.ElementRef }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxiTreeListButtonComponent, isStandalone: true, selector: "dxi-tree-list-button", inputs: { cssClass: "cssClass", disabled: "disabled", hint: "hint", icon: "icon", name: "name", onClick: "onClick", template: "template", text: "text", visible: "visible", location: "location", options: "options" }, providers: [
            NestedOptionHost,
            DxTemplateHost,
            {
                provide: PROPERTY_TOKEN_buttons,
                useExisting: DxiTreeListButtonComponent,
            }
        ], usesInheritance: true, ngImport: i0, template: '<ng-content></ng-content>', isInline: true, styles: [":host{display:block}\n"], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiTreeListButtonComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxi-tree-list-button', template: '<ng-content></ng-content>', imports: [DxIntegrationModule], providers: [
                        NestedOptionHost,
                        DxTemplateHost,
                        {
                            provide: PROPERTY_TOKEN_buttons,
                            useExisting: DxiTreeListButtonComponent,
                        }
                    ], styles: [":host{display:block}\n"] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }, { type: i0.Renderer2 }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [DOCUMENT]
                }] }, { type: i1.DxTemplateHost, decorators: [{
                    type: Host
                }] }, { type: i0.ElementRef }], propDecorators: { cssClass: [{
                type: Input
            }], disabled: [{
                type: Input
            }], hint: [{
                type: Input
            }], icon: [{
                type: Input
            }], name: [{
                type: Input
            }], onClick: [{
                type: Input
            }], template: [{
                type: Input
            }], text: [{
                type: Input
            }], visible: [{
                type: Input
            }], location: [{
                type: Input
            }], options: [{
                type: Input
            }] } });
class DxiTreeListButtonModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiTreeListButtonModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxiTreeListButtonModule, imports: [DxiTreeListButtonComponent], exports: [DxiTreeListButtonComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiTreeListButtonModule, imports: [DxiTreeListButtonComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiTreeListButtonModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxiTreeListButtonComponent
                    ],
                    exports: [
                        DxiTreeListButtonComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxiTreeListButtonItemComponent extends CollectionNestedOption {
    get buttonOptions() {
        return this._getOption('buttonOptions');
    }
    set buttonOptions(value) {
        this._setOption('buttonOptions', value);
    }
    get colSpan() {
        return this._getOption('colSpan');
    }
    set colSpan(value) {
        this._setOption('colSpan', value);
    }
    get cssClass() {
        return this._getOption('cssClass');
    }
    set cssClass(value) {
        this._setOption('cssClass', value);
    }
    get horizontalAlignment() {
        return this._getOption('horizontalAlignment');
    }
    set horizontalAlignment(value) {
        this._setOption('horizontalAlignment', value);
    }
    get itemType() {
        return this._getOption('itemType');
    }
    set itemType(value) {
        this._setOption('itemType', value);
    }
    get name() {
        return this._getOption('name');
    }
    set name(value) {
        this._setOption('name', value);
    }
    get verticalAlignment() {
        return this._getOption('verticalAlignment');
    }
    set verticalAlignment(value) {
        this._setOption('verticalAlignment', value);
    }
    get visible() {
        return this._getOption('visible');
    }
    set visible(value) {
        this._setOption('visible', value);
    }
    get visibleIndex() {
        return this._getOption('visibleIndex');
    }
    set visibleIndex(value) {
        this._setOption('visibleIndex', value);
    }
    get _optionPath() {
        return 'items';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
        this.itemType = 'button';
    }
    ngOnDestroy() {
        this._deleteRemovedOptions(this._fullOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiTreeListButtonItemComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxiTreeListButtonItemComponent, isStandalone: true, selector: "dxi-tree-list-button-item", inputs: { buttonOptions: "buttonOptions", colSpan: "colSpan", cssClass: "cssClass", horizontalAlignment: "horizontalAlignment", itemType: "itemType", name: "name", verticalAlignment: "verticalAlignment", visible: "visible", visibleIndex: "visibleIndex" }, providers: [
            NestedOptionHost,
            {
                provide: PROPERTY_TOKEN_items,
                useExisting: DxiTreeListButtonItemComponent,
            }
        ], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiTreeListButtonItemComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxi-tree-list-button-item', template: '', imports: [DxIntegrationModule], providers: [
                        NestedOptionHost,
                        {
                            provide: PROPERTY_TOKEN_items,
                            useExisting: DxiTreeListButtonItemComponent,
                        }
                    ] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { buttonOptions: [{
                type: Input
            }], colSpan: [{
                type: Input
            }], cssClass: [{
                type: Input
            }], horizontalAlignment: [{
                type: Input
            }], itemType: [{
                type: Input
            }], name: [{
                type: Input
            }], verticalAlignment: [{
                type: Input
            }], visible: [{
                type: Input
            }], visibleIndex: [{
                type: Input
            }] } });
class DxiTreeListButtonItemModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiTreeListButtonItemModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxiTreeListButtonItemModule, imports: [DxiTreeListButtonItemComponent], exports: [DxiTreeListButtonItemComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiTreeListButtonItemModule, imports: [DxiTreeListButtonItemComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiTreeListButtonItemModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxiTreeListButtonItemComponent
                    ],
                    exports: [
                        DxiTreeListButtonItemComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoTreeListButtonOptionsComponent extends NestedOption {
    get accessKey() {
        return this._getOption('accessKey');
    }
    set accessKey(value) {
        this._setOption('accessKey', value);
    }
    get activeStateEnabled() {
        return this._getOption('activeStateEnabled');
    }
    set activeStateEnabled(value) {
        this._setOption('activeStateEnabled', value);
    }
    get disabled() {
        return this._getOption('disabled');
    }
    set disabled(value) {
        this._setOption('disabled', value);
    }
    get elementAttr() {
        return this._getOption('elementAttr');
    }
    set elementAttr(value) {
        this._setOption('elementAttr', value);
    }
    get focusStateEnabled() {
        return this._getOption('focusStateEnabled');
    }
    set focusStateEnabled(value) {
        this._setOption('focusStateEnabled', value);
    }
    get height() {
        return this._getOption('height');
    }
    set height(value) {
        this._setOption('height', value);
    }
    get hint() {
        return this._getOption('hint');
    }
    set hint(value) {
        this._setOption('hint', value);
    }
    get hoverStateEnabled() {
        return this._getOption('hoverStateEnabled');
    }
    set hoverStateEnabled(value) {
        this._setOption('hoverStateEnabled', value);
    }
    get icon() {
        return this._getOption('icon');
    }
    set icon(value) {
        this._setOption('icon', value);
    }
    get onClick() {
        return this._getOption('onClick');
    }
    set onClick(value) {
        this._setOption('onClick', value);
    }
    get onContentReady() {
        return this._getOption('onContentReady');
    }
    set onContentReady(value) {
        this._setOption('onContentReady', value);
    }
    get onDisposing() {
        return this._getOption('onDisposing');
    }
    set onDisposing(value) {
        this._setOption('onDisposing', value);
    }
    get onInitialized() {
        return this._getOption('onInitialized');
    }
    set onInitialized(value) {
        this._setOption('onInitialized', value);
    }
    get onOptionChanged() {
        return this._getOption('onOptionChanged');
    }
    set onOptionChanged(value) {
        this._setOption('onOptionChanged', value);
    }
    get rtlEnabled() {
        return this._getOption('rtlEnabled');
    }
    set rtlEnabled(value) {
        this._setOption('rtlEnabled', value);
    }
    get stylingMode() {
        return this._getOption('stylingMode');
    }
    set stylingMode(value) {
        this._setOption('stylingMode', value);
    }
    get tabIndex() {
        return this._getOption('tabIndex');
    }
    set tabIndex(value) {
        this._setOption('tabIndex', value);
    }
    get template() {
        return this._getOption('template');
    }
    set template(value) {
        this._setOption('template', value);
    }
    get text() {
        return this._getOption('text');
    }
    set text(value) {
        this._setOption('text', value);
    }
    get type() {
        return this._getOption('type');
    }
    set type(value) {
        this._setOption('type', value);
    }
    get useSubmitBehavior() {
        return this._getOption('useSubmitBehavior');
    }
    set useSubmitBehavior(value) {
        this._setOption('useSubmitBehavior', value);
    }
    get validationGroup() {
        return this._getOption('validationGroup');
    }
    set validationGroup(value) {
        this._setOption('validationGroup', value);
    }
    get visible() {
        return this._getOption('visible');
    }
    set visible(value) {
        this._setOption('visible', value);
    }
    get width() {
        return this._getOption('width');
    }
    set width(value) {
        this._setOption('width', value);
    }
    get _optionPath() {
        return 'buttonOptions';
    }
    constructor(parentOptionHost, optionHost, renderer, document, templateHost, element) {
        super();
        this.renderer = renderer;
        this.document = document;
        this.element = element;
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
        templateHost.setHost(this);
    }
    setTemplate(template) {
        this.template = template;
    }
    ngAfterViewInit() {
        extractTemplate(this, this.element, this.renderer, this.document);
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListButtonOptionsComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }, { token: i0.Renderer2 }, { token: DOCUMENT }, { token: i1.DxTemplateHost, host: true }, { token: i0.ElementRef }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoTreeListButtonOptionsComponent, isStandalone: true, selector: "dxo-tree-list-button-options", inputs: { accessKey: "accessKey", activeStateEnabled: "activeStateEnabled", disabled: "disabled", elementAttr: "elementAttr", focusStateEnabled: "focusStateEnabled", height: "height", hint: "hint", hoverStateEnabled: "hoverStateEnabled", icon: "icon", onClick: "onClick", onContentReady: "onContentReady", onDisposing: "onDisposing", onInitialized: "onInitialized", onOptionChanged: "onOptionChanged", rtlEnabled: "rtlEnabled", stylingMode: "stylingMode", tabIndex: "tabIndex", template: "template", text: "text", type: "type", useSubmitBehavior: "useSubmitBehavior", validationGroup: "validationGroup", visible: "visible", width: "width" }, providers: [NestedOptionHost, DxTemplateHost], usesInheritance: true, ngImport: i0, template: '<ng-content></ng-content>', isInline: true, styles: [":host{display:block}\n"], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListButtonOptionsComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-tree-list-button-options', template: '<ng-content></ng-content>', imports: [DxIntegrationModule], providers: [NestedOptionHost, DxTemplateHost], styles: [":host{display:block}\n"] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }, { type: i0.Renderer2 }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [DOCUMENT]
                }] }, { type: i1.DxTemplateHost, decorators: [{
                    type: Host
                }] }, { type: i0.ElementRef }], propDecorators: { accessKey: [{
                type: Input
            }], activeStateEnabled: [{
                type: Input
            }], disabled: [{
                type: Input
            }], elementAttr: [{
                type: Input
            }], focusStateEnabled: [{
                type: Input
            }], height: [{
                type: Input
            }], hint: [{
                type: Input
            }], hoverStateEnabled: [{
                type: Input
            }], icon: [{
                type: Input
            }], onClick: [{
                type: Input
            }], onContentReady: [{
                type: Input
            }], onDisposing: [{
                type: Input
            }], onInitialized: [{
                type: Input
            }], onOptionChanged: [{
                type: Input
            }], rtlEnabled: [{
                type: Input
            }], stylingMode: [{
                type: Input
            }], tabIndex: [{
                type: Input
            }], template: [{
                type: Input
            }], text: [{
                type: Input
            }], type: [{
                type: Input
            }], useSubmitBehavior: [{
                type: Input
            }], validationGroup: [{
                type: Input
            }], visible: [{
                type: Input
            }], width: [{
                type: Input
            }] } });
class DxoTreeListButtonOptionsModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListButtonOptionsModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListButtonOptionsModule, imports: [DxoTreeListButtonOptionsComponent], exports: [DxoTreeListButtonOptionsComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListButtonOptionsModule, imports: [DxoTreeListButtonOptionsComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListButtonOptionsModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoTreeListButtonOptionsComponent
                    ],
                    exports: [
                        DxoTreeListButtonOptionsComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxiTreeListChangeComponent extends CollectionNestedOption {
    get data() {
        return this._getOption('data');
    }
    set data(value) {
        this._setOption('data', value);
    }
    get insertAfterKey() {
        return this._getOption('insertAfterKey');
    }
    set insertAfterKey(value) {
        this._setOption('insertAfterKey', value);
    }
    get insertBeforeKey() {
        return this._getOption('insertBeforeKey');
    }
    set insertBeforeKey(value) {
        this._setOption('insertBeforeKey', value);
    }
    get key() {
        return this._getOption('key');
    }
    set key(value) {
        this._setOption('key', value);
    }
    get type() {
        return this._getOption('type');
    }
    set type(value) {
        this._setOption('type', value);
    }
    get _optionPath() {
        return 'changes';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnDestroy() {
        this._deleteRemovedOptions(this._fullOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiTreeListChangeComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxiTreeListChangeComponent, isStandalone: true, selector: "dxi-tree-list-change", inputs: { data: "data", insertAfterKey: "insertAfterKey", insertBeforeKey: "insertBeforeKey", key: "key", type: "type" }, providers: [
            NestedOptionHost,
            {
                provide: PROPERTY_TOKEN_changes,
                useExisting: DxiTreeListChangeComponent,
            }
        ], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiTreeListChangeComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxi-tree-list-change', template: '', imports: [DxIntegrationModule], providers: [
                        NestedOptionHost,
                        {
                            provide: PROPERTY_TOKEN_changes,
                            useExisting: DxiTreeListChangeComponent,
                        }
                    ] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { data: [{
                type: Input
            }], insertAfterKey: [{
                type: Input
            }], insertBeforeKey: [{
                type: Input
            }], key: [{
                type: Input
            }], type: [{
                type: Input
            }] } });
class DxiTreeListChangeModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiTreeListChangeModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxiTreeListChangeModule, imports: [DxiTreeListChangeComponent], exports: [DxiTreeListChangeComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiTreeListChangeModule, imports: [DxiTreeListChangeComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiTreeListChangeModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxiTreeListChangeComponent
                    ],
                    exports: [
                        DxiTreeListChangeComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoTreeListColCountByScreenComponent extends NestedOption {
    get lg() {
        return this._getOption('lg');
    }
    set lg(value) {
        this._setOption('lg', value);
    }
    get md() {
        return this._getOption('md');
    }
    set md(value) {
        this._setOption('md', value);
    }
    get sm() {
        return this._getOption('sm');
    }
    set sm(value) {
        this._setOption('sm', value);
    }
    get xs() {
        return this._getOption('xs');
    }
    set xs(value) {
        this._setOption('xs', value);
    }
    get _optionPath() {
        return 'colCountByScreen';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListColCountByScreenComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoTreeListColCountByScreenComponent, isStandalone: true, selector: "dxo-tree-list-col-count-by-screen", inputs: { lg: "lg", md: "md", sm: "sm", xs: "xs" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListColCountByScreenComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-tree-list-col-count-by-screen', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { lg: [{
                type: Input
            }], md: [{
                type: Input
            }], sm: [{
                type: Input
            }], xs: [{
                type: Input
            }] } });
class DxoTreeListColCountByScreenModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListColCountByScreenModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListColCountByScreenModule, imports: [DxoTreeListColCountByScreenComponent], exports: [DxoTreeListColCountByScreenComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListColCountByScreenModule, imports: [DxoTreeListColCountByScreenComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListColCountByScreenModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoTreeListColCountByScreenComponent
                    ],
                    exports: [
                        DxoTreeListColCountByScreenComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoTreeListCollisionComponent extends NestedOption {
    get x() {
        return this._getOption('x');
    }
    set x(value) {
        this._setOption('x', value);
    }
    get y() {
        return this._getOption('y');
    }
    set y(value) {
        this._setOption('y', value);
    }
    get _optionPath() {
        return 'collision';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListCollisionComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoTreeListCollisionComponent, isStandalone: true, selector: "dxo-tree-list-collision", inputs: { x: "x", y: "y" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListCollisionComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-tree-list-collision', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { x: [{
                type: Input
            }], y: [{
                type: Input
            }] } });
class DxoTreeListCollisionModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListCollisionModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListCollisionModule, imports: [DxoTreeListCollisionComponent], exports: [DxoTreeListCollisionComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListCollisionModule, imports: [DxoTreeListCollisionComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListCollisionModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoTreeListCollisionComponent
                    ],
                    exports: [
                        DxoTreeListCollisionComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxiTreeListColumnButtonComponent extends CollectionNestedOption {
    get cssClass() {
        return this._getOption('cssClass');
    }
    set cssClass(value) {
        this._setOption('cssClass', value);
    }
    get disabled() {
        return this._getOption('disabled');
    }
    set disabled(value) {
        this._setOption('disabled', value);
    }
    get hint() {
        return this._getOption('hint');
    }
    set hint(value) {
        this._setOption('hint', value);
    }
    get icon() {
        return this._getOption('icon');
    }
    set icon(value) {
        this._setOption('icon', value);
    }
    get name() {
        return this._getOption('name');
    }
    set name(value) {
        this._setOption('name', value);
    }
    get onClick() {
        return this._getOption('onClick');
    }
    set onClick(value) {
        this._setOption('onClick', value);
    }
    get template() {
        return this._getOption('template');
    }
    set template(value) {
        this._setOption('template', value);
    }
    get text() {
        return this._getOption('text');
    }
    set text(value) {
        this._setOption('text', value);
    }
    get visible() {
        return this._getOption('visible');
    }
    set visible(value) {
        this._setOption('visible', value);
    }
    get _optionPath() {
        return 'buttons';
    }
    constructor(parentOptionHost, optionHost, renderer, document, templateHost, element) {
        super();
        this.renderer = renderer;
        this.document = document;
        this.element = element;
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
        templateHost.setHost(this);
    }
    setTemplate(template) {
        this.template = template;
    }
    ngAfterViewInit() {
        extractTemplate(this, this.element, this.renderer, this.document);
    }
    ngOnDestroy() {
        this._deleteRemovedOptions(this._fullOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiTreeListColumnButtonComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }, { token: i0.Renderer2 }, { token: DOCUMENT }, { token: i1.DxTemplateHost, host: true }, { token: i0.ElementRef }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxiTreeListColumnButtonComponent, isStandalone: true, selector: "dxi-tree-list-column-button", inputs: { cssClass: "cssClass", disabled: "disabled", hint: "hint", icon: "icon", name: "name", onClick: "onClick", template: "template", text: "text", visible: "visible" }, providers: [
            NestedOptionHost,
            DxTemplateHost,
            {
                provide: PROPERTY_TOKEN_buttons,
                useExisting: DxiTreeListColumnButtonComponent,
            }
        ], usesInheritance: true, ngImport: i0, template: '<ng-content></ng-content>', isInline: true, styles: [":host{display:block}\n"], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiTreeListColumnButtonComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxi-tree-list-column-button', template: '<ng-content></ng-content>', imports: [DxIntegrationModule], providers: [
                        NestedOptionHost,
                        DxTemplateHost,
                        {
                            provide: PROPERTY_TOKEN_buttons,
                            useExisting: DxiTreeListColumnButtonComponent,
                        }
                    ], styles: [":host{display:block}\n"] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }, { type: i0.Renderer2 }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [DOCUMENT]
                }] }, { type: i1.DxTemplateHost, decorators: [{
                    type: Host
                }] }, { type: i0.ElementRef }], propDecorators: { cssClass: [{
                type: Input
            }], disabled: [{
                type: Input
            }], hint: [{
                type: Input
            }], icon: [{
                type: Input
            }], name: [{
                type: Input
            }], onClick: [{
                type: Input
            }], template: [{
                type: Input
            }], text: [{
                type: Input
            }], visible: [{
                type: Input
            }] } });
class DxiTreeListColumnButtonModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiTreeListColumnButtonModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxiTreeListColumnButtonModule, imports: [DxiTreeListColumnButtonComponent], exports: [DxiTreeListColumnButtonComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiTreeListColumnButtonModule, imports: [DxiTreeListColumnButtonComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiTreeListColumnButtonModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxiTreeListColumnButtonComponent
                    ],
                    exports: [
                        DxiTreeListColumnButtonComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoTreeListColumnChooserSearchComponent extends NestedOption {
    get editorOptions() {
        return this._getOption('editorOptions');
    }
    set editorOptions(value) {
        this._setOption('editorOptions', value);
    }
    get enabled() {
        return this._getOption('enabled');
    }
    set enabled(value) {
        this._setOption('enabled', value);
    }
    get timeout() {
        return this._getOption('timeout');
    }
    set timeout(value) {
        this._setOption('timeout', value);
    }
    get _optionPath() {
        return 'search';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListColumnChooserSearchComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoTreeListColumnChooserSearchComponent, isStandalone: true, selector: "dxo-tree-list-column-chooser-search", inputs: { editorOptions: "editorOptions", enabled: "enabled", timeout: "timeout" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListColumnChooserSearchComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-tree-list-column-chooser-search', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { editorOptions: [{
                type: Input
            }], enabled: [{
                type: Input
            }], timeout: [{
                type: Input
            }] } });
class DxoTreeListColumnChooserSearchModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListColumnChooserSearchModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListColumnChooserSearchModule, imports: [DxoTreeListColumnChooserSearchComponent], exports: [DxoTreeListColumnChooserSearchComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListColumnChooserSearchModule, imports: [DxoTreeListColumnChooserSearchComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListColumnChooserSearchModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoTreeListColumnChooserSearchComponent
                    ],
                    exports: [
                        DxoTreeListColumnChooserSearchComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoTreeListColumnChooserSelectionComponent extends NestedOption {
    get allowSelectAll() {
        return this._getOption('allowSelectAll');
    }
    set allowSelectAll(value) {
        this._setOption('allowSelectAll', value);
    }
    get recursive() {
        return this._getOption('recursive');
    }
    set recursive(value) {
        this._setOption('recursive', value);
    }
    get selectByClick() {
        return this._getOption('selectByClick');
    }
    set selectByClick(value) {
        this._setOption('selectByClick', value);
    }
    get _optionPath() {
        return 'selection';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListColumnChooserSelectionComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoTreeListColumnChooserSelectionComponent, isStandalone: true, selector: "dxo-tree-list-column-chooser-selection", inputs: { allowSelectAll: "allowSelectAll", recursive: "recursive", selectByClick: "selectByClick" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListColumnChooserSelectionComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-tree-list-column-chooser-selection', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { allowSelectAll: [{
                type: Input
            }], recursive: [{
                type: Input
            }], selectByClick: [{
                type: Input
            }] } });
class DxoTreeListColumnChooserSelectionModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListColumnChooserSelectionModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListColumnChooserSelectionModule, imports: [DxoTreeListColumnChooserSelectionComponent], exports: [DxoTreeListColumnChooserSelectionComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListColumnChooserSelectionModule, imports: [DxoTreeListColumnChooserSelectionComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListColumnChooserSelectionModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoTreeListColumnChooserSelectionComponent
                    ],
                    exports: [
                        DxoTreeListColumnChooserSelectionComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoTreeListColumnChooserComponent extends NestedOption {
    get allowSearch() {
        return this._getOption('allowSearch');
    }
    set allowSearch(value) {
        this._setOption('allowSearch', value);
    }
    get container() {
        return this._getOption('container');
    }
    set container(value) {
        this._setOption('container', value);
    }
    get emptyPanelText() {
        return this._getOption('emptyPanelText');
    }
    set emptyPanelText(value) {
        this._setOption('emptyPanelText', value);
    }
    get enabled() {
        return this._getOption('enabled');
    }
    set enabled(value) {
        this._setOption('enabled', value);
    }
    get height() {
        return this._getOption('height');
    }
    set height(value) {
        this._setOption('height', value);
    }
    get mode() {
        return this._getOption('mode');
    }
    set mode(value) {
        this._setOption('mode', value);
    }
    get position() {
        return this._getOption('position');
    }
    set position(value) {
        this._setOption('position', value);
    }
    get search() {
        return this._getOption('search');
    }
    set search(value) {
        this._setOption('search', value);
    }
    get searchTimeout() {
        return this._getOption('searchTimeout');
    }
    set searchTimeout(value) {
        this._setOption('searchTimeout', value);
    }
    get selection() {
        return this._getOption('selection');
    }
    set selection(value) {
        this._setOption('selection', value);
    }
    get sortOrder() {
        return this._getOption('sortOrder');
    }
    set sortOrder(value) {
        this._setOption('sortOrder', value);
    }
    get title() {
        return this._getOption('title');
    }
    set title(value) {
        this._setOption('title', value);
    }
    get width() {
        return this._getOption('width');
    }
    set width(value) {
        this._setOption('width', value);
    }
    get _optionPath() {
        return 'columnChooser';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListColumnChooserComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoTreeListColumnChooserComponent, isStandalone: true, selector: "dxo-tree-list-column-chooser", inputs: { allowSearch: "allowSearch", container: "container", emptyPanelText: "emptyPanelText", enabled: "enabled", height: "height", mode: "mode", position: "position", search: "search", searchTimeout: "searchTimeout", selection: "selection", sortOrder: "sortOrder", title: "title", width: "width" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListColumnChooserComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-tree-list-column-chooser', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { allowSearch: [{
                type: Input
            }], container: [{
                type: Input
            }], emptyPanelText: [{
                type: Input
            }], enabled: [{
                type: Input
            }], height: [{
                type: Input
            }], mode: [{
                type: Input
            }], position: [{
                type: Input
            }], search: [{
                type: Input
            }], searchTimeout: [{
                type: Input
            }], selection: [{
                type: Input
            }], sortOrder: [{
                type: Input
            }], title: [{
                type: Input
            }], width: [{
                type: Input
            }] } });
class DxoTreeListColumnChooserModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListColumnChooserModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListColumnChooserModule, imports: [DxoTreeListColumnChooserComponent], exports: [DxoTreeListColumnChooserComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListColumnChooserModule, imports: [DxoTreeListColumnChooserComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListColumnChooserModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoTreeListColumnChooserComponent
                    ],
                    exports: [
                        DxoTreeListColumnChooserComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxiTreeListColumnComponent extends CollectionNestedOption {
    set _validationRulesContentChildren(value) {
        this.setChildren('validationRules', value);
    }
    set _buttonsContentChildren(value) {
        this.setChildren('buttons', value);
    }
    set _columnsContentChildren(value) {
        this.setChildren('columns', value);
    }
    get ai() {
        return this._getOption('ai');
    }
    set ai(value) {
        this._setOption('ai', value);
    }
    get alignment() {
        return this._getOption('alignment');
    }
    set alignment(value) {
        this._setOption('alignment', value);
    }
    get allowEditing() {
        return this._getOption('allowEditing');
    }
    set allowEditing(value) {
        this._setOption('allowEditing', value);
    }
    get allowFiltering() {
        return this._getOption('allowFiltering');
    }
    set allowFiltering(value) {
        this._setOption('allowFiltering', value);
    }
    get allowFixing() {
        return this._getOption('allowFixing');
    }
    set allowFixing(value) {
        this._setOption('allowFixing', value);
    }
    get allowHeaderFiltering() {
        return this._getOption('allowHeaderFiltering');
    }
    set allowHeaderFiltering(value) {
        this._setOption('allowHeaderFiltering', value);
    }
    get allowHiding() {
        return this._getOption('allowHiding');
    }
    set allowHiding(value) {
        this._setOption('allowHiding', value);
    }
    get allowReordering() {
        return this._getOption('allowReordering');
    }
    set allowReordering(value) {
        this._setOption('allowReordering', value);
    }
    get allowResizing() {
        return this._getOption('allowResizing');
    }
    set allowResizing(value) {
        this._setOption('allowResizing', value);
    }
    get allowSearch() {
        return this._getOption('allowSearch');
    }
    set allowSearch(value) {
        this._setOption('allowSearch', value);
    }
    get allowSorting() {
        return this._getOption('allowSorting');
    }
    set allowSorting(value) {
        this._setOption('allowSorting', value);
    }
    get buttons() {
        return this._getOption('buttons');
    }
    set buttons(value) {
        this._setOption('buttons', value);
    }
    get calculateCellValue() {
        return this._getOption('calculateCellValue');
    }
    set calculateCellValue(value) {
        this._setOption('calculateCellValue', value);
    }
    get calculateDisplayValue() {
        return this._getOption('calculateDisplayValue');
    }
    set calculateDisplayValue(value) {
        this._setOption('calculateDisplayValue', value);
    }
    get calculateFilterExpression() {
        return this._getOption('calculateFilterExpression');
    }
    set calculateFilterExpression(value) {
        this._setOption('calculateFilterExpression', value);
    }
    get calculateSortValue() {
        return this._getOption('calculateSortValue');
    }
    set calculateSortValue(value) {
        this._setOption('calculateSortValue', value);
    }
    get caption() {
        return this._getOption('caption');
    }
    set caption(value) {
        this._setOption('caption', value);
    }
    get cellTemplate() {
        return this._getOption('cellTemplate');
    }
    set cellTemplate(value) {
        this._setOption('cellTemplate', value);
    }
    get columns() {
        return this._getOption('columns');
    }
    set columns(value) {
        this._setOption('columns', value);
    }
    get cssClass() {
        return this._getOption('cssClass');
    }
    set cssClass(value) {
        this._setOption('cssClass', value);
    }
    get customizeText() {
        return this._getOption('customizeText');
    }
    set customizeText(value) {
        this._setOption('customizeText', value);
    }
    get dataField() {
        return this._getOption('dataField');
    }
    set dataField(value) {
        this._setOption('dataField', value);
    }
    get dataType() {
        return this._getOption('dataType');
    }
    set dataType(value) {
        this._setOption('dataType', value);
    }
    get editCellTemplate() {
        return this._getOption('editCellTemplate');
    }
    set editCellTemplate(value) {
        this._setOption('editCellTemplate', value);
    }
    get editorOptions() {
        return this._getOption('editorOptions');
    }
    set editorOptions(value) {
        this._setOption('editorOptions', value);
    }
    get encodeHtml() {
        return this._getOption('encodeHtml');
    }
    set encodeHtml(value) {
        this._setOption('encodeHtml', value);
    }
    get falseText() {
        return this._getOption('falseText');
    }
    set falseText(value) {
        this._setOption('falseText', value);
    }
    get filterOperations() {
        return this._getOption('filterOperations');
    }
    set filterOperations(value) {
        this._setOption('filterOperations', value);
    }
    get filterType() {
        return this._getOption('filterType');
    }
    set filterType(value) {
        this._setOption('filterType', value);
    }
    get filterValue() {
        return this._getOption('filterValue');
    }
    set filterValue(value) {
        this._setOption('filterValue', value);
    }
    get filterValues() {
        return this._getOption('filterValues');
    }
    set filterValues(value) {
        this._setOption('filterValues', value);
    }
    get fixed() {
        return this._getOption('fixed');
    }
    set fixed(value) {
        this._setOption('fixed', value);
    }
    get fixedPosition() {
        return this._getOption('fixedPosition');
    }
    set fixedPosition(value) {
        this._setOption('fixedPosition', value);
    }
    get format() {
        return this._getOption('format');
    }
    set format(value) {
        this._setOption('format', value);
    }
    get formItem() {
        return this._getOption('formItem');
    }
    set formItem(value) {
        this._setOption('formItem', value);
    }
    get headerCellTemplate() {
        return this._getOption('headerCellTemplate');
    }
    set headerCellTemplate(value) {
        this._setOption('headerCellTemplate', value);
    }
    get headerFilter() {
        return this._getOption('headerFilter');
    }
    set headerFilter(value) {
        this._setOption('headerFilter', value);
    }
    get hidingPriority() {
        return this._getOption('hidingPriority');
    }
    set hidingPriority(value) {
        this._setOption('hidingPriority', value);
    }
    get isBand() {
        return this._getOption('isBand');
    }
    set isBand(value) {
        this._setOption('isBand', value);
    }
    get lookup() {
        return this._getOption('lookup');
    }
    set lookup(value) {
        this._setOption('lookup', value);
    }
    get minWidth() {
        return this._getOption('minWidth');
    }
    set minWidth(value) {
        this._setOption('minWidth', value);
    }
    get name() {
        return this._getOption('name');
    }
    set name(value) {
        this._setOption('name', value);
    }
    get ownerBand() {
        return this._getOption('ownerBand');
    }
    set ownerBand(value) {
        this._setOption('ownerBand', value);
    }
    get renderAsync() {
        return this._getOption('renderAsync');
    }
    set renderAsync(value) {
        this._setOption('renderAsync', value);
    }
    get selectedFilterOperation() {
        return this._getOption('selectedFilterOperation');
    }
    set selectedFilterOperation(value) {
        this._setOption('selectedFilterOperation', value);
    }
    get setCellValue() {
        return this._getOption('setCellValue');
    }
    set setCellValue(value) {
        this._setOption('setCellValue', value);
    }
    get showEditorAlways() {
        return this._getOption('showEditorAlways');
    }
    set showEditorAlways(value) {
        this._setOption('showEditorAlways', value);
    }
    get showInColumnChooser() {
        return this._getOption('showInColumnChooser');
    }
    set showInColumnChooser(value) {
        this._setOption('showInColumnChooser', value);
    }
    get sortIndex() {
        return this._getOption('sortIndex');
    }
    set sortIndex(value) {
        this._setOption('sortIndex', value);
    }
    get sortingMethod() {
        return this._getOption('sortingMethod');
    }
    set sortingMethod(value) {
        this._setOption('sortingMethod', value);
    }
    get sortOrder() {
        return this._getOption('sortOrder');
    }
    set sortOrder(value) {
        this._setOption('sortOrder', value);
    }
    get trueText() {
        return this._getOption('trueText');
    }
    set trueText(value) {
        this._setOption('trueText', value);
    }
    get type() {
        return this._getOption('type');
    }
    set type(value) {
        this._setOption('type', value);
    }
    get validationRules() {
        return this._getOption('validationRules');
    }
    set validationRules(value) {
        this._setOption('validationRules', value);
    }
    get visible() {
        return this._getOption('visible');
    }
    set visible(value) {
        this._setOption('visible', value);
    }
    get visibleIndex() {
        return this._getOption('visibleIndex');
    }
    set visibleIndex(value) {
        this._setOption('visibleIndex', value);
    }
    get width() {
        return this._getOption('width');
    }
    set width(value) {
        this._setOption('width', value);
    }
    get _optionPath() {
        return 'columns';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        this._createEventEmitters([
            { emit: 'filterValueChange' },
            { emit: 'filterValuesChange' },
            { emit: 'selectedFilterOperationChange' },
            { emit: 'sortIndexChange' },
            { emit: 'sortOrderChange' },
            { emit: 'visibleChange' },
            { emit: 'visibleIndexChange' }
        ]);
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnDestroy() {
        this._deleteRemovedOptions(this._fullOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiTreeListColumnComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxiTreeListColumnComponent, isStandalone: true, selector: "dxi-tree-list-column", inputs: { ai: "ai", alignment: "alignment", allowEditing: "allowEditing", allowFiltering: "allowFiltering", allowFixing: "allowFixing", allowHeaderFiltering: "allowHeaderFiltering", allowHiding: "allowHiding", allowReordering: "allowReordering", allowResizing: "allowResizing", allowSearch: "allowSearch", allowSorting: "allowSorting", buttons: "buttons", calculateCellValue: "calculateCellValue", calculateDisplayValue: "calculateDisplayValue", calculateFilterExpression: "calculateFilterExpression", calculateSortValue: "calculateSortValue", caption: "caption", cellTemplate: "cellTemplate", columns: "columns", cssClass: "cssClass", customizeText: "customizeText", dataField: "dataField", dataType: "dataType", editCellTemplate: "editCellTemplate", editorOptions: "editorOptions", encodeHtml: "encodeHtml", falseText: "falseText", filterOperations: "filterOperations", filterType: "filterType", filterValue: "filterValue", filterValues: "filterValues", fixed: "fixed", fixedPosition: "fixedPosition", format: "format", formItem: "formItem", headerCellTemplate: "headerCellTemplate", headerFilter: "headerFilter", hidingPriority: "hidingPriority", isBand: "isBand", lookup: "lookup", minWidth: "minWidth", name: "name", ownerBand: "ownerBand", renderAsync: "renderAsync", selectedFilterOperation: "selectedFilterOperation", setCellValue: "setCellValue", showEditorAlways: "showEditorAlways", showInColumnChooser: "showInColumnChooser", sortIndex: "sortIndex", sortingMethod: "sortingMethod", sortOrder: "sortOrder", trueText: "trueText", type: "type", validationRules: "validationRules", visible: "visible", visibleIndex: "visibleIndex", width: "width" }, outputs: { filterValueChange: "filterValueChange", filterValuesChange: "filterValuesChange", selectedFilterOperationChange: "selectedFilterOperationChange", sortIndexChange: "sortIndexChange", sortOrderChange: "sortOrderChange", visibleChange: "visibleChange", visibleIndexChange: "visibleIndexChange" }, providers: [
            NestedOptionHost,
            {
                provide: PROPERTY_TOKEN_columns,
                useExisting: DxiTreeListColumnComponent,
            }
        ], queries: [{ propertyName: "_validationRulesContentChildren", predicate: PROPERTY_TOKEN_validationRules }, { propertyName: "_buttonsContentChildren", predicate: PROPERTY_TOKEN_buttons }, { propertyName: "_columnsContentChildren", predicate: PROPERTY_TOKEN_columns }], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiTreeListColumnComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxi-tree-list-column', template: '', imports: [DxIntegrationModule], providers: [
                        NestedOptionHost,
                        {
                            provide: PROPERTY_TOKEN_columns,
                            useExisting: DxiTreeListColumnComponent,
                        }
                    ] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { _validationRulesContentChildren: [{
                type: ContentChildren,
                args: [PROPERTY_TOKEN_validationRules]
            }], _buttonsContentChildren: [{
                type: ContentChildren,
                args: [PROPERTY_TOKEN_buttons]
            }], _columnsContentChildren: [{
                type: ContentChildren,
                args: [PROPERTY_TOKEN_columns]
            }], ai: [{
                type: Input
            }], alignment: [{
                type: Input
            }], allowEditing: [{
                type: Input
            }], allowFiltering: [{
                type: Input
            }], allowFixing: [{
                type: Input
            }], allowHeaderFiltering: [{
                type: Input
            }], allowHiding: [{
                type: Input
            }], allowReordering: [{
                type: Input
            }], allowResizing: [{
                type: Input
            }], allowSearch: [{
                type: Input
            }], allowSorting: [{
                type: Input
            }], buttons: [{
                type: Input
            }], calculateCellValue: [{
                type: Input
            }], calculateDisplayValue: [{
                type: Input
            }], calculateFilterExpression: [{
                type: Input
            }], calculateSortValue: [{
                type: Input
            }], caption: [{
                type: Input
            }], cellTemplate: [{
                type: Input
            }], columns: [{
                type: Input
            }], cssClass: [{
                type: Input
            }], customizeText: [{
                type: Input
            }], dataField: [{
                type: Input
            }], dataType: [{
                type: Input
            }], editCellTemplate: [{
                type: Input
            }], editorOptions: [{
                type: Input
            }], encodeHtml: [{
                type: Input
            }], falseText: [{
                type: Input
            }], filterOperations: [{
                type: Input
            }], filterType: [{
                type: Input
            }], filterValue: [{
                type: Input
            }], filterValues: [{
                type: Input
            }], fixed: [{
                type: Input
            }], fixedPosition: [{
                type: Input
            }], format: [{
                type: Input
            }], formItem: [{
                type: Input
            }], headerCellTemplate: [{
                type: Input
            }], headerFilter: [{
                type: Input
            }], hidingPriority: [{
                type: Input
            }], isBand: [{
                type: Input
            }], lookup: [{
                type: Input
            }], minWidth: [{
                type: Input
            }], name: [{
                type: Input
            }], ownerBand: [{
                type: Input
            }], renderAsync: [{
                type: Input
            }], selectedFilterOperation: [{
                type: Input
            }], setCellValue: [{
                type: Input
            }], showEditorAlways: [{
                type: Input
            }], showInColumnChooser: [{
                type: Input
            }], sortIndex: [{
                type: Input
            }], sortingMethod: [{
                type: Input
            }], sortOrder: [{
                type: Input
            }], trueText: [{
                type: Input
            }], type: [{
                type: Input
            }], validationRules: [{
                type: Input
            }], visible: [{
                type: Input
            }], visibleIndex: [{
                type: Input
            }], width: [{
                type: Input
            }], filterValueChange: [{
                type: Output
            }], filterValuesChange: [{
                type: Output
            }], selectedFilterOperationChange: [{
                type: Output
            }], sortIndexChange: [{
                type: Output
            }], sortOrderChange: [{
                type: Output
            }], visibleChange: [{
                type: Output
            }], visibleIndexChange: [{
                type: Output
            }] } });
class DxiTreeListColumnModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiTreeListColumnModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxiTreeListColumnModule, imports: [DxiTreeListColumnComponent], exports: [DxiTreeListColumnComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiTreeListColumnModule, imports: [DxiTreeListColumnComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiTreeListColumnModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxiTreeListColumnComponent
                    ],
                    exports: [
                        DxiTreeListColumnComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoTreeListColumnFixingTextsComponent extends NestedOption {
    get fix() {
        return this._getOption('fix');
    }
    set fix(value) {
        this._setOption('fix', value);
    }
    get leftPosition() {
        return this._getOption('leftPosition');
    }
    set leftPosition(value) {
        this._setOption('leftPosition', value);
    }
    get rightPosition() {
        return this._getOption('rightPosition');
    }
    set rightPosition(value) {
        this._setOption('rightPosition', value);
    }
    get stickyPosition() {
        return this._getOption('stickyPosition');
    }
    set stickyPosition(value) {
        this._setOption('stickyPosition', value);
    }
    get unfix() {
        return this._getOption('unfix');
    }
    set unfix(value) {
        this._setOption('unfix', value);
    }
    get _optionPath() {
        return 'texts';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListColumnFixingTextsComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoTreeListColumnFixingTextsComponent, isStandalone: true, selector: "dxo-tree-list-column-fixing-texts", inputs: { fix: "fix", leftPosition: "leftPosition", rightPosition: "rightPosition", stickyPosition: "stickyPosition", unfix: "unfix" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListColumnFixingTextsComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-tree-list-column-fixing-texts', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { fix: [{
                type: Input
            }], leftPosition: [{
                type: Input
            }], rightPosition: [{
                type: Input
            }], stickyPosition: [{
                type: Input
            }], unfix: [{
                type: Input
            }] } });
class DxoTreeListColumnFixingTextsModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListColumnFixingTextsModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListColumnFixingTextsModule, imports: [DxoTreeListColumnFixingTextsComponent], exports: [DxoTreeListColumnFixingTextsComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListColumnFixingTextsModule, imports: [DxoTreeListColumnFixingTextsComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListColumnFixingTextsModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoTreeListColumnFixingTextsComponent
                    ],
                    exports: [
                        DxoTreeListColumnFixingTextsComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoTreeListColumnFixingComponent extends NestedOption {
    get enabled() {
        return this._getOption('enabled');
    }
    set enabled(value) {
        this._setOption('enabled', value);
    }
    get icons() {
        return this._getOption('icons');
    }
    set icons(value) {
        this._setOption('icons', value);
    }
    get texts() {
        return this._getOption('texts');
    }
    set texts(value) {
        this._setOption('texts', value);
    }
    get _optionPath() {
        return 'columnFixing';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListColumnFixingComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoTreeListColumnFixingComponent, isStandalone: true, selector: "dxo-tree-list-column-fixing", inputs: { enabled: "enabled", icons: "icons", texts: "texts" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListColumnFixingComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-tree-list-column-fixing', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { enabled: [{
                type: Input
            }], icons: [{
                type: Input
            }], texts: [{
                type: Input
            }] } });
class DxoTreeListColumnFixingModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListColumnFixingModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListColumnFixingModule, imports: [DxoTreeListColumnFixingComponent], exports: [DxoTreeListColumnFixingComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListColumnFixingModule, imports: [DxoTreeListColumnFixingComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListColumnFixingModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoTreeListColumnFixingComponent
                    ],
                    exports: [
                        DxoTreeListColumnFixingComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoTreeListColumnHeaderFilterSearchComponent extends NestedOption {
    get editorOptions() {
        return this._getOption('editorOptions');
    }
    set editorOptions(value) {
        this._setOption('editorOptions', value);
    }
    get enabled() {
        return this._getOption('enabled');
    }
    set enabled(value) {
        this._setOption('enabled', value);
    }
    get mode() {
        return this._getOption('mode');
    }
    set mode(value) {
        this._setOption('mode', value);
    }
    get searchExpr() {
        return this._getOption('searchExpr');
    }
    set searchExpr(value) {
        this._setOption('searchExpr', value);
    }
    get timeout() {
        return this._getOption('timeout');
    }
    set timeout(value) {
        this._setOption('timeout', value);
    }
    get _optionPath() {
        return 'search';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListColumnHeaderFilterSearchComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoTreeListColumnHeaderFilterSearchComponent, isStandalone: true, selector: "dxo-tree-list-column-header-filter-search", inputs: { editorOptions: "editorOptions", enabled: "enabled", mode: "mode", searchExpr: "searchExpr", timeout: "timeout" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListColumnHeaderFilterSearchComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-tree-list-column-header-filter-search', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { editorOptions: [{
                type: Input
            }], enabled: [{
                type: Input
            }], mode: [{
                type: Input
            }], searchExpr: [{
                type: Input
            }], timeout: [{
                type: Input
            }] } });
class DxoTreeListColumnHeaderFilterSearchModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListColumnHeaderFilterSearchModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListColumnHeaderFilterSearchModule, imports: [DxoTreeListColumnHeaderFilterSearchComponent], exports: [DxoTreeListColumnHeaderFilterSearchComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListColumnHeaderFilterSearchModule, imports: [DxoTreeListColumnHeaderFilterSearchComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListColumnHeaderFilterSearchModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoTreeListColumnHeaderFilterSearchComponent
                    ],
                    exports: [
                        DxoTreeListColumnHeaderFilterSearchComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoTreeListColumnHeaderFilterComponent extends NestedOption {
    get allowSearch() {
        return this._getOption('allowSearch');
    }
    set allowSearch(value) {
        this._setOption('allowSearch', value);
    }
    get allowSelectAll() {
        return this._getOption('allowSelectAll');
    }
    set allowSelectAll(value) {
        this._setOption('allowSelectAll', value);
    }
    get dataSource() {
        return this._getOption('dataSource');
    }
    set dataSource(value) {
        this._setOption('dataSource', value);
    }
    get groupInterval() {
        return this._getOption('groupInterval');
    }
    set groupInterval(value) {
        this._setOption('groupInterval', value);
    }
    get height() {
        return this._getOption('height');
    }
    set height(value) {
        this._setOption('height', value);
    }
    get search() {
        return this._getOption('search');
    }
    set search(value) {
        this._setOption('search', value);
    }
    get searchMode() {
        return this._getOption('searchMode');
    }
    set searchMode(value) {
        this._setOption('searchMode', value);
    }
    get width() {
        return this._getOption('width');
    }
    set width(value) {
        this._setOption('width', value);
    }
    get _optionPath() {
        return 'headerFilter';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListColumnHeaderFilterComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoTreeListColumnHeaderFilterComponent, isStandalone: true, selector: "dxo-tree-list-column-header-filter", inputs: { allowSearch: "allowSearch", allowSelectAll: "allowSelectAll", dataSource: "dataSource", groupInterval: "groupInterval", height: "height", search: "search", searchMode: "searchMode", width: "width" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListColumnHeaderFilterComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-tree-list-column-header-filter', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { allowSearch: [{
                type: Input
            }], allowSelectAll: [{
                type: Input
            }], dataSource: [{
                type: Input
            }], groupInterval: [{
                type: Input
            }], height: [{
                type: Input
            }], search: [{
                type: Input
            }], searchMode: [{
                type: Input
            }], width: [{
                type: Input
            }] } });
class DxoTreeListColumnHeaderFilterModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListColumnHeaderFilterModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListColumnHeaderFilterModule, imports: [DxoTreeListColumnHeaderFilterComponent], exports: [DxoTreeListColumnHeaderFilterComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListColumnHeaderFilterModule, imports: [DxoTreeListColumnHeaderFilterComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListColumnHeaderFilterModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoTreeListColumnHeaderFilterComponent
                    ],
                    exports: [
                        DxoTreeListColumnHeaderFilterComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoTreeListColumnLookupComponent extends NestedOption {
    get allowClearing() {
        return this._getOption('allowClearing');
    }
    set allowClearing(value) {
        this._setOption('allowClearing', value);
    }
    get calculateCellValue() {
        return this._getOption('calculateCellValue');
    }
    set calculateCellValue(value) {
        this._setOption('calculateCellValue', value);
    }
    get dataSource() {
        return this._getOption('dataSource');
    }
    set dataSource(value) {
        this._setOption('dataSource', value);
    }
    get displayExpr() {
        return this._getOption('displayExpr');
    }
    set displayExpr(value) {
        this._setOption('displayExpr', value);
    }
    get valueExpr() {
        return this._getOption('valueExpr');
    }
    set valueExpr(value) {
        this._setOption('valueExpr', value);
    }
    get _optionPath() {
        return 'lookup';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListColumnLookupComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoTreeListColumnLookupComponent, isStandalone: true, selector: "dxo-tree-list-column-lookup", inputs: { allowClearing: "allowClearing", calculateCellValue: "calculateCellValue", dataSource: "dataSource", displayExpr: "displayExpr", valueExpr: "valueExpr" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListColumnLookupComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-tree-list-column-lookup', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { allowClearing: [{
                type: Input
            }], calculateCellValue: [{
                type: Input
            }], dataSource: [{
                type: Input
            }], displayExpr: [{
                type: Input
            }], valueExpr: [{
                type: Input
            }] } });
class DxoTreeListColumnLookupModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListColumnLookupModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListColumnLookupModule, imports: [DxoTreeListColumnLookupComponent], exports: [DxoTreeListColumnLookupComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListColumnLookupModule, imports: [DxoTreeListColumnLookupComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListColumnLookupModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoTreeListColumnLookupComponent
                    ],
                    exports: [
                        DxoTreeListColumnLookupComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxiTreeListCompareRuleComponent extends CollectionNestedOption {
    get comparisonTarget() {
        return this._getOption('comparisonTarget');
    }
    set comparisonTarget(value) {
        this._setOption('comparisonTarget', value);
    }
    get comparisonType() {
        return this._getOption('comparisonType');
    }
    set comparisonType(value) {
        this._setOption('comparisonType', value);
    }
    get ignoreEmptyValue() {
        return this._getOption('ignoreEmptyValue');
    }
    set ignoreEmptyValue(value) {
        this._setOption('ignoreEmptyValue', value);
    }
    get message() {
        return this._getOption('message');
    }
    set message(value) {
        this._setOption('message', value);
    }
    get type() {
        return this._getOption('type');
    }
    set type(value) {
        this._setOption('type', value);
    }
    get _optionPath() {
        return 'validationRules';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
        this.type = 'compare';
    }
    ngOnDestroy() {
        this._deleteRemovedOptions(this._fullOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiTreeListCompareRuleComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxiTreeListCompareRuleComponent, isStandalone: true, selector: "dxi-tree-list-compare-rule", inputs: { comparisonTarget: "comparisonTarget", comparisonType: "comparisonType", ignoreEmptyValue: "ignoreEmptyValue", message: "message", type: "type" }, providers: [
            NestedOptionHost,
            {
                provide: PROPERTY_TOKEN_validationRules,
                useExisting: DxiTreeListCompareRuleComponent,
            }
        ], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiTreeListCompareRuleComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxi-tree-list-compare-rule', template: '', imports: [DxIntegrationModule], providers: [
                        NestedOptionHost,
                        {
                            provide: PROPERTY_TOKEN_validationRules,
                            useExisting: DxiTreeListCompareRuleComponent,
                        }
                    ] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { comparisonTarget: [{
                type: Input
            }], comparisonType: [{
                type: Input
            }], ignoreEmptyValue: [{
                type: Input
            }], message: [{
                type: Input
            }], type: [{
                type: Input
            }] } });
class DxiTreeListCompareRuleModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiTreeListCompareRuleModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxiTreeListCompareRuleModule, imports: [DxiTreeListCompareRuleComponent], exports: [DxiTreeListCompareRuleComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiTreeListCompareRuleModule, imports: [DxiTreeListCompareRuleComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiTreeListCompareRuleModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxiTreeListCompareRuleComponent
                    ],
                    exports: [
                        DxiTreeListCompareRuleComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoTreeListCursorOffsetComponent extends NestedOption {
    get x() {
        return this._getOption('x');
    }
    set x(value) {
        this._setOption('x', value);
    }
    get y() {
        return this._getOption('y');
    }
    set y(value) {
        this._setOption('y', value);
    }
    get _optionPath() {
        return 'cursorOffset';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListCursorOffsetComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoTreeListCursorOffsetComponent, isStandalone: true, selector: "dxo-tree-list-cursor-offset", inputs: { x: "x", y: "y" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListCursorOffsetComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-tree-list-cursor-offset', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { x: [{
                type: Input
            }], y: [{
                type: Input
            }] } });
class DxoTreeListCursorOffsetModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListCursorOffsetModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListCursorOffsetModule, imports: [DxoTreeListCursorOffsetComponent], exports: [DxoTreeListCursorOffsetComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListCursorOffsetModule, imports: [DxoTreeListCursorOffsetComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListCursorOffsetModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoTreeListCursorOffsetComponent
                    ],
                    exports: [
                        DxoTreeListCursorOffsetComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxiTreeListCustomOperationComponent extends CollectionNestedOption {
    get calculateFilterExpression() {
        return this._getOption('calculateFilterExpression');
    }
    set calculateFilterExpression(value) {
        this._setOption('calculateFilterExpression', value);
    }
    get caption() {
        return this._getOption('caption');
    }
    set caption(value) {
        this._setOption('caption', value);
    }
    get customizeText() {
        return this._getOption('customizeText');
    }
    set customizeText(value) {
        this._setOption('customizeText', value);
    }
    get dataTypes() {
        return this._getOption('dataTypes');
    }
    set dataTypes(value) {
        this._setOption('dataTypes', value);
    }
    get editorTemplate() {
        return this._getOption('editorTemplate');
    }
    set editorTemplate(value) {
        this._setOption('editorTemplate', value);
    }
    get hasValue() {
        return this._getOption('hasValue');
    }
    set hasValue(value) {
        this._setOption('hasValue', value);
    }
    get icon() {
        return this._getOption('icon');
    }
    set icon(value) {
        this._setOption('icon', value);
    }
    get name() {
        return this._getOption('name');
    }
    set name(value) {
        this._setOption('name', value);
    }
    get _optionPath() {
        return 'customOperations';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnDestroy() {
        this._deleteRemovedOptions(this._fullOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiTreeListCustomOperationComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxiTreeListCustomOperationComponent, isStandalone: true, selector: "dxi-tree-list-custom-operation", inputs: { calculateFilterExpression: "calculateFilterExpression", caption: "caption", customizeText: "customizeText", dataTypes: "dataTypes", editorTemplate: "editorTemplate", hasValue: "hasValue", icon: "icon", name: "name" }, providers: [
            NestedOptionHost,
            {
                provide: PROPERTY_TOKEN_customOperations,
                useExisting: DxiTreeListCustomOperationComponent,
            }
        ], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiTreeListCustomOperationComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxi-tree-list-custom-operation', template: '', imports: [DxIntegrationModule], providers: [
                        NestedOptionHost,
                        {
                            provide: PROPERTY_TOKEN_customOperations,
                            useExisting: DxiTreeListCustomOperationComponent,
                        }
                    ] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { calculateFilterExpression: [{
                type: Input
            }], caption: [{
                type: Input
            }], customizeText: [{
                type: Input
            }], dataTypes: [{
                type: Input
            }], editorTemplate: [{
                type: Input
            }], hasValue: [{
                type: Input
            }], icon: [{
                type: Input
            }], name: [{
                type: Input
            }] } });
class DxiTreeListCustomOperationModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiTreeListCustomOperationModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxiTreeListCustomOperationModule, imports: [DxiTreeListCustomOperationComponent], exports: [DxiTreeListCustomOperationComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiTreeListCustomOperationModule, imports: [DxiTreeListCustomOperationComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiTreeListCustomOperationModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxiTreeListCustomOperationComponent
                    ],
                    exports: [
                        DxiTreeListCustomOperationComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxiTreeListCustomRuleComponent extends CollectionNestedOption {
    get ignoreEmptyValue() {
        return this._getOption('ignoreEmptyValue');
    }
    set ignoreEmptyValue(value) {
        this._setOption('ignoreEmptyValue', value);
    }
    get message() {
        return this._getOption('message');
    }
    set message(value) {
        this._setOption('message', value);
    }
    get reevaluate() {
        return this._getOption('reevaluate');
    }
    set reevaluate(value) {
        this._setOption('reevaluate', value);
    }
    get type() {
        return this._getOption('type');
    }
    set type(value) {
        this._setOption('type', value);
    }
    get validationCallback() {
        return this._getOption('validationCallback');
    }
    set validationCallback(value) {
        this._setOption('validationCallback', value);
    }
    get _optionPath() {
        return 'validationRules';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
        this.type = 'custom';
    }
    ngOnDestroy() {
        this._deleteRemovedOptions(this._fullOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiTreeListCustomRuleComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxiTreeListCustomRuleComponent, isStandalone: true, selector: "dxi-tree-list-custom-rule", inputs: { ignoreEmptyValue: "ignoreEmptyValue", message: "message", reevaluate: "reevaluate", type: "type", validationCallback: "validationCallback" }, providers: [
            NestedOptionHost,
            {
                provide: PROPERTY_TOKEN_validationRules,
                useExisting: DxiTreeListCustomRuleComponent,
            }
        ], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiTreeListCustomRuleComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxi-tree-list-custom-rule', template: '', imports: [DxIntegrationModule], providers: [
                        NestedOptionHost,
                        {
                            provide: PROPERTY_TOKEN_validationRules,
                            useExisting: DxiTreeListCustomRuleComponent,
                        }
                    ] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { ignoreEmptyValue: [{
                type: Input
            }], message: [{
                type: Input
            }], reevaluate: [{
                type: Input
            }], type: [{
                type: Input
            }], validationCallback: [{
                type: Input
            }] } });
class DxiTreeListCustomRuleModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiTreeListCustomRuleModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxiTreeListCustomRuleModule, imports: [DxiTreeListCustomRuleComponent], exports: [DxiTreeListCustomRuleComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiTreeListCustomRuleModule, imports: [DxiTreeListCustomRuleComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiTreeListCustomRuleModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxiTreeListCustomRuleComponent
                    ],
                    exports: [
                        DxiTreeListCustomRuleComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoTreeListEditingTextsComponent extends NestedOption {
    get addRow() {
        return this._getOption('addRow');
    }
    set addRow(value) {
        this._setOption('addRow', value);
    }
    get addRowToNode() {
        return this._getOption('addRowToNode');
    }
    set addRowToNode(value) {
        this._setOption('addRowToNode', value);
    }
    get cancelAllChanges() {
        return this._getOption('cancelAllChanges');
    }
    set cancelAllChanges(value) {
        this._setOption('cancelAllChanges', value);
    }
    get cancelRowChanges() {
        return this._getOption('cancelRowChanges');
    }
    set cancelRowChanges(value) {
        this._setOption('cancelRowChanges', value);
    }
    get confirmDeleteMessage() {
        return this._getOption('confirmDeleteMessage');
    }
    set confirmDeleteMessage(value) {
        this._setOption('confirmDeleteMessage', value);
    }
    get confirmDeleteTitle() {
        return this._getOption('confirmDeleteTitle');
    }
    set confirmDeleteTitle(value) {
        this._setOption('confirmDeleteTitle', value);
    }
    get deleteRow() {
        return this._getOption('deleteRow');
    }
    set deleteRow(value) {
        this._setOption('deleteRow', value);
    }
    get editRow() {
        return this._getOption('editRow');
    }
    set editRow(value) {
        this._setOption('editRow', value);
    }
    get saveAllChanges() {
        return this._getOption('saveAllChanges');
    }
    set saveAllChanges(value) {
        this._setOption('saveAllChanges', value);
    }
    get saveRowChanges() {
        return this._getOption('saveRowChanges');
    }
    set saveRowChanges(value) {
        this._setOption('saveRowChanges', value);
    }
    get undeleteRow() {
        return this._getOption('undeleteRow');
    }
    set undeleteRow(value) {
        this._setOption('undeleteRow', value);
    }
    get validationCancelChanges() {
        return this._getOption('validationCancelChanges');
    }
    set validationCancelChanges(value) {
        this._setOption('validationCancelChanges', value);
    }
    get _optionPath() {
        return 'texts';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListEditingTextsComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoTreeListEditingTextsComponent, isStandalone: true, selector: "dxo-tree-list-editing-texts", inputs: { addRow: "addRow", addRowToNode: "addRowToNode", cancelAllChanges: "cancelAllChanges", cancelRowChanges: "cancelRowChanges", confirmDeleteMessage: "confirmDeleteMessage", confirmDeleteTitle: "confirmDeleteTitle", deleteRow: "deleteRow", editRow: "editRow", saveAllChanges: "saveAllChanges", saveRowChanges: "saveRowChanges", undeleteRow: "undeleteRow", validationCancelChanges: "validationCancelChanges" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListEditingTextsComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-tree-list-editing-texts', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { addRow: [{
                type: Input
            }], addRowToNode: [{
                type: Input
            }], cancelAllChanges: [{
                type: Input
            }], cancelRowChanges: [{
                type: Input
            }], confirmDeleteMessage: [{
                type: Input
            }], confirmDeleteTitle: [{
                type: Input
            }], deleteRow: [{
                type: Input
            }], editRow: [{
                type: Input
            }], saveAllChanges: [{
                type: Input
            }], saveRowChanges: [{
                type: Input
            }], undeleteRow: [{
                type: Input
            }], validationCancelChanges: [{
                type: Input
            }] } });
class DxoTreeListEditingTextsModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListEditingTextsModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListEditingTextsModule, imports: [DxoTreeListEditingTextsComponent], exports: [DxoTreeListEditingTextsComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListEditingTextsModule, imports: [DxoTreeListEditingTextsComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListEditingTextsModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoTreeListEditingTextsComponent
                    ],
                    exports: [
                        DxoTreeListEditingTextsComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoTreeListEditingComponent extends NestedOption {
    set _changesContentChildren(value) {
        this.setChildren('changes', value);
    }
    get allowAdding() {
        return this._getOption('allowAdding');
    }
    set allowAdding(value) {
        this._setOption('allowAdding', value);
    }
    get allowDeleting() {
        return this._getOption('allowDeleting');
    }
    set allowDeleting(value) {
        this._setOption('allowDeleting', value);
    }
    get allowUpdating() {
        return this._getOption('allowUpdating');
    }
    set allowUpdating(value) {
        this._setOption('allowUpdating', value);
    }
    get changes() {
        return this._getOption('changes');
    }
    set changes(value) {
        this._setOption('changes', value);
    }
    get confirmDelete() {
        return this._getOption('confirmDelete');
    }
    set confirmDelete(value) {
        this._setOption('confirmDelete', value);
    }
    get editColumnName() {
        return this._getOption('editColumnName');
    }
    set editColumnName(value) {
        this._setOption('editColumnName', value);
    }
    get editRowKey() {
        return this._getOption('editRowKey');
    }
    set editRowKey(value) {
        this._setOption('editRowKey', value);
    }
    get form() {
        return this._getOption('form');
    }
    set form(value) {
        this._setOption('form', value);
    }
    get mode() {
        return this._getOption('mode');
    }
    set mode(value) {
        this._setOption('mode', value);
    }
    get popup() {
        return this._getOption('popup');
    }
    set popup(value) {
        this._setOption('popup', value);
    }
    get refreshMode() {
        return this._getOption('refreshMode');
    }
    set refreshMode(value) {
        this._setOption('refreshMode', value);
    }
    get selectTextOnEditStart() {
        return this._getOption('selectTextOnEditStart');
    }
    set selectTextOnEditStart(value) {
        this._setOption('selectTextOnEditStart', value);
    }
    get startEditAction() {
        return this._getOption('startEditAction');
    }
    set startEditAction(value) {
        this._setOption('startEditAction', value);
    }
    get texts() {
        return this._getOption('texts');
    }
    set texts(value) {
        this._setOption('texts', value);
    }
    get useIcons() {
        return this._getOption('useIcons');
    }
    set useIcons(value) {
        this._setOption('useIcons', value);
    }
    get _optionPath() {
        return 'editing';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        this._createEventEmitters([
            { emit: 'changesChange' },
            { emit: 'editColumnNameChange' },
            { emit: 'editRowKeyChange' }
        ]);
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListEditingComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoTreeListEditingComponent, isStandalone: true, selector: "dxo-tree-list-editing", inputs: { allowAdding: "allowAdding", allowDeleting: "allowDeleting", allowUpdating: "allowUpdating", changes: "changes", confirmDelete: "confirmDelete", editColumnName: "editColumnName", editRowKey: "editRowKey", form: "form", mode: "mode", popup: "popup", refreshMode: "refreshMode", selectTextOnEditStart: "selectTextOnEditStart", startEditAction: "startEditAction", texts: "texts", useIcons: "useIcons" }, outputs: { changesChange: "changesChange", editColumnNameChange: "editColumnNameChange", editRowKeyChange: "editRowKeyChange" }, providers: [NestedOptionHost], queries: [{ propertyName: "_changesContentChildren", predicate: PROPERTY_TOKEN_changes }], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListEditingComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-tree-list-editing', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { _changesContentChildren: [{
                type: ContentChildren,
                args: [PROPERTY_TOKEN_changes]
            }], allowAdding: [{
                type: Input
            }], allowDeleting: [{
                type: Input
            }], allowUpdating: [{
                type: Input
            }], changes: [{
                type: Input
            }], confirmDelete: [{
                type: Input
            }], editColumnName: [{
                type: Input
            }], editRowKey: [{
                type: Input
            }], form: [{
                type: Input
            }], mode: [{
                type: Input
            }], popup: [{
                type: Input
            }], refreshMode: [{
                type: Input
            }], selectTextOnEditStart: [{
                type: Input
            }], startEditAction: [{
                type: Input
            }], texts: [{
                type: Input
            }], useIcons: [{
                type: Input
            }], changesChange: [{
                type: Output
            }], editColumnNameChange: [{
                type: Output
            }], editRowKeyChange: [{
                type: Output
            }] } });
class DxoTreeListEditingModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListEditingModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListEditingModule, imports: [DxoTreeListEditingComponent], exports: [DxoTreeListEditingComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListEditingModule, imports: [DxoTreeListEditingComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListEditingModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoTreeListEditingComponent
                    ],
                    exports: [
                        DxoTreeListEditingComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxiTreeListEditorOptionsButtonComponent extends CollectionNestedOption {
    get location() {
        return this._getOption('location');
    }
    set location(value) {
        this._setOption('location', value);
    }
    get name() {
        return this._getOption('name');
    }
    set name(value) {
        this._setOption('name', value);
    }
    get options() {
        return this._getOption('options');
    }
    set options(value) {
        this._setOption('options', value);
    }
    get _optionPath() {
        return 'buttons';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnDestroy() {
        this._deleteRemovedOptions(this._fullOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiTreeListEditorOptionsButtonComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxiTreeListEditorOptionsButtonComponent, isStandalone: true, selector: "dxi-tree-list-editor-options-button", inputs: { location: "location", name: "name", options: "options" }, providers: [
            NestedOptionHost,
            {
                provide: PROPERTY_TOKEN_buttons,
                useExisting: DxiTreeListEditorOptionsButtonComponent,
            }
        ], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiTreeListEditorOptionsButtonComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxi-tree-list-editor-options-button', template: '', imports: [DxIntegrationModule], providers: [
                        NestedOptionHost,
                        {
                            provide: PROPERTY_TOKEN_buttons,
                            useExisting: DxiTreeListEditorOptionsButtonComponent,
                        }
                    ] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { location: [{
                type: Input
            }], name: [{
                type: Input
            }], options: [{
                type: Input
            }] } });
class DxiTreeListEditorOptionsButtonModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiTreeListEditorOptionsButtonModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxiTreeListEditorOptionsButtonModule, imports: [DxiTreeListEditorOptionsButtonComponent], exports: [DxiTreeListEditorOptionsButtonComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiTreeListEditorOptionsButtonModule, imports: [DxiTreeListEditorOptionsButtonComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiTreeListEditorOptionsButtonModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxiTreeListEditorOptionsButtonComponent
                    ],
                    exports: [
                        DxiTreeListEditorOptionsButtonComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoTreeListEditorOptionsComponent extends NestedOption {
    set _buttonsContentChildren(value) {
        this.setChildren('buttons', value);
    }
    get accessKey() {
        return this._getOption('accessKey');
    }
    set accessKey(value) {
        this._setOption('accessKey', value);
    }
    get activeStateEnabled() {
        return this._getOption('activeStateEnabled');
    }
    set activeStateEnabled(value) {
        this._setOption('activeStateEnabled', value);
    }
    get buttons() {
        return this._getOption('buttons');
    }
    set buttons(value) {
        this._setOption('buttons', value);
    }
    get disabled() {
        return this._getOption('disabled');
    }
    set disabled(value) {
        this._setOption('disabled', value);
    }
    get elementAttr() {
        return this._getOption('elementAttr');
    }
    set elementAttr(value) {
        this._setOption('elementAttr', value);
    }
    get focusStateEnabled() {
        return this._getOption('focusStateEnabled');
    }
    set focusStateEnabled(value) {
        this._setOption('focusStateEnabled', value);
    }
    get height() {
        return this._getOption('height');
    }
    set height(value) {
        this._setOption('height', value);
    }
    get hint() {
        return this._getOption('hint');
    }
    set hint(value) {
        this._setOption('hint', value);
    }
    get hoverStateEnabled() {
        return this._getOption('hoverStateEnabled');
    }
    set hoverStateEnabled(value) {
        this._setOption('hoverStateEnabled', value);
    }
    get inputAttr() {
        return this._getOption('inputAttr');
    }
    set inputAttr(value) {
        this._setOption('inputAttr', value);
    }
    get isDirty() {
        return this._getOption('isDirty');
    }
    set isDirty(value) {
        this._setOption('isDirty', value);
    }
    get isValid() {
        return this._getOption('isValid');
    }
    set isValid(value) {
        this._setOption('isValid', value);
    }
    get label() {
        return this._getOption('label');
    }
    set label(value) {
        this._setOption('label', value);
    }
    get labelMode() {
        return this._getOption('labelMode');
    }
    set labelMode(value) {
        this._setOption('labelMode', value);
    }
    get mask() {
        return this._getOption('mask');
    }
    set mask(value) {
        this._setOption('mask', value);
    }
    get maskChar() {
        return this._getOption('maskChar');
    }
    set maskChar(value) {
        this._setOption('maskChar', value);
    }
    get maskInvalidMessage() {
        return this._getOption('maskInvalidMessage');
    }
    set maskInvalidMessage(value) {
        this._setOption('maskInvalidMessage', value);
    }
    get maskRules() {
        return this._getOption('maskRules');
    }
    set maskRules(value) {
        this._setOption('maskRules', value);
    }
    get maxLength() {
        return this._getOption('maxLength');
    }
    set maxLength(value) {
        this._setOption('maxLength', value);
    }
    get mode() {
        return this._getOption('mode');
    }
    set mode(value) {
        this._setOption('mode', value);
    }
    get name() {
        return this._getOption('name');
    }
    set name(value) {
        this._setOption('name', value);
    }
    get onChange() {
        return this._getOption('onChange');
    }
    set onChange(value) {
        this._setOption('onChange', value);
    }
    get onContentReady() {
        return this._getOption('onContentReady');
    }
    set onContentReady(value) {
        this._setOption('onContentReady', value);
    }
    get onCopy() {
        return this._getOption('onCopy');
    }
    set onCopy(value) {
        this._setOption('onCopy', value);
    }
    get onCut() {
        return this._getOption('onCut');
    }
    set onCut(value) {
        this._setOption('onCut', value);
    }
    get onDisposing() {
        return this._getOption('onDisposing');
    }
    set onDisposing(value) {
        this._setOption('onDisposing', value);
    }
    get onEnterKey() {
        return this._getOption('onEnterKey');
    }
    set onEnterKey(value) {
        this._setOption('onEnterKey', value);
    }
    get onFocusIn() {
        return this._getOption('onFocusIn');
    }
    set onFocusIn(value) {
        this._setOption('onFocusIn', value);
    }
    get onFocusOut() {
        return this._getOption('onFocusOut');
    }
    set onFocusOut(value) {
        this._setOption('onFocusOut', value);
    }
    get onInitialized() {
        return this._getOption('onInitialized');
    }
    set onInitialized(value) {
        this._setOption('onInitialized', value);
    }
    get onInput() {
        return this._getOption('onInput');
    }
    set onInput(value) {
        this._setOption('onInput', value);
    }
    get onKeyDown() {
        return this._getOption('onKeyDown');
    }
    set onKeyDown(value) {
        this._setOption('onKeyDown', value);
    }
    get onKeyUp() {
        return this._getOption('onKeyUp');
    }
    set onKeyUp(value) {
        this._setOption('onKeyUp', value);
    }
    get onOptionChanged() {
        return this._getOption('onOptionChanged');
    }
    set onOptionChanged(value) {
        this._setOption('onOptionChanged', value);
    }
    get onPaste() {
        return this._getOption('onPaste');
    }
    set onPaste(value) {
        this._setOption('onPaste', value);
    }
    get onValueChanged() {
        return this._getOption('onValueChanged');
    }
    set onValueChanged(value) {
        this._setOption('onValueChanged', value);
    }
    get placeholder() {
        return this._getOption('placeholder');
    }
    set placeholder(value) {
        this._setOption('placeholder', value);
    }
    get readOnly() {
        return this._getOption('readOnly');
    }
    set readOnly(value) {
        this._setOption('readOnly', value);
    }
    get rtlEnabled() {
        return this._getOption('rtlEnabled');
    }
    set rtlEnabled(value) {
        this._setOption('rtlEnabled', value);
    }
    get showClearButton() {
        return this._getOption('showClearButton');
    }
    set showClearButton(value) {
        this._setOption('showClearButton', value);
    }
    get showMaskMode() {
        return this._getOption('showMaskMode');
    }
    set showMaskMode(value) {
        this._setOption('showMaskMode', value);
    }
    get spellcheck() {
        return this._getOption('spellcheck');
    }
    set spellcheck(value) {
        this._setOption('spellcheck', value);
    }
    get stylingMode() {
        return this._getOption('stylingMode');
    }
    set stylingMode(value) {
        this._setOption('stylingMode', value);
    }
    get tabIndex() {
        return this._getOption('tabIndex');
    }
    set tabIndex(value) {
        this._setOption('tabIndex', value);
    }
    get text() {
        return this._getOption('text');
    }
    set text(value) {
        this._setOption('text', value);
    }
    get useMaskedValue() {
        return this._getOption('useMaskedValue');
    }
    set useMaskedValue(value) {
        this._setOption('useMaskedValue', value);
    }
    get validationError() {
        return this._getOption('validationError');
    }
    set validationError(value) {
        this._setOption('validationError', value);
    }
    get validationErrors() {
        return this._getOption('validationErrors');
    }
    set validationErrors(value) {
        this._setOption('validationErrors', value);
    }
    get validationMessageMode() {
        return this._getOption('validationMessageMode');
    }
    set validationMessageMode(value) {
        this._setOption('validationMessageMode', value);
    }
    get validationMessagePosition() {
        return this._getOption('validationMessagePosition');
    }
    set validationMessagePosition(value) {
        this._setOption('validationMessagePosition', value);
    }
    get validationStatus() {
        return this._getOption('validationStatus');
    }
    set validationStatus(value) {
        this._setOption('validationStatus', value);
    }
    get value() {
        return this._getOption('value');
    }
    set value(value) {
        this._setOption('value', value);
    }
    get valueChangeEvent() {
        return this._getOption('valueChangeEvent');
    }
    set valueChangeEvent(value) {
        this._setOption('valueChangeEvent', value);
    }
    get visible() {
        return this._getOption('visible');
    }
    set visible(value) {
        this._setOption('visible', value);
    }
    get width() {
        return this._getOption('width');
    }
    set width(value) {
        this._setOption('width', value);
    }
    get _optionPath() {
        return 'editorOptions';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        this._createEventEmitters([
            { emit: 'valueChange' }
        ]);
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListEditorOptionsComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoTreeListEditorOptionsComponent, isStandalone: true, selector: "dxo-tree-list-editor-options", inputs: { accessKey: "accessKey", activeStateEnabled: "activeStateEnabled", buttons: "buttons", disabled: "disabled", elementAttr: "elementAttr", focusStateEnabled: "focusStateEnabled", height: "height", hint: "hint", hoverStateEnabled: "hoverStateEnabled", inputAttr: "inputAttr", isDirty: "isDirty", isValid: "isValid", label: "label", labelMode: "labelMode", mask: "mask", maskChar: "maskChar", maskInvalidMessage: "maskInvalidMessage", maskRules: "maskRules", maxLength: "maxLength", mode: "mode", name: "name", onChange: "onChange", onContentReady: "onContentReady", onCopy: "onCopy", onCut: "onCut", onDisposing: "onDisposing", onEnterKey: "onEnterKey", onFocusIn: "onFocusIn", onFocusOut: "onFocusOut", onInitialized: "onInitialized", onInput: "onInput", onKeyDown: "onKeyDown", onKeyUp: "onKeyUp", onOptionChanged: "onOptionChanged", onPaste: "onPaste", onValueChanged: "onValueChanged", placeholder: "placeholder", readOnly: "readOnly", rtlEnabled: "rtlEnabled", showClearButton: "showClearButton", showMaskMode: "showMaskMode", spellcheck: "spellcheck", stylingMode: "stylingMode", tabIndex: "tabIndex", text: "text", useMaskedValue: "useMaskedValue", validationError: "validationError", validationErrors: "validationErrors", validationMessageMode: "validationMessageMode", validationMessagePosition: "validationMessagePosition", validationStatus: "validationStatus", value: "value", valueChangeEvent: "valueChangeEvent", visible: "visible", width: "width" }, outputs: { valueChange: "valueChange" }, providers: [NestedOptionHost], queries: [{ propertyName: "_buttonsContentChildren", predicate: PROPERTY_TOKEN_buttons }], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListEditorOptionsComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-tree-list-editor-options', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { _buttonsContentChildren: [{
                type: ContentChildren,
                args: [PROPERTY_TOKEN_buttons]
            }], accessKey: [{
                type: Input
            }], activeStateEnabled: [{
                type: Input
            }], buttons: [{
                type: Input
            }], disabled: [{
                type: Input
            }], elementAttr: [{
                type: Input
            }], focusStateEnabled: [{
                type: Input
            }], height: [{
                type: Input
            }], hint: [{
                type: Input
            }], hoverStateEnabled: [{
                type: Input
            }], inputAttr: [{
                type: Input
            }], isDirty: [{
                type: Input
            }], isValid: [{
                type: Input
            }], label: [{
                type: Input
            }], labelMode: [{
                type: Input
            }], mask: [{
                type: Input
            }], maskChar: [{
                type: Input
            }], maskInvalidMessage: [{
                type: Input
            }], maskRules: [{
                type: Input
            }], maxLength: [{
                type: Input
            }], mode: [{
                type: Input
            }], name: [{
                type: Input
            }], onChange: [{
                type: Input
            }], onContentReady: [{
                type: Input
            }], onCopy: [{
                type: Input
            }], onCut: [{
                type: Input
            }], onDisposing: [{
                type: Input
            }], onEnterKey: [{
                type: Input
            }], onFocusIn: [{
                type: Input
            }], onFocusOut: [{
                type: Input
            }], onInitialized: [{
                type: Input
            }], onInput: [{
                type: Input
            }], onKeyDown: [{
                type: Input
            }], onKeyUp: [{
                type: Input
            }], onOptionChanged: [{
                type: Input
            }], onPaste: [{
                type: Input
            }], onValueChanged: [{
                type: Input
            }], placeholder: [{
                type: Input
            }], readOnly: [{
                type: Input
            }], rtlEnabled: [{
                type: Input
            }], showClearButton: [{
                type: Input
            }], showMaskMode: [{
                type: Input
            }], spellcheck: [{
                type: Input
            }], stylingMode: [{
                type: Input
            }], tabIndex: [{
                type: Input
            }], text: [{
                type: Input
            }], useMaskedValue: [{
                type: Input
            }], validationError: [{
                type: Input
            }], validationErrors: [{
                type: Input
            }], validationMessageMode: [{
                type: Input
            }], validationMessagePosition: [{
                type: Input
            }], validationStatus: [{
                type: Input
            }], value: [{
                type: Input
            }], valueChangeEvent: [{
                type: Input
            }], visible: [{
                type: Input
            }], width: [{
                type: Input
            }], valueChange: [{
                type: Output
            }] } });
class DxoTreeListEditorOptionsModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListEditorOptionsModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListEditorOptionsModule, imports: [DxoTreeListEditorOptionsComponent], exports: [DxoTreeListEditorOptionsComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListEditorOptionsModule, imports: [DxoTreeListEditorOptionsComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListEditorOptionsModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoTreeListEditorOptionsComponent
                    ],
                    exports: [
                        DxoTreeListEditorOptionsComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxiTreeListEmailRuleComponent extends CollectionNestedOption {
    get ignoreEmptyValue() {
        return this._getOption('ignoreEmptyValue');
    }
    set ignoreEmptyValue(value) {
        this._setOption('ignoreEmptyValue', value);
    }
    get message() {
        return this._getOption('message');
    }
    set message(value) {
        this._setOption('message', value);
    }
    get type() {
        return this._getOption('type');
    }
    set type(value) {
        this._setOption('type', value);
    }
    get _optionPath() {
        return 'validationRules';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
        this.type = 'email';
    }
    ngOnDestroy() {
        this._deleteRemovedOptions(this._fullOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiTreeListEmailRuleComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxiTreeListEmailRuleComponent, isStandalone: true, selector: "dxi-tree-list-email-rule", inputs: { ignoreEmptyValue: "ignoreEmptyValue", message: "message", type: "type" }, providers: [
            NestedOptionHost,
            {
                provide: PROPERTY_TOKEN_validationRules,
                useExisting: DxiTreeListEmailRuleComponent,
            }
        ], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiTreeListEmailRuleComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxi-tree-list-email-rule', template: '', imports: [DxIntegrationModule], providers: [
                        NestedOptionHost,
                        {
                            provide: PROPERTY_TOKEN_validationRules,
                            useExisting: DxiTreeListEmailRuleComponent,
                        }
                    ] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { ignoreEmptyValue: [{
                type: Input
            }], message: [{
                type: Input
            }], type: [{
                type: Input
            }] } });
class DxiTreeListEmailRuleModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiTreeListEmailRuleModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxiTreeListEmailRuleModule, imports: [DxiTreeListEmailRuleComponent], exports: [DxiTreeListEmailRuleComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiTreeListEmailRuleModule, imports: [DxiTreeListEmailRuleComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiTreeListEmailRuleModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxiTreeListEmailRuleComponent
                    ],
                    exports: [
                        DxiTreeListEmailRuleComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxiTreeListEmptyItemComponent extends CollectionNestedOption {
    get colSpan() {
        return this._getOption('colSpan');
    }
    set colSpan(value) {
        this._setOption('colSpan', value);
    }
    get cssClass() {
        return this._getOption('cssClass');
    }
    set cssClass(value) {
        this._setOption('cssClass', value);
    }
    get itemType() {
        return this._getOption('itemType');
    }
    set itemType(value) {
        this._setOption('itemType', value);
    }
    get name() {
        return this._getOption('name');
    }
    set name(value) {
        this._setOption('name', value);
    }
    get visible() {
        return this._getOption('visible');
    }
    set visible(value) {
        this._setOption('visible', value);
    }
    get visibleIndex() {
        return this._getOption('visibleIndex');
    }
    set visibleIndex(value) {
        this._setOption('visibleIndex', value);
    }
    get _optionPath() {
        return 'items';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
        this.itemType = 'empty';
    }
    ngOnDestroy() {
        this._deleteRemovedOptions(this._fullOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiTreeListEmptyItemComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxiTreeListEmptyItemComponent, isStandalone: true, selector: "dxi-tree-list-empty-item", inputs: { colSpan: "colSpan", cssClass: "cssClass", itemType: "itemType", name: "name", visible: "visible", visibleIndex: "visibleIndex" }, providers: [
            NestedOptionHost,
            {
                provide: PROPERTY_TOKEN_items,
                useExisting: DxiTreeListEmptyItemComponent,
            }
        ], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiTreeListEmptyItemComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxi-tree-list-empty-item', template: '', imports: [DxIntegrationModule], providers: [
                        NestedOptionHost,
                        {
                            provide: PROPERTY_TOKEN_items,
                            useExisting: DxiTreeListEmptyItemComponent,
                        }
                    ] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { colSpan: [{
                type: Input
            }], cssClass: [{
                type: Input
            }], itemType: [{
                type: Input
            }], name: [{
                type: Input
            }], visible: [{
                type: Input
            }], visibleIndex: [{
                type: Input
            }] } });
class DxiTreeListEmptyItemModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiTreeListEmptyItemModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxiTreeListEmptyItemModule, imports: [DxiTreeListEmptyItemComponent], exports: [DxiTreeListEmptyItemComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiTreeListEmptyItemModule, imports: [DxiTreeListEmptyItemComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiTreeListEmptyItemModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxiTreeListEmptyItemComponent
                    ],
                    exports: [
                        DxiTreeListEmptyItemComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxiTreeListFieldComponent extends CollectionNestedOption {
    get calculateFilterExpression() {
        return this._getOption('calculateFilterExpression');
    }
    set calculateFilterExpression(value) {
        this._setOption('calculateFilterExpression', value);
    }
    get caption() {
        return this._getOption('caption');
    }
    set caption(value) {
        this._setOption('caption', value);
    }
    get customizeText() {
        return this._getOption('customizeText');
    }
    set customizeText(value) {
        this._setOption('customizeText', value);
    }
    get dataField() {
        return this._getOption('dataField');
    }
    set dataField(value) {
        this._setOption('dataField', value);
    }
    get dataType() {
        return this._getOption('dataType');
    }
    set dataType(value) {
        this._setOption('dataType', value);
    }
    get editorOptions() {
        return this._getOption('editorOptions');
    }
    set editorOptions(value) {
        this._setOption('editorOptions', value);
    }
    get editorTemplate() {
        return this._getOption('editorTemplate');
    }
    set editorTemplate(value) {
        this._setOption('editorTemplate', value);
    }
    get falseText() {
        return this._getOption('falseText');
    }
    set falseText(value) {
        this._setOption('falseText', value);
    }
    get filterOperations() {
        return this._getOption('filterOperations');
    }
    set filterOperations(value) {
        this._setOption('filterOperations', value);
    }
    get format() {
        return this._getOption('format');
    }
    set format(value) {
        this._setOption('format', value);
    }
    get lookup() {
        return this._getOption('lookup');
    }
    set lookup(value) {
        this._setOption('lookup', value);
    }
    get name() {
        return this._getOption('name');
    }
    set name(value) {
        this._setOption('name', value);
    }
    get trueText() {
        return this._getOption('trueText');
    }
    set trueText(value) {
        this._setOption('trueText', value);
    }
    get _optionPath() {
        return 'fields';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnDestroy() {
        this._deleteRemovedOptions(this._fullOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiTreeListFieldComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxiTreeListFieldComponent, isStandalone: true, selector: "dxi-tree-list-field", inputs: { calculateFilterExpression: "calculateFilterExpression", caption: "caption", customizeText: "customizeText", dataField: "dataField", dataType: "dataType", editorOptions: "editorOptions", editorTemplate: "editorTemplate", falseText: "falseText", filterOperations: "filterOperations", format: "format", lookup: "lookup", name: "name", trueText: "trueText" }, providers: [
            NestedOptionHost,
            {
                provide: PROPERTY_TOKEN_fields,
                useExisting: DxiTreeListFieldComponent,
            }
        ], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiTreeListFieldComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxi-tree-list-field', template: '', imports: [DxIntegrationModule], providers: [
                        NestedOptionHost,
                        {
                            provide: PROPERTY_TOKEN_fields,
                            useExisting: DxiTreeListFieldComponent,
                        }
                    ] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { calculateFilterExpression: [{
                type: Input
            }], caption: [{
                type: Input
            }], customizeText: [{
                type: Input
            }], dataField: [{
                type: Input
            }], dataType: [{
                type: Input
            }], editorOptions: [{
                type: Input
            }], editorTemplate: [{
                type: Input
            }], falseText: [{
                type: Input
            }], filterOperations: [{
                type: Input
            }], format: [{
                type: Input
            }], lookup: [{
                type: Input
            }], name: [{
                type: Input
            }], trueText: [{
                type: Input
            }] } });
class DxiTreeListFieldModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiTreeListFieldModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxiTreeListFieldModule, imports: [DxiTreeListFieldComponent], exports: [DxiTreeListFieldComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiTreeListFieldModule, imports: [DxiTreeListFieldComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiTreeListFieldModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxiTreeListFieldComponent
                    ],
                    exports: [
                        DxiTreeListFieldComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoTreeListFieldLookupComponent extends NestedOption {
    get allowClearing() {
        return this._getOption('allowClearing');
    }
    set allowClearing(value) {
        this._setOption('allowClearing', value);
    }
    get dataSource() {
        return this._getOption('dataSource');
    }
    set dataSource(value) {
        this._setOption('dataSource', value);
    }
    get displayExpr() {
        return this._getOption('displayExpr');
    }
    set displayExpr(value) {
        this._setOption('displayExpr', value);
    }
    get valueExpr() {
        return this._getOption('valueExpr');
    }
    set valueExpr(value) {
        this._setOption('valueExpr', value);
    }
    get _optionPath() {
        return 'lookup';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListFieldLookupComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoTreeListFieldLookupComponent, isStandalone: true, selector: "dxo-tree-list-field-lookup", inputs: { allowClearing: "allowClearing", dataSource: "dataSource", displayExpr: "displayExpr", valueExpr: "valueExpr" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListFieldLookupComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-tree-list-field-lookup', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { allowClearing: [{
                type: Input
            }], dataSource: [{
                type: Input
            }], displayExpr: [{
                type: Input
            }], valueExpr: [{
                type: Input
            }] } });
class DxoTreeListFieldLookupModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListFieldLookupModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListFieldLookupModule, imports: [DxoTreeListFieldLookupComponent], exports: [DxoTreeListFieldLookupComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListFieldLookupModule, imports: [DxoTreeListFieldLookupComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListFieldLookupModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoTreeListFieldLookupComponent
                    ],
                    exports: [
                        DxoTreeListFieldLookupComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoTreeListFilterBuilderPopupComponent extends NestedOption {
    set _toolbarItemsContentChildren(value) {
        this.setChildren('toolbarItems', value);
    }
    get accessKey() {
        return this._getOption('accessKey');
    }
    set accessKey(value) {
        this._setOption('accessKey', value);
    }
    get animation() {
        return this._getOption('animation');
    }
    set animation(value) {
        this._setOption('animation', value);
    }
    get container() {
        return this._getOption('container');
    }
    set container(value) {
        this._setOption('container', value);
    }
    get contentTemplate() {
        return this._getOption('contentTemplate');
    }
    set contentTemplate(value) {
        this._setOption('contentTemplate', value);
    }
    get deferRendering() {
        return this._getOption('deferRendering');
    }
    set deferRendering(value) {
        this._setOption('deferRendering', value);
    }
    get disabled() {
        return this._getOption('disabled');
    }
    set disabled(value) {
        this._setOption('disabled', value);
    }
    get dragAndResizeArea() {
        return this._getOption('dragAndResizeArea');
    }
    set dragAndResizeArea(value) {
        this._setOption('dragAndResizeArea', value);
    }
    get dragEnabled() {
        return this._getOption('dragEnabled');
    }
    set dragEnabled(value) {
        this._setOption('dragEnabled', value);
    }
    get dragOutsideBoundary() {
        return this._getOption('dragOutsideBoundary');
    }
    set dragOutsideBoundary(value) {
        this._setOption('dragOutsideBoundary', value);
    }
    get enableBodyScroll() {
        return this._getOption('enableBodyScroll');
    }
    set enableBodyScroll(value) {
        this._setOption('enableBodyScroll', value);
    }
    get focusStateEnabled() {
        return this._getOption('focusStateEnabled');
    }
    set focusStateEnabled(value) {
        this._setOption('focusStateEnabled', value);
    }
    get fullScreen() {
        return this._getOption('fullScreen');
    }
    set fullScreen(value) {
        this._setOption('fullScreen', value);
    }
    get height() {
        return this._getOption('height');
    }
    set height(value) {
        this._setOption('height', value);
    }
    get hideOnOutsideClick() {
        return this._getOption('hideOnOutsideClick');
    }
    set hideOnOutsideClick(value) {
        this._setOption('hideOnOutsideClick', value);
    }
    get hideOnParentScroll() {
        return this._getOption('hideOnParentScroll');
    }
    set hideOnParentScroll(value) {
        this._setOption('hideOnParentScroll', value);
    }
    get hint() {
        return this._getOption('hint');
    }
    set hint(value) {
        this._setOption('hint', value);
    }
    get hoverStateEnabled() {
        return this._getOption('hoverStateEnabled');
    }
    set hoverStateEnabled(value) {
        this._setOption('hoverStateEnabled', value);
    }
    get maxHeight() {
        return this._getOption('maxHeight');
    }
    set maxHeight(value) {
        this._setOption('maxHeight', value);
    }
    get maxWidth() {
        return this._getOption('maxWidth');
    }
    set maxWidth(value) {
        this._setOption('maxWidth', value);
    }
    get minHeight() {
        return this._getOption('minHeight');
    }
    set minHeight(value) {
        this._setOption('minHeight', value);
    }
    get minWidth() {
        return this._getOption('minWidth');
    }
    set minWidth(value) {
        this._setOption('minWidth', value);
    }
    get onContentReady() {
        return this._getOption('onContentReady');
    }
    set onContentReady(value) {
        this._setOption('onContentReady', value);
    }
    get onDisposing() {
        return this._getOption('onDisposing');
    }
    set onDisposing(value) {
        this._setOption('onDisposing', value);
    }
    get onHidden() {
        return this._getOption('onHidden');
    }
    set onHidden(value) {
        this._setOption('onHidden', value);
    }
    get onHiding() {
        return this._getOption('onHiding');
    }
    set onHiding(value) {
        this._setOption('onHiding', value);
    }
    get onInitialized() {
        return this._getOption('onInitialized');
    }
    set onInitialized(value) {
        this._setOption('onInitialized', value);
    }
    get onOptionChanged() {
        return this._getOption('onOptionChanged');
    }
    set onOptionChanged(value) {
        this._setOption('onOptionChanged', value);
    }
    get onResize() {
        return this._getOption('onResize');
    }
    set onResize(value) {
        this._setOption('onResize', value);
    }
    get onResizeEnd() {
        return this._getOption('onResizeEnd');
    }
    set onResizeEnd(value) {
        this._setOption('onResizeEnd', value);
    }
    get onResizeStart() {
        return this._getOption('onResizeStart');
    }
    set onResizeStart(value) {
        this._setOption('onResizeStart', value);
    }
    get onShowing() {
        return this._getOption('onShowing');
    }
    set onShowing(value) {
        this._setOption('onShowing', value);
    }
    get onShown() {
        return this._getOption('onShown');
    }
    set onShown(value) {
        this._setOption('onShown', value);
    }
    get onTitleRendered() {
        return this._getOption('onTitleRendered');
    }
    set onTitleRendered(value) {
        this._setOption('onTitleRendered', value);
    }
    get position() {
        return this._getOption('position');
    }
    set position(value) {
        this._setOption('position', value);
    }
    get resizeEnabled() {
        return this._getOption('resizeEnabled');
    }
    set resizeEnabled(value) {
        this._setOption('resizeEnabled', value);
    }
    get restorePosition() {
        return this._getOption('restorePosition');
    }
    set restorePosition(value) {
        this._setOption('restorePosition', value);
    }
    get rtlEnabled() {
        return this._getOption('rtlEnabled');
    }
    set rtlEnabled(value) {
        this._setOption('rtlEnabled', value);
    }
    get shading() {
        return this._getOption('shading');
    }
    set shading(value) {
        this._setOption('shading', value);
    }
    get shadingColor() {
        return this._getOption('shadingColor');
    }
    set shadingColor(value) {
        this._setOption('shadingColor', value);
    }
    get showCloseButton() {
        return this._getOption('showCloseButton');
    }
    set showCloseButton(value) {
        this._setOption('showCloseButton', value);
    }
    get showTitle() {
        return this._getOption('showTitle');
    }
    set showTitle(value) {
        this._setOption('showTitle', value);
    }
    get tabFocusLoopEnabled() {
        return this._getOption('tabFocusLoopEnabled');
    }
    set tabFocusLoopEnabled(value) {
        this._setOption('tabFocusLoopEnabled', value);
    }
    get tabIndex() {
        return this._getOption('tabIndex');
    }
    set tabIndex(value) {
        this._setOption('tabIndex', value);
    }
    get title() {
        return this._getOption('title');
    }
    set title(value) {
        this._setOption('title', value);
    }
    get titleTemplate() {
        return this._getOption('titleTemplate');
    }
    set titleTemplate(value) {
        this._setOption('titleTemplate', value);
    }
    get toolbarItems() {
        return this._getOption('toolbarItems');
    }
    set toolbarItems(value) {
        this._setOption('toolbarItems', value);
    }
    get visible() {
        return this._getOption('visible');
    }
    set visible(value) {
        this._setOption('visible', value);
    }
    get width() {
        return this._getOption('width');
    }
    set width(value) {
        this._setOption('width', value);
    }
    get wrapperAttr() {
        return this._getOption('wrapperAttr');
    }
    set wrapperAttr(value) {
        this._setOption('wrapperAttr', value);
    }
    get _optionPath() {
        return 'filterBuilderPopup';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        this._createEventEmitters([
            { emit: 'heightChange' },
            { emit: 'positionChange' },
            { emit: 'visibleChange' },
            { emit: 'widthChange' }
        ]);
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListFilterBuilderPopupComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoTreeListFilterBuilderPopupComponent, isStandalone: true, selector: "dxo-tree-list-filter-builder-popup", inputs: { accessKey: "accessKey", animation: "animation", container: "container", contentTemplate: "contentTemplate", deferRendering: "deferRendering", disabled: "disabled", dragAndResizeArea: "dragAndResizeArea", dragEnabled: "dragEnabled", dragOutsideBoundary: "dragOutsideBoundary", enableBodyScroll: "enableBodyScroll", focusStateEnabled: "focusStateEnabled", fullScreen: "fullScreen", height: "height", hideOnOutsideClick: "hideOnOutsideClick", hideOnParentScroll: "hideOnParentScroll", hint: "hint", hoverStateEnabled: "hoverStateEnabled", maxHeight: "maxHeight", maxWidth: "maxWidth", minHeight: "minHeight", minWidth: "minWidth", onContentReady: "onContentReady", onDisposing: "onDisposing", onHidden: "onHidden", onHiding: "onHiding", onInitialized: "onInitialized", onOptionChanged: "onOptionChanged", onResize: "onResize", onResizeEnd: "onResizeEnd", onResizeStart: "onResizeStart", onShowing: "onShowing", onShown: "onShown", onTitleRendered: "onTitleRendered", position: "position", resizeEnabled: "resizeEnabled", restorePosition: "restorePosition", rtlEnabled: "rtlEnabled", shading: "shading", shadingColor: "shadingColor", showCloseButton: "showCloseButton", showTitle: "showTitle", tabFocusLoopEnabled: "tabFocusLoopEnabled", tabIndex: "tabIndex", title: "title", titleTemplate: "titleTemplate", toolbarItems: "toolbarItems", visible: "visible", width: "width", wrapperAttr: "wrapperAttr" }, outputs: { heightChange: "heightChange", positionChange: "positionChange", visibleChange: "visibleChange", widthChange: "widthChange" }, providers: [NestedOptionHost], queries: [{ propertyName: "_toolbarItemsContentChildren", predicate: PROPERTY_TOKEN_toolbarItems }], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListFilterBuilderPopupComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-tree-list-filter-builder-popup', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { _toolbarItemsContentChildren: [{
                type: ContentChildren,
                args: [PROPERTY_TOKEN_toolbarItems]
            }], accessKey: [{
                type: Input
            }], animation: [{
                type: Input
            }], container: [{
                type: Input
            }], contentTemplate: [{
                type: Input
            }], deferRendering: [{
                type: Input
            }], disabled: [{
                type: Input
            }], dragAndResizeArea: [{
                type: Input
            }], dragEnabled: [{
                type: Input
            }], dragOutsideBoundary: [{
                type: Input
            }], enableBodyScroll: [{
                type: Input
            }], focusStateEnabled: [{
                type: Input
            }], fullScreen: [{
                type: Input
            }], height: [{
                type: Input
            }], hideOnOutsideClick: [{
                type: Input
            }], hideOnParentScroll: [{
                type: Input
            }], hint: [{
                type: Input
            }], hoverStateEnabled: [{
                type: Input
            }], maxHeight: [{
                type: Input
            }], maxWidth: [{
                type: Input
            }], minHeight: [{
                type: Input
            }], minWidth: [{
                type: Input
            }], onContentReady: [{
                type: Input
            }], onDisposing: [{
                type: Input
            }], onHidden: [{
                type: Input
            }], onHiding: [{
                type: Input
            }], onInitialized: [{
                type: Input
            }], onOptionChanged: [{
                type: Input
            }], onResize: [{
                type: Input
            }], onResizeEnd: [{
                type: Input
            }], onResizeStart: [{
                type: Input
            }], onShowing: [{
                type: Input
            }], onShown: [{
                type: Input
            }], onTitleRendered: [{
                type: Input
            }], position: [{
                type: Input
            }], resizeEnabled: [{
                type: Input
            }], restorePosition: [{
                type: Input
            }], rtlEnabled: [{
                type: Input
            }], shading: [{
                type: Input
            }], shadingColor: [{
                type: Input
            }], showCloseButton: [{
                type: Input
            }], showTitle: [{
                type: Input
            }], tabFocusLoopEnabled: [{
                type: Input
            }], tabIndex: [{
                type: Input
            }], title: [{
                type: Input
            }], titleTemplate: [{
                type: Input
            }], toolbarItems: [{
                type: Input
            }], visible: [{
                type: Input
            }], width: [{
                type: Input
            }], wrapperAttr: [{
                type: Input
            }], heightChange: [{
                type: Output
            }], positionChange: [{
                type: Output
            }], visibleChange: [{
                type: Output
            }], widthChange: [{
                type: Output
            }] } });
class DxoTreeListFilterBuilderPopupModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListFilterBuilderPopupModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListFilterBuilderPopupModule, imports: [DxoTreeListFilterBuilderPopupComponent], exports: [DxoTreeListFilterBuilderPopupComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListFilterBuilderPopupModule, imports: [DxoTreeListFilterBuilderPopupComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListFilterBuilderPopupModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoTreeListFilterBuilderPopupComponent
                    ],
                    exports: [
                        DxoTreeListFilterBuilderPopupComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoTreeListFilterBuilderComponent extends NestedOption {
    set _customOperationsContentChildren(value) {
        this.setChildren('customOperations', value);
    }
    set _fieldsContentChildren(value) {
        this.setChildren('fields', value);
    }
    get accessKey() {
        return this._getOption('accessKey');
    }
    set accessKey(value) {
        this._setOption('accessKey', value);
    }
    get activeStateEnabled() {
        return this._getOption('activeStateEnabled');
    }
    set activeStateEnabled(value) {
        this._setOption('activeStateEnabled', value);
    }
    get allowHierarchicalFields() {
        return this._getOption('allowHierarchicalFields');
    }
    set allowHierarchicalFields(value) {
        this._setOption('allowHierarchicalFields', value);
    }
    get customOperations() {
        return this._getOption('customOperations');
    }
    set customOperations(value) {
        this._setOption('customOperations', value);
    }
    get disabled() {
        return this._getOption('disabled');
    }
    set disabled(value) {
        this._setOption('disabled', value);
    }
    get elementAttr() {
        return this._getOption('elementAttr');
    }
    set elementAttr(value) {
        this._setOption('elementAttr', value);
    }
    get fields() {
        return this._getOption('fields');
    }
    set fields(value) {
        this._setOption('fields', value);
    }
    get filterOperationDescriptions() {
        return this._getOption('filterOperationDescriptions');
    }
    set filterOperationDescriptions(value) {
        this._setOption('filterOperationDescriptions', value);
    }
    get focusStateEnabled() {
        return this._getOption('focusStateEnabled');
    }
    set focusStateEnabled(value) {
        this._setOption('focusStateEnabled', value);
    }
    get groupOperationDescriptions() {
        return this._getOption('groupOperationDescriptions');
    }
    set groupOperationDescriptions(value) {
        this._setOption('groupOperationDescriptions', value);
    }
    get groupOperations() {
        return this._getOption('groupOperations');
    }
    set groupOperations(value) {
        this._setOption('groupOperations', value);
    }
    get height() {
        return this._getOption('height');
    }
    set height(value) {
        this._setOption('height', value);
    }
    get hint() {
        return this._getOption('hint');
    }
    set hint(value) {
        this._setOption('hint', value);
    }
    get hoverStateEnabled() {
        return this._getOption('hoverStateEnabled');
    }
    set hoverStateEnabled(value) {
        this._setOption('hoverStateEnabled', value);
    }
    get maxGroupLevel() {
        return this._getOption('maxGroupLevel');
    }
    set maxGroupLevel(value) {
        this._setOption('maxGroupLevel', value);
    }
    get onContentReady() {
        return this._getOption('onContentReady');
    }
    set onContentReady(value) {
        this._setOption('onContentReady', value);
    }
    get onDisposing() {
        return this._getOption('onDisposing');
    }
    set onDisposing(value) {
        this._setOption('onDisposing', value);
    }
    get onEditorPrepared() {
        return this._getOption('onEditorPrepared');
    }
    set onEditorPrepared(value) {
        this._setOption('onEditorPrepared', value);
    }
    get onEditorPreparing() {
        return this._getOption('onEditorPreparing');
    }
    set onEditorPreparing(value) {
        this._setOption('onEditorPreparing', value);
    }
    get onInitialized() {
        return this._getOption('onInitialized');
    }
    set onInitialized(value) {
        this._setOption('onInitialized', value);
    }
    get onOptionChanged() {
        return this._getOption('onOptionChanged');
    }
    set onOptionChanged(value) {
        this._setOption('onOptionChanged', value);
    }
    get onValueChanged() {
        return this._getOption('onValueChanged');
    }
    set onValueChanged(value) {
        this._setOption('onValueChanged', value);
    }
    get rtlEnabled() {
        return this._getOption('rtlEnabled');
    }
    set rtlEnabled(value) {
        this._setOption('rtlEnabled', value);
    }
    get tabIndex() {
        return this._getOption('tabIndex');
    }
    set tabIndex(value) {
        this._setOption('tabIndex', value);
    }
    get value() {
        return this._getOption('value');
    }
    set value(value) {
        this._setOption('value', value);
    }
    get visible() {
        return this._getOption('visible');
    }
    set visible(value) {
        this._setOption('visible', value);
    }
    get width() {
        return this._getOption('width');
    }
    set width(value) {
        this._setOption('width', value);
    }
    get _optionPath() {
        return 'filterBuilder';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        this._createEventEmitters([
            { emit: 'valueChange' }
        ]);
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListFilterBuilderComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoTreeListFilterBuilderComponent, isStandalone: true, selector: "dxo-tree-list-filter-builder", inputs: { accessKey: "accessKey", activeStateEnabled: "activeStateEnabled", allowHierarchicalFields: "allowHierarchicalFields", customOperations: "customOperations", disabled: "disabled", elementAttr: "elementAttr", fields: "fields", filterOperationDescriptions: "filterOperationDescriptions", focusStateEnabled: "focusStateEnabled", groupOperationDescriptions: "groupOperationDescriptions", groupOperations: "groupOperations", height: "height", hint: "hint", hoverStateEnabled: "hoverStateEnabled", maxGroupLevel: "maxGroupLevel", onContentReady: "onContentReady", onDisposing: "onDisposing", onEditorPrepared: "onEditorPrepared", onEditorPreparing: "onEditorPreparing", onInitialized: "onInitialized", onOptionChanged: "onOptionChanged", onValueChanged: "onValueChanged", rtlEnabled: "rtlEnabled", tabIndex: "tabIndex", value: "value", visible: "visible", width: "width" }, outputs: { valueChange: "valueChange" }, providers: [NestedOptionHost], queries: [{ propertyName: "_customOperationsContentChildren", predicate: PROPERTY_TOKEN_customOperations }, { propertyName: "_fieldsContentChildren", predicate: PROPERTY_TOKEN_fields }], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListFilterBuilderComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-tree-list-filter-builder', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { _customOperationsContentChildren: [{
                type: ContentChildren,
                args: [PROPERTY_TOKEN_customOperations]
            }], _fieldsContentChildren: [{
                type: ContentChildren,
                args: [PROPERTY_TOKEN_fields]
            }], accessKey: [{
                type: Input
            }], activeStateEnabled: [{
                type: Input
            }], allowHierarchicalFields: [{
                type: Input
            }], customOperations: [{
                type: Input
            }], disabled: [{
                type: Input
            }], elementAttr: [{
                type: Input
            }], fields: [{
                type: Input
            }], filterOperationDescriptions: [{
                type: Input
            }], focusStateEnabled: [{
                type: Input
            }], groupOperationDescriptions: [{
                type: Input
            }], groupOperations: [{
                type: Input
            }], height: [{
                type: Input
            }], hint: [{
                type: Input
            }], hoverStateEnabled: [{
                type: Input
            }], maxGroupLevel: [{
                type: Input
            }], onContentReady: [{
                type: Input
            }], onDisposing: [{
                type: Input
            }], onEditorPrepared: [{
                type: Input
            }], onEditorPreparing: [{
                type: Input
            }], onInitialized: [{
                type: Input
            }], onOptionChanged: [{
                type: Input
            }], onValueChanged: [{
                type: Input
            }], rtlEnabled: [{
                type: Input
            }], tabIndex: [{
                type: Input
            }], value: [{
                type: Input
            }], visible: [{
                type: Input
            }], width: [{
                type: Input
            }], valueChange: [{
                type: Output
            }] } });
class DxoTreeListFilterBuilderModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListFilterBuilderModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListFilterBuilderModule, imports: [DxoTreeListFilterBuilderComponent], exports: [DxoTreeListFilterBuilderComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListFilterBuilderModule, imports: [DxoTreeListFilterBuilderComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListFilterBuilderModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoTreeListFilterBuilderComponent
                    ],
                    exports: [
                        DxoTreeListFilterBuilderComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoTreeListFilterOperationDescriptionsComponent extends NestedOption {
    get between() {
        return this._getOption('between');
    }
    set between(value) {
        this._setOption('between', value);
    }
    get contains() {
        return this._getOption('contains');
    }
    set contains(value) {
        this._setOption('contains', value);
    }
    get endsWith() {
        return this._getOption('endsWith');
    }
    set endsWith(value) {
        this._setOption('endsWith', value);
    }
    get equal() {
        return this._getOption('equal');
    }
    set equal(value) {
        this._setOption('equal', value);
    }
    get greaterThan() {
        return this._getOption('greaterThan');
    }
    set greaterThan(value) {
        this._setOption('greaterThan', value);
    }
    get greaterThanOrEqual() {
        return this._getOption('greaterThanOrEqual');
    }
    set greaterThanOrEqual(value) {
        this._setOption('greaterThanOrEqual', value);
    }
    get isBlank() {
        return this._getOption('isBlank');
    }
    set isBlank(value) {
        this._setOption('isBlank', value);
    }
    get isNotBlank() {
        return this._getOption('isNotBlank');
    }
    set isNotBlank(value) {
        this._setOption('isNotBlank', value);
    }
    get lessThan() {
        return this._getOption('lessThan');
    }
    set lessThan(value) {
        this._setOption('lessThan', value);
    }
    get lessThanOrEqual() {
        return this._getOption('lessThanOrEqual');
    }
    set lessThanOrEqual(value) {
        this._setOption('lessThanOrEqual', value);
    }
    get notContains() {
        return this._getOption('notContains');
    }
    set notContains(value) {
        this._setOption('notContains', value);
    }
    get notEqual() {
        return this._getOption('notEqual');
    }
    set notEqual(value) {
        this._setOption('notEqual', value);
    }
    get startsWith() {
        return this._getOption('startsWith');
    }
    set startsWith(value) {
        this._setOption('startsWith', value);
    }
    get _optionPath() {
        return 'filterOperationDescriptions';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListFilterOperationDescriptionsComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoTreeListFilterOperationDescriptionsComponent, isStandalone: true, selector: "dxo-tree-list-filter-operation-descriptions", inputs: { between: "between", contains: "contains", endsWith: "endsWith", equal: "equal", greaterThan: "greaterThan", greaterThanOrEqual: "greaterThanOrEqual", isBlank: "isBlank", isNotBlank: "isNotBlank", lessThan: "lessThan", lessThanOrEqual: "lessThanOrEqual", notContains: "notContains", notEqual: "notEqual", startsWith: "startsWith" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListFilterOperationDescriptionsComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-tree-list-filter-operation-descriptions', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { between: [{
                type: Input
            }], contains: [{
                type: Input
            }], endsWith: [{
                type: Input
            }], equal: [{
                type: Input
            }], greaterThan: [{
                type: Input
            }], greaterThanOrEqual: [{
                type: Input
            }], isBlank: [{
                type: Input
            }], isNotBlank: [{
                type: Input
            }], lessThan: [{
                type: Input
            }], lessThanOrEqual: [{
                type: Input
            }], notContains: [{
                type: Input
            }], notEqual: [{
                type: Input
            }], startsWith: [{
                type: Input
            }] } });
class DxoTreeListFilterOperationDescriptionsModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListFilterOperationDescriptionsModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListFilterOperationDescriptionsModule, imports: [DxoTreeListFilterOperationDescriptionsComponent], exports: [DxoTreeListFilterOperationDescriptionsComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListFilterOperationDescriptionsModule, imports: [DxoTreeListFilterOperationDescriptionsComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListFilterOperationDescriptionsModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoTreeListFilterOperationDescriptionsComponent
                    ],
                    exports: [
                        DxoTreeListFilterOperationDescriptionsComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoTreeListFilterPanelTextsComponent extends NestedOption {
    get clearFilter() {
        return this._getOption('clearFilter');
    }
    set clearFilter(value) {
        this._setOption('clearFilter', value);
    }
    get createFilter() {
        return this._getOption('createFilter');
    }
    set createFilter(value) {
        this._setOption('createFilter', value);
    }
    get filterEnabledHint() {
        return this._getOption('filterEnabledHint');
    }
    set filterEnabledHint(value) {
        this._setOption('filterEnabledHint', value);
    }
    get _optionPath() {
        return 'texts';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListFilterPanelTextsComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoTreeListFilterPanelTextsComponent, isStandalone: true, selector: "dxo-tree-list-filter-panel-texts", inputs: { clearFilter: "clearFilter", createFilter: "createFilter", filterEnabledHint: "filterEnabledHint" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListFilterPanelTextsComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-tree-list-filter-panel-texts', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { clearFilter: [{
                type: Input
            }], createFilter: [{
                type: Input
            }], filterEnabledHint: [{
                type: Input
            }] } });
class DxoTreeListFilterPanelTextsModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListFilterPanelTextsModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListFilterPanelTextsModule, imports: [DxoTreeListFilterPanelTextsComponent], exports: [DxoTreeListFilterPanelTextsComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListFilterPanelTextsModule, imports: [DxoTreeListFilterPanelTextsComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListFilterPanelTextsModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoTreeListFilterPanelTextsComponent
                    ],
                    exports: [
                        DxoTreeListFilterPanelTextsComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoTreeListFilterPanelComponent extends NestedOption {
    get customizeText() {
        return this._getOption('customizeText');
    }
    set customizeText(value) {
        this._setOption('customizeText', value);
    }
    get filterEnabled() {
        return this._getOption('filterEnabled');
    }
    set filterEnabled(value) {
        this._setOption('filterEnabled', value);
    }
    get texts() {
        return this._getOption('texts');
    }
    set texts(value) {
        this._setOption('texts', value);
    }
    get visible() {
        return this._getOption('visible');
    }
    set visible(value) {
        this._setOption('visible', value);
    }
    get _optionPath() {
        return 'filterPanel';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        this._createEventEmitters([
            { emit: 'filterEnabledChange' }
        ]);
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListFilterPanelComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoTreeListFilterPanelComponent, isStandalone: true, selector: "dxo-tree-list-filter-panel", inputs: { customizeText: "customizeText", filterEnabled: "filterEnabled", texts: "texts", visible: "visible" }, outputs: { filterEnabledChange: "filterEnabledChange" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListFilterPanelComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-tree-list-filter-panel', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { customizeText: [{
                type: Input
            }], filterEnabled: [{
                type: Input
            }], texts: [{
                type: Input
            }], visible: [{
                type: Input
            }], filterEnabledChange: [{
                type: Output
            }] } });
class DxoTreeListFilterPanelModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListFilterPanelModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListFilterPanelModule, imports: [DxoTreeListFilterPanelComponent], exports: [DxoTreeListFilterPanelComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListFilterPanelModule, imports: [DxoTreeListFilterPanelComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListFilterPanelModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoTreeListFilterPanelComponent
                    ],
                    exports: [
                        DxoTreeListFilterPanelComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoTreeListFilterRowComponent extends NestedOption {
    get applyFilter() {
        return this._getOption('applyFilter');
    }
    set applyFilter(value) {
        this._setOption('applyFilter', value);
    }
    get applyFilterText() {
        return this._getOption('applyFilterText');
    }
    set applyFilterText(value) {
        this._setOption('applyFilterText', value);
    }
    get betweenEndText() {
        return this._getOption('betweenEndText');
    }
    set betweenEndText(value) {
        this._setOption('betweenEndText', value);
    }
    get betweenStartText() {
        return this._getOption('betweenStartText');
    }
    set betweenStartText(value) {
        this._setOption('betweenStartText', value);
    }
    get operationDescriptions() {
        return this._getOption('operationDescriptions');
    }
    set operationDescriptions(value) {
        this._setOption('operationDescriptions', value);
    }
    get resetOperationText() {
        return this._getOption('resetOperationText');
    }
    set resetOperationText(value) {
        this._setOption('resetOperationText', value);
    }
    get showAllText() {
        return this._getOption('showAllText');
    }
    set showAllText(value) {
        this._setOption('showAllText', value);
    }
    get showOperationChooser() {
        return this._getOption('showOperationChooser');
    }
    set showOperationChooser(value) {
        this._setOption('showOperationChooser', value);
    }
    get visible() {
        return this._getOption('visible');
    }
    set visible(value) {
        this._setOption('visible', value);
    }
    get _optionPath() {
        return 'filterRow';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListFilterRowComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoTreeListFilterRowComponent, isStandalone: true, selector: "dxo-tree-list-filter-row", inputs: { applyFilter: "applyFilter", applyFilterText: "applyFilterText", betweenEndText: "betweenEndText", betweenStartText: "betweenStartText", operationDescriptions: "operationDescriptions", resetOperationText: "resetOperationText", showAllText: "showAllText", showOperationChooser: "showOperationChooser", visible: "visible" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListFilterRowComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-tree-list-filter-row', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { applyFilter: [{
                type: Input
            }], applyFilterText: [{
                type: Input
            }], betweenEndText: [{
                type: Input
            }], betweenStartText: [{
                type: Input
            }], operationDescriptions: [{
                type: Input
            }], resetOperationText: [{
                type: Input
            }], showAllText: [{
                type: Input
            }], showOperationChooser: [{
                type: Input
            }], visible: [{
                type: Input
            }] } });
class DxoTreeListFilterRowModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListFilterRowModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListFilterRowModule, imports: [DxoTreeListFilterRowComponent], exports: [DxoTreeListFilterRowComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListFilterRowModule, imports: [DxoTreeListFilterRowComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListFilterRowModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoTreeListFilterRowComponent
                    ],
                    exports: [
                        DxoTreeListFilterRowComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoTreeListFormItemComponent extends NestedOption {
    set _validationRulesContentChildren(value) {
        this.setChildren('validationRules', value);
    }
    get aiOptions() {
        return this._getOption('aiOptions');
    }
    set aiOptions(value) {
        this._setOption('aiOptions', value);
    }
    get colSpan() {
        return this._getOption('colSpan');
    }
    set colSpan(value) {
        this._setOption('colSpan', value);
    }
    get cssClass() {
        return this._getOption('cssClass');
    }
    set cssClass(value) {
        this._setOption('cssClass', value);
    }
    get dataField() {
        return this._getOption('dataField');
    }
    set dataField(value) {
        this._setOption('dataField', value);
    }
    get editorOptions() {
        return this._getOption('editorOptions');
    }
    set editorOptions(value) {
        this._setOption('editorOptions', value);
    }
    get editorType() {
        return this._getOption('editorType');
    }
    set editorType(value) {
        this._setOption('editorType', value);
    }
    get helpText() {
        return this._getOption('helpText');
    }
    set helpText(value) {
        this._setOption('helpText', value);
    }
    get isRequired() {
        return this._getOption('isRequired');
    }
    set isRequired(value) {
        this._setOption('isRequired', value);
    }
    get itemType() {
        return this._getOption('itemType');
    }
    set itemType(value) {
        this._setOption('itemType', value);
    }
    get label() {
        return this._getOption('label');
    }
    set label(value) {
        this._setOption('label', value);
    }
    get name() {
        return this._getOption('name');
    }
    set name(value) {
        this._setOption('name', value);
    }
    get template() {
        return this._getOption('template');
    }
    set template(value) {
        this._setOption('template', value);
    }
    get validationRules() {
        return this._getOption('validationRules');
    }
    set validationRules(value) {
        this._setOption('validationRules', value);
    }
    get visible() {
        return this._getOption('visible');
    }
    set visible(value) {
        this._setOption('visible', value);
    }
    get visibleIndex() {
        return this._getOption('visibleIndex');
    }
    set visibleIndex(value) {
        this._setOption('visibleIndex', value);
    }
    get _optionPath() {
        return 'formItem';
    }
    constructor(parentOptionHost, optionHost, renderer, document, templateHost, element) {
        super();
        this.renderer = renderer;
        this.document = document;
        this.element = element;
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
        templateHost.setHost(this);
    }
    setTemplate(template) {
        this.template = template;
    }
    ngAfterViewInit() {
        extractTemplate(this, this.element, this.renderer, this.document);
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListFormItemComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }, { token: i0.Renderer2 }, { token: DOCUMENT }, { token: i1.DxTemplateHost, host: true }, { token: i0.ElementRef }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoTreeListFormItemComponent, isStandalone: true, selector: "dxo-tree-list-form-item", inputs: { aiOptions: "aiOptions", colSpan: "colSpan", cssClass: "cssClass", dataField: "dataField", editorOptions: "editorOptions", editorType: "editorType", helpText: "helpText", isRequired: "isRequired", itemType: "itemType", label: "label", name: "name", template: "template", validationRules: "validationRules", visible: "visible", visibleIndex: "visibleIndex" }, providers: [NestedOptionHost, DxTemplateHost], queries: [{ propertyName: "_validationRulesContentChildren", predicate: PROPERTY_TOKEN_validationRules }], usesInheritance: true, ngImport: i0, template: '<ng-content></ng-content>', isInline: true, styles: [":host{display:block}\n"], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListFormItemComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-tree-list-form-item', template: '<ng-content></ng-content>', imports: [DxIntegrationModule], providers: [NestedOptionHost, DxTemplateHost], styles: [":host{display:block}\n"] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }, { type: i0.Renderer2 }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [DOCUMENT]
                }] }, { type: i1.DxTemplateHost, decorators: [{
                    type: Host
                }] }, { type: i0.ElementRef }], propDecorators: { _validationRulesContentChildren: [{
                type: ContentChildren,
                args: [PROPERTY_TOKEN_validationRules]
            }], aiOptions: [{
                type: Input
            }], colSpan: [{
                type: Input
            }], cssClass: [{
                type: Input
            }], dataField: [{
                type: Input
            }], editorOptions: [{
                type: Input
            }], editorType: [{
                type: Input
            }], helpText: [{
                type: Input
            }], isRequired: [{
                type: Input
            }], itemType: [{
                type: Input
            }], label: [{
                type: Input
            }], name: [{
                type: Input
            }], template: [{
                type: Input
            }], validationRules: [{
                type: Input
            }], visible: [{
                type: Input
            }], visibleIndex: [{
                type: Input
            }] } });
class DxoTreeListFormItemModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListFormItemModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListFormItemModule, imports: [DxoTreeListFormItemComponent], exports: [DxoTreeListFormItemComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListFormItemModule, imports: [DxoTreeListFormItemComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListFormItemModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoTreeListFormItemComponent
                    ],
                    exports: [
                        DxoTreeListFormItemComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoTreeListFormComponent extends NestedOption {
    set _itemsContentChildren(value) {
        this.setChildren('items', value);
    }
    get accessKey() {
        return this._getOption('accessKey');
    }
    set accessKey(value) {
        this._setOption('accessKey', value);
    }
    get activeStateEnabled() {
        return this._getOption('activeStateEnabled');
    }
    set activeStateEnabled(value) {
        this._setOption('activeStateEnabled', value);
    }
    get aiIntegration() {
        return this._getOption('aiIntegration');
    }
    set aiIntegration(value) {
        this._setOption('aiIntegration', value);
    }
    get alignItemLabels() {
        return this._getOption('alignItemLabels');
    }
    set alignItemLabels(value) {
        this._setOption('alignItemLabels', value);
    }
    get alignItemLabelsInAllGroups() {
        return this._getOption('alignItemLabelsInAllGroups');
    }
    set alignItemLabelsInAllGroups(value) {
        this._setOption('alignItemLabelsInAllGroups', value);
    }
    get colCount() {
        return this._getOption('colCount');
    }
    set colCount(value) {
        this._setOption('colCount', value);
    }
    get colCountByScreen() {
        return this._getOption('colCountByScreen');
    }
    set colCountByScreen(value) {
        this._setOption('colCountByScreen', value);
    }
    get customizeItem() {
        return this._getOption('customizeItem');
    }
    set customizeItem(value) {
        this._setOption('customizeItem', value);
    }
    get disabled() {
        return this._getOption('disabled');
    }
    set disabled(value) {
        this._setOption('disabled', value);
    }
    get elementAttr() {
        return this._getOption('elementAttr');
    }
    set elementAttr(value) {
        this._setOption('elementAttr', value);
    }
    get focusStateEnabled() {
        return this._getOption('focusStateEnabled');
    }
    set focusStateEnabled(value) {
        this._setOption('focusStateEnabled', value);
    }
    get formData() {
        return this._getOption('formData');
    }
    set formData(value) {
        this._setOption('formData', value);
    }
    get height() {
        return this._getOption('height');
    }
    set height(value) {
        this._setOption('height', value);
    }
    get hint() {
        return this._getOption('hint');
    }
    set hint(value) {
        this._setOption('hint', value);
    }
    get hoverStateEnabled() {
        return this._getOption('hoverStateEnabled');
    }
    set hoverStateEnabled(value) {
        this._setOption('hoverStateEnabled', value);
    }
    get isDirty() {
        return this._getOption('isDirty');
    }
    set isDirty(value) {
        this._setOption('isDirty', value);
    }
    get items() {
        return this._getOption('items');
    }
    set items(value) {
        this._setOption('items', value);
    }
    get labelLocation() {
        return this._getOption('labelLocation');
    }
    set labelLocation(value) {
        this._setOption('labelLocation', value);
    }
    get labelMode() {
        return this._getOption('labelMode');
    }
    set labelMode(value) {
        this._setOption('labelMode', value);
    }
    get minColWidth() {
        return this._getOption('minColWidth');
    }
    set minColWidth(value) {
        this._setOption('minColWidth', value);
    }
    get onContentReady() {
        return this._getOption('onContentReady');
    }
    set onContentReady(value) {
        this._setOption('onContentReady', value);
    }
    get onDisposing() {
        return this._getOption('onDisposing');
    }
    set onDisposing(value) {
        this._setOption('onDisposing', value);
    }
    get onEditorEnterKey() {
        return this._getOption('onEditorEnterKey');
    }
    set onEditorEnterKey(value) {
        this._setOption('onEditorEnterKey', value);
    }
    get onFieldDataChanged() {
        return this._getOption('onFieldDataChanged');
    }
    set onFieldDataChanged(value) {
        this._setOption('onFieldDataChanged', value);
    }
    get onInitialized() {
        return this._getOption('onInitialized');
    }
    set onInitialized(value) {
        this._setOption('onInitialized', value);
    }
    get onOptionChanged() {
        return this._getOption('onOptionChanged');
    }
    set onOptionChanged(value) {
        this._setOption('onOptionChanged', value);
    }
    get onSmartPasted() {
        return this._getOption('onSmartPasted');
    }
    set onSmartPasted(value) {
        this._setOption('onSmartPasted', value);
    }
    get onSmartPasting() {
        return this._getOption('onSmartPasting');
    }
    set onSmartPasting(value) {
        this._setOption('onSmartPasting', value);
    }
    get optionalMark() {
        return this._getOption('optionalMark');
    }
    set optionalMark(value) {
        this._setOption('optionalMark', value);
    }
    get readOnly() {
        return this._getOption('readOnly');
    }
    set readOnly(value) {
        this._setOption('readOnly', value);
    }
    get requiredMark() {
        return this._getOption('requiredMark');
    }
    set requiredMark(value) {
        this._setOption('requiredMark', value);
    }
    get requiredMessage() {
        return this._getOption('requiredMessage');
    }
    set requiredMessage(value) {
        this._setOption('requiredMessage', value);
    }
    get rtlEnabled() {
        return this._getOption('rtlEnabled');
    }
    set rtlEnabled(value) {
        this._setOption('rtlEnabled', value);
    }
    get screenByWidth() {
        return this._getOption('screenByWidth');
    }
    set screenByWidth(value) {
        this._setOption('screenByWidth', value);
    }
    get scrollingEnabled() {
        return this._getOption('scrollingEnabled');
    }
    set scrollingEnabled(value) {
        this._setOption('scrollingEnabled', value);
    }
    get showColonAfterLabel() {
        return this._getOption('showColonAfterLabel');
    }
    set showColonAfterLabel(value) {
        this._setOption('showColonAfterLabel', value);
    }
    get showOptionalMark() {
        return this._getOption('showOptionalMark');
    }
    set showOptionalMark(value) {
        this._setOption('showOptionalMark', value);
    }
    get showRequiredMark() {
        return this._getOption('showRequiredMark');
    }
    set showRequiredMark(value) {
        this._setOption('showRequiredMark', value);
    }
    get showValidationSummary() {
        return this._getOption('showValidationSummary');
    }
    set showValidationSummary(value) {
        this._setOption('showValidationSummary', value);
    }
    get tabIndex() {
        return this._getOption('tabIndex');
    }
    set tabIndex(value) {
        this._setOption('tabIndex', value);
    }
    get validationGroup() {
        return this._getOption('validationGroup');
    }
    set validationGroup(value) {
        this._setOption('validationGroup', value);
    }
    get visible() {
        return this._getOption('visible');
    }
    set visible(value) {
        this._setOption('visible', value);
    }
    get width() {
        return this._getOption('width');
    }
    set width(value) {
        this._setOption('width', value);
    }
    get _optionPath() {
        return 'form';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        this._createEventEmitters([
            { emit: 'formDataChange' }
        ]);
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListFormComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoTreeListFormComponent, isStandalone: true, selector: "dxo-tree-list-form", inputs: { accessKey: "accessKey", activeStateEnabled: "activeStateEnabled", aiIntegration: "aiIntegration", alignItemLabels: "alignItemLabels", alignItemLabelsInAllGroups: "alignItemLabelsInAllGroups", colCount: "colCount", colCountByScreen: "colCountByScreen", customizeItem: "customizeItem", disabled: "disabled", elementAttr: "elementAttr", focusStateEnabled: "focusStateEnabled", formData: "formData", height: "height", hint: "hint", hoverStateEnabled: "hoverStateEnabled", isDirty: "isDirty", items: "items", labelLocation: "labelLocation", labelMode: "labelMode", minColWidth: "minColWidth", onContentReady: "onContentReady", onDisposing: "onDisposing", onEditorEnterKey: "onEditorEnterKey", onFieldDataChanged: "onFieldDataChanged", onInitialized: "onInitialized", onOptionChanged: "onOptionChanged", onSmartPasted: "onSmartPasted", onSmartPasting: "onSmartPasting", optionalMark: "optionalMark", readOnly: "readOnly", requiredMark: "requiredMark", requiredMessage: "requiredMessage", rtlEnabled: "rtlEnabled", screenByWidth: "screenByWidth", scrollingEnabled: "scrollingEnabled", showColonAfterLabel: "showColonAfterLabel", showOptionalMark: "showOptionalMark", showRequiredMark: "showRequiredMark", showValidationSummary: "showValidationSummary", tabIndex: "tabIndex", validationGroup: "validationGroup", visible: "visible", width: "width" }, outputs: { formDataChange: "formDataChange" }, providers: [NestedOptionHost], queries: [{ propertyName: "_itemsContentChildren", predicate: PROPERTY_TOKEN_items }], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListFormComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-tree-list-form', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { _itemsContentChildren: [{
                type: ContentChildren,
                args: [PROPERTY_TOKEN_items]
            }], accessKey: [{
                type: Input
            }], activeStateEnabled: [{
                type: Input
            }], aiIntegration: [{
                type: Input
            }], alignItemLabels: [{
                type: Input
            }], alignItemLabelsInAllGroups: [{
                type: Input
            }], colCount: [{
                type: Input
            }], colCountByScreen: [{
                type: Input
            }], customizeItem: [{
                type: Input
            }], disabled: [{
                type: Input
            }], elementAttr: [{
                type: Input
            }], focusStateEnabled: [{
                type: Input
            }], formData: [{
                type: Input
            }], height: [{
                type: Input
            }], hint: [{
                type: Input
            }], hoverStateEnabled: [{
                type: Input
            }], isDirty: [{
                type: Input
            }], items: [{
                type: Input
            }], labelLocation: [{
                type: Input
            }], labelMode: [{
                type: Input
            }], minColWidth: [{
                type: Input
            }], onContentReady: [{
                type: Input
            }], onDisposing: [{
                type: Input
            }], onEditorEnterKey: [{
                type: Input
            }], onFieldDataChanged: [{
                type: Input
            }], onInitialized: [{
                type: Input
            }], onOptionChanged: [{
                type: Input
            }], onSmartPasted: [{
                type: Input
            }], onSmartPasting: [{
                type: Input
            }], optionalMark: [{
                type: Input
            }], readOnly: [{
                type: Input
            }], requiredMark: [{
                type: Input
            }], requiredMessage: [{
                type: Input
            }], rtlEnabled: [{
                type: Input
            }], screenByWidth: [{
                type: Input
            }], scrollingEnabled: [{
                type: Input
            }], showColonAfterLabel: [{
                type: Input
            }], showOptionalMark: [{
                type: Input
            }], showRequiredMark: [{
                type: Input
            }], showValidationSummary: [{
                type: Input
            }], tabIndex: [{
                type: Input
            }], validationGroup: [{
                type: Input
            }], visible: [{
                type: Input
            }], width: [{
                type: Input
            }], formDataChange: [{
                type: Output
            }] } });
class DxoTreeListFormModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListFormModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListFormModule, imports: [DxoTreeListFormComponent], exports: [DxoTreeListFormComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListFormModule, imports: [DxoTreeListFormComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListFormModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoTreeListFormComponent
                    ],
                    exports: [
                        DxoTreeListFormComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoTreeListFormatComponent extends NestedOption {
    get currency() {
        return this._getOption('currency');
    }
    set currency(value) {
        this._setOption('currency', value);
    }
    get formatter() {
        return this._getOption('formatter');
    }
    set formatter(value) {
        this._setOption('formatter', value);
    }
    get parser() {
        return this._getOption('parser');
    }
    set parser(value) {
        this._setOption('parser', value);
    }
    get precision() {
        return this._getOption('precision');
    }
    set precision(value) {
        this._setOption('precision', value);
    }
    get type() {
        return this._getOption('type');
    }
    set type(value) {
        this._setOption('type', value);
    }
    get useCurrencyAccountingStyle() {
        return this._getOption('useCurrencyAccountingStyle');
    }
    set useCurrencyAccountingStyle(value) {
        this._setOption('useCurrencyAccountingStyle', value);
    }
    get _optionPath() {
        return 'format';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListFormatComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoTreeListFormatComponent, isStandalone: true, selector: "dxo-tree-list-format", inputs: { currency: "currency", formatter: "formatter", parser: "parser", precision: "precision", type: "type", useCurrencyAccountingStyle: "useCurrencyAccountingStyle" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListFormatComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-tree-list-format', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { currency: [{
                type: Input
            }], formatter: [{
                type: Input
            }], parser: [{
                type: Input
            }], precision: [{
                type: Input
            }], type: [{
                type: Input
            }], useCurrencyAccountingStyle: [{
                type: Input
            }] } });
class DxoTreeListFormatModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListFormatModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListFormatModule, imports: [DxoTreeListFormatComponent], exports: [DxoTreeListFormatComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListFormatModule, imports: [DxoTreeListFormatComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListFormatModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoTreeListFormatComponent
                    ],
                    exports: [
                        DxoTreeListFormatComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoTreeListFromComponent extends NestedOption {
    get left() {
        return this._getOption('left');
    }
    set left(value) {
        this._setOption('left', value);
    }
    get opacity() {
        return this._getOption('opacity');
    }
    set opacity(value) {
        this._setOption('opacity', value);
    }
    get position() {
        return this._getOption('position');
    }
    set position(value) {
        this._setOption('position', value);
    }
    get scale() {
        return this._getOption('scale');
    }
    set scale(value) {
        this._setOption('scale', value);
    }
    get top() {
        return this._getOption('top');
    }
    set top(value) {
        this._setOption('top', value);
    }
    get _optionPath() {
        return 'from';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListFromComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoTreeListFromComponent, isStandalone: true, selector: "dxo-tree-list-from", inputs: { left: "left", opacity: "opacity", position: "position", scale: "scale", top: "top" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListFromComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-tree-list-from', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { left: [{
                type: Input
            }], opacity: [{
                type: Input
            }], position: [{
                type: Input
            }], scale: [{
                type: Input
            }], top: [{
                type: Input
            }] } });
class DxoTreeListFromModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListFromModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListFromModule, imports: [DxoTreeListFromComponent], exports: [DxoTreeListFromComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListFromModule, imports: [DxoTreeListFromComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListFromModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoTreeListFromComponent
                    ],
                    exports: [
                        DxoTreeListFromComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxiTreeListGroupItemComponent extends CollectionNestedOption {
    set _itemsContentChildren(value) {
        this.setChildren('items', value);
    }
    get alignItemLabels() {
        return this._getOption('alignItemLabels');
    }
    set alignItemLabels(value) {
        this._setOption('alignItemLabels', value);
    }
    get caption() {
        return this._getOption('caption');
    }
    set caption(value) {
        this._setOption('caption', value);
    }
    get captionTemplate() {
        return this._getOption('captionTemplate');
    }
    set captionTemplate(value) {
        this._setOption('captionTemplate', value);
    }
    get colCount() {
        return this._getOption('colCount');
    }
    set colCount(value) {
        this._setOption('colCount', value);
    }
    get colCountByScreen() {
        return this._getOption('colCountByScreen');
    }
    set colCountByScreen(value) {
        this._setOption('colCountByScreen', value);
    }
    get colSpan() {
        return this._getOption('colSpan');
    }
    set colSpan(value) {
        this._setOption('colSpan', value);
    }
    get cssClass() {
        return this._getOption('cssClass');
    }
    set cssClass(value) {
        this._setOption('cssClass', value);
    }
    get items() {
        return this._getOption('items');
    }
    set items(value) {
        this._setOption('items', value);
    }
    get itemType() {
        return this._getOption('itemType');
    }
    set itemType(value) {
        this._setOption('itemType', value);
    }
    get name() {
        return this._getOption('name');
    }
    set name(value) {
        this._setOption('name', value);
    }
    get template() {
        return this._getOption('template');
    }
    set template(value) {
        this._setOption('template', value);
    }
    get visible() {
        return this._getOption('visible');
    }
    set visible(value) {
        this._setOption('visible', value);
    }
    get visibleIndex() {
        return this._getOption('visibleIndex');
    }
    set visibleIndex(value) {
        this._setOption('visibleIndex', value);
    }
    get _optionPath() {
        return 'items';
    }
    constructor(parentOptionHost, optionHost, renderer, document, templateHost, element) {
        super();
        this.renderer = renderer;
        this.document = document;
        this.element = element;
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
        templateHost.setHost(this);
        this.itemType = 'group';
    }
    setTemplate(template) {
        this.template = template;
    }
    ngAfterViewInit() {
        extractTemplate(this, this.element, this.renderer, this.document);
    }
    ngOnDestroy() {
        this._deleteRemovedOptions(this._fullOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiTreeListGroupItemComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }, { token: i0.Renderer2 }, { token: DOCUMENT }, { token: i1.DxTemplateHost, host: true }, { token: i0.ElementRef }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxiTreeListGroupItemComponent, isStandalone: true, selector: "dxi-tree-list-group-item", inputs: { alignItemLabels: "alignItemLabels", caption: "caption", captionTemplate: "captionTemplate", colCount: "colCount", colCountByScreen: "colCountByScreen", colSpan: "colSpan", cssClass: "cssClass", items: "items", itemType: "itemType", name: "name", template: "template", visible: "visible", visibleIndex: "visibleIndex" }, providers: [
            NestedOptionHost,
            DxTemplateHost,
            {
                provide: PROPERTY_TOKEN_items,
                useExisting: DxiTreeListGroupItemComponent,
            }
        ], queries: [{ propertyName: "_itemsContentChildren", predicate: PROPERTY_TOKEN_items }], usesInheritance: true, ngImport: i0, template: '<ng-content></ng-content>', isInline: true, styles: [":host{display:block}\n"], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiTreeListGroupItemComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxi-tree-list-group-item', template: '<ng-content></ng-content>', imports: [DxIntegrationModule], providers: [
                        NestedOptionHost,
                        DxTemplateHost,
                        {
                            provide: PROPERTY_TOKEN_items,
                            useExisting: DxiTreeListGroupItemComponent,
                        }
                    ], styles: [":host{display:block}\n"] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }, { type: i0.Renderer2 }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [DOCUMENT]
                }] }, { type: i1.DxTemplateHost, decorators: [{
                    type: Host
                }] }, { type: i0.ElementRef }], propDecorators: { _itemsContentChildren: [{
                type: ContentChildren,
                args: [PROPERTY_TOKEN_items]
            }], alignItemLabels: [{
                type: Input
            }], caption: [{
                type: Input
            }], captionTemplate: [{
                type: Input
            }], colCount: [{
                type: Input
            }], colCountByScreen: [{
                type: Input
            }], colSpan: [{
                type: Input
            }], cssClass: [{
                type: Input
            }], items: [{
                type: Input
            }], itemType: [{
                type: Input
            }], name: [{
                type: Input
            }], template: [{
                type: Input
            }], visible: [{
                type: Input
            }], visibleIndex: [{
                type: Input
            }] } });
class DxiTreeListGroupItemModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiTreeListGroupItemModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxiTreeListGroupItemModule, imports: [DxiTreeListGroupItemComponent], exports: [DxiTreeListGroupItemComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiTreeListGroupItemModule, imports: [DxiTreeListGroupItemComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiTreeListGroupItemModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxiTreeListGroupItemComponent
                    ],
                    exports: [
                        DxiTreeListGroupItemComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoTreeListGroupOperationDescriptionsComponent extends NestedOption {
    get and() {
        return this._getOption('and');
    }
    set and(value) {
        this._setOption('and', value);
    }
    get notAnd() {
        return this._getOption('notAnd');
    }
    set notAnd(value) {
        this._setOption('notAnd', value);
    }
    get notOr() {
        return this._getOption('notOr');
    }
    set notOr(value) {
        this._setOption('notOr', value);
    }
    get or() {
        return this._getOption('or');
    }
    set or(value) {
        this._setOption('or', value);
    }
    get _optionPath() {
        return 'groupOperationDescriptions';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListGroupOperationDescriptionsComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoTreeListGroupOperationDescriptionsComponent, isStandalone: true, selector: "dxo-tree-list-group-operation-descriptions", inputs: { and: "and", notAnd: "notAnd", notOr: "notOr", or: "or" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListGroupOperationDescriptionsComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-tree-list-group-operation-descriptions', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { and: [{
                type: Input
            }], notAnd: [{
                type: Input
            }], notOr: [{
                type: Input
            }], or: [{
                type: Input
            }] } });
class DxoTreeListGroupOperationDescriptionsModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListGroupOperationDescriptionsModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListGroupOperationDescriptionsModule, imports: [DxoTreeListGroupOperationDescriptionsComponent], exports: [DxoTreeListGroupOperationDescriptionsComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListGroupOperationDescriptionsModule, imports: [DxoTreeListGroupOperationDescriptionsComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListGroupOperationDescriptionsModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoTreeListGroupOperationDescriptionsComponent
                    ],
                    exports: [
                        DxoTreeListGroupOperationDescriptionsComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoTreeListHeaderFilterComponent extends NestedOption {
    get allowSearch() {
        return this._getOption('allowSearch');
    }
    set allowSearch(value) {
        this._setOption('allowSearch', value);
    }
    get allowSelectAll() {
        return this._getOption('allowSelectAll');
    }
    set allowSelectAll(value) {
        this._setOption('allowSelectAll', value);
    }
    get dataSource() {
        return this._getOption('dataSource');
    }
    set dataSource(value) {
        this._setOption('dataSource', value);
    }
    get groupInterval() {
        return this._getOption('groupInterval');
    }
    set groupInterval(value) {
        this._setOption('groupInterval', value);
    }
    get height() {
        return this._getOption('height');
    }
    set height(value) {
        this._setOption('height', value);
    }
    get search() {
        return this._getOption('search');
    }
    set search(value) {
        this._setOption('search', value);
    }
    get searchMode() {
        return this._getOption('searchMode');
    }
    set searchMode(value) {
        this._setOption('searchMode', value);
    }
    get width() {
        return this._getOption('width');
    }
    set width(value) {
        this._setOption('width', value);
    }
    get searchTimeout() {
        return this._getOption('searchTimeout');
    }
    set searchTimeout(value) {
        this._setOption('searchTimeout', value);
    }
    get texts() {
        return this._getOption('texts');
    }
    set texts(value) {
        this._setOption('texts', value);
    }
    get visible() {
        return this._getOption('visible');
    }
    set visible(value) {
        this._setOption('visible', value);
    }
    get _optionPath() {
        return 'headerFilter';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListHeaderFilterComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoTreeListHeaderFilterComponent, isStandalone: true, selector: "dxo-tree-list-header-filter", inputs: { allowSearch: "allowSearch", allowSelectAll: "allowSelectAll", dataSource: "dataSource", groupInterval: "groupInterval", height: "height", search: "search", searchMode: "searchMode", width: "width", searchTimeout: "searchTimeout", texts: "texts", visible: "visible" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListHeaderFilterComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-tree-list-header-filter', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { allowSearch: [{
                type: Input
            }], allowSelectAll: [{
                type: Input
            }], dataSource: [{
                type: Input
            }], groupInterval: [{
                type: Input
            }], height: [{
                type: Input
            }], search: [{
                type: Input
            }], searchMode: [{
                type: Input
            }], width: [{
                type: Input
            }], searchTimeout: [{
                type: Input
            }], texts: [{
                type: Input
            }], visible: [{
                type: Input
            }] } });
class DxoTreeListHeaderFilterModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListHeaderFilterModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListHeaderFilterModule, imports: [DxoTreeListHeaderFilterComponent], exports: [DxoTreeListHeaderFilterComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListHeaderFilterModule, imports: [DxoTreeListHeaderFilterComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListHeaderFilterModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoTreeListHeaderFilterComponent
                    ],
                    exports: [
                        DxoTreeListHeaderFilterComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoTreeListHideComponent extends NestedOption {
    get complete() {
        return this._getOption('complete');
    }
    set complete(value) {
        this._setOption('complete', value);
    }
    get delay() {
        return this._getOption('delay');
    }
    set delay(value) {
        this._setOption('delay', value);
    }
    get direction() {
        return this._getOption('direction');
    }
    set direction(value) {
        this._setOption('direction', value);
    }
    get duration() {
        return this._getOption('duration');
    }
    set duration(value) {
        this._setOption('duration', value);
    }
    get easing() {
        return this._getOption('easing');
    }
    set easing(value) {
        this._setOption('easing', value);
    }
    get from() {
        return this._getOption('from');
    }
    set from(value) {
        this._setOption('from', value);
    }
    get staggerDelay() {
        return this._getOption('staggerDelay');
    }
    set staggerDelay(value) {
        this._setOption('staggerDelay', value);
    }
    get start() {
        return this._getOption('start');
    }
    set start(value) {
        this._setOption('start', value);
    }
    get to() {
        return this._getOption('to');
    }
    set to(value) {
        this._setOption('to', value);
    }
    get type() {
        return this._getOption('type');
    }
    set type(value) {
        this._setOption('type', value);
    }
    get _optionPath() {
        return 'hide';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListHideComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoTreeListHideComponent, isStandalone: true, selector: "dxo-tree-list-hide", inputs: { complete: "complete", delay: "delay", direction: "direction", duration: "duration", easing: "easing", from: "from", staggerDelay: "staggerDelay", start: "start", to: "to", type: "type" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListHideComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-tree-list-hide', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { complete: [{
                type: Input
            }], delay: [{
                type: Input
            }], direction: [{
                type: Input
            }], duration: [{
                type: Input
            }], easing: [{
                type: Input
            }], from: [{
                type: Input
            }], staggerDelay: [{
                type: Input
            }], start: [{
                type: Input
            }], to: [{
                type: Input
            }], type: [{
                type: Input
            }] } });
class DxoTreeListHideModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListHideModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListHideModule, imports: [DxoTreeListHideComponent], exports: [DxoTreeListHideComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListHideModule, imports: [DxoTreeListHideComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListHideModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoTreeListHideComponent
                    ],
                    exports: [
                        DxoTreeListHideComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoTreeListIconsComponent extends NestedOption {
    get fix() {
        return this._getOption('fix');
    }
    set fix(value) {
        this._setOption('fix', value);
    }
    get leftPosition() {
        return this._getOption('leftPosition');
    }
    set leftPosition(value) {
        this._setOption('leftPosition', value);
    }
    get rightPosition() {
        return this._getOption('rightPosition');
    }
    set rightPosition(value) {
        this._setOption('rightPosition', value);
    }
    get stickyPosition() {
        return this._getOption('stickyPosition');
    }
    set stickyPosition(value) {
        this._setOption('stickyPosition', value);
    }
    get unfix() {
        return this._getOption('unfix');
    }
    set unfix(value) {
        this._setOption('unfix', value);
    }
    get _optionPath() {
        return 'icons';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListIconsComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoTreeListIconsComponent, isStandalone: true, selector: "dxo-tree-list-icons", inputs: { fix: "fix", leftPosition: "leftPosition", rightPosition: "rightPosition", stickyPosition: "stickyPosition", unfix: "unfix" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListIconsComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-tree-list-icons', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { fix: [{
                type: Input
            }], leftPosition: [{
                type: Input
            }], rightPosition: [{
                type: Input
            }], stickyPosition: [{
                type: Input
            }], unfix: [{
                type: Input
            }] } });
class DxoTreeListIconsModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListIconsModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListIconsModule, imports: [DxoTreeListIconsComponent], exports: [DxoTreeListIconsComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListIconsModule, imports: [DxoTreeListIconsComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListIconsModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoTreeListIconsComponent
                    ],
                    exports: [
                        DxoTreeListIconsComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoTreeListIndicatorOptionsComponent extends NestedOption {
    get animationType() {
        return this._getOption('animationType');
    }
    set animationType(value) {
        this._setOption('animationType', value);
    }
    get height() {
        return this._getOption('height');
    }
    set height(value) {
        this._setOption('height', value);
    }
    get src() {
        return this._getOption('src');
    }
    set src(value) {
        this._setOption('src', value);
    }
    get width() {
        return this._getOption('width');
    }
    set width(value) {
        this._setOption('width', value);
    }
    get _optionPath() {
        return 'indicatorOptions';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListIndicatorOptionsComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoTreeListIndicatorOptionsComponent, isStandalone: true, selector: "dxo-tree-list-indicator-options", inputs: { animationType: "animationType", height: "height", src: "src", width: "width" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListIndicatorOptionsComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-tree-list-indicator-options', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { animationType: [{
                type: Input
            }], height: [{
                type: Input
            }], src: [{
                type: Input
            }], width: [{
                type: Input
            }] } });
class DxoTreeListIndicatorOptionsModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListIndicatorOptionsModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListIndicatorOptionsModule, imports: [DxoTreeListIndicatorOptionsComponent], exports: [DxoTreeListIndicatorOptionsComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListIndicatorOptionsModule, imports: [DxoTreeListIndicatorOptionsComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListIndicatorOptionsModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoTreeListIndicatorOptionsComponent
                    ],
                    exports: [
                        DxoTreeListIndicatorOptionsComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxiTreeListItemComponent extends CollectionNestedOption {
    set _validationRulesContentChildren(value) {
        this.setChildren('validationRules', value);
    }
    set _tabsContentChildren(value) {
        this.setChildren('tabs', value);
    }
    set _itemsContentChildren(value) {
        this.setChildren('items', value);
    }
    get badge() {
        return this._getOption('badge');
    }
    set badge(value) {
        this._setOption('badge', value);
    }
    get disabled() {
        return this._getOption('disabled');
    }
    set disabled(value) {
        this._setOption('disabled', value);
    }
    get html() {
        return this._getOption('html');
    }
    set html(value) {
        this._setOption('html', value);
    }
    get icon() {
        return this._getOption('icon');
    }
    set icon(value) {
        this._setOption('icon', value);
    }
    get tabTemplate() {
        return this._getOption('tabTemplate');
    }
    set tabTemplate(value) {
        this._setOption('tabTemplate', value);
    }
    get template() {
        return this._getOption('template');
    }
    set template(value) {
        this._setOption('template', value);
    }
    get text() {
        return this._getOption('text');
    }
    set text(value) {
        this._setOption('text', value);
    }
    get title() {
        return this._getOption('title');
    }
    set title(value) {
        this._setOption('title', value);
    }
    get visible() {
        return this._getOption('visible');
    }
    set visible(value) {
        this._setOption('visible', value);
    }
    get aiOptions() {
        return this._getOption('aiOptions');
    }
    set aiOptions(value) {
        this._setOption('aiOptions', value);
    }
    get colSpan() {
        return this._getOption('colSpan');
    }
    set colSpan(value) {
        this._setOption('colSpan', value);
    }
    get cssClass() {
        return this._getOption('cssClass');
    }
    set cssClass(value) {
        this._setOption('cssClass', value);
    }
    get dataField() {
        return this._getOption('dataField');
    }
    set dataField(value) {
        this._setOption('dataField', value);
    }
    get editorOptions() {
        return this._getOption('editorOptions');
    }
    set editorOptions(value) {
        this._setOption('editorOptions', value);
    }
    get editorType() {
        return this._getOption('editorType');
    }
    set editorType(value) {
        this._setOption('editorType', value);
    }
    get helpText() {
        return this._getOption('helpText');
    }
    set helpText(value) {
        this._setOption('helpText', value);
    }
    get isRequired() {
        return this._getOption('isRequired');
    }
    set isRequired(value) {
        this._setOption('isRequired', value);
    }
    get itemType() {
        return this._getOption('itemType');
    }
    set itemType(value) {
        this._setOption('itemType', value);
    }
    get label() {
        return this._getOption('label');
    }
    set label(value) {
        this._setOption('label', value);
    }
    get name() {
        return this._getOption('name');
    }
    set name(value) {
        this._setOption('name', value);
    }
    get validationRules() {
        return this._getOption('validationRules');
    }
    set validationRules(value) {
        this._setOption('validationRules', value);
    }
    get visibleIndex() {
        return this._getOption('visibleIndex');
    }
    set visibleIndex(value) {
        this._setOption('visibleIndex', value);
    }
    get alignItemLabels() {
        return this._getOption('alignItemLabels');
    }
    set alignItemLabels(value) {
        this._setOption('alignItemLabels', value);
    }
    get caption() {
        return this._getOption('caption');
    }
    set caption(value) {
        this._setOption('caption', value);
    }
    get captionTemplate() {
        return this._getOption('captionTemplate');
    }
    set captionTemplate(value) {
        this._setOption('captionTemplate', value);
    }
    get colCount() {
        return this._getOption('colCount');
    }
    set colCount(value) {
        this._setOption('colCount', value);
    }
    get colCountByScreen() {
        return this._getOption('colCountByScreen');
    }
    set colCountByScreen(value) {
        this._setOption('colCountByScreen', value);
    }
    get items() {
        return this._getOption('items');
    }
    set items(value) {
        this._setOption('items', value);
    }
    get tabPanelOptions() {
        return this._getOption('tabPanelOptions');
    }
    set tabPanelOptions(value) {
        this._setOption('tabPanelOptions', value);
    }
    get tabs() {
        return this._getOption('tabs');
    }
    set tabs(value) {
        this._setOption('tabs', value);
    }
    get buttonOptions() {
        return this._getOption('buttonOptions');
    }
    set buttonOptions(value) {
        this._setOption('buttonOptions', value);
    }
    get horizontalAlignment() {
        return this._getOption('horizontalAlignment');
    }
    set horizontalAlignment(value) {
        this._setOption('horizontalAlignment', value);
    }
    get verticalAlignment() {
        return this._getOption('verticalAlignment');
    }
    set verticalAlignment(value) {
        this._setOption('verticalAlignment', value);
    }
    get locateInMenu() {
        return this._getOption('locateInMenu');
    }
    set locateInMenu(value) {
        this._setOption('locateInMenu', value);
    }
    get location() {
        return this._getOption('location');
    }
    set location(value) {
        this._setOption('location', value);
    }
    get menuItemTemplate() {
        return this._getOption('menuItemTemplate');
    }
    set menuItemTemplate(value) {
        this._setOption('menuItemTemplate', value);
    }
    get options() {
        return this._getOption('options');
    }
    set options(value) {
        this._setOption('options', value);
    }
    get showText() {
        return this._getOption('showText');
    }
    set showText(value) {
        this._setOption('showText', value);
    }
    get widget() {
        return this._getOption('widget');
    }
    set widget(value) {
        this._setOption('widget', value);
    }
    get _optionPath() {
        return 'items';
    }
    constructor(parentOptionHost, optionHost, renderer, document, templateHost, element) {
        super();
        this.renderer = renderer;
        this.document = document;
        this.element = element;
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
        templateHost.setHost(this);
    }
    setTemplate(template) {
        this.template = template;
    }
    ngAfterViewInit() {
        extractTemplate(this, this.element, this.renderer, this.document);
    }
    ngOnDestroy() {
        this._deleteRemovedOptions(this._fullOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiTreeListItemComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }, { token: i0.Renderer2 }, { token: DOCUMENT }, { token: i1.DxTemplateHost, host: true }, { token: i0.ElementRef }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxiTreeListItemComponent, isStandalone: true, selector: "dxi-tree-list-item", inputs: { badge: "badge", disabled: "disabled", html: "html", icon: "icon", tabTemplate: "tabTemplate", template: "template", text: "text", title: "title", visible: "visible", aiOptions: "aiOptions", colSpan: "colSpan", cssClass: "cssClass", dataField: "dataField", editorOptions: "editorOptions", editorType: "editorType", helpText: "helpText", isRequired: "isRequired", itemType: "itemType", label: "label", name: "name", validationRules: "validationRules", visibleIndex: "visibleIndex", alignItemLabels: "alignItemLabels", caption: "caption", captionTemplate: "captionTemplate", colCount: "colCount", colCountByScreen: "colCountByScreen", items: "items", tabPanelOptions: "tabPanelOptions", tabs: "tabs", buttonOptions: "buttonOptions", horizontalAlignment: "horizontalAlignment", verticalAlignment: "verticalAlignment", locateInMenu: "locateInMenu", location: "location", menuItemTemplate: "menuItemTemplate", options: "options", showText: "showText", widget: "widget" }, providers: [
            NestedOptionHost,
            DxTemplateHost,
            {
                provide: PROPERTY_TOKEN_items,
                useExisting: DxiTreeListItemComponent,
            }
        ], queries: [{ propertyName: "_validationRulesContentChildren", predicate: PROPERTY_TOKEN_validationRules }, { propertyName: "_tabsContentChildren", predicate: PROPERTY_TOKEN_tabs }, { propertyName: "_itemsContentChildren", predicate: PROPERTY_TOKEN_items }], usesInheritance: true, ngImport: i0, template: '<ng-content></ng-content>', isInline: true, styles: [":host{display:block}\n"], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiTreeListItemComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxi-tree-list-item', template: '<ng-content></ng-content>', imports: [DxIntegrationModule], providers: [
                        NestedOptionHost,
                        DxTemplateHost,
                        {
                            provide: PROPERTY_TOKEN_items,
                            useExisting: DxiTreeListItemComponent,
                        }
                    ], styles: [":host{display:block}\n"] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }, { type: i0.Renderer2 }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [DOCUMENT]
                }] }, { type: i1.DxTemplateHost, decorators: [{
                    type: Host
                }] }, { type: i0.ElementRef }], propDecorators: { _validationRulesContentChildren: [{
                type: ContentChildren,
                args: [PROPERTY_TOKEN_validationRules]
            }], _tabsContentChildren: [{
                type: ContentChildren,
                args: [PROPERTY_TOKEN_tabs]
            }], _itemsContentChildren: [{
                type: ContentChildren,
                args: [PROPERTY_TOKEN_items]
            }], badge: [{
                type: Input
            }], disabled: [{
                type: Input
            }], html: [{
                type: Input
            }], icon: [{
                type: Input
            }], tabTemplate: [{
                type: Input
            }], template: [{
                type: Input
            }], text: [{
                type: Input
            }], title: [{
                type: Input
            }], visible: [{
                type: Input
            }], aiOptions: [{
                type: Input
            }], colSpan: [{
                type: Input
            }], cssClass: [{
                type: Input
            }], dataField: [{
                type: Input
            }], editorOptions: [{
                type: Input
            }], editorType: [{
                type: Input
            }], helpText: [{
                type: Input
            }], isRequired: [{
                type: Input
            }], itemType: [{
                type: Input
            }], label: [{
                type: Input
            }], name: [{
                type: Input
            }], validationRules: [{
                type: Input
            }], visibleIndex: [{
                type: Input
            }], alignItemLabels: [{
                type: Input
            }], caption: [{
                type: Input
            }], captionTemplate: [{
                type: Input
            }], colCount: [{
                type: Input
            }], colCountByScreen: [{
                type: Input
            }], items: [{
                type: Input
            }], tabPanelOptions: [{
                type: Input
            }], tabs: [{
                type: Input
            }], buttonOptions: [{
                type: Input
            }], horizontalAlignment: [{
                type: Input
            }], verticalAlignment: [{
                type: Input
            }], locateInMenu: [{
                type: Input
            }], location: [{
                type: Input
            }], menuItemTemplate: [{
                type: Input
            }], options: [{
                type: Input
            }], showText: [{
                type: Input
            }], widget: [{
                type: Input
            }] } });
class DxiTreeListItemModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiTreeListItemModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxiTreeListItemModule, imports: [DxiTreeListItemComponent], exports: [DxiTreeListItemComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiTreeListItemModule, imports: [DxiTreeListItemComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiTreeListItemModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxiTreeListItemComponent
                    ],
                    exports: [
                        DxiTreeListItemComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoTreeListKeyboardNavigationComponent extends NestedOption {
    get editOnKeyPress() {
        return this._getOption('editOnKeyPress');
    }
    set editOnKeyPress(value) {
        this._setOption('editOnKeyPress', value);
    }
    get enabled() {
        return this._getOption('enabled');
    }
    set enabled(value) {
        this._setOption('enabled', value);
    }
    get enterKeyAction() {
        return this._getOption('enterKeyAction');
    }
    set enterKeyAction(value) {
        this._setOption('enterKeyAction', value);
    }
    get enterKeyDirection() {
        return this._getOption('enterKeyDirection');
    }
    set enterKeyDirection(value) {
        this._setOption('enterKeyDirection', value);
    }
    get _optionPath() {
        return 'keyboardNavigation';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListKeyboardNavigationComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoTreeListKeyboardNavigationComponent, isStandalone: true, selector: "dxo-tree-list-keyboard-navigation", inputs: { editOnKeyPress: "editOnKeyPress", enabled: "enabled", enterKeyAction: "enterKeyAction", enterKeyDirection: "enterKeyDirection" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListKeyboardNavigationComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-tree-list-keyboard-navigation', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { editOnKeyPress: [{
                type: Input
            }], enabled: [{
                type: Input
            }], enterKeyAction: [{
                type: Input
            }], enterKeyDirection: [{
                type: Input
            }] } });
class DxoTreeListKeyboardNavigationModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListKeyboardNavigationModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListKeyboardNavigationModule, imports: [DxoTreeListKeyboardNavigationComponent], exports: [DxoTreeListKeyboardNavigationComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListKeyboardNavigationModule, imports: [DxoTreeListKeyboardNavigationComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListKeyboardNavigationModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoTreeListKeyboardNavigationComponent
                    ],
                    exports: [
                        DxoTreeListKeyboardNavigationComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoTreeListLabelComponent extends NestedOption {
    get alignment() {
        return this._getOption('alignment');
    }
    set alignment(value) {
        this._setOption('alignment', value);
    }
    get location() {
        return this._getOption('location');
    }
    set location(value) {
        this._setOption('location', value);
    }
    get showColon() {
        return this._getOption('showColon');
    }
    set showColon(value) {
        this._setOption('showColon', value);
    }
    get template() {
        return this._getOption('template');
    }
    set template(value) {
        this._setOption('template', value);
    }
    get text() {
        return this._getOption('text');
    }
    set text(value) {
        this._setOption('text', value);
    }
    get visible() {
        return this._getOption('visible');
    }
    set visible(value) {
        this._setOption('visible', value);
    }
    get _optionPath() {
        return 'label';
    }
    constructor(parentOptionHost, optionHost, renderer, document, templateHost, element) {
        super();
        this.renderer = renderer;
        this.document = document;
        this.element = element;
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
        templateHost.setHost(this);
    }
    setTemplate(template) {
        this.template = template;
    }
    ngAfterViewInit() {
        extractTemplate(this, this.element, this.renderer, this.document);
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListLabelComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }, { token: i0.Renderer2 }, { token: DOCUMENT }, { token: i1.DxTemplateHost, host: true }, { token: i0.ElementRef }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoTreeListLabelComponent, isStandalone: true, selector: "dxo-tree-list-label", inputs: { alignment: "alignment", location: "location", showColon: "showColon", template: "template", text: "text", visible: "visible" }, providers: [NestedOptionHost, DxTemplateHost], usesInheritance: true, ngImport: i0, template: '<ng-content></ng-content>', isInline: true, styles: [":host{display:block}\n"], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListLabelComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-tree-list-label', template: '<ng-content></ng-content>', imports: [DxIntegrationModule], providers: [NestedOptionHost, DxTemplateHost], styles: [":host{display:block}\n"] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }, { type: i0.Renderer2 }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [DOCUMENT]
                }] }, { type: i1.DxTemplateHost, decorators: [{
                    type: Host
                }] }, { type: i0.ElementRef }], propDecorators: { alignment: [{
                type: Input
            }], location: [{
                type: Input
            }], showColon: [{
                type: Input
            }], template: [{
                type: Input
            }], text: [{
                type: Input
            }], visible: [{
                type: Input
            }] } });
class DxoTreeListLabelModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListLabelModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListLabelModule, imports: [DxoTreeListLabelComponent], exports: [DxoTreeListLabelComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListLabelModule, imports: [DxoTreeListLabelComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListLabelModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoTreeListLabelComponent
                    ],
                    exports: [
                        DxoTreeListLabelComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoTreeListLoadPanelComponent extends NestedOption {
    get enabled() {
        return this._getOption('enabled');
    }
    set enabled(value) {
        this._setOption('enabled', value);
    }
    get height() {
        return this._getOption('height');
    }
    set height(value) {
        this._setOption('height', value);
    }
    get indicatorOptions() {
        return this._getOption('indicatorOptions');
    }
    set indicatorOptions(value) {
        this._setOption('indicatorOptions', value);
    }
    get indicatorSrc() {
        return this._getOption('indicatorSrc');
    }
    set indicatorSrc(value) {
        this._setOption('indicatorSrc', value);
    }
    get shading() {
        return this._getOption('shading');
    }
    set shading(value) {
        this._setOption('shading', value);
    }
    get shadingColor() {
        return this._getOption('shadingColor');
    }
    set shadingColor(value) {
        this._setOption('shadingColor', value);
    }
    get showIndicator() {
        return this._getOption('showIndicator');
    }
    set showIndicator(value) {
        this._setOption('showIndicator', value);
    }
    get showPane() {
        return this._getOption('showPane');
    }
    set showPane(value) {
        this._setOption('showPane', value);
    }
    get text() {
        return this._getOption('text');
    }
    set text(value) {
        this._setOption('text', value);
    }
    get width() {
        return this._getOption('width');
    }
    set width(value) {
        this._setOption('width', value);
    }
    get _optionPath() {
        return 'loadPanel';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListLoadPanelComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoTreeListLoadPanelComponent, isStandalone: true, selector: "dxo-tree-list-load-panel", inputs: { enabled: "enabled", height: "height", indicatorOptions: "indicatorOptions", indicatorSrc: "indicatorSrc", shading: "shading", shadingColor: "shadingColor", showIndicator: "showIndicator", showPane: "showPane", text: "text", width: "width" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListLoadPanelComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-tree-list-load-panel', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { enabled: [{
                type: Input
            }], height: [{
                type: Input
            }], indicatorOptions: [{
                type: Input
            }], indicatorSrc: [{
                type: Input
            }], shading: [{
                type: Input
            }], shadingColor: [{
                type: Input
            }], showIndicator: [{
                type: Input
            }], showPane: [{
                type: Input
            }], text: [{
                type: Input
            }], width: [{
                type: Input
            }] } });
class DxoTreeListLoadPanelModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListLoadPanelModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListLoadPanelModule, imports: [DxoTreeListLoadPanelComponent], exports: [DxoTreeListLoadPanelComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListLoadPanelModule, imports: [DxoTreeListLoadPanelComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListLoadPanelModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoTreeListLoadPanelComponent
                    ],
                    exports: [
                        DxoTreeListLoadPanelComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoTreeListLookupComponent extends NestedOption {
    get allowClearing() {
        return this._getOption('allowClearing');
    }
    set allowClearing(value) {
        this._setOption('allowClearing', value);
    }
    get calculateCellValue() {
        return this._getOption('calculateCellValue');
    }
    set calculateCellValue(value) {
        this._setOption('calculateCellValue', value);
    }
    get dataSource() {
        return this._getOption('dataSource');
    }
    set dataSource(value) {
        this._setOption('dataSource', value);
    }
    get displayExpr() {
        return this._getOption('displayExpr');
    }
    set displayExpr(value) {
        this._setOption('displayExpr', value);
    }
    get valueExpr() {
        return this._getOption('valueExpr');
    }
    set valueExpr(value) {
        this._setOption('valueExpr', value);
    }
    get _optionPath() {
        return 'lookup';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListLookupComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoTreeListLookupComponent, isStandalone: true, selector: "dxo-tree-list-lookup", inputs: { allowClearing: "allowClearing", calculateCellValue: "calculateCellValue", dataSource: "dataSource", displayExpr: "displayExpr", valueExpr: "valueExpr" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListLookupComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-tree-list-lookup', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { allowClearing: [{
                type: Input
            }], calculateCellValue: [{
                type: Input
            }], dataSource: [{
                type: Input
            }], displayExpr: [{
                type: Input
            }], valueExpr: [{
                type: Input
            }] } });
class DxoTreeListLookupModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListLookupModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListLookupModule, imports: [DxoTreeListLookupComponent], exports: [DxoTreeListLookupComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListLookupModule, imports: [DxoTreeListLookupComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListLookupModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoTreeListLookupComponent
                    ],
                    exports: [
                        DxoTreeListLookupComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoTreeListMyComponent extends NestedOption {
    get x() {
        return this._getOption('x');
    }
    set x(value) {
        this._setOption('x', value);
    }
    get y() {
        return this._getOption('y');
    }
    set y(value) {
        this._setOption('y', value);
    }
    get _optionPath() {
        return 'my';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListMyComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoTreeListMyComponent, isStandalone: true, selector: "dxo-tree-list-my", inputs: { x: "x", y: "y" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListMyComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-tree-list-my', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { x: [{
                type: Input
            }], y: [{
                type: Input
            }] } });
class DxoTreeListMyModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListMyModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListMyModule, imports: [DxoTreeListMyComponent], exports: [DxoTreeListMyComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListMyModule, imports: [DxoTreeListMyComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListMyModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoTreeListMyComponent
                    ],
                    exports: [
                        DxoTreeListMyComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxiTreeListNumericRuleComponent extends CollectionNestedOption {
    get ignoreEmptyValue() {
        return this._getOption('ignoreEmptyValue');
    }
    set ignoreEmptyValue(value) {
        this._setOption('ignoreEmptyValue', value);
    }
    get message() {
        return this._getOption('message');
    }
    set message(value) {
        this._setOption('message', value);
    }
    get type() {
        return this._getOption('type');
    }
    set type(value) {
        this._setOption('type', value);
    }
    get _optionPath() {
        return 'validationRules';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
        this.type = 'numeric';
    }
    ngOnDestroy() {
        this._deleteRemovedOptions(this._fullOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiTreeListNumericRuleComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxiTreeListNumericRuleComponent, isStandalone: true, selector: "dxi-tree-list-numeric-rule", inputs: { ignoreEmptyValue: "ignoreEmptyValue", message: "message", type: "type" }, providers: [
            NestedOptionHost,
            {
                provide: PROPERTY_TOKEN_validationRules,
                useExisting: DxiTreeListNumericRuleComponent,
            }
        ], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiTreeListNumericRuleComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxi-tree-list-numeric-rule', template: '', imports: [DxIntegrationModule], providers: [
                        NestedOptionHost,
                        {
                            provide: PROPERTY_TOKEN_validationRules,
                            useExisting: DxiTreeListNumericRuleComponent,
                        }
                    ] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { ignoreEmptyValue: [{
                type: Input
            }], message: [{
                type: Input
            }], type: [{
                type: Input
            }] } });
class DxiTreeListNumericRuleModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiTreeListNumericRuleModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxiTreeListNumericRuleModule, imports: [DxiTreeListNumericRuleComponent], exports: [DxiTreeListNumericRuleComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiTreeListNumericRuleModule, imports: [DxiTreeListNumericRuleComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiTreeListNumericRuleModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxiTreeListNumericRuleComponent
                    ],
                    exports: [
                        DxiTreeListNumericRuleComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoTreeListOffsetComponent extends NestedOption {
    get x() {
        return this._getOption('x');
    }
    set x(value) {
        this._setOption('x', value);
    }
    get y() {
        return this._getOption('y');
    }
    set y(value) {
        this._setOption('y', value);
    }
    get _optionPath() {
        return 'offset';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListOffsetComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoTreeListOffsetComponent, isStandalone: true, selector: "dxo-tree-list-offset", inputs: { x: "x", y: "y" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListOffsetComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-tree-list-offset', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { x: [{
                type: Input
            }], y: [{
                type: Input
            }] } });
class DxoTreeListOffsetModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListOffsetModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListOffsetModule, imports: [DxoTreeListOffsetComponent], exports: [DxoTreeListOffsetComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListOffsetModule, imports: [DxoTreeListOffsetComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListOffsetModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoTreeListOffsetComponent
                    ],
                    exports: [
                        DxoTreeListOffsetComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoTreeListOperationDescriptionsComponent extends NestedOption {
    get between() {
        return this._getOption('between');
    }
    set between(value) {
        this._setOption('between', value);
    }
    get contains() {
        return this._getOption('contains');
    }
    set contains(value) {
        this._setOption('contains', value);
    }
    get endsWith() {
        return this._getOption('endsWith');
    }
    set endsWith(value) {
        this._setOption('endsWith', value);
    }
    get equal() {
        return this._getOption('equal');
    }
    set equal(value) {
        this._setOption('equal', value);
    }
    get greaterThan() {
        return this._getOption('greaterThan');
    }
    set greaterThan(value) {
        this._setOption('greaterThan', value);
    }
    get greaterThanOrEqual() {
        return this._getOption('greaterThanOrEqual');
    }
    set greaterThanOrEqual(value) {
        this._setOption('greaterThanOrEqual', value);
    }
    get lessThan() {
        return this._getOption('lessThan');
    }
    set lessThan(value) {
        this._setOption('lessThan', value);
    }
    get lessThanOrEqual() {
        return this._getOption('lessThanOrEqual');
    }
    set lessThanOrEqual(value) {
        this._setOption('lessThanOrEqual', value);
    }
    get notContains() {
        return this._getOption('notContains');
    }
    set notContains(value) {
        this._setOption('notContains', value);
    }
    get notEqual() {
        return this._getOption('notEqual');
    }
    set notEqual(value) {
        this._setOption('notEqual', value);
    }
    get startsWith() {
        return this._getOption('startsWith');
    }
    set startsWith(value) {
        this._setOption('startsWith', value);
    }
    get _optionPath() {
        return 'operationDescriptions';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListOperationDescriptionsComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoTreeListOperationDescriptionsComponent, isStandalone: true, selector: "dxo-tree-list-operation-descriptions", inputs: { between: "between", contains: "contains", endsWith: "endsWith", equal: "equal", greaterThan: "greaterThan", greaterThanOrEqual: "greaterThanOrEqual", lessThan: "lessThan", lessThanOrEqual: "lessThanOrEqual", notContains: "notContains", notEqual: "notEqual", startsWith: "startsWith" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListOperationDescriptionsComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-tree-list-operation-descriptions', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { between: [{
                type: Input
            }], contains: [{
                type: Input
            }], endsWith: [{
                type: Input
            }], equal: [{
                type: Input
            }], greaterThan: [{
                type: Input
            }], greaterThanOrEqual: [{
                type: Input
            }], lessThan: [{
                type: Input
            }], lessThanOrEqual: [{
                type: Input
            }], notContains: [{
                type: Input
            }], notEqual: [{
                type: Input
            }], startsWith: [{
                type: Input
            }] } });
class DxoTreeListOperationDescriptionsModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListOperationDescriptionsModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListOperationDescriptionsModule, imports: [DxoTreeListOperationDescriptionsComponent], exports: [DxoTreeListOperationDescriptionsComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListOperationDescriptionsModule, imports: [DxoTreeListOperationDescriptionsComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListOperationDescriptionsModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoTreeListOperationDescriptionsComponent
                    ],
                    exports: [
                        DxoTreeListOperationDescriptionsComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoTreeListOptionsComponent extends NestedOption {
    get accessKey() {
        return this._getOption('accessKey');
    }
    set accessKey(value) {
        this._setOption('accessKey', value);
    }
    get activeStateEnabled() {
        return this._getOption('activeStateEnabled');
    }
    set activeStateEnabled(value) {
        this._setOption('activeStateEnabled', value);
    }
    get disabled() {
        return this._getOption('disabled');
    }
    set disabled(value) {
        this._setOption('disabled', value);
    }
    get elementAttr() {
        return this._getOption('elementAttr');
    }
    set elementAttr(value) {
        this._setOption('elementAttr', value);
    }
    get focusStateEnabled() {
        return this._getOption('focusStateEnabled');
    }
    set focusStateEnabled(value) {
        this._setOption('focusStateEnabled', value);
    }
    get height() {
        return this._getOption('height');
    }
    set height(value) {
        this._setOption('height', value);
    }
    get hint() {
        return this._getOption('hint');
    }
    set hint(value) {
        this._setOption('hint', value);
    }
    get hoverStateEnabled() {
        return this._getOption('hoverStateEnabled');
    }
    set hoverStateEnabled(value) {
        this._setOption('hoverStateEnabled', value);
    }
    get icon() {
        return this._getOption('icon');
    }
    set icon(value) {
        this._setOption('icon', value);
    }
    get onClick() {
        return this._getOption('onClick');
    }
    set onClick(value) {
        this._setOption('onClick', value);
    }
    get onContentReady() {
        return this._getOption('onContentReady');
    }
    set onContentReady(value) {
        this._setOption('onContentReady', value);
    }
    get onDisposing() {
        return this._getOption('onDisposing');
    }
    set onDisposing(value) {
        this._setOption('onDisposing', value);
    }
    get onInitialized() {
        return this._getOption('onInitialized');
    }
    set onInitialized(value) {
        this._setOption('onInitialized', value);
    }
    get onOptionChanged() {
        return this._getOption('onOptionChanged');
    }
    set onOptionChanged(value) {
        this._setOption('onOptionChanged', value);
    }
    get rtlEnabled() {
        return this._getOption('rtlEnabled');
    }
    set rtlEnabled(value) {
        this._setOption('rtlEnabled', value);
    }
    get stylingMode() {
        return this._getOption('stylingMode');
    }
    set stylingMode(value) {
        this._setOption('stylingMode', value);
    }
    get tabIndex() {
        return this._getOption('tabIndex');
    }
    set tabIndex(value) {
        this._setOption('tabIndex', value);
    }
    get template() {
        return this._getOption('template');
    }
    set template(value) {
        this._setOption('template', value);
    }
    get text() {
        return this._getOption('text');
    }
    set text(value) {
        this._setOption('text', value);
    }
    get type() {
        return this._getOption('type');
    }
    set type(value) {
        this._setOption('type', value);
    }
    get useSubmitBehavior() {
        return this._getOption('useSubmitBehavior');
    }
    set useSubmitBehavior(value) {
        this._setOption('useSubmitBehavior', value);
    }
    get validationGroup() {
        return this._getOption('validationGroup');
    }
    set validationGroup(value) {
        this._setOption('validationGroup', value);
    }
    get visible() {
        return this._getOption('visible');
    }
    set visible(value) {
        this._setOption('visible', value);
    }
    get width() {
        return this._getOption('width');
    }
    set width(value) {
        this._setOption('width', value);
    }
    get _optionPath() {
        return 'options';
    }
    constructor(parentOptionHost, optionHost, renderer, document, templateHost, element) {
        super();
        this.renderer = renderer;
        this.document = document;
        this.element = element;
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
        templateHost.setHost(this);
    }
    setTemplate(template) {
        this.template = template;
    }
    ngAfterViewInit() {
        extractTemplate(this, this.element, this.renderer, this.document);
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListOptionsComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }, { token: i0.Renderer2 }, { token: DOCUMENT }, { token: i1.DxTemplateHost, host: true }, { token: i0.ElementRef }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoTreeListOptionsComponent, isStandalone: true, selector: "dxo-tree-list-options", inputs: { accessKey: "accessKey", activeStateEnabled: "activeStateEnabled", disabled: "disabled", elementAttr: "elementAttr", focusStateEnabled: "focusStateEnabled", height: "height", hint: "hint", hoverStateEnabled: "hoverStateEnabled", icon: "icon", onClick: "onClick", onContentReady: "onContentReady", onDisposing: "onDisposing", onInitialized: "onInitialized", onOptionChanged: "onOptionChanged", rtlEnabled: "rtlEnabled", stylingMode: "stylingMode", tabIndex: "tabIndex", template: "template", text: "text", type: "type", useSubmitBehavior: "useSubmitBehavior", validationGroup: "validationGroup", visible: "visible", width: "width" }, providers: [NestedOptionHost, DxTemplateHost], usesInheritance: true, ngImport: i0, template: '<ng-content></ng-content>', isInline: true, styles: [":host{display:block}\n"], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListOptionsComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-tree-list-options', template: '<ng-content></ng-content>', imports: [DxIntegrationModule], providers: [NestedOptionHost, DxTemplateHost], styles: [":host{display:block}\n"] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }, { type: i0.Renderer2 }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [DOCUMENT]
                }] }, { type: i1.DxTemplateHost, decorators: [{
                    type: Host
                }] }, { type: i0.ElementRef }], propDecorators: { accessKey: [{
                type: Input
            }], activeStateEnabled: [{
                type: Input
            }], disabled: [{
                type: Input
            }], elementAttr: [{
                type: Input
            }], focusStateEnabled: [{
                type: Input
            }], height: [{
                type: Input
            }], hint: [{
                type: Input
            }], hoverStateEnabled: [{
                type: Input
            }], icon: [{
                type: Input
            }], onClick: [{
                type: Input
            }], onContentReady: [{
                type: Input
            }], onDisposing: [{
                type: Input
            }], onInitialized: [{
                type: Input
            }], onOptionChanged: [{
                type: Input
            }], rtlEnabled: [{
                type: Input
            }], stylingMode: [{
                type: Input
            }], tabIndex: [{
                type: Input
            }], template: [{
                type: Input
            }], text: [{
                type: Input
            }], type: [{
                type: Input
            }], useSubmitBehavior: [{
                type: Input
            }], validationGroup: [{
                type: Input
            }], visible: [{
                type: Input
            }], width: [{
                type: Input
            }] } });
class DxoTreeListOptionsModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListOptionsModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListOptionsModule, imports: [DxoTreeListOptionsComponent], exports: [DxoTreeListOptionsComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListOptionsModule, imports: [DxoTreeListOptionsComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListOptionsModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoTreeListOptionsComponent
                    ],
                    exports: [
                        DxoTreeListOptionsComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoTreeListPagerComponent extends NestedOption {
    get allowedPageSizes() {
        return this._getOption('allowedPageSizes');
    }
    set allowedPageSizes(value) {
        this._setOption('allowedPageSizes', value);
    }
    get displayMode() {
        return this._getOption('displayMode');
    }
    set displayMode(value) {
        this._setOption('displayMode', value);
    }
    get infoText() {
        return this._getOption('infoText');
    }
    set infoText(value) {
        this._setOption('infoText', value);
    }
    get label() {
        return this._getOption('label');
    }
    set label(value) {
        this._setOption('label', value);
    }
    get showInfo() {
        return this._getOption('showInfo');
    }
    set showInfo(value) {
        this._setOption('showInfo', value);
    }
    get showNavigationButtons() {
        return this._getOption('showNavigationButtons');
    }
    set showNavigationButtons(value) {
        this._setOption('showNavigationButtons', value);
    }
    get showPageSizeSelector() {
        return this._getOption('showPageSizeSelector');
    }
    set showPageSizeSelector(value) {
        this._setOption('showPageSizeSelector', value);
    }
    get visible() {
        return this._getOption('visible');
    }
    set visible(value) {
        this._setOption('visible', value);
    }
    get _optionPath() {
        return 'pager';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListPagerComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoTreeListPagerComponent, isStandalone: true, selector: "dxo-tree-list-pager", inputs: { allowedPageSizes: "allowedPageSizes", displayMode: "displayMode", infoText: "infoText", label: "label", showInfo: "showInfo", showNavigationButtons: "showNavigationButtons", showPageSizeSelector: "showPageSizeSelector", visible: "visible" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListPagerComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-tree-list-pager', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { allowedPageSizes: [{
                type: Input
            }], displayMode: [{
                type: Input
            }], infoText: [{
                type: Input
            }], label: [{
                type: Input
            }], showInfo: [{
                type: Input
            }], showNavigationButtons: [{
                type: Input
            }], showPageSizeSelector: [{
                type: Input
            }], visible: [{
                type: Input
            }] } });
class DxoTreeListPagerModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListPagerModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListPagerModule, imports: [DxoTreeListPagerComponent], exports: [DxoTreeListPagerComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListPagerModule, imports: [DxoTreeListPagerComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListPagerModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoTreeListPagerComponent
                    ],
                    exports: [
                        DxoTreeListPagerComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoTreeListPagingComponent extends NestedOption {
    get enabled() {
        return this._getOption('enabled');
    }
    set enabled(value) {
        this._setOption('enabled', value);
    }
    get pageIndex() {
        return this._getOption('pageIndex');
    }
    set pageIndex(value) {
        this._setOption('pageIndex', value);
    }
    get pageSize() {
        return this._getOption('pageSize');
    }
    set pageSize(value) {
        this._setOption('pageSize', value);
    }
    get _optionPath() {
        return 'paging';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        this._createEventEmitters([
            { emit: 'pageIndexChange' },
            { emit: 'pageSizeChange' }
        ]);
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListPagingComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoTreeListPagingComponent, isStandalone: true, selector: "dxo-tree-list-paging", inputs: { enabled: "enabled", pageIndex: "pageIndex", pageSize: "pageSize" }, outputs: { pageIndexChange: "pageIndexChange", pageSizeChange: "pageSizeChange" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListPagingComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-tree-list-paging', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { enabled: [{
                type: Input
            }], pageIndex: [{
                type: Input
            }], pageSize: [{
                type: Input
            }], pageIndexChange: [{
                type: Output
            }], pageSizeChange: [{
                type: Output
            }] } });
class DxoTreeListPagingModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListPagingModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListPagingModule, imports: [DxoTreeListPagingComponent], exports: [DxoTreeListPagingComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListPagingModule, imports: [DxoTreeListPagingComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListPagingModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoTreeListPagingComponent
                    ],
                    exports: [
                        DxoTreeListPagingComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxiTreeListPatternRuleComponent extends CollectionNestedOption {
    get ignoreEmptyValue() {
        return this._getOption('ignoreEmptyValue');
    }
    set ignoreEmptyValue(value) {
        this._setOption('ignoreEmptyValue', value);
    }
    get message() {
        return this._getOption('message');
    }
    set message(value) {
        this._setOption('message', value);
    }
    get pattern() {
        return this._getOption('pattern');
    }
    set pattern(value) {
        this._setOption('pattern', value);
    }
    get type() {
        return this._getOption('type');
    }
    set type(value) {
        this._setOption('type', value);
    }
    get _optionPath() {
        return 'validationRules';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
        this.type = 'pattern';
    }
    ngOnDestroy() {
        this._deleteRemovedOptions(this._fullOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiTreeListPatternRuleComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxiTreeListPatternRuleComponent, isStandalone: true, selector: "dxi-tree-list-pattern-rule", inputs: { ignoreEmptyValue: "ignoreEmptyValue", message: "message", pattern: "pattern", type: "type" }, providers: [
            NestedOptionHost,
            {
                provide: PROPERTY_TOKEN_validationRules,
                useExisting: DxiTreeListPatternRuleComponent,
            }
        ], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiTreeListPatternRuleComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxi-tree-list-pattern-rule', template: '', imports: [DxIntegrationModule], providers: [
                        NestedOptionHost,
                        {
                            provide: PROPERTY_TOKEN_validationRules,
                            useExisting: DxiTreeListPatternRuleComponent,
                        }
                    ] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { ignoreEmptyValue: [{
                type: Input
            }], message: [{
                type: Input
            }], pattern: [{
                type: Input
            }], type: [{
                type: Input
            }] } });
class DxiTreeListPatternRuleModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiTreeListPatternRuleModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxiTreeListPatternRuleModule, imports: [DxiTreeListPatternRuleComponent], exports: [DxiTreeListPatternRuleComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiTreeListPatternRuleModule, imports: [DxiTreeListPatternRuleComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiTreeListPatternRuleModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxiTreeListPatternRuleComponent
                    ],
                    exports: [
                        DxiTreeListPatternRuleComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoTreeListPopupComponent extends NestedOption {
    set _toolbarItemsContentChildren(value) {
        this.setChildren('toolbarItems', value);
    }
    get accessKey() {
        return this._getOption('accessKey');
    }
    set accessKey(value) {
        this._setOption('accessKey', value);
    }
    get animation() {
        return this._getOption('animation');
    }
    set animation(value) {
        this._setOption('animation', value);
    }
    get container() {
        return this._getOption('container');
    }
    set container(value) {
        this._setOption('container', value);
    }
    get contentTemplate() {
        return this._getOption('contentTemplate');
    }
    set contentTemplate(value) {
        this._setOption('contentTemplate', value);
    }
    get deferRendering() {
        return this._getOption('deferRendering');
    }
    set deferRendering(value) {
        this._setOption('deferRendering', value);
    }
    get disabled() {
        return this._getOption('disabled');
    }
    set disabled(value) {
        this._setOption('disabled', value);
    }
    get dragAndResizeArea() {
        return this._getOption('dragAndResizeArea');
    }
    set dragAndResizeArea(value) {
        this._setOption('dragAndResizeArea', value);
    }
    get dragEnabled() {
        return this._getOption('dragEnabled');
    }
    set dragEnabled(value) {
        this._setOption('dragEnabled', value);
    }
    get dragOutsideBoundary() {
        return this._getOption('dragOutsideBoundary');
    }
    set dragOutsideBoundary(value) {
        this._setOption('dragOutsideBoundary', value);
    }
    get enableBodyScroll() {
        return this._getOption('enableBodyScroll');
    }
    set enableBodyScroll(value) {
        this._setOption('enableBodyScroll', value);
    }
    get focusStateEnabled() {
        return this._getOption('focusStateEnabled');
    }
    set focusStateEnabled(value) {
        this._setOption('focusStateEnabled', value);
    }
    get fullScreen() {
        return this._getOption('fullScreen');
    }
    set fullScreen(value) {
        this._setOption('fullScreen', value);
    }
    get height() {
        return this._getOption('height');
    }
    set height(value) {
        this._setOption('height', value);
    }
    get hideOnOutsideClick() {
        return this._getOption('hideOnOutsideClick');
    }
    set hideOnOutsideClick(value) {
        this._setOption('hideOnOutsideClick', value);
    }
    get hideOnParentScroll() {
        return this._getOption('hideOnParentScroll');
    }
    set hideOnParentScroll(value) {
        this._setOption('hideOnParentScroll', value);
    }
    get hint() {
        return this._getOption('hint');
    }
    set hint(value) {
        this._setOption('hint', value);
    }
    get hoverStateEnabled() {
        return this._getOption('hoverStateEnabled');
    }
    set hoverStateEnabled(value) {
        this._setOption('hoverStateEnabled', value);
    }
    get maxHeight() {
        return this._getOption('maxHeight');
    }
    set maxHeight(value) {
        this._setOption('maxHeight', value);
    }
    get maxWidth() {
        return this._getOption('maxWidth');
    }
    set maxWidth(value) {
        this._setOption('maxWidth', value);
    }
    get minHeight() {
        return this._getOption('minHeight');
    }
    set minHeight(value) {
        this._setOption('minHeight', value);
    }
    get minWidth() {
        return this._getOption('minWidth');
    }
    set minWidth(value) {
        this._setOption('minWidth', value);
    }
    get onContentReady() {
        return this._getOption('onContentReady');
    }
    set onContentReady(value) {
        this._setOption('onContentReady', value);
    }
    get onDisposing() {
        return this._getOption('onDisposing');
    }
    set onDisposing(value) {
        this._setOption('onDisposing', value);
    }
    get onHidden() {
        return this._getOption('onHidden');
    }
    set onHidden(value) {
        this._setOption('onHidden', value);
    }
    get onHiding() {
        return this._getOption('onHiding');
    }
    set onHiding(value) {
        this._setOption('onHiding', value);
    }
    get onInitialized() {
        return this._getOption('onInitialized');
    }
    set onInitialized(value) {
        this._setOption('onInitialized', value);
    }
    get onOptionChanged() {
        return this._getOption('onOptionChanged');
    }
    set onOptionChanged(value) {
        this._setOption('onOptionChanged', value);
    }
    get onResize() {
        return this._getOption('onResize');
    }
    set onResize(value) {
        this._setOption('onResize', value);
    }
    get onResizeEnd() {
        return this._getOption('onResizeEnd');
    }
    set onResizeEnd(value) {
        this._setOption('onResizeEnd', value);
    }
    get onResizeStart() {
        return this._getOption('onResizeStart');
    }
    set onResizeStart(value) {
        this._setOption('onResizeStart', value);
    }
    get onShowing() {
        return this._getOption('onShowing');
    }
    set onShowing(value) {
        this._setOption('onShowing', value);
    }
    get onShown() {
        return this._getOption('onShown');
    }
    set onShown(value) {
        this._setOption('onShown', value);
    }
    get onTitleRendered() {
        return this._getOption('onTitleRendered');
    }
    set onTitleRendered(value) {
        this._setOption('onTitleRendered', value);
    }
    get position() {
        return this._getOption('position');
    }
    set position(value) {
        this._setOption('position', value);
    }
    get resizeEnabled() {
        return this._getOption('resizeEnabled');
    }
    set resizeEnabled(value) {
        this._setOption('resizeEnabled', value);
    }
    get restorePosition() {
        return this._getOption('restorePosition');
    }
    set restorePosition(value) {
        this._setOption('restorePosition', value);
    }
    get rtlEnabled() {
        return this._getOption('rtlEnabled');
    }
    set rtlEnabled(value) {
        this._setOption('rtlEnabled', value);
    }
    get shading() {
        return this._getOption('shading');
    }
    set shading(value) {
        this._setOption('shading', value);
    }
    get shadingColor() {
        return this._getOption('shadingColor');
    }
    set shadingColor(value) {
        this._setOption('shadingColor', value);
    }
    get showCloseButton() {
        return this._getOption('showCloseButton');
    }
    set showCloseButton(value) {
        this._setOption('showCloseButton', value);
    }
    get showTitle() {
        return this._getOption('showTitle');
    }
    set showTitle(value) {
        this._setOption('showTitle', value);
    }
    get tabFocusLoopEnabled() {
        return this._getOption('tabFocusLoopEnabled');
    }
    set tabFocusLoopEnabled(value) {
        this._setOption('tabFocusLoopEnabled', value);
    }
    get tabIndex() {
        return this._getOption('tabIndex');
    }
    set tabIndex(value) {
        this._setOption('tabIndex', value);
    }
    get title() {
        return this._getOption('title');
    }
    set title(value) {
        this._setOption('title', value);
    }
    get titleTemplate() {
        return this._getOption('titleTemplate');
    }
    set titleTemplate(value) {
        this._setOption('titleTemplate', value);
    }
    get toolbarItems() {
        return this._getOption('toolbarItems');
    }
    set toolbarItems(value) {
        this._setOption('toolbarItems', value);
    }
    get visible() {
        return this._getOption('visible');
    }
    set visible(value) {
        this._setOption('visible', value);
    }
    get width() {
        return this._getOption('width');
    }
    set width(value) {
        this._setOption('width', value);
    }
    get wrapperAttr() {
        return this._getOption('wrapperAttr');
    }
    set wrapperAttr(value) {
        this._setOption('wrapperAttr', value);
    }
    get _optionPath() {
        return 'popup';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        this._createEventEmitters([
            { emit: 'heightChange' },
            { emit: 'positionChange' },
            { emit: 'visibleChange' },
            { emit: 'widthChange' }
        ]);
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListPopupComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoTreeListPopupComponent, isStandalone: true, selector: "dxo-tree-list-popup", inputs: { accessKey: "accessKey", animation: "animation", container: "container", contentTemplate: "contentTemplate", deferRendering: "deferRendering", disabled: "disabled", dragAndResizeArea: "dragAndResizeArea", dragEnabled: "dragEnabled", dragOutsideBoundary: "dragOutsideBoundary", enableBodyScroll: "enableBodyScroll", focusStateEnabled: "focusStateEnabled", fullScreen: "fullScreen", height: "height", hideOnOutsideClick: "hideOnOutsideClick", hideOnParentScroll: "hideOnParentScroll", hint: "hint", hoverStateEnabled: "hoverStateEnabled", maxHeight: "maxHeight", maxWidth: "maxWidth", minHeight: "minHeight", minWidth: "minWidth", onContentReady: "onContentReady", onDisposing: "onDisposing", onHidden: "onHidden", onHiding: "onHiding", onInitialized: "onInitialized", onOptionChanged: "onOptionChanged", onResize: "onResize", onResizeEnd: "onResizeEnd", onResizeStart: "onResizeStart", onShowing: "onShowing", onShown: "onShown", onTitleRendered: "onTitleRendered", position: "position", resizeEnabled: "resizeEnabled", restorePosition: "restorePosition", rtlEnabled: "rtlEnabled", shading: "shading", shadingColor: "shadingColor", showCloseButton: "showCloseButton", showTitle: "showTitle", tabFocusLoopEnabled: "tabFocusLoopEnabled", tabIndex: "tabIndex", title: "title", titleTemplate: "titleTemplate", toolbarItems: "toolbarItems", visible: "visible", width: "width", wrapperAttr: "wrapperAttr" }, outputs: { heightChange: "heightChange", positionChange: "positionChange", visibleChange: "visibleChange", widthChange: "widthChange" }, providers: [NestedOptionHost], queries: [{ propertyName: "_toolbarItemsContentChildren", predicate: PROPERTY_TOKEN_toolbarItems }], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListPopupComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-tree-list-popup', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { _toolbarItemsContentChildren: [{
                type: ContentChildren,
                args: [PROPERTY_TOKEN_toolbarItems]
            }], accessKey: [{
                type: Input
            }], animation: [{
                type: Input
            }], container: [{
                type: Input
            }], contentTemplate: [{
                type: Input
            }], deferRendering: [{
                type: Input
            }], disabled: [{
                type: Input
            }], dragAndResizeArea: [{
                type: Input
            }], dragEnabled: [{
                type: Input
            }], dragOutsideBoundary: [{
                type: Input
            }], enableBodyScroll: [{
                type: Input
            }], focusStateEnabled: [{
                type: Input
            }], fullScreen: [{
                type: Input
            }], height: [{
                type: Input
            }], hideOnOutsideClick: [{
                type: Input
            }], hideOnParentScroll: [{
                type: Input
            }], hint: [{
                type: Input
            }], hoverStateEnabled: [{
                type: Input
            }], maxHeight: [{
                type: Input
            }], maxWidth: [{
                type: Input
            }], minHeight: [{
                type: Input
            }], minWidth: [{
                type: Input
            }], onContentReady: [{
                type: Input
            }], onDisposing: [{
                type: Input
            }], onHidden: [{
                type: Input
            }], onHiding: [{
                type: Input
            }], onInitialized: [{
                type: Input
            }], onOptionChanged: [{
                type: Input
            }], onResize: [{
                type: Input
            }], onResizeEnd: [{
                type: Input
            }], onResizeStart: [{
                type: Input
            }], onShowing: [{
                type: Input
            }], onShown: [{
                type: Input
            }], onTitleRendered: [{
                type: Input
            }], position: [{
                type: Input
            }], resizeEnabled: [{
                type: Input
            }], restorePosition: [{
                type: Input
            }], rtlEnabled: [{
                type: Input
            }], shading: [{
                type: Input
            }], shadingColor: [{
                type: Input
            }], showCloseButton: [{
                type: Input
            }], showTitle: [{
                type: Input
            }], tabFocusLoopEnabled: [{
                type: Input
            }], tabIndex: [{
                type: Input
            }], title: [{
                type: Input
            }], titleTemplate: [{
                type: Input
            }], toolbarItems: [{
                type: Input
            }], visible: [{
                type: Input
            }], width: [{
                type: Input
            }], wrapperAttr: [{
                type: Input
            }], heightChange: [{
                type: Output
            }], positionChange: [{
                type: Output
            }], visibleChange: [{
                type: Output
            }], widthChange: [{
                type: Output
            }] } });
class DxoTreeListPopupModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListPopupModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListPopupModule, imports: [DxoTreeListPopupComponent], exports: [DxoTreeListPopupComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListPopupModule, imports: [DxoTreeListPopupComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListPopupModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoTreeListPopupComponent
                    ],
                    exports: [
                        DxoTreeListPopupComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoTreeListPositionComponent extends NestedOption {
    get at() {
        return this._getOption('at');
    }
    set at(value) {
        this._setOption('at', value);
    }
    get boundary() {
        return this._getOption('boundary');
    }
    set boundary(value) {
        this._setOption('boundary', value);
    }
    get boundaryOffset() {
        return this._getOption('boundaryOffset');
    }
    set boundaryOffset(value) {
        this._setOption('boundaryOffset', value);
    }
    get collision() {
        return this._getOption('collision');
    }
    set collision(value) {
        this._setOption('collision', value);
    }
    get my() {
        return this._getOption('my');
    }
    set my(value) {
        this._setOption('my', value);
    }
    get of() {
        return this._getOption('of');
    }
    set of(value) {
        this._setOption('of', value);
    }
    get offset() {
        return this._getOption('offset');
    }
    set offset(value) {
        this._setOption('offset', value);
    }
    get _optionPath() {
        return 'position';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListPositionComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoTreeListPositionComponent, isStandalone: true, selector: "dxo-tree-list-position", inputs: { at: "at", boundary: "boundary", boundaryOffset: "boundaryOffset", collision: "collision", my: "my", of: "of", offset: "offset" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListPositionComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-tree-list-position', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { at: [{
                type: Input
            }], boundary: [{
                type: Input
            }], boundaryOffset: [{
                type: Input
            }], collision: [{
                type: Input
            }], my: [{
                type: Input
            }], of: [{
                type: Input
            }], offset: [{
                type: Input
            }] } });
class DxoTreeListPositionModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListPositionModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListPositionModule, imports: [DxoTreeListPositionComponent], exports: [DxoTreeListPositionComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListPositionModule, imports: [DxoTreeListPositionComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListPositionModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoTreeListPositionComponent
                    ],
                    exports: [
                        DxoTreeListPositionComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxiTreeListRangeRuleComponent extends CollectionNestedOption {
    get ignoreEmptyValue() {
        return this._getOption('ignoreEmptyValue');
    }
    set ignoreEmptyValue(value) {
        this._setOption('ignoreEmptyValue', value);
    }
    get max() {
        return this._getOption('max');
    }
    set max(value) {
        this._setOption('max', value);
    }
    get message() {
        return this._getOption('message');
    }
    set message(value) {
        this._setOption('message', value);
    }
    get min() {
        return this._getOption('min');
    }
    set min(value) {
        this._setOption('min', value);
    }
    get reevaluate() {
        return this._getOption('reevaluate');
    }
    set reevaluate(value) {
        this._setOption('reevaluate', value);
    }
    get type() {
        return this._getOption('type');
    }
    set type(value) {
        this._setOption('type', value);
    }
    get _optionPath() {
        return 'validationRules';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
        this.type = 'range';
    }
    ngOnDestroy() {
        this._deleteRemovedOptions(this._fullOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiTreeListRangeRuleComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxiTreeListRangeRuleComponent, isStandalone: true, selector: "dxi-tree-list-range-rule", inputs: { ignoreEmptyValue: "ignoreEmptyValue", max: "max", message: "message", min: "min", reevaluate: "reevaluate", type: "type" }, providers: [
            NestedOptionHost,
            {
                provide: PROPERTY_TOKEN_validationRules,
                useExisting: DxiTreeListRangeRuleComponent,
            }
        ], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiTreeListRangeRuleComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxi-tree-list-range-rule', template: '', imports: [DxIntegrationModule], providers: [
                        NestedOptionHost,
                        {
                            provide: PROPERTY_TOKEN_validationRules,
                            useExisting: DxiTreeListRangeRuleComponent,
                        }
                    ] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { ignoreEmptyValue: [{
                type: Input
            }], max: [{
                type: Input
            }], message: [{
                type: Input
            }], min: [{
                type: Input
            }], reevaluate: [{
                type: Input
            }], type: [{
                type: Input
            }] } });
class DxiTreeListRangeRuleModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiTreeListRangeRuleModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxiTreeListRangeRuleModule, imports: [DxiTreeListRangeRuleComponent], exports: [DxiTreeListRangeRuleComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiTreeListRangeRuleModule, imports: [DxiTreeListRangeRuleComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiTreeListRangeRuleModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxiTreeListRangeRuleComponent
                    ],
                    exports: [
                        DxiTreeListRangeRuleComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoTreeListRemoteOperationsComponent extends NestedOption {
    get filtering() {
        return this._getOption('filtering');
    }
    set filtering(value) {
        this._setOption('filtering', value);
    }
    get grouping() {
        return this._getOption('grouping');
    }
    set grouping(value) {
        this._setOption('grouping', value);
    }
    get sorting() {
        return this._getOption('sorting');
    }
    set sorting(value) {
        this._setOption('sorting', value);
    }
    get _optionPath() {
        return 'remoteOperations';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListRemoteOperationsComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoTreeListRemoteOperationsComponent, isStandalone: true, selector: "dxo-tree-list-remote-operations", inputs: { filtering: "filtering", grouping: "grouping", sorting: "sorting" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListRemoteOperationsComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-tree-list-remote-operations', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { filtering: [{
                type: Input
            }], grouping: [{
                type: Input
            }], sorting: [{
                type: Input
            }] } });
class DxoTreeListRemoteOperationsModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListRemoteOperationsModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListRemoteOperationsModule, imports: [DxoTreeListRemoteOperationsComponent], exports: [DxoTreeListRemoteOperationsComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListRemoteOperationsModule, imports: [DxoTreeListRemoteOperationsComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListRemoteOperationsModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoTreeListRemoteOperationsComponent
                    ],
                    exports: [
                        DxoTreeListRemoteOperationsComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxiTreeListRequiredRuleComponent extends CollectionNestedOption {
    get message() {
        return this._getOption('message');
    }
    set message(value) {
        this._setOption('message', value);
    }
    get trim() {
        return this._getOption('trim');
    }
    set trim(value) {
        this._setOption('trim', value);
    }
    get type() {
        return this._getOption('type');
    }
    set type(value) {
        this._setOption('type', value);
    }
    get _optionPath() {
        return 'validationRules';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
        this.type = 'required';
    }
    ngOnDestroy() {
        this._deleteRemovedOptions(this._fullOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiTreeListRequiredRuleComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxiTreeListRequiredRuleComponent, isStandalone: true, selector: "dxi-tree-list-required-rule", inputs: { message: "message", trim: "trim", type: "type" }, providers: [
            NestedOptionHost,
            {
                provide: PROPERTY_TOKEN_validationRules,
                useExisting: DxiTreeListRequiredRuleComponent,
            }
        ], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiTreeListRequiredRuleComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxi-tree-list-required-rule', template: '', imports: [DxIntegrationModule], providers: [
                        NestedOptionHost,
                        {
                            provide: PROPERTY_TOKEN_validationRules,
                            useExisting: DxiTreeListRequiredRuleComponent,
                        }
                    ] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { message: [{
                type: Input
            }], trim: [{
                type: Input
            }], type: [{
                type: Input
            }] } });
class DxiTreeListRequiredRuleModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiTreeListRequiredRuleModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxiTreeListRequiredRuleModule, imports: [DxiTreeListRequiredRuleComponent], exports: [DxiTreeListRequiredRuleComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiTreeListRequiredRuleModule, imports: [DxiTreeListRequiredRuleComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiTreeListRequiredRuleModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxiTreeListRequiredRuleComponent
                    ],
                    exports: [
                        DxiTreeListRequiredRuleComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoTreeListRowDraggingComponent extends NestedOption {
    get allowDropInsideItem() {
        return this._getOption('allowDropInsideItem');
    }
    set allowDropInsideItem(value) {
        this._setOption('allowDropInsideItem', value);
    }
    get allowReordering() {
        return this._getOption('allowReordering');
    }
    set allowReordering(value) {
        this._setOption('allowReordering', value);
    }
    get autoScroll() {
        return this._getOption('autoScroll');
    }
    set autoScroll(value) {
        this._setOption('autoScroll', value);
    }
    get boundary() {
        return this._getOption('boundary');
    }
    set boundary(value) {
        this._setOption('boundary', value);
    }
    get container() {
        return this._getOption('container');
    }
    set container(value) {
        this._setOption('container', value);
    }
    get cursorOffset() {
        return this._getOption('cursorOffset');
    }
    set cursorOffset(value) {
        this._setOption('cursorOffset', value);
    }
    get data() {
        return this._getOption('data');
    }
    set data(value) {
        this._setOption('data', value);
    }
    get dragDirection() {
        return this._getOption('dragDirection');
    }
    set dragDirection(value) {
        this._setOption('dragDirection', value);
    }
    get dragTemplate() {
        return this._getOption('dragTemplate');
    }
    set dragTemplate(value) {
        this._setOption('dragTemplate', value);
    }
    get dropFeedbackMode() {
        return this._getOption('dropFeedbackMode');
    }
    set dropFeedbackMode(value) {
        this._setOption('dropFeedbackMode', value);
    }
    get filter() {
        return this._getOption('filter');
    }
    set filter(value) {
        this._setOption('filter', value);
    }
    get group() {
        return this._getOption('group');
    }
    set group(value) {
        this._setOption('group', value);
    }
    get handle() {
        return this._getOption('handle');
    }
    set handle(value) {
        this._setOption('handle', value);
    }
    get onAdd() {
        return this._getOption('onAdd');
    }
    set onAdd(value) {
        this._setOption('onAdd', value);
    }
    get onDragChange() {
        return this._getOption('onDragChange');
    }
    set onDragChange(value) {
        this._setOption('onDragChange', value);
    }
    get onDragEnd() {
        return this._getOption('onDragEnd');
    }
    set onDragEnd(value) {
        this._setOption('onDragEnd', value);
    }
    get onDragMove() {
        return this._getOption('onDragMove');
    }
    set onDragMove(value) {
        this._setOption('onDragMove', value);
    }
    get onDragStart() {
        return this._getOption('onDragStart');
    }
    set onDragStart(value) {
        this._setOption('onDragStart', value);
    }
    get onRemove() {
        return this._getOption('onRemove');
    }
    set onRemove(value) {
        this._setOption('onRemove', value);
    }
    get onReorder() {
        return this._getOption('onReorder');
    }
    set onReorder(value) {
        this._setOption('onReorder', value);
    }
    get scrollSensitivity() {
        return this._getOption('scrollSensitivity');
    }
    set scrollSensitivity(value) {
        this._setOption('scrollSensitivity', value);
    }
    get scrollSpeed() {
        return this._getOption('scrollSpeed');
    }
    set scrollSpeed(value) {
        this._setOption('scrollSpeed', value);
    }
    get showDragIcons() {
        return this._getOption('showDragIcons');
    }
    set showDragIcons(value) {
        this._setOption('showDragIcons', value);
    }
    get _optionPath() {
        return 'rowDragging';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListRowDraggingComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoTreeListRowDraggingComponent, isStandalone: true, selector: "dxo-tree-list-row-dragging", inputs: { allowDropInsideItem: "allowDropInsideItem", allowReordering: "allowReordering", autoScroll: "autoScroll", boundary: "boundary", container: "container", cursorOffset: "cursorOffset", data: "data", dragDirection: "dragDirection", dragTemplate: "dragTemplate", dropFeedbackMode: "dropFeedbackMode", filter: "filter", group: "group", handle: "handle", onAdd: "onAdd", onDragChange: "onDragChange", onDragEnd: "onDragEnd", onDragMove: "onDragMove", onDragStart: "onDragStart", onRemove: "onRemove", onReorder: "onReorder", scrollSensitivity: "scrollSensitivity", scrollSpeed: "scrollSpeed", showDragIcons: "showDragIcons" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListRowDraggingComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-tree-list-row-dragging', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { allowDropInsideItem: [{
                type: Input
            }], allowReordering: [{
                type: Input
            }], autoScroll: [{
                type: Input
            }], boundary: [{
                type: Input
            }], container: [{
                type: Input
            }], cursorOffset: [{
                type: Input
            }], data: [{
                type: Input
            }], dragDirection: [{
                type: Input
            }], dragTemplate: [{
                type: Input
            }], dropFeedbackMode: [{
                type: Input
            }], filter: [{
                type: Input
            }], group: [{
                type: Input
            }], handle: [{
                type: Input
            }], onAdd: [{
                type: Input
            }], onDragChange: [{
                type: Input
            }], onDragEnd: [{
                type: Input
            }], onDragMove: [{
                type: Input
            }], onDragStart: [{
                type: Input
            }], onRemove: [{
                type: Input
            }], onReorder: [{
                type: Input
            }], scrollSensitivity: [{
                type: Input
            }], scrollSpeed: [{
                type: Input
            }], showDragIcons: [{
                type: Input
            }] } });
class DxoTreeListRowDraggingModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListRowDraggingModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListRowDraggingModule, imports: [DxoTreeListRowDraggingComponent], exports: [DxoTreeListRowDraggingComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListRowDraggingModule, imports: [DxoTreeListRowDraggingComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListRowDraggingModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoTreeListRowDraggingComponent
                    ],
                    exports: [
                        DxoTreeListRowDraggingComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoTreeListScrollingComponent extends NestedOption {
    get columnRenderingMode() {
        return this._getOption('columnRenderingMode');
    }
    set columnRenderingMode(value) {
        this._setOption('columnRenderingMode', value);
    }
    get mode() {
        return this._getOption('mode');
    }
    set mode(value) {
        this._setOption('mode', value);
    }
    get preloadEnabled() {
        return this._getOption('preloadEnabled');
    }
    set preloadEnabled(value) {
        this._setOption('preloadEnabled', value);
    }
    get renderAsync() {
        return this._getOption('renderAsync');
    }
    set renderAsync(value) {
        this._setOption('renderAsync', value);
    }
    get rowRenderingMode() {
        return this._getOption('rowRenderingMode');
    }
    set rowRenderingMode(value) {
        this._setOption('rowRenderingMode', value);
    }
    get scrollByContent() {
        return this._getOption('scrollByContent');
    }
    set scrollByContent(value) {
        this._setOption('scrollByContent', value);
    }
    get scrollByThumb() {
        return this._getOption('scrollByThumb');
    }
    set scrollByThumb(value) {
        this._setOption('scrollByThumb', value);
    }
    get showScrollbar() {
        return this._getOption('showScrollbar');
    }
    set showScrollbar(value) {
        this._setOption('showScrollbar', value);
    }
    get useNative() {
        return this._getOption('useNative');
    }
    set useNative(value) {
        this._setOption('useNative', value);
    }
    get _optionPath() {
        return 'scrolling';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListScrollingComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoTreeListScrollingComponent, isStandalone: true, selector: "dxo-tree-list-scrolling", inputs: { columnRenderingMode: "columnRenderingMode", mode: "mode", preloadEnabled: "preloadEnabled", renderAsync: "renderAsync", rowRenderingMode: "rowRenderingMode", scrollByContent: "scrollByContent", scrollByThumb: "scrollByThumb", showScrollbar: "showScrollbar", useNative: "useNative" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListScrollingComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-tree-list-scrolling', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { columnRenderingMode: [{
                type: Input
            }], mode: [{
                type: Input
            }], preloadEnabled: [{
                type: Input
            }], renderAsync: [{
                type: Input
            }], rowRenderingMode: [{
                type: Input
            }], scrollByContent: [{
                type: Input
            }], scrollByThumb: [{
                type: Input
            }], showScrollbar: [{
                type: Input
            }], useNative: [{
                type: Input
            }] } });
class DxoTreeListScrollingModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListScrollingModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListScrollingModule, imports: [DxoTreeListScrollingComponent], exports: [DxoTreeListScrollingComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListScrollingModule, imports: [DxoTreeListScrollingComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListScrollingModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoTreeListScrollingComponent
                    ],
                    exports: [
                        DxoTreeListScrollingComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoTreeListSearchPanelComponent extends NestedOption {
    get highlightCaseSensitive() {
        return this._getOption('highlightCaseSensitive');
    }
    set highlightCaseSensitive(value) {
        this._setOption('highlightCaseSensitive', value);
    }
    get highlightSearchText() {
        return this._getOption('highlightSearchText');
    }
    set highlightSearchText(value) {
        this._setOption('highlightSearchText', value);
    }
    get placeholder() {
        return this._getOption('placeholder');
    }
    set placeholder(value) {
        this._setOption('placeholder', value);
    }
    get searchVisibleColumnsOnly() {
        return this._getOption('searchVisibleColumnsOnly');
    }
    set searchVisibleColumnsOnly(value) {
        this._setOption('searchVisibleColumnsOnly', value);
    }
    get text() {
        return this._getOption('text');
    }
    set text(value) {
        this._setOption('text', value);
    }
    get visible() {
        return this._getOption('visible');
    }
    set visible(value) {
        this._setOption('visible', value);
    }
    get width() {
        return this._getOption('width');
    }
    set width(value) {
        this._setOption('width', value);
    }
    get _optionPath() {
        return 'searchPanel';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        this._createEventEmitters([
            { emit: 'textChange' }
        ]);
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListSearchPanelComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoTreeListSearchPanelComponent, isStandalone: true, selector: "dxo-tree-list-search-panel", inputs: { highlightCaseSensitive: "highlightCaseSensitive", highlightSearchText: "highlightSearchText", placeholder: "placeholder", searchVisibleColumnsOnly: "searchVisibleColumnsOnly", text: "text", visible: "visible", width: "width" }, outputs: { textChange: "textChange" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListSearchPanelComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-tree-list-search-panel', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { highlightCaseSensitive: [{
                type: Input
            }], highlightSearchText: [{
                type: Input
            }], placeholder: [{
                type: Input
            }], searchVisibleColumnsOnly: [{
                type: Input
            }], text: [{
                type: Input
            }], visible: [{
                type: Input
            }], width: [{
                type: Input
            }], textChange: [{
                type: Output
            }] } });
class DxoTreeListSearchPanelModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListSearchPanelModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListSearchPanelModule, imports: [DxoTreeListSearchPanelComponent], exports: [DxoTreeListSearchPanelComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListSearchPanelModule, imports: [DxoTreeListSearchPanelComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListSearchPanelModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoTreeListSearchPanelComponent
                    ],
                    exports: [
                        DxoTreeListSearchPanelComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoTreeListSearchComponent extends NestedOption {
    get editorOptions() {
        return this._getOption('editorOptions');
    }
    set editorOptions(value) {
        this._setOption('editorOptions', value);
    }
    get enabled() {
        return this._getOption('enabled');
    }
    set enabled(value) {
        this._setOption('enabled', value);
    }
    get mode() {
        return this._getOption('mode');
    }
    set mode(value) {
        this._setOption('mode', value);
    }
    get searchExpr() {
        return this._getOption('searchExpr');
    }
    set searchExpr(value) {
        this._setOption('searchExpr', value);
    }
    get timeout() {
        return this._getOption('timeout');
    }
    set timeout(value) {
        this._setOption('timeout', value);
    }
    get _optionPath() {
        return 'search';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListSearchComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoTreeListSearchComponent, isStandalone: true, selector: "dxo-tree-list-search", inputs: { editorOptions: "editorOptions", enabled: "enabled", mode: "mode", searchExpr: "searchExpr", timeout: "timeout" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListSearchComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-tree-list-search', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { editorOptions: [{
                type: Input
            }], enabled: [{
                type: Input
            }], mode: [{
                type: Input
            }], searchExpr: [{
                type: Input
            }], timeout: [{
                type: Input
            }] } });
class DxoTreeListSearchModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListSearchModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListSearchModule, imports: [DxoTreeListSearchComponent], exports: [DxoTreeListSearchComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListSearchModule, imports: [DxoTreeListSearchComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListSearchModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoTreeListSearchComponent
                    ],
                    exports: [
                        DxoTreeListSearchComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoTreeListSelectionComponent extends NestedOption {
    get allowSelectAll() {
        return this._getOption('allowSelectAll');
    }
    set allowSelectAll(value) {
        this._setOption('allowSelectAll', value);
    }
    get mode() {
        return this._getOption('mode');
    }
    set mode(value) {
        this._setOption('mode', value);
    }
    get recursive() {
        return this._getOption('recursive');
    }
    set recursive(value) {
        this._setOption('recursive', value);
    }
    get selectByClick() {
        return this._getOption('selectByClick');
    }
    set selectByClick(value) {
        this._setOption('selectByClick', value);
    }
    get _optionPath() {
        return 'selection';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListSelectionComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoTreeListSelectionComponent, isStandalone: true, selector: "dxo-tree-list-selection", inputs: { allowSelectAll: "allowSelectAll", mode: "mode", recursive: "recursive", selectByClick: "selectByClick" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListSelectionComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-tree-list-selection', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { allowSelectAll: [{
                type: Input
            }], mode: [{
                type: Input
            }], recursive: [{
                type: Input
            }], selectByClick: [{
                type: Input
            }] } });
class DxoTreeListSelectionModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListSelectionModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListSelectionModule, imports: [DxoTreeListSelectionComponent], exports: [DxoTreeListSelectionComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListSelectionModule, imports: [DxoTreeListSelectionComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListSelectionModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoTreeListSelectionComponent
                    ],
                    exports: [
                        DxoTreeListSelectionComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoTreeListShowComponent extends NestedOption {
    get complete() {
        return this._getOption('complete');
    }
    set complete(value) {
        this._setOption('complete', value);
    }
    get delay() {
        return this._getOption('delay');
    }
    set delay(value) {
        this._setOption('delay', value);
    }
    get direction() {
        return this._getOption('direction');
    }
    set direction(value) {
        this._setOption('direction', value);
    }
    get duration() {
        return this._getOption('duration');
    }
    set duration(value) {
        this._setOption('duration', value);
    }
    get easing() {
        return this._getOption('easing');
    }
    set easing(value) {
        this._setOption('easing', value);
    }
    get from() {
        return this._getOption('from');
    }
    set from(value) {
        this._setOption('from', value);
    }
    get staggerDelay() {
        return this._getOption('staggerDelay');
    }
    set staggerDelay(value) {
        this._setOption('staggerDelay', value);
    }
    get start() {
        return this._getOption('start');
    }
    set start(value) {
        this._setOption('start', value);
    }
    get to() {
        return this._getOption('to');
    }
    set to(value) {
        this._setOption('to', value);
    }
    get type() {
        return this._getOption('type');
    }
    set type(value) {
        this._setOption('type', value);
    }
    get _optionPath() {
        return 'show';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListShowComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoTreeListShowComponent, isStandalone: true, selector: "dxo-tree-list-show", inputs: { complete: "complete", delay: "delay", direction: "direction", duration: "duration", easing: "easing", from: "from", staggerDelay: "staggerDelay", start: "start", to: "to", type: "type" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListShowComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-tree-list-show', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { complete: [{
                type: Input
            }], delay: [{
                type: Input
            }], direction: [{
                type: Input
            }], duration: [{
                type: Input
            }], easing: [{
                type: Input
            }], from: [{
                type: Input
            }], staggerDelay: [{
                type: Input
            }], start: [{
                type: Input
            }], to: [{
                type: Input
            }], type: [{
                type: Input
            }] } });
class DxoTreeListShowModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListShowModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListShowModule, imports: [DxoTreeListShowComponent], exports: [DxoTreeListShowComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListShowModule, imports: [DxoTreeListShowComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListShowModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoTreeListShowComponent
                    ],
                    exports: [
                        DxoTreeListShowComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxiTreeListSimpleItemComponent extends CollectionNestedOption {
    set _validationRulesContentChildren(value) {
        this.setChildren('validationRules', value);
    }
    get aiOptions() {
        return this._getOption('aiOptions');
    }
    set aiOptions(value) {
        this._setOption('aiOptions', value);
    }
    get colSpan() {
        return this._getOption('colSpan');
    }
    set colSpan(value) {
        this._setOption('colSpan', value);
    }
    get cssClass() {
        return this._getOption('cssClass');
    }
    set cssClass(value) {
        this._setOption('cssClass', value);
    }
    get dataField() {
        return this._getOption('dataField');
    }
    set dataField(value) {
        this._setOption('dataField', value);
    }
    get editorOptions() {
        return this._getOption('editorOptions');
    }
    set editorOptions(value) {
        this._setOption('editorOptions', value);
    }
    get editorType() {
        return this._getOption('editorType');
    }
    set editorType(value) {
        this._setOption('editorType', value);
    }
    get helpText() {
        return this._getOption('helpText');
    }
    set helpText(value) {
        this._setOption('helpText', value);
    }
    get isRequired() {
        return this._getOption('isRequired');
    }
    set isRequired(value) {
        this._setOption('isRequired', value);
    }
    get itemType() {
        return this._getOption('itemType');
    }
    set itemType(value) {
        this._setOption('itemType', value);
    }
    get label() {
        return this._getOption('label');
    }
    set label(value) {
        this._setOption('label', value);
    }
    get name() {
        return this._getOption('name');
    }
    set name(value) {
        this._setOption('name', value);
    }
    get template() {
        return this._getOption('template');
    }
    set template(value) {
        this._setOption('template', value);
    }
    get validationRules() {
        return this._getOption('validationRules');
    }
    set validationRules(value) {
        this._setOption('validationRules', value);
    }
    get visible() {
        return this._getOption('visible');
    }
    set visible(value) {
        this._setOption('visible', value);
    }
    get visibleIndex() {
        return this._getOption('visibleIndex');
    }
    set visibleIndex(value) {
        this._setOption('visibleIndex', value);
    }
    get _optionPath() {
        return 'items';
    }
    constructor(parentOptionHost, optionHost, renderer, document, templateHost, element) {
        super();
        this.renderer = renderer;
        this.document = document;
        this.element = element;
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
        templateHost.setHost(this);
        this.itemType = 'simple';
    }
    setTemplate(template) {
        this.template = template;
    }
    ngAfterViewInit() {
        extractTemplate(this, this.element, this.renderer, this.document);
    }
    ngOnDestroy() {
        this._deleteRemovedOptions(this._fullOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiTreeListSimpleItemComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }, { token: i0.Renderer2 }, { token: DOCUMENT }, { token: i1.DxTemplateHost, host: true }, { token: i0.ElementRef }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxiTreeListSimpleItemComponent, isStandalone: true, selector: "dxi-tree-list-simple-item", inputs: { aiOptions: "aiOptions", colSpan: "colSpan", cssClass: "cssClass", dataField: "dataField", editorOptions: "editorOptions", editorType: "editorType", helpText: "helpText", isRequired: "isRequired", itemType: "itemType", label: "label", name: "name", template: "template", validationRules: "validationRules", visible: "visible", visibleIndex: "visibleIndex" }, providers: [
            NestedOptionHost,
            DxTemplateHost,
            {
                provide: PROPERTY_TOKEN_items,
                useExisting: DxiTreeListSimpleItemComponent,
            }
        ], queries: [{ propertyName: "_validationRulesContentChildren", predicate: PROPERTY_TOKEN_validationRules }], usesInheritance: true, ngImport: i0, template: '<ng-content></ng-content>', isInline: true, styles: [":host{display:block}\n"], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiTreeListSimpleItemComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxi-tree-list-simple-item', template: '<ng-content></ng-content>', imports: [DxIntegrationModule], providers: [
                        NestedOptionHost,
                        DxTemplateHost,
                        {
                            provide: PROPERTY_TOKEN_items,
                            useExisting: DxiTreeListSimpleItemComponent,
                        }
                    ], styles: [":host{display:block}\n"] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }, { type: i0.Renderer2 }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [DOCUMENT]
                }] }, { type: i1.DxTemplateHost, decorators: [{
                    type: Host
                }] }, { type: i0.ElementRef }], propDecorators: { _validationRulesContentChildren: [{
                type: ContentChildren,
                args: [PROPERTY_TOKEN_validationRules]
            }], aiOptions: [{
                type: Input
            }], colSpan: [{
                type: Input
            }], cssClass: [{
                type: Input
            }], dataField: [{
                type: Input
            }], editorOptions: [{
                type: Input
            }], editorType: [{
                type: Input
            }], helpText: [{
                type: Input
            }], isRequired: [{
                type: Input
            }], itemType: [{
                type: Input
            }], label: [{
                type: Input
            }], name: [{
                type: Input
            }], template: [{
                type: Input
            }], validationRules: [{
                type: Input
            }], visible: [{
                type: Input
            }], visibleIndex: [{
                type: Input
            }] } });
class DxiTreeListSimpleItemModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiTreeListSimpleItemModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxiTreeListSimpleItemModule, imports: [DxiTreeListSimpleItemComponent], exports: [DxiTreeListSimpleItemComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiTreeListSimpleItemModule, imports: [DxiTreeListSimpleItemComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiTreeListSimpleItemModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxiTreeListSimpleItemComponent
                    ],
                    exports: [
                        DxiTreeListSimpleItemComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoTreeListSortingComponent extends NestedOption {
    get ascendingText() {
        return this._getOption('ascendingText');
    }
    set ascendingText(value) {
        this._setOption('ascendingText', value);
    }
    get clearText() {
        return this._getOption('clearText');
    }
    set clearText(value) {
        this._setOption('clearText', value);
    }
    get descendingText() {
        return this._getOption('descendingText');
    }
    set descendingText(value) {
        this._setOption('descendingText', value);
    }
    get mode() {
        return this._getOption('mode');
    }
    set mode(value) {
        this._setOption('mode', value);
    }
    get showSortIndexes() {
        return this._getOption('showSortIndexes');
    }
    set showSortIndexes(value) {
        this._setOption('showSortIndexes', value);
    }
    get _optionPath() {
        return 'sorting';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListSortingComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoTreeListSortingComponent, isStandalone: true, selector: "dxo-tree-list-sorting", inputs: { ascendingText: "ascendingText", clearText: "clearText", descendingText: "descendingText", mode: "mode", showSortIndexes: "showSortIndexes" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListSortingComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-tree-list-sorting', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { ascendingText: [{
                type: Input
            }], clearText: [{
                type: Input
            }], descendingText: [{
                type: Input
            }], mode: [{
                type: Input
            }], showSortIndexes: [{
                type: Input
            }] } });
class DxoTreeListSortingModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListSortingModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListSortingModule, imports: [DxoTreeListSortingComponent], exports: [DxoTreeListSortingComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListSortingModule, imports: [DxoTreeListSortingComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListSortingModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoTreeListSortingComponent
                    ],
                    exports: [
                        DxoTreeListSortingComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoTreeListStateStoringComponent extends NestedOption {
    get customLoad() {
        return this._getOption('customLoad');
    }
    set customLoad(value) {
        this._setOption('customLoad', value);
    }
    get customSave() {
        return this._getOption('customSave');
    }
    set customSave(value) {
        this._setOption('customSave', value);
    }
    get enabled() {
        return this._getOption('enabled');
    }
    set enabled(value) {
        this._setOption('enabled', value);
    }
    get savingTimeout() {
        return this._getOption('savingTimeout');
    }
    set savingTimeout(value) {
        this._setOption('savingTimeout', value);
    }
    get storageKey() {
        return this._getOption('storageKey');
    }
    set storageKey(value) {
        this._setOption('storageKey', value);
    }
    get type() {
        return this._getOption('type');
    }
    set type(value) {
        this._setOption('type', value);
    }
    get _optionPath() {
        return 'stateStoring';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListStateStoringComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoTreeListStateStoringComponent, isStandalone: true, selector: "dxo-tree-list-state-storing", inputs: { customLoad: "customLoad", customSave: "customSave", enabled: "enabled", savingTimeout: "savingTimeout", storageKey: "storageKey", type: "type" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListStateStoringComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-tree-list-state-storing', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { customLoad: [{
                type: Input
            }], customSave: [{
                type: Input
            }], enabled: [{
                type: Input
            }], savingTimeout: [{
                type: Input
            }], storageKey: [{
                type: Input
            }], type: [{
                type: Input
            }] } });
class DxoTreeListStateStoringModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListStateStoringModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListStateStoringModule, imports: [DxoTreeListStateStoringComponent], exports: [DxoTreeListStateStoringComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListStateStoringModule, imports: [DxoTreeListStateStoringComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListStateStoringModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoTreeListStateStoringComponent
                    ],
                    exports: [
                        DxoTreeListStateStoringComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxiTreeListStringLengthRuleComponent extends CollectionNestedOption {
    get ignoreEmptyValue() {
        return this._getOption('ignoreEmptyValue');
    }
    set ignoreEmptyValue(value) {
        this._setOption('ignoreEmptyValue', value);
    }
    get max() {
        return this._getOption('max');
    }
    set max(value) {
        this._setOption('max', value);
    }
    get message() {
        return this._getOption('message');
    }
    set message(value) {
        this._setOption('message', value);
    }
    get min() {
        return this._getOption('min');
    }
    set min(value) {
        this._setOption('min', value);
    }
    get trim() {
        return this._getOption('trim');
    }
    set trim(value) {
        this._setOption('trim', value);
    }
    get type() {
        return this._getOption('type');
    }
    set type(value) {
        this._setOption('type', value);
    }
    get _optionPath() {
        return 'validationRules';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
        this.type = 'stringLength';
    }
    ngOnDestroy() {
        this._deleteRemovedOptions(this._fullOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiTreeListStringLengthRuleComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxiTreeListStringLengthRuleComponent, isStandalone: true, selector: "dxi-tree-list-string-length-rule", inputs: { ignoreEmptyValue: "ignoreEmptyValue", max: "max", message: "message", min: "min", trim: "trim", type: "type" }, providers: [
            NestedOptionHost,
            {
                provide: PROPERTY_TOKEN_validationRules,
                useExisting: DxiTreeListStringLengthRuleComponent,
            }
        ], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiTreeListStringLengthRuleComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxi-tree-list-string-length-rule', template: '', imports: [DxIntegrationModule], providers: [
                        NestedOptionHost,
                        {
                            provide: PROPERTY_TOKEN_validationRules,
                            useExisting: DxiTreeListStringLengthRuleComponent,
                        }
                    ] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { ignoreEmptyValue: [{
                type: Input
            }], max: [{
                type: Input
            }], message: [{
                type: Input
            }], min: [{
                type: Input
            }], trim: [{
                type: Input
            }], type: [{
                type: Input
            }] } });
class DxiTreeListStringLengthRuleModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiTreeListStringLengthRuleModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxiTreeListStringLengthRuleModule, imports: [DxiTreeListStringLengthRuleComponent], exports: [DxiTreeListStringLengthRuleComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiTreeListStringLengthRuleModule, imports: [DxiTreeListStringLengthRuleComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiTreeListStringLengthRuleModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxiTreeListStringLengthRuleComponent
                    ],
                    exports: [
                        DxiTreeListStringLengthRuleComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxiTreeListTabComponent extends CollectionNestedOption {
    set _itemsContentChildren(value) {
        this.setChildren('items', value);
    }
    get alignItemLabels() {
        return this._getOption('alignItemLabels');
    }
    set alignItemLabels(value) {
        this._setOption('alignItemLabels', value);
    }
    get badge() {
        return this._getOption('badge');
    }
    set badge(value) {
        this._setOption('badge', value);
    }
    get colCount() {
        return this._getOption('colCount');
    }
    set colCount(value) {
        this._setOption('colCount', value);
    }
    get colCountByScreen() {
        return this._getOption('colCountByScreen');
    }
    set colCountByScreen(value) {
        this._setOption('colCountByScreen', value);
    }
    get disabled() {
        return this._getOption('disabled');
    }
    set disabled(value) {
        this._setOption('disabled', value);
    }
    get icon() {
        return this._getOption('icon');
    }
    set icon(value) {
        this._setOption('icon', value);
    }
    get items() {
        return this._getOption('items');
    }
    set items(value) {
        this._setOption('items', value);
    }
    get tabTemplate() {
        return this._getOption('tabTemplate');
    }
    set tabTemplate(value) {
        this._setOption('tabTemplate', value);
    }
    get template() {
        return this._getOption('template');
    }
    set template(value) {
        this._setOption('template', value);
    }
    get title() {
        return this._getOption('title');
    }
    set title(value) {
        this._setOption('title', value);
    }
    get _optionPath() {
        return 'tabs';
    }
    constructor(parentOptionHost, optionHost, renderer, document, templateHost, element) {
        super();
        this.renderer = renderer;
        this.document = document;
        this.element = element;
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
        templateHost.setHost(this);
    }
    setTemplate(template) {
        this.template = template;
    }
    ngAfterViewInit() {
        extractTemplate(this, this.element, this.renderer, this.document);
    }
    ngOnDestroy() {
        this._deleteRemovedOptions(this._fullOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiTreeListTabComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }, { token: i0.Renderer2 }, { token: DOCUMENT }, { token: i1.DxTemplateHost, host: true }, { token: i0.ElementRef }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxiTreeListTabComponent, isStandalone: true, selector: "dxi-tree-list-tab", inputs: { alignItemLabels: "alignItemLabels", badge: "badge", colCount: "colCount", colCountByScreen: "colCountByScreen", disabled: "disabled", icon: "icon", items: "items", tabTemplate: "tabTemplate", template: "template", title: "title" }, providers: [
            NestedOptionHost,
            DxTemplateHost,
            {
                provide: PROPERTY_TOKEN_tabs,
                useExisting: DxiTreeListTabComponent,
            }
        ], queries: [{ propertyName: "_itemsContentChildren", predicate: PROPERTY_TOKEN_items }], usesInheritance: true, ngImport: i0, template: '<ng-content></ng-content>', isInline: true, styles: [":host{display:block}\n"], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiTreeListTabComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxi-tree-list-tab', template: '<ng-content></ng-content>', imports: [DxIntegrationModule], providers: [
                        NestedOptionHost,
                        DxTemplateHost,
                        {
                            provide: PROPERTY_TOKEN_tabs,
                            useExisting: DxiTreeListTabComponent,
                        }
                    ], styles: [":host{display:block}\n"] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }, { type: i0.Renderer2 }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [DOCUMENT]
                }] }, { type: i1.DxTemplateHost, decorators: [{
                    type: Host
                }] }, { type: i0.ElementRef }], propDecorators: { _itemsContentChildren: [{
                type: ContentChildren,
                args: [PROPERTY_TOKEN_items]
            }], alignItemLabels: [{
                type: Input
            }], badge: [{
                type: Input
            }], colCount: [{
                type: Input
            }], colCountByScreen: [{
                type: Input
            }], disabled: [{
                type: Input
            }], icon: [{
                type: Input
            }], items: [{
                type: Input
            }], tabTemplate: [{
                type: Input
            }], template: [{
                type: Input
            }], title: [{
                type: Input
            }] } });
class DxiTreeListTabModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiTreeListTabModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxiTreeListTabModule, imports: [DxiTreeListTabComponent], exports: [DxiTreeListTabComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiTreeListTabModule, imports: [DxiTreeListTabComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiTreeListTabModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxiTreeListTabComponent
                    ],
                    exports: [
                        DxiTreeListTabComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxiTreeListTabPanelOptionsItemComponent extends CollectionNestedOption {
    get badge() {
        return this._getOption('badge');
    }
    set badge(value) {
        this._setOption('badge', value);
    }
    get disabled() {
        return this._getOption('disabled');
    }
    set disabled(value) {
        this._setOption('disabled', value);
    }
    get html() {
        return this._getOption('html');
    }
    set html(value) {
        this._setOption('html', value);
    }
    get icon() {
        return this._getOption('icon');
    }
    set icon(value) {
        this._setOption('icon', value);
    }
    get tabTemplate() {
        return this._getOption('tabTemplate');
    }
    set tabTemplate(value) {
        this._setOption('tabTemplate', value);
    }
    get template() {
        return this._getOption('template');
    }
    set template(value) {
        this._setOption('template', value);
    }
    get text() {
        return this._getOption('text');
    }
    set text(value) {
        this._setOption('text', value);
    }
    get title() {
        return this._getOption('title');
    }
    set title(value) {
        this._setOption('title', value);
    }
    get visible() {
        return this._getOption('visible');
    }
    set visible(value) {
        this._setOption('visible', value);
    }
    get _optionPath() {
        return 'items';
    }
    constructor(parentOptionHost, optionHost, renderer, document, templateHost, element) {
        super();
        this.renderer = renderer;
        this.document = document;
        this.element = element;
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
        templateHost.setHost(this);
    }
    setTemplate(template) {
        this.template = template;
    }
    ngAfterViewInit() {
        extractTemplate(this, this.element, this.renderer, this.document);
    }
    ngOnDestroy() {
        this._deleteRemovedOptions(this._fullOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiTreeListTabPanelOptionsItemComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }, { token: i0.Renderer2 }, { token: DOCUMENT }, { token: i1.DxTemplateHost, host: true }, { token: i0.ElementRef }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxiTreeListTabPanelOptionsItemComponent, isStandalone: true, selector: "dxi-tree-list-tab-panel-options-item", inputs: { badge: "badge", disabled: "disabled", html: "html", icon: "icon", tabTemplate: "tabTemplate", template: "template", text: "text", title: "title", visible: "visible" }, providers: [
            NestedOptionHost,
            DxTemplateHost,
            {
                provide: PROPERTY_TOKEN_items,
                useExisting: DxiTreeListTabPanelOptionsItemComponent,
            }
        ], usesInheritance: true, ngImport: i0, template: '<ng-content></ng-content>', isInline: true, styles: [":host{display:block}\n"], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiTreeListTabPanelOptionsItemComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxi-tree-list-tab-panel-options-item', template: '<ng-content></ng-content>', imports: [DxIntegrationModule], providers: [
                        NestedOptionHost,
                        DxTemplateHost,
                        {
                            provide: PROPERTY_TOKEN_items,
                            useExisting: DxiTreeListTabPanelOptionsItemComponent,
                        }
                    ], styles: [":host{display:block}\n"] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }, { type: i0.Renderer2 }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [DOCUMENT]
                }] }, { type: i1.DxTemplateHost, decorators: [{
                    type: Host
                }] }, { type: i0.ElementRef }], propDecorators: { badge: [{
                type: Input
            }], disabled: [{
                type: Input
            }], html: [{
                type: Input
            }], icon: [{
                type: Input
            }], tabTemplate: [{
                type: Input
            }], template: [{
                type: Input
            }], text: [{
                type: Input
            }], title: [{
                type: Input
            }], visible: [{
                type: Input
            }] } });
class DxiTreeListTabPanelOptionsItemModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiTreeListTabPanelOptionsItemModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxiTreeListTabPanelOptionsItemModule, imports: [DxiTreeListTabPanelOptionsItemComponent], exports: [DxiTreeListTabPanelOptionsItemComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiTreeListTabPanelOptionsItemModule, imports: [DxiTreeListTabPanelOptionsItemComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiTreeListTabPanelOptionsItemModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxiTreeListTabPanelOptionsItemComponent
                    ],
                    exports: [
                        DxiTreeListTabPanelOptionsItemComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoTreeListTabPanelOptionsComponent extends NestedOption {
    set _itemsContentChildren(value) {
        this.setChildren('items', value);
    }
    get accessKey() {
        return this._getOption('accessKey');
    }
    set accessKey(value) {
        this._setOption('accessKey', value);
    }
    get activeStateEnabled() {
        return this._getOption('activeStateEnabled');
    }
    set activeStateEnabled(value) {
        this._setOption('activeStateEnabled', value);
    }
    get animationEnabled() {
        return this._getOption('animationEnabled');
    }
    set animationEnabled(value) {
        this._setOption('animationEnabled', value);
    }
    get dataSource() {
        return this._getOption('dataSource');
    }
    set dataSource(value) {
        this._setOption('dataSource', value);
    }
    get deferRendering() {
        return this._getOption('deferRendering');
    }
    set deferRendering(value) {
        this._setOption('deferRendering', value);
    }
    get disabled() {
        return this._getOption('disabled');
    }
    set disabled(value) {
        this._setOption('disabled', value);
    }
    get elementAttr() {
        return this._getOption('elementAttr');
    }
    set elementAttr(value) {
        this._setOption('elementAttr', value);
    }
    get focusStateEnabled() {
        return this._getOption('focusStateEnabled');
    }
    set focusStateEnabled(value) {
        this._setOption('focusStateEnabled', value);
    }
    get height() {
        return this._getOption('height');
    }
    set height(value) {
        this._setOption('height', value);
    }
    get hint() {
        return this._getOption('hint');
    }
    set hint(value) {
        this._setOption('hint', value);
    }
    get hoverStateEnabled() {
        return this._getOption('hoverStateEnabled');
    }
    set hoverStateEnabled(value) {
        this._setOption('hoverStateEnabled', value);
    }
    get iconPosition() {
        return this._getOption('iconPosition');
    }
    set iconPosition(value) {
        this._setOption('iconPosition', value);
    }
    get itemHoldTimeout() {
        return this._getOption('itemHoldTimeout');
    }
    set itemHoldTimeout(value) {
        this._setOption('itemHoldTimeout', value);
    }
    get items() {
        return this._getOption('items');
    }
    set items(value) {
        this._setOption('items', value);
    }
    get itemTemplate() {
        return this._getOption('itemTemplate');
    }
    set itemTemplate(value) {
        this._setOption('itemTemplate', value);
    }
    get itemTitleTemplate() {
        return this._getOption('itemTitleTemplate');
    }
    set itemTitleTemplate(value) {
        this._setOption('itemTitleTemplate', value);
    }
    get keyExpr() {
        return this._getOption('keyExpr');
    }
    set keyExpr(value) {
        this._setOption('keyExpr', value);
    }
    get loop() {
        return this._getOption('loop');
    }
    set loop(value) {
        this._setOption('loop', value);
    }
    get noDataText() {
        return this._getOption('noDataText');
    }
    set noDataText(value) {
        this._setOption('noDataText', value);
    }
    get onContentReady() {
        return this._getOption('onContentReady');
    }
    set onContentReady(value) {
        this._setOption('onContentReady', value);
    }
    get onDisposing() {
        return this._getOption('onDisposing');
    }
    set onDisposing(value) {
        this._setOption('onDisposing', value);
    }
    get onInitialized() {
        return this._getOption('onInitialized');
    }
    set onInitialized(value) {
        this._setOption('onInitialized', value);
    }
    get onItemClick() {
        return this._getOption('onItemClick');
    }
    set onItemClick(value) {
        this._setOption('onItemClick', value);
    }
    get onItemContextMenu() {
        return this._getOption('onItemContextMenu');
    }
    set onItemContextMenu(value) {
        this._setOption('onItemContextMenu', value);
    }
    get onItemHold() {
        return this._getOption('onItemHold');
    }
    set onItemHold(value) {
        this._setOption('onItemHold', value);
    }
    get onItemRendered() {
        return this._getOption('onItemRendered');
    }
    set onItemRendered(value) {
        this._setOption('onItemRendered', value);
    }
    get onOptionChanged() {
        return this._getOption('onOptionChanged');
    }
    set onOptionChanged(value) {
        this._setOption('onOptionChanged', value);
    }
    get onSelectionChanged() {
        return this._getOption('onSelectionChanged');
    }
    set onSelectionChanged(value) {
        this._setOption('onSelectionChanged', value);
    }
    get onSelectionChanging() {
        return this._getOption('onSelectionChanging');
    }
    set onSelectionChanging(value) {
        this._setOption('onSelectionChanging', value);
    }
    get onTitleClick() {
        return this._getOption('onTitleClick');
    }
    set onTitleClick(value) {
        this._setOption('onTitleClick', value);
    }
    get onTitleHold() {
        return this._getOption('onTitleHold');
    }
    set onTitleHold(value) {
        this._setOption('onTitleHold', value);
    }
    get onTitleRendered() {
        return this._getOption('onTitleRendered');
    }
    set onTitleRendered(value) {
        this._setOption('onTitleRendered', value);
    }
    get repaintChangesOnly() {
        return this._getOption('repaintChangesOnly');
    }
    set repaintChangesOnly(value) {
        this._setOption('repaintChangesOnly', value);
    }
    get rtlEnabled() {
        return this._getOption('rtlEnabled');
    }
    set rtlEnabled(value) {
        this._setOption('rtlEnabled', value);
    }
    get scrollByContent() {
        return this._getOption('scrollByContent');
    }
    set scrollByContent(value) {
        this._setOption('scrollByContent', value);
    }
    get scrollingEnabled() {
        return this._getOption('scrollingEnabled');
    }
    set scrollingEnabled(value) {
        this._setOption('scrollingEnabled', value);
    }
    get selectedIndex() {
        return this._getOption('selectedIndex');
    }
    set selectedIndex(value) {
        this._setOption('selectedIndex', value);
    }
    get selectedItem() {
        return this._getOption('selectedItem');
    }
    set selectedItem(value) {
        this._setOption('selectedItem', value);
    }
    get showNavButtons() {
        return this._getOption('showNavButtons');
    }
    set showNavButtons(value) {
        this._setOption('showNavButtons', value);
    }
    get stylingMode() {
        return this._getOption('stylingMode');
    }
    set stylingMode(value) {
        this._setOption('stylingMode', value);
    }
    get swipeEnabled() {
        return this._getOption('swipeEnabled');
    }
    set swipeEnabled(value) {
        this._setOption('swipeEnabled', value);
    }
    get tabIndex() {
        return this._getOption('tabIndex');
    }
    set tabIndex(value) {
        this._setOption('tabIndex', value);
    }
    get tabsPosition() {
        return this._getOption('tabsPosition');
    }
    set tabsPosition(value) {
        this._setOption('tabsPosition', value);
    }
    get visible() {
        return this._getOption('visible');
    }
    set visible(value) {
        this._setOption('visible', value);
    }
    get width() {
        return this._getOption('width');
    }
    set width(value) {
        this._setOption('width', value);
    }
    get _optionPath() {
        return 'tabPanelOptions';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        this._createEventEmitters([
            { emit: 'itemsChange' },
            { emit: 'selectedIndexChange' },
            { emit: 'selectedItemChange' }
        ]);
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListTabPanelOptionsComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoTreeListTabPanelOptionsComponent, isStandalone: true, selector: "dxo-tree-list-tab-panel-options", inputs: { accessKey: "accessKey", activeStateEnabled: "activeStateEnabled", animationEnabled: "animationEnabled", dataSource: "dataSource", deferRendering: "deferRendering", disabled: "disabled", elementAttr: "elementAttr", focusStateEnabled: "focusStateEnabled", height: "height", hint: "hint", hoverStateEnabled: "hoverStateEnabled", iconPosition: "iconPosition", itemHoldTimeout: "itemHoldTimeout", items: "items", itemTemplate: "itemTemplate", itemTitleTemplate: "itemTitleTemplate", keyExpr: "keyExpr", loop: "loop", noDataText: "noDataText", onContentReady: "onContentReady", onDisposing: "onDisposing", onInitialized: "onInitialized", onItemClick: "onItemClick", onItemContextMenu: "onItemContextMenu", onItemHold: "onItemHold", onItemRendered: "onItemRendered", onOptionChanged: "onOptionChanged", onSelectionChanged: "onSelectionChanged", onSelectionChanging: "onSelectionChanging", onTitleClick: "onTitleClick", onTitleHold: "onTitleHold", onTitleRendered: "onTitleRendered", repaintChangesOnly: "repaintChangesOnly", rtlEnabled: "rtlEnabled", scrollByContent: "scrollByContent", scrollingEnabled: "scrollingEnabled", selectedIndex: "selectedIndex", selectedItem: "selectedItem", showNavButtons: "showNavButtons", stylingMode: "stylingMode", swipeEnabled: "swipeEnabled", tabIndex: "tabIndex", tabsPosition: "tabsPosition", visible: "visible", width: "width" }, outputs: { itemsChange: "itemsChange", selectedIndexChange: "selectedIndexChange", selectedItemChange: "selectedItemChange" }, providers: [NestedOptionHost], queries: [{ propertyName: "_itemsContentChildren", predicate: PROPERTY_TOKEN_items }], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListTabPanelOptionsComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-tree-list-tab-panel-options', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { _itemsContentChildren: [{
                type: ContentChildren,
                args: [PROPERTY_TOKEN_items]
            }], accessKey: [{
                type: Input
            }], activeStateEnabled: [{
                type: Input
            }], animationEnabled: [{
                type: Input
            }], dataSource: [{
                type: Input
            }], deferRendering: [{
                type: Input
            }], disabled: [{
                type: Input
            }], elementAttr: [{
                type: Input
            }], focusStateEnabled: [{
                type: Input
            }], height: [{
                type: Input
            }], hint: [{
                type: Input
            }], hoverStateEnabled: [{
                type: Input
            }], iconPosition: [{
                type: Input
            }], itemHoldTimeout: [{
                type: Input
            }], items: [{
                type: Input
            }], itemTemplate: [{
                type: Input
            }], itemTitleTemplate: [{
                type: Input
            }], keyExpr: [{
                type: Input
            }], loop: [{
                type: Input
            }], noDataText: [{
                type: Input
            }], onContentReady: [{
                type: Input
            }], onDisposing: [{
                type: Input
            }], onInitialized: [{
                type: Input
            }], onItemClick: [{
                type: Input
            }], onItemContextMenu: [{
                type: Input
            }], onItemHold: [{
                type: Input
            }], onItemRendered: [{
                type: Input
            }], onOptionChanged: [{
                type: Input
            }], onSelectionChanged: [{
                type: Input
            }], onSelectionChanging: [{
                type: Input
            }], onTitleClick: [{
                type: Input
            }], onTitleHold: [{
                type: Input
            }], onTitleRendered: [{
                type: Input
            }], repaintChangesOnly: [{
                type: Input
            }], rtlEnabled: [{
                type: Input
            }], scrollByContent: [{
                type: Input
            }], scrollingEnabled: [{
                type: Input
            }], selectedIndex: [{
                type: Input
            }], selectedItem: [{
                type: Input
            }], showNavButtons: [{
                type: Input
            }], stylingMode: [{
                type: Input
            }], swipeEnabled: [{
                type: Input
            }], tabIndex: [{
                type: Input
            }], tabsPosition: [{
                type: Input
            }], visible: [{
                type: Input
            }], width: [{
                type: Input
            }], itemsChange: [{
                type: Output
            }], selectedIndexChange: [{
                type: Output
            }], selectedItemChange: [{
                type: Output
            }] } });
class DxoTreeListTabPanelOptionsModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListTabPanelOptionsModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListTabPanelOptionsModule, imports: [DxoTreeListTabPanelOptionsComponent], exports: [DxoTreeListTabPanelOptionsComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListTabPanelOptionsModule, imports: [DxoTreeListTabPanelOptionsComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListTabPanelOptionsModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoTreeListTabPanelOptionsComponent
                    ],
                    exports: [
                        DxoTreeListTabPanelOptionsComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxiTreeListTabbedItemComponent extends CollectionNestedOption {
    set _tabsContentChildren(value) {
        this.setChildren('tabs', value);
    }
    get colSpan() {
        return this._getOption('colSpan');
    }
    set colSpan(value) {
        this._setOption('colSpan', value);
    }
    get cssClass() {
        return this._getOption('cssClass');
    }
    set cssClass(value) {
        this._setOption('cssClass', value);
    }
    get itemType() {
        return this._getOption('itemType');
    }
    set itemType(value) {
        this._setOption('itemType', value);
    }
    get name() {
        return this._getOption('name');
    }
    set name(value) {
        this._setOption('name', value);
    }
    get tabPanelOptions() {
        return this._getOption('tabPanelOptions');
    }
    set tabPanelOptions(value) {
        this._setOption('tabPanelOptions', value);
    }
    get tabs() {
        return this._getOption('tabs');
    }
    set tabs(value) {
        this._setOption('tabs', value);
    }
    get visible() {
        return this._getOption('visible');
    }
    set visible(value) {
        this._setOption('visible', value);
    }
    get visibleIndex() {
        return this._getOption('visibleIndex');
    }
    set visibleIndex(value) {
        this._setOption('visibleIndex', value);
    }
    get _optionPath() {
        return 'items';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
        this.itemType = 'tabbed';
    }
    ngOnDestroy() {
        this._deleteRemovedOptions(this._fullOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiTreeListTabbedItemComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxiTreeListTabbedItemComponent, isStandalone: true, selector: "dxi-tree-list-tabbed-item", inputs: { colSpan: "colSpan", cssClass: "cssClass", itemType: "itemType", name: "name", tabPanelOptions: "tabPanelOptions", tabs: "tabs", visible: "visible", visibleIndex: "visibleIndex" }, providers: [
            NestedOptionHost,
            {
                provide: PROPERTY_TOKEN_items,
                useExisting: DxiTreeListTabbedItemComponent,
            }
        ], queries: [{ propertyName: "_tabsContentChildren", predicate: PROPERTY_TOKEN_tabs }], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiTreeListTabbedItemComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxi-tree-list-tabbed-item', template: '', imports: [DxIntegrationModule], providers: [
                        NestedOptionHost,
                        {
                            provide: PROPERTY_TOKEN_items,
                            useExisting: DxiTreeListTabbedItemComponent,
                        }
                    ] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { _tabsContentChildren: [{
                type: ContentChildren,
                args: [PROPERTY_TOKEN_tabs]
            }], colSpan: [{
                type: Input
            }], cssClass: [{
                type: Input
            }], itemType: [{
                type: Input
            }], name: [{
                type: Input
            }], tabPanelOptions: [{
                type: Input
            }], tabs: [{
                type: Input
            }], visible: [{
                type: Input
            }], visibleIndex: [{
                type: Input
            }] } });
class DxiTreeListTabbedItemModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiTreeListTabbedItemModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxiTreeListTabbedItemModule, imports: [DxiTreeListTabbedItemComponent], exports: [DxiTreeListTabbedItemComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiTreeListTabbedItemModule, imports: [DxiTreeListTabbedItemComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiTreeListTabbedItemModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxiTreeListTabbedItemComponent
                    ],
                    exports: [
                        DxiTreeListTabbedItemComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoTreeListTextsComponent extends NestedOption {
    get addRow() {
        return this._getOption('addRow');
    }
    set addRow(value) {
        this._setOption('addRow', value);
    }
    get addRowToNode() {
        return this._getOption('addRowToNode');
    }
    set addRowToNode(value) {
        this._setOption('addRowToNode', value);
    }
    get cancelAllChanges() {
        return this._getOption('cancelAllChanges');
    }
    set cancelAllChanges(value) {
        this._setOption('cancelAllChanges', value);
    }
    get cancelRowChanges() {
        return this._getOption('cancelRowChanges');
    }
    set cancelRowChanges(value) {
        this._setOption('cancelRowChanges', value);
    }
    get confirmDeleteMessage() {
        return this._getOption('confirmDeleteMessage');
    }
    set confirmDeleteMessage(value) {
        this._setOption('confirmDeleteMessage', value);
    }
    get confirmDeleteTitle() {
        return this._getOption('confirmDeleteTitle');
    }
    set confirmDeleteTitle(value) {
        this._setOption('confirmDeleteTitle', value);
    }
    get deleteRow() {
        return this._getOption('deleteRow');
    }
    set deleteRow(value) {
        this._setOption('deleteRow', value);
    }
    get editRow() {
        return this._getOption('editRow');
    }
    set editRow(value) {
        this._setOption('editRow', value);
    }
    get saveAllChanges() {
        return this._getOption('saveAllChanges');
    }
    set saveAllChanges(value) {
        this._setOption('saveAllChanges', value);
    }
    get saveRowChanges() {
        return this._getOption('saveRowChanges');
    }
    set saveRowChanges(value) {
        this._setOption('saveRowChanges', value);
    }
    get undeleteRow() {
        return this._getOption('undeleteRow');
    }
    set undeleteRow(value) {
        this._setOption('undeleteRow', value);
    }
    get validationCancelChanges() {
        return this._getOption('validationCancelChanges');
    }
    set validationCancelChanges(value) {
        this._setOption('validationCancelChanges', value);
    }
    get fix() {
        return this._getOption('fix');
    }
    set fix(value) {
        this._setOption('fix', value);
    }
    get leftPosition() {
        return this._getOption('leftPosition');
    }
    set leftPosition(value) {
        this._setOption('leftPosition', value);
    }
    get rightPosition() {
        return this._getOption('rightPosition');
    }
    set rightPosition(value) {
        this._setOption('rightPosition', value);
    }
    get stickyPosition() {
        return this._getOption('stickyPosition');
    }
    set stickyPosition(value) {
        this._setOption('stickyPosition', value);
    }
    get unfix() {
        return this._getOption('unfix');
    }
    set unfix(value) {
        this._setOption('unfix', value);
    }
    get clearFilter() {
        return this._getOption('clearFilter');
    }
    set clearFilter(value) {
        this._setOption('clearFilter', value);
    }
    get createFilter() {
        return this._getOption('createFilter');
    }
    set createFilter(value) {
        this._setOption('createFilter', value);
    }
    get filterEnabledHint() {
        return this._getOption('filterEnabledHint');
    }
    set filterEnabledHint(value) {
        this._setOption('filterEnabledHint', value);
    }
    get cancel() {
        return this._getOption('cancel');
    }
    set cancel(value) {
        this._setOption('cancel', value);
    }
    get emptyValue() {
        return this._getOption('emptyValue');
    }
    set emptyValue(value) {
        this._setOption('emptyValue', value);
    }
    get ok() {
        return this._getOption('ok');
    }
    set ok(value) {
        this._setOption('ok', value);
    }
    get _optionPath() {
        return 'texts';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListTextsComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoTreeListTextsComponent, isStandalone: true, selector: "dxo-tree-list-texts", inputs: { addRow: "addRow", addRowToNode: "addRowToNode", cancelAllChanges: "cancelAllChanges", cancelRowChanges: "cancelRowChanges", confirmDeleteMessage: "confirmDeleteMessage", confirmDeleteTitle: "confirmDeleteTitle", deleteRow: "deleteRow", editRow: "editRow", saveAllChanges: "saveAllChanges", saveRowChanges: "saveRowChanges", undeleteRow: "undeleteRow", validationCancelChanges: "validationCancelChanges", fix: "fix", leftPosition: "leftPosition", rightPosition: "rightPosition", stickyPosition: "stickyPosition", unfix: "unfix", clearFilter: "clearFilter", createFilter: "createFilter", filterEnabledHint: "filterEnabledHint", cancel: "cancel", emptyValue: "emptyValue", ok: "ok" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListTextsComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-tree-list-texts', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { addRow: [{
                type: Input
            }], addRowToNode: [{
                type: Input
            }], cancelAllChanges: [{
                type: Input
            }], cancelRowChanges: [{
                type: Input
            }], confirmDeleteMessage: [{
                type: Input
            }], confirmDeleteTitle: [{
                type: Input
            }], deleteRow: [{
                type: Input
            }], editRow: [{
                type: Input
            }], saveAllChanges: [{
                type: Input
            }], saveRowChanges: [{
                type: Input
            }], undeleteRow: [{
                type: Input
            }], validationCancelChanges: [{
                type: Input
            }], fix: [{
                type: Input
            }], leftPosition: [{
                type: Input
            }], rightPosition: [{
                type: Input
            }], stickyPosition: [{
                type: Input
            }], unfix: [{
                type: Input
            }], clearFilter: [{
                type: Input
            }], createFilter: [{
                type: Input
            }], filterEnabledHint: [{
                type: Input
            }], cancel: [{
                type: Input
            }], emptyValue: [{
                type: Input
            }], ok: [{
                type: Input
            }] } });
class DxoTreeListTextsModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListTextsModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListTextsModule, imports: [DxoTreeListTextsComponent], exports: [DxoTreeListTextsComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListTextsModule, imports: [DxoTreeListTextsComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListTextsModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoTreeListTextsComponent
                    ],
                    exports: [
                        DxoTreeListTextsComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoTreeListToComponent extends NestedOption {
    get left() {
        return this._getOption('left');
    }
    set left(value) {
        this._setOption('left', value);
    }
    get opacity() {
        return this._getOption('opacity');
    }
    set opacity(value) {
        this._setOption('opacity', value);
    }
    get position() {
        return this._getOption('position');
    }
    set position(value) {
        this._setOption('position', value);
    }
    get scale() {
        return this._getOption('scale');
    }
    set scale(value) {
        this._setOption('scale', value);
    }
    get top() {
        return this._getOption('top');
    }
    set top(value) {
        this._setOption('top', value);
    }
    get _optionPath() {
        return 'to';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListToComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoTreeListToComponent, isStandalone: true, selector: "dxo-tree-list-to", inputs: { left: "left", opacity: "opacity", position: "position", scale: "scale", top: "top" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListToComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-tree-list-to', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { left: [{
                type: Input
            }], opacity: [{
                type: Input
            }], position: [{
                type: Input
            }], scale: [{
                type: Input
            }], top: [{
                type: Input
            }] } });
class DxoTreeListToModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListToModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListToModule, imports: [DxoTreeListToComponent], exports: [DxoTreeListToComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListToModule, imports: [DxoTreeListToComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListToModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoTreeListToComponent
                    ],
                    exports: [
                        DxoTreeListToComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxiTreeListToolbarItemComponent extends CollectionNestedOption {
    get cssClass() {
        return this._getOption('cssClass');
    }
    set cssClass(value) {
        this._setOption('cssClass', value);
    }
    get disabled() {
        return this._getOption('disabled');
    }
    set disabled(value) {
        this._setOption('disabled', value);
    }
    get html() {
        return this._getOption('html');
    }
    set html(value) {
        this._setOption('html', value);
    }
    get locateInMenu() {
        return this._getOption('locateInMenu');
    }
    set locateInMenu(value) {
        this._setOption('locateInMenu', value);
    }
    get location() {
        return this._getOption('location');
    }
    set location(value) {
        this._setOption('location', value);
    }
    get menuItemTemplate() {
        return this._getOption('menuItemTemplate');
    }
    set menuItemTemplate(value) {
        this._setOption('menuItemTemplate', value);
    }
    get options() {
        return this._getOption('options');
    }
    set options(value) {
        this._setOption('options', value);
    }
    get showText() {
        return this._getOption('showText');
    }
    set showText(value) {
        this._setOption('showText', value);
    }
    get template() {
        return this._getOption('template');
    }
    set template(value) {
        this._setOption('template', value);
    }
    get text() {
        return this._getOption('text');
    }
    set text(value) {
        this._setOption('text', value);
    }
    get toolbar() {
        return this._getOption('toolbar');
    }
    set toolbar(value) {
        this._setOption('toolbar', value);
    }
    get visible() {
        return this._getOption('visible');
    }
    set visible(value) {
        this._setOption('visible', value);
    }
    get widget() {
        return this._getOption('widget');
    }
    set widget(value) {
        this._setOption('widget', value);
    }
    get _optionPath() {
        return 'toolbarItems';
    }
    constructor(parentOptionHost, optionHost, renderer, document, templateHost, element) {
        super();
        this.renderer = renderer;
        this.document = document;
        this.element = element;
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
        templateHost.setHost(this);
    }
    setTemplate(template) {
        this.template = template;
    }
    ngAfterViewInit() {
        extractTemplate(this, this.element, this.renderer, this.document);
    }
    ngOnDestroy() {
        this._deleteRemovedOptions(this._fullOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiTreeListToolbarItemComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }, { token: i0.Renderer2 }, { token: DOCUMENT }, { token: i1.DxTemplateHost, host: true }, { token: i0.ElementRef }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxiTreeListToolbarItemComponent, isStandalone: true, selector: "dxi-tree-list-toolbar-item", inputs: { cssClass: "cssClass", disabled: "disabled", html: "html", locateInMenu: "locateInMenu", location: "location", menuItemTemplate: "menuItemTemplate", options: "options", showText: "showText", template: "template", text: "text", toolbar: "toolbar", visible: "visible", widget: "widget" }, providers: [
            NestedOptionHost,
            DxTemplateHost,
            {
                provide: PROPERTY_TOKEN_toolbarItems,
                useExisting: DxiTreeListToolbarItemComponent,
            }
        ], usesInheritance: true, ngImport: i0, template: '<ng-content></ng-content>', isInline: true, styles: [":host{display:block}\n"], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiTreeListToolbarItemComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxi-tree-list-toolbar-item', template: '<ng-content></ng-content>', imports: [DxIntegrationModule], providers: [
                        NestedOptionHost,
                        DxTemplateHost,
                        {
                            provide: PROPERTY_TOKEN_toolbarItems,
                            useExisting: DxiTreeListToolbarItemComponent,
                        }
                    ], styles: [":host{display:block}\n"] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }, { type: i0.Renderer2 }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [DOCUMENT]
                }] }, { type: i1.DxTemplateHost, decorators: [{
                    type: Host
                }] }, { type: i0.ElementRef }], propDecorators: { cssClass: [{
                type: Input
            }], disabled: [{
                type: Input
            }], html: [{
                type: Input
            }], locateInMenu: [{
                type: Input
            }], location: [{
                type: Input
            }], menuItemTemplate: [{
                type: Input
            }], options: [{
                type: Input
            }], showText: [{
                type: Input
            }], template: [{
                type: Input
            }], text: [{
                type: Input
            }], toolbar: [{
                type: Input
            }], visible: [{
                type: Input
            }], widget: [{
                type: Input
            }] } });
class DxiTreeListToolbarItemModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiTreeListToolbarItemModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxiTreeListToolbarItemModule, imports: [DxiTreeListToolbarItemComponent], exports: [DxiTreeListToolbarItemComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiTreeListToolbarItemModule, imports: [DxiTreeListToolbarItemComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiTreeListToolbarItemModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxiTreeListToolbarItemComponent
                    ],
                    exports: [
                        DxiTreeListToolbarItemComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoTreeListToolbarComponent extends NestedOption {
    set _itemsContentChildren(value) {
        this.setChildren('items', value);
    }
    get disabled() {
        return this._getOption('disabled');
    }
    set disabled(value) {
        this._setOption('disabled', value);
    }
    get items() {
        return this._getOption('items');
    }
    set items(value) {
        this._setOption('items', value);
    }
    get visible() {
        return this._getOption('visible');
    }
    set visible(value) {
        this._setOption('visible', value);
    }
    get _optionPath() {
        return 'toolbar';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListToolbarComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoTreeListToolbarComponent, isStandalone: true, selector: "dxo-tree-list-toolbar", inputs: { disabled: "disabled", items: "items", visible: "visible" }, providers: [NestedOptionHost], queries: [{ propertyName: "_itemsContentChildren", predicate: PROPERTY_TOKEN_items }], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListToolbarComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-tree-list-toolbar', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { _itemsContentChildren: [{
                type: ContentChildren,
                args: [PROPERTY_TOKEN_items]
            }], disabled: [{
                type: Input
            }], items: [{
                type: Input
            }], visible: [{
                type: Input
            }] } });
class DxoTreeListToolbarModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListToolbarModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListToolbarModule, imports: [DxoTreeListToolbarComponent], exports: [DxoTreeListToolbarComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListToolbarModule, imports: [DxoTreeListToolbarComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListToolbarModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoTreeListToolbarComponent
                    ],
                    exports: [
                        DxoTreeListToolbarComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoTreeListTreeListHeaderFilterSearchComponent extends NestedOption {
    get editorOptions() {
        return this._getOption('editorOptions');
    }
    set editorOptions(value) {
        this._setOption('editorOptions', value);
    }
    get enabled() {
        return this._getOption('enabled');
    }
    set enabled(value) {
        this._setOption('enabled', value);
    }
    get mode() {
        return this._getOption('mode');
    }
    set mode(value) {
        this._setOption('mode', value);
    }
    get timeout() {
        return this._getOption('timeout');
    }
    set timeout(value) {
        this._setOption('timeout', value);
    }
    get _optionPath() {
        return 'search';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListTreeListHeaderFilterSearchComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoTreeListTreeListHeaderFilterSearchComponent, isStandalone: true, selector: "dxo-tree-list-tree-list-header-filter-search", inputs: { editorOptions: "editorOptions", enabled: "enabled", mode: "mode", timeout: "timeout" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListTreeListHeaderFilterSearchComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-tree-list-tree-list-header-filter-search', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { editorOptions: [{
                type: Input
            }], enabled: [{
                type: Input
            }], mode: [{
                type: Input
            }], timeout: [{
                type: Input
            }] } });
class DxoTreeListTreeListHeaderFilterSearchModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListTreeListHeaderFilterSearchModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListTreeListHeaderFilterSearchModule, imports: [DxoTreeListTreeListHeaderFilterSearchComponent], exports: [DxoTreeListTreeListHeaderFilterSearchComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListTreeListHeaderFilterSearchModule, imports: [DxoTreeListTreeListHeaderFilterSearchComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListTreeListHeaderFilterSearchModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoTreeListTreeListHeaderFilterSearchComponent
                    ],
                    exports: [
                        DxoTreeListTreeListHeaderFilterSearchComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoTreeListTreeListHeaderFilterTextsComponent extends NestedOption {
    get cancel() {
        return this._getOption('cancel');
    }
    set cancel(value) {
        this._setOption('cancel', value);
    }
    get emptyValue() {
        return this._getOption('emptyValue');
    }
    set emptyValue(value) {
        this._setOption('emptyValue', value);
    }
    get ok() {
        return this._getOption('ok');
    }
    set ok(value) {
        this._setOption('ok', value);
    }
    get _optionPath() {
        return 'texts';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListTreeListHeaderFilterTextsComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoTreeListTreeListHeaderFilterTextsComponent, isStandalone: true, selector: "dxo-tree-list-tree-list-header-filter-texts", inputs: { cancel: "cancel", emptyValue: "emptyValue", ok: "ok" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListTreeListHeaderFilterTextsComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-tree-list-tree-list-header-filter-texts', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { cancel: [{
                type: Input
            }], emptyValue: [{
                type: Input
            }], ok: [{
                type: Input
            }] } });
class DxoTreeListTreeListHeaderFilterTextsModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListTreeListHeaderFilterTextsModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListTreeListHeaderFilterTextsModule, imports: [DxoTreeListTreeListHeaderFilterTextsComponent], exports: [DxoTreeListTreeListHeaderFilterTextsComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListTreeListHeaderFilterTextsModule, imports: [DxoTreeListTreeListHeaderFilterTextsComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListTreeListHeaderFilterTextsModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoTreeListTreeListHeaderFilterTextsComponent
                    ],
                    exports: [
                        DxoTreeListTreeListHeaderFilterTextsComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoTreeListTreeListHeaderFilterComponent extends NestedOption {
    get allowSearch() {
        return this._getOption('allowSearch');
    }
    set allowSearch(value) {
        this._setOption('allowSearch', value);
    }
    get allowSelectAll() {
        return this._getOption('allowSelectAll');
    }
    set allowSelectAll(value) {
        this._setOption('allowSelectAll', value);
    }
    get height() {
        return this._getOption('height');
    }
    set height(value) {
        this._setOption('height', value);
    }
    get search() {
        return this._getOption('search');
    }
    set search(value) {
        this._setOption('search', value);
    }
    get searchTimeout() {
        return this._getOption('searchTimeout');
    }
    set searchTimeout(value) {
        this._setOption('searchTimeout', value);
    }
    get texts() {
        return this._getOption('texts');
    }
    set texts(value) {
        this._setOption('texts', value);
    }
    get visible() {
        return this._getOption('visible');
    }
    set visible(value) {
        this._setOption('visible', value);
    }
    get width() {
        return this._getOption('width');
    }
    set width(value) {
        this._setOption('width', value);
    }
    get _optionPath() {
        return 'headerFilter';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListTreeListHeaderFilterComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoTreeListTreeListHeaderFilterComponent, isStandalone: true, selector: "dxo-tree-list-tree-list-header-filter", inputs: { allowSearch: "allowSearch", allowSelectAll: "allowSelectAll", height: "height", search: "search", searchTimeout: "searchTimeout", texts: "texts", visible: "visible", width: "width" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListTreeListHeaderFilterComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-tree-list-tree-list-header-filter', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { allowSearch: [{
                type: Input
            }], allowSelectAll: [{
                type: Input
            }], height: [{
                type: Input
            }], search: [{
                type: Input
            }], searchTimeout: [{
                type: Input
            }], texts: [{
                type: Input
            }], visible: [{
                type: Input
            }], width: [{
                type: Input
            }] } });
class DxoTreeListTreeListHeaderFilterModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListTreeListHeaderFilterModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListTreeListHeaderFilterModule, imports: [DxoTreeListTreeListHeaderFilterComponent], exports: [DxoTreeListTreeListHeaderFilterComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListTreeListHeaderFilterModule, imports: [DxoTreeListTreeListHeaderFilterComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListTreeListHeaderFilterModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoTreeListTreeListHeaderFilterComponent
                    ],
                    exports: [
                        DxoTreeListTreeListHeaderFilterComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoTreeListTreeListSelectionComponent extends NestedOption {
    get allowSelectAll() {
        return this._getOption('allowSelectAll');
    }
    set allowSelectAll(value) {
        this._setOption('allowSelectAll', value);
    }
    get mode() {
        return this._getOption('mode');
    }
    set mode(value) {
        this._setOption('mode', value);
    }
    get recursive() {
        return this._getOption('recursive');
    }
    set recursive(value) {
        this._setOption('recursive', value);
    }
    get _optionPath() {
        return 'selection';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListTreeListSelectionComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoTreeListTreeListSelectionComponent, isStandalone: true, selector: "dxo-tree-list-tree-list-selection", inputs: { allowSelectAll: "allowSelectAll", mode: "mode", recursive: "recursive" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListTreeListSelectionComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-tree-list-tree-list-selection', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { allowSelectAll: [{
                type: Input
            }], mode: [{
                type: Input
            }], recursive: [{
                type: Input
            }] } });
class DxoTreeListTreeListSelectionModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListTreeListSelectionModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListTreeListSelectionModule, imports: [DxoTreeListTreeListSelectionComponent], exports: [DxoTreeListTreeListSelectionComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListTreeListSelectionModule, imports: [DxoTreeListTreeListSelectionComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoTreeListTreeListSelectionModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoTreeListTreeListSelectionComponent
                    ],
                    exports: [
                        DxoTreeListTreeListSelectionComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxiTreeListTreeListToolbarItemComponent extends CollectionNestedOption {
    get cssClass() {
        return this._getOption('cssClass');
    }
    set cssClass(value) {
        this._setOption('cssClass', value);
    }
    get disabled() {
        return this._getOption('disabled');
    }
    set disabled(value) {
        this._setOption('disabled', value);
    }
    get html() {
        return this._getOption('html');
    }
    set html(value) {
        this._setOption('html', value);
    }
    get locateInMenu() {
        return this._getOption('locateInMenu');
    }
    set locateInMenu(value) {
        this._setOption('locateInMenu', value);
    }
    get location() {
        return this._getOption('location');
    }
    set location(value) {
        this._setOption('location', value);
    }
    get menuItemTemplate() {
        return this._getOption('menuItemTemplate');
    }
    set menuItemTemplate(value) {
        this._setOption('menuItemTemplate', value);
    }
    get name() {
        return this._getOption('name');
    }
    set name(value) {
        this._setOption('name', value);
    }
    get options() {
        return this._getOption('options');
    }
    set options(value) {
        this._setOption('options', value);
    }
    get showText() {
        return this._getOption('showText');
    }
    set showText(value) {
        this._setOption('showText', value);
    }
    get template() {
        return this._getOption('template');
    }
    set template(value) {
        this._setOption('template', value);
    }
    get text() {
        return this._getOption('text');
    }
    set text(value) {
        this._setOption('text', value);
    }
    get visible() {
        return this._getOption('visible');
    }
    set visible(value) {
        this._setOption('visible', value);
    }
    get widget() {
        return this._getOption('widget');
    }
    set widget(value) {
        this._setOption('widget', value);
    }
    get _optionPath() {
        return 'items';
    }
    constructor(parentOptionHost, optionHost, renderer, document, templateHost, element) {
        super();
        this.renderer = renderer;
        this.document = document;
        this.element = element;
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
        templateHost.setHost(this);
    }
    setTemplate(template) {
        this.template = template;
    }
    ngAfterViewInit() {
        extractTemplate(this, this.element, this.renderer, this.document);
    }
    ngOnDestroy() {
        this._deleteRemovedOptions(this._fullOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiTreeListTreeListToolbarItemComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }, { token: i0.Renderer2 }, { token: DOCUMENT }, { token: i1.DxTemplateHost, host: true }, { token: i0.ElementRef }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxiTreeListTreeListToolbarItemComponent, isStandalone: true, selector: "dxi-tree-list-tree-list-toolbar-item", inputs: { cssClass: "cssClass", disabled: "disabled", html: "html", locateInMenu: "locateInMenu", location: "location", menuItemTemplate: "menuItemTemplate", name: "name", options: "options", showText: "showText", template: "template", text: "text", visible: "visible", widget: "widget" }, providers: [
            NestedOptionHost,
            DxTemplateHost,
            {
                provide: PROPERTY_TOKEN_items,
                useExisting: DxiTreeListTreeListToolbarItemComponent,
            }
        ], usesInheritance: true, ngImport: i0, template: '<ng-content></ng-content>', isInline: true, styles: [":host{display:block}\n"], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiTreeListTreeListToolbarItemComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxi-tree-list-tree-list-toolbar-item', template: '<ng-content></ng-content>', imports: [DxIntegrationModule], providers: [
                        NestedOptionHost,
                        DxTemplateHost,
                        {
                            provide: PROPERTY_TOKEN_items,
                            useExisting: DxiTreeListTreeListToolbarItemComponent,
                        }
                    ], styles: [":host{display:block}\n"] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }, { type: i0.Renderer2 }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [DOCUMENT]
                }] }, { type: i1.DxTemplateHost, decorators: [{
                    type: Host
                }] }, { type: i0.ElementRef }], propDecorators: { cssClass: [{
                type: Input
            }], disabled: [{
                type: Input
            }], html: [{
                type: Input
            }], locateInMenu: [{
                type: Input
            }], location: [{
                type: Input
            }], menuItemTemplate: [{
                type: Input
            }], name: [{
                type: Input
            }], options: [{
                type: Input
            }], showText: [{
                type: Input
            }], template: [{
                type: Input
            }], text: [{
                type: Input
            }], visible: [{
                type: Input
            }], widget: [{
                type: Input
            }] } });
class DxiTreeListTreeListToolbarItemModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiTreeListTreeListToolbarItemModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxiTreeListTreeListToolbarItemModule, imports: [DxiTreeListTreeListToolbarItemComponent], exports: [DxiTreeListTreeListToolbarItemComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiTreeListTreeListToolbarItemModule, imports: [DxiTreeListTreeListToolbarItemComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiTreeListTreeListToolbarItemModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxiTreeListTreeListToolbarItemComponent
                    ],
                    exports: [
                        DxiTreeListTreeListToolbarItemComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxiTreeListValidationRuleComponent extends CollectionNestedOption {
    get message() {
        return this._getOption('message');
    }
    set message(value) {
        this._setOption('message', value);
    }
    get trim() {
        return this._getOption('trim');
    }
    set trim(value) {
        this._setOption('trim', value);
    }
    get type() {
        return this._getOption('type');
    }
    set type(value) {
        this._setOption('type', value);
    }
    get ignoreEmptyValue() {
        return this._getOption('ignoreEmptyValue');
    }
    set ignoreEmptyValue(value) {
        this._setOption('ignoreEmptyValue', value);
    }
    get max() {
        return this._getOption('max');
    }
    set max(value) {
        this._setOption('max', value);
    }
    get min() {
        return this._getOption('min');
    }
    set min(value) {
        this._setOption('min', value);
    }
    get reevaluate() {
        return this._getOption('reevaluate');
    }
    set reevaluate(value) {
        this._setOption('reevaluate', value);
    }
    get validationCallback() {
        return this._getOption('validationCallback');
    }
    set validationCallback(value) {
        this._setOption('validationCallback', value);
    }
    get comparisonTarget() {
        return this._getOption('comparisonTarget');
    }
    set comparisonTarget(value) {
        this._setOption('comparisonTarget', value);
    }
    get comparisonType() {
        return this._getOption('comparisonType');
    }
    set comparisonType(value) {
        this._setOption('comparisonType', value);
    }
    get pattern() {
        return this._getOption('pattern');
    }
    set pattern(value) {
        this._setOption('pattern', value);
    }
    get _optionPath() {
        return 'validationRules';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
        this.type = 'required';
    }
    ngOnDestroy() {
        this._deleteRemovedOptions(this._fullOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiTreeListValidationRuleComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxiTreeListValidationRuleComponent, isStandalone: true, selector: "dxi-tree-list-validation-rule", inputs: { message: "message", trim: "trim", type: "type", ignoreEmptyValue: "ignoreEmptyValue", max: "max", min: "min", reevaluate: "reevaluate", validationCallback: "validationCallback", comparisonTarget: "comparisonTarget", comparisonType: "comparisonType", pattern: "pattern" }, providers: [
            NestedOptionHost,
            {
                provide: PROPERTY_TOKEN_validationRules,
                useExisting: DxiTreeListValidationRuleComponent,
            }
        ], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiTreeListValidationRuleComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxi-tree-list-validation-rule', template: '', imports: [DxIntegrationModule], providers: [
                        NestedOptionHost,
                        {
                            provide: PROPERTY_TOKEN_validationRules,
                            useExisting: DxiTreeListValidationRuleComponent,
                        }
                    ] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { message: [{
                type: Input
            }], trim: [{
                type: Input
            }], type: [{
                type: Input
            }], ignoreEmptyValue: [{
                type: Input
            }], max: [{
                type: Input
            }], min: [{
                type: Input
            }], reevaluate: [{
                type: Input
            }], validationCallback: [{
                type: Input
            }], comparisonTarget: [{
                type: Input
            }], comparisonType: [{
                type: Input
            }], pattern: [{
                type: Input
            }] } });
class DxiTreeListValidationRuleModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiTreeListValidationRuleModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxiTreeListValidationRuleModule, imports: [DxiTreeListValidationRuleComponent], exports: [DxiTreeListValidationRuleComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiTreeListValidationRuleModule, imports: [DxiTreeListValidationRuleComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiTreeListValidationRuleModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxiTreeListValidationRuleComponent
                    ],
                    exports: [
                        DxiTreeListValidationRuleComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

/**
 * Generated bundle index. Do not edit.
 */

export { DxiTreeListAsyncRuleComponent, DxiTreeListAsyncRuleModule, DxiTreeListButtonComponent, DxiTreeListButtonItemComponent, DxiTreeListButtonItemModule, DxiTreeListButtonModule, DxiTreeListChangeComponent, DxiTreeListChangeModule, DxiTreeListColumnButtonComponent, DxiTreeListColumnButtonModule, DxiTreeListColumnComponent, DxiTreeListColumnModule, DxiTreeListCompareRuleComponent, DxiTreeListCompareRuleModule, DxiTreeListCustomOperationComponent, DxiTreeListCustomOperationModule, DxiTreeListCustomRuleComponent, DxiTreeListCustomRuleModule, DxiTreeListEditorOptionsButtonComponent, DxiTreeListEditorOptionsButtonModule, DxiTreeListEmailRuleComponent, DxiTreeListEmailRuleModule, DxiTreeListEmptyItemComponent, DxiTreeListEmptyItemModule, DxiTreeListFieldComponent, DxiTreeListFieldModule, DxiTreeListGroupItemComponent, DxiTreeListGroupItemModule, DxiTreeListItemComponent, DxiTreeListItemModule, DxiTreeListNumericRuleComponent, DxiTreeListNumericRuleModule, DxiTreeListPatternRuleComponent, DxiTreeListPatternRuleModule, DxiTreeListRangeRuleComponent, DxiTreeListRangeRuleModule, DxiTreeListRequiredRuleComponent, DxiTreeListRequiredRuleModule, DxiTreeListSimpleItemComponent, DxiTreeListSimpleItemModule, DxiTreeListStringLengthRuleComponent, DxiTreeListStringLengthRuleModule, DxiTreeListTabComponent, DxiTreeListTabModule, DxiTreeListTabPanelOptionsItemComponent, DxiTreeListTabPanelOptionsItemModule, DxiTreeListTabbedItemComponent, DxiTreeListTabbedItemModule, DxiTreeListToolbarItemComponent, DxiTreeListToolbarItemModule, DxiTreeListTreeListToolbarItemComponent, DxiTreeListTreeListToolbarItemModule, DxiTreeListValidationRuleComponent, DxiTreeListValidationRuleModule, DxoTreeListAIAssistantComponent, DxoTreeListAIAssistantModule, DxoTreeListAIComponent, DxoTreeListAIModule, DxoTreeListAIOptionsComponent, DxoTreeListAIOptionsModule, DxoTreeListAnimationComponent, DxoTreeListAnimationModule, DxoTreeListAtComponent, DxoTreeListAtModule, DxoTreeListBoundaryOffsetComponent, DxoTreeListBoundaryOffsetModule, DxoTreeListButtonOptionsComponent, DxoTreeListButtonOptionsModule, DxoTreeListColCountByScreenComponent, DxoTreeListColCountByScreenModule, DxoTreeListCollisionComponent, DxoTreeListCollisionModule, DxoTreeListColumnChooserComponent, DxoTreeListColumnChooserModule, DxoTreeListColumnChooserSearchComponent, DxoTreeListColumnChooserSearchModule, DxoTreeListColumnChooserSelectionComponent, DxoTreeListColumnChooserSelectionModule, DxoTreeListColumnFixingComponent, DxoTreeListColumnFixingModule, DxoTreeListColumnFixingTextsComponent, DxoTreeListColumnFixingTextsModule, DxoTreeListColumnHeaderFilterComponent, DxoTreeListColumnHeaderFilterModule, DxoTreeListColumnHeaderFilterSearchComponent, DxoTreeListColumnHeaderFilterSearchModule, DxoTreeListColumnLookupComponent, DxoTreeListColumnLookupModule, DxoTreeListCursorOffsetComponent, DxoTreeListCursorOffsetModule, DxoTreeListEditingComponent, DxoTreeListEditingModule, DxoTreeListEditingTextsComponent, DxoTreeListEditingTextsModule, DxoTreeListEditorOptionsComponent, DxoTreeListEditorOptionsModule, DxoTreeListFieldLookupComponent, DxoTreeListFieldLookupModule, DxoTreeListFilterBuilderComponent, DxoTreeListFilterBuilderModule, DxoTreeListFilterBuilderPopupComponent, DxoTreeListFilterBuilderPopupModule, DxoTreeListFilterOperationDescriptionsComponent, DxoTreeListFilterOperationDescriptionsModule, DxoTreeListFilterPanelComponent, DxoTreeListFilterPanelModule, DxoTreeListFilterPanelTextsComponent, DxoTreeListFilterPanelTextsModule, DxoTreeListFilterRowComponent, DxoTreeListFilterRowModule, DxoTreeListFormComponent, DxoTreeListFormItemComponent, DxoTreeListFormItemModule, DxoTreeListFormModule, DxoTreeListFormatComponent, DxoTreeListFormatModule, DxoTreeListFromComponent, DxoTreeListFromModule, DxoTreeListGroupOperationDescriptionsComponent, DxoTreeListGroupOperationDescriptionsModule, DxoTreeListHeaderFilterComponent, DxoTreeListHeaderFilterModule, DxoTreeListHideComponent, DxoTreeListHideModule, DxoTreeListIconsComponent, DxoTreeListIconsModule, DxoTreeListIndicatorOptionsComponent, DxoTreeListIndicatorOptionsModule, DxoTreeListKeyboardNavigationComponent, DxoTreeListKeyboardNavigationModule, DxoTreeListLabelComponent, DxoTreeListLabelModule, DxoTreeListLoadPanelComponent, DxoTreeListLoadPanelModule, DxoTreeListLookupComponent, DxoTreeListLookupModule, DxoTreeListMyComponent, DxoTreeListMyModule, DxoTreeListOffsetComponent, DxoTreeListOffsetModule, DxoTreeListOperationDescriptionsComponent, DxoTreeListOperationDescriptionsModule, DxoTreeListOptionsComponent, DxoTreeListOptionsModule, DxoTreeListPagerComponent, DxoTreeListPagerModule, DxoTreeListPagingComponent, DxoTreeListPagingModule, DxoTreeListPopupComponent, DxoTreeListPopupModule, DxoTreeListPositionComponent, DxoTreeListPositionModule, DxoTreeListRemoteOperationsComponent, DxoTreeListRemoteOperationsModule, DxoTreeListRowDraggingComponent, DxoTreeListRowDraggingModule, DxoTreeListScrollingComponent, DxoTreeListScrollingModule, DxoTreeListSearchComponent, DxoTreeListSearchModule, DxoTreeListSearchPanelComponent, DxoTreeListSearchPanelModule, DxoTreeListSelectionComponent, DxoTreeListSelectionModule, DxoTreeListShowComponent, DxoTreeListShowModule, DxoTreeListSortingComponent, DxoTreeListSortingModule, DxoTreeListStateStoringComponent, DxoTreeListStateStoringModule, DxoTreeListTabPanelOptionsComponent, DxoTreeListTabPanelOptionsModule, DxoTreeListTextsComponent, DxoTreeListTextsModule, DxoTreeListToComponent, DxoTreeListToModule, DxoTreeListToolbarComponent, DxoTreeListToolbarModule, DxoTreeListTreeListHeaderFilterComponent, DxoTreeListTreeListHeaderFilterModule, DxoTreeListTreeListHeaderFilterSearchComponent, DxoTreeListTreeListHeaderFilterSearchModule, DxoTreeListTreeListHeaderFilterTextsComponent, DxoTreeListTreeListHeaderFilterTextsModule, DxoTreeListTreeListSelectionComponent, DxoTreeListTreeListSelectionModule };
//# sourceMappingURL=devextreme-angular-ui-tree-list-nested.mjs.map
