import * as i0 from '@angular/core';
import { Input, SkipSelf, Host, Component, NgModule, Output, ContentChildren, Inject } from '@angular/core';
import * as i1 from 'devextreme-angular/core';
import { CollectionNestedOption, DxIntegrationModule, NestedOptionHost, NestedOption, extractTemplate, DxTemplateHost } from 'devextreme-angular/core';
import { PROPERTY_TOKEN_commands, PROPERTY_TOKEN_tabs, PROPERTY_TOKEN_items, PROPERTY_TOKEN_mentions } from 'devextreme-angular/core/tokens';
import { DOCUMENT } from '@angular/common';

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxiHtmlEditorCommandComponent extends CollectionNestedOption {
    get name() {
        return this._getOption('name');
    }
    set name(value) {
        this._setOption('name', value);
    }
    get options() {
        return this._getOption('options');
    }
    set options(value) {
        this._setOption('options', value);
    }
    get prompt() {
        return this._getOption('prompt');
    }
    set prompt(value) {
        this._setOption('prompt', value);
    }
    get text() {
        return this._getOption('text');
    }
    set text(value) {
        this._setOption('text', value);
    }
    get _optionPath() {
        return 'commands';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnDestroy() {
        this._deleteRemovedOptions(this._fullOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiHtmlEditorCommandComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxiHtmlEditorCommandComponent, isStandalone: true, selector: "dxi-html-editor-command", inputs: { name: "name", options: "options", prompt: "prompt", text: "text" }, providers: [
            NestedOptionHost,
            {
                provide: PROPERTY_TOKEN_commands,
                useExisting: DxiHtmlEditorCommandComponent,
            }
        ], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiHtmlEditorCommandComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxi-html-editor-command', template: '', imports: [DxIntegrationModule], providers: [
                        NestedOptionHost,
                        {
                            provide: PROPERTY_TOKEN_commands,
                            useExisting: DxiHtmlEditorCommandComponent,
                        }
                    ] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { name: [{
                type: Input
            }], options: [{
                type: Input
            }], prompt: [{
                type: Input
            }], text: [{
                type: Input
            }] } });
class DxiHtmlEditorCommandModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiHtmlEditorCommandModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxiHtmlEditorCommandModule, imports: [DxiHtmlEditorCommandComponent], exports: [DxiHtmlEditorCommandComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiHtmlEditorCommandModule, imports: [DxiHtmlEditorCommandComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiHtmlEditorCommandModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxiHtmlEditorCommandComponent
                    ],
                    exports: [
                        DxiHtmlEditorCommandComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoHtmlEditorConverterComponent extends NestedOption {
    get fromHtml() {
        return this._getOption('fromHtml');
    }
    set fromHtml(value) {
        this._setOption('fromHtml', value);
    }
    get toHtml() {
        return this._getOption('toHtml');
    }
    set toHtml(value) {
        this._setOption('toHtml', value);
    }
    get _optionPath() {
        return 'converter';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoHtmlEditorConverterComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoHtmlEditorConverterComponent, isStandalone: true, selector: "dxo-html-editor-converter", inputs: { fromHtml: "fromHtml", toHtml: "toHtml" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoHtmlEditorConverterComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-html-editor-converter', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { fromHtml: [{
                type: Input
            }], toHtml: [{
                type: Input
            }] } });
class DxoHtmlEditorConverterModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoHtmlEditorConverterModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoHtmlEditorConverterModule, imports: [DxoHtmlEditorConverterComponent], exports: [DxoHtmlEditorConverterComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoHtmlEditorConverterModule, imports: [DxoHtmlEditorConverterComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoHtmlEditorConverterModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoHtmlEditorConverterComponent
                    ],
                    exports: [
                        DxoHtmlEditorConverterComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoHtmlEditorFileUploaderOptionsComponent extends NestedOption {
    get abortUpload() {
        return this._getOption('abortUpload');
    }
    set abortUpload(value) {
        this._setOption('abortUpload', value);
    }
    get accept() {
        return this._getOption('accept');
    }
    set accept(value) {
        this._setOption('accept', value);
    }
    get accessKey() {
        return this._getOption('accessKey');
    }
    set accessKey(value) {
        this._setOption('accessKey', value);
    }
    get activeStateEnabled() {
        return this._getOption('activeStateEnabled');
    }
    set activeStateEnabled(value) {
        this._setOption('activeStateEnabled', value);
    }
    get allowCanceling() {
        return this._getOption('allowCanceling');
    }
    set allowCanceling(value) {
        this._setOption('allowCanceling', value);
    }
    get allowedFileExtensions() {
        return this._getOption('allowedFileExtensions');
    }
    set allowedFileExtensions(value) {
        this._setOption('allowedFileExtensions', value);
    }
    get chunkSize() {
        return this._getOption('chunkSize');
    }
    set chunkSize(value) {
        this._setOption('chunkSize', value);
    }
    get dialogTrigger() {
        return this._getOption('dialogTrigger');
    }
    set dialogTrigger(value) {
        this._setOption('dialogTrigger', value);
    }
    get disabled() {
        return this._getOption('disabled');
    }
    set disabled(value) {
        this._setOption('disabled', value);
    }
    get dropZone() {
        return this._getOption('dropZone');
    }
    set dropZone(value) {
        this._setOption('dropZone', value);
    }
    get elementAttr() {
        return this._getOption('elementAttr');
    }
    set elementAttr(value) {
        this._setOption('elementAttr', value);
    }
    get focusStateEnabled() {
        return this._getOption('focusStateEnabled');
    }
    set focusStateEnabled(value) {
        this._setOption('focusStateEnabled', value);
    }
    get height() {
        return this._getOption('height');
    }
    set height(value) {
        this._setOption('height', value);
    }
    get hint() {
        return this._getOption('hint');
    }
    set hint(value) {
        this._setOption('hint', value);
    }
    get hoverStateEnabled() {
        return this._getOption('hoverStateEnabled');
    }
    set hoverStateEnabled(value) {
        this._setOption('hoverStateEnabled', value);
    }
    get inputAttr() {
        return this._getOption('inputAttr');
    }
    set inputAttr(value) {
        this._setOption('inputAttr', value);
    }
    get invalidFileExtensionMessage() {
        return this._getOption('invalidFileExtensionMessage');
    }
    set invalidFileExtensionMessage(value) {
        this._setOption('invalidFileExtensionMessage', value);
    }
    get invalidMaxFileSizeMessage() {
        return this._getOption('invalidMaxFileSizeMessage');
    }
    set invalidMaxFileSizeMessage(value) {
        this._setOption('invalidMaxFileSizeMessage', value);
    }
    get invalidMinFileSizeMessage() {
        return this._getOption('invalidMinFileSizeMessage');
    }
    set invalidMinFileSizeMessage(value) {
        this._setOption('invalidMinFileSizeMessage', value);
    }
    get isDirty() {
        return this._getOption('isDirty');
    }
    set isDirty(value) {
        this._setOption('isDirty', value);
    }
    get isValid() {
        return this._getOption('isValid');
    }
    set isValid(value) {
        this._setOption('isValid', value);
    }
    get labelText() {
        return this._getOption('labelText');
    }
    set labelText(value) {
        this._setOption('labelText', value);
    }
    get maxFileSize() {
        return this._getOption('maxFileSize');
    }
    set maxFileSize(value) {
        this._setOption('maxFileSize', value);
    }
    get minFileSize() {
        return this._getOption('minFileSize');
    }
    set minFileSize(value) {
        this._setOption('minFileSize', value);
    }
    get multiple() {
        return this._getOption('multiple');
    }
    set multiple(value) {
        this._setOption('multiple', value);
    }
    get name() {
        return this._getOption('name');
    }
    set name(value) {
        this._setOption('name', value);
    }
    get onBeforeSend() {
        return this._getOption('onBeforeSend');
    }
    set onBeforeSend(value) {
        this._setOption('onBeforeSend', value);
    }
    get onContentReady() {
        return this._getOption('onContentReady');
    }
    set onContentReady(value) {
        this._setOption('onContentReady', value);
    }
    get onDisposing() {
        return this._getOption('onDisposing');
    }
    set onDisposing(value) {
        this._setOption('onDisposing', value);
    }
    get onDropZoneEnter() {
        return this._getOption('onDropZoneEnter');
    }
    set onDropZoneEnter(value) {
        this._setOption('onDropZoneEnter', value);
    }
    get onDropZoneLeave() {
        return this._getOption('onDropZoneLeave');
    }
    set onDropZoneLeave(value) {
        this._setOption('onDropZoneLeave', value);
    }
    get onFilesUploaded() {
        return this._getOption('onFilesUploaded');
    }
    set onFilesUploaded(value) {
        this._setOption('onFilesUploaded', value);
    }
    get onInitialized() {
        return this._getOption('onInitialized');
    }
    set onInitialized(value) {
        this._setOption('onInitialized', value);
    }
    get onOptionChanged() {
        return this._getOption('onOptionChanged');
    }
    set onOptionChanged(value) {
        this._setOption('onOptionChanged', value);
    }
    get onProgress() {
        return this._getOption('onProgress');
    }
    set onProgress(value) {
        this._setOption('onProgress', value);
    }
    get onUploadAborted() {
        return this._getOption('onUploadAborted');
    }
    set onUploadAborted(value) {
        this._setOption('onUploadAborted', value);
    }
    get onUploaded() {
        return this._getOption('onUploaded');
    }
    set onUploaded(value) {
        this._setOption('onUploaded', value);
    }
    get onUploadError() {
        return this._getOption('onUploadError');
    }
    set onUploadError(value) {
        this._setOption('onUploadError', value);
    }
    get onUploadStarted() {
        return this._getOption('onUploadStarted');
    }
    set onUploadStarted(value) {
        this._setOption('onUploadStarted', value);
    }
    get onValueChanged() {
        return this._getOption('onValueChanged');
    }
    set onValueChanged(value) {
        this._setOption('onValueChanged', value);
    }
    get progress() {
        return this._getOption('progress');
    }
    set progress(value) {
        this._setOption('progress', value);
    }
    get readOnly() {
        return this._getOption('readOnly');
    }
    set readOnly(value) {
        this._setOption('readOnly', value);
    }
    get readyToUploadMessage() {
        return this._getOption('readyToUploadMessage');
    }
    set readyToUploadMessage(value) {
        this._setOption('readyToUploadMessage', value);
    }
    get rtlEnabled() {
        return this._getOption('rtlEnabled');
    }
    set rtlEnabled(value) {
        this._setOption('rtlEnabled', value);
    }
    get selectButtonText() {
        return this._getOption('selectButtonText');
    }
    set selectButtonText(value) {
        this._setOption('selectButtonText', value);
    }
    get showFileList() {
        return this._getOption('showFileList');
    }
    set showFileList(value) {
        this._setOption('showFileList', value);
    }
    get tabIndex() {
        return this._getOption('tabIndex');
    }
    set tabIndex(value) {
        this._setOption('tabIndex', value);
    }
    get uploadAbortedMessage() {
        return this._getOption('uploadAbortedMessage');
    }
    set uploadAbortedMessage(value) {
        this._setOption('uploadAbortedMessage', value);
    }
    get uploadButtonText() {
        return this._getOption('uploadButtonText');
    }
    set uploadButtonText(value) {
        this._setOption('uploadButtonText', value);
    }
    get uploadChunk() {
        return this._getOption('uploadChunk');
    }
    set uploadChunk(value) {
        this._setOption('uploadChunk', value);
    }
    get uploadCustomData() {
        return this._getOption('uploadCustomData');
    }
    set uploadCustomData(value) {
        this._setOption('uploadCustomData', value);
    }
    get uploadedMessage() {
        return this._getOption('uploadedMessage');
    }
    set uploadedMessage(value) {
        this._setOption('uploadedMessage', value);
    }
    get uploadFailedMessage() {
        return this._getOption('uploadFailedMessage');
    }
    set uploadFailedMessage(value) {
        this._setOption('uploadFailedMessage', value);
    }
    get uploadFile() {
        return this._getOption('uploadFile');
    }
    set uploadFile(value) {
        this._setOption('uploadFile', value);
    }
    get uploadHeaders() {
        return this._getOption('uploadHeaders');
    }
    set uploadHeaders(value) {
        this._setOption('uploadHeaders', value);
    }
    get uploadMethod() {
        return this._getOption('uploadMethod');
    }
    set uploadMethod(value) {
        this._setOption('uploadMethod', value);
    }
    get uploadMode() {
        return this._getOption('uploadMode');
    }
    set uploadMode(value) {
        this._setOption('uploadMode', value);
    }
    get uploadUrl() {
        return this._getOption('uploadUrl');
    }
    set uploadUrl(value) {
        this._setOption('uploadUrl', value);
    }
    get validationError() {
        return this._getOption('validationError');
    }
    set validationError(value) {
        this._setOption('validationError', value);
    }
    get validationErrors() {
        return this._getOption('validationErrors');
    }
    set validationErrors(value) {
        this._setOption('validationErrors', value);
    }
    get validationStatus() {
        return this._getOption('validationStatus');
    }
    set validationStatus(value) {
        this._setOption('validationStatus', value);
    }
    get value() {
        return this._getOption('value');
    }
    set value(value) {
        this._setOption('value', value);
    }
    get visible() {
        return this._getOption('visible');
    }
    set visible(value) {
        this._setOption('visible', value);
    }
    get width() {
        return this._getOption('width');
    }
    set width(value) {
        this._setOption('width', value);
    }
    get _optionPath() {
        return 'fileUploaderOptions';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        this._createEventEmitters([
            { emit: 'valueChange' }
        ]);
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoHtmlEditorFileUploaderOptionsComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoHtmlEditorFileUploaderOptionsComponent, isStandalone: true, selector: "dxo-html-editor-file-uploader-options", inputs: { abortUpload: "abortUpload", accept: "accept", accessKey: "accessKey", activeStateEnabled: "activeStateEnabled", allowCanceling: "allowCanceling", allowedFileExtensions: "allowedFileExtensions", chunkSize: "chunkSize", dialogTrigger: "dialogTrigger", disabled: "disabled", dropZone: "dropZone", elementAttr: "elementAttr", focusStateEnabled: "focusStateEnabled", height: "height", hint: "hint", hoverStateEnabled: "hoverStateEnabled", inputAttr: "inputAttr", invalidFileExtensionMessage: "invalidFileExtensionMessage", invalidMaxFileSizeMessage: "invalidMaxFileSizeMessage", invalidMinFileSizeMessage: "invalidMinFileSizeMessage", isDirty: "isDirty", isValid: "isValid", labelText: "labelText", maxFileSize: "maxFileSize", minFileSize: "minFileSize", multiple: "multiple", name: "name", onBeforeSend: "onBeforeSend", onContentReady: "onContentReady", onDisposing: "onDisposing", onDropZoneEnter: "onDropZoneEnter", onDropZoneLeave: "onDropZoneLeave", onFilesUploaded: "onFilesUploaded", onInitialized: "onInitialized", onOptionChanged: "onOptionChanged", onProgress: "onProgress", onUploadAborted: "onUploadAborted", onUploaded: "onUploaded", onUploadError: "onUploadError", onUploadStarted: "onUploadStarted", onValueChanged: "onValueChanged", progress: "progress", readOnly: "readOnly", readyToUploadMessage: "readyToUploadMessage", rtlEnabled: "rtlEnabled", selectButtonText: "selectButtonText", showFileList: "showFileList", tabIndex: "tabIndex", uploadAbortedMessage: "uploadAbortedMessage", uploadButtonText: "uploadButtonText", uploadChunk: "uploadChunk", uploadCustomData: "uploadCustomData", uploadedMessage: "uploadedMessage", uploadFailedMessage: "uploadFailedMessage", uploadFile: "uploadFile", uploadHeaders: "uploadHeaders", uploadMethod: "uploadMethod", uploadMode: "uploadMode", uploadUrl: "uploadUrl", validationError: "validationError", validationErrors: "validationErrors", validationStatus: "validationStatus", value: "value", visible: "visible", width: "width" }, outputs: { valueChange: "valueChange" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoHtmlEditorFileUploaderOptionsComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-html-editor-file-uploader-options', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { abortUpload: [{
                type: Input
            }], accept: [{
                type: Input
            }], accessKey: [{
                type: Input
            }], activeStateEnabled: [{
                type: Input
            }], allowCanceling: [{
                type: Input
            }], allowedFileExtensions: [{
                type: Input
            }], chunkSize: [{
                type: Input
            }], dialogTrigger: [{
                type: Input
            }], disabled: [{
                type: Input
            }], dropZone: [{
                type: Input
            }], elementAttr: [{
                type: Input
            }], focusStateEnabled: [{
                type: Input
            }], height: [{
                type: Input
            }], hint: [{
                type: Input
            }], hoverStateEnabled: [{
                type: Input
            }], inputAttr: [{
                type: Input
            }], invalidFileExtensionMessage: [{
                type: Input
            }], invalidMaxFileSizeMessage: [{
                type: Input
            }], invalidMinFileSizeMessage: [{
                type: Input
            }], isDirty: [{
                type: Input
            }], isValid: [{
                type: Input
            }], labelText: [{
                type: Input
            }], maxFileSize: [{
                type: Input
            }], minFileSize: [{
                type: Input
            }], multiple: [{
                type: Input
            }], name: [{
                type: Input
            }], onBeforeSend: [{
                type: Input
            }], onContentReady: [{
                type: Input
            }], onDisposing: [{
                type: Input
            }], onDropZoneEnter: [{
                type: Input
            }], onDropZoneLeave: [{
                type: Input
            }], onFilesUploaded: [{
                type: Input
            }], onInitialized: [{
                type: Input
            }], onOptionChanged: [{
                type: Input
            }], onProgress: [{
                type: Input
            }], onUploadAborted: [{
                type: Input
            }], onUploaded: [{
                type: Input
            }], onUploadError: [{
                type: Input
            }], onUploadStarted: [{
                type: Input
            }], onValueChanged: [{
                type: Input
            }], progress: [{
                type: Input
            }], readOnly: [{
                type: Input
            }], readyToUploadMessage: [{
                type: Input
            }], rtlEnabled: [{
                type: Input
            }], selectButtonText: [{
                type: Input
            }], showFileList: [{
                type: Input
            }], tabIndex: [{
                type: Input
            }], uploadAbortedMessage: [{
                type: Input
            }], uploadButtonText: [{
                type: Input
            }], uploadChunk: [{
                type: Input
            }], uploadCustomData: [{
                type: Input
            }], uploadedMessage: [{
                type: Input
            }], uploadFailedMessage: [{
                type: Input
            }], uploadFile: [{
                type: Input
            }], uploadHeaders: [{
                type: Input
            }], uploadMethod: [{
                type: Input
            }], uploadMode: [{
                type: Input
            }], uploadUrl: [{
                type: Input
            }], validationError: [{
                type: Input
            }], validationErrors: [{
                type: Input
            }], validationStatus: [{
                type: Input
            }], value: [{
                type: Input
            }], visible: [{
                type: Input
            }], width: [{
                type: Input
            }], valueChange: [{
                type: Output
            }] } });
class DxoHtmlEditorFileUploaderOptionsModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoHtmlEditorFileUploaderOptionsModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoHtmlEditorFileUploaderOptionsModule, imports: [DxoHtmlEditorFileUploaderOptionsComponent], exports: [DxoHtmlEditorFileUploaderOptionsComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoHtmlEditorFileUploaderOptionsModule, imports: [DxoHtmlEditorFileUploaderOptionsComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoHtmlEditorFileUploaderOptionsModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoHtmlEditorFileUploaderOptionsComponent
                    ],
                    exports: [
                        DxoHtmlEditorFileUploaderOptionsComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoHtmlEditorImageUploadComponent extends NestedOption {
    set _tabsContentChildren(value) {
        this.setChildren('tabs', value);
    }
    get fileUploaderOptions() {
        return this._getOption('fileUploaderOptions');
    }
    set fileUploaderOptions(value) {
        this._setOption('fileUploaderOptions', value);
    }
    get fileUploadMode() {
        return this._getOption('fileUploadMode');
    }
    set fileUploadMode(value) {
        this._setOption('fileUploadMode', value);
    }
    get tabs() {
        return this._getOption('tabs');
    }
    set tabs(value) {
        this._setOption('tabs', value);
    }
    get uploadDirectory() {
        return this._getOption('uploadDirectory');
    }
    set uploadDirectory(value) {
        this._setOption('uploadDirectory', value);
    }
    get uploadUrl() {
        return this._getOption('uploadUrl');
    }
    set uploadUrl(value) {
        this._setOption('uploadUrl', value);
    }
    get _optionPath() {
        return 'imageUpload';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoHtmlEditorImageUploadComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoHtmlEditorImageUploadComponent, isStandalone: true, selector: "dxo-html-editor-image-upload", inputs: { fileUploaderOptions: "fileUploaderOptions", fileUploadMode: "fileUploadMode", tabs: "tabs", uploadDirectory: "uploadDirectory", uploadUrl: "uploadUrl" }, providers: [NestedOptionHost], queries: [{ propertyName: "_tabsContentChildren", predicate: PROPERTY_TOKEN_tabs }], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoHtmlEditorImageUploadComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-html-editor-image-upload', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { _tabsContentChildren: [{
                type: ContentChildren,
                args: [PROPERTY_TOKEN_tabs]
            }], fileUploaderOptions: [{
                type: Input
            }], fileUploadMode: [{
                type: Input
            }], tabs: [{
                type: Input
            }], uploadDirectory: [{
                type: Input
            }], uploadUrl: [{
                type: Input
            }] } });
class DxoHtmlEditorImageUploadModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoHtmlEditorImageUploadModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoHtmlEditorImageUploadModule, imports: [DxoHtmlEditorImageUploadComponent], exports: [DxoHtmlEditorImageUploadComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoHtmlEditorImageUploadModule, imports: [DxoHtmlEditorImageUploadComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoHtmlEditorImageUploadModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoHtmlEditorImageUploadComponent
                    ],
                    exports: [
                        DxoHtmlEditorImageUploadComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxiHtmlEditorItemComponent extends CollectionNestedOption {
    set _commandsContentChildren(value) {
        this.setChildren('commands', value);
    }
    set _itemsContentChildren(value) {
        this.setChildren('items', value);
    }
    get beginGroup() {
        return this._getOption('beginGroup');
    }
    set beginGroup(value) {
        this._setOption('beginGroup', value);
    }
    get closeMenuOnClick() {
        return this._getOption('closeMenuOnClick');
    }
    set closeMenuOnClick(value) {
        this._setOption('closeMenuOnClick', value);
    }
    get disabled() {
        return this._getOption('disabled');
    }
    set disabled(value) {
        this._setOption('disabled', value);
    }
    get icon() {
        return this._getOption('icon');
    }
    set icon(value) {
        this._setOption('icon', value);
    }
    get items() {
        return this._getOption('items');
    }
    set items(value) {
        this._setOption('items', value);
    }
    get name() {
        return this._getOption('name');
    }
    set name(value) {
        this._setOption('name', value);
    }
    get selectable() {
        return this._getOption('selectable');
    }
    set selectable(value) {
        this._setOption('selectable', value);
    }
    get selected() {
        return this._getOption('selected');
    }
    set selected(value) {
        this._setOption('selected', value);
    }
    get template() {
        return this._getOption('template');
    }
    set template(value) {
        this._setOption('template', value);
    }
    get text() {
        return this._getOption('text');
    }
    set text(value) {
        this._setOption('text', value);
    }
    get visible() {
        return this._getOption('visible');
    }
    set visible(value) {
        this._setOption('visible', value);
    }
    get acceptedValues() {
        return this._getOption('acceptedValues');
    }
    set acceptedValues(value) {
        this._setOption('acceptedValues', value);
    }
    get commands() {
        return this._getOption('commands');
    }
    set commands(value) {
        this._setOption('commands', value);
    }
    get cssClass() {
        return this._getOption('cssClass');
    }
    set cssClass(value) {
        this._setOption('cssClass', value);
    }
    get html() {
        return this._getOption('html');
    }
    set html(value) {
        this._setOption('html', value);
    }
    get locateInMenu() {
        return this._getOption('locateInMenu');
    }
    set locateInMenu(value) {
        this._setOption('locateInMenu', value);
    }
    get location() {
        return this._getOption('location');
    }
    set location(value) {
        this._setOption('location', value);
    }
    get menuItemTemplate() {
        return this._getOption('menuItemTemplate');
    }
    set menuItemTemplate(value) {
        this._setOption('menuItemTemplate', value);
    }
    get options() {
        return this._getOption('options');
    }
    set options(value) {
        this._setOption('options', value);
    }
    get showText() {
        return this._getOption('showText');
    }
    set showText(value) {
        this._setOption('showText', value);
    }
    get widget() {
        return this._getOption('widget');
    }
    set widget(value) {
        this._setOption('widget', value);
    }
    get _optionPath() {
        return 'items';
    }
    constructor(parentOptionHost, optionHost, renderer, document, templateHost, element) {
        super();
        this.renderer = renderer;
        this.document = document;
        this.element = element;
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
        templateHost.setHost(this);
    }
    setTemplate(template) {
        this.template = template;
    }
    ngAfterViewInit() {
        extractTemplate(this, this.element, this.renderer, this.document);
    }
    ngOnDestroy() {
        this._deleteRemovedOptions(this._fullOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiHtmlEditorItemComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }, { token: i0.Renderer2 }, { token: DOCUMENT }, { token: i1.DxTemplateHost, host: true }, { token: i0.ElementRef }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxiHtmlEditorItemComponent, isStandalone: true, selector: "dxi-html-editor-item", inputs: { beginGroup: "beginGroup", closeMenuOnClick: "closeMenuOnClick", disabled: "disabled", icon: "icon", items: "items", name: "name", selectable: "selectable", selected: "selected", template: "template", text: "text", visible: "visible", acceptedValues: "acceptedValues", commands: "commands", cssClass: "cssClass", html: "html", locateInMenu: "locateInMenu", location: "location", menuItemTemplate: "menuItemTemplate", options: "options", showText: "showText", widget: "widget" }, providers: [
            NestedOptionHost,
            DxTemplateHost,
            {
                provide: PROPERTY_TOKEN_items,
                useExisting: DxiHtmlEditorItemComponent,
            }
        ], queries: [{ propertyName: "_commandsContentChildren", predicate: PROPERTY_TOKEN_commands }, { propertyName: "_itemsContentChildren", predicate: PROPERTY_TOKEN_items }], usesInheritance: true, ngImport: i0, template: '<ng-content></ng-content>', isInline: true, styles: [":host{display:block}\n"], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiHtmlEditorItemComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxi-html-editor-item', template: '<ng-content></ng-content>', imports: [DxIntegrationModule], providers: [
                        NestedOptionHost,
                        DxTemplateHost,
                        {
                            provide: PROPERTY_TOKEN_items,
                            useExisting: DxiHtmlEditorItemComponent,
                        }
                    ], styles: [":host{display:block}\n"] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }, { type: i0.Renderer2 }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [DOCUMENT]
                }] }, { type: i1.DxTemplateHost, decorators: [{
                    type: Host
                }] }, { type: i0.ElementRef }], propDecorators: { _commandsContentChildren: [{
                type: ContentChildren,
                args: [PROPERTY_TOKEN_commands]
            }], _itemsContentChildren: [{
                type: ContentChildren,
                args: [PROPERTY_TOKEN_items]
            }], beginGroup: [{
                type: Input
            }], closeMenuOnClick: [{
                type: Input
            }], disabled: [{
                type: Input
            }], icon: [{
                type: Input
            }], items: [{
                type: Input
            }], name: [{
                type: Input
            }], selectable: [{
                type: Input
            }], selected: [{
                type: Input
            }], template: [{
                type: Input
            }], text: [{
                type: Input
            }], visible: [{
                type: Input
            }], acceptedValues: [{
                type: Input
            }], commands: [{
                type: Input
            }], cssClass: [{
                type: Input
            }], html: [{
                type: Input
            }], locateInMenu: [{
                type: Input
            }], location: [{
                type: Input
            }], menuItemTemplate: [{
                type: Input
            }], options: [{
                type: Input
            }], showText: [{
                type: Input
            }], widget: [{
                type: Input
            }] } });
class DxiHtmlEditorItemModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiHtmlEditorItemModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxiHtmlEditorItemModule, imports: [DxiHtmlEditorItemComponent], exports: [DxiHtmlEditorItemComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiHtmlEditorItemModule, imports: [DxiHtmlEditorItemComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiHtmlEditorItemModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxiHtmlEditorItemComponent
                    ],
                    exports: [
                        DxiHtmlEditorItemComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoHtmlEditorMediaResizingComponent extends NestedOption {
    get allowedTargets() {
        return this._getOption('allowedTargets');
    }
    set allowedTargets(value) {
        this._setOption('allowedTargets', value);
    }
    get enabled() {
        return this._getOption('enabled');
    }
    set enabled(value) {
        this._setOption('enabled', value);
    }
    get _optionPath() {
        return 'mediaResizing';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoHtmlEditorMediaResizingComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoHtmlEditorMediaResizingComponent, isStandalone: true, selector: "dxo-html-editor-media-resizing", inputs: { allowedTargets: "allowedTargets", enabled: "enabled" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoHtmlEditorMediaResizingComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-html-editor-media-resizing', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { allowedTargets: [{
                type: Input
            }], enabled: [{
                type: Input
            }] } });
class DxoHtmlEditorMediaResizingModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoHtmlEditorMediaResizingModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoHtmlEditorMediaResizingModule, imports: [DxoHtmlEditorMediaResizingComponent], exports: [DxoHtmlEditorMediaResizingComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoHtmlEditorMediaResizingModule, imports: [DxoHtmlEditorMediaResizingComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoHtmlEditorMediaResizingModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoHtmlEditorMediaResizingComponent
                    ],
                    exports: [
                        DxoHtmlEditorMediaResizingComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxiHtmlEditorMentionComponent extends CollectionNestedOption {
    get dataSource() {
        return this._getOption('dataSource');
    }
    set dataSource(value) {
        this._setOption('dataSource', value);
    }
    get displayExpr() {
        return this._getOption('displayExpr');
    }
    set displayExpr(value) {
        this._setOption('displayExpr', value);
    }
    get itemTemplate() {
        return this._getOption('itemTemplate');
    }
    set itemTemplate(value) {
        this._setOption('itemTemplate', value);
    }
    get marker() {
        return this._getOption('marker');
    }
    set marker(value) {
        this._setOption('marker', value);
    }
    get minSearchLength() {
        return this._getOption('minSearchLength');
    }
    set minSearchLength(value) {
        this._setOption('minSearchLength', value);
    }
    get searchExpr() {
        return this._getOption('searchExpr');
    }
    set searchExpr(value) {
        this._setOption('searchExpr', value);
    }
    get searchTimeout() {
        return this._getOption('searchTimeout');
    }
    set searchTimeout(value) {
        this._setOption('searchTimeout', value);
    }
    get template() {
        return this._getOption('template');
    }
    set template(value) {
        this._setOption('template', value);
    }
    get valueExpr() {
        return this._getOption('valueExpr');
    }
    set valueExpr(value) {
        this._setOption('valueExpr', value);
    }
    get _optionPath() {
        return 'mentions';
    }
    constructor(parentOptionHost, optionHost, renderer, document, templateHost, element) {
        super();
        this.renderer = renderer;
        this.document = document;
        this.element = element;
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
        templateHost.setHost(this);
    }
    setTemplate(template) {
        this.template = template;
    }
    ngAfterViewInit() {
        extractTemplate(this, this.element, this.renderer, this.document);
    }
    ngOnDestroy() {
        this._deleteRemovedOptions(this._fullOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiHtmlEditorMentionComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }, { token: i0.Renderer2 }, { token: DOCUMENT }, { token: i1.DxTemplateHost, host: true }, { token: i0.ElementRef }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxiHtmlEditorMentionComponent, isStandalone: true, selector: "dxi-html-editor-mention", inputs: { dataSource: "dataSource", displayExpr: "displayExpr", itemTemplate: "itemTemplate", marker: "marker", minSearchLength: "minSearchLength", searchExpr: "searchExpr", searchTimeout: "searchTimeout", template: "template", valueExpr: "valueExpr" }, providers: [
            NestedOptionHost,
            DxTemplateHost,
            {
                provide: PROPERTY_TOKEN_mentions,
                useExisting: DxiHtmlEditorMentionComponent,
            }
        ], usesInheritance: true, ngImport: i0, template: '<ng-content></ng-content>', isInline: true, styles: [":host{display:block}\n"], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiHtmlEditorMentionComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxi-html-editor-mention', template: '<ng-content></ng-content>', imports: [DxIntegrationModule], providers: [
                        NestedOptionHost,
                        DxTemplateHost,
                        {
                            provide: PROPERTY_TOKEN_mentions,
                            useExisting: DxiHtmlEditorMentionComponent,
                        }
                    ], styles: [":host{display:block}\n"] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }, { type: i0.Renderer2 }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [DOCUMENT]
                }] }, { type: i1.DxTemplateHost, decorators: [{
                    type: Host
                }] }, { type: i0.ElementRef }], propDecorators: { dataSource: [{
                type: Input
            }], displayExpr: [{
                type: Input
            }], itemTemplate: [{
                type: Input
            }], marker: [{
                type: Input
            }], minSearchLength: [{
                type: Input
            }], searchExpr: [{
                type: Input
            }], searchTimeout: [{
                type: Input
            }], template: [{
                type: Input
            }], valueExpr: [{
                type: Input
            }] } });
class DxiHtmlEditorMentionModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiHtmlEditorMentionModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxiHtmlEditorMentionModule, imports: [DxiHtmlEditorMentionComponent], exports: [DxiHtmlEditorMentionComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiHtmlEditorMentionModule, imports: [DxiHtmlEditorMentionComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiHtmlEditorMentionModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxiHtmlEditorMentionComponent
                    ],
                    exports: [
                        DxiHtmlEditorMentionComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxiHtmlEditorTabComponent extends CollectionNestedOption {
    get name() {
        return this._getOption('name');
    }
    set name(value) {
        this._setOption('name', value);
    }
    get _optionPath() {
        return 'tabs';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnDestroy() {
        this._deleteRemovedOptions(this._fullOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiHtmlEditorTabComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxiHtmlEditorTabComponent, isStandalone: true, selector: "dxi-html-editor-tab", inputs: { name: "name" }, providers: [
            NestedOptionHost,
            {
                provide: PROPERTY_TOKEN_tabs,
                useExisting: DxiHtmlEditorTabComponent,
            }
        ], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiHtmlEditorTabComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxi-html-editor-tab', template: '', imports: [DxIntegrationModule], providers: [
                        NestedOptionHost,
                        {
                            provide: PROPERTY_TOKEN_tabs,
                            useExisting: DxiHtmlEditorTabComponent,
                        }
                    ] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { name: [{
                type: Input
            }] } });
class DxiHtmlEditorTabModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiHtmlEditorTabModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxiHtmlEditorTabModule, imports: [DxiHtmlEditorTabComponent], exports: [DxiHtmlEditorTabComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiHtmlEditorTabModule, imports: [DxiHtmlEditorTabComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiHtmlEditorTabModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxiHtmlEditorTabComponent
                    ],
                    exports: [
                        DxiHtmlEditorTabComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxiHtmlEditorTableContextMenuItemComponent extends CollectionNestedOption {
    set _itemsContentChildren(value) {
        this.setChildren('items', value);
    }
    get beginGroup() {
        return this._getOption('beginGroup');
    }
    set beginGroup(value) {
        this._setOption('beginGroup', value);
    }
    get closeMenuOnClick() {
        return this._getOption('closeMenuOnClick');
    }
    set closeMenuOnClick(value) {
        this._setOption('closeMenuOnClick', value);
    }
    get disabled() {
        return this._getOption('disabled');
    }
    set disabled(value) {
        this._setOption('disabled', value);
    }
    get icon() {
        return this._getOption('icon');
    }
    set icon(value) {
        this._setOption('icon', value);
    }
    get items() {
        return this._getOption('items');
    }
    set items(value) {
        this._setOption('items', value);
    }
    get name() {
        return this._getOption('name');
    }
    set name(value) {
        this._setOption('name', value);
    }
    get selectable() {
        return this._getOption('selectable');
    }
    set selectable(value) {
        this._setOption('selectable', value);
    }
    get selected() {
        return this._getOption('selected');
    }
    set selected(value) {
        this._setOption('selected', value);
    }
    get template() {
        return this._getOption('template');
    }
    set template(value) {
        this._setOption('template', value);
    }
    get text() {
        return this._getOption('text');
    }
    set text(value) {
        this._setOption('text', value);
    }
    get visible() {
        return this._getOption('visible');
    }
    set visible(value) {
        this._setOption('visible', value);
    }
    get _optionPath() {
        return 'items';
    }
    constructor(parentOptionHost, optionHost, renderer, document, templateHost, element) {
        super();
        this.renderer = renderer;
        this.document = document;
        this.element = element;
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
        templateHost.setHost(this);
    }
    setTemplate(template) {
        this.template = template;
    }
    ngAfterViewInit() {
        extractTemplate(this, this.element, this.renderer, this.document);
    }
    ngOnDestroy() {
        this._deleteRemovedOptions(this._fullOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiHtmlEditorTableContextMenuItemComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }, { token: i0.Renderer2 }, { token: DOCUMENT }, { token: i1.DxTemplateHost, host: true }, { token: i0.ElementRef }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxiHtmlEditorTableContextMenuItemComponent, isStandalone: true, selector: "dxi-html-editor-table-context-menu-item", inputs: { beginGroup: "beginGroup", closeMenuOnClick: "closeMenuOnClick", disabled: "disabled", icon: "icon", items: "items", name: "name", selectable: "selectable", selected: "selected", template: "template", text: "text", visible: "visible" }, providers: [
            NestedOptionHost,
            DxTemplateHost,
            {
                provide: PROPERTY_TOKEN_items,
                useExisting: DxiHtmlEditorTableContextMenuItemComponent,
            }
        ], queries: [{ propertyName: "_itemsContentChildren", predicate: PROPERTY_TOKEN_items }], usesInheritance: true, ngImport: i0, template: '<ng-content></ng-content>', isInline: true, styles: [":host{display:block}\n"], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiHtmlEditorTableContextMenuItemComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxi-html-editor-table-context-menu-item', template: '<ng-content></ng-content>', imports: [DxIntegrationModule], providers: [
                        NestedOptionHost,
                        DxTemplateHost,
                        {
                            provide: PROPERTY_TOKEN_items,
                            useExisting: DxiHtmlEditorTableContextMenuItemComponent,
                        }
                    ], styles: [":host{display:block}\n"] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }, { type: i0.Renderer2 }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [DOCUMENT]
                }] }, { type: i1.DxTemplateHost, decorators: [{
                    type: Host
                }] }, { type: i0.ElementRef }], propDecorators: { _itemsContentChildren: [{
                type: ContentChildren,
                args: [PROPERTY_TOKEN_items]
            }], beginGroup: [{
                type: Input
            }], closeMenuOnClick: [{
                type: Input
            }], disabled: [{
                type: Input
            }], icon: [{
                type: Input
            }], items: [{
                type: Input
            }], name: [{
                type: Input
            }], selectable: [{
                type: Input
            }], selected: [{
                type: Input
            }], template: [{
                type: Input
            }], text: [{
                type: Input
            }], visible: [{
                type: Input
            }] } });
class DxiHtmlEditorTableContextMenuItemModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiHtmlEditorTableContextMenuItemModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxiHtmlEditorTableContextMenuItemModule, imports: [DxiHtmlEditorTableContextMenuItemComponent], exports: [DxiHtmlEditorTableContextMenuItemComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiHtmlEditorTableContextMenuItemModule, imports: [DxiHtmlEditorTableContextMenuItemComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiHtmlEditorTableContextMenuItemModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxiHtmlEditorTableContextMenuItemComponent
                    ],
                    exports: [
                        DxiHtmlEditorTableContextMenuItemComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoHtmlEditorTableContextMenuComponent extends NestedOption {
    set _itemsContentChildren(value) {
        this.setChildren('items', value);
    }
    get enabled() {
        return this._getOption('enabled');
    }
    set enabled(value) {
        this._setOption('enabled', value);
    }
    get items() {
        return this._getOption('items');
    }
    set items(value) {
        this._setOption('items', value);
    }
    get _optionPath() {
        return 'tableContextMenu';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoHtmlEditorTableContextMenuComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoHtmlEditorTableContextMenuComponent, isStandalone: true, selector: "dxo-html-editor-table-context-menu", inputs: { enabled: "enabled", items: "items" }, providers: [NestedOptionHost], queries: [{ propertyName: "_itemsContentChildren", predicate: PROPERTY_TOKEN_items }], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoHtmlEditorTableContextMenuComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-html-editor-table-context-menu', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { _itemsContentChildren: [{
                type: ContentChildren,
                args: [PROPERTY_TOKEN_items]
            }], enabled: [{
                type: Input
            }], items: [{
                type: Input
            }] } });
class DxoHtmlEditorTableContextMenuModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoHtmlEditorTableContextMenuModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoHtmlEditorTableContextMenuModule, imports: [DxoHtmlEditorTableContextMenuComponent], exports: [DxoHtmlEditorTableContextMenuComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoHtmlEditorTableContextMenuModule, imports: [DxoHtmlEditorTableContextMenuComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoHtmlEditorTableContextMenuModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoHtmlEditorTableContextMenuComponent
                    ],
                    exports: [
                        DxoHtmlEditorTableContextMenuComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoHtmlEditorTableResizingComponent extends NestedOption {
    get enabled() {
        return this._getOption('enabled');
    }
    set enabled(value) {
        this._setOption('enabled', value);
    }
    get minColumnWidth() {
        return this._getOption('minColumnWidth');
    }
    set minColumnWidth(value) {
        this._setOption('minColumnWidth', value);
    }
    get minRowHeight() {
        return this._getOption('minRowHeight');
    }
    set minRowHeight(value) {
        this._setOption('minRowHeight', value);
    }
    get _optionPath() {
        return 'tableResizing';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoHtmlEditorTableResizingComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoHtmlEditorTableResizingComponent, isStandalone: true, selector: "dxo-html-editor-table-resizing", inputs: { enabled: "enabled", minColumnWidth: "minColumnWidth", minRowHeight: "minRowHeight" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoHtmlEditorTableResizingComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-html-editor-table-resizing', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { enabled: [{
                type: Input
            }], minColumnWidth: [{
                type: Input
            }], minRowHeight: [{
                type: Input
            }] } });
class DxoHtmlEditorTableResizingModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoHtmlEditorTableResizingModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoHtmlEditorTableResizingModule, imports: [DxoHtmlEditorTableResizingComponent], exports: [DxoHtmlEditorTableResizingComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoHtmlEditorTableResizingModule, imports: [DxoHtmlEditorTableResizingComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoHtmlEditorTableResizingModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoHtmlEditorTableResizingComponent
                    ],
                    exports: [
                        DxoHtmlEditorTableResizingComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxiHtmlEditorToolbarItemComponent extends CollectionNestedOption {
    set _commandsContentChildren(value) {
        this.setChildren('commands', value);
    }
    get acceptedValues() {
        return this._getOption('acceptedValues');
    }
    set acceptedValues(value) {
        this._setOption('acceptedValues', value);
    }
    get commands() {
        return this._getOption('commands');
    }
    set commands(value) {
        this._setOption('commands', value);
    }
    get cssClass() {
        return this._getOption('cssClass');
    }
    set cssClass(value) {
        this._setOption('cssClass', value);
    }
    get disabled() {
        return this._getOption('disabled');
    }
    set disabled(value) {
        this._setOption('disabled', value);
    }
    get html() {
        return this._getOption('html');
    }
    set html(value) {
        this._setOption('html', value);
    }
    get locateInMenu() {
        return this._getOption('locateInMenu');
    }
    set locateInMenu(value) {
        this._setOption('locateInMenu', value);
    }
    get location() {
        return this._getOption('location');
    }
    set location(value) {
        this._setOption('location', value);
    }
    get menuItemTemplate() {
        return this._getOption('menuItemTemplate');
    }
    set menuItemTemplate(value) {
        this._setOption('menuItemTemplate', value);
    }
    get name() {
        return this._getOption('name');
    }
    set name(value) {
        this._setOption('name', value);
    }
    get options() {
        return this._getOption('options');
    }
    set options(value) {
        this._setOption('options', value);
    }
    get showText() {
        return this._getOption('showText');
    }
    set showText(value) {
        this._setOption('showText', value);
    }
    get template() {
        return this._getOption('template');
    }
    set template(value) {
        this._setOption('template', value);
    }
    get text() {
        return this._getOption('text');
    }
    set text(value) {
        this._setOption('text', value);
    }
    get visible() {
        return this._getOption('visible');
    }
    set visible(value) {
        this._setOption('visible', value);
    }
    get widget() {
        return this._getOption('widget');
    }
    set widget(value) {
        this._setOption('widget', value);
    }
    get _optionPath() {
        return 'items';
    }
    constructor(parentOptionHost, optionHost, renderer, document, templateHost, element) {
        super();
        this.renderer = renderer;
        this.document = document;
        this.element = element;
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
        templateHost.setHost(this);
    }
    setTemplate(template) {
        this.template = template;
    }
    ngAfterViewInit() {
        extractTemplate(this, this.element, this.renderer, this.document);
    }
    ngOnDestroy() {
        this._deleteRemovedOptions(this._fullOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiHtmlEditorToolbarItemComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }, { token: i0.Renderer2 }, { token: DOCUMENT }, { token: i1.DxTemplateHost, host: true }, { token: i0.ElementRef }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxiHtmlEditorToolbarItemComponent, isStandalone: true, selector: "dxi-html-editor-toolbar-item", inputs: { acceptedValues: "acceptedValues", commands: "commands", cssClass: "cssClass", disabled: "disabled", html: "html", locateInMenu: "locateInMenu", location: "location", menuItemTemplate: "menuItemTemplate", name: "name", options: "options", showText: "showText", template: "template", text: "text", visible: "visible", widget: "widget" }, providers: [
            NestedOptionHost,
            DxTemplateHost,
            {
                provide: PROPERTY_TOKEN_items,
                useExisting: DxiHtmlEditorToolbarItemComponent,
            }
        ], queries: [{ propertyName: "_commandsContentChildren", predicate: PROPERTY_TOKEN_commands }], usesInheritance: true, ngImport: i0, template: '<ng-content></ng-content>', isInline: true, styles: [":host{display:block}\n"], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiHtmlEditorToolbarItemComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxi-html-editor-toolbar-item', template: '<ng-content></ng-content>', imports: [DxIntegrationModule], providers: [
                        NestedOptionHost,
                        DxTemplateHost,
                        {
                            provide: PROPERTY_TOKEN_items,
                            useExisting: DxiHtmlEditorToolbarItemComponent,
                        }
                    ], styles: [":host{display:block}\n"] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }, { type: i0.Renderer2 }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [DOCUMENT]
                }] }, { type: i1.DxTemplateHost, decorators: [{
                    type: Host
                }] }, { type: i0.ElementRef }], propDecorators: { _commandsContentChildren: [{
                type: ContentChildren,
                args: [PROPERTY_TOKEN_commands]
            }], acceptedValues: [{
                type: Input
            }], commands: [{
                type: Input
            }], cssClass: [{
                type: Input
            }], disabled: [{
                type: Input
            }], html: [{
                type: Input
            }], locateInMenu: [{
                type: Input
            }], location: [{
                type: Input
            }], menuItemTemplate: [{
                type: Input
            }], name: [{
                type: Input
            }], options: [{
                type: Input
            }], showText: [{
                type: Input
            }], template: [{
                type: Input
            }], text: [{
                type: Input
            }], visible: [{
                type: Input
            }], widget: [{
                type: Input
            }] } });
class DxiHtmlEditorToolbarItemModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiHtmlEditorToolbarItemModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxiHtmlEditorToolbarItemModule, imports: [DxiHtmlEditorToolbarItemComponent], exports: [DxiHtmlEditorToolbarItemComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiHtmlEditorToolbarItemModule, imports: [DxiHtmlEditorToolbarItemComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiHtmlEditorToolbarItemModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxiHtmlEditorToolbarItemComponent
                    ],
                    exports: [
                        DxiHtmlEditorToolbarItemComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoHtmlEditorToolbarComponent extends NestedOption {
    set _itemsContentChildren(value) {
        this.setChildren('items', value);
    }
    get container() {
        return this._getOption('container');
    }
    set container(value) {
        this._setOption('container', value);
    }
    get items() {
        return this._getOption('items');
    }
    set items(value) {
        this._setOption('items', value);
    }
    get multiline() {
        return this._getOption('multiline');
    }
    set multiline(value) {
        this._setOption('multiline', value);
    }
    get _optionPath() {
        return 'toolbar';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoHtmlEditorToolbarComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoHtmlEditorToolbarComponent, isStandalone: true, selector: "dxo-html-editor-toolbar", inputs: { container: "container", items: "items", multiline: "multiline" }, providers: [NestedOptionHost], queries: [{ propertyName: "_itemsContentChildren", predicate: PROPERTY_TOKEN_items }], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoHtmlEditorToolbarComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-html-editor-toolbar', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { _itemsContentChildren: [{
                type: ContentChildren,
                args: [PROPERTY_TOKEN_items]
            }], container: [{
                type: Input
            }], items: [{
                type: Input
            }], multiline: [{
                type: Input
            }] } });
class DxoHtmlEditorToolbarModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoHtmlEditorToolbarModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoHtmlEditorToolbarModule, imports: [DxoHtmlEditorToolbarComponent], exports: [DxoHtmlEditorToolbarComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoHtmlEditorToolbarModule, imports: [DxoHtmlEditorToolbarComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoHtmlEditorToolbarModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoHtmlEditorToolbarComponent
                    ],
                    exports: [
                        DxoHtmlEditorToolbarComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoHtmlEditorVariablesComponent extends NestedOption {
    get dataSource() {
        return this._getOption('dataSource');
    }
    set dataSource(value) {
        this._setOption('dataSource', value);
    }
    get escapeChar() {
        return this._getOption('escapeChar');
    }
    set escapeChar(value) {
        this._setOption('escapeChar', value);
    }
    get _optionPath() {
        return 'variables';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoHtmlEditorVariablesComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoHtmlEditorVariablesComponent, isStandalone: true, selector: "dxo-html-editor-variables", inputs: { dataSource: "dataSource", escapeChar: "escapeChar" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoHtmlEditorVariablesComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-html-editor-variables', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { dataSource: [{
                type: Input
            }], escapeChar: [{
                type: Input
            }] } });
class DxoHtmlEditorVariablesModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoHtmlEditorVariablesModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoHtmlEditorVariablesModule, imports: [DxoHtmlEditorVariablesComponent], exports: [DxoHtmlEditorVariablesComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoHtmlEditorVariablesModule, imports: [DxoHtmlEditorVariablesComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoHtmlEditorVariablesModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoHtmlEditorVariablesComponent
                    ],
                    exports: [
                        DxoHtmlEditorVariablesComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

/**
 * Generated bundle index. Do not edit.
 */

export { DxiHtmlEditorCommandComponent, DxiHtmlEditorCommandModule, DxiHtmlEditorItemComponent, DxiHtmlEditorItemModule, DxiHtmlEditorMentionComponent, DxiHtmlEditorMentionModule, DxiHtmlEditorTabComponent, DxiHtmlEditorTabModule, DxiHtmlEditorTableContextMenuItemComponent, DxiHtmlEditorTableContextMenuItemModule, DxiHtmlEditorToolbarItemComponent, DxiHtmlEditorToolbarItemModule, DxoHtmlEditorConverterComponent, DxoHtmlEditorConverterModule, DxoHtmlEditorFileUploaderOptionsComponent, DxoHtmlEditorFileUploaderOptionsModule, DxoHtmlEditorImageUploadComponent, DxoHtmlEditorImageUploadModule, DxoHtmlEditorMediaResizingComponent, DxoHtmlEditorMediaResizingModule, DxoHtmlEditorTableContextMenuComponent, DxoHtmlEditorTableContextMenuModule, DxoHtmlEditorTableResizingComponent, DxoHtmlEditorTableResizingModule, DxoHtmlEditorToolbarComponent, DxoHtmlEditorToolbarModule, DxoHtmlEditorVariablesComponent, DxoHtmlEditorVariablesModule };
//# sourceMappingURL=devextreme-angular-ui-html-editor-nested.mjs.map
