import * as i0 from '@angular/core';
import { PLATFORM_ID, Output, Input, Inject, Component, NgModule } from '@angular/core';
import DxPagination from 'devextreme/ui/pagination';
import * as i1 from 'devextreme-angular/core';
import { DxComponent, DxIntegrationModule, DxTemplateHost, WatcherHelper, NestedOptionHost, IterableDifferHelper, DxTemplateModule } from 'devextreme-angular/core';

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
/**
 * [descr:dxPagination]

 */
class DxPaginationComponent extends DxComponent {
    /**
     * [descr:WidgetOptions.accessKey]
    
     */
    get accessKey() {
        return this._getOption('accessKey');
    }
    set accessKey(value) {
        this._setOption('accessKey', value);
    }
    /**
     * [descr:WidgetOptions.activeStateEnabled]
    
     */
    get activeStateEnabled() {
        return this._getOption('activeStateEnabled');
    }
    set activeStateEnabled(value) {
        this._setOption('activeStateEnabled', value);
    }
    /**
     * [descr:dxPaginationOptions.allowedPageSizes]
    
     */
    get allowedPageSizes() {
        return this._getOption('allowedPageSizes');
    }
    set allowedPageSizes(value) {
        this._setOption('allowedPageSizes', value);
    }
    /**
     * [descr:WidgetOptions.disabled]
    
     */
    get disabled() {
        return this._getOption('disabled');
    }
    set disabled(value) {
        this._setOption('disabled', value);
    }
    /**
     * [descr:PagerBase.displayMode]
    
     */
    get displayMode() {
        return this._getOption('displayMode');
    }
    set displayMode(value) {
        this._setOption('displayMode', value);
    }
    /**
     * [descr:DOMComponentOptions.elementAttr]
    
     */
    get elementAttr() {
        return this._getOption('elementAttr');
    }
    set elementAttr(value) {
        this._setOption('elementAttr', value);
    }
    /**
     * [descr:WidgetOptions.focusStateEnabled]
    
     */
    get focusStateEnabled() {
        return this._getOption('focusStateEnabled');
    }
    set focusStateEnabled(value) {
        this._setOption('focusStateEnabled', value);
    }
    /**
     * [descr:DOMComponentOptions.height]
    
     */
    get height() {
        return this._getOption('height');
    }
    set height(value) {
        this._setOption('height', value);
    }
    /**
     * [descr:WidgetOptions.hint]
    
     */
    get hint() {
        return this._getOption('hint');
    }
    set hint(value) {
        this._setOption('hint', value);
    }
    /**
     * [descr:WidgetOptions.hoverStateEnabled]
    
     */
    get hoverStateEnabled() {
        return this._getOption('hoverStateEnabled');
    }
    set hoverStateEnabled(value) {
        this._setOption('hoverStateEnabled', value);
    }
    /**
     * [descr:PagerBase.infoText]
    
     */
    get infoText() {
        return this._getOption('infoText');
    }
    set infoText(value) {
        this._setOption('infoText', value);
    }
    /**
     * [descr:dxPaginationOptions.itemCount]
    
     */
    get itemCount() {
        return this._getOption('itemCount');
    }
    set itemCount(value) {
        this._setOption('itemCount', value);
    }
    /**
     * [descr:PagerBase.label]
    
     */
    get label() {
        return this._getOption('label');
    }
    set label(value) {
        this._setOption('label', value);
    }
    /**
     * [descr:dxPaginationOptions.pageIndex]
    
     */
    get pageIndex() {
        return this._getOption('pageIndex');
    }
    set pageIndex(value) {
        this._setOption('pageIndex', value);
    }
    /**
     * [descr:dxPaginationOptions.pageSize]
    
     */
    get pageSize() {
        return this._getOption('pageSize');
    }
    set pageSize(value) {
        this._setOption('pageSize', value);
    }
    /**
     * [descr:DOMComponentOptions.rtlEnabled]
    
     */
    get rtlEnabled() {
        return this._getOption('rtlEnabled');
    }
    set rtlEnabled(value) {
        this._setOption('rtlEnabled', value);
    }
    /**
     * [descr:PagerBase.showInfo]
    
     */
    get showInfo() {
        return this._getOption('showInfo');
    }
    set showInfo(value) {
        this._setOption('showInfo', value);
    }
    /**
     * [descr:PagerBase.showNavigationButtons]
    
     */
    get showNavigationButtons() {
        return this._getOption('showNavigationButtons');
    }
    set showNavigationButtons(value) {
        this._setOption('showNavigationButtons', value);
    }
    /**
     * [descr:PagerBase.showPageSizeSelector]
    
     */
    get showPageSizeSelector() {
        return this._getOption('showPageSizeSelector');
    }
    set showPageSizeSelector(value) {
        this._setOption('showPageSizeSelector', value);
    }
    /**
     * [descr:WidgetOptions.tabIndex]
    
     */
    get tabIndex() {
        return this._getOption('tabIndex');
    }
    set tabIndex(value) {
        this._setOption('tabIndex', value);
    }
    /**
     * [descr:WidgetOptions.visible]
    
     */
    get visible() {
        return this._getOption('visible');
    }
    set visible(value) {
        this._setOption('visible', value);
    }
    /**
     * [descr:DOMComponentOptions.width]
    
     */
    get width() {
        return this._getOption('width');
    }
    set width(value) {
        this._setOption('width', value);
    }
    constructor(elementRef, ngZone, templateHost, _watcherHelper, _idh, optionHost, transferState, platformId) {
        super(elementRef, ngZone, templateHost, _watcherHelper, transferState, platformId);
        this._watcherHelper = _watcherHelper;
        this._idh = _idh;
        this.instance = null;
        this._createEventEmitters([
            { subscribe: 'contentReady', emit: 'onContentReady' },
            { subscribe: 'disposing', emit: 'onDisposing' },
            { subscribe: 'initialized', emit: 'onInitialized' },
            { subscribe: 'optionChanged', emit: 'onOptionChanged' },
            { emit: 'accessKeyChange' },
            { emit: 'activeStateEnabledChange' },
            { emit: 'allowedPageSizesChange' },
            { emit: 'disabledChange' },
            { emit: 'displayModeChange' },
            { emit: 'elementAttrChange' },
            { emit: 'focusStateEnabledChange' },
            { emit: 'heightChange' },
            { emit: 'hintChange' },
            { emit: 'hoverStateEnabledChange' },
            { emit: 'infoTextChange' },
            { emit: 'itemCountChange' },
            { emit: 'labelChange' },
            { emit: 'pageIndexChange' },
            { emit: 'pageSizeChange' },
            { emit: 'rtlEnabledChange' },
            { emit: 'showInfoChange' },
            { emit: 'showNavigationButtonsChange' },
            { emit: 'showPageSizeSelectorChange' },
            { emit: 'tabIndexChange' },
            { emit: 'visibleChange' },
            { emit: 'widthChange' }
        ]);
        this._idh.setHost(this);
        optionHost.setHost(this);
    }
    _createInstance(element, options) {
        return new DxPagination(element, options);
    }
    ngOnDestroy() {
        this._destroyWidget();
    }
    ngOnChanges(changes) {
        super.ngOnChanges(changes);
        this.setupChanges('allowedPageSizes', changes);
    }
    setupChanges(prop, changes) {
        if (!(prop in this._optionsToUpdate)) {
            this._idh.setup(prop, changes);
        }
    }
    ngDoCheck() {
        this._idh.doCheck('allowedPageSizes');
        this._watcherHelper.checkWatchers();
        super.ngDoCheck();
        super.clearChangedOptions();
    }
    _setOption(name, value) {
        let isSetup = this._idh.setupSingle(name, value);
        let isChanged = this._idh.getChanges(name, value) !== null;
        if (isSetup || isChanged) {
            super._setOption(name, value);
        }
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxPaginationComponent, deps: [{ token: i0.ElementRef }, { token: i0.NgZone }, { token: i1.DxTemplateHost }, { token: i1.WatcherHelper }, { token: i1.IterableDifferHelper }, { token: i1.NestedOptionHost }, { token: i0.TransferState }, { token: PLATFORM_ID }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxPaginationComponent, isStandalone: true, selector: "dx-pagination", inputs: { accessKey: "accessKey", activeStateEnabled: "activeStateEnabled", allowedPageSizes: "allowedPageSizes", disabled: "disabled", displayMode: "displayMode", elementAttr: "elementAttr", focusStateEnabled: "focusStateEnabled", height: "height", hint: "hint", hoverStateEnabled: "hoverStateEnabled", infoText: "infoText", itemCount: "itemCount", label: "label", pageIndex: "pageIndex", pageSize: "pageSize", rtlEnabled: "rtlEnabled", showInfo: "showInfo", showNavigationButtons: "showNavigationButtons", showPageSizeSelector: "showPageSizeSelector", tabIndex: "tabIndex", visible: "visible", width: "width" }, outputs: { onContentReady: "onContentReady", onDisposing: "onDisposing", onInitialized: "onInitialized", onOptionChanged: "onOptionChanged", accessKeyChange: "accessKeyChange", activeStateEnabledChange: "activeStateEnabledChange", allowedPageSizesChange: "allowedPageSizesChange", disabledChange: "disabledChange", displayModeChange: "displayModeChange", elementAttrChange: "elementAttrChange", focusStateEnabledChange: "focusStateEnabledChange", heightChange: "heightChange", hintChange: "hintChange", hoverStateEnabledChange: "hoverStateEnabledChange", infoTextChange: "infoTextChange", itemCountChange: "itemCountChange", labelChange: "labelChange", pageIndexChange: "pageIndexChange", pageSizeChange: "pageSizeChange", rtlEnabledChange: "rtlEnabledChange", showInfoChange: "showInfoChange", showNavigationButtonsChange: "showNavigationButtonsChange", showPageSizeSelectorChange: "showPageSizeSelectorChange", tabIndexChange: "tabIndexChange", visibleChange: "visibleChange", widthChange: "widthChange" }, host: { attributes: { "ngSkipHydration": "true" } }, providers: [
            DxTemplateHost,
            WatcherHelper,
            NestedOptionHost,
            IterableDifferHelper
        ], usesInheritance: true, usesOnChanges: true, ngImport: i0, template: '', isInline: true, dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxPaginationComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'dx-pagination',
                    template: '',
                    host: { ngSkipHydration: 'true' },
                    imports: [DxIntegrationModule],
                    providers: [
                        DxTemplateHost,
                        WatcherHelper,
                        NestedOptionHost,
                        IterableDifferHelper
                    ]
                }]
        }], ctorParameters: () => [{ type: i0.ElementRef }, { type: i0.NgZone }, { type: i1.DxTemplateHost }, { type: i1.WatcherHelper }, { type: i1.IterableDifferHelper }, { type: i1.NestedOptionHost }, { type: i0.TransferState }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [PLATFORM_ID]
                }] }], propDecorators: { accessKey: [{
                type: Input
            }], activeStateEnabled: [{
                type: Input
            }], allowedPageSizes: [{
                type: Input
            }], disabled: [{
                type: Input
            }], displayMode: [{
                type: Input
            }], elementAttr: [{
                type: Input
            }], focusStateEnabled: [{
                type: Input
            }], height: [{
                type: Input
            }], hint: [{
                type: Input
            }], hoverStateEnabled: [{
                type: Input
            }], infoText: [{
                type: Input
            }], itemCount: [{
                type: Input
            }], label: [{
                type: Input
            }], pageIndex: [{
                type: Input
            }], pageSize: [{
                type: Input
            }], rtlEnabled: [{
                type: Input
            }], showInfo: [{
                type: Input
            }], showNavigationButtons: [{
                type: Input
            }], showPageSizeSelector: [{
                type: Input
            }], tabIndex: [{
                type: Input
            }], visible: [{
                type: Input
            }], width: [{
                type: Input
            }], onContentReady: [{
                type: Output
            }], onDisposing: [{
                type: Output
            }], onInitialized: [{
                type: Output
            }], onOptionChanged: [{
                type: Output
            }], accessKeyChange: [{
                type: Output
            }], activeStateEnabledChange: [{
                type: Output
            }], allowedPageSizesChange: [{
                type: Output
            }], disabledChange: [{
                type: Output
            }], displayModeChange: [{
                type: Output
            }], elementAttrChange: [{
                type: Output
            }], focusStateEnabledChange: [{
                type: Output
            }], heightChange: [{
                type: Output
            }], hintChange: [{
                type: Output
            }], hoverStateEnabledChange: [{
                type: Output
            }], infoTextChange: [{
                type: Output
            }], itemCountChange: [{
                type: Output
            }], labelChange: [{
                type: Output
            }], pageIndexChange: [{
                type: Output
            }], pageSizeChange: [{
                type: Output
            }], rtlEnabledChange: [{
                type: Output
            }], showInfoChange: [{
                type: Output
            }], showNavigationButtonsChange: [{
                type: Output
            }], showPageSizeSelectorChange: [{
                type: Output
            }], tabIndexChange: [{
                type: Output
            }], visibleChange: [{
                type: Output
            }], widthChange: [{
                type: Output
            }] } });
class DxPaginationModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxPaginationModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxPaginationModule, imports: [DxPaginationComponent, DxIntegrationModule,
            DxTemplateModule], exports: [DxPaginationComponent, DxTemplateModule] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxPaginationModule, imports: [DxPaginationComponent,
            DxIntegrationModule,
            DxTemplateModule, DxTemplateModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxPaginationModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxPaginationComponent,
                        DxIntegrationModule,
                        DxTemplateModule
                    ],
                    exports: [
                        DxPaginationComponent,
                        DxTemplateModule
                    ]
                }]
        }] });

/**
 * Generated bundle index. Do not edit.
 */

export { DxPaginationComponent, DxPaginationModule };
//# sourceMappingURL=devextreme-angular-ui-pagination.mjs.map
