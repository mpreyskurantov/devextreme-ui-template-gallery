import * as i0 from '@angular/core';
import { Input, SkipSelf, Host, Component, NgModule, Inject, Output, ContentChildren } from '@angular/core';
import * as i1 from 'devextreme-angular/core';
import { NestedOption, DxIntegrationModule, NestedOptionHost, CollectionNestedOption, extractTemplate, DxTemplateHost } from 'devextreme-angular/core';
import { PROPERTY_TOKEN_validationRules, PROPERTY_TOKEN_items, PROPERTY_TOKEN_tabs, PROPERTY_TOKEN_resources, PROPERTY_TOKEN_views } from 'devextreme-angular/core/tokens';
import { DOCUMENT } from '@angular/common';

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoSchedulerAIOptionsComponent extends NestedOption {
    get disabled() {
        return this._getOption('disabled');
    }
    set disabled(value) {
        this._setOption('disabled', value);
    }
    get instruction() {
        return this._getOption('instruction');
    }
    set instruction(value) {
        this._setOption('instruction', value);
    }
    get _optionPath() {
        return 'aiOptions';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoSchedulerAIOptionsComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoSchedulerAIOptionsComponent, isStandalone: true, selector: "dxo-scheduler-ai-options", inputs: { disabled: "disabled", instruction: "instruction" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoSchedulerAIOptionsComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-scheduler-ai-options', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { disabled: [{
                type: Input
            }], instruction: [{
                type: Input
            }] } });
class DxoSchedulerAIOptionsModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoSchedulerAIOptionsModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoSchedulerAIOptionsModule, imports: [DxoSchedulerAIOptionsComponent], exports: [DxoSchedulerAIOptionsComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoSchedulerAIOptionsModule, imports: [DxoSchedulerAIOptionsComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoSchedulerAIOptionsModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoSchedulerAIOptionsComponent
                    ],
                    exports: [
                        DxoSchedulerAIOptionsComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoSchedulerAppointmentDraggingComponent extends NestedOption {
    get autoScroll() {
        return this._getOption('autoScroll');
    }
    set autoScroll(value) {
        this._setOption('autoScroll', value);
    }
    get data() {
        return this._getOption('data');
    }
    set data(value) {
        this._setOption('data', value);
    }
    get group() {
        return this._getOption('group');
    }
    set group(value) {
        this._setOption('group', value);
    }
    get onAdd() {
        return this._getOption('onAdd');
    }
    set onAdd(value) {
        this._setOption('onAdd', value);
    }
    get onDragEnd() {
        return this._getOption('onDragEnd');
    }
    set onDragEnd(value) {
        this._setOption('onDragEnd', value);
    }
    get onDragMove() {
        return this._getOption('onDragMove');
    }
    set onDragMove(value) {
        this._setOption('onDragMove', value);
    }
    get onDragStart() {
        return this._getOption('onDragStart');
    }
    set onDragStart(value) {
        this._setOption('onDragStart', value);
    }
    get onRemove() {
        return this._getOption('onRemove');
    }
    set onRemove(value) {
        this._setOption('onRemove', value);
    }
    get scrollSensitivity() {
        return this._getOption('scrollSensitivity');
    }
    set scrollSensitivity(value) {
        this._setOption('scrollSensitivity', value);
    }
    get scrollSpeed() {
        return this._getOption('scrollSpeed');
    }
    set scrollSpeed(value) {
        this._setOption('scrollSpeed', value);
    }
    get _optionPath() {
        return 'appointmentDragging';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoSchedulerAppointmentDraggingComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoSchedulerAppointmentDraggingComponent, isStandalone: true, selector: "dxo-scheduler-appointment-dragging", inputs: { autoScroll: "autoScroll", data: "data", group: "group", onAdd: "onAdd", onDragEnd: "onDragEnd", onDragMove: "onDragMove", onDragStart: "onDragStart", onRemove: "onRemove", scrollSensitivity: "scrollSensitivity", scrollSpeed: "scrollSpeed" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoSchedulerAppointmentDraggingComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-scheduler-appointment-dragging', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { autoScroll: [{
                type: Input
            }], data: [{
                type: Input
            }], group: [{
                type: Input
            }], onAdd: [{
                type: Input
            }], onDragEnd: [{
                type: Input
            }], onDragMove: [{
                type: Input
            }], onDragStart: [{
                type: Input
            }], onRemove: [{
                type: Input
            }], scrollSensitivity: [{
                type: Input
            }], scrollSpeed: [{
                type: Input
            }] } });
class DxoSchedulerAppointmentDraggingModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoSchedulerAppointmentDraggingModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoSchedulerAppointmentDraggingModule, imports: [DxoSchedulerAppointmentDraggingComponent], exports: [DxoSchedulerAppointmentDraggingComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoSchedulerAppointmentDraggingModule, imports: [DxoSchedulerAppointmentDraggingComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoSchedulerAppointmentDraggingModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoSchedulerAppointmentDraggingComponent
                    ],
                    exports: [
                        DxoSchedulerAppointmentDraggingComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxiSchedulerAsyncRuleComponent extends CollectionNestedOption {
    get ignoreEmptyValue() {
        return this._getOption('ignoreEmptyValue');
    }
    set ignoreEmptyValue(value) {
        this._setOption('ignoreEmptyValue', value);
    }
    get message() {
        return this._getOption('message');
    }
    set message(value) {
        this._setOption('message', value);
    }
    get reevaluate() {
        return this._getOption('reevaluate');
    }
    set reevaluate(value) {
        this._setOption('reevaluate', value);
    }
    get type() {
        return this._getOption('type');
    }
    set type(value) {
        this._setOption('type', value);
    }
    get validationCallback() {
        return this._getOption('validationCallback');
    }
    set validationCallback(value) {
        this._setOption('validationCallback', value);
    }
    get _optionPath() {
        return 'validationRules';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
        this.type = 'async';
    }
    ngOnDestroy() {
        this._deleteRemovedOptions(this._fullOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiSchedulerAsyncRuleComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxiSchedulerAsyncRuleComponent, isStandalone: true, selector: "dxi-scheduler-async-rule", inputs: { ignoreEmptyValue: "ignoreEmptyValue", message: "message", reevaluate: "reevaluate", type: "type", validationCallback: "validationCallback" }, providers: [
            NestedOptionHost,
            {
                provide: PROPERTY_TOKEN_validationRules,
                useExisting: DxiSchedulerAsyncRuleComponent,
            }
        ], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiSchedulerAsyncRuleComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxi-scheduler-async-rule', template: '', imports: [DxIntegrationModule], providers: [
                        NestedOptionHost,
                        {
                            provide: PROPERTY_TOKEN_validationRules,
                            useExisting: DxiSchedulerAsyncRuleComponent,
                        }
                    ] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { ignoreEmptyValue: [{
                type: Input
            }], message: [{
                type: Input
            }], reevaluate: [{
                type: Input
            }], type: [{
                type: Input
            }], validationCallback: [{
                type: Input
            }] } });
class DxiSchedulerAsyncRuleModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiSchedulerAsyncRuleModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxiSchedulerAsyncRuleModule, imports: [DxiSchedulerAsyncRuleComponent], exports: [DxiSchedulerAsyncRuleComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiSchedulerAsyncRuleModule, imports: [DxiSchedulerAsyncRuleComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiSchedulerAsyncRuleModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxiSchedulerAsyncRuleComponent
                    ],
                    exports: [
                        DxiSchedulerAsyncRuleComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxiSchedulerButtonItemComponent extends CollectionNestedOption {
    get buttonOptions() {
        return this._getOption('buttonOptions');
    }
    set buttonOptions(value) {
        this._setOption('buttonOptions', value);
    }
    get colSpan() {
        return this._getOption('colSpan');
    }
    set colSpan(value) {
        this._setOption('colSpan', value);
    }
    get cssClass() {
        return this._getOption('cssClass');
    }
    set cssClass(value) {
        this._setOption('cssClass', value);
    }
    get horizontalAlignment() {
        return this._getOption('horizontalAlignment');
    }
    set horizontalAlignment(value) {
        this._setOption('horizontalAlignment', value);
    }
    get itemType() {
        return this._getOption('itemType');
    }
    set itemType(value) {
        this._setOption('itemType', value);
    }
    get name() {
        return this._getOption('name');
    }
    set name(value) {
        this._setOption('name', value);
    }
    get verticalAlignment() {
        return this._getOption('verticalAlignment');
    }
    set verticalAlignment(value) {
        this._setOption('verticalAlignment', value);
    }
    get visible() {
        return this._getOption('visible');
    }
    set visible(value) {
        this._setOption('visible', value);
    }
    get visibleIndex() {
        return this._getOption('visibleIndex');
    }
    set visibleIndex(value) {
        this._setOption('visibleIndex', value);
    }
    get _optionPath() {
        return 'items';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
        this.itemType = 'button';
    }
    ngOnDestroy() {
        this._deleteRemovedOptions(this._fullOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiSchedulerButtonItemComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxiSchedulerButtonItemComponent, isStandalone: true, selector: "dxi-scheduler-button-item", inputs: { buttonOptions: "buttonOptions", colSpan: "colSpan", cssClass: "cssClass", horizontalAlignment: "horizontalAlignment", itemType: "itemType", name: "name", verticalAlignment: "verticalAlignment", visible: "visible", visibleIndex: "visibleIndex" }, providers: [
            NestedOptionHost,
            {
                provide: PROPERTY_TOKEN_items,
                useExisting: DxiSchedulerButtonItemComponent,
            }
        ], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiSchedulerButtonItemComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxi-scheduler-button-item', template: '', imports: [DxIntegrationModule], providers: [
                        NestedOptionHost,
                        {
                            provide: PROPERTY_TOKEN_items,
                            useExisting: DxiSchedulerButtonItemComponent,
                        }
                    ] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { buttonOptions: [{
                type: Input
            }], colSpan: [{
                type: Input
            }], cssClass: [{
                type: Input
            }], horizontalAlignment: [{
                type: Input
            }], itemType: [{
                type: Input
            }], name: [{
                type: Input
            }], verticalAlignment: [{
                type: Input
            }], visible: [{
                type: Input
            }], visibleIndex: [{
                type: Input
            }] } });
class DxiSchedulerButtonItemModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiSchedulerButtonItemModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxiSchedulerButtonItemModule, imports: [DxiSchedulerButtonItemComponent], exports: [DxiSchedulerButtonItemComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiSchedulerButtonItemModule, imports: [DxiSchedulerButtonItemComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiSchedulerButtonItemModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxiSchedulerButtonItemComponent
                    ],
                    exports: [
                        DxiSchedulerButtonItemComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoSchedulerButtonOptionsComponent extends NestedOption {
    get accessKey() {
        return this._getOption('accessKey');
    }
    set accessKey(value) {
        this._setOption('accessKey', value);
    }
    get activeStateEnabled() {
        return this._getOption('activeStateEnabled');
    }
    set activeStateEnabled(value) {
        this._setOption('activeStateEnabled', value);
    }
    get disabled() {
        return this._getOption('disabled');
    }
    set disabled(value) {
        this._setOption('disabled', value);
    }
    get elementAttr() {
        return this._getOption('elementAttr');
    }
    set elementAttr(value) {
        this._setOption('elementAttr', value);
    }
    get focusStateEnabled() {
        return this._getOption('focusStateEnabled');
    }
    set focusStateEnabled(value) {
        this._setOption('focusStateEnabled', value);
    }
    get height() {
        return this._getOption('height');
    }
    set height(value) {
        this._setOption('height', value);
    }
    get hint() {
        return this._getOption('hint');
    }
    set hint(value) {
        this._setOption('hint', value);
    }
    get hoverStateEnabled() {
        return this._getOption('hoverStateEnabled');
    }
    set hoverStateEnabled(value) {
        this._setOption('hoverStateEnabled', value);
    }
    get icon() {
        return this._getOption('icon');
    }
    set icon(value) {
        this._setOption('icon', value);
    }
    get onClick() {
        return this._getOption('onClick');
    }
    set onClick(value) {
        this._setOption('onClick', value);
    }
    get onContentReady() {
        return this._getOption('onContentReady');
    }
    set onContentReady(value) {
        this._setOption('onContentReady', value);
    }
    get onDisposing() {
        return this._getOption('onDisposing');
    }
    set onDisposing(value) {
        this._setOption('onDisposing', value);
    }
    get onInitialized() {
        return this._getOption('onInitialized');
    }
    set onInitialized(value) {
        this._setOption('onInitialized', value);
    }
    get onOptionChanged() {
        return this._getOption('onOptionChanged');
    }
    set onOptionChanged(value) {
        this._setOption('onOptionChanged', value);
    }
    get rtlEnabled() {
        return this._getOption('rtlEnabled');
    }
    set rtlEnabled(value) {
        this._setOption('rtlEnabled', value);
    }
    get stylingMode() {
        return this._getOption('stylingMode');
    }
    set stylingMode(value) {
        this._setOption('stylingMode', value);
    }
    get tabIndex() {
        return this._getOption('tabIndex');
    }
    set tabIndex(value) {
        this._setOption('tabIndex', value);
    }
    get template() {
        return this._getOption('template');
    }
    set template(value) {
        this._setOption('template', value);
    }
    get text() {
        return this._getOption('text');
    }
    set text(value) {
        this._setOption('text', value);
    }
    get type() {
        return this._getOption('type');
    }
    set type(value) {
        this._setOption('type', value);
    }
    get useSubmitBehavior() {
        return this._getOption('useSubmitBehavior');
    }
    set useSubmitBehavior(value) {
        this._setOption('useSubmitBehavior', value);
    }
    get validationGroup() {
        return this._getOption('validationGroup');
    }
    set validationGroup(value) {
        this._setOption('validationGroup', value);
    }
    get visible() {
        return this._getOption('visible');
    }
    set visible(value) {
        this._setOption('visible', value);
    }
    get width() {
        return this._getOption('width');
    }
    set width(value) {
        this._setOption('width', value);
    }
    get _optionPath() {
        return 'buttonOptions';
    }
    constructor(parentOptionHost, optionHost, renderer, document, templateHost, element) {
        super();
        this.renderer = renderer;
        this.document = document;
        this.element = element;
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
        templateHost.setHost(this);
    }
    setTemplate(template) {
        this.template = template;
    }
    ngAfterViewInit() {
        extractTemplate(this, this.element, this.renderer, this.document);
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoSchedulerButtonOptionsComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }, { token: i0.Renderer2 }, { token: DOCUMENT }, { token: i1.DxTemplateHost, host: true }, { token: i0.ElementRef }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoSchedulerButtonOptionsComponent, isStandalone: true, selector: "dxo-scheduler-button-options", inputs: { accessKey: "accessKey", activeStateEnabled: "activeStateEnabled", disabled: "disabled", elementAttr: "elementAttr", focusStateEnabled: "focusStateEnabled", height: "height", hint: "hint", hoverStateEnabled: "hoverStateEnabled", icon: "icon", onClick: "onClick", onContentReady: "onContentReady", onDisposing: "onDisposing", onInitialized: "onInitialized", onOptionChanged: "onOptionChanged", rtlEnabled: "rtlEnabled", stylingMode: "stylingMode", tabIndex: "tabIndex", template: "template", text: "text", type: "type", useSubmitBehavior: "useSubmitBehavior", validationGroup: "validationGroup", visible: "visible", width: "width" }, providers: [NestedOptionHost, DxTemplateHost], usesInheritance: true, ngImport: i0, template: '<ng-content></ng-content>', isInline: true, styles: [":host{display:block}\n"], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoSchedulerButtonOptionsComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-scheduler-button-options', template: '<ng-content></ng-content>', imports: [DxIntegrationModule], providers: [NestedOptionHost, DxTemplateHost], styles: [":host{display:block}\n"] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }, { type: i0.Renderer2 }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [DOCUMENT]
                }] }, { type: i1.DxTemplateHost, decorators: [{
                    type: Host
                }] }, { type: i0.ElementRef }], propDecorators: { accessKey: [{
                type: Input
            }], activeStateEnabled: [{
                type: Input
            }], disabled: [{
                type: Input
            }], elementAttr: [{
                type: Input
            }], focusStateEnabled: [{
                type: Input
            }], height: [{
                type: Input
            }], hint: [{
                type: Input
            }], hoverStateEnabled: [{
                type: Input
            }], icon: [{
                type: Input
            }], onClick: [{
                type: Input
            }], onContentReady: [{
                type: Input
            }], onDisposing: [{
                type: Input
            }], onInitialized: [{
                type: Input
            }], onOptionChanged: [{
                type: Input
            }], rtlEnabled: [{
                type: Input
            }], stylingMode: [{
                type: Input
            }], tabIndex: [{
                type: Input
            }], template: [{
                type: Input
            }], text: [{
                type: Input
            }], type: [{
                type: Input
            }], useSubmitBehavior: [{
                type: Input
            }], validationGroup: [{
                type: Input
            }], visible: [{
                type: Input
            }], width: [{
                type: Input
            }] } });
class DxoSchedulerButtonOptionsModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoSchedulerButtonOptionsModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoSchedulerButtonOptionsModule, imports: [DxoSchedulerButtonOptionsComponent], exports: [DxoSchedulerButtonOptionsComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoSchedulerButtonOptionsModule, imports: [DxoSchedulerButtonOptionsComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoSchedulerButtonOptionsModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoSchedulerButtonOptionsComponent
                    ],
                    exports: [
                        DxoSchedulerButtonOptionsComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoSchedulerColCountByScreenComponent extends NestedOption {
    get lg() {
        return this._getOption('lg');
    }
    set lg(value) {
        this._setOption('lg', value);
    }
    get md() {
        return this._getOption('md');
    }
    set md(value) {
        this._setOption('md', value);
    }
    get sm() {
        return this._getOption('sm');
    }
    set sm(value) {
        this._setOption('sm', value);
    }
    get xs() {
        return this._getOption('xs');
    }
    set xs(value) {
        this._setOption('xs', value);
    }
    get _optionPath() {
        return 'colCountByScreen';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoSchedulerColCountByScreenComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoSchedulerColCountByScreenComponent, isStandalone: true, selector: "dxo-scheduler-col-count-by-screen", inputs: { lg: "lg", md: "md", sm: "sm", xs: "xs" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoSchedulerColCountByScreenComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-scheduler-col-count-by-screen', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { lg: [{
                type: Input
            }], md: [{
                type: Input
            }], sm: [{
                type: Input
            }], xs: [{
                type: Input
            }] } });
class DxoSchedulerColCountByScreenModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoSchedulerColCountByScreenModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoSchedulerColCountByScreenModule, imports: [DxoSchedulerColCountByScreenComponent], exports: [DxoSchedulerColCountByScreenComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoSchedulerColCountByScreenModule, imports: [DxoSchedulerColCountByScreenComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoSchedulerColCountByScreenModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoSchedulerColCountByScreenComponent
                    ],
                    exports: [
                        DxoSchedulerColCountByScreenComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxiSchedulerCompareRuleComponent extends CollectionNestedOption {
    get comparisonTarget() {
        return this._getOption('comparisonTarget');
    }
    set comparisonTarget(value) {
        this._setOption('comparisonTarget', value);
    }
    get comparisonType() {
        return this._getOption('comparisonType');
    }
    set comparisonType(value) {
        this._setOption('comparisonType', value);
    }
    get ignoreEmptyValue() {
        return this._getOption('ignoreEmptyValue');
    }
    set ignoreEmptyValue(value) {
        this._setOption('ignoreEmptyValue', value);
    }
    get message() {
        return this._getOption('message');
    }
    set message(value) {
        this._setOption('message', value);
    }
    get type() {
        return this._getOption('type');
    }
    set type(value) {
        this._setOption('type', value);
    }
    get _optionPath() {
        return 'validationRules';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
        this.type = 'compare';
    }
    ngOnDestroy() {
        this._deleteRemovedOptions(this._fullOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiSchedulerCompareRuleComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxiSchedulerCompareRuleComponent, isStandalone: true, selector: "dxi-scheduler-compare-rule", inputs: { comparisonTarget: "comparisonTarget", comparisonType: "comparisonType", ignoreEmptyValue: "ignoreEmptyValue", message: "message", type: "type" }, providers: [
            NestedOptionHost,
            {
                provide: PROPERTY_TOKEN_validationRules,
                useExisting: DxiSchedulerCompareRuleComponent,
            }
        ], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiSchedulerCompareRuleComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxi-scheduler-compare-rule', template: '', imports: [DxIntegrationModule], providers: [
                        NestedOptionHost,
                        {
                            provide: PROPERTY_TOKEN_validationRules,
                            useExisting: DxiSchedulerCompareRuleComponent,
                        }
                    ] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { comparisonTarget: [{
                type: Input
            }], comparisonType: [{
                type: Input
            }], ignoreEmptyValue: [{
                type: Input
            }], message: [{
                type: Input
            }], type: [{
                type: Input
            }] } });
class DxiSchedulerCompareRuleModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiSchedulerCompareRuleModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxiSchedulerCompareRuleModule, imports: [DxiSchedulerCompareRuleComponent], exports: [DxiSchedulerCompareRuleComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiSchedulerCompareRuleModule, imports: [DxiSchedulerCompareRuleComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiSchedulerCompareRuleModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxiSchedulerCompareRuleComponent
                    ],
                    exports: [
                        DxiSchedulerCompareRuleComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxiSchedulerCustomRuleComponent extends CollectionNestedOption {
    get ignoreEmptyValue() {
        return this._getOption('ignoreEmptyValue');
    }
    set ignoreEmptyValue(value) {
        this._setOption('ignoreEmptyValue', value);
    }
    get message() {
        return this._getOption('message');
    }
    set message(value) {
        this._setOption('message', value);
    }
    get reevaluate() {
        return this._getOption('reevaluate');
    }
    set reevaluate(value) {
        this._setOption('reevaluate', value);
    }
    get type() {
        return this._getOption('type');
    }
    set type(value) {
        this._setOption('type', value);
    }
    get validationCallback() {
        return this._getOption('validationCallback');
    }
    set validationCallback(value) {
        this._setOption('validationCallback', value);
    }
    get _optionPath() {
        return 'validationRules';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
        this.type = 'custom';
    }
    ngOnDestroy() {
        this._deleteRemovedOptions(this._fullOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiSchedulerCustomRuleComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxiSchedulerCustomRuleComponent, isStandalone: true, selector: "dxi-scheduler-custom-rule", inputs: { ignoreEmptyValue: "ignoreEmptyValue", message: "message", reevaluate: "reevaluate", type: "type", validationCallback: "validationCallback" }, providers: [
            NestedOptionHost,
            {
                provide: PROPERTY_TOKEN_validationRules,
                useExisting: DxiSchedulerCustomRuleComponent,
            }
        ], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiSchedulerCustomRuleComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxi-scheduler-custom-rule', template: '', imports: [DxIntegrationModule], providers: [
                        NestedOptionHost,
                        {
                            provide: PROPERTY_TOKEN_validationRules,
                            useExisting: DxiSchedulerCustomRuleComponent,
                        }
                    ] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { ignoreEmptyValue: [{
                type: Input
            }], message: [{
                type: Input
            }], reevaluate: [{
                type: Input
            }], type: [{
                type: Input
            }], validationCallback: [{
                type: Input
            }] } });
class DxiSchedulerCustomRuleModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiSchedulerCustomRuleModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxiSchedulerCustomRuleModule, imports: [DxiSchedulerCustomRuleComponent], exports: [DxiSchedulerCustomRuleComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiSchedulerCustomRuleModule, imports: [DxiSchedulerCustomRuleComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiSchedulerCustomRuleModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxiSchedulerCustomRuleComponent
                    ],
                    exports: [
                        DxiSchedulerCustomRuleComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoSchedulerEditingComponent extends NestedOption {
    get allowAdding() {
        return this._getOption('allowAdding');
    }
    set allowAdding(value) {
        this._setOption('allowAdding', value);
    }
    get allowDeleting() {
        return this._getOption('allowDeleting');
    }
    set allowDeleting(value) {
        this._setOption('allowDeleting', value);
    }
    get allowDragging() {
        return this._getOption('allowDragging');
    }
    set allowDragging(value) {
        this._setOption('allowDragging', value);
    }
    get allowResizing() {
        return this._getOption('allowResizing');
    }
    set allowResizing(value) {
        this._setOption('allowResizing', value);
    }
    get allowTimeZoneEditing() {
        return this._getOption('allowTimeZoneEditing');
    }
    set allowTimeZoneEditing(value) {
        this._setOption('allowTimeZoneEditing', value);
    }
    get allowUpdating() {
        return this._getOption('allowUpdating');
    }
    set allowUpdating(value) {
        this._setOption('allowUpdating', value);
    }
    get form() {
        return this._getOption('form');
    }
    set form(value) {
        this._setOption('form', value);
    }
    get popup() {
        return this._getOption('popup');
    }
    set popup(value) {
        this._setOption('popup', value);
    }
    get _optionPath() {
        return 'editing';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoSchedulerEditingComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoSchedulerEditingComponent, isStandalone: true, selector: "dxo-scheduler-editing", inputs: { allowAdding: "allowAdding", allowDeleting: "allowDeleting", allowDragging: "allowDragging", allowResizing: "allowResizing", allowTimeZoneEditing: "allowTimeZoneEditing", allowUpdating: "allowUpdating", form: "form", popup: "popup" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoSchedulerEditingComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-scheduler-editing', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { allowAdding: [{
                type: Input
            }], allowDeleting: [{
                type: Input
            }], allowDragging: [{
                type: Input
            }], allowResizing: [{
                type: Input
            }], allowTimeZoneEditing: [{
                type: Input
            }], allowUpdating: [{
                type: Input
            }], form: [{
                type: Input
            }], popup: [{
                type: Input
            }] } });
class DxoSchedulerEditingModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoSchedulerEditingModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoSchedulerEditingModule, imports: [DxoSchedulerEditingComponent], exports: [DxoSchedulerEditingComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoSchedulerEditingModule, imports: [DxoSchedulerEditingComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoSchedulerEditingModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoSchedulerEditingComponent
                    ],
                    exports: [
                        DxoSchedulerEditingComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxiSchedulerEmailRuleComponent extends CollectionNestedOption {
    get ignoreEmptyValue() {
        return this._getOption('ignoreEmptyValue');
    }
    set ignoreEmptyValue(value) {
        this._setOption('ignoreEmptyValue', value);
    }
    get message() {
        return this._getOption('message');
    }
    set message(value) {
        this._setOption('message', value);
    }
    get type() {
        return this._getOption('type');
    }
    set type(value) {
        this._setOption('type', value);
    }
    get _optionPath() {
        return 'validationRules';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
        this.type = 'email';
    }
    ngOnDestroy() {
        this._deleteRemovedOptions(this._fullOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiSchedulerEmailRuleComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxiSchedulerEmailRuleComponent, isStandalone: true, selector: "dxi-scheduler-email-rule", inputs: { ignoreEmptyValue: "ignoreEmptyValue", message: "message", type: "type" }, providers: [
            NestedOptionHost,
            {
                provide: PROPERTY_TOKEN_validationRules,
                useExisting: DxiSchedulerEmailRuleComponent,
            }
        ], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiSchedulerEmailRuleComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxi-scheduler-email-rule', template: '', imports: [DxIntegrationModule], providers: [
                        NestedOptionHost,
                        {
                            provide: PROPERTY_TOKEN_validationRules,
                            useExisting: DxiSchedulerEmailRuleComponent,
                        }
                    ] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { ignoreEmptyValue: [{
                type: Input
            }], message: [{
                type: Input
            }], type: [{
                type: Input
            }] } });
class DxiSchedulerEmailRuleModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiSchedulerEmailRuleModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxiSchedulerEmailRuleModule, imports: [DxiSchedulerEmailRuleComponent], exports: [DxiSchedulerEmailRuleComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiSchedulerEmailRuleModule, imports: [DxiSchedulerEmailRuleComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiSchedulerEmailRuleModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxiSchedulerEmailRuleComponent
                    ],
                    exports: [
                        DxiSchedulerEmailRuleComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxiSchedulerEmptyItemComponent extends CollectionNestedOption {
    get colSpan() {
        return this._getOption('colSpan');
    }
    set colSpan(value) {
        this._setOption('colSpan', value);
    }
    get cssClass() {
        return this._getOption('cssClass');
    }
    set cssClass(value) {
        this._setOption('cssClass', value);
    }
    get itemType() {
        return this._getOption('itemType');
    }
    set itemType(value) {
        this._setOption('itemType', value);
    }
    get name() {
        return this._getOption('name');
    }
    set name(value) {
        this._setOption('name', value);
    }
    get visible() {
        return this._getOption('visible');
    }
    set visible(value) {
        this._setOption('visible', value);
    }
    get visibleIndex() {
        return this._getOption('visibleIndex');
    }
    set visibleIndex(value) {
        this._setOption('visibleIndex', value);
    }
    get _optionPath() {
        return 'items';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
        this.itemType = 'empty';
    }
    ngOnDestroy() {
        this._deleteRemovedOptions(this._fullOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiSchedulerEmptyItemComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxiSchedulerEmptyItemComponent, isStandalone: true, selector: "dxi-scheduler-empty-item", inputs: { colSpan: "colSpan", cssClass: "cssClass", itemType: "itemType", name: "name", visible: "visible", visibleIndex: "visibleIndex" }, providers: [
            NestedOptionHost,
            {
                provide: PROPERTY_TOKEN_items,
                useExisting: DxiSchedulerEmptyItemComponent,
            }
        ], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiSchedulerEmptyItemComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxi-scheduler-empty-item', template: '', imports: [DxIntegrationModule], providers: [
                        NestedOptionHost,
                        {
                            provide: PROPERTY_TOKEN_items,
                            useExisting: DxiSchedulerEmptyItemComponent,
                        }
                    ] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { colSpan: [{
                type: Input
            }], cssClass: [{
                type: Input
            }], itemType: [{
                type: Input
            }], name: [{
                type: Input
            }], visible: [{
                type: Input
            }], visibleIndex: [{
                type: Input
            }] } });
class DxiSchedulerEmptyItemModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiSchedulerEmptyItemModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxiSchedulerEmptyItemModule, imports: [DxiSchedulerEmptyItemComponent], exports: [DxiSchedulerEmptyItemComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiSchedulerEmptyItemModule, imports: [DxiSchedulerEmptyItemComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiSchedulerEmptyItemModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxiSchedulerEmptyItemComponent
                    ],
                    exports: [
                        DxiSchedulerEmptyItemComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoSchedulerFormComponent extends NestedOption {
    set _itemsContentChildren(value) {
        this.setChildren('items', value);
    }
    get accessKey() {
        return this._getOption('accessKey');
    }
    set accessKey(value) {
        this._setOption('accessKey', value);
    }
    get activeStateEnabled() {
        return this._getOption('activeStateEnabled');
    }
    set activeStateEnabled(value) {
        this._setOption('activeStateEnabled', value);
    }
    get aiIntegration() {
        return this._getOption('aiIntegration');
    }
    set aiIntegration(value) {
        this._setOption('aiIntegration', value);
    }
    get alignItemLabels() {
        return this._getOption('alignItemLabels');
    }
    set alignItemLabels(value) {
        this._setOption('alignItemLabels', value);
    }
    get alignItemLabelsInAllGroups() {
        return this._getOption('alignItemLabelsInAllGroups');
    }
    set alignItemLabelsInAllGroups(value) {
        this._setOption('alignItemLabelsInAllGroups', value);
    }
    get colCount() {
        return this._getOption('colCount');
    }
    set colCount(value) {
        this._setOption('colCount', value);
    }
    get colCountByScreen() {
        return this._getOption('colCountByScreen');
    }
    set colCountByScreen(value) {
        this._setOption('colCountByScreen', value);
    }
    get customizeItem() {
        return this._getOption('customizeItem');
    }
    set customizeItem(value) {
        this._setOption('customizeItem', value);
    }
    get disabled() {
        return this._getOption('disabled');
    }
    set disabled(value) {
        this._setOption('disabled', value);
    }
    get elementAttr() {
        return this._getOption('elementAttr');
    }
    set elementAttr(value) {
        this._setOption('elementAttr', value);
    }
    get focusStateEnabled() {
        return this._getOption('focusStateEnabled');
    }
    set focusStateEnabled(value) {
        this._setOption('focusStateEnabled', value);
    }
    get formData() {
        return this._getOption('formData');
    }
    set formData(value) {
        this._setOption('formData', value);
    }
    get height() {
        return this._getOption('height');
    }
    set height(value) {
        this._setOption('height', value);
    }
    get hint() {
        return this._getOption('hint');
    }
    set hint(value) {
        this._setOption('hint', value);
    }
    get hoverStateEnabled() {
        return this._getOption('hoverStateEnabled');
    }
    set hoverStateEnabled(value) {
        this._setOption('hoverStateEnabled', value);
    }
    get iconsShowMode() {
        return this._getOption('iconsShowMode');
    }
    set iconsShowMode(value) {
        this._setOption('iconsShowMode', value);
    }
    get isDirty() {
        return this._getOption('isDirty');
    }
    set isDirty(value) {
        this._setOption('isDirty', value);
    }
    get items() {
        return this._getOption('items');
    }
    set items(value) {
        this._setOption('items', value);
    }
    get labelLocation() {
        return this._getOption('labelLocation');
    }
    set labelLocation(value) {
        this._setOption('labelLocation', value);
    }
    get labelMode() {
        return this._getOption('labelMode');
    }
    set labelMode(value) {
        this._setOption('labelMode', value);
    }
    get minColWidth() {
        return this._getOption('minColWidth');
    }
    set minColWidth(value) {
        this._setOption('minColWidth', value);
    }
    get onContentReady() {
        return this._getOption('onContentReady');
    }
    set onContentReady(value) {
        this._setOption('onContentReady', value);
    }
    get onDisposing() {
        return this._getOption('onDisposing');
    }
    set onDisposing(value) {
        this._setOption('onDisposing', value);
    }
    get onEditorEnterKey() {
        return this._getOption('onEditorEnterKey');
    }
    set onEditorEnterKey(value) {
        this._setOption('onEditorEnterKey', value);
    }
    get onFieldDataChanged() {
        return this._getOption('onFieldDataChanged');
    }
    set onFieldDataChanged(value) {
        this._setOption('onFieldDataChanged', value);
    }
    get onInitialized() {
        return this._getOption('onInitialized');
    }
    set onInitialized(value) {
        this._setOption('onInitialized', value);
    }
    get onOptionChanged() {
        return this._getOption('onOptionChanged');
    }
    set onOptionChanged(value) {
        this._setOption('onOptionChanged', value);
    }
    get onSmartPasted() {
        return this._getOption('onSmartPasted');
    }
    set onSmartPasted(value) {
        this._setOption('onSmartPasted', value);
    }
    get onSmartPasting() {
        return this._getOption('onSmartPasting');
    }
    set onSmartPasting(value) {
        this._setOption('onSmartPasting', value);
    }
    get optionalMark() {
        return this._getOption('optionalMark');
    }
    set optionalMark(value) {
        this._setOption('optionalMark', value);
    }
    get readOnly() {
        return this._getOption('readOnly');
    }
    set readOnly(value) {
        this._setOption('readOnly', value);
    }
    get requiredMark() {
        return this._getOption('requiredMark');
    }
    set requiredMark(value) {
        this._setOption('requiredMark', value);
    }
    get requiredMessage() {
        return this._getOption('requiredMessage');
    }
    set requiredMessage(value) {
        this._setOption('requiredMessage', value);
    }
    get rtlEnabled() {
        return this._getOption('rtlEnabled');
    }
    set rtlEnabled(value) {
        this._setOption('rtlEnabled', value);
    }
    get screenByWidth() {
        return this._getOption('screenByWidth');
    }
    set screenByWidth(value) {
        this._setOption('screenByWidth', value);
    }
    get scrollingEnabled() {
        return this._getOption('scrollingEnabled');
    }
    set scrollingEnabled(value) {
        this._setOption('scrollingEnabled', value);
    }
    get showColonAfterLabel() {
        return this._getOption('showColonAfterLabel');
    }
    set showColonAfterLabel(value) {
        this._setOption('showColonAfterLabel', value);
    }
    get showOptionalMark() {
        return this._getOption('showOptionalMark');
    }
    set showOptionalMark(value) {
        this._setOption('showOptionalMark', value);
    }
    get showRequiredMark() {
        return this._getOption('showRequiredMark');
    }
    set showRequiredMark(value) {
        this._setOption('showRequiredMark', value);
    }
    get showValidationSummary() {
        return this._getOption('showValidationSummary');
    }
    set showValidationSummary(value) {
        this._setOption('showValidationSummary', value);
    }
    get tabIndex() {
        return this._getOption('tabIndex');
    }
    set tabIndex(value) {
        this._setOption('tabIndex', value);
    }
    get validationGroup() {
        return this._getOption('validationGroup');
    }
    set validationGroup(value) {
        this._setOption('validationGroup', value);
    }
    get visible() {
        return this._getOption('visible');
    }
    set visible(value) {
        this._setOption('visible', value);
    }
    get width() {
        return this._getOption('width');
    }
    set width(value) {
        this._setOption('width', value);
    }
    get _optionPath() {
        return 'form';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        this._createEventEmitters([
            { emit: 'formDataChange' }
        ]);
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoSchedulerFormComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoSchedulerFormComponent, isStandalone: true, selector: "dxo-scheduler-form", inputs: { accessKey: "accessKey", activeStateEnabled: "activeStateEnabled", aiIntegration: "aiIntegration", alignItemLabels: "alignItemLabels", alignItemLabelsInAllGroups: "alignItemLabelsInAllGroups", colCount: "colCount", colCountByScreen: "colCountByScreen", customizeItem: "customizeItem", disabled: "disabled", elementAttr: "elementAttr", focusStateEnabled: "focusStateEnabled", formData: "formData", height: "height", hint: "hint", hoverStateEnabled: "hoverStateEnabled", iconsShowMode: "iconsShowMode", isDirty: "isDirty", items: "items", labelLocation: "labelLocation", labelMode: "labelMode", minColWidth: "minColWidth", onContentReady: "onContentReady", onDisposing: "onDisposing", onEditorEnterKey: "onEditorEnterKey", onFieldDataChanged: "onFieldDataChanged", onInitialized: "onInitialized", onOptionChanged: "onOptionChanged", onSmartPasted: "onSmartPasted", onSmartPasting: "onSmartPasting", optionalMark: "optionalMark", readOnly: "readOnly", requiredMark: "requiredMark", requiredMessage: "requiredMessage", rtlEnabled: "rtlEnabled", screenByWidth: "screenByWidth", scrollingEnabled: "scrollingEnabled", showColonAfterLabel: "showColonAfterLabel", showOptionalMark: "showOptionalMark", showRequiredMark: "showRequiredMark", showValidationSummary: "showValidationSummary", tabIndex: "tabIndex", validationGroup: "validationGroup", visible: "visible", width: "width" }, outputs: { formDataChange: "formDataChange" }, providers: [NestedOptionHost], queries: [{ propertyName: "_itemsContentChildren", predicate: PROPERTY_TOKEN_items }], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoSchedulerFormComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-scheduler-form', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { _itemsContentChildren: [{
                type: ContentChildren,
                args: [PROPERTY_TOKEN_items]
            }], accessKey: [{
                type: Input
            }], activeStateEnabled: [{
                type: Input
            }], aiIntegration: [{
                type: Input
            }], alignItemLabels: [{
                type: Input
            }], alignItemLabelsInAllGroups: [{
                type: Input
            }], colCount: [{
                type: Input
            }], colCountByScreen: [{
                type: Input
            }], customizeItem: [{
                type: Input
            }], disabled: [{
                type: Input
            }], elementAttr: [{
                type: Input
            }], focusStateEnabled: [{
                type: Input
            }], formData: [{
                type: Input
            }], height: [{
                type: Input
            }], hint: [{
                type: Input
            }], hoverStateEnabled: [{
                type: Input
            }], iconsShowMode: [{
                type: Input
            }], isDirty: [{
                type: Input
            }], items: [{
                type: Input
            }], labelLocation: [{
                type: Input
            }], labelMode: [{
                type: Input
            }], minColWidth: [{
                type: Input
            }], onContentReady: [{
                type: Input
            }], onDisposing: [{
                type: Input
            }], onEditorEnterKey: [{
                type: Input
            }], onFieldDataChanged: [{
                type: Input
            }], onInitialized: [{
                type: Input
            }], onOptionChanged: [{
                type: Input
            }], onSmartPasted: [{
                type: Input
            }], onSmartPasting: [{
                type: Input
            }], optionalMark: [{
                type: Input
            }], readOnly: [{
                type: Input
            }], requiredMark: [{
                type: Input
            }], requiredMessage: [{
                type: Input
            }], rtlEnabled: [{
                type: Input
            }], screenByWidth: [{
                type: Input
            }], scrollingEnabled: [{
                type: Input
            }], showColonAfterLabel: [{
                type: Input
            }], showOptionalMark: [{
                type: Input
            }], showRequiredMark: [{
                type: Input
            }], showValidationSummary: [{
                type: Input
            }], tabIndex: [{
                type: Input
            }], validationGroup: [{
                type: Input
            }], visible: [{
                type: Input
            }], width: [{
                type: Input
            }], formDataChange: [{
                type: Output
            }] } });
class DxoSchedulerFormModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoSchedulerFormModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoSchedulerFormModule, imports: [DxoSchedulerFormComponent], exports: [DxoSchedulerFormComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoSchedulerFormModule, imports: [DxoSchedulerFormComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoSchedulerFormModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoSchedulerFormComponent
                    ],
                    exports: [
                        DxoSchedulerFormComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxiSchedulerGroupItemComponent extends CollectionNestedOption {
    set _itemsContentChildren(value) {
        this.setChildren('items', value);
    }
    get alignItemLabels() {
        return this._getOption('alignItemLabels');
    }
    set alignItemLabels(value) {
        this._setOption('alignItemLabels', value);
    }
    get caption() {
        return this._getOption('caption');
    }
    set caption(value) {
        this._setOption('caption', value);
    }
    get captionTemplate() {
        return this._getOption('captionTemplate');
    }
    set captionTemplate(value) {
        this._setOption('captionTemplate', value);
    }
    get colCount() {
        return this._getOption('colCount');
    }
    set colCount(value) {
        this._setOption('colCount', value);
    }
    get colCountByScreen() {
        return this._getOption('colCountByScreen');
    }
    set colCountByScreen(value) {
        this._setOption('colCountByScreen', value);
    }
    get colSpan() {
        return this._getOption('colSpan');
    }
    set colSpan(value) {
        this._setOption('colSpan', value);
    }
    get cssClass() {
        return this._getOption('cssClass');
    }
    set cssClass(value) {
        this._setOption('cssClass', value);
    }
    get items() {
        return this._getOption('items');
    }
    set items(value) {
        this._setOption('items', value);
    }
    get itemType() {
        return this._getOption('itemType');
    }
    set itemType(value) {
        this._setOption('itemType', value);
    }
    get name() {
        return this._getOption('name');
    }
    set name(value) {
        this._setOption('name', value);
    }
    get template() {
        return this._getOption('template');
    }
    set template(value) {
        this._setOption('template', value);
    }
    get visible() {
        return this._getOption('visible');
    }
    set visible(value) {
        this._setOption('visible', value);
    }
    get visibleIndex() {
        return this._getOption('visibleIndex');
    }
    set visibleIndex(value) {
        this._setOption('visibleIndex', value);
    }
    get _optionPath() {
        return 'items';
    }
    constructor(parentOptionHost, optionHost, renderer, document, templateHost, element) {
        super();
        this.renderer = renderer;
        this.document = document;
        this.element = element;
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
        templateHost.setHost(this);
        this.itemType = 'group';
    }
    setTemplate(template) {
        this.template = template;
    }
    ngAfterViewInit() {
        extractTemplate(this, this.element, this.renderer, this.document);
    }
    ngOnDestroy() {
        this._deleteRemovedOptions(this._fullOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiSchedulerGroupItemComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }, { token: i0.Renderer2 }, { token: DOCUMENT }, { token: i1.DxTemplateHost, host: true }, { token: i0.ElementRef }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxiSchedulerGroupItemComponent, isStandalone: true, selector: "dxi-scheduler-group-item", inputs: { alignItemLabels: "alignItemLabels", caption: "caption", captionTemplate: "captionTemplate", colCount: "colCount", colCountByScreen: "colCountByScreen", colSpan: "colSpan", cssClass: "cssClass", items: "items", itemType: "itemType", name: "name", template: "template", visible: "visible", visibleIndex: "visibleIndex" }, providers: [
            NestedOptionHost,
            DxTemplateHost,
            {
                provide: PROPERTY_TOKEN_items,
                useExisting: DxiSchedulerGroupItemComponent,
            }
        ], queries: [{ propertyName: "_itemsContentChildren", predicate: PROPERTY_TOKEN_items }], usesInheritance: true, ngImport: i0, template: '<ng-content></ng-content>', isInline: true, styles: [":host{display:block}\n"], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiSchedulerGroupItemComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxi-scheduler-group-item', template: '<ng-content></ng-content>', imports: [DxIntegrationModule], providers: [
                        NestedOptionHost,
                        DxTemplateHost,
                        {
                            provide: PROPERTY_TOKEN_items,
                            useExisting: DxiSchedulerGroupItemComponent,
                        }
                    ], styles: [":host{display:block}\n"] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }, { type: i0.Renderer2 }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [DOCUMENT]
                }] }, { type: i1.DxTemplateHost, decorators: [{
                    type: Host
                }] }, { type: i0.ElementRef }], propDecorators: { _itemsContentChildren: [{
                type: ContentChildren,
                args: [PROPERTY_TOKEN_items]
            }], alignItemLabels: [{
                type: Input
            }], caption: [{
                type: Input
            }], captionTemplate: [{
                type: Input
            }], colCount: [{
                type: Input
            }], colCountByScreen: [{
                type: Input
            }], colSpan: [{
                type: Input
            }], cssClass: [{
                type: Input
            }], items: [{
                type: Input
            }], itemType: [{
                type: Input
            }], name: [{
                type: Input
            }], template: [{
                type: Input
            }], visible: [{
                type: Input
            }], visibleIndex: [{
                type: Input
            }] } });
class DxiSchedulerGroupItemModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiSchedulerGroupItemModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxiSchedulerGroupItemModule, imports: [DxiSchedulerGroupItemComponent], exports: [DxiSchedulerGroupItemComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiSchedulerGroupItemModule, imports: [DxiSchedulerGroupItemComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiSchedulerGroupItemModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxiSchedulerGroupItemComponent
                    ],
                    exports: [
                        DxiSchedulerGroupItemComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxiSchedulerItemComponent extends CollectionNestedOption {
    set _validationRulesContentChildren(value) {
        this.setChildren('validationRules', value);
    }
    set _tabsContentChildren(value) {
        this.setChildren('tabs', value);
    }
    set _itemsContentChildren(value) {
        this.setChildren('items', value);
    }
    get badge() {
        return this._getOption('badge');
    }
    set badge(value) {
        this._setOption('badge', value);
    }
    get disabled() {
        return this._getOption('disabled');
    }
    set disabled(value) {
        this._setOption('disabled', value);
    }
    get html() {
        return this._getOption('html');
    }
    set html(value) {
        this._setOption('html', value);
    }
    get icon() {
        return this._getOption('icon');
    }
    set icon(value) {
        this._setOption('icon', value);
    }
    get tabTemplate() {
        return this._getOption('tabTemplate');
    }
    set tabTemplate(value) {
        this._setOption('tabTemplate', value);
    }
    get template() {
        return this._getOption('template');
    }
    set template(value) {
        this._setOption('template', value);
    }
    get text() {
        return this._getOption('text');
    }
    set text(value) {
        this._setOption('text', value);
    }
    get title() {
        return this._getOption('title');
    }
    set title(value) {
        this._setOption('title', value);
    }
    get visible() {
        return this._getOption('visible');
    }
    set visible(value) {
        this._setOption('visible', value);
    }
    get aiOptions() {
        return this._getOption('aiOptions');
    }
    set aiOptions(value) {
        this._setOption('aiOptions', value);
    }
    get colSpan() {
        return this._getOption('colSpan');
    }
    set colSpan(value) {
        this._setOption('colSpan', value);
    }
    get cssClass() {
        return this._getOption('cssClass');
    }
    set cssClass(value) {
        this._setOption('cssClass', value);
    }
    get dataField() {
        return this._getOption('dataField');
    }
    set dataField(value) {
        this._setOption('dataField', value);
    }
    get editorOptions() {
        return this._getOption('editorOptions');
    }
    set editorOptions(value) {
        this._setOption('editorOptions', value);
    }
    get editorType() {
        return this._getOption('editorType');
    }
    set editorType(value) {
        this._setOption('editorType', value);
    }
    get helpText() {
        return this._getOption('helpText');
    }
    set helpText(value) {
        this._setOption('helpText', value);
    }
    get isRequired() {
        return this._getOption('isRequired');
    }
    set isRequired(value) {
        this._setOption('isRequired', value);
    }
    get itemType() {
        return this._getOption('itemType');
    }
    set itemType(value) {
        this._setOption('itemType', value);
    }
    get label() {
        return this._getOption('label');
    }
    set label(value) {
        this._setOption('label', value);
    }
    get name() {
        return this._getOption('name');
    }
    set name(value) {
        this._setOption('name', value);
    }
    get validationRules() {
        return this._getOption('validationRules');
    }
    set validationRules(value) {
        this._setOption('validationRules', value);
    }
    get visibleIndex() {
        return this._getOption('visibleIndex');
    }
    set visibleIndex(value) {
        this._setOption('visibleIndex', value);
    }
    get alignItemLabels() {
        return this._getOption('alignItemLabels');
    }
    set alignItemLabels(value) {
        this._setOption('alignItemLabels', value);
    }
    get caption() {
        return this._getOption('caption');
    }
    set caption(value) {
        this._setOption('caption', value);
    }
    get captionTemplate() {
        return this._getOption('captionTemplate');
    }
    set captionTemplate(value) {
        this._setOption('captionTemplate', value);
    }
    get colCount() {
        return this._getOption('colCount');
    }
    set colCount(value) {
        this._setOption('colCount', value);
    }
    get colCountByScreen() {
        return this._getOption('colCountByScreen');
    }
    set colCountByScreen(value) {
        this._setOption('colCountByScreen', value);
    }
    get items() {
        return this._getOption('items');
    }
    set items(value) {
        this._setOption('items', value);
    }
    get tabPanelOptions() {
        return this._getOption('tabPanelOptions');
    }
    set tabPanelOptions(value) {
        this._setOption('tabPanelOptions', value);
    }
    get tabs() {
        return this._getOption('tabs');
    }
    set tabs(value) {
        this._setOption('tabs', value);
    }
    get buttonOptions() {
        return this._getOption('buttonOptions');
    }
    set buttonOptions(value) {
        this._setOption('buttonOptions', value);
    }
    get horizontalAlignment() {
        return this._getOption('horizontalAlignment');
    }
    set horizontalAlignment(value) {
        this._setOption('horizontalAlignment', value);
    }
    get verticalAlignment() {
        return this._getOption('verticalAlignment');
    }
    set verticalAlignment(value) {
        this._setOption('verticalAlignment', value);
    }
    get locateInMenu() {
        return this._getOption('locateInMenu');
    }
    set locateInMenu(value) {
        this._setOption('locateInMenu', value);
    }
    get location() {
        return this._getOption('location');
    }
    set location(value) {
        this._setOption('location', value);
    }
    get menuItemTemplate() {
        return this._getOption('menuItemTemplate');
    }
    set menuItemTemplate(value) {
        this._setOption('menuItemTemplate', value);
    }
    get options() {
        return this._getOption('options');
    }
    set options(value) {
        this._setOption('options', value);
    }
    get showText() {
        return this._getOption('showText');
    }
    set showText(value) {
        this._setOption('showText', value);
    }
    get widget() {
        return this._getOption('widget');
    }
    set widget(value) {
        this._setOption('widget', value);
    }
    get elementAttr() {
        return this._getOption('elementAttr');
    }
    set elementAttr(value) {
        this._setOption('elementAttr', value);
    }
    get hint() {
        return this._getOption('hint');
    }
    set hint(value) {
        this._setOption('hint', value);
    }
    get type() {
        return this._getOption('type');
    }
    set type(value) {
        this._setOption('type', value);
    }
    get _optionPath() {
        return 'items';
    }
    constructor(parentOptionHost, optionHost, renderer, document, templateHost, element) {
        super();
        this.renderer = renderer;
        this.document = document;
        this.element = element;
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
        templateHost.setHost(this);
    }
    setTemplate(template) {
        this.template = template;
    }
    ngAfterViewInit() {
        extractTemplate(this, this.element, this.renderer, this.document);
    }
    ngOnDestroy() {
        this._deleteRemovedOptions(this._fullOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiSchedulerItemComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }, { token: i0.Renderer2 }, { token: DOCUMENT }, { token: i1.DxTemplateHost, host: true }, { token: i0.ElementRef }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxiSchedulerItemComponent, isStandalone: true, selector: "dxi-scheduler-item", inputs: { badge: "badge", disabled: "disabled", html: "html", icon: "icon", tabTemplate: "tabTemplate", template: "template", text: "text", title: "title", visible: "visible", aiOptions: "aiOptions", colSpan: "colSpan", cssClass: "cssClass", dataField: "dataField", editorOptions: "editorOptions", editorType: "editorType", helpText: "helpText", isRequired: "isRequired", itemType: "itemType", label: "label", name: "name", validationRules: "validationRules", visibleIndex: "visibleIndex", alignItemLabels: "alignItemLabels", caption: "caption", captionTemplate: "captionTemplate", colCount: "colCount", colCountByScreen: "colCountByScreen", items: "items", tabPanelOptions: "tabPanelOptions", tabs: "tabs", buttonOptions: "buttonOptions", horizontalAlignment: "horizontalAlignment", verticalAlignment: "verticalAlignment", locateInMenu: "locateInMenu", location: "location", menuItemTemplate: "menuItemTemplate", options: "options", showText: "showText", widget: "widget", elementAttr: "elementAttr", hint: "hint", type: "type" }, providers: [
            NestedOptionHost,
            DxTemplateHost,
            {
                provide: PROPERTY_TOKEN_items,
                useExisting: DxiSchedulerItemComponent,
            }
        ], queries: [{ propertyName: "_validationRulesContentChildren", predicate: PROPERTY_TOKEN_validationRules }, { propertyName: "_tabsContentChildren", predicate: PROPERTY_TOKEN_tabs }, { propertyName: "_itemsContentChildren", predicate: PROPERTY_TOKEN_items }], usesInheritance: true, ngImport: i0, template: '<ng-content></ng-content>', isInline: true, styles: [":host{display:block}\n"], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiSchedulerItemComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxi-scheduler-item', template: '<ng-content></ng-content>', imports: [DxIntegrationModule], providers: [
                        NestedOptionHost,
                        DxTemplateHost,
                        {
                            provide: PROPERTY_TOKEN_items,
                            useExisting: DxiSchedulerItemComponent,
                        }
                    ], styles: [":host{display:block}\n"] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }, { type: i0.Renderer2 }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [DOCUMENT]
                }] }, { type: i1.DxTemplateHost, decorators: [{
                    type: Host
                }] }, { type: i0.ElementRef }], propDecorators: { _validationRulesContentChildren: [{
                type: ContentChildren,
                args: [PROPERTY_TOKEN_validationRules]
            }], _tabsContentChildren: [{
                type: ContentChildren,
                args: [PROPERTY_TOKEN_tabs]
            }], _itemsContentChildren: [{
                type: ContentChildren,
                args: [PROPERTY_TOKEN_items]
            }], badge: [{
                type: Input
            }], disabled: [{
                type: Input
            }], html: [{
                type: Input
            }], icon: [{
                type: Input
            }], tabTemplate: [{
                type: Input
            }], template: [{
                type: Input
            }], text: [{
                type: Input
            }], title: [{
                type: Input
            }], visible: [{
                type: Input
            }], aiOptions: [{
                type: Input
            }], colSpan: [{
                type: Input
            }], cssClass: [{
                type: Input
            }], dataField: [{
                type: Input
            }], editorOptions: [{
                type: Input
            }], editorType: [{
                type: Input
            }], helpText: [{
                type: Input
            }], isRequired: [{
                type: Input
            }], itemType: [{
                type: Input
            }], label: [{
                type: Input
            }], name: [{
                type: Input
            }], validationRules: [{
                type: Input
            }], visibleIndex: [{
                type: Input
            }], alignItemLabels: [{
                type: Input
            }], caption: [{
                type: Input
            }], captionTemplate: [{
                type: Input
            }], colCount: [{
                type: Input
            }], colCountByScreen: [{
                type: Input
            }], items: [{
                type: Input
            }], tabPanelOptions: [{
                type: Input
            }], tabs: [{
                type: Input
            }], buttonOptions: [{
                type: Input
            }], horizontalAlignment: [{
                type: Input
            }], verticalAlignment: [{
                type: Input
            }], locateInMenu: [{
                type: Input
            }], location: [{
                type: Input
            }], menuItemTemplate: [{
                type: Input
            }], options: [{
                type: Input
            }], showText: [{
                type: Input
            }], widget: [{
                type: Input
            }], elementAttr: [{
                type: Input
            }], hint: [{
                type: Input
            }], type: [{
                type: Input
            }] } });
class DxiSchedulerItemModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiSchedulerItemModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxiSchedulerItemModule, imports: [DxiSchedulerItemComponent], exports: [DxiSchedulerItemComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiSchedulerItemModule, imports: [DxiSchedulerItemComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiSchedulerItemModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxiSchedulerItemComponent
                    ],
                    exports: [
                        DxiSchedulerItemComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoSchedulerLabelComponent extends NestedOption {
    get alignment() {
        return this._getOption('alignment');
    }
    set alignment(value) {
        this._setOption('alignment', value);
    }
    get location() {
        return this._getOption('location');
    }
    set location(value) {
        this._setOption('location', value);
    }
    get showColon() {
        return this._getOption('showColon');
    }
    set showColon(value) {
        this._setOption('showColon', value);
    }
    get template() {
        return this._getOption('template');
    }
    set template(value) {
        this._setOption('template', value);
    }
    get text() {
        return this._getOption('text');
    }
    set text(value) {
        this._setOption('text', value);
    }
    get visible() {
        return this._getOption('visible');
    }
    set visible(value) {
        this._setOption('visible', value);
    }
    get _optionPath() {
        return 'label';
    }
    constructor(parentOptionHost, optionHost, renderer, document, templateHost, element) {
        super();
        this.renderer = renderer;
        this.document = document;
        this.element = element;
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
        templateHost.setHost(this);
    }
    setTemplate(template) {
        this.template = template;
    }
    ngAfterViewInit() {
        extractTemplate(this, this.element, this.renderer, this.document);
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoSchedulerLabelComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }, { token: i0.Renderer2 }, { token: DOCUMENT }, { token: i1.DxTemplateHost, host: true }, { token: i0.ElementRef }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoSchedulerLabelComponent, isStandalone: true, selector: "dxo-scheduler-label", inputs: { alignment: "alignment", location: "location", showColon: "showColon", template: "template", text: "text", visible: "visible" }, providers: [NestedOptionHost, DxTemplateHost], usesInheritance: true, ngImport: i0, template: '<ng-content></ng-content>', isInline: true, styles: [":host{display:block}\n"], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoSchedulerLabelComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-scheduler-label', template: '<ng-content></ng-content>', imports: [DxIntegrationModule], providers: [NestedOptionHost, DxTemplateHost], styles: [":host{display:block}\n"] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }, { type: i0.Renderer2 }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [DOCUMENT]
                }] }, { type: i1.DxTemplateHost, decorators: [{
                    type: Host
                }] }, { type: i0.ElementRef }], propDecorators: { alignment: [{
                type: Input
            }], location: [{
                type: Input
            }], showColon: [{
                type: Input
            }], template: [{
                type: Input
            }], text: [{
                type: Input
            }], visible: [{
                type: Input
            }] } });
class DxoSchedulerLabelModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoSchedulerLabelModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoSchedulerLabelModule, imports: [DxoSchedulerLabelComponent], exports: [DxoSchedulerLabelComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoSchedulerLabelModule, imports: [DxoSchedulerLabelComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoSchedulerLabelModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoSchedulerLabelComponent
                    ],
                    exports: [
                        DxoSchedulerLabelComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxiSchedulerNumericRuleComponent extends CollectionNestedOption {
    get ignoreEmptyValue() {
        return this._getOption('ignoreEmptyValue');
    }
    set ignoreEmptyValue(value) {
        this._setOption('ignoreEmptyValue', value);
    }
    get message() {
        return this._getOption('message');
    }
    set message(value) {
        this._setOption('message', value);
    }
    get type() {
        return this._getOption('type');
    }
    set type(value) {
        this._setOption('type', value);
    }
    get _optionPath() {
        return 'validationRules';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
        this.type = 'numeric';
    }
    ngOnDestroy() {
        this._deleteRemovedOptions(this._fullOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiSchedulerNumericRuleComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxiSchedulerNumericRuleComponent, isStandalone: true, selector: "dxi-scheduler-numeric-rule", inputs: { ignoreEmptyValue: "ignoreEmptyValue", message: "message", type: "type" }, providers: [
            NestedOptionHost,
            {
                provide: PROPERTY_TOKEN_validationRules,
                useExisting: DxiSchedulerNumericRuleComponent,
            }
        ], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiSchedulerNumericRuleComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxi-scheduler-numeric-rule', template: '', imports: [DxIntegrationModule], providers: [
                        NestedOptionHost,
                        {
                            provide: PROPERTY_TOKEN_validationRules,
                            useExisting: DxiSchedulerNumericRuleComponent,
                        }
                    ] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { ignoreEmptyValue: [{
                type: Input
            }], message: [{
                type: Input
            }], type: [{
                type: Input
            }] } });
class DxiSchedulerNumericRuleModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiSchedulerNumericRuleModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxiSchedulerNumericRuleModule, imports: [DxiSchedulerNumericRuleComponent], exports: [DxiSchedulerNumericRuleComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiSchedulerNumericRuleModule, imports: [DxiSchedulerNumericRuleComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiSchedulerNumericRuleModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxiSchedulerNumericRuleComponent
                    ],
                    exports: [
                        DxiSchedulerNumericRuleComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxiSchedulerOptionsItemComponent extends CollectionNestedOption {
    get disabled() {
        return this._getOption('disabled');
    }
    set disabled(value) {
        this._setOption('disabled', value);
    }
    get elementAttr() {
        return this._getOption('elementAttr');
    }
    set elementAttr(value) {
        this._setOption('elementAttr', value);
    }
    get hint() {
        return this._getOption('hint');
    }
    set hint(value) {
        this._setOption('hint', value);
    }
    get icon() {
        return this._getOption('icon');
    }
    set icon(value) {
        this._setOption('icon', value);
    }
    get template() {
        return this._getOption('template');
    }
    set template(value) {
        this._setOption('template', value);
    }
    get text() {
        return this._getOption('text');
    }
    set text(value) {
        this._setOption('text', value);
    }
    get type() {
        return this._getOption('type');
    }
    set type(value) {
        this._setOption('type', value);
    }
    get visible() {
        return this._getOption('visible');
    }
    set visible(value) {
        this._setOption('visible', value);
    }
    get _optionPath() {
        return 'items';
    }
    constructor(parentOptionHost, optionHost, renderer, document, templateHost, element) {
        super();
        this.renderer = renderer;
        this.document = document;
        this.element = element;
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
        templateHost.setHost(this);
    }
    setTemplate(template) {
        this.template = template;
    }
    ngAfterViewInit() {
        extractTemplate(this, this.element, this.renderer, this.document);
    }
    ngOnDestroy() {
        this._deleteRemovedOptions(this._fullOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiSchedulerOptionsItemComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }, { token: i0.Renderer2 }, { token: DOCUMENT }, { token: i1.DxTemplateHost, host: true }, { token: i0.ElementRef }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxiSchedulerOptionsItemComponent, isStandalone: true, selector: "dxi-scheduler-options-item", inputs: { disabled: "disabled", elementAttr: "elementAttr", hint: "hint", icon: "icon", template: "template", text: "text", type: "type", visible: "visible" }, providers: [
            NestedOptionHost,
            DxTemplateHost,
            {
                provide: PROPERTY_TOKEN_items,
                useExisting: DxiSchedulerOptionsItemComponent,
            }
        ], usesInheritance: true, ngImport: i0, template: '<ng-content></ng-content>', isInline: true, styles: [":host{display:block}\n"], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiSchedulerOptionsItemComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxi-scheduler-options-item', template: '<ng-content></ng-content>', imports: [DxIntegrationModule], providers: [
                        NestedOptionHost,
                        DxTemplateHost,
                        {
                            provide: PROPERTY_TOKEN_items,
                            useExisting: DxiSchedulerOptionsItemComponent,
                        }
                    ], styles: [":host{display:block}\n"] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }, { type: i0.Renderer2 }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [DOCUMENT]
                }] }, { type: i1.DxTemplateHost, decorators: [{
                    type: Host
                }] }, { type: i0.ElementRef }], propDecorators: { disabled: [{
                type: Input
            }], elementAttr: [{
                type: Input
            }], hint: [{
                type: Input
            }], icon: [{
                type: Input
            }], template: [{
                type: Input
            }], text: [{
                type: Input
            }], type: [{
                type: Input
            }], visible: [{
                type: Input
            }] } });
class DxiSchedulerOptionsItemModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiSchedulerOptionsItemModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxiSchedulerOptionsItemModule, imports: [DxiSchedulerOptionsItemComponent], exports: [DxiSchedulerOptionsItemComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiSchedulerOptionsItemModule, imports: [DxiSchedulerOptionsItemComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiSchedulerOptionsItemModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxiSchedulerOptionsItemComponent
                    ],
                    exports: [
                        DxiSchedulerOptionsItemComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoSchedulerOptionsComponent extends NestedOption {
    set _itemsContentChildren(value) {
        this.setChildren('items', value);
    }
    get accessKey() {
        return this._getOption('accessKey');
    }
    set accessKey(value) {
        this._setOption('accessKey', value);
    }
    get activeStateEnabled() {
        return this._getOption('activeStateEnabled');
    }
    set activeStateEnabled(value) {
        this._setOption('activeStateEnabled', value);
    }
    get buttonTemplate() {
        return this._getOption('buttonTemplate');
    }
    set buttonTemplate(value) {
        this._setOption('buttonTemplate', value);
    }
    get disabled() {
        return this._getOption('disabled');
    }
    set disabled(value) {
        this._setOption('disabled', value);
    }
    get elementAttr() {
        return this._getOption('elementAttr');
    }
    set elementAttr(value) {
        this._setOption('elementAttr', value);
    }
    get focusStateEnabled() {
        return this._getOption('focusStateEnabled');
    }
    set focusStateEnabled(value) {
        this._setOption('focusStateEnabled', value);
    }
    get height() {
        return this._getOption('height');
    }
    set height(value) {
        this._setOption('height', value);
    }
    get hint() {
        return this._getOption('hint');
    }
    set hint(value) {
        this._setOption('hint', value);
    }
    get hoverStateEnabled() {
        return this._getOption('hoverStateEnabled');
    }
    set hoverStateEnabled(value) {
        this._setOption('hoverStateEnabled', value);
    }
    get items() {
        return this._getOption('items');
    }
    set items(value) {
        this._setOption('items', value);
    }
    get keyExpr() {
        return this._getOption('keyExpr');
    }
    set keyExpr(value) {
        this._setOption('keyExpr', value);
    }
    get onContentReady() {
        return this._getOption('onContentReady');
    }
    set onContentReady(value) {
        this._setOption('onContentReady', value);
    }
    get onDisposing() {
        return this._getOption('onDisposing');
    }
    set onDisposing(value) {
        this._setOption('onDisposing', value);
    }
    get onInitialized() {
        return this._getOption('onInitialized');
    }
    set onInitialized(value) {
        this._setOption('onInitialized', value);
    }
    get onItemClick() {
        return this._getOption('onItemClick');
    }
    set onItemClick(value) {
        this._setOption('onItemClick', value);
    }
    get onOptionChanged() {
        return this._getOption('onOptionChanged');
    }
    set onOptionChanged(value) {
        this._setOption('onOptionChanged', value);
    }
    get onSelectionChanged() {
        return this._getOption('onSelectionChanged');
    }
    set onSelectionChanged(value) {
        this._setOption('onSelectionChanged', value);
    }
    get rtlEnabled() {
        return this._getOption('rtlEnabled');
    }
    set rtlEnabled(value) {
        this._setOption('rtlEnabled', value);
    }
    get selectedItemKeys() {
        return this._getOption('selectedItemKeys');
    }
    set selectedItemKeys(value) {
        this._setOption('selectedItemKeys', value);
    }
    get selectedItems() {
        return this._getOption('selectedItems');
    }
    set selectedItems(value) {
        this._setOption('selectedItems', value);
    }
    get selectionMode() {
        return this._getOption('selectionMode');
    }
    set selectionMode(value) {
        this._setOption('selectionMode', value);
    }
    get stylingMode() {
        return this._getOption('stylingMode');
    }
    set stylingMode(value) {
        this._setOption('stylingMode', value);
    }
    get tabIndex() {
        return this._getOption('tabIndex');
    }
    set tabIndex(value) {
        this._setOption('tabIndex', value);
    }
    get visible() {
        return this._getOption('visible');
    }
    set visible(value) {
        this._setOption('visible', value);
    }
    get width() {
        return this._getOption('width');
    }
    set width(value) {
        this._setOption('width', value);
    }
    get _optionPath() {
        return 'options';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        this._createEventEmitters([
            { emit: 'selectedItemKeysChange' },
            { emit: 'selectedItemsChange' }
        ]);
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoSchedulerOptionsComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoSchedulerOptionsComponent, isStandalone: true, selector: "dxo-scheduler-options", inputs: { accessKey: "accessKey", activeStateEnabled: "activeStateEnabled", buttonTemplate: "buttonTemplate", disabled: "disabled", elementAttr: "elementAttr", focusStateEnabled: "focusStateEnabled", height: "height", hint: "hint", hoverStateEnabled: "hoverStateEnabled", items: "items", keyExpr: "keyExpr", onContentReady: "onContentReady", onDisposing: "onDisposing", onInitialized: "onInitialized", onItemClick: "onItemClick", onOptionChanged: "onOptionChanged", onSelectionChanged: "onSelectionChanged", rtlEnabled: "rtlEnabled", selectedItemKeys: "selectedItemKeys", selectedItems: "selectedItems", selectionMode: "selectionMode", stylingMode: "stylingMode", tabIndex: "tabIndex", visible: "visible", width: "width" }, outputs: { selectedItemKeysChange: "selectedItemKeysChange", selectedItemsChange: "selectedItemsChange" }, providers: [NestedOptionHost], queries: [{ propertyName: "_itemsContentChildren", predicate: PROPERTY_TOKEN_items }], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoSchedulerOptionsComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-scheduler-options', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { _itemsContentChildren: [{
                type: ContentChildren,
                args: [PROPERTY_TOKEN_items]
            }], accessKey: [{
                type: Input
            }], activeStateEnabled: [{
                type: Input
            }], buttonTemplate: [{
                type: Input
            }], disabled: [{
                type: Input
            }], elementAttr: [{
                type: Input
            }], focusStateEnabled: [{
                type: Input
            }], height: [{
                type: Input
            }], hint: [{
                type: Input
            }], hoverStateEnabled: [{
                type: Input
            }], items: [{
                type: Input
            }], keyExpr: [{
                type: Input
            }], onContentReady: [{
                type: Input
            }], onDisposing: [{
                type: Input
            }], onInitialized: [{
                type: Input
            }], onItemClick: [{
                type: Input
            }], onOptionChanged: [{
                type: Input
            }], onSelectionChanged: [{
                type: Input
            }], rtlEnabled: [{
                type: Input
            }], selectedItemKeys: [{
                type: Input
            }], selectedItems: [{
                type: Input
            }], selectionMode: [{
                type: Input
            }], stylingMode: [{
                type: Input
            }], tabIndex: [{
                type: Input
            }], visible: [{
                type: Input
            }], width: [{
                type: Input
            }], selectedItemKeysChange: [{
                type: Output
            }], selectedItemsChange: [{
                type: Output
            }] } });
class DxoSchedulerOptionsModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoSchedulerOptionsModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoSchedulerOptionsModule, imports: [DxoSchedulerOptionsComponent], exports: [DxoSchedulerOptionsComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoSchedulerOptionsModule, imports: [DxoSchedulerOptionsComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoSchedulerOptionsModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoSchedulerOptionsComponent
                    ],
                    exports: [
                        DxoSchedulerOptionsComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxiSchedulerPatternRuleComponent extends CollectionNestedOption {
    get ignoreEmptyValue() {
        return this._getOption('ignoreEmptyValue');
    }
    set ignoreEmptyValue(value) {
        this._setOption('ignoreEmptyValue', value);
    }
    get message() {
        return this._getOption('message');
    }
    set message(value) {
        this._setOption('message', value);
    }
    get pattern() {
        return this._getOption('pattern');
    }
    set pattern(value) {
        this._setOption('pattern', value);
    }
    get type() {
        return this._getOption('type');
    }
    set type(value) {
        this._setOption('type', value);
    }
    get _optionPath() {
        return 'validationRules';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
        this.type = 'pattern';
    }
    ngOnDestroy() {
        this._deleteRemovedOptions(this._fullOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiSchedulerPatternRuleComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxiSchedulerPatternRuleComponent, isStandalone: true, selector: "dxi-scheduler-pattern-rule", inputs: { ignoreEmptyValue: "ignoreEmptyValue", message: "message", pattern: "pattern", type: "type" }, providers: [
            NestedOptionHost,
            {
                provide: PROPERTY_TOKEN_validationRules,
                useExisting: DxiSchedulerPatternRuleComponent,
            }
        ], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiSchedulerPatternRuleComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxi-scheduler-pattern-rule', template: '', imports: [DxIntegrationModule], providers: [
                        NestedOptionHost,
                        {
                            provide: PROPERTY_TOKEN_validationRules,
                            useExisting: DxiSchedulerPatternRuleComponent,
                        }
                    ] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { ignoreEmptyValue: [{
                type: Input
            }], message: [{
                type: Input
            }], pattern: [{
                type: Input
            }], type: [{
                type: Input
            }] } });
class DxiSchedulerPatternRuleModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiSchedulerPatternRuleModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxiSchedulerPatternRuleModule, imports: [DxiSchedulerPatternRuleComponent], exports: [DxiSchedulerPatternRuleComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiSchedulerPatternRuleModule, imports: [DxiSchedulerPatternRuleComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiSchedulerPatternRuleModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxiSchedulerPatternRuleComponent
                    ],
                    exports: [
                        DxiSchedulerPatternRuleComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxiSchedulerRangeRuleComponent extends CollectionNestedOption {
    get ignoreEmptyValue() {
        return this._getOption('ignoreEmptyValue');
    }
    set ignoreEmptyValue(value) {
        this._setOption('ignoreEmptyValue', value);
    }
    get max() {
        return this._getOption('max');
    }
    set max(value) {
        this._setOption('max', value);
    }
    get message() {
        return this._getOption('message');
    }
    set message(value) {
        this._setOption('message', value);
    }
    get min() {
        return this._getOption('min');
    }
    set min(value) {
        this._setOption('min', value);
    }
    get reevaluate() {
        return this._getOption('reevaluate');
    }
    set reevaluate(value) {
        this._setOption('reevaluate', value);
    }
    get type() {
        return this._getOption('type');
    }
    set type(value) {
        this._setOption('type', value);
    }
    get _optionPath() {
        return 'validationRules';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
        this.type = 'range';
    }
    ngOnDestroy() {
        this._deleteRemovedOptions(this._fullOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiSchedulerRangeRuleComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxiSchedulerRangeRuleComponent, isStandalone: true, selector: "dxi-scheduler-range-rule", inputs: { ignoreEmptyValue: "ignoreEmptyValue", max: "max", message: "message", min: "min", reevaluate: "reevaluate", type: "type" }, providers: [
            NestedOptionHost,
            {
                provide: PROPERTY_TOKEN_validationRules,
                useExisting: DxiSchedulerRangeRuleComponent,
            }
        ], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiSchedulerRangeRuleComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxi-scheduler-range-rule', template: '', imports: [DxIntegrationModule], providers: [
                        NestedOptionHost,
                        {
                            provide: PROPERTY_TOKEN_validationRules,
                            useExisting: DxiSchedulerRangeRuleComponent,
                        }
                    ] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { ignoreEmptyValue: [{
                type: Input
            }], max: [{
                type: Input
            }], message: [{
                type: Input
            }], min: [{
                type: Input
            }], reevaluate: [{
                type: Input
            }], type: [{
                type: Input
            }] } });
class DxiSchedulerRangeRuleModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiSchedulerRangeRuleModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxiSchedulerRangeRuleModule, imports: [DxiSchedulerRangeRuleComponent], exports: [DxiSchedulerRangeRuleComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiSchedulerRangeRuleModule, imports: [DxiSchedulerRangeRuleComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiSchedulerRangeRuleModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxiSchedulerRangeRuleComponent
                    ],
                    exports: [
                        DxiSchedulerRangeRuleComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxiSchedulerRequiredRuleComponent extends CollectionNestedOption {
    get message() {
        return this._getOption('message');
    }
    set message(value) {
        this._setOption('message', value);
    }
    get trim() {
        return this._getOption('trim');
    }
    set trim(value) {
        this._setOption('trim', value);
    }
    get type() {
        return this._getOption('type');
    }
    set type(value) {
        this._setOption('type', value);
    }
    get _optionPath() {
        return 'validationRules';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
        this.type = 'required';
    }
    ngOnDestroy() {
        this._deleteRemovedOptions(this._fullOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiSchedulerRequiredRuleComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxiSchedulerRequiredRuleComponent, isStandalone: true, selector: "dxi-scheduler-required-rule", inputs: { message: "message", trim: "trim", type: "type" }, providers: [
            NestedOptionHost,
            {
                provide: PROPERTY_TOKEN_validationRules,
                useExisting: DxiSchedulerRequiredRuleComponent,
            }
        ], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiSchedulerRequiredRuleComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxi-scheduler-required-rule', template: '', imports: [DxIntegrationModule], providers: [
                        NestedOptionHost,
                        {
                            provide: PROPERTY_TOKEN_validationRules,
                            useExisting: DxiSchedulerRequiredRuleComponent,
                        }
                    ] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { message: [{
                type: Input
            }], trim: [{
                type: Input
            }], type: [{
                type: Input
            }] } });
class DxiSchedulerRequiredRuleModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiSchedulerRequiredRuleModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxiSchedulerRequiredRuleModule, imports: [DxiSchedulerRequiredRuleComponent], exports: [DxiSchedulerRequiredRuleComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiSchedulerRequiredRuleModule, imports: [DxiSchedulerRequiredRuleComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiSchedulerRequiredRuleModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxiSchedulerRequiredRuleComponent
                    ],
                    exports: [
                        DxiSchedulerRequiredRuleComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxiSchedulerResourceComponent extends CollectionNestedOption {
    get allowMultiple() {
        return this._getOption('allowMultiple');
    }
    set allowMultiple(value) {
        this._setOption('allowMultiple', value);
    }
    get colorExpr() {
        return this._getOption('colorExpr');
    }
    set colorExpr(value) {
        this._setOption('colorExpr', value);
    }
    get dataSource() {
        return this._getOption('dataSource');
    }
    set dataSource(value) {
        this._setOption('dataSource', value);
    }
    get displayExpr() {
        return this._getOption('displayExpr');
    }
    set displayExpr(value) {
        this._setOption('displayExpr', value);
    }
    get fieldExpr() {
        return this._getOption('fieldExpr');
    }
    set fieldExpr(value) {
        this._setOption('fieldExpr', value);
    }
    get icon() {
        return this._getOption('icon');
    }
    set icon(value) {
        this._setOption('icon', value);
    }
    get label() {
        return this._getOption('label');
    }
    set label(value) {
        this._setOption('label', value);
    }
    get parentIdExpr() {
        return this._getOption('parentIdExpr');
    }
    set parentIdExpr(value) {
        this._setOption('parentIdExpr', value);
    }
    get useColorAsDefault() {
        return this._getOption('useColorAsDefault');
    }
    set useColorAsDefault(value) {
        this._setOption('useColorAsDefault', value);
    }
    get valueExpr() {
        return this._getOption('valueExpr');
    }
    set valueExpr(value) {
        this._setOption('valueExpr', value);
    }
    get _optionPath() {
        return 'resources';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnDestroy() {
        this._deleteRemovedOptions(this._fullOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiSchedulerResourceComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxiSchedulerResourceComponent, isStandalone: true, selector: "dxi-scheduler-resource", inputs: { allowMultiple: "allowMultiple", colorExpr: "colorExpr", dataSource: "dataSource", displayExpr: "displayExpr", fieldExpr: "fieldExpr", icon: "icon", label: "label", parentIdExpr: "parentIdExpr", useColorAsDefault: "useColorAsDefault", valueExpr: "valueExpr" }, providers: [
            NestedOptionHost,
            {
                provide: PROPERTY_TOKEN_resources,
                useExisting: DxiSchedulerResourceComponent,
            }
        ], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiSchedulerResourceComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxi-scheduler-resource', template: '', imports: [DxIntegrationModule], providers: [
                        NestedOptionHost,
                        {
                            provide: PROPERTY_TOKEN_resources,
                            useExisting: DxiSchedulerResourceComponent,
                        }
                    ] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { allowMultiple: [{
                type: Input
            }], colorExpr: [{
                type: Input
            }], dataSource: [{
                type: Input
            }], displayExpr: [{
                type: Input
            }], fieldExpr: [{
                type: Input
            }], icon: [{
                type: Input
            }], label: [{
                type: Input
            }], parentIdExpr: [{
                type: Input
            }], useColorAsDefault: [{
                type: Input
            }], valueExpr: [{
                type: Input
            }] } });
class DxiSchedulerResourceModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiSchedulerResourceModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxiSchedulerResourceModule, imports: [DxiSchedulerResourceComponent], exports: [DxiSchedulerResourceComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiSchedulerResourceModule, imports: [DxiSchedulerResourceComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiSchedulerResourceModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxiSchedulerResourceComponent
                    ],
                    exports: [
                        DxiSchedulerResourceComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoSchedulerScrollingComponent extends NestedOption {
    get mode() {
        return this._getOption('mode');
    }
    set mode(value) {
        this._setOption('mode', value);
    }
    get _optionPath() {
        return 'scrolling';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoSchedulerScrollingComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoSchedulerScrollingComponent, isStandalone: true, selector: "dxo-scheduler-scrolling", inputs: { mode: "mode" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoSchedulerScrollingComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-scheduler-scrolling', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { mode: [{
                type: Input
            }] } });
class DxoSchedulerScrollingModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoSchedulerScrollingModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoSchedulerScrollingModule, imports: [DxoSchedulerScrollingComponent], exports: [DxoSchedulerScrollingComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoSchedulerScrollingModule, imports: [DxoSchedulerScrollingComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoSchedulerScrollingModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoSchedulerScrollingComponent
                    ],
                    exports: [
                        DxoSchedulerScrollingComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxiSchedulerSimpleItemComponent extends CollectionNestedOption {
    set _validationRulesContentChildren(value) {
        this.setChildren('validationRules', value);
    }
    get aiOptions() {
        return this._getOption('aiOptions');
    }
    set aiOptions(value) {
        this._setOption('aiOptions', value);
    }
    get colSpan() {
        return this._getOption('colSpan');
    }
    set colSpan(value) {
        this._setOption('colSpan', value);
    }
    get cssClass() {
        return this._getOption('cssClass');
    }
    set cssClass(value) {
        this._setOption('cssClass', value);
    }
    get dataField() {
        return this._getOption('dataField');
    }
    set dataField(value) {
        this._setOption('dataField', value);
    }
    get editorOptions() {
        return this._getOption('editorOptions');
    }
    set editorOptions(value) {
        this._setOption('editorOptions', value);
    }
    get editorType() {
        return this._getOption('editorType');
    }
    set editorType(value) {
        this._setOption('editorType', value);
    }
    get helpText() {
        return this._getOption('helpText');
    }
    set helpText(value) {
        this._setOption('helpText', value);
    }
    get isRequired() {
        return this._getOption('isRequired');
    }
    set isRequired(value) {
        this._setOption('isRequired', value);
    }
    get itemType() {
        return this._getOption('itemType');
    }
    set itemType(value) {
        this._setOption('itemType', value);
    }
    get label() {
        return this._getOption('label');
    }
    set label(value) {
        this._setOption('label', value);
    }
    get name() {
        return this._getOption('name');
    }
    set name(value) {
        this._setOption('name', value);
    }
    get template() {
        return this._getOption('template');
    }
    set template(value) {
        this._setOption('template', value);
    }
    get validationRules() {
        return this._getOption('validationRules');
    }
    set validationRules(value) {
        this._setOption('validationRules', value);
    }
    get visible() {
        return this._getOption('visible');
    }
    set visible(value) {
        this._setOption('visible', value);
    }
    get visibleIndex() {
        return this._getOption('visibleIndex');
    }
    set visibleIndex(value) {
        this._setOption('visibleIndex', value);
    }
    get _optionPath() {
        return 'items';
    }
    constructor(parentOptionHost, optionHost, renderer, document, templateHost, element) {
        super();
        this.renderer = renderer;
        this.document = document;
        this.element = element;
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
        templateHost.setHost(this);
        this.itemType = 'simple';
    }
    setTemplate(template) {
        this.template = template;
    }
    ngAfterViewInit() {
        extractTemplate(this, this.element, this.renderer, this.document);
    }
    ngOnDestroy() {
        this._deleteRemovedOptions(this._fullOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiSchedulerSimpleItemComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }, { token: i0.Renderer2 }, { token: DOCUMENT }, { token: i1.DxTemplateHost, host: true }, { token: i0.ElementRef }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxiSchedulerSimpleItemComponent, isStandalone: true, selector: "dxi-scheduler-simple-item", inputs: { aiOptions: "aiOptions", colSpan: "colSpan", cssClass: "cssClass", dataField: "dataField", editorOptions: "editorOptions", editorType: "editorType", helpText: "helpText", isRequired: "isRequired", itemType: "itemType", label: "label", name: "name", template: "template", validationRules: "validationRules", visible: "visible", visibleIndex: "visibleIndex" }, providers: [
            NestedOptionHost,
            DxTemplateHost,
            {
                provide: PROPERTY_TOKEN_items,
                useExisting: DxiSchedulerSimpleItemComponent,
            }
        ], queries: [{ propertyName: "_validationRulesContentChildren", predicate: PROPERTY_TOKEN_validationRules }], usesInheritance: true, ngImport: i0, template: '<ng-content></ng-content>', isInline: true, styles: [":host{display:block}\n"], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiSchedulerSimpleItemComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxi-scheduler-simple-item', template: '<ng-content></ng-content>', imports: [DxIntegrationModule], providers: [
                        NestedOptionHost,
                        DxTemplateHost,
                        {
                            provide: PROPERTY_TOKEN_items,
                            useExisting: DxiSchedulerSimpleItemComponent,
                        }
                    ], styles: [":host{display:block}\n"] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }, { type: i0.Renderer2 }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [DOCUMENT]
                }] }, { type: i1.DxTemplateHost, decorators: [{
                    type: Host
                }] }, { type: i0.ElementRef }], propDecorators: { _validationRulesContentChildren: [{
                type: ContentChildren,
                args: [PROPERTY_TOKEN_validationRules]
            }], aiOptions: [{
                type: Input
            }], colSpan: [{
                type: Input
            }], cssClass: [{
                type: Input
            }], dataField: [{
                type: Input
            }], editorOptions: [{
                type: Input
            }], editorType: [{
                type: Input
            }], helpText: [{
                type: Input
            }], isRequired: [{
                type: Input
            }], itemType: [{
                type: Input
            }], label: [{
                type: Input
            }], name: [{
                type: Input
            }], template: [{
                type: Input
            }], validationRules: [{
                type: Input
            }], visible: [{
                type: Input
            }], visibleIndex: [{
                type: Input
            }] } });
class DxiSchedulerSimpleItemModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiSchedulerSimpleItemModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxiSchedulerSimpleItemModule, imports: [DxiSchedulerSimpleItemComponent], exports: [DxiSchedulerSimpleItemComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiSchedulerSimpleItemModule, imports: [DxiSchedulerSimpleItemComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiSchedulerSimpleItemModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxiSchedulerSimpleItemComponent
                    ],
                    exports: [
                        DxiSchedulerSimpleItemComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxiSchedulerStringLengthRuleComponent extends CollectionNestedOption {
    get ignoreEmptyValue() {
        return this._getOption('ignoreEmptyValue');
    }
    set ignoreEmptyValue(value) {
        this._setOption('ignoreEmptyValue', value);
    }
    get max() {
        return this._getOption('max');
    }
    set max(value) {
        this._setOption('max', value);
    }
    get message() {
        return this._getOption('message');
    }
    set message(value) {
        this._setOption('message', value);
    }
    get min() {
        return this._getOption('min');
    }
    set min(value) {
        this._setOption('min', value);
    }
    get trim() {
        return this._getOption('trim');
    }
    set trim(value) {
        this._setOption('trim', value);
    }
    get type() {
        return this._getOption('type');
    }
    set type(value) {
        this._setOption('type', value);
    }
    get _optionPath() {
        return 'validationRules';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
        this.type = 'stringLength';
    }
    ngOnDestroy() {
        this._deleteRemovedOptions(this._fullOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiSchedulerStringLengthRuleComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxiSchedulerStringLengthRuleComponent, isStandalone: true, selector: "dxi-scheduler-string-length-rule", inputs: { ignoreEmptyValue: "ignoreEmptyValue", max: "max", message: "message", min: "min", trim: "trim", type: "type" }, providers: [
            NestedOptionHost,
            {
                provide: PROPERTY_TOKEN_validationRules,
                useExisting: DxiSchedulerStringLengthRuleComponent,
            }
        ], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiSchedulerStringLengthRuleComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxi-scheduler-string-length-rule', template: '', imports: [DxIntegrationModule], providers: [
                        NestedOptionHost,
                        {
                            provide: PROPERTY_TOKEN_validationRules,
                            useExisting: DxiSchedulerStringLengthRuleComponent,
                        }
                    ] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { ignoreEmptyValue: [{
                type: Input
            }], max: [{
                type: Input
            }], message: [{
                type: Input
            }], min: [{
                type: Input
            }], trim: [{
                type: Input
            }], type: [{
                type: Input
            }] } });
class DxiSchedulerStringLengthRuleModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiSchedulerStringLengthRuleModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxiSchedulerStringLengthRuleModule, imports: [DxiSchedulerStringLengthRuleComponent], exports: [DxiSchedulerStringLengthRuleComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiSchedulerStringLengthRuleModule, imports: [DxiSchedulerStringLengthRuleComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiSchedulerStringLengthRuleModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxiSchedulerStringLengthRuleComponent
                    ],
                    exports: [
                        DxiSchedulerStringLengthRuleComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxiSchedulerTabComponent extends CollectionNestedOption {
    set _itemsContentChildren(value) {
        this.setChildren('items', value);
    }
    get alignItemLabels() {
        return this._getOption('alignItemLabels');
    }
    set alignItemLabels(value) {
        this._setOption('alignItemLabels', value);
    }
    get badge() {
        return this._getOption('badge');
    }
    set badge(value) {
        this._setOption('badge', value);
    }
    get colCount() {
        return this._getOption('colCount');
    }
    set colCount(value) {
        this._setOption('colCount', value);
    }
    get colCountByScreen() {
        return this._getOption('colCountByScreen');
    }
    set colCountByScreen(value) {
        this._setOption('colCountByScreen', value);
    }
    get disabled() {
        return this._getOption('disabled');
    }
    set disabled(value) {
        this._setOption('disabled', value);
    }
    get icon() {
        return this._getOption('icon');
    }
    set icon(value) {
        this._setOption('icon', value);
    }
    get items() {
        return this._getOption('items');
    }
    set items(value) {
        this._setOption('items', value);
    }
    get tabTemplate() {
        return this._getOption('tabTemplate');
    }
    set tabTemplate(value) {
        this._setOption('tabTemplate', value);
    }
    get template() {
        return this._getOption('template');
    }
    set template(value) {
        this._setOption('template', value);
    }
    get title() {
        return this._getOption('title');
    }
    set title(value) {
        this._setOption('title', value);
    }
    get _optionPath() {
        return 'tabs';
    }
    constructor(parentOptionHost, optionHost, renderer, document, templateHost, element) {
        super();
        this.renderer = renderer;
        this.document = document;
        this.element = element;
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
        templateHost.setHost(this);
    }
    setTemplate(template) {
        this.template = template;
    }
    ngAfterViewInit() {
        extractTemplate(this, this.element, this.renderer, this.document);
    }
    ngOnDestroy() {
        this._deleteRemovedOptions(this._fullOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiSchedulerTabComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }, { token: i0.Renderer2 }, { token: DOCUMENT }, { token: i1.DxTemplateHost, host: true }, { token: i0.ElementRef }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxiSchedulerTabComponent, isStandalone: true, selector: "dxi-scheduler-tab", inputs: { alignItemLabels: "alignItemLabels", badge: "badge", colCount: "colCount", colCountByScreen: "colCountByScreen", disabled: "disabled", icon: "icon", items: "items", tabTemplate: "tabTemplate", template: "template", title: "title" }, providers: [
            NestedOptionHost,
            DxTemplateHost,
            {
                provide: PROPERTY_TOKEN_tabs,
                useExisting: DxiSchedulerTabComponent,
            }
        ], queries: [{ propertyName: "_itemsContentChildren", predicate: PROPERTY_TOKEN_items }], usesInheritance: true, ngImport: i0, template: '<ng-content></ng-content>', isInline: true, styles: [":host{display:block}\n"], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiSchedulerTabComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxi-scheduler-tab', template: '<ng-content></ng-content>', imports: [DxIntegrationModule], providers: [
                        NestedOptionHost,
                        DxTemplateHost,
                        {
                            provide: PROPERTY_TOKEN_tabs,
                            useExisting: DxiSchedulerTabComponent,
                        }
                    ], styles: [":host{display:block}\n"] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }, { type: i0.Renderer2 }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [DOCUMENT]
                }] }, { type: i1.DxTemplateHost, decorators: [{
                    type: Host
                }] }, { type: i0.ElementRef }], propDecorators: { _itemsContentChildren: [{
                type: ContentChildren,
                args: [PROPERTY_TOKEN_items]
            }], alignItemLabels: [{
                type: Input
            }], badge: [{
                type: Input
            }], colCount: [{
                type: Input
            }], colCountByScreen: [{
                type: Input
            }], disabled: [{
                type: Input
            }], icon: [{
                type: Input
            }], items: [{
                type: Input
            }], tabTemplate: [{
                type: Input
            }], template: [{
                type: Input
            }], title: [{
                type: Input
            }] } });
class DxiSchedulerTabModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiSchedulerTabModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxiSchedulerTabModule, imports: [DxiSchedulerTabComponent], exports: [DxiSchedulerTabComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiSchedulerTabModule, imports: [DxiSchedulerTabComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiSchedulerTabModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxiSchedulerTabComponent
                    ],
                    exports: [
                        DxiSchedulerTabComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxiSchedulerTabPanelOptionsItemComponent extends CollectionNestedOption {
    get badge() {
        return this._getOption('badge');
    }
    set badge(value) {
        this._setOption('badge', value);
    }
    get disabled() {
        return this._getOption('disabled');
    }
    set disabled(value) {
        this._setOption('disabled', value);
    }
    get html() {
        return this._getOption('html');
    }
    set html(value) {
        this._setOption('html', value);
    }
    get icon() {
        return this._getOption('icon');
    }
    set icon(value) {
        this._setOption('icon', value);
    }
    get tabTemplate() {
        return this._getOption('tabTemplate');
    }
    set tabTemplate(value) {
        this._setOption('tabTemplate', value);
    }
    get template() {
        return this._getOption('template');
    }
    set template(value) {
        this._setOption('template', value);
    }
    get text() {
        return this._getOption('text');
    }
    set text(value) {
        this._setOption('text', value);
    }
    get title() {
        return this._getOption('title');
    }
    set title(value) {
        this._setOption('title', value);
    }
    get visible() {
        return this._getOption('visible');
    }
    set visible(value) {
        this._setOption('visible', value);
    }
    get _optionPath() {
        return 'items';
    }
    constructor(parentOptionHost, optionHost, renderer, document, templateHost, element) {
        super();
        this.renderer = renderer;
        this.document = document;
        this.element = element;
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
        templateHost.setHost(this);
    }
    setTemplate(template) {
        this.template = template;
    }
    ngAfterViewInit() {
        extractTemplate(this, this.element, this.renderer, this.document);
    }
    ngOnDestroy() {
        this._deleteRemovedOptions(this._fullOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiSchedulerTabPanelOptionsItemComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }, { token: i0.Renderer2 }, { token: DOCUMENT }, { token: i1.DxTemplateHost, host: true }, { token: i0.ElementRef }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxiSchedulerTabPanelOptionsItemComponent, isStandalone: true, selector: "dxi-scheduler-tab-panel-options-item", inputs: { badge: "badge", disabled: "disabled", html: "html", icon: "icon", tabTemplate: "tabTemplate", template: "template", text: "text", title: "title", visible: "visible" }, providers: [
            NestedOptionHost,
            DxTemplateHost,
            {
                provide: PROPERTY_TOKEN_items,
                useExisting: DxiSchedulerTabPanelOptionsItemComponent,
            }
        ], usesInheritance: true, ngImport: i0, template: '<ng-content></ng-content>', isInline: true, styles: [":host{display:block}\n"], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiSchedulerTabPanelOptionsItemComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxi-scheduler-tab-panel-options-item', template: '<ng-content></ng-content>', imports: [DxIntegrationModule], providers: [
                        NestedOptionHost,
                        DxTemplateHost,
                        {
                            provide: PROPERTY_TOKEN_items,
                            useExisting: DxiSchedulerTabPanelOptionsItemComponent,
                        }
                    ], styles: [":host{display:block}\n"] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }, { type: i0.Renderer2 }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [DOCUMENT]
                }] }, { type: i1.DxTemplateHost, decorators: [{
                    type: Host
                }] }, { type: i0.ElementRef }], propDecorators: { badge: [{
                type: Input
            }], disabled: [{
                type: Input
            }], html: [{
                type: Input
            }], icon: [{
                type: Input
            }], tabTemplate: [{
                type: Input
            }], template: [{
                type: Input
            }], text: [{
                type: Input
            }], title: [{
                type: Input
            }], visible: [{
                type: Input
            }] } });
class DxiSchedulerTabPanelOptionsItemModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiSchedulerTabPanelOptionsItemModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxiSchedulerTabPanelOptionsItemModule, imports: [DxiSchedulerTabPanelOptionsItemComponent], exports: [DxiSchedulerTabPanelOptionsItemComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiSchedulerTabPanelOptionsItemModule, imports: [DxiSchedulerTabPanelOptionsItemComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiSchedulerTabPanelOptionsItemModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxiSchedulerTabPanelOptionsItemComponent
                    ],
                    exports: [
                        DxiSchedulerTabPanelOptionsItemComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoSchedulerTabPanelOptionsComponent extends NestedOption {
    set _itemsContentChildren(value) {
        this.setChildren('items', value);
    }
    get accessKey() {
        return this._getOption('accessKey');
    }
    set accessKey(value) {
        this._setOption('accessKey', value);
    }
    get activeStateEnabled() {
        return this._getOption('activeStateEnabled');
    }
    set activeStateEnabled(value) {
        this._setOption('activeStateEnabled', value);
    }
    get animationEnabled() {
        return this._getOption('animationEnabled');
    }
    set animationEnabled(value) {
        this._setOption('animationEnabled', value);
    }
    get dataSource() {
        return this._getOption('dataSource');
    }
    set dataSource(value) {
        this._setOption('dataSource', value);
    }
    get deferRendering() {
        return this._getOption('deferRendering');
    }
    set deferRendering(value) {
        this._setOption('deferRendering', value);
    }
    get disabled() {
        return this._getOption('disabled');
    }
    set disabled(value) {
        this._setOption('disabled', value);
    }
    get elementAttr() {
        return this._getOption('elementAttr');
    }
    set elementAttr(value) {
        this._setOption('elementAttr', value);
    }
    get focusStateEnabled() {
        return this._getOption('focusStateEnabled');
    }
    set focusStateEnabled(value) {
        this._setOption('focusStateEnabled', value);
    }
    get height() {
        return this._getOption('height');
    }
    set height(value) {
        this._setOption('height', value);
    }
    get hint() {
        return this._getOption('hint');
    }
    set hint(value) {
        this._setOption('hint', value);
    }
    get hoverStateEnabled() {
        return this._getOption('hoverStateEnabled');
    }
    set hoverStateEnabled(value) {
        this._setOption('hoverStateEnabled', value);
    }
    get iconPosition() {
        return this._getOption('iconPosition');
    }
    set iconPosition(value) {
        this._setOption('iconPosition', value);
    }
    get itemHoldTimeout() {
        return this._getOption('itemHoldTimeout');
    }
    set itemHoldTimeout(value) {
        this._setOption('itemHoldTimeout', value);
    }
    get items() {
        return this._getOption('items');
    }
    set items(value) {
        this._setOption('items', value);
    }
    get itemTemplate() {
        return this._getOption('itemTemplate');
    }
    set itemTemplate(value) {
        this._setOption('itemTemplate', value);
    }
    get itemTitleTemplate() {
        return this._getOption('itemTitleTemplate');
    }
    set itemTitleTemplate(value) {
        this._setOption('itemTitleTemplate', value);
    }
    get keyExpr() {
        return this._getOption('keyExpr');
    }
    set keyExpr(value) {
        this._setOption('keyExpr', value);
    }
    get loop() {
        return this._getOption('loop');
    }
    set loop(value) {
        this._setOption('loop', value);
    }
    get noDataText() {
        return this._getOption('noDataText');
    }
    set noDataText(value) {
        this._setOption('noDataText', value);
    }
    get onContentReady() {
        return this._getOption('onContentReady');
    }
    set onContentReady(value) {
        this._setOption('onContentReady', value);
    }
    get onDisposing() {
        return this._getOption('onDisposing');
    }
    set onDisposing(value) {
        this._setOption('onDisposing', value);
    }
    get onInitialized() {
        return this._getOption('onInitialized');
    }
    set onInitialized(value) {
        this._setOption('onInitialized', value);
    }
    get onItemClick() {
        return this._getOption('onItemClick');
    }
    set onItemClick(value) {
        this._setOption('onItemClick', value);
    }
    get onItemContextMenu() {
        return this._getOption('onItemContextMenu');
    }
    set onItemContextMenu(value) {
        this._setOption('onItemContextMenu', value);
    }
    get onItemHold() {
        return this._getOption('onItemHold');
    }
    set onItemHold(value) {
        this._setOption('onItemHold', value);
    }
    get onItemRendered() {
        return this._getOption('onItemRendered');
    }
    set onItemRendered(value) {
        this._setOption('onItemRendered', value);
    }
    get onOptionChanged() {
        return this._getOption('onOptionChanged');
    }
    set onOptionChanged(value) {
        this._setOption('onOptionChanged', value);
    }
    get onSelectionChanged() {
        return this._getOption('onSelectionChanged');
    }
    set onSelectionChanged(value) {
        this._setOption('onSelectionChanged', value);
    }
    get onSelectionChanging() {
        return this._getOption('onSelectionChanging');
    }
    set onSelectionChanging(value) {
        this._setOption('onSelectionChanging', value);
    }
    get onTitleClick() {
        return this._getOption('onTitleClick');
    }
    set onTitleClick(value) {
        this._setOption('onTitleClick', value);
    }
    get onTitleHold() {
        return this._getOption('onTitleHold');
    }
    set onTitleHold(value) {
        this._setOption('onTitleHold', value);
    }
    get onTitleRendered() {
        return this._getOption('onTitleRendered');
    }
    set onTitleRendered(value) {
        this._setOption('onTitleRendered', value);
    }
    get repaintChangesOnly() {
        return this._getOption('repaintChangesOnly');
    }
    set repaintChangesOnly(value) {
        this._setOption('repaintChangesOnly', value);
    }
    get rtlEnabled() {
        return this._getOption('rtlEnabled');
    }
    set rtlEnabled(value) {
        this._setOption('rtlEnabled', value);
    }
    get scrollByContent() {
        return this._getOption('scrollByContent');
    }
    set scrollByContent(value) {
        this._setOption('scrollByContent', value);
    }
    get scrollingEnabled() {
        return this._getOption('scrollingEnabled');
    }
    set scrollingEnabled(value) {
        this._setOption('scrollingEnabled', value);
    }
    get selectedIndex() {
        return this._getOption('selectedIndex');
    }
    set selectedIndex(value) {
        this._setOption('selectedIndex', value);
    }
    get selectedItem() {
        return this._getOption('selectedItem');
    }
    set selectedItem(value) {
        this._setOption('selectedItem', value);
    }
    get showNavButtons() {
        return this._getOption('showNavButtons');
    }
    set showNavButtons(value) {
        this._setOption('showNavButtons', value);
    }
    get stylingMode() {
        return this._getOption('stylingMode');
    }
    set stylingMode(value) {
        this._setOption('stylingMode', value);
    }
    get swipeEnabled() {
        return this._getOption('swipeEnabled');
    }
    set swipeEnabled(value) {
        this._setOption('swipeEnabled', value);
    }
    get tabIndex() {
        return this._getOption('tabIndex');
    }
    set tabIndex(value) {
        this._setOption('tabIndex', value);
    }
    get tabsPosition() {
        return this._getOption('tabsPosition');
    }
    set tabsPosition(value) {
        this._setOption('tabsPosition', value);
    }
    get visible() {
        return this._getOption('visible');
    }
    set visible(value) {
        this._setOption('visible', value);
    }
    get width() {
        return this._getOption('width');
    }
    set width(value) {
        this._setOption('width', value);
    }
    get _optionPath() {
        return 'tabPanelOptions';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        this._createEventEmitters([
            { emit: 'itemsChange' },
            { emit: 'selectedIndexChange' },
            { emit: 'selectedItemChange' }
        ]);
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoSchedulerTabPanelOptionsComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoSchedulerTabPanelOptionsComponent, isStandalone: true, selector: "dxo-scheduler-tab-panel-options", inputs: { accessKey: "accessKey", activeStateEnabled: "activeStateEnabled", animationEnabled: "animationEnabled", dataSource: "dataSource", deferRendering: "deferRendering", disabled: "disabled", elementAttr: "elementAttr", focusStateEnabled: "focusStateEnabled", height: "height", hint: "hint", hoverStateEnabled: "hoverStateEnabled", iconPosition: "iconPosition", itemHoldTimeout: "itemHoldTimeout", items: "items", itemTemplate: "itemTemplate", itemTitleTemplate: "itemTitleTemplate", keyExpr: "keyExpr", loop: "loop", noDataText: "noDataText", onContentReady: "onContentReady", onDisposing: "onDisposing", onInitialized: "onInitialized", onItemClick: "onItemClick", onItemContextMenu: "onItemContextMenu", onItemHold: "onItemHold", onItemRendered: "onItemRendered", onOptionChanged: "onOptionChanged", onSelectionChanged: "onSelectionChanged", onSelectionChanging: "onSelectionChanging", onTitleClick: "onTitleClick", onTitleHold: "onTitleHold", onTitleRendered: "onTitleRendered", repaintChangesOnly: "repaintChangesOnly", rtlEnabled: "rtlEnabled", scrollByContent: "scrollByContent", scrollingEnabled: "scrollingEnabled", selectedIndex: "selectedIndex", selectedItem: "selectedItem", showNavButtons: "showNavButtons", stylingMode: "stylingMode", swipeEnabled: "swipeEnabled", tabIndex: "tabIndex", tabsPosition: "tabsPosition", visible: "visible", width: "width" }, outputs: { itemsChange: "itemsChange", selectedIndexChange: "selectedIndexChange", selectedItemChange: "selectedItemChange" }, providers: [NestedOptionHost], queries: [{ propertyName: "_itemsContentChildren", predicate: PROPERTY_TOKEN_items }], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoSchedulerTabPanelOptionsComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-scheduler-tab-panel-options', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { _itemsContentChildren: [{
                type: ContentChildren,
                args: [PROPERTY_TOKEN_items]
            }], accessKey: [{
                type: Input
            }], activeStateEnabled: [{
                type: Input
            }], animationEnabled: [{
                type: Input
            }], dataSource: [{
                type: Input
            }], deferRendering: [{
                type: Input
            }], disabled: [{
                type: Input
            }], elementAttr: [{
                type: Input
            }], focusStateEnabled: [{
                type: Input
            }], height: [{
                type: Input
            }], hint: [{
                type: Input
            }], hoverStateEnabled: [{
                type: Input
            }], iconPosition: [{
                type: Input
            }], itemHoldTimeout: [{
                type: Input
            }], items: [{
                type: Input
            }], itemTemplate: [{
                type: Input
            }], itemTitleTemplate: [{
                type: Input
            }], keyExpr: [{
                type: Input
            }], loop: [{
                type: Input
            }], noDataText: [{
                type: Input
            }], onContentReady: [{
                type: Input
            }], onDisposing: [{
                type: Input
            }], onInitialized: [{
                type: Input
            }], onItemClick: [{
                type: Input
            }], onItemContextMenu: [{
                type: Input
            }], onItemHold: [{
                type: Input
            }], onItemRendered: [{
                type: Input
            }], onOptionChanged: [{
                type: Input
            }], onSelectionChanged: [{
                type: Input
            }], onSelectionChanging: [{
                type: Input
            }], onTitleClick: [{
                type: Input
            }], onTitleHold: [{
                type: Input
            }], onTitleRendered: [{
                type: Input
            }], repaintChangesOnly: [{
                type: Input
            }], rtlEnabled: [{
                type: Input
            }], scrollByContent: [{
                type: Input
            }], scrollingEnabled: [{
                type: Input
            }], selectedIndex: [{
                type: Input
            }], selectedItem: [{
                type: Input
            }], showNavButtons: [{
                type: Input
            }], stylingMode: [{
                type: Input
            }], swipeEnabled: [{
                type: Input
            }], tabIndex: [{
                type: Input
            }], tabsPosition: [{
                type: Input
            }], visible: [{
                type: Input
            }], width: [{
                type: Input
            }], itemsChange: [{
                type: Output
            }], selectedIndexChange: [{
                type: Output
            }], selectedItemChange: [{
                type: Output
            }] } });
class DxoSchedulerTabPanelOptionsModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoSchedulerTabPanelOptionsModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoSchedulerTabPanelOptionsModule, imports: [DxoSchedulerTabPanelOptionsComponent], exports: [DxoSchedulerTabPanelOptionsComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoSchedulerTabPanelOptionsModule, imports: [DxoSchedulerTabPanelOptionsComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoSchedulerTabPanelOptionsModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoSchedulerTabPanelOptionsComponent
                    ],
                    exports: [
                        DxoSchedulerTabPanelOptionsComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxiSchedulerTabbedItemComponent extends CollectionNestedOption {
    set _tabsContentChildren(value) {
        this.setChildren('tabs', value);
    }
    get colSpan() {
        return this._getOption('colSpan');
    }
    set colSpan(value) {
        this._setOption('colSpan', value);
    }
    get cssClass() {
        return this._getOption('cssClass');
    }
    set cssClass(value) {
        this._setOption('cssClass', value);
    }
    get itemType() {
        return this._getOption('itemType');
    }
    set itemType(value) {
        this._setOption('itemType', value);
    }
    get name() {
        return this._getOption('name');
    }
    set name(value) {
        this._setOption('name', value);
    }
    get tabPanelOptions() {
        return this._getOption('tabPanelOptions');
    }
    set tabPanelOptions(value) {
        this._setOption('tabPanelOptions', value);
    }
    get tabs() {
        return this._getOption('tabs');
    }
    set tabs(value) {
        this._setOption('tabs', value);
    }
    get visible() {
        return this._getOption('visible');
    }
    set visible(value) {
        this._setOption('visible', value);
    }
    get visibleIndex() {
        return this._getOption('visibleIndex');
    }
    set visibleIndex(value) {
        this._setOption('visibleIndex', value);
    }
    get _optionPath() {
        return 'items';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
        this.itemType = 'tabbed';
    }
    ngOnDestroy() {
        this._deleteRemovedOptions(this._fullOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiSchedulerTabbedItemComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxiSchedulerTabbedItemComponent, isStandalone: true, selector: "dxi-scheduler-tabbed-item", inputs: { colSpan: "colSpan", cssClass: "cssClass", itemType: "itemType", name: "name", tabPanelOptions: "tabPanelOptions", tabs: "tabs", visible: "visible", visibleIndex: "visibleIndex" }, providers: [
            NestedOptionHost,
            {
                provide: PROPERTY_TOKEN_items,
                useExisting: DxiSchedulerTabbedItemComponent,
            }
        ], queries: [{ propertyName: "_tabsContentChildren", predicate: PROPERTY_TOKEN_tabs }], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiSchedulerTabbedItemComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxi-scheduler-tabbed-item', template: '', imports: [DxIntegrationModule], providers: [
                        NestedOptionHost,
                        {
                            provide: PROPERTY_TOKEN_items,
                            useExisting: DxiSchedulerTabbedItemComponent,
                        }
                    ] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { _tabsContentChildren: [{
                type: ContentChildren,
                args: [PROPERTY_TOKEN_tabs]
            }], colSpan: [{
                type: Input
            }], cssClass: [{
                type: Input
            }], itemType: [{
                type: Input
            }], name: [{
                type: Input
            }], tabPanelOptions: [{
                type: Input
            }], tabs: [{
                type: Input
            }], visible: [{
                type: Input
            }], visibleIndex: [{
                type: Input
            }] } });
class DxiSchedulerTabbedItemModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiSchedulerTabbedItemModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxiSchedulerTabbedItemModule, imports: [DxiSchedulerTabbedItemComponent], exports: [DxiSchedulerTabbedItemComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiSchedulerTabbedItemModule, imports: [DxiSchedulerTabbedItemComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiSchedulerTabbedItemModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxiSchedulerTabbedItemComponent
                    ],
                    exports: [
                        DxiSchedulerTabbedItemComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxiSchedulerToolbarItemComponent extends CollectionNestedOption {
    get cssClass() {
        return this._getOption('cssClass');
    }
    set cssClass(value) {
        this._setOption('cssClass', value);
    }
    get disabled() {
        return this._getOption('disabled');
    }
    set disabled(value) {
        this._setOption('disabled', value);
    }
    get html() {
        return this._getOption('html');
    }
    set html(value) {
        this._setOption('html', value);
    }
    get locateInMenu() {
        return this._getOption('locateInMenu');
    }
    set locateInMenu(value) {
        this._setOption('locateInMenu', value);
    }
    get location() {
        return this._getOption('location');
    }
    set location(value) {
        this._setOption('location', value);
    }
    get menuItemTemplate() {
        return this._getOption('menuItemTemplate');
    }
    set menuItemTemplate(value) {
        this._setOption('menuItemTemplate', value);
    }
    get name() {
        return this._getOption('name');
    }
    set name(value) {
        this._setOption('name', value);
    }
    get options() {
        return this._getOption('options');
    }
    set options(value) {
        this._setOption('options', value);
    }
    get showText() {
        return this._getOption('showText');
    }
    set showText(value) {
        this._setOption('showText', value);
    }
    get template() {
        return this._getOption('template');
    }
    set template(value) {
        this._setOption('template', value);
    }
    get text() {
        return this._getOption('text');
    }
    set text(value) {
        this._setOption('text', value);
    }
    get visible() {
        return this._getOption('visible');
    }
    set visible(value) {
        this._setOption('visible', value);
    }
    get widget() {
        return this._getOption('widget');
    }
    set widget(value) {
        this._setOption('widget', value);
    }
    get _optionPath() {
        return 'items';
    }
    constructor(parentOptionHost, optionHost, renderer, document, templateHost, element) {
        super();
        this.renderer = renderer;
        this.document = document;
        this.element = element;
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
        templateHost.setHost(this);
    }
    setTemplate(template) {
        this.template = template;
    }
    ngAfterViewInit() {
        extractTemplate(this, this.element, this.renderer, this.document);
    }
    ngOnDestroy() {
        this._deleteRemovedOptions(this._fullOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiSchedulerToolbarItemComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }, { token: i0.Renderer2 }, { token: DOCUMENT }, { token: i1.DxTemplateHost, host: true }, { token: i0.ElementRef }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxiSchedulerToolbarItemComponent, isStandalone: true, selector: "dxi-scheduler-toolbar-item", inputs: { cssClass: "cssClass", disabled: "disabled", html: "html", locateInMenu: "locateInMenu", location: "location", menuItemTemplate: "menuItemTemplate", name: "name", options: "options", showText: "showText", template: "template", text: "text", visible: "visible", widget: "widget" }, providers: [
            NestedOptionHost,
            DxTemplateHost,
            {
                provide: PROPERTY_TOKEN_items,
                useExisting: DxiSchedulerToolbarItemComponent,
            }
        ], usesInheritance: true, ngImport: i0, template: '<ng-content></ng-content>', isInline: true, styles: [":host{display:block}\n"], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiSchedulerToolbarItemComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxi-scheduler-toolbar-item', template: '<ng-content></ng-content>', imports: [DxIntegrationModule], providers: [
                        NestedOptionHost,
                        DxTemplateHost,
                        {
                            provide: PROPERTY_TOKEN_items,
                            useExisting: DxiSchedulerToolbarItemComponent,
                        }
                    ], styles: [":host{display:block}\n"] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }, { type: i0.Renderer2 }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [DOCUMENT]
                }] }, { type: i1.DxTemplateHost, decorators: [{
                    type: Host
                }] }, { type: i0.ElementRef }], propDecorators: { cssClass: [{
                type: Input
            }], disabled: [{
                type: Input
            }], html: [{
                type: Input
            }], locateInMenu: [{
                type: Input
            }], location: [{
                type: Input
            }], menuItemTemplate: [{
                type: Input
            }], name: [{
                type: Input
            }], options: [{
                type: Input
            }], showText: [{
                type: Input
            }], template: [{
                type: Input
            }], text: [{
                type: Input
            }], visible: [{
                type: Input
            }], widget: [{
                type: Input
            }] } });
class DxiSchedulerToolbarItemModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiSchedulerToolbarItemModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxiSchedulerToolbarItemModule, imports: [DxiSchedulerToolbarItemComponent], exports: [DxiSchedulerToolbarItemComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiSchedulerToolbarItemModule, imports: [DxiSchedulerToolbarItemComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiSchedulerToolbarItemModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxiSchedulerToolbarItemComponent
                    ],
                    exports: [
                        DxiSchedulerToolbarItemComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoSchedulerToolbarComponent extends NestedOption {
    set _itemsContentChildren(value) {
        this.setChildren('items', value);
    }
    get disabled() {
        return this._getOption('disabled');
    }
    set disabled(value) {
        this._setOption('disabled', value);
    }
    get items() {
        return this._getOption('items');
    }
    set items(value) {
        this._setOption('items', value);
    }
    get multiline() {
        return this._getOption('multiline');
    }
    set multiline(value) {
        this._setOption('multiline', value);
    }
    get visible() {
        return this._getOption('visible');
    }
    set visible(value) {
        this._setOption('visible', value);
    }
    get _optionPath() {
        return 'toolbar';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoSchedulerToolbarComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoSchedulerToolbarComponent, isStandalone: true, selector: "dxo-scheduler-toolbar", inputs: { disabled: "disabled", items: "items", multiline: "multiline", visible: "visible" }, providers: [NestedOptionHost], queries: [{ propertyName: "_itemsContentChildren", predicate: PROPERTY_TOKEN_items }], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoSchedulerToolbarComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-scheduler-toolbar', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { _itemsContentChildren: [{
                type: ContentChildren,
                args: [PROPERTY_TOKEN_items]
            }], disabled: [{
                type: Input
            }], items: [{
                type: Input
            }], multiline: [{
                type: Input
            }], visible: [{
                type: Input
            }] } });
class DxoSchedulerToolbarModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoSchedulerToolbarModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoSchedulerToolbarModule, imports: [DxoSchedulerToolbarComponent], exports: [DxoSchedulerToolbarComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoSchedulerToolbarModule, imports: [DxoSchedulerToolbarComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoSchedulerToolbarModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoSchedulerToolbarComponent
                    ],
                    exports: [
                        DxoSchedulerToolbarComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxiSchedulerValidationRuleComponent extends CollectionNestedOption {
    get message() {
        return this._getOption('message');
    }
    set message(value) {
        this._setOption('message', value);
    }
    get trim() {
        return this._getOption('trim');
    }
    set trim(value) {
        this._setOption('trim', value);
    }
    get type() {
        return this._getOption('type');
    }
    set type(value) {
        this._setOption('type', value);
    }
    get ignoreEmptyValue() {
        return this._getOption('ignoreEmptyValue');
    }
    set ignoreEmptyValue(value) {
        this._setOption('ignoreEmptyValue', value);
    }
    get max() {
        return this._getOption('max');
    }
    set max(value) {
        this._setOption('max', value);
    }
    get min() {
        return this._getOption('min');
    }
    set min(value) {
        this._setOption('min', value);
    }
    get reevaluate() {
        return this._getOption('reevaluate');
    }
    set reevaluate(value) {
        this._setOption('reevaluate', value);
    }
    get validationCallback() {
        return this._getOption('validationCallback');
    }
    set validationCallback(value) {
        this._setOption('validationCallback', value);
    }
    get comparisonTarget() {
        return this._getOption('comparisonTarget');
    }
    set comparisonTarget(value) {
        this._setOption('comparisonTarget', value);
    }
    get comparisonType() {
        return this._getOption('comparisonType');
    }
    set comparisonType(value) {
        this._setOption('comparisonType', value);
    }
    get pattern() {
        return this._getOption('pattern');
    }
    set pattern(value) {
        this._setOption('pattern', value);
    }
    get _optionPath() {
        return 'validationRules';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
        this.type = 'required';
    }
    ngOnDestroy() {
        this._deleteRemovedOptions(this._fullOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiSchedulerValidationRuleComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxiSchedulerValidationRuleComponent, isStandalone: true, selector: "dxi-scheduler-validation-rule", inputs: { message: "message", trim: "trim", type: "type", ignoreEmptyValue: "ignoreEmptyValue", max: "max", min: "min", reevaluate: "reevaluate", validationCallback: "validationCallback", comparisonTarget: "comparisonTarget", comparisonType: "comparisonType", pattern: "pattern" }, providers: [
            NestedOptionHost,
            {
                provide: PROPERTY_TOKEN_validationRules,
                useExisting: DxiSchedulerValidationRuleComponent,
            }
        ], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiSchedulerValidationRuleComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxi-scheduler-validation-rule', template: '', imports: [DxIntegrationModule], providers: [
                        NestedOptionHost,
                        {
                            provide: PROPERTY_TOKEN_validationRules,
                            useExisting: DxiSchedulerValidationRuleComponent,
                        }
                    ] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { message: [{
                type: Input
            }], trim: [{
                type: Input
            }], type: [{
                type: Input
            }], ignoreEmptyValue: [{
                type: Input
            }], max: [{
                type: Input
            }], min: [{
                type: Input
            }], reevaluate: [{
                type: Input
            }], validationCallback: [{
                type: Input
            }], comparisonTarget: [{
                type: Input
            }], comparisonType: [{
                type: Input
            }], pattern: [{
                type: Input
            }] } });
class DxiSchedulerValidationRuleModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiSchedulerValidationRuleModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxiSchedulerValidationRuleModule, imports: [DxiSchedulerValidationRuleComponent], exports: [DxiSchedulerValidationRuleComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiSchedulerValidationRuleModule, imports: [DxiSchedulerValidationRuleComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiSchedulerValidationRuleModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxiSchedulerValidationRuleComponent
                    ],
                    exports: [
                        DxiSchedulerValidationRuleComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxiSchedulerViewComponent extends CollectionNestedOption {
    get agendaDuration() {
        return this._getOption('agendaDuration');
    }
    set agendaDuration(value) {
        this._setOption('agendaDuration', value);
    }
    get allDayPanelMode() {
        return this._getOption('allDayPanelMode');
    }
    set allDayPanelMode(value) {
        this._setOption('allDayPanelMode', value);
    }
    get appointmentCollectorTemplate() {
        return this._getOption('appointmentCollectorTemplate');
    }
    set appointmentCollectorTemplate(value) {
        this._setOption('appointmentCollectorTemplate', value);
    }
    get appointmentTemplate() {
        return this._getOption('appointmentTemplate');
    }
    set appointmentTemplate(value) {
        this._setOption('appointmentTemplate', value);
    }
    get appointmentTooltipTemplate() {
        return this._getOption('appointmentTooltipTemplate');
    }
    set appointmentTooltipTemplate(value) {
        this._setOption('appointmentTooltipTemplate', value);
    }
    get cellDuration() {
        return this._getOption('cellDuration');
    }
    set cellDuration(value) {
        this._setOption('cellDuration', value);
    }
    get dataCellTemplate() {
        return this._getOption('dataCellTemplate');
    }
    set dataCellTemplate(value) {
        this._setOption('dataCellTemplate', value);
    }
    get dateCellTemplate() {
        return this._getOption('dateCellTemplate');
    }
    set dateCellTemplate(value) {
        this._setOption('dateCellTemplate', value);
    }
    get endDayHour() {
        return this._getOption('endDayHour');
    }
    set endDayHour(value) {
        this._setOption('endDayHour', value);
    }
    get firstDayOfWeek() {
        return this._getOption('firstDayOfWeek');
    }
    set firstDayOfWeek(value) {
        this._setOption('firstDayOfWeek', value);
    }
    get groupByDate() {
        return this._getOption('groupByDate');
    }
    set groupByDate(value) {
        this._setOption('groupByDate', value);
    }
    get groupOrientation() {
        return this._getOption('groupOrientation');
    }
    set groupOrientation(value) {
        this._setOption('groupOrientation', value);
    }
    get groups() {
        return this._getOption('groups');
    }
    set groups(value) {
        this._setOption('groups', value);
    }
    get hiddenWeekDays() {
        return this._getOption('hiddenWeekDays');
    }
    set hiddenWeekDays(value) {
        this._setOption('hiddenWeekDays', value);
    }
    get intervalCount() {
        return this._getOption('intervalCount');
    }
    set intervalCount(value) {
        this._setOption('intervalCount', value);
    }
    get maxAppointmentsPerCell() {
        return this._getOption('maxAppointmentsPerCell');
    }
    set maxAppointmentsPerCell(value) {
        this._setOption('maxAppointmentsPerCell', value);
    }
    get name() {
        return this._getOption('name');
    }
    set name(value) {
        this._setOption('name', value);
    }
    get offset() {
        return this._getOption('offset');
    }
    set offset(value) {
        this._setOption('offset', value);
    }
    get resourceCellTemplate() {
        return this._getOption('resourceCellTemplate');
    }
    set resourceCellTemplate(value) {
        this._setOption('resourceCellTemplate', value);
    }
    get scrolling() {
        return this._getOption('scrolling');
    }
    set scrolling(value) {
        this._setOption('scrolling', value);
    }
    get snapToCellsMode() {
        return this._getOption('snapToCellsMode');
    }
    set snapToCellsMode(value) {
        this._setOption('snapToCellsMode', value);
    }
    get startDate() {
        return this._getOption('startDate');
    }
    set startDate(value) {
        this._setOption('startDate', value);
    }
    get startDayHour() {
        return this._getOption('startDayHour');
    }
    set startDayHour(value) {
        this._setOption('startDayHour', value);
    }
    get timeCellTemplate() {
        return this._getOption('timeCellTemplate');
    }
    set timeCellTemplate(value) {
        this._setOption('timeCellTemplate', value);
    }
    get type() {
        return this._getOption('type');
    }
    set type(value) {
        this._setOption('type', value);
    }
    get _optionPath() {
        return 'views';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnDestroy() {
        this._deleteRemovedOptions(this._fullOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiSchedulerViewComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxiSchedulerViewComponent, isStandalone: true, selector: "dxi-scheduler-view", inputs: { agendaDuration: "agendaDuration", allDayPanelMode: "allDayPanelMode", appointmentCollectorTemplate: "appointmentCollectorTemplate", appointmentTemplate: "appointmentTemplate", appointmentTooltipTemplate: "appointmentTooltipTemplate", cellDuration: "cellDuration", dataCellTemplate: "dataCellTemplate", dateCellTemplate: "dateCellTemplate", endDayHour: "endDayHour", firstDayOfWeek: "firstDayOfWeek", groupByDate: "groupByDate", groupOrientation: "groupOrientation", groups: "groups", hiddenWeekDays: "hiddenWeekDays", intervalCount: "intervalCount", maxAppointmentsPerCell: "maxAppointmentsPerCell", name: "name", offset: "offset", resourceCellTemplate: "resourceCellTemplate", scrolling: "scrolling", snapToCellsMode: "snapToCellsMode", startDate: "startDate", startDayHour: "startDayHour", timeCellTemplate: "timeCellTemplate", type: "type" }, providers: [
            NestedOptionHost,
            {
                provide: PROPERTY_TOKEN_views,
                useExisting: DxiSchedulerViewComponent,
            }
        ], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiSchedulerViewComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxi-scheduler-view', template: '', imports: [DxIntegrationModule], providers: [
                        NestedOptionHost,
                        {
                            provide: PROPERTY_TOKEN_views,
                            useExisting: DxiSchedulerViewComponent,
                        }
                    ] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { agendaDuration: [{
                type: Input
            }], allDayPanelMode: [{
                type: Input
            }], appointmentCollectorTemplate: [{
                type: Input
            }], appointmentTemplate: [{
                type: Input
            }], appointmentTooltipTemplate: [{
                type: Input
            }], cellDuration: [{
                type: Input
            }], dataCellTemplate: [{
                type: Input
            }], dateCellTemplate: [{
                type: Input
            }], endDayHour: [{
                type: Input
            }], firstDayOfWeek: [{
                type: Input
            }], groupByDate: [{
                type: Input
            }], groupOrientation: [{
                type: Input
            }], groups: [{
                type: Input
            }], hiddenWeekDays: [{
                type: Input
            }], intervalCount: [{
                type: Input
            }], maxAppointmentsPerCell: [{
                type: Input
            }], name: [{
                type: Input
            }], offset: [{
                type: Input
            }], resourceCellTemplate: [{
                type: Input
            }], scrolling: [{
                type: Input
            }], snapToCellsMode: [{
                type: Input
            }], startDate: [{
                type: Input
            }], startDayHour: [{
                type: Input
            }], timeCellTemplate: [{
                type: Input
            }], type: [{
                type: Input
            }] } });
class DxiSchedulerViewModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiSchedulerViewModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxiSchedulerViewModule, imports: [DxiSchedulerViewComponent], exports: [DxiSchedulerViewComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiSchedulerViewModule, imports: [DxiSchedulerViewComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiSchedulerViewModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxiSchedulerViewComponent
                    ],
                    exports: [
                        DxiSchedulerViewComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

/**
 * Generated bundle index. Do not edit.
 */

export { DxiSchedulerAsyncRuleComponent, DxiSchedulerAsyncRuleModule, DxiSchedulerButtonItemComponent, DxiSchedulerButtonItemModule, DxiSchedulerCompareRuleComponent, DxiSchedulerCompareRuleModule, DxiSchedulerCustomRuleComponent, DxiSchedulerCustomRuleModule, DxiSchedulerEmailRuleComponent, DxiSchedulerEmailRuleModule, DxiSchedulerEmptyItemComponent, DxiSchedulerEmptyItemModule, DxiSchedulerGroupItemComponent, DxiSchedulerGroupItemModule, DxiSchedulerItemComponent, DxiSchedulerItemModule, DxiSchedulerNumericRuleComponent, DxiSchedulerNumericRuleModule, DxiSchedulerOptionsItemComponent, DxiSchedulerOptionsItemModule, DxiSchedulerPatternRuleComponent, DxiSchedulerPatternRuleModule, DxiSchedulerRangeRuleComponent, DxiSchedulerRangeRuleModule, DxiSchedulerRequiredRuleComponent, DxiSchedulerRequiredRuleModule, DxiSchedulerResourceComponent, DxiSchedulerResourceModule, DxiSchedulerSimpleItemComponent, DxiSchedulerSimpleItemModule, DxiSchedulerStringLengthRuleComponent, DxiSchedulerStringLengthRuleModule, DxiSchedulerTabComponent, DxiSchedulerTabModule, DxiSchedulerTabPanelOptionsItemComponent, DxiSchedulerTabPanelOptionsItemModule, DxiSchedulerTabbedItemComponent, DxiSchedulerTabbedItemModule, DxiSchedulerToolbarItemComponent, DxiSchedulerToolbarItemModule, DxiSchedulerValidationRuleComponent, DxiSchedulerValidationRuleModule, DxiSchedulerViewComponent, DxiSchedulerViewModule, DxoSchedulerAIOptionsComponent, DxoSchedulerAIOptionsModule, DxoSchedulerAppointmentDraggingComponent, DxoSchedulerAppointmentDraggingModule, DxoSchedulerButtonOptionsComponent, DxoSchedulerButtonOptionsModule, DxoSchedulerColCountByScreenComponent, DxoSchedulerColCountByScreenModule, DxoSchedulerEditingComponent, DxoSchedulerEditingModule, DxoSchedulerFormComponent, DxoSchedulerFormModule, DxoSchedulerLabelComponent, DxoSchedulerLabelModule, DxoSchedulerOptionsComponent, DxoSchedulerOptionsModule, DxoSchedulerScrollingComponent, DxoSchedulerScrollingModule, DxoSchedulerTabPanelOptionsComponent, DxoSchedulerTabPanelOptionsModule, DxoSchedulerToolbarComponent, DxoSchedulerToolbarModule };
//# sourceMappingURL=devextreme-angular-ui-scheduler-nested.mjs.map
