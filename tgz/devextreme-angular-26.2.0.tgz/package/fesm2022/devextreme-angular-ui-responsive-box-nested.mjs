import * as i0 from '@angular/core';
import { Input, SkipSelf, Host, Component, NgModule, ContentChildren, Inject } from '@angular/core';
import * as i1 from 'devextreme-angular/core';
import { CollectionNestedOption, DxIntegrationModule, NestedOptionHost, extractTemplate, DxTemplateHost } from 'devextreme-angular/core';
import { PROPERTY_TOKEN_cols, PROPERTY_TOKEN_location, PROPERTY_TOKEN_items, PROPERTY_TOKEN_rows } from 'devextreme-angular/core/tokens';
import { DOCUMENT } from '@angular/common';

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxiResponsiveBoxColComponent extends CollectionNestedOption {
    get baseSize() {
        return this._getOption('baseSize');
    }
    set baseSize(value) {
        this._setOption('baseSize', value);
    }
    get ratio() {
        return this._getOption('ratio');
    }
    set ratio(value) {
        this._setOption('ratio', value);
    }
    get screen() {
        return this._getOption('screen');
    }
    set screen(value) {
        this._setOption('screen', value);
    }
    get shrink() {
        return this._getOption('shrink');
    }
    set shrink(value) {
        this._setOption('shrink', value);
    }
    get _optionPath() {
        return 'cols';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnDestroy() {
        this._deleteRemovedOptions(this._fullOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiResponsiveBoxColComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxiResponsiveBoxColComponent, isStandalone: true, selector: "dxi-responsive-box-col", inputs: { baseSize: "baseSize", ratio: "ratio", screen: "screen", shrink: "shrink" }, providers: [
            NestedOptionHost,
            {
                provide: PROPERTY_TOKEN_cols,
                useExisting: DxiResponsiveBoxColComponent,
            }
        ], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiResponsiveBoxColComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxi-responsive-box-col', template: '', imports: [DxIntegrationModule], providers: [
                        NestedOptionHost,
                        {
                            provide: PROPERTY_TOKEN_cols,
                            useExisting: DxiResponsiveBoxColComponent,
                        }
                    ] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { baseSize: [{
                type: Input
            }], ratio: [{
                type: Input
            }], screen: [{
                type: Input
            }], shrink: [{
                type: Input
            }] } });
class DxiResponsiveBoxColModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiResponsiveBoxColModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxiResponsiveBoxColModule, imports: [DxiResponsiveBoxColComponent], exports: [DxiResponsiveBoxColComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiResponsiveBoxColModule, imports: [DxiResponsiveBoxColComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiResponsiveBoxColModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxiResponsiveBoxColComponent
                    ],
                    exports: [
                        DxiResponsiveBoxColComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxiResponsiveBoxItemComponent extends CollectionNestedOption {
    set _locationContentChildren(value) {
        this.setChildren('location', value);
    }
    get disabled() {
        return this._getOption('disabled');
    }
    set disabled(value) {
        this._setOption('disabled', value);
    }
    get html() {
        return this._getOption('html');
    }
    set html(value) {
        this._setOption('html', value);
    }
    get location() {
        return this._getOption('location');
    }
    set location(value) {
        this._setOption('location', value);
    }
    get template() {
        return this._getOption('template');
    }
    set template(value) {
        this._setOption('template', value);
    }
    get text() {
        return this._getOption('text');
    }
    set text(value) {
        this._setOption('text', value);
    }
    get visible() {
        return this._getOption('visible');
    }
    set visible(value) {
        this._setOption('visible', value);
    }
    get _optionPath() {
        return 'items';
    }
    constructor(parentOptionHost, optionHost, renderer, document, templateHost, element) {
        super();
        this.renderer = renderer;
        this.document = document;
        this.element = element;
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
        templateHost.setHost(this);
    }
    setTemplate(template) {
        this.template = template;
    }
    ngAfterViewInit() {
        extractTemplate(this, this.element, this.renderer, this.document);
    }
    ngOnDestroy() {
        this._deleteRemovedOptions(this._fullOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiResponsiveBoxItemComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }, { token: i0.Renderer2 }, { token: DOCUMENT }, { token: i1.DxTemplateHost, host: true }, { token: i0.ElementRef }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxiResponsiveBoxItemComponent, isStandalone: true, selector: "dxi-responsive-box-item", inputs: { disabled: "disabled", html: "html", location: "location", template: "template", text: "text", visible: "visible" }, providers: [
            NestedOptionHost,
            DxTemplateHost,
            {
                provide: PROPERTY_TOKEN_items,
                useExisting: DxiResponsiveBoxItemComponent,
            }
        ], queries: [{ propertyName: "_locationContentChildren", predicate: PROPERTY_TOKEN_location }], usesInheritance: true, ngImport: i0, template: '<ng-content></ng-content>', isInline: true, styles: [":host{display:block}\n"], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiResponsiveBoxItemComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxi-responsive-box-item', template: '<ng-content></ng-content>', imports: [DxIntegrationModule], providers: [
                        NestedOptionHost,
                        DxTemplateHost,
                        {
                            provide: PROPERTY_TOKEN_items,
                            useExisting: DxiResponsiveBoxItemComponent,
                        }
                    ], styles: [":host{display:block}\n"] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }, { type: i0.Renderer2 }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [DOCUMENT]
                }] }, { type: i1.DxTemplateHost, decorators: [{
                    type: Host
                }] }, { type: i0.ElementRef }], propDecorators: { _locationContentChildren: [{
                type: ContentChildren,
                args: [PROPERTY_TOKEN_location]
            }], disabled: [{
                type: Input
            }], html: [{
                type: Input
            }], location: [{
                type: Input
            }], template: [{
                type: Input
            }], text: [{
                type: Input
            }], visible: [{
                type: Input
            }] } });
class DxiResponsiveBoxItemModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiResponsiveBoxItemModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxiResponsiveBoxItemModule, imports: [DxiResponsiveBoxItemComponent], exports: [DxiResponsiveBoxItemComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiResponsiveBoxItemModule, imports: [DxiResponsiveBoxItemComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiResponsiveBoxItemModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxiResponsiveBoxItemComponent
                    ],
                    exports: [
                        DxiResponsiveBoxItemComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxiResponsiveBoxLocationComponent extends CollectionNestedOption {
    get col() {
        return this._getOption('col');
    }
    set col(value) {
        this._setOption('col', value);
    }
    get colspan() {
        return this._getOption('colspan');
    }
    set colspan(value) {
        this._setOption('colspan', value);
    }
    get row() {
        return this._getOption('row');
    }
    set row(value) {
        this._setOption('row', value);
    }
    get rowspan() {
        return this._getOption('rowspan');
    }
    set rowspan(value) {
        this._setOption('rowspan', value);
    }
    get screen() {
        return this._getOption('screen');
    }
    set screen(value) {
        this._setOption('screen', value);
    }
    get _optionPath() {
        return 'location';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnDestroy() {
        this._deleteRemovedOptions(this._fullOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiResponsiveBoxLocationComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxiResponsiveBoxLocationComponent, isStandalone: true, selector: "dxi-responsive-box-location", inputs: { col: "col", colspan: "colspan", row: "row", rowspan: "rowspan", screen: "screen" }, providers: [
            NestedOptionHost,
            {
                provide: PROPERTY_TOKEN_location,
                useExisting: DxiResponsiveBoxLocationComponent,
            }
        ], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiResponsiveBoxLocationComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxi-responsive-box-location', template: '', imports: [DxIntegrationModule], providers: [
                        NestedOptionHost,
                        {
                            provide: PROPERTY_TOKEN_location,
                            useExisting: DxiResponsiveBoxLocationComponent,
                        }
                    ] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { col: [{
                type: Input
            }], colspan: [{
                type: Input
            }], row: [{
                type: Input
            }], rowspan: [{
                type: Input
            }], screen: [{
                type: Input
            }] } });
class DxiResponsiveBoxLocationModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiResponsiveBoxLocationModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxiResponsiveBoxLocationModule, imports: [DxiResponsiveBoxLocationComponent], exports: [DxiResponsiveBoxLocationComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiResponsiveBoxLocationModule, imports: [DxiResponsiveBoxLocationComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiResponsiveBoxLocationModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxiResponsiveBoxLocationComponent
                    ],
                    exports: [
                        DxiResponsiveBoxLocationComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxiResponsiveBoxRowComponent extends CollectionNestedOption {
    get baseSize() {
        return this._getOption('baseSize');
    }
    set baseSize(value) {
        this._setOption('baseSize', value);
    }
    get ratio() {
        return this._getOption('ratio');
    }
    set ratio(value) {
        this._setOption('ratio', value);
    }
    get screen() {
        return this._getOption('screen');
    }
    set screen(value) {
        this._setOption('screen', value);
    }
    get shrink() {
        return this._getOption('shrink');
    }
    set shrink(value) {
        this._setOption('shrink', value);
    }
    get _optionPath() {
        return 'rows';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnDestroy() {
        this._deleteRemovedOptions(this._fullOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiResponsiveBoxRowComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxiResponsiveBoxRowComponent, isStandalone: true, selector: "dxi-responsive-box-row", inputs: { baseSize: "baseSize", ratio: "ratio", screen: "screen", shrink: "shrink" }, providers: [
            NestedOptionHost,
            {
                provide: PROPERTY_TOKEN_rows,
                useExisting: DxiResponsiveBoxRowComponent,
            }
        ], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiResponsiveBoxRowComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxi-responsive-box-row', template: '', imports: [DxIntegrationModule], providers: [
                        NestedOptionHost,
                        {
                            provide: PROPERTY_TOKEN_rows,
                            useExisting: DxiResponsiveBoxRowComponent,
                        }
                    ] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { baseSize: [{
                type: Input
            }], ratio: [{
                type: Input
            }], screen: [{
                type: Input
            }], shrink: [{
                type: Input
            }] } });
class DxiResponsiveBoxRowModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiResponsiveBoxRowModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxiResponsiveBoxRowModule, imports: [DxiResponsiveBoxRowComponent], exports: [DxiResponsiveBoxRowComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiResponsiveBoxRowModule, imports: [DxiResponsiveBoxRowComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiResponsiveBoxRowModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxiResponsiveBoxRowComponent
                    ],
                    exports: [
                        DxiResponsiveBoxRowComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

/**
 * Generated bundle index. Do not edit.
 */

export { DxiResponsiveBoxColComponent, DxiResponsiveBoxColModule, DxiResponsiveBoxItemComponent, DxiResponsiveBoxItemModule, DxiResponsiveBoxLocationComponent, DxiResponsiveBoxLocationModule, DxiResponsiveBoxRowComponent, DxiResponsiveBoxRowModule };
//# sourceMappingURL=devextreme-angular-ui-responsive-box-nested.mjs.map
