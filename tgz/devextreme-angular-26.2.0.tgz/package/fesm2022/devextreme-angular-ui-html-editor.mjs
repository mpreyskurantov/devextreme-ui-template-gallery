import * as i0 from '@angular/core';
import { forwardRef, PLATFORM_ID, HostListener, Output, Input, ContentChildren, Inject, Component, NgModule } from '@angular/core';
import DxHtmlEditor from 'devextreme/ui/html_editor';
import { NG_VALUE_ACCESSOR } from '@angular/forms';
import * as i1 from 'devextreme-angular/core';
import { DxComponent, DxIntegrationModule, DxTemplateHost, WatcherHelper, NestedOptionHost, IterableDifferHelper, DxTemplateModule } from 'devextreme-angular/core';
import { DxoConverterModule, DxoImageUploadModule, DxoFileUploaderOptionsModule, DxiTabModule, DxoMediaResizingModule, DxiMentionModule, DxoTableContextMenuModule, DxiItemModule, DxoTableResizingModule, DxoToolbarModule, DxiCommandModule, DxoVariablesModule } from 'devextreme-angular/ui/nested';
import { DxiHtmlEditorCommandModule, DxoHtmlEditorConverterModule, DxoHtmlEditorFileUploaderOptionsModule, DxoHtmlEditorImageUploadModule, DxiHtmlEditorItemModule, DxoHtmlEditorMediaResizingModule, DxiHtmlEditorMentionModule, DxiHtmlEditorTabModule, DxoHtmlEditorTableContextMenuModule, DxiHtmlEditorTableContextMenuItemModule, DxoHtmlEditorTableResizingModule, DxoHtmlEditorToolbarModule, DxiHtmlEditorToolbarItemModule, DxoHtmlEditorVariablesModule } from 'devextreme-angular/ui/html-editor/nested';
export * from 'devextreme-angular/ui/html-editor/nested';
import { PROPERTY_TOKEN_commands, PROPERTY_TOKEN_items, PROPERTY_TOKEN_mentions, PROPERTY_TOKEN_tabs } from 'devextreme-angular/core/tokens';

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
const CUSTOM_VALUE_ACCESSOR_PROVIDER = {
    provide: NG_VALUE_ACCESSOR,
    useExisting: forwardRef(() => DxHtmlEditorComponent),
    multi: true
};
/**
 * [descr:dxHtmlEditor]

 */
class DxHtmlEditorComponent extends DxComponent {
    set _commandsContentChildren(value) {
        this.setChildren('commands', value);
    }
    set _itemsContentChildren(value) {
        this.setChildren('items', value);
    }
    set _mentionsContentChildren(value) {
        this.setChildren('mentions', value);
    }
    set _tabsContentChildren(value) {
        this.setChildren('tabs', value);
    }
    /**
     * [descr:WidgetOptions.accessKey]
    
     */
    get accessKey() {
        return this._getOption('accessKey');
    }
    set accessKey(value) {
        this._setOption('accessKey', value);
    }
    /**
     * [descr:WidgetOptions.activeStateEnabled]
    
     */
    get activeStateEnabled() {
        return this._getOption('activeStateEnabled');
    }
    set activeStateEnabled(value) {
        this._setOption('activeStateEnabled', value);
    }
    /**
     * [descr:dxHtmlEditorOptions.aiIntegration]
    
     */
    get aiIntegration() {
        return this._getOption('aiIntegration');
    }
    set aiIntegration(value) {
        this._setOption('aiIntegration', value);
    }
    /**
     * [descr:dxHtmlEditorOptions.allowSoftLineBreak]
    
     */
    get allowSoftLineBreak() {
        return this._getOption('allowSoftLineBreak');
    }
    set allowSoftLineBreak(value) {
        this._setOption('allowSoftLineBreak', value);
    }
    /**
     * [descr:dxHtmlEditorOptions.converter]
    
     */
    get converter() {
        return this._getOption('converter');
    }
    set converter(value) {
        this._setOption('converter', value);
    }
    /**
     * [descr:dxHtmlEditorOptions.customizeModules]
    
     */
    get customizeModules() {
        return this._getOption('customizeModules');
    }
    set customizeModules(value) {
        this._setOption('customizeModules', value);
    }
    /**
     * [descr:WidgetOptions.disabled]
    
     */
    get disabled() {
        return this._getOption('disabled');
    }
    set disabled(value) {
        this._setOption('disabled', value);
    }
    /**
     * [descr:DOMComponentOptions.elementAttr]
    
     */
    get elementAttr() {
        return this._getOption('elementAttr');
    }
    set elementAttr(value) {
        this._setOption('elementAttr', value);
    }
    /**
     * [descr:dxHtmlEditorOptions.focusStateEnabled]
    
     */
    get focusStateEnabled() {
        return this._getOption('focusStateEnabled');
    }
    set focusStateEnabled(value) {
        this._setOption('focusStateEnabled', value);
    }
    /**
     * [descr:DOMComponentOptions.height]
    
     */
    get height() {
        return this._getOption('height');
    }
    set height(value) {
        this._setOption('height', value);
    }
    /**
     * [descr:WidgetOptions.hint]
    
     */
    get hint() {
        return this._getOption('hint');
    }
    set hint(value) {
        this._setOption('hint', value);
    }
    /**
     * [descr:WidgetOptions.hoverStateEnabled]
    
     */
    get hoverStateEnabled() {
        return this._getOption('hoverStateEnabled');
    }
    set hoverStateEnabled(value) {
        this._setOption('hoverStateEnabled', value);
    }
    /**
     * [descr:dxHtmlEditorOptions.imageUpload]
    
     */
    get imageUpload() {
        return this._getOption('imageUpload');
    }
    set imageUpload(value) {
        this._setOption('imageUpload', value);
    }
    /**
     * [descr:EditorOptions.isDirty]
    
     */
    get isDirty() {
        return this._getOption('isDirty');
    }
    set isDirty(value) {
        this._setOption('isDirty', value);
    }
    /**
     * [descr:EditorOptions.isValid]
    
     */
    get isValid() {
        return this._getOption('isValid');
    }
    set isValid(value) {
        this._setOption('isValid', value);
    }
    /**
     * [descr:dxHtmlEditorOptions.mediaResizing]
    
     */
    get mediaResizing() {
        return this._getOption('mediaResizing');
    }
    set mediaResizing(value) {
        this._setOption('mediaResizing', value);
    }
    /**
     * [descr:dxHtmlEditorOptions.mentions]
    
     */
    get mentions() {
        return this._getOption('mentions');
    }
    set mentions(value) {
        this._setOption('mentions', value);
    }
    /**
     * [descr:dxHtmlEditorOptions.name]
    
     */
    get name() {
        return this._getOption('name');
    }
    set name(value) {
        this._setOption('name', value);
    }
    /**
     * [descr:dxHtmlEditorOptions.placeholder]
    
     */
    get placeholder() {
        return this._getOption('placeholder');
    }
    set placeholder(value) {
        this._setOption('placeholder', value);
    }
    /**
     * [descr:EditorOptions.readOnly]
    
     */
    get readOnly() {
        return this._getOption('readOnly');
    }
    set readOnly(value) {
        this._setOption('readOnly', value);
    }
    /**
     * [descr:DOMComponentOptions.rtlEnabled]
    
     */
    get rtlEnabled() {
        return this._getOption('rtlEnabled');
    }
    set rtlEnabled(value) {
        this._setOption('rtlEnabled', value);
    }
    /**
     * [descr:dxHtmlEditorOptions.stylingMode]
    
     */
    get stylingMode() {
        return this._getOption('stylingMode');
    }
    set stylingMode(value) {
        this._setOption('stylingMode', value);
    }
    /**
     * [descr:WidgetOptions.tabIndex]
    
     */
    get tabIndex() {
        return this._getOption('tabIndex');
    }
    set tabIndex(value) {
        this._setOption('tabIndex', value);
    }
    /**
     * [descr:dxHtmlEditorOptions.tableContextMenu]
    
     */
    get tableContextMenu() {
        return this._getOption('tableContextMenu');
    }
    set tableContextMenu(value) {
        this._setOption('tableContextMenu', value);
    }
    /**
     * [descr:dxHtmlEditorOptions.tableResizing]
    
     */
    get tableResizing() {
        return this._getOption('tableResizing');
    }
    set tableResizing(value) {
        this._setOption('tableResizing', value);
    }
    /**
     * [descr:dxHtmlEditorOptions.toolbar]
    
     */
    get toolbar() {
        return this._getOption('toolbar');
    }
    set toolbar(value) {
        this._setOption('toolbar', value);
    }
    /**
     * [descr:EditorOptions.validationError]
    
     */
    get validationError() {
        return this._getOption('validationError');
    }
    set validationError(value) {
        this._setOption('validationError', value);
    }
    /**
     * [descr:EditorOptions.validationErrors]
    
     */
    get validationErrors() {
        return this._getOption('validationErrors');
    }
    set validationErrors(value) {
        this._setOption('validationErrors', value);
    }
    /**
     * [descr:EditorOptions.validationMessageMode]
    
     */
    get validationMessageMode() {
        return this._getOption('validationMessageMode');
    }
    set validationMessageMode(value) {
        this._setOption('validationMessageMode', value);
    }
    /**
     * [descr:EditorOptions.validationMessagePosition]
    
     */
    get validationMessagePosition() {
        return this._getOption('validationMessagePosition');
    }
    set validationMessagePosition(value) {
        this._setOption('validationMessagePosition', value);
    }
    /**
     * [descr:EditorOptions.validationStatus]
    
     */
    get validationStatus() {
        return this._getOption('validationStatus');
    }
    set validationStatus(value) {
        this._setOption('validationStatus', value);
    }
    /**
     * [descr:EditorOptions.value]
    
     */
    get value() {
        return this._getOption('value');
    }
    set value(value) {
        this._setOption('value', value);
    }
    /**
     * [descr:dxHtmlEditorOptions.variables]
    
     */
    get variables() {
        return this._getOption('variables');
    }
    set variables(value) {
        this._setOption('variables', value);
    }
    /**
     * [descr:WidgetOptions.visible]
    
     */
    get visible() {
        return this._getOption('visible');
    }
    set visible(value) {
        this._setOption('visible', value);
    }
    /**
     * [descr:DOMComponentOptions.width]
    
     */
    get width() {
        return this._getOption('width');
    }
    set width(value) {
        this._setOption('width', value);
    }
    change(_) { }
    constructor(elementRef, ngZone, templateHost, _watcherHelper, _idh, optionHost, transferState, platformId) {
        super(elementRef, ngZone, templateHost, _watcherHelper, transferState, platformId);
        this._watcherHelper = _watcherHelper;
        this._idh = _idh;
        this.instance = null;
        this.touched = (_) => { };
        this._createEventEmitters([
            { subscribe: 'contentReady', emit: 'onContentReady' },
            { subscribe: 'disposing', emit: 'onDisposing' },
            { subscribe: 'focusIn', emit: 'onFocusIn' },
            { subscribe: 'focusOut', emit: 'onFocusOut' },
            { subscribe: 'initialized', emit: 'onInitialized' },
            { subscribe: 'optionChanged', emit: 'onOptionChanged' },
            { subscribe: 'valueChanged', emit: 'onValueChanged' },
            { emit: 'accessKeyChange' },
            { emit: 'activeStateEnabledChange' },
            { emit: 'aiIntegrationChange' },
            { emit: 'allowSoftLineBreakChange' },
            { emit: 'converterChange' },
            { emit: 'customizeModulesChange' },
            { emit: 'disabledChange' },
            { emit: 'elementAttrChange' },
            { emit: 'focusStateEnabledChange' },
            { emit: 'heightChange' },
            { emit: 'hintChange' },
            { emit: 'hoverStateEnabledChange' },
            { emit: 'imageUploadChange' },
            { emit: 'isDirtyChange' },
            { emit: 'isValidChange' },
            { emit: 'mediaResizingChange' },
            { emit: 'mentionsChange' },
            { emit: 'nameChange' },
            { emit: 'placeholderChange' },
            { emit: 'readOnlyChange' },
            { emit: 'rtlEnabledChange' },
            { emit: 'stylingModeChange' },
            { emit: 'tabIndexChange' },
            { emit: 'tableContextMenuChange' },
            { emit: 'tableResizingChange' },
            { emit: 'toolbarChange' },
            { emit: 'validationErrorChange' },
            { emit: 'validationErrorsChange' },
            { emit: 'validationMessageModeChange' },
            { emit: 'validationMessagePositionChange' },
            { emit: 'validationStatusChange' },
            { emit: 'valueChange' },
            { emit: 'variablesChange' },
            { emit: 'visibleChange' },
            { emit: 'widthChange' },
            { emit: 'onBlur' }
        ]);
        this._idh.setHost(this);
        optionHost.setHost(this);
    }
    _createInstance(element, options) {
        return new DxHtmlEditor(element, options);
    }
    writeValue(value) {
        this.eventHelper.lockedValueChangeEvent = true;
        this.value = value;
        this.eventHelper.lockedValueChangeEvent = false;
    }
    setDisabledState(isDisabled) {
        this.disabled = isDisabled;
    }
    registerOnChange(fn) { this.change = fn; }
    registerOnTouched(fn) { this.touched = fn; }
    _createWidget(element) {
        super._createWidget(element);
        this.instance.on('focusOut', (e) => {
            this.eventHelper.fireNgEvent('onBlur', [e]);
        });
    }
    ngOnDestroy() {
        this._destroyWidget();
    }
    ngOnChanges(changes) {
        super.ngOnChanges(changes);
        this.setupChanges('mentions', changes);
        this.setupChanges('validationErrors', changes);
    }
    setupChanges(prop, changes) {
        if (!(prop in this._optionsToUpdate)) {
            this._idh.setup(prop, changes);
        }
    }
    ngDoCheck() {
        this._idh.doCheck('mentions');
        this._idh.doCheck('validationErrors');
        this._watcherHelper.checkWatchers();
        super.ngDoCheck();
        super.clearChangedOptions();
    }
    _setOption(name, value) {
        let isSetup = this._idh.setupSingle(name, value);
        let isChanged = this._idh.getChanges(name, value) !== null;
        if (isSetup || isChanged) {
            super._setOption(name, value);
        }
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxHtmlEditorComponent, deps: [{ token: i0.ElementRef }, { token: i0.NgZone }, { token: i1.DxTemplateHost }, { token: i1.WatcherHelper }, { token: i1.IterableDifferHelper }, { token: i1.NestedOptionHost }, { token: i0.TransferState }, { token: PLATFORM_ID }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxHtmlEditorComponent, isStandalone: true, selector: "dx-html-editor", inputs: { accessKey: "accessKey", activeStateEnabled: "activeStateEnabled", aiIntegration: "aiIntegration", allowSoftLineBreak: "allowSoftLineBreak", converter: "converter", customizeModules: "customizeModules", disabled: "disabled", elementAttr: "elementAttr", focusStateEnabled: "focusStateEnabled", height: "height", hint: "hint", hoverStateEnabled: "hoverStateEnabled", imageUpload: "imageUpload", isDirty: "isDirty", isValid: "isValid", mediaResizing: "mediaResizing", mentions: "mentions", name: "name", placeholder: "placeholder", readOnly: "readOnly", rtlEnabled: "rtlEnabled", stylingMode: "stylingMode", tabIndex: "tabIndex", tableContextMenu: "tableContextMenu", tableResizing: "tableResizing", toolbar: "toolbar", validationError: "validationError", validationErrors: "validationErrors", validationMessageMode: "validationMessageMode", validationMessagePosition: "validationMessagePosition", validationStatus: "validationStatus", value: "value", variables: "variables", visible: "visible", width: "width" }, outputs: { onContentReady: "onContentReady", onDisposing: "onDisposing", onFocusIn: "onFocusIn", onFocusOut: "onFocusOut", onInitialized: "onInitialized", onOptionChanged: "onOptionChanged", onValueChanged: "onValueChanged", accessKeyChange: "accessKeyChange", activeStateEnabledChange: "activeStateEnabledChange", aiIntegrationChange: "aiIntegrationChange", allowSoftLineBreakChange: "allowSoftLineBreakChange", converterChange: "converterChange", customizeModulesChange: "customizeModulesChange", disabledChange: "disabledChange", elementAttrChange: "elementAttrChange", focusStateEnabledChange: "focusStateEnabledChange", heightChange: "heightChange", hintChange: "hintChange", hoverStateEnabledChange: "hoverStateEnabledChange", imageUploadChange: "imageUploadChange", isDirtyChange: "isDirtyChange", isValidChange: "isValidChange", mediaResizingChange: "mediaResizingChange", mentionsChange: "mentionsChange", nameChange: "nameChange", placeholderChange: "placeholderChange", readOnlyChange: "readOnlyChange", rtlEnabledChange: "rtlEnabledChange", stylingModeChange: "stylingModeChange", tabIndexChange: "tabIndexChange", tableContextMenuChange: "tableContextMenuChange", tableResizingChange: "tableResizingChange", toolbarChange: "toolbarChange", validationErrorChange: "validationErrorChange", validationErrorsChange: "validationErrorsChange", validationMessageModeChange: "validationMessageModeChange", validationMessagePositionChange: "validationMessagePositionChange", validationStatusChange: "validationStatusChange", valueChange: "valueChange", variablesChange: "variablesChange", visibleChange: "visibleChange", widthChange: "widthChange", onBlur: "onBlur" }, host: { attributes: { "ngSkipHydration": "true" }, listeners: { "valueChange": "change($event)", "onBlur": "touched($event)" } }, providers: [
            DxTemplateHost,
            WatcherHelper,
            CUSTOM_VALUE_ACCESSOR_PROVIDER,
            NestedOptionHost,
            IterableDifferHelper
        ], queries: [{ propertyName: "_commandsContentChildren", predicate: PROPERTY_TOKEN_commands }, { propertyName: "_itemsContentChildren", predicate: PROPERTY_TOKEN_items }, { propertyName: "_mentionsContentChildren", predicate: PROPERTY_TOKEN_mentions }, { propertyName: "_tabsContentChildren", predicate: PROPERTY_TOKEN_tabs }], usesInheritance: true, usesOnChanges: true, ngImport: i0, template: '<ng-content></ng-content>', isInline: true, dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxHtmlEditorComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'dx-html-editor',
                    template: '<ng-content></ng-content>',
                    host: { ngSkipHydration: 'true' },
                    imports: [DxIntegrationModule],
                    providers: [
                        DxTemplateHost,
                        WatcherHelper,
                        CUSTOM_VALUE_ACCESSOR_PROVIDER,
                        NestedOptionHost,
                        IterableDifferHelper
                    ]
                }]
        }], ctorParameters: () => [{ type: i0.ElementRef }, { type: i0.NgZone }, { type: i1.DxTemplateHost }, { type: i1.WatcherHelper }, { type: i1.IterableDifferHelper }, { type: i1.NestedOptionHost }, { type: i0.TransferState }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [PLATFORM_ID]
                }] }], propDecorators: { _commandsContentChildren: [{
                type: ContentChildren,
                args: [PROPERTY_TOKEN_commands]
            }], _itemsContentChildren: [{
                type: ContentChildren,
                args: [PROPERTY_TOKEN_items]
            }], _mentionsContentChildren: [{
                type: ContentChildren,
                args: [PROPERTY_TOKEN_mentions]
            }], _tabsContentChildren: [{
                type: ContentChildren,
                args: [PROPERTY_TOKEN_tabs]
            }], accessKey: [{
                type: Input
            }], activeStateEnabled: [{
                type: Input
            }], aiIntegration: [{
                type: Input
            }], allowSoftLineBreak: [{
                type: Input
            }], converter: [{
                type: Input
            }], customizeModules: [{
                type: Input
            }], disabled: [{
                type: Input
            }], elementAttr: [{
                type: Input
            }], focusStateEnabled: [{
                type: Input
            }], height: [{
                type: Input
            }], hint: [{
                type: Input
            }], hoverStateEnabled: [{
                type: Input
            }], imageUpload: [{
                type: Input
            }], isDirty: [{
                type: Input
            }], isValid: [{
                type: Input
            }], mediaResizing: [{
                type: Input
            }], mentions: [{
                type: Input
            }], name: [{
                type: Input
            }], placeholder: [{
                type: Input
            }], readOnly: [{
                type: Input
            }], rtlEnabled: [{
                type: Input
            }], stylingMode: [{
                type: Input
            }], tabIndex: [{
                type: Input
            }], tableContextMenu: [{
                type: Input
            }], tableResizing: [{
                type: Input
            }], toolbar: [{
                type: Input
            }], validationError: [{
                type: Input
            }], validationErrors: [{
                type: Input
            }], validationMessageMode: [{
                type: Input
            }], validationMessagePosition: [{
                type: Input
            }], validationStatus: [{
                type: Input
            }], value: [{
                type: Input
            }], variables: [{
                type: Input
            }], visible: [{
                type: Input
            }], width: [{
                type: Input
            }], onContentReady: [{
                type: Output
            }], onDisposing: [{
                type: Output
            }], onFocusIn: [{
                type: Output
            }], onFocusOut: [{
                type: Output
            }], onInitialized: [{
                type: Output
            }], onOptionChanged: [{
                type: Output
            }], onValueChanged: [{
                type: Output
            }], accessKeyChange: [{
                type: Output
            }], activeStateEnabledChange: [{
                type: Output
            }], aiIntegrationChange: [{
                type: Output
            }], allowSoftLineBreakChange: [{
                type: Output
            }], converterChange: [{
                type: Output
            }], customizeModulesChange: [{
                type: Output
            }], disabledChange: [{
                type: Output
            }], elementAttrChange: [{
                type: Output
            }], focusStateEnabledChange: [{
                type: Output
            }], heightChange: [{
                type: Output
            }], hintChange: [{
                type: Output
            }], hoverStateEnabledChange: [{
                type: Output
            }], imageUploadChange: [{
                type: Output
            }], isDirtyChange: [{
                type: Output
            }], isValidChange: [{
                type: Output
            }], mediaResizingChange: [{
                type: Output
            }], mentionsChange: [{
                type: Output
            }], nameChange: [{
                type: Output
            }], placeholderChange: [{
                type: Output
            }], readOnlyChange: [{
                type: Output
            }], rtlEnabledChange: [{
                type: Output
            }], stylingModeChange: [{
                type: Output
            }], tabIndexChange: [{
                type: Output
            }], tableContextMenuChange: [{
                type: Output
            }], tableResizingChange: [{
                type: Output
            }], toolbarChange: [{
                type: Output
            }], validationErrorChange: [{
                type: Output
            }], validationErrorsChange: [{
                type: Output
            }], validationMessageModeChange: [{
                type: Output
            }], validationMessagePositionChange: [{
                type: Output
            }], validationStatusChange: [{
                type: Output
            }], valueChange: [{
                type: Output
            }], variablesChange: [{
                type: Output
            }], visibleChange: [{
                type: Output
            }], widthChange: [{
                type: Output
            }], onBlur: [{
                type: Output
            }], change: [{
                type: HostListener,
                args: ['valueChange', ['$event']]
            }], touched: [{
                type: HostListener,
                args: ['onBlur', ['$event']]
            }] } });
class DxHtmlEditorModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxHtmlEditorModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxHtmlEditorModule, imports: [DxHtmlEditorComponent, DxoConverterModule,
            DxoImageUploadModule,
            DxoFileUploaderOptionsModule,
            DxiTabModule,
            DxoMediaResizingModule,
            DxiMentionModule,
            DxoTableContextMenuModule,
            DxiItemModule,
            DxoTableResizingModule,
            DxoToolbarModule,
            DxiCommandModule,
            DxoVariablesModule,
            DxiHtmlEditorCommandModule,
            DxoHtmlEditorConverterModule,
            DxoHtmlEditorFileUploaderOptionsModule,
            DxoHtmlEditorImageUploadModule,
            DxiHtmlEditorItemModule,
            DxoHtmlEditorMediaResizingModule,
            DxiHtmlEditorMentionModule,
            DxiHtmlEditorTabModule,
            DxoHtmlEditorTableContextMenuModule,
            DxiHtmlEditorTableContextMenuItemModule,
            DxoHtmlEditorTableResizingModule,
            DxoHtmlEditorToolbarModule,
            DxiHtmlEditorToolbarItemModule,
            DxoHtmlEditorVariablesModule,
            DxIntegrationModule,
            DxTemplateModule], exports: [DxHtmlEditorComponent, DxoConverterModule,
            DxoImageUploadModule,
            DxoFileUploaderOptionsModule,
            DxiTabModule,
            DxoMediaResizingModule,
            DxiMentionModule,
            DxoTableContextMenuModule,
            DxiItemModule,
            DxoTableResizingModule,
            DxoToolbarModule,
            DxiCommandModule,
            DxoVariablesModule,
            DxiHtmlEditorCommandModule,
            DxoHtmlEditorConverterModule,
            DxoHtmlEditorFileUploaderOptionsModule,
            DxoHtmlEditorImageUploadModule,
            DxiHtmlEditorItemModule,
            DxoHtmlEditorMediaResizingModule,
            DxiHtmlEditorMentionModule,
            DxiHtmlEditorTabModule,
            DxoHtmlEditorTableContextMenuModule,
            DxiHtmlEditorTableContextMenuItemModule,
            DxoHtmlEditorTableResizingModule,
            DxoHtmlEditorToolbarModule,
            DxiHtmlEditorToolbarItemModule,
            DxoHtmlEditorVariablesModule,
            DxTemplateModule] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxHtmlEditorModule, imports: [DxHtmlEditorComponent,
            DxoConverterModule,
            DxoImageUploadModule,
            DxoFileUploaderOptionsModule,
            DxiTabModule,
            DxoMediaResizingModule,
            DxiMentionModule,
            DxoTableContextMenuModule,
            DxiItemModule,
            DxoTableResizingModule,
            DxoToolbarModule,
            DxiCommandModule,
            DxoVariablesModule,
            DxiHtmlEditorCommandModule,
            DxoHtmlEditorConverterModule,
            DxoHtmlEditorFileUploaderOptionsModule,
            DxoHtmlEditorImageUploadModule,
            DxiHtmlEditorItemModule,
            DxoHtmlEditorMediaResizingModule,
            DxiHtmlEditorMentionModule,
            DxiHtmlEditorTabModule,
            DxoHtmlEditorTableContextMenuModule,
            DxiHtmlEditorTableContextMenuItemModule,
            DxoHtmlEditorTableResizingModule,
            DxoHtmlEditorToolbarModule,
            DxiHtmlEditorToolbarItemModule,
            DxoHtmlEditorVariablesModule,
            DxIntegrationModule,
            DxTemplateModule, DxoConverterModule,
            DxoImageUploadModule,
            DxoFileUploaderOptionsModule,
            DxiTabModule,
            DxoMediaResizingModule,
            DxiMentionModule,
            DxoTableContextMenuModule,
            DxiItemModule,
            DxoTableResizingModule,
            DxoToolbarModule,
            DxiCommandModule,
            DxoVariablesModule,
            DxiHtmlEditorCommandModule,
            DxoHtmlEditorConverterModule,
            DxoHtmlEditorFileUploaderOptionsModule,
            DxoHtmlEditorImageUploadModule,
            DxiHtmlEditorItemModule,
            DxoHtmlEditorMediaResizingModule,
            DxiHtmlEditorMentionModule,
            DxiHtmlEditorTabModule,
            DxoHtmlEditorTableContextMenuModule,
            DxiHtmlEditorTableContextMenuItemModule,
            DxoHtmlEditorTableResizingModule,
            DxoHtmlEditorToolbarModule,
            DxiHtmlEditorToolbarItemModule,
            DxoHtmlEditorVariablesModule,
            DxTemplateModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxHtmlEditorModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxHtmlEditorComponent,
                        DxoConverterModule,
                        DxoImageUploadModule,
                        DxoFileUploaderOptionsModule,
                        DxiTabModule,
                        DxoMediaResizingModule,
                        DxiMentionModule,
                        DxoTableContextMenuModule,
                        DxiItemModule,
                        DxoTableResizingModule,
                        DxoToolbarModule,
                        DxiCommandModule,
                        DxoVariablesModule,
                        DxiHtmlEditorCommandModule,
                        DxoHtmlEditorConverterModule,
                        DxoHtmlEditorFileUploaderOptionsModule,
                        DxoHtmlEditorImageUploadModule,
                        DxiHtmlEditorItemModule,
                        DxoHtmlEditorMediaResizingModule,
                        DxiHtmlEditorMentionModule,
                        DxiHtmlEditorTabModule,
                        DxoHtmlEditorTableContextMenuModule,
                        DxiHtmlEditorTableContextMenuItemModule,
                        DxoHtmlEditorTableResizingModule,
                        DxoHtmlEditorToolbarModule,
                        DxiHtmlEditorToolbarItemModule,
                        DxoHtmlEditorVariablesModule,
                        DxIntegrationModule,
                        DxTemplateModule
                    ],
                    exports: [
                        DxHtmlEditorComponent,
                        DxoConverterModule,
                        DxoImageUploadModule,
                        DxoFileUploaderOptionsModule,
                        DxiTabModule,
                        DxoMediaResizingModule,
                        DxiMentionModule,
                        DxoTableContextMenuModule,
                        DxiItemModule,
                        DxoTableResizingModule,
                        DxoToolbarModule,
                        DxiCommandModule,
                        DxoVariablesModule,
                        DxiHtmlEditorCommandModule,
                        DxoHtmlEditorConverterModule,
                        DxoHtmlEditorFileUploaderOptionsModule,
                        DxoHtmlEditorImageUploadModule,
                        DxiHtmlEditorItemModule,
                        DxoHtmlEditorMediaResizingModule,
                        DxiHtmlEditorMentionModule,
                        DxiHtmlEditorTabModule,
                        DxoHtmlEditorTableContextMenuModule,
                        DxiHtmlEditorTableContextMenuItemModule,
                        DxoHtmlEditorTableResizingModule,
                        DxoHtmlEditorToolbarModule,
                        DxiHtmlEditorToolbarItemModule,
                        DxoHtmlEditorVariablesModule,
                        DxTemplateModule
                    ]
                }]
        }] });

/**
 * Generated bundle index. Do not edit.
 */

export { DxHtmlEditorComponent, DxHtmlEditorModule };
//# sourceMappingURL=devextreme-angular-ui-html-editor.mjs.map
