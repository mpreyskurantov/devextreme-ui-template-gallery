import * as i0 from '@angular/core';
import { Input, SkipSelf, Host, Component, NgModule, Output, ContentChildren, Inject } from '@angular/core';
import * as i1 from 'devextreme-angular/core';
import { NestedOption, DxIntegrationModule, NestedOptionHost, CollectionNestedOption, extractTemplate, DxTemplateHost } from 'devextreme-angular/core';
import { PROPERTY_TOKEN_toolbarItems, PROPERTY_TOKEN_items } from 'devextreme-angular/core/tokens';
import { DOCUMENT } from '@angular/common';

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoDropDownButtonAnimationComponent extends NestedOption {
    get hide() {
        return this._getOption('hide');
    }
    set hide(value) {
        this._setOption('hide', value);
    }
    get show() {
        return this._getOption('show');
    }
    set show(value) {
        this._setOption('show', value);
    }
    get _optionPath() {
        return 'animation';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDropDownButtonAnimationComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoDropDownButtonAnimationComponent, isStandalone: true, selector: "dxo-drop-down-button-animation", inputs: { hide: "hide", show: "show" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDropDownButtonAnimationComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-drop-down-button-animation', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { hide: [{
                type: Input
            }], show: [{
                type: Input
            }] } });
class DxoDropDownButtonAnimationModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDropDownButtonAnimationModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoDropDownButtonAnimationModule, imports: [DxoDropDownButtonAnimationComponent], exports: [DxoDropDownButtonAnimationComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDropDownButtonAnimationModule, imports: [DxoDropDownButtonAnimationComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDropDownButtonAnimationModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoDropDownButtonAnimationComponent
                    ],
                    exports: [
                        DxoDropDownButtonAnimationComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoDropDownButtonAtComponent extends NestedOption {
    get x() {
        return this._getOption('x');
    }
    set x(value) {
        this._setOption('x', value);
    }
    get y() {
        return this._getOption('y');
    }
    set y(value) {
        this._setOption('y', value);
    }
    get _optionPath() {
        return 'at';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDropDownButtonAtComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoDropDownButtonAtComponent, isStandalone: true, selector: "dxo-drop-down-button-at", inputs: { x: "x", y: "y" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDropDownButtonAtComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-drop-down-button-at', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { x: [{
                type: Input
            }], y: [{
                type: Input
            }] } });
class DxoDropDownButtonAtModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDropDownButtonAtModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoDropDownButtonAtModule, imports: [DxoDropDownButtonAtComponent], exports: [DxoDropDownButtonAtComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDropDownButtonAtModule, imports: [DxoDropDownButtonAtComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDropDownButtonAtModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoDropDownButtonAtComponent
                    ],
                    exports: [
                        DxoDropDownButtonAtComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoDropDownButtonBoundaryOffsetComponent extends NestedOption {
    get x() {
        return this._getOption('x');
    }
    set x(value) {
        this._setOption('x', value);
    }
    get y() {
        return this._getOption('y');
    }
    set y(value) {
        this._setOption('y', value);
    }
    get _optionPath() {
        return 'boundaryOffset';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDropDownButtonBoundaryOffsetComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoDropDownButtonBoundaryOffsetComponent, isStandalone: true, selector: "dxo-drop-down-button-boundary-offset", inputs: { x: "x", y: "y" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDropDownButtonBoundaryOffsetComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-drop-down-button-boundary-offset', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { x: [{
                type: Input
            }], y: [{
                type: Input
            }] } });
class DxoDropDownButtonBoundaryOffsetModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDropDownButtonBoundaryOffsetModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoDropDownButtonBoundaryOffsetModule, imports: [DxoDropDownButtonBoundaryOffsetComponent], exports: [DxoDropDownButtonBoundaryOffsetComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDropDownButtonBoundaryOffsetModule, imports: [DxoDropDownButtonBoundaryOffsetComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDropDownButtonBoundaryOffsetModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoDropDownButtonBoundaryOffsetComponent
                    ],
                    exports: [
                        DxoDropDownButtonBoundaryOffsetComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoDropDownButtonCollisionComponent extends NestedOption {
    get x() {
        return this._getOption('x');
    }
    set x(value) {
        this._setOption('x', value);
    }
    get y() {
        return this._getOption('y');
    }
    set y(value) {
        this._setOption('y', value);
    }
    get _optionPath() {
        return 'collision';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDropDownButtonCollisionComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoDropDownButtonCollisionComponent, isStandalone: true, selector: "dxo-drop-down-button-collision", inputs: { x: "x", y: "y" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDropDownButtonCollisionComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-drop-down-button-collision', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { x: [{
                type: Input
            }], y: [{
                type: Input
            }] } });
class DxoDropDownButtonCollisionModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDropDownButtonCollisionModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoDropDownButtonCollisionModule, imports: [DxoDropDownButtonCollisionComponent], exports: [DxoDropDownButtonCollisionComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDropDownButtonCollisionModule, imports: [DxoDropDownButtonCollisionComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDropDownButtonCollisionModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoDropDownButtonCollisionComponent
                    ],
                    exports: [
                        DxoDropDownButtonCollisionComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoDropDownButtonDropDownOptionsComponent extends NestedOption {
    set _toolbarItemsContentChildren(value) {
        this.setChildren('toolbarItems', value);
    }
    get accessKey() {
        return this._getOption('accessKey');
    }
    set accessKey(value) {
        this._setOption('accessKey', value);
    }
    get animation() {
        return this._getOption('animation');
    }
    set animation(value) {
        this._setOption('animation', value);
    }
    get container() {
        return this._getOption('container');
    }
    set container(value) {
        this._setOption('container', value);
    }
    get contentTemplate() {
        return this._getOption('contentTemplate');
    }
    set contentTemplate(value) {
        this._setOption('contentTemplate', value);
    }
    get deferRendering() {
        return this._getOption('deferRendering');
    }
    set deferRendering(value) {
        this._setOption('deferRendering', value);
    }
    get disabled() {
        return this._getOption('disabled');
    }
    set disabled(value) {
        this._setOption('disabled', value);
    }
    get dragAndResizeArea() {
        return this._getOption('dragAndResizeArea');
    }
    set dragAndResizeArea(value) {
        this._setOption('dragAndResizeArea', value);
    }
    get dragEnabled() {
        return this._getOption('dragEnabled');
    }
    set dragEnabled(value) {
        this._setOption('dragEnabled', value);
    }
    get dragOutsideBoundary() {
        return this._getOption('dragOutsideBoundary');
    }
    set dragOutsideBoundary(value) {
        this._setOption('dragOutsideBoundary', value);
    }
    get enableBodyScroll() {
        return this._getOption('enableBodyScroll');
    }
    set enableBodyScroll(value) {
        this._setOption('enableBodyScroll', value);
    }
    get focusStateEnabled() {
        return this._getOption('focusStateEnabled');
    }
    set focusStateEnabled(value) {
        this._setOption('focusStateEnabled', value);
    }
    get fullScreen() {
        return this._getOption('fullScreen');
    }
    set fullScreen(value) {
        this._setOption('fullScreen', value);
    }
    get height() {
        return this._getOption('height');
    }
    set height(value) {
        this._setOption('height', value);
    }
    get hideOnOutsideClick() {
        return this._getOption('hideOnOutsideClick');
    }
    set hideOnOutsideClick(value) {
        this._setOption('hideOnOutsideClick', value);
    }
    get hideOnParentScroll() {
        return this._getOption('hideOnParentScroll');
    }
    set hideOnParentScroll(value) {
        this._setOption('hideOnParentScroll', value);
    }
    get hint() {
        return this._getOption('hint');
    }
    set hint(value) {
        this._setOption('hint', value);
    }
    get hoverStateEnabled() {
        return this._getOption('hoverStateEnabled');
    }
    set hoverStateEnabled(value) {
        this._setOption('hoverStateEnabled', value);
    }
    get maxHeight() {
        return this._getOption('maxHeight');
    }
    set maxHeight(value) {
        this._setOption('maxHeight', value);
    }
    get maxWidth() {
        return this._getOption('maxWidth');
    }
    set maxWidth(value) {
        this._setOption('maxWidth', value);
    }
    get minHeight() {
        return this._getOption('minHeight');
    }
    set minHeight(value) {
        this._setOption('minHeight', value);
    }
    get minWidth() {
        return this._getOption('minWidth');
    }
    set minWidth(value) {
        this._setOption('minWidth', value);
    }
    get onContentReady() {
        return this._getOption('onContentReady');
    }
    set onContentReady(value) {
        this._setOption('onContentReady', value);
    }
    get onDisposing() {
        return this._getOption('onDisposing');
    }
    set onDisposing(value) {
        this._setOption('onDisposing', value);
    }
    get onHidden() {
        return this._getOption('onHidden');
    }
    set onHidden(value) {
        this._setOption('onHidden', value);
    }
    get onHiding() {
        return this._getOption('onHiding');
    }
    set onHiding(value) {
        this._setOption('onHiding', value);
    }
    get onInitialized() {
        return this._getOption('onInitialized');
    }
    set onInitialized(value) {
        this._setOption('onInitialized', value);
    }
    get onOptionChanged() {
        return this._getOption('onOptionChanged');
    }
    set onOptionChanged(value) {
        this._setOption('onOptionChanged', value);
    }
    get onResize() {
        return this._getOption('onResize');
    }
    set onResize(value) {
        this._setOption('onResize', value);
    }
    get onResizeEnd() {
        return this._getOption('onResizeEnd');
    }
    set onResizeEnd(value) {
        this._setOption('onResizeEnd', value);
    }
    get onResizeStart() {
        return this._getOption('onResizeStart');
    }
    set onResizeStart(value) {
        this._setOption('onResizeStart', value);
    }
    get onShowing() {
        return this._getOption('onShowing');
    }
    set onShowing(value) {
        this._setOption('onShowing', value);
    }
    get onShown() {
        return this._getOption('onShown');
    }
    set onShown(value) {
        this._setOption('onShown', value);
    }
    get onTitleRendered() {
        return this._getOption('onTitleRendered');
    }
    set onTitleRendered(value) {
        this._setOption('onTitleRendered', value);
    }
    get position() {
        return this._getOption('position');
    }
    set position(value) {
        this._setOption('position', value);
    }
    get resizeEnabled() {
        return this._getOption('resizeEnabled');
    }
    set resizeEnabled(value) {
        this._setOption('resizeEnabled', value);
    }
    get restorePosition() {
        return this._getOption('restorePosition');
    }
    set restorePosition(value) {
        this._setOption('restorePosition', value);
    }
    get rtlEnabled() {
        return this._getOption('rtlEnabled');
    }
    set rtlEnabled(value) {
        this._setOption('rtlEnabled', value);
    }
    get shading() {
        return this._getOption('shading');
    }
    set shading(value) {
        this._setOption('shading', value);
    }
    get shadingColor() {
        return this._getOption('shadingColor');
    }
    set shadingColor(value) {
        this._setOption('shadingColor', value);
    }
    get showCloseButton() {
        return this._getOption('showCloseButton');
    }
    set showCloseButton(value) {
        this._setOption('showCloseButton', value);
    }
    get showTitle() {
        return this._getOption('showTitle');
    }
    set showTitle(value) {
        this._setOption('showTitle', value);
    }
    get tabFocusLoopEnabled() {
        return this._getOption('tabFocusLoopEnabled');
    }
    set tabFocusLoopEnabled(value) {
        this._setOption('tabFocusLoopEnabled', value);
    }
    get tabIndex() {
        return this._getOption('tabIndex');
    }
    set tabIndex(value) {
        this._setOption('tabIndex', value);
    }
    get title() {
        return this._getOption('title');
    }
    set title(value) {
        this._setOption('title', value);
    }
    get titleTemplate() {
        return this._getOption('titleTemplate');
    }
    set titleTemplate(value) {
        this._setOption('titleTemplate', value);
    }
    get toolbarItems() {
        return this._getOption('toolbarItems');
    }
    set toolbarItems(value) {
        this._setOption('toolbarItems', value);
    }
    get visible() {
        return this._getOption('visible');
    }
    set visible(value) {
        this._setOption('visible', value);
    }
    get width() {
        return this._getOption('width');
    }
    set width(value) {
        this._setOption('width', value);
    }
    get wrapperAttr() {
        return this._getOption('wrapperAttr');
    }
    set wrapperAttr(value) {
        this._setOption('wrapperAttr', value);
    }
    get _optionPath() {
        return 'dropDownOptions';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        this._createEventEmitters([
            { emit: 'heightChange' },
            { emit: 'positionChange' },
            { emit: 'visibleChange' },
            { emit: 'widthChange' }
        ]);
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDropDownButtonDropDownOptionsComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoDropDownButtonDropDownOptionsComponent, isStandalone: true, selector: "dxo-drop-down-button-drop-down-options", inputs: { accessKey: "accessKey", animation: "animation", container: "container", contentTemplate: "contentTemplate", deferRendering: "deferRendering", disabled: "disabled", dragAndResizeArea: "dragAndResizeArea", dragEnabled: "dragEnabled", dragOutsideBoundary: "dragOutsideBoundary", enableBodyScroll: "enableBodyScroll", focusStateEnabled: "focusStateEnabled", fullScreen: "fullScreen", height: "height", hideOnOutsideClick: "hideOnOutsideClick", hideOnParentScroll: "hideOnParentScroll", hint: "hint", hoverStateEnabled: "hoverStateEnabled", maxHeight: "maxHeight", maxWidth: "maxWidth", minHeight: "minHeight", minWidth: "minWidth", onContentReady: "onContentReady", onDisposing: "onDisposing", onHidden: "onHidden", onHiding: "onHiding", onInitialized: "onInitialized", onOptionChanged: "onOptionChanged", onResize: "onResize", onResizeEnd: "onResizeEnd", onResizeStart: "onResizeStart", onShowing: "onShowing", onShown: "onShown", onTitleRendered: "onTitleRendered", position: "position", resizeEnabled: "resizeEnabled", restorePosition: "restorePosition", rtlEnabled: "rtlEnabled", shading: "shading", shadingColor: "shadingColor", showCloseButton: "showCloseButton", showTitle: "showTitle", tabFocusLoopEnabled: "tabFocusLoopEnabled", tabIndex: "tabIndex", title: "title", titleTemplate: "titleTemplate", toolbarItems: "toolbarItems", visible: "visible", width: "width", wrapperAttr: "wrapperAttr" }, outputs: { heightChange: "heightChange", positionChange: "positionChange", visibleChange: "visibleChange", widthChange: "widthChange" }, providers: [NestedOptionHost], queries: [{ propertyName: "_toolbarItemsContentChildren", predicate: PROPERTY_TOKEN_toolbarItems }], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDropDownButtonDropDownOptionsComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-drop-down-button-drop-down-options', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { _toolbarItemsContentChildren: [{
                type: ContentChildren,
                args: [PROPERTY_TOKEN_toolbarItems]
            }], accessKey: [{
                type: Input
            }], animation: [{
                type: Input
            }], container: [{
                type: Input
            }], contentTemplate: [{
                type: Input
            }], deferRendering: [{
                type: Input
            }], disabled: [{
                type: Input
            }], dragAndResizeArea: [{
                type: Input
            }], dragEnabled: [{
                type: Input
            }], dragOutsideBoundary: [{
                type: Input
            }], enableBodyScroll: [{
                type: Input
            }], focusStateEnabled: [{
                type: Input
            }], fullScreen: [{
                type: Input
            }], height: [{
                type: Input
            }], hideOnOutsideClick: [{
                type: Input
            }], hideOnParentScroll: [{
                type: Input
            }], hint: [{
                type: Input
            }], hoverStateEnabled: [{
                type: Input
            }], maxHeight: [{
                type: Input
            }], maxWidth: [{
                type: Input
            }], minHeight: [{
                type: Input
            }], minWidth: [{
                type: Input
            }], onContentReady: [{
                type: Input
            }], onDisposing: [{
                type: Input
            }], onHidden: [{
                type: Input
            }], onHiding: [{
                type: Input
            }], onInitialized: [{
                type: Input
            }], onOptionChanged: [{
                type: Input
            }], onResize: [{
                type: Input
            }], onResizeEnd: [{
                type: Input
            }], onResizeStart: [{
                type: Input
            }], onShowing: [{
                type: Input
            }], onShown: [{
                type: Input
            }], onTitleRendered: [{
                type: Input
            }], position: [{
                type: Input
            }], resizeEnabled: [{
                type: Input
            }], restorePosition: [{
                type: Input
            }], rtlEnabled: [{
                type: Input
            }], shading: [{
                type: Input
            }], shadingColor: [{
                type: Input
            }], showCloseButton: [{
                type: Input
            }], showTitle: [{
                type: Input
            }], tabFocusLoopEnabled: [{
                type: Input
            }], tabIndex: [{
                type: Input
            }], title: [{
                type: Input
            }], titleTemplate: [{
                type: Input
            }], toolbarItems: [{
                type: Input
            }], visible: [{
                type: Input
            }], width: [{
                type: Input
            }], wrapperAttr: [{
                type: Input
            }], heightChange: [{
                type: Output
            }], positionChange: [{
                type: Output
            }], visibleChange: [{
                type: Output
            }], widthChange: [{
                type: Output
            }] } });
class DxoDropDownButtonDropDownOptionsModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDropDownButtonDropDownOptionsModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoDropDownButtonDropDownOptionsModule, imports: [DxoDropDownButtonDropDownOptionsComponent], exports: [DxoDropDownButtonDropDownOptionsComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDropDownButtonDropDownOptionsModule, imports: [DxoDropDownButtonDropDownOptionsComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDropDownButtonDropDownOptionsModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoDropDownButtonDropDownOptionsComponent
                    ],
                    exports: [
                        DxoDropDownButtonDropDownOptionsComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoDropDownButtonFromComponent extends NestedOption {
    get left() {
        return this._getOption('left');
    }
    set left(value) {
        this._setOption('left', value);
    }
    get opacity() {
        return this._getOption('opacity');
    }
    set opacity(value) {
        this._setOption('opacity', value);
    }
    get position() {
        return this._getOption('position');
    }
    set position(value) {
        this._setOption('position', value);
    }
    get scale() {
        return this._getOption('scale');
    }
    set scale(value) {
        this._setOption('scale', value);
    }
    get top() {
        return this._getOption('top');
    }
    set top(value) {
        this._setOption('top', value);
    }
    get _optionPath() {
        return 'from';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDropDownButtonFromComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoDropDownButtonFromComponent, isStandalone: true, selector: "dxo-drop-down-button-from", inputs: { left: "left", opacity: "opacity", position: "position", scale: "scale", top: "top" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDropDownButtonFromComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-drop-down-button-from', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { left: [{
                type: Input
            }], opacity: [{
                type: Input
            }], position: [{
                type: Input
            }], scale: [{
                type: Input
            }], top: [{
                type: Input
            }] } });
class DxoDropDownButtonFromModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDropDownButtonFromModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoDropDownButtonFromModule, imports: [DxoDropDownButtonFromComponent], exports: [DxoDropDownButtonFromComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDropDownButtonFromModule, imports: [DxoDropDownButtonFromComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDropDownButtonFromModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoDropDownButtonFromComponent
                    ],
                    exports: [
                        DxoDropDownButtonFromComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoDropDownButtonHideComponent extends NestedOption {
    get complete() {
        return this._getOption('complete');
    }
    set complete(value) {
        this._setOption('complete', value);
    }
    get delay() {
        return this._getOption('delay');
    }
    set delay(value) {
        this._setOption('delay', value);
    }
    get direction() {
        return this._getOption('direction');
    }
    set direction(value) {
        this._setOption('direction', value);
    }
    get duration() {
        return this._getOption('duration');
    }
    set duration(value) {
        this._setOption('duration', value);
    }
    get easing() {
        return this._getOption('easing');
    }
    set easing(value) {
        this._setOption('easing', value);
    }
    get from() {
        return this._getOption('from');
    }
    set from(value) {
        this._setOption('from', value);
    }
    get staggerDelay() {
        return this._getOption('staggerDelay');
    }
    set staggerDelay(value) {
        this._setOption('staggerDelay', value);
    }
    get start() {
        return this._getOption('start');
    }
    set start(value) {
        this._setOption('start', value);
    }
    get to() {
        return this._getOption('to');
    }
    set to(value) {
        this._setOption('to', value);
    }
    get type() {
        return this._getOption('type');
    }
    set type(value) {
        this._setOption('type', value);
    }
    get _optionPath() {
        return 'hide';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDropDownButtonHideComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoDropDownButtonHideComponent, isStandalone: true, selector: "dxo-drop-down-button-hide", inputs: { complete: "complete", delay: "delay", direction: "direction", duration: "duration", easing: "easing", from: "from", staggerDelay: "staggerDelay", start: "start", to: "to", type: "type" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDropDownButtonHideComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-drop-down-button-hide', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { complete: [{
                type: Input
            }], delay: [{
                type: Input
            }], direction: [{
                type: Input
            }], duration: [{
                type: Input
            }], easing: [{
                type: Input
            }], from: [{
                type: Input
            }], staggerDelay: [{
                type: Input
            }], start: [{
                type: Input
            }], to: [{
                type: Input
            }], type: [{
                type: Input
            }] } });
class DxoDropDownButtonHideModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDropDownButtonHideModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoDropDownButtonHideModule, imports: [DxoDropDownButtonHideComponent], exports: [DxoDropDownButtonHideComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDropDownButtonHideModule, imports: [DxoDropDownButtonHideComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDropDownButtonHideModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoDropDownButtonHideComponent
                    ],
                    exports: [
                        DxoDropDownButtonHideComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxiDropDownButtonItemComponent extends CollectionNestedOption {
    get badge() {
        return this._getOption('badge');
    }
    set badge(value) {
        this._setOption('badge', value);
    }
    get disabled() {
        return this._getOption('disabled');
    }
    set disabled(value) {
        this._setOption('disabled', value);
    }
    get html() {
        return this._getOption('html');
    }
    set html(value) {
        this._setOption('html', value);
    }
    get icon() {
        return this._getOption('icon');
    }
    set icon(value) {
        this._setOption('icon', value);
    }
    get onClick() {
        return this._getOption('onClick');
    }
    set onClick(value) {
        this._setOption('onClick', value);
    }
    get template() {
        return this._getOption('template');
    }
    set template(value) {
        this._setOption('template', value);
    }
    get text() {
        return this._getOption('text');
    }
    set text(value) {
        this._setOption('text', value);
    }
    get visible() {
        return this._getOption('visible');
    }
    set visible(value) {
        this._setOption('visible', value);
    }
    get _optionPath() {
        return 'items';
    }
    constructor(parentOptionHost, optionHost, renderer, document, templateHost, element) {
        super();
        this.renderer = renderer;
        this.document = document;
        this.element = element;
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
        templateHost.setHost(this);
    }
    setTemplate(template) {
        this.template = template;
    }
    ngAfterViewInit() {
        extractTemplate(this, this.element, this.renderer, this.document);
    }
    ngOnDestroy() {
        this._deleteRemovedOptions(this._fullOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiDropDownButtonItemComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }, { token: i0.Renderer2 }, { token: DOCUMENT }, { token: i1.DxTemplateHost, host: true }, { token: i0.ElementRef }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxiDropDownButtonItemComponent, isStandalone: true, selector: "dxi-drop-down-button-item", inputs: { badge: "badge", disabled: "disabled", html: "html", icon: "icon", onClick: "onClick", template: "template", text: "text", visible: "visible" }, providers: [
            NestedOptionHost,
            DxTemplateHost,
            {
                provide: PROPERTY_TOKEN_items,
                useExisting: DxiDropDownButtonItemComponent,
            }
        ], usesInheritance: true, ngImport: i0, template: '<ng-content></ng-content>', isInline: true, styles: [":host{display:block}\n"], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiDropDownButtonItemComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxi-drop-down-button-item', template: '<ng-content></ng-content>', imports: [DxIntegrationModule], providers: [
                        NestedOptionHost,
                        DxTemplateHost,
                        {
                            provide: PROPERTY_TOKEN_items,
                            useExisting: DxiDropDownButtonItemComponent,
                        }
                    ], styles: [":host{display:block}\n"] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }, { type: i0.Renderer2 }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [DOCUMENT]
                }] }, { type: i1.DxTemplateHost, decorators: [{
                    type: Host
                }] }, { type: i0.ElementRef }], propDecorators: { badge: [{
                type: Input
            }], disabled: [{
                type: Input
            }], html: [{
                type: Input
            }], icon: [{
                type: Input
            }], onClick: [{
                type: Input
            }], template: [{
                type: Input
            }], text: [{
                type: Input
            }], visible: [{
                type: Input
            }] } });
class DxiDropDownButtonItemModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiDropDownButtonItemModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxiDropDownButtonItemModule, imports: [DxiDropDownButtonItemComponent], exports: [DxiDropDownButtonItemComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiDropDownButtonItemModule, imports: [DxiDropDownButtonItemComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiDropDownButtonItemModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxiDropDownButtonItemComponent
                    ],
                    exports: [
                        DxiDropDownButtonItemComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoDropDownButtonMyComponent extends NestedOption {
    get x() {
        return this._getOption('x');
    }
    set x(value) {
        this._setOption('x', value);
    }
    get y() {
        return this._getOption('y');
    }
    set y(value) {
        this._setOption('y', value);
    }
    get _optionPath() {
        return 'my';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDropDownButtonMyComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoDropDownButtonMyComponent, isStandalone: true, selector: "dxo-drop-down-button-my", inputs: { x: "x", y: "y" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDropDownButtonMyComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-drop-down-button-my', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { x: [{
                type: Input
            }], y: [{
                type: Input
            }] } });
class DxoDropDownButtonMyModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDropDownButtonMyModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoDropDownButtonMyModule, imports: [DxoDropDownButtonMyComponent], exports: [DxoDropDownButtonMyComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDropDownButtonMyModule, imports: [DxoDropDownButtonMyComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDropDownButtonMyModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoDropDownButtonMyComponent
                    ],
                    exports: [
                        DxoDropDownButtonMyComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoDropDownButtonOffsetComponent extends NestedOption {
    get x() {
        return this._getOption('x');
    }
    set x(value) {
        this._setOption('x', value);
    }
    get y() {
        return this._getOption('y');
    }
    set y(value) {
        this._setOption('y', value);
    }
    get _optionPath() {
        return 'offset';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDropDownButtonOffsetComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoDropDownButtonOffsetComponent, isStandalone: true, selector: "dxo-drop-down-button-offset", inputs: { x: "x", y: "y" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDropDownButtonOffsetComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-drop-down-button-offset', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { x: [{
                type: Input
            }], y: [{
                type: Input
            }] } });
class DxoDropDownButtonOffsetModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDropDownButtonOffsetModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoDropDownButtonOffsetModule, imports: [DxoDropDownButtonOffsetComponent], exports: [DxoDropDownButtonOffsetComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDropDownButtonOffsetModule, imports: [DxoDropDownButtonOffsetComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDropDownButtonOffsetModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoDropDownButtonOffsetComponent
                    ],
                    exports: [
                        DxoDropDownButtonOffsetComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoDropDownButtonPositionComponent extends NestedOption {
    get at() {
        return this._getOption('at');
    }
    set at(value) {
        this._setOption('at', value);
    }
    get boundary() {
        return this._getOption('boundary');
    }
    set boundary(value) {
        this._setOption('boundary', value);
    }
    get boundaryOffset() {
        return this._getOption('boundaryOffset');
    }
    set boundaryOffset(value) {
        this._setOption('boundaryOffset', value);
    }
    get collision() {
        return this._getOption('collision');
    }
    set collision(value) {
        this._setOption('collision', value);
    }
    get my() {
        return this._getOption('my');
    }
    set my(value) {
        this._setOption('my', value);
    }
    get of() {
        return this._getOption('of');
    }
    set of(value) {
        this._setOption('of', value);
    }
    get offset() {
        return this._getOption('offset');
    }
    set offset(value) {
        this._setOption('offset', value);
    }
    get _optionPath() {
        return 'position';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDropDownButtonPositionComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoDropDownButtonPositionComponent, isStandalone: true, selector: "dxo-drop-down-button-position", inputs: { at: "at", boundary: "boundary", boundaryOffset: "boundaryOffset", collision: "collision", my: "my", of: "of", offset: "offset" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDropDownButtonPositionComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-drop-down-button-position', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { at: [{
                type: Input
            }], boundary: [{
                type: Input
            }], boundaryOffset: [{
                type: Input
            }], collision: [{
                type: Input
            }], my: [{
                type: Input
            }], of: [{
                type: Input
            }], offset: [{
                type: Input
            }] } });
class DxoDropDownButtonPositionModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDropDownButtonPositionModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoDropDownButtonPositionModule, imports: [DxoDropDownButtonPositionComponent], exports: [DxoDropDownButtonPositionComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDropDownButtonPositionModule, imports: [DxoDropDownButtonPositionComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDropDownButtonPositionModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoDropDownButtonPositionComponent
                    ],
                    exports: [
                        DxoDropDownButtonPositionComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoDropDownButtonShowComponent extends NestedOption {
    get complete() {
        return this._getOption('complete');
    }
    set complete(value) {
        this._setOption('complete', value);
    }
    get delay() {
        return this._getOption('delay');
    }
    set delay(value) {
        this._setOption('delay', value);
    }
    get direction() {
        return this._getOption('direction');
    }
    set direction(value) {
        this._setOption('direction', value);
    }
    get duration() {
        return this._getOption('duration');
    }
    set duration(value) {
        this._setOption('duration', value);
    }
    get easing() {
        return this._getOption('easing');
    }
    set easing(value) {
        this._setOption('easing', value);
    }
    get from() {
        return this._getOption('from');
    }
    set from(value) {
        this._setOption('from', value);
    }
    get staggerDelay() {
        return this._getOption('staggerDelay');
    }
    set staggerDelay(value) {
        this._setOption('staggerDelay', value);
    }
    get start() {
        return this._getOption('start');
    }
    set start(value) {
        this._setOption('start', value);
    }
    get to() {
        return this._getOption('to');
    }
    set to(value) {
        this._setOption('to', value);
    }
    get type() {
        return this._getOption('type');
    }
    set type(value) {
        this._setOption('type', value);
    }
    get _optionPath() {
        return 'show';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDropDownButtonShowComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoDropDownButtonShowComponent, isStandalone: true, selector: "dxo-drop-down-button-show", inputs: { complete: "complete", delay: "delay", direction: "direction", duration: "duration", easing: "easing", from: "from", staggerDelay: "staggerDelay", start: "start", to: "to", type: "type" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDropDownButtonShowComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-drop-down-button-show', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { complete: [{
                type: Input
            }], delay: [{
                type: Input
            }], direction: [{
                type: Input
            }], duration: [{
                type: Input
            }], easing: [{
                type: Input
            }], from: [{
                type: Input
            }], staggerDelay: [{
                type: Input
            }], start: [{
                type: Input
            }], to: [{
                type: Input
            }], type: [{
                type: Input
            }] } });
class DxoDropDownButtonShowModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDropDownButtonShowModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoDropDownButtonShowModule, imports: [DxoDropDownButtonShowComponent], exports: [DxoDropDownButtonShowComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDropDownButtonShowModule, imports: [DxoDropDownButtonShowComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDropDownButtonShowModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoDropDownButtonShowComponent
                    ],
                    exports: [
                        DxoDropDownButtonShowComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoDropDownButtonToComponent extends NestedOption {
    get left() {
        return this._getOption('left');
    }
    set left(value) {
        this._setOption('left', value);
    }
    get opacity() {
        return this._getOption('opacity');
    }
    set opacity(value) {
        this._setOption('opacity', value);
    }
    get position() {
        return this._getOption('position');
    }
    set position(value) {
        this._setOption('position', value);
    }
    get scale() {
        return this._getOption('scale');
    }
    set scale(value) {
        this._setOption('scale', value);
    }
    get top() {
        return this._getOption('top');
    }
    set top(value) {
        this._setOption('top', value);
    }
    get _optionPath() {
        return 'to';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDropDownButtonToComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoDropDownButtonToComponent, isStandalone: true, selector: "dxo-drop-down-button-to", inputs: { left: "left", opacity: "opacity", position: "position", scale: "scale", top: "top" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDropDownButtonToComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-drop-down-button-to', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { left: [{
                type: Input
            }], opacity: [{
                type: Input
            }], position: [{
                type: Input
            }], scale: [{
                type: Input
            }], top: [{
                type: Input
            }] } });
class DxoDropDownButtonToModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDropDownButtonToModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoDropDownButtonToModule, imports: [DxoDropDownButtonToComponent], exports: [DxoDropDownButtonToComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDropDownButtonToModule, imports: [DxoDropDownButtonToComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDropDownButtonToModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoDropDownButtonToComponent
                    ],
                    exports: [
                        DxoDropDownButtonToComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxiDropDownButtonToolbarItemComponent extends CollectionNestedOption {
    get cssClass() {
        return this._getOption('cssClass');
    }
    set cssClass(value) {
        this._setOption('cssClass', value);
    }
    get disabled() {
        return this._getOption('disabled');
    }
    set disabled(value) {
        this._setOption('disabled', value);
    }
    get html() {
        return this._getOption('html');
    }
    set html(value) {
        this._setOption('html', value);
    }
    get locateInMenu() {
        return this._getOption('locateInMenu');
    }
    set locateInMenu(value) {
        this._setOption('locateInMenu', value);
    }
    get location() {
        return this._getOption('location');
    }
    set location(value) {
        this._setOption('location', value);
    }
    get menuItemTemplate() {
        return this._getOption('menuItemTemplate');
    }
    set menuItemTemplate(value) {
        this._setOption('menuItemTemplate', value);
    }
    get options() {
        return this._getOption('options');
    }
    set options(value) {
        this._setOption('options', value);
    }
    get showText() {
        return this._getOption('showText');
    }
    set showText(value) {
        this._setOption('showText', value);
    }
    get template() {
        return this._getOption('template');
    }
    set template(value) {
        this._setOption('template', value);
    }
    get text() {
        return this._getOption('text');
    }
    set text(value) {
        this._setOption('text', value);
    }
    get toolbar() {
        return this._getOption('toolbar');
    }
    set toolbar(value) {
        this._setOption('toolbar', value);
    }
    get visible() {
        return this._getOption('visible');
    }
    set visible(value) {
        this._setOption('visible', value);
    }
    get widget() {
        return this._getOption('widget');
    }
    set widget(value) {
        this._setOption('widget', value);
    }
    get _optionPath() {
        return 'toolbarItems';
    }
    constructor(parentOptionHost, optionHost, renderer, document, templateHost, element) {
        super();
        this.renderer = renderer;
        this.document = document;
        this.element = element;
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
        templateHost.setHost(this);
    }
    setTemplate(template) {
        this.template = template;
    }
    ngAfterViewInit() {
        extractTemplate(this, this.element, this.renderer, this.document);
    }
    ngOnDestroy() {
        this._deleteRemovedOptions(this._fullOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiDropDownButtonToolbarItemComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }, { token: i0.Renderer2 }, { token: DOCUMENT }, { token: i1.DxTemplateHost, host: true }, { token: i0.ElementRef }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxiDropDownButtonToolbarItemComponent, isStandalone: true, selector: "dxi-drop-down-button-toolbar-item", inputs: { cssClass: "cssClass", disabled: "disabled", html: "html", locateInMenu: "locateInMenu", location: "location", menuItemTemplate: "menuItemTemplate", options: "options", showText: "showText", template: "template", text: "text", toolbar: "toolbar", visible: "visible", widget: "widget" }, providers: [
            NestedOptionHost,
            DxTemplateHost,
            {
                provide: PROPERTY_TOKEN_toolbarItems,
                useExisting: DxiDropDownButtonToolbarItemComponent,
            }
        ], usesInheritance: true, ngImport: i0, template: '<ng-content></ng-content>', isInline: true, styles: [":host{display:block}\n"], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiDropDownButtonToolbarItemComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxi-drop-down-button-toolbar-item', template: '<ng-content></ng-content>', imports: [DxIntegrationModule], providers: [
                        NestedOptionHost,
                        DxTemplateHost,
                        {
                            provide: PROPERTY_TOKEN_toolbarItems,
                            useExisting: DxiDropDownButtonToolbarItemComponent,
                        }
                    ], styles: [":host{display:block}\n"] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }, { type: i0.Renderer2 }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [DOCUMENT]
                }] }, { type: i1.DxTemplateHost, decorators: [{
                    type: Host
                }] }, { type: i0.ElementRef }], propDecorators: { cssClass: [{
                type: Input
            }], disabled: [{
                type: Input
            }], html: [{
                type: Input
            }], locateInMenu: [{
                type: Input
            }], location: [{
                type: Input
            }], menuItemTemplate: [{
                type: Input
            }], options: [{
                type: Input
            }], showText: [{
                type: Input
            }], template: [{
                type: Input
            }], text: [{
                type: Input
            }], toolbar: [{
                type: Input
            }], visible: [{
                type: Input
            }], widget: [{
                type: Input
            }] } });
class DxiDropDownButtonToolbarItemModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiDropDownButtonToolbarItemModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxiDropDownButtonToolbarItemModule, imports: [DxiDropDownButtonToolbarItemComponent], exports: [DxiDropDownButtonToolbarItemComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiDropDownButtonToolbarItemModule, imports: [DxiDropDownButtonToolbarItemComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiDropDownButtonToolbarItemModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxiDropDownButtonToolbarItemComponent
                    ],
                    exports: [
                        DxiDropDownButtonToolbarItemComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

/**
 * Generated bundle index. Do not edit.
 */

export { DxiDropDownButtonItemComponent, DxiDropDownButtonItemModule, DxiDropDownButtonToolbarItemComponent, DxiDropDownButtonToolbarItemModule, DxoDropDownButtonAnimationComponent, DxoDropDownButtonAnimationModule, DxoDropDownButtonAtComponent, DxoDropDownButtonAtModule, DxoDropDownButtonBoundaryOffsetComponent, DxoDropDownButtonBoundaryOffsetModule, DxoDropDownButtonCollisionComponent, DxoDropDownButtonCollisionModule, DxoDropDownButtonDropDownOptionsComponent, DxoDropDownButtonDropDownOptionsModule, DxoDropDownButtonFromComponent, DxoDropDownButtonFromModule, DxoDropDownButtonHideComponent, DxoDropDownButtonHideModule, DxoDropDownButtonMyComponent, DxoDropDownButtonMyModule, DxoDropDownButtonOffsetComponent, DxoDropDownButtonOffsetModule, DxoDropDownButtonPositionComponent, DxoDropDownButtonPositionModule, DxoDropDownButtonShowComponent, DxoDropDownButtonShowModule, DxoDropDownButtonToComponent, DxoDropDownButtonToModule };
//# sourceMappingURL=devextreme-angular-ui-drop-down-button-nested.mjs.map
