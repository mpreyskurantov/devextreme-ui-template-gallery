import * as i0 from '@angular/core';
import { PLATFORM_ID, Output, Input, Inject, Component, NgModule } from '@angular/core';
import DxFunnel from 'devextreme/viz/funnel';
import * as i1 from 'devextreme-angular/core';
import { DxComponent, DxIntegrationModule, DxTemplateHost, WatcherHelper, NestedOptionHost, IterableDifferHelper, DxTemplateModule } from 'devextreme-angular/core';
import { DxoAdaptiveLayoutModule, DxoExportModule, DxoItemModule, DxoBorderModule, DxoHoverStyleModule, DxoHatchingModule, DxoSelectionStyleModule, DxoLabelModule, DxoConnectorModule, DxoFontModule, DxoFormatModule, DxoLegendModule, DxoMarginModule, DxoTitleModule, DxoSubtitleModule, DxoLoadingIndicatorModule, DxoSizeModule, DxoTooltipModule, DxoShadowModule } from 'devextreme-angular/ui/nested';
import { DxoFunnelAdaptiveLayoutModule, DxoFunnelBorderModule, DxoFunnelConnectorModule, DxoFunnelExportModule, DxoFunnelFontModule, DxoFunnelFormatModule, DxoFunnelFunnelTitleModule, DxoFunnelFunnelTitleSubtitleModule, DxoFunnelHatchingModule, DxoFunnelHoverStyleModule, DxoFunnelItemModule, DxoFunnelItemBorderModule, DxoFunnelLabelModule, DxoFunnelLabelBorderModule, DxoFunnelLegendModule, DxoFunnelLegendBorderModule, DxoFunnelLegendTitleModule, DxoFunnelLegendTitleSubtitleModule, DxoFunnelLoadingIndicatorModule, DxoFunnelMarginModule, DxoFunnelSelectionStyleModule, DxoFunnelShadowModule, DxoFunnelSizeModule, DxoFunnelSubtitleModule, DxoFunnelTitleModule, DxoFunnelTooltipModule, DxoFunnelTooltipBorderModule } from 'devextreme-angular/ui/funnel/nested';
export * from 'devextreme-angular/ui/funnel/nested';

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
/**
 * [descr:dxFunnel]

 */
class DxFunnelComponent extends DxComponent {
    /**
     * [descr:dxFunnelOptions.adaptiveLayout]
    
     */
    get adaptiveLayout() {
        return this._getOption('adaptiveLayout');
    }
    set adaptiveLayout(value) {
        this._setOption('adaptiveLayout', value);
    }
    /**
     * [descr:dxFunnelOptions.algorithm]
    
     */
    get algorithm() {
        return this._getOption('algorithm');
    }
    set algorithm(value) {
        this._setOption('algorithm', value);
    }
    /**
     * [descr:dxFunnelOptions.argumentField]
    
     */
    get argumentField() {
        return this._getOption('argumentField');
    }
    set argumentField(value) {
        this._setOption('argumentField', value);
    }
    /**
     * [descr:dxFunnelOptions.colorField]
    
     */
    get colorField() {
        return this._getOption('colorField');
    }
    set colorField(value) {
        this._setOption('colorField', value);
    }
    /**
     * [descr:dxFunnelOptions.dataSource]
    
     */
    get dataSource() {
        return this._getOption('dataSource');
    }
    set dataSource(value) {
        this._setOption('dataSource', value);
    }
    /**
     * [descr:BaseWidgetOptions.disabled]
    
     */
    get disabled() {
        return this._getOption('disabled');
    }
    set disabled(value) {
        this._setOption('disabled', value);
    }
    /**
     * [descr:DOMComponentOptions.elementAttr]
    
     */
    get elementAttr() {
        return this._getOption('elementAttr');
    }
    set elementAttr(value) {
        this._setOption('elementAttr', value);
    }
    /**
     * [descr:BaseWidgetOptions.encodeHtml]
    
     */
    get encodeHtml() {
        return this._getOption('encodeHtml');
    }
    set encodeHtml(value) {
        this._setOption('encodeHtml', value);
    }
    /**
     * [descr:BaseWidgetOptions.export]
    
     */
    get export() {
        return this._getOption('export');
    }
    set export(value) {
        this._setOption('export', value);
    }
    /**
     * [descr:dxFunnelOptions.hoverEnabled]
    
     */
    get hoverEnabled() {
        return this._getOption('hoverEnabled');
    }
    set hoverEnabled(value) {
        this._setOption('hoverEnabled', value);
    }
    /**
     * [descr:dxFunnelOptions.inverted]
    
     */
    get inverted() {
        return this._getOption('inverted');
    }
    set inverted(value) {
        this._setOption('inverted', value);
    }
    /**
     * [descr:dxFunnelOptions.item]
    
     */
    get item() {
        return this._getOption('item');
    }
    set item(value) {
        this._setOption('item', value);
    }
    /**
     * [descr:dxFunnelOptions.label]
    
     */
    get label() {
        return this._getOption('label');
    }
    set label(value) {
        this._setOption('label', value);
    }
    /**
     * [descr:dxFunnelOptions.legend]
    
     */
    get legend() {
        return this._getOption('legend');
    }
    set legend(value) {
        this._setOption('legend', value);
    }
    /**
     * [descr:BaseWidgetOptions.loadingIndicator]
    
     */
    get loadingIndicator() {
        return this._getOption('loadingIndicator');
    }
    set loadingIndicator(value) {
        this._setOption('loadingIndicator', value);
    }
    /**
     * [descr:BaseWidgetOptions.margin]
    
     */
    get margin() {
        return this._getOption('margin');
    }
    set margin(value) {
        this._setOption('margin', value);
    }
    /**
     * [descr:dxFunnelOptions.neckHeight]
    
     */
    get neckHeight() {
        return this._getOption('neckHeight');
    }
    set neckHeight(value) {
        this._setOption('neckHeight', value);
    }
    /**
     * [descr:dxFunnelOptions.neckWidth]
    
     */
    get neckWidth() {
        return this._getOption('neckWidth');
    }
    set neckWidth(value) {
        this._setOption('neckWidth', value);
    }
    /**
     * [descr:dxFunnelOptions.palette]
    
     */
    get palette() {
        return this._getOption('palette');
    }
    set palette(value) {
        this._setOption('palette', value);
    }
    /**
     * [descr:dxFunnelOptions.paletteExtensionMode]
    
     */
    get paletteExtensionMode() {
        return this._getOption('paletteExtensionMode');
    }
    set paletteExtensionMode(value) {
        this._setOption('paletteExtensionMode', value);
    }
    /**
     * [descr:BaseWidgetOptions.pathModified]
    
     */
    get pathModified() {
        return this._getOption('pathModified');
    }
    set pathModified(value) {
        this._setOption('pathModified', value);
    }
    /**
     * [descr:BaseWidgetOptions.redrawOnResize]
    
     */
    get redrawOnResize() {
        return this._getOption('redrawOnResize');
    }
    set redrawOnResize(value) {
        this._setOption('redrawOnResize', value);
    }
    /**
     * [descr:dxFunnelOptions.resolveLabelOverlapping]
    
     */
    get resolveLabelOverlapping() {
        return this._getOption('resolveLabelOverlapping');
    }
    set resolveLabelOverlapping(value) {
        this._setOption('resolveLabelOverlapping', value);
    }
    /**
     * [descr:BaseWidgetOptions.rtlEnabled]
    
     */
    get rtlEnabled() {
        return this._getOption('rtlEnabled');
    }
    set rtlEnabled(value) {
        this._setOption('rtlEnabled', value);
    }
    /**
     * [descr:dxFunnelOptions.selectionMode]
    
     */
    get selectionMode() {
        return this._getOption('selectionMode');
    }
    set selectionMode(value) {
        this._setOption('selectionMode', value);
    }
    /**
     * [descr:BaseWidgetOptions.size]
    
     */
    get size() {
        return this._getOption('size');
    }
    set size(value) {
        this._setOption('size', value);
    }
    /**
     * [descr:dxFunnelOptions.sortData]
    
     */
    get sortData() {
        return this._getOption('sortData');
    }
    set sortData(value) {
        this._setOption('sortData', value);
    }
    /**
     * [descr:BaseWidgetOptions.theme]
    
     */
    get theme() {
        return this._getOption('theme');
    }
    set theme(value) {
        this._setOption('theme', value);
    }
    /**
     * [descr:BaseWidgetOptions.title]
    
     */
    get title() {
        return this._getOption('title');
    }
    set title(value) {
        this._setOption('title', value);
    }
    /**
     * [descr:dxFunnelOptions.tooltip]
    
     */
    get tooltip() {
        return this._getOption('tooltip');
    }
    set tooltip(value) {
        this._setOption('tooltip', value);
    }
    /**
     * [descr:dxFunnelOptions.valueField]
    
     */
    get valueField() {
        return this._getOption('valueField');
    }
    set valueField(value) {
        this._setOption('valueField', value);
    }
    constructor(elementRef, ngZone, templateHost, _watcherHelper, _idh, optionHost, transferState, platformId) {
        super(elementRef, ngZone, templateHost, _watcherHelper, transferState, platformId);
        this._watcherHelper = _watcherHelper;
        this._idh = _idh;
        this.instance = null;
        this._createEventEmitters([
            { subscribe: 'disposing', emit: 'onDisposing' },
            { subscribe: 'drawn', emit: 'onDrawn' },
            { subscribe: 'exported', emit: 'onExported' },
            { subscribe: 'exporting', emit: 'onExporting' },
            { subscribe: 'fileSaving', emit: 'onFileSaving' },
            { subscribe: 'hoverChanged', emit: 'onHoverChanged' },
            { subscribe: 'incidentOccurred', emit: 'onIncidentOccurred' },
            { subscribe: 'initialized', emit: 'onInitialized' },
            { subscribe: 'itemClick', emit: 'onItemClick' },
            { subscribe: 'legendClick', emit: 'onLegendClick' },
            { subscribe: 'optionChanged', emit: 'onOptionChanged' },
            { subscribe: 'selectionChanged', emit: 'onSelectionChanged' },
            { emit: 'adaptiveLayoutChange' },
            { emit: 'algorithmChange' },
            { emit: 'argumentFieldChange' },
            { emit: 'colorFieldChange' },
            { emit: 'dataSourceChange' },
            { emit: 'disabledChange' },
            { emit: 'elementAttrChange' },
            { emit: 'encodeHtmlChange' },
            { emit: 'exportChange' },
            { emit: 'hoverEnabledChange' },
            { emit: 'invertedChange' },
            { emit: 'itemChange' },
            { emit: 'labelChange' },
            { emit: 'legendChange' },
            { emit: 'loadingIndicatorChange' },
            { emit: 'marginChange' },
            { emit: 'neckHeightChange' },
            { emit: 'neckWidthChange' },
            { emit: 'paletteChange' },
            { emit: 'paletteExtensionModeChange' },
            { emit: 'pathModifiedChange' },
            { emit: 'redrawOnResizeChange' },
            { emit: 'resolveLabelOverlappingChange' },
            { emit: 'rtlEnabledChange' },
            { emit: 'selectionModeChange' },
            { emit: 'sizeChange' },
            { emit: 'sortDataChange' },
            { emit: 'themeChange' },
            { emit: 'titleChange' },
            { emit: 'tooltipChange' },
            { emit: 'valueFieldChange' }
        ]);
        this._idh.setHost(this);
        optionHost.setHost(this);
    }
    _createInstance(element, options) {
        return new DxFunnel(element, options);
    }
    ngOnDestroy() {
        this._destroyWidget();
    }
    ngOnChanges(changes) {
        super.ngOnChanges(changes);
        this.setupChanges('dataSource', changes);
        this.setupChanges('palette', changes);
    }
    setupChanges(prop, changes) {
        if (!(prop in this._optionsToUpdate)) {
            this._idh.setup(prop, changes);
        }
    }
    ngDoCheck() {
        this._idh.doCheck('dataSource');
        this._idh.doCheck('palette');
        this._watcherHelper.checkWatchers();
        super.ngDoCheck();
        super.clearChangedOptions();
    }
    _setOption(name, value) {
        let isSetup = this._idh.setupSingle(name, value);
        let isChanged = this._idh.getChanges(name, value) !== null;
        if (isSetup || isChanged) {
            super._setOption(name, value);
        }
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxFunnelComponent, deps: [{ token: i0.ElementRef }, { token: i0.NgZone }, { token: i1.DxTemplateHost }, { token: i1.WatcherHelper }, { token: i1.IterableDifferHelper }, { token: i1.NestedOptionHost }, { token: i0.TransferState }, { token: PLATFORM_ID }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxFunnelComponent, isStandalone: true, selector: "dx-funnel", inputs: { adaptiveLayout: "adaptiveLayout", algorithm: "algorithm", argumentField: "argumentField", colorField: "colorField", dataSource: "dataSource", disabled: "disabled", elementAttr: "elementAttr", encodeHtml: "encodeHtml", export: "export", hoverEnabled: "hoverEnabled", inverted: "inverted", item: "item", label: "label", legend: "legend", loadingIndicator: "loadingIndicator", margin: "margin", neckHeight: "neckHeight", neckWidth: "neckWidth", palette: "palette", paletteExtensionMode: "paletteExtensionMode", pathModified: "pathModified", redrawOnResize: "redrawOnResize", resolveLabelOverlapping: "resolveLabelOverlapping", rtlEnabled: "rtlEnabled", selectionMode: "selectionMode", size: "size", sortData: "sortData", theme: "theme", title: "title", tooltip: "tooltip", valueField: "valueField" }, outputs: { onDisposing: "onDisposing", onDrawn: "onDrawn", onExported: "onExported", onExporting: "onExporting", onFileSaving: "onFileSaving", onHoverChanged: "onHoverChanged", onIncidentOccurred: "onIncidentOccurred", onInitialized: "onInitialized", onItemClick: "onItemClick", onLegendClick: "onLegendClick", onOptionChanged: "onOptionChanged", onSelectionChanged: "onSelectionChanged", adaptiveLayoutChange: "adaptiveLayoutChange", algorithmChange: "algorithmChange", argumentFieldChange: "argumentFieldChange", colorFieldChange: "colorFieldChange", dataSourceChange: "dataSourceChange", disabledChange: "disabledChange", elementAttrChange: "elementAttrChange", encodeHtmlChange: "encodeHtmlChange", exportChange: "exportChange", hoverEnabledChange: "hoverEnabledChange", invertedChange: "invertedChange", itemChange: "itemChange", labelChange: "labelChange", legendChange: "legendChange", loadingIndicatorChange: "loadingIndicatorChange", marginChange: "marginChange", neckHeightChange: "neckHeightChange", neckWidthChange: "neckWidthChange", paletteChange: "paletteChange", paletteExtensionModeChange: "paletteExtensionModeChange", pathModifiedChange: "pathModifiedChange", redrawOnResizeChange: "redrawOnResizeChange", resolveLabelOverlappingChange: "resolveLabelOverlappingChange", rtlEnabledChange: "rtlEnabledChange", selectionModeChange: "selectionModeChange", sizeChange: "sizeChange", sortDataChange: "sortDataChange", themeChange: "themeChange", titleChange: "titleChange", tooltipChange: "tooltipChange", valueFieldChange: "valueFieldChange" }, host: { attributes: { "ngSkipHydration": "true" } }, providers: [
            DxTemplateHost,
            WatcherHelper,
            NestedOptionHost,
            IterableDifferHelper
        ], usesInheritance: true, usesOnChanges: true, ngImport: i0, template: '', isInline: true, styles: [":host{display:block}\n"], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxFunnelComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dx-funnel', template: '', host: { ngSkipHydration: 'true' }, imports: [DxIntegrationModule], providers: [
                        DxTemplateHost,
                        WatcherHelper,
                        NestedOptionHost,
                        IterableDifferHelper
                    ], styles: [":host{display:block}\n"] }]
        }], ctorParameters: () => [{ type: i0.ElementRef }, { type: i0.NgZone }, { type: i1.DxTemplateHost }, { type: i1.WatcherHelper }, { type: i1.IterableDifferHelper }, { type: i1.NestedOptionHost }, { type: i0.TransferState }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [PLATFORM_ID]
                }] }], propDecorators: { adaptiveLayout: [{
                type: Input
            }], algorithm: [{
                type: Input
            }], argumentField: [{
                type: Input
            }], colorField: [{
                type: Input
            }], dataSource: [{
                type: Input
            }], disabled: [{
                type: Input
            }], elementAttr: [{
                type: Input
            }], encodeHtml: [{
                type: Input
            }], export: [{
                type: Input
            }], hoverEnabled: [{
                type: Input
            }], inverted: [{
                type: Input
            }], item: [{
                type: Input
            }], label: [{
                type: Input
            }], legend: [{
                type: Input
            }], loadingIndicator: [{
                type: Input
            }], margin: [{
                type: Input
            }], neckHeight: [{
                type: Input
            }], neckWidth: [{
                type: Input
            }], palette: [{
                type: Input
            }], paletteExtensionMode: [{
                type: Input
            }], pathModified: [{
                type: Input
            }], redrawOnResize: [{
                type: Input
            }], resolveLabelOverlapping: [{
                type: Input
            }], rtlEnabled: [{
                type: Input
            }], selectionMode: [{
                type: Input
            }], size: [{
                type: Input
            }], sortData: [{
                type: Input
            }], theme: [{
                type: Input
            }], title: [{
                type: Input
            }], tooltip: [{
                type: Input
            }], valueField: [{
                type: Input
            }], onDisposing: [{
                type: Output
            }], onDrawn: [{
                type: Output
            }], onExported: [{
                type: Output
            }], onExporting: [{
                type: Output
            }], onFileSaving: [{
                type: Output
            }], onHoverChanged: [{
                type: Output
            }], onIncidentOccurred: [{
                type: Output
            }], onInitialized: [{
                type: Output
            }], onItemClick: [{
                type: Output
            }], onLegendClick: [{
                type: Output
            }], onOptionChanged: [{
                type: Output
            }], onSelectionChanged: [{
                type: Output
            }], adaptiveLayoutChange: [{
                type: Output
            }], algorithmChange: [{
                type: Output
            }], argumentFieldChange: [{
                type: Output
            }], colorFieldChange: [{
                type: Output
            }], dataSourceChange: [{
                type: Output
            }], disabledChange: [{
                type: Output
            }], elementAttrChange: [{
                type: Output
            }], encodeHtmlChange: [{
                type: Output
            }], exportChange: [{
                type: Output
            }], hoverEnabledChange: [{
                type: Output
            }], invertedChange: [{
                type: Output
            }], itemChange: [{
                type: Output
            }], labelChange: [{
                type: Output
            }], legendChange: [{
                type: Output
            }], loadingIndicatorChange: [{
                type: Output
            }], marginChange: [{
                type: Output
            }], neckHeightChange: [{
                type: Output
            }], neckWidthChange: [{
                type: Output
            }], paletteChange: [{
                type: Output
            }], paletteExtensionModeChange: [{
                type: Output
            }], pathModifiedChange: [{
                type: Output
            }], redrawOnResizeChange: [{
                type: Output
            }], resolveLabelOverlappingChange: [{
                type: Output
            }], rtlEnabledChange: [{
                type: Output
            }], selectionModeChange: [{
                type: Output
            }], sizeChange: [{
                type: Output
            }], sortDataChange: [{
                type: Output
            }], themeChange: [{
                type: Output
            }], titleChange: [{
                type: Output
            }], tooltipChange: [{
                type: Output
            }], valueFieldChange: [{
                type: Output
            }] } });
class DxFunnelModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxFunnelModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxFunnelModule, imports: [DxFunnelComponent, DxoAdaptiveLayoutModule,
            DxoExportModule,
            DxoItemModule,
            DxoBorderModule,
            DxoHoverStyleModule,
            DxoHatchingModule,
            DxoSelectionStyleModule,
            DxoLabelModule,
            DxoConnectorModule,
            DxoFontModule,
            DxoFormatModule,
            DxoLegendModule,
            DxoMarginModule,
            DxoTitleModule,
            DxoSubtitleModule,
            DxoLoadingIndicatorModule,
            DxoSizeModule,
            DxoTooltipModule,
            DxoShadowModule,
            DxoFunnelAdaptiveLayoutModule,
            DxoFunnelBorderModule,
            DxoFunnelConnectorModule,
            DxoFunnelExportModule,
            DxoFunnelFontModule,
            DxoFunnelFormatModule,
            DxoFunnelFunnelTitleModule,
            DxoFunnelFunnelTitleSubtitleModule,
            DxoFunnelHatchingModule,
            DxoFunnelHoverStyleModule,
            DxoFunnelItemModule,
            DxoFunnelItemBorderModule,
            DxoFunnelLabelModule,
            DxoFunnelLabelBorderModule,
            DxoFunnelLegendModule,
            DxoFunnelLegendBorderModule,
            DxoFunnelLegendTitleModule,
            DxoFunnelLegendTitleSubtitleModule,
            DxoFunnelLoadingIndicatorModule,
            DxoFunnelMarginModule,
            DxoFunnelSelectionStyleModule,
            DxoFunnelShadowModule,
            DxoFunnelSizeModule,
            DxoFunnelSubtitleModule,
            DxoFunnelTitleModule,
            DxoFunnelTooltipModule,
            DxoFunnelTooltipBorderModule,
            DxIntegrationModule,
            DxTemplateModule], exports: [DxFunnelComponent, DxoAdaptiveLayoutModule,
            DxoExportModule,
            DxoItemModule,
            DxoBorderModule,
            DxoHoverStyleModule,
            DxoHatchingModule,
            DxoSelectionStyleModule,
            DxoLabelModule,
            DxoConnectorModule,
            DxoFontModule,
            DxoFormatModule,
            DxoLegendModule,
            DxoMarginModule,
            DxoTitleModule,
            DxoSubtitleModule,
            DxoLoadingIndicatorModule,
            DxoSizeModule,
            DxoTooltipModule,
            DxoShadowModule,
            DxoFunnelAdaptiveLayoutModule,
            DxoFunnelBorderModule,
            DxoFunnelConnectorModule,
            DxoFunnelExportModule,
            DxoFunnelFontModule,
            DxoFunnelFormatModule,
            DxoFunnelFunnelTitleModule,
            DxoFunnelFunnelTitleSubtitleModule,
            DxoFunnelHatchingModule,
            DxoFunnelHoverStyleModule,
            DxoFunnelItemModule,
            DxoFunnelItemBorderModule,
            DxoFunnelLabelModule,
            DxoFunnelLabelBorderModule,
            DxoFunnelLegendModule,
            DxoFunnelLegendBorderModule,
            DxoFunnelLegendTitleModule,
            DxoFunnelLegendTitleSubtitleModule,
            DxoFunnelLoadingIndicatorModule,
            DxoFunnelMarginModule,
            DxoFunnelSelectionStyleModule,
            DxoFunnelShadowModule,
            DxoFunnelSizeModule,
            DxoFunnelSubtitleModule,
            DxoFunnelTitleModule,
            DxoFunnelTooltipModule,
            DxoFunnelTooltipBorderModule,
            DxTemplateModule] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxFunnelModule, imports: [DxFunnelComponent,
            DxoAdaptiveLayoutModule,
            DxoExportModule,
            DxoItemModule,
            DxoBorderModule,
            DxoHoverStyleModule,
            DxoHatchingModule,
            DxoSelectionStyleModule,
            DxoLabelModule,
            DxoConnectorModule,
            DxoFontModule,
            DxoFormatModule,
            DxoLegendModule,
            DxoMarginModule,
            DxoTitleModule,
            DxoSubtitleModule,
            DxoLoadingIndicatorModule,
            DxoSizeModule,
            DxoTooltipModule,
            DxoShadowModule,
            DxoFunnelAdaptiveLayoutModule,
            DxoFunnelBorderModule,
            DxoFunnelConnectorModule,
            DxoFunnelExportModule,
            DxoFunnelFontModule,
            DxoFunnelFormatModule,
            DxoFunnelFunnelTitleModule,
            DxoFunnelFunnelTitleSubtitleModule,
            DxoFunnelHatchingModule,
            DxoFunnelHoverStyleModule,
            DxoFunnelItemModule,
            DxoFunnelItemBorderModule,
            DxoFunnelLabelModule,
            DxoFunnelLabelBorderModule,
            DxoFunnelLegendModule,
            DxoFunnelLegendBorderModule,
            DxoFunnelLegendTitleModule,
            DxoFunnelLegendTitleSubtitleModule,
            DxoFunnelLoadingIndicatorModule,
            DxoFunnelMarginModule,
            DxoFunnelSelectionStyleModule,
            DxoFunnelShadowModule,
            DxoFunnelSizeModule,
            DxoFunnelSubtitleModule,
            DxoFunnelTitleModule,
            DxoFunnelTooltipModule,
            DxoFunnelTooltipBorderModule,
            DxIntegrationModule,
            DxTemplateModule, DxoAdaptiveLayoutModule,
            DxoExportModule,
            DxoItemModule,
            DxoBorderModule,
            DxoHoverStyleModule,
            DxoHatchingModule,
            DxoSelectionStyleModule,
            DxoLabelModule,
            DxoConnectorModule,
            DxoFontModule,
            DxoFormatModule,
            DxoLegendModule,
            DxoMarginModule,
            DxoTitleModule,
            DxoSubtitleModule,
            DxoLoadingIndicatorModule,
            DxoSizeModule,
            DxoTooltipModule,
            DxoShadowModule,
            DxoFunnelAdaptiveLayoutModule,
            DxoFunnelBorderModule,
            DxoFunnelConnectorModule,
            DxoFunnelExportModule,
            DxoFunnelFontModule,
            DxoFunnelFormatModule,
            DxoFunnelFunnelTitleModule,
            DxoFunnelFunnelTitleSubtitleModule,
            DxoFunnelHatchingModule,
            DxoFunnelHoverStyleModule,
            DxoFunnelItemModule,
            DxoFunnelItemBorderModule,
            DxoFunnelLabelModule,
            DxoFunnelLabelBorderModule,
            DxoFunnelLegendModule,
            DxoFunnelLegendBorderModule,
            DxoFunnelLegendTitleModule,
            DxoFunnelLegendTitleSubtitleModule,
            DxoFunnelLoadingIndicatorModule,
            DxoFunnelMarginModule,
            DxoFunnelSelectionStyleModule,
            DxoFunnelShadowModule,
            DxoFunnelSizeModule,
            DxoFunnelSubtitleModule,
            DxoFunnelTitleModule,
            DxoFunnelTooltipModule,
            DxoFunnelTooltipBorderModule,
            DxTemplateModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxFunnelModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxFunnelComponent,
                        DxoAdaptiveLayoutModule,
                        DxoExportModule,
                        DxoItemModule,
                        DxoBorderModule,
                        DxoHoverStyleModule,
                        DxoHatchingModule,
                        DxoSelectionStyleModule,
                        DxoLabelModule,
                        DxoConnectorModule,
                        DxoFontModule,
                        DxoFormatModule,
                        DxoLegendModule,
                        DxoMarginModule,
                        DxoTitleModule,
                        DxoSubtitleModule,
                        DxoLoadingIndicatorModule,
                        DxoSizeModule,
                        DxoTooltipModule,
                        DxoShadowModule,
                        DxoFunnelAdaptiveLayoutModule,
                        DxoFunnelBorderModule,
                        DxoFunnelConnectorModule,
                        DxoFunnelExportModule,
                        DxoFunnelFontModule,
                        DxoFunnelFormatModule,
                        DxoFunnelFunnelTitleModule,
                        DxoFunnelFunnelTitleSubtitleModule,
                        DxoFunnelHatchingModule,
                        DxoFunnelHoverStyleModule,
                        DxoFunnelItemModule,
                        DxoFunnelItemBorderModule,
                        DxoFunnelLabelModule,
                        DxoFunnelLabelBorderModule,
                        DxoFunnelLegendModule,
                        DxoFunnelLegendBorderModule,
                        DxoFunnelLegendTitleModule,
                        DxoFunnelLegendTitleSubtitleModule,
                        DxoFunnelLoadingIndicatorModule,
                        DxoFunnelMarginModule,
                        DxoFunnelSelectionStyleModule,
                        DxoFunnelShadowModule,
                        DxoFunnelSizeModule,
                        DxoFunnelSubtitleModule,
                        DxoFunnelTitleModule,
                        DxoFunnelTooltipModule,
                        DxoFunnelTooltipBorderModule,
                        DxIntegrationModule,
                        DxTemplateModule
                    ],
                    exports: [
                        DxFunnelComponent,
                        DxoAdaptiveLayoutModule,
                        DxoExportModule,
                        DxoItemModule,
                        DxoBorderModule,
                        DxoHoverStyleModule,
                        DxoHatchingModule,
                        DxoSelectionStyleModule,
                        DxoLabelModule,
                        DxoConnectorModule,
                        DxoFontModule,
                        DxoFormatModule,
                        DxoLegendModule,
                        DxoMarginModule,
                        DxoTitleModule,
                        DxoSubtitleModule,
                        DxoLoadingIndicatorModule,
                        DxoSizeModule,
                        DxoTooltipModule,
                        DxoShadowModule,
                        DxoFunnelAdaptiveLayoutModule,
                        DxoFunnelBorderModule,
                        DxoFunnelConnectorModule,
                        DxoFunnelExportModule,
                        DxoFunnelFontModule,
                        DxoFunnelFormatModule,
                        DxoFunnelFunnelTitleModule,
                        DxoFunnelFunnelTitleSubtitleModule,
                        DxoFunnelHatchingModule,
                        DxoFunnelHoverStyleModule,
                        DxoFunnelItemModule,
                        DxoFunnelItemBorderModule,
                        DxoFunnelLabelModule,
                        DxoFunnelLabelBorderModule,
                        DxoFunnelLegendModule,
                        DxoFunnelLegendBorderModule,
                        DxoFunnelLegendTitleModule,
                        DxoFunnelLegendTitleSubtitleModule,
                        DxoFunnelLoadingIndicatorModule,
                        DxoFunnelMarginModule,
                        DxoFunnelSelectionStyleModule,
                        DxoFunnelShadowModule,
                        DxoFunnelSizeModule,
                        DxoFunnelSubtitleModule,
                        DxoFunnelTitleModule,
                        DxoFunnelTooltipModule,
                        DxoFunnelTooltipBorderModule,
                        DxTemplateModule
                    ]
                }]
        }] });

/**
 * Generated bundle index. Do not edit.
 */

export { DxFunnelComponent, DxFunnelModule };
//# sourceMappingURL=devextreme-angular-ui-funnel.mjs.map
