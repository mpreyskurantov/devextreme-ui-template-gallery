import * as i0 from '@angular/core';
import { PLATFORM_ID, Output, Input, ContentChildren, Inject, Component, NgModule } from '@angular/core';
import DxFileManager from 'devextreme/ui/file_manager';
import * as i1 from 'devextreme-angular/core';
import { DxComponent, DxIntegrationModule, DxTemplateHost, WatcherHelper, NestedOptionHost, IterableDifferHelper, DxTemplateModule } from 'devextreme-angular/core';
import { DxoContextMenuModule, DxiItemModule, DxoItemViewModule, DxoDetailsModule, DxiColumnModule, DxoNotificationsModule, DxoPermissionsModule, DxoToolbarModule, DxiFileSelectionItemModule, DxoUploadModule } from 'devextreme-angular/ui/nested';
import { DxiFileManagerColumnModule, DxoFileManagerContextMenuModule, DxiFileManagerContextMenuItemModule, DxoFileManagerDetailsModule, DxiFileManagerFileSelectionItemModule, DxiFileManagerItemModule, DxoFileManagerItemViewModule, DxoFileManagerNotificationsModule, DxoFileManagerPermissionsModule, DxoFileManagerToolbarModule, DxiFileManagerToolbarItemModule, DxoFileManagerUploadModule } from 'devextreme-angular/ui/file-manager/nested';
export * from 'devextreme-angular/ui/file-manager/nested';
import { PROPERTY_TOKEN_columns, PROPERTY_TOKEN_items, PROPERTY_TOKEN_fileSelectionItems } from 'devextreme-angular/core/tokens';

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
/**
 * [descr:dxFileManager]

 */
class DxFileManagerComponent extends DxComponent {
    set _columnsContentChildren(value) {
        this.setChildren('columns', value);
    }
    set _itemsContentChildren(value) {
        this.setChildren('items', value);
    }
    set _fileSelectionItemsContentChildren(value) {
        this.setChildren('fileSelectionItems', value);
    }
    /**
     * [descr:WidgetOptions.accessKey]
    
     */
    get accessKey() {
        return this._getOption('accessKey');
    }
    set accessKey(value) {
        this._setOption('accessKey', value);
    }
    /**
     * [descr:WidgetOptions.activeStateEnabled]
    
     */
    get activeStateEnabled() {
        return this._getOption('activeStateEnabled');
    }
    set activeStateEnabled(value) {
        this._setOption('activeStateEnabled', value);
    }
    /**
     * [descr:dxFileManagerOptions.allowedFileExtensions]
    
     */
    get allowedFileExtensions() {
        return this._getOption('allowedFileExtensions');
    }
    set allowedFileExtensions(value) {
        this._setOption('allowedFileExtensions', value);
    }
    /**
     * [descr:dxFileManagerOptions.contextMenu]
    
     */
    get contextMenu() {
        return this._getOption('contextMenu');
    }
    set contextMenu(value) {
        this._setOption('contextMenu', value);
    }
    /**
     * [descr:dxFileManagerOptions.currentPath]
    
     */
    get currentPath() {
        return this._getOption('currentPath');
    }
    set currentPath(value) {
        this._setOption('currentPath', value);
    }
    /**
     * [descr:dxFileManagerOptions.currentPathKeys]
    
     */
    get currentPathKeys() {
        return this._getOption('currentPathKeys');
    }
    set currentPathKeys(value) {
        this._setOption('currentPathKeys', value);
    }
    /**
     * [descr:dxFileManagerOptions.customizeDetailColumns]
    
     */
    get customizeDetailColumns() {
        return this._getOption('customizeDetailColumns');
    }
    set customizeDetailColumns(value) {
        this._setOption('customizeDetailColumns', value);
    }
    /**
     * [descr:dxFileManagerOptions.customizeThumbnail]
    
     */
    get customizeThumbnail() {
        return this._getOption('customizeThumbnail');
    }
    set customizeThumbnail(value) {
        this._setOption('customizeThumbnail', value);
    }
    /**
     * [descr:WidgetOptions.disabled]
    
     */
    get disabled() {
        return this._getOption('disabled');
    }
    set disabled(value) {
        this._setOption('disabled', value);
    }
    /**
     * [descr:DOMComponentOptions.elementAttr]
    
     */
    get elementAttr() {
        return this._getOption('elementAttr');
    }
    set elementAttr(value) {
        this._setOption('elementAttr', value);
    }
    /**
     * [descr:dxFileManagerOptions.fileSystemProvider]
    
     */
    get fileSystemProvider() {
        return this._getOption('fileSystemProvider');
    }
    set fileSystemProvider(value) {
        this._setOption('fileSystemProvider', value);
    }
    /**
     * [descr:dxFileManagerOptions.focusedItemKey]
    
     */
    get focusedItemKey() {
        return this._getOption('focusedItemKey');
    }
    set focusedItemKey(value) {
        this._setOption('focusedItemKey', value);
    }
    /**
     * [descr:WidgetOptions.focusStateEnabled]
    
     */
    get focusStateEnabled() {
        return this._getOption('focusStateEnabled');
    }
    set focusStateEnabled(value) {
        this._setOption('focusStateEnabled', value);
    }
    /**
     * [descr:DOMComponentOptions.height]
    
     */
    get height() {
        return this._getOption('height');
    }
    set height(value) {
        this._setOption('height', value);
    }
    /**
     * [descr:WidgetOptions.hint]
    
     */
    get hint() {
        return this._getOption('hint');
    }
    set hint(value) {
        this._setOption('hint', value);
    }
    /**
     * [descr:WidgetOptions.hoverStateEnabled]
    
     */
    get hoverStateEnabled() {
        return this._getOption('hoverStateEnabled');
    }
    set hoverStateEnabled(value) {
        this._setOption('hoverStateEnabled', value);
    }
    /**
     * [descr:dxFileManagerOptions.itemView]
    
     */
    get itemView() {
        return this._getOption('itemView');
    }
    set itemView(value) {
        this._setOption('itemView', value);
    }
    /**
     * [descr:dxFileManagerOptions.notifications]
    
     */
    get notifications() {
        return this._getOption('notifications');
    }
    set notifications(value) {
        this._setOption('notifications', value);
    }
    /**
     * [descr:dxFileManagerOptions.permissions]
    
     */
    get permissions() {
        return this._getOption('permissions');
    }
    set permissions(value) {
        this._setOption('permissions', value);
    }
    /**
     * [descr:dxFileManagerOptions.rootFolderName]
    
     */
    get rootFolderName() {
        return this._getOption('rootFolderName');
    }
    set rootFolderName(value) {
        this._setOption('rootFolderName', value);
    }
    /**
     * [descr:DOMComponentOptions.rtlEnabled]
    
     */
    get rtlEnabled() {
        return this._getOption('rtlEnabled');
    }
    set rtlEnabled(value) {
        this._setOption('rtlEnabled', value);
    }
    /**
     * [descr:dxFileManagerOptions.selectedItemKeys]
    
     */
    get selectedItemKeys() {
        return this._getOption('selectedItemKeys');
    }
    set selectedItemKeys(value) {
        this._setOption('selectedItemKeys', value);
    }
    /**
     * [descr:dxFileManagerOptions.selectionMode]
    
     */
    get selectionMode() {
        return this._getOption('selectionMode');
    }
    set selectionMode(value) {
        this._setOption('selectionMode', value);
    }
    /**
     * [descr:WidgetOptions.tabIndex]
    
     */
    get tabIndex() {
        return this._getOption('tabIndex');
    }
    set tabIndex(value) {
        this._setOption('tabIndex', value);
    }
    /**
     * [descr:dxFileManagerOptions.toolbar]
    
     */
    get toolbar() {
        return this._getOption('toolbar');
    }
    set toolbar(value) {
        this._setOption('toolbar', value);
    }
    /**
     * [descr:dxFileManagerOptions.upload]
    
     */
    get upload() {
        return this._getOption('upload');
    }
    set upload(value) {
        this._setOption('upload', value);
    }
    /**
     * [descr:WidgetOptions.visible]
    
     */
    get visible() {
        return this._getOption('visible');
    }
    set visible(value) {
        this._setOption('visible', value);
    }
    /**
     * [descr:DOMComponentOptions.width]
    
     */
    get width() {
        return this._getOption('width');
    }
    set width(value) {
        this._setOption('width', value);
    }
    constructor(elementRef, ngZone, templateHost, _watcherHelper, _idh, optionHost, transferState, platformId) {
        super(elementRef, ngZone, templateHost, _watcherHelper, transferState, platformId);
        this._watcherHelper = _watcherHelper;
        this._idh = _idh;
        this.instance = null;
        this._createEventEmitters([
            { subscribe: 'contentReady', emit: 'onContentReady' },
            { subscribe: 'contextMenuItemClick', emit: 'onContextMenuItemClick' },
            { subscribe: 'contextMenuShowing', emit: 'onContextMenuShowing' },
            { subscribe: 'currentDirectoryChanged', emit: 'onCurrentDirectoryChanged' },
            { subscribe: 'directoryCreated', emit: 'onDirectoryCreated' },
            { subscribe: 'directoryCreating', emit: 'onDirectoryCreating' },
            { subscribe: 'disposing', emit: 'onDisposing' },
            { subscribe: 'errorOccurred', emit: 'onErrorOccurred' },
            { subscribe: 'fileUploaded', emit: 'onFileUploaded' },
            { subscribe: 'fileUploading', emit: 'onFileUploading' },
            { subscribe: 'focusedItemChanged', emit: 'onFocusedItemChanged' },
            { subscribe: 'initialized', emit: 'onInitialized' },
            { subscribe: 'itemCopied', emit: 'onItemCopied' },
            { subscribe: 'itemCopying', emit: 'onItemCopying' },
            { subscribe: 'itemDeleted', emit: 'onItemDeleted' },
            { subscribe: 'itemDeleting', emit: 'onItemDeleting' },
            { subscribe: 'itemDownloading', emit: 'onItemDownloading' },
            { subscribe: 'itemMoved', emit: 'onItemMoved' },
            { subscribe: 'itemMoving', emit: 'onItemMoving' },
            { subscribe: 'itemRenamed', emit: 'onItemRenamed' },
            { subscribe: 'itemRenaming', emit: 'onItemRenaming' },
            { subscribe: 'optionChanged', emit: 'onOptionChanged' },
            { subscribe: 'selectedFileOpened', emit: 'onSelectedFileOpened' },
            { subscribe: 'selectionChanged', emit: 'onSelectionChanged' },
            { subscribe: 'toolbarItemClick', emit: 'onToolbarItemClick' },
            { emit: 'accessKeyChange' },
            { emit: 'activeStateEnabledChange' },
            { emit: 'allowedFileExtensionsChange' },
            { emit: 'contextMenuChange' },
            { emit: 'currentPathChange' },
            { emit: 'currentPathKeysChange' },
            { emit: 'customizeDetailColumnsChange' },
            { emit: 'customizeThumbnailChange' },
            { emit: 'disabledChange' },
            { emit: 'elementAttrChange' },
            { emit: 'fileSystemProviderChange' },
            { emit: 'focusedItemKeyChange' },
            { emit: 'focusStateEnabledChange' },
            { emit: 'heightChange' },
            { emit: 'hintChange' },
            { emit: 'hoverStateEnabledChange' },
            { emit: 'itemViewChange' },
            { emit: 'notificationsChange' },
            { emit: 'permissionsChange' },
            { emit: 'rootFolderNameChange' },
            { emit: 'rtlEnabledChange' },
            { emit: 'selectedItemKeysChange' },
            { emit: 'selectionModeChange' },
            { emit: 'tabIndexChange' },
            { emit: 'toolbarChange' },
            { emit: 'uploadChange' },
            { emit: 'visibleChange' },
            { emit: 'widthChange' }
        ]);
        this._idh.setHost(this);
        optionHost.setHost(this);
    }
    _createInstance(element, options) {
        return new DxFileManager(element, options);
    }
    ngOnDestroy() {
        this._destroyWidget();
    }
    ngOnChanges(changes) {
        super.ngOnChanges(changes);
        this.setupChanges('allowedFileExtensions', changes);
        this.setupChanges('currentPathKeys', changes);
        this.setupChanges('selectedItemKeys', changes);
    }
    setupChanges(prop, changes) {
        if (!(prop in this._optionsToUpdate)) {
            this._idh.setup(prop, changes);
        }
    }
    ngDoCheck() {
        this._idh.doCheck('allowedFileExtensions');
        this._idh.doCheck('currentPathKeys');
        this._idh.doCheck('selectedItemKeys');
        this._watcherHelper.checkWatchers();
        super.ngDoCheck();
        super.clearChangedOptions();
    }
    _setOption(name, value) {
        let isSetup = this._idh.setupSingle(name, value);
        let isChanged = this._idh.getChanges(name, value) !== null;
        if (isSetup || isChanged) {
            super._setOption(name, value);
        }
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxFileManagerComponent, deps: [{ token: i0.ElementRef }, { token: i0.NgZone }, { token: i1.DxTemplateHost }, { token: i1.WatcherHelper }, { token: i1.IterableDifferHelper }, { token: i1.NestedOptionHost }, { token: i0.TransferState }, { token: PLATFORM_ID }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxFileManagerComponent, isStandalone: true, selector: "dx-file-manager", inputs: { accessKey: "accessKey", activeStateEnabled: "activeStateEnabled", allowedFileExtensions: "allowedFileExtensions", contextMenu: "contextMenu", currentPath: "currentPath", currentPathKeys: "currentPathKeys", customizeDetailColumns: "customizeDetailColumns", customizeThumbnail: "customizeThumbnail", disabled: "disabled", elementAttr: "elementAttr", fileSystemProvider: "fileSystemProvider", focusedItemKey: "focusedItemKey", focusStateEnabled: "focusStateEnabled", height: "height", hint: "hint", hoverStateEnabled: "hoverStateEnabled", itemView: "itemView", notifications: "notifications", permissions: "permissions", rootFolderName: "rootFolderName", rtlEnabled: "rtlEnabled", selectedItemKeys: "selectedItemKeys", selectionMode: "selectionMode", tabIndex: "tabIndex", toolbar: "toolbar", upload: "upload", visible: "visible", width: "width" }, outputs: { onContentReady: "onContentReady", onContextMenuItemClick: "onContextMenuItemClick", onContextMenuShowing: "onContextMenuShowing", onCurrentDirectoryChanged: "onCurrentDirectoryChanged", onDirectoryCreated: "onDirectoryCreated", onDirectoryCreating: "onDirectoryCreating", onDisposing: "onDisposing", onErrorOccurred: "onErrorOccurred", onFileUploaded: "onFileUploaded", onFileUploading: "onFileUploading", onFocusedItemChanged: "onFocusedItemChanged", onInitialized: "onInitialized", onItemCopied: "onItemCopied", onItemCopying: "onItemCopying", onItemDeleted: "onItemDeleted", onItemDeleting: "onItemDeleting", onItemDownloading: "onItemDownloading", onItemMoved: "onItemMoved", onItemMoving: "onItemMoving", onItemRenamed: "onItemRenamed", onItemRenaming: "onItemRenaming", onOptionChanged: "onOptionChanged", onSelectedFileOpened: "onSelectedFileOpened", onSelectionChanged: "onSelectionChanged", onToolbarItemClick: "onToolbarItemClick", accessKeyChange: "accessKeyChange", activeStateEnabledChange: "activeStateEnabledChange", allowedFileExtensionsChange: "allowedFileExtensionsChange", contextMenuChange: "contextMenuChange", currentPathChange: "currentPathChange", currentPathKeysChange: "currentPathKeysChange", customizeDetailColumnsChange: "customizeDetailColumnsChange", customizeThumbnailChange: "customizeThumbnailChange", disabledChange: "disabledChange", elementAttrChange: "elementAttrChange", fileSystemProviderChange: "fileSystemProviderChange", focusedItemKeyChange: "focusedItemKeyChange", focusStateEnabledChange: "focusStateEnabledChange", heightChange: "heightChange", hintChange: "hintChange", hoverStateEnabledChange: "hoverStateEnabledChange", itemViewChange: "itemViewChange", notificationsChange: "notificationsChange", permissionsChange: "permissionsChange", rootFolderNameChange: "rootFolderNameChange", rtlEnabledChange: "rtlEnabledChange", selectedItemKeysChange: "selectedItemKeysChange", selectionModeChange: "selectionModeChange", tabIndexChange: "tabIndexChange", toolbarChange: "toolbarChange", uploadChange: "uploadChange", visibleChange: "visibleChange", widthChange: "widthChange" }, host: { attributes: { "ngSkipHydration": "true" } }, providers: [
            DxTemplateHost,
            WatcherHelper,
            NestedOptionHost,
            IterableDifferHelper
        ], queries: [{ propertyName: "_columnsContentChildren", predicate: PROPERTY_TOKEN_columns }, { propertyName: "_itemsContentChildren", predicate: PROPERTY_TOKEN_items }, { propertyName: "_fileSelectionItemsContentChildren", predicate: PROPERTY_TOKEN_fileSelectionItems }], usesInheritance: true, usesOnChanges: true, ngImport: i0, template: '', isInline: true, dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxFileManagerComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'dx-file-manager',
                    template: '',
                    host: { ngSkipHydration: 'true' },
                    imports: [DxIntegrationModule],
                    providers: [
                        DxTemplateHost,
                        WatcherHelper,
                        NestedOptionHost,
                        IterableDifferHelper
                    ]
                }]
        }], ctorParameters: () => [{ type: i0.ElementRef }, { type: i0.NgZone }, { type: i1.DxTemplateHost }, { type: i1.WatcherHelper }, { type: i1.IterableDifferHelper }, { type: i1.NestedOptionHost }, { type: i0.TransferState }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [PLATFORM_ID]
                }] }], propDecorators: { _columnsContentChildren: [{
                type: ContentChildren,
                args: [PROPERTY_TOKEN_columns]
            }], _itemsContentChildren: [{
                type: ContentChildren,
                args: [PROPERTY_TOKEN_items]
            }], _fileSelectionItemsContentChildren: [{
                type: ContentChildren,
                args: [PROPERTY_TOKEN_fileSelectionItems]
            }], accessKey: [{
                type: Input
            }], activeStateEnabled: [{
                type: Input
            }], allowedFileExtensions: [{
                type: Input
            }], contextMenu: [{
                type: Input
            }], currentPath: [{
                type: Input
            }], currentPathKeys: [{
                type: Input
            }], customizeDetailColumns: [{
                type: Input
            }], customizeThumbnail: [{
                type: Input
            }], disabled: [{
                type: Input
            }], elementAttr: [{
                type: Input
            }], fileSystemProvider: [{
                type: Input
            }], focusedItemKey: [{
                type: Input
            }], focusStateEnabled: [{
                type: Input
            }], height: [{
                type: Input
            }], hint: [{
                type: Input
            }], hoverStateEnabled: [{
                type: Input
            }], itemView: [{
                type: Input
            }], notifications: [{
                type: Input
            }], permissions: [{
                type: Input
            }], rootFolderName: [{
                type: Input
            }], rtlEnabled: [{
                type: Input
            }], selectedItemKeys: [{
                type: Input
            }], selectionMode: [{
                type: Input
            }], tabIndex: [{
                type: Input
            }], toolbar: [{
                type: Input
            }], upload: [{
                type: Input
            }], visible: [{
                type: Input
            }], width: [{
                type: Input
            }], onContentReady: [{
                type: Output
            }], onContextMenuItemClick: [{
                type: Output
            }], onContextMenuShowing: [{
                type: Output
            }], onCurrentDirectoryChanged: [{
                type: Output
            }], onDirectoryCreated: [{
                type: Output
            }], onDirectoryCreating: [{
                type: Output
            }], onDisposing: [{
                type: Output
            }], onErrorOccurred: [{
                type: Output
            }], onFileUploaded: [{
                type: Output
            }], onFileUploading: [{
                type: Output
            }], onFocusedItemChanged: [{
                type: Output
            }], onInitialized: [{
                type: Output
            }], onItemCopied: [{
                type: Output
            }], onItemCopying: [{
                type: Output
            }], onItemDeleted: [{
                type: Output
            }], onItemDeleting: [{
                type: Output
            }], onItemDownloading: [{
                type: Output
            }], onItemMoved: [{
                type: Output
            }], onItemMoving: [{
                type: Output
            }], onItemRenamed: [{
                type: Output
            }], onItemRenaming: [{
                type: Output
            }], onOptionChanged: [{
                type: Output
            }], onSelectedFileOpened: [{
                type: Output
            }], onSelectionChanged: [{
                type: Output
            }], onToolbarItemClick: [{
                type: Output
            }], accessKeyChange: [{
                type: Output
            }], activeStateEnabledChange: [{
                type: Output
            }], allowedFileExtensionsChange: [{
                type: Output
            }], contextMenuChange: [{
                type: Output
            }], currentPathChange: [{
                type: Output
            }], currentPathKeysChange: [{
                type: Output
            }], customizeDetailColumnsChange: [{
                type: Output
            }], customizeThumbnailChange: [{
                type: Output
            }], disabledChange: [{
                type: Output
            }], elementAttrChange: [{
                type: Output
            }], fileSystemProviderChange: [{
                type: Output
            }], focusedItemKeyChange: [{
                type: Output
            }], focusStateEnabledChange: [{
                type: Output
            }], heightChange: [{
                type: Output
            }], hintChange: [{
                type: Output
            }], hoverStateEnabledChange: [{
                type: Output
            }], itemViewChange: [{
                type: Output
            }], notificationsChange: [{
                type: Output
            }], permissionsChange: [{
                type: Output
            }], rootFolderNameChange: [{
                type: Output
            }], rtlEnabledChange: [{
                type: Output
            }], selectedItemKeysChange: [{
                type: Output
            }], selectionModeChange: [{
                type: Output
            }], tabIndexChange: [{
                type: Output
            }], toolbarChange: [{
                type: Output
            }], uploadChange: [{
                type: Output
            }], visibleChange: [{
                type: Output
            }], widthChange: [{
                type: Output
            }] } });
class DxFileManagerModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxFileManagerModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxFileManagerModule, imports: [DxFileManagerComponent, DxoContextMenuModule,
            DxiItemModule,
            DxoItemViewModule,
            DxoDetailsModule,
            DxiColumnModule,
            DxoNotificationsModule,
            DxoPermissionsModule,
            DxoToolbarModule,
            DxiFileSelectionItemModule,
            DxoUploadModule,
            DxiFileManagerColumnModule,
            DxoFileManagerContextMenuModule,
            DxiFileManagerContextMenuItemModule,
            DxoFileManagerDetailsModule,
            DxiFileManagerFileSelectionItemModule,
            DxiFileManagerItemModule,
            DxoFileManagerItemViewModule,
            DxoFileManagerNotificationsModule,
            DxoFileManagerPermissionsModule,
            DxoFileManagerToolbarModule,
            DxiFileManagerToolbarItemModule,
            DxoFileManagerUploadModule,
            DxIntegrationModule,
            DxTemplateModule], exports: [DxFileManagerComponent, DxoContextMenuModule,
            DxiItemModule,
            DxoItemViewModule,
            DxoDetailsModule,
            DxiColumnModule,
            DxoNotificationsModule,
            DxoPermissionsModule,
            DxoToolbarModule,
            DxiFileSelectionItemModule,
            DxoUploadModule,
            DxiFileManagerColumnModule,
            DxoFileManagerContextMenuModule,
            DxiFileManagerContextMenuItemModule,
            DxoFileManagerDetailsModule,
            DxiFileManagerFileSelectionItemModule,
            DxiFileManagerItemModule,
            DxoFileManagerItemViewModule,
            DxoFileManagerNotificationsModule,
            DxoFileManagerPermissionsModule,
            DxoFileManagerToolbarModule,
            DxiFileManagerToolbarItemModule,
            DxoFileManagerUploadModule,
            DxTemplateModule] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxFileManagerModule, imports: [DxFileManagerComponent,
            DxoContextMenuModule,
            DxiItemModule,
            DxoItemViewModule,
            DxoDetailsModule,
            DxiColumnModule,
            DxoNotificationsModule,
            DxoPermissionsModule,
            DxoToolbarModule,
            DxiFileSelectionItemModule,
            DxoUploadModule,
            DxiFileManagerColumnModule,
            DxoFileManagerContextMenuModule,
            DxiFileManagerContextMenuItemModule,
            DxoFileManagerDetailsModule,
            DxiFileManagerFileSelectionItemModule,
            DxiFileManagerItemModule,
            DxoFileManagerItemViewModule,
            DxoFileManagerNotificationsModule,
            DxoFileManagerPermissionsModule,
            DxoFileManagerToolbarModule,
            DxiFileManagerToolbarItemModule,
            DxoFileManagerUploadModule,
            DxIntegrationModule,
            DxTemplateModule, DxoContextMenuModule,
            DxiItemModule,
            DxoItemViewModule,
            DxoDetailsModule,
            DxiColumnModule,
            DxoNotificationsModule,
            DxoPermissionsModule,
            DxoToolbarModule,
            DxiFileSelectionItemModule,
            DxoUploadModule,
            DxiFileManagerColumnModule,
            DxoFileManagerContextMenuModule,
            DxiFileManagerContextMenuItemModule,
            DxoFileManagerDetailsModule,
            DxiFileManagerFileSelectionItemModule,
            DxiFileManagerItemModule,
            DxoFileManagerItemViewModule,
            DxoFileManagerNotificationsModule,
            DxoFileManagerPermissionsModule,
            DxoFileManagerToolbarModule,
            DxiFileManagerToolbarItemModule,
            DxoFileManagerUploadModule,
            DxTemplateModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxFileManagerModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxFileManagerComponent,
                        DxoContextMenuModule,
                        DxiItemModule,
                        DxoItemViewModule,
                        DxoDetailsModule,
                        DxiColumnModule,
                        DxoNotificationsModule,
                        DxoPermissionsModule,
                        DxoToolbarModule,
                        DxiFileSelectionItemModule,
                        DxoUploadModule,
                        DxiFileManagerColumnModule,
                        DxoFileManagerContextMenuModule,
                        DxiFileManagerContextMenuItemModule,
                        DxoFileManagerDetailsModule,
                        DxiFileManagerFileSelectionItemModule,
                        DxiFileManagerItemModule,
                        DxoFileManagerItemViewModule,
                        DxoFileManagerNotificationsModule,
                        DxoFileManagerPermissionsModule,
                        DxoFileManagerToolbarModule,
                        DxiFileManagerToolbarItemModule,
                        DxoFileManagerUploadModule,
                        DxIntegrationModule,
                        DxTemplateModule
                    ],
                    exports: [
                        DxFileManagerComponent,
                        DxoContextMenuModule,
                        DxiItemModule,
                        DxoItemViewModule,
                        DxoDetailsModule,
                        DxiColumnModule,
                        DxoNotificationsModule,
                        DxoPermissionsModule,
                        DxoToolbarModule,
                        DxiFileSelectionItemModule,
                        DxoUploadModule,
                        DxiFileManagerColumnModule,
                        DxoFileManagerContextMenuModule,
                        DxiFileManagerContextMenuItemModule,
                        DxoFileManagerDetailsModule,
                        DxiFileManagerFileSelectionItemModule,
                        DxiFileManagerItemModule,
                        DxoFileManagerItemViewModule,
                        DxoFileManagerNotificationsModule,
                        DxoFileManagerPermissionsModule,
                        DxoFileManagerToolbarModule,
                        DxiFileManagerToolbarItemModule,
                        DxoFileManagerUploadModule,
                        DxTemplateModule
                    ]
                }]
        }] });

/**
 * Generated bundle index. Do not edit.
 */

export { DxFileManagerComponent, DxFileManagerModule };
//# sourceMappingURL=devextreme-angular-ui-file-manager.mjs.map
