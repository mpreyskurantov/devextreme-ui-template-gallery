import * as i0 from '@angular/core';
import { PLATFORM_ID, Output, Input, Inject, Component, NgModule } from '@angular/core';
import DxSpeechToText from 'devextreme/ui/speech_to_text';
import * as i1 from 'devextreme-angular/core';
import { DxComponent, DxIntegrationModule, DxTemplateHost, WatcherHelper, NestedOptionHost, DxTemplateModule } from 'devextreme-angular/core';
import { DxoSpeechToTextCustomSpeechRecognizerModule, DxoSpeechToTextSpeechRecognitionConfigModule } from 'devextreme-angular/ui/speech-to-text/nested';
export * from 'devextreme-angular/ui/speech-to-text/nested';

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxSpeechToTextComponent extends DxComponent {
    get accessKey() {
        return this._getOption('accessKey');
    }
    set accessKey(value) {
        this._setOption('accessKey', value);
    }
    get activeStateEnabled() {
        return this._getOption('activeStateEnabled');
    }
    set activeStateEnabled(value) {
        this._setOption('activeStateEnabled', value);
    }
    get customSpeechRecognizer() {
        return this._getOption('customSpeechRecognizer');
    }
    set customSpeechRecognizer(value) {
        this._setOption('customSpeechRecognizer', value);
    }
    get disabled() {
        return this._getOption('disabled');
    }
    set disabled(value) {
        this._setOption('disabled', value);
    }
    get elementAttr() {
        return this._getOption('elementAttr');
    }
    set elementAttr(value) {
        this._setOption('elementAttr', value);
    }
    get focusStateEnabled() {
        return this._getOption('focusStateEnabled');
    }
    set focusStateEnabled(value) {
        this._setOption('focusStateEnabled', value);
    }
    get height() {
        return this._getOption('height');
    }
    set height(value) {
        this._setOption('height', value);
    }
    get hint() {
        return this._getOption('hint');
    }
    set hint(value) {
        this._setOption('hint', value);
    }
    get hoverStateEnabled() {
        return this._getOption('hoverStateEnabled');
    }
    set hoverStateEnabled(value) {
        this._setOption('hoverStateEnabled', value);
    }
    get rtlEnabled() {
        return this._getOption('rtlEnabled');
    }
    set rtlEnabled(value) {
        this._setOption('rtlEnabled', value);
    }
    get speechRecognitionConfig() {
        return this._getOption('speechRecognitionConfig');
    }
    set speechRecognitionConfig(value) {
        this._setOption('speechRecognitionConfig', value);
    }
    get startIcon() {
        return this._getOption('startIcon');
    }
    set startIcon(value) {
        this._setOption('startIcon', value);
    }
    get startText() {
        return this._getOption('startText');
    }
    set startText(value) {
        this._setOption('startText', value);
    }
    get stopIcon() {
        return this._getOption('stopIcon');
    }
    set stopIcon(value) {
        this._setOption('stopIcon', value);
    }
    get stopText() {
        return this._getOption('stopText');
    }
    set stopText(value) {
        this._setOption('stopText', value);
    }
    get stylingMode() {
        return this._getOption('stylingMode');
    }
    set stylingMode(value) {
        this._setOption('stylingMode', value);
    }
    get tabIndex() {
        return this._getOption('tabIndex');
    }
    set tabIndex(value) {
        this._setOption('tabIndex', value);
    }
    get type() {
        return this._getOption('type');
    }
    set type(value) {
        this._setOption('type', value);
    }
    get visible() {
        return this._getOption('visible');
    }
    set visible(value) {
        this._setOption('visible', value);
    }
    get width() {
        return this._getOption('width');
    }
    set width(value) {
        this._setOption('width', value);
    }
    constructor(elementRef, ngZone, templateHost, _watcherHelper, optionHost, transferState, platformId) {
        super(elementRef, ngZone, templateHost, _watcherHelper, transferState, platformId);
        this.instance = null;
        this._createEventEmitters([
            { subscribe: 'contentReady', emit: 'onContentReady' },
            { subscribe: 'disposing', emit: 'onDisposing' },
            { subscribe: 'end', emit: 'onEnd' },
            { subscribe: 'error', emit: 'onError' },
            { subscribe: 'initialized', emit: 'onInitialized' },
            { subscribe: 'optionChanged', emit: 'onOptionChanged' },
            { subscribe: 'result', emit: 'onResult' },
            { subscribe: 'startClick', emit: 'onStartClick' },
            { subscribe: 'stopClick', emit: 'onStopClick' },
            { emit: 'accessKeyChange' },
            { emit: 'activeStateEnabledChange' },
            { emit: 'customSpeechRecognizerChange' },
            { emit: 'disabledChange' },
            { emit: 'elementAttrChange' },
            { emit: 'focusStateEnabledChange' },
            { emit: 'heightChange' },
            { emit: 'hintChange' },
            { emit: 'hoverStateEnabledChange' },
            { emit: 'rtlEnabledChange' },
            { emit: 'speechRecognitionConfigChange' },
            { emit: 'startIconChange' },
            { emit: 'startTextChange' },
            { emit: 'stopIconChange' },
            { emit: 'stopTextChange' },
            { emit: 'stylingModeChange' },
            { emit: 'tabIndexChange' },
            { emit: 'typeChange' },
            { emit: 'visibleChange' },
            { emit: 'widthChange' }
        ]);
        optionHost.setHost(this);
    }
    _createInstance(element, options) {
        return new DxSpeechToText(element, options);
    }
    ngOnDestroy() {
        this._destroyWidget();
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxSpeechToTextComponent, deps: [{ token: i0.ElementRef }, { token: i0.NgZone }, { token: i1.DxTemplateHost }, { token: i1.WatcherHelper }, { token: i1.NestedOptionHost }, { token: i0.TransferState }, { token: PLATFORM_ID }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxSpeechToTextComponent, isStandalone: true, selector: "dx-speech-to-text", inputs: { accessKey: "accessKey", activeStateEnabled: "activeStateEnabled", customSpeechRecognizer: "customSpeechRecognizer", disabled: "disabled", elementAttr: "elementAttr", focusStateEnabled: "focusStateEnabled", height: "height", hint: "hint", hoverStateEnabled: "hoverStateEnabled", rtlEnabled: "rtlEnabled", speechRecognitionConfig: "speechRecognitionConfig", startIcon: "startIcon", startText: "startText", stopIcon: "stopIcon", stopText: "stopText", stylingMode: "stylingMode", tabIndex: "tabIndex", type: "type", visible: "visible", width: "width" }, outputs: { onContentReady: "onContentReady", onDisposing: "onDisposing", onEnd: "onEnd", onError: "onError", onInitialized: "onInitialized", onOptionChanged: "onOptionChanged", onResult: "onResult", onStartClick: "onStartClick", onStopClick: "onStopClick", accessKeyChange: "accessKeyChange", activeStateEnabledChange: "activeStateEnabledChange", customSpeechRecognizerChange: "customSpeechRecognizerChange", disabledChange: "disabledChange", elementAttrChange: "elementAttrChange", focusStateEnabledChange: "focusStateEnabledChange", heightChange: "heightChange", hintChange: "hintChange", hoverStateEnabledChange: "hoverStateEnabledChange", rtlEnabledChange: "rtlEnabledChange", speechRecognitionConfigChange: "speechRecognitionConfigChange", startIconChange: "startIconChange", startTextChange: "startTextChange", stopIconChange: "stopIconChange", stopTextChange: "stopTextChange", stylingModeChange: "stylingModeChange", tabIndexChange: "tabIndexChange", typeChange: "typeChange", visibleChange: "visibleChange", widthChange: "widthChange" }, host: { attributes: { "ngSkipHydration": "true" } }, providers: [
            DxTemplateHost,
            WatcherHelper,
            NestedOptionHost
        ], usesInheritance: true, ngImport: i0, template: '', isInline: true, dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxSpeechToTextComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'dx-speech-to-text',
                    template: '',
                    host: { ngSkipHydration: 'true' },
                    imports: [DxIntegrationModule],
                    providers: [
                        DxTemplateHost,
                        WatcherHelper,
                        NestedOptionHost
                    ]
                }]
        }], ctorParameters: () => [{ type: i0.ElementRef }, { type: i0.NgZone }, { type: i1.DxTemplateHost }, { type: i1.WatcherHelper }, { type: i1.NestedOptionHost }, { type: i0.TransferState }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [PLATFORM_ID]
                }] }], propDecorators: { accessKey: [{
                type: Input
            }], activeStateEnabled: [{
                type: Input
            }], customSpeechRecognizer: [{
                type: Input
            }], disabled: [{
                type: Input
            }], elementAttr: [{
                type: Input
            }], focusStateEnabled: [{
                type: Input
            }], height: [{
                type: Input
            }], hint: [{
                type: Input
            }], hoverStateEnabled: [{
                type: Input
            }], rtlEnabled: [{
                type: Input
            }], speechRecognitionConfig: [{
                type: Input
            }], startIcon: [{
                type: Input
            }], startText: [{
                type: Input
            }], stopIcon: [{
                type: Input
            }], stopText: [{
                type: Input
            }], stylingMode: [{
                type: Input
            }], tabIndex: [{
                type: Input
            }], type: [{
                type: Input
            }], visible: [{
                type: Input
            }], width: [{
                type: Input
            }], onContentReady: [{
                type: Output
            }], onDisposing: [{
                type: Output
            }], onEnd: [{
                type: Output
            }], onError: [{
                type: Output
            }], onInitialized: [{
                type: Output
            }], onOptionChanged: [{
                type: Output
            }], onResult: [{
                type: Output
            }], onStartClick: [{
                type: Output
            }], onStopClick: [{
                type: Output
            }], accessKeyChange: [{
                type: Output
            }], activeStateEnabledChange: [{
                type: Output
            }], customSpeechRecognizerChange: [{
                type: Output
            }], disabledChange: [{
                type: Output
            }], elementAttrChange: [{
                type: Output
            }], focusStateEnabledChange: [{
                type: Output
            }], heightChange: [{
                type: Output
            }], hintChange: [{
                type: Output
            }], hoverStateEnabledChange: [{
                type: Output
            }], rtlEnabledChange: [{
                type: Output
            }], speechRecognitionConfigChange: [{
                type: Output
            }], startIconChange: [{
                type: Output
            }], startTextChange: [{
                type: Output
            }], stopIconChange: [{
                type: Output
            }], stopTextChange: [{
                type: Output
            }], stylingModeChange: [{
                type: Output
            }], tabIndexChange: [{
                type: Output
            }], typeChange: [{
                type: Output
            }], visibleChange: [{
                type: Output
            }], widthChange: [{
                type: Output
            }] } });
class DxSpeechToTextModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxSpeechToTextModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxSpeechToTextModule, imports: [DxSpeechToTextComponent, DxoSpeechToTextCustomSpeechRecognizerModule,
            DxoSpeechToTextSpeechRecognitionConfigModule,
            DxIntegrationModule,
            DxTemplateModule], exports: [DxSpeechToTextComponent, DxoSpeechToTextCustomSpeechRecognizerModule,
            DxoSpeechToTextSpeechRecognitionConfigModule,
            DxTemplateModule] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxSpeechToTextModule, imports: [DxSpeechToTextComponent,
            DxoSpeechToTextCustomSpeechRecognizerModule,
            DxoSpeechToTextSpeechRecognitionConfigModule,
            DxIntegrationModule,
            DxTemplateModule, DxoSpeechToTextCustomSpeechRecognizerModule,
            DxoSpeechToTextSpeechRecognitionConfigModule,
            DxTemplateModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxSpeechToTextModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxSpeechToTextComponent,
                        DxoSpeechToTextCustomSpeechRecognizerModule,
                        DxoSpeechToTextSpeechRecognitionConfigModule,
                        DxIntegrationModule,
                        DxTemplateModule
                    ],
                    exports: [
                        DxSpeechToTextComponent,
                        DxoSpeechToTextCustomSpeechRecognizerModule,
                        DxoSpeechToTextSpeechRecognitionConfigModule,
                        DxTemplateModule
                    ]
                }]
        }] });

/**
 * Generated bundle index. Do not edit.
 */

export { DxSpeechToTextComponent, DxSpeechToTextModule };
//# sourceMappingURL=devextreme-angular-ui-speech-to-text.mjs.map
