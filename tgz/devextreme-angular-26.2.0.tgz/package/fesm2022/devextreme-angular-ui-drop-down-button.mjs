import * as i0 from '@angular/core';
import { PLATFORM_ID, Output, Input, ContentChildren, Inject, Component, NgModule } from '@angular/core';
import DxDropDownButton from 'devextreme/ui/drop_down_button';
import * as i1 from 'devextreme-angular/core';
import { DxComponent, DxIntegrationModule, DxTemplateHost, WatcherHelper, NestedOptionHost, IterableDifferHelper, DxTemplateModule } from 'devextreme-angular/core';
import { DxoDropDownOptionsModule, DxoAnimationModule, DxoHideModule, DxoFromModule, DxoPositionModule, DxoAtModule, DxoBoundaryOffsetModule, DxoCollisionModule, DxoMyModule, DxoOffsetModule, DxoToModule, DxoShowModule, DxiItemModule } from 'devextreme-angular/ui/nested';
import { DxoDropDownButtonAnimationModule, DxoDropDownButtonAtModule, DxoDropDownButtonBoundaryOffsetModule, DxoDropDownButtonCollisionModule, DxoDropDownButtonDropDownOptionsModule, DxoDropDownButtonFromModule, DxoDropDownButtonHideModule, DxiDropDownButtonItemModule, DxoDropDownButtonMyModule, DxoDropDownButtonOffsetModule, DxoDropDownButtonPositionModule, DxoDropDownButtonShowModule, DxoDropDownButtonToModule, DxiDropDownButtonToolbarItemModule } from 'devextreme-angular/ui/drop-down-button/nested';
export * from 'devextreme-angular/ui/drop-down-button/nested';
import { PROPERTY_TOKEN_items, PROPERTY_TOKEN_toolbarItems } from 'devextreme-angular/core/tokens';

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
/**
 * [descr:dxDropDownButton]

 */
class DxDropDownButtonComponent extends DxComponent {
    set _itemsContentChildren(value) {
        this.setChildren('items', value);
    }
    set _toolbarItemsContentChildren(value) {
        this.setChildren('toolbarItems', value);
    }
    /**
     * [descr:WidgetOptions.accessKey]
    
     */
    get accessKey() {
        return this._getOption('accessKey');
    }
    set accessKey(value) {
        this._setOption('accessKey', value);
    }
    /**
     * [descr:WidgetOptions.activeStateEnabled]
    
     */
    get activeStateEnabled() {
        return this._getOption('activeStateEnabled');
    }
    set activeStateEnabled(value) {
        this._setOption('activeStateEnabled', value);
    }
    /**
     * [descr:dxDropDownButtonOptions.dataSource]
    
     */
    get dataSource() {
        return this._getOption('dataSource');
    }
    set dataSource(value) {
        this._setOption('dataSource', value);
    }
    /**
     * [descr:dxDropDownButtonOptions.deferRendering]
    
     */
    get deferRendering() {
        return this._getOption('deferRendering');
    }
    set deferRendering(value) {
        this._setOption('deferRendering', value);
    }
    /**
     * [descr:WidgetOptions.disabled]
    
     */
    get disabled() {
        return this._getOption('disabled');
    }
    set disabled(value) {
        this._setOption('disabled', value);
    }
    /**
     * [descr:dxDropDownButtonOptions.displayExpr]
    
     */
    get displayExpr() {
        return this._getOption('displayExpr');
    }
    set displayExpr(value) {
        this._setOption('displayExpr', value);
    }
    /**
     * [descr:dxDropDownButtonOptions.dropDownContentTemplate]
    
     */
    get dropDownContentTemplate() {
        return this._getOption('dropDownContentTemplate');
    }
    set dropDownContentTemplate(value) {
        this._setOption('dropDownContentTemplate', value);
    }
    /**
     * [descr:dxDropDownButtonOptions.dropDownOptions]
    
     */
    get dropDownOptions() {
        return this._getOption('dropDownOptions');
    }
    set dropDownOptions(value) {
        this._setOption('dropDownOptions', value);
    }
    /**
     * [descr:DOMComponentOptions.elementAttr]
    
     */
    get elementAttr() {
        return this._getOption('elementAttr');
    }
    set elementAttr(value) {
        this._setOption('elementAttr', value);
    }
    /**
     * [descr:dxDropDownButtonOptions.focusStateEnabled]
    
     */
    get focusStateEnabled() {
        return this._getOption('focusStateEnabled');
    }
    set focusStateEnabled(value) {
        this._setOption('focusStateEnabled', value);
    }
    /**
     * [descr:DOMComponentOptions.height]
    
     */
    get height() {
        return this._getOption('height');
    }
    set height(value) {
        this._setOption('height', value);
    }
    /**
     * [descr:WidgetOptions.hint]
    
     */
    get hint() {
        return this._getOption('hint');
    }
    set hint(value) {
        this._setOption('hint', value);
    }
    /**
     * [descr:dxDropDownButtonOptions.hoverStateEnabled]
    
     */
    get hoverStateEnabled() {
        return this._getOption('hoverStateEnabled');
    }
    set hoverStateEnabled(value) {
        this._setOption('hoverStateEnabled', value);
    }
    /**
     * [descr:dxDropDownButtonOptions.icon]
    
     */
    get icon() {
        return this._getOption('icon');
    }
    set icon(value) {
        this._setOption('icon', value);
    }
    /**
     * [descr:dxDropDownButtonOptions.items]
    
     */
    get items() {
        return this._getOption('items');
    }
    set items(value) {
        this._setOption('items', value);
    }
    /**
     * [descr:dxDropDownButtonOptions.itemTemplate]
    
     */
    get itemTemplate() {
        return this._getOption('itemTemplate');
    }
    set itemTemplate(value) {
        this._setOption('itemTemplate', value);
    }
    /**
     * [descr:dxDropDownButtonOptions.keyExpr]
    
     */
    get keyExpr() {
        return this._getOption('keyExpr');
    }
    set keyExpr(value) {
        this._setOption('keyExpr', value);
    }
    /**
     * [descr:dxDropDownButtonOptions.noDataText]
    
     */
    get noDataText() {
        return this._getOption('noDataText');
    }
    set noDataText(value) {
        this._setOption('noDataText', value);
    }
    /**
     * [descr:dxDropDownButtonOptions.opened]
    
     */
    get opened() {
        return this._getOption('opened');
    }
    set opened(value) {
        this._setOption('opened', value);
    }
    /**
     * [descr:DOMComponentOptions.rtlEnabled]
    
     */
    get rtlEnabled() {
        return this._getOption('rtlEnabled');
    }
    set rtlEnabled(value) {
        this._setOption('rtlEnabled', value);
    }
    /**
     * [descr:dxDropDownButtonOptions.selectedItem]
    
     */
    get selectedItem() {
        return this._getOption('selectedItem');
    }
    set selectedItem(value) {
        this._setOption('selectedItem', value);
    }
    /**
     * [descr:dxDropDownButtonOptions.selectedItemKey]
    
     */
    get selectedItemKey() {
        return this._getOption('selectedItemKey');
    }
    set selectedItemKey(value) {
        this._setOption('selectedItemKey', value);
    }
    /**
     * [descr:dxDropDownButtonOptions.showArrowIcon]
    
     */
    get showArrowIcon() {
        return this._getOption('showArrowIcon');
    }
    set showArrowIcon(value) {
        this._setOption('showArrowIcon', value);
    }
    /**
     * [descr:dxDropDownButtonOptions.splitButton]
    
     */
    get splitButton() {
        return this._getOption('splitButton');
    }
    set splitButton(value) {
        this._setOption('splitButton', value);
    }
    /**
     * [descr:dxDropDownButtonOptions.stylingMode]
    
     */
    get stylingMode() {
        return this._getOption('stylingMode');
    }
    set stylingMode(value) {
        this._setOption('stylingMode', value);
    }
    /**
     * [descr:WidgetOptions.tabIndex]
    
     */
    get tabIndex() {
        return this._getOption('tabIndex');
    }
    set tabIndex(value) {
        this._setOption('tabIndex', value);
    }
    /**
     * [descr:dxDropDownButtonOptions.template]
    
     */
    get template() {
        return this._getOption('template');
    }
    set template(value) {
        this._setOption('template', value);
    }
    /**
     * [descr:dxDropDownButtonOptions.text]
    
     */
    get text() {
        return this._getOption('text');
    }
    set text(value) {
        this._setOption('text', value);
    }
    /**
     * [descr:dxDropDownButtonOptions.type]
    
     */
    get type() {
        return this._getOption('type');
    }
    set type(value) {
        this._setOption('type', value);
    }
    /**
     * [descr:dxDropDownButtonOptions.useItemTextAsTitle]
    
     */
    get useItemTextAsTitle() {
        return this._getOption('useItemTextAsTitle');
    }
    set useItemTextAsTitle(value) {
        this._setOption('useItemTextAsTitle', value);
    }
    /**
     * [descr:dxDropDownButtonOptions.useSelectMode]
    
     */
    get useSelectMode() {
        return this._getOption('useSelectMode');
    }
    set useSelectMode(value) {
        this._setOption('useSelectMode', value);
    }
    /**
     * [descr:WidgetOptions.visible]
    
     */
    get visible() {
        return this._getOption('visible');
    }
    set visible(value) {
        this._setOption('visible', value);
    }
    /**
     * [descr:DOMComponentOptions.width]
    
     */
    get width() {
        return this._getOption('width');
    }
    set width(value) {
        this._setOption('width', value);
    }
    /**
     * [descr:dxDropDownButtonOptions.wrapItemText]
    
     */
    get wrapItemText() {
        return this._getOption('wrapItemText');
    }
    set wrapItemText(value) {
        this._setOption('wrapItemText', value);
    }
    constructor(elementRef, ngZone, templateHost, _watcherHelper, _idh, optionHost, transferState, platformId) {
        super(elementRef, ngZone, templateHost, _watcherHelper, transferState, platformId);
        this._watcherHelper = _watcherHelper;
        this._idh = _idh;
        this.instance = null;
        this._createEventEmitters([
            { subscribe: 'buttonClick', emit: 'onButtonClick' },
            { subscribe: 'contentReady', emit: 'onContentReady' },
            { subscribe: 'disposing', emit: 'onDisposing' },
            { subscribe: 'initialized', emit: 'onInitialized' },
            { subscribe: 'itemClick', emit: 'onItemClick' },
            { subscribe: 'optionChanged', emit: 'onOptionChanged' },
            { subscribe: 'selectionChanged', emit: 'onSelectionChanged' },
            { emit: 'accessKeyChange' },
            { emit: 'activeStateEnabledChange' },
            { emit: 'dataSourceChange' },
            { emit: 'deferRenderingChange' },
            { emit: 'disabledChange' },
            { emit: 'displayExprChange' },
            { emit: 'dropDownContentTemplateChange' },
            { emit: 'dropDownOptionsChange' },
            { emit: 'elementAttrChange' },
            { emit: 'focusStateEnabledChange' },
            { emit: 'heightChange' },
            { emit: 'hintChange' },
            { emit: 'hoverStateEnabledChange' },
            { emit: 'iconChange' },
            { emit: 'itemsChange' },
            { emit: 'itemTemplateChange' },
            { emit: 'keyExprChange' },
            { emit: 'noDataTextChange' },
            { emit: 'openedChange' },
            { emit: 'rtlEnabledChange' },
            { emit: 'selectedItemChange' },
            { emit: 'selectedItemKeyChange' },
            { emit: 'showArrowIconChange' },
            { emit: 'splitButtonChange' },
            { emit: 'stylingModeChange' },
            { emit: 'tabIndexChange' },
            { emit: 'templateChange' },
            { emit: 'textChange' },
            { emit: 'typeChange' },
            { emit: 'useItemTextAsTitleChange' },
            { emit: 'useSelectModeChange' },
            { emit: 'visibleChange' },
            { emit: 'widthChange' },
            { emit: 'wrapItemTextChange' }
        ]);
        this._idh.setHost(this);
        optionHost.setHost(this);
    }
    _createInstance(element, options) {
        return new DxDropDownButton(element, options);
    }
    ngOnDestroy() {
        this._destroyWidget();
    }
    ngOnChanges(changes) {
        super.ngOnChanges(changes);
        this.setupChanges('dataSource', changes);
        this.setupChanges('items', changes);
    }
    setupChanges(prop, changes) {
        if (!(prop in this._optionsToUpdate)) {
            this._idh.setup(prop, changes);
        }
    }
    ngDoCheck() {
        this._idh.doCheck('dataSource');
        this._idh.doCheck('items');
        this._watcherHelper.checkWatchers();
        super.ngDoCheck();
        super.clearChangedOptions();
    }
    _setOption(name, value) {
        let isSetup = this._idh.setupSingle(name, value);
        let isChanged = this._idh.getChanges(name, value) !== null;
        if (isSetup || isChanged) {
            super._setOption(name, value);
        }
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxDropDownButtonComponent, deps: [{ token: i0.ElementRef }, { token: i0.NgZone }, { token: i1.DxTemplateHost }, { token: i1.WatcherHelper }, { token: i1.IterableDifferHelper }, { token: i1.NestedOptionHost }, { token: i0.TransferState }, { token: PLATFORM_ID }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxDropDownButtonComponent, isStandalone: true, selector: "dx-drop-down-button", inputs: { accessKey: "accessKey", activeStateEnabled: "activeStateEnabled", dataSource: "dataSource", deferRendering: "deferRendering", disabled: "disabled", displayExpr: "displayExpr", dropDownContentTemplate: "dropDownContentTemplate", dropDownOptions: "dropDownOptions", elementAttr: "elementAttr", focusStateEnabled: "focusStateEnabled", height: "height", hint: "hint", hoverStateEnabled: "hoverStateEnabled", icon: "icon", items: "items", itemTemplate: "itemTemplate", keyExpr: "keyExpr", noDataText: "noDataText", opened: "opened", rtlEnabled: "rtlEnabled", selectedItem: "selectedItem", selectedItemKey: "selectedItemKey", showArrowIcon: "showArrowIcon", splitButton: "splitButton", stylingMode: "stylingMode", tabIndex: "tabIndex", template: "template", text: "text", type: "type", useItemTextAsTitle: "useItemTextAsTitle", useSelectMode: "useSelectMode", visible: "visible", width: "width", wrapItemText: "wrapItemText" }, outputs: { onButtonClick: "onButtonClick", onContentReady: "onContentReady", onDisposing: "onDisposing", onInitialized: "onInitialized", onItemClick: "onItemClick", onOptionChanged: "onOptionChanged", onSelectionChanged: "onSelectionChanged", accessKeyChange: "accessKeyChange", activeStateEnabledChange: "activeStateEnabledChange", dataSourceChange: "dataSourceChange", deferRenderingChange: "deferRenderingChange", disabledChange: "disabledChange", displayExprChange: "displayExprChange", dropDownContentTemplateChange: "dropDownContentTemplateChange", dropDownOptionsChange: "dropDownOptionsChange", elementAttrChange: "elementAttrChange", focusStateEnabledChange: "focusStateEnabledChange", heightChange: "heightChange", hintChange: "hintChange", hoverStateEnabledChange: "hoverStateEnabledChange", iconChange: "iconChange", itemsChange: "itemsChange", itemTemplateChange: "itemTemplateChange", keyExprChange: "keyExprChange", noDataTextChange: "noDataTextChange", openedChange: "openedChange", rtlEnabledChange: "rtlEnabledChange", selectedItemChange: "selectedItemChange", selectedItemKeyChange: "selectedItemKeyChange", showArrowIconChange: "showArrowIconChange", splitButtonChange: "splitButtonChange", stylingModeChange: "stylingModeChange", tabIndexChange: "tabIndexChange", templateChange: "templateChange", textChange: "textChange", typeChange: "typeChange", useItemTextAsTitleChange: "useItemTextAsTitleChange", useSelectModeChange: "useSelectModeChange", visibleChange: "visibleChange", widthChange: "widthChange", wrapItemTextChange: "wrapItemTextChange" }, host: { attributes: { "ngSkipHydration": "true" } }, providers: [
            DxTemplateHost,
            WatcherHelper,
            NestedOptionHost,
            IterableDifferHelper
        ], queries: [{ propertyName: "_itemsContentChildren", predicate: PROPERTY_TOKEN_items }, { propertyName: "_toolbarItemsContentChildren", predicate: PROPERTY_TOKEN_toolbarItems }], usesInheritance: true, usesOnChanges: true, ngImport: i0, template: '', isInline: true, dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxDropDownButtonComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'dx-drop-down-button',
                    template: '',
                    host: { ngSkipHydration: 'true' },
                    imports: [DxIntegrationModule],
                    providers: [
                        DxTemplateHost,
                        WatcherHelper,
                        NestedOptionHost,
                        IterableDifferHelper
                    ]
                }]
        }], ctorParameters: () => [{ type: i0.ElementRef }, { type: i0.NgZone }, { type: i1.DxTemplateHost }, { type: i1.WatcherHelper }, { type: i1.IterableDifferHelper }, { type: i1.NestedOptionHost }, { type: i0.TransferState }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [PLATFORM_ID]
                }] }], propDecorators: { _itemsContentChildren: [{
                type: ContentChildren,
                args: [PROPERTY_TOKEN_items]
            }], _toolbarItemsContentChildren: [{
                type: ContentChildren,
                args: [PROPERTY_TOKEN_toolbarItems]
            }], accessKey: [{
                type: Input
            }], activeStateEnabled: [{
                type: Input
            }], dataSource: [{
                type: Input
            }], deferRendering: [{
                type: Input
            }], disabled: [{
                type: Input
            }], displayExpr: [{
                type: Input
            }], dropDownContentTemplate: [{
                type: Input
            }], dropDownOptions: [{
                type: Input
            }], elementAttr: [{
                type: Input
            }], focusStateEnabled: [{
                type: Input
            }], height: [{
                type: Input
            }], hint: [{
                type: Input
            }], hoverStateEnabled: [{
                type: Input
            }], icon: [{
                type: Input
            }], items: [{
                type: Input
            }], itemTemplate: [{
                type: Input
            }], keyExpr: [{
                type: Input
            }], noDataText: [{
                type: Input
            }], opened: [{
                type: Input
            }], rtlEnabled: [{
                type: Input
            }], selectedItem: [{
                type: Input
            }], selectedItemKey: [{
                type: Input
            }], showArrowIcon: [{
                type: Input
            }], splitButton: [{
                type: Input
            }], stylingMode: [{
                type: Input
            }], tabIndex: [{
                type: Input
            }], template: [{
                type: Input
            }], text: [{
                type: Input
            }], type: [{
                type: Input
            }], useItemTextAsTitle: [{
                type: Input
            }], useSelectMode: [{
                type: Input
            }], visible: [{
                type: Input
            }], width: [{
                type: Input
            }], wrapItemText: [{
                type: Input
            }], onButtonClick: [{
                type: Output
            }], onContentReady: [{
                type: Output
            }], onDisposing: [{
                type: Output
            }], onInitialized: [{
                type: Output
            }], onItemClick: [{
                type: Output
            }], onOptionChanged: [{
                type: Output
            }], onSelectionChanged: [{
                type: Output
            }], accessKeyChange: [{
                type: Output
            }], activeStateEnabledChange: [{
                type: Output
            }], dataSourceChange: [{
                type: Output
            }], deferRenderingChange: [{
                type: Output
            }], disabledChange: [{
                type: Output
            }], displayExprChange: [{
                type: Output
            }], dropDownContentTemplateChange: [{
                type: Output
            }], dropDownOptionsChange: [{
                type: Output
            }], elementAttrChange: [{
                type: Output
            }], focusStateEnabledChange: [{
                type: Output
            }], heightChange: [{
                type: Output
            }], hintChange: [{
                type: Output
            }], hoverStateEnabledChange: [{
                type: Output
            }], iconChange: [{
                type: Output
            }], itemsChange: [{
                type: Output
            }], itemTemplateChange: [{
                type: Output
            }], keyExprChange: [{
                type: Output
            }], noDataTextChange: [{
                type: Output
            }], openedChange: [{
                type: Output
            }], rtlEnabledChange: [{
                type: Output
            }], selectedItemChange: [{
                type: Output
            }], selectedItemKeyChange: [{
                type: Output
            }], showArrowIconChange: [{
                type: Output
            }], splitButtonChange: [{
                type: Output
            }], stylingModeChange: [{
                type: Output
            }], tabIndexChange: [{
                type: Output
            }], templateChange: [{
                type: Output
            }], textChange: [{
                type: Output
            }], typeChange: [{
                type: Output
            }], useItemTextAsTitleChange: [{
                type: Output
            }], useSelectModeChange: [{
                type: Output
            }], visibleChange: [{
                type: Output
            }], widthChange: [{
                type: Output
            }], wrapItemTextChange: [{
                type: Output
            }] } });
class DxDropDownButtonModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxDropDownButtonModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxDropDownButtonModule, imports: [DxDropDownButtonComponent, DxoDropDownOptionsModule,
            DxoAnimationModule,
            DxoHideModule,
            DxoFromModule,
            DxoPositionModule,
            DxoAtModule,
            DxoBoundaryOffsetModule,
            DxoCollisionModule,
            DxoMyModule,
            DxoOffsetModule,
            DxoToModule,
            DxoShowModule,
            DxiItemModule,
            DxoDropDownButtonAnimationModule,
            DxoDropDownButtonAtModule,
            DxoDropDownButtonBoundaryOffsetModule,
            DxoDropDownButtonCollisionModule,
            DxoDropDownButtonDropDownOptionsModule,
            DxoDropDownButtonFromModule,
            DxoDropDownButtonHideModule,
            DxiDropDownButtonItemModule,
            DxoDropDownButtonMyModule,
            DxoDropDownButtonOffsetModule,
            DxoDropDownButtonPositionModule,
            DxoDropDownButtonShowModule,
            DxoDropDownButtonToModule,
            DxiDropDownButtonToolbarItemModule,
            DxIntegrationModule,
            DxTemplateModule], exports: [DxDropDownButtonComponent, DxoDropDownOptionsModule,
            DxoAnimationModule,
            DxoHideModule,
            DxoFromModule,
            DxoPositionModule,
            DxoAtModule,
            DxoBoundaryOffsetModule,
            DxoCollisionModule,
            DxoMyModule,
            DxoOffsetModule,
            DxoToModule,
            DxoShowModule,
            DxiItemModule,
            DxoDropDownButtonAnimationModule,
            DxoDropDownButtonAtModule,
            DxoDropDownButtonBoundaryOffsetModule,
            DxoDropDownButtonCollisionModule,
            DxoDropDownButtonDropDownOptionsModule,
            DxoDropDownButtonFromModule,
            DxoDropDownButtonHideModule,
            DxiDropDownButtonItemModule,
            DxoDropDownButtonMyModule,
            DxoDropDownButtonOffsetModule,
            DxoDropDownButtonPositionModule,
            DxoDropDownButtonShowModule,
            DxoDropDownButtonToModule,
            DxiDropDownButtonToolbarItemModule,
            DxTemplateModule] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxDropDownButtonModule, imports: [DxDropDownButtonComponent,
            DxoDropDownOptionsModule,
            DxoAnimationModule,
            DxoHideModule,
            DxoFromModule,
            DxoPositionModule,
            DxoAtModule,
            DxoBoundaryOffsetModule,
            DxoCollisionModule,
            DxoMyModule,
            DxoOffsetModule,
            DxoToModule,
            DxoShowModule,
            DxiItemModule,
            DxoDropDownButtonAnimationModule,
            DxoDropDownButtonAtModule,
            DxoDropDownButtonBoundaryOffsetModule,
            DxoDropDownButtonCollisionModule,
            DxoDropDownButtonDropDownOptionsModule,
            DxoDropDownButtonFromModule,
            DxoDropDownButtonHideModule,
            DxiDropDownButtonItemModule,
            DxoDropDownButtonMyModule,
            DxoDropDownButtonOffsetModule,
            DxoDropDownButtonPositionModule,
            DxoDropDownButtonShowModule,
            DxoDropDownButtonToModule,
            DxiDropDownButtonToolbarItemModule,
            DxIntegrationModule,
            DxTemplateModule, DxoDropDownOptionsModule,
            DxoAnimationModule,
            DxoHideModule,
            DxoFromModule,
            DxoPositionModule,
            DxoAtModule,
            DxoBoundaryOffsetModule,
            DxoCollisionModule,
            DxoMyModule,
            DxoOffsetModule,
            DxoToModule,
            DxoShowModule,
            DxiItemModule,
            DxoDropDownButtonAnimationModule,
            DxoDropDownButtonAtModule,
            DxoDropDownButtonBoundaryOffsetModule,
            DxoDropDownButtonCollisionModule,
            DxoDropDownButtonDropDownOptionsModule,
            DxoDropDownButtonFromModule,
            DxoDropDownButtonHideModule,
            DxiDropDownButtonItemModule,
            DxoDropDownButtonMyModule,
            DxoDropDownButtonOffsetModule,
            DxoDropDownButtonPositionModule,
            DxoDropDownButtonShowModule,
            DxoDropDownButtonToModule,
            DxiDropDownButtonToolbarItemModule,
            DxTemplateModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxDropDownButtonModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxDropDownButtonComponent,
                        DxoDropDownOptionsModule,
                        DxoAnimationModule,
                        DxoHideModule,
                        DxoFromModule,
                        DxoPositionModule,
                        DxoAtModule,
                        DxoBoundaryOffsetModule,
                        DxoCollisionModule,
                        DxoMyModule,
                        DxoOffsetModule,
                        DxoToModule,
                        DxoShowModule,
                        DxiItemModule,
                        DxoDropDownButtonAnimationModule,
                        DxoDropDownButtonAtModule,
                        DxoDropDownButtonBoundaryOffsetModule,
                        DxoDropDownButtonCollisionModule,
                        DxoDropDownButtonDropDownOptionsModule,
                        DxoDropDownButtonFromModule,
                        DxoDropDownButtonHideModule,
                        DxiDropDownButtonItemModule,
                        DxoDropDownButtonMyModule,
                        DxoDropDownButtonOffsetModule,
                        DxoDropDownButtonPositionModule,
                        DxoDropDownButtonShowModule,
                        DxoDropDownButtonToModule,
                        DxiDropDownButtonToolbarItemModule,
                        DxIntegrationModule,
                        DxTemplateModule
                    ],
                    exports: [
                        DxDropDownButtonComponent,
                        DxoDropDownOptionsModule,
                        DxoAnimationModule,
                        DxoHideModule,
                        DxoFromModule,
                        DxoPositionModule,
                        DxoAtModule,
                        DxoBoundaryOffsetModule,
                        DxoCollisionModule,
                        DxoMyModule,
                        DxoOffsetModule,
                        DxoToModule,
                        DxoShowModule,
                        DxiItemModule,
                        DxoDropDownButtonAnimationModule,
                        DxoDropDownButtonAtModule,
                        DxoDropDownButtonBoundaryOffsetModule,
                        DxoDropDownButtonCollisionModule,
                        DxoDropDownButtonDropDownOptionsModule,
                        DxoDropDownButtonFromModule,
                        DxoDropDownButtonHideModule,
                        DxiDropDownButtonItemModule,
                        DxoDropDownButtonMyModule,
                        DxoDropDownButtonOffsetModule,
                        DxoDropDownButtonPositionModule,
                        DxoDropDownButtonShowModule,
                        DxoDropDownButtonToModule,
                        DxiDropDownButtonToolbarItemModule,
                        DxTemplateModule
                    ]
                }]
        }] });

/**
 * Generated bundle index. Do not edit.
 */

export { DxDropDownButtonComponent, DxDropDownButtonModule };
//# sourceMappingURL=devextreme-angular-ui-drop-down-button.mjs.map
