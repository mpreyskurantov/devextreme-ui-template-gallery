import * as i0 from '@angular/core';
import { PLATFORM_ID, Output, Input, Inject, Component, NgModule } from '@angular/core';
import DxBarGauge from 'devextreme/viz/bar_gauge';
import * as i1 from 'devextreme-angular/core';
import { DxComponent, DxIntegrationModule, DxTemplateHost, WatcherHelper, NestedOptionHost, IterableDifferHelper, DxTemplateModule } from 'devextreme-angular/core';
import { DxoAnimationModule, DxoExportModule, DxoGeometryModule, DxoLabelModule, DxoFontModule, DxoFormatModule, DxoLegendModule, DxoBorderModule, DxoItemTextFormatModule, DxoMarginModule, DxoTitleModule, DxoSubtitleModule, DxoLoadingIndicatorModule, DxoSizeModule, DxoTooltipModule, DxoShadowModule } from 'devextreme-angular/ui/nested';
import { DxoBarGaugeAnimationModule, DxoBarGaugeBarGaugeTitleModule, DxoBarGaugeBarGaugeTitleSubtitleModule, DxoBarGaugeBorderModule, DxoBarGaugeExportModule, DxoBarGaugeFontModule, DxoBarGaugeFormatModule, DxoBarGaugeGeometryModule, DxoBarGaugeItemTextFormatModule, DxoBarGaugeLabelModule, DxoBarGaugeLegendModule, DxoBarGaugeLegendBorderModule, DxoBarGaugeLegendTitleModule, DxoBarGaugeLegendTitleSubtitleModule, DxoBarGaugeLoadingIndicatorModule, DxoBarGaugeMarginModule, DxoBarGaugeShadowModule, DxoBarGaugeSizeModule, DxoBarGaugeSubtitleModule, DxoBarGaugeTitleModule, DxoBarGaugeTooltipModule, DxoBarGaugeTooltipBorderModule } from 'devextreme-angular/ui/bar-gauge/nested';
export * from 'devextreme-angular/ui/bar-gauge/nested';

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
/**
 * [descr:dxBarGauge]

 */
class DxBarGaugeComponent extends DxComponent {
    /**
     * [descr:dxBarGaugeOptions.animation]
    
     */
    get animation() {
        return this._getOption('animation');
    }
    set animation(value) {
        this._setOption('animation', value);
    }
    /**
     * [descr:dxBarGaugeOptions.backgroundColor]
    
     */
    get backgroundColor() {
        return this._getOption('backgroundColor');
    }
    set backgroundColor(value) {
        this._setOption('backgroundColor', value);
    }
    /**
     * [descr:dxBarGaugeOptions.barSpacing]
    
     */
    get barSpacing() {
        return this._getOption('barSpacing');
    }
    set barSpacing(value) {
        this._setOption('barSpacing', value);
    }
    /**
     * [descr:dxBarGaugeOptions.baseValue]
    
     */
    get baseValue() {
        return this._getOption('baseValue');
    }
    set baseValue(value) {
        this._setOption('baseValue', value);
    }
    /**
     * [descr:dxBarGaugeOptions.centerTemplate]
    
     */
    get centerTemplate() {
        return this._getOption('centerTemplate');
    }
    set centerTemplate(value) {
        this._setOption('centerTemplate', value);
    }
    /**
     * [descr:BaseWidgetOptions.disabled]
    
     */
    get disabled() {
        return this._getOption('disabled');
    }
    set disabled(value) {
        this._setOption('disabled', value);
    }
    /**
     * [descr:DOMComponentOptions.elementAttr]
    
     */
    get elementAttr() {
        return this._getOption('elementAttr');
    }
    set elementAttr(value) {
        this._setOption('elementAttr', value);
    }
    /**
     * [descr:BaseWidgetOptions.encodeHtml]
    
     */
    get encodeHtml() {
        return this._getOption('encodeHtml');
    }
    set encodeHtml(value) {
        this._setOption('encodeHtml', value);
    }
    /**
     * [descr:dxBarGaugeOptions.endValue]
    
     */
    get endValue() {
        return this._getOption('endValue');
    }
    set endValue(value) {
        this._setOption('endValue', value);
    }
    /**
     * [descr:BaseWidgetOptions.export]
    
     */
    get export() {
        return this._getOption('export');
    }
    set export(value) {
        this._setOption('export', value);
    }
    /**
     * [descr:dxBarGaugeOptions.geometry]
    
     */
    get geometry() {
        return this._getOption('geometry');
    }
    set geometry(value) {
        this._setOption('geometry', value);
    }
    /**
     * [descr:dxBarGaugeOptions.label]
    
     */
    get label() {
        return this._getOption('label');
    }
    set label(value) {
        this._setOption('label', value);
    }
    /**
     * [descr:dxBarGaugeOptions.legend]
    
     */
    get legend() {
        return this._getOption('legend');
    }
    set legend(value) {
        this._setOption('legend', value);
    }
    /**
     * [descr:dxBarGaugeOptions.loadingIndicator]
    
     */
    get loadingIndicator() {
        return this._getOption('loadingIndicator');
    }
    set loadingIndicator(value) {
        this._setOption('loadingIndicator', value);
    }
    /**
     * [descr:BaseWidgetOptions.margin]
    
     */
    get margin() {
        return this._getOption('margin');
    }
    set margin(value) {
        this._setOption('margin', value);
    }
    /**
     * [descr:dxBarGaugeOptions.palette]
    
     */
    get palette() {
        return this._getOption('palette');
    }
    set palette(value) {
        this._setOption('palette', value);
    }
    /**
     * [descr:dxBarGaugeOptions.paletteExtensionMode]
    
     */
    get paletteExtensionMode() {
        return this._getOption('paletteExtensionMode');
    }
    set paletteExtensionMode(value) {
        this._setOption('paletteExtensionMode', value);
    }
    /**
     * [descr:BaseWidgetOptions.pathModified]
    
     */
    get pathModified() {
        return this._getOption('pathModified');
    }
    set pathModified(value) {
        this._setOption('pathModified', value);
    }
    /**
     * [descr:BaseWidgetOptions.redrawOnResize]
    
     */
    get redrawOnResize() {
        return this._getOption('redrawOnResize');
    }
    set redrawOnResize(value) {
        this._setOption('redrawOnResize', value);
    }
    /**
     * [descr:dxBarGaugeOptions.relativeInnerRadius]
    
     */
    get relativeInnerRadius() {
        return this._getOption('relativeInnerRadius');
    }
    set relativeInnerRadius(value) {
        this._setOption('relativeInnerRadius', value);
    }
    /**
     * [descr:dxBarGaugeOptions.resolveLabelOverlapping]
    
     */
    get resolveLabelOverlapping() {
        return this._getOption('resolveLabelOverlapping');
    }
    set resolveLabelOverlapping(value) {
        this._setOption('resolveLabelOverlapping', value);
    }
    /**
     * [descr:BaseWidgetOptions.rtlEnabled]
    
     */
    get rtlEnabled() {
        return this._getOption('rtlEnabled');
    }
    set rtlEnabled(value) {
        this._setOption('rtlEnabled', value);
    }
    /**
     * [descr:BaseWidgetOptions.size]
    
     */
    get size() {
        return this._getOption('size');
    }
    set size(value) {
        this._setOption('size', value);
    }
    /**
     * [descr:dxBarGaugeOptions.startValue]
    
     */
    get startValue() {
        return this._getOption('startValue');
    }
    set startValue(value) {
        this._setOption('startValue', value);
    }
    /**
     * [descr:BaseWidgetOptions.theme]
    
     */
    get theme() {
        return this._getOption('theme');
    }
    set theme(value) {
        this._setOption('theme', value);
    }
    /**
     * [descr:BaseWidgetOptions.title]
    
     */
    get title() {
        return this._getOption('title');
    }
    set title(value) {
        this._setOption('title', value);
    }
    /**
     * [descr:dxBarGaugeOptions.tooltip]
    
     */
    get tooltip() {
        return this._getOption('tooltip');
    }
    set tooltip(value) {
        this._setOption('tooltip', value);
    }
    /**
     * [descr:dxBarGaugeOptions.values]
    
     */
    get values() {
        return this._getOption('values');
    }
    set values(value) {
        this._setOption('values', value);
    }
    constructor(elementRef, ngZone, templateHost, _watcherHelper, _idh, optionHost, transferState, platformId) {
        super(elementRef, ngZone, templateHost, _watcherHelper, transferState, platformId);
        this._watcherHelper = _watcherHelper;
        this._idh = _idh;
        this.instance = null;
        this._createEventEmitters([
            { subscribe: 'disposing', emit: 'onDisposing' },
            { subscribe: 'drawn', emit: 'onDrawn' },
            { subscribe: 'exported', emit: 'onExported' },
            { subscribe: 'exporting', emit: 'onExporting' },
            { subscribe: 'fileSaving', emit: 'onFileSaving' },
            { subscribe: 'incidentOccurred', emit: 'onIncidentOccurred' },
            { subscribe: 'initialized', emit: 'onInitialized' },
            { subscribe: 'optionChanged', emit: 'onOptionChanged' },
            { subscribe: 'tooltipHidden', emit: 'onTooltipHidden' },
            { subscribe: 'tooltipShown', emit: 'onTooltipShown' },
            { emit: 'animationChange' },
            { emit: 'backgroundColorChange' },
            { emit: 'barSpacingChange' },
            { emit: 'baseValueChange' },
            { emit: 'centerTemplateChange' },
            { emit: 'disabledChange' },
            { emit: 'elementAttrChange' },
            { emit: 'encodeHtmlChange' },
            { emit: 'endValueChange' },
            { emit: 'exportChange' },
            { emit: 'geometryChange' },
            { emit: 'labelChange' },
            { emit: 'legendChange' },
            { emit: 'loadingIndicatorChange' },
            { emit: 'marginChange' },
            { emit: 'paletteChange' },
            { emit: 'paletteExtensionModeChange' },
            { emit: 'pathModifiedChange' },
            { emit: 'redrawOnResizeChange' },
            { emit: 'relativeInnerRadiusChange' },
            { emit: 'resolveLabelOverlappingChange' },
            { emit: 'rtlEnabledChange' },
            { emit: 'sizeChange' },
            { emit: 'startValueChange' },
            { emit: 'themeChange' },
            { emit: 'titleChange' },
            { emit: 'tooltipChange' },
            { emit: 'valuesChange' }
        ]);
        this._idh.setHost(this);
        optionHost.setHost(this);
    }
    _createInstance(element, options) {
        return new DxBarGauge(element, options);
    }
    ngOnDestroy() {
        this._destroyWidget();
    }
    ngOnChanges(changes) {
        super.ngOnChanges(changes);
        this.setupChanges('palette', changes);
        this.setupChanges('values', changes);
    }
    setupChanges(prop, changes) {
        if (!(prop in this._optionsToUpdate)) {
            this._idh.setup(prop, changes);
        }
    }
    ngDoCheck() {
        this._idh.doCheck('palette');
        this._idh.doCheck('values');
        this._watcherHelper.checkWatchers();
        super.ngDoCheck();
        super.clearChangedOptions();
    }
    _setOption(name, value) {
        let isSetup = this._idh.setupSingle(name, value);
        let isChanged = this._idh.getChanges(name, value) !== null;
        if (isSetup || isChanged) {
            super._setOption(name, value);
        }
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxBarGaugeComponent, deps: [{ token: i0.ElementRef }, { token: i0.NgZone }, { token: i1.DxTemplateHost }, { token: i1.WatcherHelper }, { token: i1.IterableDifferHelper }, { token: i1.NestedOptionHost }, { token: i0.TransferState }, { token: PLATFORM_ID }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxBarGaugeComponent, isStandalone: true, selector: "dx-bar-gauge", inputs: { animation: "animation", backgroundColor: "backgroundColor", barSpacing: "barSpacing", baseValue: "baseValue", centerTemplate: "centerTemplate", disabled: "disabled", elementAttr: "elementAttr", encodeHtml: "encodeHtml", endValue: "endValue", export: "export", geometry: "geometry", label: "label", legend: "legend", loadingIndicator: "loadingIndicator", margin: "margin", palette: "palette", paletteExtensionMode: "paletteExtensionMode", pathModified: "pathModified", redrawOnResize: "redrawOnResize", relativeInnerRadius: "relativeInnerRadius", resolveLabelOverlapping: "resolveLabelOverlapping", rtlEnabled: "rtlEnabled", size: "size", startValue: "startValue", theme: "theme", title: "title", tooltip: "tooltip", values: "values" }, outputs: { onDisposing: "onDisposing", onDrawn: "onDrawn", onExported: "onExported", onExporting: "onExporting", onFileSaving: "onFileSaving", onIncidentOccurred: "onIncidentOccurred", onInitialized: "onInitialized", onOptionChanged: "onOptionChanged", onTooltipHidden: "onTooltipHidden", onTooltipShown: "onTooltipShown", animationChange: "animationChange", backgroundColorChange: "backgroundColorChange", barSpacingChange: "barSpacingChange", baseValueChange: "baseValueChange", centerTemplateChange: "centerTemplateChange", disabledChange: "disabledChange", elementAttrChange: "elementAttrChange", encodeHtmlChange: "encodeHtmlChange", endValueChange: "endValueChange", exportChange: "exportChange", geometryChange: "geometryChange", labelChange: "labelChange", legendChange: "legendChange", loadingIndicatorChange: "loadingIndicatorChange", marginChange: "marginChange", paletteChange: "paletteChange", paletteExtensionModeChange: "paletteExtensionModeChange", pathModifiedChange: "pathModifiedChange", redrawOnResizeChange: "redrawOnResizeChange", relativeInnerRadiusChange: "relativeInnerRadiusChange", resolveLabelOverlappingChange: "resolveLabelOverlappingChange", rtlEnabledChange: "rtlEnabledChange", sizeChange: "sizeChange", startValueChange: "startValueChange", themeChange: "themeChange", titleChange: "titleChange", tooltipChange: "tooltipChange", valuesChange: "valuesChange" }, host: { attributes: { "ngSkipHydration": "true" } }, providers: [
            DxTemplateHost,
            WatcherHelper,
            NestedOptionHost,
            IterableDifferHelper
        ], usesInheritance: true, usesOnChanges: true, ngImport: i0, template: '', isInline: true, styles: [":host{display:block}\n"], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxBarGaugeComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dx-bar-gauge', template: '', host: { ngSkipHydration: 'true' }, imports: [DxIntegrationModule], providers: [
                        DxTemplateHost,
                        WatcherHelper,
                        NestedOptionHost,
                        IterableDifferHelper
                    ], styles: [":host{display:block}\n"] }]
        }], ctorParameters: () => [{ type: i0.ElementRef }, { type: i0.NgZone }, { type: i1.DxTemplateHost }, { type: i1.WatcherHelper }, { type: i1.IterableDifferHelper }, { type: i1.NestedOptionHost }, { type: i0.TransferState }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [PLATFORM_ID]
                }] }], propDecorators: { animation: [{
                type: Input
            }], backgroundColor: [{
                type: Input
            }], barSpacing: [{
                type: Input
            }], baseValue: [{
                type: Input
            }], centerTemplate: [{
                type: Input
            }], disabled: [{
                type: Input
            }], elementAttr: [{
                type: Input
            }], encodeHtml: [{
                type: Input
            }], endValue: [{
                type: Input
            }], export: [{
                type: Input
            }], geometry: [{
                type: Input
            }], label: [{
                type: Input
            }], legend: [{
                type: Input
            }], loadingIndicator: [{
                type: Input
            }], margin: [{
                type: Input
            }], palette: [{
                type: Input
            }], paletteExtensionMode: [{
                type: Input
            }], pathModified: [{
                type: Input
            }], redrawOnResize: [{
                type: Input
            }], relativeInnerRadius: [{
                type: Input
            }], resolveLabelOverlapping: [{
                type: Input
            }], rtlEnabled: [{
                type: Input
            }], size: [{
                type: Input
            }], startValue: [{
                type: Input
            }], theme: [{
                type: Input
            }], title: [{
                type: Input
            }], tooltip: [{
                type: Input
            }], values: [{
                type: Input
            }], onDisposing: [{
                type: Output
            }], onDrawn: [{
                type: Output
            }], onExported: [{
                type: Output
            }], onExporting: [{
                type: Output
            }], onFileSaving: [{
                type: Output
            }], onIncidentOccurred: [{
                type: Output
            }], onInitialized: [{
                type: Output
            }], onOptionChanged: [{
                type: Output
            }], onTooltipHidden: [{
                type: Output
            }], onTooltipShown: [{
                type: Output
            }], animationChange: [{
                type: Output
            }], backgroundColorChange: [{
                type: Output
            }], barSpacingChange: [{
                type: Output
            }], baseValueChange: [{
                type: Output
            }], centerTemplateChange: [{
                type: Output
            }], disabledChange: [{
                type: Output
            }], elementAttrChange: [{
                type: Output
            }], encodeHtmlChange: [{
                type: Output
            }], endValueChange: [{
                type: Output
            }], exportChange: [{
                type: Output
            }], geometryChange: [{
                type: Output
            }], labelChange: [{
                type: Output
            }], legendChange: [{
                type: Output
            }], loadingIndicatorChange: [{
                type: Output
            }], marginChange: [{
                type: Output
            }], paletteChange: [{
                type: Output
            }], paletteExtensionModeChange: [{
                type: Output
            }], pathModifiedChange: [{
                type: Output
            }], redrawOnResizeChange: [{
                type: Output
            }], relativeInnerRadiusChange: [{
                type: Output
            }], resolveLabelOverlappingChange: [{
                type: Output
            }], rtlEnabledChange: [{
                type: Output
            }], sizeChange: [{
                type: Output
            }], startValueChange: [{
                type: Output
            }], themeChange: [{
                type: Output
            }], titleChange: [{
                type: Output
            }], tooltipChange: [{
                type: Output
            }], valuesChange: [{
                type: Output
            }] } });
class DxBarGaugeModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxBarGaugeModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxBarGaugeModule, imports: [DxBarGaugeComponent, DxoAnimationModule,
            DxoExportModule,
            DxoGeometryModule,
            DxoLabelModule,
            DxoFontModule,
            DxoFormatModule,
            DxoLegendModule,
            DxoBorderModule,
            DxoItemTextFormatModule,
            DxoMarginModule,
            DxoTitleModule,
            DxoSubtitleModule,
            DxoLoadingIndicatorModule,
            DxoSizeModule,
            DxoTooltipModule,
            DxoShadowModule,
            DxoBarGaugeAnimationModule,
            DxoBarGaugeBarGaugeTitleModule,
            DxoBarGaugeBarGaugeTitleSubtitleModule,
            DxoBarGaugeBorderModule,
            DxoBarGaugeExportModule,
            DxoBarGaugeFontModule,
            DxoBarGaugeFormatModule,
            DxoBarGaugeGeometryModule,
            DxoBarGaugeItemTextFormatModule,
            DxoBarGaugeLabelModule,
            DxoBarGaugeLegendModule,
            DxoBarGaugeLegendBorderModule,
            DxoBarGaugeLegendTitleModule,
            DxoBarGaugeLegendTitleSubtitleModule,
            DxoBarGaugeLoadingIndicatorModule,
            DxoBarGaugeMarginModule,
            DxoBarGaugeShadowModule,
            DxoBarGaugeSizeModule,
            DxoBarGaugeSubtitleModule,
            DxoBarGaugeTitleModule,
            DxoBarGaugeTooltipModule,
            DxoBarGaugeTooltipBorderModule,
            DxIntegrationModule,
            DxTemplateModule], exports: [DxBarGaugeComponent, DxoAnimationModule,
            DxoExportModule,
            DxoGeometryModule,
            DxoLabelModule,
            DxoFontModule,
            DxoFormatModule,
            DxoLegendModule,
            DxoBorderModule,
            DxoItemTextFormatModule,
            DxoMarginModule,
            DxoTitleModule,
            DxoSubtitleModule,
            DxoLoadingIndicatorModule,
            DxoSizeModule,
            DxoTooltipModule,
            DxoShadowModule,
            DxoBarGaugeAnimationModule,
            DxoBarGaugeBarGaugeTitleModule,
            DxoBarGaugeBarGaugeTitleSubtitleModule,
            DxoBarGaugeBorderModule,
            DxoBarGaugeExportModule,
            DxoBarGaugeFontModule,
            DxoBarGaugeFormatModule,
            DxoBarGaugeGeometryModule,
            DxoBarGaugeItemTextFormatModule,
            DxoBarGaugeLabelModule,
            DxoBarGaugeLegendModule,
            DxoBarGaugeLegendBorderModule,
            DxoBarGaugeLegendTitleModule,
            DxoBarGaugeLegendTitleSubtitleModule,
            DxoBarGaugeLoadingIndicatorModule,
            DxoBarGaugeMarginModule,
            DxoBarGaugeShadowModule,
            DxoBarGaugeSizeModule,
            DxoBarGaugeSubtitleModule,
            DxoBarGaugeTitleModule,
            DxoBarGaugeTooltipModule,
            DxoBarGaugeTooltipBorderModule,
            DxTemplateModule] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxBarGaugeModule, imports: [DxBarGaugeComponent,
            DxoAnimationModule,
            DxoExportModule,
            DxoGeometryModule,
            DxoLabelModule,
            DxoFontModule,
            DxoFormatModule,
            DxoLegendModule,
            DxoBorderModule,
            DxoItemTextFormatModule,
            DxoMarginModule,
            DxoTitleModule,
            DxoSubtitleModule,
            DxoLoadingIndicatorModule,
            DxoSizeModule,
            DxoTooltipModule,
            DxoShadowModule,
            DxoBarGaugeAnimationModule,
            DxoBarGaugeBarGaugeTitleModule,
            DxoBarGaugeBarGaugeTitleSubtitleModule,
            DxoBarGaugeBorderModule,
            DxoBarGaugeExportModule,
            DxoBarGaugeFontModule,
            DxoBarGaugeFormatModule,
            DxoBarGaugeGeometryModule,
            DxoBarGaugeItemTextFormatModule,
            DxoBarGaugeLabelModule,
            DxoBarGaugeLegendModule,
            DxoBarGaugeLegendBorderModule,
            DxoBarGaugeLegendTitleModule,
            DxoBarGaugeLegendTitleSubtitleModule,
            DxoBarGaugeLoadingIndicatorModule,
            DxoBarGaugeMarginModule,
            DxoBarGaugeShadowModule,
            DxoBarGaugeSizeModule,
            DxoBarGaugeSubtitleModule,
            DxoBarGaugeTitleModule,
            DxoBarGaugeTooltipModule,
            DxoBarGaugeTooltipBorderModule,
            DxIntegrationModule,
            DxTemplateModule, DxoAnimationModule,
            DxoExportModule,
            DxoGeometryModule,
            DxoLabelModule,
            DxoFontModule,
            DxoFormatModule,
            DxoLegendModule,
            DxoBorderModule,
            DxoItemTextFormatModule,
            DxoMarginModule,
            DxoTitleModule,
            DxoSubtitleModule,
            DxoLoadingIndicatorModule,
            DxoSizeModule,
            DxoTooltipModule,
            DxoShadowModule,
            DxoBarGaugeAnimationModule,
            DxoBarGaugeBarGaugeTitleModule,
            DxoBarGaugeBarGaugeTitleSubtitleModule,
            DxoBarGaugeBorderModule,
            DxoBarGaugeExportModule,
            DxoBarGaugeFontModule,
            DxoBarGaugeFormatModule,
            DxoBarGaugeGeometryModule,
            DxoBarGaugeItemTextFormatModule,
            DxoBarGaugeLabelModule,
            DxoBarGaugeLegendModule,
            DxoBarGaugeLegendBorderModule,
            DxoBarGaugeLegendTitleModule,
            DxoBarGaugeLegendTitleSubtitleModule,
            DxoBarGaugeLoadingIndicatorModule,
            DxoBarGaugeMarginModule,
            DxoBarGaugeShadowModule,
            DxoBarGaugeSizeModule,
            DxoBarGaugeSubtitleModule,
            DxoBarGaugeTitleModule,
            DxoBarGaugeTooltipModule,
            DxoBarGaugeTooltipBorderModule,
            DxTemplateModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxBarGaugeModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxBarGaugeComponent,
                        DxoAnimationModule,
                        DxoExportModule,
                        DxoGeometryModule,
                        DxoLabelModule,
                        DxoFontModule,
                        DxoFormatModule,
                        DxoLegendModule,
                        DxoBorderModule,
                        DxoItemTextFormatModule,
                        DxoMarginModule,
                        DxoTitleModule,
                        DxoSubtitleModule,
                        DxoLoadingIndicatorModule,
                        DxoSizeModule,
                        DxoTooltipModule,
                        DxoShadowModule,
                        DxoBarGaugeAnimationModule,
                        DxoBarGaugeBarGaugeTitleModule,
                        DxoBarGaugeBarGaugeTitleSubtitleModule,
                        DxoBarGaugeBorderModule,
                        DxoBarGaugeExportModule,
                        DxoBarGaugeFontModule,
                        DxoBarGaugeFormatModule,
                        DxoBarGaugeGeometryModule,
                        DxoBarGaugeItemTextFormatModule,
                        DxoBarGaugeLabelModule,
                        DxoBarGaugeLegendModule,
                        DxoBarGaugeLegendBorderModule,
                        DxoBarGaugeLegendTitleModule,
                        DxoBarGaugeLegendTitleSubtitleModule,
                        DxoBarGaugeLoadingIndicatorModule,
                        DxoBarGaugeMarginModule,
                        DxoBarGaugeShadowModule,
                        DxoBarGaugeSizeModule,
                        DxoBarGaugeSubtitleModule,
                        DxoBarGaugeTitleModule,
                        DxoBarGaugeTooltipModule,
                        DxoBarGaugeTooltipBorderModule,
                        DxIntegrationModule,
                        DxTemplateModule
                    ],
                    exports: [
                        DxBarGaugeComponent,
                        DxoAnimationModule,
                        DxoExportModule,
                        DxoGeometryModule,
                        DxoLabelModule,
                        DxoFontModule,
                        DxoFormatModule,
                        DxoLegendModule,
                        DxoBorderModule,
                        DxoItemTextFormatModule,
                        DxoMarginModule,
                        DxoTitleModule,
                        DxoSubtitleModule,
                        DxoLoadingIndicatorModule,
                        DxoSizeModule,
                        DxoTooltipModule,
                        DxoShadowModule,
                        DxoBarGaugeAnimationModule,
                        DxoBarGaugeBarGaugeTitleModule,
                        DxoBarGaugeBarGaugeTitleSubtitleModule,
                        DxoBarGaugeBorderModule,
                        DxoBarGaugeExportModule,
                        DxoBarGaugeFontModule,
                        DxoBarGaugeFormatModule,
                        DxoBarGaugeGeometryModule,
                        DxoBarGaugeItemTextFormatModule,
                        DxoBarGaugeLabelModule,
                        DxoBarGaugeLegendModule,
                        DxoBarGaugeLegendBorderModule,
                        DxoBarGaugeLegendTitleModule,
                        DxoBarGaugeLegendTitleSubtitleModule,
                        DxoBarGaugeLoadingIndicatorModule,
                        DxoBarGaugeMarginModule,
                        DxoBarGaugeShadowModule,
                        DxoBarGaugeSizeModule,
                        DxoBarGaugeSubtitleModule,
                        DxoBarGaugeTitleModule,
                        DxoBarGaugeTooltipModule,
                        DxoBarGaugeTooltipBorderModule,
                        DxTemplateModule
                    ]
                }]
        }] });

/**
 * Generated bundle index. Do not edit.
 */

export { DxBarGaugeComponent, DxBarGaugeModule };
//# sourceMappingURL=devextreme-angular-ui-bar-gauge.mjs.map
