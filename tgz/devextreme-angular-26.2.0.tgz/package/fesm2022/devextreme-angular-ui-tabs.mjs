import * as i0 from '@angular/core';
import { PLATFORM_ID, Output, Input, ContentChildren, Inject, Component, NgModule } from '@angular/core';
import DxTabs from 'devextreme/ui/tabs';
import * as i1 from 'devextreme-angular/core';
import { DxComponent, DxIntegrationModule, DxTemplateHost, WatcherHelper, NestedOptionHost, IterableDifferHelper, DxTemplateModule } from 'devextreme-angular/core';
import { DxiItemModule } from 'devextreme-angular/ui/nested';
import { DxiTabsItemModule } from 'devextreme-angular/ui/tabs/nested';
export * from 'devextreme-angular/ui/tabs/nested';
import { PROPERTY_TOKEN_items } from 'devextreme-angular/core/tokens';

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
/**
 * [descr:dxTabs]

 */
class DxTabsComponent extends DxComponent {
    set _itemsContentChildren(value) {
        this.setChildren('items', value);
    }
    /**
     * [descr:WidgetOptions.accessKey]
    
     */
    get accessKey() {
        return this._getOption('accessKey');
    }
    set accessKey(value) {
        this._setOption('accessKey', value);
    }
    /**
     * [descr:dxTabsOptions.dataSource]
    
     */
    get dataSource() {
        return this._getOption('dataSource');
    }
    set dataSource(value) {
        this._setOption('dataSource', value);
    }
    /**
     * [descr:WidgetOptions.disabled]
    
     */
    get disabled() {
        return this._getOption('disabled');
    }
    set disabled(value) {
        this._setOption('disabled', value);
    }
    /**
     * [descr:DOMComponentOptions.elementAttr]
    
     */
    get elementAttr() {
        return this._getOption('elementAttr');
    }
    set elementAttr(value) {
        this._setOption('elementAttr', value);
    }
    /**
     * [descr:dxTabsOptions.focusStateEnabled]
    
     */
    get focusStateEnabled() {
        return this._getOption('focusStateEnabled');
    }
    set focusStateEnabled(value) {
        this._setOption('focusStateEnabled', value);
    }
    /**
     * [descr:DOMComponentOptions.height]
    
     */
    get height() {
        return this._getOption('height');
    }
    set height(value) {
        this._setOption('height', value);
    }
    /**
     * [descr:WidgetOptions.hint]
    
     */
    get hint() {
        return this._getOption('hint');
    }
    set hint(value) {
        this._setOption('hint', value);
    }
    /**
     * [descr:dxTabsOptions.hoverStateEnabled]
    
     */
    get hoverStateEnabled() {
        return this._getOption('hoverStateEnabled');
    }
    set hoverStateEnabled(value) {
        this._setOption('hoverStateEnabled', value);
    }
    /**
     * [descr:dxTabsOptions.iconPosition]
    
     */
    get iconPosition() {
        return this._getOption('iconPosition');
    }
    set iconPosition(value) {
        this._setOption('iconPosition', value);
    }
    /**
     * [descr:CollectionWidgetOptions.itemHoldTimeout]
    
     */
    get itemHoldTimeout() {
        return this._getOption('itemHoldTimeout');
    }
    set itemHoldTimeout(value) {
        this._setOption('itemHoldTimeout', value);
    }
    /**
     * [descr:dxTabsOptions.items]
    
     */
    get items() {
        return this._getOption('items');
    }
    set items(value) {
        this._setOption('items', value);
    }
    /**
     * [descr:CollectionWidgetOptions.itemTemplate]
    
     */
    get itemTemplate() {
        return this._getOption('itemTemplate');
    }
    set itemTemplate(value) {
        this._setOption('itemTemplate', value);
    }
    /**
     * [descr:CollectionWidgetOptions.keyExpr]
    
     */
    get keyExpr() {
        return this._getOption('keyExpr');
    }
    set keyExpr(value) {
        this._setOption('keyExpr', value);
    }
    /**
     * [descr:CollectionWidgetOptions.noDataText]
    
     */
    get noDataText() {
        return this._getOption('noDataText');
    }
    set noDataText(value) {
        this._setOption('noDataText', value);
    }
    /**
     * [descr:dxTabsOptions.orientation]
    
     */
    get orientation() {
        return this._getOption('orientation');
    }
    set orientation(value) {
        this._setOption('orientation', value);
    }
    /**
     * [descr:dxTabsOptions.repaintChangesOnly]
    
     */
    get repaintChangesOnly() {
        return this._getOption('repaintChangesOnly');
    }
    set repaintChangesOnly(value) {
        this._setOption('repaintChangesOnly', value);
    }
    /**
     * [descr:DOMComponentOptions.rtlEnabled]
    
     */
    get rtlEnabled() {
        return this._getOption('rtlEnabled');
    }
    set rtlEnabled(value) {
        this._setOption('rtlEnabled', value);
    }
    /**
     * [descr:dxTabsOptions.scrollByContent]
    
     */
    get scrollByContent() {
        return this._getOption('scrollByContent');
    }
    set scrollByContent(value) {
        this._setOption('scrollByContent', value);
    }
    /**
     * [descr:dxTabsOptions.scrollingEnabled]
    
     */
    get scrollingEnabled() {
        return this._getOption('scrollingEnabled');
    }
    set scrollingEnabled(value) {
        this._setOption('scrollingEnabled', value);
    }
    /**
     * [descr:CollectionWidgetOptions.selectedIndex]
    
     */
    get selectedIndex() {
        return this._getOption('selectedIndex');
    }
    set selectedIndex(value) {
        this._setOption('selectedIndex', value);
    }
    /**
     * [descr:CollectionWidgetOptions.selectedItem]
    
     */
    get selectedItem() {
        return this._getOption('selectedItem');
    }
    set selectedItem(value) {
        this._setOption('selectedItem', value);
    }
    /**
     * [descr:CollectionWidgetOptions.selectedItemKeys]
    
     */
    get selectedItemKeys() {
        return this._getOption('selectedItemKeys');
    }
    set selectedItemKeys(value) {
        this._setOption('selectedItemKeys', value);
    }
    /**
     * [descr:CollectionWidgetOptions.selectedItems]
    
     */
    get selectedItems() {
        return this._getOption('selectedItems');
    }
    set selectedItems(value) {
        this._setOption('selectedItems', value);
    }
    /**
     * [descr:dxTabsOptions.selectionMode]
    
     */
    get selectionMode() {
        return this._getOption('selectionMode');
    }
    set selectionMode(value) {
        this._setOption('selectionMode', value);
    }
    /**
     * [descr:dxTabsOptions.showNavButtons]
    
     */
    get showNavButtons() {
        return this._getOption('showNavButtons');
    }
    set showNavButtons(value) {
        this._setOption('showNavButtons', value);
    }
    /**
     * [descr:dxTabsOptions.stylingMode]
    
     */
    get stylingMode() {
        return this._getOption('stylingMode');
    }
    set stylingMode(value) {
        this._setOption('stylingMode', value);
    }
    /**
     * [descr:WidgetOptions.tabIndex]
    
     */
    get tabIndex() {
        return this._getOption('tabIndex');
    }
    set tabIndex(value) {
        this._setOption('tabIndex', value);
    }
    /**
     * [descr:WidgetOptions.visible]
    
     */
    get visible() {
        return this._getOption('visible');
    }
    set visible(value) {
        this._setOption('visible', value);
    }
    /**
     * [descr:DOMComponentOptions.width]
    
     */
    get width() {
        return this._getOption('width');
    }
    set width(value) {
        this._setOption('width', value);
    }
    constructor(elementRef, ngZone, templateHost, _watcherHelper, _idh, optionHost, transferState, platformId) {
        super(elementRef, ngZone, templateHost, _watcherHelper, transferState, platformId);
        this._watcherHelper = _watcherHelper;
        this._idh = _idh;
        this.instance = null;
        this._createEventEmitters([
            { subscribe: 'contentReady', emit: 'onContentReady' },
            { subscribe: 'disposing', emit: 'onDisposing' },
            { subscribe: 'initialized', emit: 'onInitialized' },
            { subscribe: 'itemClick', emit: 'onItemClick' },
            { subscribe: 'itemContextMenu', emit: 'onItemContextMenu' },
            { subscribe: 'itemHold', emit: 'onItemHold' },
            { subscribe: 'itemRendered', emit: 'onItemRendered' },
            { subscribe: 'optionChanged', emit: 'onOptionChanged' },
            { subscribe: 'selectionChanged', emit: 'onSelectionChanged' },
            { subscribe: 'selectionChanging', emit: 'onSelectionChanging' },
            { emit: 'accessKeyChange' },
            { emit: 'dataSourceChange' },
            { emit: 'disabledChange' },
            { emit: 'elementAttrChange' },
            { emit: 'focusStateEnabledChange' },
            { emit: 'heightChange' },
            { emit: 'hintChange' },
            { emit: 'hoverStateEnabledChange' },
            { emit: 'iconPositionChange' },
            { emit: 'itemHoldTimeoutChange' },
            { emit: 'itemsChange' },
            { emit: 'itemTemplateChange' },
            { emit: 'keyExprChange' },
            { emit: 'noDataTextChange' },
            { emit: 'orientationChange' },
            { emit: 'repaintChangesOnlyChange' },
            { emit: 'rtlEnabledChange' },
            { emit: 'scrollByContentChange' },
            { emit: 'scrollingEnabledChange' },
            { emit: 'selectedIndexChange' },
            { emit: 'selectedItemChange' },
            { emit: 'selectedItemKeysChange' },
            { emit: 'selectedItemsChange' },
            { emit: 'selectionModeChange' },
            { emit: 'showNavButtonsChange' },
            { emit: 'stylingModeChange' },
            { emit: 'tabIndexChange' },
            { emit: 'visibleChange' },
            { emit: 'widthChange' }
        ]);
        this._idh.setHost(this);
        optionHost.setHost(this);
    }
    _createInstance(element, options) {
        return new DxTabs(element, options);
    }
    ngOnDestroy() {
        this._destroyWidget();
    }
    ngOnChanges(changes) {
        super.ngOnChanges(changes);
        this.setupChanges('dataSource', changes);
        this.setupChanges('items', changes);
        this.setupChanges('selectedItemKeys', changes);
        this.setupChanges('selectedItems', changes);
    }
    setupChanges(prop, changes) {
        if (!(prop in this._optionsToUpdate)) {
            this._idh.setup(prop, changes);
        }
    }
    ngDoCheck() {
        this._idh.doCheck('dataSource');
        this._idh.doCheck('items');
        this._idh.doCheck('selectedItemKeys');
        this._idh.doCheck('selectedItems');
        this._watcherHelper.checkWatchers();
        super.ngDoCheck();
        super.clearChangedOptions();
    }
    _setOption(name, value) {
        let isSetup = this._idh.setupSingle(name, value);
        let isChanged = this._idh.getChanges(name, value) !== null;
        if (isSetup || isChanged) {
            super._setOption(name, value);
        }
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxTabsComponent, deps: [{ token: i0.ElementRef }, { token: i0.NgZone }, { token: i1.DxTemplateHost }, { token: i1.WatcherHelper }, { token: i1.IterableDifferHelper }, { token: i1.NestedOptionHost }, { token: i0.TransferState }, { token: PLATFORM_ID }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxTabsComponent, isStandalone: true, selector: "dx-tabs", inputs: { accessKey: "accessKey", dataSource: "dataSource", disabled: "disabled", elementAttr: "elementAttr", focusStateEnabled: "focusStateEnabled", height: "height", hint: "hint", hoverStateEnabled: "hoverStateEnabled", iconPosition: "iconPosition", itemHoldTimeout: "itemHoldTimeout", items: "items", itemTemplate: "itemTemplate", keyExpr: "keyExpr", noDataText: "noDataText", orientation: "orientation", repaintChangesOnly: "repaintChangesOnly", rtlEnabled: "rtlEnabled", scrollByContent: "scrollByContent", scrollingEnabled: "scrollingEnabled", selectedIndex: "selectedIndex", selectedItem: "selectedItem", selectedItemKeys: "selectedItemKeys", selectedItems: "selectedItems", selectionMode: "selectionMode", showNavButtons: "showNavButtons", stylingMode: "stylingMode", tabIndex: "tabIndex", visible: "visible", width: "width" }, outputs: { onContentReady: "onContentReady", onDisposing: "onDisposing", onInitialized: "onInitialized", onItemClick: "onItemClick", onItemContextMenu: "onItemContextMenu", onItemHold: "onItemHold", onItemRendered: "onItemRendered", onOptionChanged: "onOptionChanged", onSelectionChanged: "onSelectionChanged", onSelectionChanging: "onSelectionChanging", accessKeyChange: "accessKeyChange", dataSourceChange: "dataSourceChange", disabledChange: "disabledChange", elementAttrChange: "elementAttrChange", focusStateEnabledChange: "focusStateEnabledChange", heightChange: "heightChange", hintChange: "hintChange", hoverStateEnabledChange: "hoverStateEnabledChange", iconPositionChange: "iconPositionChange", itemHoldTimeoutChange: "itemHoldTimeoutChange", itemsChange: "itemsChange", itemTemplateChange: "itemTemplateChange", keyExprChange: "keyExprChange", noDataTextChange: "noDataTextChange", orientationChange: "orientationChange", repaintChangesOnlyChange: "repaintChangesOnlyChange", rtlEnabledChange: "rtlEnabledChange", scrollByContentChange: "scrollByContentChange", scrollingEnabledChange: "scrollingEnabledChange", selectedIndexChange: "selectedIndexChange", selectedItemChange: "selectedItemChange", selectedItemKeysChange: "selectedItemKeysChange", selectedItemsChange: "selectedItemsChange", selectionModeChange: "selectionModeChange", showNavButtonsChange: "showNavButtonsChange", stylingModeChange: "stylingModeChange", tabIndexChange: "tabIndexChange", visibleChange: "visibleChange", widthChange: "widthChange" }, host: { attributes: { "ngSkipHydration": "true" } }, providers: [
            DxTemplateHost,
            WatcherHelper,
            NestedOptionHost,
            IterableDifferHelper
        ], queries: [{ propertyName: "_itemsContentChildren", predicate: PROPERTY_TOKEN_items }], usesInheritance: true, usesOnChanges: true, ngImport: i0, template: '', isInline: true, dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxTabsComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'dx-tabs',
                    template: '',
                    host: { ngSkipHydration: 'true' },
                    imports: [DxIntegrationModule],
                    providers: [
                        DxTemplateHost,
                        WatcherHelper,
                        NestedOptionHost,
                        IterableDifferHelper
                    ]
                }]
        }], ctorParameters: () => [{ type: i0.ElementRef }, { type: i0.NgZone }, { type: i1.DxTemplateHost }, { type: i1.WatcherHelper }, { type: i1.IterableDifferHelper }, { type: i1.NestedOptionHost }, { type: i0.TransferState }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [PLATFORM_ID]
                }] }], propDecorators: { _itemsContentChildren: [{
                type: ContentChildren,
                args: [PROPERTY_TOKEN_items]
            }], accessKey: [{
                type: Input
            }], dataSource: [{
                type: Input
            }], disabled: [{
                type: Input
            }], elementAttr: [{
                type: Input
            }], focusStateEnabled: [{
                type: Input
            }], height: [{
                type: Input
            }], hint: [{
                type: Input
            }], hoverStateEnabled: [{
                type: Input
            }], iconPosition: [{
                type: Input
            }], itemHoldTimeout: [{
                type: Input
            }], items: [{
                type: Input
            }], itemTemplate: [{
                type: Input
            }], keyExpr: [{
                type: Input
            }], noDataText: [{
                type: Input
            }], orientation: [{
                type: Input
            }], repaintChangesOnly: [{
                type: Input
            }], rtlEnabled: [{
                type: Input
            }], scrollByContent: [{
                type: Input
            }], scrollingEnabled: [{
                type: Input
            }], selectedIndex: [{
                type: Input
            }], selectedItem: [{
                type: Input
            }], selectedItemKeys: [{
                type: Input
            }], selectedItems: [{
                type: Input
            }], selectionMode: [{
                type: Input
            }], showNavButtons: [{
                type: Input
            }], stylingMode: [{
                type: Input
            }], tabIndex: [{
                type: Input
            }], visible: [{
                type: Input
            }], width: [{
                type: Input
            }], onContentReady: [{
                type: Output
            }], onDisposing: [{
                type: Output
            }], onInitialized: [{
                type: Output
            }], onItemClick: [{
                type: Output
            }], onItemContextMenu: [{
                type: Output
            }], onItemHold: [{
                type: Output
            }], onItemRendered: [{
                type: Output
            }], onOptionChanged: [{
                type: Output
            }], onSelectionChanged: [{
                type: Output
            }], onSelectionChanging: [{
                type: Output
            }], accessKeyChange: [{
                type: Output
            }], dataSourceChange: [{
                type: Output
            }], disabledChange: [{
                type: Output
            }], elementAttrChange: [{
                type: Output
            }], focusStateEnabledChange: [{
                type: Output
            }], heightChange: [{
                type: Output
            }], hintChange: [{
                type: Output
            }], hoverStateEnabledChange: [{
                type: Output
            }], iconPositionChange: [{
                type: Output
            }], itemHoldTimeoutChange: [{
                type: Output
            }], itemsChange: [{
                type: Output
            }], itemTemplateChange: [{
                type: Output
            }], keyExprChange: [{
                type: Output
            }], noDataTextChange: [{
                type: Output
            }], orientationChange: [{
                type: Output
            }], repaintChangesOnlyChange: [{
                type: Output
            }], rtlEnabledChange: [{
                type: Output
            }], scrollByContentChange: [{
                type: Output
            }], scrollingEnabledChange: [{
                type: Output
            }], selectedIndexChange: [{
                type: Output
            }], selectedItemChange: [{
                type: Output
            }], selectedItemKeysChange: [{
                type: Output
            }], selectedItemsChange: [{
                type: Output
            }], selectionModeChange: [{
                type: Output
            }], showNavButtonsChange: [{
                type: Output
            }], stylingModeChange: [{
                type: Output
            }], tabIndexChange: [{
                type: Output
            }], visibleChange: [{
                type: Output
            }], widthChange: [{
                type: Output
            }] } });
class DxTabsModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxTabsModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxTabsModule, imports: [DxTabsComponent, DxiItemModule,
            DxiTabsItemModule,
            DxIntegrationModule,
            DxTemplateModule], exports: [DxTabsComponent, DxiItemModule,
            DxiTabsItemModule,
            DxTemplateModule] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxTabsModule, imports: [DxTabsComponent,
            DxiItemModule,
            DxiTabsItemModule,
            DxIntegrationModule,
            DxTemplateModule, DxiItemModule,
            DxiTabsItemModule,
            DxTemplateModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxTabsModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxTabsComponent,
                        DxiItemModule,
                        DxiTabsItemModule,
                        DxIntegrationModule,
                        DxTemplateModule
                    ],
                    exports: [
                        DxTabsComponent,
                        DxiItemModule,
                        DxiTabsItemModule,
                        DxTemplateModule
                    ]
                }]
        }] });

/**
 * Generated bundle index. Do not edit.
 */

export { DxTabsComponent, DxTabsModule };
//# sourceMappingURL=devextreme-angular-ui-tabs.mjs.map
