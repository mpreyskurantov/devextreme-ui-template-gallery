import * as i0 from '@angular/core';
import { PLATFORM_ID, Output, Input, ContentChildren, Inject, Component, NgModule } from '@angular/core';
import DxTreeView from 'devextreme/ui/tree_view';
import * as i1 from 'devextreme-angular/core';
import { DxComponent, DxIntegrationModule, DxTemplateHost, WatcherHelper, NestedOptionHost, IterableDifferHelper, DxTemplateModule } from 'devextreme-angular/core';
import { DxiItemModule, DxoSearchEditorOptionsModule, DxiButtonModule, DxoOptionsModule } from 'devextreme-angular/ui/nested';
import { DxiTreeViewButtonModule, DxiTreeViewItemModule, DxoTreeViewOptionsModule, DxoTreeViewSearchEditorOptionsModule } from 'devextreme-angular/ui/tree-view/nested';
export * from 'devextreme-angular/ui/tree-view/nested';
import { PROPERTY_TOKEN_buttons, PROPERTY_TOKEN_items } from 'devextreme-angular/core/tokens';

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
/**
 * [descr:dxTreeView]

 */
class DxTreeViewComponent extends DxComponent {
    set _buttonsContentChildren(value) {
        this.setChildren('buttons', value);
    }
    set _itemsContentChildren(value) {
        this.setChildren('items', value);
    }
    /**
     * [descr:WidgetOptions.accessKey]
    
     */
    get accessKey() {
        return this._getOption('accessKey');
    }
    set accessKey(value) {
        this._setOption('accessKey', value);
    }
    /**
     * [descr:WidgetOptions.activeStateEnabled]
    
     */
    get activeStateEnabled() {
        return this._getOption('activeStateEnabled');
    }
    set activeStateEnabled(value) {
        this._setOption('activeStateEnabled', value);
    }
    /**
     * [descr:dxTreeViewOptions.animationEnabled]
    
     */
    get animationEnabled() {
        return this._getOption('animationEnabled');
    }
    set animationEnabled(value) {
        this._setOption('animationEnabled', value);
    }
    /**
     * [descr:dxTreeViewOptions.collapseIcon]
    
     */
    get collapseIcon() {
        return this._getOption('collapseIcon');
    }
    set collapseIcon(value) {
        this._setOption('collapseIcon', value);
    }
    /**
     * [descr:dxTreeViewOptions.createChildren]
    
     */
    get createChildren() {
        return this._getOption('createChildren');
    }
    set createChildren(value) {
        this._setOption('createChildren', value);
    }
    /**
     * [descr:dxTreeViewOptions.dataSource]
    
     */
    get dataSource() {
        return this._getOption('dataSource');
    }
    set dataSource(value) {
        this._setOption('dataSource', value);
    }
    /**
     * [descr:dxTreeViewOptions.dataStructure]
    
     */
    get dataStructure() {
        return this._getOption('dataStructure');
    }
    set dataStructure(value) {
        this._setOption('dataStructure', value);
    }
    /**
     * [descr:WidgetOptions.disabled]
    
     */
    get disabled() {
        return this._getOption('disabled');
    }
    set disabled(value) {
        this._setOption('disabled', value);
    }
    /**
     * [descr:HierarchicalCollectionWidgetOptions.disabledExpr]
    
     */
    get disabledExpr() {
        return this._getOption('disabledExpr');
    }
    set disabledExpr(value) {
        this._setOption('disabledExpr', value);
    }
    /**
     * [descr:dxTreeViewOptions.disabledNodeSelectionMode]
    
     */
    get disabledNodeSelectionMode() {
        return this._getOption('disabledNodeSelectionMode');
    }
    set disabledNodeSelectionMode(value) {
        this._setOption('disabledNodeSelectionMode', value);
    }
    /**
     * [descr:HierarchicalCollectionWidgetOptions.displayExpr]
    
     */
    get displayExpr() {
        return this._getOption('displayExpr');
    }
    set displayExpr(value) {
        this._setOption('displayExpr', value);
    }
    /**
     * [descr:DOMComponentOptions.elementAttr]
    
     */
    get elementAttr() {
        return this._getOption('elementAttr');
    }
    set elementAttr(value) {
        this._setOption('elementAttr', value);
    }
    /**
     * [descr:dxTreeViewOptions.expandAllEnabled]
    
     */
    get expandAllEnabled() {
        return this._getOption('expandAllEnabled');
    }
    set expandAllEnabled(value) {
        this._setOption('expandAllEnabled', value);
    }
    /**
     * [descr:dxTreeViewOptions.expandedExpr]
    
     */
    get expandedExpr() {
        return this._getOption('expandedExpr');
    }
    set expandedExpr(value) {
        this._setOption('expandedExpr', value);
    }
    /**
     * [descr:dxTreeViewOptions.expandEvent]
    
     */
    get expandEvent() {
        return this._getOption('expandEvent');
    }
    set expandEvent(value) {
        this._setOption('expandEvent', value);
    }
    /**
     * [descr:dxTreeViewOptions.expandIcon]
    
     */
    get expandIcon() {
        return this._getOption('expandIcon');
    }
    set expandIcon(value) {
        this._setOption('expandIcon', value);
    }
    /**
     * [descr:dxTreeViewOptions.expandNodesRecursive]
    
     */
    get expandNodesRecursive() {
        return this._getOption('expandNodesRecursive');
    }
    set expandNodesRecursive(value) {
        this._setOption('expandNodesRecursive', value);
    }
    /**
     * [descr:HierarchicalCollectionWidgetOptions.focusStateEnabled]
    
     */
    get focusStateEnabled() {
        return this._getOption('focusStateEnabled');
    }
    set focusStateEnabled(value) {
        this._setOption('focusStateEnabled', value);
    }
    /**
     * [descr:dxTreeViewOptions.hasItemsExpr]
    
     */
    get hasItemsExpr() {
        return this._getOption('hasItemsExpr');
    }
    set hasItemsExpr(value) {
        this._setOption('hasItemsExpr', value);
    }
    /**
     * [descr:DOMComponentOptions.height]
    
     */
    get height() {
        return this._getOption('height');
    }
    set height(value) {
        this._setOption('height', value);
    }
    /**
     * [descr:WidgetOptions.hint]
    
     */
    get hint() {
        return this._getOption('hint');
    }
    set hint(value) {
        this._setOption('hint', value);
    }
    /**
     * [descr:HierarchicalCollectionWidgetOptions.hoverStateEnabled]
    
     */
    get hoverStateEnabled() {
        return this._getOption('hoverStateEnabled');
    }
    set hoverStateEnabled(value) {
        this._setOption('hoverStateEnabled', value);
    }
    /**
     * [descr:CollectionWidgetOptions.itemHoldTimeout]
    
     */
    get itemHoldTimeout() {
        return this._getOption('itemHoldTimeout');
    }
    set itemHoldTimeout(value) {
        this._setOption('itemHoldTimeout', value);
    }
    /**
     * [descr:dxTreeViewOptions.items]
    
     */
    get items() {
        return this._getOption('items');
    }
    set items(value) {
        this._setOption('items', value);
    }
    /**
     * [descr:HierarchicalCollectionWidgetOptions.itemsExpr]
    
     */
    get itemsExpr() {
        return this._getOption('itemsExpr');
    }
    set itemsExpr(value) {
        this._setOption('itemsExpr', value);
    }
    /**
     * [descr:CollectionWidgetOptions.itemTemplate]
    
     */
    get itemTemplate() {
        return this._getOption('itemTemplate');
    }
    set itemTemplate(value) {
        this._setOption('itemTemplate', value);
    }
    /**
     * [descr:HierarchicalCollectionWidgetOptions.keyExpr]
    
     */
    get keyExpr() {
        return this._getOption('keyExpr');
    }
    set keyExpr(value) {
        this._setOption('keyExpr', value);
    }
    /**
     * [descr:CollectionWidgetOptions.noDataText]
    
     */
    get noDataText() {
        return this._getOption('noDataText');
    }
    set noDataText(value) {
        this._setOption('noDataText', value);
    }
    /**
     * [descr:dxTreeViewOptions.parentIdExpr]
    
     */
    get parentIdExpr() {
        return this._getOption('parentIdExpr');
    }
    set parentIdExpr(value) {
        this._setOption('parentIdExpr', value);
    }
    /**
     * [descr:dxTreeViewOptions.rootValue]
    
     */
    get rootValue() {
        return this._getOption('rootValue');
    }
    set rootValue(value) {
        this._setOption('rootValue', value);
    }
    /**
     * [descr:DOMComponentOptions.rtlEnabled]
    
     */
    get rtlEnabled() {
        return this._getOption('rtlEnabled');
    }
    set rtlEnabled(value) {
        this._setOption('rtlEnabled', value);
    }
    /**
     * [descr:dxTreeViewOptions.scrollDirection]
    
     */
    get scrollDirection() {
        return this._getOption('scrollDirection');
    }
    set scrollDirection(value) {
        this._setOption('scrollDirection', value);
    }
    /**
     * [descr:SearchBoxMixinOptions.searchEditorOptions]
    
     */
    get searchEditorOptions() {
        return this._getOption('searchEditorOptions');
    }
    set searchEditorOptions(value) {
        this._setOption('searchEditorOptions', value);
    }
    /**
     * [descr:SearchBoxMixinOptions.searchEnabled]
    
     */
    get searchEnabled() {
        return this._getOption('searchEnabled');
    }
    set searchEnabled(value) {
        this._setOption('searchEnabled', value);
    }
    /**
     * [descr:SearchBoxMixinOptions.searchExpr]
    
     */
    get searchExpr() {
        return this._getOption('searchExpr');
    }
    set searchExpr(value) {
        this._setOption('searchExpr', value);
    }
    /**
     * [descr:SearchBoxMixinOptions.searchMode]
    
     */
    get searchMode() {
        return this._getOption('searchMode');
    }
    set searchMode(value) {
        this._setOption('searchMode', value);
    }
    /**
     * [descr:SearchBoxMixinOptions.searchTimeout]
    
     */
    get searchTimeout() {
        return this._getOption('searchTimeout');
    }
    set searchTimeout(value) {
        this._setOption('searchTimeout', value);
    }
    /**
     * [descr:SearchBoxMixinOptions.searchValue]
    
     */
    get searchValue() {
        return this._getOption('searchValue');
    }
    set searchValue(value) {
        this._setOption('searchValue', value);
    }
    /**
     * [descr:dxTreeViewOptions.selectAllText]
    
     */
    get selectAllText() {
        return this._getOption('selectAllText');
    }
    set selectAllText(value) {
        this._setOption('selectAllText', value);
    }
    /**
     * [descr:dxTreeViewOptions.selectByClick]
    
     */
    get selectByClick() {
        return this._getOption('selectByClick');
    }
    set selectByClick(value) {
        this._setOption('selectByClick', value);
    }
    /**
     * [descr:HierarchicalCollectionWidgetOptions.selectedExpr]
    
     */
    get selectedExpr() {
        return this._getOption('selectedExpr');
    }
    set selectedExpr(value) {
        this._setOption('selectedExpr', value);
    }
    /**
     * [descr:dxTreeViewOptions.selectionMode]
    
     */
    get selectionMode() {
        return this._getOption('selectionMode');
    }
    set selectionMode(value) {
        this._setOption('selectionMode', value);
    }
    /**
     * [descr:dxTreeViewOptions.selectNodesRecursive]
    
     */
    get selectNodesRecursive() {
        return this._getOption('selectNodesRecursive');
    }
    set selectNodesRecursive(value) {
        this._setOption('selectNodesRecursive', value);
    }
    /**
     * [descr:dxTreeViewOptions.showCheckBoxesMode]
    
     */
    get showCheckBoxesMode() {
        return this._getOption('showCheckBoxesMode');
    }
    set showCheckBoxesMode(value) {
        this._setOption('showCheckBoxesMode', value);
    }
    /**
     * [descr:WidgetOptions.tabIndex]
    
     */
    get tabIndex() {
        return this._getOption('tabIndex');
    }
    set tabIndex(value) {
        this._setOption('tabIndex', value);
    }
    /**
     * [descr:dxTreeViewOptions.useNativeScrolling]
    
     */
    get useNativeScrolling() {
        return this._getOption('useNativeScrolling');
    }
    set useNativeScrolling(value) {
        this._setOption('useNativeScrolling', value);
    }
    /**
     * [descr:dxTreeViewOptions.virtualModeEnabled]
    
     */
    get virtualModeEnabled() {
        return this._getOption('virtualModeEnabled');
    }
    set virtualModeEnabled(value) {
        this._setOption('virtualModeEnabled', value);
    }
    /**
     * [descr:WidgetOptions.visible]
    
     */
    get visible() {
        return this._getOption('visible');
    }
    set visible(value) {
        this._setOption('visible', value);
    }
    /**
     * [descr:DOMComponentOptions.width]
    
     */
    get width() {
        return this._getOption('width');
    }
    set width(value) {
        this._setOption('width', value);
    }
    constructor(elementRef, ngZone, templateHost, _watcherHelper, _idh, optionHost, transferState, platformId) {
        super(elementRef, ngZone, templateHost, _watcherHelper, transferState, platformId);
        this._watcherHelper = _watcherHelper;
        this._idh = _idh;
        this.instance = null;
        this._createEventEmitters([
            { subscribe: 'contentReady', emit: 'onContentReady' },
            { subscribe: 'disposing', emit: 'onDisposing' },
            { subscribe: 'initialized', emit: 'onInitialized' },
            { subscribe: 'itemClick', emit: 'onItemClick' },
            { subscribe: 'itemCollapsed', emit: 'onItemCollapsed' },
            { subscribe: 'itemContextMenu', emit: 'onItemContextMenu' },
            { subscribe: 'itemExpanded', emit: 'onItemExpanded' },
            { subscribe: 'itemHold', emit: 'onItemHold' },
            { subscribe: 'itemRendered', emit: 'onItemRendered' },
            { subscribe: 'itemSelectionChanged', emit: 'onItemSelectionChanged' },
            { subscribe: 'optionChanged', emit: 'onOptionChanged' },
            { subscribe: 'selectAllValueChanged', emit: 'onSelectAllValueChanged' },
            { subscribe: 'selectionChanged', emit: 'onSelectionChanged' },
            { emit: 'accessKeyChange' },
            { emit: 'activeStateEnabledChange' },
            { emit: 'animationEnabledChange' },
            { emit: 'collapseIconChange' },
            { emit: 'createChildrenChange' },
            { emit: 'dataSourceChange' },
            { emit: 'dataStructureChange' },
            { emit: 'disabledChange' },
            { emit: 'disabledExprChange' },
            { emit: 'disabledNodeSelectionModeChange' },
            { emit: 'displayExprChange' },
            { emit: 'elementAttrChange' },
            { emit: 'expandAllEnabledChange' },
            { emit: 'expandedExprChange' },
            { emit: 'expandEventChange' },
            { emit: 'expandIconChange' },
            { emit: 'expandNodesRecursiveChange' },
            { emit: 'focusStateEnabledChange' },
            { emit: 'hasItemsExprChange' },
            { emit: 'heightChange' },
            { emit: 'hintChange' },
            { emit: 'hoverStateEnabledChange' },
            { emit: 'itemHoldTimeoutChange' },
            { emit: 'itemsChange' },
            { emit: 'itemsExprChange' },
            { emit: 'itemTemplateChange' },
            { emit: 'keyExprChange' },
            { emit: 'noDataTextChange' },
            { emit: 'parentIdExprChange' },
            { emit: 'rootValueChange' },
            { emit: 'rtlEnabledChange' },
            { emit: 'scrollDirectionChange' },
            { emit: 'searchEditorOptionsChange' },
            { emit: 'searchEnabledChange' },
            { emit: 'searchExprChange' },
            { emit: 'searchModeChange' },
            { emit: 'searchTimeoutChange' },
            { emit: 'searchValueChange' },
            { emit: 'selectAllTextChange' },
            { emit: 'selectByClickChange' },
            { emit: 'selectedExprChange' },
            { emit: 'selectionModeChange' },
            { emit: 'selectNodesRecursiveChange' },
            { emit: 'showCheckBoxesModeChange' },
            { emit: 'tabIndexChange' },
            { emit: 'useNativeScrollingChange' },
            { emit: 'virtualModeEnabledChange' },
            { emit: 'visibleChange' },
            { emit: 'widthChange' }
        ]);
        this._idh.setHost(this);
        optionHost.setHost(this);
    }
    _createInstance(element, options) {
        return new DxTreeView(element, options);
    }
    ngOnDestroy() {
        this._destroyWidget();
    }
    ngOnChanges(changes) {
        super.ngOnChanges(changes);
        this.setupChanges('dataSource', changes);
        this.setupChanges('items', changes);
        this.setupChanges('searchExpr', changes);
    }
    setupChanges(prop, changes) {
        if (!(prop in this._optionsToUpdate)) {
            this._idh.setup(prop, changes);
        }
    }
    ngDoCheck() {
        this._idh.doCheck('dataSource');
        this._idh.doCheck('items');
        this._idh.doCheck('searchExpr');
        this._watcherHelper.checkWatchers();
        super.ngDoCheck();
        super.clearChangedOptions();
    }
    _setOption(name, value) {
        let isSetup = this._idh.setupSingle(name, value);
        let isChanged = this._idh.getChanges(name, value) !== null;
        if (isSetup || isChanged) {
            super._setOption(name, value);
        }
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxTreeViewComponent, deps: [{ token: i0.ElementRef }, { token: i0.NgZone }, { token: i1.DxTemplateHost }, { token: i1.WatcherHelper }, { token: i1.IterableDifferHelper }, { token: i1.NestedOptionHost }, { token: i0.TransferState }, { token: PLATFORM_ID }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxTreeViewComponent, isStandalone: true, selector: "dx-tree-view", inputs: { accessKey: "accessKey", activeStateEnabled: "activeStateEnabled", animationEnabled: "animationEnabled", collapseIcon: "collapseIcon", createChildren: "createChildren", dataSource: "dataSource", dataStructure: "dataStructure", disabled: "disabled", disabledExpr: "disabledExpr", disabledNodeSelectionMode: "disabledNodeSelectionMode", displayExpr: "displayExpr", elementAttr: "elementAttr", expandAllEnabled: "expandAllEnabled", expandedExpr: "expandedExpr", expandEvent: "expandEvent", expandIcon: "expandIcon", expandNodesRecursive: "expandNodesRecursive", focusStateEnabled: "focusStateEnabled", hasItemsExpr: "hasItemsExpr", height: "height", hint: "hint", hoverStateEnabled: "hoverStateEnabled", itemHoldTimeout: "itemHoldTimeout", items: "items", itemsExpr: "itemsExpr", itemTemplate: "itemTemplate", keyExpr: "keyExpr", noDataText: "noDataText", parentIdExpr: "parentIdExpr", rootValue: "rootValue", rtlEnabled: "rtlEnabled", scrollDirection: "scrollDirection", searchEditorOptions: "searchEditorOptions", searchEnabled: "searchEnabled", searchExpr: "searchExpr", searchMode: "searchMode", searchTimeout: "searchTimeout", searchValue: "searchValue", selectAllText: "selectAllText", selectByClick: "selectByClick", selectedExpr: "selectedExpr", selectionMode: "selectionMode", selectNodesRecursive: "selectNodesRecursive", showCheckBoxesMode: "showCheckBoxesMode", tabIndex: "tabIndex", useNativeScrolling: "useNativeScrolling", virtualModeEnabled: "virtualModeEnabled", visible: "visible", width: "width" }, outputs: { onContentReady: "onContentReady", onDisposing: "onDisposing", onInitialized: "onInitialized", onItemClick: "onItemClick", onItemCollapsed: "onItemCollapsed", onItemContextMenu: "onItemContextMenu", onItemExpanded: "onItemExpanded", onItemHold: "onItemHold", onItemRendered: "onItemRendered", onItemSelectionChanged: "onItemSelectionChanged", onOptionChanged: "onOptionChanged", onSelectAllValueChanged: "onSelectAllValueChanged", onSelectionChanged: "onSelectionChanged", accessKeyChange: "accessKeyChange", activeStateEnabledChange: "activeStateEnabledChange", animationEnabledChange: "animationEnabledChange", collapseIconChange: "collapseIconChange", createChildrenChange: "createChildrenChange", dataSourceChange: "dataSourceChange", dataStructureChange: "dataStructureChange", disabledChange: "disabledChange", disabledExprChange: "disabledExprChange", disabledNodeSelectionModeChange: "disabledNodeSelectionModeChange", displayExprChange: "displayExprChange", elementAttrChange: "elementAttrChange", expandAllEnabledChange: "expandAllEnabledChange", expandedExprChange: "expandedExprChange", expandEventChange: "expandEventChange", expandIconChange: "expandIconChange", expandNodesRecursiveChange: "expandNodesRecursiveChange", focusStateEnabledChange: "focusStateEnabledChange", hasItemsExprChange: "hasItemsExprChange", heightChange: "heightChange", hintChange: "hintChange", hoverStateEnabledChange: "hoverStateEnabledChange", itemHoldTimeoutChange: "itemHoldTimeoutChange", itemsChange: "itemsChange", itemsExprChange: "itemsExprChange", itemTemplateChange: "itemTemplateChange", keyExprChange: "keyExprChange", noDataTextChange: "noDataTextChange", parentIdExprChange: "parentIdExprChange", rootValueChange: "rootValueChange", rtlEnabledChange: "rtlEnabledChange", scrollDirectionChange: "scrollDirectionChange", searchEditorOptionsChange: "searchEditorOptionsChange", searchEnabledChange: "searchEnabledChange", searchExprChange: "searchExprChange", searchModeChange: "searchModeChange", searchTimeoutChange: "searchTimeoutChange", searchValueChange: "searchValueChange", selectAllTextChange: "selectAllTextChange", selectByClickChange: "selectByClickChange", selectedExprChange: "selectedExprChange", selectionModeChange: "selectionModeChange", selectNodesRecursiveChange: "selectNodesRecursiveChange", showCheckBoxesModeChange: "showCheckBoxesModeChange", tabIndexChange: "tabIndexChange", useNativeScrollingChange: "useNativeScrollingChange", virtualModeEnabledChange: "virtualModeEnabledChange", visibleChange: "visibleChange", widthChange: "widthChange" }, host: { attributes: { "ngSkipHydration": "true" } }, providers: [
            DxTemplateHost,
            WatcherHelper,
            NestedOptionHost,
            IterableDifferHelper
        ], queries: [{ propertyName: "_buttonsContentChildren", predicate: PROPERTY_TOKEN_buttons }, { propertyName: "_itemsContentChildren", predicate: PROPERTY_TOKEN_items }], usesInheritance: true, usesOnChanges: true, ngImport: i0, template: '', isInline: true, dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxTreeViewComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'dx-tree-view',
                    template: '',
                    host: { ngSkipHydration: 'true' },
                    imports: [DxIntegrationModule],
                    providers: [
                        DxTemplateHost,
                        WatcherHelper,
                        NestedOptionHost,
                        IterableDifferHelper
                    ]
                }]
        }], ctorParameters: () => [{ type: i0.ElementRef }, { type: i0.NgZone }, { type: i1.DxTemplateHost }, { type: i1.WatcherHelper }, { type: i1.IterableDifferHelper }, { type: i1.NestedOptionHost }, { type: i0.TransferState }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [PLATFORM_ID]
                }] }], propDecorators: { _buttonsContentChildren: [{
                type: ContentChildren,
                args: [PROPERTY_TOKEN_buttons]
            }], _itemsContentChildren: [{
                type: ContentChildren,
                args: [PROPERTY_TOKEN_items]
            }], accessKey: [{
                type: Input
            }], activeStateEnabled: [{
                type: Input
            }], animationEnabled: [{
                type: Input
            }], collapseIcon: [{
                type: Input
            }], createChildren: [{
                type: Input
            }], dataSource: [{
                type: Input
            }], dataStructure: [{
                type: Input
            }], disabled: [{
                type: Input
            }], disabledExpr: [{
                type: Input
            }], disabledNodeSelectionMode: [{
                type: Input
            }], displayExpr: [{
                type: Input
            }], elementAttr: [{
                type: Input
            }], expandAllEnabled: [{
                type: Input
            }], expandedExpr: [{
                type: Input
            }], expandEvent: [{
                type: Input
            }], expandIcon: [{
                type: Input
            }], expandNodesRecursive: [{
                type: Input
            }], focusStateEnabled: [{
                type: Input
            }], hasItemsExpr: [{
                type: Input
            }], height: [{
                type: Input
            }], hint: [{
                type: Input
            }], hoverStateEnabled: [{
                type: Input
            }], itemHoldTimeout: [{
                type: Input
            }], items: [{
                type: Input
            }], itemsExpr: [{
                type: Input
            }], itemTemplate: [{
                type: Input
            }], keyExpr: [{
                type: Input
            }], noDataText: [{
                type: Input
            }], parentIdExpr: [{
                type: Input
            }], rootValue: [{
                type: Input
            }], rtlEnabled: [{
                type: Input
            }], scrollDirection: [{
                type: Input
            }], searchEditorOptions: [{
                type: Input
            }], searchEnabled: [{
                type: Input
            }], searchExpr: [{
                type: Input
            }], searchMode: [{
                type: Input
            }], searchTimeout: [{
                type: Input
            }], searchValue: [{
                type: Input
            }], selectAllText: [{
                type: Input
            }], selectByClick: [{
                type: Input
            }], selectedExpr: [{
                type: Input
            }], selectionMode: [{
                type: Input
            }], selectNodesRecursive: [{
                type: Input
            }], showCheckBoxesMode: [{
                type: Input
            }], tabIndex: [{
                type: Input
            }], useNativeScrolling: [{
                type: Input
            }], virtualModeEnabled: [{
                type: Input
            }], visible: [{
                type: Input
            }], width: [{
                type: Input
            }], onContentReady: [{
                type: Output
            }], onDisposing: [{
                type: Output
            }], onInitialized: [{
                type: Output
            }], onItemClick: [{
                type: Output
            }], onItemCollapsed: [{
                type: Output
            }], onItemContextMenu: [{
                type: Output
            }], onItemExpanded: [{
                type: Output
            }], onItemHold: [{
                type: Output
            }], onItemRendered: [{
                type: Output
            }], onItemSelectionChanged: [{
                type: Output
            }], onOptionChanged: [{
                type: Output
            }], onSelectAllValueChanged: [{
                type: Output
            }], onSelectionChanged: [{
                type: Output
            }], accessKeyChange: [{
                type: Output
            }], activeStateEnabledChange: [{
                type: Output
            }], animationEnabledChange: [{
                type: Output
            }], collapseIconChange: [{
                type: Output
            }], createChildrenChange: [{
                type: Output
            }], dataSourceChange: [{
                type: Output
            }], dataStructureChange: [{
                type: Output
            }], disabledChange: [{
                type: Output
            }], disabledExprChange: [{
                type: Output
            }], disabledNodeSelectionModeChange: [{
                type: Output
            }], displayExprChange: [{
                type: Output
            }], elementAttrChange: [{
                type: Output
            }], expandAllEnabledChange: [{
                type: Output
            }], expandedExprChange: [{
                type: Output
            }], expandEventChange: [{
                type: Output
            }], expandIconChange: [{
                type: Output
            }], expandNodesRecursiveChange: [{
                type: Output
            }], focusStateEnabledChange: [{
                type: Output
            }], hasItemsExprChange: [{
                type: Output
            }], heightChange: [{
                type: Output
            }], hintChange: [{
                type: Output
            }], hoverStateEnabledChange: [{
                type: Output
            }], itemHoldTimeoutChange: [{
                type: Output
            }], itemsChange: [{
                type: Output
            }], itemsExprChange: [{
                type: Output
            }], itemTemplateChange: [{
                type: Output
            }], keyExprChange: [{
                type: Output
            }], noDataTextChange: [{
                type: Output
            }], parentIdExprChange: [{
                type: Output
            }], rootValueChange: [{
                type: Output
            }], rtlEnabledChange: [{
                type: Output
            }], scrollDirectionChange: [{
                type: Output
            }], searchEditorOptionsChange: [{
                type: Output
            }], searchEnabledChange: [{
                type: Output
            }], searchExprChange: [{
                type: Output
            }], searchModeChange: [{
                type: Output
            }], searchTimeoutChange: [{
                type: Output
            }], searchValueChange: [{
                type: Output
            }], selectAllTextChange: [{
                type: Output
            }], selectByClickChange: [{
                type: Output
            }], selectedExprChange: [{
                type: Output
            }], selectionModeChange: [{
                type: Output
            }], selectNodesRecursiveChange: [{
                type: Output
            }], showCheckBoxesModeChange: [{
                type: Output
            }], tabIndexChange: [{
                type: Output
            }], useNativeScrollingChange: [{
                type: Output
            }], virtualModeEnabledChange: [{
                type: Output
            }], visibleChange: [{
                type: Output
            }], widthChange: [{
                type: Output
            }] } });
class DxTreeViewModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxTreeViewModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxTreeViewModule, imports: [DxTreeViewComponent, DxiItemModule,
            DxoSearchEditorOptionsModule,
            DxiButtonModule,
            DxoOptionsModule,
            DxiTreeViewButtonModule,
            DxiTreeViewItemModule,
            DxoTreeViewOptionsModule,
            DxoTreeViewSearchEditorOptionsModule,
            DxIntegrationModule,
            DxTemplateModule], exports: [DxTreeViewComponent, DxiItemModule,
            DxoSearchEditorOptionsModule,
            DxiButtonModule,
            DxoOptionsModule,
            DxiTreeViewButtonModule,
            DxiTreeViewItemModule,
            DxoTreeViewOptionsModule,
            DxoTreeViewSearchEditorOptionsModule,
            DxTemplateModule] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxTreeViewModule, imports: [DxTreeViewComponent,
            DxiItemModule,
            DxoSearchEditorOptionsModule,
            DxiButtonModule,
            DxoOptionsModule,
            DxiTreeViewButtonModule,
            DxiTreeViewItemModule,
            DxoTreeViewOptionsModule,
            DxoTreeViewSearchEditorOptionsModule,
            DxIntegrationModule,
            DxTemplateModule, DxiItemModule,
            DxoSearchEditorOptionsModule,
            DxiButtonModule,
            DxoOptionsModule,
            DxiTreeViewButtonModule,
            DxiTreeViewItemModule,
            DxoTreeViewOptionsModule,
            DxoTreeViewSearchEditorOptionsModule,
            DxTemplateModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxTreeViewModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxTreeViewComponent,
                        DxiItemModule,
                        DxoSearchEditorOptionsModule,
                        DxiButtonModule,
                        DxoOptionsModule,
                        DxiTreeViewButtonModule,
                        DxiTreeViewItemModule,
                        DxoTreeViewOptionsModule,
                        DxoTreeViewSearchEditorOptionsModule,
                        DxIntegrationModule,
                        DxTemplateModule
                    ],
                    exports: [
                        DxTreeViewComponent,
                        DxiItemModule,
                        DxoSearchEditorOptionsModule,
                        DxiButtonModule,
                        DxoOptionsModule,
                        DxiTreeViewButtonModule,
                        DxiTreeViewItemModule,
                        DxoTreeViewOptionsModule,
                        DxoTreeViewSearchEditorOptionsModule,
                        DxTemplateModule
                    ]
                }]
        }] });

/**
 * Generated bundle index. Do not edit.
 */

export { DxTreeViewComponent, DxTreeViewModule };
//# sourceMappingURL=devextreme-angular-ui-tree-view.mjs.map
