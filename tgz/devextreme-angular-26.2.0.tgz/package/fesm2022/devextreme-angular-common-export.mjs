import { exportDataGrid, exportPivotGrid } from 'devextreme/common/export/excel';
import { exportDataGrid as exportDataGrid$1, exportGantt } from 'devextreme/common/export/pdf';

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

var index$1 = /*#__PURE__*/Object.freeze({
	__proto__: null,
	exportDataGrid: exportDataGrid,
	exportPivotGrid: exportPivotGrid
});

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

var index = /*#__PURE__*/Object.freeze({
	__proto__: null,
	exportDataGrid: exportDataGrid$1,
	exportGantt: exportGantt
});

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

/**
 * Generated bundle index. Do not edit.
 */

export { index$1 as Excel, index as Pdf };
//# sourceMappingURL=devextreme-angular-common-export.mjs.map
