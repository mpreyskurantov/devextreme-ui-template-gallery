import * as i0 from '@angular/core';
import { PLATFORM_ID, Output, Input, ContentChildren, Inject, Component, NgModule } from '@angular/core';
import DxScheduler from 'devextreme/ui/scheduler';
import * as i1 from 'devextreme-angular/core';
import { DxComponent, DxIntegrationModule, DxTemplateHost, WatcherHelper, NestedOptionHost, IterableDifferHelper, DxTemplateModule } from 'devextreme-angular/core';
import { DxoAppointmentDraggingModule, DxoEditingModule, DxiResourceModule, DxoScrollingModule, DxiViewModule } from 'devextreme-angular/ui/nested';
import { DxoSchedulerAIOptionsModule, DxoSchedulerAppointmentDraggingModule, DxiSchedulerAsyncRuleModule, DxiSchedulerButtonItemModule, DxoSchedulerButtonOptionsModule, DxoSchedulerColCountByScreenModule, DxiSchedulerCompareRuleModule, DxiSchedulerCustomRuleModule, DxoSchedulerEditingModule, DxiSchedulerEmailRuleModule, DxiSchedulerEmptyItemModule, DxoSchedulerFormModule, DxiSchedulerGroupItemModule, DxiSchedulerItemModule, DxoSchedulerLabelModule, DxiSchedulerNumericRuleModule, DxoSchedulerOptionsModule, DxiSchedulerOptionsItemModule, DxiSchedulerPatternRuleModule, DxiSchedulerRangeRuleModule, DxiSchedulerRequiredRuleModule, DxiSchedulerResourceModule, DxoSchedulerScrollingModule, DxiSchedulerSimpleItemModule, DxiSchedulerStringLengthRuleModule, DxiSchedulerTabModule, DxiSchedulerTabbedItemModule, DxoSchedulerTabPanelOptionsModule, DxiSchedulerTabPanelOptionsItemModule, DxoSchedulerToolbarModule, DxiSchedulerToolbarItemModule, DxiSchedulerValidationRuleModule, DxiSchedulerViewModule } from 'devextreme-angular/ui/scheduler/nested';
export * from 'devextreme-angular/ui/scheduler/nested';
import { PROPERTY_TOKEN_validationRules, PROPERTY_TOKEN_items, PROPERTY_TOKEN_resources, PROPERTY_TOKEN_tabs, PROPERTY_TOKEN_views } from 'devextreme-angular/core/tokens';

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
/**
 * [descr:dxScheduler]

 */
class DxSchedulerComponent extends DxComponent {
    set _validationRulesContentChildren(value) {
        this.setChildren('validationRules', value);
    }
    set _itemsContentChildren(value) {
        this.setChildren('items', value);
    }
    set _resourcesContentChildren(value) {
        this.setChildren('resources', value);
    }
    set _tabsContentChildren(value) {
        this.setChildren('tabs', value);
    }
    set _viewsContentChildren(value) {
        this.setChildren('views', value);
    }
    /**
     * [descr:WidgetOptions.accessKey]
    
     */
    get accessKey() {
        return this._getOption('accessKey');
    }
    set accessKey(value) {
        this._setOption('accessKey', value);
    }
    /**
     * [descr:dxSchedulerOptions.adaptivityEnabled]
    
     */
    get adaptivityEnabled() {
        return this._getOption('adaptivityEnabled');
    }
    set adaptivityEnabled(value) {
        this._setOption('adaptivityEnabled', value);
    }
    /**
     * [descr:dxSchedulerOptions.allDayExpr]
    
     */
    get allDayExpr() {
        return this._getOption('allDayExpr');
    }
    set allDayExpr(value) {
        this._setOption('allDayExpr', value);
    }
    /**
     * [descr:dxSchedulerOptions.allDayPanelMode]
    
     */
    get allDayPanelMode() {
        return this._getOption('allDayPanelMode');
    }
    set allDayPanelMode(value) {
        this._setOption('allDayPanelMode', value);
    }
    /**
     * [descr:dxSchedulerOptions.appointmentCollectorTemplate]
    
     */
    get appointmentCollectorTemplate() {
        return this._getOption('appointmentCollectorTemplate');
    }
    set appointmentCollectorTemplate(value) {
        this._setOption('appointmentCollectorTemplate', value);
    }
    /**
     * [descr:dxSchedulerOptions.appointmentDragging]
    
     */
    get appointmentDragging() {
        return this._getOption('appointmentDragging');
    }
    set appointmentDragging(value) {
        this._setOption('appointmentDragging', value);
    }
    /**
     * [descr:dxSchedulerOptions.appointmentTemplate]
    
     */
    get appointmentTemplate() {
        return this._getOption('appointmentTemplate');
    }
    set appointmentTemplate(value) {
        this._setOption('appointmentTemplate', value);
    }
    /**
     * [descr:dxSchedulerOptions.appointmentTooltipTemplate]
    
     */
    get appointmentTooltipTemplate() {
        return this._getOption('appointmentTooltipTemplate');
    }
    set appointmentTooltipTemplate(value) {
        this._setOption('appointmentTooltipTemplate', value);
    }
    /**
     * [descr:dxSchedulerOptions.cellDuration]
    
     */
    get cellDuration() {
        return this._getOption('cellDuration');
    }
    set cellDuration(value) {
        this._setOption('cellDuration', value);
    }
    /**
     * [descr:dxSchedulerOptions.crossScrollingEnabled]
    
     */
    get crossScrollingEnabled() {
        return this._getOption('crossScrollingEnabled');
    }
    set crossScrollingEnabled(value) {
        this._setOption('crossScrollingEnabled', value);
    }
    /**
     * [descr:dxSchedulerOptions.currentDate]
    
     */
    get currentDate() {
        return this._getOption('currentDate');
    }
    set currentDate(value) {
        this._setOption('currentDate', value);
    }
    /**
     * [descr:dxSchedulerOptions.currentView]
    
     */
    get currentView() {
        return this._getOption('currentView');
    }
    set currentView(value) {
        this._setOption('currentView', value);
    }
    /**
     * [descr:dxSchedulerOptions.customizeDateNavigatorText]
    
     */
    get customizeDateNavigatorText() {
        return this._getOption('customizeDateNavigatorText');
    }
    set customizeDateNavigatorText(value) {
        this._setOption('customizeDateNavigatorText', value);
    }
    /**
     * [descr:dxSchedulerOptions.dataCellTemplate]
    
     */
    get dataCellTemplate() {
        return this._getOption('dataCellTemplate');
    }
    set dataCellTemplate(value) {
        this._setOption('dataCellTemplate', value);
    }
    /**
     * [descr:dxSchedulerOptions.dataSource]
    
     */
    get dataSource() {
        return this._getOption('dataSource');
    }
    set dataSource(value) {
        this._setOption('dataSource', value);
    }
    /**
     * [descr:dxSchedulerOptions.dateCellTemplate]
    
     */
    get dateCellTemplate() {
        return this._getOption('dateCellTemplate');
    }
    set dateCellTemplate(value) {
        this._setOption('dateCellTemplate', value);
    }
    /**
     * [descr:dxSchedulerOptions.dateSerializationFormat]
    
     */
    get dateSerializationFormat() {
        return this._getOption('dateSerializationFormat');
    }
    set dateSerializationFormat(value) {
        this._setOption('dateSerializationFormat', value);
    }
    /**
     * [descr:dxSchedulerOptions.descriptionExpr]
    
     */
    get descriptionExpr() {
        return this._getOption('descriptionExpr');
    }
    set descriptionExpr(value) {
        this._setOption('descriptionExpr', value);
    }
    /**
     * [descr:WidgetOptions.disabled]
    
     */
    get disabled() {
        return this._getOption('disabled');
    }
    set disabled(value) {
        this._setOption('disabled', value);
    }
    /**
     * [descr:dxSchedulerOptions.editing]
    
     */
    get editing() {
        return this._getOption('editing');
    }
    set editing(value) {
        this._setOption('editing', value);
    }
    /**
     * [descr:DOMComponentOptions.elementAttr]
    
     */
    get elementAttr() {
        return this._getOption('elementAttr');
    }
    set elementAttr(value) {
        this._setOption('elementAttr', value);
    }
    /**
     * [descr:dxSchedulerOptions.endDateExpr]
    
     */
    get endDateExpr() {
        return this._getOption('endDateExpr');
    }
    set endDateExpr(value) {
        this._setOption('endDateExpr', value);
    }
    /**
     * [descr:dxSchedulerOptions.endDateTimeZoneExpr]
    
     */
    get endDateTimeZoneExpr() {
        return this._getOption('endDateTimeZoneExpr');
    }
    set endDateTimeZoneExpr(value) {
        this._setOption('endDateTimeZoneExpr', value);
    }
    /**
     * [descr:dxSchedulerOptions.endDayHour]
    
     */
    get endDayHour() {
        return this._getOption('endDayHour');
    }
    set endDayHour(value) {
        this._setOption('endDayHour', value);
    }
    /**
     * [descr:dxSchedulerOptions.firstDayOfWeek]
    
     */
    get firstDayOfWeek() {
        return this._getOption('firstDayOfWeek');
    }
    set firstDayOfWeek(value) {
        this._setOption('firstDayOfWeek', value);
    }
    /**
     * [descr:dxSchedulerOptions.focusStateEnabled]
    
     */
    get focusStateEnabled() {
        return this._getOption('focusStateEnabled');
    }
    set focusStateEnabled(value) {
        this._setOption('focusStateEnabled', value);
    }
    /**
     * [descr:dxSchedulerOptions.groupByDate]
    
     */
    get groupByDate() {
        return this._getOption('groupByDate');
    }
    set groupByDate(value) {
        this._setOption('groupByDate', value);
    }
    /**
     * [descr:dxSchedulerOptions.groups]
    
     */
    get groups() {
        return this._getOption('groups');
    }
    set groups(value) {
        this._setOption('groups', value);
    }
    /**
     * [descr:DOMComponentOptions.height]
    
     */
    get height() {
        return this._getOption('height');
    }
    set height(value) {
        this._setOption('height', value);
    }
    get hiddenWeekDays() {
        return this._getOption('hiddenWeekDays');
    }
    set hiddenWeekDays(value) {
        this._setOption('hiddenWeekDays', value);
    }
    /**
     * [descr:WidgetOptions.hint]
    
     */
    get hint() {
        return this._getOption('hint');
    }
    set hint(value) {
        this._setOption('hint', value);
    }
    /**
     * [descr:dxSchedulerOptions.indicatorUpdateInterval]
    
     */
    get indicatorUpdateInterval() {
        return this._getOption('indicatorUpdateInterval');
    }
    set indicatorUpdateInterval(value) {
        this._setOption('indicatorUpdateInterval', value);
    }
    /**
     * [descr:dxSchedulerOptions.max]
    
     */
    get max() {
        return this._getOption('max');
    }
    set max(value) {
        this._setOption('max', value);
    }
    /**
     * [descr:dxSchedulerOptions.maxAppointmentsPerCell]
    
     */
    get maxAppointmentsPerCell() {
        return this._getOption('maxAppointmentsPerCell');
    }
    set maxAppointmentsPerCell(value) {
        this._setOption('maxAppointmentsPerCell', value);
    }
    /**
     * [descr:dxSchedulerOptions.min]
    
     */
    get min() {
        return this._getOption('min');
    }
    set min(value) {
        this._setOption('min', value);
    }
    /**
     * [descr:dxSchedulerOptions.noDataText]
    
     */
    get noDataText() {
        return this._getOption('noDataText');
    }
    set noDataText(value) {
        this._setOption('noDataText', value);
    }
    /**
     * [descr:dxSchedulerOptions.offset]
    
     */
    get offset() {
        return this._getOption('offset');
    }
    set offset(value) {
        this._setOption('offset', value);
    }
    /**
     * [descr:dxSchedulerOptions.recurrenceEditMode]
    
     */
    get recurrenceEditMode() {
        return this._getOption('recurrenceEditMode');
    }
    set recurrenceEditMode(value) {
        this._setOption('recurrenceEditMode', value);
    }
    /**
     * [descr:dxSchedulerOptions.recurrenceExceptionExpr]
    
     */
    get recurrenceExceptionExpr() {
        return this._getOption('recurrenceExceptionExpr');
    }
    set recurrenceExceptionExpr(value) {
        this._setOption('recurrenceExceptionExpr', value);
    }
    /**
     * [descr:dxSchedulerOptions.recurrenceRuleExpr]
    
     */
    get recurrenceRuleExpr() {
        return this._getOption('recurrenceRuleExpr');
    }
    set recurrenceRuleExpr(value) {
        this._setOption('recurrenceRuleExpr', value);
    }
    /**
     * [descr:dxSchedulerOptions.remoteFiltering]
    
     */
    get remoteFiltering() {
        return this._getOption('remoteFiltering');
    }
    set remoteFiltering(value) {
        this._setOption('remoteFiltering', value);
    }
    /**
     * [descr:dxSchedulerOptions.resourceCellTemplate]
    
     */
    get resourceCellTemplate() {
        return this._getOption('resourceCellTemplate');
    }
    set resourceCellTemplate(value) {
        this._setOption('resourceCellTemplate', value);
    }
    /**
     * [descr:dxSchedulerOptions.resources]
    
     */
    get resources() {
        return this._getOption('resources');
    }
    set resources(value) {
        this._setOption('resources', value);
    }
    /**
     * [descr:DOMComponentOptions.rtlEnabled]
    
     */
    get rtlEnabled() {
        return this._getOption('rtlEnabled');
    }
    set rtlEnabled(value) {
        this._setOption('rtlEnabled', value);
    }
    /**
     * [descr:dxSchedulerOptions.scrolling]
    
     */
    get scrolling() {
        return this._getOption('scrolling');
    }
    set scrolling(value) {
        this._setOption('scrolling', value);
    }
    /**
     * [descr:dxSchedulerOptions.selectedCellData]
    
     */
    get selectedCellData() {
        return this._getOption('selectedCellData');
    }
    set selectedCellData(value) {
        this._setOption('selectedCellData', value);
    }
    /**
     * [descr:dxSchedulerOptions.shadeUntilCurrentTime]
    
     */
    get shadeUntilCurrentTime() {
        return this._getOption('shadeUntilCurrentTime');
    }
    set shadeUntilCurrentTime(value) {
        this._setOption('shadeUntilCurrentTime', value);
    }
    /**
     * [descr:dxSchedulerOptions.showAllDayPanel]
    
     */
    get showAllDayPanel() {
        return this._getOption('showAllDayPanel');
    }
    set showAllDayPanel(value) {
        this._setOption('showAllDayPanel', value);
    }
    /**
     * [descr:dxSchedulerOptions.showCurrentTimeIndicator]
    
     */
    get showCurrentTimeIndicator() {
        return this._getOption('showCurrentTimeIndicator');
    }
    set showCurrentTimeIndicator(value) {
        this._setOption('showCurrentTimeIndicator', value);
    }
    get snapToCellsMode() {
        return this._getOption('snapToCellsMode');
    }
    set snapToCellsMode(value) {
        this._setOption('snapToCellsMode', value);
    }
    /**
     * [descr:dxSchedulerOptions.startDateExpr]
    
     */
    get startDateExpr() {
        return this._getOption('startDateExpr');
    }
    set startDateExpr(value) {
        this._setOption('startDateExpr', value);
    }
    /**
     * [descr:dxSchedulerOptions.startDateTimeZoneExpr]
    
     */
    get startDateTimeZoneExpr() {
        return this._getOption('startDateTimeZoneExpr');
    }
    set startDateTimeZoneExpr(value) {
        this._setOption('startDateTimeZoneExpr', value);
    }
    /**
     * [descr:dxSchedulerOptions.startDayHour]
    
     */
    get startDayHour() {
        return this._getOption('startDayHour');
    }
    set startDayHour(value) {
        this._setOption('startDayHour', value);
    }
    /**
     * [descr:WidgetOptions.tabIndex]
    
     */
    get tabIndex() {
        return this._getOption('tabIndex');
    }
    set tabIndex(value) {
        this._setOption('tabIndex', value);
    }
    /**
     * [descr:dxSchedulerOptions.textExpr]
    
     */
    get textExpr() {
        return this._getOption('textExpr');
    }
    set textExpr(value) {
        this._setOption('textExpr', value);
    }
    /**
     * [descr:dxSchedulerOptions.timeCellTemplate]
    
     */
    get timeCellTemplate() {
        return this._getOption('timeCellTemplate');
    }
    set timeCellTemplate(value) {
        this._setOption('timeCellTemplate', value);
    }
    /**
     * [descr:dxSchedulerOptions.timeZone]
    
     */
    get timeZone() {
        return this._getOption('timeZone');
    }
    set timeZone(value) {
        this._setOption('timeZone', value);
    }
    /**
     * [descr:dxSchedulerOptions.toolbar]
    
     */
    get toolbar() {
        return this._getOption('toolbar');
    }
    set toolbar(value) {
        this._setOption('toolbar', value);
    }
    /**
     * [descr:dxSchedulerOptions.useDropDownViewSwitcher]
    
     */
    get useDropDownViewSwitcher() {
        return this._getOption('useDropDownViewSwitcher');
    }
    set useDropDownViewSwitcher(value) {
        this._setOption('useDropDownViewSwitcher', value);
    }
    /**
     * [descr:dxSchedulerOptions.views]
    
     */
    get views() {
        return this._getOption('views');
    }
    set views(value) {
        this._setOption('views', value);
    }
    /**
     * [descr:WidgetOptions.visible]
    
     */
    get visible() {
        return this._getOption('visible');
    }
    set visible(value) {
        this._setOption('visible', value);
    }
    /**
     * [descr:DOMComponentOptions.width]
    
     */
    get width() {
        return this._getOption('width');
    }
    set width(value) {
        this._setOption('width', value);
    }
    constructor(elementRef, ngZone, templateHost, _watcherHelper, _idh, optionHost, transferState, platformId) {
        super(elementRef, ngZone, templateHost, _watcherHelper, transferState, platformId);
        this._watcherHelper = _watcherHelper;
        this._idh = _idh;
        this.instance = null;
        this._createEventEmitters([
            { subscribe: 'appointmentAdded', emit: 'onAppointmentAdded' },
            { subscribe: 'appointmentAdding', emit: 'onAppointmentAdding' },
            { subscribe: 'appointmentClick', emit: 'onAppointmentClick' },
            { subscribe: 'appointmentContextMenu', emit: 'onAppointmentContextMenu' },
            { subscribe: 'appointmentDblClick', emit: 'onAppointmentDblClick' },
            { subscribe: 'appointmentDeleted', emit: 'onAppointmentDeleted' },
            { subscribe: 'appointmentDeleting', emit: 'onAppointmentDeleting' },
            { subscribe: 'appointmentFormOpening', emit: 'onAppointmentFormOpening' },
            { subscribe: 'appointmentRendered', emit: 'onAppointmentRendered' },
            { subscribe: 'appointmentTooltipShowing', emit: 'onAppointmentTooltipShowing' },
            { subscribe: 'appointmentUpdated', emit: 'onAppointmentUpdated' },
            { subscribe: 'appointmentUpdating', emit: 'onAppointmentUpdating' },
            { subscribe: 'cellClick', emit: 'onCellClick' },
            { subscribe: 'cellContextMenu', emit: 'onCellContextMenu' },
            { subscribe: 'contentReady', emit: 'onContentReady' },
            { subscribe: 'disposing', emit: 'onDisposing' },
            { subscribe: 'initialized', emit: 'onInitialized' },
            { subscribe: 'optionChanged', emit: 'onOptionChanged' },
            { subscribe: 'selectionEnd', emit: 'onSelectionEnd' },
            { emit: 'accessKeyChange' },
            { emit: 'adaptivityEnabledChange' },
            { emit: 'allDayExprChange' },
            { emit: 'allDayPanelModeChange' },
            { emit: 'appointmentCollectorTemplateChange' },
            { emit: 'appointmentDraggingChange' },
            { emit: 'appointmentTemplateChange' },
            { emit: 'appointmentTooltipTemplateChange' },
            { emit: 'cellDurationChange' },
            { emit: 'crossScrollingEnabledChange' },
            { emit: 'currentDateChange' },
            { emit: 'currentViewChange' },
            { emit: 'customizeDateNavigatorTextChange' },
            { emit: 'dataCellTemplateChange' },
            { emit: 'dataSourceChange' },
            { emit: 'dateCellTemplateChange' },
            { emit: 'dateSerializationFormatChange' },
            { emit: 'descriptionExprChange' },
            { emit: 'disabledChange' },
            { emit: 'editingChange' },
            { emit: 'elementAttrChange' },
            { emit: 'endDateExprChange' },
            { emit: 'endDateTimeZoneExprChange' },
            { emit: 'endDayHourChange' },
            { emit: 'firstDayOfWeekChange' },
            { emit: 'focusStateEnabledChange' },
            { emit: 'groupByDateChange' },
            { emit: 'groupsChange' },
            { emit: 'heightChange' },
            { emit: 'hiddenWeekDaysChange' },
            { emit: 'hintChange' },
            { emit: 'indicatorUpdateIntervalChange' },
            { emit: 'maxChange' },
            { emit: 'maxAppointmentsPerCellChange' },
            { emit: 'minChange' },
            { emit: 'noDataTextChange' },
            { emit: 'offsetChange' },
            { emit: 'recurrenceEditModeChange' },
            { emit: 'recurrenceExceptionExprChange' },
            { emit: 'recurrenceRuleExprChange' },
            { emit: 'remoteFilteringChange' },
            { emit: 'resourceCellTemplateChange' },
            { emit: 'resourcesChange' },
            { emit: 'rtlEnabledChange' },
            { emit: 'scrollingChange' },
            { emit: 'selectedCellDataChange' },
            { emit: 'shadeUntilCurrentTimeChange' },
            { emit: 'showAllDayPanelChange' },
            { emit: 'showCurrentTimeIndicatorChange' },
            { emit: 'snapToCellsModeChange' },
            { emit: 'startDateExprChange' },
            { emit: 'startDateTimeZoneExprChange' },
            { emit: 'startDayHourChange' },
            { emit: 'tabIndexChange' },
            { emit: 'textExprChange' },
            { emit: 'timeCellTemplateChange' },
            { emit: 'timeZoneChange' },
            { emit: 'toolbarChange' },
            { emit: 'useDropDownViewSwitcherChange' },
            { emit: 'viewsChange' },
            { emit: 'visibleChange' },
            { emit: 'widthChange' }
        ]);
        this._idh.setHost(this);
        optionHost.setHost(this);
    }
    _createInstance(element, options) {
        return new DxScheduler(element, options);
    }
    ngOnDestroy() {
        this._destroyWidget();
    }
    ngOnChanges(changes) {
        super.ngOnChanges(changes);
        this.setupChanges('dataSource', changes);
        this.setupChanges('groups', changes);
        this.setupChanges('hiddenWeekDays', changes);
        this.setupChanges('resources', changes);
        this.setupChanges('selectedCellData', changes);
        this.setupChanges('views', changes);
    }
    setupChanges(prop, changes) {
        if (!(prop in this._optionsToUpdate)) {
            this._idh.setup(prop, changes);
        }
    }
    ngDoCheck() {
        this._idh.doCheck('dataSource');
        this._idh.doCheck('groups');
        this._idh.doCheck('hiddenWeekDays');
        this._idh.doCheck('resources');
        this._idh.doCheck('selectedCellData');
        this._idh.doCheck('views');
        this._watcherHelper.checkWatchers();
        super.ngDoCheck();
        super.clearChangedOptions();
    }
    _setOption(name, value) {
        let isSetup = this._idh.setupSingle(name, value);
        let isChanged = this._idh.getChanges(name, value) !== null;
        if (isSetup || isChanged) {
            super._setOption(name, value);
        }
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxSchedulerComponent, deps: [{ token: i0.ElementRef }, { token: i0.NgZone }, { token: i1.DxTemplateHost }, { token: i1.WatcherHelper }, { token: i1.IterableDifferHelper }, { token: i1.NestedOptionHost }, { token: i0.TransferState }, { token: PLATFORM_ID }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxSchedulerComponent, isStandalone: true, selector: "dx-scheduler", inputs: { accessKey: "accessKey", adaptivityEnabled: "adaptivityEnabled", allDayExpr: "allDayExpr", allDayPanelMode: "allDayPanelMode", appointmentCollectorTemplate: "appointmentCollectorTemplate", appointmentDragging: "appointmentDragging", appointmentTemplate: "appointmentTemplate", appointmentTooltipTemplate: "appointmentTooltipTemplate", cellDuration: "cellDuration", crossScrollingEnabled: "crossScrollingEnabled", currentDate: "currentDate", currentView: "currentView", customizeDateNavigatorText: "customizeDateNavigatorText", dataCellTemplate: "dataCellTemplate", dataSource: "dataSource", dateCellTemplate: "dateCellTemplate", dateSerializationFormat: "dateSerializationFormat", descriptionExpr: "descriptionExpr", disabled: "disabled", editing: "editing", elementAttr: "elementAttr", endDateExpr: "endDateExpr", endDateTimeZoneExpr: "endDateTimeZoneExpr", endDayHour: "endDayHour", firstDayOfWeek: "firstDayOfWeek", focusStateEnabled: "focusStateEnabled", groupByDate: "groupByDate", groups: "groups", height: "height", hiddenWeekDays: "hiddenWeekDays", hint: "hint", indicatorUpdateInterval: "indicatorUpdateInterval", max: "max", maxAppointmentsPerCell: "maxAppointmentsPerCell", min: "min", noDataText: "noDataText", offset: "offset", recurrenceEditMode: "recurrenceEditMode", recurrenceExceptionExpr: "recurrenceExceptionExpr", recurrenceRuleExpr: "recurrenceRuleExpr", remoteFiltering: "remoteFiltering", resourceCellTemplate: "resourceCellTemplate", resources: "resources", rtlEnabled: "rtlEnabled", scrolling: "scrolling", selectedCellData: "selectedCellData", shadeUntilCurrentTime: "shadeUntilCurrentTime", showAllDayPanel: "showAllDayPanel", showCurrentTimeIndicator: "showCurrentTimeIndicator", snapToCellsMode: "snapToCellsMode", startDateExpr: "startDateExpr", startDateTimeZoneExpr: "startDateTimeZoneExpr", startDayHour: "startDayHour", tabIndex: "tabIndex", textExpr: "textExpr", timeCellTemplate: "timeCellTemplate", timeZone: "timeZone", toolbar: "toolbar", useDropDownViewSwitcher: "useDropDownViewSwitcher", views: "views", visible: "visible", width: "width" }, outputs: { onAppointmentAdded: "onAppointmentAdded", onAppointmentAdding: "onAppointmentAdding", onAppointmentClick: "onAppointmentClick", onAppointmentContextMenu: "onAppointmentContextMenu", onAppointmentDblClick: "onAppointmentDblClick", onAppointmentDeleted: "onAppointmentDeleted", onAppointmentDeleting: "onAppointmentDeleting", onAppointmentFormOpening: "onAppointmentFormOpening", onAppointmentRendered: "onAppointmentRendered", onAppointmentTooltipShowing: "onAppointmentTooltipShowing", onAppointmentUpdated: "onAppointmentUpdated", onAppointmentUpdating: "onAppointmentUpdating", onCellClick: "onCellClick", onCellContextMenu: "onCellContextMenu", onContentReady: "onContentReady", onDisposing: "onDisposing", onInitialized: "onInitialized", onOptionChanged: "onOptionChanged", onSelectionEnd: "onSelectionEnd", accessKeyChange: "accessKeyChange", adaptivityEnabledChange: "adaptivityEnabledChange", allDayExprChange: "allDayExprChange", allDayPanelModeChange: "allDayPanelModeChange", appointmentCollectorTemplateChange: "appointmentCollectorTemplateChange", appointmentDraggingChange: "appointmentDraggingChange", appointmentTemplateChange: "appointmentTemplateChange", appointmentTooltipTemplateChange: "appointmentTooltipTemplateChange", cellDurationChange: "cellDurationChange", crossScrollingEnabledChange: "crossScrollingEnabledChange", currentDateChange: "currentDateChange", currentViewChange: "currentViewChange", customizeDateNavigatorTextChange: "customizeDateNavigatorTextChange", dataCellTemplateChange: "dataCellTemplateChange", dataSourceChange: "dataSourceChange", dateCellTemplateChange: "dateCellTemplateChange", dateSerializationFormatChange: "dateSerializationFormatChange", descriptionExprChange: "descriptionExprChange", disabledChange: "disabledChange", editingChange: "editingChange", elementAttrChange: "elementAttrChange", endDateExprChange: "endDateExprChange", endDateTimeZoneExprChange: "endDateTimeZoneExprChange", endDayHourChange: "endDayHourChange", firstDayOfWeekChange: "firstDayOfWeekChange", focusStateEnabledChange: "focusStateEnabledChange", groupByDateChange: "groupByDateChange", groupsChange: "groupsChange", heightChange: "heightChange", hiddenWeekDaysChange: "hiddenWeekDaysChange", hintChange: "hintChange", indicatorUpdateIntervalChange: "indicatorUpdateIntervalChange", maxChange: "maxChange", maxAppointmentsPerCellChange: "maxAppointmentsPerCellChange", minChange: "minChange", noDataTextChange: "noDataTextChange", offsetChange: "offsetChange", recurrenceEditModeChange: "recurrenceEditModeChange", recurrenceExceptionExprChange: "recurrenceExceptionExprChange", recurrenceRuleExprChange: "recurrenceRuleExprChange", remoteFilteringChange: "remoteFilteringChange", resourceCellTemplateChange: "resourceCellTemplateChange", resourcesChange: "resourcesChange", rtlEnabledChange: "rtlEnabledChange", scrollingChange: "scrollingChange", selectedCellDataChange: "selectedCellDataChange", shadeUntilCurrentTimeChange: "shadeUntilCurrentTimeChange", showAllDayPanelChange: "showAllDayPanelChange", showCurrentTimeIndicatorChange: "showCurrentTimeIndicatorChange", snapToCellsModeChange: "snapToCellsModeChange", startDateExprChange: "startDateExprChange", startDateTimeZoneExprChange: "startDateTimeZoneExprChange", startDayHourChange: "startDayHourChange", tabIndexChange: "tabIndexChange", textExprChange: "textExprChange", timeCellTemplateChange: "timeCellTemplateChange", timeZoneChange: "timeZoneChange", toolbarChange: "toolbarChange", useDropDownViewSwitcherChange: "useDropDownViewSwitcherChange", viewsChange: "viewsChange", visibleChange: "visibleChange", widthChange: "widthChange" }, host: { attributes: { "ngSkipHydration": "true" } }, providers: [
            DxTemplateHost,
            WatcherHelper,
            NestedOptionHost,
            IterableDifferHelper
        ], queries: [{ propertyName: "_validationRulesContentChildren", predicate: PROPERTY_TOKEN_validationRules }, { propertyName: "_itemsContentChildren", predicate: PROPERTY_TOKEN_items }, { propertyName: "_resourcesContentChildren", predicate: PROPERTY_TOKEN_resources }, { propertyName: "_tabsContentChildren", predicate: PROPERTY_TOKEN_tabs }, { propertyName: "_viewsContentChildren", predicate: PROPERTY_TOKEN_views }], usesInheritance: true, usesOnChanges: true, ngImport: i0, template: '', isInline: true, dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxSchedulerComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'dx-scheduler',
                    template: '',
                    host: { ngSkipHydration: 'true' },
                    imports: [DxIntegrationModule],
                    providers: [
                        DxTemplateHost,
                        WatcherHelper,
                        NestedOptionHost,
                        IterableDifferHelper
                    ]
                }]
        }], ctorParameters: () => [{ type: i0.ElementRef }, { type: i0.NgZone }, { type: i1.DxTemplateHost }, { type: i1.WatcherHelper }, { type: i1.IterableDifferHelper }, { type: i1.NestedOptionHost }, { type: i0.TransferState }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [PLATFORM_ID]
                }] }], propDecorators: { _validationRulesContentChildren: [{
                type: ContentChildren,
                args: [PROPERTY_TOKEN_validationRules]
            }], _itemsContentChildren: [{
                type: ContentChildren,
                args: [PROPERTY_TOKEN_items]
            }], _resourcesContentChildren: [{
                type: ContentChildren,
                args: [PROPERTY_TOKEN_resources]
            }], _tabsContentChildren: [{
                type: ContentChildren,
                args: [PROPERTY_TOKEN_tabs]
            }], _viewsContentChildren: [{
                type: ContentChildren,
                args: [PROPERTY_TOKEN_views]
            }], accessKey: [{
                type: Input
            }], adaptivityEnabled: [{
                type: Input
            }], allDayExpr: [{
                type: Input
            }], allDayPanelMode: [{
                type: Input
            }], appointmentCollectorTemplate: [{
                type: Input
            }], appointmentDragging: [{
                type: Input
            }], appointmentTemplate: [{
                type: Input
            }], appointmentTooltipTemplate: [{
                type: Input
            }], cellDuration: [{
                type: Input
            }], crossScrollingEnabled: [{
                type: Input
            }], currentDate: [{
                type: Input
            }], currentView: [{
                type: Input
            }], customizeDateNavigatorText: [{
                type: Input
            }], dataCellTemplate: [{
                type: Input
            }], dataSource: [{
                type: Input
            }], dateCellTemplate: [{
                type: Input
            }], dateSerializationFormat: [{
                type: Input
            }], descriptionExpr: [{
                type: Input
            }], disabled: [{
                type: Input
            }], editing: [{
                type: Input
            }], elementAttr: [{
                type: Input
            }], endDateExpr: [{
                type: Input
            }], endDateTimeZoneExpr: [{
                type: Input
            }], endDayHour: [{
                type: Input
            }], firstDayOfWeek: [{
                type: Input
            }], focusStateEnabled: [{
                type: Input
            }], groupByDate: [{
                type: Input
            }], groups: [{
                type: Input
            }], height: [{
                type: Input
            }], hiddenWeekDays: [{
                type: Input
            }], hint: [{
                type: Input
            }], indicatorUpdateInterval: [{
                type: Input
            }], max: [{
                type: Input
            }], maxAppointmentsPerCell: [{
                type: Input
            }], min: [{
                type: Input
            }], noDataText: [{
                type: Input
            }], offset: [{
                type: Input
            }], recurrenceEditMode: [{
                type: Input
            }], recurrenceExceptionExpr: [{
                type: Input
            }], recurrenceRuleExpr: [{
                type: Input
            }], remoteFiltering: [{
                type: Input
            }], resourceCellTemplate: [{
                type: Input
            }], resources: [{
                type: Input
            }], rtlEnabled: [{
                type: Input
            }], scrolling: [{
                type: Input
            }], selectedCellData: [{
                type: Input
            }], shadeUntilCurrentTime: [{
                type: Input
            }], showAllDayPanel: [{
                type: Input
            }], showCurrentTimeIndicator: [{
                type: Input
            }], snapToCellsMode: [{
                type: Input
            }], startDateExpr: [{
                type: Input
            }], startDateTimeZoneExpr: [{
                type: Input
            }], startDayHour: [{
                type: Input
            }], tabIndex: [{
                type: Input
            }], textExpr: [{
                type: Input
            }], timeCellTemplate: [{
                type: Input
            }], timeZone: [{
                type: Input
            }], toolbar: [{
                type: Input
            }], useDropDownViewSwitcher: [{
                type: Input
            }], views: [{
                type: Input
            }], visible: [{
                type: Input
            }], width: [{
                type: Input
            }], onAppointmentAdded: [{
                type: Output
            }], onAppointmentAdding: [{
                type: Output
            }], onAppointmentClick: [{
                type: Output
            }], onAppointmentContextMenu: [{
                type: Output
            }], onAppointmentDblClick: [{
                type: Output
            }], onAppointmentDeleted: [{
                type: Output
            }], onAppointmentDeleting: [{
                type: Output
            }], onAppointmentFormOpening: [{
                type: Output
            }], onAppointmentRendered: [{
                type: Output
            }], onAppointmentTooltipShowing: [{
                type: Output
            }], onAppointmentUpdated: [{
                type: Output
            }], onAppointmentUpdating: [{
                type: Output
            }], onCellClick: [{
                type: Output
            }], onCellContextMenu: [{
                type: Output
            }], onContentReady: [{
                type: Output
            }], onDisposing: [{
                type: Output
            }], onInitialized: [{
                type: Output
            }], onOptionChanged: [{
                type: Output
            }], onSelectionEnd: [{
                type: Output
            }], accessKeyChange: [{
                type: Output
            }], adaptivityEnabledChange: [{
                type: Output
            }], allDayExprChange: [{
                type: Output
            }], allDayPanelModeChange: [{
                type: Output
            }], appointmentCollectorTemplateChange: [{
                type: Output
            }], appointmentDraggingChange: [{
                type: Output
            }], appointmentTemplateChange: [{
                type: Output
            }], appointmentTooltipTemplateChange: [{
                type: Output
            }], cellDurationChange: [{
                type: Output
            }], crossScrollingEnabledChange: [{
                type: Output
            }], currentDateChange: [{
                type: Output
            }], currentViewChange: [{
                type: Output
            }], customizeDateNavigatorTextChange: [{
                type: Output
            }], dataCellTemplateChange: [{
                type: Output
            }], dataSourceChange: [{
                type: Output
            }], dateCellTemplateChange: [{
                type: Output
            }], dateSerializationFormatChange: [{
                type: Output
            }], descriptionExprChange: [{
                type: Output
            }], disabledChange: [{
                type: Output
            }], editingChange: [{
                type: Output
            }], elementAttrChange: [{
                type: Output
            }], endDateExprChange: [{
                type: Output
            }], endDateTimeZoneExprChange: [{
                type: Output
            }], endDayHourChange: [{
                type: Output
            }], firstDayOfWeekChange: [{
                type: Output
            }], focusStateEnabledChange: [{
                type: Output
            }], groupByDateChange: [{
                type: Output
            }], groupsChange: [{
                type: Output
            }], heightChange: [{
                type: Output
            }], hiddenWeekDaysChange: [{
                type: Output
            }], hintChange: [{
                type: Output
            }], indicatorUpdateIntervalChange: [{
                type: Output
            }], maxChange: [{
                type: Output
            }], maxAppointmentsPerCellChange: [{
                type: Output
            }], minChange: [{
                type: Output
            }], noDataTextChange: [{
                type: Output
            }], offsetChange: [{
                type: Output
            }], recurrenceEditModeChange: [{
                type: Output
            }], recurrenceExceptionExprChange: [{
                type: Output
            }], recurrenceRuleExprChange: [{
                type: Output
            }], remoteFilteringChange: [{
                type: Output
            }], resourceCellTemplateChange: [{
                type: Output
            }], resourcesChange: [{
                type: Output
            }], rtlEnabledChange: [{
                type: Output
            }], scrollingChange: [{
                type: Output
            }], selectedCellDataChange: [{
                type: Output
            }], shadeUntilCurrentTimeChange: [{
                type: Output
            }], showAllDayPanelChange: [{
                type: Output
            }], showCurrentTimeIndicatorChange: [{
                type: Output
            }], snapToCellsModeChange: [{
                type: Output
            }], startDateExprChange: [{
                type: Output
            }], startDateTimeZoneExprChange: [{
                type: Output
            }], startDayHourChange: [{
                type: Output
            }], tabIndexChange: [{
                type: Output
            }], textExprChange: [{
                type: Output
            }], timeCellTemplateChange: [{
                type: Output
            }], timeZoneChange: [{
                type: Output
            }], toolbarChange: [{
                type: Output
            }], useDropDownViewSwitcherChange: [{
                type: Output
            }], viewsChange: [{
                type: Output
            }], visibleChange: [{
                type: Output
            }], widthChange: [{
                type: Output
            }] } });
class DxSchedulerModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxSchedulerModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxSchedulerModule, imports: [DxSchedulerComponent, DxoAppointmentDraggingModule,
            DxoEditingModule,
            DxiResourceModule,
            DxoScrollingModule,
            DxiViewModule,
            DxoSchedulerAIOptionsModule,
            DxoSchedulerAppointmentDraggingModule,
            DxiSchedulerAsyncRuleModule,
            DxiSchedulerButtonItemModule,
            DxoSchedulerButtonOptionsModule,
            DxoSchedulerColCountByScreenModule,
            DxiSchedulerCompareRuleModule,
            DxiSchedulerCustomRuleModule,
            DxoSchedulerEditingModule,
            DxiSchedulerEmailRuleModule,
            DxiSchedulerEmptyItemModule,
            DxoSchedulerFormModule,
            DxiSchedulerGroupItemModule,
            DxiSchedulerItemModule,
            DxoSchedulerLabelModule,
            DxiSchedulerNumericRuleModule,
            DxoSchedulerOptionsModule,
            DxiSchedulerOptionsItemModule,
            DxiSchedulerPatternRuleModule,
            DxiSchedulerRangeRuleModule,
            DxiSchedulerRequiredRuleModule,
            DxiSchedulerResourceModule,
            DxoSchedulerScrollingModule,
            DxiSchedulerSimpleItemModule,
            DxiSchedulerStringLengthRuleModule,
            DxiSchedulerTabModule,
            DxiSchedulerTabbedItemModule,
            DxoSchedulerTabPanelOptionsModule,
            DxiSchedulerTabPanelOptionsItemModule,
            DxoSchedulerToolbarModule,
            DxiSchedulerToolbarItemModule,
            DxiSchedulerValidationRuleModule,
            DxiSchedulerViewModule,
            DxIntegrationModule,
            DxTemplateModule], exports: [DxSchedulerComponent, DxoAppointmentDraggingModule,
            DxoEditingModule,
            DxiResourceModule,
            DxoScrollingModule,
            DxiViewModule,
            DxoSchedulerAIOptionsModule,
            DxoSchedulerAppointmentDraggingModule,
            DxiSchedulerAsyncRuleModule,
            DxiSchedulerButtonItemModule,
            DxoSchedulerButtonOptionsModule,
            DxoSchedulerColCountByScreenModule,
            DxiSchedulerCompareRuleModule,
            DxiSchedulerCustomRuleModule,
            DxoSchedulerEditingModule,
            DxiSchedulerEmailRuleModule,
            DxiSchedulerEmptyItemModule,
            DxoSchedulerFormModule,
            DxiSchedulerGroupItemModule,
            DxiSchedulerItemModule,
            DxoSchedulerLabelModule,
            DxiSchedulerNumericRuleModule,
            DxoSchedulerOptionsModule,
            DxiSchedulerOptionsItemModule,
            DxiSchedulerPatternRuleModule,
            DxiSchedulerRangeRuleModule,
            DxiSchedulerRequiredRuleModule,
            DxiSchedulerResourceModule,
            DxoSchedulerScrollingModule,
            DxiSchedulerSimpleItemModule,
            DxiSchedulerStringLengthRuleModule,
            DxiSchedulerTabModule,
            DxiSchedulerTabbedItemModule,
            DxoSchedulerTabPanelOptionsModule,
            DxiSchedulerTabPanelOptionsItemModule,
            DxoSchedulerToolbarModule,
            DxiSchedulerToolbarItemModule,
            DxiSchedulerValidationRuleModule,
            DxiSchedulerViewModule,
            DxTemplateModule] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxSchedulerModule, imports: [DxSchedulerComponent,
            DxoAppointmentDraggingModule,
            DxoEditingModule,
            DxiResourceModule,
            DxoScrollingModule,
            DxiViewModule,
            DxoSchedulerAIOptionsModule,
            DxoSchedulerAppointmentDraggingModule,
            DxiSchedulerAsyncRuleModule,
            DxiSchedulerButtonItemModule,
            DxoSchedulerButtonOptionsModule,
            DxoSchedulerColCountByScreenModule,
            DxiSchedulerCompareRuleModule,
            DxiSchedulerCustomRuleModule,
            DxoSchedulerEditingModule,
            DxiSchedulerEmailRuleModule,
            DxiSchedulerEmptyItemModule,
            DxoSchedulerFormModule,
            DxiSchedulerGroupItemModule,
            DxiSchedulerItemModule,
            DxoSchedulerLabelModule,
            DxiSchedulerNumericRuleModule,
            DxoSchedulerOptionsModule,
            DxiSchedulerOptionsItemModule,
            DxiSchedulerPatternRuleModule,
            DxiSchedulerRangeRuleModule,
            DxiSchedulerRequiredRuleModule,
            DxiSchedulerResourceModule,
            DxoSchedulerScrollingModule,
            DxiSchedulerSimpleItemModule,
            DxiSchedulerStringLengthRuleModule,
            DxiSchedulerTabModule,
            DxiSchedulerTabbedItemModule,
            DxoSchedulerTabPanelOptionsModule,
            DxiSchedulerTabPanelOptionsItemModule,
            DxoSchedulerToolbarModule,
            DxiSchedulerToolbarItemModule,
            DxiSchedulerValidationRuleModule,
            DxiSchedulerViewModule,
            DxIntegrationModule,
            DxTemplateModule, DxoAppointmentDraggingModule,
            DxoEditingModule,
            DxiResourceModule,
            DxoScrollingModule,
            DxiViewModule,
            DxoSchedulerAIOptionsModule,
            DxoSchedulerAppointmentDraggingModule,
            DxiSchedulerAsyncRuleModule,
            DxiSchedulerButtonItemModule,
            DxoSchedulerButtonOptionsModule,
            DxoSchedulerColCountByScreenModule,
            DxiSchedulerCompareRuleModule,
            DxiSchedulerCustomRuleModule,
            DxoSchedulerEditingModule,
            DxiSchedulerEmailRuleModule,
            DxiSchedulerEmptyItemModule,
            DxoSchedulerFormModule,
            DxiSchedulerGroupItemModule,
            DxiSchedulerItemModule,
            DxoSchedulerLabelModule,
            DxiSchedulerNumericRuleModule,
            DxoSchedulerOptionsModule,
            DxiSchedulerOptionsItemModule,
            DxiSchedulerPatternRuleModule,
            DxiSchedulerRangeRuleModule,
            DxiSchedulerRequiredRuleModule,
            DxiSchedulerResourceModule,
            DxoSchedulerScrollingModule,
            DxiSchedulerSimpleItemModule,
            DxiSchedulerStringLengthRuleModule,
            DxiSchedulerTabModule,
            DxiSchedulerTabbedItemModule,
            DxoSchedulerTabPanelOptionsModule,
            DxiSchedulerTabPanelOptionsItemModule,
            DxoSchedulerToolbarModule,
            DxiSchedulerToolbarItemModule,
            DxiSchedulerValidationRuleModule,
            DxiSchedulerViewModule,
            DxTemplateModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxSchedulerModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxSchedulerComponent,
                        DxoAppointmentDraggingModule,
                        DxoEditingModule,
                        DxiResourceModule,
                        DxoScrollingModule,
                        DxiViewModule,
                        DxoSchedulerAIOptionsModule,
                        DxoSchedulerAppointmentDraggingModule,
                        DxiSchedulerAsyncRuleModule,
                        DxiSchedulerButtonItemModule,
                        DxoSchedulerButtonOptionsModule,
                        DxoSchedulerColCountByScreenModule,
                        DxiSchedulerCompareRuleModule,
                        DxiSchedulerCustomRuleModule,
                        DxoSchedulerEditingModule,
                        DxiSchedulerEmailRuleModule,
                        DxiSchedulerEmptyItemModule,
                        DxoSchedulerFormModule,
                        DxiSchedulerGroupItemModule,
                        DxiSchedulerItemModule,
                        DxoSchedulerLabelModule,
                        DxiSchedulerNumericRuleModule,
                        DxoSchedulerOptionsModule,
                        DxiSchedulerOptionsItemModule,
                        DxiSchedulerPatternRuleModule,
                        DxiSchedulerRangeRuleModule,
                        DxiSchedulerRequiredRuleModule,
                        DxiSchedulerResourceModule,
                        DxoSchedulerScrollingModule,
                        DxiSchedulerSimpleItemModule,
                        DxiSchedulerStringLengthRuleModule,
                        DxiSchedulerTabModule,
                        DxiSchedulerTabbedItemModule,
                        DxoSchedulerTabPanelOptionsModule,
                        DxiSchedulerTabPanelOptionsItemModule,
                        DxoSchedulerToolbarModule,
                        DxiSchedulerToolbarItemModule,
                        DxiSchedulerValidationRuleModule,
                        DxiSchedulerViewModule,
                        DxIntegrationModule,
                        DxTemplateModule
                    ],
                    exports: [
                        DxSchedulerComponent,
                        DxoAppointmentDraggingModule,
                        DxoEditingModule,
                        DxiResourceModule,
                        DxoScrollingModule,
                        DxiViewModule,
                        DxoSchedulerAIOptionsModule,
                        DxoSchedulerAppointmentDraggingModule,
                        DxiSchedulerAsyncRuleModule,
                        DxiSchedulerButtonItemModule,
                        DxoSchedulerButtonOptionsModule,
                        DxoSchedulerColCountByScreenModule,
                        DxiSchedulerCompareRuleModule,
                        DxiSchedulerCustomRuleModule,
                        DxoSchedulerEditingModule,
                        DxiSchedulerEmailRuleModule,
                        DxiSchedulerEmptyItemModule,
                        DxoSchedulerFormModule,
                        DxiSchedulerGroupItemModule,
                        DxiSchedulerItemModule,
                        DxoSchedulerLabelModule,
                        DxiSchedulerNumericRuleModule,
                        DxoSchedulerOptionsModule,
                        DxiSchedulerOptionsItemModule,
                        DxiSchedulerPatternRuleModule,
                        DxiSchedulerRangeRuleModule,
                        DxiSchedulerRequiredRuleModule,
                        DxiSchedulerResourceModule,
                        DxoSchedulerScrollingModule,
                        DxiSchedulerSimpleItemModule,
                        DxiSchedulerStringLengthRuleModule,
                        DxiSchedulerTabModule,
                        DxiSchedulerTabbedItemModule,
                        DxoSchedulerTabPanelOptionsModule,
                        DxiSchedulerTabPanelOptionsItemModule,
                        DxoSchedulerToolbarModule,
                        DxiSchedulerToolbarItemModule,
                        DxiSchedulerValidationRuleModule,
                        DxiSchedulerViewModule,
                        DxTemplateModule
                    ]
                }]
        }] });

/**
 * Generated bundle index. Do not edit.
 */

export { DxSchedulerComponent, DxSchedulerModule };
//# sourceMappingURL=devextreme-angular-ui-scheduler.mjs.map
