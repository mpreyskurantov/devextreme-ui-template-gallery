import * as i0 from '@angular/core';
import { PLATFORM_ID, Output, Input, ContentChildren, Inject, Component, NgModule } from '@angular/core';
import DxCircularGauge from 'devextreme/viz/circular_gauge';
import * as i1 from 'devextreme-angular/core';
import { DxComponent, DxIntegrationModule, DxTemplateHost, WatcherHelper, NestedOptionHost, IterableDifferHelper, DxTemplateModule } from 'devextreme-angular/core';
import { DxoAnimationModule, DxoExportModule, DxoGeometryModule, DxoLoadingIndicatorModule, DxoFontModule, DxoMarginModule, DxoRangeContainerModule, DxoBackgroundColorModule, DxiRangeModule, DxoColorModule, DxoScaleModule, DxoLabelModule, DxoFormatModule, DxoMinorTickModule, DxoTickModule, DxoSizeModule, DxoSubvalueIndicatorModule, DxoTextModule, DxoTitleModule, DxoSubtitleModule, DxoTooltipModule, DxoBorderModule, DxoShadowModule, DxoValueIndicatorModule } from 'devextreme-angular/ui/nested';
import { DxoCircularGaugeAnimationModule, DxoCircularGaugeBackgroundColorModule, DxoCircularGaugeBorderModule, DxoCircularGaugeColorModule, DxoCircularGaugeExportModule, DxoCircularGaugeFontModule, DxoCircularGaugeFormatModule, DxoCircularGaugeGeometryModule, DxoCircularGaugeLabelModule, DxoCircularGaugeLoadingIndicatorModule, DxoCircularGaugeMarginModule, DxoCircularGaugeMinorTickModule, DxiCircularGaugeRangeModule, DxoCircularGaugeRangeContainerModule, DxoCircularGaugeScaleModule, DxoCircularGaugeShadowModule, DxoCircularGaugeSizeModule, DxoCircularGaugeSubtitleModule, DxoCircularGaugeSubvalueIndicatorModule, DxoCircularGaugeTextModule, DxoCircularGaugeTickModule, DxoCircularGaugeTitleModule, DxoCircularGaugeTooltipModule, DxoCircularGaugeValueIndicatorModule } from 'devextreme-angular/ui/circular-gauge/nested';
export * from 'devextreme-angular/ui/circular-gauge/nested';
import { PROPERTY_TOKEN_ranges } from 'devextreme-angular/core/tokens';

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
/**
 * [descr:dxCircularGauge]

 */
class DxCircularGaugeComponent extends DxComponent {
    set _rangesContentChildren(value) {
        this.setChildren('ranges', value);
    }
    /**
     * [descr:BaseGaugeOptions.animation]
    
     */
    get animation() {
        return this._getOption('animation');
    }
    set animation(value) {
        this._setOption('animation', value);
    }
    /**
     * [descr:dxCircularGaugeOptions.centerTemplate]
    
     */
    get centerTemplate() {
        return this._getOption('centerTemplate');
    }
    set centerTemplate(value) {
        this._setOption('centerTemplate', value);
    }
    /**
     * [descr:BaseGaugeOptions.containerBackgroundColor]
    
     */
    get containerBackgroundColor() {
        return this._getOption('containerBackgroundColor');
    }
    set containerBackgroundColor(value) {
        this._setOption('containerBackgroundColor', value);
    }
    /**
     * [descr:BaseWidgetOptions.disabled]
    
     */
    get disabled() {
        return this._getOption('disabled');
    }
    set disabled(value) {
        this._setOption('disabled', value);
    }
    /**
     * [descr:DOMComponentOptions.elementAttr]
    
     */
    get elementAttr() {
        return this._getOption('elementAttr');
    }
    set elementAttr(value) {
        this._setOption('elementAttr', value);
    }
    /**
     * [descr:BaseWidgetOptions.encodeHtml]
    
     */
    get encodeHtml() {
        return this._getOption('encodeHtml');
    }
    set encodeHtml(value) {
        this._setOption('encodeHtml', value);
    }
    /**
     * [descr:BaseWidgetOptions.export]
    
     */
    get export() {
        return this._getOption('export');
    }
    set export(value) {
        this._setOption('export', value);
    }
    /**
     * [descr:dxCircularGaugeOptions.geometry]
    
     */
    get geometry() {
        return this._getOption('geometry');
    }
    set geometry(value) {
        this._setOption('geometry', value);
    }
    /**
     * [descr:BaseGaugeOptions.loadingIndicator]
    
     */
    get loadingIndicator() {
        return this._getOption('loadingIndicator');
    }
    set loadingIndicator(value) {
        this._setOption('loadingIndicator', value);
    }
    /**
     * [descr:BaseWidgetOptions.margin]
    
     */
    get margin() {
        return this._getOption('margin');
    }
    set margin(value) {
        this._setOption('margin', value);
    }
    /**
     * [descr:BaseWidgetOptions.pathModified]
    
     */
    get pathModified() {
        return this._getOption('pathModified');
    }
    set pathModified(value) {
        this._setOption('pathModified', value);
    }
    /**
     * [descr:dxCircularGaugeOptions.rangeContainer]
    
     */
    get rangeContainer() {
        return this._getOption('rangeContainer');
    }
    set rangeContainer(value) {
        this._setOption('rangeContainer', value);
    }
    /**
     * [descr:BaseWidgetOptions.redrawOnResize]
    
     */
    get redrawOnResize() {
        return this._getOption('redrawOnResize');
    }
    set redrawOnResize(value) {
        this._setOption('redrawOnResize', value);
    }
    /**
     * [descr:BaseWidgetOptions.rtlEnabled]
    
     */
    get rtlEnabled() {
        return this._getOption('rtlEnabled');
    }
    set rtlEnabled(value) {
        this._setOption('rtlEnabled', value);
    }
    /**
     * [descr:dxCircularGaugeOptions.scale]
    
     */
    get scale() {
        return this._getOption('scale');
    }
    set scale(value) {
        this._setOption('scale', value);
    }
    /**
     * [descr:BaseWidgetOptions.size]
    
     */
    get size() {
        return this._getOption('size');
    }
    set size(value) {
        this._setOption('size', value);
    }
    /**
     * [descr:dxCircularGaugeOptions.subvalueIndicator]
    
     */
    get subvalueIndicator() {
        return this._getOption('subvalueIndicator');
    }
    set subvalueIndicator(value) {
        this._setOption('subvalueIndicator', value);
    }
    /**
     * [descr:BaseGaugeOptions.subvalues]
    
     */
    get subvalues() {
        return this._getOption('subvalues');
    }
    set subvalues(value) {
        this._setOption('subvalues', value);
    }
    /**
     * [descr:BaseWidgetOptions.theme]
    
     */
    get theme() {
        return this._getOption('theme');
    }
    set theme(value) {
        this._setOption('theme', value);
    }
    /**
     * [descr:BaseWidgetOptions.title]
    
     */
    get title() {
        return this._getOption('title');
    }
    set title(value) {
        this._setOption('title', value);
    }
    /**
     * [descr:BaseGaugeOptions.tooltip]
    
     */
    get tooltip() {
        return this._getOption('tooltip');
    }
    set tooltip(value) {
        this._setOption('tooltip', value);
    }
    /**
     * [descr:BaseGaugeOptions.value]
    
     */
    get value() {
        return this._getOption('value');
    }
    set value(value) {
        this._setOption('value', value);
    }
    /**
     * [descr:dxCircularGaugeOptions.valueIndicator]
    
     */
    get valueIndicator() {
        return this._getOption('valueIndicator');
    }
    set valueIndicator(value) {
        this._setOption('valueIndicator', value);
    }
    constructor(elementRef, ngZone, templateHost, _watcherHelper, _idh, optionHost, transferState, platformId) {
        super(elementRef, ngZone, templateHost, _watcherHelper, transferState, platformId);
        this._watcherHelper = _watcherHelper;
        this._idh = _idh;
        this.instance = null;
        this._createEventEmitters([
            { subscribe: 'disposing', emit: 'onDisposing' },
            { subscribe: 'drawn', emit: 'onDrawn' },
            { subscribe: 'exported', emit: 'onExported' },
            { subscribe: 'exporting', emit: 'onExporting' },
            { subscribe: 'fileSaving', emit: 'onFileSaving' },
            { subscribe: 'incidentOccurred', emit: 'onIncidentOccurred' },
            { subscribe: 'initialized', emit: 'onInitialized' },
            { subscribe: 'optionChanged', emit: 'onOptionChanged' },
            { subscribe: 'tooltipHidden', emit: 'onTooltipHidden' },
            { subscribe: 'tooltipShown', emit: 'onTooltipShown' },
            { emit: 'animationChange' },
            { emit: 'centerTemplateChange' },
            { emit: 'containerBackgroundColorChange' },
            { emit: 'disabledChange' },
            { emit: 'elementAttrChange' },
            { emit: 'encodeHtmlChange' },
            { emit: 'exportChange' },
            { emit: 'geometryChange' },
            { emit: 'loadingIndicatorChange' },
            { emit: 'marginChange' },
            { emit: 'pathModifiedChange' },
            { emit: 'rangeContainerChange' },
            { emit: 'redrawOnResizeChange' },
            { emit: 'rtlEnabledChange' },
            { emit: 'scaleChange' },
            { emit: 'sizeChange' },
            { emit: 'subvalueIndicatorChange' },
            { emit: 'subvaluesChange' },
            { emit: 'themeChange' },
            { emit: 'titleChange' },
            { emit: 'tooltipChange' },
            { emit: 'valueChange' },
            { emit: 'valueIndicatorChange' }
        ]);
        this._idh.setHost(this);
        optionHost.setHost(this);
    }
    _createInstance(element, options) {
        return new DxCircularGauge(element, options);
    }
    ngOnDestroy() {
        this._destroyWidget();
    }
    ngOnChanges(changes) {
        super.ngOnChanges(changes);
        this.setupChanges('subvalues', changes);
    }
    setupChanges(prop, changes) {
        if (!(prop in this._optionsToUpdate)) {
            this._idh.setup(prop, changes);
        }
    }
    ngDoCheck() {
        this._idh.doCheck('subvalues');
        this._watcherHelper.checkWatchers();
        super.ngDoCheck();
        super.clearChangedOptions();
    }
    _setOption(name, value) {
        let isSetup = this._idh.setupSingle(name, value);
        let isChanged = this._idh.getChanges(name, value) !== null;
        if (isSetup || isChanged) {
            super._setOption(name, value);
        }
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxCircularGaugeComponent, deps: [{ token: i0.ElementRef }, { token: i0.NgZone }, { token: i1.DxTemplateHost }, { token: i1.WatcherHelper }, { token: i1.IterableDifferHelper }, { token: i1.NestedOptionHost }, { token: i0.TransferState }, { token: PLATFORM_ID }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxCircularGaugeComponent, isStandalone: true, selector: "dx-circular-gauge", inputs: { animation: "animation", centerTemplate: "centerTemplate", containerBackgroundColor: "containerBackgroundColor", disabled: "disabled", elementAttr: "elementAttr", encodeHtml: "encodeHtml", export: "export", geometry: "geometry", loadingIndicator: "loadingIndicator", margin: "margin", pathModified: "pathModified", rangeContainer: "rangeContainer", redrawOnResize: "redrawOnResize", rtlEnabled: "rtlEnabled", scale: "scale", size: "size", subvalueIndicator: "subvalueIndicator", subvalues: "subvalues", theme: "theme", title: "title", tooltip: "tooltip", value: "value", valueIndicator: "valueIndicator" }, outputs: { onDisposing: "onDisposing", onDrawn: "onDrawn", onExported: "onExported", onExporting: "onExporting", onFileSaving: "onFileSaving", onIncidentOccurred: "onIncidentOccurred", onInitialized: "onInitialized", onOptionChanged: "onOptionChanged", onTooltipHidden: "onTooltipHidden", onTooltipShown: "onTooltipShown", animationChange: "animationChange", centerTemplateChange: "centerTemplateChange", containerBackgroundColorChange: "containerBackgroundColorChange", disabledChange: "disabledChange", elementAttrChange: "elementAttrChange", encodeHtmlChange: "encodeHtmlChange", exportChange: "exportChange", geometryChange: "geometryChange", loadingIndicatorChange: "loadingIndicatorChange", marginChange: "marginChange", pathModifiedChange: "pathModifiedChange", rangeContainerChange: "rangeContainerChange", redrawOnResizeChange: "redrawOnResizeChange", rtlEnabledChange: "rtlEnabledChange", scaleChange: "scaleChange", sizeChange: "sizeChange", subvalueIndicatorChange: "subvalueIndicatorChange", subvaluesChange: "subvaluesChange", themeChange: "themeChange", titleChange: "titleChange", tooltipChange: "tooltipChange", valueChange: "valueChange", valueIndicatorChange: "valueIndicatorChange" }, host: { attributes: { "ngSkipHydration": "true" } }, providers: [
            DxTemplateHost,
            WatcherHelper,
            NestedOptionHost,
            IterableDifferHelper
        ], queries: [{ propertyName: "_rangesContentChildren", predicate: PROPERTY_TOKEN_ranges }], usesInheritance: true, usesOnChanges: true, ngImport: i0, template: '', isInline: true, styles: [":host{display:block}\n"], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxCircularGaugeComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dx-circular-gauge', template: '', host: { ngSkipHydration: 'true' }, imports: [DxIntegrationModule], providers: [
                        DxTemplateHost,
                        WatcherHelper,
                        NestedOptionHost,
                        IterableDifferHelper
                    ], styles: [":host{display:block}\n"] }]
        }], ctorParameters: () => [{ type: i0.ElementRef }, { type: i0.NgZone }, { type: i1.DxTemplateHost }, { type: i1.WatcherHelper }, { type: i1.IterableDifferHelper }, { type: i1.NestedOptionHost }, { type: i0.TransferState }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [PLATFORM_ID]
                }] }], propDecorators: { _rangesContentChildren: [{
                type: ContentChildren,
                args: [PROPERTY_TOKEN_ranges]
            }], animation: [{
                type: Input
            }], centerTemplate: [{
                type: Input
            }], containerBackgroundColor: [{
                type: Input
            }], disabled: [{
                type: Input
            }], elementAttr: [{
                type: Input
            }], encodeHtml: [{
                type: Input
            }], export: [{
                type: Input
            }], geometry: [{
                type: Input
            }], loadingIndicator: [{
                type: Input
            }], margin: [{
                type: Input
            }], pathModified: [{
                type: Input
            }], rangeContainer: [{
                type: Input
            }], redrawOnResize: [{
                type: Input
            }], rtlEnabled: [{
                type: Input
            }], scale: [{
                type: Input
            }], size: [{
                type: Input
            }], subvalueIndicator: [{
                type: Input
            }], subvalues: [{
                type: Input
            }], theme: [{
                type: Input
            }], title: [{
                type: Input
            }], tooltip: [{
                type: Input
            }], value: [{
                type: Input
            }], valueIndicator: [{
                type: Input
            }], onDisposing: [{
                type: Output
            }], onDrawn: [{
                type: Output
            }], onExported: [{
                type: Output
            }], onExporting: [{
                type: Output
            }], onFileSaving: [{
                type: Output
            }], onIncidentOccurred: [{
                type: Output
            }], onInitialized: [{
                type: Output
            }], onOptionChanged: [{
                type: Output
            }], onTooltipHidden: [{
                type: Output
            }], onTooltipShown: [{
                type: Output
            }], animationChange: [{
                type: Output
            }], centerTemplateChange: [{
                type: Output
            }], containerBackgroundColorChange: [{
                type: Output
            }], disabledChange: [{
                type: Output
            }], elementAttrChange: [{
                type: Output
            }], encodeHtmlChange: [{
                type: Output
            }], exportChange: [{
                type: Output
            }], geometryChange: [{
                type: Output
            }], loadingIndicatorChange: [{
                type: Output
            }], marginChange: [{
                type: Output
            }], pathModifiedChange: [{
                type: Output
            }], rangeContainerChange: [{
                type: Output
            }], redrawOnResizeChange: [{
                type: Output
            }], rtlEnabledChange: [{
                type: Output
            }], scaleChange: [{
                type: Output
            }], sizeChange: [{
                type: Output
            }], subvalueIndicatorChange: [{
                type: Output
            }], subvaluesChange: [{
                type: Output
            }], themeChange: [{
                type: Output
            }], titleChange: [{
                type: Output
            }], tooltipChange: [{
                type: Output
            }], valueChange: [{
                type: Output
            }], valueIndicatorChange: [{
                type: Output
            }] } });
class DxCircularGaugeModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxCircularGaugeModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxCircularGaugeModule, imports: [DxCircularGaugeComponent, DxoAnimationModule,
            DxoExportModule,
            DxoGeometryModule,
            DxoLoadingIndicatorModule,
            DxoFontModule,
            DxoMarginModule,
            DxoRangeContainerModule,
            DxoBackgroundColorModule,
            DxiRangeModule,
            DxoColorModule,
            DxoScaleModule,
            DxoLabelModule,
            DxoFormatModule,
            DxoMinorTickModule,
            DxoTickModule,
            DxoSizeModule,
            DxoSubvalueIndicatorModule,
            DxoTextModule,
            DxoTitleModule,
            DxoSubtitleModule,
            DxoTooltipModule,
            DxoBorderModule,
            DxoShadowModule,
            DxoValueIndicatorModule,
            DxoCircularGaugeAnimationModule,
            DxoCircularGaugeBackgroundColorModule,
            DxoCircularGaugeBorderModule,
            DxoCircularGaugeColorModule,
            DxoCircularGaugeExportModule,
            DxoCircularGaugeFontModule,
            DxoCircularGaugeFormatModule,
            DxoCircularGaugeGeometryModule,
            DxoCircularGaugeLabelModule,
            DxoCircularGaugeLoadingIndicatorModule,
            DxoCircularGaugeMarginModule,
            DxoCircularGaugeMinorTickModule,
            DxiCircularGaugeRangeModule,
            DxoCircularGaugeRangeContainerModule,
            DxoCircularGaugeScaleModule,
            DxoCircularGaugeShadowModule,
            DxoCircularGaugeSizeModule,
            DxoCircularGaugeSubtitleModule,
            DxoCircularGaugeSubvalueIndicatorModule,
            DxoCircularGaugeTextModule,
            DxoCircularGaugeTickModule,
            DxoCircularGaugeTitleModule,
            DxoCircularGaugeTooltipModule,
            DxoCircularGaugeValueIndicatorModule,
            DxIntegrationModule,
            DxTemplateModule], exports: [DxCircularGaugeComponent, DxoAnimationModule,
            DxoExportModule,
            DxoGeometryModule,
            DxoLoadingIndicatorModule,
            DxoFontModule,
            DxoMarginModule,
            DxoRangeContainerModule,
            DxoBackgroundColorModule,
            DxiRangeModule,
            DxoColorModule,
            DxoScaleModule,
            DxoLabelModule,
            DxoFormatModule,
            DxoMinorTickModule,
            DxoTickModule,
            DxoSizeModule,
            DxoSubvalueIndicatorModule,
            DxoTextModule,
            DxoTitleModule,
            DxoSubtitleModule,
            DxoTooltipModule,
            DxoBorderModule,
            DxoShadowModule,
            DxoValueIndicatorModule,
            DxoCircularGaugeAnimationModule,
            DxoCircularGaugeBackgroundColorModule,
            DxoCircularGaugeBorderModule,
            DxoCircularGaugeColorModule,
            DxoCircularGaugeExportModule,
            DxoCircularGaugeFontModule,
            DxoCircularGaugeFormatModule,
            DxoCircularGaugeGeometryModule,
            DxoCircularGaugeLabelModule,
            DxoCircularGaugeLoadingIndicatorModule,
            DxoCircularGaugeMarginModule,
            DxoCircularGaugeMinorTickModule,
            DxiCircularGaugeRangeModule,
            DxoCircularGaugeRangeContainerModule,
            DxoCircularGaugeScaleModule,
            DxoCircularGaugeShadowModule,
            DxoCircularGaugeSizeModule,
            DxoCircularGaugeSubtitleModule,
            DxoCircularGaugeSubvalueIndicatorModule,
            DxoCircularGaugeTextModule,
            DxoCircularGaugeTickModule,
            DxoCircularGaugeTitleModule,
            DxoCircularGaugeTooltipModule,
            DxoCircularGaugeValueIndicatorModule,
            DxTemplateModule] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxCircularGaugeModule, imports: [DxCircularGaugeComponent,
            DxoAnimationModule,
            DxoExportModule,
            DxoGeometryModule,
            DxoLoadingIndicatorModule,
            DxoFontModule,
            DxoMarginModule,
            DxoRangeContainerModule,
            DxoBackgroundColorModule,
            DxiRangeModule,
            DxoColorModule,
            DxoScaleModule,
            DxoLabelModule,
            DxoFormatModule,
            DxoMinorTickModule,
            DxoTickModule,
            DxoSizeModule,
            DxoSubvalueIndicatorModule,
            DxoTextModule,
            DxoTitleModule,
            DxoSubtitleModule,
            DxoTooltipModule,
            DxoBorderModule,
            DxoShadowModule,
            DxoValueIndicatorModule,
            DxoCircularGaugeAnimationModule,
            DxoCircularGaugeBackgroundColorModule,
            DxoCircularGaugeBorderModule,
            DxoCircularGaugeColorModule,
            DxoCircularGaugeExportModule,
            DxoCircularGaugeFontModule,
            DxoCircularGaugeFormatModule,
            DxoCircularGaugeGeometryModule,
            DxoCircularGaugeLabelModule,
            DxoCircularGaugeLoadingIndicatorModule,
            DxoCircularGaugeMarginModule,
            DxoCircularGaugeMinorTickModule,
            DxiCircularGaugeRangeModule,
            DxoCircularGaugeRangeContainerModule,
            DxoCircularGaugeScaleModule,
            DxoCircularGaugeShadowModule,
            DxoCircularGaugeSizeModule,
            DxoCircularGaugeSubtitleModule,
            DxoCircularGaugeSubvalueIndicatorModule,
            DxoCircularGaugeTextModule,
            DxoCircularGaugeTickModule,
            DxoCircularGaugeTitleModule,
            DxoCircularGaugeTooltipModule,
            DxoCircularGaugeValueIndicatorModule,
            DxIntegrationModule,
            DxTemplateModule, DxoAnimationModule,
            DxoExportModule,
            DxoGeometryModule,
            DxoLoadingIndicatorModule,
            DxoFontModule,
            DxoMarginModule,
            DxoRangeContainerModule,
            DxoBackgroundColorModule,
            DxiRangeModule,
            DxoColorModule,
            DxoScaleModule,
            DxoLabelModule,
            DxoFormatModule,
            DxoMinorTickModule,
            DxoTickModule,
            DxoSizeModule,
            DxoSubvalueIndicatorModule,
            DxoTextModule,
            DxoTitleModule,
            DxoSubtitleModule,
            DxoTooltipModule,
            DxoBorderModule,
            DxoShadowModule,
            DxoValueIndicatorModule,
            DxoCircularGaugeAnimationModule,
            DxoCircularGaugeBackgroundColorModule,
            DxoCircularGaugeBorderModule,
            DxoCircularGaugeColorModule,
            DxoCircularGaugeExportModule,
            DxoCircularGaugeFontModule,
            DxoCircularGaugeFormatModule,
            DxoCircularGaugeGeometryModule,
            DxoCircularGaugeLabelModule,
            DxoCircularGaugeLoadingIndicatorModule,
            DxoCircularGaugeMarginModule,
            DxoCircularGaugeMinorTickModule,
            DxiCircularGaugeRangeModule,
            DxoCircularGaugeRangeContainerModule,
            DxoCircularGaugeScaleModule,
            DxoCircularGaugeShadowModule,
            DxoCircularGaugeSizeModule,
            DxoCircularGaugeSubtitleModule,
            DxoCircularGaugeSubvalueIndicatorModule,
            DxoCircularGaugeTextModule,
            DxoCircularGaugeTickModule,
            DxoCircularGaugeTitleModule,
            DxoCircularGaugeTooltipModule,
            DxoCircularGaugeValueIndicatorModule,
            DxTemplateModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxCircularGaugeModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxCircularGaugeComponent,
                        DxoAnimationModule,
                        DxoExportModule,
                        DxoGeometryModule,
                        DxoLoadingIndicatorModule,
                        DxoFontModule,
                        DxoMarginModule,
                        DxoRangeContainerModule,
                        DxoBackgroundColorModule,
                        DxiRangeModule,
                        DxoColorModule,
                        DxoScaleModule,
                        DxoLabelModule,
                        DxoFormatModule,
                        DxoMinorTickModule,
                        DxoTickModule,
                        DxoSizeModule,
                        DxoSubvalueIndicatorModule,
                        DxoTextModule,
                        DxoTitleModule,
                        DxoSubtitleModule,
                        DxoTooltipModule,
                        DxoBorderModule,
                        DxoShadowModule,
                        DxoValueIndicatorModule,
                        DxoCircularGaugeAnimationModule,
                        DxoCircularGaugeBackgroundColorModule,
                        DxoCircularGaugeBorderModule,
                        DxoCircularGaugeColorModule,
                        DxoCircularGaugeExportModule,
                        DxoCircularGaugeFontModule,
                        DxoCircularGaugeFormatModule,
                        DxoCircularGaugeGeometryModule,
                        DxoCircularGaugeLabelModule,
                        DxoCircularGaugeLoadingIndicatorModule,
                        DxoCircularGaugeMarginModule,
                        DxoCircularGaugeMinorTickModule,
                        DxiCircularGaugeRangeModule,
                        DxoCircularGaugeRangeContainerModule,
                        DxoCircularGaugeScaleModule,
                        DxoCircularGaugeShadowModule,
                        DxoCircularGaugeSizeModule,
                        DxoCircularGaugeSubtitleModule,
                        DxoCircularGaugeSubvalueIndicatorModule,
                        DxoCircularGaugeTextModule,
                        DxoCircularGaugeTickModule,
                        DxoCircularGaugeTitleModule,
                        DxoCircularGaugeTooltipModule,
                        DxoCircularGaugeValueIndicatorModule,
                        DxIntegrationModule,
                        DxTemplateModule
                    ],
                    exports: [
                        DxCircularGaugeComponent,
                        DxoAnimationModule,
                        DxoExportModule,
                        DxoGeometryModule,
                        DxoLoadingIndicatorModule,
                        DxoFontModule,
                        DxoMarginModule,
                        DxoRangeContainerModule,
                        DxoBackgroundColorModule,
                        DxiRangeModule,
                        DxoColorModule,
                        DxoScaleModule,
                        DxoLabelModule,
                        DxoFormatModule,
                        DxoMinorTickModule,
                        DxoTickModule,
                        DxoSizeModule,
                        DxoSubvalueIndicatorModule,
                        DxoTextModule,
                        DxoTitleModule,
                        DxoSubtitleModule,
                        DxoTooltipModule,
                        DxoBorderModule,
                        DxoShadowModule,
                        DxoValueIndicatorModule,
                        DxoCircularGaugeAnimationModule,
                        DxoCircularGaugeBackgroundColorModule,
                        DxoCircularGaugeBorderModule,
                        DxoCircularGaugeColorModule,
                        DxoCircularGaugeExportModule,
                        DxoCircularGaugeFontModule,
                        DxoCircularGaugeFormatModule,
                        DxoCircularGaugeGeometryModule,
                        DxoCircularGaugeLabelModule,
                        DxoCircularGaugeLoadingIndicatorModule,
                        DxoCircularGaugeMarginModule,
                        DxoCircularGaugeMinorTickModule,
                        DxiCircularGaugeRangeModule,
                        DxoCircularGaugeRangeContainerModule,
                        DxoCircularGaugeScaleModule,
                        DxoCircularGaugeShadowModule,
                        DxoCircularGaugeSizeModule,
                        DxoCircularGaugeSubtitleModule,
                        DxoCircularGaugeSubvalueIndicatorModule,
                        DxoCircularGaugeTextModule,
                        DxoCircularGaugeTickModule,
                        DxoCircularGaugeTitleModule,
                        DxoCircularGaugeTooltipModule,
                        DxoCircularGaugeValueIndicatorModule,
                        DxTemplateModule
                    ]
                }]
        }] });

/**
 * Generated bundle index. Do not edit.
 */

export { DxCircularGaugeComponent, DxCircularGaugeModule };
//# sourceMappingURL=devextreme-angular-ui-circular-gauge.mjs.map
