import * as i0 from '@angular/core';
import { PLATFORM_ID, Output, Input, ContentChildren, Inject, Component, NgModule } from '@angular/core';
import DxDataGrid from 'devextreme/ui/data_grid';
import * as i1 from 'devextreme-angular/core';
import { DxComponent, DxIntegrationModule, DxTemplateHost, WatcherHelper, NestedOptionHost, IterableDifferHelper, DxTemplateModule } from 'devextreme-angular/core';
import { DxoColumnChooserModule, DxoPositionModule, DxoAtModule, DxoBoundaryOffsetModule, DxoCollisionModule, DxoMyModule, DxoOffsetModule, DxoSearchModule, DxoSelectionModule, DxoColumnFixingModule, DxoIconsModule, DxoTextsModule, DxiColumnModule, DxiButtonModule, DxoLookupModule, DxoFormatModule, DxoFormItemModule, DxoLabelModule, DxiValidationRuleModule, DxoHeaderFilterModule, DxoEditingModule, DxiChangeModule, DxoFormModule, DxoColCountByScreenModule, DxiItemModule, DxoTabPanelOptionsModule, DxiTabModule, DxoButtonOptionsModule, DxoPopupModule, DxoAnimationModule, DxoHideModule, DxoFromModule, DxoToModule, DxoShowModule, DxoExportModule, DxoFilterBuilderModule, DxiCustomOperationModule, DxiFieldModule, DxoFilterOperationDescriptionsModule, DxoGroupOperationDescriptionsModule, DxoFilterBuilderPopupModule, DxoFilterPanelModule, DxoFilterRowModule, DxoOperationDescriptionsModule, DxoGroupingModule, DxoGroupPanelModule, DxoKeyboardNavigationModule, DxoLoadPanelModule, DxoMasterDetailModule, DxoPagerModule, DxoPagingModule, DxoRemoteOperationsModule, DxoRowDraggingModule, DxoCursorOffsetModule, DxoScrollingModule, DxoSearchPanelModule, DxiSortByGroupSummaryInfoModule, DxoSortingModule, DxoStateStoringModule, DxoSummaryModule, DxiGroupItemModule, DxoValueFormatModule, DxiTotalItemModule, DxoToolbarModule } from 'devextreme-angular/ui/nested';
import { DxoDataGridAIModule, DxoDataGridAIAssistantModule, DxoDataGridAIOptionsModule, DxoDataGridAnimationModule, DxiDataGridAsyncRuleModule, DxoDataGridAtModule, DxoDataGridBoundaryOffsetModule, DxiDataGridButtonModule, DxiDataGridButtonItemModule, DxoDataGridButtonOptionsModule, DxiDataGridChangeModule, DxoDataGridColCountByScreenModule, DxoDataGridCollisionModule, DxiDataGridColumnModule, DxiDataGridColumnButtonModule, DxoDataGridColumnChooserModule, DxoDataGridColumnChooserSearchModule, DxoDataGridColumnChooserSelectionModule, DxoDataGridColumnFixingModule, DxoDataGridColumnFixingTextsModule, DxoDataGridColumnHeaderFilterModule, DxoDataGridColumnHeaderFilterSearchModule, DxoDataGridColumnLookupModule, DxiDataGridCompareRuleModule, DxoDataGridCursorOffsetModule, DxiDataGridCustomOperationModule, DxiDataGridCustomRuleModule, DxoDataGridDataGridHeaderFilterModule, DxoDataGridDataGridHeaderFilterSearchModule, DxoDataGridDataGridHeaderFilterTextsModule, DxoDataGridDataGridSelectionModule, DxiDataGridDataGridToolbarItemModule, DxoDataGridEditingModule, DxoDataGridEditingTextsModule, DxoDataGridEditorOptionsModule, DxiDataGridEditorOptionsButtonModule, DxiDataGridEmailRuleModule, DxiDataGridEmptyItemModule, DxoDataGridExportModule, DxoDataGridExportTextsModule, DxiDataGridFieldModule, DxoDataGridFieldLookupModule, DxoDataGridFilterBuilderModule, DxoDataGridFilterBuilderPopupModule, DxoDataGridFilterOperationDescriptionsModule, DxoDataGridFilterPanelModule, DxoDataGridFilterPanelTextsModule, DxoDataGridFilterRowModule, DxoDataGridFormModule, DxoDataGridFormatModule, DxiDataGridFormGroupItemModule, DxoDataGridFormItemModule, DxoDataGridFromModule, DxoDataGridGroupingModule, DxoDataGridGroupingTextsModule, DxiDataGridGroupItemModule, DxoDataGridGroupOperationDescriptionsModule, DxoDataGridGroupPanelModule, DxoDataGridHeaderFilterModule, DxoDataGridHideModule, DxoDataGridIconsModule, DxoDataGridIndicatorOptionsModule, DxiDataGridItemModule, DxoDataGridKeyboardNavigationModule, DxoDataGridLabelModule, DxoDataGridLoadPanelModule, DxoDataGridLookupModule, DxoDataGridMasterDetailModule, DxoDataGridMyModule, DxiDataGridNumericRuleModule, DxoDataGridOffsetModule, DxoDataGridOperationDescriptionsModule, DxoDataGridOptionsModule, DxoDataGridPagerModule, DxoDataGridPagingModule, DxiDataGridPatternRuleModule, DxoDataGridPopupModule, DxoDataGridPositionModule, DxiDataGridRangeRuleModule, DxoDataGridRemoteOperationsModule, DxiDataGridRequiredRuleModule, DxoDataGridRowDraggingModule, DxoDataGridScrollingModule, DxoDataGridSearchModule, DxoDataGridSearchPanelModule, DxoDataGridSelectionModule, DxoDataGridShowModule, DxiDataGridSimpleItemModule, DxiDataGridSortByGroupSummaryInfoModule, DxoDataGridSortingModule, DxoDataGridStateStoringModule, DxiDataGridStringLengthRuleModule, DxoDataGridSummaryModule, DxoDataGridSummaryTextsModule, DxiDataGridTabModule, DxiDataGridTabbedItemModule, DxoDataGridTabPanelOptionsModule, DxiDataGridTabPanelOptionsItemModule, DxoDataGridTextsModule, DxoDataGridToModule, DxoDataGridToolbarModule, DxiDataGridToolbarItemModule, DxiDataGridTotalItemModule, DxiDataGridValidationRuleModule, DxoDataGridValueFormatModule } from 'devextreme-angular/ui/data-grid/nested';
export * from 'devextreme-angular/ui/data-grid/nested';
import { PROPERTY_TOKEN_validationRules, PROPERTY_TOKEN_buttons, PROPERTY_TOKEN_items, PROPERTY_TOKEN_changes, PROPERTY_TOKEN_columns, PROPERTY_TOKEN_customOperations, PROPERTY_TOKEN_fields, PROPERTY_TOKEN_groupItems, PROPERTY_TOKEN_sortByGroupSummaryInfo, PROPERTY_TOKEN_tabs, PROPERTY_TOKEN_toolbarItems, PROPERTY_TOKEN_totalItems } from 'devextreme-angular/core/tokens';

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
/**
 * [descr:dxDataGrid]

 */
class DxDataGridComponent extends DxComponent {
    set _validationRulesContentChildren(value) {
        this.setChildren('validationRules', value);
    }
    set _buttonsContentChildren(value) {
        this.setChildren('buttons', value);
    }
    set _itemsContentChildren(value) {
        this.setChildren('items', value);
    }
    set _changesContentChildren(value) {
        this.setChildren('changes', value);
    }
    set _columnsContentChildren(value) {
        this.setChildren('columns', value);
    }
    set _customOperationsContentChildren(value) {
        this.setChildren('customOperations', value);
    }
    set _fieldsContentChildren(value) {
        this.setChildren('fields', value);
    }
    set _groupItemsContentChildren(value) {
        this.setChildren('groupItems', value);
    }
    set _sortByGroupSummaryInfoContentChildren(value) {
        this.setChildren('sortByGroupSummaryInfo', value);
    }
    set _tabsContentChildren(value) {
        this.setChildren('tabs', value);
    }
    set _toolbarItemsContentChildren(value) {
        this.setChildren('toolbarItems', value);
    }
    set _totalItemsContentChildren(value) {
        this.setChildren('totalItems', value);
    }
    /**
     * [descr:WidgetOptions.accessKey]
    
     */
    get accessKey() {
        return this._getOption('accessKey');
    }
    set accessKey(value) {
        this._setOption('accessKey', value);
    }
    /**
     * [descr:WidgetOptions.activeStateEnabled]
    
     */
    get activeStateEnabled() {
        return this._getOption('activeStateEnabled');
    }
    set activeStateEnabled(value) {
        this._setOption('activeStateEnabled', value);
    }
    /**
     * [descr:dxDataGridOptions.aiAssistant]
    
     */
    get aiAssistant() {
        return this._getOption('aiAssistant');
    }
    set aiAssistant(value) {
        this._setOption('aiAssistant', value);
    }
    /**
     * [descr:GridBaseOptions.aiIntegration]
    
     */
    get aiIntegration() {
        return this._getOption('aiIntegration');
    }
    set aiIntegration(value) {
        this._setOption('aiIntegration', value);
    }
    /**
     * [descr:GridBaseOptions.allowColumnReordering]
    
     */
    get allowColumnReordering() {
        return this._getOption('allowColumnReordering');
    }
    set allowColumnReordering(value) {
        this._setOption('allowColumnReordering', value);
    }
    /**
     * [descr:GridBaseOptions.allowColumnResizing]
    
     */
    get allowColumnResizing() {
        return this._getOption('allowColumnResizing');
    }
    set allowColumnResizing(value) {
        this._setOption('allowColumnResizing', value);
    }
    /**
     * [descr:GridBaseOptions.autoNavigateToFocusedRow]
    
     */
    get autoNavigateToFocusedRow() {
        return this._getOption('autoNavigateToFocusedRow');
    }
    set autoNavigateToFocusedRow(value) {
        this._setOption('autoNavigateToFocusedRow', value);
    }
    /**
     * [descr:GridBaseOptions.cacheEnabled]
    
     */
    get cacheEnabled() {
        return this._getOption('cacheEnabled');
    }
    set cacheEnabled(value) {
        this._setOption('cacheEnabled', value);
    }
    /**
     * [descr:GridBaseOptions.cellHintEnabled]
    
     */
    get cellHintEnabled() {
        return this._getOption('cellHintEnabled');
    }
    set cellHintEnabled(value) {
        this._setOption('cellHintEnabled', value);
    }
    /**
     * [descr:GridBaseOptions.columnAutoWidth]
    
     */
    get columnAutoWidth() {
        return this._getOption('columnAutoWidth');
    }
    set columnAutoWidth(value) {
        this._setOption('columnAutoWidth', value);
    }
    /**
     * [descr:GridBaseOptions.columnChooser]
    
     */
    get columnChooser() {
        return this._getOption('columnChooser');
    }
    set columnChooser(value) {
        this._setOption('columnChooser', value);
    }
    /**
     * [descr:GridBaseOptions.columnFixing]
    
     */
    get columnFixing() {
        return this._getOption('columnFixing');
    }
    set columnFixing(value) {
        this._setOption('columnFixing', value);
    }
    /**
     * [descr:GridBaseOptions.columnHidingEnabled]
    
     */
    get columnHidingEnabled() {
        return this._getOption('columnHidingEnabled');
    }
    set columnHidingEnabled(value) {
        this._setOption('columnHidingEnabled', value);
    }
    /**
     * [descr:GridBaseOptions.columnMinWidth]
    
     */
    get columnMinWidth() {
        return this._getOption('columnMinWidth');
    }
    set columnMinWidth(value) {
        this._setOption('columnMinWidth', value);
    }
    /**
     * [descr:GridBaseOptions.columnResizingMode]
    
     */
    get columnResizingMode() {
        return this._getOption('columnResizingMode');
    }
    set columnResizingMode(value) {
        this._setOption('columnResizingMode', value);
    }
    /**
     * [descr:dxDataGridOptions.columns]
    
     */
    get columns() {
        return this._getOption('columns');
    }
    set columns(value) {
        this._setOption('columns', value);
    }
    /**
     * [descr:GridBaseOptions.columnWidth]
    
     */
    get columnWidth() {
        return this._getOption('columnWidth');
    }
    set columnWidth(value) {
        this._setOption('columnWidth', value);
    }
    /**
     * [descr:dxDataGridOptions.customizeColumns]
    
     */
    get customizeColumns() {
        return this._getOption('customizeColumns');
    }
    set customizeColumns(value) {
        this._setOption('customizeColumns', value);
    }
    /**
     * [descr:dxDataGridOptions.dataRowTemplate]
    
     */
    get dataRowTemplate() {
        return this._getOption('dataRowTemplate');
    }
    set dataRowTemplate(value) {
        this._setOption('dataRowTemplate', value);
    }
    /**
     * [descr:GridBaseOptions.dataSource]
    
     */
    get dataSource() {
        return this._getOption('dataSource');
    }
    set dataSource(value) {
        this._setOption('dataSource', value);
    }
    /**
     * [descr:GridBaseOptions.dateSerializationFormat]
    
     */
    get dateSerializationFormat() {
        return this._getOption('dateSerializationFormat');
    }
    set dateSerializationFormat(value) {
        this._setOption('dateSerializationFormat', value);
    }
    /**
     * [descr:WidgetOptions.disabled]
    
     */
    get disabled() {
        return this._getOption('disabled');
    }
    set disabled(value) {
        this._setOption('disabled', value);
    }
    /**
     * [descr:dxDataGridOptions.editing]
    
     */
    get editing() {
        return this._getOption('editing');
    }
    set editing(value) {
        this._setOption('editing', value);
    }
    /**
     * [descr:DOMComponentOptions.elementAttr]
    
     */
    get elementAttr() {
        return this._getOption('elementAttr');
    }
    set elementAttr(value) {
        this._setOption('elementAttr', value);
    }
    /**
     * [descr:GridBaseOptions.errorRowEnabled]
    
     */
    get errorRowEnabled() {
        return this._getOption('errorRowEnabled');
    }
    set errorRowEnabled(value) {
        this._setOption('errorRowEnabled', value);
    }
    /**
     * [descr:dxDataGridOptions.export]
    
     */
    get export() {
        return this._getOption('export');
    }
    set export(value) {
        this._setOption('export', value);
    }
    /**
     * [descr:GridBaseOptions.filterBuilder]
    
     */
    get filterBuilder() {
        return this._getOption('filterBuilder');
    }
    set filterBuilder(value) {
        this._setOption('filterBuilder', value);
    }
    /**
     * [descr:GridBaseOptions.filterBuilderPopup]
    
     */
    get filterBuilderPopup() {
        return this._getOption('filterBuilderPopup');
    }
    set filterBuilderPopup(value) {
        this._setOption('filterBuilderPopup', value);
    }
    /**
     * [descr:GridBaseOptions.filterPanel]
    
     */
    get filterPanel() {
        return this._getOption('filterPanel');
    }
    set filterPanel(value) {
        this._setOption('filterPanel', value);
    }
    /**
     * [descr:GridBaseOptions.filterRow]
    
     */
    get filterRow() {
        return this._getOption('filterRow');
    }
    set filterRow(value) {
        this._setOption('filterRow', value);
    }
    /**
     * [descr:GridBaseOptions.filterSyncEnabled]
    
     */
    get filterSyncEnabled() {
        return this._getOption('filterSyncEnabled');
    }
    set filterSyncEnabled(value) {
        this._setOption('filterSyncEnabled', value);
    }
    /**
     * [descr:GridBaseOptions.filterValue]
    
     */
    get filterValue() {
        return this._getOption('filterValue');
    }
    set filterValue(value) {
        this._setOption('filterValue', value);
    }
    /**
     * [descr:GridBaseOptions.focusedColumnIndex]
    
     */
    get focusedColumnIndex() {
        return this._getOption('focusedColumnIndex');
    }
    set focusedColumnIndex(value) {
        this._setOption('focusedColumnIndex', value);
    }
    /**
     * [descr:GridBaseOptions.focusedRowEnabled]
    
     */
    get focusedRowEnabled() {
        return this._getOption('focusedRowEnabled');
    }
    set focusedRowEnabled(value) {
        this._setOption('focusedRowEnabled', value);
    }
    /**
     * [descr:GridBaseOptions.focusedRowIndex]
    
     */
    get focusedRowIndex() {
        return this._getOption('focusedRowIndex');
    }
    set focusedRowIndex(value) {
        this._setOption('focusedRowIndex', value);
    }
    /**
     * [descr:GridBaseOptions.focusedRowKey]
    
     */
    get focusedRowKey() {
        return this._getOption('focusedRowKey');
    }
    set focusedRowKey(value) {
        this._setOption('focusedRowKey', value);
    }
    /**
     * [descr:dxDataGridOptions.grouping]
    
     */
    get grouping() {
        return this._getOption('grouping');
    }
    set grouping(value) {
        this._setOption('grouping', value);
    }
    /**
     * [descr:dxDataGridOptions.groupPanel]
    
     */
    get groupPanel() {
        return this._getOption('groupPanel');
    }
    set groupPanel(value) {
        this._setOption('groupPanel', value);
    }
    /**
     * [descr:GridBaseOptions.headerFilter]
    
     */
    get headerFilter() {
        return this._getOption('headerFilter');
    }
    set headerFilter(value) {
        this._setOption('headerFilter', value);
    }
    /**
     * [descr:DOMComponentOptions.height]
    
     */
    get height() {
        return this._getOption('height');
    }
    set height(value) {
        this._setOption('height', value);
    }
    /**
     * [descr:GridBaseOptions.highlightChanges]
    
     */
    get highlightChanges() {
        return this._getOption('highlightChanges');
    }
    set highlightChanges(value) {
        this._setOption('highlightChanges', value);
    }
    /**
     * [descr:WidgetOptions.hint]
    
     */
    get hint() {
        return this._getOption('hint');
    }
    set hint(value) {
        this._setOption('hint', value);
    }
    /**
     * [descr:WidgetOptions.hoverStateEnabled]
    
     */
    get hoverStateEnabled() {
        return this._getOption('hoverStateEnabled');
    }
    set hoverStateEnabled(value) {
        this._setOption('hoverStateEnabled', value);
    }
    /**
     * [descr:GridBaseOptions.keyboardNavigation]
    
     */
    get keyboardNavigation() {
        return this._getOption('keyboardNavigation');
    }
    set keyboardNavigation(value) {
        this._setOption('keyboardNavigation', value);
    }
    /**
     * [descr:dxDataGridOptions.keyExpr]
    
     */
    get keyExpr() {
        return this._getOption('keyExpr');
    }
    set keyExpr(value) {
        this._setOption('keyExpr', value);
    }
    /**
     * [descr:GridBaseOptions.loadPanel]
    
     */
    get loadPanel() {
        return this._getOption('loadPanel');
    }
    set loadPanel(value) {
        this._setOption('loadPanel', value);
    }
    /**
     * [descr:dxDataGridOptions.masterDetail]
    
     */
    get masterDetail() {
        return this._getOption('masterDetail');
    }
    set masterDetail(value) {
        this._setOption('masterDetail', value);
    }
    /**
     * [descr:GridBaseOptions.noDataText]
    
     */
    get noDataText() {
        return this._getOption('noDataText');
    }
    set noDataText(value) {
        this._setOption('noDataText', value);
    }
    /**
     * [descr:GridBaseOptions.pager]
    
     */
    get pager() {
        return this._getOption('pager');
    }
    set pager(value) {
        this._setOption('pager', value);
    }
    /**
     * [descr:GridBaseOptions.paging]
    
     */
    get paging() {
        return this._getOption('paging');
    }
    set paging(value) {
        this._setOption('paging', value);
    }
    /**
     * [descr:dxDataGridOptions.remoteOperations]
    
     */
    get remoteOperations() {
        return this._getOption('remoteOperations');
    }
    set remoteOperations(value) {
        this._setOption('remoteOperations', value);
    }
    /**
     * [descr:GridBaseOptions.renderAsync]
    
     */
    get renderAsync() {
        return this._getOption('renderAsync');
    }
    set renderAsync(value) {
        this._setOption('renderAsync', value);
    }
    /**
     * [descr:GridBaseOptions.repaintChangesOnly]
    
     */
    get repaintChangesOnly() {
        return this._getOption('repaintChangesOnly');
    }
    set repaintChangesOnly(value) {
        this._setOption('repaintChangesOnly', value);
    }
    /**
     * [descr:GridBaseOptions.rowAlternationEnabled]
    
     */
    get rowAlternationEnabled() {
        return this._getOption('rowAlternationEnabled');
    }
    set rowAlternationEnabled(value) {
        this._setOption('rowAlternationEnabled', value);
    }
    /**
     * [descr:GridBaseOptions.rowDragging]
    
     */
    get rowDragging() {
        return this._getOption('rowDragging');
    }
    set rowDragging(value) {
        this._setOption('rowDragging', value);
    }
    /**
     * [descr:dxDataGridOptions.rowTemplate]
    
     * @deprecated [depNote:dxDataGridOptions.rowTemplate]
    
     */
    get rowTemplate() {
        return this._getOption('rowTemplate');
    }
    set rowTemplate(value) {
        this._setOption('rowTemplate', value);
    }
    /**
     * [descr:DOMComponentOptions.rtlEnabled]
    
     */
    get rtlEnabled() {
        return this._getOption('rtlEnabled');
    }
    set rtlEnabled(value) {
        this._setOption('rtlEnabled', value);
    }
    /**
     * [descr:dxDataGridOptions.scrolling]
    
     */
    get scrolling() {
        return this._getOption('scrolling');
    }
    set scrolling(value) {
        this._setOption('scrolling', value);
    }
    /**
     * [descr:GridBaseOptions.searchPanel]
    
     */
    get searchPanel() {
        return this._getOption('searchPanel');
    }
    set searchPanel(value) {
        this._setOption('searchPanel', value);
    }
    /**
     * [descr:GridBaseOptions.selectedRowKeys]
    
     */
    get selectedRowKeys() {
        return this._getOption('selectedRowKeys');
    }
    set selectedRowKeys(value) {
        this._setOption('selectedRowKeys', value);
    }
    /**
     * [descr:dxDataGridOptions.selection]
    
     */
    get selection() {
        return this._getOption('selection');
    }
    set selection(value) {
        this._setOption('selection', value);
    }
    /**
     * [descr:dxDataGridOptions.selectionFilter]
    
     */
    get selectionFilter() {
        return this._getOption('selectionFilter');
    }
    set selectionFilter(value) {
        this._setOption('selectionFilter', value);
    }
    /**
     * [descr:GridBaseOptions.showBorders]
    
     */
    get showBorders() {
        return this._getOption('showBorders');
    }
    set showBorders(value) {
        this._setOption('showBorders', value);
    }
    /**
     * [descr:GridBaseOptions.showColumnHeaders]
    
     */
    get showColumnHeaders() {
        return this._getOption('showColumnHeaders');
    }
    set showColumnHeaders(value) {
        this._setOption('showColumnHeaders', value);
    }
    /**
     * [descr:GridBaseOptions.showColumnLines]
    
     */
    get showColumnLines() {
        return this._getOption('showColumnLines');
    }
    set showColumnLines(value) {
        this._setOption('showColumnLines', value);
    }
    /**
     * [descr:GridBaseOptions.showRowLines]
    
     */
    get showRowLines() {
        return this._getOption('showRowLines');
    }
    set showRowLines(value) {
        this._setOption('showRowLines', value);
    }
    /**
     * [descr:dxDataGridOptions.sortByGroupSummaryInfo]
    
     */
    get sortByGroupSummaryInfo() {
        return this._getOption('sortByGroupSummaryInfo');
    }
    set sortByGroupSummaryInfo(value) {
        this._setOption('sortByGroupSummaryInfo', value);
    }
    /**
     * [descr:GridBaseOptions.sorting]
    
     */
    get sorting() {
        return this._getOption('sorting');
    }
    set sorting(value) {
        this._setOption('sorting', value);
    }
    /**
     * [descr:GridBaseOptions.stateStoring]
    
     */
    get stateStoring() {
        return this._getOption('stateStoring');
    }
    set stateStoring(value) {
        this._setOption('stateStoring', value);
    }
    /**
     * [descr:dxDataGridOptions.summary]
    
     */
    get summary() {
        return this._getOption('summary');
    }
    set summary(value) {
        this._setOption('summary', value);
    }
    /**
     * [descr:GridBaseOptions.syncLookupFilterValues]
    
     */
    get syncLookupFilterValues() {
        return this._getOption('syncLookupFilterValues');
    }
    set syncLookupFilterValues(value) {
        this._setOption('syncLookupFilterValues', value);
    }
    /**
     * [descr:WidgetOptions.tabIndex]
    
     */
    get tabIndex() {
        return this._getOption('tabIndex');
    }
    set tabIndex(value) {
        this._setOption('tabIndex', value);
    }
    /**
     * [descr:dxDataGridOptions.toolbar]
    
     */
    get toolbar() {
        return this._getOption('toolbar');
    }
    set toolbar(value) {
        this._setOption('toolbar', value);
    }
    /**
     * [descr:GridBaseOptions.twoWayBindingEnabled]
    
     */
    get twoWayBindingEnabled() {
        return this._getOption('twoWayBindingEnabled');
    }
    set twoWayBindingEnabled(value) {
        this._setOption('twoWayBindingEnabled', value);
    }
    /**
     * [descr:WidgetOptions.visible]
    
     */
    get visible() {
        return this._getOption('visible');
    }
    set visible(value) {
        this._setOption('visible', value);
    }
    /**
     * [descr:DOMComponentOptions.width]
    
     */
    get width() {
        return this._getOption('width');
    }
    set width(value) {
        this._setOption('width', value);
    }
    /**
     * [descr:GridBaseOptions.wordWrapEnabled]
    
     */
    get wordWrapEnabled() {
        return this._getOption('wordWrapEnabled');
    }
    set wordWrapEnabled(value) {
        this._setOption('wordWrapEnabled', value);
    }
    constructor(elementRef, ngZone, templateHost, _watcherHelper, _idh, optionHost, transferState, platformId) {
        super(elementRef, ngZone, templateHost, _watcherHelper, transferState, platformId);
        this._watcherHelper = _watcherHelper;
        this._idh = _idh;
        this.instance = null;
        this._createEventEmitters([
            { subscribe: 'adaptiveDetailRowPreparing', emit: 'onAdaptiveDetailRowPreparing' },
            { subscribe: 'aIAssistantRequestCreating', emit: 'onAIAssistantRequestCreating' },
            { subscribe: 'aIColumnRequestCreating', emit: 'onAIColumnRequestCreating' },
            { subscribe: 'cellClick', emit: 'onCellClick' },
            { subscribe: 'cellDblClick', emit: 'onCellDblClick' },
            { subscribe: 'cellHoverChanged', emit: 'onCellHoverChanged' },
            { subscribe: 'cellPrepared', emit: 'onCellPrepared' },
            { subscribe: 'contentReady', emit: 'onContentReady' },
            { subscribe: 'contextMenuPreparing', emit: 'onContextMenuPreparing' },
            { subscribe: 'dataErrorOccurred', emit: 'onDataErrorOccurred' },
            { subscribe: 'disposing', emit: 'onDisposing' },
            { subscribe: 'editCanceled', emit: 'onEditCanceled' },
            { subscribe: 'editCanceling', emit: 'onEditCanceling' },
            { subscribe: 'editingStart', emit: 'onEditingStart' },
            { subscribe: 'editorPrepared', emit: 'onEditorPrepared' },
            { subscribe: 'editorPreparing', emit: 'onEditorPreparing' },
            { subscribe: 'exporting', emit: 'onExporting' },
            { subscribe: 'focusedCellChanged', emit: 'onFocusedCellChanged' },
            { subscribe: 'focusedCellChanging', emit: 'onFocusedCellChanging' },
            { subscribe: 'focusedRowChanged', emit: 'onFocusedRowChanged' },
            { subscribe: 'focusedRowChanging', emit: 'onFocusedRowChanging' },
            { subscribe: 'initialized', emit: 'onInitialized' },
            { subscribe: 'initNewRow', emit: 'onInitNewRow' },
            { subscribe: 'keyDown', emit: 'onKeyDown' },
            { subscribe: 'optionChanged', emit: 'onOptionChanged' },
            { subscribe: 'rowClick', emit: 'onRowClick' },
            { subscribe: 'rowCollapsed', emit: 'onRowCollapsed' },
            { subscribe: 'rowCollapsing', emit: 'onRowCollapsing' },
            { subscribe: 'rowDblClick', emit: 'onRowDblClick' },
            { subscribe: 'rowExpanded', emit: 'onRowExpanded' },
            { subscribe: 'rowExpanding', emit: 'onRowExpanding' },
            { subscribe: 'rowInserted', emit: 'onRowInserted' },
            { subscribe: 'rowInserting', emit: 'onRowInserting' },
            { subscribe: 'rowPrepared', emit: 'onRowPrepared' },
            { subscribe: 'rowRemoved', emit: 'onRowRemoved' },
            { subscribe: 'rowRemoving', emit: 'onRowRemoving' },
            { subscribe: 'rowUpdated', emit: 'onRowUpdated' },
            { subscribe: 'rowUpdating', emit: 'onRowUpdating' },
            { subscribe: 'rowValidating', emit: 'onRowValidating' },
            { subscribe: 'saved', emit: 'onSaved' },
            { subscribe: 'saving', emit: 'onSaving' },
            { subscribe: 'selectionChanged', emit: 'onSelectionChanged' },
            { subscribe: 'toolbarPreparing', emit: 'onToolbarPreparing' },
            { emit: 'accessKeyChange' },
            { emit: 'activeStateEnabledChange' },
            { emit: 'aiAssistantChange' },
            { emit: 'aiIntegrationChange' },
            { emit: 'allowColumnReorderingChange' },
            { emit: 'allowColumnResizingChange' },
            { emit: 'autoNavigateToFocusedRowChange' },
            { emit: 'cacheEnabledChange' },
            { emit: 'cellHintEnabledChange' },
            { emit: 'columnAutoWidthChange' },
            { emit: 'columnChooserChange' },
            { emit: 'columnFixingChange' },
            { emit: 'columnHidingEnabledChange' },
            { emit: 'columnMinWidthChange' },
            { emit: 'columnResizingModeChange' },
            { emit: 'columnsChange' },
            { emit: 'columnWidthChange' },
            { emit: 'customizeColumnsChange' },
            { emit: 'dataRowTemplateChange' },
            { emit: 'dataSourceChange' },
            { emit: 'dateSerializationFormatChange' },
            { emit: 'disabledChange' },
            { emit: 'editingChange' },
            { emit: 'elementAttrChange' },
            { emit: 'errorRowEnabledChange' },
            { emit: 'exportChange' },
            { emit: 'filterBuilderChange' },
            { emit: 'filterBuilderPopupChange' },
            { emit: 'filterPanelChange' },
            { emit: 'filterRowChange' },
            { emit: 'filterSyncEnabledChange' },
            { emit: 'filterValueChange' },
            { emit: 'focusedColumnIndexChange' },
            { emit: 'focusedRowEnabledChange' },
            { emit: 'focusedRowIndexChange' },
            { emit: 'focusedRowKeyChange' },
            { emit: 'groupingChange' },
            { emit: 'groupPanelChange' },
            { emit: 'headerFilterChange' },
            { emit: 'heightChange' },
            { emit: 'highlightChangesChange' },
            { emit: 'hintChange' },
            { emit: 'hoverStateEnabledChange' },
            { emit: 'keyboardNavigationChange' },
            { emit: 'keyExprChange' },
            { emit: 'loadPanelChange' },
            { emit: 'masterDetailChange' },
            { emit: 'noDataTextChange' },
            { emit: 'pagerChange' },
            { emit: 'pagingChange' },
            { emit: 'remoteOperationsChange' },
            { emit: 'renderAsyncChange' },
            { emit: 'repaintChangesOnlyChange' },
            { emit: 'rowAlternationEnabledChange' },
            { emit: 'rowDraggingChange' },
            { emit: 'rowTemplateChange' },
            { emit: 'rtlEnabledChange' },
            { emit: 'scrollingChange' },
            { emit: 'searchPanelChange' },
            { emit: 'selectedRowKeysChange' },
            { emit: 'selectionChange' },
            { emit: 'selectionFilterChange' },
            { emit: 'showBordersChange' },
            { emit: 'showColumnHeadersChange' },
            { emit: 'showColumnLinesChange' },
            { emit: 'showRowLinesChange' },
            { emit: 'sortByGroupSummaryInfoChange' },
            { emit: 'sortingChange' },
            { emit: 'stateStoringChange' },
            { emit: 'summaryChange' },
            { emit: 'syncLookupFilterValuesChange' },
            { emit: 'tabIndexChange' },
            { emit: 'toolbarChange' },
            { emit: 'twoWayBindingEnabledChange' },
            { emit: 'visibleChange' },
            { emit: 'widthChange' },
            { emit: 'wordWrapEnabledChange' }
        ]);
        this._idh.setHost(this);
        optionHost.setHost(this);
    }
    _createInstance(element, options) {
        return new DxDataGrid(element, options);
    }
    ngOnDestroy() {
        this._destroyWidget();
    }
    ngOnChanges(changes) {
        super.ngOnChanges(changes);
        this.setupChanges('columns', changes);
        this.setupChanges('dataSource', changes);
        this.setupChanges('filterValue', changes);
        this.setupChanges('keyExpr', changes);
        this.setupChanges('selectedRowKeys', changes);
        this.setupChanges('selectionFilter', changes);
        this.setupChanges('sortByGroupSummaryInfo', changes);
    }
    setupChanges(prop, changes) {
        if (!(prop in this._optionsToUpdate)) {
            this._idh.setup(prop, changes);
        }
    }
    ngDoCheck() {
        this._idh.doCheck('columns');
        this._idh.doCheck('dataSource');
        this._idh.doCheck('filterValue');
        this._idh.doCheck('keyExpr');
        this._idh.doCheck('selectedRowKeys');
        this._idh.doCheck('selectionFilter');
        this._idh.doCheck('sortByGroupSummaryInfo');
        this._watcherHelper.checkWatchers();
        super.ngDoCheck();
        super.clearChangedOptions();
    }
    _setOption(name, value) {
        let isSetup = this._idh.setupSingle(name, value);
        let isChanged = this._idh.getChanges(name, value) !== null;
        if (isSetup || isChanged) {
            super._setOption(name, value);
        }
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxDataGridComponent, deps: [{ token: i0.ElementRef }, { token: i0.NgZone }, { token: i1.DxTemplateHost }, { token: i1.WatcherHelper }, { token: i1.IterableDifferHelper }, { token: i1.NestedOptionHost }, { token: i0.TransferState }, { token: PLATFORM_ID }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxDataGridComponent, isStandalone: true, selector: "dx-data-grid", inputs: { accessKey: "accessKey", activeStateEnabled: "activeStateEnabled", aiAssistant: "aiAssistant", aiIntegration: "aiIntegration", allowColumnReordering: "allowColumnReordering", allowColumnResizing: "allowColumnResizing", autoNavigateToFocusedRow: "autoNavigateToFocusedRow", cacheEnabled: "cacheEnabled", cellHintEnabled: "cellHintEnabled", columnAutoWidth: "columnAutoWidth", columnChooser: "columnChooser", columnFixing: "columnFixing", columnHidingEnabled: "columnHidingEnabled", columnMinWidth: "columnMinWidth", columnResizingMode: "columnResizingMode", columns: "columns", columnWidth: "columnWidth", customizeColumns: "customizeColumns", dataRowTemplate: "dataRowTemplate", dataSource: "dataSource", dateSerializationFormat: "dateSerializationFormat", disabled: "disabled", editing: "editing", elementAttr: "elementAttr", errorRowEnabled: "errorRowEnabled", export: "export", filterBuilder: "filterBuilder", filterBuilderPopup: "filterBuilderPopup", filterPanel: "filterPanel", filterRow: "filterRow", filterSyncEnabled: "filterSyncEnabled", filterValue: "filterValue", focusedColumnIndex: "focusedColumnIndex", focusedRowEnabled: "focusedRowEnabled", focusedRowIndex: "focusedRowIndex", focusedRowKey: "focusedRowKey", grouping: "grouping", groupPanel: "groupPanel", headerFilter: "headerFilter", height: "height", highlightChanges: "highlightChanges", hint: "hint", hoverStateEnabled: "hoverStateEnabled", keyboardNavigation: "keyboardNavigation", keyExpr: "keyExpr", loadPanel: "loadPanel", masterDetail: "masterDetail", noDataText: "noDataText", pager: "pager", paging: "paging", remoteOperations: "remoteOperations", renderAsync: "renderAsync", repaintChangesOnly: "repaintChangesOnly", rowAlternationEnabled: "rowAlternationEnabled", rowDragging: "rowDragging", rowTemplate: "rowTemplate", rtlEnabled: "rtlEnabled", scrolling: "scrolling", searchPanel: "searchPanel", selectedRowKeys: "selectedRowKeys", selection: "selection", selectionFilter: "selectionFilter", showBorders: "showBorders", showColumnHeaders: "showColumnHeaders", showColumnLines: "showColumnLines", showRowLines: "showRowLines", sortByGroupSummaryInfo: "sortByGroupSummaryInfo", sorting: "sorting", stateStoring: "stateStoring", summary: "summary", syncLookupFilterValues: "syncLookupFilterValues", tabIndex: "tabIndex", toolbar: "toolbar", twoWayBindingEnabled: "twoWayBindingEnabled", visible: "visible", width: "width", wordWrapEnabled: "wordWrapEnabled" }, outputs: { onAdaptiveDetailRowPreparing: "onAdaptiveDetailRowPreparing", onAIAssistantRequestCreating: "onAIAssistantRequestCreating", onAIColumnRequestCreating: "onAIColumnRequestCreating", onCellClick: "onCellClick", onCellDblClick: "onCellDblClick", onCellHoverChanged: "onCellHoverChanged", onCellPrepared: "onCellPrepared", onContentReady: "onContentReady", onContextMenuPreparing: "onContextMenuPreparing", onDataErrorOccurred: "onDataErrorOccurred", onDisposing: "onDisposing", onEditCanceled: "onEditCanceled", onEditCanceling: "onEditCanceling", onEditingStart: "onEditingStart", onEditorPrepared: "onEditorPrepared", onEditorPreparing: "onEditorPreparing", onExporting: "onExporting", onFocusedCellChanged: "onFocusedCellChanged", onFocusedCellChanging: "onFocusedCellChanging", onFocusedRowChanged: "onFocusedRowChanged", onFocusedRowChanging: "onFocusedRowChanging", onInitialized: "onInitialized", onInitNewRow: "onInitNewRow", onKeyDown: "onKeyDown", onOptionChanged: "onOptionChanged", onRowClick: "onRowClick", onRowCollapsed: "onRowCollapsed", onRowCollapsing: "onRowCollapsing", onRowDblClick: "onRowDblClick", onRowExpanded: "onRowExpanded", onRowExpanding: "onRowExpanding", onRowInserted: "onRowInserted", onRowInserting: "onRowInserting", onRowPrepared: "onRowPrepared", onRowRemoved: "onRowRemoved", onRowRemoving: "onRowRemoving", onRowUpdated: "onRowUpdated", onRowUpdating: "onRowUpdating", onRowValidating: "onRowValidating", onSaved: "onSaved", onSaving: "onSaving", onSelectionChanged: "onSelectionChanged", onToolbarPreparing: "onToolbarPreparing", accessKeyChange: "accessKeyChange", activeStateEnabledChange: "activeStateEnabledChange", aiAssistantChange: "aiAssistantChange", aiIntegrationChange: "aiIntegrationChange", allowColumnReorderingChange: "allowColumnReorderingChange", allowColumnResizingChange: "allowColumnResizingChange", autoNavigateToFocusedRowChange: "autoNavigateToFocusedRowChange", cacheEnabledChange: "cacheEnabledChange", cellHintEnabledChange: "cellHintEnabledChange", columnAutoWidthChange: "columnAutoWidthChange", columnChooserChange: "columnChooserChange", columnFixingChange: "columnFixingChange", columnHidingEnabledChange: "columnHidingEnabledChange", columnMinWidthChange: "columnMinWidthChange", columnResizingModeChange: "columnResizingModeChange", columnsChange: "columnsChange", columnWidthChange: "columnWidthChange", customizeColumnsChange: "customizeColumnsChange", dataRowTemplateChange: "dataRowTemplateChange", dataSourceChange: "dataSourceChange", dateSerializationFormatChange: "dateSerializationFormatChange", disabledChange: "disabledChange", editingChange: "editingChange", elementAttrChange: "elementAttrChange", errorRowEnabledChange: "errorRowEnabledChange", exportChange: "exportChange", filterBuilderChange: "filterBuilderChange", filterBuilderPopupChange: "filterBuilderPopupChange", filterPanelChange: "filterPanelChange", filterRowChange: "filterRowChange", filterSyncEnabledChange: "filterSyncEnabledChange", filterValueChange: "filterValueChange", focusedColumnIndexChange: "focusedColumnIndexChange", focusedRowEnabledChange: "focusedRowEnabledChange", focusedRowIndexChange: "focusedRowIndexChange", focusedRowKeyChange: "focusedRowKeyChange", groupingChange: "groupingChange", groupPanelChange: "groupPanelChange", headerFilterChange: "headerFilterChange", heightChange: "heightChange", highlightChangesChange: "highlightChangesChange", hintChange: "hintChange", hoverStateEnabledChange: "hoverStateEnabledChange", keyboardNavigationChange: "keyboardNavigationChange", keyExprChange: "keyExprChange", loadPanelChange: "loadPanelChange", masterDetailChange: "masterDetailChange", noDataTextChange: "noDataTextChange", pagerChange: "pagerChange", pagingChange: "pagingChange", remoteOperationsChange: "remoteOperationsChange", renderAsyncChange: "renderAsyncChange", repaintChangesOnlyChange: "repaintChangesOnlyChange", rowAlternationEnabledChange: "rowAlternationEnabledChange", rowDraggingChange: "rowDraggingChange", rowTemplateChange: "rowTemplateChange", rtlEnabledChange: "rtlEnabledChange", scrollingChange: "scrollingChange", searchPanelChange: "searchPanelChange", selectedRowKeysChange: "selectedRowKeysChange", selectionChange: "selectionChange", selectionFilterChange: "selectionFilterChange", showBordersChange: "showBordersChange", showColumnHeadersChange: "showColumnHeadersChange", showColumnLinesChange: "showColumnLinesChange", showRowLinesChange: "showRowLinesChange", sortByGroupSummaryInfoChange: "sortByGroupSummaryInfoChange", sortingChange: "sortingChange", stateStoringChange: "stateStoringChange", summaryChange: "summaryChange", syncLookupFilterValuesChange: "syncLookupFilterValuesChange", tabIndexChange: "tabIndexChange", toolbarChange: "toolbarChange", twoWayBindingEnabledChange: "twoWayBindingEnabledChange", visibleChange: "visibleChange", widthChange: "widthChange", wordWrapEnabledChange: "wordWrapEnabledChange" }, host: { attributes: { "ngSkipHydration": "true" } }, providers: [
            DxTemplateHost,
            WatcherHelper,
            NestedOptionHost,
            IterableDifferHelper
        ], queries: [{ propertyName: "_validationRulesContentChildren", predicate: PROPERTY_TOKEN_validationRules }, { propertyName: "_buttonsContentChildren", predicate: PROPERTY_TOKEN_buttons }, { propertyName: "_itemsContentChildren", predicate: PROPERTY_TOKEN_items }, { propertyName: "_changesContentChildren", predicate: PROPERTY_TOKEN_changes }, { propertyName: "_columnsContentChildren", predicate: PROPERTY_TOKEN_columns }, { propertyName: "_customOperationsContentChildren", predicate: PROPERTY_TOKEN_customOperations }, { propertyName: "_fieldsContentChildren", predicate: PROPERTY_TOKEN_fields }, { propertyName: "_groupItemsContentChildren", predicate: PROPERTY_TOKEN_groupItems }, { propertyName: "_sortByGroupSummaryInfoContentChildren", predicate: PROPERTY_TOKEN_sortByGroupSummaryInfo }, { propertyName: "_tabsContentChildren", predicate: PROPERTY_TOKEN_tabs }, { propertyName: "_toolbarItemsContentChildren", predicate: PROPERTY_TOKEN_toolbarItems }, { propertyName: "_totalItemsContentChildren", predicate: PROPERTY_TOKEN_totalItems }], usesInheritance: true, usesOnChanges: true, ngImport: i0, template: '', isInline: true, dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxDataGridComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'dx-data-grid',
                    template: '',
                    host: { ngSkipHydration: 'true' },
                    imports: [DxIntegrationModule],
                    providers: [
                        DxTemplateHost,
                        WatcherHelper,
                        NestedOptionHost,
                        IterableDifferHelper
                    ]
                }]
        }], ctorParameters: () => [{ type: i0.ElementRef }, { type: i0.NgZone }, { type: i1.DxTemplateHost }, { type: i1.WatcherHelper }, { type: i1.IterableDifferHelper }, { type: i1.NestedOptionHost }, { type: i0.TransferState }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [PLATFORM_ID]
                }] }], propDecorators: { _validationRulesContentChildren: [{
                type: ContentChildren,
                args: [PROPERTY_TOKEN_validationRules]
            }], _buttonsContentChildren: [{
                type: ContentChildren,
                args: [PROPERTY_TOKEN_buttons]
            }], _itemsContentChildren: [{
                type: ContentChildren,
                args: [PROPERTY_TOKEN_items]
            }], _changesContentChildren: [{
                type: ContentChildren,
                args: [PROPERTY_TOKEN_changes]
            }], _columnsContentChildren: [{
                type: ContentChildren,
                args: [PROPERTY_TOKEN_columns]
            }], _customOperationsContentChildren: [{
                type: ContentChildren,
                args: [PROPERTY_TOKEN_customOperations]
            }], _fieldsContentChildren: [{
                type: ContentChildren,
                args: [PROPERTY_TOKEN_fields]
            }], _groupItemsContentChildren: [{
                type: ContentChildren,
                args: [PROPERTY_TOKEN_groupItems]
            }], _sortByGroupSummaryInfoContentChildren: [{
                type: ContentChildren,
                args: [PROPERTY_TOKEN_sortByGroupSummaryInfo]
            }], _tabsContentChildren: [{
                type: ContentChildren,
                args: [PROPERTY_TOKEN_tabs]
            }], _toolbarItemsContentChildren: [{
                type: ContentChildren,
                args: [PROPERTY_TOKEN_toolbarItems]
            }], _totalItemsContentChildren: [{
                type: ContentChildren,
                args: [PROPERTY_TOKEN_totalItems]
            }], accessKey: [{
                type: Input
            }], activeStateEnabled: [{
                type: Input
            }], aiAssistant: [{
                type: Input
            }], aiIntegration: [{
                type: Input
            }], allowColumnReordering: [{
                type: Input
            }], allowColumnResizing: [{
                type: Input
            }], autoNavigateToFocusedRow: [{
                type: Input
            }], cacheEnabled: [{
                type: Input
            }], cellHintEnabled: [{
                type: Input
            }], columnAutoWidth: [{
                type: Input
            }], columnChooser: [{
                type: Input
            }], columnFixing: [{
                type: Input
            }], columnHidingEnabled: [{
                type: Input
            }], columnMinWidth: [{
                type: Input
            }], columnResizingMode: [{
                type: Input
            }], columns: [{
                type: Input
            }], columnWidth: [{
                type: Input
            }], customizeColumns: [{
                type: Input
            }], dataRowTemplate: [{
                type: Input
            }], dataSource: [{
                type: Input
            }], dateSerializationFormat: [{
                type: Input
            }], disabled: [{
                type: Input
            }], editing: [{
                type: Input
            }], elementAttr: [{
                type: Input
            }], errorRowEnabled: [{
                type: Input
            }], export: [{
                type: Input
            }], filterBuilder: [{
                type: Input
            }], filterBuilderPopup: [{
                type: Input
            }], filterPanel: [{
                type: Input
            }], filterRow: [{
                type: Input
            }], filterSyncEnabled: [{
                type: Input
            }], filterValue: [{
                type: Input
            }], focusedColumnIndex: [{
                type: Input
            }], focusedRowEnabled: [{
                type: Input
            }], focusedRowIndex: [{
                type: Input
            }], focusedRowKey: [{
                type: Input
            }], grouping: [{
                type: Input
            }], groupPanel: [{
                type: Input
            }], headerFilter: [{
                type: Input
            }], height: [{
                type: Input
            }], highlightChanges: [{
                type: Input
            }], hint: [{
                type: Input
            }], hoverStateEnabled: [{
                type: Input
            }], keyboardNavigation: [{
                type: Input
            }], keyExpr: [{
                type: Input
            }], loadPanel: [{
                type: Input
            }], masterDetail: [{
                type: Input
            }], noDataText: [{
                type: Input
            }], pager: [{
                type: Input
            }], paging: [{
                type: Input
            }], remoteOperations: [{
                type: Input
            }], renderAsync: [{
                type: Input
            }], repaintChangesOnly: [{
                type: Input
            }], rowAlternationEnabled: [{
                type: Input
            }], rowDragging: [{
                type: Input
            }], rowTemplate: [{
                type: Input
            }], rtlEnabled: [{
                type: Input
            }], scrolling: [{
                type: Input
            }], searchPanel: [{
                type: Input
            }], selectedRowKeys: [{
                type: Input
            }], selection: [{
                type: Input
            }], selectionFilter: [{
                type: Input
            }], showBorders: [{
                type: Input
            }], showColumnHeaders: [{
                type: Input
            }], showColumnLines: [{
                type: Input
            }], showRowLines: [{
                type: Input
            }], sortByGroupSummaryInfo: [{
                type: Input
            }], sorting: [{
                type: Input
            }], stateStoring: [{
                type: Input
            }], summary: [{
                type: Input
            }], syncLookupFilterValues: [{
                type: Input
            }], tabIndex: [{
                type: Input
            }], toolbar: [{
                type: Input
            }], twoWayBindingEnabled: [{
                type: Input
            }], visible: [{
                type: Input
            }], width: [{
                type: Input
            }], wordWrapEnabled: [{
                type: Input
            }], onAdaptiveDetailRowPreparing: [{
                type: Output
            }], onAIAssistantRequestCreating: [{
                type: Output
            }], onAIColumnRequestCreating: [{
                type: Output
            }], onCellClick: [{
                type: Output
            }], onCellDblClick: [{
                type: Output
            }], onCellHoverChanged: [{
                type: Output
            }], onCellPrepared: [{
                type: Output
            }], onContentReady: [{
                type: Output
            }], onContextMenuPreparing: [{
                type: Output
            }], onDataErrorOccurred: [{
                type: Output
            }], onDisposing: [{
                type: Output
            }], onEditCanceled: [{
                type: Output
            }], onEditCanceling: [{
                type: Output
            }], onEditingStart: [{
                type: Output
            }], onEditorPrepared: [{
                type: Output
            }], onEditorPreparing: [{
                type: Output
            }], onExporting: [{
                type: Output
            }], onFocusedCellChanged: [{
                type: Output
            }], onFocusedCellChanging: [{
                type: Output
            }], onFocusedRowChanged: [{
                type: Output
            }], onFocusedRowChanging: [{
                type: Output
            }], onInitialized: [{
                type: Output
            }], onInitNewRow: [{
                type: Output
            }], onKeyDown: [{
                type: Output
            }], onOptionChanged: [{
                type: Output
            }], onRowClick: [{
                type: Output
            }], onRowCollapsed: [{
                type: Output
            }], onRowCollapsing: [{
                type: Output
            }], onRowDblClick: [{
                type: Output
            }], onRowExpanded: [{
                type: Output
            }], onRowExpanding: [{
                type: Output
            }], onRowInserted: [{
                type: Output
            }], onRowInserting: [{
                type: Output
            }], onRowPrepared: [{
                type: Output
            }], onRowRemoved: [{
                type: Output
            }], onRowRemoving: [{
                type: Output
            }], onRowUpdated: [{
                type: Output
            }], onRowUpdating: [{
                type: Output
            }], onRowValidating: [{
                type: Output
            }], onSaved: [{
                type: Output
            }], onSaving: [{
                type: Output
            }], onSelectionChanged: [{
                type: Output
            }], onToolbarPreparing: [{
                type: Output
            }], accessKeyChange: [{
                type: Output
            }], activeStateEnabledChange: [{
                type: Output
            }], aiAssistantChange: [{
                type: Output
            }], aiIntegrationChange: [{
                type: Output
            }], allowColumnReorderingChange: [{
                type: Output
            }], allowColumnResizingChange: [{
                type: Output
            }], autoNavigateToFocusedRowChange: [{
                type: Output
            }], cacheEnabledChange: [{
                type: Output
            }], cellHintEnabledChange: [{
                type: Output
            }], columnAutoWidthChange: [{
                type: Output
            }], columnChooserChange: [{
                type: Output
            }], columnFixingChange: [{
                type: Output
            }], columnHidingEnabledChange: [{
                type: Output
            }], columnMinWidthChange: [{
                type: Output
            }], columnResizingModeChange: [{
                type: Output
            }], columnsChange: [{
                type: Output
            }], columnWidthChange: [{
                type: Output
            }], customizeColumnsChange: [{
                type: Output
            }], dataRowTemplateChange: [{
                type: Output
            }], dataSourceChange: [{
                type: Output
            }], dateSerializationFormatChange: [{
                type: Output
            }], disabledChange: [{
                type: Output
            }], editingChange: [{
                type: Output
            }], elementAttrChange: [{
                type: Output
            }], errorRowEnabledChange: [{
                type: Output
            }], exportChange: [{
                type: Output
            }], filterBuilderChange: [{
                type: Output
            }], filterBuilderPopupChange: [{
                type: Output
            }], filterPanelChange: [{
                type: Output
            }], filterRowChange: [{
                type: Output
            }], filterSyncEnabledChange: [{
                type: Output
            }], filterValueChange: [{
                type: Output
            }], focusedColumnIndexChange: [{
                type: Output
            }], focusedRowEnabledChange: [{
                type: Output
            }], focusedRowIndexChange: [{
                type: Output
            }], focusedRowKeyChange: [{
                type: Output
            }], groupingChange: [{
                type: Output
            }], groupPanelChange: [{
                type: Output
            }], headerFilterChange: [{
                type: Output
            }], heightChange: [{
                type: Output
            }], highlightChangesChange: [{
                type: Output
            }], hintChange: [{
                type: Output
            }], hoverStateEnabledChange: [{
                type: Output
            }], keyboardNavigationChange: [{
                type: Output
            }], keyExprChange: [{
                type: Output
            }], loadPanelChange: [{
                type: Output
            }], masterDetailChange: [{
                type: Output
            }], noDataTextChange: [{
                type: Output
            }], pagerChange: [{
                type: Output
            }], pagingChange: [{
                type: Output
            }], remoteOperationsChange: [{
                type: Output
            }], renderAsyncChange: [{
                type: Output
            }], repaintChangesOnlyChange: [{
                type: Output
            }], rowAlternationEnabledChange: [{
                type: Output
            }], rowDraggingChange: [{
                type: Output
            }], rowTemplateChange: [{
                type: Output
            }], rtlEnabledChange: [{
                type: Output
            }], scrollingChange: [{
                type: Output
            }], searchPanelChange: [{
                type: Output
            }], selectedRowKeysChange: [{
                type: Output
            }], selectionChange: [{
                type: Output
            }], selectionFilterChange: [{
                type: Output
            }], showBordersChange: [{
                type: Output
            }], showColumnHeadersChange: [{
                type: Output
            }], showColumnLinesChange: [{
                type: Output
            }], showRowLinesChange: [{
                type: Output
            }], sortByGroupSummaryInfoChange: [{
                type: Output
            }], sortingChange: [{
                type: Output
            }], stateStoringChange: [{
                type: Output
            }], summaryChange: [{
                type: Output
            }], syncLookupFilterValuesChange: [{
                type: Output
            }], tabIndexChange: [{
                type: Output
            }], toolbarChange: [{
                type: Output
            }], twoWayBindingEnabledChange: [{
                type: Output
            }], visibleChange: [{
                type: Output
            }], widthChange: [{
                type: Output
            }], wordWrapEnabledChange: [{
                type: Output
            }] } });
class DxDataGridModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxDataGridModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxDataGridModule, imports: [DxDataGridComponent, DxoColumnChooserModule,
            DxoPositionModule,
            DxoAtModule,
            DxoBoundaryOffsetModule,
            DxoCollisionModule,
            DxoMyModule,
            DxoOffsetModule,
            DxoSearchModule,
            DxoSelectionModule,
            DxoColumnFixingModule,
            DxoIconsModule,
            DxoTextsModule,
            DxiColumnModule,
            DxiButtonModule,
            DxoLookupModule,
            DxoFormatModule,
            DxoFormItemModule,
            DxoLabelModule,
            DxiValidationRuleModule,
            DxoHeaderFilterModule,
            DxoEditingModule,
            DxiChangeModule,
            DxoFormModule,
            DxoColCountByScreenModule,
            DxiItemModule,
            DxoTabPanelOptionsModule,
            DxiTabModule,
            DxoButtonOptionsModule,
            DxoPopupModule,
            DxoAnimationModule,
            DxoHideModule,
            DxoFromModule,
            DxoToModule,
            DxoShowModule,
            DxoExportModule,
            DxoFilterBuilderModule,
            DxiCustomOperationModule,
            DxiFieldModule,
            DxoFilterOperationDescriptionsModule,
            DxoGroupOperationDescriptionsModule,
            DxoFilterBuilderPopupModule,
            DxoFilterPanelModule,
            DxoFilterRowModule,
            DxoOperationDescriptionsModule,
            DxoGroupingModule,
            DxoGroupPanelModule,
            DxoKeyboardNavigationModule,
            DxoLoadPanelModule,
            DxoMasterDetailModule,
            DxoPagerModule,
            DxoPagingModule,
            DxoRemoteOperationsModule,
            DxoRowDraggingModule,
            DxoCursorOffsetModule,
            DxoScrollingModule,
            DxoSearchPanelModule,
            DxiSortByGroupSummaryInfoModule,
            DxoSortingModule,
            DxoStateStoringModule,
            DxoSummaryModule,
            DxiGroupItemModule,
            DxoValueFormatModule,
            DxiTotalItemModule,
            DxoToolbarModule,
            DxoDataGridAIModule,
            DxoDataGridAIAssistantModule,
            DxoDataGridAIOptionsModule,
            DxoDataGridAnimationModule,
            DxiDataGridAsyncRuleModule,
            DxoDataGridAtModule,
            DxoDataGridBoundaryOffsetModule,
            DxiDataGridButtonModule,
            DxiDataGridButtonItemModule,
            DxoDataGridButtonOptionsModule,
            DxiDataGridChangeModule,
            DxoDataGridColCountByScreenModule,
            DxoDataGridCollisionModule,
            DxiDataGridColumnModule,
            DxiDataGridColumnButtonModule,
            DxoDataGridColumnChooserModule,
            DxoDataGridColumnChooserSearchModule,
            DxoDataGridColumnChooserSelectionModule,
            DxoDataGridColumnFixingModule,
            DxoDataGridColumnFixingTextsModule,
            DxoDataGridColumnHeaderFilterModule,
            DxoDataGridColumnHeaderFilterSearchModule,
            DxoDataGridColumnLookupModule,
            DxiDataGridCompareRuleModule,
            DxoDataGridCursorOffsetModule,
            DxiDataGridCustomOperationModule,
            DxiDataGridCustomRuleModule,
            DxoDataGridDataGridHeaderFilterModule,
            DxoDataGridDataGridHeaderFilterSearchModule,
            DxoDataGridDataGridHeaderFilterTextsModule,
            DxoDataGridDataGridSelectionModule,
            DxiDataGridDataGridToolbarItemModule,
            DxoDataGridEditingModule,
            DxoDataGridEditingTextsModule,
            DxoDataGridEditorOptionsModule,
            DxiDataGridEditorOptionsButtonModule,
            DxiDataGridEmailRuleModule,
            DxiDataGridEmptyItemModule,
            DxoDataGridExportModule,
            DxoDataGridExportTextsModule,
            DxiDataGridFieldModule,
            DxoDataGridFieldLookupModule,
            DxoDataGridFilterBuilderModule,
            DxoDataGridFilterBuilderPopupModule,
            DxoDataGridFilterOperationDescriptionsModule,
            DxoDataGridFilterPanelModule,
            DxoDataGridFilterPanelTextsModule,
            DxoDataGridFilterRowModule,
            DxoDataGridFormModule,
            DxoDataGridFormatModule,
            DxiDataGridFormGroupItemModule,
            DxoDataGridFormItemModule,
            DxoDataGridFromModule,
            DxoDataGridGroupingModule,
            DxoDataGridGroupingTextsModule,
            DxiDataGridGroupItemModule,
            DxoDataGridGroupOperationDescriptionsModule,
            DxoDataGridGroupPanelModule,
            DxoDataGridHeaderFilterModule,
            DxoDataGridHideModule,
            DxoDataGridIconsModule,
            DxoDataGridIndicatorOptionsModule,
            DxiDataGridItemModule,
            DxoDataGridKeyboardNavigationModule,
            DxoDataGridLabelModule,
            DxoDataGridLoadPanelModule,
            DxoDataGridLookupModule,
            DxoDataGridMasterDetailModule,
            DxoDataGridMyModule,
            DxiDataGridNumericRuleModule,
            DxoDataGridOffsetModule,
            DxoDataGridOperationDescriptionsModule,
            DxoDataGridOptionsModule,
            DxoDataGridPagerModule,
            DxoDataGridPagingModule,
            DxiDataGridPatternRuleModule,
            DxoDataGridPopupModule,
            DxoDataGridPositionModule,
            DxiDataGridRangeRuleModule,
            DxoDataGridRemoteOperationsModule,
            DxiDataGridRequiredRuleModule,
            DxoDataGridRowDraggingModule,
            DxoDataGridScrollingModule,
            DxoDataGridSearchModule,
            DxoDataGridSearchPanelModule,
            DxoDataGridSelectionModule,
            DxoDataGridShowModule,
            DxiDataGridSimpleItemModule,
            DxiDataGridSortByGroupSummaryInfoModule,
            DxoDataGridSortingModule,
            DxoDataGridStateStoringModule,
            DxiDataGridStringLengthRuleModule,
            DxoDataGridSummaryModule,
            DxoDataGridSummaryTextsModule,
            DxiDataGridTabModule,
            DxiDataGridTabbedItemModule,
            DxoDataGridTabPanelOptionsModule,
            DxiDataGridTabPanelOptionsItemModule,
            DxoDataGridTextsModule,
            DxoDataGridToModule,
            DxoDataGridToolbarModule,
            DxiDataGridToolbarItemModule,
            DxiDataGridTotalItemModule,
            DxiDataGridValidationRuleModule,
            DxoDataGridValueFormatModule,
            DxIntegrationModule,
            DxTemplateModule], exports: [DxDataGridComponent, DxoColumnChooserModule,
            DxoPositionModule,
            DxoAtModule,
            DxoBoundaryOffsetModule,
            DxoCollisionModule,
            DxoMyModule,
            DxoOffsetModule,
            DxoSearchModule,
            DxoSelectionModule,
            DxoColumnFixingModule,
            DxoIconsModule,
            DxoTextsModule,
            DxiColumnModule,
            DxiButtonModule,
            DxoLookupModule,
            DxoFormatModule,
            DxoFormItemModule,
            DxoLabelModule,
            DxiValidationRuleModule,
            DxoHeaderFilterModule,
            DxoEditingModule,
            DxiChangeModule,
            DxoFormModule,
            DxoColCountByScreenModule,
            DxiItemModule,
            DxoTabPanelOptionsModule,
            DxiTabModule,
            DxoButtonOptionsModule,
            DxoPopupModule,
            DxoAnimationModule,
            DxoHideModule,
            DxoFromModule,
            DxoToModule,
            DxoShowModule,
            DxoExportModule,
            DxoFilterBuilderModule,
            DxiCustomOperationModule,
            DxiFieldModule,
            DxoFilterOperationDescriptionsModule,
            DxoGroupOperationDescriptionsModule,
            DxoFilterBuilderPopupModule,
            DxoFilterPanelModule,
            DxoFilterRowModule,
            DxoOperationDescriptionsModule,
            DxoGroupingModule,
            DxoGroupPanelModule,
            DxoKeyboardNavigationModule,
            DxoLoadPanelModule,
            DxoMasterDetailModule,
            DxoPagerModule,
            DxoPagingModule,
            DxoRemoteOperationsModule,
            DxoRowDraggingModule,
            DxoCursorOffsetModule,
            DxoScrollingModule,
            DxoSearchPanelModule,
            DxiSortByGroupSummaryInfoModule,
            DxoSortingModule,
            DxoStateStoringModule,
            DxoSummaryModule,
            DxiGroupItemModule,
            DxoValueFormatModule,
            DxiTotalItemModule,
            DxoToolbarModule,
            DxoDataGridAIModule,
            DxoDataGridAIAssistantModule,
            DxoDataGridAIOptionsModule,
            DxoDataGridAnimationModule,
            DxiDataGridAsyncRuleModule,
            DxoDataGridAtModule,
            DxoDataGridBoundaryOffsetModule,
            DxiDataGridButtonModule,
            DxiDataGridButtonItemModule,
            DxoDataGridButtonOptionsModule,
            DxiDataGridChangeModule,
            DxoDataGridColCountByScreenModule,
            DxoDataGridCollisionModule,
            DxiDataGridColumnModule,
            DxiDataGridColumnButtonModule,
            DxoDataGridColumnChooserModule,
            DxoDataGridColumnChooserSearchModule,
            DxoDataGridColumnChooserSelectionModule,
            DxoDataGridColumnFixingModule,
            DxoDataGridColumnFixingTextsModule,
            DxoDataGridColumnHeaderFilterModule,
            DxoDataGridColumnHeaderFilterSearchModule,
            DxoDataGridColumnLookupModule,
            DxiDataGridCompareRuleModule,
            DxoDataGridCursorOffsetModule,
            DxiDataGridCustomOperationModule,
            DxiDataGridCustomRuleModule,
            DxoDataGridDataGridHeaderFilterModule,
            DxoDataGridDataGridHeaderFilterSearchModule,
            DxoDataGridDataGridHeaderFilterTextsModule,
            DxoDataGridDataGridSelectionModule,
            DxiDataGridDataGridToolbarItemModule,
            DxoDataGridEditingModule,
            DxoDataGridEditingTextsModule,
            DxoDataGridEditorOptionsModule,
            DxiDataGridEditorOptionsButtonModule,
            DxiDataGridEmailRuleModule,
            DxiDataGridEmptyItemModule,
            DxoDataGridExportModule,
            DxoDataGridExportTextsModule,
            DxiDataGridFieldModule,
            DxoDataGridFieldLookupModule,
            DxoDataGridFilterBuilderModule,
            DxoDataGridFilterBuilderPopupModule,
            DxoDataGridFilterOperationDescriptionsModule,
            DxoDataGridFilterPanelModule,
            DxoDataGridFilterPanelTextsModule,
            DxoDataGridFilterRowModule,
            DxoDataGridFormModule,
            DxoDataGridFormatModule,
            DxiDataGridFormGroupItemModule,
            DxoDataGridFormItemModule,
            DxoDataGridFromModule,
            DxoDataGridGroupingModule,
            DxoDataGridGroupingTextsModule,
            DxiDataGridGroupItemModule,
            DxoDataGridGroupOperationDescriptionsModule,
            DxoDataGridGroupPanelModule,
            DxoDataGridHeaderFilterModule,
            DxoDataGridHideModule,
            DxoDataGridIconsModule,
            DxoDataGridIndicatorOptionsModule,
            DxiDataGridItemModule,
            DxoDataGridKeyboardNavigationModule,
            DxoDataGridLabelModule,
            DxoDataGridLoadPanelModule,
            DxoDataGridLookupModule,
            DxoDataGridMasterDetailModule,
            DxoDataGridMyModule,
            DxiDataGridNumericRuleModule,
            DxoDataGridOffsetModule,
            DxoDataGridOperationDescriptionsModule,
            DxoDataGridOptionsModule,
            DxoDataGridPagerModule,
            DxoDataGridPagingModule,
            DxiDataGridPatternRuleModule,
            DxoDataGridPopupModule,
            DxoDataGridPositionModule,
            DxiDataGridRangeRuleModule,
            DxoDataGridRemoteOperationsModule,
            DxiDataGridRequiredRuleModule,
            DxoDataGridRowDraggingModule,
            DxoDataGridScrollingModule,
            DxoDataGridSearchModule,
            DxoDataGridSearchPanelModule,
            DxoDataGridSelectionModule,
            DxoDataGridShowModule,
            DxiDataGridSimpleItemModule,
            DxiDataGridSortByGroupSummaryInfoModule,
            DxoDataGridSortingModule,
            DxoDataGridStateStoringModule,
            DxiDataGridStringLengthRuleModule,
            DxoDataGridSummaryModule,
            DxoDataGridSummaryTextsModule,
            DxiDataGridTabModule,
            DxiDataGridTabbedItemModule,
            DxoDataGridTabPanelOptionsModule,
            DxiDataGridTabPanelOptionsItemModule,
            DxoDataGridTextsModule,
            DxoDataGridToModule,
            DxoDataGridToolbarModule,
            DxiDataGridToolbarItemModule,
            DxiDataGridTotalItemModule,
            DxiDataGridValidationRuleModule,
            DxoDataGridValueFormatModule,
            DxTemplateModule] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxDataGridModule, imports: [DxDataGridComponent,
            DxoColumnChooserModule,
            DxoPositionModule,
            DxoAtModule,
            DxoBoundaryOffsetModule,
            DxoCollisionModule,
            DxoMyModule,
            DxoOffsetModule,
            DxoSearchModule,
            DxoSelectionModule,
            DxoColumnFixingModule,
            DxoIconsModule,
            DxoTextsModule,
            DxiColumnModule,
            DxiButtonModule,
            DxoLookupModule,
            DxoFormatModule,
            DxoFormItemModule,
            DxoLabelModule,
            DxiValidationRuleModule,
            DxoHeaderFilterModule,
            DxoEditingModule,
            DxiChangeModule,
            DxoFormModule,
            DxoColCountByScreenModule,
            DxiItemModule,
            DxoTabPanelOptionsModule,
            DxiTabModule,
            DxoButtonOptionsModule,
            DxoPopupModule,
            DxoAnimationModule,
            DxoHideModule,
            DxoFromModule,
            DxoToModule,
            DxoShowModule,
            DxoExportModule,
            DxoFilterBuilderModule,
            DxiCustomOperationModule,
            DxiFieldModule,
            DxoFilterOperationDescriptionsModule,
            DxoGroupOperationDescriptionsModule,
            DxoFilterBuilderPopupModule,
            DxoFilterPanelModule,
            DxoFilterRowModule,
            DxoOperationDescriptionsModule,
            DxoGroupingModule,
            DxoGroupPanelModule,
            DxoKeyboardNavigationModule,
            DxoLoadPanelModule,
            DxoMasterDetailModule,
            DxoPagerModule,
            DxoPagingModule,
            DxoRemoteOperationsModule,
            DxoRowDraggingModule,
            DxoCursorOffsetModule,
            DxoScrollingModule,
            DxoSearchPanelModule,
            DxiSortByGroupSummaryInfoModule,
            DxoSortingModule,
            DxoStateStoringModule,
            DxoSummaryModule,
            DxiGroupItemModule,
            DxoValueFormatModule,
            DxiTotalItemModule,
            DxoToolbarModule,
            DxoDataGridAIModule,
            DxoDataGridAIAssistantModule,
            DxoDataGridAIOptionsModule,
            DxoDataGridAnimationModule,
            DxiDataGridAsyncRuleModule,
            DxoDataGridAtModule,
            DxoDataGridBoundaryOffsetModule,
            DxiDataGridButtonModule,
            DxiDataGridButtonItemModule,
            DxoDataGridButtonOptionsModule,
            DxiDataGridChangeModule,
            DxoDataGridColCountByScreenModule,
            DxoDataGridCollisionModule,
            DxiDataGridColumnModule,
            DxiDataGridColumnButtonModule,
            DxoDataGridColumnChooserModule,
            DxoDataGridColumnChooserSearchModule,
            DxoDataGridColumnChooserSelectionModule,
            DxoDataGridColumnFixingModule,
            DxoDataGridColumnFixingTextsModule,
            DxoDataGridColumnHeaderFilterModule,
            DxoDataGridColumnHeaderFilterSearchModule,
            DxoDataGridColumnLookupModule,
            DxiDataGridCompareRuleModule,
            DxoDataGridCursorOffsetModule,
            DxiDataGridCustomOperationModule,
            DxiDataGridCustomRuleModule,
            DxoDataGridDataGridHeaderFilterModule,
            DxoDataGridDataGridHeaderFilterSearchModule,
            DxoDataGridDataGridHeaderFilterTextsModule,
            DxoDataGridDataGridSelectionModule,
            DxiDataGridDataGridToolbarItemModule,
            DxoDataGridEditingModule,
            DxoDataGridEditingTextsModule,
            DxoDataGridEditorOptionsModule,
            DxiDataGridEditorOptionsButtonModule,
            DxiDataGridEmailRuleModule,
            DxiDataGridEmptyItemModule,
            DxoDataGridExportModule,
            DxoDataGridExportTextsModule,
            DxiDataGridFieldModule,
            DxoDataGridFieldLookupModule,
            DxoDataGridFilterBuilderModule,
            DxoDataGridFilterBuilderPopupModule,
            DxoDataGridFilterOperationDescriptionsModule,
            DxoDataGridFilterPanelModule,
            DxoDataGridFilterPanelTextsModule,
            DxoDataGridFilterRowModule,
            DxoDataGridFormModule,
            DxoDataGridFormatModule,
            DxiDataGridFormGroupItemModule,
            DxoDataGridFormItemModule,
            DxoDataGridFromModule,
            DxoDataGridGroupingModule,
            DxoDataGridGroupingTextsModule,
            DxiDataGridGroupItemModule,
            DxoDataGridGroupOperationDescriptionsModule,
            DxoDataGridGroupPanelModule,
            DxoDataGridHeaderFilterModule,
            DxoDataGridHideModule,
            DxoDataGridIconsModule,
            DxoDataGridIndicatorOptionsModule,
            DxiDataGridItemModule,
            DxoDataGridKeyboardNavigationModule,
            DxoDataGridLabelModule,
            DxoDataGridLoadPanelModule,
            DxoDataGridLookupModule,
            DxoDataGridMasterDetailModule,
            DxoDataGridMyModule,
            DxiDataGridNumericRuleModule,
            DxoDataGridOffsetModule,
            DxoDataGridOperationDescriptionsModule,
            DxoDataGridOptionsModule,
            DxoDataGridPagerModule,
            DxoDataGridPagingModule,
            DxiDataGridPatternRuleModule,
            DxoDataGridPopupModule,
            DxoDataGridPositionModule,
            DxiDataGridRangeRuleModule,
            DxoDataGridRemoteOperationsModule,
            DxiDataGridRequiredRuleModule,
            DxoDataGridRowDraggingModule,
            DxoDataGridScrollingModule,
            DxoDataGridSearchModule,
            DxoDataGridSearchPanelModule,
            DxoDataGridSelectionModule,
            DxoDataGridShowModule,
            DxiDataGridSimpleItemModule,
            DxiDataGridSortByGroupSummaryInfoModule,
            DxoDataGridSortingModule,
            DxoDataGridStateStoringModule,
            DxiDataGridStringLengthRuleModule,
            DxoDataGridSummaryModule,
            DxoDataGridSummaryTextsModule,
            DxiDataGridTabModule,
            DxiDataGridTabbedItemModule,
            DxoDataGridTabPanelOptionsModule,
            DxiDataGridTabPanelOptionsItemModule,
            DxoDataGridTextsModule,
            DxoDataGridToModule,
            DxoDataGridToolbarModule,
            DxiDataGridToolbarItemModule,
            DxiDataGridTotalItemModule,
            DxiDataGridValidationRuleModule,
            DxoDataGridValueFormatModule,
            DxIntegrationModule,
            DxTemplateModule, DxoColumnChooserModule,
            DxoPositionModule,
            DxoAtModule,
            DxoBoundaryOffsetModule,
            DxoCollisionModule,
            DxoMyModule,
            DxoOffsetModule,
            DxoSearchModule,
            DxoSelectionModule,
            DxoColumnFixingModule,
            DxoIconsModule,
            DxoTextsModule,
            DxiColumnModule,
            DxiButtonModule,
            DxoLookupModule,
            DxoFormatModule,
            DxoFormItemModule,
            DxoLabelModule,
            DxiValidationRuleModule,
            DxoHeaderFilterModule,
            DxoEditingModule,
            DxiChangeModule,
            DxoFormModule,
            DxoColCountByScreenModule,
            DxiItemModule,
            DxoTabPanelOptionsModule,
            DxiTabModule,
            DxoButtonOptionsModule,
            DxoPopupModule,
            DxoAnimationModule,
            DxoHideModule,
            DxoFromModule,
            DxoToModule,
            DxoShowModule,
            DxoExportModule,
            DxoFilterBuilderModule,
            DxiCustomOperationModule,
            DxiFieldModule,
            DxoFilterOperationDescriptionsModule,
            DxoGroupOperationDescriptionsModule,
            DxoFilterBuilderPopupModule,
            DxoFilterPanelModule,
            DxoFilterRowModule,
            DxoOperationDescriptionsModule,
            DxoGroupingModule,
            DxoGroupPanelModule,
            DxoKeyboardNavigationModule,
            DxoLoadPanelModule,
            DxoMasterDetailModule,
            DxoPagerModule,
            DxoPagingModule,
            DxoRemoteOperationsModule,
            DxoRowDraggingModule,
            DxoCursorOffsetModule,
            DxoScrollingModule,
            DxoSearchPanelModule,
            DxiSortByGroupSummaryInfoModule,
            DxoSortingModule,
            DxoStateStoringModule,
            DxoSummaryModule,
            DxiGroupItemModule,
            DxoValueFormatModule,
            DxiTotalItemModule,
            DxoToolbarModule,
            DxoDataGridAIModule,
            DxoDataGridAIAssistantModule,
            DxoDataGridAIOptionsModule,
            DxoDataGridAnimationModule,
            DxiDataGridAsyncRuleModule,
            DxoDataGridAtModule,
            DxoDataGridBoundaryOffsetModule,
            DxiDataGridButtonModule,
            DxiDataGridButtonItemModule,
            DxoDataGridButtonOptionsModule,
            DxiDataGridChangeModule,
            DxoDataGridColCountByScreenModule,
            DxoDataGridCollisionModule,
            DxiDataGridColumnModule,
            DxiDataGridColumnButtonModule,
            DxoDataGridColumnChooserModule,
            DxoDataGridColumnChooserSearchModule,
            DxoDataGridColumnChooserSelectionModule,
            DxoDataGridColumnFixingModule,
            DxoDataGridColumnFixingTextsModule,
            DxoDataGridColumnHeaderFilterModule,
            DxoDataGridColumnHeaderFilterSearchModule,
            DxoDataGridColumnLookupModule,
            DxiDataGridCompareRuleModule,
            DxoDataGridCursorOffsetModule,
            DxiDataGridCustomOperationModule,
            DxiDataGridCustomRuleModule,
            DxoDataGridDataGridHeaderFilterModule,
            DxoDataGridDataGridHeaderFilterSearchModule,
            DxoDataGridDataGridHeaderFilterTextsModule,
            DxoDataGridDataGridSelectionModule,
            DxiDataGridDataGridToolbarItemModule,
            DxoDataGridEditingModule,
            DxoDataGridEditingTextsModule,
            DxoDataGridEditorOptionsModule,
            DxiDataGridEditorOptionsButtonModule,
            DxiDataGridEmailRuleModule,
            DxiDataGridEmptyItemModule,
            DxoDataGridExportModule,
            DxoDataGridExportTextsModule,
            DxiDataGridFieldModule,
            DxoDataGridFieldLookupModule,
            DxoDataGridFilterBuilderModule,
            DxoDataGridFilterBuilderPopupModule,
            DxoDataGridFilterOperationDescriptionsModule,
            DxoDataGridFilterPanelModule,
            DxoDataGridFilterPanelTextsModule,
            DxoDataGridFilterRowModule,
            DxoDataGridFormModule,
            DxoDataGridFormatModule,
            DxiDataGridFormGroupItemModule,
            DxoDataGridFormItemModule,
            DxoDataGridFromModule,
            DxoDataGridGroupingModule,
            DxoDataGridGroupingTextsModule,
            DxiDataGridGroupItemModule,
            DxoDataGridGroupOperationDescriptionsModule,
            DxoDataGridGroupPanelModule,
            DxoDataGridHeaderFilterModule,
            DxoDataGridHideModule,
            DxoDataGridIconsModule,
            DxoDataGridIndicatorOptionsModule,
            DxiDataGridItemModule,
            DxoDataGridKeyboardNavigationModule,
            DxoDataGridLabelModule,
            DxoDataGridLoadPanelModule,
            DxoDataGridLookupModule,
            DxoDataGridMasterDetailModule,
            DxoDataGridMyModule,
            DxiDataGridNumericRuleModule,
            DxoDataGridOffsetModule,
            DxoDataGridOperationDescriptionsModule,
            DxoDataGridOptionsModule,
            DxoDataGridPagerModule,
            DxoDataGridPagingModule,
            DxiDataGridPatternRuleModule,
            DxoDataGridPopupModule,
            DxoDataGridPositionModule,
            DxiDataGridRangeRuleModule,
            DxoDataGridRemoteOperationsModule,
            DxiDataGridRequiredRuleModule,
            DxoDataGridRowDraggingModule,
            DxoDataGridScrollingModule,
            DxoDataGridSearchModule,
            DxoDataGridSearchPanelModule,
            DxoDataGridSelectionModule,
            DxoDataGridShowModule,
            DxiDataGridSimpleItemModule,
            DxiDataGridSortByGroupSummaryInfoModule,
            DxoDataGridSortingModule,
            DxoDataGridStateStoringModule,
            DxiDataGridStringLengthRuleModule,
            DxoDataGridSummaryModule,
            DxoDataGridSummaryTextsModule,
            DxiDataGridTabModule,
            DxiDataGridTabbedItemModule,
            DxoDataGridTabPanelOptionsModule,
            DxiDataGridTabPanelOptionsItemModule,
            DxoDataGridTextsModule,
            DxoDataGridToModule,
            DxoDataGridToolbarModule,
            DxiDataGridToolbarItemModule,
            DxiDataGridTotalItemModule,
            DxiDataGridValidationRuleModule,
            DxoDataGridValueFormatModule,
            DxTemplateModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxDataGridModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxDataGridComponent,
                        DxoColumnChooserModule,
                        DxoPositionModule,
                        DxoAtModule,
                        DxoBoundaryOffsetModule,
                        DxoCollisionModule,
                        DxoMyModule,
                        DxoOffsetModule,
                        DxoSearchModule,
                        DxoSelectionModule,
                        DxoColumnFixingModule,
                        DxoIconsModule,
                        DxoTextsModule,
                        DxiColumnModule,
                        DxiButtonModule,
                        DxoLookupModule,
                        DxoFormatModule,
                        DxoFormItemModule,
                        DxoLabelModule,
                        DxiValidationRuleModule,
                        DxoHeaderFilterModule,
                        DxoEditingModule,
                        DxiChangeModule,
                        DxoFormModule,
                        DxoColCountByScreenModule,
                        DxiItemModule,
                        DxoTabPanelOptionsModule,
                        DxiTabModule,
                        DxoButtonOptionsModule,
                        DxoPopupModule,
                        DxoAnimationModule,
                        DxoHideModule,
                        DxoFromModule,
                        DxoToModule,
                        DxoShowModule,
                        DxoExportModule,
                        DxoFilterBuilderModule,
                        DxiCustomOperationModule,
                        DxiFieldModule,
                        DxoFilterOperationDescriptionsModule,
                        DxoGroupOperationDescriptionsModule,
                        DxoFilterBuilderPopupModule,
                        DxoFilterPanelModule,
                        DxoFilterRowModule,
                        DxoOperationDescriptionsModule,
                        DxoGroupingModule,
                        DxoGroupPanelModule,
                        DxoKeyboardNavigationModule,
                        DxoLoadPanelModule,
                        DxoMasterDetailModule,
                        DxoPagerModule,
                        DxoPagingModule,
                        DxoRemoteOperationsModule,
                        DxoRowDraggingModule,
                        DxoCursorOffsetModule,
                        DxoScrollingModule,
                        DxoSearchPanelModule,
                        DxiSortByGroupSummaryInfoModule,
                        DxoSortingModule,
                        DxoStateStoringModule,
                        DxoSummaryModule,
                        DxiGroupItemModule,
                        DxoValueFormatModule,
                        DxiTotalItemModule,
                        DxoToolbarModule,
                        DxoDataGridAIModule,
                        DxoDataGridAIAssistantModule,
                        DxoDataGridAIOptionsModule,
                        DxoDataGridAnimationModule,
                        DxiDataGridAsyncRuleModule,
                        DxoDataGridAtModule,
                        DxoDataGridBoundaryOffsetModule,
                        DxiDataGridButtonModule,
                        DxiDataGridButtonItemModule,
                        DxoDataGridButtonOptionsModule,
                        DxiDataGridChangeModule,
                        DxoDataGridColCountByScreenModule,
                        DxoDataGridCollisionModule,
                        DxiDataGridColumnModule,
                        DxiDataGridColumnButtonModule,
                        DxoDataGridColumnChooserModule,
                        DxoDataGridColumnChooserSearchModule,
                        DxoDataGridColumnChooserSelectionModule,
                        DxoDataGridColumnFixingModule,
                        DxoDataGridColumnFixingTextsModule,
                        DxoDataGridColumnHeaderFilterModule,
                        DxoDataGridColumnHeaderFilterSearchModule,
                        DxoDataGridColumnLookupModule,
                        DxiDataGridCompareRuleModule,
                        DxoDataGridCursorOffsetModule,
                        DxiDataGridCustomOperationModule,
                        DxiDataGridCustomRuleModule,
                        DxoDataGridDataGridHeaderFilterModule,
                        DxoDataGridDataGridHeaderFilterSearchModule,
                        DxoDataGridDataGridHeaderFilterTextsModule,
                        DxoDataGridDataGridSelectionModule,
                        DxiDataGridDataGridToolbarItemModule,
                        DxoDataGridEditingModule,
                        DxoDataGridEditingTextsModule,
                        DxoDataGridEditorOptionsModule,
                        DxiDataGridEditorOptionsButtonModule,
                        DxiDataGridEmailRuleModule,
                        DxiDataGridEmptyItemModule,
                        DxoDataGridExportModule,
                        DxoDataGridExportTextsModule,
                        DxiDataGridFieldModule,
                        DxoDataGridFieldLookupModule,
                        DxoDataGridFilterBuilderModule,
                        DxoDataGridFilterBuilderPopupModule,
                        DxoDataGridFilterOperationDescriptionsModule,
                        DxoDataGridFilterPanelModule,
                        DxoDataGridFilterPanelTextsModule,
                        DxoDataGridFilterRowModule,
                        DxoDataGridFormModule,
                        DxoDataGridFormatModule,
                        DxiDataGridFormGroupItemModule,
                        DxoDataGridFormItemModule,
                        DxoDataGridFromModule,
                        DxoDataGridGroupingModule,
                        DxoDataGridGroupingTextsModule,
                        DxiDataGridGroupItemModule,
                        DxoDataGridGroupOperationDescriptionsModule,
                        DxoDataGridGroupPanelModule,
                        DxoDataGridHeaderFilterModule,
                        DxoDataGridHideModule,
                        DxoDataGridIconsModule,
                        DxoDataGridIndicatorOptionsModule,
                        DxiDataGridItemModule,
                        DxoDataGridKeyboardNavigationModule,
                        DxoDataGridLabelModule,
                        DxoDataGridLoadPanelModule,
                        DxoDataGridLookupModule,
                        DxoDataGridMasterDetailModule,
                        DxoDataGridMyModule,
                        DxiDataGridNumericRuleModule,
                        DxoDataGridOffsetModule,
                        DxoDataGridOperationDescriptionsModule,
                        DxoDataGridOptionsModule,
                        DxoDataGridPagerModule,
                        DxoDataGridPagingModule,
                        DxiDataGridPatternRuleModule,
                        DxoDataGridPopupModule,
                        DxoDataGridPositionModule,
                        DxiDataGridRangeRuleModule,
                        DxoDataGridRemoteOperationsModule,
                        DxiDataGridRequiredRuleModule,
                        DxoDataGridRowDraggingModule,
                        DxoDataGridScrollingModule,
                        DxoDataGridSearchModule,
                        DxoDataGridSearchPanelModule,
                        DxoDataGridSelectionModule,
                        DxoDataGridShowModule,
                        DxiDataGridSimpleItemModule,
                        DxiDataGridSortByGroupSummaryInfoModule,
                        DxoDataGridSortingModule,
                        DxoDataGridStateStoringModule,
                        DxiDataGridStringLengthRuleModule,
                        DxoDataGridSummaryModule,
                        DxoDataGridSummaryTextsModule,
                        DxiDataGridTabModule,
                        DxiDataGridTabbedItemModule,
                        DxoDataGridTabPanelOptionsModule,
                        DxiDataGridTabPanelOptionsItemModule,
                        DxoDataGridTextsModule,
                        DxoDataGridToModule,
                        DxoDataGridToolbarModule,
                        DxiDataGridToolbarItemModule,
                        DxiDataGridTotalItemModule,
                        DxiDataGridValidationRuleModule,
                        DxoDataGridValueFormatModule,
                        DxIntegrationModule,
                        DxTemplateModule
                    ],
                    exports: [
                        DxDataGridComponent,
                        DxoColumnChooserModule,
                        DxoPositionModule,
                        DxoAtModule,
                        DxoBoundaryOffsetModule,
                        DxoCollisionModule,
                        DxoMyModule,
                        DxoOffsetModule,
                        DxoSearchModule,
                        DxoSelectionModule,
                        DxoColumnFixingModule,
                        DxoIconsModule,
                        DxoTextsModule,
                        DxiColumnModule,
                        DxiButtonModule,
                        DxoLookupModule,
                        DxoFormatModule,
                        DxoFormItemModule,
                        DxoLabelModule,
                        DxiValidationRuleModule,
                        DxoHeaderFilterModule,
                        DxoEditingModule,
                        DxiChangeModule,
                        DxoFormModule,
                        DxoColCountByScreenModule,
                        DxiItemModule,
                        DxoTabPanelOptionsModule,
                        DxiTabModule,
                        DxoButtonOptionsModule,
                        DxoPopupModule,
                        DxoAnimationModule,
                        DxoHideModule,
                        DxoFromModule,
                        DxoToModule,
                        DxoShowModule,
                        DxoExportModule,
                        DxoFilterBuilderModule,
                        DxiCustomOperationModule,
                        DxiFieldModule,
                        DxoFilterOperationDescriptionsModule,
                        DxoGroupOperationDescriptionsModule,
                        DxoFilterBuilderPopupModule,
                        DxoFilterPanelModule,
                        DxoFilterRowModule,
                        DxoOperationDescriptionsModule,
                        DxoGroupingModule,
                        DxoGroupPanelModule,
                        DxoKeyboardNavigationModule,
                        DxoLoadPanelModule,
                        DxoMasterDetailModule,
                        DxoPagerModule,
                        DxoPagingModule,
                        DxoRemoteOperationsModule,
                        DxoRowDraggingModule,
                        DxoCursorOffsetModule,
                        DxoScrollingModule,
                        DxoSearchPanelModule,
                        DxiSortByGroupSummaryInfoModule,
                        DxoSortingModule,
                        DxoStateStoringModule,
                        DxoSummaryModule,
                        DxiGroupItemModule,
                        DxoValueFormatModule,
                        DxiTotalItemModule,
                        DxoToolbarModule,
                        DxoDataGridAIModule,
                        DxoDataGridAIAssistantModule,
                        DxoDataGridAIOptionsModule,
                        DxoDataGridAnimationModule,
                        DxiDataGridAsyncRuleModule,
                        DxoDataGridAtModule,
                        DxoDataGridBoundaryOffsetModule,
                        DxiDataGridButtonModule,
                        DxiDataGridButtonItemModule,
                        DxoDataGridButtonOptionsModule,
                        DxiDataGridChangeModule,
                        DxoDataGridColCountByScreenModule,
                        DxoDataGridCollisionModule,
                        DxiDataGridColumnModule,
                        DxiDataGridColumnButtonModule,
                        DxoDataGridColumnChooserModule,
                        DxoDataGridColumnChooserSearchModule,
                        DxoDataGridColumnChooserSelectionModule,
                        DxoDataGridColumnFixingModule,
                        DxoDataGridColumnFixingTextsModule,
                        DxoDataGridColumnHeaderFilterModule,
                        DxoDataGridColumnHeaderFilterSearchModule,
                        DxoDataGridColumnLookupModule,
                        DxiDataGridCompareRuleModule,
                        DxoDataGridCursorOffsetModule,
                        DxiDataGridCustomOperationModule,
                        DxiDataGridCustomRuleModule,
                        DxoDataGridDataGridHeaderFilterModule,
                        DxoDataGridDataGridHeaderFilterSearchModule,
                        DxoDataGridDataGridHeaderFilterTextsModule,
                        DxoDataGridDataGridSelectionModule,
                        DxiDataGridDataGridToolbarItemModule,
                        DxoDataGridEditingModule,
                        DxoDataGridEditingTextsModule,
                        DxoDataGridEditorOptionsModule,
                        DxiDataGridEditorOptionsButtonModule,
                        DxiDataGridEmailRuleModule,
                        DxiDataGridEmptyItemModule,
                        DxoDataGridExportModule,
                        DxoDataGridExportTextsModule,
                        DxiDataGridFieldModule,
                        DxoDataGridFieldLookupModule,
                        DxoDataGridFilterBuilderModule,
                        DxoDataGridFilterBuilderPopupModule,
                        DxoDataGridFilterOperationDescriptionsModule,
                        DxoDataGridFilterPanelModule,
                        DxoDataGridFilterPanelTextsModule,
                        DxoDataGridFilterRowModule,
                        DxoDataGridFormModule,
                        DxoDataGridFormatModule,
                        DxiDataGridFormGroupItemModule,
                        DxoDataGridFormItemModule,
                        DxoDataGridFromModule,
                        DxoDataGridGroupingModule,
                        DxoDataGridGroupingTextsModule,
                        DxiDataGridGroupItemModule,
                        DxoDataGridGroupOperationDescriptionsModule,
                        DxoDataGridGroupPanelModule,
                        DxoDataGridHeaderFilterModule,
                        DxoDataGridHideModule,
                        DxoDataGridIconsModule,
                        DxoDataGridIndicatorOptionsModule,
                        DxiDataGridItemModule,
                        DxoDataGridKeyboardNavigationModule,
                        DxoDataGridLabelModule,
                        DxoDataGridLoadPanelModule,
                        DxoDataGridLookupModule,
                        DxoDataGridMasterDetailModule,
                        DxoDataGridMyModule,
                        DxiDataGridNumericRuleModule,
                        DxoDataGridOffsetModule,
                        DxoDataGridOperationDescriptionsModule,
                        DxoDataGridOptionsModule,
                        DxoDataGridPagerModule,
                        DxoDataGridPagingModule,
                        DxiDataGridPatternRuleModule,
                        DxoDataGridPopupModule,
                        DxoDataGridPositionModule,
                        DxiDataGridRangeRuleModule,
                        DxoDataGridRemoteOperationsModule,
                        DxiDataGridRequiredRuleModule,
                        DxoDataGridRowDraggingModule,
                        DxoDataGridScrollingModule,
                        DxoDataGridSearchModule,
                        DxoDataGridSearchPanelModule,
                        DxoDataGridSelectionModule,
                        DxoDataGridShowModule,
                        DxiDataGridSimpleItemModule,
                        DxiDataGridSortByGroupSummaryInfoModule,
                        DxoDataGridSortingModule,
                        DxoDataGridStateStoringModule,
                        DxiDataGridStringLengthRuleModule,
                        DxoDataGridSummaryModule,
                        DxoDataGridSummaryTextsModule,
                        DxiDataGridTabModule,
                        DxiDataGridTabbedItemModule,
                        DxoDataGridTabPanelOptionsModule,
                        DxiDataGridTabPanelOptionsItemModule,
                        DxoDataGridTextsModule,
                        DxoDataGridToModule,
                        DxoDataGridToolbarModule,
                        DxiDataGridToolbarItemModule,
                        DxiDataGridTotalItemModule,
                        DxiDataGridValidationRuleModule,
                        DxoDataGridValueFormatModule,
                        DxTemplateModule
                    ]
                }]
        }] });

/**
 * Generated bundle index. Do not edit.
 */

export { DxDataGridComponent, DxDataGridModule };
//# sourceMappingURL=devextreme-angular-ui-data-grid.mjs.map
