import * as i0 from '@angular/core';
import { Output, Input, SkipSelf, Host, Component, NgModule, ContentChildren, Inject } from '@angular/core';
import * as i1 from 'devextreme-angular/core';
import { CollectionNestedOption, DxIntegrationModule, NestedOptionHost, NestedOption, extractTemplate, DxTemplateHost } from 'devextreme-angular/core';
import { PROPERTY_TOKEN_columns, PROPERTY_TOKEN_items, PROPERTY_TOKEN_stripLines } from 'devextreme-angular/core/tokens';
import { DOCUMENT } from '@angular/common';

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxiGanttColumnComponent extends CollectionNestedOption {
    get alignment() {
        return this._getOption('alignment');
    }
    set alignment(value) {
        this._setOption('alignment', value);
    }
    get allowFiltering() {
        return this._getOption('allowFiltering');
    }
    set allowFiltering(value) {
        this._setOption('allowFiltering', value);
    }
    get allowHeaderFiltering() {
        return this._getOption('allowHeaderFiltering');
    }
    set allowHeaderFiltering(value) {
        this._setOption('allowHeaderFiltering', value);
    }
    get allowSorting() {
        return this._getOption('allowSorting');
    }
    set allowSorting(value) {
        this._setOption('allowSorting', value);
    }
    get calculateCellValue() {
        return this._getOption('calculateCellValue');
    }
    set calculateCellValue(value) {
        this._setOption('calculateCellValue', value);
    }
    get calculateDisplayValue() {
        return this._getOption('calculateDisplayValue');
    }
    set calculateDisplayValue(value) {
        this._setOption('calculateDisplayValue', value);
    }
    get calculateFilterExpression() {
        return this._getOption('calculateFilterExpression');
    }
    set calculateFilterExpression(value) {
        this._setOption('calculateFilterExpression', value);
    }
    get calculateSortValue() {
        return this._getOption('calculateSortValue');
    }
    set calculateSortValue(value) {
        this._setOption('calculateSortValue', value);
    }
    get caption() {
        return this._getOption('caption');
    }
    set caption(value) {
        this._setOption('caption', value);
    }
    get cellTemplate() {
        return this._getOption('cellTemplate');
    }
    set cellTemplate(value) {
        this._setOption('cellTemplate', value);
    }
    get cssClass() {
        return this._getOption('cssClass');
    }
    set cssClass(value) {
        this._setOption('cssClass', value);
    }
    get customizeText() {
        return this._getOption('customizeText');
    }
    set customizeText(value) {
        this._setOption('customizeText', value);
    }
    get dataField() {
        return this._getOption('dataField');
    }
    set dataField(value) {
        this._setOption('dataField', value);
    }
    get dataType() {
        return this._getOption('dataType');
    }
    set dataType(value) {
        this._setOption('dataType', value);
    }
    get encodeHtml() {
        return this._getOption('encodeHtml');
    }
    set encodeHtml(value) {
        this._setOption('encodeHtml', value);
    }
    get falseText() {
        return this._getOption('falseText');
    }
    set falseText(value) {
        this._setOption('falseText', value);
    }
    get filterOperations() {
        return this._getOption('filterOperations');
    }
    set filterOperations(value) {
        this._setOption('filterOperations', value);
    }
    get filterType() {
        return this._getOption('filterType');
    }
    set filterType(value) {
        this._setOption('filterType', value);
    }
    get filterValue() {
        return this._getOption('filterValue');
    }
    set filterValue(value) {
        this._setOption('filterValue', value);
    }
    get filterValues() {
        return this._getOption('filterValues');
    }
    set filterValues(value) {
        this._setOption('filterValues', value);
    }
    get format() {
        return this._getOption('format');
    }
    set format(value) {
        this._setOption('format', value);
    }
    get headerCellTemplate() {
        return this._getOption('headerCellTemplate');
    }
    set headerCellTemplate(value) {
        this._setOption('headerCellTemplate', value);
    }
    get headerFilter() {
        return this._getOption('headerFilter');
    }
    set headerFilter(value) {
        this._setOption('headerFilter', value);
    }
    get minWidth() {
        return this._getOption('minWidth');
    }
    set minWidth(value) {
        this._setOption('minWidth', value);
    }
    get selectedFilterOperation() {
        return this._getOption('selectedFilterOperation');
    }
    set selectedFilterOperation(value) {
        this._setOption('selectedFilterOperation', value);
    }
    get sortIndex() {
        return this._getOption('sortIndex');
    }
    set sortIndex(value) {
        this._setOption('sortIndex', value);
    }
    get sortingMethod() {
        return this._getOption('sortingMethod');
    }
    set sortingMethod(value) {
        this._setOption('sortingMethod', value);
    }
    get sortOrder() {
        return this._getOption('sortOrder');
    }
    set sortOrder(value) {
        this._setOption('sortOrder', value);
    }
    get trueText() {
        return this._getOption('trueText');
    }
    set trueText(value) {
        this._setOption('trueText', value);
    }
    get visible() {
        return this._getOption('visible');
    }
    set visible(value) {
        this._setOption('visible', value);
    }
    get visibleIndex() {
        return this._getOption('visibleIndex');
    }
    set visibleIndex(value) {
        this._setOption('visibleIndex', value);
    }
    get width() {
        return this._getOption('width');
    }
    set width(value) {
        this._setOption('width', value);
    }
    get _optionPath() {
        return 'columns';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        this._createEventEmitters([
            { emit: 'filterValueChange' },
            { emit: 'filterValuesChange' },
            { emit: 'selectedFilterOperationChange' },
            { emit: 'sortIndexChange' },
            { emit: 'sortOrderChange' },
            { emit: 'visibleChange' },
            { emit: 'visibleIndexChange' }
        ]);
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnDestroy() {
        this._deleteRemovedOptions(this._fullOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiGanttColumnComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxiGanttColumnComponent, isStandalone: true, selector: "dxi-gantt-column", inputs: { alignment: "alignment", allowFiltering: "allowFiltering", allowHeaderFiltering: "allowHeaderFiltering", allowSorting: "allowSorting", calculateCellValue: "calculateCellValue", calculateDisplayValue: "calculateDisplayValue", calculateFilterExpression: "calculateFilterExpression", calculateSortValue: "calculateSortValue", caption: "caption", cellTemplate: "cellTemplate", cssClass: "cssClass", customizeText: "customizeText", dataField: "dataField", dataType: "dataType", encodeHtml: "encodeHtml", falseText: "falseText", filterOperations: "filterOperations", filterType: "filterType", filterValue: "filterValue", filterValues: "filterValues", format: "format", headerCellTemplate: "headerCellTemplate", headerFilter: "headerFilter", minWidth: "minWidth", selectedFilterOperation: "selectedFilterOperation", sortIndex: "sortIndex", sortingMethod: "sortingMethod", sortOrder: "sortOrder", trueText: "trueText", visible: "visible", visibleIndex: "visibleIndex", width: "width" }, outputs: { filterValueChange: "filterValueChange", filterValuesChange: "filterValuesChange", selectedFilterOperationChange: "selectedFilterOperationChange", sortIndexChange: "sortIndexChange", sortOrderChange: "sortOrderChange", visibleChange: "visibleChange", visibleIndexChange: "visibleIndexChange" }, providers: [
            NestedOptionHost,
            {
                provide: PROPERTY_TOKEN_columns,
                useExisting: DxiGanttColumnComponent,
            }
        ], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiGanttColumnComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxi-gantt-column', template: '', imports: [DxIntegrationModule], providers: [
                        NestedOptionHost,
                        {
                            provide: PROPERTY_TOKEN_columns,
                            useExisting: DxiGanttColumnComponent,
                        }
                    ] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { alignment: [{
                type: Input
            }], allowFiltering: [{
                type: Input
            }], allowHeaderFiltering: [{
                type: Input
            }], allowSorting: [{
                type: Input
            }], calculateCellValue: [{
                type: Input
            }], calculateDisplayValue: [{
                type: Input
            }], calculateFilterExpression: [{
                type: Input
            }], calculateSortValue: [{
                type: Input
            }], caption: [{
                type: Input
            }], cellTemplate: [{
                type: Input
            }], cssClass: [{
                type: Input
            }], customizeText: [{
                type: Input
            }], dataField: [{
                type: Input
            }], dataType: [{
                type: Input
            }], encodeHtml: [{
                type: Input
            }], falseText: [{
                type: Input
            }], filterOperations: [{
                type: Input
            }], filterType: [{
                type: Input
            }], filterValue: [{
                type: Input
            }], filterValues: [{
                type: Input
            }], format: [{
                type: Input
            }], headerCellTemplate: [{
                type: Input
            }], headerFilter: [{
                type: Input
            }], minWidth: [{
                type: Input
            }], selectedFilterOperation: [{
                type: Input
            }], sortIndex: [{
                type: Input
            }], sortingMethod: [{
                type: Input
            }], sortOrder: [{
                type: Input
            }], trueText: [{
                type: Input
            }], visible: [{
                type: Input
            }], visibleIndex: [{
                type: Input
            }], width: [{
                type: Input
            }], filterValueChange: [{
                type: Output
            }], filterValuesChange: [{
                type: Output
            }], selectedFilterOperationChange: [{
                type: Output
            }], sortIndexChange: [{
                type: Output
            }], sortOrderChange: [{
                type: Output
            }], visibleChange: [{
                type: Output
            }], visibleIndexChange: [{
                type: Output
            }] } });
class DxiGanttColumnModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiGanttColumnModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxiGanttColumnModule, imports: [DxiGanttColumnComponent], exports: [DxiGanttColumnComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiGanttColumnModule, imports: [DxiGanttColumnComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiGanttColumnModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxiGanttColumnComponent
                    ],
                    exports: [
                        DxiGanttColumnComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoGanttColumnHeaderFilterSearchComponent extends NestedOption {
    get editorOptions() {
        return this._getOption('editorOptions');
    }
    set editorOptions(value) {
        this._setOption('editorOptions', value);
    }
    get enabled() {
        return this._getOption('enabled');
    }
    set enabled(value) {
        this._setOption('enabled', value);
    }
    get mode() {
        return this._getOption('mode');
    }
    set mode(value) {
        this._setOption('mode', value);
    }
    get searchExpr() {
        return this._getOption('searchExpr');
    }
    set searchExpr(value) {
        this._setOption('searchExpr', value);
    }
    get timeout() {
        return this._getOption('timeout');
    }
    set timeout(value) {
        this._setOption('timeout', value);
    }
    get _optionPath() {
        return 'search';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoGanttColumnHeaderFilterSearchComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoGanttColumnHeaderFilterSearchComponent, isStandalone: true, selector: "dxo-gantt-column-header-filter-search", inputs: { editorOptions: "editorOptions", enabled: "enabled", mode: "mode", searchExpr: "searchExpr", timeout: "timeout" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoGanttColumnHeaderFilterSearchComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-gantt-column-header-filter-search', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { editorOptions: [{
                type: Input
            }], enabled: [{
                type: Input
            }], mode: [{
                type: Input
            }], searchExpr: [{
                type: Input
            }], timeout: [{
                type: Input
            }] } });
class DxoGanttColumnHeaderFilterSearchModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoGanttColumnHeaderFilterSearchModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoGanttColumnHeaderFilterSearchModule, imports: [DxoGanttColumnHeaderFilterSearchComponent], exports: [DxoGanttColumnHeaderFilterSearchComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoGanttColumnHeaderFilterSearchModule, imports: [DxoGanttColumnHeaderFilterSearchComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoGanttColumnHeaderFilterSearchModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoGanttColumnHeaderFilterSearchComponent
                    ],
                    exports: [
                        DxoGanttColumnHeaderFilterSearchComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoGanttColumnHeaderFilterComponent extends NestedOption {
    get allowSearch() {
        return this._getOption('allowSearch');
    }
    set allowSearch(value) {
        this._setOption('allowSearch', value);
    }
    get allowSelectAll() {
        return this._getOption('allowSelectAll');
    }
    set allowSelectAll(value) {
        this._setOption('allowSelectAll', value);
    }
    get dataSource() {
        return this._getOption('dataSource');
    }
    set dataSource(value) {
        this._setOption('dataSource', value);
    }
    get groupInterval() {
        return this._getOption('groupInterval');
    }
    set groupInterval(value) {
        this._setOption('groupInterval', value);
    }
    get height() {
        return this._getOption('height');
    }
    set height(value) {
        this._setOption('height', value);
    }
    get search() {
        return this._getOption('search');
    }
    set search(value) {
        this._setOption('search', value);
    }
    get searchMode() {
        return this._getOption('searchMode');
    }
    set searchMode(value) {
        this._setOption('searchMode', value);
    }
    get width() {
        return this._getOption('width');
    }
    set width(value) {
        this._setOption('width', value);
    }
    get _optionPath() {
        return 'headerFilter';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoGanttColumnHeaderFilterComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoGanttColumnHeaderFilterComponent, isStandalone: true, selector: "dxo-gantt-column-header-filter", inputs: { allowSearch: "allowSearch", allowSelectAll: "allowSelectAll", dataSource: "dataSource", groupInterval: "groupInterval", height: "height", search: "search", searchMode: "searchMode", width: "width" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoGanttColumnHeaderFilterComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-gantt-column-header-filter', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { allowSearch: [{
                type: Input
            }], allowSelectAll: [{
                type: Input
            }], dataSource: [{
                type: Input
            }], groupInterval: [{
                type: Input
            }], height: [{
                type: Input
            }], search: [{
                type: Input
            }], searchMode: [{
                type: Input
            }], width: [{
                type: Input
            }] } });
class DxoGanttColumnHeaderFilterModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoGanttColumnHeaderFilterModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoGanttColumnHeaderFilterModule, imports: [DxoGanttColumnHeaderFilterComponent], exports: [DxoGanttColumnHeaderFilterComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoGanttColumnHeaderFilterModule, imports: [DxoGanttColumnHeaderFilterComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoGanttColumnHeaderFilterModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoGanttColumnHeaderFilterComponent
                    ],
                    exports: [
                        DxoGanttColumnHeaderFilterComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxiGanttContextMenuItemComponent extends CollectionNestedOption {
    set _itemsContentChildren(value) {
        this.setChildren('items', value);
    }
    get beginGroup() {
        return this._getOption('beginGroup');
    }
    set beginGroup(value) {
        this._setOption('beginGroup', value);
    }
    get closeMenuOnClick() {
        return this._getOption('closeMenuOnClick');
    }
    set closeMenuOnClick(value) {
        this._setOption('closeMenuOnClick', value);
    }
    get disabled() {
        return this._getOption('disabled');
    }
    set disabled(value) {
        this._setOption('disabled', value);
    }
    get icon() {
        return this._getOption('icon');
    }
    set icon(value) {
        this._setOption('icon', value);
    }
    get items() {
        return this._getOption('items');
    }
    set items(value) {
        this._setOption('items', value);
    }
    get name() {
        return this._getOption('name');
    }
    set name(value) {
        this._setOption('name', value);
    }
    get selectable() {
        return this._getOption('selectable');
    }
    set selectable(value) {
        this._setOption('selectable', value);
    }
    get selected() {
        return this._getOption('selected');
    }
    set selected(value) {
        this._setOption('selected', value);
    }
    get template() {
        return this._getOption('template');
    }
    set template(value) {
        this._setOption('template', value);
    }
    get text() {
        return this._getOption('text');
    }
    set text(value) {
        this._setOption('text', value);
    }
    get visible() {
        return this._getOption('visible');
    }
    set visible(value) {
        this._setOption('visible', value);
    }
    get _optionPath() {
        return 'items';
    }
    constructor(parentOptionHost, optionHost, renderer, document, templateHost, element) {
        super();
        this.renderer = renderer;
        this.document = document;
        this.element = element;
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
        templateHost.setHost(this);
    }
    setTemplate(template) {
        this.template = template;
    }
    ngAfterViewInit() {
        extractTemplate(this, this.element, this.renderer, this.document);
    }
    ngOnDestroy() {
        this._deleteRemovedOptions(this._fullOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiGanttContextMenuItemComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }, { token: i0.Renderer2 }, { token: DOCUMENT }, { token: i1.DxTemplateHost, host: true }, { token: i0.ElementRef }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxiGanttContextMenuItemComponent, isStandalone: true, selector: "dxi-gantt-context-menu-item", inputs: { beginGroup: "beginGroup", closeMenuOnClick: "closeMenuOnClick", disabled: "disabled", icon: "icon", items: "items", name: "name", selectable: "selectable", selected: "selected", template: "template", text: "text", visible: "visible" }, providers: [
            NestedOptionHost,
            DxTemplateHost,
            {
                provide: PROPERTY_TOKEN_items,
                useExisting: DxiGanttContextMenuItemComponent,
            }
        ], queries: [{ propertyName: "_itemsContentChildren", predicate: PROPERTY_TOKEN_items }], usesInheritance: true, ngImport: i0, template: '<ng-content></ng-content>', isInline: true, styles: [":host{display:block}\n"], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiGanttContextMenuItemComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxi-gantt-context-menu-item', template: '<ng-content></ng-content>', imports: [DxIntegrationModule], providers: [
                        NestedOptionHost,
                        DxTemplateHost,
                        {
                            provide: PROPERTY_TOKEN_items,
                            useExisting: DxiGanttContextMenuItemComponent,
                        }
                    ], styles: [":host{display:block}\n"] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }, { type: i0.Renderer2 }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [DOCUMENT]
                }] }, { type: i1.DxTemplateHost, decorators: [{
                    type: Host
                }] }, { type: i0.ElementRef }], propDecorators: { _itemsContentChildren: [{
                type: ContentChildren,
                args: [PROPERTY_TOKEN_items]
            }], beginGroup: [{
                type: Input
            }], closeMenuOnClick: [{
                type: Input
            }], disabled: [{
                type: Input
            }], icon: [{
                type: Input
            }], items: [{
                type: Input
            }], name: [{
                type: Input
            }], selectable: [{
                type: Input
            }], selected: [{
                type: Input
            }], template: [{
                type: Input
            }], text: [{
                type: Input
            }], visible: [{
                type: Input
            }] } });
class DxiGanttContextMenuItemModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiGanttContextMenuItemModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxiGanttContextMenuItemModule, imports: [DxiGanttContextMenuItemComponent], exports: [DxiGanttContextMenuItemComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiGanttContextMenuItemModule, imports: [DxiGanttContextMenuItemComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiGanttContextMenuItemModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxiGanttContextMenuItemComponent
                    ],
                    exports: [
                        DxiGanttContextMenuItemComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxiGanttContextMenuItemItemComponent extends CollectionNestedOption {
    set _itemsContentChildren(value) {
        this.setChildren('items', value);
    }
    get beginGroup() {
        return this._getOption('beginGroup');
    }
    set beginGroup(value) {
        this._setOption('beginGroup', value);
    }
    get closeMenuOnClick() {
        return this._getOption('closeMenuOnClick');
    }
    set closeMenuOnClick(value) {
        this._setOption('closeMenuOnClick', value);
    }
    get disabled() {
        return this._getOption('disabled');
    }
    set disabled(value) {
        this._setOption('disabled', value);
    }
    get icon() {
        return this._getOption('icon');
    }
    set icon(value) {
        this._setOption('icon', value);
    }
    get items() {
        return this._getOption('items');
    }
    set items(value) {
        this._setOption('items', value);
    }
    get selectable() {
        return this._getOption('selectable');
    }
    set selectable(value) {
        this._setOption('selectable', value);
    }
    get selected() {
        return this._getOption('selected');
    }
    set selected(value) {
        this._setOption('selected', value);
    }
    get template() {
        return this._getOption('template');
    }
    set template(value) {
        this._setOption('template', value);
    }
    get text() {
        return this._getOption('text');
    }
    set text(value) {
        this._setOption('text', value);
    }
    get visible() {
        return this._getOption('visible');
    }
    set visible(value) {
        this._setOption('visible', value);
    }
    get _optionPath() {
        return 'items';
    }
    constructor(parentOptionHost, optionHost, renderer, document, templateHost, element) {
        super();
        this.renderer = renderer;
        this.document = document;
        this.element = element;
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
        templateHost.setHost(this);
    }
    setTemplate(template) {
        this.template = template;
    }
    ngAfterViewInit() {
        extractTemplate(this, this.element, this.renderer, this.document);
    }
    ngOnDestroy() {
        this._deleteRemovedOptions(this._fullOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiGanttContextMenuItemItemComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }, { token: i0.Renderer2 }, { token: DOCUMENT }, { token: i1.DxTemplateHost, host: true }, { token: i0.ElementRef }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxiGanttContextMenuItemItemComponent, isStandalone: true, selector: "dxi-gantt-context-menu-item-item", inputs: { beginGroup: "beginGroup", closeMenuOnClick: "closeMenuOnClick", disabled: "disabled", icon: "icon", items: "items", selectable: "selectable", selected: "selected", template: "template", text: "text", visible: "visible" }, providers: [
            NestedOptionHost,
            DxTemplateHost,
            {
                provide: PROPERTY_TOKEN_items,
                useExisting: DxiGanttContextMenuItemItemComponent,
            }
        ], queries: [{ propertyName: "_itemsContentChildren", predicate: PROPERTY_TOKEN_items }], usesInheritance: true, ngImport: i0, template: '<ng-content></ng-content>', isInline: true, styles: [":host{display:block}\n"], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiGanttContextMenuItemItemComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxi-gantt-context-menu-item-item', template: '<ng-content></ng-content>', imports: [DxIntegrationModule], providers: [
                        NestedOptionHost,
                        DxTemplateHost,
                        {
                            provide: PROPERTY_TOKEN_items,
                            useExisting: DxiGanttContextMenuItemItemComponent,
                        }
                    ], styles: [":host{display:block}\n"] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }, { type: i0.Renderer2 }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [DOCUMENT]
                }] }, { type: i1.DxTemplateHost, decorators: [{
                    type: Host
                }] }, { type: i0.ElementRef }], propDecorators: { _itemsContentChildren: [{
                type: ContentChildren,
                args: [PROPERTY_TOKEN_items]
            }], beginGroup: [{
                type: Input
            }], closeMenuOnClick: [{
                type: Input
            }], disabled: [{
                type: Input
            }], icon: [{
                type: Input
            }], items: [{
                type: Input
            }], selectable: [{
                type: Input
            }], selected: [{
                type: Input
            }], template: [{
                type: Input
            }], text: [{
                type: Input
            }], visible: [{
                type: Input
            }] } });
class DxiGanttContextMenuItemItemModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiGanttContextMenuItemItemModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxiGanttContextMenuItemItemModule, imports: [DxiGanttContextMenuItemItemComponent], exports: [DxiGanttContextMenuItemItemComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiGanttContextMenuItemItemModule, imports: [DxiGanttContextMenuItemItemComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiGanttContextMenuItemItemModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxiGanttContextMenuItemItemComponent
                    ],
                    exports: [
                        DxiGanttContextMenuItemItemComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoGanttContextMenuComponent extends NestedOption {
    set _itemsContentChildren(value) {
        this.setChildren('items', value);
    }
    get enabled() {
        return this._getOption('enabled');
    }
    set enabled(value) {
        this._setOption('enabled', value);
    }
    get items() {
        return this._getOption('items');
    }
    set items(value) {
        this._setOption('items', value);
    }
    get _optionPath() {
        return 'contextMenu';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoGanttContextMenuComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoGanttContextMenuComponent, isStandalone: true, selector: "dxo-gantt-context-menu", inputs: { enabled: "enabled", items: "items" }, providers: [NestedOptionHost], queries: [{ propertyName: "_itemsContentChildren", predicate: PROPERTY_TOKEN_items }], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoGanttContextMenuComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-gantt-context-menu', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { _itemsContentChildren: [{
                type: ContentChildren,
                args: [PROPERTY_TOKEN_items]
            }], enabled: [{
                type: Input
            }], items: [{
                type: Input
            }] } });
class DxoGanttContextMenuModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoGanttContextMenuModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoGanttContextMenuModule, imports: [DxoGanttContextMenuComponent], exports: [DxoGanttContextMenuComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoGanttContextMenuModule, imports: [DxoGanttContextMenuComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoGanttContextMenuModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoGanttContextMenuComponent
                    ],
                    exports: [
                        DxoGanttContextMenuComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoGanttDependenciesComponent extends NestedOption {
    get dataSource() {
        return this._getOption('dataSource');
    }
    set dataSource(value) {
        this._setOption('dataSource', value);
    }
    get keyExpr() {
        return this._getOption('keyExpr');
    }
    set keyExpr(value) {
        this._setOption('keyExpr', value);
    }
    get predecessorIdExpr() {
        return this._getOption('predecessorIdExpr');
    }
    set predecessorIdExpr(value) {
        this._setOption('predecessorIdExpr', value);
    }
    get successorIdExpr() {
        return this._getOption('successorIdExpr');
    }
    set successorIdExpr(value) {
        this._setOption('successorIdExpr', value);
    }
    get typeExpr() {
        return this._getOption('typeExpr');
    }
    set typeExpr(value) {
        this._setOption('typeExpr', value);
    }
    get _optionPath() {
        return 'dependencies';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoGanttDependenciesComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoGanttDependenciesComponent, isStandalone: true, selector: "dxo-gantt-dependencies", inputs: { dataSource: "dataSource", keyExpr: "keyExpr", predecessorIdExpr: "predecessorIdExpr", successorIdExpr: "successorIdExpr", typeExpr: "typeExpr" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoGanttDependenciesComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-gantt-dependencies', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { dataSource: [{
                type: Input
            }], keyExpr: [{
                type: Input
            }], predecessorIdExpr: [{
                type: Input
            }], successorIdExpr: [{
                type: Input
            }], typeExpr: [{
                type: Input
            }] } });
class DxoGanttDependenciesModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoGanttDependenciesModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoGanttDependenciesModule, imports: [DxoGanttDependenciesComponent], exports: [DxoGanttDependenciesComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoGanttDependenciesModule, imports: [DxoGanttDependenciesComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoGanttDependenciesModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoGanttDependenciesComponent
                    ],
                    exports: [
                        DxoGanttDependenciesComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoGanttEditingComponent extends NestedOption {
    get allowDependencyAdding() {
        return this._getOption('allowDependencyAdding');
    }
    set allowDependencyAdding(value) {
        this._setOption('allowDependencyAdding', value);
    }
    get allowDependencyDeleting() {
        return this._getOption('allowDependencyDeleting');
    }
    set allowDependencyDeleting(value) {
        this._setOption('allowDependencyDeleting', value);
    }
    get allowResourceAdding() {
        return this._getOption('allowResourceAdding');
    }
    set allowResourceAdding(value) {
        this._setOption('allowResourceAdding', value);
    }
    get allowResourceDeleting() {
        return this._getOption('allowResourceDeleting');
    }
    set allowResourceDeleting(value) {
        this._setOption('allowResourceDeleting', value);
    }
    get allowResourceUpdating() {
        return this._getOption('allowResourceUpdating');
    }
    set allowResourceUpdating(value) {
        this._setOption('allowResourceUpdating', value);
    }
    get allowTaskAdding() {
        return this._getOption('allowTaskAdding');
    }
    set allowTaskAdding(value) {
        this._setOption('allowTaskAdding', value);
    }
    get allowTaskDeleting() {
        return this._getOption('allowTaskDeleting');
    }
    set allowTaskDeleting(value) {
        this._setOption('allowTaskDeleting', value);
    }
    get allowTaskResourceUpdating() {
        return this._getOption('allowTaskResourceUpdating');
    }
    set allowTaskResourceUpdating(value) {
        this._setOption('allowTaskResourceUpdating', value);
    }
    get allowTaskUpdating() {
        return this._getOption('allowTaskUpdating');
    }
    set allowTaskUpdating(value) {
        this._setOption('allowTaskUpdating', value);
    }
    get enabled() {
        return this._getOption('enabled');
    }
    set enabled(value) {
        this._setOption('enabled', value);
    }
    get _optionPath() {
        return 'editing';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoGanttEditingComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoGanttEditingComponent, isStandalone: true, selector: "dxo-gantt-editing", inputs: { allowDependencyAdding: "allowDependencyAdding", allowDependencyDeleting: "allowDependencyDeleting", allowResourceAdding: "allowResourceAdding", allowResourceDeleting: "allowResourceDeleting", allowResourceUpdating: "allowResourceUpdating", allowTaskAdding: "allowTaskAdding", allowTaskDeleting: "allowTaskDeleting", allowTaskResourceUpdating: "allowTaskResourceUpdating", allowTaskUpdating: "allowTaskUpdating", enabled: "enabled" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoGanttEditingComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-gantt-editing', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { allowDependencyAdding: [{
                type: Input
            }], allowDependencyDeleting: [{
                type: Input
            }], allowResourceAdding: [{
                type: Input
            }], allowResourceDeleting: [{
                type: Input
            }], allowResourceUpdating: [{
                type: Input
            }], allowTaskAdding: [{
                type: Input
            }], allowTaskDeleting: [{
                type: Input
            }], allowTaskResourceUpdating: [{
                type: Input
            }], allowTaskUpdating: [{
                type: Input
            }], enabled: [{
                type: Input
            }] } });
class DxoGanttEditingModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoGanttEditingModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoGanttEditingModule, imports: [DxoGanttEditingComponent], exports: [DxoGanttEditingComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoGanttEditingModule, imports: [DxoGanttEditingComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoGanttEditingModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoGanttEditingComponent
                    ],
                    exports: [
                        DxoGanttEditingComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoGanttFilterRowComponent extends NestedOption {
    get betweenEndText() {
        return this._getOption('betweenEndText');
    }
    set betweenEndText(value) {
        this._setOption('betweenEndText', value);
    }
    get betweenStartText() {
        return this._getOption('betweenStartText');
    }
    set betweenStartText(value) {
        this._setOption('betweenStartText', value);
    }
    get operationDescriptions() {
        return this._getOption('operationDescriptions');
    }
    set operationDescriptions(value) {
        this._setOption('operationDescriptions', value);
    }
    get resetOperationText() {
        return this._getOption('resetOperationText');
    }
    set resetOperationText(value) {
        this._setOption('resetOperationText', value);
    }
    get showAllText() {
        return this._getOption('showAllText');
    }
    set showAllText(value) {
        this._setOption('showAllText', value);
    }
    get showOperationChooser() {
        return this._getOption('showOperationChooser');
    }
    set showOperationChooser(value) {
        this._setOption('showOperationChooser', value);
    }
    get visible() {
        return this._getOption('visible');
    }
    set visible(value) {
        this._setOption('visible', value);
    }
    get _optionPath() {
        return 'filterRow';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoGanttFilterRowComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoGanttFilterRowComponent, isStandalone: true, selector: "dxo-gantt-filter-row", inputs: { betweenEndText: "betweenEndText", betweenStartText: "betweenStartText", operationDescriptions: "operationDescriptions", resetOperationText: "resetOperationText", showAllText: "showAllText", showOperationChooser: "showOperationChooser", visible: "visible" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoGanttFilterRowComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-gantt-filter-row', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { betweenEndText: [{
                type: Input
            }], betweenStartText: [{
                type: Input
            }], operationDescriptions: [{
                type: Input
            }], resetOperationText: [{
                type: Input
            }], showAllText: [{
                type: Input
            }], showOperationChooser: [{
                type: Input
            }], visible: [{
                type: Input
            }] } });
class DxoGanttFilterRowModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoGanttFilterRowModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoGanttFilterRowModule, imports: [DxoGanttFilterRowComponent], exports: [DxoGanttFilterRowComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoGanttFilterRowModule, imports: [DxoGanttFilterRowComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoGanttFilterRowModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoGanttFilterRowComponent
                    ],
                    exports: [
                        DxoGanttFilterRowComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoGanttFormatComponent extends NestedOption {
    get currency() {
        return this._getOption('currency');
    }
    set currency(value) {
        this._setOption('currency', value);
    }
    get formatter() {
        return this._getOption('formatter');
    }
    set formatter(value) {
        this._setOption('formatter', value);
    }
    get parser() {
        return this._getOption('parser');
    }
    set parser(value) {
        this._setOption('parser', value);
    }
    get precision() {
        return this._getOption('precision');
    }
    set precision(value) {
        this._setOption('precision', value);
    }
    get type() {
        return this._getOption('type');
    }
    set type(value) {
        this._setOption('type', value);
    }
    get useCurrencyAccountingStyle() {
        return this._getOption('useCurrencyAccountingStyle');
    }
    set useCurrencyAccountingStyle(value) {
        this._setOption('useCurrencyAccountingStyle', value);
    }
    get _optionPath() {
        return 'format';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoGanttFormatComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoGanttFormatComponent, isStandalone: true, selector: "dxo-gantt-format", inputs: { currency: "currency", formatter: "formatter", parser: "parser", precision: "precision", type: "type", useCurrencyAccountingStyle: "useCurrencyAccountingStyle" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoGanttFormatComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-gantt-format', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { currency: [{
                type: Input
            }], formatter: [{
                type: Input
            }], parser: [{
                type: Input
            }], precision: [{
                type: Input
            }], type: [{
                type: Input
            }], useCurrencyAccountingStyle: [{
                type: Input
            }] } });
class DxoGanttFormatModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoGanttFormatModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoGanttFormatModule, imports: [DxoGanttFormatComponent], exports: [DxoGanttFormatComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoGanttFormatModule, imports: [DxoGanttFormatComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoGanttFormatModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoGanttFormatComponent
                    ],
                    exports: [
                        DxoGanttFormatComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoGanttGanttHeaderFilterSearchComponent extends NestedOption {
    get editorOptions() {
        return this._getOption('editorOptions');
    }
    set editorOptions(value) {
        this._setOption('editorOptions', value);
    }
    get enabled() {
        return this._getOption('enabled');
    }
    set enabled(value) {
        this._setOption('enabled', value);
    }
    get mode() {
        return this._getOption('mode');
    }
    set mode(value) {
        this._setOption('mode', value);
    }
    get timeout() {
        return this._getOption('timeout');
    }
    set timeout(value) {
        this._setOption('timeout', value);
    }
    get _optionPath() {
        return 'search';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoGanttGanttHeaderFilterSearchComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoGanttGanttHeaderFilterSearchComponent, isStandalone: true, selector: "dxo-gantt-gantt-header-filter-search", inputs: { editorOptions: "editorOptions", enabled: "enabled", mode: "mode", timeout: "timeout" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoGanttGanttHeaderFilterSearchComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-gantt-gantt-header-filter-search', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { editorOptions: [{
                type: Input
            }], enabled: [{
                type: Input
            }], mode: [{
                type: Input
            }], timeout: [{
                type: Input
            }] } });
class DxoGanttGanttHeaderFilterSearchModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoGanttGanttHeaderFilterSearchModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoGanttGanttHeaderFilterSearchModule, imports: [DxoGanttGanttHeaderFilterSearchComponent], exports: [DxoGanttGanttHeaderFilterSearchComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoGanttGanttHeaderFilterSearchModule, imports: [DxoGanttGanttHeaderFilterSearchComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoGanttGanttHeaderFilterSearchModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoGanttGanttHeaderFilterSearchComponent
                    ],
                    exports: [
                        DxoGanttGanttHeaderFilterSearchComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoGanttGanttHeaderFilterComponent extends NestedOption {
    get allowSearch() {
        return this._getOption('allowSearch');
    }
    set allowSearch(value) {
        this._setOption('allowSearch', value);
    }
    get allowSelectAll() {
        return this._getOption('allowSelectAll');
    }
    set allowSelectAll(value) {
        this._setOption('allowSelectAll', value);
    }
    get height() {
        return this._getOption('height');
    }
    set height(value) {
        this._setOption('height', value);
    }
    get search() {
        return this._getOption('search');
    }
    set search(value) {
        this._setOption('search', value);
    }
    get searchTimeout() {
        return this._getOption('searchTimeout');
    }
    set searchTimeout(value) {
        this._setOption('searchTimeout', value);
    }
    get texts() {
        return this._getOption('texts');
    }
    set texts(value) {
        this._setOption('texts', value);
    }
    get visible() {
        return this._getOption('visible');
    }
    set visible(value) {
        this._setOption('visible', value);
    }
    get width() {
        return this._getOption('width');
    }
    set width(value) {
        this._setOption('width', value);
    }
    get _optionPath() {
        return 'headerFilter';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoGanttGanttHeaderFilterComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoGanttGanttHeaderFilterComponent, isStandalone: true, selector: "dxo-gantt-gantt-header-filter", inputs: { allowSearch: "allowSearch", allowSelectAll: "allowSelectAll", height: "height", search: "search", searchTimeout: "searchTimeout", texts: "texts", visible: "visible", width: "width" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoGanttGanttHeaderFilterComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-gantt-gantt-header-filter', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { allowSearch: [{
                type: Input
            }], allowSelectAll: [{
                type: Input
            }], height: [{
                type: Input
            }], search: [{
                type: Input
            }], searchTimeout: [{
                type: Input
            }], texts: [{
                type: Input
            }], visible: [{
                type: Input
            }], width: [{
                type: Input
            }] } });
class DxoGanttGanttHeaderFilterModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoGanttGanttHeaderFilterModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoGanttGanttHeaderFilterModule, imports: [DxoGanttGanttHeaderFilterComponent], exports: [DxoGanttGanttHeaderFilterComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoGanttGanttHeaderFilterModule, imports: [DxoGanttGanttHeaderFilterComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoGanttGanttHeaderFilterModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoGanttGanttHeaderFilterComponent
                    ],
                    exports: [
                        DxoGanttGanttHeaderFilterComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoGanttHeaderFilterComponent extends NestedOption {
    get allowSearch() {
        return this._getOption('allowSearch');
    }
    set allowSearch(value) {
        this._setOption('allowSearch', value);
    }
    get allowSelectAll() {
        return this._getOption('allowSelectAll');
    }
    set allowSelectAll(value) {
        this._setOption('allowSelectAll', value);
    }
    get dataSource() {
        return this._getOption('dataSource');
    }
    set dataSource(value) {
        this._setOption('dataSource', value);
    }
    get groupInterval() {
        return this._getOption('groupInterval');
    }
    set groupInterval(value) {
        this._setOption('groupInterval', value);
    }
    get height() {
        return this._getOption('height');
    }
    set height(value) {
        this._setOption('height', value);
    }
    get search() {
        return this._getOption('search');
    }
    set search(value) {
        this._setOption('search', value);
    }
    get searchMode() {
        return this._getOption('searchMode');
    }
    set searchMode(value) {
        this._setOption('searchMode', value);
    }
    get width() {
        return this._getOption('width');
    }
    set width(value) {
        this._setOption('width', value);
    }
    get searchTimeout() {
        return this._getOption('searchTimeout');
    }
    set searchTimeout(value) {
        this._setOption('searchTimeout', value);
    }
    get texts() {
        return this._getOption('texts');
    }
    set texts(value) {
        this._setOption('texts', value);
    }
    get visible() {
        return this._getOption('visible');
    }
    set visible(value) {
        this._setOption('visible', value);
    }
    get _optionPath() {
        return 'headerFilter';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoGanttHeaderFilterComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoGanttHeaderFilterComponent, isStandalone: true, selector: "dxo-gantt-header-filter", inputs: { allowSearch: "allowSearch", allowSelectAll: "allowSelectAll", dataSource: "dataSource", groupInterval: "groupInterval", height: "height", search: "search", searchMode: "searchMode", width: "width", searchTimeout: "searchTimeout", texts: "texts", visible: "visible" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoGanttHeaderFilterComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-gantt-header-filter', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { allowSearch: [{
                type: Input
            }], allowSelectAll: [{
                type: Input
            }], dataSource: [{
                type: Input
            }], groupInterval: [{
                type: Input
            }], height: [{
                type: Input
            }], search: [{
                type: Input
            }], searchMode: [{
                type: Input
            }], width: [{
                type: Input
            }], searchTimeout: [{
                type: Input
            }], texts: [{
                type: Input
            }], visible: [{
                type: Input
            }] } });
class DxoGanttHeaderFilterModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoGanttHeaderFilterModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoGanttHeaderFilterModule, imports: [DxoGanttHeaderFilterComponent], exports: [DxoGanttHeaderFilterComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoGanttHeaderFilterModule, imports: [DxoGanttHeaderFilterComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoGanttHeaderFilterModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoGanttHeaderFilterComponent
                    ],
                    exports: [
                        DxoGanttHeaderFilterComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxiGanttItemComponent extends CollectionNestedOption {
    set _itemsContentChildren(value) {
        this.setChildren('items', value);
    }
    get beginGroup() {
        return this._getOption('beginGroup');
    }
    set beginGroup(value) {
        this._setOption('beginGroup', value);
    }
    get closeMenuOnClick() {
        return this._getOption('closeMenuOnClick');
    }
    set closeMenuOnClick(value) {
        this._setOption('closeMenuOnClick', value);
    }
    get disabled() {
        return this._getOption('disabled');
    }
    set disabled(value) {
        this._setOption('disabled', value);
    }
    get icon() {
        return this._getOption('icon');
    }
    set icon(value) {
        this._setOption('icon', value);
    }
    get items() {
        return this._getOption('items');
    }
    set items(value) {
        this._setOption('items', value);
    }
    get name() {
        return this._getOption('name');
    }
    set name(value) {
        this._setOption('name', value);
    }
    get selectable() {
        return this._getOption('selectable');
    }
    set selectable(value) {
        this._setOption('selectable', value);
    }
    get selected() {
        return this._getOption('selected');
    }
    set selected(value) {
        this._setOption('selected', value);
    }
    get template() {
        return this._getOption('template');
    }
    set template(value) {
        this._setOption('template', value);
    }
    get text() {
        return this._getOption('text');
    }
    set text(value) {
        this._setOption('text', value);
    }
    get visible() {
        return this._getOption('visible');
    }
    set visible(value) {
        this._setOption('visible', value);
    }
    get cssClass() {
        return this._getOption('cssClass');
    }
    set cssClass(value) {
        this._setOption('cssClass', value);
    }
    get html() {
        return this._getOption('html');
    }
    set html(value) {
        this._setOption('html', value);
    }
    get locateInMenu() {
        return this._getOption('locateInMenu');
    }
    set locateInMenu(value) {
        this._setOption('locateInMenu', value);
    }
    get location() {
        return this._getOption('location');
    }
    set location(value) {
        this._setOption('location', value);
    }
    get menuItemTemplate() {
        return this._getOption('menuItemTemplate');
    }
    set menuItemTemplate(value) {
        this._setOption('menuItemTemplate', value);
    }
    get options() {
        return this._getOption('options');
    }
    set options(value) {
        this._setOption('options', value);
    }
    get showText() {
        return this._getOption('showText');
    }
    set showText(value) {
        this._setOption('showText', value);
    }
    get widget() {
        return this._getOption('widget');
    }
    set widget(value) {
        this._setOption('widget', value);
    }
    get _optionPath() {
        return 'items';
    }
    constructor(parentOptionHost, optionHost, renderer, document, templateHost, element) {
        super();
        this.renderer = renderer;
        this.document = document;
        this.element = element;
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
        templateHost.setHost(this);
    }
    setTemplate(template) {
        this.template = template;
    }
    ngAfterViewInit() {
        extractTemplate(this, this.element, this.renderer, this.document);
    }
    ngOnDestroy() {
        this._deleteRemovedOptions(this._fullOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiGanttItemComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }, { token: i0.Renderer2 }, { token: DOCUMENT }, { token: i1.DxTemplateHost, host: true }, { token: i0.ElementRef }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxiGanttItemComponent, isStandalone: true, selector: "dxi-gantt-item", inputs: { beginGroup: "beginGroup", closeMenuOnClick: "closeMenuOnClick", disabled: "disabled", icon: "icon", items: "items", name: "name", selectable: "selectable", selected: "selected", template: "template", text: "text", visible: "visible", cssClass: "cssClass", html: "html", locateInMenu: "locateInMenu", location: "location", menuItemTemplate: "menuItemTemplate", options: "options", showText: "showText", widget: "widget" }, providers: [
            NestedOptionHost,
            DxTemplateHost,
            {
                provide: PROPERTY_TOKEN_items,
                useExisting: DxiGanttItemComponent,
            }
        ], queries: [{ propertyName: "_itemsContentChildren", predicate: PROPERTY_TOKEN_items }], usesInheritance: true, ngImport: i0, template: '<ng-content></ng-content>', isInline: true, styles: [":host{display:block}\n"], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiGanttItemComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxi-gantt-item', template: '<ng-content></ng-content>', imports: [DxIntegrationModule], providers: [
                        NestedOptionHost,
                        DxTemplateHost,
                        {
                            provide: PROPERTY_TOKEN_items,
                            useExisting: DxiGanttItemComponent,
                        }
                    ], styles: [":host{display:block}\n"] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }, { type: i0.Renderer2 }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [DOCUMENT]
                }] }, { type: i1.DxTemplateHost, decorators: [{
                    type: Host
                }] }, { type: i0.ElementRef }], propDecorators: { _itemsContentChildren: [{
                type: ContentChildren,
                args: [PROPERTY_TOKEN_items]
            }], beginGroup: [{
                type: Input
            }], closeMenuOnClick: [{
                type: Input
            }], disabled: [{
                type: Input
            }], icon: [{
                type: Input
            }], items: [{
                type: Input
            }], name: [{
                type: Input
            }], selectable: [{
                type: Input
            }], selected: [{
                type: Input
            }], template: [{
                type: Input
            }], text: [{
                type: Input
            }], visible: [{
                type: Input
            }], cssClass: [{
                type: Input
            }], html: [{
                type: Input
            }], locateInMenu: [{
                type: Input
            }], location: [{
                type: Input
            }], menuItemTemplate: [{
                type: Input
            }], options: [{
                type: Input
            }], showText: [{
                type: Input
            }], widget: [{
                type: Input
            }] } });
class DxiGanttItemModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiGanttItemModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxiGanttItemModule, imports: [DxiGanttItemComponent], exports: [DxiGanttItemComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiGanttItemModule, imports: [DxiGanttItemComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiGanttItemModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxiGanttItemComponent
                    ],
                    exports: [
                        DxiGanttItemComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoGanttOperationDescriptionsComponent extends NestedOption {
    get between() {
        return this._getOption('between');
    }
    set between(value) {
        this._setOption('between', value);
    }
    get contains() {
        return this._getOption('contains');
    }
    set contains(value) {
        this._setOption('contains', value);
    }
    get endsWith() {
        return this._getOption('endsWith');
    }
    set endsWith(value) {
        this._setOption('endsWith', value);
    }
    get equal() {
        return this._getOption('equal');
    }
    set equal(value) {
        this._setOption('equal', value);
    }
    get greaterThan() {
        return this._getOption('greaterThan');
    }
    set greaterThan(value) {
        this._setOption('greaterThan', value);
    }
    get greaterThanOrEqual() {
        return this._getOption('greaterThanOrEqual');
    }
    set greaterThanOrEqual(value) {
        this._setOption('greaterThanOrEqual', value);
    }
    get lessThan() {
        return this._getOption('lessThan');
    }
    set lessThan(value) {
        this._setOption('lessThan', value);
    }
    get lessThanOrEqual() {
        return this._getOption('lessThanOrEqual');
    }
    set lessThanOrEqual(value) {
        this._setOption('lessThanOrEqual', value);
    }
    get notContains() {
        return this._getOption('notContains');
    }
    set notContains(value) {
        this._setOption('notContains', value);
    }
    get notEqual() {
        return this._getOption('notEqual');
    }
    set notEqual(value) {
        this._setOption('notEqual', value);
    }
    get startsWith() {
        return this._getOption('startsWith');
    }
    set startsWith(value) {
        this._setOption('startsWith', value);
    }
    get _optionPath() {
        return 'operationDescriptions';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoGanttOperationDescriptionsComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoGanttOperationDescriptionsComponent, isStandalone: true, selector: "dxo-gantt-operation-descriptions", inputs: { between: "between", contains: "contains", endsWith: "endsWith", equal: "equal", greaterThan: "greaterThan", greaterThanOrEqual: "greaterThanOrEqual", lessThan: "lessThan", lessThanOrEqual: "lessThanOrEqual", notContains: "notContains", notEqual: "notEqual", startsWith: "startsWith" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoGanttOperationDescriptionsComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-gantt-operation-descriptions', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { between: [{
                type: Input
            }], contains: [{
                type: Input
            }], endsWith: [{
                type: Input
            }], equal: [{
                type: Input
            }], greaterThan: [{
                type: Input
            }], greaterThanOrEqual: [{
                type: Input
            }], lessThan: [{
                type: Input
            }], lessThanOrEqual: [{
                type: Input
            }], notContains: [{
                type: Input
            }], notEqual: [{
                type: Input
            }], startsWith: [{
                type: Input
            }] } });
class DxoGanttOperationDescriptionsModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoGanttOperationDescriptionsModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoGanttOperationDescriptionsModule, imports: [DxoGanttOperationDescriptionsComponent], exports: [DxoGanttOperationDescriptionsComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoGanttOperationDescriptionsModule, imports: [DxoGanttOperationDescriptionsComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoGanttOperationDescriptionsModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoGanttOperationDescriptionsComponent
                    ],
                    exports: [
                        DxoGanttOperationDescriptionsComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoGanttResourceAssignmentsComponent extends NestedOption {
    get dataSource() {
        return this._getOption('dataSource');
    }
    set dataSource(value) {
        this._setOption('dataSource', value);
    }
    get keyExpr() {
        return this._getOption('keyExpr');
    }
    set keyExpr(value) {
        this._setOption('keyExpr', value);
    }
    get resourceIdExpr() {
        return this._getOption('resourceIdExpr');
    }
    set resourceIdExpr(value) {
        this._setOption('resourceIdExpr', value);
    }
    get taskIdExpr() {
        return this._getOption('taskIdExpr');
    }
    set taskIdExpr(value) {
        this._setOption('taskIdExpr', value);
    }
    get _optionPath() {
        return 'resourceAssignments';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoGanttResourceAssignmentsComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoGanttResourceAssignmentsComponent, isStandalone: true, selector: "dxo-gantt-resource-assignments", inputs: { dataSource: "dataSource", keyExpr: "keyExpr", resourceIdExpr: "resourceIdExpr", taskIdExpr: "taskIdExpr" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoGanttResourceAssignmentsComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-gantt-resource-assignments', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { dataSource: [{
                type: Input
            }], keyExpr: [{
                type: Input
            }], resourceIdExpr: [{
                type: Input
            }], taskIdExpr: [{
                type: Input
            }] } });
class DxoGanttResourceAssignmentsModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoGanttResourceAssignmentsModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoGanttResourceAssignmentsModule, imports: [DxoGanttResourceAssignmentsComponent], exports: [DxoGanttResourceAssignmentsComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoGanttResourceAssignmentsModule, imports: [DxoGanttResourceAssignmentsComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoGanttResourceAssignmentsModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoGanttResourceAssignmentsComponent
                    ],
                    exports: [
                        DxoGanttResourceAssignmentsComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoGanttResourcesComponent extends NestedOption {
    get colorExpr() {
        return this._getOption('colorExpr');
    }
    set colorExpr(value) {
        this._setOption('colorExpr', value);
    }
    get dataSource() {
        return this._getOption('dataSource');
    }
    set dataSource(value) {
        this._setOption('dataSource', value);
    }
    get keyExpr() {
        return this._getOption('keyExpr');
    }
    set keyExpr(value) {
        this._setOption('keyExpr', value);
    }
    get textExpr() {
        return this._getOption('textExpr');
    }
    set textExpr(value) {
        this._setOption('textExpr', value);
    }
    get _optionPath() {
        return 'resources';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoGanttResourcesComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoGanttResourcesComponent, isStandalone: true, selector: "dxo-gantt-resources", inputs: { colorExpr: "colorExpr", dataSource: "dataSource", keyExpr: "keyExpr", textExpr: "textExpr" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoGanttResourcesComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-gantt-resources', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { colorExpr: [{
                type: Input
            }], dataSource: [{
                type: Input
            }], keyExpr: [{
                type: Input
            }], textExpr: [{
                type: Input
            }] } });
class DxoGanttResourcesModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoGanttResourcesModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoGanttResourcesModule, imports: [DxoGanttResourcesComponent], exports: [DxoGanttResourcesComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoGanttResourcesModule, imports: [DxoGanttResourcesComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoGanttResourcesModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoGanttResourcesComponent
                    ],
                    exports: [
                        DxoGanttResourcesComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoGanttScaleTypeRangeComponent extends NestedOption {
    get max() {
        return this._getOption('max');
    }
    set max(value) {
        this._setOption('max', value);
    }
    get min() {
        return this._getOption('min');
    }
    set min(value) {
        this._setOption('min', value);
    }
    get _optionPath() {
        return 'scaleTypeRange';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoGanttScaleTypeRangeComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoGanttScaleTypeRangeComponent, isStandalone: true, selector: "dxo-gantt-scale-type-range", inputs: { max: "max", min: "min" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoGanttScaleTypeRangeComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-gantt-scale-type-range', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { max: [{
                type: Input
            }], min: [{
                type: Input
            }] } });
class DxoGanttScaleTypeRangeModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoGanttScaleTypeRangeModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoGanttScaleTypeRangeModule, imports: [DxoGanttScaleTypeRangeComponent], exports: [DxoGanttScaleTypeRangeComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoGanttScaleTypeRangeModule, imports: [DxoGanttScaleTypeRangeComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoGanttScaleTypeRangeModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoGanttScaleTypeRangeComponent
                    ],
                    exports: [
                        DxoGanttScaleTypeRangeComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoGanttSearchComponent extends NestedOption {
    get editorOptions() {
        return this._getOption('editorOptions');
    }
    set editorOptions(value) {
        this._setOption('editorOptions', value);
    }
    get enabled() {
        return this._getOption('enabled');
    }
    set enabled(value) {
        this._setOption('enabled', value);
    }
    get mode() {
        return this._getOption('mode');
    }
    set mode(value) {
        this._setOption('mode', value);
    }
    get searchExpr() {
        return this._getOption('searchExpr');
    }
    set searchExpr(value) {
        this._setOption('searchExpr', value);
    }
    get timeout() {
        return this._getOption('timeout');
    }
    set timeout(value) {
        this._setOption('timeout', value);
    }
    get _optionPath() {
        return 'search';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoGanttSearchComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoGanttSearchComponent, isStandalone: true, selector: "dxo-gantt-search", inputs: { editorOptions: "editorOptions", enabled: "enabled", mode: "mode", searchExpr: "searchExpr", timeout: "timeout" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoGanttSearchComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-gantt-search', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { editorOptions: [{
                type: Input
            }], enabled: [{
                type: Input
            }], mode: [{
                type: Input
            }], searchExpr: [{
                type: Input
            }], timeout: [{
                type: Input
            }] } });
class DxoGanttSearchModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoGanttSearchModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoGanttSearchModule, imports: [DxoGanttSearchComponent], exports: [DxoGanttSearchComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoGanttSearchModule, imports: [DxoGanttSearchComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoGanttSearchModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoGanttSearchComponent
                    ],
                    exports: [
                        DxoGanttSearchComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoGanttSortingComponent extends NestedOption {
    get ascendingText() {
        return this._getOption('ascendingText');
    }
    set ascendingText(value) {
        this._setOption('ascendingText', value);
    }
    get clearText() {
        return this._getOption('clearText');
    }
    set clearText(value) {
        this._setOption('clearText', value);
    }
    get descendingText() {
        return this._getOption('descendingText');
    }
    set descendingText(value) {
        this._setOption('descendingText', value);
    }
    get mode() {
        return this._getOption('mode');
    }
    set mode(value) {
        this._setOption('mode', value);
    }
    get showSortIndexes() {
        return this._getOption('showSortIndexes');
    }
    set showSortIndexes(value) {
        this._setOption('showSortIndexes', value);
    }
    get _optionPath() {
        return 'sorting';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoGanttSortingComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoGanttSortingComponent, isStandalone: true, selector: "dxo-gantt-sorting", inputs: { ascendingText: "ascendingText", clearText: "clearText", descendingText: "descendingText", mode: "mode", showSortIndexes: "showSortIndexes" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoGanttSortingComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-gantt-sorting', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { ascendingText: [{
                type: Input
            }], clearText: [{
                type: Input
            }], descendingText: [{
                type: Input
            }], mode: [{
                type: Input
            }], showSortIndexes: [{
                type: Input
            }] } });
class DxoGanttSortingModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoGanttSortingModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoGanttSortingModule, imports: [DxoGanttSortingComponent], exports: [DxoGanttSortingComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoGanttSortingModule, imports: [DxoGanttSortingComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoGanttSortingModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoGanttSortingComponent
                    ],
                    exports: [
                        DxoGanttSortingComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxiGanttStripLineComponent extends CollectionNestedOption {
    get cssClass() {
        return this._getOption('cssClass');
    }
    set cssClass(value) {
        this._setOption('cssClass', value);
    }
    get end() {
        return this._getOption('end');
    }
    set end(value) {
        this._setOption('end', value);
    }
    get start() {
        return this._getOption('start');
    }
    set start(value) {
        this._setOption('start', value);
    }
    get title() {
        return this._getOption('title');
    }
    set title(value) {
        this._setOption('title', value);
    }
    get _optionPath() {
        return 'stripLines';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnDestroy() {
        this._deleteRemovedOptions(this._fullOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiGanttStripLineComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxiGanttStripLineComponent, isStandalone: true, selector: "dxi-gantt-strip-line", inputs: { cssClass: "cssClass", end: "end", start: "start", title: "title" }, providers: [
            NestedOptionHost,
            {
                provide: PROPERTY_TOKEN_stripLines,
                useExisting: DxiGanttStripLineComponent,
            }
        ], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiGanttStripLineComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxi-gantt-strip-line', template: '', imports: [DxIntegrationModule], providers: [
                        NestedOptionHost,
                        {
                            provide: PROPERTY_TOKEN_stripLines,
                            useExisting: DxiGanttStripLineComponent,
                        }
                    ] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { cssClass: [{
                type: Input
            }], end: [{
                type: Input
            }], start: [{
                type: Input
            }], title: [{
                type: Input
            }] } });
class DxiGanttStripLineModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiGanttStripLineModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxiGanttStripLineModule, imports: [DxiGanttStripLineComponent], exports: [DxiGanttStripLineComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiGanttStripLineModule, imports: [DxiGanttStripLineComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiGanttStripLineModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxiGanttStripLineComponent
                    ],
                    exports: [
                        DxiGanttStripLineComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoGanttTasksComponent extends NestedOption {
    get colorExpr() {
        return this._getOption('colorExpr');
    }
    set colorExpr(value) {
        this._setOption('colorExpr', value);
    }
    get dataSource() {
        return this._getOption('dataSource');
    }
    set dataSource(value) {
        this._setOption('dataSource', value);
    }
    get endExpr() {
        return this._getOption('endExpr');
    }
    set endExpr(value) {
        this._setOption('endExpr', value);
    }
    get keyExpr() {
        return this._getOption('keyExpr');
    }
    set keyExpr(value) {
        this._setOption('keyExpr', value);
    }
    get parentIdExpr() {
        return this._getOption('parentIdExpr');
    }
    set parentIdExpr(value) {
        this._setOption('parentIdExpr', value);
    }
    get progressExpr() {
        return this._getOption('progressExpr');
    }
    set progressExpr(value) {
        this._setOption('progressExpr', value);
    }
    get startExpr() {
        return this._getOption('startExpr');
    }
    set startExpr(value) {
        this._setOption('startExpr', value);
    }
    get titleExpr() {
        return this._getOption('titleExpr');
    }
    set titleExpr(value) {
        this._setOption('titleExpr', value);
    }
    get _optionPath() {
        return 'tasks';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoGanttTasksComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoGanttTasksComponent, isStandalone: true, selector: "dxo-gantt-tasks", inputs: { colorExpr: "colorExpr", dataSource: "dataSource", endExpr: "endExpr", keyExpr: "keyExpr", parentIdExpr: "parentIdExpr", progressExpr: "progressExpr", startExpr: "startExpr", titleExpr: "titleExpr" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoGanttTasksComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-gantt-tasks', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { colorExpr: [{
                type: Input
            }], dataSource: [{
                type: Input
            }], endExpr: [{
                type: Input
            }], keyExpr: [{
                type: Input
            }], parentIdExpr: [{
                type: Input
            }], progressExpr: [{
                type: Input
            }], startExpr: [{
                type: Input
            }], titleExpr: [{
                type: Input
            }] } });
class DxoGanttTasksModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoGanttTasksModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoGanttTasksModule, imports: [DxoGanttTasksComponent], exports: [DxoGanttTasksComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoGanttTasksModule, imports: [DxoGanttTasksComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoGanttTasksModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoGanttTasksComponent
                    ],
                    exports: [
                        DxoGanttTasksComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoGanttTextsComponent extends NestedOption {
    get cancel() {
        return this._getOption('cancel');
    }
    set cancel(value) {
        this._setOption('cancel', value);
    }
    get emptyValue() {
        return this._getOption('emptyValue');
    }
    set emptyValue(value) {
        this._setOption('emptyValue', value);
    }
    get ok() {
        return this._getOption('ok');
    }
    set ok(value) {
        this._setOption('ok', value);
    }
    get _optionPath() {
        return 'texts';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoGanttTextsComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoGanttTextsComponent, isStandalone: true, selector: "dxo-gantt-texts", inputs: { cancel: "cancel", emptyValue: "emptyValue", ok: "ok" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoGanttTextsComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-gantt-texts', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { cancel: [{
                type: Input
            }], emptyValue: [{
                type: Input
            }], ok: [{
                type: Input
            }] } });
class DxoGanttTextsModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoGanttTextsModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoGanttTextsModule, imports: [DxoGanttTextsComponent], exports: [DxoGanttTextsComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoGanttTextsModule, imports: [DxoGanttTextsComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoGanttTextsModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoGanttTextsComponent
                    ],
                    exports: [
                        DxoGanttTextsComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxiGanttToolbarItemComponent extends CollectionNestedOption {
    get cssClass() {
        return this._getOption('cssClass');
    }
    set cssClass(value) {
        this._setOption('cssClass', value);
    }
    get disabled() {
        return this._getOption('disabled');
    }
    set disabled(value) {
        this._setOption('disabled', value);
    }
    get html() {
        return this._getOption('html');
    }
    set html(value) {
        this._setOption('html', value);
    }
    get locateInMenu() {
        return this._getOption('locateInMenu');
    }
    set locateInMenu(value) {
        this._setOption('locateInMenu', value);
    }
    get location() {
        return this._getOption('location');
    }
    set location(value) {
        this._setOption('location', value);
    }
    get menuItemTemplate() {
        return this._getOption('menuItemTemplate');
    }
    set menuItemTemplate(value) {
        this._setOption('menuItemTemplate', value);
    }
    get name() {
        return this._getOption('name');
    }
    set name(value) {
        this._setOption('name', value);
    }
    get options() {
        return this._getOption('options');
    }
    set options(value) {
        this._setOption('options', value);
    }
    get showText() {
        return this._getOption('showText');
    }
    set showText(value) {
        this._setOption('showText', value);
    }
    get template() {
        return this._getOption('template');
    }
    set template(value) {
        this._setOption('template', value);
    }
    get text() {
        return this._getOption('text');
    }
    set text(value) {
        this._setOption('text', value);
    }
    get visible() {
        return this._getOption('visible');
    }
    set visible(value) {
        this._setOption('visible', value);
    }
    get widget() {
        return this._getOption('widget');
    }
    set widget(value) {
        this._setOption('widget', value);
    }
    get _optionPath() {
        return 'items';
    }
    constructor(parentOptionHost, optionHost, renderer, document, templateHost, element) {
        super();
        this.renderer = renderer;
        this.document = document;
        this.element = element;
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
        templateHost.setHost(this);
    }
    setTemplate(template) {
        this.template = template;
    }
    ngAfterViewInit() {
        extractTemplate(this, this.element, this.renderer, this.document);
    }
    ngOnDestroy() {
        this._deleteRemovedOptions(this._fullOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiGanttToolbarItemComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }, { token: i0.Renderer2 }, { token: DOCUMENT }, { token: i1.DxTemplateHost, host: true }, { token: i0.ElementRef }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxiGanttToolbarItemComponent, isStandalone: true, selector: "dxi-gantt-toolbar-item", inputs: { cssClass: "cssClass", disabled: "disabled", html: "html", locateInMenu: "locateInMenu", location: "location", menuItemTemplate: "menuItemTemplate", name: "name", options: "options", showText: "showText", template: "template", text: "text", visible: "visible", widget: "widget" }, providers: [
            NestedOptionHost,
            DxTemplateHost,
            {
                provide: PROPERTY_TOKEN_items,
                useExisting: DxiGanttToolbarItemComponent,
            }
        ], usesInheritance: true, ngImport: i0, template: '<ng-content></ng-content>', isInline: true, styles: [":host{display:block}\n"], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiGanttToolbarItemComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxi-gantt-toolbar-item', template: '<ng-content></ng-content>', imports: [DxIntegrationModule], providers: [
                        NestedOptionHost,
                        DxTemplateHost,
                        {
                            provide: PROPERTY_TOKEN_items,
                            useExisting: DxiGanttToolbarItemComponent,
                        }
                    ], styles: [":host{display:block}\n"] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }, { type: i0.Renderer2 }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [DOCUMENT]
                }] }, { type: i1.DxTemplateHost, decorators: [{
                    type: Host
                }] }, { type: i0.ElementRef }], propDecorators: { cssClass: [{
                type: Input
            }], disabled: [{
                type: Input
            }], html: [{
                type: Input
            }], locateInMenu: [{
                type: Input
            }], location: [{
                type: Input
            }], menuItemTemplate: [{
                type: Input
            }], name: [{
                type: Input
            }], options: [{
                type: Input
            }], showText: [{
                type: Input
            }], template: [{
                type: Input
            }], text: [{
                type: Input
            }], visible: [{
                type: Input
            }], widget: [{
                type: Input
            }] } });
class DxiGanttToolbarItemModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiGanttToolbarItemModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxiGanttToolbarItemModule, imports: [DxiGanttToolbarItemComponent], exports: [DxiGanttToolbarItemComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiGanttToolbarItemModule, imports: [DxiGanttToolbarItemComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiGanttToolbarItemModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxiGanttToolbarItemComponent
                    ],
                    exports: [
                        DxiGanttToolbarItemComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoGanttToolbarComponent extends NestedOption {
    set _itemsContentChildren(value) {
        this.setChildren('items', value);
    }
    get items() {
        return this._getOption('items');
    }
    set items(value) {
        this._setOption('items', value);
    }
    get _optionPath() {
        return 'toolbar';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoGanttToolbarComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoGanttToolbarComponent, isStandalone: true, selector: "dxo-gantt-toolbar", inputs: { items: "items" }, providers: [NestedOptionHost], queries: [{ propertyName: "_itemsContentChildren", predicate: PROPERTY_TOKEN_items }], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoGanttToolbarComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-gantt-toolbar', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { _itemsContentChildren: [{
                type: ContentChildren,
                args: [PROPERTY_TOKEN_items]
            }], items: [{
                type: Input
            }] } });
class DxoGanttToolbarModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoGanttToolbarModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoGanttToolbarModule, imports: [DxoGanttToolbarComponent], exports: [DxoGanttToolbarComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoGanttToolbarModule, imports: [DxoGanttToolbarComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoGanttToolbarModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoGanttToolbarComponent
                    ],
                    exports: [
                        DxoGanttToolbarComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoGanttValidationComponent extends NestedOption {
    get autoUpdateParentTasks() {
        return this._getOption('autoUpdateParentTasks');
    }
    set autoUpdateParentTasks(value) {
        this._setOption('autoUpdateParentTasks', value);
    }
    get enablePredecessorGap() {
        return this._getOption('enablePredecessorGap');
    }
    set enablePredecessorGap(value) {
        this._setOption('enablePredecessorGap', value);
    }
    get validateDependencies() {
        return this._getOption('validateDependencies');
    }
    set validateDependencies(value) {
        this._setOption('validateDependencies', value);
    }
    get _optionPath() {
        return 'validation';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoGanttValidationComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoGanttValidationComponent, isStandalone: true, selector: "dxo-gantt-validation", inputs: { autoUpdateParentTasks: "autoUpdateParentTasks", enablePredecessorGap: "enablePredecessorGap", validateDependencies: "validateDependencies" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoGanttValidationComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-gantt-validation', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { autoUpdateParentTasks: [{
                type: Input
            }], enablePredecessorGap: [{
                type: Input
            }], validateDependencies: [{
                type: Input
            }] } });
class DxoGanttValidationModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoGanttValidationModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoGanttValidationModule, imports: [DxoGanttValidationComponent], exports: [DxoGanttValidationComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoGanttValidationModule, imports: [DxoGanttValidationComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoGanttValidationModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoGanttValidationComponent
                    ],
                    exports: [
                        DxoGanttValidationComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

/**
 * Generated bundle index. Do not edit.
 */

export { DxiGanttColumnComponent, DxiGanttColumnModule, DxiGanttContextMenuItemComponent, DxiGanttContextMenuItemItemComponent, DxiGanttContextMenuItemItemModule, DxiGanttContextMenuItemModule, DxiGanttItemComponent, DxiGanttItemModule, DxiGanttStripLineComponent, DxiGanttStripLineModule, DxiGanttToolbarItemComponent, DxiGanttToolbarItemModule, DxoGanttColumnHeaderFilterComponent, DxoGanttColumnHeaderFilterModule, DxoGanttColumnHeaderFilterSearchComponent, DxoGanttColumnHeaderFilterSearchModule, DxoGanttContextMenuComponent, DxoGanttContextMenuModule, DxoGanttDependenciesComponent, DxoGanttDependenciesModule, DxoGanttEditingComponent, DxoGanttEditingModule, DxoGanttFilterRowComponent, DxoGanttFilterRowModule, DxoGanttFormatComponent, DxoGanttFormatModule, DxoGanttGanttHeaderFilterComponent, DxoGanttGanttHeaderFilterModule, DxoGanttGanttHeaderFilterSearchComponent, DxoGanttGanttHeaderFilterSearchModule, DxoGanttHeaderFilterComponent, DxoGanttHeaderFilterModule, DxoGanttOperationDescriptionsComponent, DxoGanttOperationDescriptionsModule, DxoGanttResourceAssignmentsComponent, DxoGanttResourceAssignmentsModule, DxoGanttResourcesComponent, DxoGanttResourcesModule, DxoGanttScaleTypeRangeComponent, DxoGanttScaleTypeRangeModule, DxoGanttSearchComponent, DxoGanttSearchModule, DxoGanttSortingComponent, DxoGanttSortingModule, DxoGanttTasksComponent, DxoGanttTasksModule, DxoGanttTextsComponent, DxoGanttTextsModule, DxoGanttToolbarComponent, DxoGanttToolbarModule, DxoGanttValidationComponent, DxoGanttValidationModule };
//# sourceMappingURL=devextreme-angular-ui-gantt-nested.mjs.map
