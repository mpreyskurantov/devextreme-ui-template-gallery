import * as i0 from '@angular/core';
import { PLATFORM_ID, Output, Input, ContentChildren, Inject, Component, NgModule } from '@angular/core';
import DxCardView from 'devextreme/ui/card_view';
import * as i1 from 'devextreme-angular/core';
import { DxComponent, DxIntegrationModule, DxTemplateHost, WatcherHelper, NestedOptionHost, IterableDifferHelper, DxTemplateModule } from 'devextreme-angular/core';
import { DxoCardViewAIOptionsModule, DxoCardViewAnimationModule, DxiCardViewAsyncRuleModule, DxoCardViewAtModule, DxoCardViewBoundaryOffsetModule, DxiCardViewButtonItemModule, DxoCardViewButtonOptionsModule, DxoCardViewCardCoverModule, DxoCardViewCardHeaderModule, DxiCardViewCardHeaderItemModule, DxoCardViewCardViewHeaderFilterModule, DxoCardViewCardViewHeaderFilterSearchModule, DxoCardViewCardViewHeaderFilterTextsModule, DxoCardViewCardViewSelectionModule, DxiCardViewChangeModule, DxoCardViewColCountByScreenModule, DxoCardViewCollisionModule, DxiCardViewColumnModule, DxoCardViewColumnChooserModule, DxoCardViewColumnChooserSearchModule, DxoCardViewColumnChooserSelectionModule, DxoCardViewColumnHeaderFilterModule, DxoCardViewColumnHeaderFilterSearchModule, DxiCardViewCompareRuleModule, DxiCardViewCustomOperationModule, DxiCardViewCustomRuleModule, DxoCardViewDraggingModule, DxoCardViewEditingModule, DxoCardViewEditingTextsModule, DxiCardViewEmailRuleModule, DxiCardViewEmptyItemModule, DxiCardViewFieldModule, DxoCardViewFilterBuilderModule, DxoCardViewFilterOperationDescriptionsModule, DxoCardViewFilterPanelModule, DxoCardViewFilterPanelTextsModule, DxoCardViewFormModule, DxoCardViewFormatModule, DxoCardViewFormItemModule, DxoCardViewFromModule, DxiCardViewGroupItemModule, DxoCardViewGroupOperationDescriptionsModule, DxoCardViewHeaderFilterModule, DxoCardViewHeaderPanelModule, DxoCardViewHideModule, DxoCardViewIndicatorOptionsModule, DxiCardViewItemModule, DxoCardViewLabelModule, DxoCardViewLoadPanelModule, DxoCardViewLookupModule, DxoCardViewMyModule, DxiCardViewNumericRuleModule, DxoCardViewOffsetModule, DxoCardViewPagerModule, DxoCardViewPagingModule, DxiCardViewPatternRuleModule, DxoCardViewPositionModule, DxiCardViewRangeRuleModule, DxoCardViewRemoteOperationsModule, DxiCardViewRequiredRuleModule, DxoCardViewScrollingModule, DxoCardViewSearchModule, DxoCardViewSearchPanelModule, DxoCardViewSelectionModule, DxoCardViewShowModule, DxiCardViewSimpleItemModule, DxoCardViewSortingModule, DxiCardViewStringLengthRuleModule, DxiCardViewTabModule, DxiCardViewTabbedItemModule, DxoCardViewTabPanelOptionsModule, DxiCardViewTabPanelOptionsItemModule, DxoCardViewTextsModule, DxoCardViewToModule, DxoCardViewToolbarModule, DxiCardViewToolbarItemModule, DxiCardViewValidationRuleModule } from 'devextreme-angular/ui/card-view/nested';
export * from 'devextreme-angular/ui/card-view/nested';
import { PROPERTY_TOKEN_validationRules, PROPERTY_TOKEN_items, PROPERTY_TOKEN_changes, PROPERTY_TOKEN_columns, PROPERTY_TOKEN_customOperations, PROPERTY_TOKEN_fields, PROPERTY_TOKEN_tabs } from 'devextreme-angular/core/tokens';

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxCardViewComponent extends DxComponent {
    set _validationRulesContentChildren(value) {
        this.setChildren('validationRules', value);
    }
    set _itemsContentChildren(value) {
        this.setChildren('items', value);
    }
    set _changesContentChildren(value) {
        this.setChildren('changes', value);
    }
    set _columnsContentChildren(value) {
        this.setChildren('columns', value);
    }
    set _customOperationsContentChildren(value) {
        this.setChildren('customOperations', value);
    }
    set _fieldsContentChildren(value) {
        this.setChildren('fields', value);
    }
    set _tabsContentChildren(value) {
        this.setChildren('tabs', value);
    }
    get accessKey() {
        return this._getOption('accessKey');
    }
    set accessKey(value) {
        this._setOption('accessKey', value);
    }
    get activeStateEnabled() {
        return this._getOption('activeStateEnabled');
    }
    set activeStateEnabled(value) {
        this._setOption('activeStateEnabled', value);
    }
    get allowColumnReordering() {
        return this._getOption('allowColumnReordering');
    }
    set allowColumnReordering(value) {
        this._setOption('allowColumnReordering', value);
    }
    get cardContentTemplate() {
        return this._getOption('cardContentTemplate');
    }
    set cardContentTemplate(value) {
        this._setOption('cardContentTemplate', value);
    }
    get cardCover() {
        return this._getOption('cardCover');
    }
    set cardCover(value) {
        this._setOption('cardCover', value);
    }
    get cardFooterTemplate() {
        return this._getOption('cardFooterTemplate');
    }
    set cardFooterTemplate(value) {
        this._setOption('cardFooterTemplate', value);
    }
    get cardHeader() {
        return this._getOption('cardHeader');
    }
    set cardHeader(value) {
        this._setOption('cardHeader', value);
    }
    get cardMaxWidth() {
        return this._getOption('cardMaxWidth');
    }
    set cardMaxWidth(value) {
        this._setOption('cardMaxWidth', value);
    }
    get cardMinWidth() {
        return this._getOption('cardMinWidth');
    }
    set cardMinWidth(value) {
        this._setOption('cardMinWidth', value);
    }
    get cardsPerRow() {
        return this._getOption('cardsPerRow');
    }
    set cardsPerRow(value) {
        this._setOption('cardsPerRow', value);
    }
    get cardTemplate() {
        return this._getOption('cardTemplate');
    }
    set cardTemplate(value) {
        this._setOption('cardTemplate', value);
    }
    get columnChooser() {
        return this._getOption('columnChooser');
    }
    set columnChooser(value) {
        this._setOption('columnChooser', value);
    }
    get columns() {
        return this._getOption('columns');
    }
    set columns(value) {
        this._setOption('columns', value);
    }
    get dataSource() {
        return this._getOption('dataSource');
    }
    set dataSource(value) {
        this._setOption('dataSource', value);
    }
    get disabled() {
        return this._getOption('disabled');
    }
    set disabled(value) {
        this._setOption('disabled', value);
    }
    get editing() {
        return this._getOption('editing');
    }
    set editing(value) {
        this._setOption('editing', value);
    }
    get elementAttr() {
        return this._getOption('elementAttr');
    }
    set elementAttr(value) {
        this._setOption('elementAttr', value);
    }
    get errorRowEnabled() {
        return this._getOption('errorRowEnabled');
    }
    set errorRowEnabled(value) {
        this._setOption('errorRowEnabled', value);
    }
    get fieldHintEnabled() {
        return this._getOption('fieldHintEnabled');
    }
    set fieldHintEnabled(value) {
        this._setOption('fieldHintEnabled', value);
    }
    get filterBuilder() {
        return this._getOption('filterBuilder');
    }
    set filterBuilder(value) {
        this._setOption('filterBuilder', value);
    }
    get filterBuilderPopup() {
        return this._getOption('filterBuilderPopup');
    }
    set filterBuilderPopup(value) {
        this._setOption('filterBuilderPopup', value);
    }
    get filterPanel() {
        return this._getOption('filterPanel');
    }
    set filterPanel(value) {
        this._setOption('filterPanel', value);
    }
    get filterValue() {
        return this._getOption('filterValue');
    }
    set filterValue(value) {
        this._setOption('filterValue', value);
    }
    get focusStateEnabled() {
        return this._getOption('focusStateEnabled');
    }
    set focusStateEnabled(value) {
        this._setOption('focusStateEnabled', value);
    }
    get headerFilter() {
        return this._getOption('headerFilter');
    }
    set headerFilter(value) {
        this._setOption('headerFilter', value);
    }
    get headerPanel() {
        return this._getOption('headerPanel');
    }
    set headerPanel(value) {
        this._setOption('headerPanel', value);
    }
    get height() {
        return this._getOption('height');
    }
    set height(value) {
        this._setOption('height', value);
    }
    get hint() {
        return this._getOption('hint');
    }
    set hint(value) {
        this._setOption('hint', value);
    }
    get hoverStateEnabled() {
        return this._getOption('hoverStateEnabled');
    }
    set hoverStateEnabled(value) {
        this._setOption('hoverStateEnabled', value);
    }
    get keyExpr() {
        return this._getOption('keyExpr');
    }
    set keyExpr(value) {
        this._setOption('keyExpr', value);
    }
    get loadPanel() {
        return this._getOption('loadPanel');
    }
    set loadPanel(value) {
        this._setOption('loadPanel', value);
    }
    get noDataTemplate() {
        return this._getOption('noDataTemplate');
    }
    set noDataTemplate(value) {
        this._setOption('noDataTemplate', value);
    }
    get noDataText() {
        return this._getOption('noDataText');
    }
    set noDataText(value) {
        this._setOption('noDataText', value);
    }
    get pager() {
        return this._getOption('pager');
    }
    set pager(value) {
        this._setOption('pager', value);
    }
    get paging() {
        return this._getOption('paging');
    }
    set paging(value) {
        this._setOption('paging', value);
    }
    get remoteOperations() {
        return this._getOption('remoteOperations');
    }
    set remoteOperations(value) {
        this._setOption('remoteOperations', value);
    }
    get rtlEnabled() {
        return this._getOption('rtlEnabled');
    }
    set rtlEnabled(value) {
        this._setOption('rtlEnabled', value);
    }
    get scrolling() {
        return this._getOption('scrolling');
    }
    set scrolling(value) {
        this._setOption('scrolling', value);
    }
    get searchPanel() {
        return this._getOption('searchPanel');
    }
    set searchPanel(value) {
        this._setOption('searchPanel', value);
    }
    get selectedCardKeys() {
        return this._getOption('selectedCardKeys');
    }
    set selectedCardKeys(value) {
        this._setOption('selectedCardKeys', value);
    }
    get selection() {
        return this._getOption('selection');
    }
    set selection(value) {
        this._setOption('selection', value);
    }
    get sorting() {
        return this._getOption('sorting');
    }
    set sorting(value) {
        this._setOption('sorting', value);
    }
    get tabIndex() {
        return this._getOption('tabIndex');
    }
    set tabIndex(value) {
        this._setOption('tabIndex', value);
    }
    get toolbar() {
        return this._getOption('toolbar');
    }
    set toolbar(value) {
        this._setOption('toolbar', value);
    }
    get visible() {
        return this._getOption('visible');
    }
    set visible(value) {
        this._setOption('visible', value);
    }
    get width() {
        return this._getOption('width');
    }
    set width(value) {
        this._setOption('width', value);
    }
    get wordWrapEnabled() {
        return this._getOption('wordWrapEnabled');
    }
    set wordWrapEnabled(value) {
        this._setOption('wordWrapEnabled', value);
    }
    constructor(elementRef, ngZone, templateHost, _watcherHelper, _idh, optionHost, transferState, platformId) {
        super(elementRef, ngZone, templateHost, _watcherHelper, transferState, platformId);
        this._watcherHelper = _watcherHelper;
        this._idh = _idh;
        this.instance = null;
        this._createEventEmitters([
            { subscribe: 'cardClick', emit: 'onCardClick' },
            { subscribe: 'cardDblClick', emit: 'onCardDblClick' },
            { subscribe: 'cardHoverChanged', emit: 'onCardHoverChanged' },
            { subscribe: 'cardInserted', emit: 'onCardInserted' },
            { subscribe: 'cardInserting', emit: 'onCardInserting' },
            { subscribe: 'cardPrepared', emit: 'onCardPrepared' },
            { subscribe: 'cardRemoved', emit: 'onCardRemoved' },
            { subscribe: 'cardRemoving', emit: 'onCardRemoving' },
            { subscribe: 'cardUpdated', emit: 'onCardUpdated' },
            { subscribe: 'cardUpdating', emit: 'onCardUpdating' },
            { subscribe: 'contentReady', emit: 'onContentReady' },
            { subscribe: 'contextMenuPreparing', emit: 'onContextMenuPreparing' },
            { subscribe: 'dataErrorOccurred', emit: 'onDataErrorOccurred' },
            { subscribe: 'disposing', emit: 'onDisposing' },
            { subscribe: 'editCanceled', emit: 'onEditCanceled' },
            { subscribe: 'editCanceling', emit: 'onEditCanceling' },
            { subscribe: 'editingStart', emit: 'onEditingStart' },
            { subscribe: 'fieldCaptionClick', emit: 'onFieldCaptionClick' },
            { subscribe: 'fieldCaptionDblClick', emit: 'onFieldCaptionDblClick' },
            { subscribe: 'fieldCaptionPrepared', emit: 'onFieldCaptionPrepared' },
            { subscribe: 'fieldValueClick', emit: 'onFieldValueClick' },
            { subscribe: 'fieldValueDblClick', emit: 'onFieldValueDblClick' },
            { subscribe: 'fieldValuePrepared', emit: 'onFieldValuePrepared' },
            { subscribe: 'focusedCardChanged', emit: 'onFocusedCardChanged' },
            { subscribe: 'initialized', emit: 'onInitialized' },
            { subscribe: 'initNewCard', emit: 'onInitNewCard' },
            { subscribe: 'optionChanged', emit: 'onOptionChanged' },
            { subscribe: 'saved', emit: 'onSaved' },
            { subscribe: 'saving', emit: 'onSaving' },
            { subscribe: 'selectionChanged', emit: 'onSelectionChanged' },
            { emit: 'accessKeyChange' },
            { emit: 'activeStateEnabledChange' },
            { emit: 'allowColumnReorderingChange' },
            { emit: 'cardContentTemplateChange' },
            { emit: 'cardCoverChange' },
            { emit: 'cardFooterTemplateChange' },
            { emit: 'cardHeaderChange' },
            { emit: 'cardMaxWidthChange' },
            { emit: 'cardMinWidthChange' },
            { emit: 'cardsPerRowChange' },
            { emit: 'cardTemplateChange' },
            { emit: 'columnChooserChange' },
            { emit: 'columnsChange' },
            { emit: 'dataSourceChange' },
            { emit: 'disabledChange' },
            { emit: 'editingChange' },
            { emit: 'elementAttrChange' },
            { emit: 'errorRowEnabledChange' },
            { emit: 'fieldHintEnabledChange' },
            { emit: 'filterBuilderChange' },
            { emit: 'filterBuilderPopupChange' },
            { emit: 'filterPanelChange' },
            { emit: 'filterValueChange' },
            { emit: 'focusStateEnabledChange' },
            { emit: 'headerFilterChange' },
            { emit: 'headerPanelChange' },
            { emit: 'heightChange' },
            { emit: 'hintChange' },
            { emit: 'hoverStateEnabledChange' },
            { emit: 'keyExprChange' },
            { emit: 'loadPanelChange' },
            { emit: 'noDataTemplateChange' },
            { emit: 'noDataTextChange' },
            { emit: 'pagerChange' },
            { emit: 'pagingChange' },
            { emit: 'remoteOperationsChange' },
            { emit: 'rtlEnabledChange' },
            { emit: 'scrollingChange' },
            { emit: 'searchPanelChange' },
            { emit: 'selectedCardKeysChange' },
            { emit: 'selectionChange' },
            { emit: 'sortingChange' },
            { emit: 'tabIndexChange' },
            { emit: 'toolbarChange' },
            { emit: 'visibleChange' },
            { emit: 'widthChange' },
            { emit: 'wordWrapEnabledChange' }
        ]);
        this._idh.setHost(this);
        optionHost.setHost(this);
    }
    _createInstance(element, options) {
        return new DxCardView(element, options);
    }
    ngOnDestroy() {
        this._destroyWidget();
    }
    ngOnChanges(changes) {
        super.ngOnChanges(changes);
        this.setupChanges('columns', changes);
        this.setupChanges('dataSource', changes);
        this.setupChanges('filterValue', changes);
        this.setupChanges('keyExpr', changes);
        this.setupChanges('selectedCardKeys', changes);
    }
    setupChanges(prop, changes) {
        if (!(prop in this._optionsToUpdate)) {
            this._idh.setup(prop, changes);
        }
    }
    ngDoCheck() {
        this._idh.doCheck('columns');
        this._idh.doCheck('dataSource');
        this._idh.doCheck('filterValue');
        this._idh.doCheck('keyExpr');
        this._idh.doCheck('selectedCardKeys');
        this._watcherHelper.checkWatchers();
        super.ngDoCheck();
        super.clearChangedOptions();
    }
    _setOption(name, value) {
        let isSetup = this._idh.setupSingle(name, value);
        let isChanged = this._idh.getChanges(name, value) !== null;
        if (isSetup || isChanged) {
            super._setOption(name, value);
        }
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxCardViewComponent, deps: [{ token: i0.ElementRef }, { token: i0.NgZone }, { token: i1.DxTemplateHost }, { token: i1.WatcherHelper }, { token: i1.IterableDifferHelper }, { token: i1.NestedOptionHost }, { token: i0.TransferState }, { token: PLATFORM_ID }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxCardViewComponent, isStandalone: true, selector: "dx-card-view", inputs: { accessKey: "accessKey", activeStateEnabled: "activeStateEnabled", allowColumnReordering: "allowColumnReordering", cardContentTemplate: "cardContentTemplate", cardCover: "cardCover", cardFooterTemplate: "cardFooterTemplate", cardHeader: "cardHeader", cardMaxWidth: "cardMaxWidth", cardMinWidth: "cardMinWidth", cardsPerRow: "cardsPerRow", cardTemplate: "cardTemplate", columnChooser: "columnChooser", columns: "columns", dataSource: "dataSource", disabled: "disabled", editing: "editing", elementAttr: "elementAttr", errorRowEnabled: "errorRowEnabled", fieldHintEnabled: "fieldHintEnabled", filterBuilder: "filterBuilder", filterBuilderPopup: "filterBuilderPopup", filterPanel: "filterPanel", filterValue: "filterValue", focusStateEnabled: "focusStateEnabled", headerFilter: "headerFilter", headerPanel: "headerPanel", height: "height", hint: "hint", hoverStateEnabled: "hoverStateEnabled", keyExpr: "keyExpr", loadPanel: "loadPanel", noDataTemplate: "noDataTemplate", noDataText: "noDataText", pager: "pager", paging: "paging", remoteOperations: "remoteOperations", rtlEnabled: "rtlEnabled", scrolling: "scrolling", searchPanel: "searchPanel", selectedCardKeys: "selectedCardKeys", selection: "selection", sorting: "sorting", tabIndex: "tabIndex", toolbar: "toolbar", visible: "visible", width: "width", wordWrapEnabled: "wordWrapEnabled" }, outputs: { onCardClick: "onCardClick", onCardDblClick: "onCardDblClick", onCardHoverChanged: "onCardHoverChanged", onCardInserted: "onCardInserted", onCardInserting: "onCardInserting", onCardPrepared: "onCardPrepared", onCardRemoved: "onCardRemoved", onCardRemoving: "onCardRemoving", onCardUpdated: "onCardUpdated", onCardUpdating: "onCardUpdating", onContentReady: "onContentReady", onContextMenuPreparing: "onContextMenuPreparing", onDataErrorOccurred: "onDataErrorOccurred", onDisposing: "onDisposing", onEditCanceled: "onEditCanceled", onEditCanceling: "onEditCanceling", onEditingStart: "onEditingStart", onFieldCaptionClick: "onFieldCaptionClick", onFieldCaptionDblClick: "onFieldCaptionDblClick", onFieldCaptionPrepared: "onFieldCaptionPrepared", onFieldValueClick: "onFieldValueClick", onFieldValueDblClick: "onFieldValueDblClick", onFieldValuePrepared: "onFieldValuePrepared", onFocusedCardChanged: "onFocusedCardChanged", onInitialized: "onInitialized", onInitNewCard: "onInitNewCard", onOptionChanged: "onOptionChanged", onSaved: "onSaved", onSaving: "onSaving", onSelectionChanged: "onSelectionChanged", accessKeyChange: "accessKeyChange", activeStateEnabledChange: "activeStateEnabledChange", allowColumnReorderingChange: "allowColumnReorderingChange", cardContentTemplateChange: "cardContentTemplateChange", cardCoverChange: "cardCoverChange", cardFooterTemplateChange: "cardFooterTemplateChange", cardHeaderChange: "cardHeaderChange", cardMaxWidthChange: "cardMaxWidthChange", cardMinWidthChange: "cardMinWidthChange", cardsPerRowChange: "cardsPerRowChange", cardTemplateChange: "cardTemplateChange", columnChooserChange: "columnChooserChange", columnsChange: "columnsChange", dataSourceChange: "dataSourceChange", disabledChange: "disabledChange", editingChange: "editingChange", elementAttrChange: "elementAttrChange", errorRowEnabledChange: "errorRowEnabledChange", fieldHintEnabledChange: "fieldHintEnabledChange", filterBuilderChange: "filterBuilderChange", filterBuilderPopupChange: "filterBuilderPopupChange", filterPanelChange: "filterPanelChange", filterValueChange: "filterValueChange", focusStateEnabledChange: "focusStateEnabledChange", headerFilterChange: "headerFilterChange", headerPanelChange: "headerPanelChange", heightChange: "heightChange", hintChange: "hintChange", hoverStateEnabledChange: "hoverStateEnabledChange", keyExprChange: "keyExprChange", loadPanelChange: "loadPanelChange", noDataTemplateChange: "noDataTemplateChange", noDataTextChange: "noDataTextChange", pagerChange: "pagerChange", pagingChange: "pagingChange", remoteOperationsChange: "remoteOperationsChange", rtlEnabledChange: "rtlEnabledChange", scrollingChange: "scrollingChange", searchPanelChange: "searchPanelChange", selectedCardKeysChange: "selectedCardKeysChange", selectionChange: "selectionChange", sortingChange: "sortingChange", tabIndexChange: "tabIndexChange", toolbarChange: "toolbarChange", visibleChange: "visibleChange", widthChange: "widthChange", wordWrapEnabledChange: "wordWrapEnabledChange" }, host: { attributes: { "ngSkipHydration": "true" } }, providers: [
            DxTemplateHost,
            WatcherHelper,
            NestedOptionHost,
            IterableDifferHelper
        ], queries: [{ propertyName: "_validationRulesContentChildren", predicate: PROPERTY_TOKEN_validationRules }, { propertyName: "_itemsContentChildren", predicate: PROPERTY_TOKEN_items }, { propertyName: "_changesContentChildren", predicate: PROPERTY_TOKEN_changes }, { propertyName: "_columnsContentChildren", predicate: PROPERTY_TOKEN_columns }, { propertyName: "_customOperationsContentChildren", predicate: PROPERTY_TOKEN_customOperations }, { propertyName: "_fieldsContentChildren", predicate: PROPERTY_TOKEN_fields }, { propertyName: "_tabsContentChildren", predicate: PROPERTY_TOKEN_tabs }], usesInheritance: true, usesOnChanges: true, ngImport: i0, template: '', isInline: true, dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxCardViewComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'dx-card-view',
                    template: '',
                    host: { ngSkipHydration: 'true' },
                    imports: [DxIntegrationModule],
                    providers: [
                        DxTemplateHost,
                        WatcherHelper,
                        NestedOptionHost,
                        IterableDifferHelper
                    ]
                }]
        }], ctorParameters: () => [{ type: i0.ElementRef }, { type: i0.NgZone }, { type: i1.DxTemplateHost }, { type: i1.WatcherHelper }, { type: i1.IterableDifferHelper }, { type: i1.NestedOptionHost }, { type: i0.TransferState }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [PLATFORM_ID]
                }] }], propDecorators: { _validationRulesContentChildren: [{
                type: ContentChildren,
                args: [PROPERTY_TOKEN_validationRules]
            }], _itemsContentChildren: [{
                type: ContentChildren,
                args: [PROPERTY_TOKEN_items]
            }], _changesContentChildren: [{
                type: ContentChildren,
                args: [PROPERTY_TOKEN_changes]
            }], _columnsContentChildren: [{
                type: ContentChildren,
                args: [PROPERTY_TOKEN_columns]
            }], _customOperationsContentChildren: [{
                type: ContentChildren,
                args: [PROPERTY_TOKEN_customOperations]
            }], _fieldsContentChildren: [{
                type: ContentChildren,
                args: [PROPERTY_TOKEN_fields]
            }], _tabsContentChildren: [{
                type: ContentChildren,
                args: [PROPERTY_TOKEN_tabs]
            }], accessKey: [{
                type: Input
            }], activeStateEnabled: [{
                type: Input
            }], allowColumnReordering: [{
                type: Input
            }], cardContentTemplate: [{
                type: Input
            }], cardCover: [{
                type: Input
            }], cardFooterTemplate: [{
                type: Input
            }], cardHeader: [{
                type: Input
            }], cardMaxWidth: [{
                type: Input
            }], cardMinWidth: [{
                type: Input
            }], cardsPerRow: [{
                type: Input
            }], cardTemplate: [{
                type: Input
            }], columnChooser: [{
                type: Input
            }], columns: [{
                type: Input
            }], dataSource: [{
                type: Input
            }], disabled: [{
                type: Input
            }], editing: [{
                type: Input
            }], elementAttr: [{
                type: Input
            }], errorRowEnabled: [{
                type: Input
            }], fieldHintEnabled: [{
                type: Input
            }], filterBuilder: [{
                type: Input
            }], filterBuilderPopup: [{
                type: Input
            }], filterPanel: [{
                type: Input
            }], filterValue: [{
                type: Input
            }], focusStateEnabled: [{
                type: Input
            }], headerFilter: [{
                type: Input
            }], headerPanel: [{
                type: Input
            }], height: [{
                type: Input
            }], hint: [{
                type: Input
            }], hoverStateEnabled: [{
                type: Input
            }], keyExpr: [{
                type: Input
            }], loadPanel: [{
                type: Input
            }], noDataTemplate: [{
                type: Input
            }], noDataText: [{
                type: Input
            }], pager: [{
                type: Input
            }], paging: [{
                type: Input
            }], remoteOperations: [{
                type: Input
            }], rtlEnabled: [{
                type: Input
            }], scrolling: [{
                type: Input
            }], searchPanel: [{
                type: Input
            }], selectedCardKeys: [{
                type: Input
            }], selection: [{
                type: Input
            }], sorting: [{
                type: Input
            }], tabIndex: [{
                type: Input
            }], toolbar: [{
                type: Input
            }], visible: [{
                type: Input
            }], width: [{
                type: Input
            }], wordWrapEnabled: [{
                type: Input
            }], onCardClick: [{
                type: Output
            }], onCardDblClick: [{
                type: Output
            }], onCardHoverChanged: [{
                type: Output
            }], onCardInserted: [{
                type: Output
            }], onCardInserting: [{
                type: Output
            }], onCardPrepared: [{
                type: Output
            }], onCardRemoved: [{
                type: Output
            }], onCardRemoving: [{
                type: Output
            }], onCardUpdated: [{
                type: Output
            }], onCardUpdating: [{
                type: Output
            }], onContentReady: [{
                type: Output
            }], onContextMenuPreparing: [{
                type: Output
            }], onDataErrorOccurred: [{
                type: Output
            }], onDisposing: [{
                type: Output
            }], onEditCanceled: [{
                type: Output
            }], onEditCanceling: [{
                type: Output
            }], onEditingStart: [{
                type: Output
            }], onFieldCaptionClick: [{
                type: Output
            }], onFieldCaptionDblClick: [{
                type: Output
            }], onFieldCaptionPrepared: [{
                type: Output
            }], onFieldValueClick: [{
                type: Output
            }], onFieldValueDblClick: [{
                type: Output
            }], onFieldValuePrepared: [{
                type: Output
            }], onFocusedCardChanged: [{
                type: Output
            }], onInitialized: [{
                type: Output
            }], onInitNewCard: [{
                type: Output
            }], onOptionChanged: [{
                type: Output
            }], onSaved: [{
                type: Output
            }], onSaving: [{
                type: Output
            }], onSelectionChanged: [{
                type: Output
            }], accessKeyChange: [{
                type: Output
            }], activeStateEnabledChange: [{
                type: Output
            }], allowColumnReorderingChange: [{
                type: Output
            }], cardContentTemplateChange: [{
                type: Output
            }], cardCoverChange: [{
                type: Output
            }], cardFooterTemplateChange: [{
                type: Output
            }], cardHeaderChange: [{
                type: Output
            }], cardMaxWidthChange: [{
                type: Output
            }], cardMinWidthChange: [{
                type: Output
            }], cardsPerRowChange: [{
                type: Output
            }], cardTemplateChange: [{
                type: Output
            }], columnChooserChange: [{
                type: Output
            }], columnsChange: [{
                type: Output
            }], dataSourceChange: [{
                type: Output
            }], disabledChange: [{
                type: Output
            }], editingChange: [{
                type: Output
            }], elementAttrChange: [{
                type: Output
            }], errorRowEnabledChange: [{
                type: Output
            }], fieldHintEnabledChange: [{
                type: Output
            }], filterBuilderChange: [{
                type: Output
            }], filterBuilderPopupChange: [{
                type: Output
            }], filterPanelChange: [{
                type: Output
            }], filterValueChange: [{
                type: Output
            }], focusStateEnabledChange: [{
                type: Output
            }], headerFilterChange: [{
                type: Output
            }], headerPanelChange: [{
                type: Output
            }], heightChange: [{
                type: Output
            }], hintChange: [{
                type: Output
            }], hoverStateEnabledChange: [{
                type: Output
            }], keyExprChange: [{
                type: Output
            }], loadPanelChange: [{
                type: Output
            }], noDataTemplateChange: [{
                type: Output
            }], noDataTextChange: [{
                type: Output
            }], pagerChange: [{
                type: Output
            }], pagingChange: [{
                type: Output
            }], remoteOperationsChange: [{
                type: Output
            }], rtlEnabledChange: [{
                type: Output
            }], scrollingChange: [{
                type: Output
            }], searchPanelChange: [{
                type: Output
            }], selectedCardKeysChange: [{
                type: Output
            }], selectionChange: [{
                type: Output
            }], sortingChange: [{
                type: Output
            }], tabIndexChange: [{
                type: Output
            }], toolbarChange: [{
                type: Output
            }], visibleChange: [{
                type: Output
            }], widthChange: [{
                type: Output
            }], wordWrapEnabledChange: [{
                type: Output
            }] } });
class DxCardViewModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxCardViewModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxCardViewModule, imports: [DxCardViewComponent, DxoCardViewAIOptionsModule,
            DxoCardViewAnimationModule,
            DxiCardViewAsyncRuleModule,
            DxoCardViewAtModule,
            DxoCardViewBoundaryOffsetModule,
            DxiCardViewButtonItemModule,
            DxoCardViewButtonOptionsModule,
            DxoCardViewCardCoverModule,
            DxoCardViewCardHeaderModule,
            DxiCardViewCardHeaderItemModule,
            DxoCardViewCardViewHeaderFilterModule,
            DxoCardViewCardViewHeaderFilterSearchModule,
            DxoCardViewCardViewHeaderFilterTextsModule,
            DxoCardViewCardViewSelectionModule,
            DxiCardViewChangeModule,
            DxoCardViewColCountByScreenModule,
            DxoCardViewCollisionModule,
            DxiCardViewColumnModule,
            DxoCardViewColumnChooserModule,
            DxoCardViewColumnChooserSearchModule,
            DxoCardViewColumnChooserSelectionModule,
            DxoCardViewColumnHeaderFilterModule,
            DxoCardViewColumnHeaderFilterSearchModule,
            DxiCardViewCompareRuleModule,
            DxiCardViewCustomOperationModule,
            DxiCardViewCustomRuleModule,
            DxoCardViewDraggingModule,
            DxoCardViewEditingModule,
            DxoCardViewEditingTextsModule,
            DxiCardViewEmailRuleModule,
            DxiCardViewEmptyItemModule,
            DxiCardViewFieldModule,
            DxoCardViewFilterBuilderModule,
            DxoCardViewFilterOperationDescriptionsModule,
            DxoCardViewFilterPanelModule,
            DxoCardViewFilterPanelTextsModule,
            DxoCardViewFormModule,
            DxoCardViewFormatModule,
            DxoCardViewFormItemModule,
            DxoCardViewFromModule,
            DxiCardViewGroupItemModule,
            DxoCardViewGroupOperationDescriptionsModule,
            DxoCardViewHeaderFilterModule,
            DxoCardViewHeaderPanelModule,
            DxoCardViewHideModule,
            DxoCardViewIndicatorOptionsModule,
            DxiCardViewItemModule,
            DxoCardViewLabelModule,
            DxoCardViewLoadPanelModule,
            DxoCardViewLookupModule,
            DxoCardViewMyModule,
            DxiCardViewNumericRuleModule,
            DxoCardViewOffsetModule,
            DxoCardViewPagerModule,
            DxoCardViewPagingModule,
            DxiCardViewPatternRuleModule,
            DxoCardViewPositionModule,
            DxiCardViewRangeRuleModule,
            DxoCardViewRemoteOperationsModule,
            DxiCardViewRequiredRuleModule,
            DxoCardViewScrollingModule,
            DxoCardViewSearchModule,
            DxoCardViewSearchPanelModule,
            DxoCardViewSelectionModule,
            DxoCardViewShowModule,
            DxiCardViewSimpleItemModule,
            DxoCardViewSortingModule,
            DxiCardViewStringLengthRuleModule,
            DxiCardViewTabModule,
            DxiCardViewTabbedItemModule,
            DxoCardViewTabPanelOptionsModule,
            DxiCardViewTabPanelOptionsItemModule,
            DxoCardViewTextsModule,
            DxoCardViewToModule,
            DxoCardViewToolbarModule,
            DxiCardViewToolbarItemModule,
            DxiCardViewValidationRuleModule,
            DxIntegrationModule,
            DxTemplateModule], exports: [DxCardViewComponent, DxoCardViewAIOptionsModule,
            DxoCardViewAnimationModule,
            DxiCardViewAsyncRuleModule,
            DxoCardViewAtModule,
            DxoCardViewBoundaryOffsetModule,
            DxiCardViewButtonItemModule,
            DxoCardViewButtonOptionsModule,
            DxoCardViewCardCoverModule,
            DxoCardViewCardHeaderModule,
            DxiCardViewCardHeaderItemModule,
            DxoCardViewCardViewHeaderFilterModule,
            DxoCardViewCardViewHeaderFilterSearchModule,
            DxoCardViewCardViewHeaderFilterTextsModule,
            DxoCardViewCardViewSelectionModule,
            DxiCardViewChangeModule,
            DxoCardViewColCountByScreenModule,
            DxoCardViewCollisionModule,
            DxiCardViewColumnModule,
            DxoCardViewColumnChooserModule,
            DxoCardViewColumnChooserSearchModule,
            DxoCardViewColumnChooserSelectionModule,
            DxoCardViewColumnHeaderFilterModule,
            DxoCardViewColumnHeaderFilterSearchModule,
            DxiCardViewCompareRuleModule,
            DxiCardViewCustomOperationModule,
            DxiCardViewCustomRuleModule,
            DxoCardViewDraggingModule,
            DxoCardViewEditingModule,
            DxoCardViewEditingTextsModule,
            DxiCardViewEmailRuleModule,
            DxiCardViewEmptyItemModule,
            DxiCardViewFieldModule,
            DxoCardViewFilterBuilderModule,
            DxoCardViewFilterOperationDescriptionsModule,
            DxoCardViewFilterPanelModule,
            DxoCardViewFilterPanelTextsModule,
            DxoCardViewFormModule,
            DxoCardViewFormatModule,
            DxoCardViewFormItemModule,
            DxoCardViewFromModule,
            DxiCardViewGroupItemModule,
            DxoCardViewGroupOperationDescriptionsModule,
            DxoCardViewHeaderFilterModule,
            DxoCardViewHeaderPanelModule,
            DxoCardViewHideModule,
            DxoCardViewIndicatorOptionsModule,
            DxiCardViewItemModule,
            DxoCardViewLabelModule,
            DxoCardViewLoadPanelModule,
            DxoCardViewLookupModule,
            DxoCardViewMyModule,
            DxiCardViewNumericRuleModule,
            DxoCardViewOffsetModule,
            DxoCardViewPagerModule,
            DxoCardViewPagingModule,
            DxiCardViewPatternRuleModule,
            DxoCardViewPositionModule,
            DxiCardViewRangeRuleModule,
            DxoCardViewRemoteOperationsModule,
            DxiCardViewRequiredRuleModule,
            DxoCardViewScrollingModule,
            DxoCardViewSearchModule,
            DxoCardViewSearchPanelModule,
            DxoCardViewSelectionModule,
            DxoCardViewShowModule,
            DxiCardViewSimpleItemModule,
            DxoCardViewSortingModule,
            DxiCardViewStringLengthRuleModule,
            DxiCardViewTabModule,
            DxiCardViewTabbedItemModule,
            DxoCardViewTabPanelOptionsModule,
            DxiCardViewTabPanelOptionsItemModule,
            DxoCardViewTextsModule,
            DxoCardViewToModule,
            DxoCardViewToolbarModule,
            DxiCardViewToolbarItemModule,
            DxiCardViewValidationRuleModule,
            DxTemplateModule] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxCardViewModule, imports: [DxCardViewComponent,
            DxoCardViewAIOptionsModule,
            DxoCardViewAnimationModule,
            DxiCardViewAsyncRuleModule,
            DxoCardViewAtModule,
            DxoCardViewBoundaryOffsetModule,
            DxiCardViewButtonItemModule,
            DxoCardViewButtonOptionsModule,
            DxoCardViewCardCoverModule,
            DxoCardViewCardHeaderModule,
            DxiCardViewCardHeaderItemModule,
            DxoCardViewCardViewHeaderFilterModule,
            DxoCardViewCardViewHeaderFilterSearchModule,
            DxoCardViewCardViewHeaderFilterTextsModule,
            DxoCardViewCardViewSelectionModule,
            DxiCardViewChangeModule,
            DxoCardViewColCountByScreenModule,
            DxoCardViewCollisionModule,
            DxiCardViewColumnModule,
            DxoCardViewColumnChooserModule,
            DxoCardViewColumnChooserSearchModule,
            DxoCardViewColumnChooserSelectionModule,
            DxoCardViewColumnHeaderFilterModule,
            DxoCardViewColumnHeaderFilterSearchModule,
            DxiCardViewCompareRuleModule,
            DxiCardViewCustomOperationModule,
            DxiCardViewCustomRuleModule,
            DxoCardViewDraggingModule,
            DxoCardViewEditingModule,
            DxoCardViewEditingTextsModule,
            DxiCardViewEmailRuleModule,
            DxiCardViewEmptyItemModule,
            DxiCardViewFieldModule,
            DxoCardViewFilterBuilderModule,
            DxoCardViewFilterOperationDescriptionsModule,
            DxoCardViewFilterPanelModule,
            DxoCardViewFilterPanelTextsModule,
            DxoCardViewFormModule,
            DxoCardViewFormatModule,
            DxoCardViewFormItemModule,
            DxoCardViewFromModule,
            DxiCardViewGroupItemModule,
            DxoCardViewGroupOperationDescriptionsModule,
            DxoCardViewHeaderFilterModule,
            DxoCardViewHeaderPanelModule,
            DxoCardViewHideModule,
            DxoCardViewIndicatorOptionsModule,
            DxiCardViewItemModule,
            DxoCardViewLabelModule,
            DxoCardViewLoadPanelModule,
            DxoCardViewLookupModule,
            DxoCardViewMyModule,
            DxiCardViewNumericRuleModule,
            DxoCardViewOffsetModule,
            DxoCardViewPagerModule,
            DxoCardViewPagingModule,
            DxiCardViewPatternRuleModule,
            DxoCardViewPositionModule,
            DxiCardViewRangeRuleModule,
            DxoCardViewRemoteOperationsModule,
            DxiCardViewRequiredRuleModule,
            DxoCardViewScrollingModule,
            DxoCardViewSearchModule,
            DxoCardViewSearchPanelModule,
            DxoCardViewSelectionModule,
            DxoCardViewShowModule,
            DxiCardViewSimpleItemModule,
            DxoCardViewSortingModule,
            DxiCardViewStringLengthRuleModule,
            DxiCardViewTabModule,
            DxiCardViewTabbedItemModule,
            DxoCardViewTabPanelOptionsModule,
            DxiCardViewTabPanelOptionsItemModule,
            DxoCardViewTextsModule,
            DxoCardViewToModule,
            DxoCardViewToolbarModule,
            DxiCardViewToolbarItemModule,
            DxiCardViewValidationRuleModule,
            DxIntegrationModule,
            DxTemplateModule, DxoCardViewAIOptionsModule,
            DxoCardViewAnimationModule,
            DxiCardViewAsyncRuleModule,
            DxoCardViewAtModule,
            DxoCardViewBoundaryOffsetModule,
            DxiCardViewButtonItemModule,
            DxoCardViewButtonOptionsModule,
            DxoCardViewCardCoverModule,
            DxoCardViewCardHeaderModule,
            DxiCardViewCardHeaderItemModule,
            DxoCardViewCardViewHeaderFilterModule,
            DxoCardViewCardViewHeaderFilterSearchModule,
            DxoCardViewCardViewHeaderFilterTextsModule,
            DxoCardViewCardViewSelectionModule,
            DxiCardViewChangeModule,
            DxoCardViewColCountByScreenModule,
            DxoCardViewCollisionModule,
            DxiCardViewColumnModule,
            DxoCardViewColumnChooserModule,
            DxoCardViewColumnChooserSearchModule,
            DxoCardViewColumnChooserSelectionModule,
            DxoCardViewColumnHeaderFilterModule,
            DxoCardViewColumnHeaderFilterSearchModule,
            DxiCardViewCompareRuleModule,
            DxiCardViewCustomOperationModule,
            DxiCardViewCustomRuleModule,
            DxoCardViewDraggingModule,
            DxoCardViewEditingModule,
            DxoCardViewEditingTextsModule,
            DxiCardViewEmailRuleModule,
            DxiCardViewEmptyItemModule,
            DxiCardViewFieldModule,
            DxoCardViewFilterBuilderModule,
            DxoCardViewFilterOperationDescriptionsModule,
            DxoCardViewFilterPanelModule,
            DxoCardViewFilterPanelTextsModule,
            DxoCardViewFormModule,
            DxoCardViewFormatModule,
            DxoCardViewFormItemModule,
            DxoCardViewFromModule,
            DxiCardViewGroupItemModule,
            DxoCardViewGroupOperationDescriptionsModule,
            DxoCardViewHeaderFilterModule,
            DxoCardViewHeaderPanelModule,
            DxoCardViewHideModule,
            DxoCardViewIndicatorOptionsModule,
            DxiCardViewItemModule,
            DxoCardViewLabelModule,
            DxoCardViewLoadPanelModule,
            DxoCardViewLookupModule,
            DxoCardViewMyModule,
            DxiCardViewNumericRuleModule,
            DxoCardViewOffsetModule,
            DxoCardViewPagerModule,
            DxoCardViewPagingModule,
            DxiCardViewPatternRuleModule,
            DxoCardViewPositionModule,
            DxiCardViewRangeRuleModule,
            DxoCardViewRemoteOperationsModule,
            DxiCardViewRequiredRuleModule,
            DxoCardViewScrollingModule,
            DxoCardViewSearchModule,
            DxoCardViewSearchPanelModule,
            DxoCardViewSelectionModule,
            DxoCardViewShowModule,
            DxiCardViewSimpleItemModule,
            DxoCardViewSortingModule,
            DxiCardViewStringLengthRuleModule,
            DxiCardViewTabModule,
            DxiCardViewTabbedItemModule,
            DxoCardViewTabPanelOptionsModule,
            DxiCardViewTabPanelOptionsItemModule,
            DxoCardViewTextsModule,
            DxoCardViewToModule,
            DxoCardViewToolbarModule,
            DxiCardViewToolbarItemModule,
            DxiCardViewValidationRuleModule,
            DxTemplateModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxCardViewModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxCardViewComponent,
                        DxoCardViewAIOptionsModule,
                        DxoCardViewAnimationModule,
                        DxiCardViewAsyncRuleModule,
                        DxoCardViewAtModule,
                        DxoCardViewBoundaryOffsetModule,
                        DxiCardViewButtonItemModule,
                        DxoCardViewButtonOptionsModule,
                        DxoCardViewCardCoverModule,
                        DxoCardViewCardHeaderModule,
                        DxiCardViewCardHeaderItemModule,
                        DxoCardViewCardViewHeaderFilterModule,
                        DxoCardViewCardViewHeaderFilterSearchModule,
                        DxoCardViewCardViewHeaderFilterTextsModule,
                        DxoCardViewCardViewSelectionModule,
                        DxiCardViewChangeModule,
                        DxoCardViewColCountByScreenModule,
                        DxoCardViewCollisionModule,
                        DxiCardViewColumnModule,
                        DxoCardViewColumnChooserModule,
                        DxoCardViewColumnChooserSearchModule,
                        DxoCardViewColumnChooserSelectionModule,
                        DxoCardViewColumnHeaderFilterModule,
                        DxoCardViewColumnHeaderFilterSearchModule,
                        DxiCardViewCompareRuleModule,
                        DxiCardViewCustomOperationModule,
                        DxiCardViewCustomRuleModule,
                        DxoCardViewDraggingModule,
                        DxoCardViewEditingModule,
                        DxoCardViewEditingTextsModule,
                        DxiCardViewEmailRuleModule,
                        DxiCardViewEmptyItemModule,
                        DxiCardViewFieldModule,
                        DxoCardViewFilterBuilderModule,
                        DxoCardViewFilterOperationDescriptionsModule,
                        DxoCardViewFilterPanelModule,
                        DxoCardViewFilterPanelTextsModule,
                        DxoCardViewFormModule,
                        DxoCardViewFormatModule,
                        DxoCardViewFormItemModule,
                        DxoCardViewFromModule,
                        DxiCardViewGroupItemModule,
                        DxoCardViewGroupOperationDescriptionsModule,
                        DxoCardViewHeaderFilterModule,
                        DxoCardViewHeaderPanelModule,
                        DxoCardViewHideModule,
                        DxoCardViewIndicatorOptionsModule,
                        DxiCardViewItemModule,
                        DxoCardViewLabelModule,
                        DxoCardViewLoadPanelModule,
                        DxoCardViewLookupModule,
                        DxoCardViewMyModule,
                        DxiCardViewNumericRuleModule,
                        DxoCardViewOffsetModule,
                        DxoCardViewPagerModule,
                        DxoCardViewPagingModule,
                        DxiCardViewPatternRuleModule,
                        DxoCardViewPositionModule,
                        DxiCardViewRangeRuleModule,
                        DxoCardViewRemoteOperationsModule,
                        DxiCardViewRequiredRuleModule,
                        DxoCardViewScrollingModule,
                        DxoCardViewSearchModule,
                        DxoCardViewSearchPanelModule,
                        DxoCardViewSelectionModule,
                        DxoCardViewShowModule,
                        DxiCardViewSimpleItemModule,
                        DxoCardViewSortingModule,
                        DxiCardViewStringLengthRuleModule,
                        DxiCardViewTabModule,
                        DxiCardViewTabbedItemModule,
                        DxoCardViewTabPanelOptionsModule,
                        DxiCardViewTabPanelOptionsItemModule,
                        DxoCardViewTextsModule,
                        DxoCardViewToModule,
                        DxoCardViewToolbarModule,
                        DxiCardViewToolbarItemModule,
                        DxiCardViewValidationRuleModule,
                        DxIntegrationModule,
                        DxTemplateModule
                    ],
                    exports: [
                        DxCardViewComponent,
                        DxoCardViewAIOptionsModule,
                        DxoCardViewAnimationModule,
                        DxiCardViewAsyncRuleModule,
                        DxoCardViewAtModule,
                        DxoCardViewBoundaryOffsetModule,
                        DxiCardViewButtonItemModule,
                        DxoCardViewButtonOptionsModule,
                        DxoCardViewCardCoverModule,
                        DxoCardViewCardHeaderModule,
                        DxiCardViewCardHeaderItemModule,
                        DxoCardViewCardViewHeaderFilterModule,
                        DxoCardViewCardViewHeaderFilterSearchModule,
                        DxoCardViewCardViewHeaderFilterTextsModule,
                        DxoCardViewCardViewSelectionModule,
                        DxiCardViewChangeModule,
                        DxoCardViewColCountByScreenModule,
                        DxoCardViewCollisionModule,
                        DxiCardViewColumnModule,
                        DxoCardViewColumnChooserModule,
                        DxoCardViewColumnChooserSearchModule,
                        DxoCardViewColumnChooserSelectionModule,
                        DxoCardViewColumnHeaderFilterModule,
                        DxoCardViewColumnHeaderFilterSearchModule,
                        DxiCardViewCompareRuleModule,
                        DxiCardViewCustomOperationModule,
                        DxiCardViewCustomRuleModule,
                        DxoCardViewDraggingModule,
                        DxoCardViewEditingModule,
                        DxoCardViewEditingTextsModule,
                        DxiCardViewEmailRuleModule,
                        DxiCardViewEmptyItemModule,
                        DxiCardViewFieldModule,
                        DxoCardViewFilterBuilderModule,
                        DxoCardViewFilterOperationDescriptionsModule,
                        DxoCardViewFilterPanelModule,
                        DxoCardViewFilterPanelTextsModule,
                        DxoCardViewFormModule,
                        DxoCardViewFormatModule,
                        DxoCardViewFormItemModule,
                        DxoCardViewFromModule,
                        DxiCardViewGroupItemModule,
                        DxoCardViewGroupOperationDescriptionsModule,
                        DxoCardViewHeaderFilterModule,
                        DxoCardViewHeaderPanelModule,
                        DxoCardViewHideModule,
                        DxoCardViewIndicatorOptionsModule,
                        DxiCardViewItemModule,
                        DxoCardViewLabelModule,
                        DxoCardViewLoadPanelModule,
                        DxoCardViewLookupModule,
                        DxoCardViewMyModule,
                        DxiCardViewNumericRuleModule,
                        DxoCardViewOffsetModule,
                        DxoCardViewPagerModule,
                        DxoCardViewPagingModule,
                        DxiCardViewPatternRuleModule,
                        DxoCardViewPositionModule,
                        DxiCardViewRangeRuleModule,
                        DxoCardViewRemoteOperationsModule,
                        DxiCardViewRequiredRuleModule,
                        DxoCardViewScrollingModule,
                        DxoCardViewSearchModule,
                        DxoCardViewSearchPanelModule,
                        DxoCardViewSelectionModule,
                        DxoCardViewShowModule,
                        DxiCardViewSimpleItemModule,
                        DxoCardViewSortingModule,
                        DxiCardViewStringLengthRuleModule,
                        DxiCardViewTabModule,
                        DxiCardViewTabbedItemModule,
                        DxoCardViewTabPanelOptionsModule,
                        DxiCardViewTabPanelOptionsItemModule,
                        DxoCardViewTextsModule,
                        DxoCardViewToModule,
                        DxoCardViewToolbarModule,
                        DxiCardViewToolbarItemModule,
                        DxiCardViewValidationRuleModule,
                        DxTemplateModule
                    ]
                }]
        }] });

/**
 * Generated bundle index. Do not edit.
 */

export { DxCardViewComponent, DxCardViewModule };
//# sourceMappingURL=devextreme-angular-ui-card-view.mjs.map
