import * as i0 from '@angular/core';
import { Input, SkipSelf, Host, Component, NgModule, ContentChildren, Inject, Output } from '@angular/core';
import * as i1 from 'devextreme-angular/core';
import { NestedOption, DxIntegrationModule, NestedOptionHost, CollectionNestedOption, extractTemplate, DxTemplateHost } from 'devextreme-angular/core';
import { PROPERTY_TOKEN_items, PROPERTY_TOKEN_commands, PROPERTY_TOKEN_connectionPoints, PROPERTY_TOKEN_customShapes, PROPERTY_TOKEN_groups, PROPERTY_TOKEN_tabs } from 'devextreme-angular/core/tokens';
import { DOCUMENT } from '@angular/common';

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoDiagramAutoLayoutComponent extends NestedOption {
    get orientation() {
        return this._getOption('orientation');
    }
    set orientation(value) {
        this._setOption('orientation', value);
    }
    get type() {
        return this._getOption('type');
    }
    set type(value) {
        this._setOption('type', value);
    }
    get _optionPath() {
        return 'autoLayout';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDiagramAutoLayoutComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoDiagramAutoLayoutComponent, isStandalone: true, selector: "dxo-diagram-auto-layout", inputs: { orientation: "orientation", type: "type" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDiagramAutoLayoutComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-diagram-auto-layout', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { orientation: [{
                type: Input
            }], type: [{
                type: Input
            }] } });
class DxoDiagramAutoLayoutModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDiagramAutoLayoutModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoDiagramAutoLayoutModule, imports: [DxoDiagramAutoLayoutComponent], exports: [DxoDiagramAutoLayoutComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDiagramAutoLayoutModule, imports: [DxoDiagramAutoLayoutComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDiagramAutoLayoutModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoDiagramAutoLayoutComponent
                    ],
                    exports: [
                        DxoDiagramAutoLayoutComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxiDiagramCommandComponent extends CollectionNestedOption {
    set _itemsContentChildren(value) {
        this.setChildren('items', value);
    }
    get icon() {
        return this._getOption('icon');
    }
    set icon(value) {
        this._setOption('icon', value);
    }
    get items() {
        return this._getOption('items');
    }
    set items(value) {
        this._setOption('items', value);
    }
    get location() {
        return this._getOption('location');
    }
    set location(value) {
        this._setOption('location', value);
    }
    get name() {
        return this._getOption('name');
    }
    set name(value) {
        this._setOption('name', value);
    }
    get text() {
        return this._getOption('text');
    }
    set text(value) {
        this._setOption('text', value);
    }
    get _optionPath() {
        return 'commands';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnDestroy() {
        this._deleteRemovedOptions(this._fullOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiDiagramCommandComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxiDiagramCommandComponent, isStandalone: true, selector: "dxi-diagram-command", inputs: { icon: "icon", items: "items", location: "location", name: "name", text: "text" }, providers: [
            NestedOptionHost,
            {
                provide: PROPERTY_TOKEN_commands,
                useExisting: DxiDiagramCommandComponent,
            }
        ], queries: [{ propertyName: "_itemsContentChildren", predicate: PROPERTY_TOKEN_items }], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiDiagramCommandComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxi-diagram-command', template: '', imports: [DxIntegrationModule], providers: [
                        NestedOptionHost,
                        {
                            provide: PROPERTY_TOKEN_commands,
                            useExisting: DxiDiagramCommandComponent,
                        }
                    ] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { _itemsContentChildren: [{
                type: ContentChildren,
                args: [PROPERTY_TOKEN_items]
            }], icon: [{
                type: Input
            }], items: [{
                type: Input
            }], location: [{
                type: Input
            }], name: [{
                type: Input
            }], text: [{
                type: Input
            }] } });
class DxiDiagramCommandModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiDiagramCommandModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxiDiagramCommandModule, imports: [DxiDiagramCommandComponent], exports: [DxiDiagramCommandComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiDiagramCommandModule, imports: [DxiDiagramCommandComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiDiagramCommandModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxiDiagramCommandComponent
                    ],
                    exports: [
                        DxiDiagramCommandComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxiDiagramCommandItemComponent extends CollectionNestedOption {
    set _itemsContentChildren(value) {
        this.setChildren('items', value);
    }
    get icon() {
        return this._getOption('icon');
    }
    set icon(value) {
        this._setOption('icon', value);
    }
    get items() {
        return this._getOption('items');
    }
    set items(value) {
        this._setOption('items', value);
    }
    get location() {
        return this._getOption('location');
    }
    set location(value) {
        this._setOption('location', value);
    }
    get name() {
        return this._getOption('name');
    }
    set name(value) {
        this._setOption('name', value);
    }
    get text() {
        return this._getOption('text');
    }
    set text(value) {
        this._setOption('text', value);
    }
    get _optionPath() {
        return 'items';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnDestroy() {
        this._deleteRemovedOptions(this._fullOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiDiagramCommandItemComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxiDiagramCommandItemComponent, isStandalone: true, selector: "dxi-diagram-command-item", inputs: { icon: "icon", items: "items", location: "location", name: "name", text: "text" }, providers: [
            NestedOptionHost,
            {
                provide: PROPERTY_TOKEN_items,
                useExisting: DxiDiagramCommandItemComponent,
            }
        ], queries: [{ propertyName: "_itemsContentChildren", predicate: PROPERTY_TOKEN_items }], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiDiagramCommandItemComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxi-diagram-command-item', template: '', imports: [DxIntegrationModule], providers: [
                        NestedOptionHost,
                        {
                            provide: PROPERTY_TOKEN_items,
                            useExisting: DxiDiagramCommandItemComponent,
                        }
                    ] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { _itemsContentChildren: [{
                type: ContentChildren,
                args: [PROPERTY_TOKEN_items]
            }], icon: [{
                type: Input
            }], items: [{
                type: Input
            }], location: [{
                type: Input
            }], name: [{
                type: Input
            }], text: [{
                type: Input
            }] } });
class DxiDiagramCommandItemModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiDiagramCommandItemModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxiDiagramCommandItemModule, imports: [DxiDiagramCommandItemComponent], exports: [DxiDiagramCommandItemComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiDiagramCommandItemModule, imports: [DxiDiagramCommandItemComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiDiagramCommandItemModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxiDiagramCommandItemComponent
                    ],
                    exports: [
                        DxiDiagramCommandItemComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxiDiagramConnectionPointComponent extends CollectionNestedOption {
    get x() {
        return this._getOption('x');
    }
    set x(value) {
        this._setOption('x', value);
    }
    get y() {
        return this._getOption('y');
    }
    set y(value) {
        this._setOption('y', value);
    }
    get _optionPath() {
        return 'connectionPoints';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnDestroy() {
        this._deleteRemovedOptions(this._fullOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiDiagramConnectionPointComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxiDiagramConnectionPointComponent, isStandalone: true, selector: "dxi-diagram-connection-point", inputs: { x: "x", y: "y" }, providers: [
            NestedOptionHost,
            {
                provide: PROPERTY_TOKEN_connectionPoints,
                useExisting: DxiDiagramConnectionPointComponent,
            }
        ], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiDiagramConnectionPointComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxi-diagram-connection-point', template: '', imports: [DxIntegrationModule], providers: [
                        NestedOptionHost,
                        {
                            provide: PROPERTY_TOKEN_connectionPoints,
                            useExisting: DxiDiagramConnectionPointComponent,
                        }
                    ] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { x: [{
                type: Input
            }], y: [{
                type: Input
            }] } });
class DxiDiagramConnectionPointModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiDiagramConnectionPointModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxiDiagramConnectionPointModule, imports: [DxiDiagramConnectionPointComponent], exports: [DxiDiagramConnectionPointComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiDiagramConnectionPointModule, imports: [DxiDiagramConnectionPointComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiDiagramConnectionPointModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxiDiagramConnectionPointComponent
                    ],
                    exports: [
                        DxiDiagramConnectionPointComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoDiagramContextMenuComponent extends NestedOption {
    set _commandsContentChildren(value) {
        this.setChildren('commands', value);
    }
    get commands() {
        return this._getOption('commands');
    }
    set commands(value) {
        this._setOption('commands', value);
    }
    get enabled() {
        return this._getOption('enabled');
    }
    set enabled(value) {
        this._setOption('enabled', value);
    }
    get _optionPath() {
        return 'contextMenu';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDiagramContextMenuComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoDiagramContextMenuComponent, isStandalone: true, selector: "dxo-diagram-context-menu", inputs: { commands: "commands", enabled: "enabled" }, providers: [NestedOptionHost], queries: [{ propertyName: "_commandsContentChildren", predicate: PROPERTY_TOKEN_commands }], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDiagramContextMenuComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-diagram-context-menu', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { _commandsContentChildren: [{
                type: ContentChildren,
                args: [PROPERTY_TOKEN_commands]
            }], commands: [{
                type: Input
            }], enabled: [{
                type: Input
            }] } });
class DxoDiagramContextMenuModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDiagramContextMenuModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoDiagramContextMenuModule, imports: [DxoDiagramContextMenuComponent], exports: [DxoDiagramContextMenuComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDiagramContextMenuModule, imports: [DxoDiagramContextMenuComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDiagramContextMenuModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoDiagramContextMenuComponent
                    ],
                    exports: [
                        DxoDiagramContextMenuComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoDiagramContextToolboxComponent extends NestedOption {
    get category() {
        return this._getOption('category');
    }
    set category(value) {
        this._setOption('category', value);
    }
    get displayMode() {
        return this._getOption('displayMode');
    }
    set displayMode(value) {
        this._setOption('displayMode', value);
    }
    get enabled() {
        return this._getOption('enabled');
    }
    set enabled(value) {
        this._setOption('enabled', value);
    }
    get shapeIconsPerRow() {
        return this._getOption('shapeIconsPerRow');
    }
    set shapeIconsPerRow(value) {
        this._setOption('shapeIconsPerRow', value);
    }
    get shapes() {
        return this._getOption('shapes');
    }
    set shapes(value) {
        this._setOption('shapes', value);
    }
    get width() {
        return this._getOption('width');
    }
    set width(value) {
        this._setOption('width', value);
    }
    get _optionPath() {
        return 'contextToolbox';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDiagramContextToolboxComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoDiagramContextToolboxComponent, isStandalone: true, selector: "dxo-diagram-context-toolbox", inputs: { category: "category", displayMode: "displayMode", enabled: "enabled", shapeIconsPerRow: "shapeIconsPerRow", shapes: "shapes", width: "width" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDiagramContextToolboxComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-diagram-context-toolbox', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { category: [{
                type: Input
            }], displayMode: [{
                type: Input
            }], enabled: [{
                type: Input
            }], shapeIconsPerRow: [{
                type: Input
            }], shapes: [{
                type: Input
            }], width: [{
                type: Input
            }] } });
class DxoDiagramContextToolboxModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDiagramContextToolboxModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoDiagramContextToolboxModule, imports: [DxoDiagramContextToolboxComponent], exports: [DxoDiagramContextToolboxComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDiagramContextToolboxModule, imports: [DxoDiagramContextToolboxComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDiagramContextToolboxModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoDiagramContextToolboxComponent
                    ],
                    exports: [
                        DxoDiagramContextToolboxComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxiDiagramCustomShapeComponent extends CollectionNestedOption {
    set _connectionPointsContentChildren(value) {
        this.setChildren('connectionPoints', value);
    }
    get allowEditImage() {
        return this._getOption('allowEditImage');
    }
    set allowEditImage(value) {
        this._setOption('allowEditImage', value);
    }
    get allowEditText() {
        return this._getOption('allowEditText');
    }
    set allowEditText(value) {
        this._setOption('allowEditText', value);
    }
    get allowResize() {
        return this._getOption('allowResize');
    }
    set allowResize(value) {
        this._setOption('allowResize', value);
    }
    get backgroundImageHeight() {
        return this._getOption('backgroundImageHeight');
    }
    set backgroundImageHeight(value) {
        this._setOption('backgroundImageHeight', value);
    }
    get backgroundImageLeft() {
        return this._getOption('backgroundImageLeft');
    }
    set backgroundImageLeft(value) {
        this._setOption('backgroundImageLeft', value);
    }
    get backgroundImageToolboxUrl() {
        return this._getOption('backgroundImageToolboxUrl');
    }
    set backgroundImageToolboxUrl(value) {
        this._setOption('backgroundImageToolboxUrl', value);
    }
    get backgroundImageTop() {
        return this._getOption('backgroundImageTop');
    }
    set backgroundImageTop(value) {
        this._setOption('backgroundImageTop', value);
    }
    get backgroundImageUrl() {
        return this._getOption('backgroundImageUrl');
    }
    set backgroundImageUrl(value) {
        this._setOption('backgroundImageUrl', value);
    }
    get backgroundImageWidth() {
        return this._getOption('backgroundImageWidth');
    }
    set backgroundImageWidth(value) {
        this._setOption('backgroundImageWidth', value);
    }
    get baseType() {
        return this._getOption('baseType');
    }
    set baseType(value) {
        this._setOption('baseType', value);
    }
    get category() {
        return this._getOption('category');
    }
    set category(value) {
        this._setOption('category', value);
    }
    get connectionPoints() {
        return this._getOption('connectionPoints');
    }
    set connectionPoints(value) {
        this._setOption('connectionPoints', value);
    }
    get defaultHeight() {
        return this._getOption('defaultHeight');
    }
    set defaultHeight(value) {
        this._setOption('defaultHeight', value);
    }
    get defaultImageUrl() {
        return this._getOption('defaultImageUrl');
    }
    set defaultImageUrl(value) {
        this._setOption('defaultImageUrl', value);
    }
    get defaultText() {
        return this._getOption('defaultText');
    }
    set defaultText(value) {
        this._setOption('defaultText', value);
    }
    get defaultWidth() {
        return this._getOption('defaultWidth');
    }
    set defaultWidth(value) {
        this._setOption('defaultWidth', value);
    }
    get imageHeight() {
        return this._getOption('imageHeight');
    }
    set imageHeight(value) {
        this._setOption('imageHeight', value);
    }
    get imageLeft() {
        return this._getOption('imageLeft');
    }
    set imageLeft(value) {
        this._setOption('imageLeft', value);
    }
    get imageTop() {
        return this._getOption('imageTop');
    }
    set imageTop(value) {
        this._setOption('imageTop', value);
    }
    get imageWidth() {
        return this._getOption('imageWidth');
    }
    set imageWidth(value) {
        this._setOption('imageWidth', value);
    }
    get keepRatioOnAutoSize() {
        return this._getOption('keepRatioOnAutoSize');
    }
    set keepRatioOnAutoSize(value) {
        this._setOption('keepRatioOnAutoSize', value);
    }
    get maxHeight() {
        return this._getOption('maxHeight');
    }
    set maxHeight(value) {
        this._setOption('maxHeight', value);
    }
    get maxWidth() {
        return this._getOption('maxWidth');
    }
    set maxWidth(value) {
        this._setOption('maxWidth', value);
    }
    get minHeight() {
        return this._getOption('minHeight');
    }
    set minHeight(value) {
        this._setOption('minHeight', value);
    }
    get minWidth() {
        return this._getOption('minWidth');
    }
    set minWidth(value) {
        this._setOption('minWidth', value);
    }
    get template() {
        return this._getOption('template');
    }
    set template(value) {
        this._setOption('template', value);
    }
    get templateHeight() {
        return this._getOption('templateHeight');
    }
    set templateHeight(value) {
        this._setOption('templateHeight', value);
    }
    get templateLeft() {
        return this._getOption('templateLeft');
    }
    set templateLeft(value) {
        this._setOption('templateLeft', value);
    }
    get templateTop() {
        return this._getOption('templateTop');
    }
    set templateTop(value) {
        this._setOption('templateTop', value);
    }
    get templateWidth() {
        return this._getOption('templateWidth');
    }
    set templateWidth(value) {
        this._setOption('templateWidth', value);
    }
    get textHeight() {
        return this._getOption('textHeight');
    }
    set textHeight(value) {
        this._setOption('textHeight', value);
    }
    get textLeft() {
        return this._getOption('textLeft');
    }
    set textLeft(value) {
        this._setOption('textLeft', value);
    }
    get textTop() {
        return this._getOption('textTop');
    }
    set textTop(value) {
        this._setOption('textTop', value);
    }
    get textWidth() {
        return this._getOption('textWidth');
    }
    set textWidth(value) {
        this._setOption('textWidth', value);
    }
    get title() {
        return this._getOption('title');
    }
    set title(value) {
        this._setOption('title', value);
    }
    get toolboxTemplate() {
        return this._getOption('toolboxTemplate');
    }
    set toolboxTemplate(value) {
        this._setOption('toolboxTemplate', value);
    }
    get toolboxWidthToHeightRatio() {
        return this._getOption('toolboxWidthToHeightRatio');
    }
    set toolboxWidthToHeightRatio(value) {
        this._setOption('toolboxWidthToHeightRatio', value);
    }
    get type() {
        return this._getOption('type');
    }
    set type(value) {
        this._setOption('type', value);
    }
    get _optionPath() {
        return 'customShapes';
    }
    constructor(parentOptionHost, optionHost, renderer, document, templateHost, element) {
        super();
        this.renderer = renderer;
        this.document = document;
        this.element = element;
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
        templateHost.setHost(this);
    }
    setTemplate(template) {
        this.template = template;
    }
    ngAfterViewInit() {
        extractTemplate(this, this.element, this.renderer, this.document);
    }
    ngOnDestroy() {
        this._deleteRemovedOptions(this._fullOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiDiagramCustomShapeComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }, { token: i0.Renderer2 }, { token: DOCUMENT }, { token: i1.DxTemplateHost, host: true }, { token: i0.ElementRef }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxiDiagramCustomShapeComponent, isStandalone: true, selector: "dxi-diagram-custom-shape", inputs: { allowEditImage: "allowEditImage", allowEditText: "allowEditText", allowResize: "allowResize", backgroundImageHeight: "backgroundImageHeight", backgroundImageLeft: "backgroundImageLeft", backgroundImageToolboxUrl: "backgroundImageToolboxUrl", backgroundImageTop: "backgroundImageTop", backgroundImageUrl: "backgroundImageUrl", backgroundImageWidth: "backgroundImageWidth", baseType: "baseType", category: "category", connectionPoints: "connectionPoints", defaultHeight: "defaultHeight", defaultImageUrl: "defaultImageUrl", defaultText: "defaultText", defaultWidth: "defaultWidth", imageHeight: "imageHeight", imageLeft: "imageLeft", imageTop: "imageTop", imageWidth: "imageWidth", keepRatioOnAutoSize: "keepRatioOnAutoSize", maxHeight: "maxHeight", maxWidth: "maxWidth", minHeight: "minHeight", minWidth: "minWidth", template: "template", templateHeight: "templateHeight", templateLeft: "templateLeft", templateTop: "templateTop", templateWidth: "templateWidth", textHeight: "textHeight", textLeft: "textLeft", textTop: "textTop", textWidth: "textWidth", title: "title", toolboxTemplate: "toolboxTemplate", toolboxWidthToHeightRatio: "toolboxWidthToHeightRatio", type: "type" }, providers: [
            NestedOptionHost,
            DxTemplateHost,
            {
                provide: PROPERTY_TOKEN_customShapes,
                useExisting: DxiDiagramCustomShapeComponent,
            }
        ], queries: [{ propertyName: "_connectionPointsContentChildren", predicate: PROPERTY_TOKEN_connectionPoints }], usesInheritance: true, ngImport: i0, template: '<ng-content></ng-content>', isInline: true, styles: [":host{display:block}\n"], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiDiagramCustomShapeComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxi-diagram-custom-shape', template: '<ng-content></ng-content>', imports: [DxIntegrationModule], providers: [
                        NestedOptionHost,
                        DxTemplateHost,
                        {
                            provide: PROPERTY_TOKEN_customShapes,
                            useExisting: DxiDiagramCustomShapeComponent,
                        }
                    ], styles: [":host{display:block}\n"] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }, { type: i0.Renderer2 }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [DOCUMENT]
                }] }, { type: i1.DxTemplateHost, decorators: [{
                    type: Host
                }] }, { type: i0.ElementRef }], propDecorators: { _connectionPointsContentChildren: [{
                type: ContentChildren,
                args: [PROPERTY_TOKEN_connectionPoints]
            }], allowEditImage: [{
                type: Input
            }], allowEditText: [{
                type: Input
            }], allowResize: [{
                type: Input
            }], backgroundImageHeight: [{
                type: Input
            }], backgroundImageLeft: [{
                type: Input
            }], backgroundImageToolboxUrl: [{
                type: Input
            }], backgroundImageTop: [{
                type: Input
            }], backgroundImageUrl: [{
                type: Input
            }], backgroundImageWidth: [{
                type: Input
            }], baseType: [{
                type: Input
            }], category: [{
                type: Input
            }], connectionPoints: [{
                type: Input
            }], defaultHeight: [{
                type: Input
            }], defaultImageUrl: [{
                type: Input
            }], defaultText: [{
                type: Input
            }], defaultWidth: [{
                type: Input
            }], imageHeight: [{
                type: Input
            }], imageLeft: [{
                type: Input
            }], imageTop: [{
                type: Input
            }], imageWidth: [{
                type: Input
            }], keepRatioOnAutoSize: [{
                type: Input
            }], maxHeight: [{
                type: Input
            }], maxWidth: [{
                type: Input
            }], minHeight: [{
                type: Input
            }], minWidth: [{
                type: Input
            }], template: [{
                type: Input
            }], templateHeight: [{
                type: Input
            }], templateLeft: [{
                type: Input
            }], templateTop: [{
                type: Input
            }], templateWidth: [{
                type: Input
            }], textHeight: [{
                type: Input
            }], textLeft: [{
                type: Input
            }], textTop: [{
                type: Input
            }], textWidth: [{
                type: Input
            }], title: [{
                type: Input
            }], toolboxTemplate: [{
                type: Input
            }], toolboxWidthToHeightRatio: [{
                type: Input
            }], type: [{
                type: Input
            }] } });
class DxiDiagramCustomShapeModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiDiagramCustomShapeModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxiDiagramCustomShapeModule, imports: [DxiDiagramCustomShapeComponent], exports: [DxiDiagramCustomShapeComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiDiagramCustomShapeModule, imports: [DxiDiagramCustomShapeComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiDiagramCustomShapeModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxiDiagramCustomShapeComponent
                    ],
                    exports: [
                        DxiDiagramCustomShapeComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoDiagramDefaultItemPropertiesComponent extends NestedOption {
    get connectorLineEnd() {
        return this._getOption('connectorLineEnd');
    }
    set connectorLineEnd(value) {
        this._setOption('connectorLineEnd', value);
    }
    get connectorLineStart() {
        return this._getOption('connectorLineStart');
    }
    set connectorLineStart(value) {
        this._setOption('connectorLineStart', value);
    }
    get connectorLineType() {
        return this._getOption('connectorLineType');
    }
    set connectorLineType(value) {
        this._setOption('connectorLineType', value);
    }
    get shapeMaxHeight() {
        return this._getOption('shapeMaxHeight');
    }
    set shapeMaxHeight(value) {
        this._setOption('shapeMaxHeight', value);
    }
    get shapeMaxWidth() {
        return this._getOption('shapeMaxWidth');
    }
    set shapeMaxWidth(value) {
        this._setOption('shapeMaxWidth', value);
    }
    get shapeMinHeight() {
        return this._getOption('shapeMinHeight');
    }
    set shapeMinHeight(value) {
        this._setOption('shapeMinHeight', value);
    }
    get shapeMinWidth() {
        return this._getOption('shapeMinWidth');
    }
    set shapeMinWidth(value) {
        this._setOption('shapeMinWidth', value);
    }
    get style() {
        return this._getOption('style');
    }
    set style(value) {
        this._setOption('style', value);
    }
    get textStyle() {
        return this._getOption('textStyle');
    }
    set textStyle(value) {
        this._setOption('textStyle', value);
    }
    get _optionPath() {
        return 'defaultItemProperties';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDiagramDefaultItemPropertiesComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoDiagramDefaultItemPropertiesComponent, isStandalone: true, selector: "dxo-diagram-default-item-properties", inputs: { connectorLineEnd: "connectorLineEnd", connectorLineStart: "connectorLineStart", connectorLineType: "connectorLineType", shapeMaxHeight: "shapeMaxHeight", shapeMaxWidth: "shapeMaxWidth", shapeMinHeight: "shapeMinHeight", shapeMinWidth: "shapeMinWidth", style: "style", textStyle: "textStyle" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDiagramDefaultItemPropertiesComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-diagram-default-item-properties', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { connectorLineEnd: [{
                type: Input
            }], connectorLineStart: [{
                type: Input
            }], connectorLineType: [{
                type: Input
            }], shapeMaxHeight: [{
                type: Input
            }], shapeMaxWidth: [{
                type: Input
            }], shapeMinHeight: [{
                type: Input
            }], shapeMinWidth: [{
                type: Input
            }], style: [{
                type: Input
            }], textStyle: [{
                type: Input
            }] } });
class DxoDiagramDefaultItemPropertiesModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDiagramDefaultItemPropertiesModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoDiagramDefaultItemPropertiesModule, imports: [DxoDiagramDefaultItemPropertiesComponent], exports: [DxoDiagramDefaultItemPropertiesComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDiagramDefaultItemPropertiesModule, imports: [DxoDiagramDefaultItemPropertiesComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDiagramDefaultItemPropertiesModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoDiagramDefaultItemPropertiesComponent
                    ],
                    exports: [
                        DxoDiagramDefaultItemPropertiesComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoDiagramEdgesComponent extends NestedOption {
    get customDataExpr() {
        return this._getOption('customDataExpr');
    }
    set customDataExpr(value) {
        this._setOption('customDataExpr', value);
    }
    get dataSource() {
        return this._getOption('dataSource');
    }
    set dataSource(value) {
        this._setOption('dataSource', value);
    }
    get fromExpr() {
        return this._getOption('fromExpr');
    }
    set fromExpr(value) {
        this._setOption('fromExpr', value);
    }
    get fromLineEndExpr() {
        return this._getOption('fromLineEndExpr');
    }
    set fromLineEndExpr(value) {
        this._setOption('fromLineEndExpr', value);
    }
    get fromPointIndexExpr() {
        return this._getOption('fromPointIndexExpr');
    }
    set fromPointIndexExpr(value) {
        this._setOption('fromPointIndexExpr', value);
    }
    get keyExpr() {
        return this._getOption('keyExpr');
    }
    set keyExpr(value) {
        this._setOption('keyExpr', value);
    }
    get lineTypeExpr() {
        return this._getOption('lineTypeExpr');
    }
    set lineTypeExpr(value) {
        this._setOption('lineTypeExpr', value);
    }
    get lockedExpr() {
        return this._getOption('lockedExpr');
    }
    set lockedExpr(value) {
        this._setOption('lockedExpr', value);
    }
    get pointsExpr() {
        return this._getOption('pointsExpr');
    }
    set pointsExpr(value) {
        this._setOption('pointsExpr', value);
    }
    get styleExpr() {
        return this._getOption('styleExpr');
    }
    set styleExpr(value) {
        this._setOption('styleExpr', value);
    }
    get textExpr() {
        return this._getOption('textExpr');
    }
    set textExpr(value) {
        this._setOption('textExpr', value);
    }
    get textStyleExpr() {
        return this._getOption('textStyleExpr');
    }
    set textStyleExpr(value) {
        this._setOption('textStyleExpr', value);
    }
    get toExpr() {
        return this._getOption('toExpr');
    }
    set toExpr(value) {
        this._setOption('toExpr', value);
    }
    get toLineEndExpr() {
        return this._getOption('toLineEndExpr');
    }
    set toLineEndExpr(value) {
        this._setOption('toLineEndExpr', value);
    }
    get toPointIndexExpr() {
        return this._getOption('toPointIndexExpr');
    }
    set toPointIndexExpr(value) {
        this._setOption('toPointIndexExpr', value);
    }
    get zIndexExpr() {
        return this._getOption('zIndexExpr');
    }
    set zIndexExpr(value) {
        this._setOption('zIndexExpr', value);
    }
    get _optionPath() {
        return 'edges';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDiagramEdgesComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoDiagramEdgesComponent, isStandalone: true, selector: "dxo-diagram-edges", inputs: { customDataExpr: "customDataExpr", dataSource: "dataSource", fromExpr: "fromExpr", fromLineEndExpr: "fromLineEndExpr", fromPointIndexExpr: "fromPointIndexExpr", keyExpr: "keyExpr", lineTypeExpr: "lineTypeExpr", lockedExpr: "lockedExpr", pointsExpr: "pointsExpr", styleExpr: "styleExpr", textExpr: "textExpr", textStyleExpr: "textStyleExpr", toExpr: "toExpr", toLineEndExpr: "toLineEndExpr", toPointIndexExpr: "toPointIndexExpr", zIndexExpr: "zIndexExpr" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDiagramEdgesComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-diagram-edges', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { customDataExpr: [{
                type: Input
            }], dataSource: [{
                type: Input
            }], fromExpr: [{
                type: Input
            }], fromLineEndExpr: [{
                type: Input
            }], fromPointIndexExpr: [{
                type: Input
            }], keyExpr: [{
                type: Input
            }], lineTypeExpr: [{
                type: Input
            }], lockedExpr: [{
                type: Input
            }], pointsExpr: [{
                type: Input
            }], styleExpr: [{
                type: Input
            }], textExpr: [{
                type: Input
            }], textStyleExpr: [{
                type: Input
            }], toExpr: [{
                type: Input
            }], toLineEndExpr: [{
                type: Input
            }], toPointIndexExpr: [{
                type: Input
            }], zIndexExpr: [{
                type: Input
            }] } });
class DxoDiagramEdgesModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDiagramEdgesModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoDiagramEdgesModule, imports: [DxoDiagramEdgesComponent], exports: [DxoDiagramEdgesComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDiagramEdgesModule, imports: [DxoDiagramEdgesComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDiagramEdgesModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoDiagramEdgesComponent
                    ],
                    exports: [
                        DxoDiagramEdgesComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoDiagramEditingComponent extends NestedOption {
    get allowAddShape() {
        return this._getOption('allowAddShape');
    }
    set allowAddShape(value) {
        this._setOption('allowAddShape', value);
    }
    get allowChangeConnection() {
        return this._getOption('allowChangeConnection');
    }
    set allowChangeConnection(value) {
        this._setOption('allowChangeConnection', value);
    }
    get allowChangeConnectorPoints() {
        return this._getOption('allowChangeConnectorPoints');
    }
    set allowChangeConnectorPoints(value) {
        this._setOption('allowChangeConnectorPoints', value);
    }
    get allowChangeConnectorText() {
        return this._getOption('allowChangeConnectorText');
    }
    set allowChangeConnectorText(value) {
        this._setOption('allowChangeConnectorText', value);
    }
    get allowChangeShapeText() {
        return this._getOption('allowChangeShapeText');
    }
    set allowChangeShapeText(value) {
        this._setOption('allowChangeShapeText', value);
    }
    get allowDeleteConnector() {
        return this._getOption('allowDeleteConnector');
    }
    set allowDeleteConnector(value) {
        this._setOption('allowDeleteConnector', value);
    }
    get allowDeleteShape() {
        return this._getOption('allowDeleteShape');
    }
    set allowDeleteShape(value) {
        this._setOption('allowDeleteShape', value);
    }
    get allowMoveShape() {
        return this._getOption('allowMoveShape');
    }
    set allowMoveShape(value) {
        this._setOption('allowMoveShape', value);
    }
    get allowResizeShape() {
        return this._getOption('allowResizeShape');
    }
    set allowResizeShape(value) {
        this._setOption('allowResizeShape', value);
    }
    get _optionPath() {
        return 'editing';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDiagramEditingComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoDiagramEditingComponent, isStandalone: true, selector: "dxo-diagram-editing", inputs: { allowAddShape: "allowAddShape", allowChangeConnection: "allowChangeConnection", allowChangeConnectorPoints: "allowChangeConnectorPoints", allowChangeConnectorText: "allowChangeConnectorText", allowChangeShapeText: "allowChangeShapeText", allowDeleteConnector: "allowDeleteConnector", allowDeleteShape: "allowDeleteShape", allowMoveShape: "allowMoveShape", allowResizeShape: "allowResizeShape" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDiagramEditingComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-diagram-editing', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { allowAddShape: [{
                type: Input
            }], allowChangeConnection: [{
                type: Input
            }], allowChangeConnectorPoints: [{
                type: Input
            }], allowChangeConnectorText: [{
                type: Input
            }], allowChangeShapeText: [{
                type: Input
            }], allowDeleteConnector: [{
                type: Input
            }], allowDeleteShape: [{
                type: Input
            }], allowMoveShape: [{
                type: Input
            }], allowResizeShape: [{
                type: Input
            }] } });
class DxoDiagramEditingModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDiagramEditingModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoDiagramEditingModule, imports: [DxoDiagramEditingComponent], exports: [DxoDiagramEditingComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDiagramEditingModule, imports: [DxoDiagramEditingComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDiagramEditingModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoDiagramEditingComponent
                    ],
                    exports: [
                        DxoDiagramEditingComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoDiagramExportComponent extends NestedOption {
    get fileName() {
        return this._getOption('fileName');
    }
    set fileName(value) {
        this._setOption('fileName', value);
    }
    get _optionPath() {
        return 'export';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDiagramExportComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoDiagramExportComponent, isStandalone: true, selector: "dxo-diagram-export", inputs: { fileName: "fileName" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDiagramExportComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-diagram-export', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { fileName: [{
                type: Input
            }] } });
class DxoDiagramExportModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDiagramExportModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoDiagramExportModule, imports: [DxoDiagramExportComponent], exports: [DxoDiagramExportComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDiagramExportModule, imports: [DxoDiagramExportComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDiagramExportModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoDiagramExportComponent
                    ],
                    exports: [
                        DxoDiagramExportComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoDiagramGridSizeComponent extends NestedOption {
    get items() {
        return this._getOption('items');
    }
    set items(value) {
        this._setOption('items', value);
    }
    get value() {
        return this._getOption('value');
    }
    set value(value) {
        this._setOption('value', value);
    }
    get _optionPath() {
        return 'gridSize';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        this._createEventEmitters([
            { emit: 'valueChange' }
        ]);
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDiagramGridSizeComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoDiagramGridSizeComponent, isStandalone: true, selector: "dxo-diagram-grid-size", inputs: { items: "items", value: "value" }, outputs: { valueChange: "valueChange" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDiagramGridSizeComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-diagram-grid-size', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { items: [{
                type: Input
            }], value: [{
                type: Input
            }], valueChange: [{
                type: Output
            }] } });
class DxoDiagramGridSizeModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDiagramGridSizeModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoDiagramGridSizeModule, imports: [DxoDiagramGridSizeComponent], exports: [DxoDiagramGridSizeComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDiagramGridSizeModule, imports: [DxoDiagramGridSizeComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDiagramGridSizeModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoDiagramGridSizeComponent
                    ],
                    exports: [
                        DxoDiagramGridSizeComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxiDiagramGroupComponent extends CollectionNestedOption {
    set _commandsContentChildren(value) {
        this.setChildren('commands', value);
    }
    get commands() {
        return this._getOption('commands');
    }
    set commands(value) {
        this._setOption('commands', value);
    }
    get title() {
        return this._getOption('title');
    }
    set title(value) {
        this._setOption('title', value);
    }
    get category() {
        return this._getOption('category');
    }
    set category(value) {
        this._setOption('category', value);
    }
    get displayMode() {
        return this._getOption('displayMode');
    }
    set displayMode(value) {
        this._setOption('displayMode', value);
    }
    get expanded() {
        return this._getOption('expanded');
    }
    set expanded(value) {
        this._setOption('expanded', value);
    }
    get shapes() {
        return this._getOption('shapes');
    }
    set shapes(value) {
        this._setOption('shapes', value);
    }
    get _optionPath() {
        return 'groups';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnDestroy() {
        this._deleteRemovedOptions(this._fullOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiDiagramGroupComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxiDiagramGroupComponent, isStandalone: true, selector: "dxi-diagram-group", inputs: { commands: "commands", title: "title", category: "category", displayMode: "displayMode", expanded: "expanded", shapes: "shapes" }, providers: [
            NestedOptionHost,
            {
                provide: PROPERTY_TOKEN_groups,
                useExisting: DxiDiagramGroupComponent,
            }
        ], queries: [{ propertyName: "_commandsContentChildren", predicate: PROPERTY_TOKEN_commands }], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiDiagramGroupComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxi-diagram-group', template: '', imports: [DxIntegrationModule], providers: [
                        NestedOptionHost,
                        {
                            provide: PROPERTY_TOKEN_groups,
                            useExisting: DxiDiagramGroupComponent,
                        }
                    ] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { _commandsContentChildren: [{
                type: ContentChildren,
                args: [PROPERTY_TOKEN_commands]
            }], commands: [{
                type: Input
            }], title: [{
                type: Input
            }], category: [{
                type: Input
            }], displayMode: [{
                type: Input
            }], expanded: [{
                type: Input
            }], shapes: [{
                type: Input
            }] } });
class DxiDiagramGroupModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiDiagramGroupModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxiDiagramGroupModule, imports: [DxiDiagramGroupComponent], exports: [DxiDiagramGroupComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiDiagramGroupModule, imports: [DxiDiagramGroupComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiDiagramGroupModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxiDiagramGroupComponent
                    ],
                    exports: [
                        DxiDiagramGroupComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoDiagramHistoryToolbarComponent extends NestedOption {
    set _commandsContentChildren(value) {
        this.setChildren('commands', value);
    }
    get commands() {
        return this._getOption('commands');
    }
    set commands(value) {
        this._setOption('commands', value);
    }
    get visible() {
        return this._getOption('visible');
    }
    set visible(value) {
        this._setOption('visible', value);
    }
    get _optionPath() {
        return 'historyToolbar';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDiagramHistoryToolbarComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoDiagramHistoryToolbarComponent, isStandalone: true, selector: "dxo-diagram-history-toolbar", inputs: { commands: "commands", visible: "visible" }, providers: [NestedOptionHost], queries: [{ propertyName: "_commandsContentChildren", predicate: PROPERTY_TOKEN_commands }], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDiagramHistoryToolbarComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-diagram-history-toolbar', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { _commandsContentChildren: [{
                type: ContentChildren,
                args: [PROPERTY_TOKEN_commands]
            }], commands: [{
                type: Input
            }], visible: [{
                type: Input
            }] } });
class DxoDiagramHistoryToolbarModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDiagramHistoryToolbarModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoDiagramHistoryToolbarModule, imports: [DxoDiagramHistoryToolbarComponent], exports: [DxoDiagramHistoryToolbarComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDiagramHistoryToolbarModule, imports: [DxoDiagramHistoryToolbarComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDiagramHistoryToolbarModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoDiagramHistoryToolbarComponent
                    ],
                    exports: [
                        DxoDiagramHistoryToolbarComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxiDiagramItemComponent extends CollectionNestedOption {
    set _itemsContentChildren(value) {
        this.setChildren('items', value);
    }
    get icon() {
        return this._getOption('icon');
    }
    set icon(value) {
        this._setOption('icon', value);
    }
    get items() {
        return this._getOption('items');
    }
    set items(value) {
        this._setOption('items', value);
    }
    get location() {
        return this._getOption('location');
    }
    set location(value) {
        this._setOption('location', value);
    }
    get name() {
        return this._getOption('name');
    }
    set name(value) {
        this._setOption('name', value);
    }
    get text() {
        return this._getOption('text');
    }
    set text(value) {
        this._setOption('text', value);
    }
    get height() {
        return this._getOption('height');
    }
    set height(value) {
        this._setOption('height', value);
    }
    get width() {
        return this._getOption('width');
    }
    set width(value) {
        this._setOption('width', value);
    }
    get _optionPath() {
        return 'items';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnDestroy() {
        this._deleteRemovedOptions(this._fullOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiDiagramItemComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxiDiagramItemComponent, isStandalone: true, selector: "dxi-diagram-item", inputs: { icon: "icon", items: "items", location: "location", name: "name", text: "text", height: "height", width: "width" }, providers: [
            NestedOptionHost,
            {
                provide: PROPERTY_TOKEN_items,
                useExisting: DxiDiagramItemComponent,
            }
        ], queries: [{ propertyName: "_itemsContentChildren", predicate: PROPERTY_TOKEN_items }], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiDiagramItemComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxi-diagram-item', template: '', imports: [DxIntegrationModule], providers: [
                        NestedOptionHost,
                        {
                            provide: PROPERTY_TOKEN_items,
                            useExisting: DxiDiagramItemComponent,
                        }
                    ] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { _itemsContentChildren: [{
                type: ContentChildren,
                args: [PROPERTY_TOKEN_items]
            }], icon: [{
                type: Input
            }], items: [{
                type: Input
            }], location: [{
                type: Input
            }], name: [{
                type: Input
            }], text: [{
                type: Input
            }], height: [{
                type: Input
            }], width: [{
                type: Input
            }] } });
class DxiDiagramItemModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiDiagramItemModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxiDiagramItemModule, imports: [DxiDiagramItemComponent], exports: [DxiDiagramItemComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiDiagramItemModule, imports: [DxiDiagramItemComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiDiagramItemModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxiDiagramItemComponent
                    ],
                    exports: [
                        DxiDiagramItemComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoDiagramMainToolbarComponent extends NestedOption {
    set _commandsContentChildren(value) {
        this.setChildren('commands', value);
    }
    get commands() {
        return this._getOption('commands');
    }
    set commands(value) {
        this._setOption('commands', value);
    }
    get visible() {
        return this._getOption('visible');
    }
    set visible(value) {
        this._setOption('visible', value);
    }
    get _optionPath() {
        return 'mainToolbar';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDiagramMainToolbarComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoDiagramMainToolbarComponent, isStandalone: true, selector: "dxo-diagram-main-toolbar", inputs: { commands: "commands", visible: "visible" }, providers: [NestedOptionHost], queries: [{ propertyName: "_commandsContentChildren", predicate: PROPERTY_TOKEN_commands }], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDiagramMainToolbarComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-diagram-main-toolbar', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { _commandsContentChildren: [{
                type: ContentChildren,
                args: [PROPERTY_TOKEN_commands]
            }], commands: [{
                type: Input
            }], visible: [{
                type: Input
            }] } });
class DxoDiagramMainToolbarModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDiagramMainToolbarModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoDiagramMainToolbarModule, imports: [DxoDiagramMainToolbarComponent], exports: [DxoDiagramMainToolbarComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDiagramMainToolbarModule, imports: [DxoDiagramMainToolbarComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDiagramMainToolbarModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoDiagramMainToolbarComponent
                    ],
                    exports: [
                        DxoDiagramMainToolbarComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoDiagramNodesComponent extends NestedOption {
    get autoLayout() {
        return this._getOption('autoLayout');
    }
    set autoLayout(value) {
        this._setOption('autoLayout', value);
    }
    get autoSizeEnabled() {
        return this._getOption('autoSizeEnabled');
    }
    set autoSizeEnabled(value) {
        this._setOption('autoSizeEnabled', value);
    }
    get containerChildrenExpr() {
        return this._getOption('containerChildrenExpr');
    }
    set containerChildrenExpr(value) {
        this._setOption('containerChildrenExpr', value);
    }
    get containerKeyExpr() {
        return this._getOption('containerKeyExpr');
    }
    set containerKeyExpr(value) {
        this._setOption('containerKeyExpr', value);
    }
    get customDataExpr() {
        return this._getOption('customDataExpr');
    }
    set customDataExpr(value) {
        this._setOption('customDataExpr', value);
    }
    get dataSource() {
        return this._getOption('dataSource');
    }
    set dataSource(value) {
        this._setOption('dataSource', value);
    }
    get heightExpr() {
        return this._getOption('heightExpr');
    }
    set heightExpr(value) {
        this._setOption('heightExpr', value);
    }
    get imageUrlExpr() {
        return this._getOption('imageUrlExpr');
    }
    set imageUrlExpr(value) {
        this._setOption('imageUrlExpr', value);
    }
    get itemsExpr() {
        return this._getOption('itemsExpr');
    }
    set itemsExpr(value) {
        this._setOption('itemsExpr', value);
    }
    get keyExpr() {
        return this._getOption('keyExpr');
    }
    set keyExpr(value) {
        this._setOption('keyExpr', value);
    }
    get leftExpr() {
        return this._getOption('leftExpr');
    }
    set leftExpr(value) {
        this._setOption('leftExpr', value);
    }
    get lockedExpr() {
        return this._getOption('lockedExpr');
    }
    set lockedExpr(value) {
        this._setOption('lockedExpr', value);
    }
    get parentKeyExpr() {
        return this._getOption('parentKeyExpr');
    }
    set parentKeyExpr(value) {
        this._setOption('parentKeyExpr', value);
    }
    get styleExpr() {
        return this._getOption('styleExpr');
    }
    set styleExpr(value) {
        this._setOption('styleExpr', value);
    }
    get textExpr() {
        return this._getOption('textExpr');
    }
    set textExpr(value) {
        this._setOption('textExpr', value);
    }
    get textStyleExpr() {
        return this._getOption('textStyleExpr');
    }
    set textStyleExpr(value) {
        this._setOption('textStyleExpr', value);
    }
    get topExpr() {
        return this._getOption('topExpr');
    }
    set topExpr(value) {
        this._setOption('topExpr', value);
    }
    get typeExpr() {
        return this._getOption('typeExpr');
    }
    set typeExpr(value) {
        this._setOption('typeExpr', value);
    }
    get widthExpr() {
        return this._getOption('widthExpr');
    }
    set widthExpr(value) {
        this._setOption('widthExpr', value);
    }
    get zIndexExpr() {
        return this._getOption('zIndexExpr');
    }
    set zIndexExpr(value) {
        this._setOption('zIndexExpr', value);
    }
    get _optionPath() {
        return 'nodes';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDiagramNodesComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoDiagramNodesComponent, isStandalone: true, selector: "dxo-diagram-nodes", inputs: { autoLayout: "autoLayout", autoSizeEnabled: "autoSizeEnabled", containerChildrenExpr: "containerChildrenExpr", containerKeyExpr: "containerKeyExpr", customDataExpr: "customDataExpr", dataSource: "dataSource", heightExpr: "heightExpr", imageUrlExpr: "imageUrlExpr", itemsExpr: "itemsExpr", keyExpr: "keyExpr", leftExpr: "leftExpr", lockedExpr: "lockedExpr", parentKeyExpr: "parentKeyExpr", styleExpr: "styleExpr", textExpr: "textExpr", textStyleExpr: "textStyleExpr", topExpr: "topExpr", typeExpr: "typeExpr", widthExpr: "widthExpr", zIndexExpr: "zIndexExpr" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDiagramNodesComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-diagram-nodes', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { autoLayout: [{
                type: Input
            }], autoSizeEnabled: [{
                type: Input
            }], containerChildrenExpr: [{
                type: Input
            }], containerKeyExpr: [{
                type: Input
            }], customDataExpr: [{
                type: Input
            }], dataSource: [{
                type: Input
            }], heightExpr: [{
                type: Input
            }], imageUrlExpr: [{
                type: Input
            }], itemsExpr: [{
                type: Input
            }], keyExpr: [{
                type: Input
            }], leftExpr: [{
                type: Input
            }], lockedExpr: [{
                type: Input
            }], parentKeyExpr: [{
                type: Input
            }], styleExpr: [{
                type: Input
            }], textExpr: [{
                type: Input
            }], textStyleExpr: [{
                type: Input
            }], topExpr: [{
                type: Input
            }], typeExpr: [{
                type: Input
            }], widthExpr: [{
                type: Input
            }], zIndexExpr: [{
                type: Input
            }] } });
class DxoDiagramNodesModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDiagramNodesModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoDiagramNodesModule, imports: [DxoDiagramNodesComponent], exports: [DxoDiagramNodesComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDiagramNodesModule, imports: [DxoDiagramNodesComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDiagramNodesModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoDiagramNodesComponent
                    ],
                    exports: [
                        DxoDiagramNodesComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxiDiagramPageSizeItemComponent extends CollectionNestedOption {
    get height() {
        return this._getOption('height');
    }
    set height(value) {
        this._setOption('height', value);
    }
    get text() {
        return this._getOption('text');
    }
    set text(value) {
        this._setOption('text', value);
    }
    get width() {
        return this._getOption('width');
    }
    set width(value) {
        this._setOption('width', value);
    }
    get _optionPath() {
        return 'items';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnDestroy() {
        this._deleteRemovedOptions(this._fullOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiDiagramPageSizeItemComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxiDiagramPageSizeItemComponent, isStandalone: true, selector: "dxi-diagram-page-size-item", inputs: { height: "height", text: "text", width: "width" }, providers: [
            NestedOptionHost,
            {
                provide: PROPERTY_TOKEN_items,
                useExisting: DxiDiagramPageSizeItemComponent,
            }
        ], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiDiagramPageSizeItemComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxi-diagram-page-size-item', template: '', imports: [DxIntegrationModule], providers: [
                        NestedOptionHost,
                        {
                            provide: PROPERTY_TOKEN_items,
                            useExisting: DxiDiagramPageSizeItemComponent,
                        }
                    ] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { height: [{
                type: Input
            }], text: [{
                type: Input
            }], width: [{
                type: Input
            }] } });
class DxiDiagramPageSizeItemModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiDiagramPageSizeItemModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxiDiagramPageSizeItemModule, imports: [DxiDiagramPageSizeItemComponent], exports: [DxiDiagramPageSizeItemComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiDiagramPageSizeItemModule, imports: [DxiDiagramPageSizeItemComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiDiagramPageSizeItemModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxiDiagramPageSizeItemComponent
                    ],
                    exports: [
                        DxiDiagramPageSizeItemComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoDiagramPageSizeComponent extends NestedOption {
    set _itemsContentChildren(value) {
        this.setChildren('items', value);
    }
    get height() {
        return this._getOption('height');
    }
    set height(value) {
        this._setOption('height', value);
    }
    get items() {
        return this._getOption('items');
    }
    set items(value) {
        this._setOption('items', value);
    }
    get width() {
        return this._getOption('width');
    }
    set width(value) {
        this._setOption('width', value);
    }
    get _optionPath() {
        return 'pageSize';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        this._createEventEmitters([
            { emit: 'heightChange' },
            { emit: 'widthChange' }
        ]);
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDiagramPageSizeComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoDiagramPageSizeComponent, isStandalone: true, selector: "dxo-diagram-page-size", inputs: { height: "height", items: "items", width: "width" }, outputs: { heightChange: "heightChange", widthChange: "widthChange" }, providers: [NestedOptionHost], queries: [{ propertyName: "_itemsContentChildren", predicate: PROPERTY_TOKEN_items }], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDiagramPageSizeComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-diagram-page-size', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { _itemsContentChildren: [{
                type: ContentChildren,
                args: [PROPERTY_TOKEN_items]
            }], height: [{
                type: Input
            }], items: [{
                type: Input
            }], width: [{
                type: Input
            }], heightChange: [{
                type: Output
            }], widthChange: [{
                type: Output
            }] } });
class DxoDiagramPageSizeModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDiagramPageSizeModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoDiagramPageSizeModule, imports: [DxoDiagramPageSizeComponent], exports: [DxoDiagramPageSizeComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDiagramPageSizeModule, imports: [DxoDiagramPageSizeComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDiagramPageSizeModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoDiagramPageSizeComponent
                    ],
                    exports: [
                        DxoDiagramPageSizeComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoDiagramPropertiesPanelComponent extends NestedOption {
    set _tabsContentChildren(value) {
        this.setChildren('tabs', value);
    }
    get tabs() {
        return this._getOption('tabs');
    }
    set tabs(value) {
        this._setOption('tabs', value);
    }
    get visibility() {
        return this._getOption('visibility');
    }
    set visibility(value) {
        this._setOption('visibility', value);
    }
    get _optionPath() {
        return 'propertiesPanel';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDiagramPropertiesPanelComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoDiagramPropertiesPanelComponent, isStandalone: true, selector: "dxo-diagram-properties-panel", inputs: { tabs: "tabs", visibility: "visibility" }, providers: [NestedOptionHost], queries: [{ propertyName: "_tabsContentChildren", predicate: PROPERTY_TOKEN_tabs }], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDiagramPropertiesPanelComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-diagram-properties-panel', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { _tabsContentChildren: [{
                type: ContentChildren,
                args: [PROPERTY_TOKEN_tabs]
            }], tabs: [{
                type: Input
            }], visibility: [{
                type: Input
            }] } });
class DxoDiagramPropertiesPanelModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDiagramPropertiesPanelModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoDiagramPropertiesPanelModule, imports: [DxoDiagramPropertiesPanelComponent], exports: [DxoDiagramPropertiesPanelComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDiagramPropertiesPanelModule, imports: [DxoDiagramPropertiesPanelComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDiagramPropertiesPanelModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoDiagramPropertiesPanelComponent
                    ],
                    exports: [
                        DxoDiagramPropertiesPanelComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxiDiagramTabComponent extends CollectionNestedOption {
    set _commandsContentChildren(value) {
        this.setChildren('commands', value);
    }
    set _groupsContentChildren(value) {
        this.setChildren('groups', value);
    }
    get commands() {
        return this._getOption('commands');
    }
    set commands(value) {
        this._setOption('commands', value);
    }
    get groups() {
        return this._getOption('groups');
    }
    set groups(value) {
        this._setOption('groups', value);
    }
    get title() {
        return this._getOption('title');
    }
    set title(value) {
        this._setOption('title', value);
    }
    get _optionPath() {
        return 'tabs';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnDestroy() {
        this._deleteRemovedOptions(this._fullOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiDiagramTabComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxiDiagramTabComponent, isStandalone: true, selector: "dxi-diagram-tab", inputs: { commands: "commands", groups: "groups", title: "title" }, providers: [
            NestedOptionHost,
            {
                provide: PROPERTY_TOKEN_tabs,
                useExisting: DxiDiagramTabComponent,
            }
        ], queries: [{ propertyName: "_commandsContentChildren", predicate: PROPERTY_TOKEN_commands }, { propertyName: "_groupsContentChildren", predicate: PROPERTY_TOKEN_groups }], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiDiagramTabComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxi-diagram-tab', template: '', imports: [DxIntegrationModule], providers: [
                        NestedOptionHost,
                        {
                            provide: PROPERTY_TOKEN_tabs,
                            useExisting: DxiDiagramTabComponent,
                        }
                    ] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { _commandsContentChildren: [{
                type: ContentChildren,
                args: [PROPERTY_TOKEN_commands]
            }], _groupsContentChildren: [{
                type: ContentChildren,
                args: [PROPERTY_TOKEN_groups]
            }], commands: [{
                type: Input
            }], groups: [{
                type: Input
            }], title: [{
                type: Input
            }] } });
class DxiDiagramTabModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiDiagramTabModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxiDiagramTabModule, imports: [DxiDiagramTabComponent], exports: [DxiDiagramTabComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiDiagramTabModule, imports: [DxiDiagramTabComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiDiagramTabModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxiDiagramTabComponent
                    ],
                    exports: [
                        DxiDiagramTabComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxiDiagramTabGroupComponent extends CollectionNestedOption {
    set _commandsContentChildren(value) {
        this.setChildren('commands', value);
    }
    get commands() {
        return this._getOption('commands');
    }
    set commands(value) {
        this._setOption('commands', value);
    }
    get title() {
        return this._getOption('title');
    }
    set title(value) {
        this._setOption('title', value);
    }
    get _optionPath() {
        return 'groups';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnDestroy() {
        this._deleteRemovedOptions(this._fullOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiDiagramTabGroupComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxiDiagramTabGroupComponent, isStandalone: true, selector: "dxi-diagram-tab-group", inputs: { commands: "commands", title: "title" }, providers: [
            NestedOptionHost,
            {
                provide: PROPERTY_TOKEN_groups,
                useExisting: DxiDiagramTabGroupComponent,
            }
        ], queries: [{ propertyName: "_commandsContentChildren", predicate: PROPERTY_TOKEN_commands }], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiDiagramTabGroupComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxi-diagram-tab-group', template: '', imports: [DxIntegrationModule], providers: [
                        NestedOptionHost,
                        {
                            provide: PROPERTY_TOKEN_groups,
                            useExisting: DxiDiagramTabGroupComponent,
                        }
                    ] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { _commandsContentChildren: [{
                type: ContentChildren,
                args: [PROPERTY_TOKEN_commands]
            }], commands: [{
                type: Input
            }], title: [{
                type: Input
            }] } });
class DxiDiagramTabGroupModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiDiagramTabGroupModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxiDiagramTabGroupModule, imports: [DxiDiagramTabGroupComponent], exports: [DxiDiagramTabGroupComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiDiagramTabGroupModule, imports: [DxiDiagramTabGroupComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiDiagramTabGroupModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxiDiagramTabGroupComponent
                    ],
                    exports: [
                        DxiDiagramTabGroupComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxiDiagramToolboxGroupComponent extends CollectionNestedOption {
    get category() {
        return this._getOption('category');
    }
    set category(value) {
        this._setOption('category', value);
    }
    get displayMode() {
        return this._getOption('displayMode');
    }
    set displayMode(value) {
        this._setOption('displayMode', value);
    }
    get expanded() {
        return this._getOption('expanded');
    }
    set expanded(value) {
        this._setOption('expanded', value);
    }
    get shapes() {
        return this._getOption('shapes');
    }
    set shapes(value) {
        this._setOption('shapes', value);
    }
    get title() {
        return this._getOption('title');
    }
    set title(value) {
        this._setOption('title', value);
    }
    get _optionPath() {
        return 'groups';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnDestroy() {
        this._deleteRemovedOptions(this._fullOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiDiagramToolboxGroupComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxiDiagramToolboxGroupComponent, isStandalone: true, selector: "dxi-diagram-toolbox-group", inputs: { category: "category", displayMode: "displayMode", expanded: "expanded", shapes: "shapes", title: "title" }, providers: [
            NestedOptionHost,
            {
                provide: PROPERTY_TOKEN_groups,
                useExisting: DxiDiagramToolboxGroupComponent,
            }
        ], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiDiagramToolboxGroupComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxi-diagram-toolbox-group', template: '', imports: [DxIntegrationModule], providers: [
                        NestedOptionHost,
                        {
                            provide: PROPERTY_TOKEN_groups,
                            useExisting: DxiDiagramToolboxGroupComponent,
                        }
                    ] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { category: [{
                type: Input
            }], displayMode: [{
                type: Input
            }], expanded: [{
                type: Input
            }], shapes: [{
                type: Input
            }], title: [{
                type: Input
            }] } });
class DxiDiagramToolboxGroupModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiDiagramToolboxGroupModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxiDiagramToolboxGroupModule, imports: [DxiDiagramToolboxGroupComponent], exports: [DxiDiagramToolboxGroupComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiDiagramToolboxGroupModule, imports: [DxiDiagramToolboxGroupComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiDiagramToolboxGroupModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxiDiagramToolboxGroupComponent
                    ],
                    exports: [
                        DxiDiagramToolboxGroupComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoDiagramToolboxComponent extends NestedOption {
    set _groupsContentChildren(value) {
        this.setChildren('groups', value);
    }
    get groups() {
        return this._getOption('groups');
    }
    set groups(value) {
        this._setOption('groups', value);
    }
    get shapeIconsPerRow() {
        return this._getOption('shapeIconsPerRow');
    }
    set shapeIconsPerRow(value) {
        this._setOption('shapeIconsPerRow', value);
    }
    get showSearch() {
        return this._getOption('showSearch');
    }
    set showSearch(value) {
        this._setOption('showSearch', value);
    }
    get visibility() {
        return this._getOption('visibility');
    }
    set visibility(value) {
        this._setOption('visibility', value);
    }
    get width() {
        return this._getOption('width');
    }
    set width(value) {
        this._setOption('width', value);
    }
    get _optionPath() {
        return 'toolbox';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDiagramToolboxComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoDiagramToolboxComponent, isStandalone: true, selector: "dxo-diagram-toolbox", inputs: { groups: "groups", shapeIconsPerRow: "shapeIconsPerRow", showSearch: "showSearch", visibility: "visibility", width: "width" }, providers: [NestedOptionHost], queries: [{ propertyName: "_groupsContentChildren", predicate: PROPERTY_TOKEN_groups }], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDiagramToolboxComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-diagram-toolbox', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { _groupsContentChildren: [{
                type: ContentChildren,
                args: [PROPERTY_TOKEN_groups]
            }], groups: [{
                type: Input
            }], shapeIconsPerRow: [{
                type: Input
            }], showSearch: [{
                type: Input
            }], visibility: [{
                type: Input
            }], width: [{
                type: Input
            }] } });
class DxoDiagramToolboxModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDiagramToolboxModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoDiagramToolboxModule, imports: [DxoDiagramToolboxComponent], exports: [DxoDiagramToolboxComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDiagramToolboxModule, imports: [DxoDiagramToolboxComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDiagramToolboxModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoDiagramToolboxComponent
                    ],
                    exports: [
                        DxoDiagramToolboxComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoDiagramViewToolbarComponent extends NestedOption {
    set _commandsContentChildren(value) {
        this.setChildren('commands', value);
    }
    get commands() {
        return this._getOption('commands');
    }
    set commands(value) {
        this._setOption('commands', value);
    }
    get visible() {
        return this._getOption('visible');
    }
    set visible(value) {
        this._setOption('visible', value);
    }
    get _optionPath() {
        return 'viewToolbar';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDiagramViewToolbarComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoDiagramViewToolbarComponent, isStandalone: true, selector: "dxo-diagram-view-toolbar", inputs: { commands: "commands", visible: "visible" }, providers: [NestedOptionHost], queries: [{ propertyName: "_commandsContentChildren", predicate: PROPERTY_TOKEN_commands }], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDiagramViewToolbarComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-diagram-view-toolbar', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { _commandsContentChildren: [{
                type: ContentChildren,
                args: [PROPERTY_TOKEN_commands]
            }], commands: [{
                type: Input
            }], visible: [{
                type: Input
            }] } });
class DxoDiagramViewToolbarModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDiagramViewToolbarModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoDiagramViewToolbarModule, imports: [DxoDiagramViewToolbarComponent], exports: [DxoDiagramViewToolbarComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDiagramViewToolbarModule, imports: [DxoDiagramViewToolbarComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDiagramViewToolbarModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoDiagramViewToolbarComponent
                    ],
                    exports: [
                        DxoDiagramViewToolbarComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoDiagramZoomLevelComponent extends NestedOption {
    get items() {
        return this._getOption('items');
    }
    set items(value) {
        this._setOption('items', value);
    }
    get value() {
        return this._getOption('value');
    }
    set value(value) {
        this._setOption('value', value);
    }
    get _optionPath() {
        return 'zoomLevel';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        this._createEventEmitters([
            { emit: 'valueChange' }
        ]);
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDiagramZoomLevelComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoDiagramZoomLevelComponent, isStandalone: true, selector: "dxo-diagram-zoom-level", inputs: { items: "items", value: "value" }, outputs: { valueChange: "valueChange" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDiagramZoomLevelComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-diagram-zoom-level', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { items: [{
                type: Input
            }], value: [{
                type: Input
            }], valueChange: [{
                type: Output
            }] } });
class DxoDiagramZoomLevelModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDiagramZoomLevelModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoDiagramZoomLevelModule, imports: [DxoDiagramZoomLevelComponent], exports: [DxoDiagramZoomLevelComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDiagramZoomLevelModule, imports: [DxoDiagramZoomLevelComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoDiagramZoomLevelModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoDiagramZoomLevelComponent
                    ],
                    exports: [
                        DxoDiagramZoomLevelComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

/**
 * Generated bundle index. Do not edit.
 */

export { DxiDiagramCommandComponent, DxiDiagramCommandItemComponent, DxiDiagramCommandItemModule, DxiDiagramCommandModule, DxiDiagramConnectionPointComponent, DxiDiagramConnectionPointModule, DxiDiagramCustomShapeComponent, DxiDiagramCustomShapeModule, DxiDiagramGroupComponent, DxiDiagramGroupModule, DxiDiagramItemComponent, DxiDiagramItemModule, DxiDiagramPageSizeItemComponent, DxiDiagramPageSizeItemModule, DxiDiagramTabComponent, DxiDiagramTabGroupComponent, DxiDiagramTabGroupModule, DxiDiagramTabModule, DxiDiagramToolboxGroupComponent, DxiDiagramToolboxGroupModule, DxoDiagramAutoLayoutComponent, DxoDiagramAutoLayoutModule, DxoDiagramContextMenuComponent, DxoDiagramContextMenuModule, DxoDiagramContextToolboxComponent, DxoDiagramContextToolboxModule, DxoDiagramDefaultItemPropertiesComponent, DxoDiagramDefaultItemPropertiesModule, DxoDiagramEdgesComponent, DxoDiagramEdgesModule, DxoDiagramEditingComponent, DxoDiagramEditingModule, DxoDiagramExportComponent, DxoDiagramExportModule, DxoDiagramGridSizeComponent, DxoDiagramGridSizeModule, DxoDiagramHistoryToolbarComponent, DxoDiagramHistoryToolbarModule, DxoDiagramMainToolbarComponent, DxoDiagramMainToolbarModule, DxoDiagramNodesComponent, DxoDiagramNodesModule, DxoDiagramPageSizeComponent, DxoDiagramPageSizeModule, DxoDiagramPropertiesPanelComponent, DxoDiagramPropertiesPanelModule, DxoDiagramToolboxComponent, DxoDiagramToolboxModule, DxoDiagramViewToolbarComponent, DxoDiagramViewToolbarModule, DxoDiagramZoomLevelComponent, DxoDiagramZoomLevelModule };
//# sourceMappingURL=devextreme-angular-ui-diagram-nested.mjs.map
