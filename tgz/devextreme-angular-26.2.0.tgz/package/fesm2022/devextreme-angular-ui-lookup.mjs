import * as i0 from '@angular/core';
import { forwardRef, PLATFORM_ID, HostListener, Output, Input, ContentChildren, Inject, Component, NgModule } from '@angular/core';
import DxLookup from 'devextreme/ui/lookup';
import { NG_VALUE_ACCESSOR } from '@angular/forms';
import * as i1 from 'devextreme-angular/core';
import { DxComponent, DxIntegrationModule, DxTemplateHost, WatcherHelper, NestedOptionHost, IterableDifferHelper, DxTemplateModule } from 'devextreme-angular/core';
import { DxoDropDownOptionsModule, DxoAnimationModule, DxoHideModule, DxoFromModule, DxoPositionModule, DxoAtModule, DxoBoundaryOffsetModule, DxoCollisionModule, DxoMyModule, DxoOffsetModule, DxoToModule, DxoShowModule, DxoHideEventModule, DxoShowEventModule, DxiItemModule } from 'devextreme-angular/ui/nested';
import { DxoLookupAnimationModule, DxoLookupAtModule, DxoLookupBoundaryOffsetModule, DxoLookupCollisionModule, DxoLookupDropDownOptionsModule, DxoLookupFromModule, DxoLookupHideModule, DxoLookupHideEventModule, DxiLookupItemModule, DxoLookupMyModule, DxoLookupOffsetModule, DxoLookupPositionModule, DxoLookupShowModule, DxoLookupShowEventModule, DxoLookupToModule, DxiLookupToolbarItemModule } from 'devextreme-angular/ui/lookup/nested';
export * from 'devextreme-angular/ui/lookup/nested';
import { PROPERTY_TOKEN_items, PROPERTY_TOKEN_toolbarItems } from 'devextreme-angular/core/tokens';

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
const CUSTOM_VALUE_ACCESSOR_PROVIDER = {
    provide: NG_VALUE_ACCESSOR,
    useExisting: forwardRef(() => DxLookupComponent),
    multi: true
};
/**
 * [descr:dxLookup]

 */
class DxLookupComponent extends DxComponent {
    set _itemsContentChildren(value) {
        this.setChildren('items', value);
    }
    set _toolbarItemsContentChildren(value) {
        this.setChildren('toolbarItems', value);
    }
    /**
     * [descr:WidgetOptions.accessKey]
    
     */
    get accessKey() {
        return this._getOption('accessKey');
    }
    set accessKey(value) {
        this._setOption('accessKey', value);
    }
    /**
     * [descr:dxDropDownEditorOptions.activeStateEnabled]
    
     */
    get activeStateEnabled() {
        return this._getOption('activeStateEnabled');
    }
    set activeStateEnabled(value) {
        this._setOption('activeStateEnabled', value);
    }
    /**
     * [descr:dxLookupOptions.applyButtonText]
    
     */
    get applyButtonText() {
        return this._getOption('applyButtonText');
    }
    set applyButtonText(value) {
        this._setOption('applyButtonText', value);
    }
    /**
     * [descr:dxLookupOptions.applyValueMode]
    
     */
    get applyValueMode() {
        return this._getOption('applyValueMode');
    }
    set applyValueMode(value) {
        this._setOption('applyValueMode', value);
    }
    /**
     * [descr:dxLookupOptions.cancelButtonText]
    
     */
    get cancelButtonText() {
        return this._getOption('cancelButtonText');
    }
    set cancelButtonText(value) {
        this._setOption('cancelButtonText', value);
    }
    /**
     * [descr:dxLookupOptions.cleanSearchOnOpening]
    
     */
    get cleanSearchOnOpening() {
        return this._getOption('cleanSearchOnOpening');
    }
    set cleanSearchOnOpening(value) {
        this._setOption('cleanSearchOnOpening', value);
    }
    /**
     * [descr:dxLookupOptions.clearButtonText]
    
     */
    get clearButtonText() {
        return this._getOption('clearButtonText');
    }
    set clearButtonText(value) {
        this._setOption('clearButtonText', value);
    }
    /**
     * [descr:DataExpressionMixinOptions.dataSource]
    
     */
    get dataSource() {
        return this._getOption('dataSource');
    }
    set dataSource(value) {
        this._setOption('dataSource', value);
    }
    /**
     * [descr:dxDropDownEditorOptions.deferRendering]
    
     */
    get deferRendering() {
        return this._getOption('deferRendering');
    }
    set deferRendering(value) {
        this._setOption('deferRendering', value);
    }
    /**
     * [descr:WidgetOptions.disabled]
    
     */
    get disabled() {
        return this._getOption('disabled');
    }
    set disabled(value) {
        this._setOption('disabled', value);
    }
    /**
     * [descr:DataExpressionMixinOptions.displayExpr]
    
     */
    get displayExpr() {
        return this._getOption('displayExpr');
    }
    set displayExpr(value) {
        this._setOption('displayExpr', value);
    }
    /**
     * [descr:dxDropDownListOptions.displayValue]
    
     */
    get displayValue() {
        return this._getOption('displayValue');
    }
    set displayValue(value) {
        this._setOption('displayValue', value);
    }
    /**
     * [descr:dxLookupOptions.dropDownCentered]
    
     */
    get dropDownCentered() {
        return this._getOption('dropDownCentered');
    }
    set dropDownCentered(value) {
        this._setOption('dropDownCentered', value);
    }
    /**
     * [descr:dxLookupOptions.dropDownOptions]
    
     */
    get dropDownOptions() {
        return this._getOption('dropDownOptions');
    }
    set dropDownOptions(value) {
        this._setOption('dropDownOptions', value);
    }
    /**
     * [descr:DOMComponentOptions.elementAttr]
    
     */
    get elementAttr() {
        return this._getOption('elementAttr');
    }
    set elementAttr(value) {
        this._setOption('elementAttr', value);
    }
    /**
     * [descr:dxLookupOptions.fieldTemplate]
    
     */
    get fieldTemplate() {
        return this._getOption('fieldTemplate');
    }
    set fieldTemplate(value) {
        this._setOption('fieldTemplate', value);
    }
    /**
     * [descr:dxLookupOptions.focusStateEnabled]
    
     */
    get focusStateEnabled() {
        return this._getOption('focusStateEnabled');
    }
    set focusStateEnabled(value) {
        this._setOption('focusStateEnabled', value);
    }
    /**
     * [descr:dxLookupOptions.grouped]
    
     */
    get grouped() {
        return this._getOption('grouped');
    }
    set grouped(value) {
        this._setOption('grouped', value);
    }
    /**
     * [descr:dxLookupOptions.groupTemplate]
    
     */
    get groupTemplate() {
        return this._getOption('groupTemplate');
    }
    set groupTemplate(value) {
        this._setOption('groupTemplate', value);
    }
    /**
     * [descr:DOMComponentOptions.height]
    
     */
    get height() {
        return this._getOption('height');
    }
    set height(value) {
        this._setOption('height', value);
    }
    /**
     * [descr:WidgetOptions.hint]
    
     */
    get hint() {
        return this._getOption('hint');
    }
    set hint(value) {
        this._setOption('hint', value);
    }
    /**
     * [descr:dxTextEditorOptions.hoverStateEnabled]
    
     */
    get hoverStateEnabled() {
        return this._getOption('hoverStateEnabled');
    }
    set hoverStateEnabled(value) {
        this._setOption('hoverStateEnabled', value);
    }
    /**
     * [descr:dxTextEditorOptions.inputAttr]
    
     */
    get inputAttr() {
        return this._getOption('inputAttr');
    }
    set inputAttr(value) {
        this._setOption('inputAttr', value);
    }
    /**
     * [descr:EditorOptions.isDirty]
    
     */
    get isDirty() {
        return this._getOption('isDirty');
    }
    set isDirty(value) {
        this._setOption('isDirty', value);
    }
    /**
     * [descr:EditorOptions.isValid]
    
     */
    get isValid() {
        return this._getOption('isValid');
    }
    set isValid(value) {
        this._setOption('isValid', value);
    }
    /**
     * [descr:DataExpressionMixinOptions.items]
    
     */
    get items() {
        return this._getOption('items');
    }
    set items(value) {
        this._setOption('items', value);
    }
    /**
     * [descr:DataExpressionMixinOptions.itemTemplate]
    
     */
    get itemTemplate() {
        return this._getOption('itemTemplate');
    }
    set itemTemplate(value) {
        this._setOption('itemTemplate', value);
    }
    /**
     * [descr:dxTextEditorOptions.label]
    
     */
    get label() {
        return this._getOption('label');
    }
    set label(value) {
        this._setOption('label', value);
    }
    /**
     * [descr:dxTextEditorOptions.labelMode]
    
     */
    get labelMode() {
        return this._getOption('labelMode');
    }
    set labelMode(value) {
        this._setOption('labelMode', value);
    }
    /**
     * [descr:dxDropDownListOptions.minSearchLength]
    
     */
    get minSearchLength() {
        return this._getOption('minSearchLength');
    }
    set minSearchLength(value) {
        this._setOption('minSearchLength', value);
    }
    /**
     * [descr:dxTextEditorOptions.name]
    
     */
    get name() {
        return this._getOption('name');
    }
    set name(value) {
        this._setOption('name', value);
    }
    /**
     * [descr:dxLookupOptions.nextButtonText]
    
     */
    get nextButtonText() {
        return this._getOption('nextButtonText');
    }
    set nextButtonText(value) {
        this._setOption('nextButtonText', value);
    }
    /**
     * [descr:dxDropDownListOptions.noDataText]
    
     */
    get noDataText() {
        return this._getOption('noDataText');
    }
    set noDataText(value) {
        this._setOption('noDataText', value);
    }
    /**
     * [descr:dxDropDownEditorOptions.opened]
    
     */
    get opened() {
        return this._getOption('opened');
    }
    set opened(value) {
        this._setOption('opened', value);
    }
    /**
     * [descr:dxLookupOptions.pageLoadingText]
    
     */
    get pageLoadingText() {
        return this._getOption('pageLoadingText');
    }
    set pageLoadingText(value) {
        this._setOption('pageLoadingText', value);
    }
    /**
     * [descr:dxLookupOptions.pageLoadMode]
    
     */
    get pageLoadMode() {
        return this._getOption('pageLoadMode');
    }
    set pageLoadMode(value) {
        this._setOption('pageLoadMode', value);
    }
    /**
     * [descr:dxLookupOptions.placeholder]
    
     */
    get placeholder() {
        return this._getOption('placeholder');
    }
    set placeholder(value) {
        this._setOption('placeholder', value);
    }
    /**
     * [descr:dxLookupOptions.pulledDownText]
    
     */
    get pulledDownText() {
        return this._getOption('pulledDownText');
    }
    set pulledDownText(value) {
        this._setOption('pulledDownText', value);
    }
    /**
     * [descr:dxLookupOptions.pullingDownText]
    
     */
    get pullingDownText() {
        return this._getOption('pullingDownText');
    }
    set pullingDownText(value) {
        this._setOption('pullingDownText', value);
    }
    /**
     * [descr:dxLookupOptions.pullRefreshEnabled]
    
     */
    get pullRefreshEnabled() {
        return this._getOption('pullRefreshEnabled');
    }
    set pullRefreshEnabled(value) {
        this._setOption('pullRefreshEnabled', value);
    }
    /**
     * [descr:dxLookupOptions.refreshingText]
    
     */
    get refreshingText() {
        return this._getOption('refreshingText');
    }
    set refreshingText(value) {
        this._setOption('refreshingText', value);
    }
    /**
     * [descr:DOMComponentOptions.rtlEnabled]
    
     */
    get rtlEnabled() {
        return this._getOption('rtlEnabled');
    }
    set rtlEnabled(value) {
        this._setOption('rtlEnabled', value);
    }
    /**
     * [descr:dxLookupOptions.searchEnabled]
    
     */
    get searchEnabled() {
        return this._getOption('searchEnabled');
    }
    set searchEnabled(value) {
        this._setOption('searchEnabled', value);
    }
    /**
     * [descr:dxDropDownListOptions.searchExpr]
    
     */
    get searchExpr() {
        return this._getOption('searchExpr');
    }
    set searchExpr(value) {
        this._setOption('searchExpr', value);
    }
    /**
     * [descr:dxDropDownListOptions.searchMode]
    
     */
    get searchMode() {
        return this._getOption('searchMode');
    }
    set searchMode(value) {
        this._setOption('searchMode', value);
    }
    /**
     * [descr:dxLookupOptions.searchPlaceholder]
    
     */
    get searchPlaceholder() {
        return this._getOption('searchPlaceholder');
    }
    set searchPlaceholder(value) {
        this._setOption('searchPlaceholder', value);
    }
    /**
     * [descr:dxLookupOptions.searchStartEvent]
    
     */
    get searchStartEvent() {
        return this._getOption('searchStartEvent');
    }
    set searchStartEvent(value) {
        this._setOption('searchStartEvent', value);
    }
    /**
     * [descr:dxDropDownListOptions.searchTimeout]
    
     */
    get searchTimeout() {
        return this._getOption('searchTimeout');
    }
    set searchTimeout(value) {
        this._setOption('searchTimeout', value);
    }
    /**
     * [descr:dxDropDownListOptions.selectedItem]
    
     */
    get selectedItem() {
        return this._getOption('selectedItem');
    }
    set selectedItem(value) {
        this._setOption('selectedItem', value);
    }
    /**
     * [descr:dxLookupOptions.showCancelButton]
    
     */
    get showCancelButton() {
        return this._getOption('showCancelButton');
    }
    set showCancelButton(value) {
        this._setOption('showCancelButton', value);
    }
    /**
     * [descr:dxLookupOptions.showClearButton]
    
     */
    get showClearButton() {
        return this._getOption('showClearButton');
    }
    set showClearButton(value) {
        this._setOption('showClearButton', value);
    }
    /**
     * [descr:dxDropDownListOptions.showDataBeforeSearch]
    
     */
    get showDataBeforeSearch() {
        return this._getOption('showDataBeforeSearch');
    }
    set showDataBeforeSearch(value) {
        this._setOption('showDataBeforeSearch', value);
    }
    /**
     * [descr:dxTextEditorOptions.stylingMode]
    
     */
    get stylingMode() {
        return this._getOption('stylingMode');
    }
    set stylingMode(value) {
        this._setOption('stylingMode', value);
    }
    /**
     * [descr:WidgetOptions.tabIndex]
    
     */
    get tabIndex() {
        return this._getOption('tabIndex');
    }
    set tabIndex(value) {
        this._setOption('tabIndex', value);
    }
    /**
     * [descr:dxTextEditorOptions.text]
    
     */
    get text() {
        return this._getOption('text');
    }
    set text(value) {
        this._setOption('text', value);
    }
    /**
     * [descr:dxDropDownListOptions.useItemTextAsTitle]
    
     */
    get useItemTextAsTitle() {
        return this._getOption('useItemTextAsTitle');
    }
    set useItemTextAsTitle(value) {
        this._setOption('useItemTextAsTitle', value);
    }
    /**
     * [descr:dxLookupOptions.useNativeScrolling]
    
     */
    get useNativeScrolling() {
        return this._getOption('useNativeScrolling');
    }
    set useNativeScrolling(value) {
        this._setOption('useNativeScrolling', value);
    }
    /**
     * [descr:dxLookupOptions.usePopover]
    
     */
    get usePopover() {
        return this._getOption('usePopover');
    }
    set usePopover(value) {
        this._setOption('usePopover', value);
    }
    /**
     * [descr:EditorOptions.validationError]
    
     */
    get validationError() {
        return this._getOption('validationError');
    }
    set validationError(value) {
        this._setOption('validationError', value);
    }
    /**
     * [descr:EditorOptions.validationErrors]
    
     */
    get validationErrors() {
        return this._getOption('validationErrors');
    }
    set validationErrors(value) {
        this._setOption('validationErrors', value);
    }
    /**
     * [descr:EditorOptions.validationMessageMode]
    
     */
    get validationMessageMode() {
        return this._getOption('validationMessageMode');
    }
    set validationMessageMode(value) {
        this._setOption('validationMessageMode', value);
    }
    /**
     * [descr:dxDropDownEditorOptions.validationMessagePosition]
    
     */
    get validationMessagePosition() {
        return this._getOption('validationMessagePosition');
    }
    set validationMessagePosition(value) {
        this._setOption('validationMessagePosition', value);
    }
    /**
     * [descr:EditorOptions.validationStatus]
    
     */
    get validationStatus() {
        return this._getOption('validationStatus');
    }
    set validationStatus(value) {
        this._setOption('validationStatus', value);
    }
    /**
     * [descr:dxDropDownListOptions.value]
    
     */
    get value() {
        return this._getOption('value');
    }
    set value(value) {
        this._setOption('value', value);
    }
    /**
     * [descr:dxDropDownListOptions.valueChangeEvent]
    
     */
    get valueChangeEvent() {
        return this._getOption('valueChangeEvent');
    }
    set valueChangeEvent(value) {
        this._setOption('valueChangeEvent', value);
    }
    /**
     * [descr:DataExpressionMixinOptions.valueExpr]
    
     */
    get valueExpr() {
        return this._getOption('valueExpr');
    }
    set valueExpr(value) {
        this._setOption('valueExpr', value);
    }
    /**
     * [descr:WidgetOptions.visible]
    
     */
    get visible() {
        return this._getOption('visible');
    }
    set visible(value) {
        this._setOption('visible', value);
    }
    /**
     * [descr:DOMComponentOptions.width]
    
     */
    get width() {
        return this._getOption('width');
    }
    set width(value) {
        this._setOption('width', value);
    }
    /**
     * [descr:dxDropDownListOptions.wrapItemText]
    
     */
    get wrapItemText() {
        return this._getOption('wrapItemText');
    }
    set wrapItemText(value) {
        this._setOption('wrapItemText', value);
    }
    change(_) { }
    constructor(elementRef, ngZone, templateHost, _watcherHelper, _idh, optionHost, transferState, platformId) {
        super(elementRef, ngZone, templateHost, _watcherHelper, transferState, platformId);
        this._watcherHelper = _watcherHelper;
        this._idh = _idh;
        this.instance = null;
        this.touched = (_) => { };
        this._createEventEmitters([
            { subscribe: 'closed', emit: 'onClosed' },
            { subscribe: 'contentReady', emit: 'onContentReady' },
            { subscribe: 'disposing', emit: 'onDisposing' },
            { subscribe: 'initialized', emit: 'onInitialized' },
            { subscribe: 'itemClick', emit: 'onItemClick' },
            { subscribe: 'opened', emit: 'onOpened' },
            { subscribe: 'optionChanged', emit: 'onOptionChanged' },
            { subscribe: 'pageLoading', emit: 'onPageLoading' },
            { subscribe: 'pullRefresh', emit: 'onPullRefresh' },
            { subscribe: 'scroll', emit: 'onScroll' },
            { subscribe: 'selectionChanged', emit: 'onSelectionChanged' },
            { subscribe: 'valueChanged', emit: 'onValueChanged' },
            { emit: 'accessKeyChange' },
            { emit: 'activeStateEnabledChange' },
            { emit: 'applyButtonTextChange' },
            { emit: 'applyValueModeChange' },
            { emit: 'cancelButtonTextChange' },
            { emit: 'cleanSearchOnOpeningChange' },
            { emit: 'clearButtonTextChange' },
            { emit: 'dataSourceChange' },
            { emit: 'deferRenderingChange' },
            { emit: 'disabledChange' },
            { emit: 'displayExprChange' },
            { emit: 'displayValueChange' },
            { emit: 'dropDownCenteredChange' },
            { emit: 'dropDownOptionsChange' },
            { emit: 'elementAttrChange' },
            { emit: 'fieldTemplateChange' },
            { emit: 'focusStateEnabledChange' },
            { emit: 'groupedChange' },
            { emit: 'groupTemplateChange' },
            { emit: 'heightChange' },
            { emit: 'hintChange' },
            { emit: 'hoverStateEnabledChange' },
            { emit: 'inputAttrChange' },
            { emit: 'isDirtyChange' },
            { emit: 'isValidChange' },
            { emit: 'itemsChange' },
            { emit: 'itemTemplateChange' },
            { emit: 'labelChange' },
            { emit: 'labelModeChange' },
            { emit: 'minSearchLengthChange' },
            { emit: 'nameChange' },
            { emit: 'nextButtonTextChange' },
            { emit: 'noDataTextChange' },
            { emit: 'openedChange' },
            { emit: 'pageLoadingTextChange' },
            { emit: 'pageLoadModeChange' },
            { emit: 'placeholderChange' },
            { emit: 'pulledDownTextChange' },
            { emit: 'pullingDownTextChange' },
            { emit: 'pullRefreshEnabledChange' },
            { emit: 'refreshingTextChange' },
            { emit: 'rtlEnabledChange' },
            { emit: 'searchEnabledChange' },
            { emit: 'searchExprChange' },
            { emit: 'searchModeChange' },
            { emit: 'searchPlaceholderChange' },
            { emit: 'searchStartEventChange' },
            { emit: 'searchTimeoutChange' },
            { emit: 'selectedItemChange' },
            { emit: 'showCancelButtonChange' },
            { emit: 'showClearButtonChange' },
            { emit: 'showDataBeforeSearchChange' },
            { emit: 'stylingModeChange' },
            { emit: 'tabIndexChange' },
            { emit: 'textChange' },
            { emit: 'useItemTextAsTitleChange' },
            { emit: 'useNativeScrollingChange' },
            { emit: 'usePopoverChange' },
            { emit: 'validationErrorChange' },
            { emit: 'validationErrorsChange' },
            { emit: 'validationMessageModeChange' },
            { emit: 'validationMessagePositionChange' },
            { emit: 'validationStatusChange' },
            { emit: 'valueChange' },
            { emit: 'valueChangeEventChange' },
            { emit: 'valueExprChange' },
            { emit: 'visibleChange' },
            { emit: 'widthChange' },
            { emit: 'wrapItemTextChange' },
            { emit: 'onBlur' }
        ]);
        this._idh.setHost(this);
        optionHost.setHost(this);
    }
    _createInstance(element, options) {
        return new DxLookup(element, options);
    }
    writeValue(value) {
        this.eventHelper.lockedValueChangeEvent = true;
        this.value = value;
        this.eventHelper.lockedValueChangeEvent = false;
    }
    setDisabledState(isDisabled) {
        this.disabled = isDisabled;
    }
    registerOnChange(fn) { this.change = fn; }
    registerOnTouched(fn) { this.touched = fn; }
    _createWidget(element) {
        super._createWidget(element);
        this.instance.on('focusOut', (e) => {
            this.eventHelper.fireNgEvent('onBlur', [e]);
        });
    }
    ngOnDestroy() {
        this._destroyWidget();
    }
    ngOnChanges(changes) {
        super.ngOnChanges(changes);
        this.setupChanges('dataSource', changes);
        this.setupChanges('items', changes);
        this.setupChanges('searchExpr', changes);
        this.setupChanges('validationErrors', changes);
    }
    setupChanges(prop, changes) {
        if (!(prop in this._optionsToUpdate)) {
            this._idh.setup(prop, changes);
        }
    }
    ngDoCheck() {
        this._idh.doCheck('dataSource');
        this._idh.doCheck('items');
        this._idh.doCheck('searchExpr');
        this._idh.doCheck('validationErrors');
        this._watcherHelper.checkWatchers();
        super.ngDoCheck();
        super.clearChangedOptions();
    }
    _setOption(name, value) {
        let isSetup = this._idh.setupSingle(name, value);
        let isChanged = this._idh.getChanges(name, value) !== null;
        if (isSetup || isChanged) {
            super._setOption(name, value);
        }
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxLookupComponent, deps: [{ token: i0.ElementRef }, { token: i0.NgZone }, { token: i1.DxTemplateHost }, { token: i1.WatcherHelper }, { token: i1.IterableDifferHelper }, { token: i1.NestedOptionHost }, { token: i0.TransferState }, { token: PLATFORM_ID }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxLookupComponent, isStandalone: true, selector: "dx-lookup", inputs: { accessKey: "accessKey", activeStateEnabled: "activeStateEnabled", applyButtonText: "applyButtonText", applyValueMode: "applyValueMode", cancelButtonText: "cancelButtonText", cleanSearchOnOpening: "cleanSearchOnOpening", clearButtonText: "clearButtonText", dataSource: "dataSource", deferRendering: "deferRendering", disabled: "disabled", displayExpr: "displayExpr", displayValue: "displayValue", dropDownCentered: "dropDownCentered", dropDownOptions: "dropDownOptions", elementAttr: "elementAttr", fieldTemplate: "fieldTemplate", focusStateEnabled: "focusStateEnabled", grouped: "grouped", groupTemplate: "groupTemplate", height: "height", hint: "hint", hoverStateEnabled: "hoverStateEnabled", inputAttr: "inputAttr", isDirty: "isDirty", isValid: "isValid", items: "items", itemTemplate: "itemTemplate", label: "label", labelMode: "labelMode", minSearchLength: "minSearchLength", name: "name", nextButtonText: "nextButtonText", noDataText: "noDataText", opened: "opened", pageLoadingText: "pageLoadingText", pageLoadMode: "pageLoadMode", placeholder: "placeholder", pulledDownText: "pulledDownText", pullingDownText: "pullingDownText", pullRefreshEnabled: "pullRefreshEnabled", refreshingText: "refreshingText", rtlEnabled: "rtlEnabled", searchEnabled: "searchEnabled", searchExpr: "searchExpr", searchMode: "searchMode", searchPlaceholder: "searchPlaceholder", searchStartEvent: "searchStartEvent", searchTimeout: "searchTimeout", selectedItem: "selectedItem", showCancelButton: "showCancelButton", showClearButton: "showClearButton", showDataBeforeSearch: "showDataBeforeSearch", stylingMode: "stylingMode", tabIndex: "tabIndex", text: "text", useItemTextAsTitle: "useItemTextAsTitle", useNativeScrolling: "useNativeScrolling", usePopover: "usePopover", validationError: "validationError", validationErrors: "validationErrors", validationMessageMode: "validationMessageMode", validationMessagePosition: "validationMessagePosition", validationStatus: "validationStatus", value: "value", valueChangeEvent: "valueChangeEvent", valueExpr: "valueExpr", visible: "visible", width: "width", wrapItemText: "wrapItemText" }, outputs: { onClosed: "onClosed", onContentReady: "onContentReady", onDisposing: "onDisposing", onInitialized: "onInitialized", onItemClick: "onItemClick", onOpened: "onOpened", onOptionChanged: "onOptionChanged", onPageLoading: "onPageLoading", onPullRefresh: "onPullRefresh", onScroll: "onScroll", onSelectionChanged: "onSelectionChanged", onValueChanged: "onValueChanged", accessKeyChange: "accessKeyChange", activeStateEnabledChange: "activeStateEnabledChange", applyButtonTextChange: "applyButtonTextChange", applyValueModeChange: "applyValueModeChange", cancelButtonTextChange: "cancelButtonTextChange", cleanSearchOnOpeningChange: "cleanSearchOnOpeningChange", clearButtonTextChange: "clearButtonTextChange", dataSourceChange: "dataSourceChange", deferRenderingChange: "deferRenderingChange", disabledChange: "disabledChange", displayExprChange: "displayExprChange", displayValueChange: "displayValueChange", dropDownCenteredChange: "dropDownCenteredChange", dropDownOptionsChange: "dropDownOptionsChange", elementAttrChange: "elementAttrChange", fieldTemplateChange: "fieldTemplateChange", focusStateEnabledChange: "focusStateEnabledChange", groupedChange: "groupedChange", groupTemplateChange: "groupTemplateChange", heightChange: "heightChange", hintChange: "hintChange", hoverStateEnabledChange: "hoverStateEnabledChange", inputAttrChange: "inputAttrChange", isDirtyChange: "isDirtyChange", isValidChange: "isValidChange", itemsChange: "itemsChange", itemTemplateChange: "itemTemplateChange", labelChange: "labelChange", labelModeChange: "labelModeChange", minSearchLengthChange: "minSearchLengthChange", nameChange: "nameChange", nextButtonTextChange: "nextButtonTextChange", noDataTextChange: "noDataTextChange", openedChange: "openedChange", pageLoadingTextChange: "pageLoadingTextChange", pageLoadModeChange: "pageLoadModeChange", placeholderChange: "placeholderChange", pulledDownTextChange: "pulledDownTextChange", pullingDownTextChange: "pullingDownTextChange", pullRefreshEnabledChange: "pullRefreshEnabledChange", refreshingTextChange: "refreshingTextChange", rtlEnabledChange: "rtlEnabledChange", searchEnabledChange: "searchEnabledChange", searchExprChange: "searchExprChange", searchModeChange: "searchModeChange", searchPlaceholderChange: "searchPlaceholderChange", searchStartEventChange: "searchStartEventChange", searchTimeoutChange: "searchTimeoutChange", selectedItemChange: "selectedItemChange", showCancelButtonChange: "showCancelButtonChange", showClearButtonChange: "showClearButtonChange", showDataBeforeSearchChange: "showDataBeforeSearchChange", stylingModeChange: "stylingModeChange", tabIndexChange: "tabIndexChange", textChange: "textChange", useItemTextAsTitleChange: "useItemTextAsTitleChange", useNativeScrollingChange: "useNativeScrollingChange", usePopoverChange: "usePopoverChange", validationErrorChange: "validationErrorChange", validationErrorsChange: "validationErrorsChange", validationMessageModeChange: "validationMessageModeChange", validationMessagePositionChange: "validationMessagePositionChange", validationStatusChange: "validationStatusChange", valueChange: "valueChange", valueChangeEventChange: "valueChangeEventChange", valueExprChange: "valueExprChange", visibleChange: "visibleChange", widthChange: "widthChange", wrapItemTextChange: "wrapItemTextChange", onBlur: "onBlur" }, host: { attributes: { "ngSkipHydration": "true" }, listeners: { "valueChange": "change($event)", "onBlur": "touched($event)" } }, providers: [
            DxTemplateHost,
            WatcherHelper,
            CUSTOM_VALUE_ACCESSOR_PROVIDER,
            NestedOptionHost,
            IterableDifferHelper
        ], queries: [{ propertyName: "_itemsContentChildren", predicate: PROPERTY_TOKEN_items }, { propertyName: "_toolbarItemsContentChildren", predicate: PROPERTY_TOKEN_toolbarItems }], usesInheritance: true, usesOnChanges: true, ngImport: i0, template: '', isInline: true, dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxLookupComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'dx-lookup',
                    template: '',
                    host: { ngSkipHydration: 'true' },
                    imports: [DxIntegrationModule],
                    providers: [
                        DxTemplateHost,
                        WatcherHelper,
                        CUSTOM_VALUE_ACCESSOR_PROVIDER,
                        NestedOptionHost,
                        IterableDifferHelper
                    ]
                }]
        }], ctorParameters: () => [{ type: i0.ElementRef }, { type: i0.NgZone }, { type: i1.DxTemplateHost }, { type: i1.WatcherHelper }, { type: i1.IterableDifferHelper }, { type: i1.NestedOptionHost }, { type: i0.TransferState }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [PLATFORM_ID]
                }] }], propDecorators: { _itemsContentChildren: [{
                type: ContentChildren,
                args: [PROPERTY_TOKEN_items]
            }], _toolbarItemsContentChildren: [{
                type: ContentChildren,
                args: [PROPERTY_TOKEN_toolbarItems]
            }], accessKey: [{
                type: Input
            }], activeStateEnabled: [{
                type: Input
            }], applyButtonText: [{
                type: Input
            }], applyValueMode: [{
                type: Input
            }], cancelButtonText: [{
                type: Input
            }], cleanSearchOnOpening: [{
                type: Input
            }], clearButtonText: [{
                type: Input
            }], dataSource: [{
                type: Input
            }], deferRendering: [{
                type: Input
            }], disabled: [{
                type: Input
            }], displayExpr: [{
                type: Input
            }], displayValue: [{
                type: Input
            }], dropDownCentered: [{
                type: Input
            }], dropDownOptions: [{
                type: Input
            }], elementAttr: [{
                type: Input
            }], fieldTemplate: [{
                type: Input
            }], focusStateEnabled: [{
                type: Input
            }], grouped: [{
                type: Input
            }], groupTemplate: [{
                type: Input
            }], height: [{
                type: Input
            }], hint: [{
                type: Input
            }], hoverStateEnabled: [{
                type: Input
            }], inputAttr: [{
                type: Input
            }], isDirty: [{
                type: Input
            }], isValid: [{
                type: Input
            }], items: [{
                type: Input
            }], itemTemplate: [{
                type: Input
            }], label: [{
                type: Input
            }], labelMode: [{
                type: Input
            }], minSearchLength: [{
                type: Input
            }], name: [{
                type: Input
            }], nextButtonText: [{
                type: Input
            }], noDataText: [{
                type: Input
            }], opened: [{
                type: Input
            }], pageLoadingText: [{
                type: Input
            }], pageLoadMode: [{
                type: Input
            }], placeholder: [{
                type: Input
            }], pulledDownText: [{
                type: Input
            }], pullingDownText: [{
                type: Input
            }], pullRefreshEnabled: [{
                type: Input
            }], refreshingText: [{
                type: Input
            }], rtlEnabled: [{
                type: Input
            }], searchEnabled: [{
                type: Input
            }], searchExpr: [{
                type: Input
            }], searchMode: [{
                type: Input
            }], searchPlaceholder: [{
                type: Input
            }], searchStartEvent: [{
                type: Input
            }], searchTimeout: [{
                type: Input
            }], selectedItem: [{
                type: Input
            }], showCancelButton: [{
                type: Input
            }], showClearButton: [{
                type: Input
            }], showDataBeforeSearch: [{
                type: Input
            }], stylingMode: [{
                type: Input
            }], tabIndex: [{
                type: Input
            }], text: [{
                type: Input
            }], useItemTextAsTitle: [{
                type: Input
            }], useNativeScrolling: [{
                type: Input
            }], usePopover: [{
                type: Input
            }], validationError: [{
                type: Input
            }], validationErrors: [{
                type: Input
            }], validationMessageMode: [{
                type: Input
            }], validationMessagePosition: [{
                type: Input
            }], validationStatus: [{
                type: Input
            }], value: [{
                type: Input
            }], valueChangeEvent: [{
                type: Input
            }], valueExpr: [{
                type: Input
            }], visible: [{
                type: Input
            }], width: [{
                type: Input
            }], wrapItemText: [{
                type: Input
            }], onClosed: [{
                type: Output
            }], onContentReady: [{
                type: Output
            }], onDisposing: [{
                type: Output
            }], onInitialized: [{
                type: Output
            }], onItemClick: [{
                type: Output
            }], onOpened: [{
                type: Output
            }], onOptionChanged: [{
                type: Output
            }], onPageLoading: [{
                type: Output
            }], onPullRefresh: [{
                type: Output
            }], onScroll: [{
                type: Output
            }], onSelectionChanged: [{
                type: Output
            }], onValueChanged: [{
                type: Output
            }], accessKeyChange: [{
                type: Output
            }], activeStateEnabledChange: [{
                type: Output
            }], applyButtonTextChange: [{
                type: Output
            }], applyValueModeChange: [{
                type: Output
            }], cancelButtonTextChange: [{
                type: Output
            }], cleanSearchOnOpeningChange: [{
                type: Output
            }], clearButtonTextChange: [{
                type: Output
            }], dataSourceChange: [{
                type: Output
            }], deferRenderingChange: [{
                type: Output
            }], disabledChange: [{
                type: Output
            }], displayExprChange: [{
                type: Output
            }], displayValueChange: [{
                type: Output
            }], dropDownCenteredChange: [{
                type: Output
            }], dropDownOptionsChange: [{
                type: Output
            }], elementAttrChange: [{
                type: Output
            }], fieldTemplateChange: [{
                type: Output
            }], focusStateEnabledChange: [{
                type: Output
            }], groupedChange: [{
                type: Output
            }], groupTemplateChange: [{
                type: Output
            }], heightChange: [{
                type: Output
            }], hintChange: [{
                type: Output
            }], hoverStateEnabledChange: [{
                type: Output
            }], inputAttrChange: [{
                type: Output
            }], isDirtyChange: [{
                type: Output
            }], isValidChange: [{
                type: Output
            }], itemsChange: [{
                type: Output
            }], itemTemplateChange: [{
                type: Output
            }], labelChange: [{
                type: Output
            }], labelModeChange: [{
                type: Output
            }], minSearchLengthChange: [{
                type: Output
            }], nameChange: [{
                type: Output
            }], nextButtonTextChange: [{
                type: Output
            }], noDataTextChange: [{
                type: Output
            }], openedChange: [{
                type: Output
            }], pageLoadingTextChange: [{
                type: Output
            }], pageLoadModeChange: [{
                type: Output
            }], placeholderChange: [{
                type: Output
            }], pulledDownTextChange: [{
                type: Output
            }], pullingDownTextChange: [{
                type: Output
            }], pullRefreshEnabledChange: [{
                type: Output
            }], refreshingTextChange: [{
                type: Output
            }], rtlEnabledChange: [{
                type: Output
            }], searchEnabledChange: [{
                type: Output
            }], searchExprChange: [{
                type: Output
            }], searchModeChange: [{
                type: Output
            }], searchPlaceholderChange: [{
                type: Output
            }], searchStartEventChange: [{
                type: Output
            }], searchTimeoutChange: [{
                type: Output
            }], selectedItemChange: [{
                type: Output
            }], showCancelButtonChange: [{
                type: Output
            }], showClearButtonChange: [{
                type: Output
            }], showDataBeforeSearchChange: [{
                type: Output
            }], stylingModeChange: [{
                type: Output
            }], tabIndexChange: [{
                type: Output
            }], textChange: [{
                type: Output
            }], useItemTextAsTitleChange: [{
                type: Output
            }], useNativeScrollingChange: [{
                type: Output
            }], usePopoverChange: [{
                type: Output
            }], validationErrorChange: [{
                type: Output
            }], validationErrorsChange: [{
                type: Output
            }], validationMessageModeChange: [{
                type: Output
            }], validationMessagePositionChange: [{
                type: Output
            }], validationStatusChange: [{
                type: Output
            }], valueChange: [{
                type: Output
            }], valueChangeEventChange: [{
                type: Output
            }], valueExprChange: [{
                type: Output
            }], visibleChange: [{
                type: Output
            }], widthChange: [{
                type: Output
            }], wrapItemTextChange: [{
                type: Output
            }], onBlur: [{
                type: Output
            }], change: [{
                type: HostListener,
                args: ['valueChange', ['$event']]
            }], touched: [{
                type: HostListener,
                args: ['onBlur', ['$event']]
            }] } });
class DxLookupModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxLookupModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxLookupModule, imports: [DxLookupComponent, DxoDropDownOptionsModule,
            DxoAnimationModule,
            DxoHideModule,
            DxoFromModule,
            DxoPositionModule,
            DxoAtModule,
            DxoBoundaryOffsetModule,
            DxoCollisionModule,
            DxoMyModule,
            DxoOffsetModule,
            DxoToModule,
            DxoShowModule,
            DxoHideEventModule,
            DxoShowEventModule,
            DxiItemModule,
            DxoLookupAnimationModule,
            DxoLookupAtModule,
            DxoLookupBoundaryOffsetModule,
            DxoLookupCollisionModule,
            DxoLookupDropDownOptionsModule,
            DxoLookupFromModule,
            DxoLookupHideModule,
            DxoLookupHideEventModule,
            DxiLookupItemModule,
            DxoLookupMyModule,
            DxoLookupOffsetModule,
            DxoLookupPositionModule,
            DxoLookupShowModule,
            DxoLookupShowEventModule,
            DxoLookupToModule,
            DxiLookupToolbarItemModule,
            DxIntegrationModule,
            DxTemplateModule], exports: [DxLookupComponent, DxoDropDownOptionsModule,
            DxoAnimationModule,
            DxoHideModule,
            DxoFromModule,
            DxoPositionModule,
            DxoAtModule,
            DxoBoundaryOffsetModule,
            DxoCollisionModule,
            DxoMyModule,
            DxoOffsetModule,
            DxoToModule,
            DxoShowModule,
            DxoHideEventModule,
            DxoShowEventModule,
            DxiItemModule,
            DxoLookupAnimationModule,
            DxoLookupAtModule,
            DxoLookupBoundaryOffsetModule,
            DxoLookupCollisionModule,
            DxoLookupDropDownOptionsModule,
            DxoLookupFromModule,
            DxoLookupHideModule,
            DxoLookupHideEventModule,
            DxiLookupItemModule,
            DxoLookupMyModule,
            DxoLookupOffsetModule,
            DxoLookupPositionModule,
            DxoLookupShowModule,
            DxoLookupShowEventModule,
            DxoLookupToModule,
            DxiLookupToolbarItemModule,
            DxTemplateModule] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxLookupModule, imports: [DxLookupComponent,
            DxoDropDownOptionsModule,
            DxoAnimationModule,
            DxoHideModule,
            DxoFromModule,
            DxoPositionModule,
            DxoAtModule,
            DxoBoundaryOffsetModule,
            DxoCollisionModule,
            DxoMyModule,
            DxoOffsetModule,
            DxoToModule,
            DxoShowModule,
            DxoHideEventModule,
            DxoShowEventModule,
            DxiItemModule,
            DxoLookupAnimationModule,
            DxoLookupAtModule,
            DxoLookupBoundaryOffsetModule,
            DxoLookupCollisionModule,
            DxoLookupDropDownOptionsModule,
            DxoLookupFromModule,
            DxoLookupHideModule,
            DxoLookupHideEventModule,
            DxiLookupItemModule,
            DxoLookupMyModule,
            DxoLookupOffsetModule,
            DxoLookupPositionModule,
            DxoLookupShowModule,
            DxoLookupShowEventModule,
            DxoLookupToModule,
            DxiLookupToolbarItemModule,
            DxIntegrationModule,
            DxTemplateModule, DxoDropDownOptionsModule,
            DxoAnimationModule,
            DxoHideModule,
            DxoFromModule,
            DxoPositionModule,
            DxoAtModule,
            DxoBoundaryOffsetModule,
            DxoCollisionModule,
            DxoMyModule,
            DxoOffsetModule,
            DxoToModule,
            DxoShowModule,
            DxoHideEventModule,
            DxoShowEventModule,
            DxiItemModule,
            DxoLookupAnimationModule,
            DxoLookupAtModule,
            DxoLookupBoundaryOffsetModule,
            DxoLookupCollisionModule,
            DxoLookupDropDownOptionsModule,
            DxoLookupFromModule,
            DxoLookupHideModule,
            DxoLookupHideEventModule,
            DxiLookupItemModule,
            DxoLookupMyModule,
            DxoLookupOffsetModule,
            DxoLookupPositionModule,
            DxoLookupShowModule,
            DxoLookupShowEventModule,
            DxoLookupToModule,
            DxiLookupToolbarItemModule,
            DxTemplateModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxLookupModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxLookupComponent,
                        DxoDropDownOptionsModule,
                        DxoAnimationModule,
                        DxoHideModule,
                        DxoFromModule,
                        DxoPositionModule,
                        DxoAtModule,
                        DxoBoundaryOffsetModule,
                        DxoCollisionModule,
                        DxoMyModule,
                        DxoOffsetModule,
                        DxoToModule,
                        DxoShowModule,
                        DxoHideEventModule,
                        DxoShowEventModule,
                        DxiItemModule,
                        DxoLookupAnimationModule,
                        DxoLookupAtModule,
                        DxoLookupBoundaryOffsetModule,
                        DxoLookupCollisionModule,
                        DxoLookupDropDownOptionsModule,
                        DxoLookupFromModule,
                        DxoLookupHideModule,
                        DxoLookupHideEventModule,
                        DxiLookupItemModule,
                        DxoLookupMyModule,
                        DxoLookupOffsetModule,
                        DxoLookupPositionModule,
                        DxoLookupShowModule,
                        DxoLookupShowEventModule,
                        DxoLookupToModule,
                        DxiLookupToolbarItemModule,
                        DxIntegrationModule,
                        DxTemplateModule
                    ],
                    exports: [
                        DxLookupComponent,
                        DxoDropDownOptionsModule,
                        DxoAnimationModule,
                        DxoHideModule,
                        DxoFromModule,
                        DxoPositionModule,
                        DxoAtModule,
                        DxoBoundaryOffsetModule,
                        DxoCollisionModule,
                        DxoMyModule,
                        DxoOffsetModule,
                        DxoToModule,
                        DxoShowModule,
                        DxoHideEventModule,
                        DxoShowEventModule,
                        DxiItemModule,
                        DxoLookupAnimationModule,
                        DxoLookupAtModule,
                        DxoLookupBoundaryOffsetModule,
                        DxoLookupCollisionModule,
                        DxoLookupDropDownOptionsModule,
                        DxoLookupFromModule,
                        DxoLookupHideModule,
                        DxoLookupHideEventModule,
                        DxiLookupItemModule,
                        DxoLookupMyModule,
                        DxoLookupOffsetModule,
                        DxoLookupPositionModule,
                        DxoLookupShowModule,
                        DxoLookupShowEventModule,
                        DxoLookupToModule,
                        DxiLookupToolbarItemModule,
                        DxTemplateModule
                    ]
                }]
        }] });

/**
 * Generated bundle index. Do not edit.
 */

export { DxLookupComponent, DxLookupModule };
//# sourceMappingURL=devextreme-angular-ui-lookup.mjs.map
