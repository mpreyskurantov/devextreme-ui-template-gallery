import * as i0 from '@angular/core';
import { Input, SkipSelf, Host, Inject, Component, NgModule } from '@angular/core';
import { DOCUMENT } from '@angular/common';
import * as i1 from 'devextreme-angular/core';
import { CollectionNestedOption, extractTemplate, DxIntegrationModule, NestedOptionHost, DxTemplateHost } from 'devextreme-angular/core';
import { PROPERTY_TOKEN_items } from 'devextreme-angular/core/tokens';

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxiSplitterItemComponent extends CollectionNestedOption {
    get collapsed() {
        return this._getOption('collapsed');
    }
    set collapsed(value) {
        this._setOption('collapsed', value);
    }
    get collapsedSize() {
        return this._getOption('collapsedSize');
    }
    set collapsedSize(value) {
        this._setOption('collapsedSize', value);
    }
    get collapsible() {
        return this._getOption('collapsible');
    }
    set collapsible(value) {
        this._setOption('collapsible', value);
    }
    get maxSize() {
        return this._getOption('maxSize');
    }
    set maxSize(value) {
        this._setOption('maxSize', value);
    }
    get minSize() {
        return this._getOption('minSize');
    }
    set minSize(value) {
        this._setOption('minSize', value);
    }
    get resizable() {
        return this._getOption('resizable');
    }
    set resizable(value) {
        this._setOption('resizable', value);
    }
    get size() {
        return this._getOption('size');
    }
    set size(value) {
        this._setOption('size', value);
    }
    get splitter() {
        return this._getOption('splitter');
    }
    set splitter(value) {
        this._setOption('splitter', value);
    }
    get template() {
        return this._getOption('template');
    }
    set template(value) {
        this._setOption('template', value);
    }
    get text() {
        return this._getOption('text');
    }
    set text(value) {
        this._setOption('text', value);
    }
    get visible() {
        return this._getOption('visible');
    }
    set visible(value) {
        this._setOption('visible', value);
    }
    get _optionPath() {
        return 'items';
    }
    constructor(parentOptionHost, optionHost, renderer, document, templateHost, element) {
        super();
        this.renderer = renderer;
        this.document = document;
        this.element = element;
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
        templateHost.setHost(this);
    }
    setTemplate(template) {
        this.template = template;
    }
    ngAfterViewInit() {
        extractTemplate(this, this.element, this.renderer, this.document);
    }
    ngOnDestroy() {
        this._deleteRemovedOptions(this._fullOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiSplitterItemComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }, { token: i0.Renderer2 }, { token: DOCUMENT }, { token: i1.DxTemplateHost, host: true }, { token: i0.ElementRef }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxiSplitterItemComponent, isStandalone: true, selector: "dxi-splitter-item", inputs: { collapsed: "collapsed", collapsedSize: "collapsedSize", collapsible: "collapsible", maxSize: "maxSize", minSize: "minSize", resizable: "resizable", size: "size", splitter: "splitter", template: "template", text: "text", visible: "visible" }, providers: [
            NestedOptionHost,
            DxTemplateHost,
            {
                provide: PROPERTY_TOKEN_items,
                useExisting: DxiSplitterItemComponent,
            }
        ], usesInheritance: true, ngImport: i0, template: '<ng-content></ng-content>', isInline: true, styles: [":host{display:block}\n"], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiSplitterItemComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxi-splitter-item', template: '<ng-content></ng-content>', imports: [DxIntegrationModule], providers: [
                        NestedOptionHost,
                        DxTemplateHost,
                        {
                            provide: PROPERTY_TOKEN_items,
                            useExisting: DxiSplitterItemComponent,
                        }
                    ], styles: [":host{display:block}\n"] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }, { type: i0.Renderer2 }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [DOCUMENT]
                }] }, { type: i1.DxTemplateHost, decorators: [{
                    type: Host
                }] }, { type: i0.ElementRef }], propDecorators: { collapsed: [{
                type: Input
            }], collapsedSize: [{
                type: Input
            }], collapsible: [{
                type: Input
            }], maxSize: [{
                type: Input
            }], minSize: [{
                type: Input
            }], resizable: [{
                type: Input
            }], size: [{
                type: Input
            }], splitter: [{
                type: Input
            }], template: [{
                type: Input
            }], text: [{
                type: Input
            }], visible: [{
                type: Input
            }] } });
class DxiSplitterItemModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiSplitterItemModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxiSplitterItemModule, imports: [DxiSplitterItemComponent], exports: [DxiSplitterItemComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiSplitterItemModule, imports: [DxiSplitterItemComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiSplitterItemModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxiSplitterItemComponent
                    ],
                    exports: [
                        DxiSplitterItemComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

/**
 * Generated bundle index. Do not edit.
 */

export { DxiSplitterItemComponent, DxiSplitterItemModule };
//# sourceMappingURL=devextreme-angular-ui-splitter-nested.mjs.map
