import * as i0 from '@angular/core';
import { PLATFORM_ID, Output, Input, ContentChildren, Inject, Component, NgModule } from '@angular/core';
import DxForm from 'devextreme/ui/form';
import * as i1 from 'devextreme-angular/core';
import { DxComponent, DxIntegrationModule, DxTemplateHost, WatcherHelper, NestedOptionHost, IterableDifferHelper, DxTemplateModule } from 'devextreme-angular/core';
import { DxoColCountByScreenModule, DxiItemModule, DxoLabelModule, DxiValidationRuleModule, DxoTabPanelOptionsModule, DxiTabModule, DxoButtonOptionsModule } from 'devextreme-angular/ui/nested';
import { DxoFormAIOptionsModule, DxiFormAsyncRuleModule, DxiFormButtonItemModule, DxoFormButtonOptionsModule, DxoFormColCountByScreenModule, DxiFormCompareRuleModule, DxiFormCustomRuleModule, DxiFormEmailRuleModule, DxiFormEmptyItemModule, DxiFormGroupItemModule, DxiFormItemModule, DxoFormLabelModule, DxiFormNumericRuleModule, DxiFormPatternRuleModule, DxiFormRangeRuleModule, DxiFormRequiredRuleModule, DxiFormSimpleItemModule, DxiFormStringLengthRuleModule, DxiFormTabModule, DxiFormTabbedItemModule, DxoFormTabPanelOptionsModule, DxiFormTabPanelOptionsItemModule, DxiFormValidationRuleModule } from 'devextreme-angular/ui/form/nested';
export * from 'devextreme-angular/ui/form/nested';
import { PROPERTY_TOKEN_validationRules, PROPERTY_TOKEN_items, PROPERTY_TOKEN_tabs } from 'devextreme-angular/core/tokens';

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
/**
 * [descr:dxForm]

 */
class DxFormComponent extends DxComponent {
    set _validationRulesContentChildren(value) {
        this.setChildren('validationRules', value);
    }
    set _itemsContentChildren(value) {
        this.setChildren('items', value);
    }
    set _tabsContentChildren(value) {
        this.setChildren('tabs', value);
    }
    /**
     * [descr:WidgetOptions.accessKey]
    
     */
    get accessKey() {
        return this._getOption('accessKey');
    }
    set accessKey(value) {
        this._setOption('accessKey', value);
    }
    /**
     * [descr:WidgetOptions.activeStateEnabled]
    
     */
    get activeStateEnabled() {
        return this._getOption('activeStateEnabled');
    }
    set activeStateEnabled(value) {
        this._setOption('activeStateEnabled', value);
    }
    get aiIntegration() {
        return this._getOption('aiIntegration');
    }
    set aiIntegration(value) {
        this._setOption('aiIntegration', value);
    }
    /**
     * [descr:dxFormOptions.alignItemLabels]
    
     */
    get alignItemLabels() {
        return this._getOption('alignItemLabels');
    }
    set alignItemLabels(value) {
        this._setOption('alignItemLabels', value);
    }
    /**
     * [descr:dxFormOptions.alignItemLabelsInAllGroups]
    
     */
    get alignItemLabelsInAllGroups() {
        return this._getOption('alignItemLabelsInAllGroups');
    }
    set alignItemLabelsInAllGroups(value) {
        this._setOption('alignItemLabelsInAllGroups', value);
    }
    /**
     * [descr:dxFormOptions.colCount]
    
     */
    get colCount() {
        return this._getOption('colCount');
    }
    set colCount(value) {
        this._setOption('colCount', value);
    }
    /**
     * [descr:dxFormOptions.colCountByScreen]
    
     */
    get colCountByScreen() {
        return this._getOption('colCountByScreen');
    }
    set colCountByScreen(value) {
        this._setOption('colCountByScreen', value);
    }
    /**
     * [descr:dxFormOptions.customizeItem]
    
     */
    get customizeItem() {
        return this._getOption('customizeItem');
    }
    set customizeItem(value) {
        this._setOption('customizeItem', value);
    }
    /**
     * [descr:WidgetOptions.disabled]
    
     */
    get disabled() {
        return this._getOption('disabled');
    }
    set disabled(value) {
        this._setOption('disabled', value);
    }
    /**
     * [descr:DOMComponentOptions.elementAttr]
    
     */
    get elementAttr() {
        return this._getOption('elementAttr');
    }
    set elementAttr(value) {
        this._setOption('elementAttr', value);
    }
    /**
     * [descr:WidgetOptions.focusStateEnabled]
    
     */
    get focusStateEnabled() {
        return this._getOption('focusStateEnabled');
    }
    set focusStateEnabled(value) {
        this._setOption('focusStateEnabled', value);
    }
    /**
     * [descr:dxFormOptions.formData]
    
     */
    get formData() {
        return this._getOption('formData');
    }
    set formData(value) {
        this._setOption('formData', value);
    }
    /**
     * [descr:DOMComponentOptions.height]
    
     */
    get height() {
        return this._getOption('height');
    }
    set height(value) {
        this._setOption('height', value);
    }
    /**
     * [descr:WidgetOptions.hint]
    
     */
    get hint() {
        return this._getOption('hint');
    }
    set hint(value) {
        this._setOption('hint', value);
    }
    /**
     * [descr:WidgetOptions.hoverStateEnabled]
    
     */
    get hoverStateEnabled() {
        return this._getOption('hoverStateEnabled');
    }
    set hoverStateEnabled(value) {
        this._setOption('hoverStateEnabled', value);
    }
    /**
     * [descr:dxFormOptions.isDirty]
    
     */
    get isDirty() {
        return this._getOption('isDirty');
    }
    set isDirty(value) {
        this._setOption('isDirty', value);
    }
    /**
     * [descr:dxFormOptions.items]
    
     */
    get items() {
        return this._getOption('items');
    }
    set items(value) {
        this._setOption('items', value);
    }
    /**
     * [descr:dxFormOptions.labelLocation]
    
     */
    get labelLocation() {
        return this._getOption('labelLocation');
    }
    set labelLocation(value) {
        this._setOption('labelLocation', value);
    }
    /**
     * [descr:dxFormOptions.labelMode]
    
     */
    get labelMode() {
        return this._getOption('labelMode');
    }
    set labelMode(value) {
        this._setOption('labelMode', value);
    }
    /**
     * [descr:dxFormOptions.minColWidth]
    
     */
    get minColWidth() {
        return this._getOption('minColWidth');
    }
    set minColWidth(value) {
        this._setOption('minColWidth', value);
    }
    /**
     * [descr:dxFormOptions.optionalMark]
    
     */
    get optionalMark() {
        return this._getOption('optionalMark');
    }
    set optionalMark(value) {
        this._setOption('optionalMark', value);
    }
    /**
     * [descr:dxFormOptions.readOnly]
    
     */
    get readOnly() {
        return this._getOption('readOnly');
    }
    set readOnly(value) {
        this._setOption('readOnly', value);
    }
    /**
     * [descr:dxFormOptions.requiredMark]
    
     */
    get requiredMark() {
        return this._getOption('requiredMark');
    }
    set requiredMark(value) {
        this._setOption('requiredMark', value);
    }
    /**
     * [descr:dxFormOptions.requiredMessage]
    
     */
    get requiredMessage() {
        return this._getOption('requiredMessage');
    }
    set requiredMessage(value) {
        this._setOption('requiredMessage', value);
    }
    /**
     * [descr:DOMComponentOptions.rtlEnabled]
    
     */
    get rtlEnabled() {
        return this._getOption('rtlEnabled');
    }
    set rtlEnabled(value) {
        this._setOption('rtlEnabled', value);
    }
    /**
     * [descr:dxFormOptions.screenByWidth]
    
     */
    get screenByWidth() {
        return this._getOption('screenByWidth');
    }
    set screenByWidth(value) {
        this._setOption('screenByWidth', value);
    }
    /**
     * [descr:dxFormOptions.scrollingEnabled]
    
     */
    get scrollingEnabled() {
        return this._getOption('scrollingEnabled');
    }
    set scrollingEnabled(value) {
        this._setOption('scrollingEnabled', value);
    }
    /**
     * [descr:dxFormOptions.showColonAfterLabel]
    
     */
    get showColonAfterLabel() {
        return this._getOption('showColonAfterLabel');
    }
    set showColonAfterLabel(value) {
        this._setOption('showColonAfterLabel', value);
    }
    /**
     * [descr:dxFormOptions.showOptionalMark]
    
     */
    get showOptionalMark() {
        return this._getOption('showOptionalMark');
    }
    set showOptionalMark(value) {
        this._setOption('showOptionalMark', value);
    }
    /**
     * [descr:dxFormOptions.showRequiredMark]
    
     */
    get showRequiredMark() {
        return this._getOption('showRequiredMark');
    }
    set showRequiredMark(value) {
        this._setOption('showRequiredMark', value);
    }
    /**
     * [descr:dxFormOptions.showValidationSummary]
    
     */
    get showValidationSummary() {
        return this._getOption('showValidationSummary');
    }
    set showValidationSummary(value) {
        this._setOption('showValidationSummary', value);
    }
    /**
     * [descr:WidgetOptions.tabIndex]
    
     */
    get tabIndex() {
        return this._getOption('tabIndex');
    }
    set tabIndex(value) {
        this._setOption('tabIndex', value);
    }
    /**
     * [descr:dxFormOptions.validationGroup]
    
     */
    get validationGroup() {
        return this._getOption('validationGroup');
    }
    set validationGroup(value) {
        this._setOption('validationGroup', value);
    }
    /**
     * [descr:WidgetOptions.visible]
    
     */
    get visible() {
        return this._getOption('visible');
    }
    set visible(value) {
        this._setOption('visible', value);
    }
    /**
     * [descr:DOMComponentOptions.width]
    
     */
    get width() {
        return this._getOption('width');
    }
    set width(value) {
        this._setOption('width', value);
    }
    constructor(elementRef, ngZone, templateHost, _watcherHelper, _idh, optionHost, transferState, platformId) {
        super(elementRef, ngZone, templateHost, _watcherHelper, transferState, platformId);
        this._watcherHelper = _watcherHelper;
        this._idh = _idh;
        this.instance = null;
        this._createEventEmitters([
            { subscribe: 'contentReady', emit: 'onContentReady' },
            { subscribe: 'disposing', emit: 'onDisposing' },
            { subscribe: 'editorEnterKey', emit: 'onEditorEnterKey' },
            { subscribe: 'fieldDataChanged', emit: 'onFieldDataChanged' },
            { subscribe: 'initialized', emit: 'onInitialized' },
            { subscribe: 'optionChanged', emit: 'onOptionChanged' },
            { subscribe: 'smartPasted', emit: 'onSmartPasted' },
            { subscribe: 'smartPasting', emit: 'onSmartPasting' },
            { emit: 'accessKeyChange' },
            { emit: 'activeStateEnabledChange' },
            { emit: 'aiIntegrationChange' },
            { emit: 'alignItemLabelsChange' },
            { emit: 'alignItemLabelsInAllGroupsChange' },
            { emit: 'colCountChange' },
            { emit: 'colCountByScreenChange' },
            { emit: 'customizeItemChange' },
            { emit: 'disabledChange' },
            { emit: 'elementAttrChange' },
            { emit: 'focusStateEnabledChange' },
            { emit: 'formDataChange' },
            { emit: 'heightChange' },
            { emit: 'hintChange' },
            { emit: 'hoverStateEnabledChange' },
            { emit: 'isDirtyChange' },
            { emit: 'itemsChange' },
            { emit: 'labelLocationChange' },
            { emit: 'labelModeChange' },
            { emit: 'minColWidthChange' },
            { emit: 'optionalMarkChange' },
            { emit: 'readOnlyChange' },
            { emit: 'requiredMarkChange' },
            { emit: 'requiredMessageChange' },
            { emit: 'rtlEnabledChange' },
            { emit: 'screenByWidthChange' },
            { emit: 'scrollingEnabledChange' },
            { emit: 'showColonAfterLabelChange' },
            { emit: 'showOptionalMarkChange' },
            { emit: 'showRequiredMarkChange' },
            { emit: 'showValidationSummaryChange' },
            { emit: 'tabIndexChange' },
            { emit: 'validationGroupChange' },
            { emit: 'visibleChange' },
            { emit: 'widthChange' }
        ]);
        this._idh.setHost(this);
        optionHost.setHost(this);
    }
    _createInstance(element, options) {
        return new DxForm(element, options);
    }
    ngOnDestroy() {
        this._destroyWidget();
    }
    ngOnChanges(changes) {
        super.ngOnChanges(changes);
        this.setupChanges('items', changes);
    }
    setupChanges(prop, changes) {
        if (!(prop in this._optionsToUpdate)) {
            this._idh.setup(prop, changes);
        }
    }
    ngDoCheck() {
        this._idh.doCheck('items');
        this._watcherHelper.checkWatchers();
        super.ngDoCheck();
        super.clearChangedOptions();
    }
    _setOption(name, value) {
        let isSetup = this._idh.setupSingle(name, value);
        let isChanged = this._idh.getChanges(name, value) !== null;
        if (isSetup || isChanged) {
            super._setOption(name, value);
        }
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxFormComponent, deps: [{ token: i0.ElementRef }, { token: i0.NgZone }, { token: i1.DxTemplateHost }, { token: i1.WatcherHelper }, { token: i1.IterableDifferHelper }, { token: i1.NestedOptionHost }, { token: i0.TransferState }, { token: PLATFORM_ID }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxFormComponent, isStandalone: true, selector: "dx-form", inputs: { accessKey: "accessKey", activeStateEnabled: "activeStateEnabled", aiIntegration: "aiIntegration", alignItemLabels: "alignItemLabels", alignItemLabelsInAllGroups: "alignItemLabelsInAllGroups", colCount: "colCount", colCountByScreen: "colCountByScreen", customizeItem: "customizeItem", disabled: "disabled", elementAttr: "elementAttr", focusStateEnabled: "focusStateEnabled", formData: "formData", height: "height", hint: "hint", hoverStateEnabled: "hoverStateEnabled", isDirty: "isDirty", items: "items", labelLocation: "labelLocation", labelMode: "labelMode", minColWidth: "minColWidth", optionalMark: "optionalMark", readOnly: "readOnly", requiredMark: "requiredMark", requiredMessage: "requiredMessage", rtlEnabled: "rtlEnabled", screenByWidth: "screenByWidth", scrollingEnabled: "scrollingEnabled", showColonAfterLabel: "showColonAfterLabel", showOptionalMark: "showOptionalMark", showRequiredMark: "showRequiredMark", showValidationSummary: "showValidationSummary", tabIndex: "tabIndex", validationGroup: "validationGroup", visible: "visible", width: "width" }, outputs: { onContentReady: "onContentReady", onDisposing: "onDisposing", onEditorEnterKey: "onEditorEnterKey", onFieldDataChanged: "onFieldDataChanged", onInitialized: "onInitialized", onOptionChanged: "onOptionChanged", onSmartPasted: "onSmartPasted", onSmartPasting: "onSmartPasting", accessKeyChange: "accessKeyChange", activeStateEnabledChange: "activeStateEnabledChange", aiIntegrationChange: "aiIntegrationChange", alignItemLabelsChange: "alignItemLabelsChange", alignItemLabelsInAllGroupsChange: "alignItemLabelsInAllGroupsChange", colCountChange: "colCountChange", colCountByScreenChange: "colCountByScreenChange", customizeItemChange: "customizeItemChange", disabledChange: "disabledChange", elementAttrChange: "elementAttrChange", focusStateEnabledChange: "focusStateEnabledChange", formDataChange: "formDataChange", heightChange: "heightChange", hintChange: "hintChange", hoverStateEnabledChange: "hoverStateEnabledChange", isDirtyChange: "isDirtyChange", itemsChange: "itemsChange", labelLocationChange: "labelLocationChange", labelModeChange: "labelModeChange", minColWidthChange: "minColWidthChange", optionalMarkChange: "optionalMarkChange", readOnlyChange: "readOnlyChange", requiredMarkChange: "requiredMarkChange", requiredMessageChange: "requiredMessageChange", rtlEnabledChange: "rtlEnabledChange", screenByWidthChange: "screenByWidthChange", scrollingEnabledChange: "scrollingEnabledChange", showColonAfterLabelChange: "showColonAfterLabelChange", showOptionalMarkChange: "showOptionalMarkChange", showRequiredMarkChange: "showRequiredMarkChange", showValidationSummaryChange: "showValidationSummaryChange", tabIndexChange: "tabIndexChange", validationGroupChange: "validationGroupChange", visibleChange: "visibleChange", widthChange: "widthChange" }, host: { attributes: { "ngSkipHydration": "true" } }, providers: [
            DxTemplateHost,
            WatcherHelper,
            NestedOptionHost,
            IterableDifferHelper
        ], queries: [{ propertyName: "_validationRulesContentChildren", predicate: PROPERTY_TOKEN_validationRules }, { propertyName: "_itemsContentChildren", predicate: PROPERTY_TOKEN_items }, { propertyName: "_tabsContentChildren", predicate: PROPERTY_TOKEN_tabs }], usesInheritance: true, usesOnChanges: true, ngImport: i0, template: '', isInline: true, dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxFormComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'dx-form',
                    template: '',
                    host: { ngSkipHydration: 'true' },
                    imports: [DxIntegrationModule],
                    providers: [
                        DxTemplateHost,
                        WatcherHelper,
                        NestedOptionHost,
                        IterableDifferHelper
                    ]
                }]
        }], ctorParameters: () => [{ type: i0.ElementRef }, { type: i0.NgZone }, { type: i1.DxTemplateHost }, { type: i1.WatcherHelper }, { type: i1.IterableDifferHelper }, { type: i1.NestedOptionHost }, { type: i0.TransferState }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [PLATFORM_ID]
                }] }], propDecorators: { _validationRulesContentChildren: [{
                type: ContentChildren,
                args: [PROPERTY_TOKEN_validationRules]
            }], _itemsContentChildren: [{
                type: ContentChildren,
                args: [PROPERTY_TOKEN_items]
            }], _tabsContentChildren: [{
                type: ContentChildren,
                args: [PROPERTY_TOKEN_tabs]
            }], accessKey: [{
                type: Input
            }], activeStateEnabled: [{
                type: Input
            }], aiIntegration: [{
                type: Input
            }], alignItemLabels: [{
                type: Input
            }], alignItemLabelsInAllGroups: [{
                type: Input
            }], colCount: [{
                type: Input
            }], colCountByScreen: [{
                type: Input
            }], customizeItem: [{
                type: Input
            }], disabled: [{
                type: Input
            }], elementAttr: [{
                type: Input
            }], focusStateEnabled: [{
                type: Input
            }], formData: [{
                type: Input
            }], height: [{
                type: Input
            }], hint: [{
                type: Input
            }], hoverStateEnabled: [{
                type: Input
            }], isDirty: [{
                type: Input
            }], items: [{
                type: Input
            }], labelLocation: [{
                type: Input
            }], labelMode: [{
                type: Input
            }], minColWidth: [{
                type: Input
            }], optionalMark: [{
                type: Input
            }], readOnly: [{
                type: Input
            }], requiredMark: [{
                type: Input
            }], requiredMessage: [{
                type: Input
            }], rtlEnabled: [{
                type: Input
            }], screenByWidth: [{
                type: Input
            }], scrollingEnabled: [{
                type: Input
            }], showColonAfterLabel: [{
                type: Input
            }], showOptionalMark: [{
                type: Input
            }], showRequiredMark: [{
                type: Input
            }], showValidationSummary: [{
                type: Input
            }], tabIndex: [{
                type: Input
            }], validationGroup: [{
                type: Input
            }], visible: [{
                type: Input
            }], width: [{
                type: Input
            }], onContentReady: [{
                type: Output
            }], onDisposing: [{
                type: Output
            }], onEditorEnterKey: [{
                type: Output
            }], onFieldDataChanged: [{
                type: Output
            }], onInitialized: [{
                type: Output
            }], onOptionChanged: [{
                type: Output
            }], onSmartPasted: [{
                type: Output
            }], onSmartPasting: [{
                type: Output
            }], accessKeyChange: [{
                type: Output
            }], activeStateEnabledChange: [{
                type: Output
            }], aiIntegrationChange: [{
                type: Output
            }], alignItemLabelsChange: [{
                type: Output
            }], alignItemLabelsInAllGroupsChange: [{
                type: Output
            }], colCountChange: [{
                type: Output
            }], colCountByScreenChange: [{
                type: Output
            }], customizeItemChange: [{
                type: Output
            }], disabledChange: [{
                type: Output
            }], elementAttrChange: [{
                type: Output
            }], focusStateEnabledChange: [{
                type: Output
            }], formDataChange: [{
                type: Output
            }], heightChange: [{
                type: Output
            }], hintChange: [{
                type: Output
            }], hoverStateEnabledChange: [{
                type: Output
            }], isDirtyChange: [{
                type: Output
            }], itemsChange: [{
                type: Output
            }], labelLocationChange: [{
                type: Output
            }], labelModeChange: [{
                type: Output
            }], minColWidthChange: [{
                type: Output
            }], optionalMarkChange: [{
                type: Output
            }], readOnlyChange: [{
                type: Output
            }], requiredMarkChange: [{
                type: Output
            }], requiredMessageChange: [{
                type: Output
            }], rtlEnabledChange: [{
                type: Output
            }], screenByWidthChange: [{
                type: Output
            }], scrollingEnabledChange: [{
                type: Output
            }], showColonAfterLabelChange: [{
                type: Output
            }], showOptionalMarkChange: [{
                type: Output
            }], showRequiredMarkChange: [{
                type: Output
            }], showValidationSummaryChange: [{
                type: Output
            }], tabIndexChange: [{
                type: Output
            }], validationGroupChange: [{
                type: Output
            }], visibleChange: [{
                type: Output
            }], widthChange: [{
                type: Output
            }] } });
class DxFormModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxFormModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxFormModule, imports: [DxFormComponent, DxoColCountByScreenModule,
            DxiItemModule,
            DxoLabelModule,
            DxiValidationRuleModule,
            DxoTabPanelOptionsModule,
            DxiTabModule,
            DxoButtonOptionsModule,
            DxoFormAIOptionsModule,
            DxiFormAsyncRuleModule,
            DxiFormButtonItemModule,
            DxoFormButtonOptionsModule,
            DxoFormColCountByScreenModule,
            DxiFormCompareRuleModule,
            DxiFormCustomRuleModule,
            DxiFormEmailRuleModule,
            DxiFormEmptyItemModule,
            DxiFormGroupItemModule,
            DxiFormItemModule,
            DxoFormLabelModule,
            DxiFormNumericRuleModule,
            DxiFormPatternRuleModule,
            DxiFormRangeRuleModule,
            DxiFormRequiredRuleModule,
            DxiFormSimpleItemModule,
            DxiFormStringLengthRuleModule,
            DxiFormTabModule,
            DxiFormTabbedItemModule,
            DxoFormTabPanelOptionsModule,
            DxiFormTabPanelOptionsItemModule,
            DxiFormValidationRuleModule,
            DxIntegrationModule,
            DxTemplateModule], exports: [DxFormComponent, DxoColCountByScreenModule,
            DxiItemModule,
            DxoLabelModule,
            DxiValidationRuleModule,
            DxoTabPanelOptionsModule,
            DxiTabModule,
            DxoButtonOptionsModule,
            DxoFormAIOptionsModule,
            DxiFormAsyncRuleModule,
            DxiFormButtonItemModule,
            DxoFormButtonOptionsModule,
            DxoFormColCountByScreenModule,
            DxiFormCompareRuleModule,
            DxiFormCustomRuleModule,
            DxiFormEmailRuleModule,
            DxiFormEmptyItemModule,
            DxiFormGroupItemModule,
            DxiFormItemModule,
            DxoFormLabelModule,
            DxiFormNumericRuleModule,
            DxiFormPatternRuleModule,
            DxiFormRangeRuleModule,
            DxiFormRequiredRuleModule,
            DxiFormSimpleItemModule,
            DxiFormStringLengthRuleModule,
            DxiFormTabModule,
            DxiFormTabbedItemModule,
            DxoFormTabPanelOptionsModule,
            DxiFormTabPanelOptionsItemModule,
            DxiFormValidationRuleModule,
            DxTemplateModule] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxFormModule, imports: [DxFormComponent,
            DxoColCountByScreenModule,
            DxiItemModule,
            DxoLabelModule,
            DxiValidationRuleModule,
            DxoTabPanelOptionsModule,
            DxiTabModule,
            DxoButtonOptionsModule,
            DxoFormAIOptionsModule,
            DxiFormAsyncRuleModule,
            DxiFormButtonItemModule,
            DxoFormButtonOptionsModule,
            DxoFormColCountByScreenModule,
            DxiFormCompareRuleModule,
            DxiFormCustomRuleModule,
            DxiFormEmailRuleModule,
            DxiFormEmptyItemModule,
            DxiFormGroupItemModule,
            DxiFormItemModule,
            DxoFormLabelModule,
            DxiFormNumericRuleModule,
            DxiFormPatternRuleModule,
            DxiFormRangeRuleModule,
            DxiFormRequiredRuleModule,
            DxiFormSimpleItemModule,
            DxiFormStringLengthRuleModule,
            DxiFormTabModule,
            DxiFormTabbedItemModule,
            DxoFormTabPanelOptionsModule,
            DxiFormTabPanelOptionsItemModule,
            DxiFormValidationRuleModule,
            DxIntegrationModule,
            DxTemplateModule, DxoColCountByScreenModule,
            DxiItemModule,
            DxoLabelModule,
            DxiValidationRuleModule,
            DxoTabPanelOptionsModule,
            DxiTabModule,
            DxoButtonOptionsModule,
            DxoFormAIOptionsModule,
            DxiFormAsyncRuleModule,
            DxiFormButtonItemModule,
            DxoFormButtonOptionsModule,
            DxoFormColCountByScreenModule,
            DxiFormCompareRuleModule,
            DxiFormCustomRuleModule,
            DxiFormEmailRuleModule,
            DxiFormEmptyItemModule,
            DxiFormGroupItemModule,
            DxiFormItemModule,
            DxoFormLabelModule,
            DxiFormNumericRuleModule,
            DxiFormPatternRuleModule,
            DxiFormRangeRuleModule,
            DxiFormRequiredRuleModule,
            DxiFormSimpleItemModule,
            DxiFormStringLengthRuleModule,
            DxiFormTabModule,
            DxiFormTabbedItemModule,
            DxoFormTabPanelOptionsModule,
            DxiFormTabPanelOptionsItemModule,
            DxiFormValidationRuleModule,
            DxTemplateModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxFormModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxFormComponent,
                        DxoColCountByScreenModule,
                        DxiItemModule,
                        DxoLabelModule,
                        DxiValidationRuleModule,
                        DxoTabPanelOptionsModule,
                        DxiTabModule,
                        DxoButtonOptionsModule,
                        DxoFormAIOptionsModule,
                        DxiFormAsyncRuleModule,
                        DxiFormButtonItemModule,
                        DxoFormButtonOptionsModule,
                        DxoFormColCountByScreenModule,
                        DxiFormCompareRuleModule,
                        DxiFormCustomRuleModule,
                        DxiFormEmailRuleModule,
                        DxiFormEmptyItemModule,
                        DxiFormGroupItemModule,
                        DxiFormItemModule,
                        DxoFormLabelModule,
                        DxiFormNumericRuleModule,
                        DxiFormPatternRuleModule,
                        DxiFormRangeRuleModule,
                        DxiFormRequiredRuleModule,
                        DxiFormSimpleItemModule,
                        DxiFormStringLengthRuleModule,
                        DxiFormTabModule,
                        DxiFormTabbedItemModule,
                        DxoFormTabPanelOptionsModule,
                        DxiFormTabPanelOptionsItemModule,
                        DxiFormValidationRuleModule,
                        DxIntegrationModule,
                        DxTemplateModule
                    ],
                    exports: [
                        DxFormComponent,
                        DxoColCountByScreenModule,
                        DxiItemModule,
                        DxoLabelModule,
                        DxiValidationRuleModule,
                        DxoTabPanelOptionsModule,
                        DxiTabModule,
                        DxoButtonOptionsModule,
                        DxoFormAIOptionsModule,
                        DxiFormAsyncRuleModule,
                        DxiFormButtonItemModule,
                        DxoFormButtonOptionsModule,
                        DxoFormColCountByScreenModule,
                        DxiFormCompareRuleModule,
                        DxiFormCustomRuleModule,
                        DxiFormEmailRuleModule,
                        DxiFormEmptyItemModule,
                        DxiFormGroupItemModule,
                        DxiFormItemModule,
                        DxoFormLabelModule,
                        DxiFormNumericRuleModule,
                        DxiFormPatternRuleModule,
                        DxiFormRangeRuleModule,
                        DxiFormRequiredRuleModule,
                        DxiFormSimpleItemModule,
                        DxiFormStringLengthRuleModule,
                        DxiFormTabModule,
                        DxiFormTabbedItemModule,
                        DxoFormTabPanelOptionsModule,
                        DxiFormTabPanelOptionsItemModule,
                        DxiFormValidationRuleModule,
                        DxTemplateModule
                    ]
                }]
        }] });

/**
 * Generated bundle index. Do not edit.
 */

export { DxFormComponent, DxFormModule };
//# sourceMappingURL=devextreme-angular-ui-form.mjs.map
