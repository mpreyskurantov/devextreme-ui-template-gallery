import * as i0 from '@angular/core';
import { forwardRef, PLATFORM_ID, HostListener, Output, Input, ContentChildren, Inject, Component, NgModule } from '@angular/core';
import DxFilterBuilder from 'devextreme/ui/filter_builder';
import { NG_VALUE_ACCESSOR } from '@angular/forms';
import * as i1 from 'devextreme-angular/core';
import { DxComponent, DxIntegrationModule, DxTemplateHost, WatcherHelper, NestedOptionHost, IterableDifferHelper, DxTemplateModule } from 'devextreme-angular/core';
import { DxiCustomOperationModule, DxiFieldModule, DxoFormatModule, DxoLookupModule, DxoFilterOperationDescriptionsModule, DxoGroupOperationDescriptionsModule } from 'devextreme-angular/ui/nested';
import { DxiFilterBuilderCustomOperationModule, DxiFilterBuilderFieldModule, DxoFilterBuilderFilterOperationDescriptionsModule, DxoFilterBuilderFormatModule, DxoFilterBuilderGroupOperationDescriptionsModule, DxoFilterBuilderLookupModule } from 'devextreme-angular/ui/filter-builder/nested';
export * from 'devextreme-angular/ui/filter-builder/nested';
import { PROPERTY_TOKEN_customOperations, PROPERTY_TOKEN_fields } from 'devextreme-angular/core/tokens';

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
const CUSTOM_VALUE_ACCESSOR_PROVIDER = {
    provide: NG_VALUE_ACCESSOR,
    useExisting: forwardRef(() => DxFilterBuilderComponent),
    multi: true
};
/**
 * [descr:dxFilterBuilder]

 */
class DxFilterBuilderComponent extends DxComponent {
    set _customOperationsContentChildren(value) {
        this.setChildren('customOperations', value);
    }
    set _fieldsContentChildren(value) {
        this.setChildren('fields', value);
    }
    /**
     * [descr:WidgetOptions.accessKey]
    
     */
    get accessKey() {
        return this._getOption('accessKey');
    }
    set accessKey(value) {
        this._setOption('accessKey', value);
    }
    /**
     * [descr:WidgetOptions.activeStateEnabled]
    
     */
    get activeStateEnabled() {
        return this._getOption('activeStateEnabled');
    }
    set activeStateEnabled(value) {
        this._setOption('activeStateEnabled', value);
    }
    /**
     * [descr:dxFilterBuilderOptions.allowHierarchicalFields]
    
     */
    get allowHierarchicalFields() {
        return this._getOption('allowHierarchicalFields');
    }
    set allowHierarchicalFields(value) {
        this._setOption('allowHierarchicalFields', value);
    }
    /**
     * [descr:dxFilterBuilderOptions.customOperations]
    
     */
    get customOperations() {
        return this._getOption('customOperations');
    }
    set customOperations(value) {
        this._setOption('customOperations', value);
    }
    /**
     * [descr:WidgetOptions.disabled]
    
     */
    get disabled() {
        return this._getOption('disabled');
    }
    set disabled(value) {
        this._setOption('disabled', value);
    }
    /**
     * [descr:DOMComponentOptions.elementAttr]
    
     */
    get elementAttr() {
        return this._getOption('elementAttr');
    }
    set elementAttr(value) {
        this._setOption('elementAttr', value);
    }
    /**
     * [descr:dxFilterBuilderOptions.fields]
    
     */
    get fields() {
        return this._getOption('fields');
    }
    set fields(value) {
        this._setOption('fields', value);
    }
    /**
     * [descr:dxFilterBuilderOptions.filterOperationDescriptions]
    
     */
    get filterOperationDescriptions() {
        return this._getOption('filterOperationDescriptions');
    }
    set filterOperationDescriptions(value) {
        this._setOption('filterOperationDescriptions', value);
    }
    /**
     * [descr:WidgetOptions.focusStateEnabled]
    
     */
    get focusStateEnabled() {
        return this._getOption('focusStateEnabled');
    }
    set focusStateEnabled(value) {
        this._setOption('focusStateEnabled', value);
    }
    /**
     * [descr:dxFilterBuilderOptions.groupOperationDescriptions]
    
     */
    get groupOperationDescriptions() {
        return this._getOption('groupOperationDescriptions');
    }
    set groupOperationDescriptions(value) {
        this._setOption('groupOperationDescriptions', value);
    }
    /**
     * [descr:dxFilterBuilderOptions.groupOperations]
    
     */
    get groupOperations() {
        return this._getOption('groupOperations');
    }
    set groupOperations(value) {
        this._setOption('groupOperations', value);
    }
    /**
     * [descr:DOMComponentOptions.height]
    
     */
    get height() {
        return this._getOption('height');
    }
    set height(value) {
        this._setOption('height', value);
    }
    /**
     * [descr:WidgetOptions.hint]
    
     */
    get hint() {
        return this._getOption('hint');
    }
    set hint(value) {
        this._setOption('hint', value);
    }
    /**
     * [descr:WidgetOptions.hoverStateEnabled]
    
     */
    get hoverStateEnabled() {
        return this._getOption('hoverStateEnabled');
    }
    set hoverStateEnabled(value) {
        this._setOption('hoverStateEnabled', value);
    }
    /**
     * [descr:dxFilterBuilderOptions.maxGroupLevel]
    
     */
    get maxGroupLevel() {
        return this._getOption('maxGroupLevel');
    }
    set maxGroupLevel(value) {
        this._setOption('maxGroupLevel', value);
    }
    /**
     * [descr:DOMComponentOptions.rtlEnabled]
    
     */
    get rtlEnabled() {
        return this._getOption('rtlEnabled');
    }
    set rtlEnabled(value) {
        this._setOption('rtlEnabled', value);
    }
    /**
     * [descr:WidgetOptions.tabIndex]
    
     */
    get tabIndex() {
        return this._getOption('tabIndex');
    }
    set tabIndex(value) {
        this._setOption('tabIndex', value);
    }
    /**
     * [descr:dxFilterBuilderOptions.value]
    
     */
    get value() {
        return this._getOption('value');
    }
    set value(value) {
        this._setOption('value', value);
    }
    /**
     * [descr:WidgetOptions.visible]
    
     */
    get visible() {
        return this._getOption('visible');
    }
    set visible(value) {
        this._setOption('visible', value);
    }
    /**
     * [descr:DOMComponentOptions.width]
    
     */
    get width() {
        return this._getOption('width');
    }
    set width(value) {
        this._setOption('width', value);
    }
    change(_) { }
    constructor(elementRef, ngZone, templateHost, _watcherHelper, _idh, optionHost, transferState, platformId) {
        super(elementRef, ngZone, templateHost, _watcherHelper, transferState, platformId);
        this._watcherHelper = _watcherHelper;
        this._idh = _idh;
        this.instance = null;
        this.touched = (_) => { };
        this._createEventEmitters([
            { subscribe: 'contentReady', emit: 'onContentReady' },
            { subscribe: 'disposing', emit: 'onDisposing' },
            { subscribe: 'editorPrepared', emit: 'onEditorPrepared' },
            { subscribe: 'editorPreparing', emit: 'onEditorPreparing' },
            { subscribe: 'initialized', emit: 'onInitialized' },
            { subscribe: 'optionChanged', emit: 'onOptionChanged' },
            { subscribe: 'valueChanged', emit: 'onValueChanged' },
            { emit: 'accessKeyChange' },
            { emit: 'activeStateEnabledChange' },
            { emit: 'allowHierarchicalFieldsChange' },
            { emit: 'customOperationsChange' },
            { emit: 'disabledChange' },
            { emit: 'elementAttrChange' },
            { emit: 'fieldsChange' },
            { emit: 'filterOperationDescriptionsChange' },
            { emit: 'focusStateEnabledChange' },
            { emit: 'groupOperationDescriptionsChange' },
            { emit: 'groupOperationsChange' },
            { emit: 'heightChange' },
            { emit: 'hintChange' },
            { emit: 'hoverStateEnabledChange' },
            { emit: 'maxGroupLevelChange' },
            { emit: 'rtlEnabledChange' },
            { emit: 'tabIndexChange' },
            { emit: 'valueChange' },
            { emit: 'visibleChange' },
            { emit: 'widthChange' },
            { emit: 'onBlur' }
        ]);
        this._idh.setHost(this);
        optionHost.setHost(this);
    }
    _createInstance(element, options) {
        return new DxFilterBuilder(element, options);
    }
    writeValue(value) {
        this.eventHelper.lockedValueChangeEvent = true;
        this.value = value;
        this.eventHelper.lockedValueChangeEvent = false;
    }
    setDisabledState(isDisabled) {
        this.disabled = isDisabled;
    }
    registerOnChange(fn) { this.change = fn; }
    registerOnTouched(fn) { this.touched = fn; }
    _createWidget(element) {
        super._createWidget(element);
        this.instance.on('focusOut', (e) => {
            this.eventHelper.fireNgEvent('onBlur', [e]);
        });
    }
    ngOnDestroy() {
        this._destroyWidget();
    }
    ngOnChanges(changes) {
        super.ngOnChanges(changes);
        this.setupChanges('customOperations', changes);
        this.setupChanges('fields', changes);
        this.setupChanges('groupOperations', changes);
        this.setupChanges('value', changes);
    }
    setupChanges(prop, changes) {
        if (!(prop in this._optionsToUpdate)) {
            this._idh.setup(prop, changes);
        }
    }
    ngDoCheck() {
        this._idh.doCheck('customOperations');
        this._idh.doCheck('fields');
        this._idh.doCheck('groupOperations');
        this._idh.doCheck('value');
        this._watcherHelper.checkWatchers();
        super.ngDoCheck();
        super.clearChangedOptions();
    }
    _setOption(name, value) {
        let isSetup = this._idh.setupSingle(name, value);
        let isChanged = this._idh.getChanges(name, value) !== null;
        if (isSetup || isChanged) {
            super._setOption(name, value);
        }
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxFilterBuilderComponent, deps: [{ token: i0.ElementRef }, { token: i0.NgZone }, { token: i1.DxTemplateHost }, { token: i1.WatcherHelper }, { token: i1.IterableDifferHelper }, { token: i1.NestedOptionHost }, { token: i0.TransferState }, { token: PLATFORM_ID }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxFilterBuilderComponent, isStandalone: true, selector: "dx-filter-builder", inputs: { accessKey: "accessKey", activeStateEnabled: "activeStateEnabled", allowHierarchicalFields: "allowHierarchicalFields", customOperations: "customOperations", disabled: "disabled", elementAttr: "elementAttr", fields: "fields", filterOperationDescriptions: "filterOperationDescriptions", focusStateEnabled: "focusStateEnabled", groupOperationDescriptions: "groupOperationDescriptions", groupOperations: "groupOperations", height: "height", hint: "hint", hoverStateEnabled: "hoverStateEnabled", maxGroupLevel: "maxGroupLevel", rtlEnabled: "rtlEnabled", tabIndex: "tabIndex", value: "value", visible: "visible", width: "width" }, outputs: { onContentReady: "onContentReady", onDisposing: "onDisposing", onEditorPrepared: "onEditorPrepared", onEditorPreparing: "onEditorPreparing", onInitialized: "onInitialized", onOptionChanged: "onOptionChanged", onValueChanged: "onValueChanged", accessKeyChange: "accessKeyChange", activeStateEnabledChange: "activeStateEnabledChange", allowHierarchicalFieldsChange: "allowHierarchicalFieldsChange", customOperationsChange: "customOperationsChange", disabledChange: "disabledChange", elementAttrChange: "elementAttrChange", fieldsChange: "fieldsChange", filterOperationDescriptionsChange: "filterOperationDescriptionsChange", focusStateEnabledChange: "focusStateEnabledChange", groupOperationDescriptionsChange: "groupOperationDescriptionsChange", groupOperationsChange: "groupOperationsChange", heightChange: "heightChange", hintChange: "hintChange", hoverStateEnabledChange: "hoverStateEnabledChange", maxGroupLevelChange: "maxGroupLevelChange", rtlEnabledChange: "rtlEnabledChange", tabIndexChange: "tabIndexChange", valueChange: "valueChange", visibleChange: "visibleChange", widthChange: "widthChange", onBlur: "onBlur" }, host: { attributes: { "ngSkipHydration": "true" }, listeners: { "valueChange": "change($event)", "onBlur": "touched($event)" } }, providers: [
            DxTemplateHost,
            WatcherHelper,
            CUSTOM_VALUE_ACCESSOR_PROVIDER,
            NestedOptionHost,
            IterableDifferHelper
        ], queries: [{ propertyName: "_customOperationsContentChildren", predicate: PROPERTY_TOKEN_customOperations }, { propertyName: "_fieldsContentChildren", predicate: PROPERTY_TOKEN_fields }], usesInheritance: true, usesOnChanges: true, ngImport: i0, template: '', isInline: true, dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxFilterBuilderComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'dx-filter-builder',
                    template: '',
                    host: { ngSkipHydration: 'true' },
                    imports: [DxIntegrationModule],
                    providers: [
                        DxTemplateHost,
                        WatcherHelper,
                        CUSTOM_VALUE_ACCESSOR_PROVIDER,
                        NestedOptionHost,
                        IterableDifferHelper
                    ]
                }]
        }], ctorParameters: () => [{ type: i0.ElementRef }, { type: i0.NgZone }, { type: i1.DxTemplateHost }, { type: i1.WatcherHelper }, { type: i1.IterableDifferHelper }, { type: i1.NestedOptionHost }, { type: i0.TransferState }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [PLATFORM_ID]
                }] }], propDecorators: { _customOperationsContentChildren: [{
                type: ContentChildren,
                args: [PROPERTY_TOKEN_customOperations]
            }], _fieldsContentChildren: [{
                type: ContentChildren,
                args: [PROPERTY_TOKEN_fields]
            }], accessKey: [{
                type: Input
            }], activeStateEnabled: [{
                type: Input
            }], allowHierarchicalFields: [{
                type: Input
            }], customOperations: [{
                type: Input
            }], disabled: [{
                type: Input
            }], elementAttr: [{
                type: Input
            }], fields: [{
                type: Input
            }], filterOperationDescriptions: [{
                type: Input
            }], focusStateEnabled: [{
                type: Input
            }], groupOperationDescriptions: [{
                type: Input
            }], groupOperations: [{
                type: Input
            }], height: [{
                type: Input
            }], hint: [{
                type: Input
            }], hoverStateEnabled: [{
                type: Input
            }], maxGroupLevel: [{
                type: Input
            }], rtlEnabled: [{
                type: Input
            }], tabIndex: [{
                type: Input
            }], value: [{
                type: Input
            }], visible: [{
                type: Input
            }], width: [{
                type: Input
            }], onContentReady: [{
                type: Output
            }], onDisposing: [{
                type: Output
            }], onEditorPrepared: [{
                type: Output
            }], onEditorPreparing: [{
                type: Output
            }], onInitialized: [{
                type: Output
            }], onOptionChanged: [{
                type: Output
            }], onValueChanged: [{
                type: Output
            }], accessKeyChange: [{
                type: Output
            }], activeStateEnabledChange: [{
                type: Output
            }], allowHierarchicalFieldsChange: [{
                type: Output
            }], customOperationsChange: [{
                type: Output
            }], disabledChange: [{
                type: Output
            }], elementAttrChange: [{
                type: Output
            }], fieldsChange: [{
                type: Output
            }], filterOperationDescriptionsChange: [{
                type: Output
            }], focusStateEnabledChange: [{
                type: Output
            }], groupOperationDescriptionsChange: [{
                type: Output
            }], groupOperationsChange: [{
                type: Output
            }], heightChange: [{
                type: Output
            }], hintChange: [{
                type: Output
            }], hoverStateEnabledChange: [{
                type: Output
            }], maxGroupLevelChange: [{
                type: Output
            }], rtlEnabledChange: [{
                type: Output
            }], tabIndexChange: [{
                type: Output
            }], valueChange: [{
                type: Output
            }], visibleChange: [{
                type: Output
            }], widthChange: [{
                type: Output
            }], onBlur: [{
                type: Output
            }], change: [{
                type: HostListener,
                args: ['valueChange', ['$event']]
            }], touched: [{
                type: HostListener,
                args: ['onBlur', ['$event']]
            }] } });
class DxFilterBuilderModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxFilterBuilderModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxFilterBuilderModule, imports: [DxFilterBuilderComponent, DxiCustomOperationModule,
            DxiFieldModule,
            DxoFormatModule,
            DxoLookupModule,
            DxoFilterOperationDescriptionsModule,
            DxoGroupOperationDescriptionsModule,
            DxiFilterBuilderCustomOperationModule,
            DxiFilterBuilderFieldModule,
            DxoFilterBuilderFilterOperationDescriptionsModule,
            DxoFilterBuilderFormatModule,
            DxoFilterBuilderGroupOperationDescriptionsModule,
            DxoFilterBuilderLookupModule,
            DxIntegrationModule,
            DxTemplateModule], exports: [DxFilterBuilderComponent, DxiCustomOperationModule,
            DxiFieldModule,
            DxoFormatModule,
            DxoLookupModule,
            DxoFilterOperationDescriptionsModule,
            DxoGroupOperationDescriptionsModule,
            DxiFilterBuilderCustomOperationModule,
            DxiFilterBuilderFieldModule,
            DxoFilterBuilderFilterOperationDescriptionsModule,
            DxoFilterBuilderFormatModule,
            DxoFilterBuilderGroupOperationDescriptionsModule,
            DxoFilterBuilderLookupModule,
            DxTemplateModule] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxFilterBuilderModule, imports: [DxFilterBuilderComponent,
            DxiCustomOperationModule,
            DxiFieldModule,
            DxoFormatModule,
            DxoLookupModule,
            DxoFilterOperationDescriptionsModule,
            DxoGroupOperationDescriptionsModule,
            DxiFilterBuilderCustomOperationModule,
            DxiFilterBuilderFieldModule,
            DxoFilterBuilderFilterOperationDescriptionsModule,
            DxoFilterBuilderFormatModule,
            DxoFilterBuilderGroupOperationDescriptionsModule,
            DxoFilterBuilderLookupModule,
            DxIntegrationModule,
            DxTemplateModule, DxiCustomOperationModule,
            DxiFieldModule,
            DxoFormatModule,
            DxoLookupModule,
            DxoFilterOperationDescriptionsModule,
            DxoGroupOperationDescriptionsModule,
            DxiFilterBuilderCustomOperationModule,
            DxiFilterBuilderFieldModule,
            DxoFilterBuilderFilterOperationDescriptionsModule,
            DxoFilterBuilderFormatModule,
            DxoFilterBuilderGroupOperationDescriptionsModule,
            DxoFilterBuilderLookupModule,
            DxTemplateModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxFilterBuilderModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxFilterBuilderComponent,
                        DxiCustomOperationModule,
                        DxiFieldModule,
                        DxoFormatModule,
                        DxoLookupModule,
                        DxoFilterOperationDescriptionsModule,
                        DxoGroupOperationDescriptionsModule,
                        DxiFilterBuilderCustomOperationModule,
                        DxiFilterBuilderFieldModule,
                        DxoFilterBuilderFilterOperationDescriptionsModule,
                        DxoFilterBuilderFormatModule,
                        DxoFilterBuilderGroupOperationDescriptionsModule,
                        DxoFilterBuilderLookupModule,
                        DxIntegrationModule,
                        DxTemplateModule
                    ],
                    exports: [
                        DxFilterBuilderComponent,
                        DxiCustomOperationModule,
                        DxiFieldModule,
                        DxoFormatModule,
                        DxoLookupModule,
                        DxoFilterOperationDescriptionsModule,
                        DxoGroupOperationDescriptionsModule,
                        DxiFilterBuilderCustomOperationModule,
                        DxiFilterBuilderFieldModule,
                        DxoFilterBuilderFilterOperationDescriptionsModule,
                        DxoFilterBuilderFormatModule,
                        DxoFilterBuilderGroupOperationDescriptionsModule,
                        DxoFilterBuilderLookupModule,
                        DxTemplateModule
                    ]
                }]
        }] });

/**
 * Generated bundle index. Do not edit.
 */

export { DxFilterBuilderComponent, DxFilterBuilderModule };
//# sourceMappingURL=devextreme-angular-ui-filter-builder.mjs.map
