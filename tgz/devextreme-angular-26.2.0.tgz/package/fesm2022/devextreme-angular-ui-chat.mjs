import * as i0 from '@angular/core';
import { PLATFORM_ID, Output, Input, ContentChildren, Inject, Component, NgModule } from '@angular/core';
import DxChat from 'devextreme/ui/chat';
import * as i1 from 'devextreme-angular/core';
import { DxComponent, DxIntegrationModule, DxTemplateHost, WatcherHelper, NestedOptionHost, IterableDifferHelper, DxTemplateModule } from 'devextreme-angular/core';
import { DxiAlertModule, DxoDayHeaderFormatModule, DxoEditingModule, DxiItemModule, DxoAuthorModule, DxoMessageTimestampFormatModule, DxiTypingUserModule, DxoUserModule } from 'devextreme-angular/ui/nested';
import { DxiChatAlertModule, DxiChatAttachmentModule, DxoChatAuthorModule, DxiChatChatItemModule, DxoChatCustomSpeechRecognizerModule, DxoChatDayHeaderFormatModule, DxoChatEditingModule, DxoChatFileUploaderOptionsModule, DxiChatItemModule, DxoChatMessageTimestampFormatModule, DxoChatSendButtonOptionsModule, DxoChatSpeechRecognitionConfigModule, DxoChatSpeechToTextOptionsModule, DxoChatSuggestionsModule, DxiChatSuggestionsItemModule, DxiChatTypingUserModule, DxoChatUserModule } from 'devextreme-angular/ui/chat/nested';
export * from 'devextreme-angular/ui/chat/nested';
import { PROPERTY_TOKEN_alerts, PROPERTY_TOKEN_attachments, PROPERTY_TOKEN_items, PROPERTY_TOKEN_typingUsers } from 'devextreme-angular/core/tokens';

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
/**
 * [descr:dxChat]

 */
class DxChatComponent extends DxComponent {
    set _alertsContentChildren(value) {
        this.setChildren('alerts', value);
    }
    set _attachmentsContentChildren(value) {
        this.setChildren('attachments', value);
    }
    set _itemsContentChildren(value) {
        this.setChildren('items', value);
    }
    set _typingUsersContentChildren(value) {
        this.setChildren('typingUsers', value);
    }
    /**
     * [descr:WidgetOptions.accessKey]
    
     */
    get accessKey() {
        return this._getOption('accessKey');
    }
    set accessKey(value) {
        this._setOption('accessKey', value);
    }
    /**
     * [descr:dxChatOptions.activeStateEnabled]
    
     */
    get activeStateEnabled() {
        return this._getOption('activeStateEnabled');
    }
    set activeStateEnabled(value) {
        this._setOption('activeStateEnabled', value);
    }
    /**
     * [descr:dxChatOptions.alerts]
    
     */
    get alerts() {
        return this._getOption('alerts');
    }
    set alerts(value) {
        this._setOption('alerts', value);
    }
    /**
     * [descr:dxChatOptions.dataSource]
    
     */
    get dataSource() {
        return this._getOption('dataSource');
    }
    set dataSource(value) {
        this._setOption('dataSource', value);
    }
    /**
     * [descr:dxChatOptions.dayHeaderFormat]
    
     */
    get dayHeaderFormat() {
        return this._getOption('dayHeaderFormat');
    }
    set dayHeaderFormat(value) {
        this._setOption('dayHeaderFormat', value);
    }
    /**
     * [descr:WidgetOptions.disabled]
    
     */
    get disabled() {
        return this._getOption('disabled');
    }
    set disabled(value) {
        this._setOption('disabled', value);
    }
    /**
     * [descr:dxChatOptions.editing]
    
     */
    get editing() {
        return this._getOption('editing');
    }
    set editing(value) {
        this._setOption('editing', value);
    }
    /**
     * [descr:DOMComponentOptions.elementAttr]
    
     */
    get elementAttr() {
        return this._getOption('elementAttr');
    }
    set elementAttr(value) {
        this._setOption('elementAttr', value);
    }
    /**
     * [descr:dxChatOptions.emptyViewTemplate]
    
     */
    get emptyViewTemplate() {
        return this._getOption('emptyViewTemplate');
    }
    set emptyViewTemplate(value) {
        this._setOption('emptyViewTemplate', value);
    }
    get fileUploaderOptions() {
        return this._getOption('fileUploaderOptions');
    }
    set fileUploaderOptions(value) {
        this._setOption('fileUploaderOptions', value);
    }
    /**
     * [descr:dxChatOptions.focusStateEnabled]
    
     */
    get focusStateEnabled() {
        return this._getOption('focusStateEnabled');
    }
    set focusStateEnabled(value) {
        this._setOption('focusStateEnabled', value);
    }
    /**
     * [descr:DOMComponentOptions.height]
    
     */
    get height() {
        return this._getOption('height');
    }
    set height(value) {
        this._setOption('height', value);
    }
    /**
     * [descr:WidgetOptions.hint]
    
     */
    get hint() {
        return this._getOption('hint');
    }
    set hint(value) {
        this._setOption('hint', value);
    }
    /**
     * [descr:dxChatOptions.hoverStateEnabled]
    
     */
    get hoverStateEnabled() {
        return this._getOption('hoverStateEnabled');
    }
    set hoverStateEnabled(value) {
        this._setOption('hoverStateEnabled', value);
    }
    get inputFieldText() {
        return this._getOption('inputFieldText');
    }
    set inputFieldText(value) {
        this._setOption('inputFieldText', value);
    }
    /**
     * [descr:dxChatOptions.items]
    
     */
    get items() {
        return this._getOption('items');
    }
    set items(value) {
        this._setOption('items', value);
    }
    /**
     * [descr:dxChatOptions.messageTemplate]
    
     */
    get messageTemplate() {
        return this._getOption('messageTemplate');
    }
    set messageTemplate(value) {
        this._setOption('messageTemplate', value);
    }
    /**
     * [descr:dxChatOptions.messageTimestampFormat]
    
     */
    get messageTimestampFormat() {
        return this._getOption('messageTimestampFormat');
    }
    set messageTimestampFormat(value) {
        this._setOption('messageTimestampFormat', value);
    }
    /**
     * [descr:dxChatOptions.reloadOnChange]
    
     */
    get reloadOnChange() {
        return this._getOption('reloadOnChange');
    }
    set reloadOnChange(value) {
        this._setOption('reloadOnChange', value);
    }
    /**
     * [descr:DOMComponentOptions.rtlEnabled]
    
     */
    get rtlEnabled() {
        return this._getOption('rtlEnabled');
    }
    set rtlEnabled(value) {
        this._setOption('rtlEnabled', value);
    }
    get sendButtonOptions() {
        return this._getOption('sendButtonOptions');
    }
    set sendButtonOptions(value) {
        this._setOption('sendButtonOptions', value);
    }
    /**
     * [descr:dxChatOptions.showAvatar]
    
     */
    get showAvatar() {
        return this._getOption('showAvatar');
    }
    set showAvatar(value) {
        this._setOption('showAvatar', value);
    }
    /**
     * [descr:dxChatOptions.showDayHeaders]
    
     */
    get showDayHeaders() {
        return this._getOption('showDayHeaders');
    }
    set showDayHeaders(value) {
        this._setOption('showDayHeaders', value);
    }
    /**
     * [descr:dxChatOptions.showMessageTimestamp]
    
     */
    get showMessageTimestamp() {
        return this._getOption('showMessageTimestamp');
    }
    set showMessageTimestamp(value) {
        this._setOption('showMessageTimestamp', value);
    }
    /**
     * [descr:dxChatOptions.showUserName]
    
     */
    get showUserName() {
        return this._getOption('showUserName');
    }
    set showUserName(value) {
        this._setOption('showUserName', value);
    }
    /**
     * [descr:dxChatOptions.speechToTextEnabled]
    
     */
    get speechToTextEnabled() {
        return this._getOption('speechToTextEnabled');
    }
    set speechToTextEnabled(value) {
        this._setOption('speechToTextEnabled', value);
    }
    get speechToTextOptions() {
        return this._getOption('speechToTextOptions');
    }
    set speechToTextOptions(value) {
        this._setOption('speechToTextOptions', value);
    }
    get suggestions() {
        return this._getOption('suggestions');
    }
    set suggestions(value) {
        this._setOption('suggestions', value);
    }
    /**
     * [descr:dxChatOptions.typingUsers]
    
     */
    get typingUsers() {
        return this._getOption('typingUsers');
    }
    set typingUsers(value) {
        this._setOption('typingUsers', value);
    }
    /**
     * [descr:dxChatOptions.user]
    
     */
    get user() {
        return this._getOption('user');
    }
    set user(value) {
        this._setOption('user', value);
    }
    /**
     * [descr:WidgetOptions.visible]
    
     */
    get visible() {
        return this._getOption('visible');
    }
    set visible(value) {
        this._setOption('visible', value);
    }
    /**
     * [descr:DOMComponentOptions.width]
    
     */
    get width() {
        return this._getOption('width');
    }
    set width(value) {
        this._setOption('width', value);
    }
    constructor(elementRef, ngZone, templateHost, _watcherHelper, _idh, optionHost, transferState, platformId) {
        super(elementRef, ngZone, templateHost, _watcherHelper, transferState, platformId);
        this._watcherHelper = _watcherHelper;
        this._idh = _idh;
        this.instance = null;
        this._createEventEmitters([
            { subscribe: 'attachmentDownloadClick', emit: 'onAttachmentDownloadClick' },
            { subscribe: 'disposing', emit: 'onDisposing' },
            { subscribe: 'initialized', emit: 'onInitialized' },
            { subscribe: 'inputFieldTextChanged', emit: 'onInputFieldTextChanged' },
            { subscribe: 'messageDeleted', emit: 'onMessageDeleted' },
            { subscribe: 'messageDeleting', emit: 'onMessageDeleting' },
            { subscribe: 'messageEditCanceled', emit: 'onMessageEditCanceled' },
            { subscribe: 'messageEditingStart', emit: 'onMessageEditingStart' },
            { subscribe: 'messageEntered', emit: 'onMessageEntered' },
            { subscribe: 'messageUpdated', emit: 'onMessageUpdated' },
            { subscribe: 'messageUpdating', emit: 'onMessageUpdating' },
            { subscribe: 'optionChanged', emit: 'onOptionChanged' },
            { subscribe: 'typingEnd', emit: 'onTypingEnd' },
            { subscribe: 'typingStart', emit: 'onTypingStart' },
            { emit: 'accessKeyChange' },
            { emit: 'activeStateEnabledChange' },
            { emit: 'alertsChange' },
            { emit: 'dataSourceChange' },
            { emit: 'dayHeaderFormatChange' },
            { emit: 'disabledChange' },
            { emit: 'editingChange' },
            { emit: 'elementAttrChange' },
            { emit: 'emptyViewTemplateChange' },
            { emit: 'fileUploaderOptionsChange' },
            { emit: 'focusStateEnabledChange' },
            { emit: 'heightChange' },
            { emit: 'hintChange' },
            { emit: 'hoverStateEnabledChange' },
            { emit: 'inputFieldTextChange' },
            { emit: 'itemsChange' },
            { emit: 'messageTemplateChange' },
            { emit: 'messageTimestampFormatChange' },
            { emit: 'reloadOnChangeChange' },
            { emit: 'rtlEnabledChange' },
            { emit: 'sendButtonOptionsChange' },
            { emit: 'showAvatarChange' },
            { emit: 'showDayHeadersChange' },
            { emit: 'showMessageTimestampChange' },
            { emit: 'showUserNameChange' },
            { emit: 'speechToTextEnabledChange' },
            { emit: 'speechToTextOptionsChange' },
            { emit: 'suggestionsChange' },
            { emit: 'typingUsersChange' },
            { emit: 'userChange' },
            { emit: 'visibleChange' },
            { emit: 'widthChange' }
        ]);
        this._idh.setHost(this);
        optionHost.setHost(this);
    }
    _createInstance(element, options) {
        return new DxChat(element, options);
    }
    ngOnDestroy() {
        this._destroyWidget();
    }
    ngOnChanges(changes) {
        super.ngOnChanges(changes);
        this.setupChanges('alerts', changes);
        this.setupChanges('dataSource', changes);
        this.setupChanges('items', changes);
        this.setupChanges('typingUsers', changes);
    }
    setupChanges(prop, changes) {
        if (!(prop in this._optionsToUpdate)) {
            this._idh.setup(prop, changes);
        }
    }
    ngDoCheck() {
        this._idh.doCheck('alerts');
        this._idh.doCheck('dataSource');
        this._idh.doCheck('items');
        this._idh.doCheck('typingUsers');
        this._watcherHelper.checkWatchers();
        super.ngDoCheck();
        super.clearChangedOptions();
    }
    _setOption(name, value) {
        let isSetup = this._idh.setupSingle(name, value);
        let isChanged = this._idh.getChanges(name, value) !== null;
        if (isSetup || isChanged) {
            super._setOption(name, value);
        }
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxChatComponent, deps: [{ token: i0.ElementRef }, { token: i0.NgZone }, { token: i1.DxTemplateHost }, { token: i1.WatcherHelper }, { token: i1.IterableDifferHelper }, { token: i1.NestedOptionHost }, { token: i0.TransferState }, { token: PLATFORM_ID }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxChatComponent, isStandalone: true, selector: "dx-chat", inputs: { accessKey: "accessKey", activeStateEnabled: "activeStateEnabled", alerts: "alerts", dataSource: "dataSource", dayHeaderFormat: "dayHeaderFormat", disabled: "disabled", editing: "editing", elementAttr: "elementAttr", emptyViewTemplate: "emptyViewTemplate", fileUploaderOptions: "fileUploaderOptions", focusStateEnabled: "focusStateEnabled", height: "height", hint: "hint", hoverStateEnabled: "hoverStateEnabled", inputFieldText: "inputFieldText", items: "items", messageTemplate: "messageTemplate", messageTimestampFormat: "messageTimestampFormat", reloadOnChange: "reloadOnChange", rtlEnabled: "rtlEnabled", sendButtonOptions: "sendButtonOptions", showAvatar: "showAvatar", showDayHeaders: "showDayHeaders", showMessageTimestamp: "showMessageTimestamp", showUserName: "showUserName", speechToTextEnabled: "speechToTextEnabled", speechToTextOptions: "speechToTextOptions", suggestions: "suggestions", typingUsers: "typingUsers", user: "user", visible: "visible", width: "width" }, outputs: { onAttachmentDownloadClick: "onAttachmentDownloadClick", onDisposing: "onDisposing", onInitialized: "onInitialized", onInputFieldTextChanged: "onInputFieldTextChanged", onMessageDeleted: "onMessageDeleted", onMessageDeleting: "onMessageDeleting", onMessageEditCanceled: "onMessageEditCanceled", onMessageEditingStart: "onMessageEditingStart", onMessageEntered: "onMessageEntered", onMessageUpdated: "onMessageUpdated", onMessageUpdating: "onMessageUpdating", onOptionChanged: "onOptionChanged", onTypingEnd: "onTypingEnd", onTypingStart: "onTypingStart", accessKeyChange: "accessKeyChange", activeStateEnabledChange: "activeStateEnabledChange", alertsChange: "alertsChange", dataSourceChange: "dataSourceChange", dayHeaderFormatChange: "dayHeaderFormatChange", disabledChange: "disabledChange", editingChange: "editingChange", elementAttrChange: "elementAttrChange", emptyViewTemplateChange: "emptyViewTemplateChange", fileUploaderOptionsChange: "fileUploaderOptionsChange", focusStateEnabledChange: "focusStateEnabledChange", heightChange: "heightChange", hintChange: "hintChange", hoverStateEnabledChange: "hoverStateEnabledChange", inputFieldTextChange: "inputFieldTextChange", itemsChange: "itemsChange", messageTemplateChange: "messageTemplateChange", messageTimestampFormatChange: "messageTimestampFormatChange", reloadOnChangeChange: "reloadOnChangeChange", rtlEnabledChange: "rtlEnabledChange", sendButtonOptionsChange: "sendButtonOptionsChange", showAvatarChange: "showAvatarChange", showDayHeadersChange: "showDayHeadersChange", showMessageTimestampChange: "showMessageTimestampChange", showUserNameChange: "showUserNameChange", speechToTextEnabledChange: "speechToTextEnabledChange", speechToTextOptionsChange: "speechToTextOptionsChange", suggestionsChange: "suggestionsChange", typingUsersChange: "typingUsersChange", userChange: "userChange", visibleChange: "visibleChange", widthChange: "widthChange" }, host: { attributes: { "ngSkipHydration": "true" } }, providers: [
            DxTemplateHost,
            WatcherHelper,
            NestedOptionHost,
            IterableDifferHelper
        ], queries: [{ propertyName: "_alertsContentChildren", predicate: PROPERTY_TOKEN_alerts }, { propertyName: "_attachmentsContentChildren", predicate: PROPERTY_TOKEN_attachments }, { propertyName: "_itemsContentChildren", predicate: PROPERTY_TOKEN_items }, { propertyName: "_typingUsersContentChildren", predicate: PROPERTY_TOKEN_typingUsers }], usesInheritance: true, usesOnChanges: true, ngImport: i0, template: '', isInline: true, dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxChatComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'dx-chat',
                    template: '',
                    host: { ngSkipHydration: 'true' },
                    imports: [DxIntegrationModule],
                    providers: [
                        DxTemplateHost,
                        WatcherHelper,
                        NestedOptionHost,
                        IterableDifferHelper
                    ]
                }]
        }], ctorParameters: () => [{ type: i0.ElementRef }, { type: i0.NgZone }, { type: i1.DxTemplateHost }, { type: i1.WatcherHelper }, { type: i1.IterableDifferHelper }, { type: i1.NestedOptionHost }, { type: i0.TransferState }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [PLATFORM_ID]
                }] }], propDecorators: { _alertsContentChildren: [{
                type: ContentChildren,
                args: [PROPERTY_TOKEN_alerts]
            }], _attachmentsContentChildren: [{
                type: ContentChildren,
                args: [PROPERTY_TOKEN_attachments]
            }], _itemsContentChildren: [{
                type: ContentChildren,
                args: [PROPERTY_TOKEN_items]
            }], _typingUsersContentChildren: [{
                type: ContentChildren,
                args: [PROPERTY_TOKEN_typingUsers]
            }], accessKey: [{
                type: Input
            }], activeStateEnabled: [{
                type: Input
            }], alerts: [{
                type: Input
            }], dataSource: [{
                type: Input
            }], dayHeaderFormat: [{
                type: Input
            }], disabled: [{
                type: Input
            }], editing: [{
                type: Input
            }], elementAttr: [{
                type: Input
            }], emptyViewTemplate: [{
                type: Input
            }], fileUploaderOptions: [{
                type: Input
            }], focusStateEnabled: [{
                type: Input
            }], height: [{
                type: Input
            }], hint: [{
                type: Input
            }], hoverStateEnabled: [{
                type: Input
            }], inputFieldText: [{
                type: Input
            }], items: [{
                type: Input
            }], messageTemplate: [{
                type: Input
            }], messageTimestampFormat: [{
                type: Input
            }], reloadOnChange: [{
                type: Input
            }], rtlEnabled: [{
                type: Input
            }], sendButtonOptions: [{
                type: Input
            }], showAvatar: [{
                type: Input
            }], showDayHeaders: [{
                type: Input
            }], showMessageTimestamp: [{
                type: Input
            }], showUserName: [{
                type: Input
            }], speechToTextEnabled: [{
                type: Input
            }], speechToTextOptions: [{
                type: Input
            }], suggestions: [{
                type: Input
            }], typingUsers: [{
                type: Input
            }], user: [{
                type: Input
            }], visible: [{
                type: Input
            }], width: [{
                type: Input
            }], onAttachmentDownloadClick: [{
                type: Output
            }], onDisposing: [{
                type: Output
            }], onInitialized: [{
                type: Output
            }], onInputFieldTextChanged: [{
                type: Output
            }], onMessageDeleted: [{
                type: Output
            }], onMessageDeleting: [{
                type: Output
            }], onMessageEditCanceled: [{
                type: Output
            }], onMessageEditingStart: [{
                type: Output
            }], onMessageEntered: [{
                type: Output
            }], onMessageUpdated: [{
                type: Output
            }], onMessageUpdating: [{
                type: Output
            }], onOptionChanged: [{
                type: Output
            }], onTypingEnd: [{
                type: Output
            }], onTypingStart: [{
                type: Output
            }], accessKeyChange: [{
                type: Output
            }], activeStateEnabledChange: [{
                type: Output
            }], alertsChange: [{
                type: Output
            }], dataSourceChange: [{
                type: Output
            }], dayHeaderFormatChange: [{
                type: Output
            }], disabledChange: [{
                type: Output
            }], editingChange: [{
                type: Output
            }], elementAttrChange: [{
                type: Output
            }], emptyViewTemplateChange: [{
                type: Output
            }], fileUploaderOptionsChange: [{
                type: Output
            }], focusStateEnabledChange: [{
                type: Output
            }], heightChange: [{
                type: Output
            }], hintChange: [{
                type: Output
            }], hoverStateEnabledChange: [{
                type: Output
            }], inputFieldTextChange: [{
                type: Output
            }], itemsChange: [{
                type: Output
            }], messageTemplateChange: [{
                type: Output
            }], messageTimestampFormatChange: [{
                type: Output
            }], reloadOnChangeChange: [{
                type: Output
            }], rtlEnabledChange: [{
                type: Output
            }], sendButtonOptionsChange: [{
                type: Output
            }], showAvatarChange: [{
                type: Output
            }], showDayHeadersChange: [{
                type: Output
            }], showMessageTimestampChange: [{
                type: Output
            }], showUserNameChange: [{
                type: Output
            }], speechToTextEnabledChange: [{
                type: Output
            }], speechToTextOptionsChange: [{
                type: Output
            }], suggestionsChange: [{
                type: Output
            }], typingUsersChange: [{
                type: Output
            }], userChange: [{
                type: Output
            }], visibleChange: [{
                type: Output
            }], widthChange: [{
                type: Output
            }] } });
class DxChatModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxChatModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxChatModule, imports: [DxChatComponent, DxiAlertModule,
            DxoDayHeaderFormatModule,
            DxoEditingModule,
            DxiItemModule,
            DxoAuthorModule,
            DxoMessageTimestampFormatModule,
            DxiTypingUserModule,
            DxoUserModule,
            DxiChatAlertModule,
            DxiChatAttachmentModule,
            DxoChatAuthorModule,
            DxiChatChatItemModule,
            DxoChatCustomSpeechRecognizerModule,
            DxoChatDayHeaderFormatModule,
            DxoChatEditingModule,
            DxoChatFileUploaderOptionsModule,
            DxiChatItemModule,
            DxoChatMessageTimestampFormatModule,
            DxoChatSendButtonOptionsModule,
            DxoChatSpeechRecognitionConfigModule,
            DxoChatSpeechToTextOptionsModule,
            DxoChatSuggestionsModule,
            DxiChatSuggestionsItemModule,
            DxiChatTypingUserModule,
            DxoChatUserModule,
            DxIntegrationModule,
            DxTemplateModule], exports: [DxChatComponent, DxiAlertModule,
            DxoDayHeaderFormatModule,
            DxoEditingModule,
            DxiItemModule,
            DxoAuthorModule,
            DxoMessageTimestampFormatModule,
            DxiTypingUserModule,
            DxoUserModule,
            DxiChatAlertModule,
            DxiChatAttachmentModule,
            DxoChatAuthorModule,
            DxiChatChatItemModule,
            DxoChatCustomSpeechRecognizerModule,
            DxoChatDayHeaderFormatModule,
            DxoChatEditingModule,
            DxoChatFileUploaderOptionsModule,
            DxiChatItemModule,
            DxoChatMessageTimestampFormatModule,
            DxoChatSendButtonOptionsModule,
            DxoChatSpeechRecognitionConfigModule,
            DxoChatSpeechToTextOptionsModule,
            DxoChatSuggestionsModule,
            DxiChatSuggestionsItemModule,
            DxiChatTypingUserModule,
            DxoChatUserModule,
            DxTemplateModule] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxChatModule, imports: [DxChatComponent,
            DxiAlertModule,
            DxoDayHeaderFormatModule,
            DxoEditingModule,
            DxiItemModule,
            DxoAuthorModule,
            DxoMessageTimestampFormatModule,
            DxiTypingUserModule,
            DxoUserModule,
            DxiChatAlertModule,
            DxiChatAttachmentModule,
            DxoChatAuthorModule,
            DxiChatChatItemModule,
            DxoChatCustomSpeechRecognizerModule,
            DxoChatDayHeaderFormatModule,
            DxoChatEditingModule,
            DxoChatFileUploaderOptionsModule,
            DxiChatItemModule,
            DxoChatMessageTimestampFormatModule,
            DxoChatSendButtonOptionsModule,
            DxoChatSpeechRecognitionConfigModule,
            DxoChatSpeechToTextOptionsModule,
            DxoChatSuggestionsModule,
            DxiChatSuggestionsItemModule,
            DxiChatTypingUserModule,
            DxoChatUserModule,
            DxIntegrationModule,
            DxTemplateModule, DxiAlertModule,
            DxoDayHeaderFormatModule,
            DxoEditingModule,
            DxiItemModule,
            DxoAuthorModule,
            DxoMessageTimestampFormatModule,
            DxiTypingUserModule,
            DxoUserModule,
            DxiChatAlertModule,
            DxiChatAttachmentModule,
            DxoChatAuthorModule,
            DxiChatChatItemModule,
            DxoChatCustomSpeechRecognizerModule,
            DxoChatDayHeaderFormatModule,
            DxoChatEditingModule,
            DxoChatFileUploaderOptionsModule,
            DxiChatItemModule,
            DxoChatMessageTimestampFormatModule,
            DxoChatSendButtonOptionsModule,
            DxoChatSpeechRecognitionConfigModule,
            DxoChatSpeechToTextOptionsModule,
            DxoChatSuggestionsModule,
            DxiChatSuggestionsItemModule,
            DxiChatTypingUserModule,
            DxoChatUserModule,
            DxTemplateModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxChatModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxChatComponent,
                        DxiAlertModule,
                        DxoDayHeaderFormatModule,
                        DxoEditingModule,
                        DxiItemModule,
                        DxoAuthorModule,
                        DxoMessageTimestampFormatModule,
                        DxiTypingUserModule,
                        DxoUserModule,
                        DxiChatAlertModule,
                        DxiChatAttachmentModule,
                        DxoChatAuthorModule,
                        DxiChatChatItemModule,
                        DxoChatCustomSpeechRecognizerModule,
                        DxoChatDayHeaderFormatModule,
                        DxoChatEditingModule,
                        DxoChatFileUploaderOptionsModule,
                        DxiChatItemModule,
                        DxoChatMessageTimestampFormatModule,
                        DxoChatSendButtonOptionsModule,
                        DxoChatSpeechRecognitionConfigModule,
                        DxoChatSpeechToTextOptionsModule,
                        DxoChatSuggestionsModule,
                        DxiChatSuggestionsItemModule,
                        DxiChatTypingUserModule,
                        DxoChatUserModule,
                        DxIntegrationModule,
                        DxTemplateModule
                    ],
                    exports: [
                        DxChatComponent,
                        DxiAlertModule,
                        DxoDayHeaderFormatModule,
                        DxoEditingModule,
                        DxiItemModule,
                        DxoAuthorModule,
                        DxoMessageTimestampFormatModule,
                        DxiTypingUserModule,
                        DxoUserModule,
                        DxiChatAlertModule,
                        DxiChatAttachmentModule,
                        DxoChatAuthorModule,
                        DxiChatChatItemModule,
                        DxoChatCustomSpeechRecognizerModule,
                        DxoChatDayHeaderFormatModule,
                        DxoChatEditingModule,
                        DxoChatFileUploaderOptionsModule,
                        DxiChatItemModule,
                        DxoChatMessageTimestampFormatModule,
                        DxoChatSendButtonOptionsModule,
                        DxoChatSpeechRecognitionConfigModule,
                        DxoChatSpeechToTextOptionsModule,
                        DxoChatSuggestionsModule,
                        DxiChatSuggestionsItemModule,
                        DxiChatTypingUserModule,
                        DxoChatUserModule,
                        DxTemplateModule
                    ]
                }]
        }] });

/**
 * Generated bundle index. Do not edit.
 */

export { DxChatComponent, DxChatModule };
//# sourceMappingURL=devextreme-angular-ui-chat.mjs.map
