import * as i0 from '@angular/core';
import { Input, SkipSelf, Host, Component, NgModule } from '@angular/core';
import * as i1 from 'devextreme-angular/core';
import { NestedOption, DxIntegrationModule, NestedOptionHost } from 'devextreme-angular/core';

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoPivotGridFieldChooserHeaderFilterTextsComponent extends NestedOption {
    get cancel() {
        return this._getOption('cancel');
    }
    set cancel(value) {
        this._setOption('cancel', value);
    }
    get emptyValue() {
        return this._getOption('emptyValue');
    }
    set emptyValue(value) {
        this._setOption('emptyValue', value);
    }
    get ok() {
        return this._getOption('ok');
    }
    set ok(value) {
        this._setOption('ok', value);
    }
    get _optionPath() {
        return 'texts';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoPivotGridFieldChooserHeaderFilterTextsComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoPivotGridFieldChooserHeaderFilterTextsComponent, isStandalone: true, selector: "dxo-pivot-grid-field-chooser-header-filter-texts", inputs: { cancel: "cancel", emptyValue: "emptyValue", ok: "ok" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoPivotGridFieldChooserHeaderFilterTextsComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-pivot-grid-field-chooser-header-filter-texts', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { cancel: [{
                type: Input
            }], emptyValue: [{
                type: Input
            }], ok: [{
                type: Input
            }] } });
class DxoPivotGridFieldChooserHeaderFilterTextsModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoPivotGridFieldChooserHeaderFilterTextsModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoPivotGridFieldChooserHeaderFilterTextsModule, imports: [DxoPivotGridFieldChooserHeaderFilterTextsComponent], exports: [DxoPivotGridFieldChooserHeaderFilterTextsComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoPivotGridFieldChooserHeaderFilterTextsModule, imports: [DxoPivotGridFieldChooserHeaderFilterTextsComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoPivotGridFieldChooserHeaderFilterTextsModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoPivotGridFieldChooserHeaderFilterTextsComponent
                    ],
                    exports: [
                        DxoPivotGridFieldChooserHeaderFilterTextsComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoPivotGridFieldChooserHeaderFilterComponent extends NestedOption {
    get allowSearch() {
        return this._getOption('allowSearch');
    }
    set allowSearch(value) {
        this._setOption('allowSearch', value);
    }
    get allowSelectAll() {
        return this._getOption('allowSelectAll');
    }
    set allowSelectAll(value) {
        this._setOption('allowSelectAll', value);
    }
    get height() {
        return this._getOption('height');
    }
    set height(value) {
        this._setOption('height', value);
    }
    get search() {
        return this._getOption('search');
    }
    set search(value) {
        this._setOption('search', value);
    }
    get searchTimeout() {
        return this._getOption('searchTimeout');
    }
    set searchTimeout(value) {
        this._setOption('searchTimeout', value);
    }
    get showRelevantValues() {
        return this._getOption('showRelevantValues');
    }
    set showRelevantValues(value) {
        this._setOption('showRelevantValues', value);
    }
    get texts() {
        return this._getOption('texts');
    }
    set texts(value) {
        this._setOption('texts', value);
    }
    get width() {
        return this._getOption('width');
    }
    set width(value) {
        this._setOption('width', value);
    }
    get _optionPath() {
        return 'headerFilter';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoPivotGridFieldChooserHeaderFilterComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoPivotGridFieldChooserHeaderFilterComponent, isStandalone: true, selector: "dxo-pivot-grid-field-chooser-header-filter", inputs: { allowSearch: "allowSearch", allowSelectAll: "allowSelectAll", height: "height", search: "search", searchTimeout: "searchTimeout", showRelevantValues: "showRelevantValues", texts: "texts", width: "width" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoPivotGridFieldChooserHeaderFilterComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-pivot-grid-field-chooser-header-filter', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { allowSearch: [{
                type: Input
            }], allowSelectAll: [{
                type: Input
            }], height: [{
                type: Input
            }], search: [{
                type: Input
            }], searchTimeout: [{
                type: Input
            }], showRelevantValues: [{
                type: Input
            }], texts: [{
                type: Input
            }], width: [{
                type: Input
            }] } });
class DxoPivotGridFieldChooserHeaderFilterModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoPivotGridFieldChooserHeaderFilterModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoPivotGridFieldChooserHeaderFilterModule, imports: [DxoPivotGridFieldChooserHeaderFilterComponent], exports: [DxoPivotGridFieldChooserHeaderFilterComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoPivotGridFieldChooserHeaderFilterModule, imports: [DxoPivotGridFieldChooserHeaderFilterComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoPivotGridFieldChooserHeaderFilterModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoPivotGridFieldChooserHeaderFilterComponent
                    ],
                    exports: [
                        DxoPivotGridFieldChooserHeaderFilterComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoPivotGridFieldChooserPivotGridFieldChooserTextsComponent extends NestedOption {
    get allFields() {
        return this._getOption('allFields');
    }
    set allFields(value) {
        this._setOption('allFields', value);
    }
    get columnFields() {
        return this._getOption('columnFields');
    }
    set columnFields(value) {
        this._setOption('columnFields', value);
    }
    get dataFields() {
        return this._getOption('dataFields');
    }
    set dataFields(value) {
        this._setOption('dataFields', value);
    }
    get filterFields() {
        return this._getOption('filterFields');
    }
    set filterFields(value) {
        this._setOption('filterFields', value);
    }
    get rowFields() {
        return this._getOption('rowFields');
    }
    set rowFields(value) {
        this._setOption('rowFields', value);
    }
    get _optionPath() {
        return 'texts';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoPivotGridFieldChooserPivotGridFieldChooserTextsComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoPivotGridFieldChooserPivotGridFieldChooserTextsComponent, isStandalone: true, selector: "dxo-pivot-grid-field-chooser-pivot-grid-field-chooser-texts", inputs: { allFields: "allFields", columnFields: "columnFields", dataFields: "dataFields", filterFields: "filterFields", rowFields: "rowFields" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoPivotGridFieldChooserPivotGridFieldChooserTextsComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-pivot-grid-field-chooser-pivot-grid-field-chooser-texts', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { allFields: [{
                type: Input
            }], columnFields: [{
                type: Input
            }], dataFields: [{
                type: Input
            }], filterFields: [{
                type: Input
            }], rowFields: [{
                type: Input
            }] } });
class DxoPivotGridFieldChooserPivotGridFieldChooserTextsModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoPivotGridFieldChooserPivotGridFieldChooserTextsModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoPivotGridFieldChooserPivotGridFieldChooserTextsModule, imports: [DxoPivotGridFieldChooserPivotGridFieldChooserTextsComponent], exports: [DxoPivotGridFieldChooserPivotGridFieldChooserTextsComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoPivotGridFieldChooserPivotGridFieldChooserTextsModule, imports: [DxoPivotGridFieldChooserPivotGridFieldChooserTextsComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoPivotGridFieldChooserPivotGridFieldChooserTextsModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoPivotGridFieldChooserPivotGridFieldChooserTextsComponent
                    ],
                    exports: [
                        DxoPivotGridFieldChooserPivotGridFieldChooserTextsComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoPivotGridFieldChooserSearchComponent extends NestedOption {
    get editorOptions() {
        return this._getOption('editorOptions');
    }
    set editorOptions(value) {
        this._setOption('editorOptions', value);
    }
    get enabled() {
        return this._getOption('enabled');
    }
    set enabled(value) {
        this._setOption('enabled', value);
    }
    get mode() {
        return this._getOption('mode');
    }
    set mode(value) {
        this._setOption('mode', value);
    }
    get timeout() {
        return this._getOption('timeout');
    }
    set timeout(value) {
        this._setOption('timeout', value);
    }
    get _optionPath() {
        return 'search';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoPivotGridFieldChooserSearchComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoPivotGridFieldChooserSearchComponent, isStandalone: true, selector: "dxo-pivot-grid-field-chooser-search", inputs: { editorOptions: "editorOptions", enabled: "enabled", mode: "mode", timeout: "timeout" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoPivotGridFieldChooserSearchComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-pivot-grid-field-chooser-search', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { editorOptions: [{
                type: Input
            }], enabled: [{
                type: Input
            }], mode: [{
                type: Input
            }], timeout: [{
                type: Input
            }] } });
class DxoPivotGridFieldChooserSearchModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoPivotGridFieldChooserSearchModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoPivotGridFieldChooserSearchModule, imports: [DxoPivotGridFieldChooserSearchComponent], exports: [DxoPivotGridFieldChooserSearchComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoPivotGridFieldChooserSearchModule, imports: [DxoPivotGridFieldChooserSearchComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoPivotGridFieldChooserSearchModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoPivotGridFieldChooserSearchComponent
                    ],
                    exports: [
                        DxoPivotGridFieldChooserSearchComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoPivotGridFieldChooserTextsComponent extends NestedOption {
    get cancel() {
        return this._getOption('cancel');
    }
    set cancel(value) {
        this._setOption('cancel', value);
    }
    get emptyValue() {
        return this._getOption('emptyValue');
    }
    set emptyValue(value) {
        this._setOption('emptyValue', value);
    }
    get ok() {
        return this._getOption('ok');
    }
    set ok(value) {
        this._setOption('ok', value);
    }
    get allFields() {
        return this._getOption('allFields');
    }
    set allFields(value) {
        this._setOption('allFields', value);
    }
    get columnFields() {
        return this._getOption('columnFields');
    }
    set columnFields(value) {
        this._setOption('columnFields', value);
    }
    get dataFields() {
        return this._getOption('dataFields');
    }
    set dataFields(value) {
        this._setOption('dataFields', value);
    }
    get filterFields() {
        return this._getOption('filterFields');
    }
    set filterFields(value) {
        this._setOption('filterFields', value);
    }
    get rowFields() {
        return this._getOption('rowFields');
    }
    set rowFields(value) {
        this._setOption('rowFields', value);
    }
    get _optionPath() {
        return 'texts';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoPivotGridFieldChooserTextsComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoPivotGridFieldChooserTextsComponent, isStandalone: true, selector: "dxo-pivot-grid-field-chooser-texts", inputs: { cancel: "cancel", emptyValue: "emptyValue", ok: "ok", allFields: "allFields", columnFields: "columnFields", dataFields: "dataFields", filterFields: "filterFields", rowFields: "rowFields" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoPivotGridFieldChooserTextsComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-pivot-grid-field-chooser-texts', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { cancel: [{
                type: Input
            }], emptyValue: [{
                type: Input
            }], ok: [{
                type: Input
            }], allFields: [{
                type: Input
            }], columnFields: [{
                type: Input
            }], dataFields: [{
                type: Input
            }], filterFields: [{
                type: Input
            }], rowFields: [{
                type: Input
            }] } });
class DxoPivotGridFieldChooserTextsModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoPivotGridFieldChooserTextsModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoPivotGridFieldChooserTextsModule, imports: [DxoPivotGridFieldChooserTextsComponent], exports: [DxoPivotGridFieldChooserTextsComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoPivotGridFieldChooserTextsModule, imports: [DxoPivotGridFieldChooserTextsComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoPivotGridFieldChooserTextsModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoPivotGridFieldChooserTextsComponent
                    ],
                    exports: [
                        DxoPivotGridFieldChooserTextsComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

/**
 * Generated bundle index. Do not edit.
 */

export { DxoPivotGridFieldChooserHeaderFilterComponent, DxoPivotGridFieldChooserHeaderFilterModule, DxoPivotGridFieldChooserHeaderFilterTextsComponent, DxoPivotGridFieldChooserHeaderFilterTextsModule, DxoPivotGridFieldChooserPivotGridFieldChooserTextsComponent, DxoPivotGridFieldChooserPivotGridFieldChooserTextsModule, DxoPivotGridFieldChooserSearchComponent, DxoPivotGridFieldChooserSearchModule, DxoPivotGridFieldChooserTextsComponent, DxoPivotGridFieldChooserTextsModule };
//# sourceMappingURL=devextreme-angular-ui-pivot-grid-field-chooser-nested.mjs.map
