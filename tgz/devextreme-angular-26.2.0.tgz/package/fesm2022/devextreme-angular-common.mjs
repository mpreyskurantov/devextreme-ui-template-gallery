import * as AiIntegrationModule from 'devextreme/common/ai-integration';
import * as ChartsModule from 'devextreme/common/charts';
import * as CoreAnimationModule from 'devextreme/common/core/animation';
import * as CoreEnvironmentModule from 'devextreme/common/core/environment';
import * as CoreEventsModule from 'devextreme/common/core/events';
import * as CoreLocalizationModule from 'devextreme/common/core/localization';
import * as DataModule from 'devextreme/common/data';
import * as ExportExcelModule from 'devextreme/common/export/excel';
import * as ExportPdfModule from 'devextreme/common/export/pdf';
export { Guid, config, setTemplateEngine } from 'devextreme/common';

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
var AiIntegration;
(function (AiIntegration) {
    AiIntegration.AIIntegration = AiIntegrationModule.AIIntegration;
})(AiIntegration || (AiIntegration = {}));
var Charts;
(function (Charts) {
    Charts.registerGradient = ChartsModule.registerGradient;
    Charts.registerPattern = ChartsModule.registerPattern;
})(Charts || (Charts = {}));
var Core;
(function (Core) {
    let Animation;
    (function (Animation) {
        Animation.animationPresets = CoreAnimationModule.animationPresets;
        Animation.cancelAnimationFrame = CoreAnimationModule.cancelAnimationFrame;
        Animation.fx = CoreAnimationModule.fx;
        Animation.requestAnimationFrame = CoreAnimationModule.requestAnimationFrame;
        Animation.TransitionExecutor = CoreAnimationModule.TransitionExecutor;
    })(Animation = Core.Animation || (Core.Animation = {}));
    let Environment;
    (function (Environment) {
        Environment.getTimeZones = CoreEnvironmentModule.getTimeZones;
        Environment.hideTopOverlay = CoreEnvironmentModule.hideTopOverlay;
        Environment.initMobileViewport = CoreEnvironmentModule.initMobileViewport;
    })(Environment = Core.Environment || (Core.Environment = {}));
    let Events;
    (function (Events) {
        Events.off = CoreEventsModule.off;
        Events.on = CoreEventsModule.on;
        Events.one = CoreEventsModule.one;
        Events.trigger = CoreEventsModule.trigger;
    })(Events = Core.Events || (Core.Events = {}));
    let Localization;
    (function (Localization) {
        Localization.formatDate = CoreLocalizationModule.formatDate;
        Localization.formatMessage = CoreLocalizationModule.formatMessage;
        Localization.formatNumber = CoreLocalizationModule.formatNumber;
        Localization.loadMessages = CoreLocalizationModule.loadMessages;
        Localization.locale = CoreLocalizationModule.locale;
        Localization.parseDate = CoreLocalizationModule.parseDate;
        Localization.parseNumber = CoreLocalizationModule.parseNumber;
    })(Localization = Core.Localization || (Core.Localization = {}));
})(Core || (Core = {}));
var Data;
(function (Data) {
    Data.applyChanges = DataModule.applyChanges;
    Data.ArrayStore = DataModule.ArrayStore;
    Data.base64_encode = DataModule.base64_encode;
    Data.compileGetter = DataModule.compileGetter;
    Data.compileSetter = DataModule.compileSetter;
    Data.CustomStore = DataModule.CustomStore;
    Data.DataSource = DataModule.DataSource;
    Data.EdmLiteral = DataModule.EdmLiteral;
    Data.EndpointSelector = DataModule.EndpointSelector;
    Data.errorHandler = DataModule.errorHandler;
    Data.isGroupItemsArray = DataModule.isGroupItemsArray;
    Data.isItemsArray = DataModule.isItemsArray;
    Data.isLoadResultObject = DataModule.isLoadResultObject;
    Data.keyConverters = DataModule.keyConverters;
    Data.LocalStore = DataModule.LocalStore;
    Data.ODataContext = DataModule.ODataContext;
    Data.ODataStore = DataModule.ODataStore;
    Data.query = DataModule.query;
    Data.setErrorHandler = DataModule.setErrorHandler;
})(Data || (Data = {}));
var Export;
(function (Export) {
    let Excel;
    (function (Excel) {
        Excel.exportDataGrid = ExportExcelModule.exportDataGrid;
        Excel.exportPivotGrid = ExportExcelModule.exportPivotGrid;
    })(Excel = Export.Excel || (Export.Excel = {}));
    let Pdf;
    (function (Pdf) {
        Pdf.exportDataGrid = ExportPdfModule.exportDataGrid;
        Pdf.exportGantt = ExportPdfModule.exportGantt;
    })(Pdf = Export.Pdf || (Export.Pdf = {}));
})(Export || (Export = {}));
function Grids() { }

/**
 * Generated bundle index. Do not edit.
 */

export { AiIntegration, Charts, Core, Data, Export, Grids };
//# sourceMappingURL=devextreme-angular-common.mjs.map
