import * as i0 from '@angular/core';
import { PLATFORM_ID, Output, Input, ContentChildren, Inject, Component, NgModule } from '@angular/core';
import DxDiagram from 'devextreme/ui/diagram';
import * as i1 from 'devextreme-angular/core';
import { DxComponent, DxIntegrationModule, DxTemplateHost, WatcherHelper, NestedOptionHost, IterableDifferHelper, DxTemplateModule } from 'devextreme-angular/core';
import { DxoContextMenuModule, DxiCommandModule, DxiItemModule, DxoContextToolboxModule, DxiCustomShapeModule, DxiConnectionPointModule, DxoDefaultItemPropertiesModule, DxoEdgesModule, DxoEditingModule, DxoExportModule, DxoGridSizeModule, DxoHistoryToolbarModule, DxoMainToolbarModule, DxoNodesModule, DxoAutoLayoutModule, DxoPageSizeModule, DxoPropertiesPanelModule, DxiTabModule, DxiGroupModule, DxoToolboxModule, DxoViewToolbarModule, DxoZoomLevelModule } from 'devextreme-angular/ui/nested';
import { DxoDiagramAutoLayoutModule, DxiDiagramCommandModule, DxiDiagramCommandItemModule, DxiDiagramConnectionPointModule, DxoDiagramContextMenuModule, DxoDiagramContextToolboxModule, DxiDiagramCustomShapeModule, DxoDiagramDefaultItemPropertiesModule, DxoDiagramEdgesModule, DxoDiagramEditingModule, DxoDiagramExportModule, DxoDiagramGridSizeModule, DxiDiagramGroupModule, DxoDiagramHistoryToolbarModule, DxiDiagramItemModule, DxoDiagramMainToolbarModule, DxoDiagramNodesModule, DxoDiagramPageSizeModule, DxiDiagramPageSizeItemModule, DxoDiagramPropertiesPanelModule, DxiDiagramTabModule, DxiDiagramTabGroupModule, DxoDiagramToolboxModule, DxiDiagramToolboxGroupModule, DxoDiagramViewToolbarModule, DxoDiagramZoomLevelModule } from 'devextreme-angular/ui/diagram/nested';
export * from 'devextreme-angular/ui/diagram/nested';
import { PROPERTY_TOKEN_commands, PROPERTY_TOKEN_items, PROPERTY_TOKEN_connectionPoints, PROPERTY_TOKEN_customShapes, PROPERTY_TOKEN_groups, PROPERTY_TOKEN_tabs } from 'devextreme-angular/core/tokens';

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
/**
 * [descr:dxDiagram]

 */
class DxDiagramComponent extends DxComponent {
    set _commandsContentChildren(value) {
        this.setChildren('commands', value);
    }
    set _itemsContentChildren(value) {
        this.setChildren('items', value);
    }
    set _connectionPointsContentChildren(value) {
        this.setChildren('connectionPoints', value);
    }
    set _customShapesContentChildren(value) {
        this.setChildren('customShapes', value);
    }
    set _groupsContentChildren(value) {
        this.setChildren('groups', value);
    }
    set _tabsContentChildren(value) {
        this.setChildren('tabs', value);
    }
    /**
     * [descr:dxDiagramOptions.autoZoomMode]
    
     */
    get autoZoomMode() {
        return this._getOption('autoZoomMode');
    }
    set autoZoomMode(value) {
        this._setOption('autoZoomMode', value);
    }
    /**
     * [descr:dxDiagramOptions.contextMenu]
    
     */
    get contextMenu() {
        return this._getOption('contextMenu');
    }
    set contextMenu(value) {
        this._setOption('contextMenu', value);
    }
    /**
     * [descr:dxDiagramOptions.contextToolbox]
    
     */
    get contextToolbox() {
        return this._getOption('contextToolbox');
    }
    set contextToolbox(value) {
        this._setOption('contextToolbox', value);
    }
    /**
     * [descr:dxDiagramOptions.customShapes]
    
     */
    get customShapes() {
        return this._getOption('customShapes');
    }
    set customShapes(value) {
        this._setOption('customShapes', value);
    }
    /**
     * [descr:dxDiagramOptions.customShapeTemplate]
    
     */
    get customShapeTemplate() {
        return this._getOption('customShapeTemplate');
    }
    set customShapeTemplate(value) {
        this._setOption('customShapeTemplate', value);
    }
    /**
     * [descr:dxDiagramOptions.customShapeToolboxTemplate]
    
     */
    get customShapeToolboxTemplate() {
        return this._getOption('customShapeToolboxTemplate');
    }
    set customShapeToolboxTemplate(value) {
        this._setOption('customShapeToolboxTemplate', value);
    }
    /**
     * [descr:dxDiagramOptions.defaultItemProperties]
    
     */
    get defaultItemProperties() {
        return this._getOption('defaultItemProperties');
    }
    set defaultItemProperties(value) {
        this._setOption('defaultItemProperties', value);
    }
    /**
     * [descr:WidgetOptions.disabled]
    
     */
    get disabled() {
        return this._getOption('disabled');
    }
    set disabled(value) {
        this._setOption('disabled', value);
    }
    /**
     * [descr:dxDiagramOptions.edges]
    
     */
    get edges() {
        return this._getOption('edges');
    }
    set edges(value) {
        this._setOption('edges', value);
    }
    /**
     * [descr:dxDiagramOptions.editing]
    
     */
    get editing() {
        return this._getOption('editing');
    }
    set editing(value) {
        this._setOption('editing', value);
    }
    /**
     * [descr:DOMComponentOptions.elementAttr]
    
     */
    get elementAttr() {
        return this._getOption('elementAttr');
    }
    set elementAttr(value) {
        this._setOption('elementAttr', value);
    }
    /**
     * [descr:dxDiagramOptions.export]
    
     */
    get export() {
        return this._getOption('export');
    }
    set export(value) {
        this._setOption('export', value);
    }
    /**
     * [descr:dxDiagramOptions.fullScreen]
    
     */
    get fullScreen() {
        return this._getOption('fullScreen');
    }
    set fullScreen(value) {
        this._setOption('fullScreen', value);
    }
    /**
     * [descr:dxDiagramOptions.gridSize]
    
     */
    get gridSize() {
        return this._getOption('gridSize');
    }
    set gridSize(value) {
        this._setOption('gridSize', value);
    }
    /**
     * [descr:dxDiagramOptions.hasChanges]
    
     */
    get hasChanges() {
        return this._getOption('hasChanges');
    }
    set hasChanges(value) {
        this._setOption('hasChanges', value);
    }
    /**
     * [descr:DOMComponentOptions.height]
    
     */
    get height() {
        return this._getOption('height');
    }
    set height(value) {
        this._setOption('height', value);
    }
    /**
     * [descr:dxDiagramOptions.historyToolbar]
    
     */
    get historyToolbar() {
        return this._getOption('historyToolbar');
    }
    set historyToolbar(value) {
        this._setOption('historyToolbar', value);
    }
    /**
     * [descr:dxDiagramOptions.mainToolbar]
    
     */
    get mainToolbar() {
        return this._getOption('mainToolbar');
    }
    set mainToolbar(value) {
        this._setOption('mainToolbar', value);
    }
    /**
     * [descr:dxDiagramOptions.nodes]
    
     */
    get nodes() {
        return this._getOption('nodes');
    }
    set nodes(value) {
        this._setOption('nodes', value);
    }
    /**
     * [descr:dxDiagramOptions.pageColor]
    
     */
    get pageColor() {
        return this._getOption('pageColor');
    }
    set pageColor(value) {
        this._setOption('pageColor', value);
    }
    /**
     * [descr:dxDiagramOptions.pageOrientation]
    
     */
    get pageOrientation() {
        return this._getOption('pageOrientation');
    }
    set pageOrientation(value) {
        this._setOption('pageOrientation', value);
    }
    /**
     * [descr:dxDiagramOptions.pageSize]
    
     */
    get pageSize() {
        return this._getOption('pageSize');
    }
    set pageSize(value) {
        this._setOption('pageSize', value);
    }
    /**
     * [descr:dxDiagramOptions.propertiesPanel]
    
     */
    get propertiesPanel() {
        return this._getOption('propertiesPanel');
    }
    set propertiesPanel(value) {
        this._setOption('propertiesPanel', value);
    }
    /**
     * [descr:dxDiagramOptions.readOnly]
    
     */
    get readOnly() {
        return this._getOption('readOnly');
    }
    set readOnly(value) {
        this._setOption('readOnly', value);
    }
    /**
     * [descr:DOMComponentOptions.rtlEnabled]
    
     */
    get rtlEnabled() {
        return this._getOption('rtlEnabled');
    }
    set rtlEnabled(value) {
        this._setOption('rtlEnabled', value);
    }
    /**
     * [descr:dxDiagramOptions.showGrid]
    
     */
    get showGrid() {
        return this._getOption('showGrid');
    }
    set showGrid(value) {
        this._setOption('showGrid', value);
    }
    /**
     * [descr:dxDiagramOptions.simpleView]
    
     */
    get simpleView() {
        return this._getOption('simpleView');
    }
    set simpleView(value) {
        this._setOption('simpleView', value);
    }
    /**
     * [descr:dxDiagramOptions.snapToGrid]
    
     */
    get snapToGrid() {
        return this._getOption('snapToGrid');
    }
    set snapToGrid(value) {
        this._setOption('snapToGrid', value);
    }
    /**
     * [descr:dxDiagramOptions.toolbox]
    
     */
    get toolbox() {
        return this._getOption('toolbox');
    }
    set toolbox(value) {
        this._setOption('toolbox', value);
    }
    /**
     * [descr:dxDiagramOptions.units]
    
     */
    get units() {
        return this._getOption('units');
    }
    set units(value) {
        this._setOption('units', value);
    }
    /**
     * [descr:dxDiagramOptions.useNativeScrolling]
    
     */
    get useNativeScrolling() {
        return this._getOption('useNativeScrolling');
    }
    set useNativeScrolling(value) {
        this._setOption('useNativeScrolling', value);
    }
    /**
     * [descr:dxDiagramOptions.viewToolbar]
    
     */
    get viewToolbar() {
        return this._getOption('viewToolbar');
    }
    set viewToolbar(value) {
        this._setOption('viewToolbar', value);
    }
    /**
     * [descr:dxDiagramOptions.viewUnits]
    
     */
    get viewUnits() {
        return this._getOption('viewUnits');
    }
    set viewUnits(value) {
        this._setOption('viewUnits', value);
    }
    /**
     * [descr:WidgetOptions.visible]
    
     */
    get visible() {
        return this._getOption('visible');
    }
    set visible(value) {
        this._setOption('visible', value);
    }
    /**
     * [descr:DOMComponentOptions.width]
    
     */
    get width() {
        return this._getOption('width');
    }
    set width(value) {
        this._setOption('width', value);
    }
    /**
     * [descr:dxDiagramOptions.zoomLevel]
    
     */
    get zoomLevel() {
        return this._getOption('zoomLevel');
    }
    set zoomLevel(value) {
        this._setOption('zoomLevel', value);
    }
    constructor(elementRef, ngZone, templateHost, _watcherHelper, _idh, optionHost, transferState, platformId) {
        super(elementRef, ngZone, templateHost, _watcherHelper, transferState, platformId);
        this._watcherHelper = _watcherHelper;
        this._idh = _idh;
        this.instance = null;
        this._createEventEmitters([
            { subscribe: 'contentReady', emit: 'onContentReady' },
            { subscribe: 'customCommand', emit: 'onCustomCommand' },
            { subscribe: 'disposing', emit: 'onDisposing' },
            { subscribe: 'initialized', emit: 'onInitialized' },
            { subscribe: 'itemClick', emit: 'onItemClick' },
            { subscribe: 'itemDblClick', emit: 'onItemDblClick' },
            { subscribe: 'optionChanged', emit: 'onOptionChanged' },
            { subscribe: 'requestEditOperation', emit: 'onRequestEditOperation' },
            { subscribe: 'requestLayoutUpdate', emit: 'onRequestLayoutUpdate' },
            { subscribe: 'selectionChanged', emit: 'onSelectionChanged' },
            { emit: 'autoZoomModeChange' },
            { emit: 'contextMenuChange' },
            { emit: 'contextToolboxChange' },
            { emit: 'customShapesChange' },
            { emit: 'customShapeTemplateChange' },
            { emit: 'customShapeToolboxTemplateChange' },
            { emit: 'defaultItemPropertiesChange' },
            { emit: 'disabledChange' },
            { emit: 'edgesChange' },
            { emit: 'editingChange' },
            { emit: 'elementAttrChange' },
            { emit: 'exportChange' },
            { emit: 'fullScreenChange' },
            { emit: 'gridSizeChange' },
            { emit: 'hasChangesChange' },
            { emit: 'heightChange' },
            { emit: 'historyToolbarChange' },
            { emit: 'mainToolbarChange' },
            { emit: 'nodesChange' },
            { emit: 'pageColorChange' },
            { emit: 'pageOrientationChange' },
            { emit: 'pageSizeChange' },
            { emit: 'propertiesPanelChange' },
            { emit: 'readOnlyChange' },
            { emit: 'rtlEnabledChange' },
            { emit: 'showGridChange' },
            { emit: 'simpleViewChange' },
            { emit: 'snapToGridChange' },
            { emit: 'toolboxChange' },
            { emit: 'unitsChange' },
            { emit: 'useNativeScrollingChange' },
            { emit: 'viewToolbarChange' },
            { emit: 'viewUnitsChange' },
            { emit: 'visibleChange' },
            { emit: 'widthChange' },
            { emit: 'zoomLevelChange' }
        ]);
        this._idh.setHost(this);
        optionHost.setHost(this);
    }
    _createInstance(element, options) {
        return new DxDiagram(element, options);
    }
    ngOnDestroy() {
        this._destroyWidget();
    }
    ngOnChanges(changes) {
        super.ngOnChanges(changes);
        this.setupChanges('customShapes', changes);
    }
    setupChanges(prop, changes) {
        if (!(prop in this._optionsToUpdate)) {
            this._idh.setup(prop, changes);
        }
    }
    ngDoCheck() {
        this._idh.doCheck('customShapes');
        this._watcherHelper.checkWatchers();
        super.ngDoCheck();
        super.clearChangedOptions();
    }
    _setOption(name, value) {
        let isSetup = this._idh.setupSingle(name, value);
        let isChanged = this._idh.getChanges(name, value) !== null;
        if (isSetup || isChanged) {
            super._setOption(name, value);
        }
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxDiagramComponent, deps: [{ token: i0.ElementRef }, { token: i0.NgZone }, { token: i1.DxTemplateHost }, { token: i1.WatcherHelper }, { token: i1.IterableDifferHelper }, { token: i1.NestedOptionHost }, { token: i0.TransferState }, { token: PLATFORM_ID }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxDiagramComponent, isStandalone: true, selector: "dx-diagram", inputs: { autoZoomMode: "autoZoomMode", contextMenu: "contextMenu", contextToolbox: "contextToolbox", customShapes: "customShapes", customShapeTemplate: "customShapeTemplate", customShapeToolboxTemplate: "customShapeToolboxTemplate", defaultItemProperties: "defaultItemProperties", disabled: "disabled", edges: "edges", editing: "editing", elementAttr: "elementAttr", export: "export", fullScreen: "fullScreen", gridSize: "gridSize", hasChanges: "hasChanges", height: "height", historyToolbar: "historyToolbar", mainToolbar: "mainToolbar", nodes: "nodes", pageColor: "pageColor", pageOrientation: "pageOrientation", pageSize: "pageSize", propertiesPanel: "propertiesPanel", readOnly: "readOnly", rtlEnabled: "rtlEnabled", showGrid: "showGrid", simpleView: "simpleView", snapToGrid: "snapToGrid", toolbox: "toolbox", units: "units", useNativeScrolling: "useNativeScrolling", viewToolbar: "viewToolbar", viewUnits: "viewUnits", visible: "visible", width: "width", zoomLevel: "zoomLevel" }, outputs: { onContentReady: "onContentReady", onCustomCommand: "onCustomCommand", onDisposing: "onDisposing", onInitialized: "onInitialized", onItemClick: "onItemClick", onItemDblClick: "onItemDblClick", onOptionChanged: "onOptionChanged", onRequestEditOperation: "onRequestEditOperation", onRequestLayoutUpdate: "onRequestLayoutUpdate", onSelectionChanged: "onSelectionChanged", autoZoomModeChange: "autoZoomModeChange", contextMenuChange: "contextMenuChange", contextToolboxChange: "contextToolboxChange", customShapesChange: "customShapesChange", customShapeTemplateChange: "customShapeTemplateChange", customShapeToolboxTemplateChange: "customShapeToolboxTemplateChange", defaultItemPropertiesChange: "defaultItemPropertiesChange", disabledChange: "disabledChange", edgesChange: "edgesChange", editingChange: "editingChange", elementAttrChange: "elementAttrChange", exportChange: "exportChange", fullScreenChange: "fullScreenChange", gridSizeChange: "gridSizeChange", hasChangesChange: "hasChangesChange", heightChange: "heightChange", historyToolbarChange: "historyToolbarChange", mainToolbarChange: "mainToolbarChange", nodesChange: "nodesChange", pageColorChange: "pageColorChange", pageOrientationChange: "pageOrientationChange", pageSizeChange: "pageSizeChange", propertiesPanelChange: "propertiesPanelChange", readOnlyChange: "readOnlyChange", rtlEnabledChange: "rtlEnabledChange", showGridChange: "showGridChange", simpleViewChange: "simpleViewChange", snapToGridChange: "snapToGridChange", toolboxChange: "toolboxChange", unitsChange: "unitsChange", useNativeScrollingChange: "useNativeScrollingChange", viewToolbarChange: "viewToolbarChange", viewUnitsChange: "viewUnitsChange", visibleChange: "visibleChange", widthChange: "widthChange", zoomLevelChange: "zoomLevelChange" }, host: { attributes: { "ngSkipHydration": "true" } }, providers: [
            DxTemplateHost,
            WatcherHelper,
            NestedOptionHost,
            IterableDifferHelper
        ], queries: [{ propertyName: "_commandsContentChildren", predicate: PROPERTY_TOKEN_commands }, { propertyName: "_itemsContentChildren", predicate: PROPERTY_TOKEN_items }, { propertyName: "_connectionPointsContentChildren", predicate: PROPERTY_TOKEN_connectionPoints }, { propertyName: "_customShapesContentChildren", predicate: PROPERTY_TOKEN_customShapes }, { propertyName: "_groupsContentChildren", predicate: PROPERTY_TOKEN_groups }, { propertyName: "_tabsContentChildren", predicate: PROPERTY_TOKEN_tabs }], usesInheritance: true, usesOnChanges: true, ngImport: i0, template: '', isInline: true, dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxDiagramComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'dx-diagram',
                    template: '',
                    host: { ngSkipHydration: 'true' },
                    imports: [DxIntegrationModule],
                    providers: [
                        DxTemplateHost,
                        WatcherHelper,
                        NestedOptionHost,
                        IterableDifferHelper
                    ]
                }]
        }], ctorParameters: () => [{ type: i0.ElementRef }, { type: i0.NgZone }, { type: i1.DxTemplateHost }, { type: i1.WatcherHelper }, { type: i1.IterableDifferHelper }, { type: i1.NestedOptionHost }, { type: i0.TransferState }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [PLATFORM_ID]
                }] }], propDecorators: { _commandsContentChildren: [{
                type: ContentChildren,
                args: [PROPERTY_TOKEN_commands]
            }], _itemsContentChildren: [{
                type: ContentChildren,
                args: [PROPERTY_TOKEN_items]
            }], _connectionPointsContentChildren: [{
                type: ContentChildren,
                args: [PROPERTY_TOKEN_connectionPoints]
            }], _customShapesContentChildren: [{
                type: ContentChildren,
                args: [PROPERTY_TOKEN_customShapes]
            }], _groupsContentChildren: [{
                type: ContentChildren,
                args: [PROPERTY_TOKEN_groups]
            }], _tabsContentChildren: [{
                type: ContentChildren,
                args: [PROPERTY_TOKEN_tabs]
            }], autoZoomMode: [{
                type: Input
            }], contextMenu: [{
                type: Input
            }], contextToolbox: [{
                type: Input
            }], customShapes: [{
                type: Input
            }], customShapeTemplate: [{
                type: Input
            }], customShapeToolboxTemplate: [{
                type: Input
            }], defaultItemProperties: [{
                type: Input
            }], disabled: [{
                type: Input
            }], edges: [{
                type: Input
            }], editing: [{
                type: Input
            }], elementAttr: [{
                type: Input
            }], export: [{
                type: Input
            }], fullScreen: [{
                type: Input
            }], gridSize: [{
                type: Input
            }], hasChanges: [{
                type: Input
            }], height: [{
                type: Input
            }], historyToolbar: [{
                type: Input
            }], mainToolbar: [{
                type: Input
            }], nodes: [{
                type: Input
            }], pageColor: [{
                type: Input
            }], pageOrientation: [{
                type: Input
            }], pageSize: [{
                type: Input
            }], propertiesPanel: [{
                type: Input
            }], readOnly: [{
                type: Input
            }], rtlEnabled: [{
                type: Input
            }], showGrid: [{
                type: Input
            }], simpleView: [{
                type: Input
            }], snapToGrid: [{
                type: Input
            }], toolbox: [{
                type: Input
            }], units: [{
                type: Input
            }], useNativeScrolling: [{
                type: Input
            }], viewToolbar: [{
                type: Input
            }], viewUnits: [{
                type: Input
            }], visible: [{
                type: Input
            }], width: [{
                type: Input
            }], zoomLevel: [{
                type: Input
            }], onContentReady: [{
                type: Output
            }], onCustomCommand: [{
                type: Output
            }], onDisposing: [{
                type: Output
            }], onInitialized: [{
                type: Output
            }], onItemClick: [{
                type: Output
            }], onItemDblClick: [{
                type: Output
            }], onOptionChanged: [{
                type: Output
            }], onRequestEditOperation: [{
                type: Output
            }], onRequestLayoutUpdate: [{
                type: Output
            }], onSelectionChanged: [{
                type: Output
            }], autoZoomModeChange: [{
                type: Output
            }], contextMenuChange: [{
                type: Output
            }], contextToolboxChange: [{
                type: Output
            }], customShapesChange: [{
                type: Output
            }], customShapeTemplateChange: [{
                type: Output
            }], customShapeToolboxTemplateChange: [{
                type: Output
            }], defaultItemPropertiesChange: [{
                type: Output
            }], disabledChange: [{
                type: Output
            }], edgesChange: [{
                type: Output
            }], editingChange: [{
                type: Output
            }], elementAttrChange: [{
                type: Output
            }], exportChange: [{
                type: Output
            }], fullScreenChange: [{
                type: Output
            }], gridSizeChange: [{
                type: Output
            }], hasChangesChange: [{
                type: Output
            }], heightChange: [{
                type: Output
            }], historyToolbarChange: [{
                type: Output
            }], mainToolbarChange: [{
                type: Output
            }], nodesChange: [{
                type: Output
            }], pageColorChange: [{
                type: Output
            }], pageOrientationChange: [{
                type: Output
            }], pageSizeChange: [{
                type: Output
            }], propertiesPanelChange: [{
                type: Output
            }], readOnlyChange: [{
                type: Output
            }], rtlEnabledChange: [{
                type: Output
            }], showGridChange: [{
                type: Output
            }], simpleViewChange: [{
                type: Output
            }], snapToGridChange: [{
                type: Output
            }], toolboxChange: [{
                type: Output
            }], unitsChange: [{
                type: Output
            }], useNativeScrollingChange: [{
                type: Output
            }], viewToolbarChange: [{
                type: Output
            }], viewUnitsChange: [{
                type: Output
            }], visibleChange: [{
                type: Output
            }], widthChange: [{
                type: Output
            }], zoomLevelChange: [{
                type: Output
            }] } });
class DxDiagramModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxDiagramModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxDiagramModule, imports: [DxDiagramComponent, DxoContextMenuModule,
            DxiCommandModule,
            DxiItemModule,
            DxoContextToolboxModule,
            DxiCustomShapeModule,
            DxiConnectionPointModule,
            DxoDefaultItemPropertiesModule,
            DxoEdgesModule,
            DxoEditingModule,
            DxoExportModule,
            DxoGridSizeModule,
            DxoHistoryToolbarModule,
            DxoMainToolbarModule,
            DxoNodesModule,
            DxoAutoLayoutModule,
            DxoPageSizeModule,
            DxoPropertiesPanelModule,
            DxiTabModule,
            DxiGroupModule,
            DxoToolboxModule,
            DxoViewToolbarModule,
            DxoZoomLevelModule,
            DxoDiagramAutoLayoutModule,
            DxiDiagramCommandModule,
            DxiDiagramCommandItemModule,
            DxiDiagramConnectionPointModule,
            DxoDiagramContextMenuModule,
            DxoDiagramContextToolboxModule,
            DxiDiagramCustomShapeModule,
            DxoDiagramDefaultItemPropertiesModule,
            DxoDiagramEdgesModule,
            DxoDiagramEditingModule,
            DxoDiagramExportModule,
            DxoDiagramGridSizeModule,
            DxiDiagramGroupModule,
            DxoDiagramHistoryToolbarModule,
            DxiDiagramItemModule,
            DxoDiagramMainToolbarModule,
            DxoDiagramNodesModule,
            DxoDiagramPageSizeModule,
            DxiDiagramPageSizeItemModule,
            DxoDiagramPropertiesPanelModule,
            DxiDiagramTabModule,
            DxiDiagramTabGroupModule,
            DxoDiagramToolboxModule,
            DxiDiagramToolboxGroupModule,
            DxoDiagramViewToolbarModule,
            DxoDiagramZoomLevelModule,
            DxIntegrationModule,
            DxTemplateModule], exports: [DxDiagramComponent, DxoContextMenuModule,
            DxiCommandModule,
            DxiItemModule,
            DxoContextToolboxModule,
            DxiCustomShapeModule,
            DxiConnectionPointModule,
            DxoDefaultItemPropertiesModule,
            DxoEdgesModule,
            DxoEditingModule,
            DxoExportModule,
            DxoGridSizeModule,
            DxoHistoryToolbarModule,
            DxoMainToolbarModule,
            DxoNodesModule,
            DxoAutoLayoutModule,
            DxoPageSizeModule,
            DxoPropertiesPanelModule,
            DxiTabModule,
            DxiGroupModule,
            DxoToolboxModule,
            DxoViewToolbarModule,
            DxoZoomLevelModule,
            DxoDiagramAutoLayoutModule,
            DxiDiagramCommandModule,
            DxiDiagramCommandItemModule,
            DxiDiagramConnectionPointModule,
            DxoDiagramContextMenuModule,
            DxoDiagramContextToolboxModule,
            DxiDiagramCustomShapeModule,
            DxoDiagramDefaultItemPropertiesModule,
            DxoDiagramEdgesModule,
            DxoDiagramEditingModule,
            DxoDiagramExportModule,
            DxoDiagramGridSizeModule,
            DxiDiagramGroupModule,
            DxoDiagramHistoryToolbarModule,
            DxiDiagramItemModule,
            DxoDiagramMainToolbarModule,
            DxoDiagramNodesModule,
            DxoDiagramPageSizeModule,
            DxiDiagramPageSizeItemModule,
            DxoDiagramPropertiesPanelModule,
            DxiDiagramTabModule,
            DxiDiagramTabGroupModule,
            DxoDiagramToolboxModule,
            DxiDiagramToolboxGroupModule,
            DxoDiagramViewToolbarModule,
            DxoDiagramZoomLevelModule,
            DxTemplateModule] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxDiagramModule, imports: [DxDiagramComponent,
            DxoContextMenuModule,
            DxiCommandModule,
            DxiItemModule,
            DxoContextToolboxModule,
            DxiCustomShapeModule,
            DxiConnectionPointModule,
            DxoDefaultItemPropertiesModule,
            DxoEdgesModule,
            DxoEditingModule,
            DxoExportModule,
            DxoGridSizeModule,
            DxoHistoryToolbarModule,
            DxoMainToolbarModule,
            DxoNodesModule,
            DxoAutoLayoutModule,
            DxoPageSizeModule,
            DxoPropertiesPanelModule,
            DxiTabModule,
            DxiGroupModule,
            DxoToolboxModule,
            DxoViewToolbarModule,
            DxoZoomLevelModule,
            DxoDiagramAutoLayoutModule,
            DxiDiagramCommandModule,
            DxiDiagramCommandItemModule,
            DxiDiagramConnectionPointModule,
            DxoDiagramContextMenuModule,
            DxoDiagramContextToolboxModule,
            DxiDiagramCustomShapeModule,
            DxoDiagramDefaultItemPropertiesModule,
            DxoDiagramEdgesModule,
            DxoDiagramEditingModule,
            DxoDiagramExportModule,
            DxoDiagramGridSizeModule,
            DxiDiagramGroupModule,
            DxoDiagramHistoryToolbarModule,
            DxiDiagramItemModule,
            DxoDiagramMainToolbarModule,
            DxoDiagramNodesModule,
            DxoDiagramPageSizeModule,
            DxiDiagramPageSizeItemModule,
            DxoDiagramPropertiesPanelModule,
            DxiDiagramTabModule,
            DxiDiagramTabGroupModule,
            DxoDiagramToolboxModule,
            DxiDiagramToolboxGroupModule,
            DxoDiagramViewToolbarModule,
            DxoDiagramZoomLevelModule,
            DxIntegrationModule,
            DxTemplateModule, DxoContextMenuModule,
            DxiCommandModule,
            DxiItemModule,
            DxoContextToolboxModule,
            DxiCustomShapeModule,
            DxiConnectionPointModule,
            DxoDefaultItemPropertiesModule,
            DxoEdgesModule,
            DxoEditingModule,
            DxoExportModule,
            DxoGridSizeModule,
            DxoHistoryToolbarModule,
            DxoMainToolbarModule,
            DxoNodesModule,
            DxoAutoLayoutModule,
            DxoPageSizeModule,
            DxoPropertiesPanelModule,
            DxiTabModule,
            DxiGroupModule,
            DxoToolboxModule,
            DxoViewToolbarModule,
            DxoZoomLevelModule,
            DxoDiagramAutoLayoutModule,
            DxiDiagramCommandModule,
            DxiDiagramCommandItemModule,
            DxiDiagramConnectionPointModule,
            DxoDiagramContextMenuModule,
            DxoDiagramContextToolboxModule,
            DxiDiagramCustomShapeModule,
            DxoDiagramDefaultItemPropertiesModule,
            DxoDiagramEdgesModule,
            DxoDiagramEditingModule,
            DxoDiagramExportModule,
            DxoDiagramGridSizeModule,
            DxiDiagramGroupModule,
            DxoDiagramHistoryToolbarModule,
            DxiDiagramItemModule,
            DxoDiagramMainToolbarModule,
            DxoDiagramNodesModule,
            DxoDiagramPageSizeModule,
            DxiDiagramPageSizeItemModule,
            DxoDiagramPropertiesPanelModule,
            DxiDiagramTabModule,
            DxiDiagramTabGroupModule,
            DxoDiagramToolboxModule,
            DxiDiagramToolboxGroupModule,
            DxoDiagramViewToolbarModule,
            DxoDiagramZoomLevelModule,
            DxTemplateModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxDiagramModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxDiagramComponent,
                        DxoContextMenuModule,
                        DxiCommandModule,
                        DxiItemModule,
                        DxoContextToolboxModule,
                        DxiCustomShapeModule,
                        DxiConnectionPointModule,
                        DxoDefaultItemPropertiesModule,
                        DxoEdgesModule,
                        DxoEditingModule,
                        DxoExportModule,
                        DxoGridSizeModule,
                        DxoHistoryToolbarModule,
                        DxoMainToolbarModule,
                        DxoNodesModule,
                        DxoAutoLayoutModule,
                        DxoPageSizeModule,
                        DxoPropertiesPanelModule,
                        DxiTabModule,
                        DxiGroupModule,
                        DxoToolboxModule,
                        DxoViewToolbarModule,
                        DxoZoomLevelModule,
                        DxoDiagramAutoLayoutModule,
                        DxiDiagramCommandModule,
                        DxiDiagramCommandItemModule,
                        DxiDiagramConnectionPointModule,
                        DxoDiagramContextMenuModule,
                        DxoDiagramContextToolboxModule,
                        DxiDiagramCustomShapeModule,
                        DxoDiagramDefaultItemPropertiesModule,
                        DxoDiagramEdgesModule,
                        DxoDiagramEditingModule,
                        DxoDiagramExportModule,
                        DxoDiagramGridSizeModule,
                        DxiDiagramGroupModule,
                        DxoDiagramHistoryToolbarModule,
                        DxiDiagramItemModule,
                        DxoDiagramMainToolbarModule,
                        DxoDiagramNodesModule,
                        DxoDiagramPageSizeModule,
                        DxiDiagramPageSizeItemModule,
                        DxoDiagramPropertiesPanelModule,
                        DxiDiagramTabModule,
                        DxiDiagramTabGroupModule,
                        DxoDiagramToolboxModule,
                        DxiDiagramToolboxGroupModule,
                        DxoDiagramViewToolbarModule,
                        DxoDiagramZoomLevelModule,
                        DxIntegrationModule,
                        DxTemplateModule
                    ],
                    exports: [
                        DxDiagramComponent,
                        DxoContextMenuModule,
                        DxiCommandModule,
                        DxiItemModule,
                        DxoContextToolboxModule,
                        DxiCustomShapeModule,
                        DxiConnectionPointModule,
                        DxoDefaultItemPropertiesModule,
                        DxoEdgesModule,
                        DxoEditingModule,
                        DxoExportModule,
                        DxoGridSizeModule,
                        DxoHistoryToolbarModule,
                        DxoMainToolbarModule,
                        DxoNodesModule,
                        DxoAutoLayoutModule,
                        DxoPageSizeModule,
                        DxoPropertiesPanelModule,
                        DxiTabModule,
                        DxiGroupModule,
                        DxoToolboxModule,
                        DxoViewToolbarModule,
                        DxoZoomLevelModule,
                        DxoDiagramAutoLayoutModule,
                        DxiDiagramCommandModule,
                        DxiDiagramCommandItemModule,
                        DxiDiagramConnectionPointModule,
                        DxoDiagramContextMenuModule,
                        DxoDiagramContextToolboxModule,
                        DxiDiagramCustomShapeModule,
                        DxoDiagramDefaultItemPropertiesModule,
                        DxoDiagramEdgesModule,
                        DxoDiagramEditingModule,
                        DxoDiagramExportModule,
                        DxoDiagramGridSizeModule,
                        DxiDiagramGroupModule,
                        DxoDiagramHistoryToolbarModule,
                        DxiDiagramItemModule,
                        DxoDiagramMainToolbarModule,
                        DxoDiagramNodesModule,
                        DxoDiagramPageSizeModule,
                        DxiDiagramPageSizeItemModule,
                        DxoDiagramPropertiesPanelModule,
                        DxiDiagramTabModule,
                        DxiDiagramTabGroupModule,
                        DxoDiagramToolboxModule,
                        DxiDiagramToolboxGroupModule,
                        DxoDiagramViewToolbarModule,
                        DxoDiagramZoomLevelModule,
                        DxTemplateModule
                    ]
                }]
        }] });

/**
 * Generated bundle index. Do not edit.
 */

export { DxDiagramComponent, DxDiagramModule };
//# sourceMappingURL=devextreme-angular-ui-diagram.mjs.map
