import * as i0 from '@angular/core';
import { PLATFORM_ID, Output, Input, Inject, Component, NgModule } from '@angular/core';
import DxSankey from 'devextreme/viz/sankey';
import * as i1 from 'devextreme-angular/core';
import { DxComponent, DxIntegrationModule, DxTemplateHost, WatcherHelper, NestedOptionHost, IterableDifferHelper, DxTemplateModule } from 'devextreme-angular/core';
import { DxoAdaptiveLayoutModule, DxoExportModule, DxoLabelModule, DxoBorderModule, DxoFontModule, DxoShadowModule, DxoLinkModule, DxoHoverStyleModule, DxoHatchingModule, DxoLoadingIndicatorModule, DxoMarginModule, DxoNodeModule, DxoSizeModule, DxoTitleModule, DxoSubtitleModule, DxoTooltipModule, DxoFormatModule } from 'devextreme-angular/ui/nested';
import { DxoSankeyAdaptiveLayoutModule, DxoSankeyBorderModule, DxoSankeyExportModule, DxoSankeyFontModule, DxoSankeyFormatModule, DxoSankeyHatchingModule, DxoSankeyHoverStyleModule, DxoSankeyLabelModule, DxoSankeyLinkModule, DxoSankeyLoadingIndicatorModule, DxoSankeyMarginModule, DxoSankeyNodeModule, DxoSankeySankeyborderModule, DxoSankeyShadowModule, DxoSankeySizeModule, DxoSankeySubtitleModule, DxoSankeyTitleModule, DxoSankeyTooltipModule, DxoSankeyTooltipBorderModule } from 'devextreme-angular/ui/sankey/nested';
export * from 'devextreme-angular/ui/sankey/nested';

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
/**
 * [descr:dxSankey]

 */
class DxSankeyComponent extends DxComponent {
    /**
     * [descr:dxSankeyOptions.adaptiveLayout]
    
     */
    get adaptiveLayout() {
        return this._getOption('adaptiveLayout');
    }
    set adaptiveLayout(value) {
        this._setOption('adaptiveLayout', value);
    }
    /**
     * [descr:dxSankeyOptions.alignment]
    
     */
    get alignment() {
        return this._getOption('alignment');
    }
    set alignment(value) {
        this._setOption('alignment', value);
    }
    /**
     * [descr:dxSankeyOptions.dataSource]
    
     */
    get dataSource() {
        return this._getOption('dataSource');
    }
    set dataSource(value) {
        this._setOption('dataSource', value);
    }
    /**
     * [descr:BaseWidgetOptions.disabled]
    
     */
    get disabled() {
        return this._getOption('disabled');
    }
    set disabled(value) {
        this._setOption('disabled', value);
    }
    /**
     * [descr:DOMComponentOptions.elementAttr]
    
     */
    get elementAttr() {
        return this._getOption('elementAttr');
    }
    set elementAttr(value) {
        this._setOption('elementAttr', value);
    }
    /**
     * [descr:BaseWidgetOptions.encodeHtml]
    
     */
    get encodeHtml() {
        return this._getOption('encodeHtml');
    }
    set encodeHtml(value) {
        this._setOption('encodeHtml', value);
    }
    /**
     * [descr:BaseWidgetOptions.export]
    
     */
    get export() {
        return this._getOption('export');
    }
    set export(value) {
        this._setOption('export', value);
    }
    /**
     * [descr:dxSankeyOptions.hoverEnabled]
    
     */
    get hoverEnabled() {
        return this._getOption('hoverEnabled');
    }
    set hoverEnabled(value) {
        this._setOption('hoverEnabled', value);
    }
    /**
     * [descr:dxSankeyOptions.label]
    
     */
    get label() {
        return this._getOption('label');
    }
    set label(value) {
        this._setOption('label', value);
    }
    /**
     * [descr:dxSankeyOptions.link]
    
     */
    get link() {
        return this._getOption('link');
    }
    set link(value) {
        this._setOption('link', value);
    }
    /**
     * [descr:BaseWidgetOptions.loadingIndicator]
    
     */
    get loadingIndicator() {
        return this._getOption('loadingIndicator');
    }
    set loadingIndicator(value) {
        this._setOption('loadingIndicator', value);
    }
    /**
     * [descr:BaseWidgetOptions.margin]
    
     */
    get margin() {
        return this._getOption('margin');
    }
    set margin(value) {
        this._setOption('margin', value);
    }
    /**
     * [descr:dxSankeyOptions.node]
    
     */
    get node() {
        return this._getOption('node');
    }
    set node(value) {
        this._setOption('node', value);
    }
    /**
     * [descr:dxSankeyOptions.palette]
    
     */
    get palette() {
        return this._getOption('palette');
    }
    set palette(value) {
        this._setOption('palette', value);
    }
    /**
     * [descr:dxSankeyOptions.paletteExtensionMode]
    
     */
    get paletteExtensionMode() {
        return this._getOption('paletteExtensionMode');
    }
    set paletteExtensionMode(value) {
        this._setOption('paletteExtensionMode', value);
    }
    /**
     * [descr:BaseWidgetOptions.pathModified]
    
     */
    get pathModified() {
        return this._getOption('pathModified');
    }
    set pathModified(value) {
        this._setOption('pathModified', value);
    }
    /**
     * [descr:BaseWidgetOptions.redrawOnResize]
    
     */
    get redrawOnResize() {
        return this._getOption('redrawOnResize');
    }
    set redrawOnResize(value) {
        this._setOption('redrawOnResize', value);
    }
    /**
     * [descr:BaseWidgetOptions.rtlEnabled]
    
     */
    get rtlEnabled() {
        return this._getOption('rtlEnabled');
    }
    set rtlEnabled(value) {
        this._setOption('rtlEnabled', value);
    }
    /**
     * [descr:BaseWidgetOptions.size]
    
     */
    get size() {
        return this._getOption('size');
    }
    set size(value) {
        this._setOption('size', value);
    }
    /**
     * [descr:dxSankeyOptions.sortData]
    
     */
    get sortData() {
        return this._getOption('sortData');
    }
    set sortData(value) {
        this._setOption('sortData', value);
    }
    /**
     * [descr:dxSankeyOptions.sourceField]
    
     */
    get sourceField() {
        return this._getOption('sourceField');
    }
    set sourceField(value) {
        this._setOption('sourceField', value);
    }
    /**
     * [descr:dxSankeyOptions.targetField]
    
     */
    get targetField() {
        return this._getOption('targetField');
    }
    set targetField(value) {
        this._setOption('targetField', value);
    }
    /**
     * [descr:BaseWidgetOptions.theme]
    
     */
    get theme() {
        return this._getOption('theme');
    }
    set theme(value) {
        this._setOption('theme', value);
    }
    /**
     * [descr:BaseWidgetOptions.title]
    
     */
    get title() {
        return this._getOption('title');
    }
    set title(value) {
        this._setOption('title', value);
    }
    /**
     * [descr:dxSankeyOptions.tooltip]
    
     */
    get tooltip() {
        return this._getOption('tooltip');
    }
    set tooltip(value) {
        this._setOption('tooltip', value);
    }
    /**
     * [descr:dxSankeyOptions.weightField]
    
     */
    get weightField() {
        return this._getOption('weightField');
    }
    set weightField(value) {
        this._setOption('weightField', value);
    }
    constructor(elementRef, ngZone, templateHost, _watcherHelper, _idh, optionHost, transferState, platformId) {
        super(elementRef, ngZone, templateHost, _watcherHelper, transferState, platformId);
        this._watcherHelper = _watcherHelper;
        this._idh = _idh;
        this.instance = null;
        this._createEventEmitters([
            { subscribe: 'disposing', emit: 'onDisposing' },
            { subscribe: 'drawn', emit: 'onDrawn' },
            { subscribe: 'exported', emit: 'onExported' },
            { subscribe: 'exporting', emit: 'onExporting' },
            { subscribe: 'fileSaving', emit: 'onFileSaving' },
            { subscribe: 'incidentOccurred', emit: 'onIncidentOccurred' },
            { subscribe: 'initialized', emit: 'onInitialized' },
            { subscribe: 'linkClick', emit: 'onLinkClick' },
            { subscribe: 'linkHoverChanged', emit: 'onLinkHoverChanged' },
            { subscribe: 'nodeClick', emit: 'onNodeClick' },
            { subscribe: 'nodeHoverChanged', emit: 'onNodeHoverChanged' },
            { subscribe: 'optionChanged', emit: 'onOptionChanged' },
            { emit: 'adaptiveLayoutChange' },
            { emit: 'alignmentChange' },
            { emit: 'dataSourceChange' },
            { emit: 'disabledChange' },
            { emit: 'elementAttrChange' },
            { emit: 'encodeHtmlChange' },
            { emit: 'exportChange' },
            { emit: 'hoverEnabledChange' },
            { emit: 'labelChange' },
            { emit: 'linkChange' },
            { emit: 'loadingIndicatorChange' },
            { emit: 'marginChange' },
            { emit: 'nodeChange' },
            { emit: 'paletteChange' },
            { emit: 'paletteExtensionModeChange' },
            { emit: 'pathModifiedChange' },
            { emit: 'redrawOnResizeChange' },
            { emit: 'rtlEnabledChange' },
            { emit: 'sizeChange' },
            { emit: 'sortDataChange' },
            { emit: 'sourceFieldChange' },
            { emit: 'targetFieldChange' },
            { emit: 'themeChange' },
            { emit: 'titleChange' },
            { emit: 'tooltipChange' },
            { emit: 'weightFieldChange' }
        ]);
        this._idh.setHost(this);
        optionHost.setHost(this);
    }
    _createInstance(element, options) {
        return new DxSankey(element, options);
    }
    ngOnDestroy() {
        this._destroyWidget();
    }
    ngOnChanges(changes) {
        super.ngOnChanges(changes);
        this.setupChanges('alignment', changes);
        this.setupChanges('dataSource', changes);
        this.setupChanges('palette', changes);
    }
    setupChanges(prop, changes) {
        if (!(prop in this._optionsToUpdate)) {
            this._idh.setup(prop, changes);
        }
    }
    ngDoCheck() {
        this._idh.doCheck('alignment');
        this._idh.doCheck('dataSource');
        this._idh.doCheck('palette');
        this._watcherHelper.checkWatchers();
        super.ngDoCheck();
        super.clearChangedOptions();
    }
    _setOption(name, value) {
        let isSetup = this._idh.setupSingle(name, value);
        let isChanged = this._idh.getChanges(name, value) !== null;
        if (isSetup || isChanged) {
            super._setOption(name, value);
        }
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxSankeyComponent, deps: [{ token: i0.ElementRef }, { token: i0.NgZone }, { token: i1.DxTemplateHost }, { token: i1.WatcherHelper }, { token: i1.IterableDifferHelper }, { token: i1.NestedOptionHost }, { token: i0.TransferState }, { token: PLATFORM_ID }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxSankeyComponent, isStandalone: true, selector: "dx-sankey", inputs: { adaptiveLayout: "adaptiveLayout", alignment: "alignment", dataSource: "dataSource", disabled: "disabled", elementAttr: "elementAttr", encodeHtml: "encodeHtml", export: "export", hoverEnabled: "hoverEnabled", label: "label", link: "link", loadingIndicator: "loadingIndicator", margin: "margin", node: "node", palette: "palette", paletteExtensionMode: "paletteExtensionMode", pathModified: "pathModified", redrawOnResize: "redrawOnResize", rtlEnabled: "rtlEnabled", size: "size", sortData: "sortData", sourceField: "sourceField", targetField: "targetField", theme: "theme", title: "title", tooltip: "tooltip", weightField: "weightField" }, outputs: { onDisposing: "onDisposing", onDrawn: "onDrawn", onExported: "onExported", onExporting: "onExporting", onFileSaving: "onFileSaving", onIncidentOccurred: "onIncidentOccurred", onInitialized: "onInitialized", onLinkClick: "onLinkClick", onLinkHoverChanged: "onLinkHoverChanged", onNodeClick: "onNodeClick", onNodeHoverChanged: "onNodeHoverChanged", onOptionChanged: "onOptionChanged", adaptiveLayoutChange: "adaptiveLayoutChange", alignmentChange: "alignmentChange", dataSourceChange: "dataSourceChange", disabledChange: "disabledChange", elementAttrChange: "elementAttrChange", encodeHtmlChange: "encodeHtmlChange", exportChange: "exportChange", hoverEnabledChange: "hoverEnabledChange", labelChange: "labelChange", linkChange: "linkChange", loadingIndicatorChange: "loadingIndicatorChange", marginChange: "marginChange", nodeChange: "nodeChange", paletteChange: "paletteChange", paletteExtensionModeChange: "paletteExtensionModeChange", pathModifiedChange: "pathModifiedChange", redrawOnResizeChange: "redrawOnResizeChange", rtlEnabledChange: "rtlEnabledChange", sizeChange: "sizeChange", sortDataChange: "sortDataChange", sourceFieldChange: "sourceFieldChange", targetFieldChange: "targetFieldChange", themeChange: "themeChange", titleChange: "titleChange", tooltipChange: "tooltipChange", weightFieldChange: "weightFieldChange" }, host: { attributes: { "ngSkipHydration": "true" } }, providers: [
            DxTemplateHost,
            WatcherHelper,
            NestedOptionHost,
            IterableDifferHelper
        ], usesInheritance: true, usesOnChanges: true, ngImport: i0, template: '', isInline: true, styles: [":host{display:block}\n"], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxSankeyComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dx-sankey', template: '', host: { ngSkipHydration: 'true' }, imports: [DxIntegrationModule], providers: [
                        DxTemplateHost,
                        WatcherHelper,
                        NestedOptionHost,
                        IterableDifferHelper
                    ], styles: [":host{display:block}\n"] }]
        }], ctorParameters: () => [{ type: i0.ElementRef }, { type: i0.NgZone }, { type: i1.DxTemplateHost }, { type: i1.WatcherHelper }, { type: i1.IterableDifferHelper }, { type: i1.NestedOptionHost }, { type: i0.TransferState }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [PLATFORM_ID]
                }] }], propDecorators: { adaptiveLayout: [{
                type: Input
            }], alignment: [{
                type: Input
            }], dataSource: [{
                type: Input
            }], disabled: [{
                type: Input
            }], elementAttr: [{
                type: Input
            }], encodeHtml: [{
                type: Input
            }], export: [{
                type: Input
            }], hoverEnabled: [{
                type: Input
            }], label: [{
                type: Input
            }], link: [{
                type: Input
            }], loadingIndicator: [{
                type: Input
            }], margin: [{
                type: Input
            }], node: [{
                type: Input
            }], palette: [{
                type: Input
            }], paletteExtensionMode: [{
                type: Input
            }], pathModified: [{
                type: Input
            }], redrawOnResize: [{
                type: Input
            }], rtlEnabled: [{
                type: Input
            }], size: [{
                type: Input
            }], sortData: [{
                type: Input
            }], sourceField: [{
                type: Input
            }], targetField: [{
                type: Input
            }], theme: [{
                type: Input
            }], title: [{
                type: Input
            }], tooltip: [{
                type: Input
            }], weightField: [{
                type: Input
            }], onDisposing: [{
                type: Output
            }], onDrawn: [{
                type: Output
            }], onExported: [{
                type: Output
            }], onExporting: [{
                type: Output
            }], onFileSaving: [{
                type: Output
            }], onIncidentOccurred: [{
                type: Output
            }], onInitialized: [{
                type: Output
            }], onLinkClick: [{
                type: Output
            }], onLinkHoverChanged: [{
                type: Output
            }], onNodeClick: [{
                type: Output
            }], onNodeHoverChanged: [{
                type: Output
            }], onOptionChanged: [{
                type: Output
            }], adaptiveLayoutChange: [{
                type: Output
            }], alignmentChange: [{
                type: Output
            }], dataSourceChange: [{
                type: Output
            }], disabledChange: [{
                type: Output
            }], elementAttrChange: [{
                type: Output
            }], encodeHtmlChange: [{
                type: Output
            }], exportChange: [{
                type: Output
            }], hoverEnabledChange: [{
                type: Output
            }], labelChange: [{
                type: Output
            }], linkChange: [{
                type: Output
            }], loadingIndicatorChange: [{
                type: Output
            }], marginChange: [{
                type: Output
            }], nodeChange: [{
                type: Output
            }], paletteChange: [{
                type: Output
            }], paletteExtensionModeChange: [{
                type: Output
            }], pathModifiedChange: [{
                type: Output
            }], redrawOnResizeChange: [{
                type: Output
            }], rtlEnabledChange: [{
                type: Output
            }], sizeChange: [{
                type: Output
            }], sortDataChange: [{
                type: Output
            }], sourceFieldChange: [{
                type: Output
            }], targetFieldChange: [{
                type: Output
            }], themeChange: [{
                type: Output
            }], titleChange: [{
                type: Output
            }], tooltipChange: [{
                type: Output
            }], weightFieldChange: [{
                type: Output
            }] } });
class DxSankeyModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxSankeyModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxSankeyModule, imports: [DxSankeyComponent, DxoAdaptiveLayoutModule,
            DxoExportModule,
            DxoLabelModule,
            DxoBorderModule,
            DxoFontModule,
            DxoShadowModule,
            DxoLinkModule,
            DxoHoverStyleModule,
            DxoHatchingModule,
            DxoLoadingIndicatorModule,
            DxoMarginModule,
            DxoNodeModule,
            DxoSizeModule,
            DxoTitleModule,
            DxoSubtitleModule,
            DxoTooltipModule,
            DxoFormatModule,
            DxoSankeyAdaptiveLayoutModule,
            DxoSankeyBorderModule,
            DxoSankeyExportModule,
            DxoSankeyFontModule,
            DxoSankeyFormatModule,
            DxoSankeyHatchingModule,
            DxoSankeyHoverStyleModule,
            DxoSankeyLabelModule,
            DxoSankeyLinkModule,
            DxoSankeyLoadingIndicatorModule,
            DxoSankeyMarginModule,
            DxoSankeyNodeModule,
            DxoSankeySankeyborderModule,
            DxoSankeyShadowModule,
            DxoSankeySizeModule,
            DxoSankeySubtitleModule,
            DxoSankeyTitleModule,
            DxoSankeyTooltipModule,
            DxoSankeyTooltipBorderModule,
            DxIntegrationModule,
            DxTemplateModule], exports: [DxSankeyComponent, DxoAdaptiveLayoutModule,
            DxoExportModule,
            DxoLabelModule,
            DxoBorderModule,
            DxoFontModule,
            DxoShadowModule,
            DxoLinkModule,
            DxoHoverStyleModule,
            DxoHatchingModule,
            DxoLoadingIndicatorModule,
            DxoMarginModule,
            DxoNodeModule,
            DxoSizeModule,
            DxoTitleModule,
            DxoSubtitleModule,
            DxoTooltipModule,
            DxoFormatModule,
            DxoSankeyAdaptiveLayoutModule,
            DxoSankeyBorderModule,
            DxoSankeyExportModule,
            DxoSankeyFontModule,
            DxoSankeyFormatModule,
            DxoSankeyHatchingModule,
            DxoSankeyHoverStyleModule,
            DxoSankeyLabelModule,
            DxoSankeyLinkModule,
            DxoSankeyLoadingIndicatorModule,
            DxoSankeyMarginModule,
            DxoSankeyNodeModule,
            DxoSankeySankeyborderModule,
            DxoSankeyShadowModule,
            DxoSankeySizeModule,
            DxoSankeySubtitleModule,
            DxoSankeyTitleModule,
            DxoSankeyTooltipModule,
            DxoSankeyTooltipBorderModule,
            DxTemplateModule] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxSankeyModule, imports: [DxSankeyComponent,
            DxoAdaptiveLayoutModule,
            DxoExportModule,
            DxoLabelModule,
            DxoBorderModule,
            DxoFontModule,
            DxoShadowModule,
            DxoLinkModule,
            DxoHoverStyleModule,
            DxoHatchingModule,
            DxoLoadingIndicatorModule,
            DxoMarginModule,
            DxoNodeModule,
            DxoSizeModule,
            DxoTitleModule,
            DxoSubtitleModule,
            DxoTooltipModule,
            DxoFormatModule,
            DxoSankeyAdaptiveLayoutModule,
            DxoSankeyBorderModule,
            DxoSankeyExportModule,
            DxoSankeyFontModule,
            DxoSankeyFormatModule,
            DxoSankeyHatchingModule,
            DxoSankeyHoverStyleModule,
            DxoSankeyLabelModule,
            DxoSankeyLinkModule,
            DxoSankeyLoadingIndicatorModule,
            DxoSankeyMarginModule,
            DxoSankeyNodeModule,
            DxoSankeySankeyborderModule,
            DxoSankeyShadowModule,
            DxoSankeySizeModule,
            DxoSankeySubtitleModule,
            DxoSankeyTitleModule,
            DxoSankeyTooltipModule,
            DxoSankeyTooltipBorderModule,
            DxIntegrationModule,
            DxTemplateModule, DxoAdaptiveLayoutModule,
            DxoExportModule,
            DxoLabelModule,
            DxoBorderModule,
            DxoFontModule,
            DxoShadowModule,
            DxoLinkModule,
            DxoHoverStyleModule,
            DxoHatchingModule,
            DxoLoadingIndicatorModule,
            DxoMarginModule,
            DxoNodeModule,
            DxoSizeModule,
            DxoTitleModule,
            DxoSubtitleModule,
            DxoTooltipModule,
            DxoFormatModule,
            DxoSankeyAdaptiveLayoutModule,
            DxoSankeyBorderModule,
            DxoSankeyExportModule,
            DxoSankeyFontModule,
            DxoSankeyFormatModule,
            DxoSankeyHatchingModule,
            DxoSankeyHoverStyleModule,
            DxoSankeyLabelModule,
            DxoSankeyLinkModule,
            DxoSankeyLoadingIndicatorModule,
            DxoSankeyMarginModule,
            DxoSankeyNodeModule,
            DxoSankeySankeyborderModule,
            DxoSankeyShadowModule,
            DxoSankeySizeModule,
            DxoSankeySubtitleModule,
            DxoSankeyTitleModule,
            DxoSankeyTooltipModule,
            DxoSankeyTooltipBorderModule,
            DxTemplateModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxSankeyModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxSankeyComponent,
                        DxoAdaptiveLayoutModule,
                        DxoExportModule,
                        DxoLabelModule,
                        DxoBorderModule,
                        DxoFontModule,
                        DxoShadowModule,
                        DxoLinkModule,
                        DxoHoverStyleModule,
                        DxoHatchingModule,
                        DxoLoadingIndicatorModule,
                        DxoMarginModule,
                        DxoNodeModule,
                        DxoSizeModule,
                        DxoTitleModule,
                        DxoSubtitleModule,
                        DxoTooltipModule,
                        DxoFormatModule,
                        DxoSankeyAdaptiveLayoutModule,
                        DxoSankeyBorderModule,
                        DxoSankeyExportModule,
                        DxoSankeyFontModule,
                        DxoSankeyFormatModule,
                        DxoSankeyHatchingModule,
                        DxoSankeyHoverStyleModule,
                        DxoSankeyLabelModule,
                        DxoSankeyLinkModule,
                        DxoSankeyLoadingIndicatorModule,
                        DxoSankeyMarginModule,
                        DxoSankeyNodeModule,
                        DxoSankeySankeyborderModule,
                        DxoSankeyShadowModule,
                        DxoSankeySizeModule,
                        DxoSankeySubtitleModule,
                        DxoSankeyTitleModule,
                        DxoSankeyTooltipModule,
                        DxoSankeyTooltipBorderModule,
                        DxIntegrationModule,
                        DxTemplateModule
                    ],
                    exports: [
                        DxSankeyComponent,
                        DxoAdaptiveLayoutModule,
                        DxoExportModule,
                        DxoLabelModule,
                        DxoBorderModule,
                        DxoFontModule,
                        DxoShadowModule,
                        DxoLinkModule,
                        DxoHoverStyleModule,
                        DxoHatchingModule,
                        DxoLoadingIndicatorModule,
                        DxoMarginModule,
                        DxoNodeModule,
                        DxoSizeModule,
                        DxoTitleModule,
                        DxoSubtitleModule,
                        DxoTooltipModule,
                        DxoFormatModule,
                        DxoSankeyAdaptiveLayoutModule,
                        DxoSankeyBorderModule,
                        DxoSankeyExportModule,
                        DxoSankeyFontModule,
                        DxoSankeyFormatModule,
                        DxoSankeyHatchingModule,
                        DxoSankeyHoverStyleModule,
                        DxoSankeyLabelModule,
                        DxoSankeyLinkModule,
                        DxoSankeyLoadingIndicatorModule,
                        DxoSankeyMarginModule,
                        DxoSankeyNodeModule,
                        DxoSankeySankeyborderModule,
                        DxoSankeyShadowModule,
                        DxoSankeySizeModule,
                        DxoSankeySubtitleModule,
                        DxoSankeyTitleModule,
                        DxoSankeyTooltipModule,
                        DxoSankeyTooltipBorderModule,
                        DxTemplateModule
                    ]
                }]
        }] });

/**
 * Generated bundle index. Do not edit.
 */

export { DxSankeyComponent, DxSankeyModule };
//# sourceMappingURL=devextreme-angular-ui-sankey.mjs.map
