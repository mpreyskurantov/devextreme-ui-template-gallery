import * as i0 from '@angular/core';
import { Input, SkipSelf, Host, Component, NgModule } from '@angular/core';
import * as i1 from 'devextreme-angular/core';
import { NestedOption, DxIntegrationModule, NestedOptionHost } from 'devextreme-angular/core';

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoPivotGridExportComponent extends NestedOption {
    get enabled() {
        return this._getOption('enabled');
    }
    set enabled(value) {
        this._setOption('enabled', value);
    }
    get _optionPath() {
        return 'export';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoPivotGridExportComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoPivotGridExportComponent, isStandalone: true, selector: "dxo-pivot-grid-export", inputs: { enabled: "enabled" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoPivotGridExportComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-pivot-grid-export', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { enabled: [{
                type: Input
            }] } });
class DxoPivotGridExportModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoPivotGridExportModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoPivotGridExportModule, imports: [DxoPivotGridExportComponent], exports: [DxoPivotGridExportComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoPivotGridExportModule, imports: [DxoPivotGridExportComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoPivotGridExportModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoPivotGridExportComponent
                    ],
                    exports: [
                        DxoPivotGridExportComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoPivotGridFieldChooserTextsComponent extends NestedOption {
    get allFields() {
        return this._getOption('allFields');
    }
    set allFields(value) {
        this._setOption('allFields', value);
    }
    get columnFields() {
        return this._getOption('columnFields');
    }
    set columnFields(value) {
        this._setOption('columnFields', value);
    }
    get dataFields() {
        return this._getOption('dataFields');
    }
    set dataFields(value) {
        this._setOption('dataFields', value);
    }
    get filterFields() {
        return this._getOption('filterFields');
    }
    set filterFields(value) {
        this._setOption('filterFields', value);
    }
    get rowFields() {
        return this._getOption('rowFields');
    }
    set rowFields(value) {
        this._setOption('rowFields', value);
    }
    get _optionPath() {
        return 'texts';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoPivotGridFieldChooserTextsComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoPivotGridFieldChooserTextsComponent, isStandalone: true, selector: "dxo-pivot-grid-field-chooser-texts", inputs: { allFields: "allFields", columnFields: "columnFields", dataFields: "dataFields", filterFields: "filterFields", rowFields: "rowFields" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoPivotGridFieldChooserTextsComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-pivot-grid-field-chooser-texts', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { allFields: [{
                type: Input
            }], columnFields: [{
                type: Input
            }], dataFields: [{
                type: Input
            }], filterFields: [{
                type: Input
            }], rowFields: [{
                type: Input
            }] } });
class DxoPivotGridFieldChooserTextsModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoPivotGridFieldChooserTextsModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoPivotGridFieldChooserTextsModule, imports: [DxoPivotGridFieldChooserTextsComponent], exports: [DxoPivotGridFieldChooserTextsComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoPivotGridFieldChooserTextsModule, imports: [DxoPivotGridFieldChooserTextsComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoPivotGridFieldChooserTextsModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoPivotGridFieldChooserTextsComponent
                    ],
                    exports: [
                        DxoPivotGridFieldChooserTextsComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoPivotGridFieldChooserComponent extends NestedOption {
    get allowSearch() {
        return this._getOption('allowSearch');
    }
    set allowSearch(value) {
        this._setOption('allowSearch', value);
    }
    get applyChangesMode() {
        return this._getOption('applyChangesMode');
    }
    set applyChangesMode(value) {
        this._setOption('applyChangesMode', value);
    }
    get enabled() {
        return this._getOption('enabled');
    }
    set enabled(value) {
        this._setOption('enabled', value);
    }
    get height() {
        return this._getOption('height');
    }
    set height(value) {
        this._setOption('height', value);
    }
    get layout() {
        return this._getOption('layout');
    }
    set layout(value) {
        this._setOption('layout', value);
    }
    get searchTimeout() {
        return this._getOption('searchTimeout');
    }
    set searchTimeout(value) {
        this._setOption('searchTimeout', value);
    }
    get texts() {
        return this._getOption('texts');
    }
    set texts(value) {
        this._setOption('texts', value);
    }
    get title() {
        return this._getOption('title');
    }
    set title(value) {
        this._setOption('title', value);
    }
    get width() {
        return this._getOption('width');
    }
    set width(value) {
        this._setOption('width', value);
    }
    get _optionPath() {
        return 'fieldChooser';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoPivotGridFieldChooserComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoPivotGridFieldChooserComponent, isStandalone: true, selector: "dxo-pivot-grid-field-chooser", inputs: { allowSearch: "allowSearch", applyChangesMode: "applyChangesMode", enabled: "enabled", height: "height", layout: "layout", searchTimeout: "searchTimeout", texts: "texts", title: "title", width: "width" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoPivotGridFieldChooserComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-pivot-grid-field-chooser', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { allowSearch: [{
                type: Input
            }], applyChangesMode: [{
                type: Input
            }], enabled: [{
                type: Input
            }], height: [{
                type: Input
            }], layout: [{
                type: Input
            }], searchTimeout: [{
                type: Input
            }], texts: [{
                type: Input
            }], title: [{
                type: Input
            }], width: [{
                type: Input
            }] } });
class DxoPivotGridFieldChooserModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoPivotGridFieldChooserModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoPivotGridFieldChooserModule, imports: [DxoPivotGridFieldChooserComponent], exports: [DxoPivotGridFieldChooserComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoPivotGridFieldChooserModule, imports: [DxoPivotGridFieldChooserComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoPivotGridFieldChooserModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoPivotGridFieldChooserComponent
                    ],
                    exports: [
                        DxoPivotGridFieldChooserComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoPivotGridFieldPanelTextsComponent extends NestedOption {
    get columnFieldArea() {
        return this._getOption('columnFieldArea');
    }
    set columnFieldArea(value) {
        this._setOption('columnFieldArea', value);
    }
    get dataFieldArea() {
        return this._getOption('dataFieldArea');
    }
    set dataFieldArea(value) {
        this._setOption('dataFieldArea', value);
    }
    get filterFieldArea() {
        return this._getOption('filterFieldArea');
    }
    set filterFieldArea(value) {
        this._setOption('filterFieldArea', value);
    }
    get rowFieldArea() {
        return this._getOption('rowFieldArea');
    }
    set rowFieldArea(value) {
        this._setOption('rowFieldArea', value);
    }
    get _optionPath() {
        return 'texts';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoPivotGridFieldPanelTextsComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoPivotGridFieldPanelTextsComponent, isStandalone: true, selector: "dxo-pivot-grid-field-panel-texts", inputs: { columnFieldArea: "columnFieldArea", dataFieldArea: "dataFieldArea", filterFieldArea: "filterFieldArea", rowFieldArea: "rowFieldArea" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoPivotGridFieldPanelTextsComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-pivot-grid-field-panel-texts', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { columnFieldArea: [{
                type: Input
            }], dataFieldArea: [{
                type: Input
            }], filterFieldArea: [{
                type: Input
            }], rowFieldArea: [{
                type: Input
            }] } });
class DxoPivotGridFieldPanelTextsModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoPivotGridFieldPanelTextsModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoPivotGridFieldPanelTextsModule, imports: [DxoPivotGridFieldPanelTextsComponent], exports: [DxoPivotGridFieldPanelTextsComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoPivotGridFieldPanelTextsModule, imports: [DxoPivotGridFieldPanelTextsComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoPivotGridFieldPanelTextsModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoPivotGridFieldPanelTextsComponent
                    ],
                    exports: [
                        DxoPivotGridFieldPanelTextsComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoPivotGridFieldPanelComponent extends NestedOption {
    get allowFieldDragging() {
        return this._getOption('allowFieldDragging');
    }
    set allowFieldDragging(value) {
        this._setOption('allowFieldDragging', value);
    }
    get showColumnFields() {
        return this._getOption('showColumnFields');
    }
    set showColumnFields(value) {
        this._setOption('showColumnFields', value);
    }
    get showDataFields() {
        return this._getOption('showDataFields');
    }
    set showDataFields(value) {
        this._setOption('showDataFields', value);
    }
    get showFilterFields() {
        return this._getOption('showFilterFields');
    }
    set showFilterFields(value) {
        this._setOption('showFilterFields', value);
    }
    get showRowFields() {
        return this._getOption('showRowFields');
    }
    set showRowFields(value) {
        this._setOption('showRowFields', value);
    }
    get texts() {
        return this._getOption('texts');
    }
    set texts(value) {
        this._setOption('texts', value);
    }
    get visible() {
        return this._getOption('visible');
    }
    set visible(value) {
        this._setOption('visible', value);
    }
    get _optionPath() {
        return 'fieldPanel';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoPivotGridFieldPanelComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoPivotGridFieldPanelComponent, isStandalone: true, selector: "dxo-pivot-grid-field-panel", inputs: { allowFieldDragging: "allowFieldDragging", showColumnFields: "showColumnFields", showDataFields: "showDataFields", showFilterFields: "showFilterFields", showRowFields: "showRowFields", texts: "texts", visible: "visible" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoPivotGridFieldPanelComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-pivot-grid-field-panel', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { allowFieldDragging: [{
                type: Input
            }], showColumnFields: [{
                type: Input
            }], showDataFields: [{
                type: Input
            }], showFilterFields: [{
                type: Input
            }], showRowFields: [{
                type: Input
            }], texts: [{
                type: Input
            }], visible: [{
                type: Input
            }] } });
class DxoPivotGridFieldPanelModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoPivotGridFieldPanelModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoPivotGridFieldPanelModule, imports: [DxoPivotGridFieldPanelComponent], exports: [DxoPivotGridFieldPanelComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoPivotGridFieldPanelModule, imports: [DxoPivotGridFieldPanelComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoPivotGridFieldPanelModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoPivotGridFieldPanelComponent
                    ],
                    exports: [
                        DxoPivotGridFieldPanelComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoPivotGridHeaderFilterTextsComponent extends NestedOption {
    get cancel() {
        return this._getOption('cancel');
    }
    set cancel(value) {
        this._setOption('cancel', value);
    }
    get emptyValue() {
        return this._getOption('emptyValue');
    }
    set emptyValue(value) {
        this._setOption('emptyValue', value);
    }
    get ok() {
        return this._getOption('ok');
    }
    set ok(value) {
        this._setOption('ok', value);
    }
    get _optionPath() {
        return 'texts';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoPivotGridHeaderFilterTextsComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoPivotGridHeaderFilterTextsComponent, isStandalone: true, selector: "dxo-pivot-grid-header-filter-texts", inputs: { cancel: "cancel", emptyValue: "emptyValue", ok: "ok" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoPivotGridHeaderFilterTextsComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-pivot-grid-header-filter-texts', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { cancel: [{
                type: Input
            }], emptyValue: [{
                type: Input
            }], ok: [{
                type: Input
            }] } });
class DxoPivotGridHeaderFilterTextsModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoPivotGridHeaderFilterTextsModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoPivotGridHeaderFilterTextsModule, imports: [DxoPivotGridHeaderFilterTextsComponent], exports: [DxoPivotGridHeaderFilterTextsComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoPivotGridHeaderFilterTextsModule, imports: [DxoPivotGridHeaderFilterTextsComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoPivotGridHeaderFilterTextsModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoPivotGridHeaderFilterTextsComponent
                    ],
                    exports: [
                        DxoPivotGridHeaderFilterTextsComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoPivotGridHeaderFilterComponent extends NestedOption {
    get allowSearch() {
        return this._getOption('allowSearch');
    }
    set allowSearch(value) {
        this._setOption('allowSearch', value);
    }
    get allowSelectAll() {
        return this._getOption('allowSelectAll');
    }
    set allowSelectAll(value) {
        this._setOption('allowSelectAll', value);
    }
    get height() {
        return this._getOption('height');
    }
    set height(value) {
        this._setOption('height', value);
    }
    get search() {
        return this._getOption('search');
    }
    set search(value) {
        this._setOption('search', value);
    }
    get searchTimeout() {
        return this._getOption('searchTimeout');
    }
    set searchTimeout(value) {
        this._setOption('searchTimeout', value);
    }
    get showRelevantValues() {
        return this._getOption('showRelevantValues');
    }
    set showRelevantValues(value) {
        this._setOption('showRelevantValues', value);
    }
    get texts() {
        return this._getOption('texts');
    }
    set texts(value) {
        this._setOption('texts', value);
    }
    get width() {
        return this._getOption('width');
    }
    set width(value) {
        this._setOption('width', value);
    }
    get _optionPath() {
        return 'headerFilter';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoPivotGridHeaderFilterComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoPivotGridHeaderFilterComponent, isStandalone: true, selector: "dxo-pivot-grid-header-filter", inputs: { allowSearch: "allowSearch", allowSelectAll: "allowSelectAll", height: "height", search: "search", searchTimeout: "searchTimeout", showRelevantValues: "showRelevantValues", texts: "texts", width: "width" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoPivotGridHeaderFilterComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-pivot-grid-header-filter', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { allowSearch: [{
                type: Input
            }], allowSelectAll: [{
                type: Input
            }], height: [{
                type: Input
            }], search: [{
                type: Input
            }], searchTimeout: [{
                type: Input
            }], showRelevantValues: [{
                type: Input
            }], texts: [{
                type: Input
            }], width: [{
                type: Input
            }] } });
class DxoPivotGridHeaderFilterModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoPivotGridHeaderFilterModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoPivotGridHeaderFilterModule, imports: [DxoPivotGridHeaderFilterComponent], exports: [DxoPivotGridHeaderFilterComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoPivotGridHeaderFilterModule, imports: [DxoPivotGridHeaderFilterComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoPivotGridHeaderFilterModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoPivotGridHeaderFilterComponent
                    ],
                    exports: [
                        DxoPivotGridHeaderFilterComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoPivotGridLoadPanelComponent extends NestedOption {
    get enabled() {
        return this._getOption('enabled');
    }
    set enabled(value) {
        this._setOption('enabled', value);
    }
    get height() {
        return this._getOption('height');
    }
    set height(value) {
        this._setOption('height', value);
    }
    get indicatorSrc() {
        return this._getOption('indicatorSrc');
    }
    set indicatorSrc(value) {
        this._setOption('indicatorSrc', value);
    }
    get shading() {
        return this._getOption('shading');
    }
    set shading(value) {
        this._setOption('shading', value);
    }
    get shadingColor() {
        return this._getOption('shadingColor');
    }
    set shadingColor(value) {
        this._setOption('shadingColor', value);
    }
    get showIndicator() {
        return this._getOption('showIndicator');
    }
    set showIndicator(value) {
        this._setOption('showIndicator', value);
    }
    get showPane() {
        return this._getOption('showPane');
    }
    set showPane(value) {
        this._setOption('showPane', value);
    }
    get text() {
        return this._getOption('text');
    }
    set text(value) {
        this._setOption('text', value);
    }
    get width() {
        return this._getOption('width');
    }
    set width(value) {
        this._setOption('width', value);
    }
    get _optionPath() {
        return 'loadPanel';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoPivotGridLoadPanelComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoPivotGridLoadPanelComponent, isStandalone: true, selector: "dxo-pivot-grid-load-panel", inputs: { enabled: "enabled", height: "height", indicatorSrc: "indicatorSrc", shading: "shading", shadingColor: "shadingColor", showIndicator: "showIndicator", showPane: "showPane", text: "text", width: "width" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoPivotGridLoadPanelComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-pivot-grid-load-panel', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { enabled: [{
                type: Input
            }], height: [{
                type: Input
            }], indicatorSrc: [{
                type: Input
            }], shading: [{
                type: Input
            }], shadingColor: [{
                type: Input
            }], showIndicator: [{
                type: Input
            }], showPane: [{
                type: Input
            }], text: [{
                type: Input
            }], width: [{
                type: Input
            }] } });
class DxoPivotGridLoadPanelModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoPivotGridLoadPanelModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoPivotGridLoadPanelModule, imports: [DxoPivotGridLoadPanelComponent], exports: [DxoPivotGridLoadPanelComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoPivotGridLoadPanelModule, imports: [DxoPivotGridLoadPanelComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoPivotGridLoadPanelModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoPivotGridLoadPanelComponent
                    ],
                    exports: [
                        DxoPivotGridLoadPanelComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoPivotGridPivotGridTextsComponent extends NestedOption {
    get collapseAll() {
        return this._getOption('collapseAll');
    }
    set collapseAll(value) {
        this._setOption('collapseAll', value);
    }
    get dataNotAvailable() {
        return this._getOption('dataNotAvailable');
    }
    set dataNotAvailable(value) {
        this._setOption('dataNotAvailable', value);
    }
    get expandAll() {
        return this._getOption('expandAll');
    }
    set expandAll(value) {
        this._setOption('expandAll', value);
    }
    get exportToExcel() {
        return this._getOption('exportToExcel');
    }
    set exportToExcel(value) {
        this._setOption('exportToExcel', value);
    }
    get grandTotal() {
        return this._getOption('grandTotal');
    }
    set grandTotal(value) {
        this._setOption('grandTotal', value);
    }
    get noData() {
        return this._getOption('noData');
    }
    set noData(value) {
        this._setOption('noData', value);
    }
    get removeAllSorting() {
        return this._getOption('removeAllSorting');
    }
    set removeAllSorting(value) {
        this._setOption('removeAllSorting', value);
    }
    get showFieldChooser() {
        return this._getOption('showFieldChooser');
    }
    set showFieldChooser(value) {
        this._setOption('showFieldChooser', value);
    }
    get sortColumnBySummary() {
        return this._getOption('sortColumnBySummary');
    }
    set sortColumnBySummary(value) {
        this._setOption('sortColumnBySummary', value);
    }
    get sortRowBySummary() {
        return this._getOption('sortRowBySummary');
    }
    set sortRowBySummary(value) {
        this._setOption('sortRowBySummary', value);
    }
    get total() {
        return this._getOption('total');
    }
    set total(value) {
        this._setOption('total', value);
    }
    get _optionPath() {
        return 'texts';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoPivotGridPivotGridTextsComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoPivotGridPivotGridTextsComponent, isStandalone: true, selector: "dxo-pivot-grid-pivot-grid-texts", inputs: { collapseAll: "collapseAll", dataNotAvailable: "dataNotAvailable", expandAll: "expandAll", exportToExcel: "exportToExcel", grandTotal: "grandTotal", noData: "noData", removeAllSorting: "removeAllSorting", showFieldChooser: "showFieldChooser", sortColumnBySummary: "sortColumnBySummary", sortRowBySummary: "sortRowBySummary", total: "total" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoPivotGridPivotGridTextsComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-pivot-grid-pivot-grid-texts', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { collapseAll: [{
                type: Input
            }], dataNotAvailable: [{
                type: Input
            }], expandAll: [{
                type: Input
            }], exportToExcel: [{
                type: Input
            }], grandTotal: [{
                type: Input
            }], noData: [{
                type: Input
            }], removeAllSorting: [{
                type: Input
            }], showFieldChooser: [{
                type: Input
            }], sortColumnBySummary: [{
                type: Input
            }], sortRowBySummary: [{
                type: Input
            }], total: [{
                type: Input
            }] } });
class DxoPivotGridPivotGridTextsModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoPivotGridPivotGridTextsModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoPivotGridPivotGridTextsModule, imports: [DxoPivotGridPivotGridTextsComponent], exports: [DxoPivotGridPivotGridTextsComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoPivotGridPivotGridTextsModule, imports: [DxoPivotGridPivotGridTextsComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoPivotGridPivotGridTextsModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoPivotGridPivotGridTextsComponent
                    ],
                    exports: [
                        DxoPivotGridPivotGridTextsComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoPivotGridScrollingComponent extends NestedOption {
    get mode() {
        return this._getOption('mode');
    }
    set mode(value) {
        this._setOption('mode', value);
    }
    get useNative() {
        return this._getOption('useNative');
    }
    set useNative(value) {
        this._setOption('useNative', value);
    }
    get _optionPath() {
        return 'scrolling';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoPivotGridScrollingComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoPivotGridScrollingComponent, isStandalone: true, selector: "dxo-pivot-grid-scrolling", inputs: { mode: "mode", useNative: "useNative" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoPivotGridScrollingComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-pivot-grid-scrolling', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { mode: [{
                type: Input
            }], useNative: [{
                type: Input
            }] } });
class DxoPivotGridScrollingModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoPivotGridScrollingModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoPivotGridScrollingModule, imports: [DxoPivotGridScrollingComponent], exports: [DxoPivotGridScrollingComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoPivotGridScrollingModule, imports: [DxoPivotGridScrollingComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoPivotGridScrollingModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoPivotGridScrollingComponent
                    ],
                    exports: [
                        DxoPivotGridScrollingComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoPivotGridSearchComponent extends NestedOption {
    get editorOptions() {
        return this._getOption('editorOptions');
    }
    set editorOptions(value) {
        this._setOption('editorOptions', value);
    }
    get enabled() {
        return this._getOption('enabled');
    }
    set enabled(value) {
        this._setOption('enabled', value);
    }
    get mode() {
        return this._getOption('mode');
    }
    set mode(value) {
        this._setOption('mode', value);
    }
    get timeout() {
        return this._getOption('timeout');
    }
    set timeout(value) {
        this._setOption('timeout', value);
    }
    get _optionPath() {
        return 'search';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoPivotGridSearchComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoPivotGridSearchComponent, isStandalone: true, selector: "dxo-pivot-grid-search", inputs: { editorOptions: "editorOptions", enabled: "enabled", mode: "mode", timeout: "timeout" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoPivotGridSearchComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-pivot-grid-search', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { editorOptions: [{
                type: Input
            }], enabled: [{
                type: Input
            }], mode: [{
                type: Input
            }], timeout: [{
                type: Input
            }] } });
class DxoPivotGridSearchModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoPivotGridSearchModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoPivotGridSearchModule, imports: [DxoPivotGridSearchComponent], exports: [DxoPivotGridSearchComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoPivotGridSearchModule, imports: [DxoPivotGridSearchComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoPivotGridSearchModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoPivotGridSearchComponent
                    ],
                    exports: [
                        DxoPivotGridSearchComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoPivotGridStateStoringComponent extends NestedOption {
    get customLoad() {
        return this._getOption('customLoad');
    }
    set customLoad(value) {
        this._setOption('customLoad', value);
    }
    get customSave() {
        return this._getOption('customSave');
    }
    set customSave(value) {
        this._setOption('customSave', value);
    }
    get enabled() {
        return this._getOption('enabled');
    }
    set enabled(value) {
        this._setOption('enabled', value);
    }
    get savingTimeout() {
        return this._getOption('savingTimeout');
    }
    set savingTimeout(value) {
        this._setOption('savingTimeout', value);
    }
    get storageKey() {
        return this._getOption('storageKey');
    }
    set storageKey(value) {
        this._setOption('storageKey', value);
    }
    get type() {
        return this._getOption('type');
    }
    set type(value) {
        this._setOption('type', value);
    }
    get _optionPath() {
        return 'stateStoring';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoPivotGridStateStoringComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoPivotGridStateStoringComponent, isStandalone: true, selector: "dxo-pivot-grid-state-storing", inputs: { customLoad: "customLoad", customSave: "customSave", enabled: "enabled", savingTimeout: "savingTimeout", storageKey: "storageKey", type: "type" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoPivotGridStateStoringComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-pivot-grid-state-storing', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { customLoad: [{
                type: Input
            }], customSave: [{
                type: Input
            }], enabled: [{
                type: Input
            }], savingTimeout: [{
                type: Input
            }], storageKey: [{
                type: Input
            }], type: [{
                type: Input
            }] } });
class DxoPivotGridStateStoringModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoPivotGridStateStoringModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoPivotGridStateStoringModule, imports: [DxoPivotGridStateStoringComponent], exports: [DxoPivotGridStateStoringComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoPivotGridStateStoringModule, imports: [DxoPivotGridStateStoringComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoPivotGridStateStoringModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoPivotGridStateStoringComponent
                    ],
                    exports: [
                        DxoPivotGridStateStoringComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoPivotGridTextsComponent extends NestedOption {
    get allFields() {
        return this._getOption('allFields');
    }
    set allFields(value) {
        this._setOption('allFields', value);
    }
    get columnFields() {
        return this._getOption('columnFields');
    }
    set columnFields(value) {
        this._setOption('columnFields', value);
    }
    get dataFields() {
        return this._getOption('dataFields');
    }
    set dataFields(value) {
        this._setOption('dataFields', value);
    }
    get filterFields() {
        return this._getOption('filterFields');
    }
    set filterFields(value) {
        this._setOption('filterFields', value);
    }
    get rowFields() {
        return this._getOption('rowFields');
    }
    set rowFields(value) {
        this._setOption('rowFields', value);
    }
    get columnFieldArea() {
        return this._getOption('columnFieldArea');
    }
    set columnFieldArea(value) {
        this._setOption('columnFieldArea', value);
    }
    get dataFieldArea() {
        return this._getOption('dataFieldArea');
    }
    set dataFieldArea(value) {
        this._setOption('dataFieldArea', value);
    }
    get filterFieldArea() {
        return this._getOption('filterFieldArea');
    }
    set filterFieldArea(value) {
        this._setOption('filterFieldArea', value);
    }
    get rowFieldArea() {
        return this._getOption('rowFieldArea');
    }
    set rowFieldArea(value) {
        this._setOption('rowFieldArea', value);
    }
    get cancel() {
        return this._getOption('cancel');
    }
    set cancel(value) {
        this._setOption('cancel', value);
    }
    get emptyValue() {
        return this._getOption('emptyValue');
    }
    set emptyValue(value) {
        this._setOption('emptyValue', value);
    }
    get ok() {
        return this._getOption('ok');
    }
    set ok(value) {
        this._setOption('ok', value);
    }
    get collapseAll() {
        return this._getOption('collapseAll');
    }
    set collapseAll(value) {
        this._setOption('collapseAll', value);
    }
    get dataNotAvailable() {
        return this._getOption('dataNotAvailable');
    }
    set dataNotAvailable(value) {
        this._setOption('dataNotAvailable', value);
    }
    get expandAll() {
        return this._getOption('expandAll');
    }
    set expandAll(value) {
        this._setOption('expandAll', value);
    }
    get exportToExcel() {
        return this._getOption('exportToExcel');
    }
    set exportToExcel(value) {
        this._setOption('exportToExcel', value);
    }
    get grandTotal() {
        return this._getOption('grandTotal');
    }
    set grandTotal(value) {
        this._setOption('grandTotal', value);
    }
    get noData() {
        return this._getOption('noData');
    }
    set noData(value) {
        this._setOption('noData', value);
    }
    get removeAllSorting() {
        return this._getOption('removeAllSorting');
    }
    set removeAllSorting(value) {
        this._setOption('removeAllSorting', value);
    }
    get showFieldChooser() {
        return this._getOption('showFieldChooser');
    }
    set showFieldChooser(value) {
        this._setOption('showFieldChooser', value);
    }
    get sortColumnBySummary() {
        return this._getOption('sortColumnBySummary');
    }
    set sortColumnBySummary(value) {
        this._setOption('sortColumnBySummary', value);
    }
    get sortRowBySummary() {
        return this._getOption('sortRowBySummary');
    }
    set sortRowBySummary(value) {
        this._setOption('sortRowBySummary', value);
    }
    get total() {
        return this._getOption('total');
    }
    set total(value) {
        this._setOption('total', value);
    }
    get _optionPath() {
        return 'texts';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoPivotGridTextsComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoPivotGridTextsComponent, isStandalone: true, selector: "dxo-pivot-grid-texts", inputs: { allFields: "allFields", columnFields: "columnFields", dataFields: "dataFields", filterFields: "filterFields", rowFields: "rowFields", columnFieldArea: "columnFieldArea", dataFieldArea: "dataFieldArea", filterFieldArea: "filterFieldArea", rowFieldArea: "rowFieldArea", cancel: "cancel", emptyValue: "emptyValue", ok: "ok", collapseAll: "collapseAll", dataNotAvailable: "dataNotAvailable", expandAll: "expandAll", exportToExcel: "exportToExcel", grandTotal: "grandTotal", noData: "noData", removeAllSorting: "removeAllSorting", showFieldChooser: "showFieldChooser", sortColumnBySummary: "sortColumnBySummary", sortRowBySummary: "sortRowBySummary", total: "total" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoPivotGridTextsComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-pivot-grid-texts', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { allFields: [{
                type: Input
            }], columnFields: [{
                type: Input
            }], dataFields: [{
                type: Input
            }], filterFields: [{
                type: Input
            }], rowFields: [{
                type: Input
            }], columnFieldArea: [{
                type: Input
            }], dataFieldArea: [{
                type: Input
            }], filterFieldArea: [{
                type: Input
            }], rowFieldArea: [{
                type: Input
            }], cancel: [{
                type: Input
            }], emptyValue: [{
                type: Input
            }], ok: [{
                type: Input
            }], collapseAll: [{
                type: Input
            }], dataNotAvailable: [{
                type: Input
            }], expandAll: [{
                type: Input
            }], exportToExcel: [{
                type: Input
            }], grandTotal: [{
                type: Input
            }], noData: [{
                type: Input
            }], removeAllSorting: [{
                type: Input
            }], showFieldChooser: [{
                type: Input
            }], sortColumnBySummary: [{
                type: Input
            }], sortRowBySummary: [{
                type: Input
            }], total: [{
                type: Input
            }] } });
class DxoPivotGridTextsModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoPivotGridTextsModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoPivotGridTextsModule, imports: [DxoPivotGridTextsComponent], exports: [DxoPivotGridTextsComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoPivotGridTextsModule, imports: [DxoPivotGridTextsComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoPivotGridTextsModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoPivotGridTextsComponent
                    ],
                    exports: [
                        DxoPivotGridTextsComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

/**
 * Generated bundle index. Do not edit.
 */

export { DxoPivotGridExportComponent, DxoPivotGridExportModule, DxoPivotGridFieldChooserComponent, DxoPivotGridFieldChooserModule, DxoPivotGridFieldChooserTextsComponent, DxoPivotGridFieldChooserTextsModule, DxoPivotGridFieldPanelComponent, DxoPivotGridFieldPanelModule, DxoPivotGridFieldPanelTextsComponent, DxoPivotGridFieldPanelTextsModule, DxoPivotGridHeaderFilterComponent, DxoPivotGridHeaderFilterModule, DxoPivotGridHeaderFilterTextsComponent, DxoPivotGridHeaderFilterTextsModule, DxoPivotGridLoadPanelComponent, DxoPivotGridLoadPanelModule, DxoPivotGridPivotGridTextsComponent, DxoPivotGridPivotGridTextsModule, DxoPivotGridScrollingComponent, DxoPivotGridScrollingModule, DxoPivotGridSearchComponent, DxoPivotGridSearchModule, DxoPivotGridStateStoringComponent, DxoPivotGridStateStoringModule, DxoPivotGridTextsComponent, DxoPivotGridTextsModule };
//# sourceMappingURL=devextreme-angular-ui-pivot-grid-nested.mjs.map
