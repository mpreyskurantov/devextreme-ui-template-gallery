import * as i0 from '@angular/core';
import { Input, SkipSelf, Host, Component, NgModule, Inject } from '@angular/core';
import * as i1 from 'devextreme-angular/core';
import { NestedOption, DxIntegrationModule, NestedOptionHost, CollectionNestedOption, extractTemplate, DxTemplateHost } from 'devextreme-angular/core';
import { DOCUMENT } from '@angular/common';
import { PROPERTY_TOKEN_toolbarItems } from 'devextreme-angular/core/tokens';

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoPopoverAnimationComponent extends NestedOption {
    get hide() {
        return this._getOption('hide');
    }
    set hide(value) {
        this._setOption('hide', value);
    }
    get show() {
        return this._getOption('show');
    }
    set show(value) {
        this._setOption('show', value);
    }
    get _optionPath() {
        return 'animation';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoPopoverAnimationComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoPopoverAnimationComponent, isStandalone: true, selector: "dxo-popover-animation", inputs: { hide: "hide", show: "show" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoPopoverAnimationComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-popover-animation', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { hide: [{
                type: Input
            }], show: [{
                type: Input
            }] } });
class DxoPopoverAnimationModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoPopoverAnimationModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoPopoverAnimationModule, imports: [DxoPopoverAnimationComponent], exports: [DxoPopoverAnimationComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoPopoverAnimationModule, imports: [DxoPopoverAnimationComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoPopoverAnimationModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoPopoverAnimationComponent
                    ],
                    exports: [
                        DxoPopoverAnimationComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoPopoverAtComponent extends NestedOption {
    get x() {
        return this._getOption('x');
    }
    set x(value) {
        this._setOption('x', value);
    }
    get y() {
        return this._getOption('y');
    }
    set y(value) {
        this._setOption('y', value);
    }
    get _optionPath() {
        return 'at';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoPopoverAtComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoPopoverAtComponent, isStandalone: true, selector: "dxo-popover-at", inputs: { x: "x", y: "y" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoPopoverAtComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-popover-at', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { x: [{
                type: Input
            }], y: [{
                type: Input
            }] } });
class DxoPopoverAtModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoPopoverAtModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoPopoverAtModule, imports: [DxoPopoverAtComponent], exports: [DxoPopoverAtComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoPopoverAtModule, imports: [DxoPopoverAtComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoPopoverAtModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoPopoverAtComponent
                    ],
                    exports: [
                        DxoPopoverAtComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoPopoverBoundaryOffsetComponent extends NestedOption {
    get x() {
        return this._getOption('x');
    }
    set x(value) {
        this._setOption('x', value);
    }
    get y() {
        return this._getOption('y');
    }
    set y(value) {
        this._setOption('y', value);
    }
    get _optionPath() {
        return 'boundaryOffset';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoPopoverBoundaryOffsetComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoPopoverBoundaryOffsetComponent, isStandalone: true, selector: "dxo-popover-boundary-offset", inputs: { x: "x", y: "y" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoPopoverBoundaryOffsetComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-popover-boundary-offset', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { x: [{
                type: Input
            }], y: [{
                type: Input
            }] } });
class DxoPopoverBoundaryOffsetModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoPopoverBoundaryOffsetModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoPopoverBoundaryOffsetModule, imports: [DxoPopoverBoundaryOffsetComponent], exports: [DxoPopoverBoundaryOffsetComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoPopoverBoundaryOffsetModule, imports: [DxoPopoverBoundaryOffsetComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoPopoverBoundaryOffsetModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoPopoverBoundaryOffsetComponent
                    ],
                    exports: [
                        DxoPopoverBoundaryOffsetComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoPopoverCollisionComponent extends NestedOption {
    get x() {
        return this._getOption('x');
    }
    set x(value) {
        this._setOption('x', value);
    }
    get y() {
        return this._getOption('y');
    }
    set y(value) {
        this._setOption('y', value);
    }
    get _optionPath() {
        return 'collision';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoPopoverCollisionComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoPopoverCollisionComponent, isStandalone: true, selector: "dxo-popover-collision", inputs: { x: "x", y: "y" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoPopoverCollisionComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-popover-collision', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { x: [{
                type: Input
            }], y: [{
                type: Input
            }] } });
class DxoPopoverCollisionModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoPopoverCollisionModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoPopoverCollisionModule, imports: [DxoPopoverCollisionComponent], exports: [DxoPopoverCollisionComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoPopoverCollisionModule, imports: [DxoPopoverCollisionComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoPopoverCollisionModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoPopoverCollisionComponent
                    ],
                    exports: [
                        DxoPopoverCollisionComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoPopoverFromComponent extends NestedOption {
    get left() {
        return this._getOption('left');
    }
    set left(value) {
        this._setOption('left', value);
    }
    get opacity() {
        return this._getOption('opacity');
    }
    set opacity(value) {
        this._setOption('opacity', value);
    }
    get position() {
        return this._getOption('position');
    }
    set position(value) {
        this._setOption('position', value);
    }
    get scale() {
        return this._getOption('scale');
    }
    set scale(value) {
        this._setOption('scale', value);
    }
    get top() {
        return this._getOption('top');
    }
    set top(value) {
        this._setOption('top', value);
    }
    get _optionPath() {
        return 'from';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoPopoverFromComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoPopoverFromComponent, isStandalone: true, selector: "dxo-popover-from", inputs: { left: "left", opacity: "opacity", position: "position", scale: "scale", top: "top" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoPopoverFromComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-popover-from', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { left: [{
                type: Input
            }], opacity: [{
                type: Input
            }], position: [{
                type: Input
            }], scale: [{
                type: Input
            }], top: [{
                type: Input
            }] } });
class DxoPopoverFromModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoPopoverFromModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoPopoverFromModule, imports: [DxoPopoverFromComponent], exports: [DxoPopoverFromComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoPopoverFromModule, imports: [DxoPopoverFromComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoPopoverFromModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoPopoverFromComponent
                    ],
                    exports: [
                        DxoPopoverFromComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoPopoverHideEventComponent extends NestedOption {
    get delay() {
        return this._getOption('delay');
    }
    set delay(value) {
        this._setOption('delay', value);
    }
    get name() {
        return this._getOption('name');
    }
    set name(value) {
        this._setOption('name', value);
    }
    get _optionPath() {
        return 'hideEvent';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoPopoverHideEventComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoPopoverHideEventComponent, isStandalone: true, selector: "dxo-popover-hide-event", inputs: { delay: "delay", name: "name" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoPopoverHideEventComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-popover-hide-event', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { delay: [{
                type: Input
            }], name: [{
                type: Input
            }] } });
class DxoPopoverHideEventModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoPopoverHideEventModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoPopoverHideEventModule, imports: [DxoPopoverHideEventComponent], exports: [DxoPopoverHideEventComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoPopoverHideEventModule, imports: [DxoPopoverHideEventComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoPopoverHideEventModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoPopoverHideEventComponent
                    ],
                    exports: [
                        DxoPopoverHideEventComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoPopoverHideComponent extends NestedOption {
    get complete() {
        return this._getOption('complete');
    }
    set complete(value) {
        this._setOption('complete', value);
    }
    get delay() {
        return this._getOption('delay');
    }
    set delay(value) {
        this._setOption('delay', value);
    }
    get direction() {
        return this._getOption('direction');
    }
    set direction(value) {
        this._setOption('direction', value);
    }
    get duration() {
        return this._getOption('duration');
    }
    set duration(value) {
        this._setOption('duration', value);
    }
    get easing() {
        return this._getOption('easing');
    }
    set easing(value) {
        this._setOption('easing', value);
    }
    get from() {
        return this._getOption('from');
    }
    set from(value) {
        this._setOption('from', value);
    }
    get staggerDelay() {
        return this._getOption('staggerDelay');
    }
    set staggerDelay(value) {
        this._setOption('staggerDelay', value);
    }
    get start() {
        return this._getOption('start');
    }
    set start(value) {
        this._setOption('start', value);
    }
    get to() {
        return this._getOption('to');
    }
    set to(value) {
        this._setOption('to', value);
    }
    get type() {
        return this._getOption('type');
    }
    set type(value) {
        this._setOption('type', value);
    }
    get _optionPath() {
        return 'hide';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoPopoverHideComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoPopoverHideComponent, isStandalone: true, selector: "dxo-popover-hide", inputs: { complete: "complete", delay: "delay", direction: "direction", duration: "duration", easing: "easing", from: "from", staggerDelay: "staggerDelay", start: "start", to: "to", type: "type" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoPopoverHideComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-popover-hide', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { complete: [{
                type: Input
            }], delay: [{
                type: Input
            }], direction: [{
                type: Input
            }], duration: [{
                type: Input
            }], easing: [{
                type: Input
            }], from: [{
                type: Input
            }], staggerDelay: [{
                type: Input
            }], start: [{
                type: Input
            }], to: [{
                type: Input
            }], type: [{
                type: Input
            }] } });
class DxoPopoverHideModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoPopoverHideModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoPopoverHideModule, imports: [DxoPopoverHideComponent], exports: [DxoPopoverHideComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoPopoverHideModule, imports: [DxoPopoverHideComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoPopoverHideModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoPopoverHideComponent
                    ],
                    exports: [
                        DxoPopoverHideComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoPopoverMyComponent extends NestedOption {
    get x() {
        return this._getOption('x');
    }
    set x(value) {
        this._setOption('x', value);
    }
    get y() {
        return this._getOption('y');
    }
    set y(value) {
        this._setOption('y', value);
    }
    get _optionPath() {
        return 'my';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoPopoverMyComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoPopoverMyComponent, isStandalone: true, selector: "dxo-popover-my", inputs: { x: "x", y: "y" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoPopoverMyComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-popover-my', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { x: [{
                type: Input
            }], y: [{
                type: Input
            }] } });
class DxoPopoverMyModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoPopoverMyModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoPopoverMyModule, imports: [DxoPopoverMyComponent], exports: [DxoPopoverMyComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoPopoverMyModule, imports: [DxoPopoverMyComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoPopoverMyModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoPopoverMyComponent
                    ],
                    exports: [
                        DxoPopoverMyComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoPopoverOffsetComponent extends NestedOption {
    get x() {
        return this._getOption('x');
    }
    set x(value) {
        this._setOption('x', value);
    }
    get y() {
        return this._getOption('y');
    }
    set y(value) {
        this._setOption('y', value);
    }
    get _optionPath() {
        return 'offset';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoPopoverOffsetComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoPopoverOffsetComponent, isStandalone: true, selector: "dxo-popover-offset", inputs: { x: "x", y: "y" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoPopoverOffsetComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-popover-offset', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { x: [{
                type: Input
            }], y: [{
                type: Input
            }] } });
class DxoPopoverOffsetModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoPopoverOffsetModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoPopoverOffsetModule, imports: [DxoPopoverOffsetComponent], exports: [DxoPopoverOffsetComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoPopoverOffsetModule, imports: [DxoPopoverOffsetComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoPopoverOffsetModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoPopoverOffsetComponent
                    ],
                    exports: [
                        DxoPopoverOffsetComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoPopoverPositionComponent extends NestedOption {
    get at() {
        return this._getOption('at');
    }
    set at(value) {
        this._setOption('at', value);
    }
    get boundary() {
        return this._getOption('boundary');
    }
    set boundary(value) {
        this._setOption('boundary', value);
    }
    get boundaryOffset() {
        return this._getOption('boundaryOffset');
    }
    set boundaryOffset(value) {
        this._setOption('boundaryOffset', value);
    }
    get collision() {
        return this._getOption('collision');
    }
    set collision(value) {
        this._setOption('collision', value);
    }
    get my() {
        return this._getOption('my');
    }
    set my(value) {
        this._setOption('my', value);
    }
    get of() {
        return this._getOption('of');
    }
    set of(value) {
        this._setOption('of', value);
    }
    get offset() {
        return this._getOption('offset');
    }
    set offset(value) {
        this._setOption('offset', value);
    }
    get _optionPath() {
        return 'position';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoPopoverPositionComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoPopoverPositionComponent, isStandalone: true, selector: "dxo-popover-position", inputs: { at: "at", boundary: "boundary", boundaryOffset: "boundaryOffset", collision: "collision", my: "my", of: "of", offset: "offset" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoPopoverPositionComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-popover-position', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { at: [{
                type: Input
            }], boundary: [{
                type: Input
            }], boundaryOffset: [{
                type: Input
            }], collision: [{
                type: Input
            }], my: [{
                type: Input
            }], of: [{
                type: Input
            }], offset: [{
                type: Input
            }] } });
class DxoPopoverPositionModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoPopoverPositionModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoPopoverPositionModule, imports: [DxoPopoverPositionComponent], exports: [DxoPopoverPositionComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoPopoverPositionModule, imports: [DxoPopoverPositionComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoPopoverPositionModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoPopoverPositionComponent
                    ],
                    exports: [
                        DxoPopoverPositionComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoPopoverShowEventComponent extends NestedOption {
    get delay() {
        return this._getOption('delay');
    }
    set delay(value) {
        this._setOption('delay', value);
    }
    get name() {
        return this._getOption('name');
    }
    set name(value) {
        this._setOption('name', value);
    }
    get _optionPath() {
        return 'showEvent';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoPopoverShowEventComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoPopoverShowEventComponent, isStandalone: true, selector: "dxo-popover-show-event", inputs: { delay: "delay", name: "name" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoPopoverShowEventComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-popover-show-event', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { delay: [{
                type: Input
            }], name: [{
                type: Input
            }] } });
class DxoPopoverShowEventModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoPopoverShowEventModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoPopoverShowEventModule, imports: [DxoPopoverShowEventComponent], exports: [DxoPopoverShowEventComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoPopoverShowEventModule, imports: [DxoPopoverShowEventComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoPopoverShowEventModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoPopoverShowEventComponent
                    ],
                    exports: [
                        DxoPopoverShowEventComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoPopoverShowComponent extends NestedOption {
    get complete() {
        return this._getOption('complete');
    }
    set complete(value) {
        this._setOption('complete', value);
    }
    get delay() {
        return this._getOption('delay');
    }
    set delay(value) {
        this._setOption('delay', value);
    }
    get direction() {
        return this._getOption('direction');
    }
    set direction(value) {
        this._setOption('direction', value);
    }
    get duration() {
        return this._getOption('duration');
    }
    set duration(value) {
        this._setOption('duration', value);
    }
    get easing() {
        return this._getOption('easing');
    }
    set easing(value) {
        this._setOption('easing', value);
    }
    get from() {
        return this._getOption('from');
    }
    set from(value) {
        this._setOption('from', value);
    }
    get staggerDelay() {
        return this._getOption('staggerDelay');
    }
    set staggerDelay(value) {
        this._setOption('staggerDelay', value);
    }
    get start() {
        return this._getOption('start');
    }
    set start(value) {
        this._setOption('start', value);
    }
    get to() {
        return this._getOption('to');
    }
    set to(value) {
        this._setOption('to', value);
    }
    get type() {
        return this._getOption('type');
    }
    set type(value) {
        this._setOption('type', value);
    }
    get _optionPath() {
        return 'show';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoPopoverShowComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoPopoverShowComponent, isStandalone: true, selector: "dxo-popover-show", inputs: { complete: "complete", delay: "delay", direction: "direction", duration: "duration", easing: "easing", from: "from", staggerDelay: "staggerDelay", start: "start", to: "to", type: "type" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoPopoverShowComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-popover-show', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { complete: [{
                type: Input
            }], delay: [{
                type: Input
            }], direction: [{
                type: Input
            }], duration: [{
                type: Input
            }], easing: [{
                type: Input
            }], from: [{
                type: Input
            }], staggerDelay: [{
                type: Input
            }], start: [{
                type: Input
            }], to: [{
                type: Input
            }], type: [{
                type: Input
            }] } });
class DxoPopoverShowModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoPopoverShowModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoPopoverShowModule, imports: [DxoPopoverShowComponent], exports: [DxoPopoverShowComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoPopoverShowModule, imports: [DxoPopoverShowComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoPopoverShowModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoPopoverShowComponent
                    ],
                    exports: [
                        DxoPopoverShowComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoPopoverToComponent extends NestedOption {
    get left() {
        return this._getOption('left');
    }
    set left(value) {
        this._setOption('left', value);
    }
    get opacity() {
        return this._getOption('opacity');
    }
    set opacity(value) {
        this._setOption('opacity', value);
    }
    get position() {
        return this._getOption('position');
    }
    set position(value) {
        this._setOption('position', value);
    }
    get scale() {
        return this._getOption('scale');
    }
    set scale(value) {
        this._setOption('scale', value);
    }
    get top() {
        return this._getOption('top');
    }
    set top(value) {
        this._setOption('top', value);
    }
    get _optionPath() {
        return 'to';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoPopoverToComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoPopoverToComponent, isStandalone: true, selector: "dxo-popover-to", inputs: { left: "left", opacity: "opacity", position: "position", scale: "scale", top: "top" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoPopoverToComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-popover-to', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { left: [{
                type: Input
            }], opacity: [{
                type: Input
            }], position: [{
                type: Input
            }], scale: [{
                type: Input
            }], top: [{
                type: Input
            }] } });
class DxoPopoverToModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoPopoverToModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoPopoverToModule, imports: [DxoPopoverToComponent], exports: [DxoPopoverToComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoPopoverToModule, imports: [DxoPopoverToComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoPopoverToModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoPopoverToComponent
                    ],
                    exports: [
                        DxoPopoverToComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxiPopoverToolbarItemComponent extends CollectionNestedOption {
    get cssClass() {
        return this._getOption('cssClass');
    }
    set cssClass(value) {
        this._setOption('cssClass', value);
    }
    get disabled() {
        return this._getOption('disabled');
    }
    set disabled(value) {
        this._setOption('disabled', value);
    }
    get html() {
        return this._getOption('html');
    }
    set html(value) {
        this._setOption('html', value);
    }
    get locateInMenu() {
        return this._getOption('locateInMenu');
    }
    set locateInMenu(value) {
        this._setOption('locateInMenu', value);
    }
    get location() {
        return this._getOption('location');
    }
    set location(value) {
        this._setOption('location', value);
    }
    get menuItemTemplate() {
        return this._getOption('menuItemTemplate');
    }
    set menuItemTemplate(value) {
        this._setOption('menuItemTemplate', value);
    }
    get options() {
        return this._getOption('options');
    }
    set options(value) {
        this._setOption('options', value);
    }
    get showText() {
        return this._getOption('showText');
    }
    set showText(value) {
        this._setOption('showText', value);
    }
    get template() {
        return this._getOption('template');
    }
    set template(value) {
        this._setOption('template', value);
    }
    get text() {
        return this._getOption('text');
    }
    set text(value) {
        this._setOption('text', value);
    }
    get toolbar() {
        return this._getOption('toolbar');
    }
    set toolbar(value) {
        this._setOption('toolbar', value);
    }
    get visible() {
        return this._getOption('visible');
    }
    set visible(value) {
        this._setOption('visible', value);
    }
    get widget() {
        return this._getOption('widget');
    }
    set widget(value) {
        this._setOption('widget', value);
    }
    get _optionPath() {
        return 'toolbarItems';
    }
    constructor(parentOptionHost, optionHost, renderer, document, templateHost, element) {
        super();
        this.renderer = renderer;
        this.document = document;
        this.element = element;
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
        templateHost.setHost(this);
    }
    setTemplate(template) {
        this.template = template;
    }
    ngAfterViewInit() {
        extractTemplate(this, this.element, this.renderer, this.document);
    }
    ngOnDestroy() {
        this._deleteRemovedOptions(this._fullOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiPopoverToolbarItemComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }, { token: i0.Renderer2 }, { token: DOCUMENT }, { token: i1.DxTemplateHost, host: true }, { token: i0.ElementRef }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxiPopoverToolbarItemComponent, isStandalone: true, selector: "dxi-popover-toolbar-item", inputs: { cssClass: "cssClass", disabled: "disabled", html: "html", locateInMenu: "locateInMenu", location: "location", menuItemTemplate: "menuItemTemplate", options: "options", showText: "showText", template: "template", text: "text", toolbar: "toolbar", visible: "visible", widget: "widget" }, providers: [
            NestedOptionHost,
            DxTemplateHost,
            {
                provide: PROPERTY_TOKEN_toolbarItems,
                useExisting: DxiPopoverToolbarItemComponent,
            }
        ], usesInheritance: true, ngImport: i0, template: '<ng-content></ng-content>', isInline: true, styles: [":host{display:block}\n"], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiPopoverToolbarItemComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxi-popover-toolbar-item', template: '<ng-content></ng-content>', imports: [DxIntegrationModule], providers: [
                        NestedOptionHost,
                        DxTemplateHost,
                        {
                            provide: PROPERTY_TOKEN_toolbarItems,
                            useExisting: DxiPopoverToolbarItemComponent,
                        }
                    ], styles: [":host{display:block}\n"] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }, { type: i0.Renderer2 }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [DOCUMENT]
                }] }, { type: i1.DxTemplateHost, decorators: [{
                    type: Host
                }] }, { type: i0.ElementRef }], propDecorators: { cssClass: [{
                type: Input
            }], disabled: [{
                type: Input
            }], html: [{
                type: Input
            }], locateInMenu: [{
                type: Input
            }], location: [{
                type: Input
            }], menuItemTemplate: [{
                type: Input
            }], options: [{
                type: Input
            }], showText: [{
                type: Input
            }], template: [{
                type: Input
            }], text: [{
                type: Input
            }], toolbar: [{
                type: Input
            }], visible: [{
                type: Input
            }], widget: [{
                type: Input
            }] } });
class DxiPopoverToolbarItemModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiPopoverToolbarItemModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxiPopoverToolbarItemModule, imports: [DxiPopoverToolbarItemComponent], exports: [DxiPopoverToolbarItemComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiPopoverToolbarItemModule, imports: [DxiPopoverToolbarItemComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiPopoverToolbarItemModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxiPopoverToolbarItemComponent
                    ],
                    exports: [
                        DxiPopoverToolbarItemComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

/**
 * Generated bundle index. Do not edit.
 */

export { DxiPopoverToolbarItemComponent, DxiPopoverToolbarItemModule, DxoPopoverAnimationComponent, DxoPopoverAnimationModule, DxoPopoverAtComponent, DxoPopoverAtModule, DxoPopoverBoundaryOffsetComponent, DxoPopoverBoundaryOffsetModule, DxoPopoverCollisionComponent, DxoPopoverCollisionModule, DxoPopoverFromComponent, DxoPopoverFromModule, DxoPopoverHideComponent, DxoPopoverHideEventComponent, DxoPopoverHideEventModule, DxoPopoverHideModule, DxoPopoverMyComponent, DxoPopoverMyModule, DxoPopoverOffsetComponent, DxoPopoverOffsetModule, DxoPopoverPositionComponent, DxoPopoverPositionModule, DxoPopoverShowComponent, DxoPopoverShowEventComponent, DxoPopoverShowEventModule, DxoPopoverShowModule, DxoPopoverToComponent, DxoPopoverToModule };
//# sourceMappingURL=devextreme-angular-ui-popover-nested.mjs.map
