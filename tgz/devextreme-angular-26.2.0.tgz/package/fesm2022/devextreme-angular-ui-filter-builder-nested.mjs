import * as i0 from '@angular/core';
import { Input, SkipSelf, Host, Component, NgModule } from '@angular/core';
import * as i1 from 'devextreme-angular/core';
import { CollectionNestedOption, DxIntegrationModule, NestedOptionHost, NestedOption } from 'devextreme-angular/core';
import { PROPERTY_TOKEN_customOperations, PROPERTY_TOKEN_fields } from 'devextreme-angular/core/tokens';

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxiFilterBuilderCustomOperationComponent extends CollectionNestedOption {
    get calculateFilterExpression() {
        return this._getOption('calculateFilterExpression');
    }
    set calculateFilterExpression(value) {
        this._setOption('calculateFilterExpression', value);
    }
    get caption() {
        return this._getOption('caption');
    }
    set caption(value) {
        this._setOption('caption', value);
    }
    get customizeText() {
        return this._getOption('customizeText');
    }
    set customizeText(value) {
        this._setOption('customizeText', value);
    }
    get dataTypes() {
        return this._getOption('dataTypes');
    }
    set dataTypes(value) {
        this._setOption('dataTypes', value);
    }
    get editorTemplate() {
        return this._getOption('editorTemplate');
    }
    set editorTemplate(value) {
        this._setOption('editorTemplate', value);
    }
    get hasValue() {
        return this._getOption('hasValue');
    }
    set hasValue(value) {
        this._setOption('hasValue', value);
    }
    get icon() {
        return this._getOption('icon');
    }
    set icon(value) {
        this._setOption('icon', value);
    }
    get name() {
        return this._getOption('name');
    }
    set name(value) {
        this._setOption('name', value);
    }
    get _optionPath() {
        return 'customOperations';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnDestroy() {
        this._deleteRemovedOptions(this._fullOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiFilterBuilderCustomOperationComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxiFilterBuilderCustomOperationComponent, isStandalone: true, selector: "dxi-filter-builder-custom-operation", inputs: { calculateFilterExpression: "calculateFilterExpression", caption: "caption", customizeText: "customizeText", dataTypes: "dataTypes", editorTemplate: "editorTemplate", hasValue: "hasValue", icon: "icon", name: "name" }, providers: [
            NestedOptionHost,
            {
                provide: PROPERTY_TOKEN_customOperations,
                useExisting: DxiFilterBuilderCustomOperationComponent,
            }
        ], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiFilterBuilderCustomOperationComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxi-filter-builder-custom-operation', template: '', imports: [DxIntegrationModule], providers: [
                        NestedOptionHost,
                        {
                            provide: PROPERTY_TOKEN_customOperations,
                            useExisting: DxiFilterBuilderCustomOperationComponent,
                        }
                    ] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { calculateFilterExpression: [{
                type: Input
            }], caption: [{
                type: Input
            }], customizeText: [{
                type: Input
            }], dataTypes: [{
                type: Input
            }], editorTemplate: [{
                type: Input
            }], hasValue: [{
                type: Input
            }], icon: [{
                type: Input
            }], name: [{
                type: Input
            }] } });
class DxiFilterBuilderCustomOperationModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiFilterBuilderCustomOperationModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxiFilterBuilderCustomOperationModule, imports: [DxiFilterBuilderCustomOperationComponent], exports: [DxiFilterBuilderCustomOperationComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiFilterBuilderCustomOperationModule, imports: [DxiFilterBuilderCustomOperationComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiFilterBuilderCustomOperationModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxiFilterBuilderCustomOperationComponent
                    ],
                    exports: [
                        DxiFilterBuilderCustomOperationComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxiFilterBuilderFieldComponent extends CollectionNestedOption {
    get calculateFilterExpression() {
        return this._getOption('calculateFilterExpression');
    }
    set calculateFilterExpression(value) {
        this._setOption('calculateFilterExpression', value);
    }
    get caption() {
        return this._getOption('caption');
    }
    set caption(value) {
        this._setOption('caption', value);
    }
    get customizeText() {
        return this._getOption('customizeText');
    }
    set customizeText(value) {
        this._setOption('customizeText', value);
    }
    get dataField() {
        return this._getOption('dataField');
    }
    set dataField(value) {
        this._setOption('dataField', value);
    }
    get dataType() {
        return this._getOption('dataType');
    }
    set dataType(value) {
        this._setOption('dataType', value);
    }
    get editorOptions() {
        return this._getOption('editorOptions');
    }
    set editorOptions(value) {
        this._setOption('editorOptions', value);
    }
    get editorTemplate() {
        return this._getOption('editorTemplate');
    }
    set editorTemplate(value) {
        this._setOption('editorTemplate', value);
    }
    get falseText() {
        return this._getOption('falseText');
    }
    set falseText(value) {
        this._setOption('falseText', value);
    }
    get filterOperations() {
        return this._getOption('filterOperations');
    }
    set filterOperations(value) {
        this._setOption('filterOperations', value);
    }
    get format() {
        return this._getOption('format');
    }
    set format(value) {
        this._setOption('format', value);
    }
    get lookup() {
        return this._getOption('lookup');
    }
    set lookup(value) {
        this._setOption('lookup', value);
    }
    get name() {
        return this._getOption('name');
    }
    set name(value) {
        this._setOption('name', value);
    }
    get trueText() {
        return this._getOption('trueText');
    }
    set trueText(value) {
        this._setOption('trueText', value);
    }
    get _optionPath() {
        return 'fields';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnDestroy() {
        this._deleteRemovedOptions(this._fullOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiFilterBuilderFieldComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxiFilterBuilderFieldComponent, isStandalone: true, selector: "dxi-filter-builder-field", inputs: { calculateFilterExpression: "calculateFilterExpression", caption: "caption", customizeText: "customizeText", dataField: "dataField", dataType: "dataType", editorOptions: "editorOptions", editorTemplate: "editorTemplate", falseText: "falseText", filterOperations: "filterOperations", format: "format", lookup: "lookup", name: "name", trueText: "trueText" }, providers: [
            NestedOptionHost,
            {
                provide: PROPERTY_TOKEN_fields,
                useExisting: DxiFilterBuilderFieldComponent,
            }
        ], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiFilterBuilderFieldComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxi-filter-builder-field', template: '', imports: [DxIntegrationModule], providers: [
                        NestedOptionHost,
                        {
                            provide: PROPERTY_TOKEN_fields,
                            useExisting: DxiFilterBuilderFieldComponent,
                        }
                    ] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { calculateFilterExpression: [{
                type: Input
            }], caption: [{
                type: Input
            }], customizeText: [{
                type: Input
            }], dataField: [{
                type: Input
            }], dataType: [{
                type: Input
            }], editorOptions: [{
                type: Input
            }], editorTemplate: [{
                type: Input
            }], falseText: [{
                type: Input
            }], filterOperations: [{
                type: Input
            }], format: [{
                type: Input
            }], lookup: [{
                type: Input
            }], name: [{
                type: Input
            }], trueText: [{
                type: Input
            }] } });
class DxiFilterBuilderFieldModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiFilterBuilderFieldModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxiFilterBuilderFieldModule, imports: [DxiFilterBuilderFieldComponent], exports: [DxiFilterBuilderFieldComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiFilterBuilderFieldModule, imports: [DxiFilterBuilderFieldComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiFilterBuilderFieldModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxiFilterBuilderFieldComponent
                    ],
                    exports: [
                        DxiFilterBuilderFieldComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoFilterBuilderFilterOperationDescriptionsComponent extends NestedOption {
    get between() {
        return this._getOption('between');
    }
    set between(value) {
        this._setOption('between', value);
    }
    get contains() {
        return this._getOption('contains');
    }
    set contains(value) {
        this._setOption('contains', value);
    }
    get endsWith() {
        return this._getOption('endsWith');
    }
    set endsWith(value) {
        this._setOption('endsWith', value);
    }
    get equal() {
        return this._getOption('equal');
    }
    set equal(value) {
        this._setOption('equal', value);
    }
    get greaterThan() {
        return this._getOption('greaterThan');
    }
    set greaterThan(value) {
        this._setOption('greaterThan', value);
    }
    get greaterThanOrEqual() {
        return this._getOption('greaterThanOrEqual');
    }
    set greaterThanOrEqual(value) {
        this._setOption('greaterThanOrEqual', value);
    }
    get isBlank() {
        return this._getOption('isBlank');
    }
    set isBlank(value) {
        this._setOption('isBlank', value);
    }
    get isNotBlank() {
        return this._getOption('isNotBlank');
    }
    set isNotBlank(value) {
        this._setOption('isNotBlank', value);
    }
    get lessThan() {
        return this._getOption('lessThan');
    }
    set lessThan(value) {
        this._setOption('lessThan', value);
    }
    get lessThanOrEqual() {
        return this._getOption('lessThanOrEqual');
    }
    set lessThanOrEqual(value) {
        this._setOption('lessThanOrEqual', value);
    }
    get notContains() {
        return this._getOption('notContains');
    }
    set notContains(value) {
        this._setOption('notContains', value);
    }
    get notEqual() {
        return this._getOption('notEqual');
    }
    set notEqual(value) {
        this._setOption('notEqual', value);
    }
    get startsWith() {
        return this._getOption('startsWith');
    }
    set startsWith(value) {
        this._setOption('startsWith', value);
    }
    get _optionPath() {
        return 'filterOperationDescriptions';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoFilterBuilderFilterOperationDescriptionsComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoFilterBuilderFilterOperationDescriptionsComponent, isStandalone: true, selector: "dxo-filter-builder-filter-operation-descriptions", inputs: { between: "between", contains: "contains", endsWith: "endsWith", equal: "equal", greaterThan: "greaterThan", greaterThanOrEqual: "greaterThanOrEqual", isBlank: "isBlank", isNotBlank: "isNotBlank", lessThan: "lessThan", lessThanOrEqual: "lessThanOrEqual", notContains: "notContains", notEqual: "notEqual", startsWith: "startsWith" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoFilterBuilderFilterOperationDescriptionsComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-filter-builder-filter-operation-descriptions', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { between: [{
                type: Input
            }], contains: [{
                type: Input
            }], endsWith: [{
                type: Input
            }], equal: [{
                type: Input
            }], greaterThan: [{
                type: Input
            }], greaterThanOrEqual: [{
                type: Input
            }], isBlank: [{
                type: Input
            }], isNotBlank: [{
                type: Input
            }], lessThan: [{
                type: Input
            }], lessThanOrEqual: [{
                type: Input
            }], notContains: [{
                type: Input
            }], notEqual: [{
                type: Input
            }], startsWith: [{
                type: Input
            }] } });
class DxoFilterBuilderFilterOperationDescriptionsModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoFilterBuilderFilterOperationDescriptionsModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoFilterBuilderFilterOperationDescriptionsModule, imports: [DxoFilterBuilderFilterOperationDescriptionsComponent], exports: [DxoFilterBuilderFilterOperationDescriptionsComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoFilterBuilderFilterOperationDescriptionsModule, imports: [DxoFilterBuilderFilterOperationDescriptionsComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoFilterBuilderFilterOperationDescriptionsModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoFilterBuilderFilterOperationDescriptionsComponent
                    ],
                    exports: [
                        DxoFilterBuilderFilterOperationDescriptionsComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoFilterBuilderFormatComponent extends NestedOption {
    get currency() {
        return this._getOption('currency');
    }
    set currency(value) {
        this._setOption('currency', value);
    }
    get formatter() {
        return this._getOption('formatter');
    }
    set formatter(value) {
        this._setOption('formatter', value);
    }
    get parser() {
        return this._getOption('parser');
    }
    set parser(value) {
        this._setOption('parser', value);
    }
    get precision() {
        return this._getOption('precision');
    }
    set precision(value) {
        this._setOption('precision', value);
    }
    get type() {
        return this._getOption('type');
    }
    set type(value) {
        this._setOption('type', value);
    }
    get useCurrencyAccountingStyle() {
        return this._getOption('useCurrencyAccountingStyle');
    }
    set useCurrencyAccountingStyle(value) {
        this._setOption('useCurrencyAccountingStyle', value);
    }
    get _optionPath() {
        return 'format';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoFilterBuilderFormatComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoFilterBuilderFormatComponent, isStandalone: true, selector: "dxo-filter-builder-format", inputs: { currency: "currency", formatter: "formatter", parser: "parser", precision: "precision", type: "type", useCurrencyAccountingStyle: "useCurrencyAccountingStyle" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoFilterBuilderFormatComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-filter-builder-format', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { currency: [{
                type: Input
            }], formatter: [{
                type: Input
            }], parser: [{
                type: Input
            }], precision: [{
                type: Input
            }], type: [{
                type: Input
            }], useCurrencyAccountingStyle: [{
                type: Input
            }] } });
class DxoFilterBuilderFormatModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoFilterBuilderFormatModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoFilterBuilderFormatModule, imports: [DxoFilterBuilderFormatComponent], exports: [DxoFilterBuilderFormatComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoFilterBuilderFormatModule, imports: [DxoFilterBuilderFormatComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoFilterBuilderFormatModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoFilterBuilderFormatComponent
                    ],
                    exports: [
                        DxoFilterBuilderFormatComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoFilterBuilderGroupOperationDescriptionsComponent extends NestedOption {
    get and() {
        return this._getOption('and');
    }
    set and(value) {
        this._setOption('and', value);
    }
    get notAnd() {
        return this._getOption('notAnd');
    }
    set notAnd(value) {
        this._setOption('notAnd', value);
    }
    get notOr() {
        return this._getOption('notOr');
    }
    set notOr(value) {
        this._setOption('notOr', value);
    }
    get or() {
        return this._getOption('or');
    }
    set or(value) {
        this._setOption('or', value);
    }
    get _optionPath() {
        return 'groupOperationDescriptions';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoFilterBuilderGroupOperationDescriptionsComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoFilterBuilderGroupOperationDescriptionsComponent, isStandalone: true, selector: "dxo-filter-builder-group-operation-descriptions", inputs: { and: "and", notAnd: "notAnd", notOr: "notOr", or: "or" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoFilterBuilderGroupOperationDescriptionsComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-filter-builder-group-operation-descriptions', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { and: [{
                type: Input
            }], notAnd: [{
                type: Input
            }], notOr: [{
                type: Input
            }], or: [{
                type: Input
            }] } });
class DxoFilterBuilderGroupOperationDescriptionsModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoFilterBuilderGroupOperationDescriptionsModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoFilterBuilderGroupOperationDescriptionsModule, imports: [DxoFilterBuilderGroupOperationDescriptionsComponent], exports: [DxoFilterBuilderGroupOperationDescriptionsComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoFilterBuilderGroupOperationDescriptionsModule, imports: [DxoFilterBuilderGroupOperationDescriptionsComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoFilterBuilderGroupOperationDescriptionsModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoFilterBuilderGroupOperationDescriptionsComponent
                    ],
                    exports: [
                        DxoFilterBuilderGroupOperationDescriptionsComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoFilterBuilderLookupComponent extends NestedOption {
    get allowClearing() {
        return this._getOption('allowClearing');
    }
    set allowClearing(value) {
        this._setOption('allowClearing', value);
    }
    get dataSource() {
        return this._getOption('dataSource');
    }
    set dataSource(value) {
        this._setOption('dataSource', value);
    }
    get displayExpr() {
        return this._getOption('displayExpr');
    }
    set displayExpr(value) {
        this._setOption('displayExpr', value);
    }
    get valueExpr() {
        return this._getOption('valueExpr');
    }
    set valueExpr(value) {
        this._setOption('valueExpr', value);
    }
    get _optionPath() {
        return 'lookup';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoFilterBuilderLookupComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoFilterBuilderLookupComponent, isStandalone: true, selector: "dxo-filter-builder-lookup", inputs: { allowClearing: "allowClearing", dataSource: "dataSource", displayExpr: "displayExpr", valueExpr: "valueExpr" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoFilterBuilderLookupComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-filter-builder-lookup', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { allowClearing: [{
                type: Input
            }], dataSource: [{
                type: Input
            }], displayExpr: [{
                type: Input
            }], valueExpr: [{
                type: Input
            }] } });
class DxoFilterBuilderLookupModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoFilterBuilderLookupModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoFilterBuilderLookupModule, imports: [DxoFilterBuilderLookupComponent], exports: [DxoFilterBuilderLookupComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoFilterBuilderLookupModule, imports: [DxoFilterBuilderLookupComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoFilterBuilderLookupModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoFilterBuilderLookupComponent
                    ],
                    exports: [
                        DxoFilterBuilderLookupComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

/**
 * Generated bundle index. Do not edit.
 */

export { DxiFilterBuilderCustomOperationComponent, DxiFilterBuilderCustomOperationModule, DxiFilterBuilderFieldComponent, DxiFilterBuilderFieldModule, DxoFilterBuilderFilterOperationDescriptionsComponent, DxoFilterBuilderFilterOperationDescriptionsModule, DxoFilterBuilderFormatComponent, DxoFilterBuilderFormatModule, DxoFilterBuilderGroupOperationDescriptionsComponent, DxoFilterBuilderGroupOperationDescriptionsModule, DxoFilterBuilderLookupComponent, DxoFilterBuilderLookupModule };
//# sourceMappingURL=devextreme-angular-ui-filter-builder-nested.mjs.map
