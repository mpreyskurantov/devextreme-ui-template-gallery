import * as i0 from '@angular/core';
import { Input, SkipSelf, Host, Component, NgModule, Inject, Output, ContentChildren } from '@angular/core';
import * as i1 from 'devextreme-angular/core';
import { NestedOption, DxIntegrationModule, NestedOptionHost, CollectionNestedOption, extractTemplate, DxTemplateHost } from 'devextreme-angular/core';
import { DOCUMENT } from '@angular/common';
import { PROPERTY_TOKEN_annotations, PROPERTY_TOKEN_breaks, PROPERTY_TOKEN_constantLines, PROPERTY_TOKEN_strips, PROPERTY_TOKEN_panes, PROPERTY_TOKEN_series, PROPERTY_TOKEN_valueAxis } from 'devextreme-angular/core/tokens';

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoChartAdaptiveLayoutComponent extends NestedOption {
    get height() {
        return this._getOption('height');
    }
    set height(value) {
        this._setOption('height', value);
    }
    get keepLabels() {
        return this._getOption('keepLabels');
    }
    set keepLabels(value) {
        this._setOption('keepLabels', value);
    }
    get width() {
        return this._getOption('width');
    }
    set width(value) {
        this._setOption('width', value);
    }
    get _optionPath() {
        return 'adaptiveLayout';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartAdaptiveLayoutComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoChartAdaptiveLayoutComponent, isStandalone: true, selector: "dxo-chart-adaptive-layout", inputs: { height: "height", keepLabels: "keepLabels", width: "width" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartAdaptiveLayoutComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-chart-adaptive-layout', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { height: [{
                type: Input
            }], keepLabels: [{
                type: Input
            }], width: [{
                type: Input
            }] } });
class DxoChartAdaptiveLayoutModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartAdaptiveLayoutModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoChartAdaptiveLayoutModule, imports: [DxoChartAdaptiveLayoutComponent], exports: [DxoChartAdaptiveLayoutComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartAdaptiveLayoutModule, imports: [DxoChartAdaptiveLayoutComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartAdaptiveLayoutModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoChartAdaptiveLayoutComponent
                    ],
                    exports: [
                        DxoChartAdaptiveLayoutComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoChartAggregationIntervalComponent extends NestedOption {
    get days() {
        return this._getOption('days');
    }
    set days(value) {
        this._setOption('days', value);
    }
    get hours() {
        return this._getOption('hours');
    }
    set hours(value) {
        this._setOption('hours', value);
    }
    get milliseconds() {
        return this._getOption('milliseconds');
    }
    set milliseconds(value) {
        this._setOption('milliseconds', value);
    }
    get minutes() {
        return this._getOption('minutes');
    }
    set minutes(value) {
        this._setOption('minutes', value);
    }
    get months() {
        return this._getOption('months');
    }
    set months(value) {
        this._setOption('months', value);
    }
    get quarters() {
        return this._getOption('quarters');
    }
    set quarters(value) {
        this._setOption('quarters', value);
    }
    get seconds() {
        return this._getOption('seconds');
    }
    set seconds(value) {
        this._setOption('seconds', value);
    }
    get weeks() {
        return this._getOption('weeks');
    }
    set weeks(value) {
        this._setOption('weeks', value);
    }
    get years() {
        return this._getOption('years');
    }
    set years(value) {
        this._setOption('years', value);
    }
    get _optionPath() {
        return 'aggregationInterval';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartAggregationIntervalComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoChartAggregationIntervalComponent, isStandalone: true, selector: "dxo-chart-aggregation-interval", inputs: { days: "days", hours: "hours", milliseconds: "milliseconds", minutes: "minutes", months: "months", quarters: "quarters", seconds: "seconds", weeks: "weeks", years: "years" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartAggregationIntervalComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-chart-aggregation-interval', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { days: [{
                type: Input
            }], hours: [{
                type: Input
            }], milliseconds: [{
                type: Input
            }], minutes: [{
                type: Input
            }], months: [{
                type: Input
            }], quarters: [{
                type: Input
            }], seconds: [{
                type: Input
            }], weeks: [{
                type: Input
            }], years: [{
                type: Input
            }] } });
class DxoChartAggregationIntervalModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartAggregationIntervalModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoChartAggregationIntervalModule, imports: [DxoChartAggregationIntervalComponent], exports: [DxoChartAggregationIntervalComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartAggregationIntervalModule, imports: [DxoChartAggregationIntervalComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartAggregationIntervalModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoChartAggregationIntervalComponent
                    ],
                    exports: [
                        DxoChartAggregationIntervalComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoChartAggregationComponent extends NestedOption {
    get calculate() {
        return this._getOption('calculate');
    }
    set calculate(value) {
        this._setOption('calculate', value);
    }
    get enabled() {
        return this._getOption('enabled');
    }
    set enabled(value) {
        this._setOption('enabled', value);
    }
    get method() {
        return this._getOption('method');
    }
    set method(value) {
        this._setOption('method', value);
    }
    get _optionPath() {
        return 'aggregation';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartAggregationComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoChartAggregationComponent, isStandalone: true, selector: "dxo-chart-aggregation", inputs: { calculate: "calculate", enabled: "enabled", method: "method" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartAggregationComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-chart-aggregation', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { calculate: [{
                type: Input
            }], enabled: [{
                type: Input
            }], method: [{
                type: Input
            }] } });
class DxoChartAggregationModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartAggregationModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoChartAggregationModule, imports: [DxoChartAggregationComponent], exports: [DxoChartAggregationComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartAggregationModule, imports: [DxoChartAggregationComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartAggregationModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoChartAggregationComponent
                    ],
                    exports: [
                        DxoChartAggregationComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoChartAnimationComponent extends NestedOption {
    get duration() {
        return this._getOption('duration');
    }
    set duration(value) {
        this._setOption('duration', value);
    }
    get easing() {
        return this._getOption('easing');
    }
    set easing(value) {
        this._setOption('easing', value);
    }
    get enabled() {
        return this._getOption('enabled');
    }
    set enabled(value) {
        this._setOption('enabled', value);
    }
    get maxPointCountSupported() {
        return this._getOption('maxPointCountSupported');
    }
    set maxPointCountSupported(value) {
        this._setOption('maxPointCountSupported', value);
    }
    get _optionPath() {
        return 'animation';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartAnimationComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoChartAnimationComponent, isStandalone: true, selector: "dxo-chart-animation", inputs: { duration: "duration", easing: "easing", enabled: "enabled", maxPointCountSupported: "maxPointCountSupported" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartAnimationComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-chart-animation', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { duration: [{
                type: Input
            }], easing: [{
                type: Input
            }], enabled: [{
                type: Input
            }], maxPointCountSupported: [{
                type: Input
            }] } });
class DxoChartAnimationModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartAnimationModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoChartAnimationModule, imports: [DxoChartAnimationComponent], exports: [DxoChartAnimationComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartAnimationModule, imports: [DxoChartAnimationComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartAnimationModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoChartAnimationComponent
                    ],
                    exports: [
                        DxoChartAnimationComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoChartAnnotationBorderComponent extends NestedOption {
    get color() {
        return this._getOption('color');
    }
    set color(value) {
        this._setOption('color', value);
    }
    get cornerRadius() {
        return this._getOption('cornerRadius');
    }
    set cornerRadius(value) {
        this._setOption('cornerRadius', value);
    }
    get dashStyle() {
        return this._getOption('dashStyle');
    }
    set dashStyle(value) {
        this._setOption('dashStyle', value);
    }
    get opacity() {
        return this._getOption('opacity');
    }
    set opacity(value) {
        this._setOption('opacity', value);
    }
    get visible() {
        return this._getOption('visible');
    }
    set visible(value) {
        this._setOption('visible', value);
    }
    get width() {
        return this._getOption('width');
    }
    set width(value) {
        this._setOption('width', value);
    }
    get _optionPath() {
        return 'border';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartAnnotationBorderComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoChartAnnotationBorderComponent, isStandalone: true, selector: "dxo-chart-annotation-border", inputs: { color: "color", cornerRadius: "cornerRadius", dashStyle: "dashStyle", opacity: "opacity", visible: "visible", width: "width" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartAnnotationBorderComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-chart-annotation-border', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { color: [{
                type: Input
            }], cornerRadius: [{
                type: Input
            }], dashStyle: [{
                type: Input
            }], opacity: [{
                type: Input
            }], visible: [{
                type: Input
            }], width: [{
                type: Input
            }] } });
class DxoChartAnnotationBorderModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartAnnotationBorderModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoChartAnnotationBorderModule, imports: [DxoChartAnnotationBorderComponent], exports: [DxoChartAnnotationBorderComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartAnnotationBorderModule, imports: [DxoChartAnnotationBorderComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartAnnotationBorderModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoChartAnnotationBorderComponent
                    ],
                    exports: [
                        DxoChartAnnotationBorderComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxiChartAnnotationComponent extends CollectionNestedOption {
    get allowDragging() {
        return this._getOption('allowDragging');
    }
    set allowDragging(value) {
        this._setOption('allowDragging', value);
    }
    get argument() {
        return this._getOption('argument');
    }
    set argument(value) {
        this._setOption('argument', value);
    }
    get arrowLength() {
        return this._getOption('arrowLength');
    }
    set arrowLength(value) {
        this._setOption('arrowLength', value);
    }
    get arrowWidth() {
        return this._getOption('arrowWidth');
    }
    set arrowWidth(value) {
        this._setOption('arrowWidth', value);
    }
    get axis() {
        return this._getOption('axis');
    }
    set axis(value) {
        this._setOption('axis', value);
    }
    get border() {
        return this._getOption('border');
    }
    set border(value) {
        this._setOption('border', value);
    }
    get color() {
        return this._getOption('color');
    }
    set color(value) {
        this._setOption('color', value);
    }
    get customizeTooltip() {
        return this._getOption('customizeTooltip');
    }
    set customizeTooltip(value) {
        this._setOption('customizeTooltip', value);
    }
    get data() {
        return this._getOption('data');
    }
    set data(value) {
        this._setOption('data', value);
    }
    get description() {
        return this._getOption('description');
    }
    set description(value) {
        this._setOption('description', value);
    }
    get font() {
        return this._getOption('font');
    }
    set font(value) {
        this._setOption('font', value);
    }
    get height() {
        return this._getOption('height');
    }
    set height(value) {
        this._setOption('height', value);
    }
    get image() {
        return this._getOption('image');
    }
    set image(value) {
        this._setOption('image', value);
    }
    get name() {
        return this._getOption('name');
    }
    set name(value) {
        this._setOption('name', value);
    }
    get offsetX() {
        return this._getOption('offsetX');
    }
    set offsetX(value) {
        this._setOption('offsetX', value);
    }
    get offsetY() {
        return this._getOption('offsetY');
    }
    set offsetY(value) {
        this._setOption('offsetY', value);
    }
    get opacity() {
        return this._getOption('opacity');
    }
    set opacity(value) {
        this._setOption('opacity', value);
    }
    get paddingLeftRight() {
        return this._getOption('paddingLeftRight');
    }
    set paddingLeftRight(value) {
        this._setOption('paddingLeftRight', value);
    }
    get paddingTopBottom() {
        return this._getOption('paddingTopBottom');
    }
    set paddingTopBottom(value) {
        this._setOption('paddingTopBottom', value);
    }
    get series() {
        return this._getOption('series');
    }
    set series(value) {
        this._setOption('series', value);
    }
    get shadow() {
        return this._getOption('shadow');
    }
    set shadow(value) {
        this._setOption('shadow', value);
    }
    get template() {
        return this._getOption('template');
    }
    set template(value) {
        this._setOption('template', value);
    }
    get text() {
        return this._getOption('text');
    }
    set text(value) {
        this._setOption('text', value);
    }
    get textOverflow() {
        return this._getOption('textOverflow');
    }
    set textOverflow(value) {
        this._setOption('textOverflow', value);
    }
    get tooltipEnabled() {
        return this._getOption('tooltipEnabled');
    }
    set tooltipEnabled(value) {
        this._setOption('tooltipEnabled', value);
    }
    get tooltipTemplate() {
        return this._getOption('tooltipTemplate');
    }
    set tooltipTemplate(value) {
        this._setOption('tooltipTemplate', value);
    }
    get type() {
        return this._getOption('type');
    }
    set type(value) {
        this._setOption('type', value);
    }
    get value() {
        return this._getOption('value');
    }
    set value(value) {
        this._setOption('value', value);
    }
    get width() {
        return this._getOption('width');
    }
    set width(value) {
        this._setOption('width', value);
    }
    get wordWrap() {
        return this._getOption('wordWrap');
    }
    set wordWrap(value) {
        this._setOption('wordWrap', value);
    }
    get x() {
        return this._getOption('x');
    }
    set x(value) {
        this._setOption('x', value);
    }
    get y() {
        return this._getOption('y');
    }
    set y(value) {
        this._setOption('y', value);
    }
    get _optionPath() {
        return 'annotations';
    }
    constructor(parentOptionHost, optionHost, renderer, document, templateHost, element) {
        super();
        this.renderer = renderer;
        this.document = document;
        this.element = element;
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
        templateHost.setHost(this);
    }
    setTemplate(template) {
        this.template = template;
    }
    ngAfterViewInit() {
        extractTemplate(this, this.element, this.renderer, this.document);
    }
    ngOnDestroy() {
        this._deleteRemovedOptions(this._fullOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiChartAnnotationComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }, { token: i0.Renderer2 }, { token: DOCUMENT }, { token: i1.DxTemplateHost, host: true }, { token: i0.ElementRef }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxiChartAnnotationComponent, isStandalone: true, selector: "dxi-chart-annotation", inputs: { allowDragging: "allowDragging", argument: "argument", arrowLength: "arrowLength", arrowWidth: "arrowWidth", axis: "axis", border: "border", color: "color", customizeTooltip: "customizeTooltip", data: "data", description: "description", font: "font", height: "height", image: "image", name: "name", offsetX: "offsetX", offsetY: "offsetY", opacity: "opacity", paddingLeftRight: "paddingLeftRight", paddingTopBottom: "paddingTopBottom", series: "series", shadow: "shadow", template: "template", text: "text", textOverflow: "textOverflow", tooltipEnabled: "tooltipEnabled", tooltipTemplate: "tooltipTemplate", type: "type", value: "value", width: "width", wordWrap: "wordWrap", x: "x", y: "y" }, providers: [
            NestedOptionHost,
            DxTemplateHost,
            {
                provide: PROPERTY_TOKEN_annotations,
                useExisting: DxiChartAnnotationComponent,
            }
        ], usesInheritance: true, ngImport: i0, template: '<ng-content></ng-content>', isInline: true, styles: [":host{display:block}\n"], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiChartAnnotationComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxi-chart-annotation', template: '<ng-content></ng-content>', imports: [DxIntegrationModule], providers: [
                        NestedOptionHost,
                        DxTemplateHost,
                        {
                            provide: PROPERTY_TOKEN_annotations,
                            useExisting: DxiChartAnnotationComponent,
                        }
                    ], styles: [":host{display:block}\n"] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }, { type: i0.Renderer2 }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [DOCUMENT]
                }] }, { type: i1.DxTemplateHost, decorators: [{
                    type: Host
                }] }, { type: i0.ElementRef }], propDecorators: { allowDragging: [{
                type: Input
            }], argument: [{
                type: Input
            }], arrowLength: [{
                type: Input
            }], arrowWidth: [{
                type: Input
            }], axis: [{
                type: Input
            }], border: [{
                type: Input
            }], color: [{
                type: Input
            }], customizeTooltip: [{
                type: Input
            }], data: [{
                type: Input
            }], description: [{
                type: Input
            }], font: [{
                type: Input
            }], height: [{
                type: Input
            }], image: [{
                type: Input
            }], name: [{
                type: Input
            }], offsetX: [{
                type: Input
            }], offsetY: [{
                type: Input
            }], opacity: [{
                type: Input
            }], paddingLeftRight: [{
                type: Input
            }], paddingTopBottom: [{
                type: Input
            }], series: [{
                type: Input
            }], shadow: [{
                type: Input
            }], template: [{
                type: Input
            }], text: [{
                type: Input
            }], textOverflow: [{
                type: Input
            }], tooltipEnabled: [{
                type: Input
            }], tooltipTemplate: [{
                type: Input
            }], type: [{
                type: Input
            }], value: [{
                type: Input
            }], width: [{
                type: Input
            }], wordWrap: [{
                type: Input
            }], x: [{
                type: Input
            }], y: [{
                type: Input
            }] } });
class DxiChartAnnotationModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiChartAnnotationModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxiChartAnnotationModule, imports: [DxiChartAnnotationComponent], exports: [DxiChartAnnotationComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiChartAnnotationModule, imports: [DxiChartAnnotationComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiChartAnnotationModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxiChartAnnotationComponent
                    ],
                    exports: [
                        DxiChartAnnotationComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoChartAnnotationImageComponent extends NestedOption {
    get height() {
        return this._getOption('height');
    }
    set height(value) {
        this._setOption('height', value);
    }
    get url() {
        return this._getOption('url');
    }
    set url(value) {
        this._setOption('url', value);
    }
    get width() {
        return this._getOption('width');
    }
    set width(value) {
        this._setOption('width', value);
    }
    get _optionPath() {
        return 'image';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartAnnotationImageComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoChartAnnotationImageComponent, isStandalone: true, selector: "dxo-chart-annotation-image", inputs: { height: "height", url: "url", width: "width" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartAnnotationImageComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-chart-annotation-image', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { height: [{
                type: Input
            }], url: [{
                type: Input
            }], width: [{
                type: Input
            }] } });
class DxoChartAnnotationImageModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartAnnotationImageModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoChartAnnotationImageModule, imports: [DxoChartAnnotationImageComponent], exports: [DxoChartAnnotationImageComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartAnnotationImageModule, imports: [DxoChartAnnotationImageComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartAnnotationImageModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoChartAnnotationImageComponent
                    ],
                    exports: [
                        DxoChartAnnotationImageComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoChartArgumentAxisComponent extends NestedOption {
    set _breaksContentChildren(value) {
        this.setChildren('breaks', value);
    }
    set _constantLinesContentChildren(value) {
        this.setChildren('constantLines', value);
    }
    set _stripsContentChildren(value) {
        this.setChildren('strips', value);
    }
    get aggregatedPointsPosition() {
        return this._getOption('aggregatedPointsPosition');
    }
    set aggregatedPointsPosition(value) {
        this._setOption('aggregatedPointsPosition', value);
    }
    get aggregationGroupWidth() {
        return this._getOption('aggregationGroupWidth');
    }
    set aggregationGroupWidth(value) {
        this._setOption('aggregationGroupWidth', value);
    }
    get aggregationInterval() {
        return this._getOption('aggregationInterval');
    }
    set aggregationInterval(value) {
        this._setOption('aggregationInterval', value);
    }
    get allowDecimals() {
        return this._getOption('allowDecimals');
    }
    set allowDecimals(value) {
        this._setOption('allowDecimals', value);
    }
    get argumentType() {
        return this._getOption('argumentType');
    }
    set argumentType(value) {
        this._setOption('argumentType', value);
    }
    get axisDivisionFactor() {
        return this._getOption('axisDivisionFactor');
    }
    set axisDivisionFactor(value) {
        this._setOption('axisDivisionFactor', value);
    }
    get breaks() {
        return this._getOption('breaks');
    }
    set breaks(value) {
        this._setOption('breaks', value);
    }
    get breakStyle() {
        return this._getOption('breakStyle');
    }
    set breakStyle(value) {
        this._setOption('breakStyle', value);
    }
    get categories() {
        return this._getOption('categories');
    }
    set categories(value) {
        this._setOption('categories', value);
    }
    get color() {
        return this._getOption('color');
    }
    set color(value) {
        this._setOption('color', value);
    }
    get constantLines() {
        return this._getOption('constantLines');
    }
    set constantLines(value) {
        this._setOption('constantLines', value);
    }
    get constantLineStyle() {
        return this._getOption('constantLineStyle');
    }
    set constantLineStyle(value) {
        this._setOption('constantLineStyle', value);
    }
    get customPosition() {
        return this._getOption('customPosition');
    }
    set customPosition(value) {
        this._setOption('customPosition', value);
    }
    get customPositionAxis() {
        return this._getOption('customPositionAxis');
    }
    set customPositionAxis(value) {
        this._setOption('customPositionAxis', value);
    }
    get discreteAxisDivisionMode() {
        return this._getOption('discreteAxisDivisionMode');
    }
    set discreteAxisDivisionMode(value) {
        this._setOption('discreteAxisDivisionMode', value);
    }
    get endOnTick() {
        return this._getOption('endOnTick');
    }
    set endOnTick(value) {
        this._setOption('endOnTick', value);
    }
    get grid() {
        return this._getOption('grid');
    }
    set grid(value) {
        this._setOption('grid', value);
    }
    get holidays() {
        return this._getOption('holidays');
    }
    set holidays(value) {
        this._setOption('holidays', value);
    }
    get hoverMode() {
        return this._getOption('hoverMode');
    }
    set hoverMode(value) {
        this._setOption('hoverMode', value);
    }
    get inverted() {
        return this._getOption('inverted');
    }
    set inverted(value) {
        this._setOption('inverted', value);
    }
    get label() {
        return this._getOption('label');
    }
    set label(value) {
        this._setOption('label', value);
    }
    get linearThreshold() {
        return this._getOption('linearThreshold');
    }
    set linearThreshold(value) {
        this._setOption('linearThreshold', value);
    }
    get logarithmBase() {
        return this._getOption('logarithmBase');
    }
    set logarithmBase(value) {
        this._setOption('logarithmBase', value);
    }
    get maxValueMargin() {
        return this._getOption('maxValueMargin');
    }
    set maxValueMargin(value) {
        this._setOption('maxValueMargin', value);
    }
    get minorGrid() {
        return this._getOption('minorGrid');
    }
    set minorGrid(value) {
        this._setOption('minorGrid', value);
    }
    get minorTick() {
        return this._getOption('minorTick');
    }
    set minorTick(value) {
        this._setOption('minorTick', value);
    }
    get minorTickCount() {
        return this._getOption('minorTickCount');
    }
    set minorTickCount(value) {
        this._setOption('minorTickCount', value);
    }
    get minorTickInterval() {
        return this._getOption('minorTickInterval');
    }
    set minorTickInterval(value) {
        this._setOption('minorTickInterval', value);
    }
    get minValueMargin() {
        return this._getOption('minValueMargin');
    }
    set minValueMargin(value) {
        this._setOption('minValueMargin', value);
    }
    get minVisualRangeLength() {
        return this._getOption('minVisualRangeLength');
    }
    set minVisualRangeLength(value) {
        this._setOption('minVisualRangeLength', value);
    }
    get offset() {
        return this._getOption('offset');
    }
    set offset(value) {
        this._setOption('offset', value);
    }
    get opacity() {
        return this._getOption('opacity');
    }
    set opacity(value) {
        this._setOption('opacity', value);
    }
    get placeholderSize() {
        return this._getOption('placeholderSize');
    }
    set placeholderSize(value) {
        this._setOption('placeholderSize', value);
    }
    get position() {
        return this._getOption('position');
    }
    set position(value) {
        this._setOption('position', value);
    }
    get singleWorkdays() {
        return this._getOption('singleWorkdays');
    }
    set singleWorkdays(value) {
        this._setOption('singleWorkdays', value);
    }
    get strips() {
        return this._getOption('strips');
    }
    set strips(value) {
        this._setOption('strips', value);
    }
    get stripStyle() {
        return this._getOption('stripStyle');
    }
    set stripStyle(value) {
        this._setOption('stripStyle', value);
    }
    get tick() {
        return this._getOption('tick');
    }
    set tick(value) {
        this._setOption('tick', value);
    }
    get tickInterval() {
        return this._getOption('tickInterval');
    }
    set tickInterval(value) {
        this._setOption('tickInterval', value);
    }
    get title() {
        return this._getOption('title');
    }
    set title(value) {
        this._setOption('title', value);
    }
    get type() {
        return this._getOption('type');
    }
    set type(value) {
        this._setOption('type', value);
    }
    get valueMarginsEnabled() {
        return this._getOption('valueMarginsEnabled');
    }
    set valueMarginsEnabled(value) {
        this._setOption('valueMarginsEnabled', value);
    }
    get visible() {
        return this._getOption('visible');
    }
    set visible(value) {
        this._setOption('visible', value);
    }
    get visualRange() {
        return this._getOption('visualRange');
    }
    set visualRange(value) {
        this._setOption('visualRange', value);
    }
    get visualRangeUpdateMode() {
        return this._getOption('visualRangeUpdateMode');
    }
    set visualRangeUpdateMode(value) {
        this._setOption('visualRangeUpdateMode', value);
    }
    get wholeRange() {
        return this._getOption('wholeRange');
    }
    set wholeRange(value) {
        this._setOption('wholeRange', value);
    }
    get width() {
        return this._getOption('width');
    }
    set width(value) {
        this._setOption('width', value);
    }
    get workdaysOnly() {
        return this._getOption('workdaysOnly');
    }
    set workdaysOnly(value) {
        this._setOption('workdaysOnly', value);
    }
    get workWeek() {
        return this._getOption('workWeek');
    }
    set workWeek(value) {
        this._setOption('workWeek', value);
    }
    get _optionPath() {
        return 'argumentAxis';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        this._createEventEmitters([
            { emit: 'categoriesChange' },
            { emit: 'visualRangeChange' }
        ]);
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartArgumentAxisComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoChartArgumentAxisComponent, isStandalone: true, selector: "dxo-chart-argument-axis", inputs: { aggregatedPointsPosition: "aggregatedPointsPosition", aggregationGroupWidth: "aggregationGroupWidth", aggregationInterval: "aggregationInterval", allowDecimals: "allowDecimals", argumentType: "argumentType", axisDivisionFactor: "axisDivisionFactor", breaks: "breaks", breakStyle: "breakStyle", categories: "categories", color: "color", constantLines: "constantLines", constantLineStyle: "constantLineStyle", customPosition: "customPosition", customPositionAxis: "customPositionAxis", discreteAxisDivisionMode: "discreteAxisDivisionMode", endOnTick: "endOnTick", grid: "grid", holidays: "holidays", hoverMode: "hoverMode", inverted: "inverted", label: "label", linearThreshold: "linearThreshold", logarithmBase: "logarithmBase", maxValueMargin: "maxValueMargin", minorGrid: "minorGrid", minorTick: "minorTick", minorTickCount: "minorTickCount", minorTickInterval: "minorTickInterval", minValueMargin: "minValueMargin", minVisualRangeLength: "minVisualRangeLength", offset: "offset", opacity: "opacity", placeholderSize: "placeholderSize", position: "position", singleWorkdays: "singleWorkdays", strips: "strips", stripStyle: "stripStyle", tick: "tick", tickInterval: "tickInterval", title: "title", type: "type", valueMarginsEnabled: "valueMarginsEnabled", visible: "visible", visualRange: "visualRange", visualRangeUpdateMode: "visualRangeUpdateMode", wholeRange: "wholeRange", width: "width", workdaysOnly: "workdaysOnly", workWeek: "workWeek" }, outputs: { categoriesChange: "categoriesChange", visualRangeChange: "visualRangeChange" }, providers: [NestedOptionHost], queries: [{ propertyName: "_breaksContentChildren", predicate: PROPERTY_TOKEN_breaks }, { propertyName: "_constantLinesContentChildren", predicate: PROPERTY_TOKEN_constantLines }, { propertyName: "_stripsContentChildren", predicate: PROPERTY_TOKEN_strips }], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartArgumentAxisComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-chart-argument-axis', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { _breaksContentChildren: [{
                type: ContentChildren,
                args: [PROPERTY_TOKEN_breaks]
            }], _constantLinesContentChildren: [{
                type: ContentChildren,
                args: [PROPERTY_TOKEN_constantLines]
            }], _stripsContentChildren: [{
                type: ContentChildren,
                args: [PROPERTY_TOKEN_strips]
            }], aggregatedPointsPosition: [{
                type: Input
            }], aggregationGroupWidth: [{
                type: Input
            }], aggregationInterval: [{
                type: Input
            }], allowDecimals: [{
                type: Input
            }], argumentType: [{
                type: Input
            }], axisDivisionFactor: [{
                type: Input
            }], breaks: [{
                type: Input
            }], breakStyle: [{
                type: Input
            }], categories: [{
                type: Input
            }], color: [{
                type: Input
            }], constantLines: [{
                type: Input
            }], constantLineStyle: [{
                type: Input
            }], customPosition: [{
                type: Input
            }], customPositionAxis: [{
                type: Input
            }], discreteAxisDivisionMode: [{
                type: Input
            }], endOnTick: [{
                type: Input
            }], grid: [{
                type: Input
            }], holidays: [{
                type: Input
            }], hoverMode: [{
                type: Input
            }], inverted: [{
                type: Input
            }], label: [{
                type: Input
            }], linearThreshold: [{
                type: Input
            }], logarithmBase: [{
                type: Input
            }], maxValueMargin: [{
                type: Input
            }], minorGrid: [{
                type: Input
            }], minorTick: [{
                type: Input
            }], minorTickCount: [{
                type: Input
            }], minorTickInterval: [{
                type: Input
            }], minValueMargin: [{
                type: Input
            }], minVisualRangeLength: [{
                type: Input
            }], offset: [{
                type: Input
            }], opacity: [{
                type: Input
            }], placeholderSize: [{
                type: Input
            }], position: [{
                type: Input
            }], singleWorkdays: [{
                type: Input
            }], strips: [{
                type: Input
            }], stripStyle: [{
                type: Input
            }], tick: [{
                type: Input
            }], tickInterval: [{
                type: Input
            }], title: [{
                type: Input
            }], type: [{
                type: Input
            }], valueMarginsEnabled: [{
                type: Input
            }], visible: [{
                type: Input
            }], visualRange: [{
                type: Input
            }], visualRangeUpdateMode: [{
                type: Input
            }], wholeRange: [{
                type: Input
            }], width: [{
                type: Input
            }], workdaysOnly: [{
                type: Input
            }], workWeek: [{
                type: Input
            }], categoriesChange: [{
                type: Output
            }], visualRangeChange: [{
                type: Output
            }] } });
class DxoChartArgumentAxisModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartArgumentAxisModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoChartArgumentAxisModule, imports: [DxoChartArgumentAxisComponent], exports: [DxoChartArgumentAxisComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartArgumentAxisModule, imports: [DxoChartArgumentAxisComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartArgumentAxisModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoChartArgumentAxisComponent
                    ],
                    exports: [
                        DxoChartArgumentAxisComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoChartArgumentFormatComponent extends NestedOption {
    get currency() {
        return this._getOption('currency');
    }
    set currency(value) {
        this._setOption('currency', value);
    }
    get formatter() {
        return this._getOption('formatter');
    }
    set formatter(value) {
        this._setOption('formatter', value);
    }
    get parser() {
        return this._getOption('parser');
    }
    set parser(value) {
        this._setOption('parser', value);
    }
    get precision() {
        return this._getOption('precision');
    }
    set precision(value) {
        this._setOption('precision', value);
    }
    get type() {
        return this._getOption('type');
    }
    set type(value) {
        this._setOption('type', value);
    }
    get useCurrencyAccountingStyle() {
        return this._getOption('useCurrencyAccountingStyle');
    }
    set useCurrencyAccountingStyle(value) {
        this._setOption('useCurrencyAccountingStyle', value);
    }
    get _optionPath() {
        return 'argumentFormat';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartArgumentFormatComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoChartArgumentFormatComponent, isStandalone: true, selector: "dxo-chart-argument-format", inputs: { currency: "currency", formatter: "formatter", parser: "parser", precision: "precision", type: "type", useCurrencyAccountingStyle: "useCurrencyAccountingStyle" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartArgumentFormatComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-chart-argument-format', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { currency: [{
                type: Input
            }], formatter: [{
                type: Input
            }], parser: [{
                type: Input
            }], precision: [{
                type: Input
            }], type: [{
                type: Input
            }], useCurrencyAccountingStyle: [{
                type: Input
            }] } });
class DxoChartArgumentFormatModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartArgumentFormatModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoChartArgumentFormatModule, imports: [DxoChartArgumentFormatComponent], exports: [DxoChartArgumentFormatComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartArgumentFormatModule, imports: [DxoChartArgumentFormatComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartArgumentFormatModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoChartArgumentFormatComponent
                    ],
                    exports: [
                        DxoChartArgumentFormatComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoChartAxisConstantLineStyleLabelComponent extends NestedOption {
    get font() {
        return this._getOption('font');
    }
    set font(value) {
        this._setOption('font', value);
    }
    get horizontalAlignment() {
        return this._getOption('horizontalAlignment');
    }
    set horizontalAlignment(value) {
        this._setOption('horizontalAlignment', value);
    }
    get position() {
        return this._getOption('position');
    }
    set position(value) {
        this._setOption('position', value);
    }
    get verticalAlignment() {
        return this._getOption('verticalAlignment');
    }
    set verticalAlignment(value) {
        this._setOption('verticalAlignment', value);
    }
    get visible() {
        return this._getOption('visible');
    }
    set visible(value) {
        this._setOption('visible', value);
    }
    get _optionPath() {
        return 'label';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartAxisConstantLineStyleLabelComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoChartAxisConstantLineStyleLabelComponent, isStandalone: true, selector: "dxo-chart-axis-constant-line-style-label", inputs: { font: "font", horizontalAlignment: "horizontalAlignment", position: "position", verticalAlignment: "verticalAlignment", visible: "visible" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartAxisConstantLineStyleLabelComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-chart-axis-constant-line-style-label', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { font: [{
                type: Input
            }], horizontalAlignment: [{
                type: Input
            }], position: [{
                type: Input
            }], verticalAlignment: [{
                type: Input
            }], visible: [{
                type: Input
            }] } });
class DxoChartAxisConstantLineStyleLabelModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartAxisConstantLineStyleLabelModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoChartAxisConstantLineStyleLabelModule, imports: [DxoChartAxisConstantLineStyleLabelComponent], exports: [DxoChartAxisConstantLineStyleLabelComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartAxisConstantLineStyleLabelModule, imports: [DxoChartAxisConstantLineStyleLabelComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartAxisConstantLineStyleLabelModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoChartAxisConstantLineStyleLabelComponent
                    ],
                    exports: [
                        DxoChartAxisConstantLineStyleLabelComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoChartAxisConstantLineStyleComponent extends NestedOption {
    get color() {
        return this._getOption('color');
    }
    set color(value) {
        this._setOption('color', value);
    }
    get dashStyle() {
        return this._getOption('dashStyle');
    }
    set dashStyle(value) {
        this._setOption('dashStyle', value);
    }
    get label() {
        return this._getOption('label');
    }
    set label(value) {
        this._setOption('label', value);
    }
    get paddingLeftRight() {
        return this._getOption('paddingLeftRight');
    }
    set paddingLeftRight(value) {
        this._setOption('paddingLeftRight', value);
    }
    get paddingTopBottom() {
        return this._getOption('paddingTopBottom');
    }
    set paddingTopBottom(value) {
        this._setOption('paddingTopBottom', value);
    }
    get width() {
        return this._getOption('width');
    }
    set width(value) {
        this._setOption('width', value);
    }
    get _optionPath() {
        return 'constantLineStyle';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartAxisConstantLineStyleComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoChartAxisConstantLineStyleComponent, isStandalone: true, selector: "dxo-chart-axis-constant-line-style", inputs: { color: "color", dashStyle: "dashStyle", label: "label", paddingLeftRight: "paddingLeftRight", paddingTopBottom: "paddingTopBottom", width: "width" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartAxisConstantLineStyleComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-chart-axis-constant-line-style', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { color: [{
                type: Input
            }], dashStyle: [{
                type: Input
            }], label: [{
                type: Input
            }], paddingLeftRight: [{
                type: Input
            }], paddingTopBottom: [{
                type: Input
            }], width: [{
                type: Input
            }] } });
class DxoChartAxisConstantLineStyleModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartAxisConstantLineStyleModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoChartAxisConstantLineStyleModule, imports: [DxoChartAxisConstantLineStyleComponent], exports: [DxoChartAxisConstantLineStyleComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartAxisConstantLineStyleModule, imports: [DxoChartAxisConstantLineStyleComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartAxisConstantLineStyleModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoChartAxisConstantLineStyleComponent
                    ],
                    exports: [
                        DxoChartAxisConstantLineStyleComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoChartAxisLabelComponent extends NestedOption {
    get alignment() {
        return this._getOption('alignment');
    }
    set alignment(value) {
        this._setOption('alignment', value);
    }
    get customizeHint() {
        return this._getOption('customizeHint');
    }
    set customizeHint(value) {
        this._setOption('customizeHint', value);
    }
    get customizeText() {
        return this._getOption('customizeText');
    }
    set customizeText(value) {
        this._setOption('customizeText', value);
    }
    get displayMode() {
        return this._getOption('displayMode');
    }
    set displayMode(value) {
        this._setOption('displayMode', value);
    }
    get font() {
        return this._getOption('font');
    }
    set font(value) {
        this._setOption('font', value);
    }
    get format() {
        return this._getOption('format');
    }
    set format(value) {
        this._setOption('format', value);
    }
    get indentFromAxis() {
        return this._getOption('indentFromAxis');
    }
    set indentFromAxis(value) {
        this._setOption('indentFromAxis', value);
    }
    get overlappingBehavior() {
        return this._getOption('overlappingBehavior');
    }
    set overlappingBehavior(value) {
        this._setOption('overlappingBehavior', value);
    }
    get position() {
        return this._getOption('position');
    }
    set position(value) {
        this._setOption('position', value);
    }
    get rotationAngle() {
        return this._getOption('rotationAngle');
    }
    set rotationAngle(value) {
        this._setOption('rotationAngle', value);
    }
    get staggeringSpacing() {
        return this._getOption('staggeringSpacing');
    }
    set staggeringSpacing(value) {
        this._setOption('staggeringSpacing', value);
    }
    get template() {
        return this._getOption('template');
    }
    set template(value) {
        this._setOption('template', value);
    }
    get textOverflow() {
        return this._getOption('textOverflow');
    }
    set textOverflow(value) {
        this._setOption('textOverflow', value);
    }
    get visible() {
        return this._getOption('visible');
    }
    set visible(value) {
        this._setOption('visible', value);
    }
    get wordWrap() {
        return this._getOption('wordWrap');
    }
    set wordWrap(value) {
        this._setOption('wordWrap', value);
    }
    get _optionPath() {
        return 'label';
    }
    constructor(parentOptionHost, optionHost, renderer, document, templateHost, element) {
        super();
        this.renderer = renderer;
        this.document = document;
        this.element = element;
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
        templateHost.setHost(this);
    }
    setTemplate(template) {
        this.template = template;
    }
    ngAfterViewInit() {
        extractTemplate(this, this.element, this.renderer, this.document);
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartAxisLabelComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }, { token: i0.Renderer2 }, { token: DOCUMENT }, { token: i1.DxTemplateHost, host: true }, { token: i0.ElementRef }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoChartAxisLabelComponent, isStandalone: true, selector: "dxo-chart-axis-label", inputs: { alignment: "alignment", customizeHint: "customizeHint", customizeText: "customizeText", displayMode: "displayMode", font: "font", format: "format", indentFromAxis: "indentFromAxis", overlappingBehavior: "overlappingBehavior", position: "position", rotationAngle: "rotationAngle", staggeringSpacing: "staggeringSpacing", template: "template", textOverflow: "textOverflow", visible: "visible", wordWrap: "wordWrap" }, providers: [NestedOptionHost, DxTemplateHost], usesInheritance: true, ngImport: i0, template: '<ng-content></ng-content>', isInline: true, styles: [":host{display:block}\n"], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartAxisLabelComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-chart-axis-label', template: '<ng-content></ng-content>', imports: [DxIntegrationModule], providers: [NestedOptionHost, DxTemplateHost], styles: [":host{display:block}\n"] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }, { type: i0.Renderer2 }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [DOCUMENT]
                }] }, { type: i1.DxTemplateHost, decorators: [{
                    type: Host
                }] }, { type: i0.ElementRef }], propDecorators: { alignment: [{
                type: Input
            }], customizeHint: [{
                type: Input
            }], customizeText: [{
                type: Input
            }], displayMode: [{
                type: Input
            }], font: [{
                type: Input
            }], format: [{
                type: Input
            }], indentFromAxis: [{
                type: Input
            }], overlappingBehavior: [{
                type: Input
            }], position: [{
                type: Input
            }], rotationAngle: [{
                type: Input
            }], staggeringSpacing: [{
                type: Input
            }], template: [{
                type: Input
            }], textOverflow: [{
                type: Input
            }], visible: [{
                type: Input
            }], wordWrap: [{
                type: Input
            }] } });
class DxoChartAxisLabelModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartAxisLabelModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoChartAxisLabelModule, imports: [DxoChartAxisLabelComponent], exports: [DxoChartAxisLabelComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartAxisLabelModule, imports: [DxoChartAxisLabelComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartAxisLabelModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoChartAxisLabelComponent
                    ],
                    exports: [
                        DxoChartAxisLabelComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoChartAxisTitleComponent extends NestedOption {
    get alignment() {
        return this._getOption('alignment');
    }
    set alignment(value) {
        this._setOption('alignment', value);
    }
    get font() {
        return this._getOption('font');
    }
    set font(value) {
        this._setOption('font', value);
    }
    get margin() {
        return this._getOption('margin');
    }
    set margin(value) {
        this._setOption('margin', value);
    }
    get text() {
        return this._getOption('text');
    }
    set text(value) {
        this._setOption('text', value);
    }
    get textOverflow() {
        return this._getOption('textOverflow');
    }
    set textOverflow(value) {
        this._setOption('textOverflow', value);
    }
    get wordWrap() {
        return this._getOption('wordWrap');
    }
    set wordWrap(value) {
        this._setOption('wordWrap', value);
    }
    get _optionPath() {
        return 'title';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartAxisTitleComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoChartAxisTitleComponent, isStandalone: true, selector: "dxo-chart-axis-title", inputs: { alignment: "alignment", font: "font", margin: "margin", text: "text", textOverflow: "textOverflow", wordWrap: "wordWrap" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartAxisTitleComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-chart-axis-title', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { alignment: [{
                type: Input
            }], font: [{
                type: Input
            }], margin: [{
                type: Input
            }], text: [{
                type: Input
            }], textOverflow: [{
                type: Input
            }], wordWrap: [{
                type: Input
            }] } });
class DxoChartAxisTitleModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartAxisTitleModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoChartAxisTitleModule, imports: [DxoChartAxisTitleComponent], exports: [DxoChartAxisTitleComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartAxisTitleModule, imports: [DxoChartAxisTitleComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartAxisTitleModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoChartAxisTitleComponent
                    ],
                    exports: [
                        DxoChartAxisTitleComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoChartBackgroundColorComponent extends NestedOption {
    get base() {
        return this._getOption('base');
    }
    set base(value) {
        this._setOption('base', value);
    }
    get fillId() {
        return this._getOption('fillId');
    }
    set fillId(value) {
        this._setOption('fillId', value);
    }
    get _optionPath() {
        return 'backgroundColor';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartBackgroundColorComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoChartBackgroundColorComponent, isStandalone: true, selector: "dxo-chart-background-color", inputs: { base: "base", fillId: "fillId" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartBackgroundColorComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-chart-background-color', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { base: [{
                type: Input
            }], fillId: [{
                type: Input
            }] } });
class DxoChartBackgroundColorModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartBackgroundColorModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoChartBackgroundColorModule, imports: [DxoChartBackgroundColorComponent], exports: [DxoChartBackgroundColorComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartBackgroundColorModule, imports: [DxoChartBackgroundColorComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartBackgroundColorModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoChartBackgroundColorComponent
                    ],
                    exports: [
                        DxoChartBackgroundColorComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoChartBorderComponent extends NestedOption {
    get color() {
        return this._getOption('color');
    }
    set color(value) {
        this._setOption('color', value);
    }
    get cornerRadius() {
        return this._getOption('cornerRadius');
    }
    set cornerRadius(value) {
        this._setOption('cornerRadius', value);
    }
    get dashStyle() {
        return this._getOption('dashStyle');
    }
    set dashStyle(value) {
        this._setOption('dashStyle', value);
    }
    get opacity() {
        return this._getOption('opacity');
    }
    set opacity(value) {
        this._setOption('opacity', value);
    }
    get visible() {
        return this._getOption('visible');
    }
    set visible(value) {
        this._setOption('visible', value);
    }
    get width() {
        return this._getOption('width');
    }
    set width(value) {
        this._setOption('width', value);
    }
    get bottom() {
        return this._getOption('bottom');
    }
    set bottom(value) {
        this._setOption('bottom', value);
    }
    get left() {
        return this._getOption('left');
    }
    set left(value) {
        this._setOption('left', value);
    }
    get right() {
        return this._getOption('right');
    }
    set right(value) {
        this._setOption('right', value);
    }
    get top() {
        return this._getOption('top');
    }
    set top(value) {
        this._setOption('top', value);
    }
    get _optionPath() {
        return 'border';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartBorderComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoChartBorderComponent, isStandalone: true, selector: "dxo-chart-border", inputs: { color: "color", cornerRadius: "cornerRadius", dashStyle: "dashStyle", opacity: "opacity", visible: "visible", width: "width", bottom: "bottom", left: "left", right: "right", top: "top" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartBorderComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-chart-border', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { color: [{
                type: Input
            }], cornerRadius: [{
                type: Input
            }], dashStyle: [{
                type: Input
            }], opacity: [{
                type: Input
            }], visible: [{
                type: Input
            }], width: [{
                type: Input
            }], bottom: [{
                type: Input
            }], left: [{
                type: Input
            }], right: [{
                type: Input
            }], top: [{
                type: Input
            }] } });
class DxoChartBorderModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartBorderModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoChartBorderModule, imports: [DxoChartBorderComponent], exports: [DxoChartBorderComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartBorderModule, imports: [DxoChartBorderComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartBorderModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoChartBorderComponent
                    ],
                    exports: [
                        DxoChartBorderComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxiChartBreakComponent extends CollectionNestedOption {
    get endValue() {
        return this._getOption('endValue');
    }
    set endValue(value) {
        this._setOption('endValue', value);
    }
    get startValue() {
        return this._getOption('startValue');
    }
    set startValue(value) {
        this._setOption('startValue', value);
    }
    get _optionPath() {
        return 'breaks';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnDestroy() {
        this._deleteRemovedOptions(this._fullOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiChartBreakComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxiChartBreakComponent, isStandalone: true, selector: "dxi-chart-break", inputs: { endValue: "endValue", startValue: "startValue" }, providers: [
            NestedOptionHost,
            {
                provide: PROPERTY_TOKEN_breaks,
                useExisting: DxiChartBreakComponent,
            }
        ], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiChartBreakComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxi-chart-break', template: '', imports: [DxIntegrationModule], providers: [
                        NestedOptionHost,
                        {
                            provide: PROPERTY_TOKEN_breaks,
                            useExisting: DxiChartBreakComponent,
                        }
                    ] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { endValue: [{
                type: Input
            }], startValue: [{
                type: Input
            }] } });
class DxiChartBreakModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiChartBreakModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxiChartBreakModule, imports: [DxiChartBreakComponent], exports: [DxiChartBreakComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiChartBreakModule, imports: [DxiChartBreakComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiChartBreakModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxiChartBreakComponent
                    ],
                    exports: [
                        DxiChartBreakComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoChartBreakStyleComponent extends NestedOption {
    get color() {
        return this._getOption('color');
    }
    set color(value) {
        this._setOption('color', value);
    }
    get line() {
        return this._getOption('line');
    }
    set line(value) {
        this._setOption('line', value);
    }
    get width() {
        return this._getOption('width');
    }
    set width(value) {
        this._setOption('width', value);
    }
    get _optionPath() {
        return 'breakStyle';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartBreakStyleComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoChartBreakStyleComponent, isStandalone: true, selector: "dxo-chart-break-style", inputs: { color: "color", line: "line", width: "width" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartBreakStyleComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-chart-break-style', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { color: [{
                type: Input
            }], line: [{
                type: Input
            }], width: [{
                type: Input
            }] } });
class DxoChartBreakStyleModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartBreakStyleModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoChartBreakStyleModule, imports: [DxoChartBreakStyleComponent], exports: [DxoChartBreakStyleComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartBreakStyleModule, imports: [DxoChartBreakStyleComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartBreakStyleModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoChartBreakStyleComponent
                    ],
                    exports: [
                        DxoChartBreakStyleComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoChartChartTitleSubtitleComponent extends NestedOption {
    get font() {
        return this._getOption('font');
    }
    set font(value) {
        this._setOption('font', value);
    }
    get offset() {
        return this._getOption('offset');
    }
    set offset(value) {
        this._setOption('offset', value);
    }
    get text() {
        return this._getOption('text');
    }
    set text(value) {
        this._setOption('text', value);
    }
    get textOverflow() {
        return this._getOption('textOverflow');
    }
    set textOverflow(value) {
        this._setOption('textOverflow', value);
    }
    get wordWrap() {
        return this._getOption('wordWrap');
    }
    set wordWrap(value) {
        this._setOption('wordWrap', value);
    }
    get _optionPath() {
        return 'subtitle';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartChartTitleSubtitleComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoChartChartTitleSubtitleComponent, isStandalone: true, selector: "dxo-chart-chart-title-subtitle", inputs: { font: "font", offset: "offset", text: "text", textOverflow: "textOverflow", wordWrap: "wordWrap" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartChartTitleSubtitleComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-chart-chart-title-subtitle', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { font: [{
                type: Input
            }], offset: [{
                type: Input
            }], text: [{
                type: Input
            }], textOverflow: [{
                type: Input
            }], wordWrap: [{
                type: Input
            }] } });
class DxoChartChartTitleSubtitleModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartChartTitleSubtitleModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoChartChartTitleSubtitleModule, imports: [DxoChartChartTitleSubtitleComponent], exports: [DxoChartChartTitleSubtitleComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartChartTitleSubtitleModule, imports: [DxoChartChartTitleSubtitleComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartChartTitleSubtitleModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoChartChartTitleSubtitleComponent
                    ],
                    exports: [
                        DxoChartChartTitleSubtitleComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoChartChartTitleComponent extends NestedOption {
    get font() {
        return this._getOption('font');
    }
    set font(value) {
        this._setOption('font', value);
    }
    get horizontalAlignment() {
        return this._getOption('horizontalAlignment');
    }
    set horizontalAlignment(value) {
        this._setOption('horizontalAlignment', value);
    }
    get margin() {
        return this._getOption('margin');
    }
    set margin(value) {
        this._setOption('margin', value);
    }
    get placeholderSize() {
        return this._getOption('placeholderSize');
    }
    set placeholderSize(value) {
        this._setOption('placeholderSize', value);
    }
    get subtitle() {
        return this._getOption('subtitle');
    }
    set subtitle(value) {
        this._setOption('subtitle', value);
    }
    get text() {
        return this._getOption('text');
    }
    set text(value) {
        this._setOption('text', value);
    }
    get textOverflow() {
        return this._getOption('textOverflow');
    }
    set textOverflow(value) {
        this._setOption('textOverflow', value);
    }
    get verticalAlignment() {
        return this._getOption('verticalAlignment');
    }
    set verticalAlignment(value) {
        this._setOption('verticalAlignment', value);
    }
    get wordWrap() {
        return this._getOption('wordWrap');
    }
    set wordWrap(value) {
        this._setOption('wordWrap', value);
    }
    get _optionPath() {
        return 'title';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartChartTitleComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoChartChartTitleComponent, isStandalone: true, selector: "dxo-chart-chart-title", inputs: { font: "font", horizontalAlignment: "horizontalAlignment", margin: "margin", placeholderSize: "placeholderSize", subtitle: "subtitle", text: "text", textOverflow: "textOverflow", verticalAlignment: "verticalAlignment", wordWrap: "wordWrap" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartChartTitleComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-chart-chart-title', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { font: [{
                type: Input
            }], horizontalAlignment: [{
                type: Input
            }], margin: [{
                type: Input
            }], placeholderSize: [{
                type: Input
            }], subtitle: [{
                type: Input
            }], text: [{
                type: Input
            }], textOverflow: [{
                type: Input
            }], verticalAlignment: [{
                type: Input
            }], wordWrap: [{
                type: Input
            }] } });
class DxoChartChartTitleModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartChartTitleModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoChartChartTitleModule, imports: [DxoChartChartTitleComponent], exports: [DxoChartChartTitleComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartChartTitleModule, imports: [DxoChartChartTitleComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartChartTitleModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoChartChartTitleComponent
                    ],
                    exports: [
                        DxoChartChartTitleComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoChartColorComponent extends NestedOption {
    get base() {
        return this._getOption('base');
    }
    set base(value) {
        this._setOption('base', value);
    }
    get fillId() {
        return this._getOption('fillId');
    }
    set fillId(value) {
        this._setOption('fillId', value);
    }
    get _optionPath() {
        return 'color';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartColorComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoChartColorComponent, isStandalone: true, selector: "dxo-chart-color", inputs: { base: "base", fillId: "fillId" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartColorComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-chart-color', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { base: [{
                type: Input
            }], fillId: [{
                type: Input
            }] } });
class DxoChartColorModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartColorModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoChartColorModule, imports: [DxoChartColorComponent], exports: [DxoChartColorComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartColorModule, imports: [DxoChartColorComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartColorModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoChartColorComponent
                    ],
                    exports: [
                        DxoChartColorComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoChartCommonAnnotationSettingsComponent extends NestedOption {
    get allowDragging() {
        return this._getOption('allowDragging');
    }
    set allowDragging(value) {
        this._setOption('allowDragging', value);
    }
    get argument() {
        return this._getOption('argument');
    }
    set argument(value) {
        this._setOption('argument', value);
    }
    get arrowLength() {
        return this._getOption('arrowLength');
    }
    set arrowLength(value) {
        this._setOption('arrowLength', value);
    }
    get arrowWidth() {
        return this._getOption('arrowWidth');
    }
    set arrowWidth(value) {
        this._setOption('arrowWidth', value);
    }
    get axis() {
        return this._getOption('axis');
    }
    set axis(value) {
        this._setOption('axis', value);
    }
    get border() {
        return this._getOption('border');
    }
    set border(value) {
        this._setOption('border', value);
    }
    get color() {
        return this._getOption('color');
    }
    set color(value) {
        this._setOption('color', value);
    }
    get customizeTooltip() {
        return this._getOption('customizeTooltip');
    }
    set customizeTooltip(value) {
        this._setOption('customizeTooltip', value);
    }
    get data() {
        return this._getOption('data');
    }
    set data(value) {
        this._setOption('data', value);
    }
    get description() {
        return this._getOption('description');
    }
    set description(value) {
        this._setOption('description', value);
    }
    get font() {
        return this._getOption('font');
    }
    set font(value) {
        this._setOption('font', value);
    }
    get height() {
        return this._getOption('height');
    }
    set height(value) {
        this._setOption('height', value);
    }
    get image() {
        return this._getOption('image');
    }
    set image(value) {
        this._setOption('image', value);
    }
    get offsetX() {
        return this._getOption('offsetX');
    }
    set offsetX(value) {
        this._setOption('offsetX', value);
    }
    get offsetY() {
        return this._getOption('offsetY');
    }
    set offsetY(value) {
        this._setOption('offsetY', value);
    }
    get opacity() {
        return this._getOption('opacity');
    }
    set opacity(value) {
        this._setOption('opacity', value);
    }
    get paddingLeftRight() {
        return this._getOption('paddingLeftRight');
    }
    set paddingLeftRight(value) {
        this._setOption('paddingLeftRight', value);
    }
    get paddingTopBottom() {
        return this._getOption('paddingTopBottom');
    }
    set paddingTopBottom(value) {
        this._setOption('paddingTopBottom', value);
    }
    get series() {
        return this._getOption('series');
    }
    set series(value) {
        this._setOption('series', value);
    }
    get shadow() {
        return this._getOption('shadow');
    }
    set shadow(value) {
        this._setOption('shadow', value);
    }
    get template() {
        return this._getOption('template');
    }
    set template(value) {
        this._setOption('template', value);
    }
    get text() {
        return this._getOption('text');
    }
    set text(value) {
        this._setOption('text', value);
    }
    get textOverflow() {
        return this._getOption('textOverflow');
    }
    set textOverflow(value) {
        this._setOption('textOverflow', value);
    }
    get tooltipEnabled() {
        return this._getOption('tooltipEnabled');
    }
    set tooltipEnabled(value) {
        this._setOption('tooltipEnabled', value);
    }
    get tooltipTemplate() {
        return this._getOption('tooltipTemplate');
    }
    set tooltipTemplate(value) {
        this._setOption('tooltipTemplate', value);
    }
    get type() {
        return this._getOption('type');
    }
    set type(value) {
        this._setOption('type', value);
    }
    get value() {
        return this._getOption('value');
    }
    set value(value) {
        this._setOption('value', value);
    }
    get width() {
        return this._getOption('width');
    }
    set width(value) {
        this._setOption('width', value);
    }
    get wordWrap() {
        return this._getOption('wordWrap');
    }
    set wordWrap(value) {
        this._setOption('wordWrap', value);
    }
    get x() {
        return this._getOption('x');
    }
    set x(value) {
        this._setOption('x', value);
    }
    get y() {
        return this._getOption('y');
    }
    set y(value) {
        this._setOption('y', value);
    }
    get _optionPath() {
        return 'commonAnnotationSettings';
    }
    constructor(parentOptionHost, optionHost, renderer, document, templateHost, element) {
        super();
        this.renderer = renderer;
        this.document = document;
        this.element = element;
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
        templateHost.setHost(this);
    }
    setTemplate(template) {
        this.template = template;
    }
    ngAfterViewInit() {
        extractTemplate(this, this.element, this.renderer, this.document);
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartCommonAnnotationSettingsComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }, { token: i0.Renderer2 }, { token: DOCUMENT }, { token: i1.DxTemplateHost, host: true }, { token: i0.ElementRef }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoChartCommonAnnotationSettingsComponent, isStandalone: true, selector: "dxo-chart-common-annotation-settings", inputs: { allowDragging: "allowDragging", argument: "argument", arrowLength: "arrowLength", arrowWidth: "arrowWidth", axis: "axis", border: "border", color: "color", customizeTooltip: "customizeTooltip", data: "data", description: "description", font: "font", height: "height", image: "image", offsetX: "offsetX", offsetY: "offsetY", opacity: "opacity", paddingLeftRight: "paddingLeftRight", paddingTopBottom: "paddingTopBottom", series: "series", shadow: "shadow", template: "template", text: "text", textOverflow: "textOverflow", tooltipEnabled: "tooltipEnabled", tooltipTemplate: "tooltipTemplate", type: "type", value: "value", width: "width", wordWrap: "wordWrap", x: "x", y: "y" }, providers: [NestedOptionHost, DxTemplateHost], usesInheritance: true, ngImport: i0, template: '<ng-content></ng-content>', isInline: true, styles: [":host{display:block}\n"], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartCommonAnnotationSettingsComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-chart-common-annotation-settings', template: '<ng-content></ng-content>', imports: [DxIntegrationModule], providers: [NestedOptionHost, DxTemplateHost], styles: [":host{display:block}\n"] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }, { type: i0.Renderer2 }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [DOCUMENT]
                }] }, { type: i1.DxTemplateHost, decorators: [{
                    type: Host
                }] }, { type: i0.ElementRef }], propDecorators: { allowDragging: [{
                type: Input
            }], argument: [{
                type: Input
            }], arrowLength: [{
                type: Input
            }], arrowWidth: [{
                type: Input
            }], axis: [{
                type: Input
            }], border: [{
                type: Input
            }], color: [{
                type: Input
            }], customizeTooltip: [{
                type: Input
            }], data: [{
                type: Input
            }], description: [{
                type: Input
            }], font: [{
                type: Input
            }], height: [{
                type: Input
            }], image: [{
                type: Input
            }], offsetX: [{
                type: Input
            }], offsetY: [{
                type: Input
            }], opacity: [{
                type: Input
            }], paddingLeftRight: [{
                type: Input
            }], paddingTopBottom: [{
                type: Input
            }], series: [{
                type: Input
            }], shadow: [{
                type: Input
            }], template: [{
                type: Input
            }], text: [{
                type: Input
            }], textOverflow: [{
                type: Input
            }], tooltipEnabled: [{
                type: Input
            }], tooltipTemplate: [{
                type: Input
            }], type: [{
                type: Input
            }], value: [{
                type: Input
            }], width: [{
                type: Input
            }], wordWrap: [{
                type: Input
            }], x: [{
                type: Input
            }], y: [{
                type: Input
            }] } });
class DxoChartCommonAnnotationSettingsModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartCommonAnnotationSettingsModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoChartCommonAnnotationSettingsModule, imports: [DxoChartCommonAnnotationSettingsComponent], exports: [DxoChartCommonAnnotationSettingsComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartCommonAnnotationSettingsModule, imports: [DxoChartCommonAnnotationSettingsComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartCommonAnnotationSettingsModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoChartCommonAnnotationSettingsComponent
                    ],
                    exports: [
                        DxoChartCommonAnnotationSettingsComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoChartCommonAxisSettingsConstantLineStyleLabelComponent extends NestedOption {
    get font() {
        return this._getOption('font');
    }
    set font(value) {
        this._setOption('font', value);
    }
    get position() {
        return this._getOption('position');
    }
    set position(value) {
        this._setOption('position', value);
    }
    get visible() {
        return this._getOption('visible');
    }
    set visible(value) {
        this._setOption('visible', value);
    }
    get _optionPath() {
        return 'label';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartCommonAxisSettingsConstantLineStyleLabelComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoChartCommonAxisSettingsConstantLineStyleLabelComponent, isStandalone: true, selector: "dxo-chart-common-axis-settings-constant-line-style-label", inputs: { font: "font", position: "position", visible: "visible" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartCommonAxisSettingsConstantLineStyleLabelComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-chart-common-axis-settings-constant-line-style-label', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { font: [{
                type: Input
            }], position: [{
                type: Input
            }], visible: [{
                type: Input
            }] } });
class DxoChartCommonAxisSettingsConstantLineStyleLabelModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartCommonAxisSettingsConstantLineStyleLabelModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoChartCommonAxisSettingsConstantLineStyleLabelModule, imports: [DxoChartCommonAxisSettingsConstantLineStyleLabelComponent], exports: [DxoChartCommonAxisSettingsConstantLineStyleLabelComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartCommonAxisSettingsConstantLineStyleLabelModule, imports: [DxoChartCommonAxisSettingsConstantLineStyleLabelComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartCommonAxisSettingsConstantLineStyleLabelModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoChartCommonAxisSettingsConstantLineStyleLabelComponent
                    ],
                    exports: [
                        DxoChartCommonAxisSettingsConstantLineStyleLabelComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoChartCommonAxisSettingsConstantLineStyleComponent extends NestedOption {
    get color() {
        return this._getOption('color');
    }
    set color(value) {
        this._setOption('color', value);
    }
    get dashStyle() {
        return this._getOption('dashStyle');
    }
    set dashStyle(value) {
        this._setOption('dashStyle', value);
    }
    get label() {
        return this._getOption('label');
    }
    set label(value) {
        this._setOption('label', value);
    }
    get paddingLeftRight() {
        return this._getOption('paddingLeftRight');
    }
    set paddingLeftRight(value) {
        this._setOption('paddingLeftRight', value);
    }
    get paddingTopBottom() {
        return this._getOption('paddingTopBottom');
    }
    set paddingTopBottom(value) {
        this._setOption('paddingTopBottom', value);
    }
    get width() {
        return this._getOption('width');
    }
    set width(value) {
        this._setOption('width', value);
    }
    get _optionPath() {
        return 'constantLineStyle';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartCommonAxisSettingsConstantLineStyleComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoChartCommonAxisSettingsConstantLineStyleComponent, isStandalone: true, selector: "dxo-chart-common-axis-settings-constant-line-style", inputs: { color: "color", dashStyle: "dashStyle", label: "label", paddingLeftRight: "paddingLeftRight", paddingTopBottom: "paddingTopBottom", width: "width" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartCommonAxisSettingsConstantLineStyleComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-chart-common-axis-settings-constant-line-style', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { color: [{
                type: Input
            }], dashStyle: [{
                type: Input
            }], label: [{
                type: Input
            }], paddingLeftRight: [{
                type: Input
            }], paddingTopBottom: [{
                type: Input
            }], width: [{
                type: Input
            }] } });
class DxoChartCommonAxisSettingsConstantLineStyleModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartCommonAxisSettingsConstantLineStyleModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoChartCommonAxisSettingsConstantLineStyleModule, imports: [DxoChartCommonAxisSettingsConstantLineStyleComponent], exports: [DxoChartCommonAxisSettingsConstantLineStyleComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartCommonAxisSettingsConstantLineStyleModule, imports: [DxoChartCommonAxisSettingsConstantLineStyleComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartCommonAxisSettingsConstantLineStyleModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoChartCommonAxisSettingsConstantLineStyleComponent
                    ],
                    exports: [
                        DxoChartCommonAxisSettingsConstantLineStyleComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoChartCommonAxisSettingsLabelComponent extends NestedOption {
    get alignment() {
        return this._getOption('alignment');
    }
    set alignment(value) {
        this._setOption('alignment', value);
    }
    get displayMode() {
        return this._getOption('displayMode');
    }
    set displayMode(value) {
        this._setOption('displayMode', value);
    }
    get font() {
        return this._getOption('font');
    }
    set font(value) {
        this._setOption('font', value);
    }
    get indentFromAxis() {
        return this._getOption('indentFromAxis');
    }
    set indentFromAxis(value) {
        this._setOption('indentFromAxis', value);
    }
    get overlappingBehavior() {
        return this._getOption('overlappingBehavior');
    }
    set overlappingBehavior(value) {
        this._setOption('overlappingBehavior', value);
    }
    get position() {
        return this._getOption('position');
    }
    set position(value) {
        this._setOption('position', value);
    }
    get rotationAngle() {
        return this._getOption('rotationAngle');
    }
    set rotationAngle(value) {
        this._setOption('rotationAngle', value);
    }
    get staggeringSpacing() {
        return this._getOption('staggeringSpacing');
    }
    set staggeringSpacing(value) {
        this._setOption('staggeringSpacing', value);
    }
    get template() {
        return this._getOption('template');
    }
    set template(value) {
        this._setOption('template', value);
    }
    get textOverflow() {
        return this._getOption('textOverflow');
    }
    set textOverflow(value) {
        this._setOption('textOverflow', value);
    }
    get visible() {
        return this._getOption('visible');
    }
    set visible(value) {
        this._setOption('visible', value);
    }
    get wordWrap() {
        return this._getOption('wordWrap');
    }
    set wordWrap(value) {
        this._setOption('wordWrap', value);
    }
    get _optionPath() {
        return 'label';
    }
    constructor(parentOptionHost, optionHost, renderer, document, templateHost, element) {
        super();
        this.renderer = renderer;
        this.document = document;
        this.element = element;
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
        templateHost.setHost(this);
    }
    setTemplate(template) {
        this.template = template;
    }
    ngAfterViewInit() {
        extractTemplate(this, this.element, this.renderer, this.document);
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartCommonAxisSettingsLabelComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }, { token: i0.Renderer2 }, { token: DOCUMENT }, { token: i1.DxTemplateHost, host: true }, { token: i0.ElementRef }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoChartCommonAxisSettingsLabelComponent, isStandalone: true, selector: "dxo-chart-common-axis-settings-label", inputs: { alignment: "alignment", displayMode: "displayMode", font: "font", indentFromAxis: "indentFromAxis", overlappingBehavior: "overlappingBehavior", position: "position", rotationAngle: "rotationAngle", staggeringSpacing: "staggeringSpacing", template: "template", textOverflow: "textOverflow", visible: "visible", wordWrap: "wordWrap" }, providers: [NestedOptionHost, DxTemplateHost], usesInheritance: true, ngImport: i0, template: '<ng-content></ng-content>', isInline: true, styles: [":host{display:block}\n"], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartCommonAxisSettingsLabelComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-chart-common-axis-settings-label', template: '<ng-content></ng-content>', imports: [DxIntegrationModule], providers: [NestedOptionHost, DxTemplateHost], styles: [":host{display:block}\n"] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }, { type: i0.Renderer2 }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [DOCUMENT]
                }] }, { type: i1.DxTemplateHost, decorators: [{
                    type: Host
                }] }, { type: i0.ElementRef }], propDecorators: { alignment: [{
                type: Input
            }], displayMode: [{
                type: Input
            }], font: [{
                type: Input
            }], indentFromAxis: [{
                type: Input
            }], overlappingBehavior: [{
                type: Input
            }], position: [{
                type: Input
            }], rotationAngle: [{
                type: Input
            }], staggeringSpacing: [{
                type: Input
            }], template: [{
                type: Input
            }], textOverflow: [{
                type: Input
            }], visible: [{
                type: Input
            }], wordWrap: [{
                type: Input
            }] } });
class DxoChartCommonAxisSettingsLabelModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartCommonAxisSettingsLabelModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoChartCommonAxisSettingsLabelModule, imports: [DxoChartCommonAxisSettingsLabelComponent], exports: [DxoChartCommonAxisSettingsLabelComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartCommonAxisSettingsLabelModule, imports: [DxoChartCommonAxisSettingsLabelComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartCommonAxisSettingsLabelModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoChartCommonAxisSettingsLabelComponent
                    ],
                    exports: [
                        DxoChartCommonAxisSettingsLabelComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoChartCommonAxisSettingsTitleComponent extends NestedOption {
    get alignment() {
        return this._getOption('alignment');
    }
    set alignment(value) {
        this._setOption('alignment', value);
    }
    get font() {
        return this._getOption('font');
    }
    set font(value) {
        this._setOption('font', value);
    }
    get margin() {
        return this._getOption('margin');
    }
    set margin(value) {
        this._setOption('margin', value);
    }
    get textOverflow() {
        return this._getOption('textOverflow');
    }
    set textOverflow(value) {
        this._setOption('textOverflow', value);
    }
    get wordWrap() {
        return this._getOption('wordWrap');
    }
    set wordWrap(value) {
        this._setOption('wordWrap', value);
    }
    get _optionPath() {
        return 'title';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartCommonAxisSettingsTitleComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoChartCommonAxisSettingsTitleComponent, isStandalone: true, selector: "dxo-chart-common-axis-settings-title", inputs: { alignment: "alignment", font: "font", margin: "margin", textOverflow: "textOverflow", wordWrap: "wordWrap" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartCommonAxisSettingsTitleComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-chart-common-axis-settings-title', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { alignment: [{
                type: Input
            }], font: [{
                type: Input
            }], margin: [{
                type: Input
            }], textOverflow: [{
                type: Input
            }], wordWrap: [{
                type: Input
            }] } });
class DxoChartCommonAxisSettingsTitleModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartCommonAxisSettingsTitleModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoChartCommonAxisSettingsTitleModule, imports: [DxoChartCommonAxisSettingsTitleComponent], exports: [DxoChartCommonAxisSettingsTitleComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartCommonAxisSettingsTitleModule, imports: [DxoChartCommonAxisSettingsTitleComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartCommonAxisSettingsTitleModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoChartCommonAxisSettingsTitleComponent
                    ],
                    exports: [
                        DxoChartCommonAxisSettingsTitleComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoChartCommonAxisSettingsComponent extends NestedOption {
    get aggregatedPointsPosition() {
        return this._getOption('aggregatedPointsPosition');
    }
    set aggregatedPointsPosition(value) {
        this._setOption('aggregatedPointsPosition', value);
    }
    get allowDecimals() {
        return this._getOption('allowDecimals');
    }
    set allowDecimals(value) {
        this._setOption('allowDecimals', value);
    }
    get breakStyle() {
        return this._getOption('breakStyle');
    }
    set breakStyle(value) {
        this._setOption('breakStyle', value);
    }
    get color() {
        return this._getOption('color');
    }
    set color(value) {
        this._setOption('color', value);
    }
    get constantLineStyle() {
        return this._getOption('constantLineStyle');
    }
    set constantLineStyle(value) {
        this._setOption('constantLineStyle', value);
    }
    get discreteAxisDivisionMode() {
        return this._getOption('discreteAxisDivisionMode');
    }
    set discreteAxisDivisionMode(value) {
        this._setOption('discreteAxisDivisionMode', value);
    }
    get endOnTick() {
        return this._getOption('endOnTick');
    }
    set endOnTick(value) {
        this._setOption('endOnTick', value);
    }
    get grid() {
        return this._getOption('grid');
    }
    set grid(value) {
        this._setOption('grid', value);
    }
    get inverted() {
        return this._getOption('inverted');
    }
    set inverted(value) {
        this._setOption('inverted', value);
    }
    get label() {
        return this._getOption('label');
    }
    set label(value) {
        this._setOption('label', value);
    }
    get maxValueMargin() {
        return this._getOption('maxValueMargin');
    }
    set maxValueMargin(value) {
        this._setOption('maxValueMargin', value);
    }
    get minorGrid() {
        return this._getOption('minorGrid');
    }
    set minorGrid(value) {
        this._setOption('minorGrid', value);
    }
    get minorTick() {
        return this._getOption('minorTick');
    }
    set minorTick(value) {
        this._setOption('minorTick', value);
    }
    get minValueMargin() {
        return this._getOption('minValueMargin');
    }
    set minValueMargin(value) {
        this._setOption('minValueMargin', value);
    }
    get opacity() {
        return this._getOption('opacity');
    }
    set opacity(value) {
        this._setOption('opacity', value);
    }
    get placeholderSize() {
        return this._getOption('placeholderSize');
    }
    set placeholderSize(value) {
        this._setOption('placeholderSize', value);
    }
    get stripStyle() {
        return this._getOption('stripStyle');
    }
    set stripStyle(value) {
        this._setOption('stripStyle', value);
    }
    get tick() {
        return this._getOption('tick');
    }
    set tick(value) {
        this._setOption('tick', value);
    }
    get title() {
        return this._getOption('title');
    }
    set title(value) {
        this._setOption('title', value);
    }
    get valueMarginsEnabled() {
        return this._getOption('valueMarginsEnabled');
    }
    set valueMarginsEnabled(value) {
        this._setOption('valueMarginsEnabled', value);
    }
    get visible() {
        return this._getOption('visible');
    }
    set visible(value) {
        this._setOption('visible', value);
    }
    get width() {
        return this._getOption('width');
    }
    set width(value) {
        this._setOption('width', value);
    }
    get _optionPath() {
        return 'commonAxisSettings';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartCommonAxisSettingsComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoChartCommonAxisSettingsComponent, isStandalone: true, selector: "dxo-chart-common-axis-settings", inputs: { aggregatedPointsPosition: "aggregatedPointsPosition", allowDecimals: "allowDecimals", breakStyle: "breakStyle", color: "color", constantLineStyle: "constantLineStyle", discreteAxisDivisionMode: "discreteAxisDivisionMode", endOnTick: "endOnTick", grid: "grid", inverted: "inverted", label: "label", maxValueMargin: "maxValueMargin", minorGrid: "minorGrid", minorTick: "minorTick", minValueMargin: "minValueMargin", opacity: "opacity", placeholderSize: "placeholderSize", stripStyle: "stripStyle", tick: "tick", title: "title", valueMarginsEnabled: "valueMarginsEnabled", visible: "visible", width: "width" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartCommonAxisSettingsComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-chart-common-axis-settings', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { aggregatedPointsPosition: [{
                type: Input
            }], allowDecimals: [{
                type: Input
            }], breakStyle: [{
                type: Input
            }], color: [{
                type: Input
            }], constantLineStyle: [{
                type: Input
            }], discreteAxisDivisionMode: [{
                type: Input
            }], endOnTick: [{
                type: Input
            }], grid: [{
                type: Input
            }], inverted: [{
                type: Input
            }], label: [{
                type: Input
            }], maxValueMargin: [{
                type: Input
            }], minorGrid: [{
                type: Input
            }], minorTick: [{
                type: Input
            }], minValueMargin: [{
                type: Input
            }], opacity: [{
                type: Input
            }], placeholderSize: [{
                type: Input
            }], stripStyle: [{
                type: Input
            }], tick: [{
                type: Input
            }], title: [{
                type: Input
            }], valueMarginsEnabled: [{
                type: Input
            }], visible: [{
                type: Input
            }], width: [{
                type: Input
            }] } });
class DxoChartCommonAxisSettingsModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartCommonAxisSettingsModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoChartCommonAxisSettingsModule, imports: [DxoChartCommonAxisSettingsComponent], exports: [DxoChartCommonAxisSettingsComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartCommonAxisSettingsModule, imports: [DxoChartCommonAxisSettingsComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartCommonAxisSettingsModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoChartCommonAxisSettingsComponent
                    ],
                    exports: [
                        DxoChartCommonAxisSettingsComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoChartCommonPaneSettingsComponent extends NestedOption {
    get backgroundColor() {
        return this._getOption('backgroundColor');
    }
    set backgroundColor(value) {
        this._setOption('backgroundColor', value);
    }
    get border() {
        return this._getOption('border');
    }
    set border(value) {
        this._setOption('border', value);
    }
    get _optionPath() {
        return 'commonPaneSettings';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartCommonPaneSettingsComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoChartCommonPaneSettingsComponent, isStandalone: true, selector: "dxo-chart-common-pane-settings", inputs: { backgroundColor: "backgroundColor", border: "border" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartCommonPaneSettingsComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-chart-common-pane-settings', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { backgroundColor: [{
                type: Input
            }], border: [{
                type: Input
            }] } });
class DxoChartCommonPaneSettingsModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartCommonPaneSettingsModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoChartCommonPaneSettingsModule, imports: [DxoChartCommonPaneSettingsComponent], exports: [DxoChartCommonPaneSettingsComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartCommonPaneSettingsModule, imports: [DxoChartCommonPaneSettingsComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartCommonPaneSettingsModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoChartCommonPaneSettingsComponent
                    ],
                    exports: [
                        DxoChartCommonPaneSettingsComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoChartCommonSeriesSettingsHoverStyleComponent extends NestedOption {
    get border() {
        return this._getOption('border');
    }
    set border(value) {
        this._setOption('border', value);
    }
    get color() {
        return this._getOption('color');
    }
    set color(value) {
        this._setOption('color', value);
    }
    get dashStyle() {
        return this._getOption('dashStyle');
    }
    set dashStyle(value) {
        this._setOption('dashStyle', value);
    }
    get hatching() {
        return this._getOption('hatching');
    }
    set hatching(value) {
        this._setOption('hatching', value);
    }
    get highlight() {
        return this._getOption('highlight');
    }
    set highlight(value) {
        this._setOption('highlight', value);
    }
    get width() {
        return this._getOption('width');
    }
    set width(value) {
        this._setOption('width', value);
    }
    get _optionPath() {
        return 'hoverStyle';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartCommonSeriesSettingsHoverStyleComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoChartCommonSeriesSettingsHoverStyleComponent, isStandalone: true, selector: "dxo-chart-common-series-settings-hover-style", inputs: { border: "border", color: "color", dashStyle: "dashStyle", hatching: "hatching", highlight: "highlight", width: "width" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartCommonSeriesSettingsHoverStyleComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-chart-common-series-settings-hover-style', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { border: [{
                type: Input
            }], color: [{
                type: Input
            }], dashStyle: [{
                type: Input
            }], hatching: [{
                type: Input
            }], highlight: [{
                type: Input
            }], width: [{
                type: Input
            }] } });
class DxoChartCommonSeriesSettingsHoverStyleModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartCommonSeriesSettingsHoverStyleModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoChartCommonSeriesSettingsHoverStyleModule, imports: [DxoChartCommonSeriesSettingsHoverStyleComponent], exports: [DxoChartCommonSeriesSettingsHoverStyleComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartCommonSeriesSettingsHoverStyleModule, imports: [DxoChartCommonSeriesSettingsHoverStyleComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartCommonSeriesSettingsHoverStyleModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoChartCommonSeriesSettingsHoverStyleComponent
                    ],
                    exports: [
                        DxoChartCommonSeriesSettingsHoverStyleComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoChartCommonSeriesSettingsLabelComponent extends NestedOption {
    get alignment() {
        return this._getOption('alignment');
    }
    set alignment(value) {
        this._setOption('alignment', value);
    }
    get argumentFormat() {
        return this._getOption('argumentFormat');
    }
    set argumentFormat(value) {
        this._setOption('argumentFormat', value);
    }
    get backgroundColor() {
        return this._getOption('backgroundColor');
    }
    set backgroundColor(value) {
        this._setOption('backgroundColor', value);
    }
    get border() {
        return this._getOption('border');
    }
    set border(value) {
        this._setOption('border', value);
    }
    get connector() {
        return this._getOption('connector');
    }
    set connector(value) {
        this._setOption('connector', value);
    }
    get customizeText() {
        return this._getOption('customizeText');
    }
    set customizeText(value) {
        this._setOption('customizeText', value);
    }
    get displayFormat() {
        return this._getOption('displayFormat');
    }
    set displayFormat(value) {
        this._setOption('displayFormat', value);
    }
    get font() {
        return this._getOption('font');
    }
    set font(value) {
        this._setOption('font', value);
    }
    get format() {
        return this._getOption('format');
    }
    set format(value) {
        this._setOption('format', value);
    }
    get horizontalOffset() {
        return this._getOption('horizontalOffset');
    }
    set horizontalOffset(value) {
        this._setOption('horizontalOffset', value);
    }
    get position() {
        return this._getOption('position');
    }
    set position(value) {
        this._setOption('position', value);
    }
    get rotationAngle() {
        return this._getOption('rotationAngle');
    }
    set rotationAngle(value) {
        this._setOption('rotationAngle', value);
    }
    get showForZeroValues() {
        return this._getOption('showForZeroValues');
    }
    set showForZeroValues(value) {
        this._setOption('showForZeroValues', value);
    }
    get verticalOffset() {
        return this._getOption('verticalOffset');
    }
    set verticalOffset(value) {
        this._setOption('verticalOffset', value);
    }
    get visible() {
        return this._getOption('visible');
    }
    set visible(value) {
        this._setOption('visible', value);
    }
    get _optionPath() {
        return 'label';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartCommonSeriesSettingsLabelComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoChartCommonSeriesSettingsLabelComponent, isStandalone: true, selector: "dxo-chart-common-series-settings-label", inputs: { alignment: "alignment", argumentFormat: "argumentFormat", backgroundColor: "backgroundColor", border: "border", connector: "connector", customizeText: "customizeText", displayFormat: "displayFormat", font: "font", format: "format", horizontalOffset: "horizontalOffset", position: "position", rotationAngle: "rotationAngle", showForZeroValues: "showForZeroValues", verticalOffset: "verticalOffset", visible: "visible" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartCommonSeriesSettingsLabelComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-chart-common-series-settings-label', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { alignment: [{
                type: Input
            }], argumentFormat: [{
                type: Input
            }], backgroundColor: [{
                type: Input
            }], border: [{
                type: Input
            }], connector: [{
                type: Input
            }], customizeText: [{
                type: Input
            }], displayFormat: [{
                type: Input
            }], font: [{
                type: Input
            }], format: [{
                type: Input
            }], horizontalOffset: [{
                type: Input
            }], position: [{
                type: Input
            }], rotationAngle: [{
                type: Input
            }], showForZeroValues: [{
                type: Input
            }], verticalOffset: [{
                type: Input
            }], visible: [{
                type: Input
            }] } });
class DxoChartCommonSeriesSettingsLabelModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartCommonSeriesSettingsLabelModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoChartCommonSeriesSettingsLabelModule, imports: [DxoChartCommonSeriesSettingsLabelComponent], exports: [DxoChartCommonSeriesSettingsLabelComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartCommonSeriesSettingsLabelModule, imports: [DxoChartCommonSeriesSettingsLabelComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartCommonSeriesSettingsLabelModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoChartCommonSeriesSettingsLabelComponent
                    ],
                    exports: [
                        DxoChartCommonSeriesSettingsLabelComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoChartCommonSeriesSettingsSelectionStyleComponent extends NestedOption {
    get border() {
        return this._getOption('border');
    }
    set border(value) {
        this._setOption('border', value);
    }
    get color() {
        return this._getOption('color');
    }
    set color(value) {
        this._setOption('color', value);
    }
    get dashStyle() {
        return this._getOption('dashStyle');
    }
    set dashStyle(value) {
        this._setOption('dashStyle', value);
    }
    get hatching() {
        return this._getOption('hatching');
    }
    set hatching(value) {
        this._setOption('hatching', value);
    }
    get highlight() {
        return this._getOption('highlight');
    }
    set highlight(value) {
        this._setOption('highlight', value);
    }
    get width() {
        return this._getOption('width');
    }
    set width(value) {
        this._setOption('width', value);
    }
    get _optionPath() {
        return 'selectionStyle';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartCommonSeriesSettingsSelectionStyleComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoChartCommonSeriesSettingsSelectionStyleComponent, isStandalone: true, selector: "dxo-chart-common-series-settings-selection-style", inputs: { border: "border", color: "color", dashStyle: "dashStyle", hatching: "hatching", highlight: "highlight", width: "width" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartCommonSeriesSettingsSelectionStyleComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-chart-common-series-settings-selection-style', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { border: [{
                type: Input
            }], color: [{
                type: Input
            }], dashStyle: [{
                type: Input
            }], hatching: [{
                type: Input
            }], highlight: [{
                type: Input
            }], width: [{
                type: Input
            }] } });
class DxoChartCommonSeriesSettingsSelectionStyleModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartCommonSeriesSettingsSelectionStyleModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoChartCommonSeriesSettingsSelectionStyleModule, imports: [DxoChartCommonSeriesSettingsSelectionStyleComponent], exports: [DxoChartCommonSeriesSettingsSelectionStyleComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartCommonSeriesSettingsSelectionStyleModule, imports: [DxoChartCommonSeriesSettingsSelectionStyleComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartCommonSeriesSettingsSelectionStyleModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoChartCommonSeriesSettingsSelectionStyleComponent
                    ],
                    exports: [
                        DxoChartCommonSeriesSettingsSelectionStyleComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoChartCommonSeriesSettingsComponent extends NestedOption {
    get aggregation() {
        return this._getOption('aggregation');
    }
    set aggregation(value) {
        this._setOption('aggregation', value);
    }
    get area() {
        return this._getOption('area');
    }
    set area(value) {
        this._setOption('area', value);
    }
    get argumentField() {
        return this._getOption('argumentField');
    }
    set argumentField(value) {
        this._setOption('argumentField', value);
    }
    get axis() {
        return this._getOption('axis');
    }
    set axis(value) {
        this._setOption('axis', value);
    }
    get bar() {
        return this._getOption('bar');
    }
    set bar(value) {
        this._setOption('bar', value);
    }
    get barOverlapGroup() {
        return this._getOption('barOverlapGroup');
    }
    set barOverlapGroup(value) {
        this._setOption('barOverlapGroup', value);
    }
    get barPadding() {
        return this._getOption('barPadding');
    }
    set barPadding(value) {
        this._setOption('barPadding', value);
    }
    get barWidth() {
        return this._getOption('barWidth');
    }
    set barWidth(value) {
        this._setOption('barWidth', value);
    }
    get border() {
        return this._getOption('border');
    }
    set border(value) {
        this._setOption('border', value);
    }
    get bubble() {
        return this._getOption('bubble');
    }
    set bubble(value) {
        this._setOption('bubble', value);
    }
    get candlestick() {
        return this._getOption('candlestick');
    }
    set candlestick(value) {
        this._setOption('candlestick', value);
    }
    get closeValueField() {
        return this._getOption('closeValueField');
    }
    set closeValueField(value) {
        this._setOption('closeValueField', value);
    }
    get color() {
        return this._getOption('color');
    }
    set color(value) {
        this._setOption('color', value);
    }
    get cornerRadius() {
        return this._getOption('cornerRadius');
    }
    set cornerRadius(value) {
        this._setOption('cornerRadius', value);
    }
    get dashStyle() {
        return this._getOption('dashStyle');
    }
    set dashStyle(value) {
        this._setOption('dashStyle', value);
    }
    get fullstackedarea() {
        return this._getOption('fullstackedarea');
    }
    set fullstackedarea(value) {
        this._setOption('fullstackedarea', value);
    }
    get fullstackedbar() {
        return this._getOption('fullstackedbar');
    }
    set fullstackedbar(value) {
        this._setOption('fullstackedbar', value);
    }
    get fullstackedline() {
        return this._getOption('fullstackedline');
    }
    set fullstackedline(value) {
        this._setOption('fullstackedline', value);
    }
    get fullstackedspline() {
        return this._getOption('fullstackedspline');
    }
    set fullstackedspline(value) {
        this._setOption('fullstackedspline', value);
    }
    get fullstackedsplinearea() {
        return this._getOption('fullstackedsplinearea');
    }
    set fullstackedsplinearea(value) {
        this._setOption('fullstackedsplinearea', value);
    }
    get highValueField() {
        return this._getOption('highValueField');
    }
    set highValueField(value) {
        this._setOption('highValueField', value);
    }
    get hoverMode() {
        return this._getOption('hoverMode');
    }
    set hoverMode(value) {
        this._setOption('hoverMode', value);
    }
    get hoverStyle() {
        return this._getOption('hoverStyle');
    }
    set hoverStyle(value) {
        this._setOption('hoverStyle', value);
    }
    get ignoreEmptyPoints() {
        return this._getOption('ignoreEmptyPoints');
    }
    set ignoreEmptyPoints(value) {
        this._setOption('ignoreEmptyPoints', value);
    }
    get innerColor() {
        return this._getOption('innerColor');
    }
    set innerColor(value) {
        this._setOption('innerColor', value);
    }
    get label() {
        return this._getOption('label');
    }
    set label(value) {
        this._setOption('label', value);
    }
    get line() {
        return this._getOption('line');
    }
    set line(value) {
        this._setOption('line', value);
    }
    get lowValueField() {
        return this._getOption('lowValueField');
    }
    set lowValueField(value) {
        this._setOption('lowValueField', value);
    }
    get maxLabelCount() {
        return this._getOption('maxLabelCount');
    }
    set maxLabelCount(value) {
        this._setOption('maxLabelCount', value);
    }
    get minBarSize() {
        return this._getOption('minBarSize');
    }
    set minBarSize(value) {
        this._setOption('minBarSize', value);
    }
    get opacity() {
        return this._getOption('opacity');
    }
    set opacity(value) {
        this._setOption('opacity', value);
    }
    get openValueField() {
        return this._getOption('openValueField');
    }
    set openValueField(value) {
        this._setOption('openValueField', value);
    }
    get pane() {
        return this._getOption('pane');
    }
    set pane(value) {
        this._setOption('pane', value);
    }
    get point() {
        return this._getOption('point');
    }
    set point(value) {
        this._setOption('point', value);
    }
    get rangearea() {
        return this._getOption('rangearea');
    }
    set rangearea(value) {
        this._setOption('rangearea', value);
    }
    get rangebar() {
        return this._getOption('rangebar');
    }
    set rangebar(value) {
        this._setOption('rangebar', value);
    }
    get rangeValue1Field() {
        return this._getOption('rangeValue1Field');
    }
    set rangeValue1Field(value) {
        this._setOption('rangeValue1Field', value);
    }
    get rangeValue2Field() {
        return this._getOption('rangeValue2Field');
    }
    set rangeValue2Field(value) {
        this._setOption('rangeValue2Field', value);
    }
    get reduction() {
        return this._getOption('reduction');
    }
    set reduction(value) {
        this._setOption('reduction', value);
    }
    get scatter() {
        return this._getOption('scatter');
    }
    set scatter(value) {
        this._setOption('scatter', value);
    }
    get selectionMode() {
        return this._getOption('selectionMode');
    }
    set selectionMode(value) {
        this._setOption('selectionMode', value);
    }
    get selectionStyle() {
        return this._getOption('selectionStyle');
    }
    set selectionStyle(value) {
        this._setOption('selectionStyle', value);
    }
    get showInLegend() {
        return this._getOption('showInLegend');
    }
    set showInLegend(value) {
        this._setOption('showInLegend', value);
    }
    get sizeField() {
        return this._getOption('sizeField');
    }
    set sizeField(value) {
        this._setOption('sizeField', value);
    }
    get spline() {
        return this._getOption('spline');
    }
    set spline(value) {
        this._setOption('spline', value);
    }
    get splinearea() {
        return this._getOption('splinearea');
    }
    set splinearea(value) {
        this._setOption('splinearea', value);
    }
    get stack() {
        return this._getOption('stack');
    }
    set stack(value) {
        this._setOption('stack', value);
    }
    get stackedarea() {
        return this._getOption('stackedarea');
    }
    set stackedarea(value) {
        this._setOption('stackedarea', value);
    }
    get stackedbar() {
        return this._getOption('stackedbar');
    }
    set stackedbar(value) {
        this._setOption('stackedbar', value);
    }
    get stackedline() {
        return this._getOption('stackedline');
    }
    set stackedline(value) {
        this._setOption('stackedline', value);
    }
    get stackedspline() {
        return this._getOption('stackedspline');
    }
    set stackedspline(value) {
        this._setOption('stackedspline', value);
    }
    get stackedsplinearea() {
        return this._getOption('stackedsplinearea');
    }
    set stackedsplinearea(value) {
        this._setOption('stackedsplinearea', value);
    }
    get steparea() {
        return this._getOption('steparea');
    }
    set steparea(value) {
        this._setOption('steparea', value);
    }
    get stepline() {
        return this._getOption('stepline');
    }
    set stepline(value) {
        this._setOption('stepline', value);
    }
    get stock() {
        return this._getOption('stock');
    }
    set stock(value) {
        this._setOption('stock', value);
    }
    get tagField() {
        return this._getOption('tagField');
    }
    set tagField(value) {
        this._setOption('tagField', value);
    }
    get type() {
        return this._getOption('type');
    }
    set type(value) {
        this._setOption('type', value);
    }
    get valueErrorBar() {
        return this._getOption('valueErrorBar');
    }
    set valueErrorBar(value) {
        this._setOption('valueErrorBar', value);
    }
    get valueField() {
        return this._getOption('valueField');
    }
    set valueField(value) {
        this._setOption('valueField', value);
    }
    get visible() {
        return this._getOption('visible');
    }
    set visible(value) {
        this._setOption('visible', value);
    }
    get width() {
        return this._getOption('width');
    }
    set width(value) {
        this._setOption('width', value);
    }
    get _optionPath() {
        return 'commonSeriesSettings';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartCommonSeriesSettingsComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoChartCommonSeriesSettingsComponent, isStandalone: true, selector: "dxo-chart-common-series-settings", inputs: { aggregation: "aggregation", area: "area", argumentField: "argumentField", axis: "axis", bar: "bar", barOverlapGroup: "barOverlapGroup", barPadding: "barPadding", barWidth: "barWidth", border: "border", bubble: "bubble", candlestick: "candlestick", closeValueField: "closeValueField", color: "color", cornerRadius: "cornerRadius", dashStyle: "dashStyle", fullstackedarea: "fullstackedarea", fullstackedbar: "fullstackedbar", fullstackedline: "fullstackedline", fullstackedspline: "fullstackedspline", fullstackedsplinearea: "fullstackedsplinearea", highValueField: "highValueField", hoverMode: "hoverMode", hoverStyle: "hoverStyle", ignoreEmptyPoints: "ignoreEmptyPoints", innerColor: "innerColor", label: "label", line: "line", lowValueField: "lowValueField", maxLabelCount: "maxLabelCount", minBarSize: "minBarSize", opacity: "opacity", openValueField: "openValueField", pane: "pane", point: "point", rangearea: "rangearea", rangebar: "rangebar", rangeValue1Field: "rangeValue1Field", rangeValue2Field: "rangeValue2Field", reduction: "reduction", scatter: "scatter", selectionMode: "selectionMode", selectionStyle: "selectionStyle", showInLegend: "showInLegend", sizeField: "sizeField", spline: "spline", splinearea: "splinearea", stack: "stack", stackedarea: "stackedarea", stackedbar: "stackedbar", stackedline: "stackedline", stackedspline: "stackedspline", stackedsplinearea: "stackedsplinearea", steparea: "steparea", stepline: "stepline", stock: "stock", tagField: "tagField", type: "type", valueErrorBar: "valueErrorBar", valueField: "valueField", visible: "visible", width: "width" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartCommonSeriesSettingsComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-chart-common-series-settings', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { aggregation: [{
                type: Input
            }], area: [{
                type: Input
            }], argumentField: [{
                type: Input
            }], axis: [{
                type: Input
            }], bar: [{
                type: Input
            }], barOverlapGroup: [{
                type: Input
            }], barPadding: [{
                type: Input
            }], barWidth: [{
                type: Input
            }], border: [{
                type: Input
            }], bubble: [{
                type: Input
            }], candlestick: [{
                type: Input
            }], closeValueField: [{
                type: Input
            }], color: [{
                type: Input
            }], cornerRadius: [{
                type: Input
            }], dashStyle: [{
                type: Input
            }], fullstackedarea: [{
                type: Input
            }], fullstackedbar: [{
                type: Input
            }], fullstackedline: [{
                type: Input
            }], fullstackedspline: [{
                type: Input
            }], fullstackedsplinearea: [{
                type: Input
            }], highValueField: [{
                type: Input
            }], hoverMode: [{
                type: Input
            }], hoverStyle: [{
                type: Input
            }], ignoreEmptyPoints: [{
                type: Input
            }], innerColor: [{
                type: Input
            }], label: [{
                type: Input
            }], line: [{
                type: Input
            }], lowValueField: [{
                type: Input
            }], maxLabelCount: [{
                type: Input
            }], minBarSize: [{
                type: Input
            }], opacity: [{
                type: Input
            }], openValueField: [{
                type: Input
            }], pane: [{
                type: Input
            }], point: [{
                type: Input
            }], rangearea: [{
                type: Input
            }], rangebar: [{
                type: Input
            }], rangeValue1Field: [{
                type: Input
            }], rangeValue2Field: [{
                type: Input
            }], reduction: [{
                type: Input
            }], scatter: [{
                type: Input
            }], selectionMode: [{
                type: Input
            }], selectionStyle: [{
                type: Input
            }], showInLegend: [{
                type: Input
            }], sizeField: [{
                type: Input
            }], spline: [{
                type: Input
            }], splinearea: [{
                type: Input
            }], stack: [{
                type: Input
            }], stackedarea: [{
                type: Input
            }], stackedbar: [{
                type: Input
            }], stackedline: [{
                type: Input
            }], stackedspline: [{
                type: Input
            }], stackedsplinearea: [{
                type: Input
            }], steparea: [{
                type: Input
            }], stepline: [{
                type: Input
            }], stock: [{
                type: Input
            }], tagField: [{
                type: Input
            }], type: [{
                type: Input
            }], valueErrorBar: [{
                type: Input
            }], valueField: [{
                type: Input
            }], visible: [{
                type: Input
            }], width: [{
                type: Input
            }] } });
class DxoChartCommonSeriesSettingsModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartCommonSeriesSettingsModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoChartCommonSeriesSettingsModule, imports: [DxoChartCommonSeriesSettingsComponent], exports: [DxoChartCommonSeriesSettingsComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartCommonSeriesSettingsModule, imports: [DxoChartCommonSeriesSettingsComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartCommonSeriesSettingsModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoChartCommonSeriesSettingsComponent
                    ],
                    exports: [
                        DxoChartCommonSeriesSettingsComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoChartConnectorComponent extends NestedOption {
    get color() {
        return this._getOption('color');
    }
    set color(value) {
        this._setOption('color', value);
    }
    get visible() {
        return this._getOption('visible');
    }
    set visible(value) {
        this._setOption('visible', value);
    }
    get width() {
        return this._getOption('width');
    }
    set width(value) {
        this._setOption('width', value);
    }
    get _optionPath() {
        return 'connector';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartConnectorComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoChartConnectorComponent, isStandalone: true, selector: "dxo-chart-connector", inputs: { color: "color", visible: "visible", width: "width" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartConnectorComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-chart-connector', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { color: [{
                type: Input
            }], visible: [{
                type: Input
            }], width: [{
                type: Input
            }] } });
class DxoChartConnectorModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartConnectorModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoChartConnectorModule, imports: [DxoChartConnectorComponent], exports: [DxoChartConnectorComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartConnectorModule, imports: [DxoChartConnectorComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartConnectorModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoChartConnectorComponent
                    ],
                    exports: [
                        DxoChartConnectorComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxiChartConstantLineComponent extends CollectionNestedOption {
    get color() {
        return this._getOption('color');
    }
    set color(value) {
        this._setOption('color', value);
    }
    get dashStyle() {
        return this._getOption('dashStyle');
    }
    set dashStyle(value) {
        this._setOption('dashStyle', value);
    }
    get displayBehindSeries() {
        return this._getOption('displayBehindSeries');
    }
    set displayBehindSeries(value) {
        this._setOption('displayBehindSeries', value);
    }
    get extendAxis() {
        return this._getOption('extendAxis');
    }
    set extendAxis(value) {
        this._setOption('extendAxis', value);
    }
    get label() {
        return this._getOption('label');
    }
    set label(value) {
        this._setOption('label', value);
    }
    get paddingLeftRight() {
        return this._getOption('paddingLeftRight');
    }
    set paddingLeftRight(value) {
        this._setOption('paddingLeftRight', value);
    }
    get paddingTopBottom() {
        return this._getOption('paddingTopBottom');
    }
    set paddingTopBottom(value) {
        this._setOption('paddingTopBottom', value);
    }
    get value() {
        return this._getOption('value');
    }
    set value(value) {
        this._setOption('value', value);
    }
    get width() {
        return this._getOption('width');
    }
    set width(value) {
        this._setOption('width', value);
    }
    get _optionPath() {
        return 'constantLines';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnDestroy() {
        this._deleteRemovedOptions(this._fullOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiChartConstantLineComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxiChartConstantLineComponent, isStandalone: true, selector: "dxi-chart-constant-line", inputs: { color: "color", dashStyle: "dashStyle", displayBehindSeries: "displayBehindSeries", extendAxis: "extendAxis", label: "label", paddingLeftRight: "paddingLeftRight", paddingTopBottom: "paddingTopBottom", value: "value", width: "width" }, providers: [
            NestedOptionHost,
            {
                provide: PROPERTY_TOKEN_constantLines,
                useExisting: DxiChartConstantLineComponent,
            }
        ], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiChartConstantLineComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxi-chart-constant-line', template: '', imports: [DxIntegrationModule], providers: [
                        NestedOptionHost,
                        {
                            provide: PROPERTY_TOKEN_constantLines,
                            useExisting: DxiChartConstantLineComponent,
                        }
                    ] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { color: [{
                type: Input
            }], dashStyle: [{
                type: Input
            }], displayBehindSeries: [{
                type: Input
            }], extendAxis: [{
                type: Input
            }], label: [{
                type: Input
            }], paddingLeftRight: [{
                type: Input
            }], paddingTopBottom: [{
                type: Input
            }], value: [{
                type: Input
            }], width: [{
                type: Input
            }] } });
class DxiChartConstantLineModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiChartConstantLineModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxiChartConstantLineModule, imports: [DxiChartConstantLineComponent], exports: [DxiChartConstantLineComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiChartConstantLineModule, imports: [DxiChartConstantLineComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiChartConstantLineModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxiChartConstantLineComponent
                    ],
                    exports: [
                        DxiChartConstantLineComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoChartConstantLineLabelComponent extends NestedOption {
    get font() {
        return this._getOption('font');
    }
    set font(value) {
        this._setOption('font', value);
    }
    get horizontalAlignment() {
        return this._getOption('horizontalAlignment');
    }
    set horizontalAlignment(value) {
        this._setOption('horizontalAlignment', value);
    }
    get position() {
        return this._getOption('position');
    }
    set position(value) {
        this._setOption('position', value);
    }
    get text() {
        return this._getOption('text');
    }
    set text(value) {
        this._setOption('text', value);
    }
    get verticalAlignment() {
        return this._getOption('verticalAlignment');
    }
    set verticalAlignment(value) {
        this._setOption('verticalAlignment', value);
    }
    get visible() {
        return this._getOption('visible');
    }
    set visible(value) {
        this._setOption('visible', value);
    }
    get _optionPath() {
        return 'label';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartConstantLineLabelComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoChartConstantLineLabelComponent, isStandalone: true, selector: "dxo-chart-constant-line-label", inputs: { font: "font", horizontalAlignment: "horizontalAlignment", position: "position", text: "text", verticalAlignment: "verticalAlignment", visible: "visible" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartConstantLineLabelComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-chart-constant-line-label', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { font: [{
                type: Input
            }], horizontalAlignment: [{
                type: Input
            }], position: [{
                type: Input
            }], text: [{
                type: Input
            }], verticalAlignment: [{
                type: Input
            }], visible: [{
                type: Input
            }] } });
class DxoChartConstantLineLabelModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartConstantLineLabelModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoChartConstantLineLabelModule, imports: [DxoChartConstantLineLabelComponent], exports: [DxoChartConstantLineLabelComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartConstantLineLabelModule, imports: [DxoChartConstantLineLabelComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartConstantLineLabelModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoChartConstantLineLabelComponent
                    ],
                    exports: [
                        DxoChartConstantLineLabelComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoChartConstantLineStyleComponent extends NestedOption {
    get color() {
        return this._getOption('color');
    }
    set color(value) {
        this._setOption('color', value);
    }
    get dashStyle() {
        return this._getOption('dashStyle');
    }
    set dashStyle(value) {
        this._setOption('dashStyle', value);
    }
    get label() {
        return this._getOption('label');
    }
    set label(value) {
        this._setOption('label', value);
    }
    get paddingLeftRight() {
        return this._getOption('paddingLeftRight');
    }
    set paddingLeftRight(value) {
        this._setOption('paddingLeftRight', value);
    }
    get paddingTopBottom() {
        return this._getOption('paddingTopBottom');
    }
    set paddingTopBottom(value) {
        this._setOption('paddingTopBottom', value);
    }
    get width() {
        return this._getOption('width');
    }
    set width(value) {
        this._setOption('width', value);
    }
    get _optionPath() {
        return 'constantLineStyle';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartConstantLineStyleComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoChartConstantLineStyleComponent, isStandalone: true, selector: "dxo-chart-constant-line-style", inputs: { color: "color", dashStyle: "dashStyle", label: "label", paddingLeftRight: "paddingLeftRight", paddingTopBottom: "paddingTopBottom", width: "width" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartConstantLineStyleComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-chart-constant-line-style', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { color: [{
                type: Input
            }], dashStyle: [{
                type: Input
            }], label: [{
                type: Input
            }], paddingLeftRight: [{
                type: Input
            }], paddingTopBottom: [{
                type: Input
            }], width: [{
                type: Input
            }] } });
class DxoChartConstantLineStyleModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartConstantLineStyleModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoChartConstantLineStyleModule, imports: [DxoChartConstantLineStyleComponent], exports: [DxoChartConstantLineStyleComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartConstantLineStyleModule, imports: [DxoChartConstantLineStyleComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartConstantLineStyleModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoChartConstantLineStyleComponent
                    ],
                    exports: [
                        DxoChartConstantLineStyleComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoChartCrosshairComponent extends NestedOption {
    get color() {
        return this._getOption('color');
    }
    set color(value) {
        this._setOption('color', value);
    }
    get dashStyle() {
        return this._getOption('dashStyle');
    }
    set dashStyle(value) {
        this._setOption('dashStyle', value);
    }
    get enabled() {
        return this._getOption('enabled');
    }
    set enabled(value) {
        this._setOption('enabled', value);
    }
    get horizontalLine() {
        return this._getOption('horizontalLine');
    }
    set horizontalLine(value) {
        this._setOption('horizontalLine', value);
    }
    get label() {
        return this._getOption('label');
    }
    set label(value) {
        this._setOption('label', value);
    }
    get opacity() {
        return this._getOption('opacity');
    }
    set opacity(value) {
        this._setOption('opacity', value);
    }
    get verticalLine() {
        return this._getOption('verticalLine');
    }
    set verticalLine(value) {
        this._setOption('verticalLine', value);
    }
    get width() {
        return this._getOption('width');
    }
    set width(value) {
        this._setOption('width', value);
    }
    get _optionPath() {
        return 'crosshair';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartCrosshairComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoChartCrosshairComponent, isStandalone: true, selector: "dxo-chart-crosshair", inputs: { color: "color", dashStyle: "dashStyle", enabled: "enabled", horizontalLine: "horizontalLine", label: "label", opacity: "opacity", verticalLine: "verticalLine", width: "width" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartCrosshairComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-chart-crosshair', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { color: [{
                type: Input
            }], dashStyle: [{
                type: Input
            }], enabled: [{
                type: Input
            }], horizontalLine: [{
                type: Input
            }], label: [{
                type: Input
            }], opacity: [{
                type: Input
            }], verticalLine: [{
                type: Input
            }], width: [{
                type: Input
            }] } });
class DxoChartCrosshairModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartCrosshairModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoChartCrosshairModule, imports: [DxoChartCrosshairComponent], exports: [DxoChartCrosshairComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartCrosshairModule, imports: [DxoChartCrosshairComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartCrosshairModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoChartCrosshairComponent
                    ],
                    exports: [
                        DxoChartCrosshairComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoChartDataPrepareSettingsComponent extends NestedOption {
    get checkTypeForAllData() {
        return this._getOption('checkTypeForAllData');
    }
    set checkTypeForAllData(value) {
        this._setOption('checkTypeForAllData', value);
    }
    get convertToAxisDataType() {
        return this._getOption('convertToAxisDataType');
    }
    set convertToAxisDataType(value) {
        this._setOption('convertToAxisDataType', value);
    }
    get sortingMethod() {
        return this._getOption('sortingMethod');
    }
    set sortingMethod(value) {
        this._setOption('sortingMethod', value);
    }
    get _optionPath() {
        return 'dataPrepareSettings';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartDataPrepareSettingsComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoChartDataPrepareSettingsComponent, isStandalone: true, selector: "dxo-chart-data-prepare-settings", inputs: { checkTypeForAllData: "checkTypeForAllData", convertToAxisDataType: "convertToAxisDataType", sortingMethod: "sortingMethod" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartDataPrepareSettingsComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-chart-data-prepare-settings', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { checkTypeForAllData: [{
                type: Input
            }], convertToAxisDataType: [{
                type: Input
            }], sortingMethod: [{
                type: Input
            }] } });
class DxoChartDataPrepareSettingsModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartDataPrepareSettingsModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoChartDataPrepareSettingsModule, imports: [DxoChartDataPrepareSettingsComponent], exports: [DxoChartDataPrepareSettingsComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartDataPrepareSettingsModule, imports: [DxoChartDataPrepareSettingsComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartDataPrepareSettingsModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoChartDataPrepareSettingsComponent
                    ],
                    exports: [
                        DxoChartDataPrepareSettingsComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoChartDragBoxStyleComponent extends NestedOption {
    get color() {
        return this._getOption('color');
    }
    set color(value) {
        this._setOption('color', value);
    }
    get opacity() {
        return this._getOption('opacity');
    }
    set opacity(value) {
        this._setOption('opacity', value);
    }
    get _optionPath() {
        return 'dragBoxStyle';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartDragBoxStyleComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoChartDragBoxStyleComponent, isStandalone: true, selector: "dxo-chart-drag-box-style", inputs: { color: "color", opacity: "opacity" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartDragBoxStyleComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-chart-drag-box-style', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { color: [{
                type: Input
            }], opacity: [{
                type: Input
            }] } });
class DxoChartDragBoxStyleModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartDragBoxStyleModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoChartDragBoxStyleModule, imports: [DxoChartDragBoxStyleComponent], exports: [DxoChartDragBoxStyleComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartDragBoxStyleModule, imports: [DxoChartDragBoxStyleComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartDragBoxStyleModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoChartDragBoxStyleComponent
                    ],
                    exports: [
                        DxoChartDragBoxStyleComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoChartExportComponent extends NestedOption {
    get backgroundColor() {
        return this._getOption('backgroundColor');
    }
    set backgroundColor(value) {
        this._setOption('backgroundColor', value);
    }
    get enabled() {
        return this._getOption('enabled');
    }
    set enabled(value) {
        this._setOption('enabled', value);
    }
    get fileName() {
        return this._getOption('fileName');
    }
    set fileName(value) {
        this._setOption('fileName', value);
    }
    get formats() {
        return this._getOption('formats');
    }
    set formats(value) {
        this._setOption('formats', value);
    }
    get margin() {
        return this._getOption('margin');
    }
    set margin(value) {
        this._setOption('margin', value);
    }
    get printingEnabled() {
        return this._getOption('printingEnabled');
    }
    set printingEnabled(value) {
        this._setOption('printingEnabled', value);
    }
    get svgToCanvas() {
        return this._getOption('svgToCanvas');
    }
    set svgToCanvas(value) {
        this._setOption('svgToCanvas', value);
    }
    get _optionPath() {
        return 'export';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartExportComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoChartExportComponent, isStandalone: true, selector: "dxo-chart-export", inputs: { backgroundColor: "backgroundColor", enabled: "enabled", fileName: "fileName", formats: "formats", margin: "margin", printingEnabled: "printingEnabled", svgToCanvas: "svgToCanvas" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartExportComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-chart-export', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { backgroundColor: [{
                type: Input
            }], enabled: [{
                type: Input
            }], fileName: [{
                type: Input
            }], formats: [{
                type: Input
            }], margin: [{
                type: Input
            }], printingEnabled: [{
                type: Input
            }], svgToCanvas: [{
                type: Input
            }] } });
class DxoChartExportModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartExportModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoChartExportModule, imports: [DxoChartExportComponent], exports: [DxoChartExportComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartExportModule, imports: [DxoChartExportComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartExportModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoChartExportComponent
                    ],
                    exports: [
                        DxoChartExportComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoChartFontComponent extends NestedOption {
    get color() {
        return this._getOption('color');
    }
    set color(value) {
        this._setOption('color', value);
    }
    get family() {
        return this._getOption('family');
    }
    set family(value) {
        this._setOption('family', value);
    }
    get opacity() {
        return this._getOption('opacity');
    }
    set opacity(value) {
        this._setOption('opacity', value);
    }
    get size() {
        return this._getOption('size');
    }
    set size(value) {
        this._setOption('size', value);
    }
    get weight() {
        return this._getOption('weight');
    }
    set weight(value) {
        this._setOption('weight', value);
    }
    get _optionPath() {
        return 'font';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartFontComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoChartFontComponent, isStandalone: true, selector: "dxo-chart-font", inputs: { color: "color", family: "family", opacity: "opacity", size: "size", weight: "weight" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartFontComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-chart-font', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { color: [{
                type: Input
            }], family: [{
                type: Input
            }], opacity: [{
                type: Input
            }], size: [{
                type: Input
            }], weight: [{
                type: Input
            }] } });
class DxoChartFontModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartFontModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoChartFontModule, imports: [DxoChartFontComponent], exports: [DxoChartFontComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartFontModule, imports: [DxoChartFontComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartFontModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoChartFontComponent
                    ],
                    exports: [
                        DxoChartFontComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoChartFormatComponent extends NestedOption {
    get currency() {
        return this._getOption('currency');
    }
    set currency(value) {
        this._setOption('currency', value);
    }
    get formatter() {
        return this._getOption('formatter');
    }
    set formatter(value) {
        this._setOption('formatter', value);
    }
    get parser() {
        return this._getOption('parser');
    }
    set parser(value) {
        this._setOption('parser', value);
    }
    get precision() {
        return this._getOption('precision');
    }
    set precision(value) {
        this._setOption('precision', value);
    }
    get type() {
        return this._getOption('type');
    }
    set type(value) {
        this._setOption('type', value);
    }
    get useCurrencyAccountingStyle() {
        return this._getOption('useCurrencyAccountingStyle');
    }
    set useCurrencyAccountingStyle(value) {
        this._setOption('useCurrencyAccountingStyle', value);
    }
    get _optionPath() {
        return 'format';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartFormatComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoChartFormatComponent, isStandalone: true, selector: "dxo-chart-format", inputs: { currency: "currency", formatter: "formatter", parser: "parser", precision: "precision", type: "type", useCurrencyAccountingStyle: "useCurrencyAccountingStyle" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartFormatComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-chart-format', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { currency: [{
                type: Input
            }], formatter: [{
                type: Input
            }], parser: [{
                type: Input
            }], precision: [{
                type: Input
            }], type: [{
                type: Input
            }], useCurrencyAccountingStyle: [{
                type: Input
            }] } });
class DxoChartFormatModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartFormatModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoChartFormatModule, imports: [DxoChartFormatComponent], exports: [DxoChartFormatComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartFormatModule, imports: [DxoChartFormatComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartFormatModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoChartFormatComponent
                    ],
                    exports: [
                        DxoChartFormatComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoChartGridComponent extends NestedOption {
    get color() {
        return this._getOption('color');
    }
    set color(value) {
        this._setOption('color', value);
    }
    get opacity() {
        return this._getOption('opacity');
    }
    set opacity(value) {
        this._setOption('opacity', value);
    }
    get visible() {
        return this._getOption('visible');
    }
    set visible(value) {
        this._setOption('visible', value);
    }
    get width() {
        return this._getOption('width');
    }
    set width(value) {
        this._setOption('width', value);
    }
    get _optionPath() {
        return 'grid';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartGridComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoChartGridComponent, isStandalone: true, selector: "dxo-chart-grid", inputs: { color: "color", opacity: "opacity", visible: "visible", width: "width" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartGridComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-chart-grid', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { color: [{
                type: Input
            }], opacity: [{
                type: Input
            }], visible: [{
                type: Input
            }], width: [{
                type: Input
            }] } });
class DxoChartGridModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartGridModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoChartGridModule, imports: [DxoChartGridComponent], exports: [DxoChartGridComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartGridModule, imports: [DxoChartGridComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartGridModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoChartGridComponent
                    ],
                    exports: [
                        DxoChartGridComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoChartHatchingComponent extends NestedOption {
    get direction() {
        return this._getOption('direction');
    }
    set direction(value) {
        this._setOption('direction', value);
    }
    get opacity() {
        return this._getOption('opacity');
    }
    set opacity(value) {
        this._setOption('opacity', value);
    }
    get step() {
        return this._getOption('step');
    }
    set step(value) {
        this._setOption('step', value);
    }
    get width() {
        return this._getOption('width');
    }
    set width(value) {
        this._setOption('width', value);
    }
    get _optionPath() {
        return 'hatching';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartHatchingComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoChartHatchingComponent, isStandalone: true, selector: "dxo-chart-hatching", inputs: { direction: "direction", opacity: "opacity", step: "step", width: "width" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartHatchingComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-chart-hatching', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { direction: [{
                type: Input
            }], opacity: [{
                type: Input
            }], step: [{
                type: Input
            }], width: [{
                type: Input
            }] } });
class DxoChartHatchingModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartHatchingModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoChartHatchingModule, imports: [DxoChartHatchingComponent], exports: [DxoChartHatchingComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartHatchingModule, imports: [DxoChartHatchingComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartHatchingModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoChartHatchingComponent
                    ],
                    exports: [
                        DxoChartHatchingComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoChartHeightComponent extends NestedOption {
    get rangeMaxPoint() {
        return this._getOption('rangeMaxPoint');
    }
    set rangeMaxPoint(value) {
        this._setOption('rangeMaxPoint', value);
    }
    get rangeMinPoint() {
        return this._getOption('rangeMinPoint');
    }
    set rangeMinPoint(value) {
        this._setOption('rangeMinPoint', value);
    }
    get _optionPath() {
        return 'height';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartHeightComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoChartHeightComponent, isStandalone: true, selector: "dxo-chart-height", inputs: { rangeMaxPoint: "rangeMaxPoint", rangeMinPoint: "rangeMinPoint" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartHeightComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-chart-height', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { rangeMaxPoint: [{
                type: Input
            }], rangeMinPoint: [{
                type: Input
            }] } });
class DxoChartHeightModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartHeightModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoChartHeightModule, imports: [DxoChartHeightComponent], exports: [DxoChartHeightComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartHeightModule, imports: [DxoChartHeightComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartHeightModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoChartHeightComponent
                    ],
                    exports: [
                        DxoChartHeightComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoChartHorizontalLineLabelComponent extends NestedOption {
    get backgroundColor() {
        return this._getOption('backgroundColor');
    }
    set backgroundColor(value) {
        this._setOption('backgroundColor', value);
    }
    get customizeText() {
        return this._getOption('customizeText');
    }
    set customizeText(value) {
        this._setOption('customizeText', value);
    }
    get font() {
        return this._getOption('font');
    }
    set font(value) {
        this._setOption('font', value);
    }
    get format() {
        return this._getOption('format');
    }
    set format(value) {
        this._setOption('format', value);
    }
    get visible() {
        return this._getOption('visible');
    }
    set visible(value) {
        this._setOption('visible', value);
    }
    get _optionPath() {
        return 'label';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartHorizontalLineLabelComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoChartHorizontalLineLabelComponent, isStandalone: true, selector: "dxo-chart-horizontal-line-label", inputs: { backgroundColor: "backgroundColor", customizeText: "customizeText", font: "font", format: "format", visible: "visible" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartHorizontalLineLabelComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-chart-horizontal-line-label', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { backgroundColor: [{
                type: Input
            }], customizeText: [{
                type: Input
            }], font: [{
                type: Input
            }], format: [{
                type: Input
            }], visible: [{
                type: Input
            }] } });
class DxoChartHorizontalLineLabelModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartHorizontalLineLabelModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoChartHorizontalLineLabelModule, imports: [DxoChartHorizontalLineLabelComponent], exports: [DxoChartHorizontalLineLabelComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartHorizontalLineLabelModule, imports: [DxoChartHorizontalLineLabelComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartHorizontalLineLabelModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoChartHorizontalLineLabelComponent
                    ],
                    exports: [
                        DxoChartHorizontalLineLabelComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoChartHorizontalLineComponent extends NestedOption {
    get color() {
        return this._getOption('color');
    }
    set color(value) {
        this._setOption('color', value);
    }
    get dashStyle() {
        return this._getOption('dashStyle');
    }
    set dashStyle(value) {
        this._setOption('dashStyle', value);
    }
    get label() {
        return this._getOption('label');
    }
    set label(value) {
        this._setOption('label', value);
    }
    get opacity() {
        return this._getOption('opacity');
    }
    set opacity(value) {
        this._setOption('opacity', value);
    }
    get visible() {
        return this._getOption('visible');
    }
    set visible(value) {
        this._setOption('visible', value);
    }
    get width() {
        return this._getOption('width');
    }
    set width(value) {
        this._setOption('width', value);
    }
    get _optionPath() {
        return 'horizontalLine';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartHorizontalLineComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoChartHorizontalLineComponent, isStandalone: true, selector: "dxo-chart-horizontal-line", inputs: { color: "color", dashStyle: "dashStyle", label: "label", opacity: "opacity", visible: "visible", width: "width" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartHorizontalLineComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-chart-horizontal-line', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { color: [{
                type: Input
            }], dashStyle: [{
                type: Input
            }], label: [{
                type: Input
            }], opacity: [{
                type: Input
            }], visible: [{
                type: Input
            }], width: [{
                type: Input
            }] } });
class DxoChartHorizontalLineModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartHorizontalLineModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoChartHorizontalLineModule, imports: [DxoChartHorizontalLineComponent], exports: [DxoChartHorizontalLineComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartHorizontalLineModule, imports: [DxoChartHorizontalLineComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartHorizontalLineModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoChartHorizontalLineComponent
                    ],
                    exports: [
                        DxoChartHorizontalLineComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoChartHoverStyleComponent extends NestedOption {
    get border() {
        return this._getOption('border');
    }
    set border(value) {
        this._setOption('border', value);
    }
    get color() {
        return this._getOption('color');
    }
    set color(value) {
        this._setOption('color', value);
    }
    get dashStyle() {
        return this._getOption('dashStyle');
    }
    set dashStyle(value) {
        this._setOption('dashStyle', value);
    }
    get hatching() {
        return this._getOption('hatching');
    }
    set hatching(value) {
        this._setOption('hatching', value);
    }
    get highlight() {
        return this._getOption('highlight');
    }
    set highlight(value) {
        this._setOption('highlight', value);
    }
    get width() {
        return this._getOption('width');
    }
    set width(value) {
        this._setOption('width', value);
    }
    get size() {
        return this._getOption('size');
    }
    set size(value) {
        this._setOption('size', value);
    }
    get _optionPath() {
        return 'hoverStyle';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartHoverStyleComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoChartHoverStyleComponent, isStandalone: true, selector: "dxo-chart-hover-style", inputs: { border: "border", color: "color", dashStyle: "dashStyle", hatching: "hatching", highlight: "highlight", width: "width", size: "size" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartHoverStyleComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-chart-hover-style', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { border: [{
                type: Input
            }], color: [{
                type: Input
            }], dashStyle: [{
                type: Input
            }], hatching: [{
                type: Input
            }], highlight: [{
                type: Input
            }], width: [{
                type: Input
            }], size: [{
                type: Input
            }] } });
class DxoChartHoverStyleModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartHoverStyleModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoChartHoverStyleModule, imports: [DxoChartHoverStyleComponent], exports: [DxoChartHoverStyleComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartHoverStyleModule, imports: [DxoChartHoverStyleComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartHoverStyleModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoChartHoverStyleComponent
                    ],
                    exports: [
                        DxoChartHoverStyleComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoChartImageComponent extends NestedOption {
    get height() {
        return this._getOption('height');
    }
    set height(value) {
        this._setOption('height', value);
    }
    get url() {
        return this._getOption('url');
    }
    set url(value) {
        this._setOption('url', value);
    }
    get width() {
        return this._getOption('width');
    }
    set width(value) {
        this._setOption('width', value);
    }
    get _optionPath() {
        return 'image';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartImageComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoChartImageComponent, isStandalone: true, selector: "dxo-chart-image", inputs: { height: "height", url: "url", width: "width" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartImageComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-chart-image', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { height: [{
                type: Input
            }], url: [{
                type: Input
            }], width: [{
                type: Input
            }] } });
class DxoChartImageModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartImageModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoChartImageModule, imports: [DxoChartImageComponent], exports: [DxoChartImageComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartImageModule, imports: [DxoChartImageComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartImageModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoChartImageComponent
                    ],
                    exports: [
                        DxoChartImageComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoChartLabelComponent extends NestedOption {
    get font() {
        return this._getOption('font');
    }
    set font(value) {
        this._setOption('font', value);
    }
    get horizontalAlignment() {
        return this._getOption('horizontalAlignment');
    }
    set horizontalAlignment(value) {
        this._setOption('horizontalAlignment', value);
    }
    get position() {
        return this._getOption('position');
    }
    set position(value) {
        this._setOption('position', value);
    }
    get verticalAlignment() {
        return this._getOption('verticalAlignment');
    }
    set verticalAlignment(value) {
        this._setOption('verticalAlignment', value);
    }
    get visible() {
        return this._getOption('visible');
    }
    set visible(value) {
        this._setOption('visible', value);
    }
    get text() {
        return this._getOption('text');
    }
    set text(value) {
        this._setOption('text', value);
    }
    get alignment() {
        return this._getOption('alignment');
    }
    set alignment(value) {
        this._setOption('alignment', value);
    }
    get customizeHint() {
        return this._getOption('customizeHint');
    }
    set customizeHint(value) {
        this._setOption('customizeHint', value);
    }
    get customizeText() {
        return this._getOption('customizeText');
    }
    set customizeText(value) {
        this._setOption('customizeText', value);
    }
    get displayMode() {
        return this._getOption('displayMode');
    }
    set displayMode(value) {
        this._setOption('displayMode', value);
    }
    get format() {
        return this._getOption('format');
    }
    set format(value) {
        this._setOption('format', value);
    }
    get indentFromAxis() {
        return this._getOption('indentFromAxis');
    }
    set indentFromAxis(value) {
        this._setOption('indentFromAxis', value);
    }
    get overlappingBehavior() {
        return this._getOption('overlappingBehavior');
    }
    set overlappingBehavior(value) {
        this._setOption('overlappingBehavior', value);
    }
    get rotationAngle() {
        return this._getOption('rotationAngle');
    }
    set rotationAngle(value) {
        this._setOption('rotationAngle', value);
    }
    get staggeringSpacing() {
        return this._getOption('staggeringSpacing');
    }
    set staggeringSpacing(value) {
        this._setOption('staggeringSpacing', value);
    }
    get template() {
        return this._getOption('template');
    }
    set template(value) {
        this._setOption('template', value);
    }
    get textOverflow() {
        return this._getOption('textOverflow');
    }
    set textOverflow(value) {
        this._setOption('textOverflow', value);
    }
    get wordWrap() {
        return this._getOption('wordWrap');
    }
    set wordWrap(value) {
        this._setOption('wordWrap', value);
    }
    get argumentFormat() {
        return this._getOption('argumentFormat');
    }
    set argumentFormat(value) {
        this._setOption('argumentFormat', value);
    }
    get backgroundColor() {
        return this._getOption('backgroundColor');
    }
    set backgroundColor(value) {
        this._setOption('backgroundColor', value);
    }
    get border() {
        return this._getOption('border');
    }
    set border(value) {
        this._setOption('border', value);
    }
    get connector() {
        return this._getOption('connector');
    }
    set connector(value) {
        this._setOption('connector', value);
    }
    get displayFormat() {
        return this._getOption('displayFormat');
    }
    set displayFormat(value) {
        this._setOption('displayFormat', value);
    }
    get horizontalOffset() {
        return this._getOption('horizontalOffset');
    }
    set horizontalOffset(value) {
        this._setOption('horizontalOffset', value);
    }
    get showForZeroValues() {
        return this._getOption('showForZeroValues');
    }
    set showForZeroValues(value) {
        this._setOption('showForZeroValues', value);
    }
    get verticalOffset() {
        return this._getOption('verticalOffset');
    }
    set verticalOffset(value) {
        this._setOption('verticalOffset', value);
    }
    get _optionPath() {
        return 'label';
    }
    constructor(parentOptionHost, optionHost, renderer, document, templateHost, element) {
        super();
        this.renderer = renderer;
        this.document = document;
        this.element = element;
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
        templateHost.setHost(this);
    }
    setTemplate(template) {
        this.template = template;
    }
    ngAfterViewInit() {
        extractTemplate(this, this.element, this.renderer, this.document);
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartLabelComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }, { token: i0.Renderer2 }, { token: DOCUMENT }, { token: i1.DxTemplateHost, host: true }, { token: i0.ElementRef }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoChartLabelComponent, isStandalone: true, selector: "dxo-chart-label", inputs: { font: "font", horizontalAlignment: "horizontalAlignment", position: "position", verticalAlignment: "verticalAlignment", visible: "visible", text: "text", alignment: "alignment", customizeHint: "customizeHint", customizeText: "customizeText", displayMode: "displayMode", format: "format", indentFromAxis: "indentFromAxis", overlappingBehavior: "overlappingBehavior", rotationAngle: "rotationAngle", staggeringSpacing: "staggeringSpacing", template: "template", textOverflow: "textOverflow", wordWrap: "wordWrap", argumentFormat: "argumentFormat", backgroundColor: "backgroundColor", border: "border", connector: "connector", displayFormat: "displayFormat", horizontalOffset: "horizontalOffset", showForZeroValues: "showForZeroValues", verticalOffset: "verticalOffset" }, providers: [NestedOptionHost, DxTemplateHost], usesInheritance: true, ngImport: i0, template: '<ng-content></ng-content>', isInline: true, styles: [":host{display:block}\n"], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartLabelComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-chart-label', template: '<ng-content></ng-content>', imports: [DxIntegrationModule], providers: [NestedOptionHost, DxTemplateHost], styles: [":host{display:block}\n"] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }, { type: i0.Renderer2 }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [DOCUMENT]
                }] }, { type: i1.DxTemplateHost, decorators: [{
                    type: Host
                }] }, { type: i0.ElementRef }], propDecorators: { font: [{
                type: Input
            }], horizontalAlignment: [{
                type: Input
            }], position: [{
                type: Input
            }], verticalAlignment: [{
                type: Input
            }], visible: [{
                type: Input
            }], text: [{
                type: Input
            }], alignment: [{
                type: Input
            }], customizeHint: [{
                type: Input
            }], customizeText: [{
                type: Input
            }], displayMode: [{
                type: Input
            }], format: [{
                type: Input
            }], indentFromAxis: [{
                type: Input
            }], overlappingBehavior: [{
                type: Input
            }], rotationAngle: [{
                type: Input
            }], staggeringSpacing: [{
                type: Input
            }], template: [{
                type: Input
            }], textOverflow: [{
                type: Input
            }], wordWrap: [{
                type: Input
            }], argumentFormat: [{
                type: Input
            }], backgroundColor: [{
                type: Input
            }], border: [{
                type: Input
            }], connector: [{
                type: Input
            }], displayFormat: [{
                type: Input
            }], horizontalOffset: [{
                type: Input
            }], showForZeroValues: [{
                type: Input
            }], verticalOffset: [{
                type: Input
            }] } });
class DxoChartLabelModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartLabelModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoChartLabelModule, imports: [DxoChartLabelComponent], exports: [DxoChartLabelComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartLabelModule, imports: [DxoChartLabelComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartLabelModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoChartLabelComponent
                    ],
                    exports: [
                        DxoChartLabelComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoChartLegendTitleSubtitleComponent extends NestedOption {
    get font() {
        return this._getOption('font');
    }
    set font(value) {
        this._setOption('font', value);
    }
    get offset() {
        return this._getOption('offset');
    }
    set offset(value) {
        this._setOption('offset', value);
    }
    get text() {
        return this._getOption('text');
    }
    set text(value) {
        this._setOption('text', value);
    }
    get _optionPath() {
        return 'subtitle';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartLegendTitleSubtitleComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoChartLegendTitleSubtitleComponent, isStandalone: true, selector: "dxo-chart-legend-title-subtitle", inputs: { font: "font", offset: "offset", text: "text" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartLegendTitleSubtitleComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-chart-legend-title-subtitle', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { font: [{
                type: Input
            }], offset: [{
                type: Input
            }], text: [{
                type: Input
            }] } });
class DxoChartLegendTitleSubtitleModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartLegendTitleSubtitleModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoChartLegendTitleSubtitleModule, imports: [DxoChartLegendTitleSubtitleComponent], exports: [DxoChartLegendTitleSubtitleComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartLegendTitleSubtitleModule, imports: [DxoChartLegendTitleSubtitleComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartLegendTitleSubtitleModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoChartLegendTitleSubtitleComponent
                    ],
                    exports: [
                        DxoChartLegendTitleSubtitleComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoChartLegendTitleComponent extends NestedOption {
    get font() {
        return this._getOption('font');
    }
    set font(value) {
        this._setOption('font', value);
    }
    get horizontalAlignment() {
        return this._getOption('horizontalAlignment');
    }
    set horizontalAlignment(value) {
        this._setOption('horizontalAlignment', value);
    }
    get margin() {
        return this._getOption('margin');
    }
    set margin(value) {
        this._setOption('margin', value);
    }
    get placeholderSize() {
        return this._getOption('placeholderSize');
    }
    set placeholderSize(value) {
        this._setOption('placeholderSize', value);
    }
    get subtitle() {
        return this._getOption('subtitle');
    }
    set subtitle(value) {
        this._setOption('subtitle', value);
    }
    get text() {
        return this._getOption('text');
    }
    set text(value) {
        this._setOption('text', value);
    }
    get verticalAlignment() {
        return this._getOption('verticalAlignment');
    }
    set verticalAlignment(value) {
        this._setOption('verticalAlignment', value);
    }
    get _optionPath() {
        return 'title';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartLegendTitleComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoChartLegendTitleComponent, isStandalone: true, selector: "dxo-chart-legend-title", inputs: { font: "font", horizontalAlignment: "horizontalAlignment", margin: "margin", placeholderSize: "placeholderSize", subtitle: "subtitle", text: "text", verticalAlignment: "verticalAlignment" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartLegendTitleComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-chart-legend-title', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { font: [{
                type: Input
            }], horizontalAlignment: [{
                type: Input
            }], margin: [{
                type: Input
            }], placeholderSize: [{
                type: Input
            }], subtitle: [{
                type: Input
            }], text: [{
                type: Input
            }], verticalAlignment: [{
                type: Input
            }] } });
class DxoChartLegendTitleModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartLegendTitleModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoChartLegendTitleModule, imports: [DxoChartLegendTitleComponent], exports: [DxoChartLegendTitleComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartLegendTitleModule, imports: [DxoChartLegendTitleComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartLegendTitleModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoChartLegendTitleComponent
                    ],
                    exports: [
                        DxoChartLegendTitleComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoChartLegendComponent extends NestedOption {
    get backgroundColor() {
        return this._getOption('backgroundColor');
    }
    set backgroundColor(value) {
        this._setOption('backgroundColor', value);
    }
    get border() {
        return this._getOption('border');
    }
    set border(value) {
        this._setOption('border', value);
    }
    get columnCount() {
        return this._getOption('columnCount');
    }
    set columnCount(value) {
        this._setOption('columnCount', value);
    }
    get columnItemSpacing() {
        return this._getOption('columnItemSpacing');
    }
    set columnItemSpacing(value) {
        this._setOption('columnItemSpacing', value);
    }
    get customizeHint() {
        return this._getOption('customizeHint');
    }
    set customizeHint(value) {
        this._setOption('customizeHint', value);
    }
    get customizeItems() {
        return this._getOption('customizeItems');
    }
    set customizeItems(value) {
        this._setOption('customizeItems', value);
    }
    get customizeText() {
        return this._getOption('customizeText');
    }
    set customizeText(value) {
        this._setOption('customizeText', value);
    }
    get font() {
        return this._getOption('font');
    }
    set font(value) {
        this._setOption('font', value);
    }
    get horizontalAlignment() {
        return this._getOption('horizontalAlignment');
    }
    set horizontalAlignment(value) {
        this._setOption('horizontalAlignment', value);
    }
    get hoverMode() {
        return this._getOption('hoverMode');
    }
    set hoverMode(value) {
        this._setOption('hoverMode', value);
    }
    get itemsAlignment() {
        return this._getOption('itemsAlignment');
    }
    set itemsAlignment(value) {
        this._setOption('itemsAlignment', value);
    }
    get itemTextPosition() {
        return this._getOption('itemTextPosition');
    }
    set itemTextPosition(value) {
        this._setOption('itemTextPosition', value);
    }
    get margin() {
        return this._getOption('margin');
    }
    set margin(value) {
        this._setOption('margin', value);
    }
    get markerSize() {
        return this._getOption('markerSize');
    }
    set markerSize(value) {
        this._setOption('markerSize', value);
    }
    get markerTemplate() {
        return this._getOption('markerTemplate');
    }
    set markerTemplate(value) {
        this._setOption('markerTemplate', value);
    }
    get orientation() {
        return this._getOption('orientation');
    }
    set orientation(value) {
        this._setOption('orientation', value);
    }
    get paddingLeftRight() {
        return this._getOption('paddingLeftRight');
    }
    set paddingLeftRight(value) {
        this._setOption('paddingLeftRight', value);
    }
    get paddingTopBottom() {
        return this._getOption('paddingTopBottom');
    }
    set paddingTopBottom(value) {
        this._setOption('paddingTopBottom', value);
    }
    get position() {
        return this._getOption('position');
    }
    set position(value) {
        this._setOption('position', value);
    }
    get rowCount() {
        return this._getOption('rowCount');
    }
    set rowCount(value) {
        this._setOption('rowCount', value);
    }
    get rowItemSpacing() {
        return this._getOption('rowItemSpacing');
    }
    set rowItemSpacing(value) {
        this._setOption('rowItemSpacing', value);
    }
    get title() {
        return this._getOption('title');
    }
    set title(value) {
        this._setOption('title', value);
    }
    get verticalAlignment() {
        return this._getOption('verticalAlignment');
    }
    set verticalAlignment(value) {
        this._setOption('verticalAlignment', value);
    }
    get visible() {
        return this._getOption('visible');
    }
    set visible(value) {
        this._setOption('visible', value);
    }
    get _optionPath() {
        return 'legend';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartLegendComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoChartLegendComponent, isStandalone: true, selector: "dxo-chart-legend", inputs: { backgroundColor: "backgroundColor", border: "border", columnCount: "columnCount", columnItemSpacing: "columnItemSpacing", customizeHint: "customizeHint", customizeItems: "customizeItems", customizeText: "customizeText", font: "font", horizontalAlignment: "horizontalAlignment", hoverMode: "hoverMode", itemsAlignment: "itemsAlignment", itemTextPosition: "itemTextPosition", margin: "margin", markerSize: "markerSize", markerTemplate: "markerTemplate", orientation: "orientation", paddingLeftRight: "paddingLeftRight", paddingTopBottom: "paddingTopBottom", position: "position", rowCount: "rowCount", rowItemSpacing: "rowItemSpacing", title: "title", verticalAlignment: "verticalAlignment", visible: "visible" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartLegendComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-chart-legend', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { backgroundColor: [{
                type: Input
            }], border: [{
                type: Input
            }], columnCount: [{
                type: Input
            }], columnItemSpacing: [{
                type: Input
            }], customizeHint: [{
                type: Input
            }], customizeItems: [{
                type: Input
            }], customizeText: [{
                type: Input
            }], font: [{
                type: Input
            }], horizontalAlignment: [{
                type: Input
            }], hoverMode: [{
                type: Input
            }], itemsAlignment: [{
                type: Input
            }], itemTextPosition: [{
                type: Input
            }], margin: [{
                type: Input
            }], markerSize: [{
                type: Input
            }], markerTemplate: [{
                type: Input
            }], orientation: [{
                type: Input
            }], paddingLeftRight: [{
                type: Input
            }], paddingTopBottom: [{
                type: Input
            }], position: [{
                type: Input
            }], rowCount: [{
                type: Input
            }], rowItemSpacing: [{
                type: Input
            }], title: [{
                type: Input
            }], verticalAlignment: [{
                type: Input
            }], visible: [{
                type: Input
            }] } });
class DxoChartLegendModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartLegendModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoChartLegendModule, imports: [DxoChartLegendComponent], exports: [DxoChartLegendComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartLegendModule, imports: [DxoChartLegendComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartLegendModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoChartLegendComponent
                    ],
                    exports: [
                        DxoChartLegendComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoChartLengthComponent extends NestedOption {
    get days() {
        return this._getOption('days');
    }
    set days(value) {
        this._setOption('days', value);
    }
    get hours() {
        return this._getOption('hours');
    }
    set hours(value) {
        this._setOption('hours', value);
    }
    get milliseconds() {
        return this._getOption('milliseconds');
    }
    set milliseconds(value) {
        this._setOption('milliseconds', value);
    }
    get minutes() {
        return this._getOption('minutes');
    }
    set minutes(value) {
        this._setOption('minutes', value);
    }
    get months() {
        return this._getOption('months');
    }
    set months(value) {
        this._setOption('months', value);
    }
    get quarters() {
        return this._getOption('quarters');
    }
    set quarters(value) {
        this._setOption('quarters', value);
    }
    get seconds() {
        return this._getOption('seconds');
    }
    set seconds(value) {
        this._setOption('seconds', value);
    }
    get weeks() {
        return this._getOption('weeks');
    }
    set weeks(value) {
        this._setOption('weeks', value);
    }
    get years() {
        return this._getOption('years');
    }
    set years(value) {
        this._setOption('years', value);
    }
    get _optionPath() {
        return 'length';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartLengthComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoChartLengthComponent, isStandalone: true, selector: "dxo-chart-length", inputs: { days: "days", hours: "hours", milliseconds: "milliseconds", minutes: "minutes", months: "months", quarters: "quarters", seconds: "seconds", weeks: "weeks", years: "years" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartLengthComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-chart-length', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { days: [{
                type: Input
            }], hours: [{
                type: Input
            }], milliseconds: [{
                type: Input
            }], minutes: [{
                type: Input
            }], months: [{
                type: Input
            }], quarters: [{
                type: Input
            }], seconds: [{
                type: Input
            }], weeks: [{
                type: Input
            }], years: [{
                type: Input
            }] } });
class DxoChartLengthModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartLengthModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoChartLengthModule, imports: [DxoChartLengthComponent], exports: [DxoChartLengthComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartLengthModule, imports: [DxoChartLengthComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartLengthModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoChartLengthComponent
                    ],
                    exports: [
                        DxoChartLengthComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoChartLoadingIndicatorComponent extends NestedOption {
    get backgroundColor() {
        return this._getOption('backgroundColor');
    }
    set backgroundColor(value) {
        this._setOption('backgroundColor', value);
    }
    get enabled() {
        return this._getOption('enabled');
    }
    set enabled(value) {
        this._setOption('enabled', value);
    }
    get font() {
        return this._getOption('font');
    }
    set font(value) {
        this._setOption('font', value);
    }
    get show() {
        return this._getOption('show');
    }
    set show(value) {
        this._setOption('show', value);
    }
    get text() {
        return this._getOption('text');
    }
    set text(value) {
        this._setOption('text', value);
    }
    get _optionPath() {
        return 'loadingIndicator';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        this._createEventEmitters([
            { emit: 'showChange' }
        ]);
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartLoadingIndicatorComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoChartLoadingIndicatorComponent, isStandalone: true, selector: "dxo-chart-loading-indicator", inputs: { backgroundColor: "backgroundColor", enabled: "enabled", font: "font", show: "show", text: "text" }, outputs: { showChange: "showChange" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartLoadingIndicatorComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-chart-loading-indicator', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { backgroundColor: [{
                type: Input
            }], enabled: [{
                type: Input
            }], font: [{
                type: Input
            }], show: [{
                type: Input
            }], text: [{
                type: Input
            }], showChange: [{
                type: Output
            }] } });
class DxoChartLoadingIndicatorModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartLoadingIndicatorModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoChartLoadingIndicatorModule, imports: [DxoChartLoadingIndicatorComponent], exports: [DxoChartLoadingIndicatorComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartLoadingIndicatorModule, imports: [DxoChartLoadingIndicatorComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartLoadingIndicatorModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoChartLoadingIndicatorComponent
                    ],
                    exports: [
                        DxoChartLoadingIndicatorComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoChartMarginComponent extends NestedOption {
    get bottom() {
        return this._getOption('bottom');
    }
    set bottom(value) {
        this._setOption('bottom', value);
    }
    get left() {
        return this._getOption('left');
    }
    set left(value) {
        this._setOption('left', value);
    }
    get right() {
        return this._getOption('right');
    }
    set right(value) {
        this._setOption('right', value);
    }
    get top() {
        return this._getOption('top');
    }
    set top(value) {
        this._setOption('top', value);
    }
    get _optionPath() {
        return 'margin';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartMarginComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoChartMarginComponent, isStandalone: true, selector: "dxo-chart-margin", inputs: { bottom: "bottom", left: "left", right: "right", top: "top" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartMarginComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-chart-margin', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { bottom: [{
                type: Input
            }], left: [{
                type: Input
            }], right: [{
                type: Input
            }], top: [{
                type: Input
            }] } });
class DxoChartMarginModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartMarginModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoChartMarginModule, imports: [DxoChartMarginComponent], exports: [DxoChartMarginComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartMarginModule, imports: [DxoChartMarginComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartMarginModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoChartMarginComponent
                    ],
                    exports: [
                        DxoChartMarginComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoChartMinVisualRangeLengthComponent extends NestedOption {
    get days() {
        return this._getOption('days');
    }
    set days(value) {
        this._setOption('days', value);
    }
    get hours() {
        return this._getOption('hours');
    }
    set hours(value) {
        this._setOption('hours', value);
    }
    get milliseconds() {
        return this._getOption('milliseconds');
    }
    set milliseconds(value) {
        this._setOption('milliseconds', value);
    }
    get minutes() {
        return this._getOption('minutes');
    }
    set minutes(value) {
        this._setOption('minutes', value);
    }
    get months() {
        return this._getOption('months');
    }
    set months(value) {
        this._setOption('months', value);
    }
    get quarters() {
        return this._getOption('quarters');
    }
    set quarters(value) {
        this._setOption('quarters', value);
    }
    get seconds() {
        return this._getOption('seconds');
    }
    set seconds(value) {
        this._setOption('seconds', value);
    }
    get weeks() {
        return this._getOption('weeks');
    }
    set weeks(value) {
        this._setOption('weeks', value);
    }
    get years() {
        return this._getOption('years');
    }
    set years(value) {
        this._setOption('years', value);
    }
    get _optionPath() {
        return 'minVisualRangeLength';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartMinVisualRangeLengthComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoChartMinVisualRangeLengthComponent, isStandalone: true, selector: "dxo-chart-min-visual-range-length", inputs: { days: "days", hours: "hours", milliseconds: "milliseconds", minutes: "minutes", months: "months", quarters: "quarters", seconds: "seconds", weeks: "weeks", years: "years" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartMinVisualRangeLengthComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-chart-min-visual-range-length', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { days: [{
                type: Input
            }], hours: [{
                type: Input
            }], milliseconds: [{
                type: Input
            }], minutes: [{
                type: Input
            }], months: [{
                type: Input
            }], quarters: [{
                type: Input
            }], seconds: [{
                type: Input
            }], weeks: [{
                type: Input
            }], years: [{
                type: Input
            }] } });
class DxoChartMinVisualRangeLengthModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartMinVisualRangeLengthModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoChartMinVisualRangeLengthModule, imports: [DxoChartMinVisualRangeLengthComponent], exports: [DxoChartMinVisualRangeLengthComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartMinVisualRangeLengthModule, imports: [DxoChartMinVisualRangeLengthComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartMinVisualRangeLengthModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoChartMinVisualRangeLengthComponent
                    ],
                    exports: [
                        DxoChartMinVisualRangeLengthComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoChartMinorGridComponent extends NestedOption {
    get color() {
        return this._getOption('color');
    }
    set color(value) {
        this._setOption('color', value);
    }
    get opacity() {
        return this._getOption('opacity');
    }
    set opacity(value) {
        this._setOption('opacity', value);
    }
    get visible() {
        return this._getOption('visible');
    }
    set visible(value) {
        this._setOption('visible', value);
    }
    get width() {
        return this._getOption('width');
    }
    set width(value) {
        this._setOption('width', value);
    }
    get _optionPath() {
        return 'minorGrid';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartMinorGridComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoChartMinorGridComponent, isStandalone: true, selector: "dxo-chart-minor-grid", inputs: { color: "color", opacity: "opacity", visible: "visible", width: "width" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartMinorGridComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-chart-minor-grid', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { color: [{
                type: Input
            }], opacity: [{
                type: Input
            }], visible: [{
                type: Input
            }], width: [{
                type: Input
            }] } });
class DxoChartMinorGridModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartMinorGridModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoChartMinorGridModule, imports: [DxoChartMinorGridComponent], exports: [DxoChartMinorGridComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartMinorGridModule, imports: [DxoChartMinorGridComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartMinorGridModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoChartMinorGridComponent
                    ],
                    exports: [
                        DxoChartMinorGridComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoChartMinorTickIntervalComponent extends NestedOption {
    get days() {
        return this._getOption('days');
    }
    set days(value) {
        this._setOption('days', value);
    }
    get hours() {
        return this._getOption('hours');
    }
    set hours(value) {
        this._setOption('hours', value);
    }
    get milliseconds() {
        return this._getOption('milliseconds');
    }
    set milliseconds(value) {
        this._setOption('milliseconds', value);
    }
    get minutes() {
        return this._getOption('minutes');
    }
    set minutes(value) {
        this._setOption('minutes', value);
    }
    get months() {
        return this._getOption('months');
    }
    set months(value) {
        this._setOption('months', value);
    }
    get quarters() {
        return this._getOption('quarters');
    }
    set quarters(value) {
        this._setOption('quarters', value);
    }
    get seconds() {
        return this._getOption('seconds');
    }
    set seconds(value) {
        this._setOption('seconds', value);
    }
    get weeks() {
        return this._getOption('weeks');
    }
    set weeks(value) {
        this._setOption('weeks', value);
    }
    get years() {
        return this._getOption('years');
    }
    set years(value) {
        this._setOption('years', value);
    }
    get _optionPath() {
        return 'minorTickInterval';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartMinorTickIntervalComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoChartMinorTickIntervalComponent, isStandalone: true, selector: "dxo-chart-minor-tick-interval", inputs: { days: "days", hours: "hours", milliseconds: "milliseconds", minutes: "minutes", months: "months", quarters: "quarters", seconds: "seconds", weeks: "weeks", years: "years" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartMinorTickIntervalComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-chart-minor-tick-interval', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { days: [{
                type: Input
            }], hours: [{
                type: Input
            }], milliseconds: [{
                type: Input
            }], minutes: [{
                type: Input
            }], months: [{
                type: Input
            }], quarters: [{
                type: Input
            }], seconds: [{
                type: Input
            }], weeks: [{
                type: Input
            }], years: [{
                type: Input
            }] } });
class DxoChartMinorTickIntervalModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartMinorTickIntervalModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoChartMinorTickIntervalModule, imports: [DxoChartMinorTickIntervalComponent], exports: [DxoChartMinorTickIntervalComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartMinorTickIntervalModule, imports: [DxoChartMinorTickIntervalComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartMinorTickIntervalModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoChartMinorTickIntervalComponent
                    ],
                    exports: [
                        DxoChartMinorTickIntervalComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoChartMinorTickComponent extends NestedOption {
    get color() {
        return this._getOption('color');
    }
    set color(value) {
        this._setOption('color', value);
    }
    get length() {
        return this._getOption('length');
    }
    set length(value) {
        this._setOption('length', value);
    }
    get opacity() {
        return this._getOption('opacity');
    }
    set opacity(value) {
        this._setOption('opacity', value);
    }
    get shift() {
        return this._getOption('shift');
    }
    set shift(value) {
        this._setOption('shift', value);
    }
    get visible() {
        return this._getOption('visible');
    }
    set visible(value) {
        this._setOption('visible', value);
    }
    get width() {
        return this._getOption('width');
    }
    set width(value) {
        this._setOption('width', value);
    }
    get _optionPath() {
        return 'minorTick';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartMinorTickComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoChartMinorTickComponent, isStandalone: true, selector: "dxo-chart-minor-tick", inputs: { color: "color", length: "length", opacity: "opacity", shift: "shift", visible: "visible", width: "width" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartMinorTickComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-chart-minor-tick', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { color: [{
                type: Input
            }], length: [{
                type: Input
            }], opacity: [{
                type: Input
            }], shift: [{
                type: Input
            }], visible: [{
                type: Input
            }], width: [{
                type: Input
            }] } });
class DxoChartMinorTickModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartMinorTickModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoChartMinorTickModule, imports: [DxoChartMinorTickComponent], exports: [DxoChartMinorTickComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartMinorTickModule, imports: [DxoChartMinorTickComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartMinorTickModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoChartMinorTickComponent
                    ],
                    exports: [
                        DxoChartMinorTickComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoChartPaneBorderComponent extends NestedOption {
    get bottom() {
        return this._getOption('bottom');
    }
    set bottom(value) {
        this._setOption('bottom', value);
    }
    get color() {
        return this._getOption('color');
    }
    set color(value) {
        this._setOption('color', value);
    }
    get dashStyle() {
        return this._getOption('dashStyle');
    }
    set dashStyle(value) {
        this._setOption('dashStyle', value);
    }
    get left() {
        return this._getOption('left');
    }
    set left(value) {
        this._setOption('left', value);
    }
    get opacity() {
        return this._getOption('opacity');
    }
    set opacity(value) {
        this._setOption('opacity', value);
    }
    get right() {
        return this._getOption('right');
    }
    set right(value) {
        this._setOption('right', value);
    }
    get top() {
        return this._getOption('top');
    }
    set top(value) {
        this._setOption('top', value);
    }
    get visible() {
        return this._getOption('visible');
    }
    set visible(value) {
        this._setOption('visible', value);
    }
    get width() {
        return this._getOption('width');
    }
    set width(value) {
        this._setOption('width', value);
    }
    get _optionPath() {
        return 'border';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartPaneBorderComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoChartPaneBorderComponent, isStandalone: true, selector: "dxo-chart-pane-border", inputs: { bottom: "bottom", color: "color", dashStyle: "dashStyle", left: "left", opacity: "opacity", right: "right", top: "top", visible: "visible", width: "width" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartPaneBorderComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-chart-pane-border', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { bottom: [{
                type: Input
            }], color: [{
                type: Input
            }], dashStyle: [{
                type: Input
            }], left: [{
                type: Input
            }], opacity: [{
                type: Input
            }], right: [{
                type: Input
            }], top: [{
                type: Input
            }], visible: [{
                type: Input
            }], width: [{
                type: Input
            }] } });
class DxoChartPaneBorderModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartPaneBorderModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoChartPaneBorderModule, imports: [DxoChartPaneBorderComponent], exports: [DxoChartPaneBorderComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartPaneBorderModule, imports: [DxoChartPaneBorderComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartPaneBorderModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoChartPaneBorderComponent
                    ],
                    exports: [
                        DxoChartPaneBorderComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxiChartPaneComponent extends CollectionNestedOption {
    get backgroundColor() {
        return this._getOption('backgroundColor');
    }
    set backgroundColor(value) {
        this._setOption('backgroundColor', value);
    }
    get border() {
        return this._getOption('border');
    }
    set border(value) {
        this._setOption('border', value);
    }
    get height() {
        return this._getOption('height');
    }
    set height(value) {
        this._setOption('height', value);
    }
    get name() {
        return this._getOption('name');
    }
    set name(value) {
        this._setOption('name', value);
    }
    get _optionPath() {
        return 'panes';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnDestroy() {
        this._deleteRemovedOptions(this._fullOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiChartPaneComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxiChartPaneComponent, isStandalone: true, selector: "dxi-chart-pane", inputs: { backgroundColor: "backgroundColor", border: "border", height: "height", name: "name" }, providers: [
            NestedOptionHost,
            {
                provide: PROPERTY_TOKEN_panes,
                useExisting: DxiChartPaneComponent,
            }
        ], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiChartPaneComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxi-chart-pane', template: '', imports: [DxIntegrationModule], providers: [
                        NestedOptionHost,
                        {
                            provide: PROPERTY_TOKEN_panes,
                            useExisting: DxiChartPaneComponent,
                        }
                    ] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { backgroundColor: [{
                type: Input
            }], border: [{
                type: Input
            }], height: [{
                type: Input
            }], name: [{
                type: Input
            }] } });
class DxiChartPaneModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiChartPaneModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxiChartPaneModule, imports: [DxiChartPaneComponent], exports: [DxiChartPaneComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiChartPaneModule, imports: [DxiChartPaneComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiChartPaneModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxiChartPaneComponent
                    ],
                    exports: [
                        DxiChartPaneComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoChartPointBorderComponent extends NestedOption {
    get color() {
        return this._getOption('color');
    }
    set color(value) {
        this._setOption('color', value);
    }
    get visible() {
        return this._getOption('visible');
    }
    set visible(value) {
        this._setOption('visible', value);
    }
    get width() {
        return this._getOption('width');
    }
    set width(value) {
        this._setOption('width', value);
    }
    get _optionPath() {
        return 'border';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartPointBorderComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoChartPointBorderComponent, isStandalone: true, selector: "dxo-chart-point-border", inputs: { color: "color", visible: "visible", width: "width" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartPointBorderComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-chart-point-border', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { color: [{
                type: Input
            }], visible: [{
                type: Input
            }], width: [{
                type: Input
            }] } });
class DxoChartPointBorderModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartPointBorderModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoChartPointBorderModule, imports: [DxoChartPointBorderComponent], exports: [DxoChartPointBorderComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartPointBorderModule, imports: [DxoChartPointBorderComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartPointBorderModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoChartPointBorderComponent
                    ],
                    exports: [
                        DxoChartPointBorderComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoChartPointHoverStyleComponent extends NestedOption {
    get border() {
        return this._getOption('border');
    }
    set border(value) {
        this._setOption('border', value);
    }
    get color() {
        return this._getOption('color');
    }
    set color(value) {
        this._setOption('color', value);
    }
    get size() {
        return this._getOption('size');
    }
    set size(value) {
        this._setOption('size', value);
    }
    get _optionPath() {
        return 'hoverStyle';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartPointHoverStyleComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoChartPointHoverStyleComponent, isStandalone: true, selector: "dxo-chart-point-hover-style", inputs: { border: "border", color: "color", size: "size" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartPointHoverStyleComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-chart-point-hover-style', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { border: [{
                type: Input
            }], color: [{
                type: Input
            }], size: [{
                type: Input
            }] } });
class DxoChartPointHoverStyleModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartPointHoverStyleModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoChartPointHoverStyleModule, imports: [DxoChartPointHoverStyleComponent], exports: [DxoChartPointHoverStyleComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartPointHoverStyleModule, imports: [DxoChartPointHoverStyleComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartPointHoverStyleModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoChartPointHoverStyleComponent
                    ],
                    exports: [
                        DxoChartPointHoverStyleComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoChartPointImageComponent extends NestedOption {
    get height() {
        return this._getOption('height');
    }
    set height(value) {
        this._setOption('height', value);
    }
    get url() {
        return this._getOption('url');
    }
    set url(value) {
        this._setOption('url', value);
    }
    get width() {
        return this._getOption('width');
    }
    set width(value) {
        this._setOption('width', value);
    }
    get _optionPath() {
        return 'image';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartPointImageComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoChartPointImageComponent, isStandalone: true, selector: "dxo-chart-point-image", inputs: { height: "height", url: "url", width: "width" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartPointImageComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-chart-point-image', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { height: [{
                type: Input
            }], url: [{
                type: Input
            }], width: [{
                type: Input
            }] } });
class DxoChartPointImageModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartPointImageModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoChartPointImageModule, imports: [DxoChartPointImageComponent], exports: [DxoChartPointImageComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartPointImageModule, imports: [DxoChartPointImageComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartPointImageModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoChartPointImageComponent
                    ],
                    exports: [
                        DxoChartPointImageComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoChartPointSelectionStyleComponent extends NestedOption {
    get border() {
        return this._getOption('border');
    }
    set border(value) {
        this._setOption('border', value);
    }
    get color() {
        return this._getOption('color');
    }
    set color(value) {
        this._setOption('color', value);
    }
    get size() {
        return this._getOption('size');
    }
    set size(value) {
        this._setOption('size', value);
    }
    get _optionPath() {
        return 'selectionStyle';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartPointSelectionStyleComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoChartPointSelectionStyleComponent, isStandalone: true, selector: "dxo-chart-point-selection-style", inputs: { border: "border", color: "color", size: "size" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartPointSelectionStyleComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-chart-point-selection-style', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { border: [{
                type: Input
            }], color: [{
                type: Input
            }], size: [{
                type: Input
            }] } });
class DxoChartPointSelectionStyleModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartPointSelectionStyleModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoChartPointSelectionStyleModule, imports: [DxoChartPointSelectionStyleComponent], exports: [DxoChartPointSelectionStyleComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartPointSelectionStyleModule, imports: [DxoChartPointSelectionStyleComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartPointSelectionStyleModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoChartPointSelectionStyleComponent
                    ],
                    exports: [
                        DxoChartPointSelectionStyleComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoChartPointComponent extends NestedOption {
    get border() {
        return this._getOption('border');
    }
    set border(value) {
        this._setOption('border', value);
    }
    get color() {
        return this._getOption('color');
    }
    set color(value) {
        this._setOption('color', value);
    }
    get hoverMode() {
        return this._getOption('hoverMode');
    }
    set hoverMode(value) {
        this._setOption('hoverMode', value);
    }
    get hoverStyle() {
        return this._getOption('hoverStyle');
    }
    set hoverStyle(value) {
        this._setOption('hoverStyle', value);
    }
    get image() {
        return this._getOption('image');
    }
    set image(value) {
        this._setOption('image', value);
    }
    get selectionMode() {
        return this._getOption('selectionMode');
    }
    set selectionMode(value) {
        this._setOption('selectionMode', value);
    }
    get selectionStyle() {
        return this._getOption('selectionStyle');
    }
    set selectionStyle(value) {
        this._setOption('selectionStyle', value);
    }
    get size() {
        return this._getOption('size');
    }
    set size(value) {
        this._setOption('size', value);
    }
    get symbol() {
        return this._getOption('symbol');
    }
    set symbol(value) {
        this._setOption('symbol', value);
    }
    get visible() {
        return this._getOption('visible');
    }
    set visible(value) {
        this._setOption('visible', value);
    }
    get _optionPath() {
        return 'point';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartPointComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoChartPointComponent, isStandalone: true, selector: "dxo-chart-point", inputs: { border: "border", color: "color", hoverMode: "hoverMode", hoverStyle: "hoverStyle", image: "image", selectionMode: "selectionMode", selectionStyle: "selectionStyle", size: "size", symbol: "symbol", visible: "visible" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartPointComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-chart-point', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { border: [{
                type: Input
            }], color: [{
                type: Input
            }], hoverMode: [{
                type: Input
            }], hoverStyle: [{
                type: Input
            }], image: [{
                type: Input
            }], selectionMode: [{
                type: Input
            }], selectionStyle: [{
                type: Input
            }], size: [{
                type: Input
            }], symbol: [{
                type: Input
            }], visible: [{
                type: Input
            }] } });
class DxoChartPointModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartPointModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoChartPointModule, imports: [DxoChartPointComponent], exports: [DxoChartPointComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartPointModule, imports: [DxoChartPointComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartPointModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoChartPointComponent
                    ],
                    exports: [
                        DxoChartPointComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoChartReductionComponent extends NestedOption {
    get color() {
        return this._getOption('color');
    }
    set color(value) {
        this._setOption('color', value);
    }
    get level() {
        return this._getOption('level');
    }
    set level(value) {
        this._setOption('level', value);
    }
    get _optionPath() {
        return 'reduction';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartReductionComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoChartReductionComponent, isStandalone: true, selector: "dxo-chart-reduction", inputs: { color: "color", level: "level" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartReductionComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-chart-reduction', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { color: [{
                type: Input
            }], level: [{
                type: Input
            }] } });
class DxoChartReductionModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartReductionModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoChartReductionModule, imports: [DxoChartReductionComponent], exports: [DxoChartReductionComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartReductionModule, imports: [DxoChartReductionComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartReductionModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoChartReductionComponent
                    ],
                    exports: [
                        DxoChartReductionComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoChartScrollBarComponent extends NestedOption {
    get color() {
        return this._getOption('color');
    }
    set color(value) {
        this._setOption('color', value);
    }
    get offset() {
        return this._getOption('offset');
    }
    set offset(value) {
        this._setOption('offset', value);
    }
    get opacity() {
        return this._getOption('opacity');
    }
    set opacity(value) {
        this._setOption('opacity', value);
    }
    get position() {
        return this._getOption('position');
    }
    set position(value) {
        this._setOption('position', value);
    }
    get visible() {
        return this._getOption('visible');
    }
    set visible(value) {
        this._setOption('visible', value);
    }
    get width() {
        return this._getOption('width');
    }
    set width(value) {
        this._setOption('width', value);
    }
    get _optionPath() {
        return 'scrollBar';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartScrollBarComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoChartScrollBarComponent, isStandalone: true, selector: "dxo-chart-scroll-bar", inputs: { color: "color", offset: "offset", opacity: "opacity", position: "position", visible: "visible", width: "width" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartScrollBarComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-chart-scroll-bar', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { color: [{
                type: Input
            }], offset: [{
                type: Input
            }], opacity: [{
                type: Input
            }], position: [{
                type: Input
            }], visible: [{
                type: Input
            }], width: [{
                type: Input
            }] } });
class DxoChartScrollBarModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartScrollBarModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoChartScrollBarModule, imports: [DxoChartScrollBarComponent], exports: [DxoChartScrollBarComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartScrollBarModule, imports: [DxoChartScrollBarComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartScrollBarModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoChartScrollBarComponent
                    ],
                    exports: [
                        DxoChartScrollBarComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoChartSelectionStyleComponent extends NestedOption {
    get border() {
        return this._getOption('border');
    }
    set border(value) {
        this._setOption('border', value);
    }
    get color() {
        return this._getOption('color');
    }
    set color(value) {
        this._setOption('color', value);
    }
    get size() {
        return this._getOption('size');
    }
    set size(value) {
        this._setOption('size', value);
    }
    get dashStyle() {
        return this._getOption('dashStyle');
    }
    set dashStyle(value) {
        this._setOption('dashStyle', value);
    }
    get hatching() {
        return this._getOption('hatching');
    }
    set hatching(value) {
        this._setOption('hatching', value);
    }
    get highlight() {
        return this._getOption('highlight');
    }
    set highlight(value) {
        this._setOption('highlight', value);
    }
    get width() {
        return this._getOption('width');
    }
    set width(value) {
        this._setOption('width', value);
    }
    get _optionPath() {
        return 'selectionStyle';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartSelectionStyleComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoChartSelectionStyleComponent, isStandalone: true, selector: "dxo-chart-selection-style", inputs: { border: "border", color: "color", size: "size", dashStyle: "dashStyle", hatching: "hatching", highlight: "highlight", width: "width" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartSelectionStyleComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-chart-selection-style', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { border: [{
                type: Input
            }], color: [{
                type: Input
            }], size: [{
                type: Input
            }], dashStyle: [{
                type: Input
            }], hatching: [{
                type: Input
            }], highlight: [{
                type: Input
            }], width: [{
                type: Input
            }] } });
class DxoChartSelectionStyleModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartSelectionStyleModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoChartSelectionStyleModule, imports: [DxoChartSelectionStyleComponent], exports: [DxoChartSelectionStyleComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartSelectionStyleModule, imports: [DxoChartSelectionStyleComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartSelectionStyleModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoChartSelectionStyleComponent
                    ],
                    exports: [
                        DxoChartSelectionStyleComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoChartSeriesBorderComponent extends NestedOption {
    get color() {
        return this._getOption('color');
    }
    set color(value) {
        this._setOption('color', value);
    }
    get dashStyle() {
        return this._getOption('dashStyle');
    }
    set dashStyle(value) {
        this._setOption('dashStyle', value);
    }
    get visible() {
        return this._getOption('visible');
    }
    set visible(value) {
        this._setOption('visible', value);
    }
    get width() {
        return this._getOption('width');
    }
    set width(value) {
        this._setOption('width', value);
    }
    get _optionPath() {
        return 'border';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartSeriesBorderComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoChartSeriesBorderComponent, isStandalone: true, selector: "dxo-chart-series-border", inputs: { color: "color", dashStyle: "dashStyle", visible: "visible", width: "width" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartSeriesBorderComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-chart-series-border', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { color: [{
                type: Input
            }], dashStyle: [{
                type: Input
            }], visible: [{
                type: Input
            }], width: [{
                type: Input
            }] } });
class DxoChartSeriesBorderModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartSeriesBorderModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoChartSeriesBorderModule, imports: [DxoChartSeriesBorderComponent], exports: [DxoChartSeriesBorderComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartSeriesBorderModule, imports: [DxoChartSeriesBorderComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartSeriesBorderModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoChartSeriesBorderComponent
                    ],
                    exports: [
                        DxoChartSeriesBorderComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxiChartSeriesComponent extends CollectionNestedOption {
    get aggregation() {
        return this._getOption('aggregation');
    }
    set aggregation(value) {
        this._setOption('aggregation', value);
    }
    get argumentField() {
        return this._getOption('argumentField');
    }
    set argumentField(value) {
        this._setOption('argumentField', value);
    }
    get axis() {
        return this._getOption('axis');
    }
    set axis(value) {
        this._setOption('axis', value);
    }
    get barOverlapGroup() {
        return this._getOption('barOverlapGroup');
    }
    set barOverlapGroup(value) {
        this._setOption('barOverlapGroup', value);
    }
    get barPadding() {
        return this._getOption('barPadding');
    }
    set barPadding(value) {
        this._setOption('barPadding', value);
    }
    get barWidth() {
        return this._getOption('barWidth');
    }
    set barWidth(value) {
        this._setOption('barWidth', value);
    }
    get border() {
        return this._getOption('border');
    }
    set border(value) {
        this._setOption('border', value);
    }
    get closeValueField() {
        return this._getOption('closeValueField');
    }
    set closeValueField(value) {
        this._setOption('closeValueField', value);
    }
    get color() {
        return this._getOption('color');
    }
    set color(value) {
        this._setOption('color', value);
    }
    get cornerRadius() {
        return this._getOption('cornerRadius');
    }
    set cornerRadius(value) {
        this._setOption('cornerRadius', value);
    }
    get dashStyle() {
        return this._getOption('dashStyle');
    }
    set dashStyle(value) {
        this._setOption('dashStyle', value);
    }
    get highValueField() {
        return this._getOption('highValueField');
    }
    set highValueField(value) {
        this._setOption('highValueField', value);
    }
    get hoverMode() {
        return this._getOption('hoverMode');
    }
    set hoverMode(value) {
        this._setOption('hoverMode', value);
    }
    get hoverStyle() {
        return this._getOption('hoverStyle');
    }
    set hoverStyle(value) {
        this._setOption('hoverStyle', value);
    }
    get ignoreEmptyPoints() {
        return this._getOption('ignoreEmptyPoints');
    }
    set ignoreEmptyPoints(value) {
        this._setOption('ignoreEmptyPoints', value);
    }
    get innerColor() {
        return this._getOption('innerColor');
    }
    set innerColor(value) {
        this._setOption('innerColor', value);
    }
    get label() {
        return this._getOption('label');
    }
    set label(value) {
        this._setOption('label', value);
    }
    get lowValueField() {
        return this._getOption('lowValueField');
    }
    set lowValueField(value) {
        this._setOption('lowValueField', value);
    }
    get maxLabelCount() {
        return this._getOption('maxLabelCount');
    }
    set maxLabelCount(value) {
        this._setOption('maxLabelCount', value);
    }
    get minBarSize() {
        return this._getOption('minBarSize');
    }
    set minBarSize(value) {
        this._setOption('minBarSize', value);
    }
    get name() {
        return this._getOption('name');
    }
    set name(value) {
        this._setOption('name', value);
    }
    get opacity() {
        return this._getOption('opacity');
    }
    set opacity(value) {
        this._setOption('opacity', value);
    }
    get openValueField() {
        return this._getOption('openValueField');
    }
    set openValueField(value) {
        this._setOption('openValueField', value);
    }
    get pane() {
        return this._getOption('pane');
    }
    set pane(value) {
        this._setOption('pane', value);
    }
    get point() {
        return this._getOption('point');
    }
    set point(value) {
        this._setOption('point', value);
    }
    get rangeValue1Field() {
        return this._getOption('rangeValue1Field');
    }
    set rangeValue1Field(value) {
        this._setOption('rangeValue1Field', value);
    }
    get rangeValue2Field() {
        return this._getOption('rangeValue2Field');
    }
    set rangeValue2Field(value) {
        this._setOption('rangeValue2Field', value);
    }
    get reduction() {
        return this._getOption('reduction');
    }
    set reduction(value) {
        this._setOption('reduction', value);
    }
    get selectionMode() {
        return this._getOption('selectionMode');
    }
    set selectionMode(value) {
        this._setOption('selectionMode', value);
    }
    get selectionStyle() {
        return this._getOption('selectionStyle');
    }
    set selectionStyle(value) {
        this._setOption('selectionStyle', value);
    }
    get showInLegend() {
        return this._getOption('showInLegend');
    }
    set showInLegend(value) {
        this._setOption('showInLegend', value);
    }
    get sizeField() {
        return this._getOption('sizeField');
    }
    set sizeField(value) {
        this._setOption('sizeField', value);
    }
    get stack() {
        return this._getOption('stack');
    }
    set stack(value) {
        this._setOption('stack', value);
    }
    get tag() {
        return this._getOption('tag');
    }
    set tag(value) {
        this._setOption('tag', value);
    }
    get tagField() {
        return this._getOption('tagField');
    }
    set tagField(value) {
        this._setOption('tagField', value);
    }
    get type() {
        return this._getOption('type');
    }
    set type(value) {
        this._setOption('type', value);
    }
    get valueErrorBar() {
        return this._getOption('valueErrorBar');
    }
    set valueErrorBar(value) {
        this._setOption('valueErrorBar', value);
    }
    get valueField() {
        return this._getOption('valueField');
    }
    set valueField(value) {
        this._setOption('valueField', value);
    }
    get visible() {
        return this._getOption('visible');
    }
    set visible(value) {
        this._setOption('visible', value);
    }
    get width() {
        return this._getOption('width');
    }
    set width(value) {
        this._setOption('width', value);
    }
    get _optionPath() {
        return 'series';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnDestroy() {
        this._deleteRemovedOptions(this._fullOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiChartSeriesComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxiChartSeriesComponent, isStandalone: true, selector: "dxi-chart-series", inputs: { aggregation: "aggregation", argumentField: "argumentField", axis: "axis", barOverlapGroup: "barOverlapGroup", barPadding: "barPadding", barWidth: "barWidth", border: "border", closeValueField: "closeValueField", color: "color", cornerRadius: "cornerRadius", dashStyle: "dashStyle", highValueField: "highValueField", hoverMode: "hoverMode", hoverStyle: "hoverStyle", ignoreEmptyPoints: "ignoreEmptyPoints", innerColor: "innerColor", label: "label", lowValueField: "lowValueField", maxLabelCount: "maxLabelCount", minBarSize: "minBarSize", name: "name", opacity: "opacity", openValueField: "openValueField", pane: "pane", point: "point", rangeValue1Field: "rangeValue1Field", rangeValue2Field: "rangeValue2Field", reduction: "reduction", selectionMode: "selectionMode", selectionStyle: "selectionStyle", showInLegend: "showInLegend", sizeField: "sizeField", stack: "stack", tag: "tag", tagField: "tagField", type: "type", valueErrorBar: "valueErrorBar", valueField: "valueField", visible: "visible", width: "width" }, providers: [
            NestedOptionHost,
            {
                provide: PROPERTY_TOKEN_series,
                useExisting: DxiChartSeriesComponent,
            }
        ], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiChartSeriesComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxi-chart-series', template: '', imports: [DxIntegrationModule], providers: [
                        NestedOptionHost,
                        {
                            provide: PROPERTY_TOKEN_series,
                            useExisting: DxiChartSeriesComponent,
                        }
                    ] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { aggregation: [{
                type: Input
            }], argumentField: [{
                type: Input
            }], axis: [{
                type: Input
            }], barOverlapGroup: [{
                type: Input
            }], barPadding: [{
                type: Input
            }], barWidth: [{
                type: Input
            }], border: [{
                type: Input
            }], closeValueField: [{
                type: Input
            }], color: [{
                type: Input
            }], cornerRadius: [{
                type: Input
            }], dashStyle: [{
                type: Input
            }], highValueField: [{
                type: Input
            }], hoverMode: [{
                type: Input
            }], hoverStyle: [{
                type: Input
            }], ignoreEmptyPoints: [{
                type: Input
            }], innerColor: [{
                type: Input
            }], label: [{
                type: Input
            }], lowValueField: [{
                type: Input
            }], maxLabelCount: [{
                type: Input
            }], minBarSize: [{
                type: Input
            }], name: [{
                type: Input
            }], opacity: [{
                type: Input
            }], openValueField: [{
                type: Input
            }], pane: [{
                type: Input
            }], point: [{
                type: Input
            }], rangeValue1Field: [{
                type: Input
            }], rangeValue2Field: [{
                type: Input
            }], reduction: [{
                type: Input
            }], selectionMode: [{
                type: Input
            }], selectionStyle: [{
                type: Input
            }], showInLegend: [{
                type: Input
            }], sizeField: [{
                type: Input
            }], stack: [{
                type: Input
            }], tag: [{
                type: Input
            }], tagField: [{
                type: Input
            }], type: [{
                type: Input
            }], valueErrorBar: [{
                type: Input
            }], valueField: [{
                type: Input
            }], visible: [{
                type: Input
            }], width: [{
                type: Input
            }] } });
class DxiChartSeriesModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiChartSeriesModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxiChartSeriesModule, imports: [DxiChartSeriesComponent], exports: [DxiChartSeriesComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiChartSeriesModule, imports: [DxiChartSeriesComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiChartSeriesModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxiChartSeriesComponent
                    ],
                    exports: [
                        DxiChartSeriesComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoChartSeriesTemplateComponent extends NestedOption {
    get customizeSeries() {
        return this._getOption('customizeSeries');
    }
    set customizeSeries(value) {
        this._setOption('customizeSeries', value);
    }
    get nameField() {
        return this._getOption('nameField');
    }
    set nameField(value) {
        this._setOption('nameField', value);
    }
    get _optionPath() {
        return 'seriesTemplate';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartSeriesTemplateComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoChartSeriesTemplateComponent, isStandalone: true, selector: "dxo-chart-series-template", inputs: { customizeSeries: "customizeSeries", nameField: "nameField" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartSeriesTemplateComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-chart-series-template', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { customizeSeries: [{
                type: Input
            }], nameField: [{
                type: Input
            }] } });
class DxoChartSeriesTemplateModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartSeriesTemplateModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoChartSeriesTemplateModule, imports: [DxoChartSeriesTemplateComponent], exports: [DxoChartSeriesTemplateComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartSeriesTemplateModule, imports: [DxoChartSeriesTemplateComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartSeriesTemplateModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoChartSeriesTemplateComponent
                    ],
                    exports: [
                        DxoChartSeriesTemplateComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoChartShadowComponent extends NestedOption {
    get blur() {
        return this._getOption('blur');
    }
    set blur(value) {
        this._setOption('blur', value);
    }
    get color() {
        return this._getOption('color');
    }
    set color(value) {
        this._setOption('color', value);
    }
    get offsetX() {
        return this._getOption('offsetX');
    }
    set offsetX(value) {
        this._setOption('offsetX', value);
    }
    get offsetY() {
        return this._getOption('offsetY');
    }
    set offsetY(value) {
        this._setOption('offsetY', value);
    }
    get opacity() {
        return this._getOption('opacity');
    }
    set opacity(value) {
        this._setOption('opacity', value);
    }
    get _optionPath() {
        return 'shadow';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartShadowComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoChartShadowComponent, isStandalone: true, selector: "dxo-chart-shadow", inputs: { blur: "blur", color: "color", offsetX: "offsetX", offsetY: "offsetY", opacity: "opacity" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartShadowComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-chart-shadow', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { blur: [{
                type: Input
            }], color: [{
                type: Input
            }], offsetX: [{
                type: Input
            }], offsetY: [{
                type: Input
            }], opacity: [{
                type: Input
            }] } });
class DxoChartShadowModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartShadowModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoChartShadowModule, imports: [DxoChartShadowComponent], exports: [DxoChartShadowComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartShadowModule, imports: [DxoChartShadowComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartShadowModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoChartShadowComponent
                    ],
                    exports: [
                        DxoChartShadowComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoChartSizeComponent extends NestedOption {
    get height() {
        return this._getOption('height');
    }
    set height(value) {
        this._setOption('height', value);
    }
    get width() {
        return this._getOption('width');
    }
    set width(value) {
        this._setOption('width', value);
    }
    get _optionPath() {
        return 'size';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartSizeComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoChartSizeComponent, isStandalone: true, selector: "dxo-chart-size", inputs: { height: "height", width: "width" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartSizeComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-chart-size', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { height: [{
                type: Input
            }], width: [{
                type: Input
            }] } });
class DxoChartSizeModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartSizeModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoChartSizeModule, imports: [DxoChartSizeComponent], exports: [DxoChartSizeComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartSizeModule, imports: [DxoChartSizeComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartSizeModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoChartSizeComponent
                    ],
                    exports: [
                        DxoChartSizeComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxiChartStripComponent extends CollectionNestedOption {
    get color() {
        return this._getOption('color');
    }
    set color(value) {
        this._setOption('color', value);
    }
    get endValue() {
        return this._getOption('endValue');
    }
    set endValue(value) {
        this._setOption('endValue', value);
    }
    get label() {
        return this._getOption('label');
    }
    set label(value) {
        this._setOption('label', value);
    }
    get paddingLeftRight() {
        return this._getOption('paddingLeftRight');
    }
    set paddingLeftRight(value) {
        this._setOption('paddingLeftRight', value);
    }
    get paddingTopBottom() {
        return this._getOption('paddingTopBottom');
    }
    set paddingTopBottom(value) {
        this._setOption('paddingTopBottom', value);
    }
    get startValue() {
        return this._getOption('startValue');
    }
    set startValue(value) {
        this._setOption('startValue', value);
    }
    get _optionPath() {
        return 'strips';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnDestroy() {
        this._deleteRemovedOptions(this._fullOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiChartStripComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxiChartStripComponent, isStandalone: true, selector: "dxi-chart-strip", inputs: { color: "color", endValue: "endValue", label: "label", paddingLeftRight: "paddingLeftRight", paddingTopBottom: "paddingTopBottom", startValue: "startValue" }, providers: [
            NestedOptionHost,
            {
                provide: PROPERTY_TOKEN_strips,
                useExisting: DxiChartStripComponent,
            }
        ], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiChartStripComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxi-chart-strip', template: '', imports: [DxIntegrationModule], providers: [
                        NestedOptionHost,
                        {
                            provide: PROPERTY_TOKEN_strips,
                            useExisting: DxiChartStripComponent,
                        }
                    ] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { color: [{
                type: Input
            }], endValue: [{
                type: Input
            }], label: [{
                type: Input
            }], paddingLeftRight: [{
                type: Input
            }], paddingTopBottom: [{
                type: Input
            }], startValue: [{
                type: Input
            }] } });
class DxiChartStripModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiChartStripModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxiChartStripModule, imports: [DxiChartStripComponent], exports: [DxiChartStripComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiChartStripModule, imports: [DxiChartStripComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiChartStripModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxiChartStripComponent
                    ],
                    exports: [
                        DxiChartStripComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoChartStripLabelComponent extends NestedOption {
    get font() {
        return this._getOption('font');
    }
    set font(value) {
        this._setOption('font', value);
    }
    get horizontalAlignment() {
        return this._getOption('horizontalAlignment');
    }
    set horizontalAlignment(value) {
        this._setOption('horizontalAlignment', value);
    }
    get text() {
        return this._getOption('text');
    }
    set text(value) {
        this._setOption('text', value);
    }
    get verticalAlignment() {
        return this._getOption('verticalAlignment');
    }
    set verticalAlignment(value) {
        this._setOption('verticalAlignment', value);
    }
    get _optionPath() {
        return 'label';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartStripLabelComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoChartStripLabelComponent, isStandalone: true, selector: "dxo-chart-strip-label", inputs: { font: "font", horizontalAlignment: "horizontalAlignment", text: "text", verticalAlignment: "verticalAlignment" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartStripLabelComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-chart-strip-label', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { font: [{
                type: Input
            }], horizontalAlignment: [{
                type: Input
            }], text: [{
                type: Input
            }], verticalAlignment: [{
                type: Input
            }] } });
class DxoChartStripLabelModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartStripLabelModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoChartStripLabelModule, imports: [DxoChartStripLabelComponent], exports: [DxoChartStripLabelComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartStripLabelModule, imports: [DxoChartStripLabelComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartStripLabelModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoChartStripLabelComponent
                    ],
                    exports: [
                        DxoChartStripLabelComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoChartStripStyleLabelComponent extends NestedOption {
    get font() {
        return this._getOption('font');
    }
    set font(value) {
        this._setOption('font', value);
    }
    get horizontalAlignment() {
        return this._getOption('horizontalAlignment');
    }
    set horizontalAlignment(value) {
        this._setOption('horizontalAlignment', value);
    }
    get verticalAlignment() {
        return this._getOption('verticalAlignment');
    }
    set verticalAlignment(value) {
        this._setOption('verticalAlignment', value);
    }
    get _optionPath() {
        return 'label';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartStripStyleLabelComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoChartStripStyleLabelComponent, isStandalone: true, selector: "dxo-chart-strip-style-label", inputs: { font: "font", horizontalAlignment: "horizontalAlignment", verticalAlignment: "verticalAlignment" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartStripStyleLabelComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-chart-strip-style-label', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { font: [{
                type: Input
            }], horizontalAlignment: [{
                type: Input
            }], verticalAlignment: [{
                type: Input
            }] } });
class DxoChartStripStyleLabelModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartStripStyleLabelModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoChartStripStyleLabelModule, imports: [DxoChartStripStyleLabelComponent], exports: [DxoChartStripStyleLabelComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartStripStyleLabelModule, imports: [DxoChartStripStyleLabelComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartStripStyleLabelModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoChartStripStyleLabelComponent
                    ],
                    exports: [
                        DxoChartStripStyleLabelComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoChartStripStyleComponent extends NestedOption {
    get label() {
        return this._getOption('label');
    }
    set label(value) {
        this._setOption('label', value);
    }
    get paddingLeftRight() {
        return this._getOption('paddingLeftRight');
    }
    set paddingLeftRight(value) {
        this._setOption('paddingLeftRight', value);
    }
    get paddingTopBottom() {
        return this._getOption('paddingTopBottom');
    }
    set paddingTopBottom(value) {
        this._setOption('paddingTopBottom', value);
    }
    get _optionPath() {
        return 'stripStyle';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartStripStyleComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoChartStripStyleComponent, isStandalone: true, selector: "dxo-chart-strip-style", inputs: { label: "label", paddingLeftRight: "paddingLeftRight", paddingTopBottom: "paddingTopBottom" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartStripStyleComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-chart-strip-style', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { label: [{
                type: Input
            }], paddingLeftRight: [{
                type: Input
            }], paddingTopBottom: [{
                type: Input
            }] } });
class DxoChartStripStyleModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartStripStyleModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoChartStripStyleModule, imports: [DxoChartStripStyleComponent], exports: [DxoChartStripStyleComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartStripStyleModule, imports: [DxoChartStripStyleComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartStripStyleModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoChartStripStyleComponent
                    ],
                    exports: [
                        DxoChartStripStyleComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoChartSubtitleComponent extends NestedOption {
    get font() {
        return this._getOption('font');
    }
    set font(value) {
        this._setOption('font', value);
    }
    get offset() {
        return this._getOption('offset');
    }
    set offset(value) {
        this._setOption('offset', value);
    }
    get text() {
        return this._getOption('text');
    }
    set text(value) {
        this._setOption('text', value);
    }
    get textOverflow() {
        return this._getOption('textOverflow');
    }
    set textOverflow(value) {
        this._setOption('textOverflow', value);
    }
    get wordWrap() {
        return this._getOption('wordWrap');
    }
    set wordWrap(value) {
        this._setOption('wordWrap', value);
    }
    get _optionPath() {
        return 'subtitle';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartSubtitleComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoChartSubtitleComponent, isStandalone: true, selector: "dxo-chart-subtitle", inputs: { font: "font", offset: "offset", text: "text", textOverflow: "textOverflow", wordWrap: "wordWrap" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartSubtitleComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-chart-subtitle', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { font: [{
                type: Input
            }], offset: [{
                type: Input
            }], text: [{
                type: Input
            }], textOverflow: [{
                type: Input
            }], wordWrap: [{
                type: Input
            }] } });
class DxoChartSubtitleModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartSubtitleModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoChartSubtitleModule, imports: [DxoChartSubtitleComponent], exports: [DxoChartSubtitleComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartSubtitleModule, imports: [DxoChartSubtitleComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartSubtitleModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoChartSubtitleComponent
                    ],
                    exports: [
                        DxoChartSubtitleComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoChartTickIntervalComponent extends NestedOption {
    get days() {
        return this._getOption('days');
    }
    set days(value) {
        this._setOption('days', value);
    }
    get hours() {
        return this._getOption('hours');
    }
    set hours(value) {
        this._setOption('hours', value);
    }
    get milliseconds() {
        return this._getOption('milliseconds');
    }
    set milliseconds(value) {
        this._setOption('milliseconds', value);
    }
    get minutes() {
        return this._getOption('minutes');
    }
    set minutes(value) {
        this._setOption('minutes', value);
    }
    get months() {
        return this._getOption('months');
    }
    set months(value) {
        this._setOption('months', value);
    }
    get quarters() {
        return this._getOption('quarters');
    }
    set quarters(value) {
        this._setOption('quarters', value);
    }
    get seconds() {
        return this._getOption('seconds');
    }
    set seconds(value) {
        this._setOption('seconds', value);
    }
    get weeks() {
        return this._getOption('weeks');
    }
    set weeks(value) {
        this._setOption('weeks', value);
    }
    get years() {
        return this._getOption('years');
    }
    set years(value) {
        this._setOption('years', value);
    }
    get _optionPath() {
        return 'tickInterval';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartTickIntervalComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoChartTickIntervalComponent, isStandalone: true, selector: "dxo-chart-tick-interval", inputs: { days: "days", hours: "hours", milliseconds: "milliseconds", minutes: "minutes", months: "months", quarters: "quarters", seconds: "seconds", weeks: "weeks", years: "years" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartTickIntervalComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-chart-tick-interval', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { days: [{
                type: Input
            }], hours: [{
                type: Input
            }], milliseconds: [{
                type: Input
            }], minutes: [{
                type: Input
            }], months: [{
                type: Input
            }], quarters: [{
                type: Input
            }], seconds: [{
                type: Input
            }], weeks: [{
                type: Input
            }], years: [{
                type: Input
            }] } });
class DxoChartTickIntervalModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartTickIntervalModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoChartTickIntervalModule, imports: [DxoChartTickIntervalComponent], exports: [DxoChartTickIntervalComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartTickIntervalModule, imports: [DxoChartTickIntervalComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartTickIntervalModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoChartTickIntervalComponent
                    ],
                    exports: [
                        DxoChartTickIntervalComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoChartTickComponent extends NestedOption {
    get color() {
        return this._getOption('color');
    }
    set color(value) {
        this._setOption('color', value);
    }
    get length() {
        return this._getOption('length');
    }
    set length(value) {
        this._setOption('length', value);
    }
    get opacity() {
        return this._getOption('opacity');
    }
    set opacity(value) {
        this._setOption('opacity', value);
    }
    get shift() {
        return this._getOption('shift');
    }
    set shift(value) {
        this._setOption('shift', value);
    }
    get visible() {
        return this._getOption('visible');
    }
    set visible(value) {
        this._setOption('visible', value);
    }
    get width() {
        return this._getOption('width');
    }
    set width(value) {
        this._setOption('width', value);
    }
    get _optionPath() {
        return 'tick';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartTickComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoChartTickComponent, isStandalone: true, selector: "dxo-chart-tick", inputs: { color: "color", length: "length", opacity: "opacity", shift: "shift", visible: "visible", width: "width" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartTickComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-chart-tick', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { color: [{
                type: Input
            }], length: [{
                type: Input
            }], opacity: [{
                type: Input
            }], shift: [{
                type: Input
            }], visible: [{
                type: Input
            }], width: [{
                type: Input
            }] } });
class DxoChartTickModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartTickModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoChartTickModule, imports: [DxoChartTickComponent], exports: [DxoChartTickComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartTickModule, imports: [DxoChartTickComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartTickModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoChartTickComponent
                    ],
                    exports: [
                        DxoChartTickComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoChartTitleComponent extends NestedOption {
    get alignment() {
        return this._getOption('alignment');
    }
    set alignment(value) {
        this._setOption('alignment', value);
    }
    get font() {
        return this._getOption('font');
    }
    set font(value) {
        this._setOption('font', value);
    }
    get margin() {
        return this._getOption('margin');
    }
    set margin(value) {
        this._setOption('margin', value);
    }
    get text() {
        return this._getOption('text');
    }
    set text(value) {
        this._setOption('text', value);
    }
    get textOverflow() {
        return this._getOption('textOverflow');
    }
    set textOverflow(value) {
        this._setOption('textOverflow', value);
    }
    get wordWrap() {
        return this._getOption('wordWrap');
    }
    set wordWrap(value) {
        this._setOption('wordWrap', value);
    }
    get horizontalAlignment() {
        return this._getOption('horizontalAlignment');
    }
    set horizontalAlignment(value) {
        this._setOption('horizontalAlignment', value);
    }
    get placeholderSize() {
        return this._getOption('placeholderSize');
    }
    set placeholderSize(value) {
        this._setOption('placeholderSize', value);
    }
    get subtitle() {
        return this._getOption('subtitle');
    }
    set subtitle(value) {
        this._setOption('subtitle', value);
    }
    get verticalAlignment() {
        return this._getOption('verticalAlignment');
    }
    set verticalAlignment(value) {
        this._setOption('verticalAlignment', value);
    }
    get _optionPath() {
        return 'title';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartTitleComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoChartTitleComponent, isStandalone: true, selector: "dxo-chart-title", inputs: { alignment: "alignment", font: "font", margin: "margin", text: "text", textOverflow: "textOverflow", wordWrap: "wordWrap", horizontalAlignment: "horizontalAlignment", placeholderSize: "placeholderSize", subtitle: "subtitle", verticalAlignment: "verticalAlignment" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartTitleComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-chart-title', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { alignment: [{
                type: Input
            }], font: [{
                type: Input
            }], margin: [{
                type: Input
            }], text: [{
                type: Input
            }], textOverflow: [{
                type: Input
            }], wordWrap: [{
                type: Input
            }], horizontalAlignment: [{
                type: Input
            }], placeholderSize: [{
                type: Input
            }], subtitle: [{
                type: Input
            }], verticalAlignment: [{
                type: Input
            }] } });
class DxoChartTitleModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartTitleModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoChartTitleModule, imports: [DxoChartTitleComponent], exports: [DxoChartTitleComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartTitleModule, imports: [DxoChartTitleComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartTitleModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoChartTitleComponent
                    ],
                    exports: [
                        DxoChartTitleComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoChartTooltipBorderComponent extends NestedOption {
    get color() {
        return this._getOption('color');
    }
    set color(value) {
        this._setOption('color', value);
    }
    get dashStyle() {
        return this._getOption('dashStyle');
    }
    set dashStyle(value) {
        this._setOption('dashStyle', value);
    }
    get opacity() {
        return this._getOption('opacity');
    }
    set opacity(value) {
        this._setOption('opacity', value);
    }
    get visible() {
        return this._getOption('visible');
    }
    set visible(value) {
        this._setOption('visible', value);
    }
    get width() {
        return this._getOption('width');
    }
    set width(value) {
        this._setOption('width', value);
    }
    get _optionPath() {
        return 'border';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartTooltipBorderComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoChartTooltipBorderComponent, isStandalone: true, selector: "dxo-chart-tooltip-border", inputs: { color: "color", dashStyle: "dashStyle", opacity: "opacity", visible: "visible", width: "width" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartTooltipBorderComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-chart-tooltip-border', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { color: [{
                type: Input
            }], dashStyle: [{
                type: Input
            }], opacity: [{
                type: Input
            }], visible: [{
                type: Input
            }], width: [{
                type: Input
            }] } });
class DxoChartTooltipBorderModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartTooltipBorderModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoChartTooltipBorderModule, imports: [DxoChartTooltipBorderComponent], exports: [DxoChartTooltipBorderComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartTooltipBorderModule, imports: [DxoChartTooltipBorderComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartTooltipBorderModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoChartTooltipBorderComponent
                    ],
                    exports: [
                        DxoChartTooltipBorderComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoChartTooltipComponent extends NestedOption {
    get argumentFormat() {
        return this._getOption('argumentFormat');
    }
    set argumentFormat(value) {
        this._setOption('argumentFormat', value);
    }
    get arrowLength() {
        return this._getOption('arrowLength');
    }
    set arrowLength(value) {
        this._setOption('arrowLength', value);
    }
    get border() {
        return this._getOption('border');
    }
    set border(value) {
        this._setOption('border', value);
    }
    get color() {
        return this._getOption('color');
    }
    set color(value) {
        this._setOption('color', value);
    }
    get container() {
        return this._getOption('container');
    }
    set container(value) {
        this._setOption('container', value);
    }
    get contentTemplate() {
        return this._getOption('contentTemplate');
    }
    set contentTemplate(value) {
        this._setOption('contentTemplate', value);
    }
    get cornerRadius() {
        return this._getOption('cornerRadius');
    }
    set cornerRadius(value) {
        this._setOption('cornerRadius', value);
    }
    get customizeTooltip() {
        return this._getOption('customizeTooltip');
    }
    set customizeTooltip(value) {
        this._setOption('customizeTooltip', value);
    }
    get enabled() {
        return this._getOption('enabled');
    }
    set enabled(value) {
        this._setOption('enabled', value);
    }
    get font() {
        return this._getOption('font');
    }
    set font(value) {
        this._setOption('font', value);
    }
    get format() {
        return this._getOption('format');
    }
    set format(value) {
        this._setOption('format', value);
    }
    get interactive() {
        return this._getOption('interactive');
    }
    set interactive(value) {
        this._setOption('interactive', value);
    }
    get location() {
        return this._getOption('location');
    }
    set location(value) {
        this._setOption('location', value);
    }
    get opacity() {
        return this._getOption('opacity');
    }
    set opacity(value) {
        this._setOption('opacity', value);
    }
    get paddingLeftRight() {
        return this._getOption('paddingLeftRight');
    }
    set paddingLeftRight(value) {
        this._setOption('paddingLeftRight', value);
    }
    get paddingTopBottom() {
        return this._getOption('paddingTopBottom');
    }
    set paddingTopBottom(value) {
        this._setOption('paddingTopBottom', value);
    }
    get shadow() {
        return this._getOption('shadow');
    }
    set shadow(value) {
        this._setOption('shadow', value);
    }
    get shared() {
        return this._getOption('shared');
    }
    set shared(value) {
        this._setOption('shared', value);
    }
    get zIndex() {
        return this._getOption('zIndex');
    }
    set zIndex(value) {
        this._setOption('zIndex', value);
    }
    get _optionPath() {
        return 'tooltip';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartTooltipComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoChartTooltipComponent, isStandalone: true, selector: "dxo-chart-tooltip", inputs: { argumentFormat: "argumentFormat", arrowLength: "arrowLength", border: "border", color: "color", container: "container", contentTemplate: "contentTemplate", cornerRadius: "cornerRadius", customizeTooltip: "customizeTooltip", enabled: "enabled", font: "font", format: "format", interactive: "interactive", location: "location", opacity: "opacity", paddingLeftRight: "paddingLeftRight", paddingTopBottom: "paddingTopBottom", shadow: "shadow", shared: "shared", zIndex: "zIndex" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartTooltipComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-chart-tooltip', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { argumentFormat: [{
                type: Input
            }], arrowLength: [{
                type: Input
            }], border: [{
                type: Input
            }], color: [{
                type: Input
            }], container: [{
                type: Input
            }], contentTemplate: [{
                type: Input
            }], cornerRadius: [{
                type: Input
            }], customizeTooltip: [{
                type: Input
            }], enabled: [{
                type: Input
            }], font: [{
                type: Input
            }], format: [{
                type: Input
            }], interactive: [{
                type: Input
            }], location: [{
                type: Input
            }], opacity: [{
                type: Input
            }], paddingLeftRight: [{
                type: Input
            }], paddingTopBottom: [{
                type: Input
            }], shadow: [{
                type: Input
            }], shared: [{
                type: Input
            }], zIndex: [{
                type: Input
            }] } });
class DxoChartTooltipModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartTooltipModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoChartTooltipModule, imports: [DxoChartTooltipComponent], exports: [DxoChartTooltipComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartTooltipModule, imports: [DxoChartTooltipComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartTooltipModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoChartTooltipComponent
                    ],
                    exports: [
                        DxoChartTooltipComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoChartUrlComponent extends NestedOption {
    get rangeMaxPoint() {
        return this._getOption('rangeMaxPoint');
    }
    set rangeMaxPoint(value) {
        this._setOption('rangeMaxPoint', value);
    }
    get rangeMinPoint() {
        return this._getOption('rangeMinPoint');
    }
    set rangeMinPoint(value) {
        this._setOption('rangeMinPoint', value);
    }
    get _optionPath() {
        return 'url';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartUrlComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoChartUrlComponent, isStandalone: true, selector: "dxo-chart-url", inputs: { rangeMaxPoint: "rangeMaxPoint", rangeMinPoint: "rangeMinPoint" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartUrlComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-chart-url', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { rangeMaxPoint: [{
                type: Input
            }], rangeMinPoint: [{
                type: Input
            }] } });
class DxoChartUrlModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartUrlModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoChartUrlModule, imports: [DxoChartUrlComponent], exports: [DxoChartUrlComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartUrlModule, imports: [DxoChartUrlComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartUrlModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoChartUrlComponent
                    ],
                    exports: [
                        DxoChartUrlComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxiChartValueAxisComponent extends CollectionNestedOption {
    set _breaksContentChildren(value) {
        this.setChildren('breaks', value);
    }
    set _constantLinesContentChildren(value) {
        this.setChildren('constantLines', value);
    }
    set _stripsContentChildren(value) {
        this.setChildren('strips', value);
    }
    get aggregatedPointsPosition() {
        return this._getOption('aggregatedPointsPosition');
    }
    set aggregatedPointsPosition(value) {
        this._setOption('aggregatedPointsPosition', value);
    }
    get allowDecimals() {
        return this._getOption('allowDecimals');
    }
    set allowDecimals(value) {
        this._setOption('allowDecimals', value);
    }
    get autoBreaksEnabled() {
        return this._getOption('autoBreaksEnabled');
    }
    set autoBreaksEnabled(value) {
        this._setOption('autoBreaksEnabled', value);
    }
    get axisDivisionFactor() {
        return this._getOption('axisDivisionFactor');
    }
    set axisDivisionFactor(value) {
        this._setOption('axisDivisionFactor', value);
    }
    get breaks() {
        return this._getOption('breaks');
    }
    set breaks(value) {
        this._setOption('breaks', value);
    }
    get breakStyle() {
        return this._getOption('breakStyle');
    }
    set breakStyle(value) {
        this._setOption('breakStyle', value);
    }
    get categories() {
        return this._getOption('categories');
    }
    set categories(value) {
        this._setOption('categories', value);
    }
    get color() {
        return this._getOption('color');
    }
    set color(value) {
        this._setOption('color', value);
    }
    get constantLines() {
        return this._getOption('constantLines');
    }
    set constantLines(value) {
        this._setOption('constantLines', value);
    }
    get constantLineStyle() {
        return this._getOption('constantLineStyle');
    }
    set constantLineStyle(value) {
        this._setOption('constantLineStyle', value);
    }
    get customPosition() {
        return this._getOption('customPosition');
    }
    set customPosition(value) {
        this._setOption('customPosition', value);
    }
    get discreteAxisDivisionMode() {
        return this._getOption('discreteAxisDivisionMode');
    }
    set discreteAxisDivisionMode(value) {
        this._setOption('discreteAxisDivisionMode', value);
    }
    get endOnTick() {
        return this._getOption('endOnTick');
    }
    set endOnTick(value) {
        this._setOption('endOnTick', value);
    }
    get grid() {
        return this._getOption('grid');
    }
    set grid(value) {
        this._setOption('grid', value);
    }
    get inverted() {
        return this._getOption('inverted');
    }
    set inverted(value) {
        this._setOption('inverted', value);
    }
    get label() {
        return this._getOption('label');
    }
    set label(value) {
        this._setOption('label', value);
    }
    get linearThreshold() {
        return this._getOption('linearThreshold');
    }
    set linearThreshold(value) {
        this._setOption('linearThreshold', value);
    }
    get logarithmBase() {
        return this._getOption('logarithmBase');
    }
    set logarithmBase(value) {
        this._setOption('logarithmBase', value);
    }
    get maxAutoBreakCount() {
        return this._getOption('maxAutoBreakCount');
    }
    set maxAutoBreakCount(value) {
        this._setOption('maxAutoBreakCount', value);
    }
    get maxValueMargin() {
        return this._getOption('maxValueMargin');
    }
    set maxValueMargin(value) {
        this._setOption('maxValueMargin', value);
    }
    get minorGrid() {
        return this._getOption('minorGrid');
    }
    set minorGrid(value) {
        this._setOption('minorGrid', value);
    }
    get minorTick() {
        return this._getOption('minorTick');
    }
    set minorTick(value) {
        this._setOption('minorTick', value);
    }
    get minorTickCount() {
        return this._getOption('minorTickCount');
    }
    set minorTickCount(value) {
        this._setOption('minorTickCount', value);
    }
    get minorTickInterval() {
        return this._getOption('minorTickInterval');
    }
    set minorTickInterval(value) {
        this._setOption('minorTickInterval', value);
    }
    get minValueMargin() {
        return this._getOption('minValueMargin');
    }
    set minValueMargin(value) {
        this._setOption('minValueMargin', value);
    }
    get minVisualRangeLength() {
        return this._getOption('minVisualRangeLength');
    }
    set minVisualRangeLength(value) {
        this._setOption('minVisualRangeLength', value);
    }
    get multipleAxesSpacing() {
        return this._getOption('multipleAxesSpacing');
    }
    set multipleAxesSpacing(value) {
        this._setOption('multipleAxesSpacing', value);
    }
    get name() {
        return this._getOption('name');
    }
    set name(value) {
        this._setOption('name', value);
    }
    get offset() {
        return this._getOption('offset');
    }
    set offset(value) {
        this._setOption('offset', value);
    }
    get opacity() {
        return this._getOption('opacity');
    }
    set opacity(value) {
        this._setOption('opacity', value);
    }
    get pane() {
        return this._getOption('pane');
    }
    set pane(value) {
        this._setOption('pane', value);
    }
    get placeholderSize() {
        return this._getOption('placeholderSize');
    }
    set placeholderSize(value) {
        this._setOption('placeholderSize', value);
    }
    get position() {
        return this._getOption('position');
    }
    set position(value) {
        this._setOption('position', value);
    }
    get showZero() {
        return this._getOption('showZero');
    }
    set showZero(value) {
        this._setOption('showZero', value);
    }
    get strips() {
        return this._getOption('strips');
    }
    set strips(value) {
        this._setOption('strips', value);
    }
    get stripStyle() {
        return this._getOption('stripStyle');
    }
    set stripStyle(value) {
        this._setOption('stripStyle', value);
    }
    get synchronizedValue() {
        return this._getOption('synchronizedValue');
    }
    set synchronizedValue(value) {
        this._setOption('synchronizedValue', value);
    }
    get tick() {
        return this._getOption('tick');
    }
    set tick(value) {
        this._setOption('tick', value);
    }
    get tickInterval() {
        return this._getOption('tickInterval');
    }
    set tickInterval(value) {
        this._setOption('tickInterval', value);
    }
    get title() {
        return this._getOption('title');
    }
    set title(value) {
        this._setOption('title', value);
    }
    get type() {
        return this._getOption('type');
    }
    set type(value) {
        this._setOption('type', value);
    }
    get valueMarginsEnabled() {
        return this._getOption('valueMarginsEnabled');
    }
    set valueMarginsEnabled(value) {
        this._setOption('valueMarginsEnabled', value);
    }
    get valueType() {
        return this._getOption('valueType');
    }
    set valueType(value) {
        this._setOption('valueType', value);
    }
    get visible() {
        return this._getOption('visible');
    }
    set visible(value) {
        this._setOption('visible', value);
    }
    get visualRange() {
        return this._getOption('visualRange');
    }
    set visualRange(value) {
        this._setOption('visualRange', value);
    }
    get visualRangeUpdateMode() {
        return this._getOption('visualRangeUpdateMode');
    }
    set visualRangeUpdateMode(value) {
        this._setOption('visualRangeUpdateMode', value);
    }
    get wholeRange() {
        return this._getOption('wholeRange');
    }
    set wholeRange(value) {
        this._setOption('wholeRange', value);
    }
    get width() {
        return this._getOption('width');
    }
    set width(value) {
        this._setOption('width', value);
    }
    get _optionPath() {
        return 'valueAxis';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        this._createEventEmitters([
            { emit: 'categoriesChange' },
            { emit: 'visualRangeChange' }
        ]);
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnDestroy() {
        this._deleteRemovedOptions(this._fullOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiChartValueAxisComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxiChartValueAxisComponent, isStandalone: true, selector: "dxi-chart-value-axis", inputs: { aggregatedPointsPosition: "aggregatedPointsPosition", allowDecimals: "allowDecimals", autoBreaksEnabled: "autoBreaksEnabled", axisDivisionFactor: "axisDivisionFactor", breaks: "breaks", breakStyle: "breakStyle", categories: "categories", color: "color", constantLines: "constantLines", constantLineStyle: "constantLineStyle", customPosition: "customPosition", discreteAxisDivisionMode: "discreteAxisDivisionMode", endOnTick: "endOnTick", grid: "grid", inverted: "inverted", label: "label", linearThreshold: "linearThreshold", logarithmBase: "logarithmBase", maxAutoBreakCount: "maxAutoBreakCount", maxValueMargin: "maxValueMargin", minorGrid: "minorGrid", minorTick: "minorTick", minorTickCount: "minorTickCount", minorTickInterval: "minorTickInterval", minValueMargin: "minValueMargin", minVisualRangeLength: "minVisualRangeLength", multipleAxesSpacing: "multipleAxesSpacing", name: "name", offset: "offset", opacity: "opacity", pane: "pane", placeholderSize: "placeholderSize", position: "position", showZero: "showZero", strips: "strips", stripStyle: "stripStyle", synchronizedValue: "synchronizedValue", tick: "tick", tickInterval: "tickInterval", title: "title", type: "type", valueMarginsEnabled: "valueMarginsEnabled", valueType: "valueType", visible: "visible", visualRange: "visualRange", visualRangeUpdateMode: "visualRangeUpdateMode", wholeRange: "wholeRange", width: "width" }, outputs: { categoriesChange: "categoriesChange", visualRangeChange: "visualRangeChange" }, providers: [
            NestedOptionHost,
            {
                provide: PROPERTY_TOKEN_valueAxis,
                useExisting: DxiChartValueAxisComponent,
            }
        ], queries: [{ propertyName: "_breaksContentChildren", predicate: PROPERTY_TOKEN_breaks }, { propertyName: "_constantLinesContentChildren", predicate: PROPERTY_TOKEN_constantLines }, { propertyName: "_stripsContentChildren", predicate: PROPERTY_TOKEN_strips }], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiChartValueAxisComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxi-chart-value-axis', template: '', imports: [DxIntegrationModule], providers: [
                        NestedOptionHost,
                        {
                            provide: PROPERTY_TOKEN_valueAxis,
                            useExisting: DxiChartValueAxisComponent,
                        }
                    ] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { _breaksContentChildren: [{
                type: ContentChildren,
                args: [PROPERTY_TOKEN_breaks]
            }], _constantLinesContentChildren: [{
                type: ContentChildren,
                args: [PROPERTY_TOKEN_constantLines]
            }], _stripsContentChildren: [{
                type: ContentChildren,
                args: [PROPERTY_TOKEN_strips]
            }], aggregatedPointsPosition: [{
                type: Input
            }], allowDecimals: [{
                type: Input
            }], autoBreaksEnabled: [{
                type: Input
            }], axisDivisionFactor: [{
                type: Input
            }], breaks: [{
                type: Input
            }], breakStyle: [{
                type: Input
            }], categories: [{
                type: Input
            }], color: [{
                type: Input
            }], constantLines: [{
                type: Input
            }], constantLineStyle: [{
                type: Input
            }], customPosition: [{
                type: Input
            }], discreteAxisDivisionMode: [{
                type: Input
            }], endOnTick: [{
                type: Input
            }], grid: [{
                type: Input
            }], inverted: [{
                type: Input
            }], label: [{
                type: Input
            }], linearThreshold: [{
                type: Input
            }], logarithmBase: [{
                type: Input
            }], maxAutoBreakCount: [{
                type: Input
            }], maxValueMargin: [{
                type: Input
            }], minorGrid: [{
                type: Input
            }], minorTick: [{
                type: Input
            }], minorTickCount: [{
                type: Input
            }], minorTickInterval: [{
                type: Input
            }], minValueMargin: [{
                type: Input
            }], minVisualRangeLength: [{
                type: Input
            }], multipleAxesSpacing: [{
                type: Input
            }], name: [{
                type: Input
            }], offset: [{
                type: Input
            }], opacity: [{
                type: Input
            }], pane: [{
                type: Input
            }], placeholderSize: [{
                type: Input
            }], position: [{
                type: Input
            }], showZero: [{
                type: Input
            }], strips: [{
                type: Input
            }], stripStyle: [{
                type: Input
            }], synchronizedValue: [{
                type: Input
            }], tick: [{
                type: Input
            }], tickInterval: [{
                type: Input
            }], title: [{
                type: Input
            }], type: [{
                type: Input
            }], valueMarginsEnabled: [{
                type: Input
            }], valueType: [{
                type: Input
            }], visible: [{
                type: Input
            }], visualRange: [{
                type: Input
            }], visualRangeUpdateMode: [{
                type: Input
            }], wholeRange: [{
                type: Input
            }], width: [{
                type: Input
            }], categoriesChange: [{
                type: Output
            }], visualRangeChange: [{
                type: Output
            }] } });
class DxiChartValueAxisModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiChartValueAxisModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxiChartValueAxisModule, imports: [DxiChartValueAxisComponent], exports: [DxiChartValueAxisComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiChartValueAxisModule, imports: [DxiChartValueAxisComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxiChartValueAxisModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxiChartValueAxisComponent
                    ],
                    exports: [
                        DxiChartValueAxisComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoChartValueErrorBarComponent extends NestedOption {
    get color() {
        return this._getOption('color');
    }
    set color(value) {
        this._setOption('color', value);
    }
    get displayMode() {
        return this._getOption('displayMode');
    }
    set displayMode(value) {
        this._setOption('displayMode', value);
    }
    get edgeLength() {
        return this._getOption('edgeLength');
    }
    set edgeLength(value) {
        this._setOption('edgeLength', value);
    }
    get highValueField() {
        return this._getOption('highValueField');
    }
    set highValueField(value) {
        this._setOption('highValueField', value);
    }
    get lineWidth() {
        return this._getOption('lineWidth');
    }
    set lineWidth(value) {
        this._setOption('lineWidth', value);
    }
    get lowValueField() {
        return this._getOption('lowValueField');
    }
    set lowValueField(value) {
        this._setOption('lowValueField', value);
    }
    get opacity() {
        return this._getOption('opacity');
    }
    set opacity(value) {
        this._setOption('opacity', value);
    }
    get type() {
        return this._getOption('type');
    }
    set type(value) {
        this._setOption('type', value);
    }
    get value() {
        return this._getOption('value');
    }
    set value(value) {
        this._setOption('value', value);
    }
    get _optionPath() {
        return 'valueErrorBar';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartValueErrorBarComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoChartValueErrorBarComponent, isStandalone: true, selector: "dxo-chart-value-error-bar", inputs: { color: "color", displayMode: "displayMode", edgeLength: "edgeLength", highValueField: "highValueField", lineWidth: "lineWidth", lowValueField: "lowValueField", opacity: "opacity", type: "type", value: "value" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartValueErrorBarComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-chart-value-error-bar', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { color: [{
                type: Input
            }], displayMode: [{
                type: Input
            }], edgeLength: [{
                type: Input
            }], highValueField: [{
                type: Input
            }], lineWidth: [{
                type: Input
            }], lowValueField: [{
                type: Input
            }], opacity: [{
                type: Input
            }], type: [{
                type: Input
            }], value: [{
                type: Input
            }] } });
class DxoChartValueErrorBarModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartValueErrorBarModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoChartValueErrorBarModule, imports: [DxoChartValueErrorBarComponent], exports: [DxoChartValueErrorBarComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartValueErrorBarModule, imports: [DxoChartValueErrorBarComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartValueErrorBarModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoChartValueErrorBarComponent
                    ],
                    exports: [
                        DxoChartValueErrorBarComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoChartVerticalLineComponent extends NestedOption {
    get color() {
        return this._getOption('color');
    }
    set color(value) {
        this._setOption('color', value);
    }
    get dashStyle() {
        return this._getOption('dashStyle');
    }
    set dashStyle(value) {
        this._setOption('dashStyle', value);
    }
    get label() {
        return this._getOption('label');
    }
    set label(value) {
        this._setOption('label', value);
    }
    get opacity() {
        return this._getOption('opacity');
    }
    set opacity(value) {
        this._setOption('opacity', value);
    }
    get visible() {
        return this._getOption('visible');
    }
    set visible(value) {
        this._setOption('visible', value);
    }
    get width() {
        return this._getOption('width');
    }
    set width(value) {
        this._setOption('width', value);
    }
    get _optionPath() {
        return 'verticalLine';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartVerticalLineComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoChartVerticalLineComponent, isStandalone: true, selector: "dxo-chart-vertical-line", inputs: { color: "color", dashStyle: "dashStyle", label: "label", opacity: "opacity", visible: "visible", width: "width" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartVerticalLineComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-chart-vertical-line', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { color: [{
                type: Input
            }], dashStyle: [{
                type: Input
            }], label: [{
                type: Input
            }], opacity: [{
                type: Input
            }], visible: [{
                type: Input
            }], width: [{
                type: Input
            }] } });
class DxoChartVerticalLineModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartVerticalLineModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoChartVerticalLineModule, imports: [DxoChartVerticalLineComponent], exports: [DxoChartVerticalLineComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartVerticalLineModule, imports: [DxoChartVerticalLineComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartVerticalLineModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoChartVerticalLineComponent
                    ],
                    exports: [
                        DxoChartVerticalLineComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoChartVisualRangeComponent extends NestedOption {
    get endValue() {
        return this._getOption('endValue');
    }
    set endValue(value) {
        this._setOption('endValue', value);
    }
    get length() {
        return this._getOption('length');
    }
    set length(value) {
        this._setOption('length', value);
    }
    get startValue() {
        return this._getOption('startValue');
    }
    set startValue(value) {
        this._setOption('startValue', value);
    }
    get _optionPath() {
        return 'visualRange';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        this._createEventEmitters([
            { emit: 'endValueChange' },
            { emit: 'startValueChange' }
        ]);
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartVisualRangeComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoChartVisualRangeComponent, isStandalone: true, selector: "dxo-chart-visual-range", inputs: { endValue: "endValue", length: "length", startValue: "startValue" }, outputs: { endValueChange: "endValueChange", startValueChange: "startValueChange" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartVisualRangeComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-chart-visual-range', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { endValue: [{
                type: Input
            }], length: [{
                type: Input
            }], startValue: [{
                type: Input
            }], endValueChange: [{
                type: Output
            }], startValueChange: [{
                type: Output
            }] } });
class DxoChartVisualRangeModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartVisualRangeModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoChartVisualRangeModule, imports: [DxoChartVisualRangeComponent], exports: [DxoChartVisualRangeComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartVisualRangeModule, imports: [DxoChartVisualRangeComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartVisualRangeModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoChartVisualRangeComponent
                    ],
                    exports: [
                        DxoChartVisualRangeComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoChartWholeRangeComponent extends NestedOption {
    get endValue() {
        return this._getOption('endValue');
    }
    set endValue(value) {
        this._setOption('endValue', value);
    }
    get length() {
        return this._getOption('length');
    }
    set length(value) {
        this._setOption('length', value);
    }
    get startValue() {
        return this._getOption('startValue');
    }
    set startValue(value) {
        this._setOption('startValue', value);
    }
    get _optionPath() {
        return 'wholeRange';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        this._createEventEmitters([
            { emit: 'endValueChange' },
            { emit: 'startValueChange' }
        ]);
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartWholeRangeComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoChartWholeRangeComponent, isStandalone: true, selector: "dxo-chart-whole-range", inputs: { endValue: "endValue", length: "length", startValue: "startValue" }, outputs: { endValueChange: "endValueChange", startValueChange: "startValueChange" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartWholeRangeComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-chart-whole-range', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { endValue: [{
                type: Input
            }], length: [{
                type: Input
            }], startValue: [{
                type: Input
            }], endValueChange: [{
                type: Output
            }], startValueChange: [{
                type: Output
            }] } });
class DxoChartWholeRangeModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartWholeRangeModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoChartWholeRangeModule, imports: [DxoChartWholeRangeComponent], exports: [DxoChartWholeRangeComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartWholeRangeModule, imports: [DxoChartWholeRangeComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartWholeRangeModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoChartWholeRangeComponent
                    ],
                    exports: [
                        DxoChartWholeRangeComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoChartWidthComponent extends NestedOption {
    get rangeMaxPoint() {
        return this._getOption('rangeMaxPoint');
    }
    set rangeMaxPoint(value) {
        this._setOption('rangeMaxPoint', value);
    }
    get rangeMinPoint() {
        return this._getOption('rangeMinPoint');
    }
    set rangeMinPoint(value) {
        this._setOption('rangeMinPoint', value);
    }
    get _optionPath() {
        return 'width';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartWidthComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoChartWidthComponent, isStandalone: true, selector: "dxo-chart-width", inputs: { rangeMaxPoint: "rangeMaxPoint", rangeMinPoint: "rangeMinPoint" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartWidthComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-chart-width', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { rangeMaxPoint: [{
                type: Input
            }], rangeMinPoint: [{
                type: Input
            }] } });
class DxoChartWidthModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartWidthModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoChartWidthModule, imports: [DxoChartWidthComponent], exports: [DxoChartWidthComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartWidthModule, imports: [DxoChartWidthComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartWidthModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoChartWidthComponent
                    ],
                    exports: [
                        DxoChartWidthComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
/* tslint:disable:max-line-length */
class DxoChartZoomAndPanComponent extends NestedOption {
    get allowMouseWheel() {
        return this._getOption('allowMouseWheel');
    }
    set allowMouseWheel(value) {
        this._setOption('allowMouseWheel', value);
    }
    get allowTouchGestures() {
        return this._getOption('allowTouchGestures');
    }
    set allowTouchGestures(value) {
        this._setOption('allowTouchGestures', value);
    }
    get argumentAxis() {
        return this._getOption('argumentAxis');
    }
    set argumentAxis(value) {
        this._setOption('argumentAxis', value);
    }
    get dragBoxStyle() {
        return this._getOption('dragBoxStyle');
    }
    set dragBoxStyle(value) {
        this._setOption('dragBoxStyle', value);
    }
    get dragToZoom() {
        return this._getOption('dragToZoom');
    }
    set dragToZoom(value) {
        this._setOption('dragToZoom', value);
    }
    get panKey() {
        return this._getOption('panKey');
    }
    set panKey(value) {
        this._setOption('panKey', value);
    }
    get valueAxis() {
        return this._getOption('valueAxis');
    }
    set valueAxis(value) {
        this._setOption('valueAxis', value);
    }
    get _optionPath() {
        return 'zoomAndPan';
    }
    constructor(parentOptionHost, optionHost) {
        super();
        parentOptionHost.setNestedOption(this);
        optionHost.setHost(this, this._fullOptionPath.bind(this));
    }
    ngOnInit() {
        this._addRecreatedComponent();
    }
    ngOnDestroy() {
        this._addRemovedOption(this._getOptionPath());
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartZoomAndPanComponent, deps: [{ token: i1.NestedOptionHost, host: true, skipSelf: true }, { token: i1.NestedOptionHost, host: true }], target: i0.ɵɵFactoryTarget.Component }); }
    /** @nocollapse */ static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.27", type: DxoChartZoomAndPanComponent, isStandalone: true, selector: "dxo-chart-zoom-and-pan", inputs: { allowMouseWheel: "allowMouseWheel", allowTouchGestures: "allowTouchGestures", argumentAxis: "argumentAxis", dragBoxStyle: "dragBoxStyle", dragToZoom: "dragToZoom", panKey: "panKey", valueAxis: "valueAxis" }, providers: [NestedOptionHost], usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: DxIntegrationModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartZoomAndPanComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dxo-chart-zoom-and-pan', template: '', imports: [DxIntegrationModule], providers: [NestedOptionHost] }]
        }], ctorParameters: () => [{ type: i1.NestedOptionHost, decorators: [{
                    type: SkipSelf
                }, {
                    type: Host
                }] }, { type: i1.NestedOptionHost, decorators: [{
                    type: Host
                }] }], propDecorators: { allowMouseWheel: [{
                type: Input
            }], allowTouchGestures: [{
                type: Input
            }], argumentAxis: [{
                type: Input
            }], dragBoxStyle: [{
                type: Input
            }], dragToZoom: [{
                type: Input
            }], panKey: [{
                type: Input
            }], valueAxis: [{
                type: Input
            }] } });
class DxoChartZoomAndPanModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartZoomAndPanModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "20.3.27", ngImport: i0, type: DxoChartZoomAndPanModule, imports: [DxoChartZoomAndPanComponent], exports: [DxoChartZoomAndPanComponent] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartZoomAndPanModule, imports: [DxoChartZoomAndPanComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: DxoChartZoomAndPanModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        DxoChartZoomAndPanComponent
                    ],
                    exports: [
                        DxoChartZoomAndPanComponent
                    ],
                }]
        }] });

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

/**
 * Generated bundle index. Do not edit.
 */

export { DxiChartAnnotationComponent, DxiChartAnnotationModule, DxiChartBreakComponent, DxiChartBreakModule, DxiChartConstantLineComponent, DxiChartConstantLineModule, DxiChartPaneComponent, DxiChartPaneModule, DxiChartSeriesComponent, DxiChartSeriesModule, DxiChartStripComponent, DxiChartStripModule, DxiChartValueAxisComponent, DxiChartValueAxisModule, DxoChartAdaptiveLayoutComponent, DxoChartAdaptiveLayoutModule, DxoChartAggregationComponent, DxoChartAggregationIntervalComponent, DxoChartAggregationIntervalModule, DxoChartAggregationModule, DxoChartAnimationComponent, DxoChartAnimationModule, DxoChartAnnotationBorderComponent, DxoChartAnnotationBorderModule, DxoChartAnnotationImageComponent, DxoChartAnnotationImageModule, DxoChartArgumentAxisComponent, DxoChartArgumentAxisModule, DxoChartArgumentFormatComponent, DxoChartArgumentFormatModule, DxoChartAxisConstantLineStyleComponent, DxoChartAxisConstantLineStyleLabelComponent, DxoChartAxisConstantLineStyleLabelModule, DxoChartAxisConstantLineStyleModule, DxoChartAxisLabelComponent, DxoChartAxisLabelModule, DxoChartAxisTitleComponent, DxoChartAxisTitleModule, DxoChartBackgroundColorComponent, DxoChartBackgroundColorModule, DxoChartBorderComponent, DxoChartBorderModule, DxoChartBreakStyleComponent, DxoChartBreakStyleModule, DxoChartChartTitleComponent, DxoChartChartTitleModule, DxoChartChartTitleSubtitleComponent, DxoChartChartTitleSubtitleModule, DxoChartColorComponent, DxoChartColorModule, DxoChartCommonAnnotationSettingsComponent, DxoChartCommonAnnotationSettingsModule, DxoChartCommonAxisSettingsComponent, DxoChartCommonAxisSettingsConstantLineStyleComponent, DxoChartCommonAxisSettingsConstantLineStyleLabelComponent, DxoChartCommonAxisSettingsConstantLineStyleLabelModule, DxoChartCommonAxisSettingsConstantLineStyleModule, DxoChartCommonAxisSettingsLabelComponent, DxoChartCommonAxisSettingsLabelModule, DxoChartCommonAxisSettingsModule, DxoChartCommonAxisSettingsTitleComponent, DxoChartCommonAxisSettingsTitleModule, DxoChartCommonPaneSettingsComponent, DxoChartCommonPaneSettingsModule, DxoChartCommonSeriesSettingsComponent, DxoChartCommonSeriesSettingsHoverStyleComponent, DxoChartCommonSeriesSettingsHoverStyleModule, DxoChartCommonSeriesSettingsLabelComponent, DxoChartCommonSeriesSettingsLabelModule, DxoChartCommonSeriesSettingsModule, DxoChartCommonSeriesSettingsSelectionStyleComponent, DxoChartCommonSeriesSettingsSelectionStyleModule, DxoChartConnectorComponent, DxoChartConnectorModule, DxoChartConstantLineLabelComponent, DxoChartConstantLineLabelModule, DxoChartConstantLineStyleComponent, DxoChartConstantLineStyleModule, DxoChartCrosshairComponent, DxoChartCrosshairModule, DxoChartDataPrepareSettingsComponent, DxoChartDataPrepareSettingsModule, DxoChartDragBoxStyleComponent, DxoChartDragBoxStyleModule, DxoChartExportComponent, DxoChartExportModule, DxoChartFontComponent, DxoChartFontModule, DxoChartFormatComponent, DxoChartFormatModule, DxoChartGridComponent, DxoChartGridModule, DxoChartHatchingComponent, DxoChartHatchingModule, DxoChartHeightComponent, DxoChartHeightModule, DxoChartHorizontalLineComponent, DxoChartHorizontalLineLabelComponent, DxoChartHorizontalLineLabelModule, DxoChartHorizontalLineModule, DxoChartHoverStyleComponent, DxoChartHoverStyleModule, DxoChartImageComponent, DxoChartImageModule, DxoChartLabelComponent, DxoChartLabelModule, DxoChartLegendComponent, DxoChartLegendModule, DxoChartLegendTitleComponent, DxoChartLegendTitleModule, DxoChartLegendTitleSubtitleComponent, DxoChartLegendTitleSubtitleModule, DxoChartLengthComponent, DxoChartLengthModule, DxoChartLoadingIndicatorComponent, DxoChartLoadingIndicatorModule, DxoChartMarginComponent, DxoChartMarginModule, DxoChartMinVisualRangeLengthComponent, DxoChartMinVisualRangeLengthModule, DxoChartMinorGridComponent, DxoChartMinorGridModule, DxoChartMinorTickComponent, DxoChartMinorTickIntervalComponent, DxoChartMinorTickIntervalModule, DxoChartMinorTickModule, DxoChartPaneBorderComponent, DxoChartPaneBorderModule, DxoChartPointBorderComponent, DxoChartPointBorderModule, DxoChartPointComponent, DxoChartPointHoverStyleComponent, DxoChartPointHoverStyleModule, DxoChartPointImageComponent, DxoChartPointImageModule, DxoChartPointModule, DxoChartPointSelectionStyleComponent, DxoChartPointSelectionStyleModule, DxoChartReductionComponent, DxoChartReductionModule, DxoChartScrollBarComponent, DxoChartScrollBarModule, DxoChartSelectionStyleComponent, DxoChartSelectionStyleModule, DxoChartSeriesBorderComponent, DxoChartSeriesBorderModule, DxoChartSeriesTemplateComponent, DxoChartSeriesTemplateModule, DxoChartShadowComponent, DxoChartShadowModule, DxoChartSizeComponent, DxoChartSizeModule, DxoChartStripLabelComponent, DxoChartStripLabelModule, DxoChartStripStyleComponent, DxoChartStripStyleLabelComponent, DxoChartStripStyleLabelModule, DxoChartStripStyleModule, DxoChartSubtitleComponent, DxoChartSubtitleModule, DxoChartTickComponent, DxoChartTickIntervalComponent, DxoChartTickIntervalModule, DxoChartTickModule, DxoChartTitleComponent, DxoChartTitleModule, DxoChartTooltipBorderComponent, DxoChartTooltipBorderModule, DxoChartTooltipComponent, DxoChartTooltipModule, DxoChartUrlComponent, DxoChartUrlModule, DxoChartValueErrorBarComponent, DxoChartValueErrorBarModule, DxoChartVerticalLineComponent, DxoChartVerticalLineModule, DxoChartVisualRangeComponent, DxoChartVisualRangeModule, DxoChartWholeRangeComponent, DxoChartWholeRangeModule, DxoChartWidthComponent, DxoChartWidthModule, DxoChartZoomAndPanComponent, DxoChartZoomAndPanModule };
//# sourceMappingURL=devextreme-angular-ui-chart-nested.mjs.map
