import * as i0 from '@angular/core';
import { Injector } from '@angular/core';

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxHttpModule {
    constructor(injector: Injector);
    static ɵfac: i0.ɵɵFactoryDeclaration<DxHttpModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxHttpModule, never, never, never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxHttpModule>;
}

export { DxHttpModule };
//# sourceMappingURL=index.d.ts.map
