import { CellAddress, CellRange, DataGridCell, DataGridExportOptions, PivotGridCell, PivotGridExportOptions, exportDataGrid, exportPivotGrid } from 'devextreme/common/export/excel';
import { Cell, DataGridCell as DataGridCell$1, DataGridExportOptions as DataGridExportOptions$1, GanttExportFont, GanttExportOptions, exportDataGrid as exportDataGrid$1, exportGantt } from 'devextreme/common/export/pdf';

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare const index_d$1_CellAddress: typeof CellAddress;
declare const index_d$1_CellRange: typeof CellRange;
declare const index_d$1_DataGridCell: typeof DataGridCell;
declare const index_d$1_DataGridExportOptions: typeof DataGridExportOptions;
declare const index_d$1_PivotGridCell: typeof PivotGridCell;
declare const index_d$1_PivotGridExportOptions: typeof PivotGridExportOptions;
declare const index_d$1_exportDataGrid: typeof exportDataGrid;
declare const index_d$1_exportPivotGrid: typeof exportPivotGrid;
declare namespace index_d$1 {
  export {
    index_d$1_CellAddress as CellAddress,
    index_d$1_CellRange as CellRange,
    index_d$1_DataGridCell as DataGridCell,
    index_d$1_DataGridExportOptions as DataGridExportOptions,
    index_d$1_PivotGridCell as PivotGridCell,
    index_d$1_PivotGridExportOptions as PivotGridExportOptions,
    index_d$1_exportDataGrid as exportDataGrid,
    index_d$1_exportPivotGrid as exportPivotGrid,
  };
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare const index_d_Cell: typeof Cell;
declare const index_d_GanttExportFont: typeof GanttExportFont;
declare const index_d_GanttExportOptions: typeof GanttExportOptions;
declare const index_d_exportGantt: typeof exportGantt;
declare namespace index_d {
  export {
    index_d_Cell as Cell,
    DataGridCell$1 as DataGridCell,
    DataGridExportOptions$1 as DataGridExportOptions,
    index_d_GanttExportFont as GanttExportFont,
    index_d_GanttExportOptions as GanttExportOptions,
    exportDataGrid$1 as exportDataGrid,
    index_d_exportGantt as exportGantt,
  };
}

export { index_d$1 as Excel, index_d as Pdf };
//# sourceMappingURL=index.d.ts.map
