export { Cell, DataGridCell, DataGridExportOptions, GanttExportFont, GanttExportOptions, exportDataGrid, exportGantt } from 'devextreme/common/export/pdf';
//# sourceMappingURL=index.d.ts.map
