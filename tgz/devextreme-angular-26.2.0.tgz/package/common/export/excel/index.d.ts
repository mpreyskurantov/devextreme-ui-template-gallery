export { CellAddress, CellRange, DataGridCell, DataGridExportOptions, PivotGridCell, PivotGridExportOptions, exportDataGrid, exportPivotGrid } from 'devextreme/common/export/excel';
//# sourceMappingURL=index.d.ts.map
