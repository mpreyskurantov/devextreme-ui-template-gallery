import { AnimationConfig, AnimationState, CollisionResolution, CollisionResolutionCombination, PositionConfig, TransitionExecutor, animationPresets, cancelAnimationFrame, fx, requestAnimationFrame } from 'devextreme/common/core/animation';
import { Device, SchedulerTimeZone, getTimeZones, hideTopOverlay, initMobileViewport } from 'devextreme/common/core/environment';
import { AsyncCancelable, Cancelable, ChangedOptionInfo, EventInfo, EventObject, InitializedEventInfo, ItemInfo, NativeEventInfo, off, on, one, trigger } from 'devextreme/common/core/events';
import { Format, formatDate, formatMessage, formatNumber, loadMessages, locale, parseDate, parseNumber } from 'devextreme/common/core/localization';

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare const index_d$3_AnimationConfig: typeof AnimationConfig;
declare const index_d$3_AnimationState: typeof AnimationState;
declare const index_d$3_CollisionResolution: typeof CollisionResolution;
declare const index_d$3_CollisionResolutionCombination: typeof CollisionResolutionCombination;
declare const index_d$3_PositionConfig: typeof PositionConfig;
declare const index_d$3_TransitionExecutor: typeof TransitionExecutor;
declare const index_d$3_animationPresets: typeof animationPresets;
declare const index_d$3_cancelAnimationFrame: typeof cancelAnimationFrame;
declare const index_d$3_fx: typeof fx;
declare const index_d$3_requestAnimationFrame: typeof requestAnimationFrame;
declare namespace index_d$3 {
  export {
    index_d$3_AnimationConfig as AnimationConfig,
    index_d$3_AnimationState as AnimationState,
    index_d$3_CollisionResolution as CollisionResolution,
    index_d$3_CollisionResolutionCombination as CollisionResolutionCombination,
    index_d$3_PositionConfig as PositionConfig,
    index_d$3_TransitionExecutor as TransitionExecutor,
    index_d$3_animationPresets as animationPresets,
    index_d$3_cancelAnimationFrame as cancelAnimationFrame,
    index_d$3_fx as fx,
    index_d$3_requestAnimationFrame as requestAnimationFrame,
  };
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare const index_d$2_Device: typeof Device;
declare const index_d$2_SchedulerTimeZone: typeof SchedulerTimeZone;
declare const index_d$2_getTimeZones: typeof getTimeZones;
declare const index_d$2_hideTopOverlay: typeof hideTopOverlay;
declare const index_d$2_initMobileViewport: typeof initMobileViewport;
declare namespace index_d$2 {
  export {
    index_d$2_Device as Device,
    index_d$2_SchedulerTimeZone as SchedulerTimeZone,
    index_d$2_getTimeZones as getTimeZones,
    index_d$2_hideTopOverlay as hideTopOverlay,
    index_d$2_initMobileViewport as initMobileViewport,
  };
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare const index_d$1_AsyncCancelable: typeof AsyncCancelable;
declare const index_d$1_Cancelable: typeof Cancelable;
declare const index_d$1_ChangedOptionInfo: typeof ChangedOptionInfo;
declare const index_d$1_EventInfo: typeof EventInfo;
declare const index_d$1_EventObject: typeof EventObject;
declare const index_d$1_InitializedEventInfo: typeof InitializedEventInfo;
declare const index_d$1_ItemInfo: typeof ItemInfo;
declare const index_d$1_NativeEventInfo: typeof NativeEventInfo;
declare const index_d$1_off: typeof off;
declare const index_d$1_on: typeof on;
declare const index_d$1_one: typeof one;
declare const index_d$1_trigger: typeof trigger;
declare namespace index_d$1 {
  export {
    index_d$1_AsyncCancelable as AsyncCancelable,
    index_d$1_Cancelable as Cancelable,
    index_d$1_ChangedOptionInfo as ChangedOptionInfo,
    index_d$1_EventInfo as EventInfo,
    index_d$1_EventObject as EventObject,
    index_d$1_InitializedEventInfo as InitializedEventInfo,
    index_d$1_ItemInfo as ItemInfo,
    index_d$1_NativeEventInfo as NativeEventInfo,
    index_d$1_off as off,
    index_d$1_on as on,
    index_d$1_one as one,
    index_d$1_trigger as trigger,
  };
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare const index_d_Format: typeof Format;
declare const index_d_formatDate: typeof formatDate;
declare const index_d_formatMessage: typeof formatMessage;
declare const index_d_formatNumber: typeof formatNumber;
declare const index_d_loadMessages: typeof loadMessages;
declare const index_d_locale: typeof locale;
declare const index_d_parseDate: typeof parseDate;
declare const index_d_parseNumber: typeof parseNumber;
declare namespace index_d {
  export {
    index_d_Format as Format,
    index_d_formatDate as formatDate,
    index_d_formatMessage as formatMessage,
    index_d_formatNumber as formatNumber,
    index_d_loadMessages as loadMessages,
    index_d_locale as locale,
    index_d_parseDate as parseDate,
    index_d_parseNumber as parseNumber,
  };
}

export { index_d$3 as Animation, index_d$2 as Environment, index_d$1 as Events, index_d as Localization };
//# sourceMappingURL=index.d.ts.map
