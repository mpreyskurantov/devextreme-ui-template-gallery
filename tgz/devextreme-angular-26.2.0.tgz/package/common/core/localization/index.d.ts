export { Format, formatDate, formatMessage, formatNumber, loadMessages, locale, parseDate, parseNumber } from 'devextreme/common/core/localization';
//# sourceMappingURL=index.d.ts.map
