export { AnimationConfig, AnimationState, CollisionResolution, CollisionResolutionCombination, PositionConfig, TransitionExecutor, animationPresets, cancelAnimationFrame, fx, requestAnimationFrame } from 'devextreme/common/core/animation';
//# sourceMappingURL=index.d.ts.map
