export { Device, SchedulerTimeZone, getTimeZones, hideTopOverlay, initMobileViewport } from 'devextreme/common/core/environment';
//# sourceMappingURL=index.d.ts.map
