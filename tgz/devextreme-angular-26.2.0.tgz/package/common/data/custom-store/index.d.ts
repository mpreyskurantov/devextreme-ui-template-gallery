export { GroupItem, LoadResult, LoadResultObject, isGroupItemsArray, isItemsArray, isLoadResultObject } from 'devextreme/common/data/custom-store';
//# sourceMappingURL=index.d.ts.map
