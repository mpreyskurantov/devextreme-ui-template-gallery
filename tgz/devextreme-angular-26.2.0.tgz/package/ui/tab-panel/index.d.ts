import * as i0 from '@angular/core';
import { OnDestroy, OnChanges, DoCheck, QueryList, EventEmitter, ElementRef, NgZone, TransferState, SimpleChanges } from '@angular/core';
import DxTabPanel, { dxTabPanelItem, ContentReadyEvent, DisposingEvent, InitializedEvent, ItemClickEvent, ItemContextMenuEvent, ItemHoldEvent, ItemRenderedEvent, OptionChangedEvent, SelectionChangedEvent, SelectionChangingEvent, TitleClickEvent, TitleHoldEvent, TitleRenderedEvent } from 'devextreme/ui/tab_panel';
export { ExplicitTypes } from 'devextreme/ui/tab_panel';
import DataSource, { DataSourceOptions } from 'devextreme/data/data_source';
import { Store } from 'devextreme/data/store';
import { TabsIconPosition, TabsStyle, Position } from 'devextreme/common';
import * as i3 from 'devextreme-angular/core';
import { DxComponent, CollectionNestedOption, DxTemplateHost, WatcherHelper, IterableDifferHelper, NestedOptionHost } from 'devextreme-angular/core';
import * as i1 from 'devextreme-angular/ui/nested';
import * as i2 from 'devextreme-angular/ui/tab-panel/nested';
export * from 'devextreme-angular/ui/tab-panel/nested';
import * as tab_panel_types from 'devextreme/ui/tab_panel_types';
export { tab_panel_types as DxTabPanelTypes };

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

/**
 * [descr:dxTabPanel]

 */
declare class DxTabPanelComponent<TItem = any, TKey = any> extends DxComponent implements OnDestroy, OnChanges, DoCheck {
    private _watcherHelper;
    private _idh;
    set _itemsContentChildren(value: QueryList<CollectionNestedOption>);
    instance: DxTabPanel<TItem, TKey>;
    /**
     * [descr:WidgetOptions.accessKey]
    
     */
    get accessKey(): string | undefined;
    set accessKey(value: string | undefined);
    /**
     * [descr:WidgetOptions.activeStateEnabled]
    
     */
    get activeStateEnabled(): boolean;
    set activeStateEnabled(value: boolean);
    /**
     * [descr:dxTabPanelOptions.animationEnabled]
    
     */
    get animationEnabled(): boolean;
    set animationEnabled(value: boolean);
    /**
     * [descr:dxTabPanelOptions.dataSource]
    
     */
    get dataSource(): Array<any | dxTabPanelItem | string> | DataSource | DataSourceOptions | null | Store | string;
    set dataSource(value: Array<any | dxTabPanelItem | string> | DataSource | DataSourceOptions | null | Store | string);
    /**
     * [descr:dxMultiViewOptions.deferRendering]
    
     */
    get deferRendering(): boolean;
    set deferRendering(value: boolean);
    /**
     * [descr:WidgetOptions.disabled]
    
     */
    get disabled(): boolean;
    set disabled(value: boolean);
    /**
     * [descr:DOMComponentOptions.elementAttr]
    
     */
    get elementAttr(): Record<string, any>;
    set elementAttr(value: Record<string, any>);
    /**
     * [descr:dxMultiViewOptions.focusStateEnabled]
    
     */
    get focusStateEnabled(): boolean;
    set focusStateEnabled(value: boolean);
    /**
     * [descr:DOMComponentOptions.height]
    
     */
    get height(): number | string | undefined;
    set height(value: number | string | undefined);
    /**
     * [descr:WidgetOptions.hint]
    
     */
    get hint(): string | undefined;
    set hint(value: string | undefined);
    /**
     * [descr:dxTabPanelOptions.hoverStateEnabled]
    
     */
    get hoverStateEnabled(): boolean;
    set hoverStateEnabled(value: boolean);
    /**
     * [descr:dxTabPanelOptions.iconPosition]
    
     */
    get iconPosition(): TabsIconPosition;
    set iconPosition(value: TabsIconPosition);
    /**
     * [descr:CollectionWidgetOptions.itemHoldTimeout]
    
     */
    get itemHoldTimeout(): number;
    set itemHoldTimeout(value: number);
    /**
     * [descr:dxTabPanelOptions.items]
    
     */
    get items(): Array<any | dxTabPanelItem | string>;
    set items(value: Array<any | dxTabPanelItem | string>);
    /**
     * [descr:CollectionWidgetOptions.itemTemplate]
    
     */
    get itemTemplate(): any;
    set itemTemplate(value: any);
    /**
     * [descr:dxTabPanelOptions.itemTitleTemplate]
    
     */
    get itemTitleTemplate(): any;
    set itemTitleTemplate(value: any);
    /**
     * [descr:dxTabPanelOptions.keyExpr]
    
     */
    get keyExpr(): ((item: any) => any) | string;
    set keyExpr(value: ((item: any) => any) | string);
    /**
     * [descr:dxMultiViewOptions.loop]
    
     */
    get loop(): boolean;
    set loop(value: boolean);
    /**
     * [descr:CollectionWidgetOptions.noDataText]
    
     */
    get noDataText(): string;
    set noDataText(value: string);
    /**
     * [descr:dxTabPanelOptions.repaintChangesOnly]
    
     */
    get repaintChangesOnly(): boolean;
    set repaintChangesOnly(value: boolean);
    /**
     * [descr:DOMComponentOptions.rtlEnabled]
    
     */
    get rtlEnabled(): boolean;
    set rtlEnabled(value: boolean);
    /**
     * [descr:dxTabPanelOptions.scrollByContent]
    
     */
    get scrollByContent(): boolean;
    set scrollByContent(value: boolean);
    /**
     * [descr:dxTabPanelOptions.scrollingEnabled]
    
     */
    get scrollingEnabled(): boolean;
    set scrollingEnabled(value: boolean);
    /**
     * [descr:dxMultiViewOptions.selectedIndex]
    
     */
    get selectedIndex(): number;
    set selectedIndex(value: number);
    /**
     * [descr:CollectionWidgetOptions.selectedItem]
    
     */
    get selectedItem(): any | null;
    set selectedItem(value: any | null);
    /**
     * [descr:dxTabPanelOptions.showNavButtons]
    
     */
    get showNavButtons(): boolean;
    set showNavButtons(value: boolean);
    /**
     * [descr:dxTabPanelOptions.stylingMode]
    
     */
    get stylingMode(): TabsStyle;
    set stylingMode(value: TabsStyle);
    /**
     * [descr:dxTabPanelOptions.swipeEnabled]
    
     */
    get swipeEnabled(): boolean;
    set swipeEnabled(value: boolean);
    /**
     * [descr:WidgetOptions.tabIndex]
    
     */
    get tabIndex(): number;
    set tabIndex(value: number);
    /**
     * [descr:dxTabPanelOptions.tabsPosition]
    
     */
    get tabsPosition(): Position;
    set tabsPosition(value: Position);
    /**
     * [descr:WidgetOptions.visible]
    
     */
    get visible(): boolean;
    set visible(value: boolean);
    /**
     * [descr:DOMComponentOptions.width]
    
     */
    get width(): number | string | undefined;
    set width(value: number | string | undefined);
    /**
    
     * [descr:dxTabPanelOptions.onContentReady]
    
    
     */
    onContentReady: EventEmitter<ContentReadyEvent>;
    /**
    
     * [descr:dxTabPanelOptions.onDisposing]
    
    
     */
    onDisposing: EventEmitter<DisposingEvent>;
    /**
    
     * [descr:dxTabPanelOptions.onInitialized]
    
    
     */
    onInitialized: EventEmitter<InitializedEvent>;
    /**
    
     * [descr:dxTabPanelOptions.onItemClick]
    
    
     */
    onItemClick: EventEmitter<ItemClickEvent>;
    /**
    
     * [descr:dxTabPanelOptions.onItemContextMenu]
    
    
     */
    onItemContextMenu: EventEmitter<ItemContextMenuEvent>;
    /**
    
     * [descr:dxTabPanelOptions.onItemHold]
    
    
     */
    onItemHold: EventEmitter<ItemHoldEvent>;
    /**
    
     * [descr:dxTabPanelOptions.onItemRendered]
    
    
     */
    onItemRendered: EventEmitter<ItemRenderedEvent>;
    /**
    
     * [descr:dxTabPanelOptions.onOptionChanged]
    
    
     */
    onOptionChanged: EventEmitter<OptionChangedEvent>;
    /**
    
     * [descr:dxTabPanelOptions.onSelectionChanged]
    
    
     */
    onSelectionChanged: EventEmitter<SelectionChangedEvent>;
    /**
    
     * [descr:dxTabPanelOptions.onSelectionChanging]
    
    
     */
    onSelectionChanging: EventEmitter<SelectionChangingEvent>;
    /**
    
     * [descr:dxTabPanelOptions.onTitleClick]
    
    
     */
    onTitleClick: EventEmitter<TitleClickEvent>;
    /**
    
     * [descr:dxTabPanelOptions.onTitleHold]
    
    
     */
    onTitleHold: EventEmitter<TitleHoldEvent>;
    /**
    
     * [descr:dxTabPanelOptions.onTitleRendered]
    
    
     */
    onTitleRendered: EventEmitter<TitleRenderedEvent>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    accessKeyChange: EventEmitter<string | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    activeStateEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    animationEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    dataSourceChange: EventEmitter<Array<any | dxTabPanelItem | string> | DataSource | DataSourceOptions | null | Store | string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    deferRenderingChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    disabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    elementAttrChange: EventEmitter<Record<string, any>>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    focusStateEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    heightChange: EventEmitter<number | string | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    hintChange: EventEmitter<string | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    hoverStateEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    iconPositionChange: EventEmitter<TabsIconPosition>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    itemHoldTimeoutChange: EventEmitter<number>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    itemsChange: EventEmitter<Array<any | dxTabPanelItem | string>>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    itemTemplateChange: EventEmitter<any>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    itemTitleTemplateChange: EventEmitter<any>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    keyExprChange: EventEmitter<((item: any) => any) | string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    loopChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    noDataTextChange: EventEmitter<string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    repaintChangesOnlyChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    rtlEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    scrollByContentChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    scrollingEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    selectedIndexChange: EventEmitter<number>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    selectedItemChange: EventEmitter<any | null>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    showNavButtonsChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    stylingModeChange: EventEmitter<TabsStyle>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    swipeEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    tabIndexChange: EventEmitter<number>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    tabsPositionChange: EventEmitter<Position>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    visibleChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    widthChange: EventEmitter<number | string | undefined>;
    constructor(elementRef: ElementRef, ngZone: NgZone, templateHost: DxTemplateHost, _watcherHelper: WatcherHelper, _idh: IterableDifferHelper, optionHost: NestedOptionHost, transferState: TransferState, platformId: any);
    protected _createInstance(element: any, options: any): DxTabPanel<any, any>;
    ngOnDestroy(): void;
    ngOnChanges(changes: SimpleChanges): void;
    setupChanges(prop: string, changes: SimpleChanges): void;
    ngDoCheck(): void;
    _setOption(name: string, value: any): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxTabPanelComponent<any, any>, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxTabPanelComponent<any, any>, "dx-tab-panel", never, { "accessKey": { "alias": "accessKey"; "required": false; }; "activeStateEnabled": { "alias": "activeStateEnabled"; "required": false; }; "animationEnabled": { "alias": "animationEnabled"; "required": false; }; "dataSource": { "alias": "dataSource"; "required": false; }; "deferRendering": { "alias": "deferRendering"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "elementAttr": { "alias": "elementAttr"; "required": false; }; "focusStateEnabled": { "alias": "focusStateEnabled"; "required": false; }; "height": { "alias": "height"; "required": false; }; "hint": { "alias": "hint"; "required": false; }; "hoverStateEnabled": { "alias": "hoverStateEnabled"; "required": false; }; "iconPosition": { "alias": "iconPosition"; "required": false; }; "itemHoldTimeout": { "alias": "itemHoldTimeout"; "required": false; }; "items": { "alias": "items"; "required": false; }; "itemTemplate": { "alias": "itemTemplate"; "required": false; }; "itemTitleTemplate": { "alias": "itemTitleTemplate"; "required": false; }; "keyExpr": { "alias": "keyExpr"; "required": false; }; "loop": { "alias": "loop"; "required": false; }; "noDataText": { "alias": "noDataText"; "required": false; }; "repaintChangesOnly": { "alias": "repaintChangesOnly"; "required": false; }; "rtlEnabled": { "alias": "rtlEnabled"; "required": false; }; "scrollByContent": { "alias": "scrollByContent"; "required": false; }; "scrollingEnabled": { "alias": "scrollingEnabled"; "required": false; }; "selectedIndex": { "alias": "selectedIndex"; "required": false; }; "selectedItem": { "alias": "selectedItem"; "required": false; }; "showNavButtons": { "alias": "showNavButtons"; "required": false; }; "stylingMode": { "alias": "stylingMode"; "required": false; }; "swipeEnabled": { "alias": "swipeEnabled"; "required": false; }; "tabIndex": { "alias": "tabIndex"; "required": false; }; "tabsPosition": { "alias": "tabsPosition"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, { "onContentReady": "onContentReady"; "onDisposing": "onDisposing"; "onInitialized": "onInitialized"; "onItemClick": "onItemClick"; "onItemContextMenu": "onItemContextMenu"; "onItemHold": "onItemHold"; "onItemRendered": "onItemRendered"; "onOptionChanged": "onOptionChanged"; "onSelectionChanged": "onSelectionChanged"; "onSelectionChanging": "onSelectionChanging"; "onTitleClick": "onTitleClick"; "onTitleHold": "onTitleHold"; "onTitleRendered": "onTitleRendered"; "accessKeyChange": "accessKeyChange"; "activeStateEnabledChange": "activeStateEnabledChange"; "animationEnabledChange": "animationEnabledChange"; "dataSourceChange": "dataSourceChange"; "deferRenderingChange": "deferRenderingChange"; "disabledChange": "disabledChange"; "elementAttrChange": "elementAttrChange"; "focusStateEnabledChange": "focusStateEnabledChange"; "heightChange": "heightChange"; "hintChange": "hintChange"; "hoverStateEnabledChange": "hoverStateEnabledChange"; "iconPositionChange": "iconPositionChange"; "itemHoldTimeoutChange": "itemHoldTimeoutChange"; "itemsChange": "itemsChange"; "itemTemplateChange": "itemTemplateChange"; "itemTitleTemplateChange": "itemTitleTemplateChange"; "keyExprChange": "keyExprChange"; "loopChange": "loopChange"; "noDataTextChange": "noDataTextChange"; "repaintChangesOnlyChange": "repaintChangesOnlyChange"; "rtlEnabledChange": "rtlEnabledChange"; "scrollByContentChange": "scrollByContentChange"; "scrollingEnabledChange": "scrollingEnabledChange"; "selectedIndexChange": "selectedIndexChange"; "selectedItemChange": "selectedItemChange"; "showNavButtonsChange": "showNavButtonsChange"; "stylingModeChange": "stylingModeChange"; "swipeEnabledChange": "swipeEnabledChange"; "tabIndexChange": "tabIndexChange"; "tabsPositionChange": "tabsPositionChange"; "visibleChange": "visibleChange"; "widthChange": "widthChange"; }, ["_itemsContentChildren"], never, true, never>;
}
declare class DxTabPanelModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxTabPanelModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxTabPanelModule, never, [typeof DxTabPanelComponent, typeof i1.DxiItemModule, typeof i2.DxiTabPanelItemModule, typeof i3.DxIntegrationModule, typeof i3.DxTemplateModule], [typeof DxTabPanelComponent, typeof i1.DxiItemModule, typeof i2.DxiTabPanelItemModule, typeof i3.DxTemplateModule]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxTabPanelModule>;
}

export { DxTabPanelComponent, DxTabPanelModule };
//# sourceMappingURL=index.d.ts.map
