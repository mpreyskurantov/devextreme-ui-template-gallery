import * as i0 from '@angular/core';
import { OnDestroy, OnChanges, DoCheck, EventEmitter, ElementRef, NgZone, TransferState, SimpleChanges } from '@angular/core';
import DataSource, { DataSourceOptions } from 'devextreme/data/data_source';
import { Store } from 'devextreme/data/store';
import DxSparkline, { SparklineType, DisposingEvent, DrawnEvent, ExportedEvent, ExportingEvent, FileSavingEvent, IncidentOccurredEvent, InitializedEvent, OptionChangedEvent, TooltipHiddenEvent, TooltipShownEvent } from 'devextreme/viz/sparkline';
import { PointSymbol, Theme, DashStyle, Font } from 'devextreme/common/charts';
import { Format } from 'devextreme/common/core/localization';
import * as i3 from 'devextreme-angular/core';
import { DxComponent, DxTemplateHost, WatcherHelper, IterableDifferHelper, NestedOptionHost } from 'devextreme-angular/core';
import * as i1 from 'devextreme-angular/ui/nested';
import * as i2 from 'devextreme-angular/ui/sparkline/nested';
export * from 'devextreme-angular/ui/sparkline/nested';
import * as sparkline_types from 'devextreme/viz/sparkline_types';
export { sparkline_types as DxSparklineTypes };

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

/**
 * [descr:dxSparkline]

 */
declare class DxSparklineComponent extends DxComponent implements OnDestroy, OnChanges, DoCheck {
    private _watcherHelper;
    private _idh;
    instance: DxSparkline;
    /**
     * [descr:dxSparklineOptions.argumentField]
    
     */
    get argumentField(): string;
    set argumentField(value: string);
    /**
     * [descr:dxSparklineOptions.barNegativeColor]
    
     */
    get barNegativeColor(): string;
    set barNegativeColor(value: string);
    /**
     * [descr:dxSparklineOptions.barPositiveColor]
    
     */
    get barPositiveColor(): string;
    set barPositiveColor(value: string);
    /**
     * [descr:dxSparklineOptions.dataSource]
    
     */
    get dataSource(): Array<any> | DataSource | DataSourceOptions | null | Store | string;
    set dataSource(value: Array<any> | DataSource | DataSourceOptions | null | Store | string);
    /**
     * [descr:BaseWidgetOptions.disabled]
    
     */
    get disabled(): boolean;
    set disabled(value: boolean);
    /**
     * [descr:DOMComponentOptions.elementAttr]
    
     */
    get elementAttr(): Record<string, any>;
    set elementAttr(value: Record<string, any>);
    /**
     * [descr:BaseWidgetOptions.encodeHtml]
    
     */
    get encodeHtml(): boolean;
    set encodeHtml(value: boolean);
    /**
     * [descr:dxSparklineOptions.firstLastColor]
    
     */
    get firstLastColor(): string;
    set firstLastColor(value: string);
    /**
     * [descr:dxSparklineOptions.ignoreEmptyPoints]
    
     */
    get ignoreEmptyPoints(): boolean;
    set ignoreEmptyPoints(value: boolean);
    /**
     * [descr:dxSparklineOptions.lineColor]
    
     */
    get lineColor(): string;
    set lineColor(value: string);
    /**
     * [descr:dxSparklineOptions.lineWidth]
    
     */
    get lineWidth(): number;
    set lineWidth(value: number);
    /**
     * [descr:dxSparklineOptions.lossColor]
    
     */
    get lossColor(): string;
    set lossColor(value: string);
    /**
     * [descr:BaseWidgetOptions.margin]
    
     */
    get margin(): {
        bottom?: number;
        left?: number;
        right?: number;
        top?: number;
    };
    set margin(value: {
        bottom?: number;
        left?: number;
        right?: number;
        top?: number;
    });
    /**
     * [descr:dxSparklineOptions.maxColor]
    
     */
    get maxColor(): string;
    set maxColor(value: string);
    /**
     * [descr:dxSparklineOptions.maxValue]
    
     */
    get maxValue(): number | undefined;
    set maxValue(value: number | undefined);
    /**
     * [descr:dxSparklineOptions.minColor]
    
     */
    get minColor(): string;
    set minColor(value: string);
    /**
     * [descr:dxSparklineOptions.minValue]
    
     */
    get minValue(): number | undefined;
    set minValue(value: number | undefined);
    /**
     * [descr:BaseWidgetOptions.pathModified]
    
     */
    get pathModified(): boolean;
    set pathModified(value: boolean);
    /**
     * [descr:dxSparklineOptions.pointColor]
    
     */
    get pointColor(): string;
    set pointColor(value: string);
    /**
     * [descr:dxSparklineOptions.pointSize]
    
     */
    get pointSize(): number;
    set pointSize(value: number);
    /**
     * [descr:dxSparklineOptions.pointSymbol]
    
     */
    get pointSymbol(): PointSymbol;
    set pointSymbol(value: PointSymbol);
    /**
     * [descr:BaseWidgetOptions.rtlEnabled]
    
     */
    get rtlEnabled(): boolean;
    set rtlEnabled(value: boolean);
    /**
     * [descr:dxSparklineOptions.showFirstLast]
    
     */
    get showFirstLast(): boolean;
    set showFirstLast(value: boolean);
    /**
     * [descr:dxSparklineOptions.showMinMax]
    
     */
    get showMinMax(): boolean;
    set showMinMax(value: boolean);
    /**
     * [descr:BaseWidgetOptions.size]
    
     */
    get size(): {
        height?: number | undefined;
        width?: number | undefined;
    };
    set size(value: {
        height?: number | undefined;
        width?: number | undefined;
    });
    /**
     * [descr:BaseWidgetOptions.theme]
    
     */
    get theme(): Theme;
    set theme(value: Theme);
    /**
     * [descr:BaseSparklineOptions.tooltip]
    
     */
    get tooltip(): {
        arrowLength?: number;
        border?: {
            color?: string;
            dashStyle?: DashStyle;
            opacity?: number | undefined;
            visible?: boolean;
            width?: number;
        };
        color?: string;
        container?: any | string | undefined;
        contentTemplate?: any;
        cornerRadius?: number;
        customizeTooltip?: ((pointsInfo: any) => Record<string, any>) | undefined;
        enabled?: boolean;
        font?: Font;
        format?: Format | undefined;
        interactive?: boolean;
        opacity?: number | undefined;
        paddingLeftRight?: number;
        paddingTopBottom?: number;
        shadow?: {
            blur?: number;
            color?: string;
            offsetX?: number;
            offsetY?: number;
            opacity?: number;
        };
        zIndex?: number | undefined;
    };
    set tooltip(value: {
        arrowLength?: number;
        border?: {
            color?: string;
            dashStyle?: DashStyle;
            opacity?: number | undefined;
            visible?: boolean;
            width?: number;
        };
        color?: string;
        container?: any | string | undefined;
        contentTemplate?: any;
        cornerRadius?: number;
        customizeTooltip?: ((pointsInfo: any) => Record<string, any>) | undefined;
        enabled?: boolean;
        font?: Font;
        format?: Format | undefined;
        interactive?: boolean;
        opacity?: number | undefined;
        paddingLeftRight?: number;
        paddingTopBottom?: number;
        shadow?: {
            blur?: number;
            color?: string;
            offsetX?: number;
            offsetY?: number;
            opacity?: number;
        };
        zIndex?: number | undefined;
    });
    /**
     * [descr:dxSparklineOptions.type]
    
     */
    get type(): SparklineType;
    set type(value: SparklineType);
    /**
     * [descr:dxSparklineOptions.valueField]
    
     */
    get valueField(): string;
    set valueField(value: string);
    /**
     * [descr:dxSparklineOptions.winColor]
    
     */
    get winColor(): string;
    set winColor(value: string);
    /**
     * [descr:dxSparklineOptions.winlossThreshold]
    
     */
    get winlossThreshold(): number;
    set winlossThreshold(value: number);
    /**
    
     * [descr:dxSparklineOptions.onDisposing]
    
    
     */
    onDisposing: EventEmitter<DisposingEvent>;
    /**
    
     * [descr:dxSparklineOptions.onDrawn]
    
    
     */
    onDrawn: EventEmitter<DrawnEvent>;
    /**
    
     * [descr:dxSparklineOptions.onExported]
    
    
     */
    onExported: EventEmitter<ExportedEvent>;
    /**
    
     * [descr:dxSparklineOptions.onExporting]
    
    
     */
    onExporting: EventEmitter<ExportingEvent>;
    /**
    
     * [descr:dxSparklineOptions.onFileSaving]
    
    
     */
    onFileSaving: EventEmitter<FileSavingEvent>;
    /**
    
     * [descr:dxSparklineOptions.onIncidentOccurred]
    
    
     */
    onIncidentOccurred: EventEmitter<IncidentOccurredEvent>;
    /**
    
     * [descr:dxSparklineOptions.onInitialized]
    
    
     */
    onInitialized: EventEmitter<InitializedEvent>;
    /**
    
     * [descr:dxSparklineOptions.onOptionChanged]
    
    
     */
    onOptionChanged: EventEmitter<OptionChangedEvent>;
    /**
    
     * [descr:dxSparklineOptions.onTooltipHidden]
    
    
     */
    onTooltipHidden: EventEmitter<TooltipHiddenEvent>;
    /**
    
     * [descr:dxSparklineOptions.onTooltipShown]
    
    
     */
    onTooltipShown: EventEmitter<TooltipShownEvent>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    argumentFieldChange: EventEmitter<string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    barNegativeColorChange: EventEmitter<string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    barPositiveColorChange: EventEmitter<string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    dataSourceChange: EventEmitter<Array<any> | DataSource | DataSourceOptions | null | Store | string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    disabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    elementAttrChange: EventEmitter<Record<string, any>>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    encodeHtmlChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    firstLastColorChange: EventEmitter<string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    ignoreEmptyPointsChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    lineColorChange: EventEmitter<string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    lineWidthChange: EventEmitter<number>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    lossColorChange: EventEmitter<string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    marginChange: EventEmitter<{
        bottom?: number;
        left?: number;
        right?: number;
        top?: number;
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    maxColorChange: EventEmitter<string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    maxValueChange: EventEmitter<number | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    minColorChange: EventEmitter<string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    minValueChange: EventEmitter<number | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    pathModifiedChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    pointColorChange: EventEmitter<string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    pointSizeChange: EventEmitter<number>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    pointSymbolChange: EventEmitter<PointSymbol>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    rtlEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    showFirstLastChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    showMinMaxChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    sizeChange: EventEmitter<{
        height?: number | undefined;
        width?: number | undefined;
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    themeChange: EventEmitter<Theme>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    tooltipChange: EventEmitter<{
        arrowLength?: number;
        border?: {
            color?: string;
            dashStyle?: DashStyle;
            opacity?: number | undefined;
            visible?: boolean;
            width?: number;
        };
        color?: string;
        container?: any | string | undefined;
        contentTemplate?: any;
        cornerRadius?: number;
        customizeTooltip?: ((pointsInfo: any) => Record<string, any>) | undefined;
        enabled?: boolean;
        font?: Font;
        format?: Format | undefined;
        interactive?: boolean;
        opacity?: number | undefined;
        paddingLeftRight?: number;
        paddingTopBottom?: number;
        shadow?: {
            blur?: number;
            color?: string;
            offsetX?: number;
            offsetY?: number;
            opacity?: number;
        };
        zIndex?: number | undefined;
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    typeChange: EventEmitter<SparklineType>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    valueFieldChange: EventEmitter<string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    winColorChange: EventEmitter<string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    winlossThresholdChange: EventEmitter<number>;
    constructor(elementRef: ElementRef, ngZone: NgZone, templateHost: DxTemplateHost, _watcherHelper: WatcherHelper, _idh: IterableDifferHelper, optionHost: NestedOptionHost, transferState: TransferState, platformId: any);
    protected _createInstance(element: any, options: any): DxSparkline;
    ngOnDestroy(): void;
    ngOnChanges(changes: SimpleChanges): void;
    setupChanges(prop: string, changes: SimpleChanges): void;
    ngDoCheck(): void;
    _setOption(name: string, value: any): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxSparklineComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxSparklineComponent, "dx-sparkline", never, { "argumentField": { "alias": "argumentField"; "required": false; }; "barNegativeColor": { "alias": "barNegativeColor"; "required": false; }; "barPositiveColor": { "alias": "barPositiveColor"; "required": false; }; "dataSource": { "alias": "dataSource"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "elementAttr": { "alias": "elementAttr"; "required": false; }; "encodeHtml": { "alias": "encodeHtml"; "required": false; }; "firstLastColor": { "alias": "firstLastColor"; "required": false; }; "ignoreEmptyPoints": { "alias": "ignoreEmptyPoints"; "required": false; }; "lineColor": { "alias": "lineColor"; "required": false; }; "lineWidth": { "alias": "lineWidth"; "required": false; }; "lossColor": { "alias": "lossColor"; "required": false; }; "margin": { "alias": "margin"; "required": false; }; "maxColor": { "alias": "maxColor"; "required": false; }; "maxValue": { "alias": "maxValue"; "required": false; }; "minColor": { "alias": "minColor"; "required": false; }; "minValue": { "alias": "minValue"; "required": false; }; "pathModified": { "alias": "pathModified"; "required": false; }; "pointColor": { "alias": "pointColor"; "required": false; }; "pointSize": { "alias": "pointSize"; "required": false; }; "pointSymbol": { "alias": "pointSymbol"; "required": false; }; "rtlEnabled": { "alias": "rtlEnabled"; "required": false; }; "showFirstLast": { "alias": "showFirstLast"; "required": false; }; "showMinMax": { "alias": "showMinMax"; "required": false; }; "size": { "alias": "size"; "required": false; }; "theme": { "alias": "theme"; "required": false; }; "tooltip": { "alias": "tooltip"; "required": false; }; "type": { "alias": "type"; "required": false; }; "valueField": { "alias": "valueField"; "required": false; }; "winColor": { "alias": "winColor"; "required": false; }; "winlossThreshold": { "alias": "winlossThreshold"; "required": false; }; }, { "onDisposing": "onDisposing"; "onDrawn": "onDrawn"; "onExported": "onExported"; "onExporting": "onExporting"; "onFileSaving": "onFileSaving"; "onIncidentOccurred": "onIncidentOccurred"; "onInitialized": "onInitialized"; "onOptionChanged": "onOptionChanged"; "onTooltipHidden": "onTooltipHidden"; "onTooltipShown": "onTooltipShown"; "argumentFieldChange": "argumentFieldChange"; "barNegativeColorChange": "barNegativeColorChange"; "barPositiveColorChange": "barPositiveColorChange"; "dataSourceChange": "dataSourceChange"; "disabledChange": "disabledChange"; "elementAttrChange": "elementAttrChange"; "encodeHtmlChange": "encodeHtmlChange"; "firstLastColorChange": "firstLastColorChange"; "ignoreEmptyPointsChange": "ignoreEmptyPointsChange"; "lineColorChange": "lineColorChange"; "lineWidthChange": "lineWidthChange"; "lossColorChange": "lossColorChange"; "marginChange": "marginChange"; "maxColorChange": "maxColorChange"; "maxValueChange": "maxValueChange"; "minColorChange": "minColorChange"; "minValueChange": "minValueChange"; "pathModifiedChange": "pathModifiedChange"; "pointColorChange": "pointColorChange"; "pointSizeChange": "pointSizeChange"; "pointSymbolChange": "pointSymbolChange"; "rtlEnabledChange": "rtlEnabledChange"; "showFirstLastChange": "showFirstLastChange"; "showMinMaxChange": "showMinMaxChange"; "sizeChange": "sizeChange"; "themeChange": "themeChange"; "tooltipChange": "tooltipChange"; "typeChange": "typeChange"; "valueFieldChange": "valueFieldChange"; "winColorChange": "winColorChange"; "winlossThresholdChange": "winlossThresholdChange"; }, never, never, true, never>;
}
declare class DxSparklineModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxSparklineModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxSparklineModule, never, [typeof DxSparklineComponent, typeof i1.DxoMarginModule, typeof i1.DxoSizeModule, typeof i1.DxoTooltipModule, typeof i1.DxoBorderModule, typeof i1.DxoFontModule, typeof i1.DxoFormatModule, typeof i1.DxoShadowModule, typeof i2.DxoSparklineBorderModule, typeof i2.DxoSparklineFontModule, typeof i2.DxoSparklineFormatModule, typeof i2.DxoSparklineMarginModule, typeof i2.DxoSparklineShadowModule, typeof i2.DxoSparklineSizeModule, typeof i2.DxoSparklineTooltipModule, typeof i3.DxIntegrationModule, typeof i3.DxTemplateModule], [typeof DxSparklineComponent, typeof i1.DxoMarginModule, typeof i1.DxoSizeModule, typeof i1.DxoTooltipModule, typeof i1.DxoBorderModule, typeof i1.DxoFontModule, typeof i1.DxoFormatModule, typeof i1.DxoShadowModule, typeof i2.DxoSparklineBorderModule, typeof i2.DxoSparklineFontModule, typeof i2.DxoSparklineFormatModule, typeof i2.DxoSparklineMarginModule, typeof i2.DxoSparklineShadowModule, typeof i2.DxoSparklineSizeModule, typeof i2.DxoSparklineTooltipModule, typeof i3.DxTemplateModule]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxSparklineModule>;
}

export { DxSparklineComponent, DxSparklineModule };
//# sourceMappingURL=index.d.ts.map
