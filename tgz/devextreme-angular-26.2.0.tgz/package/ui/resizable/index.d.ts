import * as i0 from '@angular/core';
import { OnDestroy, EventEmitter, ElementRef, NgZone, TransferState } from '@angular/core';
import DxResizable, { ResizeHandle, DisposingEvent, InitializedEvent, OptionChangedEvent, ResizeEvent, ResizeEndEvent, ResizeStartEvent } from 'devextreme/ui/resizable';
import * as i1 from 'devextreme-angular/core';
import { DxComponent, DxTemplateHost, WatcherHelper, NestedOptionHost } from 'devextreme-angular/core';
import * as resizable_types from 'devextreme/ui/resizable_types';
export { resizable_types as DxResizableTypes };

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

/**
 * [descr:dxResizable]

 */
declare class DxResizableComponent extends DxComponent implements OnDestroy {
    instance: DxResizable;
    /**
     * [descr:dxResizableOptions.area]
    
     */
    get area(): any | string | undefined;
    set area(value: any | string | undefined);
    /**
     * [descr:DOMComponentOptions.elementAttr]
    
     */
    get elementAttr(): Record<string, any>;
    set elementAttr(value: Record<string, any>);
    /**
     * [descr:dxResizableOptions.handles]
    
     */
    get handles(): ResizeHandle | string;
    set handles(value: ResizeHandle | string);
    /**
     * [descr:dxResizableOptions.height]
    
     */
    get height(): number | string;
    set height(value: number | string);
    /**
     * [descr:dxResizableOptions.keepAspectRatio]
    
     */
    get keepAspectRatio(): boolean;
    set keepAspectRatio(value: boolean);
    /**
     * [descr:dxResizableOptions.maxHeight]
    
     */
    get maxHeight(): number;
    set maxHeight(value: number);
    /**
     * [descr:dxResizableOptions.maxWidth]
    
     */
    get maxWidth(): number;
    set maxWidth(value: number);
    /**
     * [descr:dxResizableOptions.minHeight]
    
     */
    get minHeight(): number;
    set minHeight(value: number);
    /**
     * [descr:dxResizableOptions.minWidth]
    
     */
    get minWidth(): number;
    set minWidth(value: number);
    /**
     * [descr:DOMComponentOptions.rtlEnabled]
    
     */
    get rtlEnabled(): boolean;
    set rtlEnabled(value: boolean);
    /**
     * [descr:dxResizableOptions.width]
    
     */
    get width(): number | string;
    set width(value: number | string);
    /**
    
     * [descr:dxResizableOptions.onDisposing]
    
    
     */
    onDisposing: EventEmitter<DisposingEvent>;
    /**
    
     * [descr:dxResizableOptions.onInitialized]
    
    
     */
    onInitialized: EventEmitter<InitializedEvent>;
    /**
    
     * [descr:dxResizableOptions.onOptionChanged]
    
    
     */
    onOptionChanged: EventEmitter<OptionChangedEvent>;
    /**
    
     * [descr:dxResizableOptions.onResize]
    
    
     */
    onResize: EventEmitter<ResizeEvent>;
    /**
    
     * [descr:dxResizableOptions.onResizeEnd]
    
    
     */
    onResizeEnd: EventEmitter<ResizeEndEvent>;
    /**
    
     * [descr:dxResizableOptions.onResizeStart]
    
    
     */
    onResizeStart: EventEmitter<ResizeStartEvent>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    areaChange: EventEmitter<any | string | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    elementAttrChange: EventEmitter<Record<string, any>>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    handlesChange: EventEmitter<ResizeHandle | string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    heightChange: EventEmitter<number | string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    keepAspectRatioChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    maxHeightChange: EventEmitter<number>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    maxWidthChange: EventEmitter<number>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    minHeightChange: EventEmitter<number>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    minWidthChange: EventEmitter<number>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    rtlEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    widthChange: EventEmitter<number | string>;
    constructor(elementRef: ElementRef, ngZone: NgZone, templateHost: DxTemplateHost, _watcherHelper: WatcherHelper, optionHost: NestedOptionHost, transferState: TransferState, platformId: any);
    protected _createInstance(element: any, options: any): DxResizable;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxResizableComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxResizableComponent, "dx-resizable", never, { "area": { "alias": "area"; "required": false; }; "elementAttr": { "alias": "elementAttr"; "required": false; }; "handles": { "alias": "handles"; "required": false; }; "height": { "alias": "height"; "required": false; }; "keepAspectRatio": { "alias": "keepAspectRatio"; "required": false; }; "maxHeight": { "alias": "maxHeight"; "required": false; }; "maxWidth": { "alias": "maxWidth"; "required": false; }; "minHeight": { "alias": "minHeight"; "required": false; }; "minWidth": { "alias": "minWidth"; "required": false; }; "rtlEnabled": { "alias": "rtlEnabled"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, { "onDisposing": "onDisposing"; "onInitialized": "onInitialized"; "onOptionChanged": "onOptionChanged"; "onResize": "onResize"; "onResizeEnd": "onResizeEnd"; "onResizeStart": "onResizeStart"; "areaChange": "areaChange"; "elementAttrChange": "elementAttrChange"; "handlesChange": "handlesChange"; "heightChange": "heightChange"; "keepAspectRatioChange": "keepAspectRatioChange"; "maxHeightChange": "maxHeightChange"; "maxWidthChange": "maxWidthChange"; "minHeightChange": "minHeightChange"; "minWidthChange": "minWidthChange"; "rtlEnabledChange": "rtlEnabledChange"; "widthChange": "widthChange"; }, never, ["*"], true, never>;
}
declare class DxResizableModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxResizableModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxResizableModule, never, [typeof DxResizableComponent, typeof i1.DxIntegrationModule, typeof i1.DxTemplateModule], [typeof DxResizableComponent, typeof i1.DxTemplateModule]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxResizableModule>;
}

export { DxResizableComponent, DxResizableModule };
//# sourceMappingURL=index.d.ts.map
