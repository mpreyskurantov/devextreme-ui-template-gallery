import * as i0 from '@angular/core';
import { OnDestroy, EventEmitter, ElementRef, NgZone, TransferState } from '@angular/core';
import { ScrollDirection } from 'devextreme/common';
import DxScrollView, { DisposingEvent, InitializedEvent, OptionChangedEvent, PullDownEvent, ReachBottomEvent, ScrollEvent, UpdatedEvent } from 'devextreme/ui/scroll_view';
import * as i1 from 'devextreme-angular/core';
import { DxComponent, DxTemplateHost, WatcherHelper, NestedOptionHost } from 'devextreme-angular/core';
import * as scroll_view_types from 'devextreme/ui/scroll_view_types';
export { scroll_view_types as DxScrollViewTypes };

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

/**
 * [descr:dxScrollView]

 */
declare class DxScrollViewComponent extends DxComponent implements OnDestroy {
    instance: DxScrollView;
    /**
     * [descr:dxScrollableOptions.bounceEnabled]
    
     */
    get bounceEnabled(): boolean;
    set bounceEnabled(value: boolean);
    /**
     * [descr:dxScrollableOptions.direction]
    
     */
    get direction(): ScrollDirection;
    set direction(value: ScrollDirection);
    /**
     * [descr:dxScrollableOptions.disabled]
    
     */
    get disabled(): boolean;
    set disabled(value: boolean);
    /**
     * [descr:DOMComponentOptions.elementAttr]
    
     */
    get elementAttr(): Record<string, any>;
    set elementAttr(value: Record<string, any>);
    /**
     * [descr:DOMComponentOptions.height]
    
     */
    get height(): number | string | undefined;
    set height(value: number | string | undefined);
    /**
     * [descr:dxScrollViewOptions.pulledDownText]
    
     */
    get pulledDownText(): string;
    set pulledDownText(value: string);
    /**
     * [descr:dxScrollViewOptions.pullingDownText]
    
     */
    get pullingDownText(): string;
    set pullingDownText(value: string);
    /**
     * [descr:dxScrollViewOptions.reachBottomText]
    
     */
    get reachBottomText(): string;
    set reachBottomText(value: string);
    /**
     * [descr:dxScrollViewOptions.refreshingText]
    
     */
    get refreshingText(): string;
    set refreshingText(value: string);
    /**
     * [descr:DOMComponentOptions.rtlEnabled]
    
     */
    get rtlEnabled(): boolean;
    set rtlEnabled(value: boolean);
    /**
     * [descr:dxScrollableOptions.scrollByContent]
    
     */
    get scrollByContent(): boolean;
    set scrollByContent(value: boolean);
    /**
     * [descr:dxScrollableOptions.scrollByThumb]
    
     */
    get scrollByThumb(): boolean;
    set scrollByThumb(value: boolean);
    /**
     * [descr:dxScrollableOptions.showScrollbar]
    
     */
    get showScrollbar(): "onScroll" | "onHover" | "always" | "never";
    set showScrollbar(value: "onScroll" | "onHover" | "always" | "never");
    /**
     * [descr:dxScrollableOptions.useNative]
    
     */
    get useNative(): boolean;
    set useNative(value: boolean);
    /**
     * [descr:DOMComponentOptions.width]
    
     */
    get width(): number | string | undefined;
    set width(value: number | string | undefined);
    /**
    
     * [descr:dxScrollViewOptions.onDisposing]
    
    
     */
    onDisposing: EventEmitter<DisposingEvent>;
    /**
    
     * [descr:dxScrollViewOptions.onInitialized]
    
    
     */
    onInitialized: EventEmitter<InitializedEvent>;
    /**
    
     * [descr:dxScrollViewOptions.onOptionChanged]
    
    
     */
    onOptionChanged: EventEmitter<OptionChangedEvent>;
    /**
    
     * [descr:dxScrollViewOptions.onPullDown]
    
    
     */
    onPullDown: EventEmitter<PullDownEvent>;
    /**
    
     * [descr:dxScrollViewOptions.onReachBottom]
    
    
     */
    onReachBottom: EventEmitter<ReachBottomEvent>;
    /**
    
     * [descr:dxScrollViewOptions.onScroll]
    
    
     */
    onScroll: EventEmitter<ScrollEvent>;
    /**
    
     * [descr:dxScrollViewOptions.onUpdated]
    
    
     */
    onUpdated: EventEmitter<UpdatedEvent>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    bounceEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    directionChange: EventEmitter<ScrollDirection>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    disabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    elementAttrChange: EventEmitter<Record<string, any>>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    heightChange: EventEmitter<number | string | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    pulledDownTextChange: EventEmitter<string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    pullingDownTextChange: EventEmitter<string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    reachBottomTextChange: EventEmitter<string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    refreshingTextChange: EventEmitter<string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    rtlEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    scrollByContentChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    scrollByThumbChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    showScrollbarChange: EventEmitter<"onScroll" | "onHover" | "always" | "never">;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    useNativeChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    widthChange: EventEmitter<number | string | undefined>;
    constructor(elementRef: ElementRef, ngZone: NgZone, templateHost: DxTemplateHost, _watcherHelper: WatcherHelper, optionHost: NestedOptionHost, transferState: TransferState, platformId: any);
    protected _createInstance(element: any, options: any): DxScrollView;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxScrollViewComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxScrollViewComponent, "dx-scroll-view", never, { "bounceEnabled": { "alias": "bounceEnabled"; "required": false; }; "direction": { "alias": "direction"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "elementAttr": { "alias": "elementAttr"; "required": false; }; "height": { "alias": "height"; "required": false; }; "pulledDownText": { "alias": "pulledDownText"; "required": false; }; "pullingDownText": { "alias": "pullingDownText"; "required": false; }; "reachBottomText": { "alias": "reachBottomText"; "required": false; }; "refreshingText": { "alias": "refreshingText"; "required": false; }; "rtlEnabled": { "alias": "rtlEnabled"; "required": false; }; "scrollByContent": { "alias": "scrollByContent"; "required": false; }; "scrollByThumb": { "alias": "scrollByThumb"; "required": false; }; "showScrollbar": { "alias": "showScrollbar"; "required": false; }; "useNative": { "alias": "useNative"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, { "onDisposing": "onDisposing"; "onInitialized": "onInitialized"; "onOptionChanged": "onOptionChanged"; "onPullDown": "onPullDown"; "onReachBottom": "onReachBottom"; "onScroll": "onScroll"; "onUpdated": "onUpdated"; "bounceEnabledChange": "bounceEnabledChange"; "directionChange": "directionChange"; "disabledChange": "disabledChange"; "elementAttrChange": "elementAttrChange"; "heightChange": "heightChange"; "pulledDownTextChange": "pulledDownTextChange"; "pullingDownTextChange": "pullingDownTextChange"; "reachBottomTextChange": "reachBottomTextChange"; "refreshingTextChange": "refreshingTextChange"; "rtlEnabledChange": "rtlEnabledChange"; "scrollByContentChange": "scrollByContentChange"; "scrollByThumbChange": "scrollByThumbChange"; "showScrollbarChange": "showScrollbarChange"; "useNativeChange": "useNativeChange"; "widthChange": "widthChange"; }, never, ["*"], true, never>;
}
declare class DxScrollViewModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxScrollViewModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxScrollViewModule, never, [typeof DxScrollViewComponent, typeof i1.DxIntegrationModule, typeof i1.DxTemplateModule], [typeof DxScrollViewComponent, typeof i1.DxTemplateModule]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxScrollViewModule>;
}

export { DxScrollViewComponent, DxScrollViewModule };
//# sourceMappingURL=index.d.ts.map
