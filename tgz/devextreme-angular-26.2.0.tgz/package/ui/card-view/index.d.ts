import * as i0 from '@angular/core';
import { OnDestroy, OnChanges, DoCheck, QueryList, EventEmitter, ElementRef, NgZone, TransferState, SimpleChanges } from '@angular/core';
import DxCardView, { CardCover, CardHeader, ColumnProperties, dxCardViewEditing, HeaderPanel, Paging, RemoteOperations, SelectionConfiguration, dxCardViewToolbar, CardClickEvent, CardDblClickEvent, CardHoverChangedEvent, CardInsertedEvent, CardInsertingEvent, CardPreparedEvent, CardRemovedEvent, CardRemovingEvent, CardUpdatedEvent, CardUpdatingEvent, ContextMenuPreparingEvent, EditCanceledEvent, EditCancelingEvent, EditingStartEvent, FieldCaptionClickEvent, FieldCaptionDblClickEvent, FieldCaptionPreparedEvent, FieldValueClickEvent, FieldValueDblClickEvent, FieldValuePreparedEvent, FocusedCardChanged, InitNewCardEvent, OptionChangedEvent, SavedEvent, SavingEvent, SelectionChangedEvent } from 'devextreme/ui/card_view';
export { ExplicitTypes } from 'devextreme/ui/card_view';
import { Mode, ScrollbarMode } from 'devextreme/common';
import { ColumnChooser, FilterPanel, HeaderFilter, Pager, SearchPanel, Sorting } from 'devextreme/common/grids';
import DataSource, { DataSourceOptions } from 'devextreme/data/data_source';
import { Store } from 'devextreme/data/store';
import { dxFilterBuilderOptions } from 'devextreme/ui/filter_builder';
import { dxLoadPanelOptions } from 'devextreme/ui/load_panel';
import { EventInfo } from 'devextreme/common/core/events';
import * as i2 from 'devextreme-angular/core';
import { DxComponent, CollectionNestedOption, DxTemplateHost, WatcherHelper, IterableDifferHelper, NestedOptionHost } from 'devextreme-angular/core';
import * as i1 from 'devextreme-angular/ui/card-view/nested';
export * from 'devextreme-angular/ui/card-view/nested';
import * as card_view_types from 'devextreme/ui/card_view_types';
export { card_view_types as DxCardViewTypes };

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxCardViewComponent<TCardData = any, TKey = any> extends DxComponent implements OnDestroy, OnChanges, DoCheck {
    private _watcherHelper;
    private _idh;
    set _validationRulesContentChildren(value: QueryList<CollectionNestedOption>);
    set _itemsContentChildren(value: QueryList<CollectionNestedOption>);
    set _changesContentChildren(value: QueryList<CollectionNestedOption>);
    set _columnsContentChildren(value: QueryList<CollectionNestedOption>);
    set _customOperationsContentChildren(value: QueryList<CollectionNestedOption>);
    set _fieldsContentChildren(value: QueryList<CollectionNestedOption>);
    set _tabsContentChildren(value: QueryList<CollectionNestedOption>);
    instance: DxCardView<TCardData, TKey>;
    get accessKey(): string | undefined;
    set accessKey(value: string | undefined);
    get activeStateEnabled(): boolean;
    set activeStateEnabled(value: boolean);
    get allowColumnReordering(): boolean;
    set allowColumnReordering(value: boolean);
    get cardContentTemplate(): any;
    set cardContentTemplate(value: any);
    get cardCover(): CardCover;
    set cardCover(value: CardCover);
    get cardFooterTemplate(): any;
    set cardFooterTemplate(value: any);
    get cardHeader(): CardHeader;
    set cardHeader(value: CardHeader);
    get cardMaxWidth(): number;
    set cardMaxWidth(value: number);
    get cardMinWidth(): number;
    set cardMinWidth(value: number);
    get cardsPerRow(): Mode | number;
    set cardsPerRow(value: Mode | number);
    get cardTemplate(): any;
    set cardTemplate(value: any);
    get columnChooser(): ColumnChooser;
    set columnChooser(value: ColumnChooser);
    get columns(): Array<ColumnProperties | string>;
    set columns(value: Array<ColumnProperties | string>);
    get dataSource(): Array<any> | DataSource | DataSourceOptions | Store | string | undefined;
    set dataSource(value: Array<any> | DataSource | DataSourceOptions | Store | string | undefined);
    get disabled(): boolean;
    set disabled(value: boolean);
    get editing(): dxCardViewEditing;
    set editing(value: dxCardViewEditing);
    get elementAttr(): Record<string, any>;
    set elementAttr(value: Record<string, any>);
    get errorRowEnabled(): boolean;
    set errorRowEnabled(value: boolean);
    get fieldHintEnabled(): boolean;
    set fieldHintEnabled(value: boolean);
    get filterBuilder(): dxFilterBuilderOptions;
    set filterBuilder(value: dxFilterBuilderOptions);
    get filterBuilderPopup(): Record<string, any>;
    set filterBuilderPopup(value: Record<string, any>);
    get filterPanel(): FilterPanel;
    set filterPanel(value: FilterPanel);
    get filterValue(): Array<any> | Function | string;
    set filterValue(value: Array<any> | Function | string);
    get focusStateEnabled(): boolean;
    set focusStateEnabled(value: boolean);
    get headerFilter(): HeaderFilter;
    set headerFilter(value: HeaderFilter);
    get headerPanel(): HeaderPanel;
    set headerPanel(value: HeaderPanel);
    get height(): number | string | undefined;
    set height(value: number | string | undefined);
    get hint(): string | undefined;
    set hint(value: string | undefined);
    get hoverStateEnabled(): boolean;
    set hoverStateEnabled(value: boolean);
    get keyExpr(): Array<string> | string | undefined;
    set keyExpr(value: Array<string> | string | undefined);
    get loadPanel(): dxLoadPanelOptions;
    set loadPanel(value: dxLoadPanelOptions);
    get noDataTemplate(): any;
    set noDataTemplate(value: any);
    get noDataText(): string;
    set noDataText(value: string);
    get pager(): Pager;
    set pager(value: Pager);
    get paging(): Paging;
    set paging(value: Paging);
    get remoteOperations(): boolean | Mode | RemoteOperations;
    set remoteOperations(value: boolean | Mode | RemoteOperations);
    get rtlEnabled(): boolean;
    set rtlEnabled(value: boolean);
    get scrolling(): {
        scrollByContent?: boolean;
        scrollByThumb?: boolean;
        showScrollbar?: ScrollbarMode;
        useNative?: boolean | Mode;
    };
    set scrolling(value: {
        scrollByContent?: boolean;
        scrollByThumb?: boolean;
        showScrollbar?: ScrollbarMode;
        useNative?: boolean | Mode;
    });
    get searchPanel(): SearchPanel;
    set searchPanel(value: SearchPanel);
    get selectedCardKeys(): Array<any>;
    set selectedCardKeys(value: Array<any>);
    get selection(): SelectionConfiguration;
    set selection(value: SelectionConfiguration);
    get sorting(): Sorting;
    set sorting(value: Sorting);
    get tabIndex(): number;
    set tabIndex(value: number);
    get toolbar(): dxCardViewToolbar;
    set toolbar(value: dxCardViewToolbar);
    get visible(): boolean;
    set visible(value: boolean);
    get width(): number | string | undefined;
    set width(value: number | string | undefined);
    get wordWrapEnabled(): boolean;
    set wordWrapEnabled(value: boolean);
    /**
    
     * [descr:undefined]
    
    
     */
    onCardClick: EventEmitter<CardClickEvent>;
    /**
    
     * [descr:undefined]
    
    
     */
    onCardDblClick: EventEmitter<CardDblClickEvent>;
    /**
    
     * [descr:undefined]
    
    
     */
    onCardHoverChanged: EventEmitter<CardHoverChangedEvent>;
    /**
    
     * [descr:undefined]
    
    
     */
    onCardInserted: EventEmitter<CardInsertedEvent>;
    /**
    
     * [descr:undefined]
    
    
     */
    onCardInserting: EventEmitter<CardInsertingEvent>;
    /**
    
     * [descr:undefined]
    
    
     */
    onCardPrepared: EventEmitter<CardPreparedEvent>;
    /**
    
     * [descr:undefined]
    
    
     */
    onCardRemoved: EventEmitter<CardRemovedEvent>;
    /**
    
     * [descr:undefined]
    
    
     */
    onCardRemoving: EventEmitter<CardRemovingEvent>;
    /**
    
     * [descr:undefined]
    
    
     */
    onCardUpdated: EventEmitter<CardUpdatedEvent>;
    /**
    
     * [descr:undefined]
    
    
     */
    onCardUpdating: EventEmitter<CardUpdatingEvent>;
    /**
    
     * [descr:undefined]
    
    
     */
    onContentReady: EventEmitter<EventInfo<any>>;
    /**
    
     * [descr:undefined]
    
    
     */
    onContextMenuPreparing: EventEmitter<ContextMenuPreparingEvent>;
    /**
    
     * [descr:undefined]
    
    
     */
    onDataErrorOccurred: EventEmitter<Object>;
    /**
    
     * [descr:undefined]
    
    
     */
    onDisposing: EventEmitter<EventInfo<any>>;
    /**
    
     * [descr:undefined]
    
    
     */
    onEditCanceled: EventEmitter<EditCanceledEvent>;
    /**
    
     * [descr:undefined]
    
    
     */
    onEditCanceling: EventEmitter<EditCancelingEvent>;
    /**
    
     * [descr:undefined]
    
    
     */
    onEditingStart: EventEmitter<EditingStartEvent>;
    /**
    
     * [descr:undefined]
    
    
     */
    onFieldCaptionClick: EventEmitter<FieldCaptionClickEvent>;
    /**
    
     * [descr:undefined]
    
    
     */
    onFieldCaptionDblClick: EventEmitter<FieldCaptionDblClickEvent>;
    /**
    
     * [descr:undefined]
    
    
     */
    onFieldCaptionPrepared: EventEmitter<FieldCaptionPreparedEvent>;
    /**
    
     * [descr:undefined]
    
    
     */
    onFieldValueClick: EventEmitter<FieldValueClickEvent>;
    /**
    
     * [descr:undefined]
    
    
     */
    onFieldValueDblClick: EventEmitter<FieldValueDblClickEvent>;
    /**
    
     * [descr:undefined]
    
    
     */
    onFieldValuePrepared: EventEmitter<FieldValuePreparedEvent>;
    /**
    
     * [descr:undefined]
    
    
     */
    onFocusedCardChanged: EventEmitter<FocusedCardChanged>;
    /**
    
     * [descr:undefined]
    
    
     */
    onInitialized: EventEmitter<Object>;
    /**
    
     * [descr:undefined]
    
    
     */
    onInitNewCard: EventEmitter<InitNewCardEvent>;
    /**
    
     * [descr:undefined]
    
    
     */
    onOptionChanged: EventEmitter<OptionChangedEvent>;
    /**
    
     * [descr:undefined]
    
    
     */
    onSaved: EventEmitter<SavedEvent>;
    /**
    
     * [descr:undefined]
    
    
     */
    onSaving: EventEmitter<SavingEvent>;
    /**
    
     * [descr:undefined]
    
    
     */
    onSelectionChanged: EventEmitter<SelectionChangedEvent>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    accessKeyChange: EventEmitter<string | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    activeStateEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    allowColumnReorderingChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    cardContentTemplateChange: EventEmitter<any>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    cardCoverChange: EventEmitter<CardCover>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    cardFooterTemplateChange: EventEmitter<any>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    cardHeaderChange: EventEmitter<CardHeader>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    cardMaxWidthChange: EventEmitter<number>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    cardMinWidthChange: EventEmitter<number>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    cardsPerRowChange: EventEmitter<Mode | number>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    cardTemplateChange: EventEmitter<any>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    columnChooserChange: EventEmitter<ColumnChooser>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    columnsChange: EventEmitter<Array<ColumnProperties | string>>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    dataSourceChange: EventEmitter<Array<any> | DataSource | DataSourceOptions | Store | string | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    disabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    editingChange: EventEmitter<dxCardViewEditing>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    elementAttrChange: EventEmitter<Record<string, any>>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    errorRowEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    fieldHintEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    filterBuilderChange: EventEmitter<dxFilterBuilderOptions>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    filterBuilderPopupChange: EventEmitter<Record<string, any>>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    filterPanelChange: EventEmitter<FilterPanel>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    filterValueChange: EventEmitter<Array<any> | Function | string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    focusStateEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    headerFilterChange: EventEmitter<HeaderFilter>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    headerPanelChange: EventEmitter<HeaderPanel>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    heightChange: EventEmitter<number | string | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    hintChange: EventEmitter<string | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    hoverStateEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    keyExprChange: EventEmitter<Array<string> | string | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    loadPanelChange: EventEmitter<dxLoadPanelOptions>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    noDataTemplateChange: EventEmitter<any>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    noDataTextChange: EventEmitter<string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    pagerChange: EventEmitter<Pager>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    pagingChange: EventEmitter<Paging>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    remoteOperationsChange: EventEmitter<boolean | Mode | RemoteOperations>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    rtlEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    scrollingChange: EventEmitter<{
        scrollByContent?: boolean;
        scrollByThumb?: boolean;
        showScrollbar?: ScrollbarMode;
        useNative?: boolean | Mode;
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    searchPanelChange: EventEmitter<SearchPanel>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    selectedCardKeysChange: EventEmitter<Array<any>>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    selectionChange: EventEmitter<SelectionConfiguration>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    sortingChange: EventEmitter<Sorting>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    tabIndexChange: EventEmitter<number>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    toolbarChange: EventEmitter<dxCardViewToolbar>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    visibleChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    widthChange: EventEmitter<number | string | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    wordWrapEnabledChange: EventEmitter<boolean>;
    constructor(elementRef: ElementRef, ngZone: NgZone, templateHost: DxTemplateHost, _watcherHelper: WatcherHelper, _idh: IterableDifferHelper, optionHost: NestedOptionHost, transferState: TransferState, platformId: any);
    protected _createInstance(element: any, options: any): DxCardView<unknown, unknown>;
    ngOnDestroy(): void;
    ngOnChanges(changes: SimpleChanges): void;
    setupChanges(prop: string, changes: SimpleChanges): void;
    ngDoCheck(): void;
    _setOption(name: string, value: any): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxCardViewComponent<any, any>, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxCardViewComponent<any, any>, "dx-card-view", never, { "accessKey": { "alias": "accessKey"; "required": false; }; "activeStateEnabled": { "alias": "activeStateEnabled"; "required": false; }; "allowColumnReordering": { "alias": "allowColumnReordering"; "required": false; }; "cardContentTemplate": { "alias": "cardContentTemplate"; "required": false; }; "cardCover": { "alias": "cardCover"; "required": false; }; "cardFooterTemplate": { "alias": "cardFooterTemplate"; "required": false; }; "cardHeader": { "alias": "cardHeader"; "required": false; }; "cardMaxWidth": { "alias": "cardMaxWidth"; "required": false; }; "cardMinWidth": { "alias": "cardMinWidth"; "required": false; }; "cardsPerRow": { "alias": "cardsPerRow"; "required": false; }; "cardTemplate": { "alias": "cardTemplate"; "required": false; }; "columnChooser": { "alias": "columnChooser"; "required": false; }; "columns": { "alias": "columns"; "required": false; }; "dataSource": { "alias": "dataSource"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "editing": { "alias": "editing"; "required": false; }; "elementAttr": { "alias": "elementAttr"; "required": false; }; "errorRowEnabled": { "alias": "errorRowEnabled"; "required": false; }; "fieldHintEnabled": { "alias": "fieldHintEnabled"; "required": false; }; "filterBuilder": { "alias": "filterBuilder"; "required": false; }; "filterBuilderPopup": { "alias": "filterBuilderPopup"; "required": false; }; "filterPanel": { "alias": "filterPanel"; "required": false; }; "filterValue": { "alias": "filterValue"; "required": false; }; "focusStateEnabled": { "alias": "focusStateEnabled"; "required": false; }; "headerFilter": { "alias": "headerFilter"; "required": false; }; "headerPanel": { "alias": "headerPanel"; "required": false; }; "height": { "alias": "height"; "required": false; }; "hint": { "alias": "hint"; "required": false; }; "hoverStateEnabled": { "alias": "hoverStateEnabled"; "required": false; }; "keyExpr": { "alias": "keyExpr"; "required": false; }; "loadPanel": { "alias": "loadPanel"; "required": false; }; "noDataTemplate": { "alias": "noDataTemplate"; "required": false; }; "noDataText": { "alias": "noDataText"; "required": false; }; "pager": { "alias": "pager"; "required": false; }; "paging": { "alias": "paging"; "required": false; }; "remoteOperations": { "alias": "remoteOperations"; "required": false; }; "rtlEnabled": { "alias": "rtlEnabled"; "required": false; }; "scrolling": { "alias": "scrolling"; "required": false; }; "searchPanel": { "alias": "searchPanel"; "required": false; }; "selectedCardKeys": { "alias": "selectedCardKeys"; "required": false; }; "selection": { "alias": "selection"; "required": false; }; "sorting": { "alias": "sorting"; "required": false; }; "tabIndex": { "alias": "tabIndex"; "required": false; }; "toolbar": { "alias": "toolbar"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; "wordWrapEnabled": { "alias": "wordWrapEnabled"; "required": false; }; }, { "onCardClick": "onCardClick"; "onCardDblClick": "onCardDblClick"; "onCardHoverChanged": "onCardHoverChanged"; "onCardInserted": "onCardInserted"; "onCardInserting": "onCardInserting"; "onCardPrepared": "onCardPrepared"; "onCardRemoved": "onCardRemoved"; "onCardRemoving": "onCardRemoving"; "onCardUpdated": "onCardUpdated"; "onCardUpdating": "onCardUpdating"; "onContentReady": "onContentReady"; "onContextMenuPreparing": "onContextMenuPreparing"; "onDataErrorOccurred": "onDataErrorOccurred"; "onDisposing": "onDisposing"; "onEditCanceled": "onEditCanceled"; "onEditCanceling": "onEditCanceling"; "onEditingStart": "onEditingStart"; "onFieldCaptionClick": "onFieldCaptionClick"; "onFieldCaptionDblClick": "onFieldCaptionDblClick"; "onFieldCaptionPrepared": "onFieldCaptionPrepared"; "onFieldValueClick": "onFieldValueClick"; "onFieldValueDblClick": "onFieldValueDblClick"; "onFieldValuePrepared": "onFieldValuePrepared"; "onFocusedCardChanged": "onFocusedCardChanged"; "onInitialized": "onInitialized"; "onInitNewCard": "onInitNewCard"; "onOptionChanged": "onOptionChanged"; "onSaved": "onSaved"; "onSaving": "onSaving"; "onSelectionChanged": "onSelectionChanged"; "accessKeyChange": "accessKeyChange"; "activeStateEnabledChange": "activeStateEnabledChange"; "allowColumnReorderingChange": "allowColumnReorderingChange"; "cardContentTemplateChange": "cardContentTemplateChange"; "cardCoverChange": "cardCoverChange"; "cardFooterTemplateChange": "cardFooterTemplateChange"; "cardHeaderChange": "cardHeaderChange"; "cardMaxWidthChange": "cardMaxWidthChange"; "cardMinWidthChange": "cardMinWidthChange"; "cardsPerRowChange": "cardsPerRowChange"; "cardTemplateChange": "cardTemplateChange"; "columnChooserChange": "columnChooserChange"; "columnsChange": "columnsChange"; "dataSourceChange": "dataSourceChange"; "disabledChange": "disabledChange"; "editingChange": "editingChange"; "elementAttrChange": "elementAttrChange"; "errorRowEnabledChange": "errorRowEnabledChange"; "fieldHintEnabledChange": "fieldHintEnabledChange"; "filterBuilderChange": "filterBuilderChange"; "filterBuilderPopupChange": "filterBuilderPopupChange"; "filterPanelChange": "filterPanelChange"; "filterValueChange": "filterValueChange"; "focusStateEnabledChange": "focusStateEnabledChange"; "headerFilterChange": "headerFilterChange"; "headerPanelChange": "headerPanelChange"; "heightChange": "heightChange"; "hintChange": "hintChange"; "hoverStateEnabledChange": "hoverStateEnabledChange"; "keyExprChange": "keyExprChange"; "loadPanelChange": "loadPanelChange"; "noDataTemplateChange": "noDataTemplateChange"; "noDataTextChange": "noDataTextChange"; "pagerChange": "pagerChange"; "pagingChange": "pagingChange"; "remoteOperationsChange": "remoteOperationsChange"; "rtlEnabledChange": "rtlEnabledChange"; "scrollingChange": "scrollingChange"; "searchPanelChange": "searchPanelChange"; "selectedCardKeysChange": "selectedCardKeysChange"; "selectionChange": "selectionChange"; "sortingChange": "sortingChange"; "tabIndexChange": "tabIndexChange"; "toolbarChange": "toolbarChange"; "visibleChange": "visibleChange"; "widthChange": "widthChange"; "wordWrapEnabledChange": "wordWrapEnabledChange"; }, ["_validationRulesContentChildren", "_itemsContentChildren", "_changesContentChildren", "_columnsContentChildren", "_customOperationsContentChildren", "_fieldsContentChildren", "_tabsContentChildren"], never, true, never>;
}
declare class DxCardViewModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxCardViewModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxCardViewModule, never, [typeof DxCardViewComponent, typeof i1.DxoCardViewAIOptionsModule, typeof i1.DxoCardViewAnimationModule, typeof i1.DxiCardViewAsyncRuleModule, typeof i1.DxoCardViewAtModule, typeof i1.DxoCardViewBoundaryOffsetModule, typeof i1.DxiCardViewButtonItemModule, typeof i1.DxoCardViewButtonOptionsModule, typeof i1.DxoCardViewCardCoverModule, typeof i1.DxoCardViewCardHeaderModule, typeof i1.DxiCardViewCardHeaderItemModule, typeof i1.DxoCardViewCardViewHeaderFilterModule, typeof i1.DxoCardViewCardViewHeaderFilterSearchModule, typeof i1.DxoCardViewCardViewHeaderFilterTextsModule, typeof i1.DxoCardViewCardViewSelectionModule, typeof i1.DxiCardViewChangeModule, typeof i1.DxoCardViewColCountByScreenModule, typeof i1.DxoCardViewCollisionModule, typeof i1.DxiCardViewColumnModule, typeof i1.DxoCardViewColumnChooserModule, typeof i1.DxoCardViewColumnChooserSearchModule, typeof i1.DxoCardViewColumnChooserSelectionModule, typeof i1.DxoCardViewColumnHeaderFilterModule, typeof i1.DxoCardViewColumnHeaderFilterSearchModule, typeof i1.DxiCardViewCompareRuleModule, typeof i1.DxiCardViewCustomOperationModule, typeof i1.DxiCardViewCustomRuleModule, typeof i1.DxoCardViewDraggingModule, typeof i1.DxoCardViewEditingModule, typeof i1.DxoCardViewEditingTextsModule, typeof i1.DxiCardViewEmailRuleModule, typeof i1.DxiCardViewEmptyItemModule, typeof i1.DxiCardViewFieldModule, typeof i1.DxoCardViewFilterBuilderModule, typeof i1.DxoCardViewFilterOperationDescriptionsModule, typeof i1.DxoCardViewFilterPanelModule, typeof i1.DxoCardViewFilterPanelTextsModule, typeof i1.DxoCardViewFormModule, typeof i1.DxoCardViewFormatModule, typeof i1.DxoCardViewFormItemModule, typeof i1.DxoCardViewFromModule, typeof i1.DxiCardViewGroupItemModule, typeof i1.DxoCardViewGroupOperationDescriptionsModule, typeof i1.DxoCardViewHeaderFilterModule, typeof i1.DxoCardViewHeaderPanelModule, typeof i1.DxoCardViewHideModule, typeof i1.DxoCardViewIndicatorOptionsModule, typeof i1.DxiCardViewItemModule, typeof i1.DxoCardViewLabelModule, typeof i1.DxoCardViewLoadPanelModule, typeof i1.DxoCardViewLookupModule, typeof i1.DxoCardViewMyModule, typeof i1.DxiCardViewNumericRuleModule, typeof i1.DxoCardViewOffsetModule, typeof i1.DxoCardViewPagerModule, typeof i1.DxoCardViewPagingModule, typeof i1.DxiCardViewPatternRuleModule, typeof i1.DxoCardViewPositionModule, typeof i1.DxiCardViewRangeRuleModule, typeof i1.DxoCardViewRemoteOperationsModule, typeof i1.DxiCardViewRequiredRuleModule, typeof i1.DxoCardViewScrollingModule, typeof i1.DxoCardViewSearchModule, typeof i1.DxoCardViewSearchPanelModule, typeof i1.DxoCardViewSelectionModule, typeof i1.DxoCardViewShowModule, typeof i1.DxiCardViewSimpleItemModule, typeof i1.DxoCardViewSortingModule, typeof i1.DxiCardViewStringLengthRuleModule, typeof i1.DxiCardViewTabModule, typeof i1.DxiCardViewTabbedItemModule, typeof i1.DxoCardViewTabPanelOptionsModule, typeof i1.DxiCardViewTabPanelOptionsItemModule, typeof i1.DxoCardViewTextsModule, typeof i1.DxoCardViewToModule, typeof i1.DxoCardViewToolbarModule, typeof i1.DxiCardViewToolbarItemModule, typeof i1.DxiCardViewValidationRuleModule, typeof i2.DxIntegrationModule, typeof i2.DxTemplateModule], [typeof DxCardViewComponent, typeof i1.DxoCardViewAIOptionsModule, typeof i1.DxoCardViewAnimationModule, typeof i1.DxiCardViewAsyncRuleModule, typeof i1.DxoCardViewAtModule, typeof i1.DxoCardViewBoundaryOffsetModule, typeof i1.DxiCardViewButtonItemModule, typeof i1.DxoCardViewButtonOptionsModule, typeof i1.DxoCardViewCardCoverModule, typeof i1.DxoCardViewCardHeaderModule, typeof i1.DxiCardViewCardHeaderItemModule, typeof i1.DxoCardViewCardViewHeaderFilterModule, typeof i1.DxoCardViewCardViewHeaderFilterSearchModule, typeof i1.DxoCardViewCardViewHeaderFilterTextsModule, typeof i1.DxoCardViewCardViewSelectionModule, typeof i1.DxiCardViewChangeModule, typeof i1.DxoCardViewColCountByScreenModule, typeof i1.DxoCardViewCollisionModule, typeof i1.DxiCardViewColumnModule, typeof i1.DxoCardViewColumnChooserModule, typeof i1.DxoCardViewColumnChooserSearchModule, typeof i1.DxoCardViewColumnChooserSelectionModule, typeof i1.DxoCardViewColumnHeaderFilterModule, typeof i1.DxoCardViewColumnHeaderFilterSearchModule, typeof i1.DxiCardViewCompareRuleModule, typeof i1.DxiCardViewCustomOperationModule, typeof i1.DxiCardViewCustomRuleModule, typeof i1.DxoCardViewDraggingModule, typeof i1.DxoCardViewEditingModule, typeof i1.DxoCardViewEditingTextsModule, typeof i1.DxiCardViewEmailRuleModule, typeof i1.DxiCardViewEmptyItemModule, typeof i1.DxiCardViewFieldModule, typeof i1.DxoCardViewFilterBuilderModule, typeof i1.DxoCardViewFilterOperationDescriptionsModule, typeof i1.DxoCardViewFilterPanelModule, typeof i1.DxoCardViewFilterPanelTextsModule, typeof i1.DxoCardViewFormModule, typeof i1.DxoCardViewFormatModule, typeof i1.DxoCardViewFormItemModule, typeof i1.DxoCardViewFromModule, typeof i1.DxiCardViewGroupItemModule, typeof i1.DxoCardViewGroupOperationDescriptionsModule, typeof i1.DxoCardViewHeaderFilterModule, typeof i1.DxoCardViewHeaderPanelModule, typeof i1.DxoCardViewHideModule, typeof i1.DxoCardViewIndicatorOptionsModule, typeof i1.DxiCardViewItemModule, typeof i1.DxoCardViewLabelModule, typeof i1.DxoCardViewLoadPanelModule, typeof i1.DxoCardViewLookupModule, typeof i1.DxoCardViewMyModule, typeof i1.DxiCardViewNumericRuleModule, typeof i1.DxoCardViewOffsetModule, typeof i1.DxoCardViewPagerModule, typeof i1.DxoCardViewPagingModule, typeof i1.DxiCardViewPatternRuleModule, typeof i1.DxoCardViewPositionModule, typeof i1.DxiCardViewRangeRuleModule, typeof i1.DxoCardViewRemoteOperationsModule, typeof i1.DxiCardViewRequiredRuleModule, typeof i1.DxoCardViewScrollingModule, typeof i1.DxoCardViewSearchModule, typeof i1.DxoCardViewSearchPanelModule, typeof i1.DxoCardViewSelectionModule, typeof i1.DxoCardViewShowModule, typeof i1.DxiCardViewSimpleItemModule, typeof i1.DxoCardViewSortingModule, typeof i1.DxiCardViewStringLengthRuleModule, typeof i1.DxiCardViewTabModule, typeof i1.DxiCardViewTabbedItemModule, typeof i1.DxoCardViewTabPanelOptionsModule, typeof i1.DxiCardViewTabPanelOptionsItemModule, typeof i1.DxoCardViewTextsModule, typeof i1.DxoCardViewToModule, typeof i1.DxoCardViewToolbarModule, typeof i1.DxiCardViewToolbarItemModule, typeof i1.DxiCardViewValidationRuleModule, typeof i2.DxTemplateModule]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxCardViewModule>;
}

export { DxCardViewComponent, DxCardViewModule };
//# sourceMappingURL=index.d.ts.map
