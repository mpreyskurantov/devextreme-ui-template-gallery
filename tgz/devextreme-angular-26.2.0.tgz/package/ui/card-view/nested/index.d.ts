import * as i0 from '@angular/core';
import { OnDestroy, OnInit, AfterViewInit, Renderer2, ElementRef, QueryList, EventEmitter } from '@angular/core';
import { NestedOption, NestedOptionHost, CollectionNestedOption, IDxTemplateHost, DxTemplateHost, DxTemplateDirective } from 'devextreme-angular/core';
import { AnimationConfig, CollisionResolution, PositionConfig, AnimationState, AnimationType, CollisionResolutionCombination } from 'devextreme/common/core/animation';
import * as CommonTypes from 'devextreme/common';
import { ValidationRuleType, HorizontalAlignment, VerticalAlignment, ButtonStyle, ButtonType, ToolbarItemLocation, ToolbarItemComponent, SearchMode, SingleMultipleOrNone, SelectAllMode, SortOrder, DataType, ComparisonOperator, DragHighlight, Mode, Format as Format$1, Direction, PositionAlignment, DisplayMode, ScrollbarMode, TabsIconPosition, TabsStyle, Position } from 'devextreme/common';
import { dxButtonOptions, ClickEvent, ContentReadyEvent, DisposingEvent, InitializedEvent, OptionChangedEvent } from 'devextreme/ui/button';
import { FormItemType, FormPredefinedButtonItem, dxFormSimpleItem, dxFormOptions, FormItemComponent, LabelLocation, dxFormGroupItem, dxFormTabbedItem, dxFormEmptyItem, dxFormButtonItem, FormLabelMode, ContentReadyEvent as ContentReadyEvent$2, DisposingEvent as DisposingEvent$2, EditorEnterKeyEvent, FieldDataChangedEvent, InitializedEvent as InitializedEvent$2, OptionChangedEvent as OptionChangedEvent$2, SmartPastedEvent, SmartPastingEvent } from 'devextreme/ui/form';
import { LocateInMenuMode, ShowTextMode } from 'devextreme/ui/toolbar';
import { CardHeaderPredefinedItem, CardHeaderItem, EditingTexts, PredefinedToolbarItem, dxCardViewToolbarItem } from 'devextreme/ui/card_view';
import { HeaderFilterSearchConfig, HeaderFilterTexts, SelectionColumnDisplayMode, DataChangeType, ColumnChooserMode, ColumnChooserSearchConfig, ColumnChooserSelectionConfig, FilterType, ColumnHeaderFilter, HeaderFilterGroupInterval, ColumnHeaderFilterSearchConfig, DataChange, FilterPanel, FilterPanelTexts, PagerPageSize } from 'devextreme/common/grids';
import { Format } from 'devextreme/common/core/localization';
import DataSource, { DataSourceOptions } from 'devextreme/data/data_source';
import { Store } from 'devextreme/data/store';
import { dxFilterBuilderField, FieldInfo, FilterBuilderOperation, dxFilterBuilderCustomOperation, GroupOperation, ContentReadyEvent as ContentReadyEvent$1, DisposingEvent as DisposingEvent$1, EditorPreparedEvent, EditorPreparingEvent, InitializedEvent as InitializedEvent$1, OptionChangedEvent as OptionChangedEvent$1, ValueChangedEvent } from 'devextreme/ui/filter_builder';
import { AIIntegration } from 'devextreme/common/ai-integration';
import { LoadingAnimationType } from 'devextreme/ui/load_indicator';
import { dxTabPanelOptions, dxTabPanelItem, ContentReadyEvent as ContentReadyEvent$4, DisposingEvent as DisposingEvent$4, InitializedEvent as InitializedEvent$4, ItemClickEvent, ItemContextMenuEvent, ItemHoldEvent, ItemRenderedEvent, OptionChangedEvent as OptionChangedEvent$4, SelectionChangedEvent, SelectionChangingEvent, TitleClickEvent, TitleHoldEvent, TitleRenderedEvent } from 'devextreme/ui/tab_panel';
import { event } from 'devextreme/events/events.types';
import { LoadPanelIndicatorProperties, ContentReadyEvent as ContentReadyEvent$3, DisposingEvent as DisposingEvent$3, HiddenEvent, HidingEvent, InitializedEvent as InitializedEvent$3, OptionChangedEvent as OptionChangedEvent$3, ShowingEvent, ShownEvent } from 'devextreme/ui/load_panel';

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoCardViewAIOptionsComponent extends NestedOption implements OnDestroy, OnInit {
    get disabled(): boolean;
    set disabled(value: boolean);
    get instruction(): string | undefined;
    set instruction(value: string | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoCardViewAIOptionsComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoCardViewAIOptionsComponent, "dxo-card-view-ai-options", never, { "disabled": { "alias": "disabled"; "required": false; }; "instruction": { "alias": "instruction"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoCardViewAIOptionsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoCardViewAIOptionsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoCardViewAIOptionsModule, never, [typeof DxoCardViewAIOptionsComponent], [typeof DxoCardViewAIOptionsComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoCardViewAIOptionsModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoCardViewAnimationComponent extends NestedOption implements OnDestroy, OnInit {
    get hide(): AnimationConfig;
    set hide(value: AnimationConfig);
    get show(): AnimationConfig;
    set show(value: AnimationConfig);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoCardViewAnimationComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoCardViewAnimationComponent, "dxo-card-view-animation", never, { "hide": { "alias": "hide"; "required": false; }; "show": { "alias": "show"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoCardViewAnimationModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoCardViewAnimationModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoCardViewAnimationModule, never, [typeof DxoCardViewAnimationComponent], [typeof DxoCardViewAnimationComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoCardViewAnimationModule>;
}

declare class DxiCardViewAsyncRuleComponent extends CollectionNestedOption {
    get ignoreEmptyValue(): boolean;
    set ignoreEmptyValue(value: boolean);
    get message(): string;
    set message(value: string);
    get reevaluate(): boolean;
    set reevaluate(value: boolean);
    get type(): ValidationRuleType;
    set type(value: ValidationRuleType);
    get validationCallback(): ((options: {
        column: Record<string, any>;
        data: Record<string, any>;
        formItem: Record<string, any>;
        rule: Record<string, any>;
        validator: Record<string, any>;
        value: any;
    }) => any);
    set validationCallback(value: ((options: {
        column: Record<string, any>;
        data: Record<string, any>;
        formItem: Record<string, any>;
        rule: Record<string, any>;
        validator: Record<string, any>;
        value: any;
    }) => any));
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiCardViewAsyncRuleComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiCardViewAsyncRuleComponent, "dxi-card-view-async-rule", never, { "ignoreEmptyValue": { "alias": "ignoreEmptyValue"; "required": false; }; "message": { "alias": "message"; "required": false; }; "reevaluate": { "alias": "reevaluate"; "required": false; }; "type": { "alias": "type"; "required": false; }; "validationCallback": { "alias": "validationCallback"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxiCardViewAsyncRuleModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiCardViewAsyncRuleModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiCardViewAsyncRuleModule, never, [typeof DxiCardViewAsyncRuleComponent], [typeof DxiCardViewAsyncRuleComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiCardViewAsyncRuleModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoCardViewAtComponent extends NestedOption implements OnDestroy, OnInit {
    get x(): HorizontalAlignment;
    set x(value: HorizontalAlignment);
    get y(): VerticalAlignment;
    set y(value: VerticalAlignment);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoCardViewAtComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoCardViewAtComponent, "dxo-card-view-at", never, { "x": { "alias": "x"; "required": false; }; "y": { "alias": "y"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoCardViewAtModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoCardViewAtModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoCardViewAtModule, never, [typeof DxoCardViewAtComponent], [typeof DxoCardViewAtComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoCardViewAtModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoCardViewBoundaryOffsetComponent extends NestedOption implements OnDestroy, OnInit {
    get x(): number;
    set x(value: number);
    get y(): number;
    set y(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoCardViewBoundaryOffsetComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoCardViewBoundaryOffsetComponent, "dxo-card-view-boundary-offset", never, { "x": { "alias": "x"; "required": false; }; "y": { "alias": "y"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoCardViewBoundaryOffsetModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoCardViewBoundaryOffsetModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoCardViewBoundaryOffsetModule, never, [typeof DxoCardViewBoundaryOffsetComponent], [typeof DxoCardViewBoundaryOffsetComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoCardViewBoundaryOffsetModule>;
}

declare class DxiCardViewButtonItemComponent extends CollectionNestedOption {
    get buttonOptions(): dxButtonOptions | undefined;
    set buttonOptions(value: dxButtonOptions | undefined);
    get colSpan(): number | undefined;
    set colSpan(value: number | undefined);
    get cssClass(): string | undefined;
    set cssClass(value: string | undefined);
    get horizontalAlignment(): HorizontalAlignment;
    set horizontalAlignment(value: HorizontalAlignment);
    get itemType(): FormItemType;
    set itemType(value: FormItemType);
    get name(): FormPredefinedButtonItem | string | undefined;
    set name(value: FormPredefinedButtonItem | string | undefined);
    get verticalAlignment(): VerticalAlignment;
    set verticalAlignment(value: VerticalAlignment);
    get visible(): boolean;
    set visible(value: boolean);
    get visibleIndex(): number | undefined;
    set visibleIndex(value: number | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiCardViewButtonItemComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiCardViewButtonItemComponent, "dxi-card-view-button-item", never, { "buttonOptions": { "alias": "buttonOptions"; "required": false; }; "colSpan": { "alias": "colSpan"; "required": false; }; "cssClass": { "alias": "cssClass"; "required": false; }; "horizontalAlignment": { "alias": "horizontalAlignment"; "required": false; }; "itemType": { "alias": "itemType"; "required": false; }; "name": { "alias": "name"; "required": false; }; "verticalAlignment": { "alias": "verticalAlignment"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "visibleIndex": { "alias": "visibleIndex"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxiCardViewButtonItemModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiCardViewButtonItemModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiCardViewButtonItemModule, never, [typeof DxiCardViewButtonItemComponent], [typeof DxiCardViewButtonItemComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiCardViewButtonItemModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoCardViewButtonOptionsComponent extends NestedOption implements AfterViewInit, OnDestroy, OnInit, IDxTemplateHost {
    private renderer;
    private document;
    private element;
    get accessKey(): string | undefined;
    set accessKey(value: string | undefined);
    get activeStateEnabled(): boolean;
    set activeStateEnabled(value: boolean);
    get disabled(): boolean;
    set disabled(value: boolean);
    get elementAttr(): Record<string, any>;
    set elementAttr(value: Record<string, any>);
    get focusStateEnabled(): boolean;
    set focusStateEnabled(value: boolean);
    get height(): number | string | undefined;
    set height(value: number | string | undefined);
    get hint(): string | undefined;
    set hint(value: string | undefined);
    get hoverStateEnabled(): boolean;
    set hoverStateEnabled(value: boolean);
    get icon(): string;
    set icon(value: string);
    get onClick(): ((e: ClickEvent) => void) | undefined;
    set onClick(value: ((e: ClickEvent) => void) | undefined);
    get onContentReady(): ((e: ContentReadyEvent) => void);
    set onContentReady(value: ((e: ContentReadyEvent) => void));
    get onDisposing(): ((e: DisposingEvent) => void);
    set onDisposing(value: ((e: DisposingEvent) => void));
    get onInitialized(): ((e: InitializedEvent) => void);
    set onInitialized(value: ((e: InitializedEvent) => void));
    get onOptionChanged(): ((e: OptionChangedEvent) => void);
    set onOptionChanged(value: ((e: OptionChangedEvent) => void));
    get rtlEnabled(): boolean;
    set rtlEnabled(value: boolean);
    get stylingMode(): ButtonStyle;
    set stylingMode(value: ButtonStyle);
    get tabIndex(): number;
    set tabIndex(value: number);
    get template(): any;
    set template(value: any);
    get text(): string;
    set text(value: string);
    get type(): ButtonType | string;
    set type(value: ButtonType | string);
    get useSubmitBehavior(): boolean;
    set useSubmitBehavior(value: boolean);
    get validationGroup(): string | undefined;
    set validationGroup(value: string | undefined);
    get visible(): boolean;
    set visible(value: boolean);
    get width(): number | string | undefined;
    set width(value: number | string | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost, renderer: Renderer2, document: any, templateHost: DxTemplateHost, element: ElementRef);
    setTemplate(template: DxTemplateDirective): void;
    ngAfterViewInit(): void;
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoCardViewButtonOptionsComponent, [{ host: true; skipSelf: true; }, { host: true; }, null, null, { host: true; }, null]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoCardViewButtonOptionsComponent, "dxo-card-view-button-options", never, { "accessKey": { "alias": "accessKey"; "required": false; }; "activeStateEnabled": { "alias": "activeStateEnabled"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "elementAttr": { "alias": "elementAttr"; "required": false; }; "focusStateEnabled": { "alias": "focusStateEnabled"; "required": false; }; "height": { "alias": "height"; "required": false; }; "hint": { "alias": "hint"; "required": false; }; "hoverStateEnabled": { "alias": "hoverStateEnabled"; "required": false; }; "icon": { "alias": "icon"; "required": false; }; "onClick": { "alias": "onClick"; "required": false; }; "onContentReady": { "alias": "onContentReady"; "required": false; }; "onDisposing": { "alias": "onDisposing"; "required": false; }; "onInitialized": { "alias": "onInitialized"; "required": false; }; "onOptionChanged": { "alias": "onOptionChanged"; "required": false; }; "rtlEnabled": { "alias": "rtlEnabled"; "required": false; }; "stylingMode": { "alias": "stylingMode"; "required": false; }; "tabIndex": { "alias": "tabIndex"; "required": false; }; "template": { "alias": "template"; "required": false; }; "text": { "alias": "text"; "required": false; }; "type": { "alias": "type"; "required": false; }; "useSubmitBehavior": { "alias": "useSubmitBehavior"; "required": false; }; "validationGroup": { "alias": "validationGroup"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, ["*"], true, never>;
}
declare class DxoCardViewButtonOptionsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoCardViewButtonOptionsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoCardViewButtonOptionsModule, never, [typeof DxoCardViewButtonOptionsComponent], [typeof DxoCardViewButtonOptionsComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoCardViewButtonOptionsModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoCardViewCardCoverComponent extends NestedOption implements AfterViewInit, OnDestroy, OnInit, IDxTemplateHost {
    private renderer;
    private document;
    private element;
    get altExpr(): ((data: any) => string) | string;
    set altExpr(value: ((data: any) => string) | string);
    get aspectRatio(): string;
    set aspectRatio(value: string);
    get imageExpr(): ((data: any) => string) | string;
    set imageExpr(value: ((data: any) => string) | string);
    get maxHeight(): number;
    set maxHeight(value: number);
    get template(): any;
    set template(value: any);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost, renderer: Renderer2, document: any, templateHost: DxTemplateHost, element: ElementRef);
    setTemplate(template: DxTemplateDirective): void;
    ngAfterViewInit(): void;
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoCardViewCardCoverComponent, [{ host: true; skipSelf: true; }, { host: true; }, null, null, { host: true; }, null]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoCardViewCardCoverComponent, "dxo-card-view-card-cover", never, { "altExpr": { "alias": "altExpr"; "required": false; }; "aspectRatio": { "alias": "aspectRatio"; "required": false; }; "imageExpr": { "alias": "imageExpr"; "required": false; }; "maxHeight": { "alias": "maxHeight"; "required": false; }; "template": { "alias": "template"; "required": false; }; }, {}, never, ["*"], true, never>;
}
declare class DxoCardViewCardCoverModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoCardViewCardCoverModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoCardViewCardCoverModule, never, [typeof DxoCardViewCardCoverComponent], [typeof DxoCardViewCardCoverComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoCardViewCardCoverModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxiCardViewCardHeaderItemComponent extends CollectionNestedOption implements AfterViewInit, IDxTemplateHost {
    private renderer;
    private document;
    private element;
    get cssClass(): string | undefined;
    set cssClass(value: string | undefined);
    get disabled(): boolean;
    set disabled(value: boolean);
    get html(): string;
    set html(value: string);
    get locateInMenu(): LocateInMenuMode;
    set locateInMenu(value: LocateInMenuMode);
    get location(): ToolbarItemLocation;
    set location(value: ToolbarItemLocation);
    get menuItemTemplate(): any;
    set menuItemTemplate(value: any);
    get name(): CardHeaderPredefinedItem | string;
    set name(value: CardHeaderPredefinedItem | string);
    get options(): any;
    set options(value: any);
    get showText(): ShowTextMode;
    set showText(value: ShowTextMode);
    get template(): any;
    set template(value: any);
    get text(): string;
    set text(value: string);
    get visible(): boolean;
    set visible(value: boolean);
    get widget(): ToolbarItemComponent;
    set widget(value: ToolbarItemComponent);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost, renderer: Renderer2, document: any, templateHost: DxTemplateHost, element: ElementRef);
    setTemplate(template: DxTemplateDirective): void;
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiCardViewCardHeaderItemComponent, [{ host: true; skipSelf: true; }, { host: true; }, null, null, { host: true; }, null]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiCardViewCardHeaderItemComponent, "dxi-card-view-card-header-item", never, { "cssClass": { "alias": "cssClass"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "html": { "alias": "html"; "required": false; }; "locateInMenu": { "alias": "locateInMenu"; "required": false; }; "location": { "alias": "location"; "required": false; }; "menuItemTemplate": { "alias": "menuItemTemplate"; "required": false; }; "name": { "alias": "name"; "required": false; }; "options": { "alias": "options"; "required": false; }; "showText": { "alias": "showText"; "required": false; }; "template": { "alias": "template"; "required": false; }; "text": { "alias": "text"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "widget": { "alias": "widget"; "required": false; }; }, {}, never, ["*"], true, never>;
}
declare class DxiCardViewCardHeaderItemModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiCardViewCardHeaderItemModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiCardViewCardHeaderItemModule, never, [typeof DxiCardViewCardHeaderItemComponent], [typeof DxiCardViewCardHeaderItemComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiCardViewCardHeaderItemModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoCardViewCardHeaderComponent extends NestedOption implements AfterViewInit, OnDestroy, OnInit, IDxTemplateHost {
    private renderer;
    private document;
    private element;
    set _itemsContentChildren(value: QueryList<CollectionNestedOption>);
    get items(): Array<CardHeaderItem | CardHeaderPredefinedItem>;
    set items(value: Array<CardHeaderItem | CardHeaderPredefinedItem>);
    get template(): any;
    set template(value: any);
    get visible(): boolean;
    set visible(value: boolean);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost, renderer: Renderer2, document: any, templateHost: DxTemplateHost, element: ElementRef);
    setTemplate(template: DxTemplateDirective): void;
    ngAfterViewInit(): void;
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoCardViewCardHeaderComponent, [{ host: true; skipSelf: true; }, { host: true; }, null, null, { host: true; }, null]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoCardViewCardHeaderComponent, "dxo-card-view-card-header", never, { "items": { "alias": "items"; "required": false; }; "template": { "alias": "template"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; }, {}, ["_itemsContentChildren"], ["*"], true, never>;
}
declare class DxoCardViewCardHeaderModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoCardViewCardHeaderModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoCardViewCardHeaderModule, never, [typeof DxoCardViewCardHeaderComponent], [typeof DxoCardViewCardHeaderComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoCardViewCardHeaderModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoCardViewCardViewHeaderFilterSearchComponent extends NestedOption implements OnDestroy, OnInit {
    get editorOptions(): any;
    set editorOptions(value: any);
    get enabled(): boolean;
    set enabled(value: boolean);
    get mode(): SearchMode;
    set mode(value: SearchMode);
    get timeout(): number;
    set timeout(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoCardViewCardViewHeaderFilterSearchComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoCardViewCardViewHeaderFilterSearchComponent, "dxo-card-view-card-view-header-filter-search", never, { "editorOptions": { "alias": "editorOptions"; "required": false; }; "enabled": { "alias": "enabled"; "required": false; }; "mode": { "alias": "mode"; "required": false; }; "timeout": { "alias": "timeout"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoCardViewCardViewHeaderFilterSearchModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoCardViewCardViewHeaderFilterSearchModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoCardViewCardViewHeaderFilterSearchModule, never, [typeof DxoCardViewCardViewHeaderFilterSearchComponent], [typeof DxoCardViewCardViewHeaderFilterSearchComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoCardViewCardViewHeaderFilterSearchModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoCardViewCardViewHeaderFilterTextsComponent extends NestedOption implements OnDestroy, OnInit {
    get cancel(): string;
    set cancel(value: string);
    get emptyValue(): string;
    set emptyValue(value: string);
    get ok(): string;
    set ok(value: string);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoCardViewCardViewHeaderFilterTextsComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoCardViewCardViewHeaderFilterTextsComponent, "dxo-card-view-card-view-header-filter-texts", never, { "cancel": { "alias": "cancel"; "required": false; }; "emptyValue": { "alias": "emptyValue"; "required": false; }; "ok": { "alias": "ok"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoCardViewCardViewHeaderFilterTextsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoCardViewCardViewHeaderFilterTextsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoCardViewCardViewHeaderFilterTextsModule, never, [typeof DxoCardViewCardViewHeaderFilterTextsComponent], [typeof DxoCardViewCardViewHeaderFilterTextsComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoCardViewCardViewHeaderFilterTextsModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoCardViewCardViewHeaderFilterComponent extends NestedOption implements OnDestroy, OnInit {
    get allowSearch(): boolean;
    set allowSearch(value: boolean);
    get allowSelectAll(): boolean;
    set allowSelectAll(value: boolean);
    get height(): number | string;
    set height(value: number | string);
    get search(): HeaderFilterSearchConfig;
    set search(value: HeaderFilterSearchConfig);
    get searchTimeout(): number;
    set searchTimeout(value: number);
    get texts(): HeaderFilterTexts;
    set texts(value: HeaderFilterTexts);
    get visible(): boolean;
    set visible(value: boolean);
    get width(): number | string;
    set width(value: number | string);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoCardViewCardViewHeaderFilterComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoCardViewCardViewHeaderFilterComponent, "dxo-card-view-card-view-header-filter", never, { "allowSearch": { "alias": "allowSearch"; "required": false; }; "allowSelectAll": { "alias": "allowSelectAll"; "required": false; }; "height": { "alias": "height"; "required": false; }; "search": { "alias": "search"; "required": false; }; "searchTimeout": { "alias": "searchTimeout"; "required": false; }; "texts": { "alias": "texts"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoCardViewCardViewHeaderFilterModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoCardViewCardViewHeaderFilterModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoCardViewCardViewHeaderFilterModule, never, [typeof DxoCardViewCardViewHeaderFilterComponent], [typeof DxoCardViewCardViewHeaderFilterComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoCardViewCardViewHeaderFilterModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoCardViewCardViewSelectionComponent extends NestedOption implements OnDestroy, OnInit {
    get allowSelectAll(): boolean;
    set allowSelectAll(value: boolean);
    get mode(): SingleMultipleOrNone;
    set mode(value: SingleMultipleOrNone);
    get selectAllMode(): SelectAllMode;
    set selectAllMode(value: SelectAllMode);
    get showCheckBoxesMode(): SelectionColumnDisplayMode;
    set showCheckBoxesMode(value: SelectionColumnDisplayMode);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoCardViewCardViewSelectionComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoCardViewCardViewSelectionComponent, "dxo-card-view-card-view-selection", never, { "allowSelectAll": { "alias": "allowSelectAll"; "required": false; }; "mode": { "alias": "mode"; "required": false; }; "selectAllMode": { "alias": "selectAllMode"; "required": false; }; "showCheckBoxesMode": { "alias": "showCheckBoxesMode"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoCardViewCardViewSelectionModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoCardViewCardViewSelectionModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoCardViewCardViewSelectionModule, never, [typeof DxoCardViewCardViewSelectionComponent], [typeof DxoCardViewCardViewSelectionComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoCardViewCardViewSelectionModule>;
}

declare class DxiCardViewChangeComponent extends CollectionNestedOption {
    get data(): any;
    set data(value: any);
    get insertAfterKey(): any;
    set insertAfterKey(value: any);
    get insertBeforeKey(): any;
    set insertBeforeKey(value: any);
    get key(): any;
    set key(value: any);
    get type(): DataChangeType;
    set type(value: DataChangeType);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiCardViewChangeComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiCardViewChangeComponent, "dxi-card-view-change", never, { "data": { "alias": "data"; "required": false; }; "insertAfterKey": { "alias": "insertAfterKey"; "required": false; }; "insertBeforeKey": { "alias": "insertBeforeKey"; "required": false; }; "key": { "alias": "key"; "required": false; }; "type": { "alias": "type"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxiCardViewChangeModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiCardViewChangeModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiCardViewChangeModule, never, [typeof DxiCardViewChangeComponent], [typeof DxiCardViewChangeComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiCardViewChangeModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoCardViewColCountByScreenComponent extends NestedOption implements OnDestroy, OnInit {
    get lg(): number | undefined;
    set lg(value: number | undefined);
    get md(): number | undefined;
    set md(value: number | undefined);
    get sm(): number | undefined;
    set sm(value: number | undefined);
    get xs(): number | undefined;
    set xs(value: number | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoCardViewColCountByScreenComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoCardViewColCountByScreenComponent, "dxo-card-view-col-count-by-screen", never, { "lg": { "alias": "lg"; "required": false; }; "md": { "alias": "md"; "required": false; }; "sm": { "alias": "sm"; "required": false; }; "xs": { "alias": "xs"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoCardViewColCountByScreenModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoCardViewColCountByScreenModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoCardViewColCountByScreenModule, never, [typeof DxoCardViewColCountByScreenComponent], [typeof DxoCardViewColCountByScreenComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoCardViewColCountByScreenModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoCardViewCollisionComponent extends NestedOption implements OnDestroy, OnInit {
    get x(): CollisionResolution;
    set x(value: CollisionResolution);
    get y(): CollisionResolution;
    set y(value: CollisionResolution);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoCardViewCollisionComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoCardViewCollisionComponent, "dxo-card-view-collision", never, { "x": { "alias": "x"; "required": false; }; "y": { "alias": "y"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoCardViewCollisionModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoCardViewCollisionModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoCardViewCollisionModule, never, [typeof DxoCardViewCollisionComponent], [typeof DxoCardViewCollisionComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoCardViewCollisionModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoCardViewColumnChooserSearchComponent extends NestedOption implements OnDestroy, OnInit {
    get editorOptions(): any;
    set editorOptions(value: any);
    get enabled(): boolean;
    set enabled(value: boolean);
    get timeout(): number;
    set timeout(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoCardViewColumnChooserSearchComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoCardViewColumnChooserSearchComponent, "dxo-card-view-column-chooser-search", never, { "editorOptions": { "alias": "editorOptions"; "required": false; }; "enabled": { "alias": "enabled"; "required": false; }; "timeout": { "alias": "timeout"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoCardViewColumnChooserSearchModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoCardViewColumnChooserSearchModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoCardViewColumnChooserSearchModule, never, [typeof DxoCardViewColumnChooserSearchComponent], [typeof DxoCardViewColumnChooserSearchComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoCardViewColumnChooserSearchModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoCardViewColumnChooserSelectionComponent extends NestedOption implements OnDestroy, OnInit {
    get allowSelectAll(): boolean;
    set allowSelectAll(value: boolean);
    get recursive(): boolean;
    set recursive(value: boolean);
    get selectByClick(): boolean;
    set selectByClick(value: boolean);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoCardViewColumnChooserSelectionComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoCardViewColumnChooserSelectionComponent, "dxo-card-view-column-chooser-selection", never, { "allowSelectAll": { "alias": "allowSelectAll"; "required": false; }; "recursive": { "alias": "recursive"; "required": false; }; "selectByClick": { "alias": "selectByClick"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoCardViewColumnChooserSelectionModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoCardViewColumnChooserSelectionModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoCardViewColumnChooserSelectionModule, never, [typeof DxoCardViewColumnChooserSelectionComponent], [typeof DxoCardViewColumnChooserSelectionComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoCardViewColumnChooserSelectionModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoCardViewColumnChooserComponent extends NestedOption implements OnDestroy, OnInit {
    get allowSearch(): boolean;
    set allowSearch(value: boolean);
    get container(): any | string | undefined;
    set container(value: any | string | undefined);
    get emptyPanelText(): string;
    set emptyPanelText(value: string);
    get enabled(): boolean;
    set enabled(value: boolean);
    get height(): number | string;
    set height(value: number | string);
    get mode(): ColumnChooserMode;
    set mode(value: ColumnChooserMode);
    get position(): PositionConfig | undefined;
    set position(value: PositionConfig | undefined);
    get search(): ColumnChooserSearchConfig;
    set search(value: ColumnChooserSearchConfig);
    get searchTimeout(): number;
    set searchTimeout(value: number);
    get selection(): ColumnChooserSelectionConfig;
    set selection(value: ColumnChooserSelectionConfig);
    get sortOrder(): SortOrder | undefined;
    set sortOrder(value: SortOrder | undefined);
    get title(): string;
    set title(value: string);
    get width(): number | string;
    set width(value: number | string);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoCardViewColumnChooserComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoCardViewColumnChooserComponent, "dxo-card-view-column-chooser", never, { "allowSearch": { "alias": "allowSearch"; "required": false; }; "container": { "alias": "container"; "required": false; }; "emptyPanelText": { "alias": "emptyPanelText"; "required": false; }; "enabled": { "alias": "enabled"; "required": false; }; "height": { "alias": "height"; "required": false; }; "mode": { "alias": "mode"; "required": false; }; "position": { "alias": "position"; "required": false; }; "search": { "alias": "search"; "required": false; }; "searchTimeout": { "alias": "searchTimeout"; "required": false; }; "selection": { "alias": "selection"; "required": false; }; "sortOrder": { "alias": "sortOrder"; "required": false; }; "title": { "alias": "title"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoCardViewColumnChooserModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoCardViewColumnChooserModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoCardViewColumnChooserModule, never, [typeof DxoCardViewColumnChooserComponent], [typeof DxoCardViewColumnChooserComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoCardViewColumnChooserModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxiCardViewColumnComponent extends CollectionNestedOption {
    set _validationRulesContentChildren(value: QueryList<CollectionNestedOption>);
    get alignment(): HorizontalAlignment | undefined;
    set alignment(value: HorizontalAlignment | undefined);
    get allowEditing(): boolean;
    set allowEditing(value: boolean);
    get allowFiltering(): boolean;
    set allowFiltering(value: boolean);
    get allowHeaderFiltering(): boolean;
    set allowHeaderFiltering(value: boolean);
    get allowHiding(): boolean;
    set allowHiding(value: boolean);
    get allowReordering(): boolean;
    set allowReordering(value: boolean);
    get allowSearch(): boolean;
    set allowSearch(value: boolean);
    get allowSorting(): boolean;
    set allowSorting(value: boolean);
    get calculateDisplayValue(): ((cardData: any) => any);
    set calculateDisplayValue(value: ((cardData: any) => any));
    get calculateFieldValue(): ((cardData: any) => any);
    set calculateFieldValue(value: ((cardData: any) => any));
    get calculateFilterExpression(): ((filterValue: any, selectedFilterOperation: string | null, target: string) => string | Array<any> | Function);
    set calculateFilterExpression(value: ((filterValue: any, selectedFilterOperation: string | null, target: string) => string | Array<any> | Function));
    get calculateSortValue(): ((cardData: any) => any) | string;
    set calculateSortValue(value: ((cardData: any) => any) | string);
    get caption(): string | undefined;
    set caption(value: string | undefined);
    get customizeText(): ((fieldInfo: {
        groupInterval: string | number;
        target: string;
        value: any;
        valueText: string;
    }) => string);
    set customizeText(value: ((fieldInfo: {
        groupInterval: string | number;
        target: string;
        value: any;
        valueText: string;
    }) => string));
    get dataField(): string | undefined;
    set dataField(value: string | undefined);
    get dataType(): DataType | undefined;
    set dataType(value: DataType | undefined);
    get editorOptions(): any;
    set editorOptions(value: any);
    get falseText(): string;
    set falseText(value: string);
    get fieldCaptionTemplate(): any;
    set fieldCaptionTemplate(value: any);
    get fieldTemplate(): any;
    set fieldTemplate(value: any);
    get fieldValueTemplate(): any;
    set fieldValueTemplate(value: any);
    get filterType(): FilterType;
    set filterType(value: FilterType);
    get filterValue(): any | undefined;
    set filterValue(value: any | undefined);
    get filterValues(): Array<any>;
    set filterValues(value: Array<any>);
    get format(): Format;
    set format(value: Format);
    get formItem(): dxFormSimpleItem;
    set formItem(value: dxFormSimpleItem);
    get headerFilter(): ColumnHeaderFilter | undefined;
    set headerFilter(value: ColumnHeaderFilter | undefined);
    get headerItemCssClass(): string;
    set headerItemCssClass(value: string);
    get headerItemTemplate(): any;
    set headerItemTemplate(value: any);
    get name(): string | undefined;
    set name(value: string | undefined);
    get setFieldValue(): ((newData: any, value: any, currentCardData: any) => any);
    set setFieldValue(value: ((newData: any, value: any, currentCardData: any) => any));
    get showInColumnChooser(): boolean;
    set showInColumnChooser(value: boolean);
    get sortIndex(): number | undefined;
    set sortIndex(value: number | undefined);
    get sortingMethod(): ((value1: any, value2: any) => number) | undefined;
    set sortingMethod(value: ((value1: any, value2: any) => number) | undefined);
    get sortOrder(): SortOrder | undefined;
    set sortOrder(value: SortOrder | undefined);
    get trueText(): string;
    set trueText(value: string);
    get validationRules(): Array<CommonTypes.ValidationRule>;
    set validationRules(value: Array<CommonTypes.ValidationRule>);
    get visible(): boolean;
    set visible(value: boolean);
    get visibleIndex(): number | undefined;
    set visibleIndex(value: number | undefined);
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    filterValueChange: EventEmitter<any | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    filterValuesChange: EventEmitter<Array<any>>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    sortIndexChange: EventEmitter<number | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    sortOrderChange: EventEmitter<SortOrder | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    visibleChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    visibleIndexChange: EventEmitter<number | undefined>;
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiCardViewColumnComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiCardViewColumnComponent, "dxi-card-view-column", never, { "alignment": { "alias": "alignment"; "required": false; }; "allowEditing": { "alias": "allowEditing"; "required": false; }; "allowFiltering": { "alias": "allowFiltering"; "required": false; }; "allowHeaderFiltering": { "alias": "allowHeaderFiltering"; "required": false; }; "allowHiding": { "alias": "allowHiding"; "required": false; }; "allowReordering": { "alias": "allowReordering"; "required": false; }; "allowSearch": { "alias": "allowSearch"; "required": false; }; "allowSorting": { "alias": "allowSorting"; "required": false; }; "calculateDisplayValue": { "alias": "calculateDisplayValue"; "required": false; }; "calculateFieldValue": { "alias": "calculateFieldValue"; "required": false; }; "calculateFilterExpression": { "alias": "calculateFilterExpression"; "required": false; }; "calculateSortValue": { "alias": "calculateSortValue"; "required": false; }; "caption": { "alias": "caption"; "required": false; }; "customizeText": { "alias": "customizeText"; "required": false; }; "dataField": { "alias": "dataField"; "required": false; }; "dataType": { "alias": "dataType"; "required": false; }; "editorOptions": { "alias": "editorOptions"; "required": false; }; "falseText": { "alias": "falseText"; "required": false; }; "fieldCaptionTemplate": { "alias": "fieldCaptionTemplate"; "required": false; }; "fieldTemplate": { "alias": "fieldTemplate"; "required": false; }; "fieldValueTemplate": { "alias": "fieldValueTemplate"; "required": false; }; "filterType": { "alias": "filterType"; "required": false; }; "filterValue": { "alias": "filterValue"; "required": false; }; "filterValues": { "alias": "filterValues"; "required": false; }; "format": { "alias": "format"; "required": false; }; "formItem": { "alias": "formItem"; "required": false; }; "headerFilter": { "alias": "headerFilter"; "required": false; }; "headerItemCssClass": { "alias": "headerItemCssClass"; "required": false; }; "headerItemTemplate": { "alias": "headerItemTemplate"; "required": false; }; "name": { "alias": "name"; "required": false; }; "setFieldValue": { "alias": "setFieldValue"; "required": false; }; "showInColumnChooser": { "alias": "showInColumnChooser"; "required": false; }; "sortIndex": { "alias": "sortIndex"; "required": false; }; "sortingMethod": { "alias": "sortingMethod"; "required": false; }; "sortOrder": { "alias": "sortOrder"; "required": false; }; "trueText": { "alias": "trueText"; "required": false; }; "validationRules": { "alias": "validationRules"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "visibleIndex": { "alias": "visibleIndex"; "required": false; }; }, { "filterValueChange": "filterValueChange"; "filterValuesChange": "filterValuesChange"; "sortIndexChange": "sortIndexChange"; "sortOrderChange": "sortOrderChange"; "visibleChange": "visibleChange"; "visibleIndexChange": "visibleIndexChange"; }, ["_validationRulesContentChildren"], never, true, never>;
}
declare class DxiCardViewColumnModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiCardViewColumnModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiCardViewColumnModule, never, [typeof DxiCardViewColumnComponent], [typeof DxiCardViewColumnComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiCardViewColumnModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoCardViewColumnHeaderFilterSearchComponent extends NestedOption implements OnDestroy, OnInit {
    get editorOptions(): any;
    set editorOptions(value: any);
    get enabled(): boolean;
    set enabled(value: boolean);
    get mode(): SearchMode;
    set mode(value: SearchMode);
    get searchExpr(): Array<Function | string> | Function | string | undefined;
    set searchExpr(value: Array<Function | string> | Function | string | undefined);
    get timeout(): number;
    set timeout(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoCardViewColumnHeaderFilterSearchComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoCardViewColumnHeaderFilterSearchComponent, "dxo-card-view-column-header-filter-search", never, { "editorOptions": { "alias": "editorOptions"; "required": false; }; "enabled": { "alias": "enabled"; "required": false; }; "mode": { "alias": "mode"; "required": false; }; "searchExpr": { "alias": "searchExpr"; "required": false; }; "timeout": { "alias": "timeout"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoCardViewColumnHeaderFilterSearchModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoCardViewColumnHeaderFilterSearchModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoCardViewColumnHeaderFilterSearchModule, never, [typeof DxoCardViewColumnHeaderFilterSearchComponent], [typeof DxoCardViewColumnHeaderFilterSearchComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoCardViewColumnHeaderFilterSearchModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoCardViewColumnHeaderFilterComponent extends NestedOption implements OnDestroy, OnInit {
    get allowSearch(): boolean;
    set allowSearch(value: boolean);
    get allowSelectAll(): boolean;
    set allowSelectAll(value: boolean);
    get dataSource(): Array<any> | DataSourceOptions | ((options: {
        component: Record<string, any>;
        dataSource: DataSourceOptions | null;
    }) => void) | null | Store | undefined;
    set dataSource(value: Array<any> | DataSourceOptions | ((options: {
        component: Record<string, any>;
        dataSource: DataSourceOptions | null;
    }) => void) | null | Store | undefined);
    get groupInterval(): Array<number | string> | HeaderFilterGroupInterval | number | undefined;
    set groupInterval(value: Array<number | string> | HeaderFilterGroupInterval | number | undefined);
    get height(): number | string | undefined;
    set height(value: number | string | undefined);
    get search(): ColumnHeaderFilterSearchConfig;
    set search(value: ColumnHeaderFilterSearchConfig);
    get searchMode(): SearchMode;
    set searchMode(value: SearchMode);
    get width(): number | string | undefined;
    set width(value: number | string | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoCardViewColumnHeaderFilterComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoCardViewColumnHeaderFilterComponent, "dxo-card-view-column-header-filter", never, { "allowSearch": { "alias": "allowSearch"; "required": false; }; "allowSelectAll": { "alias": "allowSelectAll"; "required": false; }; "dataSource": { "alias": "dataSource"; "required": false; }; "groupInterval": { "alias": "groupInterval"; "required": false; }; "height": { "alias": "height"; "required": false; }; "search": { "alias": "search"; "required": false; }; "searchMode": { "alias": "searchMode"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoCardViewColumnHeaderFilterModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoCardViewColumnHeaderFilterModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoCardViewColumnHeaderFilterModule, never, [typeof DxoCardViewColumnHeaderFilterComponent], [typeof DxoCardViewColumnHeaderFilterComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoCardViewColumnHeaderFilterModule>;
}

declare class DxiCardViewCompareRuleComponent extends CollectionNestedOption {
    get comparisonTarget(): Function;
    set comparisonTarget(value: Function);
    get comparisonType(): ComparisonOperator;
    set comparisonType(value: ComparisonOperator);
    get ignoreEmptyValue(): boolean;
    set ignoreEmptyValue(value: boolean);
    get message(): string;
    set message(value: string);
    get type(): ValidationRuleType;
    set type(value: ValidationRuleType);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiCardViewCompareRuleComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiCardViewCompareRuleComponent, "dxi-card-view-compare-rule", never, { "comparisonTarget": { "alias": "comparisonTarget"; "required": false; }; "comparisonType": { "alias": "comparisonType"; "required": false; }; "ignoreEmptyValue": { "alias": "ignoreEmptyValue"; "required": false; }; "message": { "alias": "message"; "required": false; }; "type": { "alias": "type"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxiCardViewCompareRuleModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiCardViewCompareRuleModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiCardViewCompareRuleModule, never, [typeof DxiCardViewCompareRuleComponent], [typeof DxiCardViewCompareRuleComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiCardViewCompareRuleModule>;
}

declare class DxiCardViewCustomOperationComponent extends CollectionNestedOption {
    get calculateFilterExpression(): ((filterValue: any, field: dxFilterBuilderField) => string | Function | Array<any>);
    set calculateFilterExpression(value: ((filterValue: any, field: dxFilterBuilderField) => string | Function | Array<any>));
    get caption(): string | undefined;
    set caption(value: string | undefined);
    get customizeText(): ((fieldInfo: FieldInfo) => string);
    set customizeText(value: ((fieldInfo: FieldInfo) => string));
    get dataTypes(): Array<DataType> | undefined;
    set dataTypes(value: Array<DataType> | undefined);
    get editorTemplate(): any;
    set editorTemplate(value: any);
    get hasValue(): boolean;
    set hasValue(value: boolean);
    get icon(): string | undefined;
    set icon(value: string | undefined);
    get name(): string | undefined;
    set name(value: string | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiCardViewCustomOperationComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiCardViewCustomOperationComponent, "dxi-card-view-custom-operation", never, { "calculateFilterExpression": { "alias": "calculateFilterExpression"; "required": false; }; "caption": { "alias": "caption"; "required": false; }; "customizeText": { "alias": "customizeText"; "required": false; }; "dataTypes": { "alias": "dataTypes"; "required": false; }; "editorTemplate": { "alias": "editorTemplate"; "required": false; }; "hasValue": { "alias": "hasValue"; "required": false; }; "icon": { "alias": "icon"; "required": false; }; "name": { "alias": "name"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxiCardViewCustomOperationModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiCardViewCustomOperationModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiCardViewCustomOperationModule, never, [typeof DxiCardViewCustomOperationComponent], [typeof DxiCardViewCustomOperationComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiCardViewCustomOperationModule>;
}

declare class DxiCardViewCustomRuleComponent extends CollectionNestedOption {
    get ignoreEmptyValue(): boolean;
    set ignoreEmptyValue(value: boolean);
    get message(): string;
    set message(value: string);
    get reevaluate(): boolean;
    set reevaluate(value: boolean);
    get type(): ValidationRuleType;
    set type(value: ValidationRuleType);
    get validationCallback(): ((options: {
        column: Record<string, any>;
        data: Record<string, any>;
        formItem: Record<string, any>;
        rule: Record<string, any>;
        validator: Record<string, any>;
        value: any;
    }) => boolean);
    set validationCallback(value: ((options: {
        column: Record<string, any>;
        data: Record<string, any>;
        formItem: Record<string, any>;
        rule: Record<string, any>;
        validator: Record<string, any>;
        value: any;
    }) => boolean));
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiCardViewCustomRuleComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiCardViewCustomRuleComponent, "dxi-card-view-custom-rule", never, { "ignoreEmptyValue": { "alias": "ignoreEmptyValue"; "required": false; }; "message": { "alias": "message"; "required": false; }; "reevaluate": { "alias": "reevaluate"; "required": false; }; "type": { "alias": "type"; "required": false; }; "validationCallback": { "alias": "validationCallback"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxiCardViewCustomRuleModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiCardViewCustomRuleModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiCardViewCustomRuleModule, never, [typeof DxiCardViewCustomRuleComponent], [typeof DxiCardViewCustomRuleComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiCardViewCustomRuleModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoCardViewDraggingComponent extends NestedOption implements OnDestroy, OnInit {
    get dropFeedbackMode(): DragHighlight;
    set dropFeedbackMode(value: DragHighlight);
    get onDragChange(): ((e: any) => void);
    set onDragChange(value: ((e: any) => void));
    get onDragEnd(): ((e: any) => void);
    set onDragEnd(value: ((e: any) => void));
    get onDragMove(): ((e: any) => void);
    set onDragMove(value: ((e: any) => void));
    get onDragStart(): ((e: any) => void);
    set onDragStart(value: ((e: any) => void));
    get onRemove(): ((e: any) => void);
    set onRemove(value: ((e: any) => void));
    get onReorder(): ((e: any) => void);
    set onReorder(value: ((e: any) => void));
    get scrollSensitivity(): number;
    set scrollSensitivity(value: number);
    get scrollSpeed(): number;
    set scrollSpeed(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoCardViewDraggingComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoCardViewDraggingComponent, "dxo-card-view-dragging", never, { "dropFeedbackMode": { "alias": "dropFeedbackMode"; "required": false; }; "onDragChange": { "alias": "onDragChange"; "required": false; }; "onDragEnd": { "alias": "onDragEnd"; "required": false; }; "onDragMove": { "alias": "onDragMove"; "required": false; }; "onDragStart": { "alias": "onDragStart"; "required": false; }; "onRemove": { "alias": "onRemove"; "required": false; }; "onReorder": { "alias": "onReorder"; "required": false; }; "scrollSensitivity": { "alias": "scrollSensitivity"; "required": false; }; "scrollSpeed": { "alias": "scrollSpeed"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoCardViewDraggingModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoCardViewDraggingModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoCardViewDraggingModule, never, [typeof DxoCardViewDraggingComponent], [typeof DxoCardViewDraggingComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoCardViewDraggingModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoCardViewEditingTextsComponent extends NestedOption implements OnDestroy, OnInit {
    get addCard(): string;
    set addCard(value: string);
    get confirmDeleteMessage(): string;
    set confirmDeleteMessage(value: string);
    get confirmDeleteTitle(): string;
    set confirmDeleteTitle(value: string);
    get deleteCard(): string;
    set deleteCard(value: string);
    get editCard(): string;
    set editCard(value: string);
    get saveCard(): string;
    set saveCard(value: string);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoCardViewEditingTextsComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoCardViewEditingTextsComponent, "dxo-card-view-editing-texts", never, { "addCard": { "alias": "addCard"; "required": false; }; "confirmDeleteMessage": { "alias": "confirmDeleteMessage"; "required": false; }; "confirmDeleteTitle": { "alias": "confirmDeleteTitle"; "required": false; }; "deleteCard": { "alias": "deleteCard"; "required": false; }; "editCard": { "alias": "editCard"; "required": false; }; "saveCard": { "alias": "saveCard"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoCardViewEditingTextsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoCardViewEditingTextsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoCardViewEditingTextsModule, never, [typeof DxoCardViewEditingTextsComponent], [typeof DxoCardViewEditingTextsComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoCardViewEditingTextsModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoCardViewEditingComponent extends NestedOption implements OnDestroy, OnInit {
    set _changesContentChildren(value: QueryList<CollectionNestedOption>);
    get allowAdding(): boolean;
    set allowAdding(value: boolean);
    get allowDeleting(): boolean;
    set allowDeleting(value: boolean);
    get allowUpdating(): boolean;
    set allowUpdating(value: boolean);
    get changes(): Array<DataChange>;
    set changes(value: Array<DataChange>);
    get confirmDelete(): boolean;
    set confirmDelete(value: boolean);
    get editCardKey(): any;
    set editCardKey(value: any);
    get form(): dxFormOptions;
    set form(value: dxFormOptions);
    get popup(): Record<string, any>;
    set popup(value: Record<string, any>);
    get texts(): EditingTexts;
    set texts(value: EditingTexts);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoCardViewEditingComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoCardViewEditingComponent, "dxo-card-view-editing", never, { "allowAdding": { "alias": "allowAdding"; "required": false; }; "allowDeleting": { "alias": "allowDeleting"; "required": false; }; "allowUpdating": { "alias": "allowUpdating"; "required": false; }; "changes": { "alias": "changes"; "required": false; }; "confirmDelete": { "alias": "confirmDelete"; "required": false; }; "editCardKey": { "alias": "editCardKey"; "required": false; }; "form": { "alias": "form"; "required": false; }; "popup": { "alias": "popup"; "required": false; }; "texts": { "alias": "texts"; "required": false; }; }, {}, ["_changesContentChildren"], never, true, never>;
}
declare class DxoCardViewEditingModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoCardViewEditingModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoCardViewEditingModule, never, [typeof DxoCardViewEditingComponent], [typeof DxoCardViewEditingComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoCardViewEditingModule>;
}

declare class DxiCardViewEmailRuleComponent extends CollectionNestedOption {
    get ignoreEmptyValue(): boolean;
    set ignoreEmptyValue(value: boolean);
    get message(): string;
    set message(value: string);
    get type(): ValidationRuleType;
    set type(value: ValidationRuleType);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiCardViewEmailRuleComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiCardViewEmailRuleComponent, "dxi-card-view-email-rule", never, { "ignoreEmptyValue": { "alias": "ignoreEmptyValue"; "required": false; }; "message": { "alias": "message"; "required": false; }; "type": { "alias": "type"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxiCardViewEmailRuleModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiCardViewEmailRuleModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiCardViewEmailRuleModule, never, [typeof DxiCardViewEmailRuleComponent], [typeof DxiCardViewEmailRuleComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiCardViewEmailRuleModule>;
}

declare class DxiCardViewEmptyItemComponent extends CollectionNestedOption {
    get colSpan(): number | undefined;
    set colSpan(value: number | undefined);
    get cssClass(): string | undefined;
    set cssClass(value: string | undefined);
    get itemType(): FormItemType;
    set itemType(value: FormItemType);
    get name(): string | undefined;
    set name(value: string | undefined);
    get visible(): boolean;
    set visible(value: boolean);
    get visibleIndex(): number | undefined;
    set visibleIndex(value: number | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiCardViewEmptyItemComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiCardViewEmptyItemComponent, "dxi-card-view-empty-item", never, { "colSpan": { "alias": "colSpan"; "required": false; }; "cssClass": { "alias": "cssClass"; "required": false; }; "itemType": { "alias": "itemType"; "required": false; }; "name": { "alias": "name"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "visibleIndex": { "alias": "visibleIndex"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxiCardViewEmptyItemModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiCardViewEmptyItemModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiCardViewEmptyItemModule, never, [typeof DxiCardViewEmptyItemComponent], [typeof DxiCardViewEmptyItemComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiCardViewEmptyItemModule>;
}

declare class DxiCardViewFieldComponent extends CollectionNestedOption {
    get calculateFilterExpression(): ((filterValue: any, selectedFilterOperation: string) => string | Function | Array<any>);
    set calculateFilterExpression(value: ((filterValue: any, selectedFilterOperation: string) => string | Function | Array<any>));
    get caption(): string | undefined;
    set caption(value: string | undefined);
    get customizeText(): ((fieldInfo: FieldInfo) => string);
    set customizeText(value: ((fieldInfo: FieldInfo) => string));
    get dataField(): string | undefined;
    set dataField(value: string | undefined);
    get dataType(): DataType;
    set dataType(value: DataType);
    get editorOptions(): any;
    set editorOptions(value: any);
    get editorTemplate(): any;
    set editorTemplate(value: any);
    get falseText(): string;
    set falseText(value: string);
    get filterOperations(): Array<FilterBuilderOperation | string>;
    set filterOperations(value: Array<FilterBuilderOperation | string>);
    get format(): Format;
    set format(value: Format);
    get lookup(): {
        allowClearing?: boolean;
        dataSource?: Array<any> | DataSourceOptions | Store | undefined;
        displayExpr?: ((data: any) => string) | string | undefined;
        valueExpr?: ((data: any) => string | number | boolean) | string | undefined;
    };
    set lookup(value: {
        allowClearing?: boolean;
        dataSource?: Array<any> | DataSourceOptions | Store | undefined;
        displayExpr?: ((data: any) => string) | string | undefined;
        valueExpr?: ((data: any) => string | number | boolean) | string | undefined;
    });
    get name(): string | undefined;
    set name(value: string | undefined);
    get trueText(): string;
    set trueText(value: string);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiCardViewFieldComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiCardViewFieldComponent, "dxi-card-view-field", never, { "calculateFilterExpression": { "alias": "calculateFilterExpression"; "required": false; }; "caption": { "alias": "caption"; "required": false; }; "customizeText": { "alias": "customizeText"; "required": false; }; "dataField": { "alias": "dataField"; "required": false; }; "dataType": { "alias": "dataType"; "required": false; }; "editorOptions": { "alias": "editorOptions"; "required": false; }; "editorTemplate": { "alias": "editorTemplate"; "required": false; }; "falseText": { "alias": "falseText"; "required": false; }; "filterOperations": { "alias": "filterOperations"; "required": false; }; "format": { "alias": "format"; "required": false; }; "lookup": { "alias": "lookup"; "required": false; }; "name": { "alias": "name"; "required": false; }; "trueText": { "alias": "trueText"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxiCardViewFieldModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiCardViewFieldModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiCardViewFieldModule, never, [typeof DxiCardViewFieldComponent], [typeof DxiCardViewFieldComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiCardViewFieldModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoCardViewFilterBuilderComponent extends NestedOption implements OnDestroy, OnInit {
    set _customOperationsContentChildren(value: QueryList<CollectionNestedOption>);
    set _fieldsContentChildren(value: QueryList<CollectionNestedOption>);
    get accessKey(): string | undefined;
    set accessKey(value: string | undefined);
    get activeStateEnabled(): boolean;
    set activeStateEnabled(value: boolean);
    get allowHierarchicalFields(): boolean;
    set allowHierarchicalFields(value: boolean);
    get customOperations(): Array<dxFilterBuilderCustomOperation>;
    set customOperations(value: Array<dxFilterBuilderCustomOperation>);
    get disabled(): boolean;
    set disabled(value: boolean);
    get elementAttr(): Record<string, any>;
    set elementAttr(value: Record<string, any>);
    get fields(): Array<dxFilterBuilderField>;
    set fields(value: Array<dxFilterBuilderField>);
    get filterOperationDescriptions(): {
        between?: string;
        contains?: string;
        endsWith?: string;
        equal?: string;
        greaterThan?: string;
        greaterThanOrEqual?: string;
        isBlank?: string;
        isNotBlank?: string;
        lessThan?: string;
        lessThanOrEqual?: string;
        notContains?: string;
        notEqual?: string;
        startsWith?: string;
    };
    set filterOperationDescriptions(value: {
        between?: string;
        contains?: string;
        endsWith?: string;
        equal?: string;
        greaterThan?: string;
        greaterThanOrEqual?: string;
        isBlank?: string;
        isNotBlank?: string;
        lessThan?: string;
        lessThanOrEqual?: string;
        notContains?: string;
        notEqual?: string;
        startsWith?: string;
    });
    get focusStateEnabled(): boolean;
    set focusStateEnabled(value: boolean);
    get groupOperationDescriptions(): {
        and?: string;
        notAnd?: string;
        notOr?: string;
        or?: string;
    };
    set groupOperationDescriptions(value: {
        and?: string;
        notAnd?: string;
        notOr?: string;
        or?: string;
    });
    get groupOperations(): Array<GroupOperation>;
    set groupOperations(value: Array<GroupOperation>);
    get height(): number | string | undefined;
    set height(value: number | string | undefined);
    get hint(): string | undefined;
    set hint(value: string | undefined);
    get hoverStateEnabled(): boolean;
    set hoverStateEnabled(value: boolean);
    get maxGroupLevel(): number | undefined;
    set maxGroupLevel(value: number | undefined);
    get onContentReady(): ((e: ContentReadyEvent$1) => void);
    set onContentReady(value: ((e: ContentReadyEvent$1) => void));
    get onDisposing(): ((e: DisposingEvent$1) => void);
    set onDisposing(value: ((e: DisposingEvent$1) => void));
    get onEditorPrepared(): ((e: EditorPreparedEvent) => void) | undefined;
    set onEditorPrepared(value: ((e: EditorPreparedEvent) => void) | undefined);
    get onEditorPreparing(): ((e: EditorPreparingEvent) => void) | undefined;
    set onEditorPreparing(value: ((e: EditorPreparingEvent) => void) | undefined);
    get onInitialized(): ((e: InitializedEvent$1) => void);
    set onInitialized(value: ((e: InitializedEvent$1) => void));
    get onOptionChanged(): ((e: OptionChangedEvent$1) => void);
    set onOptionChanged(value: ((e: OptionChangedEvent$1) => void));
    get onValueChanged(): ((e: ValueChangedEvent) => void) | undefined;
    set onValueChanged(value: ((e: ValueChangedEvent) => void) | undefined);
    get rtlEnabled(): boolean;
    set rtlEnabled(value: boolean);
    get tabIndex(): number;
    set tabIndex(value: number);
    get value(): Array<any> | Function | string;
    set value(value: Array<any> | Function | string);
    get visible(): boolean;
    set visible(value: boolean);
    get width(): number | string | undefined;
    set width(value: number | string | undefined);
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    valueChange: EventEmitter<Array<any> | Function | string>;
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoCardViewFilterBuilderComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoCardViewFilterBuilderComponent, "dxo-card-view-filter-builder", never, { "accessKey": { "alias": "accessKey"; "required": false; }; "activeStateEnabled": { "alias": "activeStateEnabled"; "required": false; }; "allowHierarchicalFields": { "alias": "allowHierarchicalFields"; "required": false; }; "customOperations": { "alias": "customOperations"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "elementAttr": { "alias": "elementAttr"; "required": false; }; "fields": { "alias": "fields"; "required": false; }; "filterOperationDescriptions": { "alias": "filterOperationDescriptions"; "required": false; }; "focusStateEnabled": { "alias": "focusStateEnabled"; "required": false; }; "groupOperationDescriptions": { "alias": "groupOperationDescriptions"; "required": false; }; "groupOperations": { "alias": "groupOperations"; "required": false; }; "height": { "alias": "height"; "required": false; }; "hint": { "alias": "hint"; "required": false; }; "hoverStateEnabled": { "alias": "hoverStateEnabled"; "required": false; }; "maxGroupLevel": { "alias": "maxGroupLevel"; "required": false; }; "onContentReady": { "alias": "onContentReady"; "required": false; }; "onDisposing": { "alias": "onDisposing"; "required": false; }; "onEditorPrepared": { "alias": "onEditorPrepared"; "required": false; }; "onEditorPreparing": { "alias": "onEditorPreparing"; "required": false; }; "onInitialized": { "alias": "onInitialized"; "required": false; }; "onOptionChanged": { "alias": "onOptionChanged"; "required": false; }; "onValueChanged": { "alias": "onValueChanged"; "required": false; }; "rtlEnabled": { "alias": "rtlEnabled"; "required": false; }; "tabIndex": { "alias": "tabIndex"; "required": false; }; "value": { "alias": "value"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, { "valueChange": "valueChange"; }, ["_customOperationsContentChildren", "_fieldsContentChildren"], never, true, never>;
}
declare class DxoCardViewFilterBuilderModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoCardViewFilterBuilderModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoCardViewFilterBuilderModule, never, [typeof DxoCardViewFilterBuilderComponent], [typeof DxoCardViewFilterBuilderComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoCardViewFilterBuilderModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoCardViewFilterOperationDescriptionsComponent extends NestedOption implements OnDestroy, OnInit {
    get between(): string;
    set between(value: string);
    get contains(): string;
    set contains(value: string);
    get endsWith(): string;
    set endsWith(value: string);
    get equal(): string;
    set equal(value: string);
    get greaterThan(): string;
    set greaterThan(value: string);
    get greaterThanOrEqual(): string;
    set greaterThanOrEqual(value: string);
    get isBlank(): string;
    set isBlank(value: string);
    get isNotBlank(): string;
    set isNotBlank(value: string);
    get lessThan(): string;
    set lessThan(value: string);
    get lessThanOrEqual(): string;
    set lessThanOrEqual(value: string);
    get notContains(): string;
    set notContains(value: string);
    get notEqual(): string;
    set notEqual(value: string);
    get startsWith(): string;
    set startsWith(value: string);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoCardViewFilterOperationDescriptionsComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoCardViewFilterOperationDescriptionsComponent, "dxo-card-view-filter-operation-descriptions", never, { "between": { "alias": "between"; "required": false; }; "contains": { "alias": "contains"; "required": false; }; "endsWith": { "alias": "endsWith"; "required": false; }; "equal": { "alias": "equal"; "required": false; }; "greaterThan": { "alias": "greaterThan"; "required": false; }; "greaterThanOrEqual": { "alias": "greaterThanOrEqual"; "required": false; }; "isBlank": { "alias": "isBlank"; "required": false; }; "isNotBlank": { "alias": "isNotBlank"; "required": false; }; "lessThan": { "alias": "lessThan"; "required": false; }; "lessThanOrEqual": { "alias": "lessThanOrEqual"; "required": false; }; "notContains": { "alias": "notContains"; "required": false; }; "notEqual": { "alias": "notEqual"; "required": false; }; "startsWith": { "alias": "startsWith"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoCardViewFilterOperationDescriptionsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoCardViewFilterOperationDescriptionsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoCardViewFilterOperationDescriptionsModule, never, [typeof DxoCardViewFilterOperationDescriptionsComponent], [typeof DxoCardViewFilterOperationDescriptionsComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoCardViewFilterOperationDescriptionsModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoCardViewFilterPanelTextsComponent extends NestedOption implements OnDestroy, OnInit {
    get clearFilter(): string;
    set clearFilter(value: string);
    get createFilter(): string;
    set createFilter(value: string);
    get filterEnabledHint(): string;
    set filterEnabledHint(value: string);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoCardViewFilterPanelTextsComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoCardViewFilterPanelTextsComponent, "dxo-card-view-filter-panel-texts", never, { "clearFilter": { "alias": "clearFilter"; "required": false; }; "createFilter": { "alias": "createFilter"; "required": false; }; "filterEnabledHint": { "alias": "filterEnabledHint"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoCardViewFilterPanelTextsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoCardViewFilterPanelTextsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoCardViewFilterPanelTextsModule, never, [typeof DxoCardViewFilterPanelTextsComponent], [typeof DxoCardViewFilterPanelTextsComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoCardViewFilterPanelTextsModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoCardViewFilterPanelComponent extends NestedOption implements OnDestroy, OnInit {
    get customizeText(): ((e: {
        component: FilterPanel;
        filterValue: Record<string, any>;
        text: string;
    }) => string);
    set customizeText(value: ((e: {
        component: FilterPanel;
        filterValue: Record<string, any>;
        text: string;
    }) => string));
    get filterEnabled(): boolean;
    set filterEnabled(value: boolean);
    get texts(): FilterPanelTexts;
    set texts(value: FilterPanelTexts);
    get visible(): boolean;
    set visible(value: boolean);
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    filterEnabledChange: EventEmitter<boolean>;
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoCardViewFilterPanelComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoCardViewFilterPanelComponent, "dxo-card-view-filter-panel", never, { "customizeText": { "alias": "customizeText"; "required": false; }; "filterEnabled": { "alias": "filterEnabled"; "required": false; }; "texts": { "alias": "texts"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; }, { "filterEnabledChange": "filterEnabledChange"; }, never, never, true, never>;
}
declare class DxoCardViewFilterPanelModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoCardViewFilterPanelModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoCardViewFilterPanelModule, never, [typeof DxoCardViewFilterPanelComponent], [typeof DxoCardViewFilterPanelComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoCardViewFilterPanelModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoCardViewFormItemComponent extends NestedOption implements AfterViewInit, OnDestroy, OnInit, IDxTemplateHost {
    private renderer;
    private document;
    private element;
    set _validationRulesContentChildren(value: QueryList<CollectionNestedOption>);
    get aiOptions(): {
        disabled?: boolean;
        instruction?: string | undefined;
    };
    set aiOptions(value: {
        disabled?: boolean;
        instruction?: string | undefined;
    });
    get colSpan(): number | undefined;
    set colSpan(value: number | undefined);
    get cssClass(): string | undefined;
    set cssClass(value: string | undefined);
    get dataField(): string | undefined;
    set dataField(value: string | undefined);
    get editorOptions(): any | undefined;
    set editorOptions(value: any | undefined);
    get editorType(): FormItemComponent;
    set editorType(value: FormItemComponent);
    get helpText(): string | undefined;
    set helpText(value: string | undefined);
    get isRequired(): boolean | undefined;
    set isRequired(value: boolean | undefined);
    get itemType(): FormItemType;
    set itemType(value: FormItemType);
    get label(): {
        alignment?: HorizontalAlignment;
        location?: LabelLocation;
        showColon?: boolean;
        template?: any;
        text?: string | undefined;
        visible?: boolean;
    };
    set label(value: {
        alignment?: HorizontalAlignment;
        location?: LabelLocation;
        showColon?: boolean;
        template?: any;
        text?: string | undefined;
        visible?: boolean;
    });
    get name(): string | undefined;
    set name(value: string | undefined);
    get template(): any;
    set template(value: any);
    get validationRules(): Array<CommonTypes.ValidationRule>;
    set validationRules(value: Array<CommonTypes.ValidationRule>);
    get visible(): boolean;
    set visible(value: boolean);
    get visibleIndex(): number | undefined;
    set visibleIndex(value: number | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost, renderer: Renderer2, document: any, templateHost: DxTemplateHost, element: ElementRef);
    setTemplate(template: DxTemplateDirective): void;
    ngAfterViewInit(): void;
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoCardViewFormItemComponent, [{ host: true; skipSelf: true; }, { host: true; }, null, null, { host: true; }, null]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoCardViewFormItemComponent, "dxo-card-view-form-item", never, { "aiOptions": { "alias": "aiOptions"; "required": false; }; "colSpan": { "alias": "colSpan"; "required": false; }; "cssClass": { "alias": "cssClass"; "required": false; }; "dataField": { "alias": "dataField"; "required": false; }; "editorOptions": { "alias": "editorOptions"; "required": false; }; "editorType": { "alias": "editorType"; "required": false; }; "helpText": { "alias": "helpText"; "required": false; }; "isRequired": { "alias": "isRequired"; "required": false; }; "itemType": { "alias": "itemType"; "required": false; }; "label": { "alias": "label"; "required": false; }; "name": { "alias": "name"; "required": false; }; "template": { "alias": "template"; "required": false; }; "validationRules": { "alias": "validationRules"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "visibleIndex": { "alias": "visibleIndex"; "required": false; }; }, {}, ["_validationRulesContentChildren"], ["*"], true, never>;
}
declare class DxoCardViewFormItemModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoCardViewFormItemModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoCardViewFormItemModule, never, [typeof DxoCardViewFormItemComponent], [typeof DxoCardViewFormItemComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoCardViewFormItemModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoCardViewFormComponent extends NestedOption implements OnDestroy, OnInit {
    set _itemsContentChildren(value: QueryList<CollectionNestedOption>);
    get accessKey(): string | undefined;
    set accessKey(value: string | undefined);
    get activeStateEnabled(): boolean;
    set activeStateEnabled(value: boolean);
    get aiIntegration(): AIIntegration | undefined;
    set aiIntegration(value: AIIntegration | undefined);
    get alignItemLabels(): boolean;
    set alignItemLabels(value: boolean);
    get alignItemLabelsInAllGroups(): boolean;
    set alignItemLabelsInAllGroups(value: boolean);
    get colCount(): Mode | number;
    set colCount(value: Mode | number);
    get colCountByScreen(): {
        lg?: number | undefined;
        md?: number | undefined;
        sm?: number | undefined;
        xs?: number | undefined;
    };
    set colCountByScreen(value: {
        lg?: number | undefined;
        md?: number | undefined;
        sm?: number | undefined;
        xs?: number | undefined;
    });
    get customizeItem(): ((item: dxFormSimpleItem | dxFormGroupItem | dxFormTabbedItem | dxFormEmptyItem | dxFormButtonItem) => void);
    set customizeItem(value: ((item: dxFormSimpleItem | dxFormGroupItem | dxFormTabbedItem | dxFormEmptyItem | dxFormButtonItem) => void));
    get disabled(): boolean;
    set disabled(value: boolean);
    get elementAttr(): Record<string, any>;
    set elementAttr(value: Record<string, any>);
    get focusStateEnabled(): boolean;
    set focusStateEnabled(value: boolean);
    get formData(): any;
    set formData(value: any);
    get height(): number | string | undefined;
    set height(value: number | string | undefined);
    get hint(): string | undefined;
    set hint(value: string | undefined);
    get hoverStateEnabled(): boolean;
    set hoverStateEnabled(value: boolean);
    get isDirty(): boolean;
    set isDirty(value: boolean);
    get items(): Array<dxFormButtonItem | dxFormEmptyItem | dxFormGroupItem | dxFormSimpleItem | dxFormTabbedItem>;
    set items(value: Array<dxFormButtonItem | dxFormEmptyItem | dxFormGroupItem | dxFormSimpleItem | dxFormTabbedItem>);
    get labelLocation(): LabelLocation;
    set labelLocation(value: LabelLocation);
    get labelMode(): FormLabelMode;
    set labelMode(value: FormLabelMode);
    get minColWidth(): number;
    set minColWidth(value: number);
    get onContentReady(): ((e: ContentReadyEvent$2) => void);
    set onContentReady(value: ((e: ContentReadyEvent$2) => void));
    get onDisposing(): ((e: DisposingEvent$2) => void);
    set onDisposing(value: ((e: DisposingEvent$2) => void));
    get onEditorEnterKey(): ((e: EditorEnterKeyEvent) => void) | undefined;
    set onEditorEnterKey(value: ((e: EditorEnterKeyEvent) => void) | undefined);
    get onFieldDataChanged(): ((e: FieldDataChangedEvent) => void) | undefined;
    set onFieldDataChanged(value: ((e: FieldDataChangedEvent) => void) | undefined);
    get onInitialized(): ((e: InitializedEvent$2) => void);
    set onInitialized(value: ((e: InitializedEvent$2) => void));
    get onOptionChanged(): ((e: OptionChangedEvent$2) => void);
    set onOptionChanged(value: ((e: OptionChangedEvent$2) => void));
    get onSmartPasted(): ((e: SmartPastedEvent) => void) | undefined;
    set onSmartPasted(value: ((e: SmartPastedEvent) => void) | undefined);
    get onSmartPasting(): ((e: SmartPastingEvent) => void) | undefined;
    set onSmartPasting(value: ((e: SmartPastingEvent) => void) | undefined);
    get optionalMark(): string;
    set optionalMark(value: string);
    get readOnly(): boolean;
    set readOnly(value: boolean);
    get requiredMark(): string;
    set requiredMark(value: string);
    get requiredMessage(): string;
    set requiredMessage(value: string);
    get rtlEnabled(): boolean;
    set rtlEnabled(value: boolean);
    get screenByWidth(): Function;
    set screenByWidth(value: Function);
    get scrollingEnabled(): boolean;
    set scrollingEnabled(value: boolean);
    get showColonAfterLabel(): boolean;
    set showColonAfterLabel(value: boolean);
    get showOptionalMark(): boolean;
    set showOptionalMark(value: boolean);
    get showRequiredMark(): boolean;
    set showRequiredMark(value: boolean);
    get showValidationSummary(): boolean;
    set showValidationSummary(value: boolean);
    get tabIndex(): number;
    set tabIndex(value: number);
    get validationGroup(): string | undefined;
    set validationGroup(value: string | undefined);
    get visible(): boolean;
    set visible(value: boolean);
    get width(): number | string | undefined;
    set width(value: number | string | undefined);
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    formDataChange: EventEmitter<any>;
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoCardViewFormComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoCardViewFormComponent, "dxo-card-view-form", never, { "accessKey": { "alias": "accessKey"; "required": false; }; "activeStateEnabled": { "alias": "activeStateEnabled"; "required": false; }; "aiIntegration": { "alias": "aiIntegration"; "required": false; }; "alignItemLabels": { "alias": "alignItemLabels"; "required": false; }; "alignItemLabelsInAllGroups": { "alias": "alignItemLabelsInAllGroups"; "required": false; }; "colCount": { "alias": "colCount"; "required": false; }; "colCountByScreen": { "alias": "colCountByScreen"; "required": false; }; "customizeItem": { "alias": "customizeItem"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "elementAttr": { "alias": "elementAttr"; "required": false; }; "focusStateEnabled": { "alias": "focusStateEnabled"; "required": false; }; "formData": { "alias": "formData"; "required": false; }; "height": { "alias": "height"; "required": false; }; "hint": { "alias": "hint"; "required": false; }; "hoverStateEnabled": { "alias": "hoverStateEnabled"; "required": false; }; "isDirty": { "alias": "isDirty"; "required": false; }; "items": { "alias": "items"; "required": false; }; "labelLocation": { "alias": "labelLocation"; "required": false; }; "labelMode": { "alias": "labelMode"; "required": false; }; "minColWidth": { "alias": "minColWidth"; "required": false; }; "onContentReady": { "alias": "onContentReady"; "required": false; }; "onDisposing": { "alias": "onDisposing"; "required": false; }; "onEditorEnterKey": { "alias": "onEditorEnterKey"; "required": false; }; "onFieldDataChanged": { "alias": "onFieldDataChanged"; "required": false; }; "onInitialized": { "alias": "onInitialized"; "required": false; }; "onOptionChanged": { "alias": "onOptionChanged"; "required": false; }; "onSmartPasted": { "alias": "onSmartPasted"; "required": false; }; "onSmartPasting": { "alias": "onSmartPasting"; "required": false; }; "optionalMark": { "alias": "optionalMark"; "required": false; }; "readOnly": { "alias": "readOnly"; "required": false; }; "requiredMark": { "alias": "requiredMark"; "required": false; }; "requiredMessage": { "alias": "requiredMessage"; "required": false; }; "rtlEnabled": { "alias": "rtlEnabled"; "required": false; }; "screenByWidth": { "alias": "screenByWidth"; "required": false; }; "scrollingEnabled": { "alias": "scrollingEnabled"; "required": false; }; "showColonAfterLabel": { "alias": "showColonAfterLabel"; "required": false; }; "showOptionalMark": { "alias": "showOptionalMark"; "required": false; }; "showRequiredMark": { "alias": "showRequiredMark"; "required": false; }; "showValidationSummary": { "alias": "showValidationSummary"; "required": false; }; "tabIndex": { "alias": "tabIndex"; "required": false; }; "validationGroup": { "alias": "validationGroup"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, { "formDataChange": "formDataChange"; }, ["_itemsContentChildren"], never, true, never>;
}
declare class DxoCardViewFormModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoCardViewFormModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoCardViewFormModule, never, [typeof DxoCardViewFormComponent], [typeof DxoCardViewFormComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoCardViewFormModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoCardViewFormatComponent extends NestedOption implements OnDestroy, OnInit {
    get currency(): string;
    set currency(value: string);
    get formatter(): ((value: number | Date) => string);
    set formatter(value: ((value: number | Date) => string));
    get parser(): ((value: string) => number | Date);
    set parser(value: ((value: string) => number | Date));
    get precision(): number;
    set precision(value: number);
    get type(): Format$1 | string;
    set type(value: Format$1 | string);
    get useCurrencyAccountingStyle(): boolean;
    set useCurrencyAccountingStyle(value: boolean);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoCardViewFormatComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoCardViewFormatComponent, "dxo-card-view-format", never, { "currency": { "alias": "currency"; "required": false; }; "formatter": { "alias": "formatter"; "required": false; }; "parser": { "alias": "parser"; "required": false; }; "precision": { "alias": "precision"; "required": false; }; "type": { "alias": "type"; "required": false; }; "useCurrencyAccountingStyle": { "alias": "useCurrencyAccountingStyle"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoCardViewFormatModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoCardViewFormatModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoCardViewFormatModule, never, [typeof DxoCardViewFormatComponent], [typeof DxoCardViewFormatComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoCardViewFormatModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoCardViewFromComponent extends NestedOption implements OnDestroy, OnInit {
    get left(): number;
    set left(value: number);
    get opacity(): number;
    set opacity(value: number);
    get position(): PositionConfig;
    set position(value: PositionConfig);
    get scale(): number;
    set scale(value: number);
    get top(): number;
    set top(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoCardViewFromComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoCardViewFromComponent, "dxo-card-view-from", never, { "left": { "alias": "left"; "required": false; }; "opacity": { "alias": "opacity"; "required": false; }; "position": { "alias": "position"; "required": false; }; "scale": { "alias": "scale"; "required": false; }; "top": { "alias": "top"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoCardViewFromModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoCardViewFromModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoCardViewFromModule, never, [typeof DxoCardViewFromComponent], [typeof DxoCardViewFromComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoCardViewFromModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxiCardViewGroupItemComponent extends CollectionNestedOption implements AfterViewInit, IDxTemplateHost {
    private renderer;
    private document;
    private element;
    set _itemsContentChildren(value: QueryList<CollectionNestedOption>);
    get alignItemLabels(): boolean;
    set alignItemLabels(value: boolean);
    get caption(): string | undefined;
    set caption(value: string | undefined);
    get captionTemplate(): any;
    set captionTemplate(value: any);
    get colCount(): number;
    set colCount(value: number);
    get colCountByScreen(): {
        lg?: number | undefined;
        md?: number | undefined;
        sm?: number | undefined;
        xs?: number | undefined;
    };
    set colCountByScreen(value: {
        lg?: number | undefined;
        md?: number | undefined;
        sm?: number | undefined;
        xs?: number | undefined;
    });
    get colSpan(): number | undefined;
    set colSpan(value: number | undefined);
    get cssClass(): string | undefined;
    set cssClass(value: string | undefined);
    get items(): Array<dxFormButtonItem | dxFormEmptyItem | dxFormGroupItem | dxFormSimpleItem | dxFormTabbedItem>;
    set items(value: Array<dxFormButtonItem | dxFormEmptyItem | dxFormGroupItem | dxFormSimpleItem | dxFormTabbedItem>);
    get itemType(): FormItemType;
    set itemType(value: FormItemType);
    get name(): string | undefined;
    set name(value: string | undefined);
    get template(): any;
    set template(value: any);
    get visible(): boolean;
    set visible(value: boolean);
    get visibleIndex(): number | undefined;
    set visibleIndex(value: number | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost, renderer: Renderer2, document: any, templateHost: DxTemplateHost, element: ElementRef);
    setTemplate(template: DxTemplateDirective): void;
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiCardViewGroupItemComponent, [{ host: true; skipSelf: true; }, { host: true; }, null, null, { host: true; }, null]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiCardViewGroupItemComponent, "dxi-card-view-group-item", never, { "alignItemLabels": { "alias": "alignItemLabels"; "required": false; }; "caption": { "alias": "caption"; "required": false; }; "captionTemplate": { "alias": "captionTemplate"; "required": false; }; "colCount": { "alias": "colCount"; "required": false; }; "colCountByScreen": { "alias": "colCountByScreen"; "required": false; }; "colSpan": { "alias": "colSpan"; "required": false; }; "cssClass": { "alias": "cssClass"; "required": false; }; "items": { "alias": "items"; "required": false; }; "itemType": { "alias": "itemType"; "required": false; }; "name": { "alias": "name"; "required": false; }; "template": { "alias": "template"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "visibleIndex": { "alias": "visibleIndex"; "required": false; }; }, {}, ["_itemsContentChildren"], ["*"], true, never>;
}
declare class DxiCardViewGroupItemModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiCardViewGroupItemModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiCardViewGroupItemModule, never, [typeof DxiCardViewGroupItemComponent], [typeof DxiCardViewGroupItemComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiCardViewGroupItemModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoCardViewGroupOperationDescriptionsComponent extends NestedOption implements OnDestroy, OnInit {
    get and(): string;
    set and(value: string);
    get notAnd(): string;
    set notAnd(value: string);
    get notOr(): string;
    set notOr(value: string);
    get or(): string;
    set or(value: string);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoCardViewGroupOperationDescriptionsComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoCardViewGroupOperationDescriptionsComponent, "dxo-card-view-group-operation-descriptions", never, { "and": { "alias": "and"; "required": false; }; "notAnd": { "alias": "notAnd"; "required": false; }; "notOr": { "alias": "notOr"; "required": false; }; "or": { "alias": "or"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoCardViewGroupOperationDescriptionsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoCardViewGroupOperationDescriptionsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoCardViewGroupOperationDescriptionsModule, never, [typeof DxoCardViewGroupOperationDescriptionsComponent], [typeof DxoCardViewGroupOperationDescriptionsComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoCardViewGroupOperationDescriptionsModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoCardViewHeaderFilterComponent extends NestedOption implements OnDestroy, OnInit {
    get allowSearch(): boolean;
    set allowSearch(value: boolean);
    get allowSelectAll(): boolean;
    set allowSelectAll(value: boolean);
    get dataSource(): Array<any> | DataSourceOptions | ((options: {
        component: Record<string, any>;
        dataSource: DataSourceOptions | null;
    }) => void) | null | Store | undefined;
    set dataSource(value: Array<any> | DataSourceOptions | ((options: {
        component: Record<string, any>;
        dataSource: DataSourceOptions | null;
    }) => void) | null | Store | undefined);
    get groupInterval(): Array<number | string> | HeaderFilterGroupInterval | number | undefined;
    set groupInterval(value: Array<number | string> | HeaderFilterGroupInterval | number | undefined);
    get height(): number | string | undefined;
    set height(value: number | string | undefined);
    get search(): ColumnHeaderFilterSearchConfig | HeaderFilterSearchConfig;
    set search(value: ColumnHeaderFilterSearchConfig | HeaderFilterSearchConfig);
    get searchMode(): SearchMode;
    set searchMode(value: SearchMode);
    get width(): number | string | undefined;
    set width(value: number | string | undefined);
    get searchTimeout(): number;
    set searchTimeout(value: number);
    get texts(): HeaderFilterTexts;
    set texts(value: HeaderFilterTexts);
    get visible(): boolean;
    set visible(value: boolean);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoCardViewHeaderFilterComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoCardViewHeaderFilterComponent, "dxo-card-view-header-filter", never, { "allowSearch": { "alias": "allowSearch"; "required": false; }; "allowSelectAll": { "alias": "allowSelectAll"; "required": false; }; "dataSource": { "alias": "dataSource"; "required": false; }; "groupInterval": { "alias": "groupInterval"; "required": false; }; "height": { "alias": "height"; "required": false; }; "search": { "alias": "search"; "required": false; }; "searchMode": { "alias": "searchMode"; "required": false; }; "width": { "alias": "width"; "required": false; }; "searchTimeout": { "alias": "searchTimeout"; "required": false; }; "texts": { "alias": "texts"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoCardViewHeaderFilterModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoCardViewHeaderFilterModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoCardViewHeaderFilterModule, never, [typeof DxoCardViewHeaderFilterComponent], [typeof DxoCardViewHeaderFilterComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoCardViewHeaderFilterModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoCardViewHeaderPanelComponent extends NestedOption implements OnDestroy, OnInit {
    get dragging(): {
        dropFeedbackMode?: DragHighlight;
        onDragChange?: ((e: any) => void);
        onDragEnd?: ((e: any) => void);
        onDragMove?: ((e: any) => void);
        onDragStart?: ((e: any) => void);
        onRemove?: ((e: any) => void);
        onReorder?: ((e: any) => void);
        scrollSensitivity?: number;
        scrollSpeed?: number;
    };
    set dragging(value: {
        dropFeedbackMode?: DragHighlight;
        onDragChange?: ((e: any) => void);
        onDragEnd?: ((e: any) => void);
        onDragMove?: ((e: any) => void);
        onDragStart?: ((e: any) => void);
        onRemove?: ((e: any) => void);
        onReorder?: ((e: any) => void);
        scrollSensitivity?: number;
        scrollSpeed?: number;
    });
    get itemCssClass(): string;
    set itemCssClass(value: string);
    get itemTemplate(): any;
    set itemTemplate(value: any);
    get visible(): boolean;
    set visible(value: boolean);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoCardViewHeaderPanelComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoCardViewHeaderPanelComponent, "dxo-card-view-header-panel", never, { "dragging": { "alias": "dragging"; "required": false; }; "itemCssClass": { "alias": "itemCssClass"; "required": false; }; "itemTemplate": { "alias": "itemTemplate"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoCardViewHeaderPanelModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoCardViewHeaderPanelModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoCardViewHeaderPanelModule, never, [typeof DxoCardViewHeaderPanelComponent], [typeof DxoCardViewHeaderPanelComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoCardViewHeaderPanelModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoCardViewHideComponent extends NestedOption implements OnDestroy, OnInit {
    get complete(): (($element: any, config: AnimationConfig) => void);
    set complete(value: (($element: any, config: AnimationConfig) => void));
    get delay(): number;
    set delay(value: number);
    get direction(): Direction | undefined;
    set direction(value: Direction | undefined);
    get duration(): number;
    set duration(value: number);
    get easing(): string;
    set easing(value: string);
    get from(): AnimationState;
    set from(value: AnimationState);
    get staggerDelay(): number | undefined;
    set staggerDelay(value: number | undefined);
    get start(): (($element: any, config: AnimationConfig) => void);
    set start(value: (($element: any, config: AnimationConfig) => void));
    get to(): AnimationState;
    set to(value: AnimationState);
    get type(): AnimationType;
    set type(value: AnimationType);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoCardViewHideComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoCardViewHideComponent, "dxo-card-view-hide", never, { "complete": { "alias": "complete"; "required": false; }; "delay": { "alias": "delay"; "required": false; }; "direction": { "alias": "direction"; "required": false; }; "duration": { "alias": "duration"; "required": false; }; "easing": { "alias": "easing"; "required": false; }; "from": { "alias": "from"; "required": false; }; "staggerDelay": { "alias": "staggerDelay"; "required": false; }; "start": { "alias": "start"; "required": false; }; "to": { "alias": "to"; "required": false; }; "type": { "alias": "type"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoCardViewHideModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoCardViewHideModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoCardViewHideModule, never, [typeof DxoCardViewHideComponent], [typeof DxoCardViewHideComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoCardViewHideModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoCardViewIndicatorOptionsComponent extends NestedOption implements OnDestroy, OnInit {
    get animationType(): LoadingAnimationType;
    set animationType(value: LoadingAnimationType);
    get height(): number | string | undefined;
    set height(value: number | string | undefined);
    get src(): string;
    set src(value: string);
    get width(): number | string | undefined;
    set width(value: number | string | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoCardViewIndicatorOptionsComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoCardViewIndicatorOptionsComponent, "dxo-card-view-indicator-options", never, { "animationType": { "alias": "animationType"; "required": false; }; "height": { "alias": "height"; "required": false; }; "src": { "alias": "src"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoCardViewIndicatorOptionsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoCardViewIndicatorOptionsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoCardViewIndicatorOptionsModule, never, [typeof DxoCardViewIndicatorOptionsComponent], [typeof DxoCardViewIndicatorOptionsComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoCardViewIndicatorOptionsModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxiCardViewItemComponent extends CollectionNestedOption implements AfterViewInit, IDxTemplateHost {
    private renderer;
    private document;
    private element;
    set _validationRulesContentChildren(value: QueryList<CollectionNestedOption>);
    set _tabsContentChildren(value: QueryList<CollectionNestedOption>);
    set _itemsContentChildren(value: QueryList<CollectionNestedOption>);
    get cssClass(): string | undefined;
    set cssClass(value: string | undefined);
    get disabled(): boolean;
    set disabled(value: boolean);
    get html(): string;
    set html(value: string);
    get locateInMenu(): LocateInMenuMode;
    set locateInMenu(value: LocateInMenuMode);
    get location(): ToolbarItemLocation;
    set location(value: ToolbarItemLocation);
    get menuItemTemplate(): any;
    set menuItemTemplate(value: any);
    get name(): CardHeaderPredefinedItem | string | undefined | FormPredefinedButtonItem | PredefinedToolbarItem;
    set name(value: CardHeaderPredefinedItem | string | undefined | FormPredefinedButtonItem | PredefinedToolbarItem);
    get options(): any;
    set options(value: any);
    get showText(): ShowTextMode;
    set showText(value: ShowTextMode);
    get template(): any;
    set template(value: any);
    get text(): string;
    set text(value: string);
    get visible(): boolean;
    set visible(value: boolean);
    get widget(): ToolbarItemComponent;
    set widget(value: ToolbarItemComponent);
    get badge(): string;
    set badge(value: string);
    get icon(): string;
    set icon(value: string);
    get tabTemplate(): any;
    set tabTemplate(value: any);
    get title(): string;
    set title(value: string);
    get aiOptions(): {
        disabled?: boolean;
        instruction?: string | undefined;
    };
    set aiOptions(value: {
        disabled?: boolean;
        instruction?: string | undefined;
    });
    get colSpan(): number | undefined;
    set colSpan(value: number | undefined);
    get dataField(): string | undefined;
    set dataField(value: string | undefined);
    get editorOptions(): any | undefined;
    set editorOptions(value: any | undefined);
    get editorType(): FormItemComponent;
    set editorType(value: FormItemComponent);
    get helpText(): string | undefined;
    set helpText(value: string | undefined);
    get isRequired(): boolean | undefined;
    set isRequired(value: boolean | undefined);
    get itemType(): FormItemType;
    set itemType(value: FormItemType);
    get label(): {
        alignment?: HorizontalAlignment;
        location?: LabelLocation;
        showColon?: boolean;
        template?: any;
        text?: string | undefined;
        visible?: boolean;
    };
    set label(value: {
        alignment?: HorizontalAlignment;
        location?: LabelLocation;
        showColon?: boolean;
        template?: any;
        text?: string | undefined;
        visible?: boolean;
    });
    get validationRules(): Array<CommonTypes.ValidationRule>;
    set validationRules(value: Array<CommonTypes.ValidationRule>);
    get visibleIndex(): number | undefined;
    set visibleIndex(value: number | undefined);
    get alignItemLabels(): boolean;
    set alignItemLabels(value: boolean);
    get caption(): string | undefined;
    set caption(value: string | undefined);
    get captionTemplate(): any;
    set captionTemplate(value: any);
    get colCount(): number;
    set colCount(value: number);
    get colCountByScreen(): {
        lg?: number | undefined;
        md?: number | undefined;
        sm?: number | undefined;
        xs?: number | undefined;
    };
    set colCountByScreen(value: {
        lg?: number | undefined;
        md?: number | undefined;
        sm?: number | undefined;
        xs?: number | undefined;
    });
    get items(): Array<dxFormButtonItem | dxFormEmptyItem | dxFormGroupItem | dxFormSimpleItem | dxFormTabbedItem>;
    set items(value: Array<dxFormButtonItem | dxFormEmptyItem | dxFormGroupItem | dxFormSimpleItem | dxFormTabbedItem>);
    get tabPanelOptions(): dxTabPanelOptions | undefined;
    set tabPanelOptions(value: dxTabPanelOptions | undefined);
    get tabs(): {
        alignItemLabels?: boolean;
        badge?: string | undefined;
        colCount?: number;
        colCountByScreen?: {
            lg?: number | undefined;
            md?: number | undefined;
            sm?: number | undefined;
            xs?: number | undefined;
        };
        disabled?: boolean;
        icon?: string | undefined;
        items?: Array<dxFormButtonItem | dxFormEmptyItem | dxFormGroupItem | dxFormSimpleItem | dxFormTabbedItem>;
        tabTemplate?: any;
        template?: any;
        title?: string | undefined;
    }[];
    set tabs(value: {
        alignItemLabels?: boolean;
        badge?: string | undefined;
        colCount?: number;
        colCountByScreen?: {
            lg?: number | undefined;
            md?: number | undefined;
            sm?: number | undefined;
            xs?: number | undefined;
        };
        disabled?: boolean;
        icon?: string | undefined;
        items?: Array<dxFormButtonItem | dxFormEmptyItem | dxFormGroupItem | dxFormSimpleItem | dxFormTabbedItem>;
        tabTemplate?: any;
        template?: any;
        title?: string | undefined;
    }[]);
    get buttonOptions(): dxButtonOptions | undefined;
    set buttonOptions(value: dxButtonOptions | undefined);
    get horizontalAlignment(): HorizontalAlignment;
    set horizontalAlignment(value: HorizontalAlignment);
    get verticalAlignment(): VerticalAlignment;
    set verticalAlignment(value: VerticalAlignment);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost, renderer: Renderer2, document: any, templateHost: DxTemplateHost, element: ElementRef);
    setTemplate(template: DxTemplateDirective): void;
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiCardViewItemComponent, [{ host: true; skipSelf: true; }, { host: true; }, null, null, { host: true; }, null]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiCardViewItemComponent, "dxi-card-view-item", never, { "cssClass": { "alias": "cssClass"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "html": { "alias": "html"; "required": false; }; "locateInMenu": { "alias": "locateInMenu"; "required": false; }; "location": { "alias": "location"; "required": false; }; "menuItemTemplate": { "alias": "menuItemTemplate"; "required": false; }; "name": { "alias": "name"; "required": false; }; "options": { "alias": "options"; "required": false; }; "showText": { "alias": "showText"; "required": false; }; "template": { "alias": "template"; "required": false; }; "text": { "alias": "text"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "widget": { "alias": "widget"; "required": false; }; "badge": { "alias": "badge"; "required": false; }; "icon": { "alias": "icon"; "required": false; }; "tabTemplate": { "alias": "tabTemplate"; "required": false; }; "title": { "alias": "title"; "required": false; }; "aiOptions": { "alias": "aiOptions"; "required": false; }; "colSpan": { "alias": "colSpan"; "required": false; }; "dataField": { "alias": "dataField"; "required": false; }; "editorOptions": { "alias": "editorOptions"; "required": false; }; "editorType": { "alias": "editorType"; "required": false; }; "helpText": { "alias": "helpText"; "required": false; }; "isRequired": { "alias": "isRequired"; "required": false; }; "itemType": { "alias": "itemType"; "required": false; }; "label": { "alias": "label"; "required": false; }; "validationRules": { "alias": "validationRules"; "required": false; }; "visibleIndex": { "alias": "visibleIndex"; "required": false; }; "alignItemLabels": { "alias": "alignItemLabels"; "required": false; }; "caption": { "alias": "caption"; "required": false; }; "captionTemplate": { "alias": "captionTemplate"; "required": false; }; "colCount": { "alias": "colCount"; "required": false; }; "colCountByScreen": { "alias": "colCountByScreen"; "required": false; }; "items": { "alias": "items"; "required": false; }; "tabPanelOptions": { "alias": "tabPanelOptions"; "required": false; }; "tabs": { "alias": "tabs"; "required": false; }; "buttonOptions": { "alias": "buttonOptions"; "required": false; }; "horizontalAlignment": { "alias": "horizontalAlignment"; "required": false; }; "verticalAlignment": { "alias": "verticalAlignment"; "required": false; }; }, {}, ["_validationRulesContentChildren", "_tabsContentChildren", "_itemsContentChildren"], ["*"], true, never>;
}
declare class DxiCardViewItemModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiCardViewItemModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiCardViewItemModule, never, [typeof DxiCardViewItemComponent], [typeof DxiCardViewItemComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiCardViewItemModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoCardViewLabelComponent extends NestedOption implements AfterViewInit, OnDestroy, OnInit, IDxTemplateHost {
    private renderer;
    private document;
    private element;
    get alignment(): HorizontalAlignment;
    set alignment(value: HorizontalAlignment);
    get location(): LabelLocation;
    set location(value: LabelLocation);
    get showColon(): boolean;
    set showColon(value: boolean);
    get template(): any;
    set template(value: any);
    get text(): string | undefined;
    set text(value: string | undefined);
    get visible(): boolean;
    set visible(value: boolean);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost, renderer: Renderer2, document: any, templateHost: DxTemplateHost, element: ElementRef);
    setTemplate(template: DxTemplateDirective): void;
    ngAfterViewInit(): void;
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoCardViewLabelComponent, [{ host: true; skipSelf: true; }, { host: true; }, null, null, { host: true; }, null]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoCardViewLabelComponent, "dxo-card-view-label", never, { "alignment": { "alias": "alignment"; "required": false; }; "location": { "alias": "location"; "required": false; }; "showColon": { "alias": "showColon"; "required": false; }; "template": { "alias": "template"; "required": false; }; "text": { "alias": "text"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; }, {}, never, ["*"], true, never>;
}
declare class DxoCardViewLabelModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoCardViewLabelModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoCardViewLabelModule, never, [typeof DxoCardViewLabelComponent], [typeof DxoCardViewLabelComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoCardViewLabelModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoCardViewLoadPanelComponent extends NestedOption implements OnDestroy, OnInit {
    get animation(): {
        hide?: AnimationConfig;
        show?: AnimationConfig;
    };
    set animation(value: {
        hide?: AnimationConfig;
        show?: AnimationConfig;
    });
    get container(): any | string | undefined;
    set container(value: any | string | undefined);
    get deferRendering(): boolean;
    set deferRendering(value: boolean);
    get delay(): number;
    set delay(value: number);
    get focusStateEnabled(): boolean;
    set focusStateEnabled(value: boolean);
    get height(): number | string;
    set height(value: number | string);
    get hideOnOutsideClick(): boolean | ((event: event) => boolean);
    set hideOnOutsideClick(value: boolean | ((event: event) => boolean));
    get hideOnParentScroll(): boolean;
    set hideOnParentScroll(value: boolean);
    get hint(): string | undefined;
    set hint(value: string | undefined);
    get hoverStateEnabled(): boolean;
    set hoverStateEnabled(value: boolean);
    get indicatorOptions(): LoadPanelIndicatorProperties;
    set indicatorOptions(value: LoadPanelIndicatorProperties);
    get indicatorSrc(): string;
    set indicatorSrc(value: string);
    get maxHeight(): number | string;
    set maxHeight(value: number | string);
    get maxWidth(): number | string;
    set maxWidth(value: number | string);
    get message(): string;
    set message(value: string);
    get minHeight(): number | string;
    set minHeight(value: number | string);
    get minWidth(): number | string;
    set minWidth(value: number | string);
    get onContentReady(): ((e: ContentReadyEvent$3) => void);
    set onContentReady(value: ((e: ContentReadyEvent$3) => void));
    get onDisposing(): ((e: DisposingEvent$3) => void);
    set onDisposing(value: ((e: DisposingEvent$3) => void));
    get onHidden(): ((e: HiddenEvent) => void);
    set onHidden(value: ((e: HiddenEvent) => void));
    get onHiding(): ((e: HidingEvent) => void);
    set onHiding(value: ((e: HidingEvent) => void));
    get onInitialized(): ((e: InitializedEvent$3) => void);
    set onInitialized(value: ((e: InitializedEvent$3) => void));
    get onOptionChanged(): ((e: OptionChangedEvent$3) => void);
    set onOptionChanged(value: ((e: OptionChangedEvent$3) => void));
    get onShowing(): ((e: ShowingEvent) => void);
    set onShowing(value: ((e: ShowingEvent) => void));
    get onShown(): ((e: ShownEvent) => void);
    set onShown(value: ((e: ShownEvent) => void));
    get position(): Function | PositionAlignment | PositionConfig;
    set position(value: Function | PositionAlignment | PositionConfig);
    get rtlEnabled(): boolean;
    set rtlEnabled(value: boolean);
    get shading(): boolean;
    set shading(value: boolean);
    get shadingColor(): string;
    set shadingColor(value: string);
    get showIndicator(): boolean;
    set showIndicator(value: boolean);
    get showPane(): boolean;
    set showPane(value: boolean);
    get visible(): boolean;
    set visible(value: boolean);
    get width(): number | string;
    set width(value: number | string);
    get wrapperAttr(): any;
    set wrapperAttr(value: any);
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    positionChange: EventEmitter<Function | PositionAlignment | PositionConfig>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    visibleChange: EventEmitter<boolean>;
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoCardViewLoadPanelComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoCardViewLoadPanelComponent, "dxo-card-view-load-panel", never, { "animation": { "alias": "animation"; "required": false; }; "container": { "alias": "container"; "required": false; }; "deferRendering": { "alias": "deferRendering"; "required": false; }; "delay": { "alias": "delay"; "required": false; }; "focusStateEnabled": { "alias": "focusStateEnabled"; "required": false; }; "height": { "alias": "height"; "required": false; }; "hideOnOutsideClick": { "alias": "hideOnOutsideClick"; "required": false; }; "hideOnParentScroll": { "alias": "hideOnParentScroll"; "required": false; }; "hint": { "alias": "hint"; "required": false; }; "hoverStateEnabled": { "alias": "hoverStateEnabled"; "required": false; }; "indicatorOptions": { "alias": "indicatorOptions"; "required": false; }; "indicatorSrc": { "alias": "indicatorSrc"; "required": false; }; "maxHeight": { "alias": "maxHeight"; "required": false; }; "maxWidth": { "alias": "maxWidth"; "required": false; }; "message": { "alias": "message"; "required": false; }; "minHeight": { "alias": "minHeight"; "required": false; }; "minWidth": { "alias": "minWidth"; "required": false; }; "onContentReady": { "alias": "onContentReady"; "required": false; }; "onDisposing": { "alias": "onDisposing"; "required": false; }; "onHidden": { "alias": "onHidden"; "required": false; }; "onHiding": { "alias": "onHiding"; "required": false; }; "onInitialized": { "alias": "onInitialized"; "required": false; }; "onOptionChanged": { "alias": "onOptionChanged"; "required": false; }; "onShowing": { "alias": "onShowing"; "required": false; }; "onShown": { "alias": "onShown"; "required": false; }; "position": { "alias": "position"; "required": false; }; "rtlEnabled": { "alias": "rtlEnabled"; "required": false; }; "shading": { "alias": "shading"; "required": false; }; "shadingColor": { "alias": "shadingColor"; "required": false; }; "showIndicator": { "alias": "showIndicator"; "required": false; }; "showPane": { "alias": "showPane"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; "wrapperAttr": { "alias": "wrapperAttr"; "required": false; }; }, { "positionChange": "positionChange"; "visibleChange": "visibleChange"; }, never, never, true, never>;
}
declare class DxoCardViewLoadPanelModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoCardViewLoadPanelModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoCardViewLoadPanelModule, never, [typeof DxoCardViewLoadPanelComponent], [typeof DxoCardViewLoadPanelComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoCardViewLoadPanelModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoCardViewLookupComponent extends NestedOption implements OnDestroy, OnInit {
    get allowClearing(): boolean;
    set allowClearing(value: boolean);
    get dataSource(): Array<any> | DataSourceOptions | Store | undefined;
    set dataSource(value: Array<any> | DataSourceOptions | Store | undefined);
    get displayExpr(): ((data: any) => string) | string | undefined;
    set displayExpr(value: ((data: any) => string) | string | undefined);
    get valueExpr(): ((data: any) => string | number | boolean) | string | undefined;
    set valueExpr(value: ((data: any) => string | number | boolean) | string | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoCardViewLookupComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoCardViewLookupComponent, "dxo-card-view-lookup", never, { "allowClearing": { "alias": "allowClearing"; "required": false; }; "dataSource": { "alias": "dataSource"; "required": false; }; "displayExpr": { "alias": "displayExpr"; "required": false; }; "valueExpr": { "alias": "valueExpr"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoCardViewLookupModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoCardViewLookupModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoCardViewLookupModule, never, [typeof DxoCardViewLookupComponent], [typeof DxoCardViewLookupComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoCardViewLookupModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoCardViewMyComponent extends NestedOption implements OnDestroy, OnInit {
    get x(): HorizontalAlignment;
    set x(value: HorizontalAlignment);
    get y(): VerticalAlignment;
    set y(value: VerticalAlignment);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoCardViewMyComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoCardViewMyComponent, "dxo-card-view-my", never, { "x": { "alias": "x"; "required": false; }; "y": { "alias": "y"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoCardViewMyModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoCardViewMyModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoCardViewMyModule, never, [typeof DxoCardViewMyComponent], [typeof DxoCardViewMyComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoCardViewMyModule>;
}

declare class DxiCardViewNumericRuleComponent extends CollectionNestedOption {
    get ignoreEmptyValue(): boolean;
    set ignoreEmptyValue(value: boolean);
    get message(): string;
    set message(value: string);
    get type(): ValidationRuleType;
    set type(value: ValidationRuleType);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiCardViewNumericRuleComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiCardViewNumericRuleComponent, "dxi-card-view-numeric-rule", never, { "ignoreEmptyValue": { "alias": "ignoreEmptyValue"; "required": false; }; "message": { "alias": "message"; "required": false; }; "type": { "alias": "type"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxiCardViewNumericRuleModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiCardViewNumericRuleModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiCardViewNumericRuleModule, never, [typeof DxiCardViewNumericRuleComponent], [typeof DxiCardViewNumericRuleComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiCardViewNumericRuleModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoCardViewOffsetComponent extends NestedOption implements OnDestroy, OnInit {
    get x(): number;
    set x(value: number);
    get y(): number;
    set y(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoCardViewOffsetComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoCardViewOffsetComponent, "dxo-card-view-offset", never, { "x": { "alias": "x"; "required": false; }; "y": { "alias": "y"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoCardViewOffsetModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoCardViewOffsetModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoCardViewOffsetModule, never, [typeof DxoCardViewOffsetComponent], [typeof DxoCardViewOffsetComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoCardViewOffsetModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoCardViewPagerComponent extends NestedOption implements OnDestroy, OnInit {
    get allowedPageSizes(): Array<number | PagerPageSize> | Mode;
    set allowedPageSizes(value: Array<number | PagerPageSize> | Mode);
    get displayMode(): DisplayMode;
    set displayMode(value: DisplayMode);
    get infoText(): string;
    set infoText(value: string);
    get label(): string;
    set label(value: string);
    get showInfo(): boolean;
    set showInfo(value: boolean);
    get showNavigationButtons(): boolean;
    set showNavigationButtons(value: boolean);
    get showPageSizeSelector(): boolean | Mode;
    set showPageSizeSelector(value: boolean | Mode);
    get visible(): boolean | Mode;
    set visible(value: boolean | Mode);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoCardViewPagerComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoCardViewPagerComponent, "dxo-card-view-pager", never, { "allowedPageSizes": { "alias": "allowedPageSizes"; "required": false; }; "displayMode": { "alias": "displayMode"; "required": false; }; "infoText": { "alias": "infoText"; "required": false; }; "label": { "alias": "label"; "required": false; }; "showInfo": { "alias": "showInfo"; "required": false; }; "showNavigationButtons": { "alias": "showNavigationButtons"; "required": false; }; "showPageSizeSelector": { "alias": "showPageSizeSelector"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoCardViewPagerModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoCardViewPagerModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoCardViewPagerModule, never, [typeof DxoCardViewPagerComponent], [typeof DxoCardViewPagerComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoCardViewPagerModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoCardViewPagingComponent extends NestedOption implements OnDestroy, OnInit {
    get enabled(): boolean;
    set enabled(value: boolean);
    get pageIndex(): number;
    set pageIndex(value: number);
    get pageSize(): number;
    set pageSize(value: number);
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    pageIndexChange: EventEmitter<number>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    pageSizeChange: EventEmitter<number>;
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoCardViewPagingComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoCardViewPagingComponent, "dxo-card-view-paging", never, { "enabled": { "alias": "enabled"; "required": false; }; "pageIndex": { "alias": "pageIndex"; "required": false; }; "pageSize": { "alias": "pageSize"; "required": false; }; }, { "pageIndexChange": "pageIndexChange"; "pageSizeChange": "pageSizeChange"; }, never, never, true, never>;
}
declare class DxoCardViewPagingModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoCardViewPagingModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoCardViewPagingModule, never, [typeof DxoCardViewPagingComponent], [typeof DxoCardViewPagingComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoCardViewPagingModule>;
}

declare class DxiCardViewPatternRuleComponent extends CollectionNestedOption {
    get ignoreEmptyValue(): boolean;
    set ignoreEmptyValue(value: boolean);
    get message(): string;
    set message(value: string);
    get pattern(): RegExp | string;
    set pattern(value: RegExp | string);
    get type(): ValidationRuleType;
    set type(value: ValidationRuleType);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiCardViewPatternRuleComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiCardViewPatternRuleComponent, "dxi-card-view-pattern-rule", never, { "ignoreEmptyValue": { "alias": "ignoreEmptyValue"; "required": false; }; "message": { "alias": "message"; "required": false; }; "pattern": { "alias": "pattern"; "required": false; }; "type": { "alias": "type"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxiCardViewPatternRuleModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiCardViewPatternRuleModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiCardViewPatternRuleModule, never, [typeof DxiCardViewPatternRuleComponent], [typeof DxiCardViewPatternRuleComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiCardViewPatternRuleModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoCardViewPositionComponent extends NestedOption implements OnDestroy, OnInit {
    get at(): PositionAlignment | {
        x?: HorizontalAlignment;
        y?: VerticalAlignment;
    };
    set at(value: PositionAlignment | {
        x?: HorizontalAlignment;
        y?: VerticalAlignment;
    });
    get boundary(): any | string;
    set boundary(value: any | string);
    get boundaryOffset(): string | {
        x?: number;
        y?: number;
    };
    set boundaryOffset(value: string | {
        x?: number;
        y?: number;
    });
    get collision(): CollisionResolutionCombination | {
        x?: CollisionResolution;
        y?: CollisionResolution;
    };
    set collision(value: CollisionResolutionCombination | {
        x?: CollisionResolution;
        y?: CollisionResolution;
    });
    get my(): PositionAlignment | {
        x?: HorizontalAlignment;
        y?: VerticalAlignment;
    };
    set my(value: PositionAlignment | {
        x?: HorizontalAlignment;
        y?: VerticalAlignment;
    });
    get of(): any | string;
    set of(value: any | string);
    get offset(): string | {
        x?: number;
        y?: number;
    };
    set offset(value: string | {
        x?: number;
        y?: number;
    });
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoCardViewPositionComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoCardViewPositionComponent, "dxo-card-view-position", never, { "at": { "alias": "at"; "required": false; }; "boundary": { "alias": "boundary"; "required": false; }; "boundaryOffset": { "alias": "boundaryOffset"; "required": false; }; "collision": { "alias": "collision"; "required": false; }; "my": { "alias": "my"; "required": false; }; "of": { "alias": "of"; "required": false; }; "offset": { "alias": "offset"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoCardViewPositionModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoCardViewPositionModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoCardViewPositionModule, never, [typeof DxoCardViewPositionComponent], [typeof DxoCardViewPositionComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoCardViewPositionModule>;
}

declare class DxiCardViewRangeRuleComponent extends CollectionNestedOption {
    get ignoreEmptyValue(): boolean;
    set ignoreEmptyValue(value: boolean);
    get max(): Date | number | string;
    set max(value: Date | number | string);
    get message(): string;
    set message(value: string);
    get min(): Date | number | string;
    set min(value: Date | number | string);
    get reevaluate(): boolean;
    set reevaluate(value: boolean);
    get type(): ValidationRuleType;
    set type(value: ValidationRuleType);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiCardViewRangeRuleComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiCardViewRangeRuleComponent, "dxi-card-view-range-rule", never, { "ignoreEmptyValue": { "alias": "ignoreEmptyValue"; "required": false; }; "max": { "alias": "max"; "required": false; }; "message": { "alias": "message"; "required": false; }; "min": { "alias": "min"; "required": false; }; "reevaluate": { "alias": "reevaluate"; "required": false; }; "type": { "alias": "type"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxiCardViewRangeRuleModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiCardViewRangeRuleModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiCardViewRangeRuleModule, never, [typeof DxiCardViewRangeRuleComponent], [typeof DxiCardViewRangeRuleComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiCardViewRangeRuleModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoCardViewRemoteOperationsComponent extends NestedOption implements OnDestroy, OnInit {
    get filtering(): boolean;
    set filtering(value: boolean);
    get grouping(): boolean;
    set grouping(value: boolean);
    get paging(): boolean;
    set paging(value: boolean);
    get sorting(): boolean;
    set sorting(value: boolean);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoCardViewRemoteOperationsComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoCardViewRemoteOperationsComponent, "dxo-card-view-remote-operations", never, { "filtering": { "alias": "filtering"; "required": false; }; "grouping": { "alias": "grouping"; "required": false; }; "paging": { "alias": "paging"; "required": false; }; "sorting": { "alias": "sorting"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoCardViewRemoteOperationsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoCardViewRemoteOperationsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoCardViewRemoteOperationsModule, never, [typeof DxoCardViewRemoteOperationsComponent], [typeof DxoCardViewRemoteOperationsComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoCardViewRemoteOperationsModule>;
}

declare class DxiCardViewRequiredRuleComponent extends CollectionNestedOption {
    get message(): string;
    set message(value: string);
    get trim(): boolean;
    set trim(value: boolean);
    get type(): ValidationRuleType;
    set type(value: ValidationRuleType);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiCardViewRequiredRuleComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiCardViewRequiredRuleComponent, "dxi-card-view-required-rule", never, { "message": { "alias": "message"; "required": false; }; "trim": { "alias": "trim"; "required": false; }; "type": { "alias": "type"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxiCardViewRequiredRuleModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiCardViewRequiredRuleModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiCardViewRequiredRuleModule, never, [typeof DxiCardViewRequiredRuleComponent], [typeof DxiCardViewRequiredRuleComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiCardViewRequiredRuleModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoCardViewScrollingComponent extends NestedOption implements OnDestroy, OnInit {
    get scrollByContent(): boolean;
    set scrollByContent(value: boolean);
    get scrollByThumb(): boolean;
    set scrollByThumb(value: boolean);
    get showScrollbar(): ScrollbarMode;
    set showScrollbar(value: ScrollbarMode);
    get useNative(): boolean | Mode;
    set useNative(value: boolean | Mode);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoCardViewScrollingComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoCardViewScrollingComponent, "dxo-card-view-scrolling", never, { "scrollByContent": { "alias": "scrollByContent"; "required": false; }; "scrollByThumb": { "alias": "scrollByThumb"; "required": false; }; "showScrollbar": { "alias": "showScrollbar"; "required": false; }; "useNative": { "alias": "useNative"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoCardViewScrollingModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoCardViewScrollingModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoCardViewScrollingModule, never, [typeof DxoCardViewScrollingComponent], [typeof DxoCardViewScrollingComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoCardViewScrollingModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoCardViewSearchPanelComponent extends NestedOption implements OnDestroy, OnInit {
    get highlightCaseSensitive(): boolean;
    set highlightCaseSensitive(value: boolean);
    get highlightSearchText(): boolean;
    set highlightSearchText(value: boolean);
    get placeholder(): string;
    set placeholder(value: string);
    get searchVisibleColumnsOnly(): boolean;
    set searchVisibleColumnsOnly(value: boolean);
    get text(): string;
    set text(value: string);
    get visible(): boolean;
    set visible(value: boolean);
    get width(): number | string;
    set width(value: number | string);
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    textChange: EventEmitter<string>;
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoCardViewSearchPanelComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoCardViewSearchPanelComponent, "dxo-card-view-search-panel", never, { "highlightCaseSensitive": { "alias": "highlightCaseSensitive"; "required": false; }; "highlightSearchText": { "alias": "highlightSearchText"; "required": false; }; "placeholder": { "alias": "placeholder"; "required": false; }; "searchVisibleColumnsOnly": { "alias": "searchVisibleColumnsOnly"; "required": false; }; "text": { "alias": "text"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, { "textChange": "textChange"; }, never, never, true, never>;
}
declare class DxoCardViewSearchPanelModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoCardViewSearchPanelModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoCardViewSearchPanelModule, never, [typeof DxoCardViewSearchPanelComponent], [typeof DxoCardViewSearchPanelComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoCardViewSearchPanelModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoCardViewSearchComponent extends NestedOption implements OnDestroy, OnInit {
    get editorOptions(): any;
    set editorOptions(value: any);
    get enabled(): boolean;
    set enabled(value: boolean);
    get timeout(): number;
    set timeout(value: number);
    get mode(): SearchMode;
    set mode(value: SearchMode);
    get searchExpr(): Array<Function | string> | Function | string | undefined;
    set searchExpr(value: Array<Function | string> | Function | string | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoCardViewSearchComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoCardViewSearchComponent, "dxo-card-view-search", never, { "editorOptions": { "alias": "editorOptions"; "required": false; }; "enabled": { "alias": "enabled"; "required": false; }; "timeout": { "alias": "timeout"; "required": false; }; "mode": { "alias": "mode"; "required": false; }; "searchExpr": { "alias": "searchExpr"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoCardViewSearchModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoCardViewSearchModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoCardViewSearchModule, never, [typeof DxoCardViewSearchComponent], [typeof DxoCardViewSearchComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoCardViewSearchModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoCardViewSelectionComponent extends NestedOption implements OnDestroy, OnInit {
    get allowSelectAll(): boolean;
    set allowSelectAll(value: boolean);
    get recursive(): boolean;
    set recursive(value: boolean);
    get selectByClick(): boolean;
    set selectByClick(value: boolean);
    get mode(): SingleMultipleOrNone;
    set mode(value: SingleMultipleOrNone);
    get selectAllMode(): SelectAllMode;
    set selectAllMode(value: SelectAllMode);
    get showCheckBoxesMode(): SelectionColumnDisplayMode;
    set showCheckBoxesMode(value: SelectionColumnDisplayMode);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoCardViewSelectionComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoCardViewSelectionComponent, "dxo-card-view-selection", never, { "allowSelectAll": { "alias": "allowSelectAll"; "required": false; }; "recursive": { "alias": "recursive"; "required": false; }; "selectByClick": { "alias": "selectByClick"; "required": false; }; "mode": { "alias": "mode"; "required": false; }; "selectAllMode": { "alias": "selectAllMode"; "required": false; }; "showCheckBoxesMode": { "alias": "showCheckBoxesMode"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoCardViewSelectionModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoCardViewSelectionModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoCardViewSelectionModule, never, [typeof DxoCardViewSelectionComponent], [typeof DxoCardViewSelectionComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoCardViewSelectionModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoCardViewShowComponent extends NestedOption implements OnDestroy, OnInit {
    get complete(): (($element: any, config: AnimationConfig) => void);
    set complete(value: (($element: any, config: AnimationConfig) => void));
    get delay(): number;
    set delay(value: number);
    get direction(): Direction | undefined;
    set direction(value: Direction | undefined);
    get duration(): number;
    set duration(value: number);
    get easing(): string;
    set easing(value: string);
    get from(): AnimationState;
    set from(value: AnimationState);
    get staggerDelay(): number | undefined;
    set staggerDelay(value: number | undefined);
    get start(): (($element: any, config: AnimationConfig) => void);
    set start(value: (($element: any, config: AnimationConfig) => void));
    get to(): AnimationState;
    set to(value: AnimationState);
    get type(): AnimationType;
    set type(value: AnimationType);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoCardViewShowComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoCardViewShowComponent, "dxo-card-view-show", never, { "complete": { "alias": "complete"; "required": false; }; "delay": { "alias": "delay"; "required": false; }; "direction": { "alias": "direction"; "required": false; }; "duration": { "alias": "duration"; "required": false; }; "easing": { "alias": "easing"; "required": false; }; "from": { "alias": "from"; "required": false; }; "staggerDelay": { "alias": "staggerDelay"; "required": false; }; "start": { "alias": "start"; "required": false; }; "to": { "alias": "to"; "required": false; }; "type": { "alias": "type"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoCardViewShowModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoCardViewShowModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoCardViewShowModule, never, [typeof DxoCardViewShowComponent], [typeof DxoCardViewShowComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoCardViewShowModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxiCardViewSimpleItemComponent extends CollectionNestedOption implements AfterViewInit, IDxTemplateHost {
    private renderer;
    private document;
    private element;
    set _validationRulesContentChildren(value: QueryList<CollectionNestedOption>);
    get aiOptions(): {
        disabled?: boolean;
        instruction?: string | undefined;
    };
    set aiOptions(value: {
        disabled?: boolean;
        instruction?: string | undefined;
    });
    get colSpan(): number | undefined;
    set colSpan(value: number | undefined);
    get cssClass(): string | undefined;
    set cssClass(value: string | undefined);
    get dataField(): string | undefined;
    set dataField(value: string | undefined);
    get editorOptions(): any | undefined;
    set editorOptions(value: any | undefined);
    get editorType(): FormItemComponent;
    set editorType(value: FormItemComponent);
    get helpText(): string | undefined;
    set helpText(value: string | undefined);
    get isRequired(): boolean | undefined;
    set isRequired(value: boolean | undefined);
    get itemType(): FormItemType;
    set itemType(value: FormItemType);
    get label(): {
        alignment?: HorizontalAlignment;
        location?: LabelLocation;
        showColon?: boolean;
        template?: any;
        text?: string | undefined;
        visible?: boolean;
    };
    set label(value: {
        alignment?: HorizontalAlignment;
        location?: LabelLocation;
        showColon?: boolean;
        template?: any;
        text?: string | undefined;
        visible?: boolean;
    });
    get name(): string | undefined;
    set name(value: string | undefined);
    get template(): any;
    set template(value: any);
    get validationRules(): Array<CommonTypes.ValidationRule>;
    set validationRules(value: Array<CommonTypes.ValidationRule>);
    get visible(): boolean;
    set visible(value: boolean);
    get visibleIndex(): number | undefined;
    set visibleIndex(value: number | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost, renderer: Renderer2, document: any, templateHost: DxTemplateHost, element: ElementRef);
    setTemplate(template: DxTemplateDirective): void;
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiCardViewSimpleItemComponent, [{ host: true; skipSelf: true; }, { host: true; }, null, null, { host: true; }, null]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiCardViewSimpleItemComponent, "dxi-card-view-simple-item", never, { "aiOptions": { "alias": "aiOptions"; "required": false; }; "colSpan": { "alias": "colSpan"; "required": false; }; "cssClass": { "alias": "cssClass"; "required": false; }; "dataField": { "alias": "dataField"; "required": false; }; "editorOptions": { "alias": "editorOptions"; "required": false; }; "editorType": { "alias": "editorType"; "required": false; }; "helpText": { "alias": "helpText"; "required": false; }; "isRequired": { "alias": "isRequired"; "required": false; }; "itemType": { "alias": "itemType"; "required": false; }; "label": { "alias": "label"; "required": false; }; "name": { "alias": "name"; "required": false; }; "template": { "alias": "template"; "required": false; }; "validationRules": { "alias": "validationRules"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "visibleIndex": { "alias": "visibleIndex"; "required": false; }; }, {}, ["_validationRulesContentChildren"], ["*"], true, never>;
}
declare class DxiCardViewSimpleItemModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiCardViewSimpleItemModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiCardViewSimpleItemModule, never, [typeof DxiCardViewSimpleItemComponent], [typeof DxiCardViewSimpleItemComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiCardViewSimpleItemModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoCardViewSortingComponent extends NestedOption implements OnDestroy, OnInit {
    get ascendingText(): string;
    set ascendingText(value: string);
    get clearText(): string;
    set clearText(value: string);
    get descendingText(): string;
    set descendingText(value: string);
    get mode(): SingleMultipleOrNone;
    set mode(value: SingleMultipleOrNone);
    get showSortIndexes(): boolean;
    set showSortIndexes(value: boolean);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoCardViewSortingComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoCardViewSortingComponent, "dxo-card-view-sorting", never, { "ascendingText": { "alias": "ascendingText"; "required": false; }; "clearText": { "alias": "clearText"; "required": false; }; "descendingText": { "alias": "descendingText"; "required": false; }; "mode": { "alias": "mode"; "required": false; }; "showSortIndexes": { "alias": "showSortIndexes"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoCardViewSortingModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoCardViewSortingModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoCardViewSortingModule, never, [typeof DxoCardViewSortingComponent], [typeof DxoCardViewSortingComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoCardViewSortingModule>;
}

declare class DxiCardViewStringLengthRuleComponent extends CollectionNestedOption {
    get ignoreEmptyValue(): boolean;
    set ignoreEmptyValue(value: boolean);
    get max(): number;
    set max(value: number);
    get message(): string;
    set message(value: string);
    get min(): number;
    set min(value: number);
    get trim(): boolean;
    set trim(value: boolean);
    get type(): ValidationRuleType;
    set type(value: ValidationRuleType);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiCardViewStringLengthRuleComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiCardViewStringLengthRuleComponent, "dxi-card-view-string-length-rule", never, { "ignoreEmptyValue": { "alias": "ignoreEmptyValue"; "required": false; }; "max": { "alias": "max"; "required": false; }; "message": { "alias": "message"; "required": false; }; "min": { "alias": "min"; "required": false; }; "trim": { "alias": "trim"; "required": false; }; "type": { "alias": "type"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxiCardViewStringLengthRuleModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiCardViewStringLengthRuleModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiCardViewStringLengthRuleModule, never, [typeof DxiCardViewStringLengthRuleComponent], [typeof DxiCardViewStringLengthRuleComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiCardViewStringLengthRuleModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxiCardViewTabComponent extends CollectionNestedOption implements AfterViewInit, IDxTemplateHost {
    private renderer;
    private document;
    private element;
    set _itemsContentChildren(value: QueryList<CollectionNestedOption>);
    get alignItemLabels(): boolean;
    set alignItemLabels(value: boolean);
    get badge(): string | undefined;
    set badge(value: string | undefined);
    get colCount(): number;
    set colCount(value: number);
    get colCountByScreen(): {
        lg?: number | undefined;
        md?: number | undefined;
        sm?: number | undefined;
        xs?: number | undefined;
    };
    set colCountByScreen(value: {
        lg?: number | undefined;
        md?: number | undefined;
        sm?: number | undefined;
        xs?: number | undefined;
    });
    get disabled(): boolean;
    set disabled(value: boolean);
    get icon(): string | undefined;
    set icon(value: string | undefined);
    get items(): Array<dxFormButtonItem | dxFormEmptyItem | dxFormGroupItem | dxFormSimpleItem | dxFormTabbedItem>;
    set items(value: Array<dxFormButtonItem | dxFormEmptyItem | dxFormGroupItem | dxFormSimpleItem | dxFormTabbedItem>);
    get tabTemplate(): any;
    set tabTemplate(value: any);
    get template(): any;
    set template(value: any);
    get title(): string | undefined;
    set title(value: string | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost, renderer: Renderer2, document: any, templateHost: DxTemplateHost, element: ElementRef);
    setTemplate(template: DxTemplateDirective): void;
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiCardViewTabComponent, [{ host: true; skipSelf: true; }, { host: true; }, null, null, { host: true; }, null]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiCardViewTabComponent, "dxi-card-view-tab", never, { "alignItemLabels": { "alias": "alignItemLabels"; "required": false; }; "badge": { "alias": "badge"; "required": false; }; "colCount": { "alias": "colCount"; "required": false; }; "colCountByScreen": { "alias": "colCountByScreen"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "icon": { "alias": "icon"; "required": false; }; "items": { "alias": "items"; "required": false; }; "tabTemplate": { "alias": "tabTemplate"; "required": false; }; "template": { "alias": "template"; "required": false; }; "title": { "alias": "title"; "required": false; }; }, {}, ["_itemsContentChildren"], ["*"], true, never>;
}
declare class DxiCardViewTabModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiCardViewTabModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiCardViewTabModule, never, [typeof DxiCardViewTabComponent], [typeof DxiCardViewTabComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiCardViewTabModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxiCardViewTabPanelOptionsItemComponent extends CollectionNestedOption implements AfterViewInit, IDxTemplateHost {
    private renderer;
    private document;
    private element;
    get badge(): string;
    set badge(value: string);
    get disabled(): boolean;
    set disabled(value: boolean);
    get html(): string;
    set html(value: string);
    get icon(): string;
    set icon(value: string);
    get tabTemplate(): any;
    set tabTemplate(value: any);
    get template(): any;
    set template(value: any);
    get text(): string;
    set text(value: string);
    get title(): string;
    set title(value: string);
    get visible(): boolean;
    set visible(value: boolean);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost, renderer: Renderer2, document: any, templateHost: DxTemplateHost, element: ElementRef);
    setTemplate(template: DxTemplateDirective): void;
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiCardViewTabPanelOptionsItemComponent, [{ host: true; skipSelf: true; }, { host: true; }, null, null, { host: true; }, null]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiCardViewTabPanelOptionsItemComponent, "dxi-card-view-tab-panel-options-item", never, { "badge": { "alias": "badge"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "html": { "alias": "html"; "required": false; }; "icon": { "alias": "icon"; "required": false; }; "tabTemplate": { "alias": "tabTemplate"; "required": false; }; "template": { "alias": "template"; "required": false; }; "text": { "alias": "text"; "required": false; }; "title": { "alias": "title"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; }, {}, never, ["*"], true, never>;
}
declare class DxiCardViewTabPanelOptionsItemModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiCardViewTabPanelOptionsItemModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiCardViewTabPanelOptionsItemModule, never, [typeof DxiCardViewTabPanelOptionsItemComponent], [typeof DxiCardViewTabPanelOptionsItemComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiCardViewTabPanelOptionsItemModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoCardViewTabPanelOptionsComponent extends NestedOption implements OnDestroy, OnInit {
    set _itemsContentChildren(value: QueryList<CollectionNestedOption>);
    get accessKey(): string | undefined;
    set accessKey(value: string | undefined);
    get activeStateEnabled(): boolean;
    set activeStateEnabled(value: boolean);
    get animationEnabled(): boolean;
    set animationEnabled(value: boolean);
    get dataSource(): Array<any | dxTabPanelItem | string> | DataSource | DataSourceOptions | null | Store | string;
    set dataSource(value: Array<any | dxTabPanelItem | string> | DataSource | DataSourceOptions | null | Store | string);
    get deferRendering(): boolean;
    set deferRendering(value: boolean);
    get disabled(): boolean;
    set disabled(value: boolean);
    get elementAttr(): Record<string, any>;
    set elementAttr(value: Record<string, any>);
    get focusStateEnabled(): boolean;
    set focusStateEnabled(value: boolean);
    get height(): number | string | undefined;
    set height(value: number | string | undefined);
    get hint(): string | undefined;
    set hint(value: string | undefined);
    get hoverStateEnabled(): boolean;
    set hoverStateEnabled(value: boolean);
    get iconPosition(): TabsIconPosition;
    set iconPosition(value: TabsIconPosition);
    get itemHoldTimeout(): number;
    set itemHoldTimeout(value: number);
    get items(): Array<any | dxTabPanelItem | string>;
    set items(value: Array<any | dxTabPanelItem | string>);
    get itemTemplate(): any;
    set itemTemplate(value: any);
    get itemTitleTemplate(): any;
    set itemTitleTemplate(value: any);
    get keyExpr(): ((item: any) => any) | string;
    set keyExpr(value: ((item: any) => any) | string);
    get loop(): boolean;
    set loop(value: boolean);
    get noDataText(): string;
    set noDataText(value: string);
    get onContentReady(): ((e: ContentReadyEvent$4) => void);
    set onContentReady(value: ((e: ContentReadyEvent$4) => void));
    get onDisposing(): ((e: DisposingEvent$4) => void);
    set onDisposing(value: ((e: DisposingEvent$4) => void));
    get onInitialized(): ((e: InitializedEvent$4) => void);
    set onInitialized(value: ((e: InitializedEvent$4) => void));
    get onItemClick(): ((e: ItemClickEvent) => void);
    set onItemClick(value: ((e: ItemClickEvent) => void));
    get onItemContextMenu(): ((e: ItemContextMenuEvent) => void);
    set onItemContextMenu(value: ((e: ItemContextMenuEvent) => void));
    get onItemHold(): ((e: ItemHoldEvent) => void);
    set onItemHold(value: ((e: ItemHoldEvent) => void));
    get onItemRendered(): ((e: ItemRenderedEvent) => void);
    set onItemRendered(value: ((e: ItemRenderedEvent) => void));
    get onOptionChanged(): ((e: OptionChangedEvent$4) => void);
    set onOptionChanged(value: ((e: OptionChangedEvent$4) => void));
    get onSelectionChanged(): ((e: SelectionChangedEvent) => void);
    set onSelectionChanged(value: ((e: SelectionChangedEvent) => void));
    get onSelectionChanging(): ((e: SelectionChangingEvent) => void);
    set onSelectionChanging(value: ((e: SelectionChangingEvent) => void));
    get onTitleClick(): ((e: TitleClickEvent) => void);
    set onTitleClick(value: ((e: TitleClickEvent) => void));
    get onTitleHold(): ((e: TitleHoldEvent) => void) | undefined;
    set onTitleHold(value: ((e: TitleHoldEvent) => void) | undefined);
    get onTitleRendered(): ((e: TitleRenderedEvent) => void) | undefined;
    set onTitleRendered(value: ((e: TitleRenderedEvent) => void) | undefined);
    get repaintChangesOnly(): boolean;
    set repaintChangesOnly(value: boolean);
    get rtlEnabled(): boolean;
    set rtlEnabled(value: boolean);
    get scrollByContent(): boolean;
    set scrollByContent(value: boolean);
    get scrollingEnabled(): boolean;
    set scrollingEnabled(value: boolean);
    get selectedIndex(): number;
    set selectedIndex(value: number);
    get selectedItem(): any | null;
    set selectedItem(value: any | null);
    get showNavButtons(): boolean;
    set showNavButtons(value: boolean);
    get stylingMode(): TabsStyle;
    set stylingMode(value: TabsStyle);
    get swipeEnabled(): boolean;
    set swipeEnabled(value: boolean);
    get tabIndex(): number;
    set tabIndex(value: number);
    get tabsPosition(): Position;
    set tabsPosition(value: Position);
    get visible(): boolean;
    set visible(value: boolean);
    get width(): number | string | undefined;
    set width(value: number | string | undefined);
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    itemsChange: EventEmitter<Array<any | dxTabPanelItem | string>>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    selectedIndexChange: EventEmitter<number>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    selectedItemChange: EventEmitter<any | null>;
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoCardViewTabPanelOptionsComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoCardViewTabPanelOptionsComponent, "dxo-card-view-tab-panel-options", never, { "accessKey": { "alias": "accessKey"; "required": false; }; "activeStateEnabled": { "alias": "activeStateEnabled"; "required": false; }; "animationEnabled": { "alias": "animationEnabled"; "required": false; }; "dataSource": { "alias": "dataSource"; "required": false; }; "deferRendering": { "alias": "deferRendering"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "elementAttr": { "alias": "elementAttr"; "required": false; }; "focusStateEnabled": { "alias": "focusStateEnabled"; "required": false; }; "height": { "alias": "height"; "required": false; }; "hint": { "alias": "hint"; "required": false; }; "hoverStateEnabled": { "alias": "hoverStateEnabled"; "required": false; }; "iconPosition": { "alias": "iconPosition"; "required": false; }; "itemHoldTimeout": { "alias": "itemHoldTimeout"; "required": false; }; "items": { "alias": "items"; "required": false; }; "itemTemplate": { "alias": "itemTemplate"; "required": false; }; "itemTitleTemplate": { "alias": "itemTitleTemplate"; "required": false; }; "keyExpr": { "alias": "keyExpr"; "required": false; }; "loop": { "alias": "loop"; "required": false; }; "noDataText": { "alias": "noDataText"; "required": false; }; "onContentReady": { "alias": "onContentReady"; "required": false; }; "onDisposing": { "alias": "onDisposing"; "required": false; }; "onInitialized": { "alias": "onInitialized"; "required": false; }; "onItemClick": { "alias": "onItemClick"; "required": false; }; "onItemContextMenu": { "alias": "onItemContextMenu"; "required": false; }; "onItemHold": { "alias": "onItemHold"; "required": false; }; "onItemRendered": { "alias": "onItemRendered"; "required": false; }; "onOptionChanged": { "alias": "onOptionChanged"; "required": false; }; "onSelectionChanged": { "alias": "onSelectionChanged"; "required": false; }; "onSelectionChanging": { "alias": "onSelectionChanging"; "required": false; }; "onTitleClick": { "alias": "onTitleClick"; "required": false; }; "onTitleHold": { "alias": "onTitleHold"; "required": false; }; "onTitleRendered": { "alias": "onTitleRendered"; "required": false; }; "repaintChangesOnly": { "alias": "repaintChangesOnly"; "required": false; }; "rtlEnabled": { "alias": "rtlEnabled"; "required": false; }; "scrollByContent": { "alias": "scrollByContent"; "required": false; }; "scrollingEnabled": { "alias": "scrollingEnabled"; "required": false; }; "selectedIndex": { "alias": "selectedIndex"; "required": false; }; "selectedItem": { "alias": "selectedItem"; "required": false; }; "showNavButtons": { "alias": "showNavButtons"; "required": false; }; "stylingMode": { "alias": "stylingMode"; "required": false; }; "swipeEnabled": { "alias": "swipeEnabled"; "required": false; }; "tabIndex": { "alias": "tabIndex"; "required": false; }; "tabsPosition": { "alias": "tabsPosition"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, { "itemsChange": "itemsChange"; "selectedIndexChange": "selectedIndexChange"; "selectedItemChange": "selectedItemChange"; }, ["_itemsContentChildren"], never, true, never>;
}
declare class DxoCardViewTabPanelOptionsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoCardViewTabPanelOptionsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoCardViewTabPanelOptionsModule, never, [typeof DxoCardViewTabPanelOptionsComponent], [typeof DxoCardViewTabPanelOptionsComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoCardViewTabPanelOptionsModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxiCardViewTabbedItemComponent extends CollectionNestedOption {
    set _tabsContentChildren(value: QueryList<CollectionNestedOption>);
    get colSpan(): number | undefined;
    set colSpan(value: number | undefined);
    get cssClass(): string | undefined;
    set cssClass(value: string | undefined);
    get itemType(): FormItemType;
    set itemType(value: FormItemType);
    get name(): string | undefined;
    set name(value: string | undefined);
    get tabPanelOptions(): dxTabPanelOptions | undefined;
    set tabPanelOptions(value: dxTabPanelOptions | undefined);
    get tabs(): {
        alignItemLabels?: boolean;
        badge?: string | undefined;
        colCount?: number;
        colCountByScreen?: {
            lg?: number | undefined;
            md?: number | undefined;
            sm?: number | undefined;
            xs?: number | undefined;
        };
        disabled?: boolean;
        icon?: string | undefined;
        items?: Array<dxFormButtonItem | dxFormEmptyItem | dxFormGroupItem | dxFormSimpleItem | dxFormTabbedItem>;
        tabTemplate?: any;
        template?: any;
        title?: string | undefined;
    }[];
    set tabs(value: {
        alignItemLabels?: boolean;
        badge?: string | undefined;
        colCount?: number;
        colCountByScreen?: {
            lg?: number | undefined;
            md?: number | undefined;
            sm?: number | undefined;
            xs?: number | undefined;
        };
        disabled?: boolean;
        icon?: string | undefined;
        items?: Array<dxFormButtonItem | dxFormEmptyItem | dxFormGroupItem | dxFormSimpleItem | dxFormTabbedItem>;
        tabTemplate?: any;
        template?: any;
        title?: string | undefined;
    }[]);
    get visible(): boolean;
    set visible(value: boolean);
    get visibleIndex(): number | undefined;
    set visibleIndex(value: number | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiCardViewTabbedItemComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiCardViewTabbedItemComponent, "dxi-card-view-tabbed-item", never, { "colSpan": { "alias": "colSpan"; "required": false; }; "cssClass": { "alias": "cssClass"; "required": false; }; "itemType": { "alias": "itemType"; "required": false; }; "name": { "alias": "name"; "required": false; }; "tabPanelOptions": { "alias": "tabPanelOptions"; "required": false; }; "tabs": { "alias": "tabs"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "visibleIndex": { "alias": "visibleIndex"; "required": false; }; }, {}, ["_tabsContentChildren"], never, true, never>;
}
declare class DxiCardViewTabbedItemModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiCardViewTabbedItemModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiCardViewTabbedItemModule, never, [typeof DxiCardViewTabbedItemComponent], [typeof DxiCardViewTabbedItemComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiCardViewTabbedItemModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoCardViewTextsComponent extends NestedOption implements OnDestroy, OnInit {
    get addCard(): string;
    set addCard(value: string);
    get confirmDeleteMessage(): string;
    set confirmDeleteMessage(value: string);
    get confirmDeleteTitle(): string;
    set confirmDeleteTitle(value: string);
    get deleteCard(): string;
    set deleteCard(value: string);
    get editCard(): string;
    set editCard(value: string);
    get saveCard(): string;
    set saveCard(value: string);
    get clearFilter(): string;
    set clearFilter(value: string);
    get createFilter(): string;
    set createFilter(value: string);
    get filterEnabledHint(): string;
    set filterEnabledHint(value: string);
    get cancel(): string;
    set cancel(value: string);
    get emptyValue(): string;
    set emptyValue(value: string);
    get ok(): string;
    set ok(value: string);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoCardViewTextsComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoCardViewTextsComponent, "dxo-card-view-texts", never, { "addCard": { "alias": "addCard"; "required": false; }; "confirmDeleteMessage": { "alias": "confirmDeleteMessage"; "required": false; }; "confirmDeleteTitle": { "alias": "confirmDeleteTitle"; "required": false; }; "deleteCard": { "alias": "deleteCard"; "required": false; }; "editCard": { "alias": "editCard"; "required": false; }; "saveCard": { "alias": "saveCard"; "required": false; }; "clearFilter": { "alias": "clearFilter"; "required": false; }; "createFilter": { "alias": "createFilter"; "required": false; }; "filterEnabledHint": { "alias": "filterEnabledHint"; "required": false; }; "cancel": { "alias": "cancel"; "required": false; }; "emptyValue": { "alias": "emptyValue"; "required": false; }; "ok": { "alias": "ok"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoCardViewTextsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoCardViewTextsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoCardViewTextsModule, never, [typeof DxoCardViewTextsComponent], [typeof DxoCardViewTextsComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoCardViewTextsModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoCardViewToComponent extends NestedOption implements OnDestroy, OnInit {
    get left(): number;
    set left(value: number);
    get opacity(): number;
    set opacity(value: number);
    get position(): PositionConfig;
    set position(value: PositionConfig);
    get scale(): number;
    set scale(value: number);
    get top(): number;
    set top(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoCardViewToComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoCardViewToComponent, "dxo-card-view-to", never, { "left": { "alias": "left"; "required": false; }; "opacity": { "alias": "opacity"; "required": false; }; "position": { "alias": "position"; "required": false; }; "scale": { "alias": "scale"; "required": false; }; "top": { "alias": "top"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoCardViewToModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoCardViewToModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoCardViewToModule, never, [typeof DxoCardViewToComponent], [typeof DxoCardViewToComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoCardViewToModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxiCardViewToolbarItemComponent extends CollectionNestedOption implements AfterViewInit, IDxTemplateHost {
    private renderer;
    private document;
    private element;
    get cssClass(): string | undefined;
    set cssClass(value: string | undefined);
    get disabled(): boolean;
    set disabled(value: boolean);
    get html(): string;
    set html(value: string);
    get locateInMenu(): LocateInMenuMode;
    set locateInMenu(value: LocateInMenuMode);
    get location(): ToolbarItemLocation;
    set location(value: ToolbarItemLocation);
    get menuItemTemplate(): any;
    set menuItemTemplate(value: any);
    get name(): PredefinedToolbarItem | string;
    set name(value: PredefinedToolbarItem | string);
    get options(): any;
    set options(value: any);
    get showText(): ShowTextMode;
    set showText(value: ShowTextMode);
    get template(): any;
    set template(value: any);
    get text(): string;
    set text(value: string);
    get visible(): boolean;
    set visible(value: boolean);
    get widget(): ToolbarItemComponent;
    set widget(value: ToolbarItemComponent);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost, renderer: Renderer2, document: any, templateHost: DxTemplateHost, element: ElementRef);
    setTemplate(template: DxTemplateDirective): void;
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiCardViewToolbarItemComponent, [{ host: true; skipSelf: true; }, { host: true; }, null, null, { host: true; }, null]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiCardViewToolbarItemComponent, "dxi-card-view-toolbar-item", never, { "cssClass": { "alias": "cssClass"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "html": { "alias": "html"; "required": false; }; "locateInMenu": { "alias": "locateInMenu"; "required": false; }; "location": { "alias": "location"; "required": false; }; "menuItemTemplate": { "alias": "menuItemTemplate"; "required": false; }; "name": { "alias": "name"; "required": false; }; "options": { "alias": "options"; "required": false; }; "showText": { "alias": "showText"; "required": false; }; "template": { "alias": "template"; "required": false; }; "text": { "alias": "text"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "widget": { "alias": "widget"; "required": false; }; }, {}, never, ["*"], true, never>;
}
declare class DxiCardViewToolbarItemModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiCardViewToolbarItemModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiCardViewToolbarItemModule, never, [typeof DxiCardViewToolbarItemComponent], [typeof DxiCardViewToolbarItemComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiCardViewToolbarItemModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoCardViewToolbarComponent extends NestedOption implements OnDestroy, OnInit {
    set _itemsContentChildren(value: QueryList<CollectionNestedOption>);
    get disabled(): boolean;
    set disabled(value: boolean);
    get items(): Array<dxCardViewToolbarItem | PredefinedToolbarItem>;
    set items(value: Array<dxCardViewToolbarItem | PredefinedToolbarItem>);
    get multiline(): boolean;
    set multiline(value: boolean);
    get visible(): boolean | undefined;
    set visible(value: boolean | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoCardViewToolbarComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoCardViewToolbarComponent, "dxo-card-view-toolbar", never, { "disabled": { "alias": "disabled"; "required": false; }; "items": { "alias": "items"; "required": false; }; "multiline": { "alias": "multiline"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; }, {}, ["_itemsContentChildren"], never, true, never>;
}
declare class DxoCardViewToolbarModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoCardViewToolbarModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoCardViewToolbarModule, never, [typeof DxoCardViewToolbarComponent], [typeof DxoCardViewToolbarComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoCardViewToolbarModule>;
}

declare class DxiCardViewValidationRuleComponent extends CollectionNestedOption {
    get message(): string;
    set message(value: string);
    get trim(): boolean;
    set trim(value: boolean);
    get type(): ValidationRuleType;
    set type(value: ValidationRuleType);
    get ignoreEmptyValue(): boolean;
    set ignoreEmptyValue(value: boolean);
    get max(): Date | number | string;
    set max(value: Date | number | string);
    get min(): Date | number | string;
    set min(value: Date | number | string);
    get reevaluate(): boolean;
    set reevaluate(value: boolean);
    get validationCallback(): ((options: {
        column: Record<string, any>;
        data: Record<string, any>;
        formItem: Record<string, any>;
        rule: Record<string, any>;
        validator: Record<string, any>;
        value: any;
    }) => boolean);
    set validationCallback(value: ((options: {
        column: Record<string, any>;
        data: Record<string, any>;
        formItem: Record<string, any>;
        rule: Record<string, any>;
        validator: Record<string, any>;
        value: any;
    }) => boolean));
    get comparisonTarget(): Function;
    set comparisonTarget(value: Function);
    get comparisonType(): ComparisonOperator;
    set comparisonType(value: ComparisonOperator);
    get pattern(): RegExp | string;
    set pattern(value: RegExp | string);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiCardViewValidationRuleComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiCardViewValidationRuleComponent, "dxi-card-view-validation-rule", never, { "message": { "alias": "message"; "required": false; }; "trim": { "alias": "trim"; "required": false; }; "type": { "alias": "type"; "required": false; }; "ignoreEmptyValue": { "alias": "ignoreEmptyValue"; "required": false; }; "max": { "alias": "max"; "required": false; }; "min": { "alias": "min"; "required": false; }; "reevaluate": { "alias": "reevaluate"; "required": false; }; "validationCallback": { "alias": "validationCallback"; "required": false; }; "comparisonTarget": { "alias": "comparisonTarget"; "required": false; }; "comparisonType": { "alias": "comparisonType"; "required": false; }; "pattern": { "alias": "pattern"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxiCardViewValidationRuleModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiCardViewValidationRuleModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiCardViewValidationRuleModule, never, [typeof DxiCardViewValidationRuleComponent], [typeof DxiCardViewValidationRuleComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiCardViewValidationRuleModule>;
}

export { DxiCardViewAsyncRuleComponent, DxiCardViewAsyncRuleModule, DxiCardViewButtonItemComponent, DxiCardViewButtonItemModule, DxiCardViewCardHeaderItemComponent, DxiCardViewCardHeaderItemModule, DxiCardViewChangeComponent, DxiCardViewChangeModule, DxiCardViewColumnComponent, DxiCardViewColumnModule, DxiCardViewCompareRuleComponent, DxiCardViewCompareRuleModule, DxiCardViewCustomOperationComponent, DxiCardViewCustomOperationModule, DxiCardViewCustomRuleComponent, DxiCardViewCustomRuleModule, DxiCardViewEmailRuleComponent, DxiCardViewEmailRuleModule, DxiCardViewEmptyItemComponent, DxiCardViewEmptyItemModule, DxiCardViewFieldComponent, DxiCardViewFieldModule, DxiCardViewGroupItemComponent, DxiCardViewGroupItemModule, DxiCardViewItemComponent, DxiCardViewItemModule, DxiCardViewNumericRuleComponent, DxiCardViewNumericRuleModule, DxiCardViewPatternRuleComponent, DxiCardViewPatternRuleModule, DxiCardViewRangeRuleComponent, DxiCardViewRangeRuleModule, DxiCardViewRequiredRuleComponent, DxiCardViewRequiredRuleModule, DxiCardViewSimpleItemComponent, DxiCardViewSimpleItemModule, DxiCardViewStringLengthRuleComponent, DxiCardViewStringLengthRuleModule, DxiCardViewTabComponent, DxiCardViewTabModule, DxiCardViewTabPanelOptionsItemComponent, DxiCardViewTabPanelOptionsItemModule, DxiCardViewTabbedItemComponent, DxiCardViewTabbedItemModule, DxiCardViewToolbarItemComponent, DxiCardViewToolbarItemModule, DxiCardViewValidationRuleComponent, DxiCardViewValidationRuleModule, DxoCardViewAIOptionsComponent, DxoCardViewAIOptionsModule, DxoCardViewAnimationComponent, DxoCardViewAnimationModule, DxoCardViewAtComponent, DxoCardViewAtModule, DxoCardViewBoundaryOffsetComponent, DxoCardViewBoundaryOffsetModule, DxoCardViewButtonOptionsComponent, DxoCardViewButtonOptionsModule, DxoCardViewCardCoverComponent, DxoCardViewCardCoverModule, DxoCardViewCardHeaderComponent, DxoCardViewCardHeaderModule, DxoCardViewCardViewHeaderFilterComponent, DxoCardViewCardViewHeaderFilterModule, DxoCardViewCardViewHeaderFilterSearchComponent, DxoCardViewCardViewHeaderFilterSearchModule, DxoCardViewCardViewHeaderFilterTextsComponent, DxoCardViewCardViewHeaderFilterTextsModule, DxoCardViewCardViewSelectionComponent, DxoCardViewCardViewSelectionModule, DxoCardViewColCountByScreenComponent, DxoCardViewColCountByScreenModule, DxoCardViewCollisionComponent, DxoCardViewCollisionModule, DxoCardViewColumnChooserComponent, DxoCardViewColumnChooserModule, DxoCardViewColumnChooserSearchComponent, DxoCardViewColumnChooserSearchModule, DxoCardViewColumnChooserSelectionComponent, DxoCardViewColumnChooserSelectionModule, DxoCardViewColumnHeaderFilterComponent, DxoCardViewColumnHeaderFilterModule, DxoCardViewColumnHeaderFilterSearchComponent, DxoCardViewColumnHeaderFilterSearchModule, DxoCardViewDraggingComponent, DxoCardViewDraggingModule, DxoCardViewEditingComponent, DxoCardViewEditingModule, DxoCardViewEditingTextsComponent, DxoCardViewEditingTextsModule, DxoCardViewFilterBuilderComponent, DxoCardViewFilterBuilderModule, DxoCardViewFilterOperationDescriptionsComponent, DxoCardViewFilterOperationDescriptionsModule, DxoCardViewFilterPanelComponent, DxoCardViewFilterPanelModule, DxoCardViewFilterPanelTextsComponent, DxoCardViewFilterPanelTextsModule, DxoCardViewFormComponent, DxoCardViewFormItemComponent, DxoCardViewFormItemModule, DxoCardViewFormModule, DxoCardViewFormatComponent, DxoCardViewFormatModule, DxoCardViewFromComponent, DxoCardViewFromModule, DxoCardViewGroupOperationDescriptionsComponent, DxoCardViewGroupOperationDescriptionsModule, DxoCardViewHeaderFilterComponent, DxoCardViewHeaderFilterModule, DxoCardViewHeaderPanelComponent, DxoCardViewHeaderPanelModule, DxoCardViewHideComponent, DxoCardViewHideModule, DxoCardViewIndicatorOptionsComponent, DxoCardViewIndicatorOptionsModule, DxoCardViewLabelComponent, DxoCardViewLabelModule, DxoCardViewLoadPanelComponent, DxoCardViewLoadPanelModule, DxoCardViewLookupComponent, DxoCardViewLookupModule, DxoCardViewMyComponent, DxoCardViewMyModule, DxoCardViewOffsetComponent, DxoCardViewOffsetModule, DxoCardViewPagerComponent, DxoCardViewPagerModule, DxoCardViewPagingComponent, DxoCardViewPagingModule, DxoCardViewPositionComponent, DxoCardViewPositionModule, DxoCardViewRemoteOperationsComponent, DxoCardViewRemoteOperationsModule, DxoCardViewScrollingComponent, DxoCardViewScrollingModule, DxoCardViewSearchComponent, DxoCardViewSearchModule, DxoCardViewSearchPanelComponent, DxoCardViewSearchPanelModule, DxoCardViewSelectionComponent, DxoCardViewSelectionModule, DxoCardViewShowComponent, DxoCardViewShowModule, DxoCardViewSortingComponent, DxoCardViewSortingModule, DxoCardViewTabPanelOptionsComponent, DxoCardViewTabPanelOptionsModule, DxoCardViewTextsComponent, DxoCardViewTextsModule, DxoCardViewToComponent, DxoCardViewToModule, DxoCardViewToolbarComponent, DxoCardViewToolbarModule };
//# sourceMappingURL=index.d.ts.map
