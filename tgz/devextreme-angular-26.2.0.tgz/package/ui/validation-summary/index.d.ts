import * as i0 from '@angular/core';
import { OnDestroy, OnChanges, DoCheck, QueryList, EventEmitter, ElementRef, NgZone, TransferState, SimpleChanges } from '@angular/core';
import { CollectionWidgetItem } from 'devextreme/ui/collection/ui.collection_widget.base';
import DxValidationSummary, { ContentReadyEvent, DisposingEvent, InitializedEvent, ItemClickEvent, OptionChangedEvent } from 'devextreme/ui/validation_summary';
export { ExplicitTypes } from 'devextreme/ui/validation_summary';
import * as i3 from 'devextreme-angular/core';
import { DxComponent, CollectionNestedOption, DxTemplateHost, WatcherHelper, IterableDifferHelper, NestedOptionHost } from 'devextreme-angular/core';
import * as i1 from 'devextreme-angular/ui/nested';
import * as i2 from 'devextreme-angular/ui/validation-summary/nested';
export * from 'devextreme-angular/ui/validation-summary/nested';
import * as validation_summary_types from 'devextreme/ui/validation_summary_types';
export { validation_summary_types as DxValidationSummaryTypes };

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

/**
 * [descr:dxValidationSummary]

 */
declare class DxValidationSummaryComponent<TItem = any, TKey = any> extends DxComponent implements OnDestroy, OnChanges, DoCheck {
    private _watcherHelper;
    private _idh;
    set _itemsContentChildren(value: QueryList<CollectionNestedOption>);
    instance: DxValidationSummary<TItem, TKey>;
    /**
     * [descr:DOMComponentOptions.elementAttr]
    
     */
    get elementAttr(): Record<string, any>;
    set elementAttr(value: Record<string, any>);
    /**
     * [descr:WidgetOptions.hoverStateEnabled]
    
     */
    get hoverStateEnabled(): boolean;
    set hoverStateEnabled(value: boolean);
    /**
     * [descr:CollectionWidgetOptions.items]
    
     */
    get items(): Array<any | CollectionWidgetItem | string>;
    set items(value: Array<any | CollectionWidgetItem | string>);
    /**
     * [descr:CollectionWidgetOptions.itemTemplate]
    
     */
    get itemTemplate(): any;
    set itemTemplate(value: any);
    /**
     * [descr:dxValidationSummaryOptions.validationGroup]
    
     */
    get validationGroup(): string;
    set validationGroup(value: string);
    /**
    
     * [descr:dxValidationSummaryOptions.onContentReady]
    
    
     */
    onContentReady: EventEmitter<ContentReadyEvent>;
    /**
    
     * [descr:dxValidationSummaryOptions.onDisposing]
    
    
     */
    onDisposing: EventEmitter<DisposingEvent>;
    /**
    
     * [descr:dxValidationSummaryOptions.onInitialized]
    
    
     */
    onInitialized: EventEmitter<InitializedEvent>;
    /**
    
     * [descr:dxValidationSummaryOptions.onItemClick]
    
    
     */
    onItemClick: EventEmitter<ItemClickEvent>;
    /**
    
     * [descr:dxValidationSummaryOptions.onOptionChanged]
    
    
     */
    onOptionChanged: EventEmitter<OptionChangedEvent>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    elementAttrChange: EventEmitter<Record<string, any>>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    hoverStateEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    itemsChange: EventEmitter<Array<any | CollectionWidgetItem | string>>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    itemTemplateChange: EventEmitter<any>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    validationGroupChange: EventEmitter<string>;
    constructor(elementRef: ElementRef, ngZone: NgZone, templateHost: DxTemplateHost, _watcherHelper: WatcherHelper, _idh: IterableDifferHelper, optionHost: NestedOptionHost, transferState: TransferState, platformId: any);
    protected _createInstance(element: any, options: any): DxValidationSummary<any, any>;
    ngOnDestroy(): void;
    ngOnChanges(changes: SimpleChanges): void;
    setupChanges(prop: string, changes: SimpleChanges): void;
    ngDoCheck(): void;
    _setOption(name: string, value: any): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxValidationSummaryComponent<any, any>, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxValidationSummaryComponent<any, any>, "dx-validation-summary", never, { "elementAttr": { "alias": "elementAttr"; "required": false; }; "hoverStateEnabled": { "alias": "hoverStateEnabled"; "required": false; }; "items": { "alias": "items"; "required": false; }; "itemTemplate": { "alias": "itemTemplate"; "required": false; }; "validationGroup": { "alias": "validationGroup"; "required": false; }; }, { "onContentReady": "onContentReady"; "onDisposing": "onDisposing"; "onInitialized": "onInitialized"; "onItemClick": "onItemClick"; "onOptionChanged": "onOptionChanged"; "elementAttrChange": "elementAttrChange"; "hoverStateEnabledChange": "hoverStateEnabledChange"; "itemsChange": "itemsChange"; "itemTemplateChange": "itemTemplateChange"; "validationGroupChange": "validationGroupChange"; }, ["_itemsContentChildren"], never, true, never>;
}
declare class DxValidationSummaryModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxValidationSummaryModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxValidationSummaryModule, never, [typeof DxValidationSummaryComponent, typeof i1.DxiItemModule, typeof i2.DxiValidationSummaryItemModule, typeof i3.DxIntegrationModule, typeof i3.DxTemplateModule], [typeof DxValidationSummaryComponent, typeof i1.DxiItemModule, typeof i2.DxiValidationSummaryItemModule, typeof i3.DxTemplateModule]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxValidationSummaryModule>;
}

export { DxValidationSummaryComponent, DxValidationSummaryModule };
//# sourceMappingURL=index.d.ts.map
