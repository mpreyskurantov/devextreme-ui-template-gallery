import { TextEditorButtonLocation, ButtonStyle, ButtonType } from 'devextreme/common';
import { dxButtonOptions, ClickEvent, ContentReadyEvent, DisposingEvent, InitializedEvent, OptionChangedEvent } from 'devextreme/ui/button';
import { CollectionNestedOption, NestedOptionHost, NestedOption, IDxTemplateHost, DxTemplateHost, DxTemplateDirective } from 'devextreme-angular/core';
import * as i0 from '@angular/core';
import { AfterViewInit, OnDestroy, OnInit, Renderer2, ElementRef } from '@angular/core';

declare class DxiTextBoxButtonComponent extends CollectionNestedOption {
    get location(): TextEditorButtonLocation;
    set location(value: TextEditorButtonLocation);
    get name(): string | undefined;
    set name(value: string | undefined);
    get options(): dxButtonOptions | undefined;
    set options(value: dxButtonOptions | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiTextBoxButtonComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiTextBoxButtonComponent, "dxi-text-box-button", never, { "location": { "alias": "location"; "required": false; }; "name": { "alias": "name"; "required": false; }; "options": { "alias": "options"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxiTextBoxButtonModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiTextBoxButtonModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiTextBoxButtonModule, never, [typeof DxiTextBoxButtonComponent], [typeof DxiTextBoxButtonComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiTextBoxButtonModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoTextBoxOptionsComponent extends NestedOption implements AfterViewInit, OnDestroy, OnInit, IDxTemplateHost {
    private renderer;
    private document;
    private element;
    get accessKey(): string | undefined;
    set accessKey(value: string | undefined);
    get activeStateEnabled(): boolean;
    set activeStateEnabled(value: boolean);
    get disabled(): boolean;
    set disabled(value: boolean);
    get elementAttr(): Record<string, any>;
    set elementAttr(value: Record<string, any>);
    get focusStateEnabled(): boolean;
    set focusStateEnabled(value: boolean);
    get height(): number | string | undefined;
    set height(value: number | string | undefined);
    get hint(): string | undefined;
    set hint(value: string | undefined);
    get hoverStateEnabled(): boolean;
    set hoverStateEnabled(value: boolean);
    get icon(): string;
    set icon(value: string);
    get onClick(): ((e: ClickEvent) => void) | undefined;
    set onClick(value: ((e: ClickEvent) => void) | undefined);
    get onContentReady(): ((e: ContentReadyEvent) => void);
    set onContentReady(value: ((e: ContentReadyEvent) => void));
    get onDisposing(): ((e: DisposingEvent) => void);
    set onDisposing(value: ((e: DisposingEvent) => void));
    get onInitialized(): ((e: InitializedEvent) => void);
    set onInitialized(value: ((e: InitializedEvent) => void));
    get onOptionChanged(): ((e: OptionChangedEvent) => void);
    set onOptionChanged(value: ((e: OptionChangedEvent) => void));
    get rtlEnabled(): boolean;
    set rtlEnabled(value: boolean);
    get stylingMode(): ButtonStyle;
    set stylingMode(value: ButtonStyle);
    get tabIndex(): number;
    set tabIndex(value: number);
    get template(): any;
    set template(value: any);
    get text(): string;
    set text(value: string);
    get type(): ButtonType | string;
    set type(value: ButtonType | string);
    get useSubmitBehavior(): boolean;
    set useSubmitBehavior(value: boolean);
    get validationGroup(): string | undefined;
    set validationGroup(value: string | undefined);
    get visible(): boolean;
    set visible(value: boolean);
    get width(): number | string | undefined;
    set width(value: number | string | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost, renderer: Renderer2, document: any, templateHost: DxTemplateHost, element: ElementRef);
    setTemplate(template: DxTemplateDirective): void;
    ngAfterViewInit(): void;
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTextBoxOptionsComponent, [{ host: true; skipSelf: true; }, { host: true; }, null, null, { host: true; }, null]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoTextBoxOptionsComponent, "dxo-text-box-options", never, { "accessKey": { "alias": "accessKey"; "required": false; }; "activeStateEnabled": { "alias": "activeStateEnabled"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "elementAttr": { "alias": "elementAttr"; "required": false; }; "focusStateEnabled": { "alias": "focusStateEnabled"; "required": false; }; "height": { "alias": "height"; "required": false; }; "hint": { "alias": "hint"; "required": false; }; "hoverStateEnabled": { "alias": "hoverStateEnabled"; "required": false; }; "icon": { "alias": "icon"; "required": false; }; "onClick": { "alias": "onClick"; "required": false; }; "onContentReady": { "alias": "onContentReady"; "required": false; }; "onDisposing": { "alias": "onDisposing"; "required": false; }; "onInitialized": { "alias": "onInitialized"; "required": false; }; "onOptionChanged": { "alias": "onOptionChanged"; "required": false; }; "rtlEnabled": { "alias": "rtlEnabled"; "required": false; }; "stylingMode": { "alias": "stylingMode"; "required": false; }; "tabIndex": { "alias": "tabIndex"; "required": false; }; "template": { "alias": "template"; "required": false; }; "text": { "alias": "text"; "required": false; }; "type": { "alias": "type"; "required": false; }; "useSubmitBehavior": { "alias": "useSubmitBehavior"; "required": false; }; "validationGroup": { "alias": "validationGroup"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, ["*"], true, never>;
}
declare class DxoTextBoxOptionsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTextBoxOptionsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoTextBoxOptionsModule, never, [typeof DxoTextBoxOptionsComponent], [typeof DxoTextBoxOptionsComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoTextBoxOptionsModule>;
}

export { DxiTextBoxButtonComponent, DxiTextBoxButtonModule, DxoTextBoxOptionsComponent, DxoTextBoxOptionsModule };
//# sourceMappingURL=index.d.ts.map
