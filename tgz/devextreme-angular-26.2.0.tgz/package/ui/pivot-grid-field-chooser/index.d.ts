import * as i0 from '@angular/core';
import { OnDestroy, OnChanges, DoCheck, EventEmitter, ElementRef, NgZone, TransferState, SimpleChanges } from '@angular/core';
import PivotGridDataSource from 'devextreme/ui/pivot_grid/data_source';
import { ApplyChangesMode, HeaderFilterSearchConfig } from 'devextreme/common/grids';
import { FieldChooserLayout } from 'devextreme/common';
import DxPivotGridFieldChooser, { ContentReadyEvent, ContextMenuPreparingEvent, DisposingEvent, InitializedEvent, OptionChangedEvent } from 'devextreme/ui/pivot_grid_field_chooser';
import * as i3 from 'devextreme-angular/core';
import { DxComponent, DxTemplateHost, WatcherHelper, IterableDifferHelper, NestedOptionHost } from 'devextreme-angular/core';
import * as i1 from 'devextreme-angular/ui/nested';
import * as i2 from 'devextreme-angular/ui/pivot-grid-field-chooser/nested';
export * from 'devextreme-angular/ui/pivot-grid-field-chooser/nested';
import * as pivot_grid_field_chooser_types from 'devextreme/ui/pivot_grid_field_chooser_types';
export { pivot_grid_field_chooser_types as DxPivotGridFieldChooserTypes };

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

/**
 * [descr:dxPivotGridFieldChooser]

 */
declare class DxPivotGridFieldChooserComponent extends DxComponent implements OnDestroy, OnChanges, DoCheck {
    private _watcherHelper;
    private _idh;
    instance: DxPivotGridFieldChooser;
    /**
     * [descr:WidgetOptions.accessKey]
    
     */
    get accessKey(): string | undefined;
    set accessKey(value: string | undefined);
    /**
     * [descr:WidgetOptions.activeStateEnabled]
    
     */
    get activeStateEnabled(): boolean;
    set activeStateEnabled(value: boolean);
    /**
     * [descr:dxPivotGridFieldChooserOptions.allowSearch]
    
     */
    get allowSearch(): boolean;
    set allowSearch(value: boolean);
    /**
     * [descr:dxPivotGridFieldChooserOptions.applyChangesMode]
    
     */
    get applyChangesMode(): ApplyChangesMode;
    set applyChangesMode(value: ApplyChangesMode);
    /**
     * [descr:dxPivotGridFieldChooserOptions.dataSource]
    
     */
    get dataSource(): null | PivotGridDataSource;
    set dataSource(value: null | PivotGridDataSource);
    /**
     * [descr:WidgetOptions.disabled]
    
     */
    get disabled(): boolean;
    set disabled(value: boolean);
    /**
     * [descr:DOMComponentOptions.elementAttr]
    
     */
    get elementAttr(): Record<string, any>;
    set elementAttr(value: Record<string, any>);
    /**
     * [descr:dxPivotGridFieldChooserOptions.encodeHtml]
    
     */
    get encodeHtml(): boolean;
    set encodeHtml(value: boolean);
    /**
     * [descr:WidgetOptions.focusStateEnabled]
    
     */
    get focusStateEnabled(): boolean;
    set focusStateEnabled(value: boolean);
    /**
     * [descr:dxPivotGridFieldChooserOptions.headerFilter]
    
     */
    get headerFilter(): {
        allowSearch?: boolean;
        allowSelectAll?: boolean;
        height?: number;
        search?: HeaderFilterSearchConfig;
        searchTimeout?: number;
        showRelevantValues?: boolean;
        texts?: {
            cancel?: string;
            emptyValue?: string;
            ok?: string;
        };
        width?: number;
    };
    set headerFilter(value: {
        allowSearch?: boolean;
        allowSelectAll?: boolean;
        height?: number;
        search?: HeaderFilterSearchConfig;
        searchTimeout?: number;
        showRelevantValues?: boolean;
        texts?: {
            cancel?: string;
            emptyValue?: string;
            ok?: string;
        };
        width?: number;
    });
    /**
     * [descr:dxPivotGridFieldChooserOptions.height]
    
     */
    get height(): number | string;
    set height(value: number | string);
    /**
     * [descr:WidgetOptions.hint]
    
     */
    get hint(): string | undefined;
    set hint(value: string | undefined);
    /**
     * [descr:WidgetOptions.hoverStateEnabled]
    
     */
    get hoverStateEnabled(): boolean;
    set hoverStateEnabled(value: boolean);
    /**
     * [descr:dxPivotGridFieldChooserOptions.layout]
    
     */
    get layout(): FieldChooserLayout;
    set layout(value: FieldChooserLayout);
    /**
     * [descr:DOMComponentOptions.rtlEnabled]
    
     */
    get rtlEnabled(): boolean;
    set rtlEnabled(value: boolean);
    /**
     * [descr:dxPivotGridFieldChooserOptions.searchTimeout]
    
     */
    get searchTimeout(): number;
    set searchTimeout(value: number);
    /**
     * [descr:dxPivotGridFieldChooserOptions.state]
    
     */
    get state(): any | undefined;
    set state(value: any | undefined);
    /**
     * [descr:WidgetOptions.tabIndex]
    
     */
    get tabIndex(): number;
    set tabIndex(value: number);
    /**
     * [descr:dxPivotGridFieldChooserOptions.texts]
    
     */
    get texts(): {
        allFields?: string;
        columnFields?: string;
        dataFields?: string;
        filterFields?: string;
        rowFields?: string;
    };
    set texts(value: {
        allFields?: string;
        columnFields?: string;
        dataFields?: string;
        filterFields?: string;
        rowFields?: string;
    });
    /**
     * [descr:WidgetOptions.visible]
    
     */
    get visible(): boolean;
    set visible(value: boolean);
    /**
     * [descr:DOMComponentOptions.width]
    
     */
    get width(): number | string | undefined;
    set width(value: number | string | undefined);
    /**
    
     * [descr:dxPivotGridFieldChooserOptions.onContentReady]
    
    
     */
    onContentReady: EventEmitter<ContentReadyEvent>;
    /**
    
     * [descr:dxPivotGridFieldChooserOptions.onContextMenuPreparing]
    
    
     */
    onContextMenuPreparing: EventEmitter<ContextMenuPreparingEvent>;
    /**
    
     * [descr:dxPivotGridFieldChooserOptions.onDisposing]
    
    
     */
    onDisposing: EventEmitter<DisposingEvent>;
    /**
    
     * [descr:dxPivotGridFieldChooserOptions.onInitialized]
    
    
     */
    onInitialized: EventEmitter<InitializedEvent>;
    /**
    
     * [descr:dxPivotGridFieldChooserOptions.onOptionChanged]
    
    
     */
    onOptionChanged: EventEmitter<OptionChangedEvent>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    accessKeyChange: EventEmitter<string | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    activeStateEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    allowSearchChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    applyChangesModeChange: EventEmitter<ApplyChangesMode>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    dataSourceChange: EventEmitter<null | PivotGridDataSource>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    disabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    elementAttrChange: EventEmitter<Record<string, any>>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    encodeHtmlChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    focusStateEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    headerFilterChange: EventEmitter<{
        allowSearch?: boolean;
        allowSelectAll?: boolean;
        height?: number;
        search?: HeaderFilterSearchConfig;
        searchTimeout?: number;
        showRelevantValues?: boolean;
        texts?: {
            cancel?: string;
            emptyValue?: string;
            ok?: string;
        };
        width?: number;
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    heightChange: EventEmitter<number | string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    hintChange: EventEmitter<string | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    hoverStateEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    layoutChange: EventEmitter<FieldChooserLayout>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    rtlEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    searchTimeoutChange: EventEmitter<number>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    stateChange: EventEmitter<any | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    tabIndexChange: EventEmitter<number>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    textsChange: EventEmitter<{
        allFields?: string;
        columnFields?: string;
        dataFields?: string;
        filterFields?: string;
        rowFields?: string;
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    visibleChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    widthChange: EventEmitter<number | string | undefined>;
    constructor(elementRef: ElementRef, ngZone: NgZone, templateHost: DxTemplateHost, _watcherHelper: WatcherHelper, _idh: IterableDifferHelper, optionHost: NestedOptionHost, transferState: TransferState, platformId: any);
    protected _createInstance(element: any, options: any): DxPivotGridFieldChooser;
    ngOnDestroy(): void;
    ngOnChanges(changes: SimpleChanges): void;
    setupChanges(prop: string, changes: SimpleChanges): void;
    ngDoCheck(): void;
    _setOption(name: string, value: any): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxPivotGridFieldChooserComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxPivotGridFieldChooserComponent, "dx-pivot-grid-field-chooser", never, { "accessKey": { "alias": "accessKey"; "required": false; }; "activeStateEnabled": { "alias": "activeStateEnabled"; "required": false; }; "allowSearch": { "alias": "allowSearch"; "required": false; }; "applyChangesMode": { "alias": "applyChangesMode"; "required": false; }; "dataSource": { "alias": "dataSource"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "elementAttr": { "alias": "elementAttr"; "required": false; }; "encodeHtml": { "alias": "encodeHtml"; "required": false; }; "focusStateEnabled": { "alias": "focusStateEnabled"; "required": false; }; "headerFilter": { "alias": "headerFilter"; "required": false; }; "height": { "alias": "height"; "required": false; }; "hint": { "alias": "hint"; "required": false; }; "hoverStateEnabled": { "alias": "hoverStateEnabled"; "required": false; }; "layout": { "alias": "layout"; "required": false; }; "rtlEnabled": { "alias": "rtlEnabled"; "required": false; }; "searchTimeout": { "alias": "searchTimeout"; "required": false; }; "state": { "alias": "state"; "required": false; }; "tabIndex": { "alias": "tabIndex"; "required": false; }; "texts": { "alias": "texts"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, { "onContentReady": "onContentReady"; "onContextMenuPreparing": "onContextMenuPreparing"; "onDisposing": "onDisposing"; "onInitialized": "onInitialized"; "onOptionChanged": "onOptionChanged"; "accessKeyChange": "accessKeyChange"; "activeStateEnabledChange": "activeStateEnabledChange"; "allowSearchChange": "allowSearchChange"; "applyChangesModeChange": "applyChangesModeChange"; "dataSourceChange": "dataSourceChange"; "disabledChange": "disabledChange"; "elementAttrChange": "elementAttrChange"; "encodeHtmlChange": "encodeHtmlChange"; "focusStateEnabledChange": "focusStateEnabledChange"; "headerFilterChange": "headerFilterChange"; "heightChange": "heightChange"; "hintChange": "hintChange"; "hoverStateEnabledChange": "hoverStateEnabledChange"; "layoutChange": "layoutChange"; "rtlEnabledChange": "rtlEnabledChange"; "searchTimeoutChange": "searchTimeoutChange"; "stateChange": "stateChange"; "tabIndexChange": "tabIndexChange"; "textsChange": "textsChange"; "visibleChange": "visibleChange"; "widthChange": "widthChange"; }, never, never, true, never>;
}
declare class DxPivotGridFieldChooserModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxPivotGridFieldChooserModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxPivotGridFieldChooserModule, never, [typeof DxPivotGridFieldChooserComponent, typeof i1.DxoHeaderFilterModule, typeof i1.DxoSearchModule, typeof i1.DxoTextsModule, typeof i2.DxoPivotGridFieldChooserHeaderFilterModule, typeof i2.DxoPivotGridFieldChooserHeaderFilterTextsModule, typeof i2.DxoPivotGridFieldChooserPivotGridFieldChooserTextsModule, typeof i2.DxoPivotGridFieldChooserSearchModule, typeof i2.DxoPivotGridFieldChooserTextsModule, typeof i3.DxIntegrationModule, typeof i3.DxTemplateModule], [typeof DxPivotGridFieldChooserComponent, typeof i1.DxoHeaderFilterModule, typeof i1.DxoSearchModule, typeof i1.DxoTextsModule, typeof i2.DxoPivotGridFieldChooserHeaderFilterModule, typeof i2.DxoPivotGridFieldChooserHeaderFilterTextsModule, typeof i2.DxoPivotGridFieldChooserPivotGridFieldChooserTextsModule, typeof i2.DxoPivotGridFieldChooserSearchModule, typeof i2.DxoPivotGridFieldChooserTextsModule, typeof i3.DxTemplateModule]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxPivotGridFieldChooserModule>;
}

export { DxPivotGridFieldChooserComponent, DxPivotGridFieldChooserModule };
//# sourceMappingURL=index.d.ts.map
