import * as i0 from '@angular/core';
import { OnDestroy, OnInit } from '@angular/core';
import { NestedOption, NestedOptionHost } from 'devextreme-angular/core';
import { HeaderFilterSearchConfig } from 'devextreme/common/grids';
import { SearchMode } from 'devextreme/common';

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoPivotGridFieldChooserHeaderFilterTextsComponent extends NestedOption implements OnDestroy, OnInit {
    get cancel(): string;
    set cancel(value: string);
    get emptyValue(): string;
    set emptyValue(value: string);
    get ok(): string;
    set ok(value: string);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPivotGridFieldChooserHeaderFilterTextsComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoPivotGridFieldChooserHeaderFilterTextsComponent, "dxo-pivot-grid-field-chooser-header-filter-texts", never, { "cancel": { "alias": "cancel"; "required": false; }; "emptyValue": { "alias": "emptyValue"; "required": false; }; "ok": { "alias": "ok"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoPivotGridFieldChooserHeaderFilterTextsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPivotGridFieldChooserHeaderFilterTextsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoPivotGridFieldChooserHeaderFilterTextsModule, never, [typeof DxoPivotGridFieldChooserHeaderFilterTextsComponent], [typeof DxoPivotGridFieldChooserHeaderFilterTextsComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoPivotGridFieldChooserHeaderFilterTextsModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoPivotGridFieldChooserHeaderFilterComponent extends NestedOption implements OnDestroy, OnInit {
    get allowSearch(): boolean;
    set allowSearch(value: boolean);
    get allowSelectAll(): boolean;
    set allowSelectAll(value: boolean);
    get height(): number;
    set height(value: number);
    get search(): HeaderFilterSearchConfig;
    set search(value: HeaderFilterSearchConfig);
    get searchTimeout(): number;
    set searchTimeout(value: number);
    get showRelevantValues(): boolean;
    set showRelevantValues(value: boolean);
    get texts(): {
        cancel?: string;
        emptyValue?: string;
        ok?: string;
    };
    set texts(value: {
        cancel?: string;
        emptyValue?: string;
        ok?: string;
    });
    get width(): number;
    set width(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPivotGridFieldChooserHeaderFilterComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoPivotGridFieldChooserHeaderFilterComponent, "dxo-pivot-grid-field-chooser-header-filter", never, { "allowSearch": { "alias": "allowSearch"; "required": false; }; "allowSelectAll": { "alias": "allowSelectAll"; "required": false; }; "height": { "alias": "height"; "required": false; }; "search": { "alias": "search"; "required": false; }; "searchTimeout": { "alias": "searchTimeout"; "required": false; }; "showRelevantValues": { "alias": "showRelevantValues"; "required": false; }; "texts": { "alias": "texts"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoPivotGridFieldChooserHeaderFilterModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPivotGridFieldChooserHeaderFilterModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoPivotGridFieldChooserHeaderFilterModule, never, [typeof DxoPivotGridFieldChooserHeaderFilterComponent], [typeof DxoPivotGridFieldChooserHeaderFilterComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoPivotGridFieldChooserHeaderFilterModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoPivotGridFieldChooserPivotGridFieldChooserTextsComponent extends NestedOption implements OnDestroy, OnInit {
    get allFields(): string;
    set allFields(value: string);
    get columnFields(): string;
    set columnFields(value: string);
    get dataFields(): string;
    set dataFields(value: string);
    get filterFields(): string;
    set filterFields(value: string);
    get rowFields(): string;
    set rowFields(value: string);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPivotGridFieldChooserPivotGridFieldChooserTextsComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoPivotGridFieldChooserPivotGridFieldChooserTextsComponent, "dxo-pivot-grid-field-chooser-pivot-grid-field-chooser-texts", never, { "allFields": { "alias": "allFields"; "required": false; }; "columnFields": { "alias": "columnFields"; "required": false; }; "dataFields": { "alias": "dataFields"; "required": false; }; "filterFields": { "alias": "filterFields"; "required": false; }; "rowFields": { "alias": "rowFields"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoPivotGridFieldChooserPivotGridFieldChooserTextsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPivotGridFieldChooserPivotGridFieldChooserTextsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoPivotGridFieldChooserPivotGridFieldChooserTextsModule, never, [typeof DxoPivotGridFieldChooserPivotGridFieldChooserTextsComponent], [typeof DxoPivotGridFieldChooserPivotGridFieldChooserTextsComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoPivotGridFieldChooserPivotGridFieldChooserTextsModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoPivotGridFieldChooserSearchComponent extends NestedOption implements OnDestroy, OnInit {
    get editorOptions(): any;
    set editorOptions(value: any);
    get enabled(): boolean;
    set enabled(value: boolean);
    get mode(): SearchMode;
    set mode(value: SearchMode);
    get timeout(): number;
    set timeout(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPivotGridFieldChooserSearchComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoPivotGridFieldChooserSearchComponent, "dxo-pivot-grid-field-chooser-search", never, { "editorOptions": { "alias": "editorOptions"; "required": false; }; "enabled": { "alias": "enabled"; "required": false; }; "mode": { "alias": "mode"; "required": false; }; "timeout": { "alias": "timeout"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoPivotGridFieldChooserSearchModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPivotGridFieldChooserSearchModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoPivotGridFieldChooserSearchModule, never, [typeof DxoPivotGridFieldChooserSearchComponent], [typeof DxoPivotGridFieldChooserSearchComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoPivotGridFieldChooserSearchModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoPivotGridFieldChooserTextsComponent extends NestedOption implements OnDestroy, OnInit {
    get cancel(): string;
    set cancel(value: string);
    get emptyValue(): string;
    set emptyValue(value: string);
    get ok(): string;
    set ok(value: string);
    get allFields(): string;
    set allFields(value: string);
    get columnFields(): string;
    set columnFields(value: string);
    get dataFields(): string;
    set dataFields(value: string);
    get filterFields(): string;
    set filterFields(value: string);
    get rowFields(): string;
    set rowFields(value: string);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPivotGridFieldChooserTextsComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoPivotGridFieldChooserTextsComponent, "dxo-pivot-grid-field-chooser-texts", never, { "cancel": { "alias": "cancel"; "required": false; }; "emptyValue": { "alias": "emptyValue"; "required": false; }; "ok": { "alias": "ok"; "required": false; }; "allFields": { "alias": "allFields"; "required": false; }; "columnFields": { "alias": "columnFields"; "required": false; }; "dataFields": { "alias": "dataFields"; "required": false; }; "filterFields": { "alias": "filterFields"; "required": false; }; "rowFields": { "alias": "rowFields"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoPivotGridFieldChooserTextsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPivotGridFieldChooserTextsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoPivotGridFieldChooserTextsModule, never, [typeof DxoPivotGridFieldChooserTextsComponent], [typeof DxoPivotGridFieldChooserTextsComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoPivotGridFieldChooserTextsModule>;
}

export { DxoPivotGridFieldChooserHeaderFilterComponent, DxoPivotGridFieldChooserHeaderFilterModule, DxoPivotGridFieldChooserHeaderFilterTextsComponent, DxoPivotGridFieldChooserHeaderFilterTextsModule, DxoPivotGridFieldChooserPivotGridFieldChooserTextsComponent, DxoPivotGridFieldChooserPivotGridFieldChooserTextsModule, DxoPivotGridFieldChooserSearchComponent, DxoPivotGridFieldChooserSearchModule, DxoPivotGridFieldChooserTextsComponent, DxoPivotGridFieldChooserTextsModule };
//# sourceMappingURL=index.d.ts.map
