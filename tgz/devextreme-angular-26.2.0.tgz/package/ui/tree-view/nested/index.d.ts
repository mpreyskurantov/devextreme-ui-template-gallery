import { TextEditorButtonLocation, ButtonStyle, ButtonType, TextBoxPredefinedButton, TextEditorButton, LabelMode, MaskMode, EditorStyle, ValidationMessageMode, Position, ValidationStatus } from 'devextreme/common';
import { dxButtonOptions, ClickEvent, ContentReadyEvent, DisposingEvent, InitializedEvent, OptionChangedEvent } from 'devextreme/ui/button';
import { CollectionNestedOption, NestedOptionHost, IDxTemplateHost, DxTemplateHost, DxTemplateDirective, NestedOption } from 'devextreme-angular/core';
import * as i0 from '@angular/core';
import { AfterViewInit, QueryList, Renderer2, ElementRef, OnDestroy, OnInit, EventEmitter } from '@angular/core';
import { dxTreeViewItem } from 'devextreme/ui/tree_view';
import { TextBoxType, ChangeEvent, ContentReadyEvent as ContentReadyEvent$1, CopyEvent, CutEvent, DisposingEvent as DisposingEvent$1, EnterKeyEvent, FocusInEvent, FocusOutEvent, InitializedEvent as InitializedEvent$1, InputEvent, KeyDownEvent, KeyUpEvent, OptionChangedEvent as OptionChangedEvent$1, PasteEvent, ValueChangedEvent } from 'devextreme/ui/text_box';

declare class DxiTreeViewButtonComponent extends CollectionNestedOption {
    get location(): TextEditorButtonLocation;
    set location(value: TextEditorButtonLocation);
    get name(): string | undefined;
    set name(value: string | undefined);
    get options(): dxButtonOptions | undefined;
    set options(value: dxButtonOptions | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiTreeViewButtonComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiTreeViewButtonComponent, "dxi-tree-view-button", never, { "location": { "alias": "location"; "required": false; }; "name": { "alias": "name"; "required": false; }; "options": { "alias": "options"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxiTreeViewButtonModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiTreeViewButtonModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiTreeViewButtonModule, never, [typeof DxiTreeViewButtonComponent], [typeof DxiTreeViewButtonComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiTreeViewButtonModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxiTreeViewItemComponent extends CollectionNestedOption implements AfterViewInit, IDxTemplateHost {
    private renderer;
    private document;
    private element;
    set _itemsContentChildren(value: QueryList<CollectionNestedOption>);
    get disabled(): boolean;
    set disabled(value: boolean);
    get expanded(): boolean;
    set expanded(value: boolean);
    get hasItems(): boolean | undefined;
    set hasItems(value: boolean | undefined);
    get html(): string;
    set html(value: string);
    get icon(): string;
    set icon(value: string);
    get id(): number | string | undefined;
    set id(value: number | string | undefined);
    get items(): Array<dxTreeViewItem>;
    set items(value: Array<dxTreeViewItem>);
    get parentId(): number | string | undefined;
    set parentId(value: number | string | undefined);
    get selected(): boolean;
    set selected(value: boolean);
    get template(): any;
    set template(value: any);
    get text(): string;
    set text(value: string);
    get visible(): boolean;
    set visible(value: boolean);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost, renderer: Renderer2, document: any, templateHost: DxTemplateHost, element: ElementRef);
    setTemplate(template: DxTemplateDirective): void;
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiTreeViewItemComponent, [{ host: true; skipSelf: true; }, { host: true; }, null, null, { host: true; }, null]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiTreeViewItemComponent, "dxi-tree-view-item", never, { "disabled": { "alias": "disabled"; "required": false; }; "expanded": { "alias": "expanded"; "required": false; }; "hasItems": { "alias": "hasItems"; "required": false; }; "html": { "alias": "html"; "required": false; }; "icon": { "alias": "icon"; "required": false; }; "id": { "alias": "id"; "required": false; }; "items": { "alias": "items"; "required": false; }; "parentId": { "alias": "parentId"; "required": false; }; "selected": { "alias": "selected"; "required": false; }; "template": { "alias": "template"; "required": false; }; "text": { "alias": "text"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; }, {}, ["_itemsContentChildren"], ["*"], true, never>;
}
declare class DxiTreeViewItemModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiTreeViewItemModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiTreeViewItemModule, never, [typeof DxiTreeViewItemComponent], [typeof DxiTreeViewItemComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiTreeViewItemModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoTreeViewOptionsComponent extends NestedOption implements AfterViewInit, OnDestroy, OnInit, IDxTemplateHost {
    private renderer;
    private document;
    private element;
    get accessKey(): string | undefined;
    set accessKey(value: string | undefined);
    get activeStateEnabled(): boolean;
    set activeStateEnabled(value: boolean);
    get disabled(): boolean;
    set disabled(value: boolean);
    get elementAttr(): Record<string, any>;
    set elementAttr(value: Record<string, any>);
    get focusStateEnabled(): boolean;
    set focusStateEnabled(value: boolean);
    get height(): number | string | undefined;
    set height(value: number | string | undefined);
    get hint(): string | undefined;
    set hint(value: string | undefined);
    get hoverStateEnabled(): boolean;
    set hoverStateEnabled(value: boolean);
    get icon(): string;
    set icon(value: string);
    get onClick(): ((e: ClickEvent) => void) | undefined;
    set onClick(value: ((e: ClickEvent) => void) | undefined);
    get onContentReady(): ((e: ContentReadyEvent) => void);
    set onContentReady(value: ((e: ContentReadyEvent) => void));
    get onDisposing(): ((e: DisposingEvent) => void);
    set onDisposing(value: ((e: DisposingEvent) => void));
    get onInitialized(): ((e: InitializedEvent) => void);
    set onInitialized(value: ((e: InitializedEvent) => void));
    get onOptionChanged(): ((e: OptionChangedEvent) => void);
    set onOptionChanged(value: ((e: OptionChangedEvent) => void));
    get rtlEnabled(): boolean;
    set rtlEnabled(value: boolean);
    get stylingMode(): ButtonStyle;
    set stylingMode(value: ButtonStyle);
    get tabIndex(): number;
    set tabIndex(value: number);
    get template(): any;
    set template(value: any);
    get text(): string;
    set text(value: string);
    get type(): ButtonType | string;
    set type(value: ButtonType | string);
    get useSubmitBehavior(): boolean;
    set useSubmitBehavior(value: boolean);
    get validationGroup(): string | undefined;
    set validationGroup(value: string | undefined);
    get visible(): boolean;
    set visible(value: boolean);
    get width(): number | string | undefined;
    set width(value: number | string | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost, renderer: Renderer2, document: any, templateHost: DxTemplateHost, element: ElementRef);
    setTemplate(template: DxTemplateDirective): void;
    ngAfterViewInit(): void;
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTreeViewOptionsComponent, [{ host: true; skipSelf: true; }, { host: true; }, null, null, { host: true; }, null]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoTreeViewOptionsComponent, "dxo-tree-view-options", never, { "accessKey": { "alias": "accessKey"; "required": false; }; "activeStateEnabled": { "alias": "activeStateEnabled"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "elementAttr": { "alias": "elementAttr"; "required": false; }; "focusStateEnabled": { "alias": "focusStateEnabled"; "required": false; }; "height": { "alias": "height"; "required": false; }; "hint": { "alias": "hint"; "required": false; }; "hoverStateEnabled": { "alias": "hoverStateEnabled"; "required": false; }; "icon": { "alias": "icon"; "required": false; }; "onClick": { "alias": "onClick"; "required": false; }; "onContentReady": { "alias": "onContentReady"; "required": false; }; "onDisposing": { "alias": "onDisposing"; "required": false; }; "onInitialized": { "alias": "onInitialized"; "required": false; }; "onOptionChanged": { "alias": "onOptionChanged"; "required": false; }; "rtlEnabled": { "alias": "rtlEnabled"; "required": false; }; "stylingMode": { "alias": "stylingMode"; "required": false; }; "tabIndex": { "alias": "tabIndex"; "required": false; }; "template": { "alias": "template"; "required": false; }; "text": { "alias": "text"; "required": false; }; "type": { "alias": "type"; "required": false; }; "useSubmitBehavior": { "alias": "useSubmitBehavior"; "required": false; }; "validationGroup": { "alias": "validationGroup"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, ["*"], true, never>;
}
declare class DxoTreeViewOptionsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTreeViewOptionsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoTreeViewOptionsModule, never, [typeof DxoTreeViewOptionsComponent], [typeof DxoTreeViewOptionsComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoTreeViewOptionsModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoTreeViewSearchEditorOptionsComponent extends NestedOption implements OnDestroy, OnInit {
    set _buttonsContentChildren(value: QueryList<CollectionNestedOption>);
    get accessKey(): string | undefined;
    set accessKey(value: string | undefined);
    get activeStateEnabled(): boolean;
    set activeStateEnabled(value: boolean);
    get buttons(): Array<string | TextBoxPredefinedButton | TextEditorButton> | undefined;
    set buttons(value: Array<string | TextBoxPredefinedButton | TextEditorButton> | undefined);
    get disabled(): boolean;
    set disabled(value: boolean);
    get elementAttr(): Record<string, any>;
    set elementAttr(value: Record<string, any>);
    get focusStateEnabled(): boolean;
    set focusStateEnabled(value: boolean);
    get height(): number | string | undefined;
    set height(value: number | string | undefined);
    get hint(): string | undefined;
    set hint(value: string | undefined);
    get hoverStateEnabled(): boolean;
    set hoverStateEnabled(value: boolean);
    get inputAttr(): any;
    set inputAttr(value: any);
    get isDirty(): boolean;
    set isDirty(value: boolean);
    get isValid(): boolean;
    set isValid(value: boolean);
    get label(): string;
    set label(value: string);
    get labelMode(): LabelMode;
    set labelMode(value: LabelMode);
    get mask(): string;
    set mask(value: string);
    get maskChar(): string;
    set maskChar(value: string);
    get maskInvalidMessage(): string;
    set maskInvalidMessage(value: string);
    get maskRules(): any;
    set maskRules(value: any);
    get maxLength(): null | number | string;
    set maxLength(value: null | number | string);
    get mode(): TextBoxType;
    set mode(value: TextBoxType);
    get name(): string;
    set name(value: string);
    get onChange(): ((e: ChangeEvent) => void);
    set onChange(value: ((e: ChangeEvent) => void));
    get onContentReady(): ((e: ContentReadyEvent$1) => void);
    set onContentReady(value: ((e: ContentReadyEvent$1) => void));
    get onCopy(): ((e: CopyEvent) => void);
    set onCopy(value: ((e: CopyEvent) => void));
    get onCut(): ((e: CutEvent) => void);
    set onCut(value: ((e: CutEvent) => void));
    get onDisposing(): ((e: DisposingEvent$1) => void);
    set onDisposing(value: ((e: DisposingEvent$1) => void));
    get onEnterKey(): ((e: EnterKeyEvent) => void);
    set onEnterKey(value: ((e: EnterKeyEvent) => void));
    get onFocusIn(): ((e: FocusInEvent) => void);
    set onFocusIn(value: ((e: FocusInEvent) => void));
    get onFocusOut(): ((e: FocusOutEvent) => void);
    set onFocusOut(value: ((e: FocusOutEvent) => void));
    get onInitialized(): ((e: InitializedEvent$1) => void);
    set onInitialized(value: ((e: InitializedEvent$1) => void));
    get onInput(): ((e: InputEvent) => void);
    set onInput(value: ((e: InputEvent) => void));
    get onKeyDown(): ((e: KeyDownEvent) => void);
    set onKeyDown(value: ((e: KeyDownEvent) => void));
    get onKeyUp(): ((e: KeyUpEvent) => void);
    set onKeyUp(value: ((e: KeyUpEvent) => void));
    get onOptionChanged(): ((e: OptionChangedEvent$1) => void);
    set onOptionChanged(value: ((e: OptionChangedEvent$1) => void));
    get onPaste(): ((e: PasteEvent) => void);
    set onPaste(value: ((e: PasteEvent) => void));
    get onValueChanged(): ((e: ValueChangedEvent) => void);
    set onValueChanged(value: ((e: ValueChangedEvent) => void));
    get placeholder(): string;
    set placeholder(value: string);
    get readOnly(): boolean;
    set readOnly(value: boolean);
    get rtlEnabled(): boolean;
    set rtlEnabled(value: boolean);
    get showClearButton(): boolean;
    set showClearButton(value: boolean);
    get showMaskMode(): MaskMode;
    set showMaskMode(value: MaskMode);
    get spellcheck(): boolean;
    set spellcheck(value: boolean);
    get stylingMode(): EditorStyle;
    set stylingMode(value: EditorStyle);
    get tabIndex(): number;
    set tabIndex(value: number);
    get text(): string;
    set text(value: string);
    get useMaskedValue(): boolean;
    set useMaskedValue(value: boolean);
    get validationError(): any | null;
    set validationError(value: any | null);
    get validationErrors(): Array<any> | null;
    set validationErrors(value: Array<any> | null);
    get validationMessageMode(): ValidationMessageMode;
    set validationMessageMode(value: ValidationMessageMode);
    get validationMessagePosition(): Position;
    set validationMessagePosition(value: Position);
    get validationStatus(): ValidationStatus;
    set validationStatus(value: ValidationStatus);
    get value(): string;
    set value(value: string);
    get valueChangeEvent(): string;
    set valueChangeEvent(value: string);
    get visible(): boolean;
    set visible(value: boolean);
    get width(): number | string | undefined;
    set width(value: number | string | undefined);
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    valueChange: EventEmitter<string>;
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTreeViewSearchEditorOptionsComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoTreeViewSearchEditorOptionsComponent, "dxo-tree-view-search-editor-options", never, { "accessKey": { "alias": "accessKey"; "required": false; }; "activeStateEnabled": { "alias": "activeStateEnabled"; "required": false; }; "buttons": { "alias": "buttons"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "elementAttr": { "alias": "elementAttr"; "required": false; }; "focusStateEnabled": { "alias": "focusStateEnabled"; "required": false; }; "height": { "alias": "height"; "required": false; }; "hint": { "alias": "hint"; "required": false; }; "hoverStateEnabled": { "alias": "hoverStateEnabled"; "required": false; }; "inputAttr": { "alias": "inputAttr"; "required": false; }; "isDirty": { "alias": "isDirty"; "required": false; }; "isValid": { "alias": "isValid"; "required": false; }; "label": { "alias": "label"; "required": false; }; "labelMode": { "alias": "labelMode"; "required": false; }; "mask": { "alias": "mask"; "required": false; }; "maskChar": { "alias": "maskChar"; "required": false; }; "maskInvalidMessage": { "alias": "maskInvalidMessage"; "required": false; }; "maskRules": { "alias": "maskRules"; "required": false; }; "maxLength": { "alias": "maxLength"; "required": false; }; "mode": { "alias": "mode"; "required": false; }; "name": { "alias": "name"; "required": false; }; "onChange": { "alias": "onChange"; "required": false; }; "onContentReady": { "alias": "onContentReady"; "required": false; }; "onCopy": { "alias": "onCopy"; "required": false; }; "onCut": { "alias": "onCut"; "required": false; }; "onDisposing": { "alias": "onDisposing"; "required": false; }; "onEnterKey": { "alias": "onEnterKey"; "required": false; }; "onFocusIn": { "alias": "onFocusIn"; "required": false; }; "onFocusOut": { "alias": "onFocusOut"; "required": false; }; "onInitialized": { "alias": "onInitialized"; "required": false; }; "onInput": { "alias": "onInput"; "required": false; }; "onKeyDown": { "alias": "onKeyDown"; "required": false; }; "onKeyUp": { "alias": "onKeyUp"; "required": false; }; "onOptionChanged": { "alias": "onOptionChanged"; "required": false; }; "onPaste": { "alias": "onPaste"; "required": false; }; "onValueChanged": { "alias": "onValueChanged"; "required": false; }; "placeholder": { "alias": "placeholder"; "required": false; }; "readOnly": { "alias": "readOnly"; "required": false; }; "rtlEnabled": { "alias": "rtlEnabled"; "required": false; }; "showClearButton": { "alias": "showClearButton"; "required": false; }; "showMaskMode": { "alias": "showMaskMode"; "required": false; }; "spellcheck": { "alias": "spellcheck"; "required": false; }; "stylingMode": { "alias": "stylingMode"; "required": false; }; "tabIndex": { "alias": "tabIndex"; "required": false; }; "text": { "alias": "text"; "required": false; }; "useMaskedValue": { "alias": "useMaskedValue"; "required": false; }; "validationError": { "alias": "validationError"; "required": false; }; "validationErrors": { "alias": "validationErrors"; "required": false; }; "validationMessageMode": { "alias": "validationMessageMode"; "required": false; }; "validationMessagePosition": { "alias": "validationMessagePosition"; "required": false; }; "validationStatus": { "alias": "validationStatus"; "required": false; }; "value": { "alias": "value"; "required": false; }; "valueChangeEvent": { "alias": "valueChangeEvent"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, { "valueChange": "valueChange"; }, ["_buttonsContentChildren"], never, true, never>;
}
declare class DxoTreeViewSearchEditorOptionsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTreeViewSearchEditorOptionsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoTreeViewSearchEditorOptionsModule, never, [typeof DxoTreeViewSearchEditorOptionsComponent], [typeof DxoTreeViewSearchEditorOptionsComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoTreeViewSearchEditorOptionsModule>;
}

export { DxiTreeViewButtonComponent, DxiTreeViewButtonModule, DxiTreeViewItemComponent, DxiTreeViewItemModule, DxoTreeViewOptionsComponent, DxoTreeViewOptionsModule, DxoTreeViewSearchEditorOptionsComponent, DxoTreeViewSearchEditorOptionsModule };
//# sourceMappingURL=index.d.ts.map
