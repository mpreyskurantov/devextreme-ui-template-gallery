import * as i0 from '@angular/core';
import { OnDestroy, OnChanges, DoCheck, QueryList, EventEmitter, ElementRef, NgZone, TransferState, SimpleChanges } from '@angular/core';
import DxTreeView, { dxTreeViewNode, dxTreeViewItem, DisabledNodeSelectionMode, TreeViewExpandEvent, TreeViewCheckBoxMode, ContentReadyEvent, DisposingEvent, InitializedEvent, ItemClickEvent, ItemCollapsedEvent, ItemContextMenuEvent, ItemExpandedEvent, ItemHoldEvent, ItemRenderedEvent, ItemSelectionChangedEvent, OptionChangedEvent, SelectAllValueChangedEvent, SelectionChangedEvent } from 'devextreme/ui/tree_view';
export { ExplicitTypes } from 'devextreme/ui/tree_view';
import DataSource, { DataSourceOptions } from 'devextreme/data/data_source';
import { Store } from 'devextreme/data/store';
import { DataStructure, ScrollDirection, SearchMode, SingleOrMultiple } from 'devextreme/common';
import { dxTextBoxOptions } from 'devextreme/ui/text_box';
import * as i3 from 'devextreme-angular/core';
import { DxComponent, CollectionNestedOption, DxTemplateHost, WatcherHelper, IterableDifferHelper, NestedOptionHost } from 'devextreme-angular/core';
import * as i1 from 'devextreme-angular/ui/nested';
import * as i2 from 'devextreme-angular/ui/tree-view/nested';
export * from 'devextreme-angular/ui/tree-view/nested';
import * as tree_view_types from 'devextreme/ui/tree_view_types';
export { tree_view_types as DxTreeViewTypes };

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

/**
 * [descr:dxTreeView]

 */
declare class DxTreeViewComponent<TItem = any, TKey = any> extends DxComponent implements OnDestroy, OnChanges, DoCheck {
    private _watcherHelper;
    private _idh;
    set _buttonsContentChildren(value: QueryList<CollectionNestedOption>);
    set _itemsContentChildren(value: QueryList<CollectionNestedOption>);
    instance: DxTreeView<TItem, TKey>;
    /**
     * [descr:WidgetOptions.accessKey]
    
     */
    get accessKey(): string | undefined;
    set accessKey(value: string | undefined);
    /**
     * [descr:WidgetOptions.activeStateEnabled]
    
     */
    get activeStateEnabled(): boolean;
    set activeStateEnabled(value: boolean);
    /**
     * [descr:dxTreeViewOptions.animationEnabled]
    
     */
    get animationEnabled(): boolean;
    set animationEnabled(value: boolean);
    /**
     * [descr:dxTreeViewOptions.collapseIcon]
    
     */
    get collapseIcon(): null | string;
    set collapseIcon(value: null | string);
    /**
     * [descr:dxTreeViewOptions.createChildren]
    
     */
    get createChildren(): ((parentNode: dxTreeViewNode) => any | Array<Record<string, any>>);
    set createChildren(value: ((parentNode: dxTreeViewNode) => any | Array<Record<string, any>>));
    /**
     * [descr:dxTreeViewOptions.dataSource]
    
     */
    get dataSource(): Array<dxTreeViewItem> | DataSource | DataSourceOptions | null | Store | string;
    set dataSource(value: Array<dxTreeViewItem> | DataSource | DataSourceOptions | null | Store | string);
    /**
     * [descr:dxTreeViewOptions.dataStructure]
    
     */
    get dataStructure(): DataStructure;
    set dataStructure(value: DataStructure);
    /**
     * [descr:WidgetOptions.disabled]
    
     */
    get disabled(): boolean;
    set disabled(value: boolean);
    /**
     * [descr:HierarchicalCollectionWidgetOptions.disabledExpr]
    
     */
    get disabledExpr(): ((item: any) => boolean | undefined) | string;
    set disabledExpr(value: ((item: any) => boolean | undefined) | string);
    /**
     * [descr:dxTreeViewOptions.disabledNodeSelectionMode]
    
     */
    get disabledNodeSelectionMode(): DisabledNodeSelectionMode;
    set disabledNodeSelectionMode(value: DisabledNodeSelectionMode);
    /**
     * [descr:HierarchicalCollectionWidgetOptions.displayExpr]
    
     */
    get displayExpr(): ((item: any) => string) | string;
    set displayExpr(value: ((item: any) => string) | string);
    /**
     * [descr:DOMComponentOptions.elementAttr]
    
     */
    get elementAttr(): Record<string, any>;
    set elementAttr(value: Record<string, any>);
    /**
     * [descr:dxTreeViewOptions.expandAllEnabled]
    
     */
    get expandAllEnabled(): boolean;
    set expandAllEnabled(value: boolean);
    /**
     * [descr:dxTreeViewOptions.expandedExpr]
    
     */
    get expandedExpr(): ((item: any, value: boolean | undefined) => boolean | undefined) | string;
    set expandedExpr(value: ((item: any, value: boolean | undefined) => boolean | undefined) | string);
    /**
     * [descr:dxTreeViewOptions.expandEvent]
    
     */
    get expandEvent(): TreeViewExpandEvent;
    set expandEvent(value: TreeViewExpandEvent);
    /**
     * [descr:dxTreeViewOptions.expandIcon]
    
     */
    get expandIcon(): null | string;
    set expandIcon(value: null | string);
    /**
     * [descr:dxTreeViewOptions.expandNodesRecursive]
    
     */
    get expandNodesRecursive(): boolean;
    set expandNodesRecursive(value: boolean);
    /**
     * [descr:HierarchicalCollectionWidgetOptions.focusStateEnabled]
    
     */
    get focusStateEnabled(): boolean;
    set focusStateEnabled(value: boolean);
    /**
     * [descr:dxTreeViewOptions.hasItemsExpr]
    
     */
    get hasItemsExpr(): ((item: any) => boolean | undefined) | string;
    set hasItemsExpr(value: ((item: any) => boolean | undefined) | string);
    /**
     * [descr:DOMComponentOptions.height]
    
     */
    get height(): number | string | undefined;
    set height(value: number | string | undefined);
    /**
     * [descr:WidgetOptions.hint]
    
     */
    get hint(): string | undefined;
    set hint(value: string | undefined);
    /**
     * [descr:HierarchicalCollectionWidgetOptions.hoverStateEnabled]
    
     */
    get hoverStateEnabled(): boolean;
    set hoverStateEnabled(value: boolean);
    /**
     * [descr:CollectionWidgetOptions.itemHoldTimeout]
    
     */
    get itemHoldTimeout(): number;
    set itemHoldTimeout(value: number);
    /**
     * [descr:dxTreeViewOptions.items]
    
     */
    get items(): Array<any | dxTreeViewItem>;
    set items(value: Array<any | dxTreeViewItem>);
    /**
     * [descr:HierarchicalCollectionWidgetOptions.itemsExpr]
    
     */
    get itemsExpr(): ((item: any) => Array<any> | undefined) | string;
    set itemsExpr(value: ((item: any) => Array<any> | undefined) | string);
    /**
     * [descr:CollectionWidgetOptions.itemTemplate]
    
     */
    get itemTemplate(): any;
    set itemTemplate(value: any);
    /**
     * [descr:HierarchicalCollectionWidgetOptions.keyExpr]
    
     */
    get keyExpr(): ((item: any) => any) | string;
    set keyExpr(value: ((item: any) => any) | string);
    /**
     * [descr:CollectionWidgetOptions.noDataText]
    
     */
    get noDataText(): string;
    set noDataText(value: string);
    /**
     * [descr:dxTreeViewOptions.parentIdExpr]
    
     */
    get parentIdExpr(): ((item: any) => any | undefined) | string;
    set parentIdExpr(value: ((item: any) => any | undefined) | string);
    /**
     * [descr:dxTreeViewOptions.rootValue]
    
     */
    get rootValue(): any;
    set rootValue(value: any);
    /**
     * [descr:DOMComponentOptions.rtlEnabled]
    
     */
    get rtlEnabled(): boolean;
    set rtlEnabled(value: boolean);
    /**
     * [descr:dxTreeViewOptions.scrollDirection]
    
     */
    get scrollDirection(): ScrollDirection;
    set scrollDirection(value: ScrollDirection);
    /**
     * [descr:SearchBoxMixinOptions.searchEditorOptions]
    
     */
    get searchEditorOptions(): dxTextBoxOptions<any>;
    set searchEditorOptions(value: dxTextBoxOptions<any>);
    /**
     * [descr:SearchBoxMixinOptions.searchEnabled]
    
     */
    get searchEnabled(): boolean;
    set searchEnabled(value: boolean);
    /**
     * [descr:SearchBoxMixinOptions.searchExpr]
    
     */
    get searchExpr(): Array<Function | string> | Function | string;
    set searchExpr(value: Array<Function | string> | Function | string);
    /**
     * [descr:SearchBoxMixinOptions.searchMode]
    
     */
    get searchMode(): SearchMode;
    set searchMode(value: SearchMode);
    /**
     * [descr:SearchBoxMixinOptions.searchTimeout]
    
     */
    get searchTimeout(): number | undefined;
    set searchTimeout(value: number | undefined);
    /**
     * [descr:SearchBoxMixinOptions.searchValue]
    
     */
    get searchValue(): string;
    set searchValue(value: string);
    /**
     * [descr:dxTreeViewOptions.selectAllText]
    
     */
    get selectAllText(): string;
    set selectAllText(value: string);
    /**
     * [descr:dxTreeViewOptions.selectByClick]
    
     */
    get selectByClick(): boolean;
    set selectByClick(value: boolean);
    /**
     * [descr:HierarchicalCollectionWidgetOptions.selectedExpr]
    
     */
    get selectedExpr(): ((item: any, value: boolean | undefined) => boolean | undefined) | string;
    set selectedExpr(value: ((item: any, value: boolean | undefined) => boolean | undefined) | string);
    /**
     * [descr:dxTreeViewOptions.selectionMode]
    
     */
    get selectionMode(): SingleOrMultiple;
    set selectionMode(value: SingleOrMultiple);
    /**
     * [descr:dxTreeViewOptions.selectNodesRecursive]
    
     */
    get selectNodesRecursive(): boolean;
    set selectNodesRecursive(value: boolean);
    /**
     * [descr:dxTreeViewOptions.showCheckBoxesMode]
    
     */
    get showCheckBoxesMode(): TreeViewCheckBoxMode;
    set showCheckBoxesMode(value: TreeViewCheckBoxMode);
    /**
     * [descr:WidgetOptions.tabIndex]
    
     */
    get tabIndex(): number;
    set tabIndex(value: number);
    /**
     * [descr:dxTreeViewOptions.useNativeScrolling]
    
     */
    get useNativeScrolling(): boolean;
    set useNativeScrolling(value: boolean);
    /**
     * [descr:dxTreeViewOptions.virtualModeEnabled]
    
     */
    get virtualModeEnabled(): boolean;
    set virtualModeEnabled(value: boolean);
    /**
     * [descr:WidgetOptions.visible]
    
     */
    get visible(): boolean;
    set visible(value: boolean);
    /**
     * [descr:DOMComponentOptions.width]
    
     */
    get width(): number | string | undefined;
    set width(value: number | string | undefined);
    /**
    
     * [descr:dxTreeViewOptions.onContentReady]
    
    
     */
    onContentReady: EventEmitter<ContentReadyEvent>;
    /**
    
     * [descr:dxTreeViewOptions.onDisposing]
    
    
     */
    onDisposing: EventEmitter<DisposingEvent>;
    /**
    
     * [descr:dxTreeViewOptions.onInitialized]
    
    
     */
    onInitialized: EventEmitter<InitializedEvent>;
    /**
    
     * [descr:dxTreeViewOptions.onItemClick]
    
    
     */
    onItemClick: EventEmitter<ItemClickEvent>;
    /**
    
     * [descr:dxTreeViewOptions.onItemCollapsed]
    
    
     */
    onItemCollapsed: EventEmitter<ItemCollapsedEvent>;
    /**
    
     * [descr:dxTreeViewOptions.onItemContextMenu]
    
    
     */
    onItemContextMenu: EventEmitter<ItemContextMenuEvent>;
    /**
    
     * [descr:dxTreeViewOptions.onItemExpanded]
    
    
     */
    onItemExpanded: EventEmitter<ItemExpandedEvent>;
    /**
    
     * [descr:dxTreeViewOptions.onItemHold]
    
    
     */
    onItemHold: EventEmitter<ItemHoldEvent>;
    /**
    
     * [descr:dxTreeViewOptions.onItemRendered]
    
    
     */
    onItemRendered: EventEmitter<ItemRenderedEvent>;
    /**
    
     * [descr:dxTreeViewOptions.onItemSelectionChanged]
    
    
     */
    onItemSelectionChanged: EventEmitter<ItemSelectionChangedEvent>;
    /**
    
     * [descr:dxTreeViewOptions.onOptionChanged]
    
    
     */
    onOptionChanged: EventEmitter<OptionChangedEvent>;
    /**
    
     * [descr:dxTreeViewOptions.onSelectAllValueChanged]
    
    
     */
    onSelectAllValueChanged: EventEmitter<SelectAllValueChangedEvent>;
    /**
    
     * [descr:dxTreeViewOptions.onSelectionChanged]
    
    
     */
    onSelectionChanged: EventEmitter<SelectionChangedEvent>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    accessKeyChange: EventEmitter<string | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    activeStateEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    animationEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    collapseIconChange: EventEmitter<null | string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    createChildrenChange: EventEmitter<((parentNode: dxTreeViewNode) => any | Array<Record<string, any>>)>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    dataSourceChange: EventEmitter<Array<dxTreeViewItem> | DataSource | DataSourceOptions | null | Store | string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    dataStructureChange: EventEmitter<DataStructure>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    disabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    disabledExprChange: EventEmitter<((item: any) => boolean | undefined) | string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    disabledNodeSelectionModeChange: EventEmitter<DisabledNodeSelectionMode>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    displayExprChange: EventEmitter<((item: any) => string) | string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    elementAttrChange: EventEmitter<Record<string, any>>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    expandAllEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    expandedExprChange: EventEmitter<((item: any, value: boolean | undefined) => boolean | undefined) | string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    expandEventChange: EventEmitter<TreeViewExpandEvent>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    expandIconChange: EventEmitter<null | string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    expandNodesRecursiveChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    focusStateEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    hasItemsExprChange: EventEmitter<((item: any) => boolean | undefined) | string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    heightChange: EventEmitter<number | string | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    hintChange: EventEmitter<string | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    hoverStateEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    itemHoldTimeoutChange: EventEmitter<number>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    itemsChange: EventEmitter<Array<any | dxTreeViewItem>>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    itemsExprChange: EventEmitter<((item: any) => Array<any> | undefined) | string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    itemTemplateChange: EventEmitter<any>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    keyExprChange: EventEmitter<((item: any) => any) | string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    noDataTextChange: EventEmitter<string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    parentIdExprChange: EventEmitter<((item: any) => any | undefined) | string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    rootValueChange: EventEmitter<any>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    rtlEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    scrollDirectionChange: EventEmitter<ScrollDirection>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    searchEditorOptionsChange: EventEmitter<dxTextBoxOptions<any>>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    searchEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    searchExprChange: EventEmitter<Array<Function | string> | Function | string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    searchModeChange: EventEmitter<SearchMode>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    searchTimeoutChange: EventEmitter<number | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    searchValueChange: EventEmitter<string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    selectAllTextChange: EventEmitter<string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    selectByClickChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    selectedExprChange: EventEmitter<((item: any, value: boolean | undefined) => boolean | undefined) | string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    selectionModeChange: EventEmitter<SingleOrMultiple>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    selectNodesRecursiveChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    showCheckBoxesModeChange: EventEmitter<TreeViewCheckBoxMode>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    tabIndexChange: EventEmitter<number>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    useNativeScrollingChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    virtualModeEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    visibleChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    widthChange: EventEmitter<number | string | undefined>;
    constructor(elementRef: ElementRef, ngZone: NgZone, templateHost: DxTemplateHost, _watcherHelper: WatcherHelper, _idh: IterableDifferHelper, optionHost: NestedOptionHost, transferState: TransferState, platformId: any);
    protected _createInstance(element: any, options: any): DxTreeView<any, any>;
    ngOnDestroy(): void;
    ngOnChanges(changes: SimpleChanges): void;
    setupChanges(prop: string, changes: SimpleChanges): void;
    ngDoCheck(): void;
    _setOption(name: string, value: any): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxTreeViewComponent<any, any>, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxTreeViewComponent<any, any>, "dx-tree-view", never, { "accessKey": { "alias": "accessKey"; "required": false; }; "activeStateEnabled": { "alias": "activeStateEnabled"; "required": false; }; "animationEnabled": { "alias": "animationEnabled"; "required": false; }; "collapseIcon": { "alias": "collapseIcon"; "required": false; }; "createChildren": { "alias": "createChildren"; "required": false; }; "dataSource": { "alias": "dataSource"; "required": false; }; "dataStructure": { "alias": "dataStructure"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "disabledExpr": { "alias": "disabledExpr"; "required": false; }; "disabledNodeSelectionMode": { "alias": "disabledNodeSelectionMode"; "required": false; }; "displayExpr": { "alias": "displayExpr"; "required": false; }; "elementAttr": { "alias": "elementAttr"; "required": false; }; "expandAllEnabled": { "alias": "expandAllEnabled"; "required": false; }; "expandedExpr": { "alias": "expandedExpr"; "required": false; }; "expandEvent": { "alias": "expandEvent"; "required": false; }; "expandIcon": { "alias": "expandIcon"; "required": false; }; "expandNodesRecursive": { "alias": "expandNodesRecursive"; "required": false; }; "focusStateEnabled": { "alias": "focusStateEnabled"; "required": false; }; "hasItemsExpr": { "alias": "hasItemsExpr"; "required": false; }; "height": { "alias": "height"; "required": false; }; "hint": { "alias": "hint"; "required": false; }; "hoverStateEnabled": { "alias": "hoverStateEnabled"; "required": false; }; "itemHoldTimeout": { "alias": "itemHoldTimeout"; "required": false; }; "items": { "alias": "items"; "required": false; }; "itemsExpr": { "alias": "itemsExpr"; "required": false; }; "itemTemplate": { "alias": "itemTemplate"; "required": false; }; "keyExpr": { "alias": "keyExpr"; "required": false; }; "noDataText": { "alias": "noDataText"; "required": false; }; "parentIdExpr": { "alias": "parentIdExpr"; "required": false; }; "rootValue": { "alias": "rootValue"; "required": false; }; "rtlEnabled": { "alias": "rtlEnabled"; "required": false; }; "scrollDirection": { "alias": "scrollDirection"; "required": false; }; "searchEditorOptions": { "alias": "searchEditorOptions"; "required": false; }; "searchEnabled": { "alias": "searchEnabled"; "required": false; }; "searchExpr": { "alias": "searchExpr"; "required": false; }; "searchMode": { "alias": "searchMode"; "required": false; }; "searchTimeout": { "alias": "searchTimeout"; "required": false; }; "searchValue": { "alias": "searchValue"; "required": false; }; "selectAllText": { "alias": "selectAllText"; "required": false; }; "selectByClick": { "alias": "selectByClick"; "required": false; }; "selectedExpr": { "alias": "selectedExpr"; "required": false; }; "selectionMode": { "alias": "selectionMode"; "required": false; }; "selectNodesRecursive": { "alias": "selectNodesRecursive"; "required": false; }; "showCheckBoxesMode": { "alias": "showCheckBoxesMode"; "required": false; }; "tabIndex": { "alias": "tabIndex"; "required": false; }; "useNativeScrolling": { "alias": "useNativeScrolling"; "required": false; }; "virtualModeEnabled": { "alias": "virtualModeEnabled"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, { "onContentReady": "onContentReady"; "onDisposing": "onDisposing"; "onInitialized": "onInitialized"; "onItemClick": "onItemClick"; "onItemCollapsed": "onItemCollapsed"; "onItemContextMenu": "onItemContextMenu"; "onItemExpanded": "onItemExpanded"; "onItemHold": "onItemHold"; "onItemRendered": "onItemRendered"; "onItemSelectionChanged": "onItemSelectionChanged"; "onOptionChanged": "onOptionChanged"; "onSelectAllValueChanged": "onSelectAllValueChanged"; "onSelectionChanged": "onSelectionChanged"; "accessKeyChange": "accessKeyChange"; "activeStateEnabledChange": "activeStateEnabledChange"; "animationEnabledChange": "animationEnabledChange"; "collapseIconChange": "collapseIconChange"; "createChildrenChange": "createChildrenChange"; "dataSourceChange": "dataSourceChange"; "dataStructureChange": "dataStructureChange"; "disabledChange": "disabledChange"; "disabledExprChange": "disabledExprChange"; "disabledNodeSelectionModeChange": "disabledNodeSelectionModeChange"; "displayExprChange": "displayExprChange"; "elementAttrChange": "elementAttrChange"; "expandAllEnabledChange": "expandAllEnabledChange"; "expandedExprChange": "expandedExprChange"; "expandEventChange": "expandEventChange"; "expandIconChange": "expandIconChange"; "expandNodesRecursiveChange": "expandNodesRecursiveChange"; "focusStateEnabledChange": "focusStateEnabledChange"; "hasItemsExprChange": "hasItemsExprChange"; "heightChange": "heightChange"; "hintChange": "hintChange"; "hoverStateEnabledChange": "hoverStateEnabledChange"; "itemHoldTimeoutChange": "itemHoldTimeoutChange"; "itemsChange": "itemsChange"; "itemsExprChange": "itemsExprChange"; "itemTemplateChange": "itemTemplateChange"; "keyExprChange": "keyExprChange"; "noDataTextChange": "noDataTextChange"; "parentIdExprChange": "parentIdExprChange"; "rootValueChange": "rootValueChange"; "rtlEnabledChange": "rtlEnabledChange"; "scrollDirectionChange": "scrollDirectionChange"; "searchEditorOptionsChange": "searchEditorOptionsChange"; "searchEnabledChange": "searchEnabledChange"; "searchExprChange": "searchExprChange"; "searchModeChange": "searchModeChange"; "searchTimeoutChange": "searchTimeoutChange"; "searchValueChange": "searchValueChange"; "selectAllTextChange": "selectAllTextChange"; "selectByClickChange": "selectByClickChange"; "selectedExprChange": "selectedExprChange"; "selectionModeChange": "selectionModeChange"; "selectNodesRecursiveChange": "selectNodesRecursiveChange"; "showCheckBoxesModeChange": "showCheckBoxesModeChange"; "tabIndexChange": "tabIndexChange"; "useNativeScrollingChange": "useNativeScrollingChange"; "virtualModeEnabledChange": "virtualModeEnabledChange"; "visibleChange": "visibleChange"; "widthChange": "widthChange"; }, ["_buttonsContentChildren", "_itemsContentChildren"], never, true, never>;
}
declare class DxTreeViewModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxTreeViewModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxTreeViewModule, never, [typeof DxTreeViewComponent, typeof i1.DxiItemModule, typeof i1.DxoSearchEditorOptionsModule, typeof i1.DxiButtonModule, typeof i1.DxoOptionsModule, typeof i2.DxiTreeViewButtonModule, typeof i2.DxiTreeViewItemModule, typeof i2.DxoTreeViewOptionsModule, typeof i2.DxoTreeViewSearchEditorOptionsModule, typeof i3.DxIntegrationModule, typeof i3.DxTemplateModule], [typeof DxTreeViewComponent, typeof i1.DxiItemModule, typeof i1.DxoSearchEditorOptionsModule, typeof i1.DxiButtonModule, typeof i1.DxoOptionsModule, typeof i2.DxiTreeViewButtonModule, typeof i2.DxiTreeViewItemModule, typeof i2.DxoTreeViewOptionsModule, typeof i2.DxoTreeViewSearchEditorOptionsModule, typeof i3.DxTemplateModule]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxTreeViewModule>;
}

export { DxTreeViewComponent, DxTreeViewModule };
//# sourceMappingURL=index.d.ts.map
