import * as i0 from '@angular/core';
import { OnDestroy, OnChanges, DoCheck, QueryList, EventEmitter, ElementRef, NgZone, TransferState, SimpleChanges } from '@angular/core';
import DxMap, { MapProvider, RouteMode, MapType, ClickEvent, DisposingEvent, InitializedEvent, MarkerAddedEvent, MarkerRemovedEvent, OptionChangedEvent, ReadyEvent, RouteAddedEvent, RouteRemovedEvent } from 'devextreme/ui/map';
import * as i3 from 'devextreme-angular/core';
import { DxComponent, CollectionNestedOption, DxTemplateHost, WatcherHelper, IterableDifferHelper, NestedOptionHost } from 'devextreme-angular/core';
import * as i1 from 'devextreme-angular/ui/nested';
import * as i2 from 'devextreme-angular/ui/map/nested';
export * from 'devextreme-angular/ui/map/nested';
import * as map_types from 'devextreme/ui/map_types';
export { map_types as DxMapTypes };

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

/**
 * [descr:dxMap]

 */
declare class DxMapComponent extends DxComponent implements OnDestroy, OnChanges, DoCheck {
    private _watcherHelper;
    private _idh;
    set _markersContentChildren(value: QueryList<CollectionNestedOption>);
    set _routesContentChildren(value: QueryList<CollectionNestedOption>);
    set _locationsContentChildren(value: QueryList<CollectionNestedOption>);
    set _centerContentChildren(value: QueryList<CollectionNestedOption>);
    instance: DxMap;
    /**
     * [descr:WidgetOptions.accessKey]
    
     */
    get accessKey(): string | undefined;
    set accessKey(value: string | undefined);
    /**
     * [descr:WidgetOptions.activeStateEnabled]
    
     */
    get activeStateEnabled(): boolean;
    set activeStateEnabled(value: boolean);
    /**
     * [descr:dxMapOptions.apiKey]
    
     */
    get apiKey(): string | {
        azure?: string;
        bing?: string;
        google?: string;
        googleStatic?: string;
    };
    set apiKey(value: string | {
        azure?: string;
        bing?: string;
        google?: string;
        googleStatic?: string;
    });
    /**
     * [descr:dxMapOptions.autoAdjust]
    
     */
    get autoAdjust(): boolean;
    set autoAdjust(value: boolean);
    /**
     * [descr:dxMapOptions.center]
    
     */
    get center(): Array<number> | string | {
        lat?: number;
        lng?: number;
    }[];
    set center(value: Array<number> | string | {
        lat?: number;
        lng?: number;
    }[]);
    /**
     * [descr:dxMapOptions.controls]
    
     */
    get controls(): boolean;
    set controls(value: boolean);
    /**
     * [descr:WidgetOptions.disabled]
    
     */
    get disabled(): boolean;
    set disabled(value: boolean);
    /**
     * [descr:DOMComponentOptions.elementAttr]
    
     */
    get elementAttr(): Record<string, any>;
    set elementAttr(value: Record<string, any>);
    /**
     * [descr:dxMapOptions.focusStateEnabled]
    
     */
    get focusStateEnabled(): boolean;
    set focusStateEnabled(value: boolean);
    /**
     * [descr:dxMapOptions.height]
    
     */
    get height(): number | string;
    set height(value: number | string);
    /**
     * [descr:WidgetOptions.hint]
    
     */
    get hint(): string | undefined;
    set hint(value: string | undefined);
    /**
     * [descr:WidgetOptions.hoverStateEnabled]
    
     */
    get hoverStateEnabled(): boolean;
    set hoverStateEnabled(value: boolean);
    /**
     * [descr:dxMapOptions.markerIconSrc]
    
     */
    get markerIconSrc(): string;
    set markerIconSrc(value: string);
    /**
     * [descr:dxMapOptions.markers]
    
     */
    get markers(): {
        iconSrc?: string;
        location?: Array<number> | string | {
            lat?: number;
            lng?: number;
        }[];
        onClick?: Function;
        tooltip?: string | {
            isShown?: boolean;
            text?: string;
        };
    }[];
    set markers(value: {
        iconSrc?: string;
        location?: Array<number> | string | {
            lat?: number;
            lng?: number;
        }[];
        onClick?: Function;
        tooltip?: string | {
            isShown?: boolean;
            text?: string;
        };
    }[]);
    /**
     * [descr:dxMapOptions.provider]
    
     */
    get provider(): MapProvider;
    set provider(value: MapProvider);
    /**
     * [descr:dxMapOptions.providerConfig]
    
     */
    get providerConfig(): {
        mapId?: string;
        useAdvancedMarkers?: boolean;
    };
    set providerConfig(value: {
        mapId?: string;
        useAdvancedMarkers?: boolean;
    });
    /**
     * [descr:dxMapOptions.routes]
    
     */
    get routes(): {
        color?: string;
        locations?: {
            lat?: number;
            lng?: number;
        }[];
        mode?: RouteMode | string;
        opacity?: number;
        weight?: number;
    }[];
    set routes(value: {
        color?: string;
        locations?: {
            lat?: number;
            lng?: number;
        }[];
        mode?: RouteMode | string;
        opacity?: number;
        weight?: number;
    }[]);
    /**
     * [descr:DOMComponentOptions.rtlEnabled]
    
     */
    get rtlEnabled(): boolean;
    set rtlEnabled(value: boolean);
    /**
     * [descr:WidgetOptions.tabIndex]
    
     */
    get tabIndex(): number;
    set tabIndex(value: number);
    /**
     * [descr:dxMapOptions.type]
    
     */
    get type(): MapType;
    set type(value: MapType);
    /**
     * [descr:WidgetOptions.visible]
    
     */
    get visible(): boolean;
    set visible(value: boolean);
    /**
     * [descr:dxMapOptions.width]
    
     */
    get width(): number | string;
    set width(value: number | string);
    /**
     * [descr:dxMapOptions.zoom]
    
     */
    get zoom(): number;
    set zoom(value: number);
    /**
    
     * [descr:dxMapOptions.onClick]
    
    
     */
    onClick: EventEmitter<ClickEvent>;
    /**
    
     * [descr:dxMapOptions.onDisposing]
    
    
     */
    onDisposing: EventEmitter<DisposingEvent>;
    /**
    
     * [descr:dxMapOptions.onInitialized]
    
    
     */
    onInitialized: EventEmitter<InitializedEvent>;
    /**
    
     * [descr:dxMapOptions.onMarkerAdded]
    
    
     */
    onMarkerAdded: EventEmitter<MarkerAddedEvent>;
    /**
    
     * [descr:dxMapOptions.onMarkerRemoved]
    
    
     */
    onMarkerRemoved: EventEmitter<MarkerRemovedEvent>;
    /**
    
     * [descr:dxMapOptions.onOptionChanged]
    
    
     */
    onOptionChanged: EventEmitter<OptionChangedEvent>;
    /**
    
     * [descr:dxMapOptions.onReady]
    
    
     */
    onReady: EventEmitter<ReadyEvent>;
    /**
    
     * [descr:dxMapOptions.onRouteAdded]
    
    
     */
    onRouteAdded: EventEmitter<RouteAddedEvent>;
    /**
    
     * [descr:dxMapOptions.onRouteRemoved]
    
    
     */
    onRouteRemoved: EventEmitter<RouteRemovedEvent>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    accessKeyChange: EventEmitter<string | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    activeStateEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    apiKeyChange: EventEmitter<string | {
        azure?: string;
        bing?: string;
        google?: string;
        googleStatic?: string;
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    autoAdjustChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    centerChange: EventEmitter<Array<number> | string | {
        lat?: number;
        lng?: number;
    }[]>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    controlsChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    disabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    elementAttrChange: EventEmitter<Record<string, any>>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    focusStateEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    heightChange: EventEmitter<number | string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    hintChange: EventEmitter<string | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    hoverStateEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    markerIconSrcChange: EventEmitter<string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    markersChange: EventEmitter<{
        iconSrc?: string;
        location?: Array<number> | string | {
            lat?: number;
            lng?: number;
        }[];
        onClick?: Function;
        tooltip?: string | {
            isShown?: boolean;
            text?: string;
        };
    }[]>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    providerChange: EventEmitter<MapProvider>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    providerConfigChange: EventEmitter<{
        mapId?: string;
        useAdvancedMarkers?: boolean;
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    routesChange: EventEmitter<{
        color?: string;
        locations?: {
            lat?: number;
            lng?: number;
        }[];
        mode?: RouteMode | string;
        opacity?: number;
        weight?: number;
    }[]>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    rtlEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    tabIndexChange: EventEmitter<number>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    typeChange: EventEmitter<MapType>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    visibleChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    widthChange: EventEmitter<number | string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    zoomChange: EventEmitter<number>;
    constructor(elementRef: ElementRef, ngZone: NgZone, templateHost: DxTemplateHost, _watcherHelper: WatcherHelper, _idh: IterableDifferHelper, optionHost: NestedOptionHost, transferState: TransferState, platformId: any);
    protected _createInstance(element: any, options: any): DxMap;
    ngOnDestroy(): void;
    ngOnChanges(changes: SimpleChanges): void;
    setupChanges(prop: string, changes: SimpleChanges): void;
    ngDoCheck(): void;
    _setOption(name: string, value: any): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxMapComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxMapComponent, "dx-map", never, { "accessKey": { "alias": "accessKey"; "required": false; }; "activeStateEnabled": { "alias": "activeStateEnabled"; "required": false; }; "apiKey": { "alias": "apiKey"; "required": false; }; "autoAdjust": { "alias": "autoAdjust"; "required": false; }; "center": { "alias": "center"; "required": false; }; "controls": { "alias": "controls"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "elementAttr": { "alias": "elementAttr"; "required": false; }; "focusStateEnabled": { "alias": "focusStateEnabled"; "required": false; }; "height": { "alias": "height"; "required": false; }; "hint": { "alias": "hint"; "required": false; }; "hoverStateEnabled": { "alias": "hoverStateEnabled"; "required": false; }; "markerIconSrc": { "alias": "markerIconSrc"; "required": false; }; "markers": { "alias": "markers"; "required": false; }; "provider": { "alias": "provider"; "required": false; }; "providerConfig": { "alias": "providerConfig"; "required": false; }; "routes": { "alias": "routes"; "required": false; }; "rtlEnabled": { "alias": "rtlEnabled"; "required": false; }; "tabIndex": { "alias": "tabIndex"; "required": false; }; "type": { "alias": "type"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; "zoom": { "alias": "zoom"; "required": false; }; }, { "onClick": "onClick"; "onDisposing": "onDisposing"; "onInitialized": "onInitialized"; "onMarkerAdded": "onMarkerAdded"; "onMarkerRemoved": "onMarkerRemoved"; "onOptionChanged": "onOptionChanged"; "onReady": "onReady"; "onRouteAdded": "onRouteAdded"; "onRouteRemoved": "onRouteRemoved"; "accessKeyChange": "accessKeyChange"; "activeStateEnabledChange": "activeStateEnabledChange"; "apiKeyChange": "apiKeyChange"; "autoAdjustChange": "autoAdjustChange"; "centerChange": "centerChange"; "controlsChange": "controlsChange"; "disabledChange": "disabledChange"; "elementAttrChange": "elementAttrChange"; "focusStateEnabledChange": "focusStateEnabledChange"; "heightChange": "heightChange"; "hintChange": "hintChange"; "hoverStateEnabledChange": "hoverStateEnabledChange"; "markerIconSrcChange": "markerIconSrcChange"; "markersChange": "markersChange"; "providerChange": "providerChange"; "providerConfigChange": "providerConfigChange"; "routesChange": "routesChange"; "rtlEnabledChange": "rtlEnabledChange"; "tabIndexChange": "tabIndexChange"; "typeChange": "typeChange"; "visibleChange": "visibleChange"; "widthChange": "widthChange"; "zoomChange": "zoomChange"; }, ["_markersContentChildren", "_routesContentChildren", "_locationsContentChildren", "_centerContentChildren"], never, true, never>;
}
declare class DxMapModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxMapModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxMapModule, never, [typeof DxMapComponent, typeof i1.DxoApiKeyModule, typeof i1.DxiCenterModule, typeof i1.DxiMarkerModule, typeof i1.DxiLocationModule, typeof i1.DxoTooltipModule, typeof i1.DxoProviderConfigModule, typeof i1.DxiRouteModule, typeof i2.DxoMapApiKeyModule, typeof i2.DxoMapCenterModule, typeof i2.DxoMapLocationModule, typeof i2.DxiMapMarkerModule, typeof i2.DxoMapProviderConfigModule, typeof i2.DxiMapRouteModule, typeof i2.DxoMapTooltipModule, typeof i2.DxiMapLocationModule, typeof i3.DxIntegrationModule, typeof i3.DxTemplateModule], [typeof DxMapComponent, typeof i1.DxoApiKeyModule, typeof i1.DxiCenterModule, typeof i1.DxiMarkerModule, typeof i1.DxiLocationModule, typeof i1.DxoTooltipModule, typeof i1.DxoProviderConfigModule, typeof i1.DxiRouteModule, typeof i2.DxoMapApiKeyModule, typeof i2.DxoMapCenterModule, typeof i2.DxoMapLocationModule, typeof i2.DxiMapMarkerModule, typeof i2.DxoMapProviderConfigModule, typeof i2.DxiMapRouteModule, typeof i2.DxoMapTooltipModule, typeof i2.DxiMapLocationModule, typeof i3.DxTemplateModule]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxMapModule>;
}

export { DxMapComponent, DxMapModule };
//# sourceMappingURL=index.d.ts.map
