import * as i0 from '@angular/core';
import { OnDestroy, OnInit, QueryList } from '@angular/core';
import { NestedOption, NestedOptionHost, CollectionNestedOption } from 'devextreme-angular/core';
import { RouteMode } from 'devextreme/ui/map';

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoMapApiKeyComponent extends NestedOption implements OnDestroy, OnInit {
    get azure(): string;
    set azure(value: string);
    get bing(): string;
    set bing(value: string);
    get google(): string;
    set google(value: string);
    get googleStatic(): string;
    set googleStatic(value: string);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoMapApiKeyComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoMapApiKeyComponent, "dxo-map-api-key", never, { "azure": { "alias": "azure"; "required": false; }; "bing": { "alias": "bing"; "required": false; }; "google": { "alias": "google"; "required": false; }; "googleStatic": { "alias": "googleStatic"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoMapApiKeyModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoMapApiKeyModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoMapApiKeyModule, never, [typeof DxoMapApiKeyComponent], [typeof DxoMapApiKeyComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoMapApiKeyModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoMapCenterComponent extends NestedOption implements OnDestroy, OnInit {
    get lat(): number;
    set lat(value: number);
    get lng(): number;
    set lng(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoMapCenterComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoMapCenterComponent, "dxo-map-center", never, { "lat": { "alias": "lat"; "required": false; }; "lng": { "alias": "lng"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoMapCenterModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoMapCenterModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoMapCenterModule, never, [typeof DxoMapCenterComponent], [typeof DxoMapCenterComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoMapCenterModule>;
}

declare class DxiMapLocationComponent extends CollectionNestedOption {
    get lat(): number;
    set lat(value: number);
    get lng(): number;
    set lng(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiMapLocationComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiMapLocationComponent, "dxi-map-location", never, { "lat": { "alias": "lat"; "required": false; }; "lng": { "alias": "lng"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxiMapLocationModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiMapLocationModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiMapLocationModule, never, [typeof DxiMapLocationComponent], [typeof DxiMapLocationComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiMapLocationModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoMapLocationComponent extends NestedOption implements OnDestroy, OnInit {
    get lat(): number;
    set lat(value: number);
    get lng(): number;
    set lng(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoMapLocationComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoMapLocationComponent, "dxo-map-location", never, { "lat": { "alias": "lat"; "required": false; }; "lng": { "alias": "lng"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoMapLocationModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoMapLocationModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoMapLocationModule, never, [typeof DxoMapLocationComponent], [typeof DxoMapLocationComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoMapLocationModule>;
}

declare class DxiMapMarkerComponent extends CollectionNestedOption {
    get iconSrc(): string;
    set iconSrc(value: string);
    get location(): Array<number> | string | {
        lat?: number;
        lng?: number;
    }[];
    set location(value: Array<number> | string | {
        lat?: number;
        lng?: number;
    }[]);
    get onClick(): Function;
    set onClick(value: Function);
    get tooltip(): string | {
        isShown?: boolean;
        text?: string;
    };
    set tooltip(value: string | {
        isShown?: boolean;
        text?: string;
    });
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiMapMarkerComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiMapMarkerComponent, "dxi-map-marker", never, { "iconSrc": { "alias": "iconSrc"; "required": false; }; "location": { "alias": "location"; "required": false; }; "onClick": { "alias": "onClick"; "required": false; }; "tooltip": { "alias": "tooltip"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxiMapMarkerModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiMapMarkerModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiMapMarkerModule, never, [typeof DxiMapMarkerComponent], [typeof DxiMapMarkerComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiMapMarkerModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoMapProviderConfigComponent extends NestedOption implements OnDestroy, OnInit {
    get mapId(): string;
    set mapId(value: string);
    get useAdvancedMarkers(): boolean;
    set useAdvancedMarkers(value: boolean);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoMapProviderConfigComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoMapProviderConfigComponent, "dxo-map-provider-config", never, { "mapId": { "alias": "mapId"; "required": false; }; "useAdvancedMarkers": { "alias": "useAdvancedMarkers"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoMapProviderConfigModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoMapProviderConfigModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoMapProviderConfigModule, never, [typeof DxoMapProviderConfigComponent], [typeof DxoMapProviderConfigComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoMapProviderConfigModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxiMapRouteComponent extends CollectionNestedOption {
    set _locationsContentChildren(value: QueryList<CollectionNestedOption>);
    get color(): string;
    set color(value: string);
    get locations(): {
        lat?: number;
        lng?: number;
    }[];
    set locations(value: {
        lat?: number;
        lng?: number;
    }[]);
    get mode(): RouteMode | string;
    set mode(value: RouteMode | string);
    get opacity(): number;
    set opacity(value: number);
    get weight(): number;
    set weight(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiMapRouteComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiMapRouteComponent, "dxi-map-route", never, { "color": { "alias": "color"; "required": false; }; "locations": { "alias": "locations"; "required": false; }; "mode": { "alias": "mode"; "required": false; }; "opacity": { "alias": "opacity"; "required": false; }; "weight": { "alias": "weight"; "required": false; }; }, {}, ["_locationsContentChildren"], never, true, never>;
}
declare class DxiMapRouteModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiMapRouteModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiMapRouteModule, never, [typeof DxiMapRouteComponent], [typeof DxiMapRouteComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiMapRouteModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoMapTooltipComponent extends NestedOption implements OnDestroy, OnInit {
    get isShown(): boolean;
    set isShown(value: boolean);
    get text(): string;
    set text(value: string);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoMapTooltipComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoMapTooltipComponent, "dxo-map-tooltip", never, { "isShown": { "alias": "isShown"; "required": false; }; "text": { "alias": "text"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoMapTooltipModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoMapTooltipModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoMapTooltipModule, never, [typeof DxoMapTooltipComponent], [typeof DxoMapTooltipComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoMapTooltipModule>;
}

export { DxiMapLocationComponent, DxiMapLocationModule, DxiMapMarkerComponent, DxiMapMarkerModule, DxiMapRouteComponent, DxiMapRouteModule, DxoMapApiKeyComponent, DxoMapApiKeyModule, DxoMapCenterComponent, DxoMapCenterModule, DxoMapLocationComponent, DxoMapLocationModule, DxoMapProviderConfigComponent, DxoMapProviderConfigModule, DxoMapTooltipComponent, DxoMapTooltipModule };
//# sourceMappingURL=index.d.ts.map
