import * as i0 from '@angular/core';
import { OnDestroy, OnChanges, DoCheck, QueryList, EventEmitter, ElementRef, NgZone, TransferState, SimpleChanges } from '@angular/core';
import DxDropDownButton, { dxDropDownButtonItem, ButtonClickEvent, ContentReadyEvent, DisposingEvent, InitializedEvent, ItemClickEvent, OptionChangedEvent, SelectionChangedEvent } from 'devextreme/ui/drop_down_button';
import DataSource, { DataSourceOptions } from 'devextreme/data/data_source';
import { Store } from 'devextreme/data/store';
import { dxPopupOptions } from 'devextreme/ui/popup';
import { ButtonStyle, ButtonType } from 'devextreme/common';
import * as i3 from 'devextreme-angular/core';
import { DxComponent, CollectionNestedOption, DxTemplateHost, WatcherHelper, IterableDifferHelper, NestedOptionHost } from 'devextreme-angular/core';
import * as i1 from 'devextreme-angular/ui/nested';
import * as i2 from 'devextreme-angular/ui/drop-down-button/nested';
export * from 'devextreme-angular/ui/drop-down-button/nested';
import * as drop_down_button_types from 'devextreme/ui/drop_down_button_types';
export { drop_down_button_types as DxDropDownButtonTypes };

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

/**
 * [descr:dxDropDownButton]

 */
declare class DxDropDownButtonComponent extends DxComponent implements OnDestroy, OnChanges, DoCheck {
    private _watcherHelper;
    private _idh;
    set _itemsContentChildren(value: QueryList<CollectionNestedOption>);
    set _toolbarItemsContentChildren(value: QueryList<CollectionNestedOption>);
    instance: DxDropDownButton;
    /**
     * [descr:WidgetOptions.accessKey]
    
     */
    get accessKey(): string | undefined;
    set accessKey(value: string | undefined);
    /**
     * [descr:WidgetOptions.activeStateEnabled]
    
     */
    get activeStateEnabled(): boolean;
    set activeStateEnabled(value: boolean);
    /**
     * [descr:dxDropDownButtonOptions.dataSource]
    
     */
    get dataSource(): Array<any | dxDropDownButtonItem> | DataSource | DataSourceOptions | null | Store | string;
    set dataSource(value: Array<any | dxDropDownButtonItem> | DataSource | DataSourceOptions | null | Store | string);
    /**
     * [descr:dxDropDownButtonOptions.deferRendering]
    
     */
    get deferRendering(): boolean;
    set deferRendering(value: boolean);
    /**
     * [descr:WidgetOptions.disabled]
    
     */
    get disabled(): boolean;
    set disabled(value: boolean);
    /**
     * [descr:dxDropDownButtonOptions.displayExpr]
    
     */
    get displayExpr(): ((itemData: any) => string) | string | undefined;
    set displayExpr(value: ((itemData: any) => string) | string | undefined);
    /**
     * [descr:dxDropDownButtonOptions.dropDownContentTemplate]
    
     */
    get dropDownContentTemplate(): any;
    set dropDownContentTemplate(value: any);
    /**
     * [descr:dxDropDownButtonOptions.dropDownOptions]
    
     */
    get dropDownOptions(): dxPopupOptions<any>;
    set dropDownOptions(value: dxPopupOptions<any>);
    /**
     * [descr:DOMComponentOptions.elementAttr]
    
     */
    get elementAttr(): Record<string, any>;
    set elementAttr(value: Record<string, any>);
    /**
     * [descr:dxDropDownButtonOptions.focusStateEnabled]
    
     */
    get focusStateEnabled(): boolean;
    set focusStateEnabled(value: boolean);
    /**
     * [descr:DOMComponentOptions.height]
    
     */
    get height(): number | string | undefined;
    set height(value: number | string | undefined);
    /**
     * [descr:WidgetOptions.hint]
    
     */
    get hint(): string | undefined;
    set hint(value: string | undefined);
    /**
     * [descr:dxDropDownButtonOptions.hoverStateEnabled]
    
     */
    get hoverStateEnabled(): boolean;
    set hoverStateEnabled(value: boolean);
    /**
     * [descr:dxDropDownButtonOptions.icon]
    
     */
    get icon(): string | undefined;
    set icon(value: string | undefined);
    /**
     * [descr:dxDropDownButtonOptions.items]
    
     */
    get items(): Array<any | dxDropDownButtonItem> | null;
    set items(value: Array<any | dxDropDownButtonItem> | null);
    /**
     * [descr:dxDropDownButtonOptions.itemTemplate]
    
     */
    get itemTemplate(): any;
    set itemTemplate(value: any);
    /**
     * [descr:dxDropDownButtonOptions.keyExpr]
    
     */
    get keyExpr(): string;
    set keyExpr(value: string);
    /**
     * [descr:dxDropDownButtonOptions.noDataText]
    
     */
    get noDataText(): string;
    set noDataText(value: string);
    /**
     * [descr:dxDropDownButtonOptions.opened]
    
     */
    get opened(): boolean;
    set opened(value: boolean);
    /**
     * [descr:DOMComponentOptions.rtlEnabled]
    
     */
    get rtlEnabled(): boolean;
    set rtlEnabled(value: boolean);
    /**
     * [descr:dxDropDownButtonOptions.selectedItem]
    
     */
    get selectedItem(): any | null | number | string;
    set selectedItem(value: any | null | number | string);
    /**
     * [descr:dxDropDownButtonOptions.selectedItemKey]
    
     */
    get selectedItemKey(): null | number | string;
    set selectedItemKey(value: null | number | string);
    /**
     * [descr:dxDropDownButtonOptions.showArrowIcon]
    
     */
    get showArrowIcon(): boolean;
    set showArrowIcon(value: boolean);
    /**
     * [descr:dxDropDownButtonOptions.splitButton]
    
     */
    get splitButton(): boolean;
    set splitButton(value: boolean);
    /**
     * [descr:dxDropDownButtonOptions.stylingMode]
    
     */
    get stylingMode(): ButtonStyle;
    set stylingMode(value: ButtonStyle);
    /**
     * [descr:WidgetOptions.tabIndex]
    
     */
    get tabIndex(): number;
    set tabIndex(value: number);
    /**
     * [descr:dxDropDownButtonOptions.template]
    
     */
    get template(): any;
    set template(value: any);
    /**
     * [descr:dxDropDownButtonOptions.text]
    
     */
    get text(): string;
    set text(value: string);
    /**
     * [descr:dxDropDownButtonOptions.type]
    
     */
    get type(): ButtonType | string;
    set type(value: ButtonType | string);
    /**
     * [descr:dxDropDownButtonOptions.useItemTextAsTitle]
    
     */
    get useItemTextAsTitle(): boolean;
    set useItemTextAsTitle(value: boolean);
    /**
     * [descr:dxDropDownButtonOptions.useSelectMode]
    
     */
    get useSelectMode(): boolean;
    set useSelectMode(value: boolean);
    /**
     * [descr:WidgetOptions.visible]
    
     */
    get visible(): boolean;
    set visible(value: boolean);
    /**
     * [descr:DOMComponentOptions.width]
    
     */
    get width(): number | string | undefined;
    set width(value: number | string | undefined);
    /**
     * [descr:dxDropDownButtonOptions.wrapItemText]
    
     */
    get wrapItemText(): boolean;
    set wrapItemText(value: boolean);
    /**
    
     * [descr:dxDropDownButtonOptions.onButtonClick]
    
    
     */
    onButtonClick: EventEmitter<ButtonClickEvent>;
    /**
    
     * [descr:dxDropDownButtonOptions.onContentReady]
    
    
     */
    onContentReady: EventEmitter<ContentReadyEvent>;
    /**
    
     * [descr:dxDropDownButtonOptions.onDisposing]
    
    
     */
    onDisposing: EventEmitter<DisposingEvent>;
    /**
    
     * [descr:dxDropDownButtonOptions.onInitialized]
    
    
     */
    onInitialized: EventEmitter<InitializedEvent>;
    /**
    
     * [descr:dxDropDownButtonOptions.onItemClick]
    
    
     */
    onItemClick: EventEmitter<ItemClickEvent>;
    /**
    
     * [descr:dxDropDownButtonOptions.onOptionChanged]
    
    
     */
    onOptionChanged: EventEmitter<OptionChangedEvent>;
    /**
    
     * [descr:dxDropDownButtonOptions.onSelectionChanged]
    
    
     */
    onSelectionChanged: EventEmitter<SelectionChangedEvent>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    accessKeyChange: EventEmitter<string | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    activeStateEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    dataSourceChange: EventEmitter<Array<any | dxDropDownButtonItem> | DataSource | DataSourceOptions | null | Store | string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    deferRenderingChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    disabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    displayExprChange: EventEmitter<((itemData: any) => string) | string | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    dropDownContentTemplateChange: EventEmitter<any>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    dropDownOptionsChange: EventEmitter<dxPopupOptions<any>>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    elementAttrChange: EventEmitter<Record<string, any>>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    focusStateEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    heightChange: EventEmitter<number | string | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    hintChange: EventEmitter<string | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    hoverStateEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    iconChange: EventEmitter<string | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    itemsChange: EventEmitter<Array<any | dxDropDownButtonItem> | null>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    itemTemplateChange: EventEmitter<any>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    keyExprChange: EventEmitter<string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    noDataTextChange: EventEmitter<string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    openedChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    rtlEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    selectedItemChange: EventEmitter<any | null | number | string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    selectedItemKeyChange: EventEmitter<null | number | string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    showArrowIconChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    splitButtonChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    stylingModeChange: EventEmitter<ButtonStyle>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    tabIndexChange: EventEmitter<number>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    templateChange: EventEmitter<any>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    textChange: EventEmitter<string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    typeChange: EventEmitter<ButtonType | string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    useItemTextAsTitleChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    useSelectModeChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    visibleChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    widthChange: EventEmitter<number | string | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    wrapItemTextChange: EventEmitter<boolean>;
    constructor(elementRef: ElementRef, ngZone: NgZone, templateHost: DxTemplateHost, _watcherHelper: WatcherHelper, _idh: IterableDifferHelper, optionHost: NestedOptionHost, transferState: TransferState, platformId: any);
    protected _createInstance(element: any, options: any): DxDropDownButton;
    ngOnDestroy(): void;
    ngOnChanges(changes: SimpleChanges): void;
    setupChanges(prop: string, changes: SimpleChanges): void;
    ngDoCheck(): void;
    _setOption(name: string, value: any): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxDropDownButtonComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxDropDownButtonComponent, "dx-drop-down-button", never, { "accessKey": { "alias": "accessKey"; "required": false; }; "activeStateEnabled": { "alias": "activeStateEnabled"; "required": false; }; "dataSource": { "alias": "dataSource"; "required": false; }; "deferRendering": { "alias": "deferRendering"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "displayExpr": { "alias": "displayExpr"; "required": false; }; "dropDownContentTemplate": { "alias": "dropDownContentTemplate"; "required": false; }; "dropDownOptions": { "alias": "dropDownOptions"; "required": false; }; "elementAttr": { "alias": "elementAttr"; "required": false; }; "focusStateEnabled": { "alias": "focusStateEnabled"; "required": false; }; "height": { "alias": "height"; "required": false; }; "hint": { "alias": "hint"; "required": false; }; "hoverStateEnabled": { "alias": "hoverStateEnabled"; "required": false; }; "icon": { "alias": "icon"; "required": false; }; "items": { "alias": "items"; "required": false; }; "itemTemplate": { "alias": "itemTemplate"; "required": false; }; "keyExpr": { "alias": "keyExpr"; "required": false; }; "noDataText": { "alias": "noDataText"; "required": false; }; "opened": { "alias": "opened"; "required": false; }; "rtlEnabled": { "alias": "rtlEnabled"; "required": false; }; "selectedItem": { "alias": "selectedItem"; "required": false; }; "selectedItemKey": { "alias": "selectedItemKey"; "required": false; }; "showArrowIcon": { "alias": "showArrowIcon"; "required": false; }; "splitButton": { "alias": "splitButton"; "required": false; }; "stylingMode": { "alias": "stylingMode"; "required": false; }; "tabIndex": { "alias": "tabIndex"; "required": false; }; "template": { "alias": "template"; "required": false; }; "text": { "alias": "text"; "required": false; }; "type": { "alias": "type"; "required": false; }; "useItemTextAsTitle": { "alias": "useItemTextAsTitle"; "required": false; }; "useSelectMode": { "alias": "useSelectMode"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; "wrapItemText": { "alias": "wrapItemText"; "required": false; }; }, { "onButtonClick": "onButtonClick"; "onContentReady": "onContentReady"; "onDisposing": "onDisposing"; "onInitialized": "onInitialized"; "onItemClick": "onItemClick"; "onOptionChanged": "onOptionChanged"; "onSelectionChanged": "onSelectionChanged"; "accessKeyChange": "accessKeyChange"; "activeStateEnabledChange": "activeStateEnabledChange"; "dataSourceChange": "dataSourceChange"; "deferRenderingChange": "deferRenderingChange"; "disabledChange": "disabledChange"; "displayExprChange": "displayExprChange"; "dropDownContentTemplateChange": "dropDownContentTemplateChange"; "dropDownOptionsChange": "dropDownOptionsChange"; "elementAttrChange": "elementAttrChange"; "focusStateEnabledChange": "focusStateEnabledChange"; "heightChange": "heightChange"; "hintChange": "hintChange"; "hoverStateEnabledChange": "hoverStateEnabledChange"; "iconChange": "iconChange"; "itemsChange": "itemsChange"; "itemTemplateChange": "itemTemplateChange"; "keyExprChange": "keyExprChange"; "noDataTextChange": "noDataTextChange"; "openedChange": "openedChange"; "rtlEnabledChange": "rtlEnabledChange"; "selectedItemChange": "selectedItemChange"; "selectedItemKeyChange": "selectedItemKeyChange"; "showArrowIconChange": "showArrowIconChange"; "splitButtonChange": "splitButtonChange"; "stylingModeChange": "stylingModeChange"; "tabIndexChange": "tabIndexChange"; "templateChange": "templateChange"; "textChange": "textChange"; "typeChange": "typeChange"; "useItemTextAsTitleChange": "useItemTextAsTitleChange"; "useSelectModeChange": "useSelectModeChange"; "visibleChange": "visibleChange"; "widthChange": "widthChange"; "wrapItemTextChange": "wrapItemTextChange"; }, ["_itemsContentChildren", "_toolbarItemsContentChildren"], never, true, never>;
}
declare class DxDropDownButtonModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxDropDownButtonModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxDropDownButtonModule, never, [typeof DxDropDownButtonComponent, typeof i1.DxoDropDownOptionsModule, typeof i1.DxoAnimationModule, typeof i1.DxoHideModule, typeof i1.DxoFromModule, typeof i1.DxoPositionModule, typeof i1.DxoAtModule, typeof i1.DxoBoundaryOffsetModule, typeof i1.DxoCollisionModule, typeof i1.DxoMyModule, typeof i1.DxoOffsetModule, typeof i1.DxoToModule, typeof i1.DxoShowModule, typeof i1.DxiItemModule, typeof i2.DxoDropDownButtonAnimationModule, typeof i2.DxoDropDownButtonAtModule, typeof i2.DxoDropDownButtonBoundaryOffsetModule, typeof i2.DxoDropDownButtonCollisionModule, typeof i2.DxoDropDownButtonDropDownOptionsModule, typeof i2.DxoDropDownButtonFromModule, typeof i2.DxoDropDownButtonHideModule, typeof i2.DxiDropDownButtonItemModule, typeof i2.DxoDropDownButtonMyModule, typeof i2.DxoDropDownButtonOffsetModule, typeof i2.DxoDropDownButtonPositionModule, typeof i2.DxoDropDownButtonShowModule, typeof i2.DxoDropDownButtonToModule, typeof i2.DxiDropDownButtonToolbarItemModule, typeof i3.DxIntegrationModule, typeof i3.DxTemplateModule], [typeof DxDropDownButtonComponent, typeof i1.DxoDropDownOptionsModule, typeof i1.DxoAnimationModule, typeof i1.DxoHideModule, typeof i1.DxoFromModule, typeof i1.DxoPositionModule, typeof i1.DxoAtModule, typeof i1.DxoBoundaryOffsetModule, typeof i1.DxoCollisionModule, typeof i1.DxoMyModule, typeof i1.DxoOffsetModule, typeof i1.DxoToModule, typeof i1.DxoShowModule, typeof i1.DxiItemModule, typeof i2.DxoDropDownButtonAnimationModule, typeof i2.DxoDropDownButtonAtModule, typeof i2.DxoDropDownButtonBoundaryOffsetModule, typeof i2.DxoDropDownButtonCollisionModule, typeof i2.DxoDropDownButtonDropDownOptionsModule, typeof i2.DxoDropDownButtonFromModule, typeof i2.DxoDropDownButtonHideModule, typeof i2.DxiDropDownButtonItemModule, typeof i2.DxoDropDownButtonMyModule, typeof i2.DxoDropDownButtonOffsetModule, typeof i2.DxoDropDownButtonPositionModule, typeof i2.DxoDropDownButtonShowModule, typeof i2.DxoDropDownButtonToModule, typeof i2.DxiDropDownButtonToolbarItemModule, typeof i3.DxTemplateModule]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxDropDownButtonModule>;
}

export { DxDropDownButtonComponent, DxDropDownButtonModule };
//# sourceMappingURL=index.d.ts.map
