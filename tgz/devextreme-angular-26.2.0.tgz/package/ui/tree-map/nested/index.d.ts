import * as i0 from '@angular/core';
import { OnDestroy, OnInit, EventEmitter } from '@angular/core';
import { DashStyle, Palette, PaletteExtensionMode, Font, TextOverflow, WordWrap } from 'devextreme/common/charts';
import { NestedOption, NestedOptionHost } from 'devextreme-angular/core';
import { TreeMapColorizerType, dxTreeMapNode } from 'devextreme/viz/tree_map';
import { ExportFormat, Format, HorizontalAlignment, VerticalEdge } from 'devextreme/common';
import { Format as Format$1 } from 'devextreme/common/core/localization';

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoTreeMapBorderComponent extends NestedOption implements OnDestroy, OnInit {
    get color(): string | undefined;
    set color(value: string | undefined);
    get width(): number | undefined;
    set width(value: number | undefined);
    get dashStyle(): DashStyle;
    set dashStyle(value: DashStyle);
    get opacity(): number | undefined;
    set opacity(value: number | undefined);
    get visible(): boolean;
    set visible(value: boolean);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTreeMapBorderComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoTreeMapBorderComponent, "dxo-tree-map-border", never, { "color": { "alias": "color"; "required": false; }; "width": { "alias": "width"; "required": false; }; "dashStyle": { "alias": "dashStyle"; "required": false; }; "opacity": { "alias": "opacity"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoTreeMapBorderModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTreeMapBorderModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoTreeMapBorderModule, never, [typeof DxoTreeMapBorderComponent], [typeof DxoTreeMapBorderComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoTreeMapBorderModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoTreeMapColorizerComponent extends NestedOption implements OnDestroy, OnInit {
    get colorCodeField(): string | undefined;
    set colorCodeField(value: string | undefined);
    get colorizeGroups(): boolean;
    set colorizeGroups(value: boolean);
    get palette(): Array<string> | Palette;
    set palette(value: Array<string> | Palette);
    get paletteExtensionMode(): PaletteExtensionMode;
    set paletteExtensionMode(value: PaletteExtensionMode);
    get range(): Array<number> | undefined;
    set range(value: Array<number> | undefined);
    get type(): TreeMapColorizerType | undefined;
    set type(value: TreeMapColorizerType | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTreeMapColorizerComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoTreeMapColorizerComponent, "dxo-tree-map-colorizer", never, { "colorCodeField": { "alias": "colorCodeField"; "required": false; }; "colorizeGroups": { "alias": "colorizeGroups"; "required": false; }; "palette": { "alias": "palette"; "required": false; }; "paletteExtensionMode": { "alias": "paletteExtensionMode"; "required": false; }; "range": { "alias": "range"; "required": false; }; "type": { "alias": "type"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoTreeMapColorizerModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTreeMapColorizerModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoTreeMapColorizerModule, never, [typeof DxoTreeMapColorizerComponent], [typeof DxoTreeMapColorizerComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoTreeMapColorizerModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoTreeMapExportComponent extends NestedOption implements OnDestroy, OnInit {
    get backgroundColor(): string;
    set backgroundColor(value: string);
    get enabled(): boolean;
    set enabled(value: boolean);
    get fileName(): string;
    set fileName(value: string);
    get formats(): Array<ExportFormat>;
    set formats(value: Array<ExportFormat>);
    get margin(): number;
    set margin(value: number);
    get printingEnabled(): boolean;
    set printingEnabled(value: boolean);
    get svgToCanvas(): ((svg: any, canvas: any) => any) | undefined;
    set svgToCanvas(value: ((svg: any, canvas: any) => any) | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTreeMapExportComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoTreeMapExportComponent, "dxo-tree-map-export", never, { "backgroundColor": { "alias": "backgroundColor"; "required": false; }; "enabled": { "alias": "enabled"; "required": false; }; "fileName": { "alias": "fileName"; "required": false; }; "formats": { "alias": "formats"; "required": false; }; "margin": { "alias": "margin"; "required": false; }; "printingEnabled": { "alias": "printingEnabled"; "required": false; }; "svgToCanvas": { "alias": "svgToCanvas"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoTreeMapExportModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTreeMapExportModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoTreeMapExportModule, never, [typeof DxoTreeMapExportComponent], [typeof DxoTreeMapExportComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoTreeMapExportModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoTreeMapFontComponent extends NestedOption implements OnDestroy, OnInit {
    get color(): string;
    set color(value: string);
    get family(): string;
    set family(value: string);
    get opacity(): number;
    set opacity(value: number);
    get size(): number | string;
    set size(value: number | string);
    get weight(): number;
    set weight(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTreeMapFontComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoTreeMapFontComponent, "dxo-tree-map-font", never, { "color": { "alias": "color"; "required": false; }; "family": { "alias": "family"; "required": false; }; "opacity": { "alias": "opacity"; "required": false; }; "size": { "alias": "size"; "required": false; }; "weight": { "alias": "weight"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoTreeMapFontModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTreeMapFontModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoTreeMapFontModule, never, [typeof DxoTreeMapFontComponent], [typeof DxoTreeMapFontComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoTreeMapFontModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoTreeMapFormatComponent extends NestedOption implements OnDestroy, OnInit {
    get currency(): string;
    set currency(value: string);
    get formatter(): ((value: number | Date) => string);
    set formatter(value: ((value: number | Date) => string));
    get parser(): ((value: string) => number | Date);
    set parser(value: ((value: string) => number | Date));
    get precision(): number;
    set precision(value: number);
    get type(): Format | string;
    set type(value: Format | string);
    get useCurrencyAccountingStyle(): boolean;
    set useCurrencyAccountingStyle(value: boolean);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTreeMapFormatComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoTreeMapFormatComponent, "dxo-tree-map-format", never, { "currency": { "alias": "currency"; "required": false; }; "formatter": { "alias": "formatter"; "required": false; }; "parser": { "alias": "parser"; "required": false; }; "precision": { "alias": "precision"; "required": false; }; "type": { "alias": "type"; "required": false; }; "useCurrencyAccountingStyle": { "alias": "useCurrencyAccountingStyle"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoTreeMapFormatModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTreeMapFormatModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoTreeMapFormatModule, never, [typeof DxoTreeMapFormatComponent], [typeof DxoTreeMapFormatComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoTreeMapFormatModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoTreeMapGroupLabelComponent extends NestedOption implements OnDestroy, OnInit {
    get font(): Font;
    set font(value: Font);
    get textOverflow(): TextOverflow;
    set textOverflow(value: TextOverflow);
    get visible(): boolean;
    set visible(value: boolean);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTreeMapGroupLabelComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoTreeMapGroupLabelComponent, "dxo-tree-map-group-label", never, { "font": { "alias": "font"; "required": false; }; "textOverflow": { "alias": "textOverflow"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoTreeMapGroupLabelModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTreeMapGroupLabelModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoTreeMapGroupLabelModule, never, [typeof DxoTreeMapGroupLabelComponent], [typeof DxoTreeMapGroupLabelComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoTreeMapGroupLabelModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoTreeMapGroupComponent extends NestedOption implements OnDestroy, OnInit {
    get border(): {
        color?: string | undefined;
        width?: number | undefined;
    };
    set border(value: {
        color?: string | undefined;
        width?: number | undefined;
    });
    get color(): string;
    set color(value: string);
    get headerHeight(): number | undefined;
    set headerHeight(value: number | undefined);
    get hoverEnabled(): boolean | undefined;
    set hoverEnabled(value: boolean | undefined);
    get hoverStyle(): {
        border?: {
            color?: string | undefined;
            width?: number | undefined;
        };
        color?: string | undefined;
    };
    set hoverStyle(value: {
        border?: {
            color?: string | undefined;
            width?: number | undefined;
        };
        color?: string | undefined;
    });
    get label(): {
        font?: Font;
        textOverflow?: TextOverflow;
        visible?: boolean;
    };
    set label(value: {
        font?: Font;
        textOverflow?: TextOverflow;
        visible?: boolean;
    });
    get padding(): number;
    set padding(value: number);
    get selectionStyle(): {
        border?: {
            color?: string | undefined;
            width?: number | undefined;
        };
        color?: string | undefined;
    };
    set selectionStyle(value: {
        border?: {
            color?: string | undefined;
            width?: number | undefined;
        };
        color?: string | undefined;
    });
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTreeMapGroupComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoTreeMapGroupComponent, "dxo-tree-map-group", never, { "border": { "alias": "border"; "required": false; }; "color": { "alias": "color"; "required": false; }; "headerHeight": { "alias": "headerHeight"; "required": false; }; "hoverEnabled": { "alias": "hoverEnabled"; "required": false; }; "hoverStyle": { "alias": "hoverStyle"; "required": false; }; "label": { "alias": "label"; "required": false; }; "padding": { "alias": "padding"; "required": false; }; "selectionStyle": { "alias": "selectionStyle"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoTreeMapGroupModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTreeMapGroupModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoTreeMapGroupModule, never, [typeof DxoTreeMapGroupComponent], [typeof DxoTreeMapGroupComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoTreeMapGroupModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoTreeMapHoverStyleComponent extends NestedOption implements OnDestroy, OnInit {
    get border(): {
        color?: string | undefined;
        width?: number | undefined;
    };
    set border(value: {
        color?: string | undefined;
        width?: number | undefined;
    });
    get color(): string | undefined;
    set color(value: string | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTreeMapHoverStyleComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoTreeMapHoverStyleComponent, "dxo-tree-map-hover-style", never, { "border": { "alias": "border"; "required": false; }; "color": { "alias": "color"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoTreeMapHoverStyleModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTreeMapHoverStyleModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoTreeMapHoverStyleModule, never, [typeof DxoTreeMapHoverStyleComponent], [typeof DxoTreeMapHoverStyleComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoTreeMapHoverStyleModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoTreeMapLabelComponent extends NestedOption implements OnDestroy, OnInit {
    get font(): Font;
    set font(value: Font);
    get textOverflow(): TextOverflow;
    set textOverflow(value: TextOverflow);
    get visible(): boolean;
    set visible(value: boolean);
    get wordWrap(): WordWrap;
    set wordWrap(value: WordWrap);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTreeMapLabelComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoTreeMapLabelComponent, "dxo-tree-map-label", never, { "font": { "alias": "font"; "required": false; }; "textOverflow": { "alias": "textOverflow"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "wordWrap": { "alias": "wordWrap"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoTreeMapLabelModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTreeMapLabelModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoTreeMapLabelModule, never, [typeof DxoTreeMapLabelComponent], [typeof DxoTreeMapLabelComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoTreeMapLabelModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoTreeMapLoadingIndicatorComponent extends NestedOption implements OnDestroy, OnInit {
    get backgroundColor(): string;
    set backgroundColor(value: string);
    get enabled(): boolean;
    set enabled(value: boolean);
    get font(): Font;
    set font(value: Font);
    get show(): boolean;
    set show(value: boolean);
    get text(): string;
    set text(value: string);
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    showChange: EventEmitter<boolean>;
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTreeMapLoadingIndicatorComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoTreeMapLoadingIndicatorComponent, "dxo-tree-map-loading-indicator", never, { "backgroundColor": { "alias": "backgroundColor"; "required": false; }; "enabled": { "alias": "enabled"; "required": false; }; "font": { "alias": "font"; "required": false; }; "show": { "alias": "show"; "required": false; }; "text": { "alias": "text"; "required": false; }; }, { "showChange": "showChange"; }, never, never, true, never>;
}
declare class DxoTreeMapLoadingIndicatorModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTreeMapLoadingIndicatorModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoTreeMapLoadingIndicatorModule, never, [typeof DxoTreeMapLoadingIndicatorComponent], [typeof DxoTreeMapLoadingIndicatorComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoTreeMapLoadingIndicatorModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoTreeMapMarginComponent extends NestedOption implements OnDestroy, OnInit {
    get bottom(): number;
    set bottom(value: number);
    get left(): number;
    set left(value: number);
    get right(): number;
    set right(value: number);
    get top(): number;
    set top(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTreeMapMarginComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoTreeMapMarginComponent, "dxo-tree-map-margin", never, { "bottom": { "alias": "bottom"; "required": false; }; "left": { "alias": "left"; "required": false; }; "right": { "alias": "right"; "required": false; }; "top": { "alias": "top"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoTreeMapMarginModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTreeMapMarginModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoTreeMapMarginModule, never, [typeof DxoTreeMapMarginComponent], [typeof DxoTreeMapMarginComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoTreeMapMarginModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoTreeMapSelectionStyleComponent extends NestedOption implements OnDestroy, OnInit {
    get border(): {
        color?: string | undefined;
        width?: number | undefined;
    };
    set border(value: {
        color?: string | undefined;
        width?: number | undefined;
    });
    get color(): string | undefined;
    set color(value: string | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTreeMapSelectionStyleComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoTreeMapSelectionStyleComponent, "dxo-tree-map-selection-style", never, { "border": { "alias": "border"; "required": false; }; "color": { "alias": "color"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoTreeMapSelectionStyleModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTreeMapSelectionStyleModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoTreeMapSelectionStyleModule, never, [typeof DxoTreeMapSelectionStyleComponent], [typeof DxoTreeMapSelectionStyleComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoTreeMapSelectionStyleModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoTreeMapShadowComponent extends NestedOption implements OnDestroy, OnInit {
    get blur(): number;
    set blur(value: number);
    get color(): string;
    set color(value: string);
    get offsetX(): number;
    set offsetX(value: number);
    get offsetY(): number;
    set offsetY(value: number);
    get opacity(): number;
    set opacity(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTreeMapShadowComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoTreeMapShadowComponent, "dxo-tree-map-shadow", never, { "blur": { "alias": "blur"; "required": false; }; "color": { "alias": "color"; "required": false; }; "offsetX": { "alias": "offsetX"; "required": false; }; "offsetY": { "alias": "offsetY"; "required": false; }; "opacity": { "alias": "opacity"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoTreeMapShadowModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTreeMapShadowModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoTreeMapShadowModule, never, [typeof DxoTreeMapShadowComponent], [typeof DxoTreeMapShadowComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoTreeMapShadowModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoTreeMapSizeComponent extends NestedOption implements OnDestroy, OnInit {
    get height(): number | undefined;
    set height(value: number | undefined);
    get width(): number | undefined;
    set width(value: number | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTreeMapSizeComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoTreeMapSizeComponent, "dxo-tree-map-size", never, { "height": { "alias": "height"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoTreeMapSizeModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTreeMapSizeModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoTreeMapSizeModule, never, [typeof DxoTreeMapSizeComponent], [typeof DxoTreeMapSizeComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoTreeMapSizeModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoTreeMapSubtitleComponent extends NestedOption implements OnDestroy, OnInit {
    get font(): Font;
    set font(value: Font);
    get offset(): number;
    set offset(value: number);
    get text(): string | undefined;
    set text(value: string | undefined);
    get textOverflow(): TextOverflow;
    set textOverflow(value: TextOverflow);
    get wordWrap(): WordWrap;
    set wordWrap(value: WordWrap);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTreeMapSubtitleComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoTreeMapSubtitleComponent, "dxo-tree-map-subtitle", never, { "font": { "alias": "font"; "required": false; }; "offset": { "alias": "offset"; "required": false; }; "text": { "alias": "text"; "required": false; }; "textOverflow": { "alias": "textOverflow"; "required": false; }; "wordWrap": { "alias": "wordWrap"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoTreeMapSubtitleModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTreeMapSubtitleModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoTreeMapSubtitleModule, never, [typeof DxoTreeMapSubtitleComponent], [typeof DxoTreeMapSubtitleComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoTreeMapSubtitleModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoTreeMapTileLabelComponent extends NestedOption implements OnDestroy, OnInit {
    get font(): Font;
    set font(value: Font);
    get textOverflow(): TextOverflow;
    set textOverflow(value: TextOverflow);
    get visible(): boolean;
    set visible(value: boolean);
    get wordWrap(): WordWrap;
    set wordWrap(value: WordWrap);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTreeMapTileLabelComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoTreeMapTileLabelComponent, "dxo-tree-map-tile-label", never, { "font": { "alias": "font"; "required": false; }; "textOverflow": { "alias": "textOverflow"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "wordWrap": { "alias": "wordWrap"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoTreeMapTileLabelModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTreeMapTileLabelModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoTreeMapTileLabelModule, never, [typeof DxoTreeMapTileLabelComponent], [typeof DxoTreeMapTileLabelComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoTreeMapTileLabelModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoTreeMapTileComponent extends NestedOption implements OnDestroy, OnInit {
    get border(): {
        color?: string | undefined;
        width?: number | undefined;
    };
    set border(value: {
        color?: string | undefined;
        width?: number | undefined;
    });
    get color(): string;
    set color(value: string);
    get hoverStyle(): {
        border?: {
            color?: string | undefined;
            width?: number | undefined;
        };
        color?: string | undefined;
    };
    set hoverStyle(value: {
        border?: {
            color?: string | undefined;
            width?: number | undefined;
        };
        color?: string | undefined;
    });
    get label(): {
        font?: Font;
        textOverflow?: TextOverflow;
        visible?: boolean;
        wordWrap?: WordWrap;
    };
    set label(value: {
        font?: Font;
        textOverflow?: TextOverflow;
        visible?: boolean;
        wordWrap?: WordWrap;
    });
    get selectionStyle(): {
        border?: {
            color?: string | undefined;
            width?: number | undefined;
        };
        color?: string | undefined;
    };
    set selectionStyle(value: {
        border?: {
            color?: string | undefined;
            width?: number | undefined;
        };
        color?: string | undefined;
    });
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTreeMapTileComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoTreeMapTileComponent, "dxo-tree-map-tile", never, { "border": { "alias": "border"; "required": false; }; "color": { "alias": "color"; "required": false; }; "hoverStyle": { "alias": "hoverStyle"; "required": false; }; "label": { "alias": "label"; "required": false; }; "selectionStyle": { "alias": "selectionStyle"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoTreeMapTileModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTreeMapTileModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoTreeMapTileModule, never, [typeof DxoTreeMapTileComponent], [typeof DxoTreeMapTileComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoTreeMapTileModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoTreeMapTitleComponent extends NestedOption implements OnDestroy, OnInit {
    get font(): Font;
    set font(value: Font);
    get horizontalAlignment(): HorizontalAlignment;
    set horizontalAlignment(value: HorizontalAlignment);
    get margin(): number | {
        bottom?: number;
        left?: number;
        right?: number;
        top?: number;
    };
    set margin(value: number | {
        bottom?: number;
        left?: number;
        right?: number;
        top?: number;
    });
    get placeholderSize(): number | undefined;
    set placeholderSize(value: number | undefined);
    get subtitle(): string | {
        font?: Font;
        offset?: number;
        text?: string | undefined;
        textOverflow?: TextOverflow;
        wordWrap?: WordWrap;
    };
    set subtitle(value: string | {
        font?: Font;
        offset?: number;
        text?: string | undefined;
        textOverflow?: TextOverflow;
        wordWrap?: WordWrap;
    });
    get text(): string | undefined;
    set text(value: string | undefined);
    get textOverflow(): TextOverflow;
    set textOverflow(value: TextOverflow);
    get verticalAlignment(): VerticalEdge;
    set verticalAlignment(value: VerticalEdge);
    get wordWrap(): WordWrap;
    set wordWrap(value: WordWrap);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTreeMapTitleComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoTreeMapTitleComponent, "dxo-tree-map-title", never, { "font": { "alias": "font"; "required": false; }; "horizontalAlignment": { "alias": "horizontalAlignment"; "required": false; }; "margin": { "alias": "margin"; "required": false; }; "placeholderSize": { "alias": "placeholderSize"; "required": false; }; "subtitle": { "alias": "subtitle"; "required": false; }; "text": { "alias": "text"; "required": false; }; "textOverflow": { "alias": "textOverflow"; "required": false; }; "verticalAlignment": { "alias": "verticalAlignment"; "required": false; }; "wordWrap": { "alias": "wordWrap"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoTreeMapTitleModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTreeMapTitleModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoTreeMapTitleModule, never, [typeof DxoTreeMapTitleComponent], [typeof DxoTreeMapTitleComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoTreeMapTitleModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoTreeMapTooltipBorderComponent extends NestedOption implements OnDestroy, OnInit {
    get color(): string;
    set color(value: string);
    get dashStyle(): DashStyle;
    set dashStyle(value: DashStyle);
    get opacity(): number | undefined;
    set opacity(value: number | undefined);
    get visible(): boolean;
    set visible(value: boolean);
    get width(): number;
    set width(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTreeMapTooltipBorderComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoTreeMapTooltipBorderComponent, "dxo-tree-map-tooltip-border", never, { "color": { "alias": "color"; "required": false; }; "dashStyle": { "alias": "dashStyle"; "required": false; }; "opacity": { "alias": "opacity"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoTreeMapTooltipBorderModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTreeMapTooltipBorderModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoTreeMapTooltipBorderModule, never, [typeof DxoTreeMapTooltipBorderComponent], [typeof DxoTreeMapTooltipBorderComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoTreeMapTooltipBorderModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoTreeMapTooltipComponent extends NestedOption implements OnDestroy, OnInit {
    get arrowLength(): number;
    set arrowLength(value: number);
    get border(): {
        color?: string;
        dashStyle?: DashStyle;
        opacity?: number | undefined;
        visible?: boolean;
        width?: number;
    };
    set border(value: {
        color?: string;
        dashStyle?: DashStyle;
        opacity?: number | undefined;
        visible?: boolean;
        width?: number;
    });
    get color(): string;
    set color(value: string);
    get container(): any | string | undefined;
    set container(value: any | string | undefined);
    get contentTemplate(): any;
    set contentTemplate(value: any);
    get cornerRadius(): number;
    set cornerRadius(value: number);
    get customizeTooltip(): ((info: {
        node: dxTreeMapNode;
        value: number;
        valueText: string;
    }) => Record<string, any>) | undefined;
    set customizeTooltip(value: ((info: {
        node: dxTreeMapNode;
        value: number;
        valueText: string;
    }) => Record<string, any>) | undefined);
    get enabled(): boolean;
    set enabled(value: boolean);
    get font(): Font;
    set font(value: Font);
    get format(): Format$1 | undefined;
    set format(value: Format$1 | undefined);
    get opacity(): number | undefined;
    set opacity(value: number | undefined);
    get paddingLeftRight(): number;
    set paddingLeftRight(value: number);
    get paddingTopBottom(): number;
    set paddingTopBottom(value: number);
    get shadow(): {
        blur?: number;
        color?: string;
        offsetX?: number;
        offsetY?: number;
        opacity?: number;
    };
    set shadow(value: {
        blur?: number;
        color?: string;
        offsetX?: number;
        offsetY?: number;
        opacity?: number;
    });
    get zIndex(): number | undefined;
    set zIndex(value: number | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTreeMapTooltipComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoTreeMapTooltipComponent, "dxo-tree-map-tooltip", never, { "arrowLength": { "alias": "arrowLength"; "required": false; }; "border": { "alias": "border"; "required": false; }; "color": { "alias": "color"; "required": false; }; "container": { "alias": "container"; "required": false; }; "contentTemplate": { "alias": "contentTemplate"; "required": false; }; "cornerRadius": { "alias": "cornerRadius"; "required": false; }; "customizeTooltip": { "alias": "customizeTooltip"; "required": false; }; "enabled": { "alias": "enabled"; "required": false; }; "font": { "alias": "font"; "required": false; }; "format": { "alias": "format"; "required": false; }; "opacity": { "alias": "opacity"; "required": false; }; "paddingLeftRight": { "alias": "paddingLeftRight"; "required": false; }; "paddingTopBottom": { "alias": "paddingTopBottom"; "required": false; }; "shadow": { "alias": "shadow"; "required": false; }; "zIndex": { "alias": "zIndex"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoTreeMapTooltipModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTreeMapTooltipModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoTreeMapTooltipModule, never, [typeof DxoTreeMapTooltipComponent], [typeof DxoTreeMapTooltipComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoTreeMapTooltipModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoTreeMapTreeMapborderComponent extends NestedOption implements OnDestroy, OnInit {
    get color(): string | undefined;
    set color(value: string | undefined);
    get width(): number | undefined;
    set width(value: number | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTreeMapTreeMapborderComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoTreeMapTreeMapborderComponent, "dxo-tree-map-tree-mapborder", never, { "color": { "alias": "color"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoTreeMapTreeMapborderModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTreeMapTreeMapborderModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoTreeMapTreeMapborderModule, never, [typeof DxoTreeMapTreeMapborderComponent], [typeof DxoTreeMapTreeMapborderComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoTreeMapTreeMapborderModule>;
}

export { DxoTreeMapBorderComponent, DxoTreeMapBorderModule, DxoTreeMapColorizerComponent, DxoTreeMapColorizerModule, DxoTreeMapExportComponent, DxoTreeMapExportModule, DxoTreeMapFontComponent, DxoTreeMapFontModule, DxoTreeMapFormatComponent, DxoTreeMapFormatModule, DxoTreeMapGroupComponent, DxoTreeMapGroupLabelComponent, DxoTreeMapGroupLabelModule, DxoTreeMapGroupModule, DxoTreeMapHoverStyleComponent, DxoTreeMapHoverStyleModule, DxoTreeMapLabelComponent, DxoTreeMapLabelModule, DxoTreeMapLoadingIndicatorComponent, DxoTreeMapLoadingIndicatorModule, DxoTreeMapMarginComponent, DxoTreeMapMarginModule, DxoTreeMapSelectionStyleComponent, DxoTreeMapSelectionStyleModule, DxoTreeMapShadowComponent, DxoTreeMapShadowModule, DxoTreeMapSizeComponent, DxoTreeMapSizeModule, DxoTreeMapSubtitleComponent, DxoTreeMapSubtitleModule, DxoTreeMapTileComponent, DxoTreeMapTileLabelComponent, DxoTreeMapTileLabelModule, DxoTreeMapTileModule, DxoTreeMapTitleComponent, DxoTreeMapTitleModule, DxoTreeMapTooltipBorderComponent, DxoTreeMapTooltipBorderModule, DxoTreeMapTooltipComponent, DxoTreeMapTooltipModule, DxoTreeMapTreeMapborderComponent, DxoTreeMapTreeMapborderModule };
//# sourceMappingURL=index.d.ts.map
