import * as i0 from '@angular/core';
import { OnDestroy, OnChanges, DoCheck, EventEmitter, ElementRef, NgZone, TransferState, SimpleChanges } from '@angular/core';
import { Palette, PaletteExtensionMode, Font, TextOverflow, Theme, WordWrap, DashStyle } from 'devextreme/common/charts';
import DxTreeMap, { TreeMapColorizerType, TreeMapLayoutAlgorithm, TreeMapLayoutDirection, dxTreeMapNode, ClickEvent, DisposingEvent, DrawnEvent, DrillEvent, ExportedEvent, ExportingEvent, FileSavingEvent, HoverChangedEvent, IncidentOccurredEvent, InitializedEvent, NodesInitializedEvent, NodesRenderingEvent, OptionChangedEvent, SelectionChangedEvent } from 'devextreme/viz/tree_map';
import DataSource, { DataSourceOptions } from 'devextreme/data/data_source';
import { Store } from 'devextreme/data/store';
import { ExportFormat, SingleMultipleOrNone, HorizontalAlignment, VerticalEdge } from 'devextreme/common';
import { Format } from 'devextreme/common/core/localization';
import * as i3 from 'devextreme-angular/core';
import { DxComponent, DxTemplateHost, WatcherHelper, IterableDifferHelper, NestedOptionHost } from 'devextreme-angular/core';
import * as i1 from 'devextreme-angular/ui/nested';
import * as i2 from 'devextreme-angular/ui/tree-map/nested';
export * from 'devextreme-angular/ui/tree-map/nested';
import * as tree_map_types from 'devextreme/viz/tree_map_types';
export { tree_map_types as DxTreeMapTypes };

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

/**
 * [descr:dxTreeMap]

 */
declare class DxTreeMapComponent extends DxComponent implements OnDestroy, OnChanges, DoCheck {
    private _watcherHelper;
    private _idh;
    instance: DxTreeMap;
    /**
     * [descr:dxTreeMapOptions.childrenField]
    
     */
    get childrenField(): string;
    set childrenField(value: string);
    /**
     * [descr:dxTreeMapOptions.colorField]
    
     */
    get colorField(): string;
    set colorField(value: string);
    /**
     * [descr:dxTreeMapOptions.colorizer]
    
     */
    get colorizer(): {
        colorCodeField?: string | undefined;
        colorizeGroups?: boolean;
        palette?: Array<string> | Palette;
        paletteExtensionMode?: PaletteExtensionMode;
        range?: Array<number> | undefined;
        type?: TreeMapColorizerType | undefined;
    };
    set colorizer(value: {
        colorCodeField?: string | undefined;
        colorizeGroups?: boolean;
        palette?: Array<string> | Palette;
        paletteExtensionMode?: PaletteExtensionMode;
        range?: Array<number> | undefined;
        type?: TreeMapColorizerType | undefined;
    });
    /**
     * [descr:dxTreeMapOptions.dataSource]
    
     */
    get dataSource(): Array<any> | DataSource | DataSourceOptions | null | Store | string;
    set dataSource(value: Array<any> | DataSource | DataSourceOptions | null | Store | string);
    /**
     * [descr:BaseWidgetOptions.disabled]
    
     */
    get disabled(): boolean;
    set disabled(value: boolean);
    /**
     * [descr:DOMComponentOptions.elementAttr]
    
     */
    get elementAttr(): Record<string, any>;
    set elementAttr(value: Record<string, any>);
    /**
     * [descr:BaseWidgetOptions.encodeHtml]
    
     */
    get encodeHtml(): boolean;
    set encodeHtml(value: boolean);
    /**
     * [descr:BaseWidgetOptions.export]
    
     */
    get export(): {
        backgroundColor?: string;
        enabled?: boolean;
        fileName?: string;
        formats?: Array<ExportFormat>;
        margin?: number;
        printingEnabled?: boolean;
        svgToCanvas?: ((svg: any, canvas: any) => any) | undefined;
    };
    set export(value: {
        backgroundColor?: string;
        enabled?: boolean;
        fileName?: string;
        formats?: Array<ExportFormat>;
        margin?: number;
        printingEnabled?: boolean;
        svgToCanvas?: ((svg: any, canvas: any) => any) | undefined;
    });
    /**
     * [descr:dxTreeMapOptions.group]
    
     */
    get group(): {
        border?: {
            color?: string | undefined;
            width?: number | undefined;
        };
        color?: string;
        headerHeight?: number | undefined;
        hoverEnabled?: boolean | undefined;
        hoverStyle?: {
            border?: {
                color?: string | undefined;
                width?: number | undefined;
            };
            color?: string | undefined;
        };
        label?: {
            font?: Font;
            textOverflow?: TextOverflow;
            visible?: boolean;
        };
        padding?: number;
        selectionStyle?: {
            border?: {
                color?: string | undefined;
                width?: number | undefined;
            };
            color?: string | undefined;
        };
    };
    set group(value: {
        border?: {
            color?: string | undefined;
            width?: number | undefined;
        };
        color?: string;
        headerHeight?: number | undefined;
        hoverEnabled?: boolean | undefined;
        hoverStyle?: {
            border?: {
                color?: string | undefined;
                width?: number | undefined;
            };
            color?: string | undefined;
        };
        label?: {
            font?: Font;
            textOverflow?: TextOverflow;
            visible?: boolean;
        };
        padding?: number;
        selectionStyle?: {
            border?: {
                color?: string | undefined;
                width?: number | undefined;
            };
            color?: string | undefined;
        };
    });
    /**
     * [descr:dxTreeMapOptions.hoverEnabled]
    
     */
    get hoverEnabled(): boolean | undefined;
    set hoverEnabled(value: boolean | undefined);
    /**
     * [descr:dxTreeMapOptions.idField]
    
     */
    get idField(): string | undefined;
    set idField(value: string | undefined);
    /**
     * [descr:dxTreeMapOptions.interactWithGroup]
    
     */
    get interactWithGroup(): boolean;
    set interactWithGroup(value: boolean);
    /**
     * [descr:dxTreeMapOptions.labelField]
    
     */
    get labelField(): string;
    set labelField(value: string);
    /**
     * [descr:dxTreeMapOptions.layoutAlgorithm]
    
     */
    get layoutAlgorithm(): ((e: {
        items: Array<any>;
        rect: Array<number>;
        sum: number;
    }) => void) | TreeMapLayoutAlgorithm;
    set layoutAlgorithm(value: ((e: {
        items: Array<any>;
        rect: Array<number>;
        sum: number;
    }) => void) | TreeMapLayoutAlgorithm);
    /**
     * [descr:dxTreeMapOptions.layoutDirection]
    
     */
    get layoutDirection(): TreeMapLayoutDirection;
    set layoutDirection(value: TreeMapLayoutDirection);
    /**
     * [descr:BaseWidgetOptions.loadingIndicator]
    
     */
    get loadingIndicator(): {
        backgroundColor?: string;
        enabled?: boolean;
        font?: Font;
        show?: boolean;
        text?: string;
    };
    set loadingIndicator(value: {
        backgroundColor?: string;
        enabled?: boolean;
        font?: Font;
        show?: boolean;
        text?: string;
    });
    /**
     * [descr:dxTreeMapOptions.maxDepth]
    
     */
    get maxDepth(): number | undefined;
    set maxDepth(value: number | undefined);
    /**
     * [descr:dxTreeMapOptions.parentField]
    
     */
    get parentField(): string | undefined;
    set parentField(value: string | undefined);
    /**
     * [descr:BaseWidgetOptions.pathModified]
    
     */
    get pathModified(): boolean;
    set pathModified(value: boolean);
    /**
     * [descr:BaseWidgetOptions.redrawOnResize]
    
     */
    get redrawOnResize(): boolean;
    set redrawOnResize(value: boolean);
    /**
     * [descr:BaseWidgetOptions.rtlEnabled]
    
     */
    get rtlEnabled(): boolean;
    set rtlEnabled(value: boolean);
    /**
     * [descr:dxTreeMapOptions.selectionMode]
    
     */
    get selectionMode(): SingleMultipleOrNone | undefined;
    set selectionMode(value: SingleMultipleOrNone | undefined);
    /**
     * [descr:BaseWidgetOptions.size]
    
     */
    get size(): {
        height?: number | undefined;
        width?: number | undefined;
    };
    set size(value: {
        height?: number | undefined;
        width?: number | undefined;
    });
    /**
     * [descr:BaseWidgetOptions.theme]
    
     */
    get theme(): Theme;
    set theme(value: Theme);
    /**
     * [descr:dxTreeMapOptions.tile]
    
     */
    get tile(): {
        border?: {
            color?: string | undefined;
            width?: number | undefined;
        };
        color?: string;
        hoverStyle?: {
            border?: {
                color?: string | undefined;
                width?: number | undefined;
            };
            color?: string | undefined;
        };
        label?: {
            font?: Font;
            textOverflow?: TextOverflow;
            visible?: boolean;
            wordWrap?: WordWrap;
        };
        selectionStyle?: {
            border?: {
                color?: string | undefined;
                width?: number | undefined;
            };
            color?: string | undefined;
        };
    };
    set tile(value: {
        border?: {
            color?: string | undefined;
            width?: number | undefined;
        };
        color?: string;
        hoverStyle?: {
            border?: {
                color?: string | undefined;
                width?: number | undefined;
            };
            color?: string | undefined;
        };
        label?: {
            font?: Font;
            textOverflow?: TextOverflow;
            visible?: boolean;
            wordWrap?: WordWrap;
        };
        selectionStyle?: {
            border?: {
                color?: string | undefined;
                width?: number | undefined;
            };
            color?: string | undefined;
        };
    });
    /**
     * [descr:BaseWidgetOptions.title]
    
     */
    get title(): string | {
        font?: Font;
        horizontalAlignment?: HorizontalAlignment;
        margin?: number | {
            bottom?: number;
            left?: number;
            right?: number;
            top?: number;
        };
        placeholderSize?: number | undefined;
        subtitle?: string | {
            font?: Font;
            offset?: number;
            text?: string | undefined;
            textOverflow?: TextOverflow;
            wordWrap?: WordWrap;
        };
        text?: string | undefined;
        textOverflow?: TextOverflow;
        verticalAlignment?: VerticalEdge;
        wordWrap?: WordWrap;
    };
    set title(value: string | {
        font?: Font;
        horizontalAlignment?: HorizontalAlignment;
        margin?: number | {
            bottom?: number;
            left?: number;
            right?: number;
            top?: number;
        };
        placeholderSize?: number | undefined;
        subtitle?: string | {
            font?: Font;
            offset?: number;
            text?: string | undefined;
            textOverflow?: TextOverflow;
            wordWrap?: WordWrap;
        };
        text?: string | undefined;
        textOverflow?: TextOverflow;
        verticalAlignment?: VerticalEdge;
        wordWrap?: WordWrap;
    });
    /**
     * [descr:dxTreeMapOptions.tooltip]
    
     */
    get tooltip(): {
        arrowLength?: number;
        border?: {
            color?: string;
            dashStyle?: DashStyle;
            opacity?: number | undefined;
            visible?: boolean;
            width?: number;
        };
        color?: string;
        container?: any | string | undefined;
        contentTemplate?: any;
        cornerRadius?: number;
        customizeTooltip?: ((info: {
            node: dxTreeMapNode;
            value: number;
            valueText: string;
        }) => Record<string, any>) | undefined;
        enabled?: boolean;
        font?: Font;
        format?: Format | undefined;
        opacity?: number | undefined;
        paddingLeftRight?: number;
        paddingTopBottom?: number;
        shadow?: {
            blur?: number;
            color?: string;
            offsetX?: number;
            offsetY?: number;
            opacity?: number;
        };
        zIndex?: number | undefined;
    };
    set tooltip(value: {
        arrowLength?: number;
        border?: {
            color?: string;
            dashStyle?: DashStyle;
            opacity?: number | undefined;
            visible?: boolean;
            width?: number;
        };
        color?: string;
        container?: any | string | undefined;
        contentTemplate?: any;
        cornerRadius?: number;
        customizeTooltip?: ((info: {
            node: dxTreeMapNode;
            value: number;
            valueText: string;
        }) => Record<string, any>) | undefined;
        enabled?: boolean;
        font?: Font;
        format?: Format | undefined;
        opacity?: number | undefined;
        paddingLeftRight?: number;
        paddingTopBottom?: number;
        shadow?: {
            blur?: number;
            color?: string;
            offsetX?: number;
            offsetY?: number;
            opacity?: number;
        };
        zIndex?: number | undefined;
    });
    /**
     * [descr:dxTreeMapOptions.valueField]
    
     */
    get valueField(): string;
    set valueField(value: string);
    /**
    
     * [descr:dxTreeMapOptions.onClick]
    
    
     */
    onClick: EventEmitter<ClickEvent>;
    /**
    
     * [descr:dxTreeMapOptions.onDisposing]
    
    
     */
    onDisposing: EventEmitter<DisposingEvent>;
    /**
    
     * [descr:dxTreeMapOptions.onDrawn]
    
    
     */
    onDrawn: EventEmitter<DrawnEvent>;
    /**
    
     * [descr:dxTreeMapOptions.onDrill]
    
    
     */
    onDrill: EventEmitter<DrillEvent>;
    /**
    
     * [descr:dxTreeMapOptions.onExported]
    
    
     */
    onExported: EventEmitter<ExportedEvent>;
    /**
    
     * [descr:dxTreeMapOptions.onExporting]
    
    
     */
    onExporting: EventEmitter<ExportingEvent>;
    /**
    
     * [descr:dxTreeMapOptions.onFileSaving]
    
    
     */
    onFileSaving: EventEmitter<FileSavingEvent>;
    /**
    
     * [descr:dxTreeMapOptions.onHoverChanged]
    
    
     */
    onHoverChanged: EventEmitter<HoverChangedEvent>;
    /**
    
     * [descr:dxTreeMapOptions.onIncidentOccurred]
    
    
     */
    onIncidentOccurred: EventEmitter<IncidentOccurredEvent>;
    /**
    
     * [descr:dxTreeMapOptions.onInitialized]
    
    
     */
    onInitialized: EventEmitter<InitializedEvent>;
    /**
    
     * [descr:dxTreeMapOptions.onNodesInitialized]
    
    
     */
    onNodesInitialized: EventEmitter<NodesInitializedEvent>;
    /**
    
     * [descr:dxTreeMapOptions.onNodesRendering]
    
    
     */
    onNodesRendering: EventEmitter<NodesRenderingEvent>;
    /**
    
     * [descr:dxTreeMapOptions.onOptionChanged]
    
    
     */
    onOptionChanged: EventEmitter<OptionChangedEvent>;
    /**
    
     * [descr:dxTreeMapOptions.onSelectionChanged]
    
    
     */
    onSelectionChanged: EventEmitter<SelectionChangedEvent>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    childrenFieldChange: EventEmitter<string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    colorFieldChange: EventEmitter<string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    colorizerChange: EventEmitter<{
        colorCodeField?: string | undefined;
        colorizeGroups?: boolean;
        palette?: Array<string> | Palette;
        paletteExtensionMode?: PaletteExtensionMode;
        range?: Array<number> | undefined;
        type?: TreeMapColorizerType | undefined;
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    dataSourceChange: EventEmitter<Array<any> | DataSource | DataSourceOptions | null | Store | string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    disabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    elementAttrChange: EventEmitter<Record<string, any>>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    encodeHtmlChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    exportChange: EventEmitter<{
        backgroundColor?: string;
        enabled?: boolean;
        fileName?: string;
        formats?: Array<ExportFormat>;
        margin?: number;
        printingEnabled?: boolean;
        svgToCanvas?: ((svg: any, canvas: any) => any) | undefined;
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    groupChange: EventEmitter<{
        border?: {
            color?: string | undefined;
            width?: number | undefined;
        };
        color?: string;
        headerHeight?: number | undefined;
        hoverEnabled?: boolean | undefined;
        hoverStyle?: {
            border?: {
                color?: string | undefined;
                width?: number | undefined;
            };
            color?: string | undefined;
        };
        label?: {
            font?: Font;
            textOverflow?: TextOverflow;
            visible?: boolean;
        };
        padding?: number;
        selectionStyle?: {
            border?: {
                color?: string | undefined;
                width?: number | undefined;
            };
            color?: string | undefined;
        };
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    hoverEnabledChange: EventEmitter<boolean | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    idFieldChange: EventEmitter<string | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    interactWithGroupChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    labelFieldChange: EventEmitter<string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    layoutAlgorithmChange: EventEmitter<((e: {
        items: Array<any>;
        rect: Array<number>;
        sum: number;
    }) => void) | TreeMapLayoutAlgorithm>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    layoutDirectionChange: EventEmitter<TreeMapLayoutDirection>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    loadingIndicatorChange: EventEmitter<{
        backgroundColor?: string;
        enabled?: boolean;
        font?: Font;
        show?: boolean;
        text?: string;
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    maxDepthChange: EventEmitter<number | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    parentFieldChange: EventEmitter<string | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    pathModifiedChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    redrawOnResizeChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    rtlEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    selectionModeChange: EventEmitter<SingleMultipleOrNone | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    sizeChange: EventEmitter<{
        height?: number | undefined;
        width?: number | undefined;
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    themeChange: EventEmitter<Theme>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    tileChange: EventEmitter<{
        border?: {
            color?: string | undefined;
            width?: number | undefined;
        };
        color?: string;
        hoverStyle?: {
            border?: {
                color?: string | undefined;
                width?: number | undefined;
            };
            color?: string | undefined;
        };
        label?: {
            font?: Font;
            textOverflow?: TextOverflow;
            visible?: boolean;
            wordWrap?: WordWrap;
        };
        selectionStyle?: {
            border?: {
                color?: string | undefined;
                width?: number | undefined;
            };
            color?: string | undefined;
        };
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    titleChange: EventEmitter<string | {
        font?: Font;
        horizontalAlignment?: HorizontalAlignment;
        margin?: number | {
            bottom?: number;
            left?: number;
            right?: number;
            top?: number;
        };
        placeholderSize?: number | undefined;
        subtitle?: string | {
            font?: Font;
            offset?: number;
            text?: string | undefined;
            textOverflow?: TextOverflow;
            wordWrap?: WordWrap;
        };
        text?: string | undefined;
        textOverflow?: TextOverflow;
        verticalAlignment?: VerticalEdge;
        wordWrap?: WordWrap;
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    tooltipChange: EventEmitter<{
        arrowLength?: number;
        border?: {
            color?: string;
            dashStyle?: DashStyle;
            opacity?: number | undefined;
            visible?: boolean;
            width?: number;
        };
        color?: string;
        container?: any | string | undefined;
        contentTemplate?: any;
        cornerRadius?: number;
        customizeTooltip?: ((info: {
            node: dxTreeMapNode;
            value: number;
            valueText: string;
        }) => Record<string, any>) | undefined;
        enabled?: boolean;
        font?: Font;
        format?: Format | undefined;
        opacity?: number | undefined;
        paddingLeftRight?: number;
        paddingTopBottom?: number;
        shadow?: {
            blur?: number;
            color?: string;
            offsetX?: number;
            offsetY?: number;
            opacity?: number;
        };
        zIndex?: number | undefined;
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    valueFieldChange: EventEmitter<string>;
    constructor(elementRef: ElementRef, ngZone: NgZone, templateHost: DxTemplateHost, _watcherHelper: WatcherHelper, _idh: IterableDifferHelper, optionHost: NestedOptionHost, transferState: TransferState, platformId: any);
    protected _createInstance(element: any, options: any): DxTreeMap;
    ngOnDestroy(): void;
    ngOnChanges(changes: SimpleChanges): void;
    setupChanges(prop: string, changes: SimpleChanges): void;
    ngDoCheck(): void;
    _setOption(name: string, value: any): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxTreeMapComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxTreeMapComponent, "dx-tree-map", never, { "childrenField": { "alias": "childrenField"; "required": false; }; "colorField": { "alias": "colorField"; "required": false; }; "colorizer": { "alias": "colorizer"; "required": false; }; "dataSource": { "alias": "dataSource"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "elementAttr": { "alias": "elementAttr"; "required": false; }; "encodeHtml": { "alias": "encodeHtml"; "required": false; }; "export": { "alias": "export"; "required": false; }; "group": { "alias": "group"; "required": false; }; "hoverEnabled": { "alias": "hoverEnabled"; "required": false; }; "idField": { "alias": "idField"; "required": false; }; "interactWithGroup": { "alias": "interactWithGroup"; "required": false; }; "labelField": { "alias": "labelField"; "required": false; }; "layoutAlgorithm": { "alias": "layoutAlgorithm"; "required": false; }; "layoutDirection": { "alias": "layoutDirection"; "required": false; }; "loadingIndicator": { "alias": "loadingIndicator"; "required": false; }; "maxDepth": { "alias": "maxDepth"; "required": false; }; "parentField": { "alias": "parentField"; "required": false; }; "pathModified": { "alias": "pathModified"; "required": false; }; "redrawOnResize": { "alias": "redrawOnResize"; "required": false; }; "rtlEnabled": { "alias": "rtlEnabled"; "required": false; }; "selectionMode": { "alias": "selectionMode"; "required": false; }; "size": { "alias": "size"; "required": false; }; "theme": { "alias": "theme"; "required": false; }; "tile": { "alias": "tile"; "required": false; }; "title": { "alias": "title"; "required": false; }; "tooltip": { "alias": "tooltip"; "required": false; }; "valueField": { "alias": "valueField"; "required": false; }; }, { "onClick": "onClick"; "onDisposing": "onDisposing"; "onDrawn": "onDrawn"; "onDrill": "onDrill"; "onExported": "onExported"; "onExporting": "onExporting"; "onFileSaving": "onFileSaving"; "onHoverChanged": "onHoverChanged"; "onIncidentOccurred": "onIncidentOccurred"; "onInitialized": "onInitialized"; "onNodesInitialized": "onNodesInitialized"; "onNodesRendering": "onNodesRendering"; "onOptionChanged": "onOptionChanged"; "onSelectionChanged": "onSelectionChanged"; "childrenFieldChange": "childrenFieldChange"; "colorFieldChange": "colorFieldChange"; "colorizerChange": "colorizerChange"; "dataSourceChange": "dataSourceChange"; "disabledChange": "disabledChange"; "elementAttrChange": "elementAttrChange"; "encodeHtmlChange": "encodeHtmlChange"; "exportChange": "exportChange"; "groupChange": "groupChange"; "hoverEnabledChange": "hoverEnabledChange"; "idFieldChange": "idFieldChange"; "interactWithGroupChange": "interactWithGroupChange"; "labelFieldChange": "labelFieldChange"; "layoutAlgorithmChange": "layoutAlgorithmChange"; "layoutDirectionChange": "layoutDirectionChange"; "loadingIndicatorChange": "loadingIndicatorChange"; "maxDepthChange": "maxDepthChange"; "parentFieldChange": "parentFieldChange"; "pathModifiedChange": "pathModifiedChange"; "redrawOnResizeChange": "redrawOnResizeChange"; "rtlEnabledChange": "rtlEnabledChange"; "selectionModeChange": "selectionModeChange"; "sizeChange": "sizeChange"; "themeChange": "themeChange"; "tileChange": "tileChange"; "titleChange": "titleChange"; "tooltipChange": "tooltipChange"; "valueFieldChange": "valueFieldChange"; }, never, never, true, never>;
}
declare class DxTreeMapModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxTreeMapModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxTreeMapModule, never, [typeof DxTreeMapComponent, typeof i1.DxoColorizerModule, typeof i1.DxoExportModule, typeof i1.DxoGroupModule, typeof i1.DxoBorderModule, typeof i1.DxoHoverStyleModule, typeof i1.DxoLabelModule, typeof i1.DxoFontModule, typeof i1.DxoSelectionStyleModule, typeof i1.DxoLoadingIndicatorModule, typeof i1.DxoSizeModule, typeof i1.DxoTileModule, typeof i1.DxoTitleModule, typeof i1.DxoMarginModule, typeof i1.DxoSubtitleModule, typeof i1.DxoTooltipModule, typeof i1.DxoFormatModule, typeof i1.DxoShadowModule, typeof i2.DxoTreeMapBorderModule, typeof i2.DxoTreeMapColorizerModule, typeof i2.DxoTreeMapExportModule, typeof i2.DxoTreeMapFontModule, typeof i2.DxoTreeMapFormatModule, typeof i2.DxoTreeMapGroupModule, typeof i2.DxoTreeMapGroupLabelModule, typeof i2.DxoTreeMapHoverStyleModule, typeof i2.DxoTreeMapLabelModule, typeof i2.DxoTreeMapLoadingIndicatorModule, typeof i2.DxoTreeMapMarginModule, typeof i2.DxoTreeMapSelectionStyleModule, typeof i2.DxoTreeMapShadowModule, typeof i2.DxoTreeMapSizeModule, typeof i2.DxoTreeMapSubtitleModule, typeof i2.DxoTreeMapTileModule, typeof i2.DxoTreeMapTileLabelModule, typeof i2.DxoTreeMapTitleModule, typeof i2.DxoTreeMapTooltipModule, typeof i2.DxoTreeMapTooltipBorderModule, typeof i2.DxoTreeMapTreeMapborderModule, typeof i3.DxIntegrationModule, typeof i3.DxTemplateModule], [typeof DxTreeMapComponent, typeof i1.DxoColorizerModule, typeof i1.DxoExportModule, typeof i1.DxoGroupModule, typeof i1.DxoBorderModule, typeof i1.DxoHoverStyleModule, typeof i1.DxoLabelModule, typeof i1.DxoFontModule, typeof i1.DxoSelectionStyleModule, typeof i1.DxoLoadingIndicatorModule, typeof i1.DxoSizeModule, typeof i1.DxoTileModule, typeof i1.DxoTitleModule, typeof i1.DxoMarginModule, typeof i1.DxoSubtitleModule, typeof i1.DxoTooltipModule, typeof i1.DxoFormatModule, typeof i1.DxoShadowModule, typeof i2.DxoTreeMapBorderModule, typeof i2.DxoTreeMapColorizerModule, typeof i2.DxoTreeMapExportModule, typeof i2.DxoTreeMapFontModule, typeof i2.DxoTreeMapFormatModule, typeof i2.DxoTreeMapGroupModule, typeof i2.DxoTreeMapGroupLabelModule, typeof i2.DxoTreeMapHoverStyleModule, typeof i2.DxoTreeMapLabelModule, typeof i2.DxoTreeMapLoadingIndicatorModule, typeof i2.DxoTreeMapMarginModule, typeof i2.DxoTreeMapSelectionStyleModule, typeof i2.DxoTreeMapShadowModule, typeof i2.DxoTreeMapSizeModule, typeof i2.DxoTreeMapSubtitleModule, typeof i2.DxoTreeMapTileModule, typeof i2.DxoTreeMapTileLabelModule, typeof i2.DxoTreeMapTitleModule, typeof i2.DxoTreeMapTooltipModule, typeof i2.DxoTreeMapTooltipBorderModule, typeof i2.DxoTreeMapTreeMapborderModule, typeof i3.DxTemplateModule]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxTreeMapModule>;
}

export { DxTreeMapComponent, DxTreeMapModule };
//# sourceMappingURL=index.d.ts.map
