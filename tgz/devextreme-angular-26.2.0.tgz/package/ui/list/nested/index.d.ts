import { TextEditorButtonLocation, DragDirection, DragHighlight, Orientation, ButtonStyle, ButtonType, TextBoxPredefinedButton, TextEditorButton, LabelMode, MaskMode, EditorStyle, ValidationMessageMode, Position, ValidationStatus } from 'devextreme/common';
import { dxButtonOptions, ClickEvent, ContentReadyEvent, DisposingEvent as DisposingEvent$1, InitializedEvent as InitializedEvent$1, OptionChangedEvent as OptionChangedEvent$1 } from 'devextreme/ui/button';
import { CollectionNestedOption, NestedOptionHost, NestedOption, IDxTemplateHost, DxTemplateHost, DxTemplateDirective } from 'devextreme-angular/core';
import * as i0 from '@angular/core';
import { OnDestroy, OnInit, AfterViewInit, Renderer2, ElementRef, QueryList, EventEmitter } from '@angular/core';
import { AddEvent, DisposingEvent, DragChangeEvent, DragEndEvent, DragMoveEvent, DragStartEvent, InitializedEvent, OptionChangedEvent, RemoveEvent, ReorderEvent } from 'devextreme/ui/sortable';
import { TextBoxType, ChangeEvent, ContentReadyEvent as ContentReadyEvent$1, CopyEvent, CutEvent, DisposingEvent as DisposingEvent$2, EnterKeyEvent, FocusInEvent, FocusOutEvent, InitializedEvent as InitializedEvent$2, InputEvent, KeyDownEvent, KeyUpEvent, OptionChangedEvent as OptionChangedEvent$2, PasteEvent, ValueChangedEvent } from 'devextreme/ui/text_box';

declare class DxiListButtonComponent extends CollectionNestedOption {
    get location(): TextEditorButtonLocation;
    set location(value: TextEditorButtonLocation);
    get name(): string | undefined;
    set name(value: string | undefined);
    get options(): dxButtonOptions | undefined;
    set options(value: dxButtonOptions | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiListButtonComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiListButtonComponent, "dxi-list-button", never, { "location": { "alias": "location"; "required": false; }; "name": { "alias": "name"; "required": false; }; "options": { "alias": "options"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxiListButtonModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiListButtonModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiListButtonModule, never, [typeof DxiListButtonComponent], [typeof DxiListButtonComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiListButtonModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoListCursorOffsetComponent extends NestedOption implements OnDestroy, OnInit {
    get x(): number;
    set x(value: number);
    get y(): number;
    set y(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoListCursorOffsetComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoListCursorOffsetComponent, "dxo-list-cursor-offset", never, { "x": { "alias": "x"; "required": false; }; "y": { "alias": "y"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoListCursorOffsetModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoListCursorOffsetModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoListCursorOffsetModule, never, [typeof DxoListCursorOffsetComponent], [typeof DxoListCursorOffsetComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoListCursorOffsetModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoListItemDraggingComponent extends NestedOption implements OnDestroy, OnInit {
    get allowDropInsideItem(): boolean;
    set allowDropInsideItem(value: boolean);
    get allowReordering(): boolean;
    set allowReordering(value: boolean);
    get autoScroll(): boolean;
    set autoScroll(value: boolean);
    get boundary(): any | string | undefined;
    set boundary(value: any | string | undefined);
    get container(): any | string | undefined;
    set container(value: any | string | undefined);
    get cursorOffset(): string | {
        x?: number;
        y?: number;
    };
    set cursorOffset(value: string | {
        x?: number;
        y?: number;
    });
    get data(): any | undefined;
    set data(value: any | undefined);
    get dragDirection(): DragDirection;
    set dragDirection(value: DragDirection);
    get dragTemplate(): any;
    set dragTemplate(value: any);
    get dropFeedbackMode(): DragHighlight;
    set dropFeedbackMode(value: DragHighlight);
    get elementAttr(): Record<string, any>;
    set elementAttr(value: Record<string, any>);
    get filter(): string;
    set filter(value: string);
    get group(): string | undefined;
    set group(value: string | undefined);
    get handle(): string;
    set handle(value: string);
    get height(): number | string | undefined;
    set height(value: number | string | undefined);
    get itemOrientation(): Orientation;
    set itemOrientation(value: Orientation);
    get moveItemOnDrop(): boolean;
    set moveItemOnDrop(value: boolean);
    get onAdd(): ((e: AddEvent) => void) | undefined;
    set onAdd(value: ((e: AddEvent) => void) | undefined);
    get onDisposing(): ((e: DisposingEvent) => void);
    set onDisposing(value: ((e: DisposingEvent) => void));
    get onDragChange(): ((e: DragChangeEvent) => void) | undefined;
    set onDragChange(value: ((e: DragChangeEvent) => void) | undefined);
    get onDragEnd(): ((e: DragEndEvent) => void) | undefined;
    set onDragEnd(value: ((e: DragEndEvent) => void) | undefined);
    get onDragMove(): ((e: DragMoveEvent) => void) | undefined;
    set onDragMove(value: ((e: DragMoveEvent) => void) | undefined);
    get onDragStart(): ((e: DragStartEvent) => void) | undefined;
    set onDragStart(value: ((e: DragStartEvent) => void) | undefined);
    get onInitialized(): ((e: InitializedEvent) => void);
    set onInitialized(value: ((e: InitializedEvent) => void));
    get onOptionChanged(): ((e: OptionChangedEvent) => void);
    set onOptionChanged(value: ((e: OptionChangedEvent) => void));
    get onRemove(): ((e: RemoveEvent) => void) | undefined;
    set onRemove(value: ((e: RemoveEvent) => void) | undefined);
    get onReorder(): ((e: ReorderEvent) => void) | undefined;
    set onReorder(value: ((e: ReorderEvent) => void) | undefined);
    get rtlEnabled(): boolean;
    set rtlEnabled(value: boolean);
    get scrollSensitivity(): number;
    set scrollSensitivity(value: number);
    get scrollSpeed(): number;
    set scrollSpeed(value: number);
    get width(): number | string | undefined;
    set width(value: number | string | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoListItemDraggingComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoListItemDraggingComponent, "dxo-list-item-dragging", never, { "allowDropInsideItem": { "alias": "allowDropInsideItem"; "required": false; }; "allowReordering": { "alias": "allowReordering"; "required": false; }; "autoScroll": { "alias": "autoScroll"; "required": false; }; "boundary": { "alias": "boundary"; "required": false; }; "container": { "alias": "container"; "required": false; }; "cursorOffset": { "alias": "cursorOffset"; "required": false; }; "data": { "alias": "data"; "required": false; }; "dragDirection": { "alias": "dragDirection"; "required": false; }; "dragTemplate": { "alias": "dragTemplate"; "required": false; }; "dropFeedbackMode": { "alias": "dropFeedbackMode"; "required": false; }; "elementAttr": { "alias": "elementAttr"; "required": false; }; "filter": { "alias": "filter"; "required": false; }; "group": { "alias": "group"; "required": false; }; "handle": { "alias": "handle"; "required": false; }; "height": { "alias": "height"; "required": false; }; "itemOrientation": { "alias": "itemOrientation"; "required": false; }; "moveItemOnDrop": { "alias": "moveItemOnDrop"; "required": false; }; "onAdd": { "alias": "onAdd"; "required": false; }; "onDisposing": { "alias": "onDisposing"; "required": false; }; "onDragChange": { "alias": "onDragChange"; "required": false; }; "onDragEnd": { "alias": "onDragEnd"; "required": false; }; "onDragMove": { "alias": "onDragMove"; "required": false; }; "onDragStart": { "alias": "onDragStart"; "required": false; }; "onInitialized": { "alias": "onInitialized"; "required": false; }; "onOptionChanged": { "alias": "onOptionChanged"; "required": false; }; "onRemove": { "alias": "onRemove"; "required": false; }; "onReorder": { "alias": "onReorder"; "required": false; }; "rtlEnabled": { "alias": "rtlEnabled"; "required": false; }; "scrollSensitivity": { "alias": "scrollSensitivity"; "required": false; }; "scrollSpeed": { "alias": "scrollSpeed"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoListItemDraggingModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoListItemDraggingModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoListItemDraggingModule, never, [typeof DxoListItemDraggingComponent], [typeof DxoListItemDraggingComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoListItemDraggingModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxiListItemComponent extends CollectionNestedOption implements AfterViewInit, IDxTemplateHost {
    private renderer;
    private document;
    private element;
    get badge(): string;
    set badge(value: string);
    get disabled(): boolean;
    set disabled(value: boolean);
    get html(): string;
    set html(value: string);
    get icon(): string;
    set icon(value: string);
    get key(): string;
    set key(value: string);
    get showChevron(): boolean;
    set showChevron(value: boolean);
    get template(): any;
    set template(value: any);
    get text(): string;
    set text(value: string);
    get visible(): boolean;
    set visible(value: boolean);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost, renderer: Renderer2, document: any, templateHost: DxTemplateHost, element: ElementRef);
    setTemplate(template: DxTemplateDirective): void;
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiListItemComponent, [{ host: true; skipSelf: true; }, { host: true; }, null, null, { host: true; }, null]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiListItemComponent, "dxi-list-item", never, { "badge": { "alias": "badge"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "html": { "alias": "html"; "required": false; }; "icon": { "alias": "icon"; "required": false; }; "key": { "alias": "key"; "required": false; }; "showChevron": { "alias": "showChevron"; "required": false; }; "template": { "alias": "template"; "required": false; }; "text": { "alias": "text"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; }, {}, never, ["*"], true, never>;
}
declare class DxiListItemModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiListItemModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiListItemModule, never, [typeof DxiListItemComponent], [typeof DxiListItemComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiListItemModule>;
}

declare class DxiListMenuItemComponent extends CollectionNestedOption {
    get action(): ((itemElement: any, itemData: any) => void);
    set action(value: ((itemElement: any, itemData: any) => void));
    get text(): string;
    set text(value: string);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiListMenuItemComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiListMenuItemComponent, "dxi-list-menu-item", never, { "action": { "alias": "action"; "required": false; }; "text": { "alias": "text"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxiListMenuItemModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiListMenuItemModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiListMenuItemModule, never, [typeof DxiListMenuItemComponent], [typeof DxiListMenuItemComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiListMenuItemModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoListOptionsComponent extends NestedOption implements AfterViewInit, OnDestroy, OnInit, IDxTemplateHost {
    private renderer;
    private document;
    private element;
    get accessKey(): string | undefined;
    set accessKey(value: string | undefined);
    get activeStateEnabled(): boolean;
    set activeStateEnabled(value: boolean);
    get disabled(): boolean;
    set disabled(value: boolean);
    get elementAttr(): Record<string, any>;
    set elementAttr(value: Record<string, any>);
    get focusStateEnabled(): boolean;
    set focusStateEnabled(value: boolean);
    get height(): number | string | undefined;
    set height(value: number | string | undefined);
    get hint(): string | undefined;
    set hint(value: string | undefined);
    get hoverStateEnabled(): boolean;
    set hoverStateEnabled(value: boolean);
    get icon(): string;
    set icon(value: string);
    get onClick(): ((e: ClickEvent) => void) | undefined;
    set onClick(value: ((e: ClickEvent) => void) | undefined);
    get onContentReady(): ((e: ContentReadyEvent) => void);
    set onContentReady(value: ((e: ContentReadyEvent) => void));
    get onDisposing(): ((e: DisposingEvent$1) => void);
    set onDisposing(value: ((e: DisposingEvent$1) => void));
    get onInitialized(): ((e: InitializedEvent$1) => void);
    set onInitialized(value: ((e: InitializedEvent$1) => void));
    get onOptionChanged(): ((e: OptionChangedEvent$1) => void);
    set onOptionChanged(value: ((e: OptionChangedEvent$1) => void));
    get rtlEnabled(): boolean;
    set rtlEnabled(value: boolean);
    get stylingMode(): ButtonStyle;
    set stylingMode(value: ButtonStyle);
    get tabIndex(): number;
    set tabIndex(value: number);
    get template(): any;
    set template(value: any);
    get text(): string;
    set text(value: string);
    get type(): ButtonType | string;
    set type(value: ButtonType | string);
    get useSubmitBehavior(): boolean;
    set useSubmitBehavior(value: boolean);
    get validationGroup(): string | undefined;
    set validationGroup(value: string | undefined);
    get visible(): boolean;
    set visible(value: boolean);
    get width(): number | string | undefined;
    set width(value: number | string | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost, renderer: Renderer2, document: any, templateHost: DxTemplateHost, element: ElementRef);
    setTemplate(template: DxTemplateDirective): void;
    ngAfterViewInit(): void;
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoListOptionsComponent, [{ host: true; skipSelf: true; }, { host: true; }, null, null, { host: true; }, null]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoListOptionsComponent, "dxo-list-options", never, { "accessKey": { "alias": "accessKey"; "required": false; }; "activeStateEnabled": { "alias": "activeStateEnabled"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "elementAttr": { "alias": "elementAttr"; "required": false; }; "focusStateEnabled": { "alias": "focusStateEnabled"; "required": false; }; "height": { "alias": "height"; "required": false; }; "hint": { "alias": "hint"; "required": false; }; "hoverStateEnabled": { "alias": "hoverStateEnabled"; "required": false; }; "icon": { "alias": "icon"; "required": false; }; "onClick": { "alias": "onClick"; "required": false; }; "onContentReady": { "alias": "onContentReady"; "required": false; }; "onDisposing": { "alias": "onDisposing"; "required": false; }; "onInitialized": { "alias": "onInitialized"; "required": false; }; "onOptionChanged": { "alias": "onOptionChanged"; "required": false; }; "rtlEnabled": { "alias": "rtlEnabled"; "required": false; }; "stylingMode": { "alias": "stylingMode"; "required": false; }; "tabIndex": { "alias": "tabIndex"; "required": false; }; "template": { "alias": "template"; "required": false; }; "text": { "alias": "text"; "required": false; }; "type": { "alias": "type"; "required": false; }; "useSubmitBehavior": { "alias": "useSubmitBehavior"; "required": false; }; "validationGroup": { "alias": "validationGroup"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, ["*"], true, never>;
}
declare class DxoListOptionsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoListOptionsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoListOptionsModule, never, [typeof DxoListOptionsComponent], [typeof DxoListOptionsComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoListOptionsModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoListSearchEditorOptionsComponent extends NestedOption implements OnDestroy, OnInit {
    set _buttonsContentChildren(value: QueryList<CollectionNestedOption>);
    get accessKey(): string | undefined;
    set accessKey(value: string | undefined);
    get activeStateEnabled(): boolean;
    set activeStateEnabled(value: boolean);
    get buttons(): Array<string | TextBoxPredefinedButton | TextEditorButton> | undefined;
    set buttons(value: Array<string | TextBoxPredefinedButton | TextEditorButton> | undefined);
    get disabled(): boolean;
    set disabled(value: boolean);
    get elementAttr(): Record<string, any>;
    set elementAttr(value: Record<string, any>);
    get focusStateEnabled(): boolean;
    set focusStateEnabled(value: boolean);
    get height(): number | string | undefined;
    set height(value: number | string | undefined);
    get hint(): string | undefined;
    set hint(value: string | undefined);
    get hoverStateEnabled(): boolean;
    set hoverStateEnabled(value: boolean);
    get inputAttr(): any;
    set inputAttr(value: any);
    get isDirty(): boolean;
    set isDirty(value: boolean);
    get isValid(): boolean;
    set isValid(value: boolean);
    get label(): string;
    set label(value: string);
    get labelMode(): LabelMode;
    set labelMode(value: LabelMode);
    get mask(): string;
    set mask(value: string);
    get maskChar(): string;
    set maskChar(value: string);
    get maskInvalidMessage(): string;
    set maskInvalidMessage(value: string);
    get maskRules(): any;
    set maskRules(value: any);
    get maxLength(): null | number | string;
    set maxLength(value: null | number | string);
    get mode(): TextBoxType;
    set mode(value: TextBoxType);
    get name(): string;
    set name(value: string);
    get onChange(): ((e: ChangeEvent) => void);
    set onChange(value: ((e: ChangeEvent) => void));
    get onContentReady(): ((e: ContentReadyEvent$1) => void);
    set onContentReady(value: ((e: ContentReadyEvent$1) => void));
    get onCopy(): ((e: CopyEvent) => void);
    set onCopy(value: ((e: CopyEvent) => void));
    get onCut(): ((e: CutEvent) => void);
    set onCut(value: ((e: CutEvent) => void));
    get onDisposing(): ((e: DisposingEvent$2) => void);
    set onDisposing(value: ((e: DisposingEvent$2) => void));
    get onEnterKey(): ((e: EnterKeyEvent) => void);
    set onEnterKey(value: ((e: EnterKeyEvent) => void));
    get onFocusIn(): ((e: FocusInEvent) => void);
    set onFocusIn(value: ((e: FocusInEvent) => void));
    get onFocusOut(): ((e: FocusOutEvent) => void);
    set onFocusOut(value: ((e: FocusOutEvent) => void));
    get onInitialized(): ((e: InitializedEvent$2) => void);
    set onInitialized(value: ((e: InitializedEvent$2) => void));
    get onInput(): ((e: InputEvent) => void);
    set onInput(value: ((e: InputEvent) => void));
    get onKeyDown(): ((e: KeyDownEvent) => void);
    set onKeyDown(value: ((e: KeyDownEvent) => void));
    get onKeyUp(): ((e: KeyUpEvent) => void);
    set onKeyUp(value: ((e: KeyUpEvent) => void));
    get onOptionChanged(): ((e: OptionChangedEvent$2) => void);
    set onOptionChanged(value: ((e: OptionChangedEvent$2) => void));
    get onPaste(): ((e: PasteEvent) => void);
    set onPaste(value: ((e: PasteEvent) => void));
    get onValueChanged(): ((e: ValueChangedEvent) => void);
    set onValueChanged(value: ((e: ValueChangedEvent) => void));
    get placeholder(): string;
    set placeholder(value: string);
    get readOnly(): boolean;
    set readOnly(value: boolean);
    get rtlEnabled(): boolean;
    set rtlEnabled(value: boolean);
    get showClearButton(): boolean;
    set showClearButton(value: boolean);
    get showMaskMode(): MaskMode;
    set showMaskMode(value: MaskMode);
    get spellcheck(): boolean;
    set spellcheck(value: boolean);
    get stylingMode(): EditorStyle;
    set stylingMode(value: EditorStyle);
    get tabIndex(): number;
    set tabIndex(value: number);
    get text(): string;
    set text(value: string);
    get useMaskedValue(): boolean;
    set useMaskedValue(value: boolean);
    get validationError(): any | null;
    set validationError(value: any | null);
    get validationErrors(): Array<any> | null;
    set validationErrors(value: Array<any> | null);
    get validationMessageMode(): ValidationMessageMode;
    set validationMessageMode(value: ValidationMessageMode);
    get validationMessagePosition(): Position;
    set validationMessagePosition(value: Position);
    get validationStatus(): ValidationStatus;
    set validationStatus(value: ValidationStatus);
    get value(): string;
    set value(value: string);
    get valueChangeEvent(): string;
    set valueChangeEvent(value: string);
    get visible(): boolean;
    set visible(value: boolean);
    get width(): number | string | undefined;
    set width(value: number | string | undefined);
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    valueChange: EventEmitter<string>;
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoListSearchEditorOptionsComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoListSearchEditorOptionsComponent, "dxo-list-search-editor-options", never, { "accessKey": { "alias": "accessKey"; "required": false; }; "activeStateEnabled": { "alias": "activeStateEnabled"; "required": false; }; "buttons": { "alias": "buttons"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "elementAttr": { "alias": "elementAttr"; "required": false; }; "focusStateEnabled": { "alias": "focusStateEnabled"; "required": false; }; "height": { "alias": "height"; "required": false; }; "hint": { "alias": "hint"; "required": false; }; "hoverStateEnabled": { "alias": "hoverStateEnabled"; "required": false; }; "inputAttr": { "alias": "inputAttr"; "required": false; }; "isDirty": { "alias": "isDirty"; "required": false; }; "isValid": { "alias": "isValid"; "required": false; }; "label": { "alias": "label"; "required": false; }; "labelMode": { "alias": "labelMode"; "required": false; }; "mask": { "alias": "mask"; "required": false; }; "maskChar": { "alias": "maskChar"; "required": false; }; "maskInvalidMessage": { "alias": "maskInvalidMessage"; "required": false; }; "maskRules": { "alias": "maskRules"; "required": false; }; "maxLength": { "alias": "maxLength"; "required": false; }; "mode": { "alias": "mode"; "required": false; }; "name": { "alias": "name"; "required": false; }; "onChange": { "alias": "onChange"; "required": false; }; "onContentReady": { "alias": "onContentReady"; "required": false; }; "onCopy": { "alias": "onCopy"; "required": false; }; "onCut": { "alias": "onCut"; "required": false; }; "onDisposing": { "alias": "onDisposing"; "required": false; }; "onEnterKey": { "alias": "onEnterKey"; "required": false; }; "onFocusIn": { "alias": "onFocusIn"; "required": false; }; "onFocusOut": { "alias": "onFocusOut"; "required": false; }; "onInitialized": { "alias": "onInitialized"; "required": false; }; "onInput": { "alias": "onInput"; "required": false; }; "onKeyDown": { "alias": "onKeyDown"; "required": false; }; "onKeyUp": { "alias": "onKeyUp"; "required": false; }; "onOptionChanged": { "alias": "onOptionChanged"; "required": false; }; "onPaste": { "alias": "onPaste"; "required": false; }; "onValueChanged": { "alias": "onValueChanged"; "required": false; }; "placeholder": { "alias": "placeholder"; "required": false; }; "readOnly": { "alias": "readOnly"; "required": false; }; "rtlEnabled": { "alias": "rtlEnabled"; "required": false; }; "showClearButton": { "alias": "showClearButton"; "required": false; }; "showMaskMode": { "alias": "showMaskMode"; "required": false; }; "spellcheck": { "alias": "spellcheck"; "required": false; }; "stylingMode": { "alias": "stylingMode"; "required": false; }; "tabIndex": { "alias": "tabIndex"; "required": false; }; "text": { "alias": "text"; "required": false; }; "useMaskedValue": { "alias": "useMaskedValue"; "required": false; }; "validationError": { "alias": "validationError"; "required": false; }; "validationErrors": { "alias": "validationErrors"; "required": false; }; "validationMessageMode": { "alias": "validationMessageMode"; "required": false; }; "validationMessagePosition": { "alias": "validationMessagePosition"; "required": false; }; "validationStatus": { "alias": "validationStatus"; "required": false; }; "value": { "alias": "value"; "required": false; }; "valueChangeEvent": { "alias": "valueChangeEvent"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, { "valueChange": "valueChange"; }, ["_buttonsContentChildren"], never, true, never>;
}
declare class DxoListSearchEditorOptionsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoListSearchEditorOptionsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoListSearchEditorOptionsModule, never, [typeof DxoListSearchEditorOptionsComponent], [typeof DxoListSearchEditorOptionsComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoListSearchEditorOptionsModule>;
}

export { DxiListButtonComponent, DxiListButtonModule, DxiListItemComponent, DxiListItemModule, DxiListMenuItemComponent, DxiListMenuItemModule, DxoListCursorOffsetComponent, DxoListCursorOffsetModule, DxoListItemDraggingComponent, DxoListItemDraggingModule, DxoListOptionsComponent, DxoListOptionsModule, DxoListSearchEditorOptionsComponent, DxoListSearchEditorOptionsModule };
//# sourceMappingURL=index.d.ts.map
