import * as i0 from '@angular/core';
import { OnDestroy, OnChanges, DoCheck, QueryList, EventEmitter, ElementRef, NgZone, TransferState, SimpleChanges } from '@angular/core';
import DxList, { dxListItem, ItemDeleteMode, ListMenuMode, ContentReadyEvent, DisposingEvent, GroupRenderedEvent, InitializedEvent, ItemClickEvent, ItemContextMenuEvent, ItemDeletedEvent, ItemDeletingEvent, ItemHoldEvent, ItemRenderedEvent, ItemReorderedEvent, ItemSwipeEvent, OptionChangedEvent, PageLoadingEvent, PullRefreshEvent, ScrollEvent, SelectAllValueChangedEvent, SelectionChangedEvent, SelectionChangingEvent } from 'devextreme/ui/list';
export { ExplicitTypes } from 'devextreme/ui/list';
import DataSource, { DataSourceOptions } from 'devextreme/data/data_source';
import { Store } from 'devextreme/data/store';
import { dxSortableOptions } from 'devextreme/ui/sortable';
import { PageLoadMode, SearchMode, SelectAllMode, SingleMultipleAllOrNone, ScrollbarMode } from 'devextreme/common';
import { dxTextBoxOptions } from 'devextreme/ui/text_box';
import * as i3 from 'devextreme-angular/core';
import { DxComponent, CollectionNestedOption, DxTemplateHost, WatcherHelper, IterableDifferHelper, NestedOptionHost } from 'devextreme-angular/core';
import * as i1 from 'devextreme-angular/ui/nested';
import * as i2 from 'devextreme-angular/ui/list/nested';
export * from 'devextreme-angular/ui/list/nested';
import * as list_types from 'devextreme/ui/list_types';
export { list_types as DxListTypes };

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

/**
 * [descr:dxList]

 */
declare class DxListComponent<TItem = any, TKey = any> extends DxComponent implements OnDestroy, OnChanges, DoCheck {
    private _watcherHelper;
    private _idh;
    set _buttonsContentChildren(value: QueryList<CollectionNestedOption>);
    set _itemsContentChildren(value: QueryList<CollectionNestedOption>);
    set _menuItemsContentChildren(value: QueryList<CollectionNestedOption>);
    instance: DxList<TItem, TKey>;
    /**
     * [descr:WidgetOptions.accessKey]
    
     */
    get accessKey(): string | undefined;
    set accessKey(value: string | undefined);
    /**
     * [descr:dxListOptions.activeStateEnabled]
    
     */
    get activeStateEnabled(): boolean;
    set activeStateEnabled(value: boolean);
    /**
     * [descr:dxListOptions.allowItemDeleting]
    
     */
    get allowItemDeleting(): boolean;
    set allowItemDeleting(value: boolean);
    /**
     * [descr:dxListOptions.bounceEnabled]
    
     */
    get bounceEnabled(): boolean;
    set bounceEnabled(value: boolean);
    /**
     * [descr:dxListOptions.collapsibleGroups]
    
     */
    get collapsibleGroups(): boolean;
    set collapsibleGroups(value: boolean);
    /**
     * [descr:dxListOptions.dataSource]
    
     */
    get dataSource(): Array<any | dxListItem | string> | DataSource | DataSourceOptions | null | Store | string;
    set dataSource(value: Array<any | dxListItem | string> | DataSource | DataSourceOptions | null | Store | string);
    /**
     * [descr:WidgetOptions.disabled]
    
     */
    get disabled(): boolean;
    set disabled(value: boolean);
    /**
     * [descr:dxListOptions.displayExpr]
    
     */
    get displayExpr(): ((item: any) => string) | string | undefined;
    set displayExpr(value: ((item: any) => string) | string | undefined);
    /**
     * [descr:DOMComponentOptions.elementAttr]
    
     */
    get elementAttr(): Record<string, any>;
    set elementAttr(value: Record<string, any>);
    /**
     * [descr:dxListOptions.focusStateEnabled]
    
     */
    get focusStateEnabled(): boolean;
    set focusStateEnabled(value: boolean);
    /**
     * [descr:dxListOptions.grouped]
    
     */
    get grouped(): boolean;
    set grouped(value: boolean);
    /**
     * [descr:dxListOptions.groupTemplate]
    
     */
    get groupTemplate(): any;
    set groupTemplate(value: any);
    /**
     * [descr:DOMComponentOptions.height]
    
     */
    get height(): number | string | undefined;
    set height(value: number | string | undefined);
    /**
     * [descr:WidgetOptions.hint]
    
     */
    get hint(): string | undefined;
    set hint(value: string | undefined);
    /**
     * [descr:dxListOptions.hoverStateEnabled]
    
     */
    get hoverStateEnabled(): boolean;
    set hoverStateEnabled(value: boolean);
    /**
     * [descr:dxListOptions.indicateLoading]
    
     */
    get indicateLoading(): boolean;
    set indicateLoading(value: boolean);
    /**
     * [descr:dxListOptions.itemDeleteMode]
    
     */
    get itemDeleteMode(): ItemDeleteMode;
    set itemDeleteMode(value: ItemDeleteMode);
    /**
     * [descr:dxListOptions.itemDragging]
    
     */
    get itemDragging(): dxSortableOptions;
    set itemDragging(value: dxSortableOptions);
    /**
     * [descr:CollectionWidgetOptions.itemHoldTimeout]
    
     */
    get itemHoldTimeout(): number;
    set itemHoldTimeout(value: number);
    /**
     * [descr:dxListOptions.items]
    
     */
    get items(): Array<any | dxListItem | string>;
    set items(value: Array<any | dxListItem | string>);
    /**
     * [descr:CollectionWidgetOptions.itemTemplate]
    
     */
    get itemTemplate(): any;
    set itemTemplate(value: any);
    /**
     * [descr:CollectionWidgetOptions.keyExpr]
    
     */
    get keyExpr(): ((item: any) => any) | null | string;
    set keyExpr(value: ((item: any) => any) | null | string);
    /**
     * [descr:dxListOptions.menuItems]
    
     */
    get menuItems(): {
        action?: ((itemElement: any, itemData: any) => void);
        text?: string;
    }[];
    set menuItems(value: {
        action?: ((itemElement: any, itemData: any) => void);
        text?: string;
    }[]);
    /**
     * [descr:dxListOptions.menuMode]
    
     */
    get menuMode(): ListMenuMode;
    set menuMode(value: ListMenuMode);
    /**
     * [descr:dxListOptions.nextButtonText]
    
     */
    get nextButtonText(): string;
    set nextButtonText(value: string);
    /**
     * [descr:CollectionWidgetOptions.noDataText]
    
     */
    get noDataText(): string;
    set noDataText(value: string);
    /**
     * [descr:dxListOptions.pageLoadingText]
    
     */
    get pageLoadingText(): string;
    set pageLoadingText(value: string);
    /**
     * [descr:dxListOptions.pageLoadMode]
    
     */
    get pageLoadMode(): PageLoadMode;
    set pageLoadMode(value: PageLoadMode);
    /**
     * [descr:dxListOptions.pulledDownText]
    
     */
    get pulledDownText(): string;
    set pulledDownText(value: string);
    /**
     * [descr:dxListOptions.pullingDownText]
    
     */
    get pullingDownText(): string;
    set pullingDownText(value: string);
    /**
     * [descr:dxListOptions.pullRefreshEnabled]
    
     */
    get pullRefreshEnabled(): boolean;
    set pullRefreshEnabled(value: boolean);
    /**
     * [descr:dxListOptions.refreshingText]
    
     */
    get refreshingText(): string;
    set refreshingText(value: string);
    /**
     * [descr:dxListOptions.repaintChangesOnly]
    
     */
    get repaintChangesOnly(): boolean;
    set repaintChangesOnly(value: boolean);
    /**
     * [descr:DOMComponentOptions.rtlEnabled]
    
     */
    get rtlEnabled(): boolean;
    set rtlEnabled(value: boolean);
    /**
     * [descr:dxListOptions.scrollByContent]
    
     */
    get scrollByContent(): boolean;
    set scrollByContent(value: boolean);
    /**
     * [descr:dxListOptions.scrollByThumb]
    
     */
    get scrollByThumb(): boolean;
    set scrollByThumb(value: boolean);
    /**
     * [descr:dxListOptions.scrollingEnabled]
    
     */
    get scrollingEnabled(): boolean;
    set scrollingEnabled(value: boolean);
    /**
     * [descr:SearchBoxMixinOptions.searchEditorOptions]
    
     */
    get searchEditorOptions(): dxTextBoxOptions<any>;
    set searchEditorOptions(value: dxTextBoxOptions<any>);
    /**
     * [descr:SearchBoxMixinOptions.searchEnabled]
    
     */
    get searchEnabled(): boolean;
    set searchEnabled(value: boolean);
    /**
     * [descr:SearchBoxMixinOptions.searchExpr]
    
     */
    get searchExpr(): Array<Function | string> | Function | string;
    set searchExpr(value: Array<Function | string> | Function | string);
    /**
     * [descr:SearchBoxMixinOptions.searchMode]
    
     */
    get searchMode(): SearchMode;
    set searchMode(value: SearchMode);
    /**
     * [descr:SearchBoxMixinOptions.searchTimeout]
    
     */
    get searchTimeout(): number | undefined;
    set searchTimeout(value: number | undefined);
    /**
     * [descr:SearchBoxMixinOptions.searchValue]
    
     */
    get searchValue(): string;
    set searchValue(value: string);
    /**
     * [descr:dxListOptions.selectAllMode]
    
     */
    get selectAllMode(): SelectAllMode;
    set selectAllMode(value: SelectAllMode);
    /**
     * [descr:dxListOptions.selectAllText]
    
     */
    get selectAllText(): string;
    set selectAllText(value: string);
    /**
     * [descr:dxListOptions.selectByClick]
    
     */
    get selectByClick(): boolean;
    set selectByClick(value: boolean);
    /**
     * [descr:CollectionWidgetOptions.selectedItemKeys]
    
     */
    get selectedItemKeys(): Array<any>;
    set selectedItemKeys(value: Array<any>);
    /**
     * [descr:CollectionWidgetOptions.selectedItems]
    
     */
    get selectedItems(): Array<any>;
    set selectedItems(value: Array<any>);
    /**
     * [descr:dxListOptions.selectionMode]
    
     */
    get selectionMode(): SingleMultipleAllOrNone;
    set selectionMode(value: SingleMultipleAllOrNone);
    /**
     * [descr:dxListOptions.showScrollbar]
    
     */
    get showScrollbar(): ScrollbarMode;
    set showScrollbar(value: ScrollbarMode);
    /**
     * [descr:dxListOptions.showSelectionControls]
    
     */
    get showSelectionControls(): boolean;
    set showSelectionControls(value: boolean);
    /**
     * [descr:WidgetOptions.tabIndex]
    
     */
    get tabIndex(): number;
    set tabIndex(value: number);
    /**
     * [descr:dxListOptions.useNativeScrolling]
    
     */
    get useNativeScrolling(): boolean;
    set useNativeScrolling(value: boolean);
    /**
     * [descr:WidgetOptions.visible]
    
     */
    get visible(): boolean;
    set visible(value: boolean);
    /**
     * [descr:DOMComponentOptions.width]
    
     */
    get width(): number | string | undefined;
    set width(value: number | string | undefined);
    /**
    
     * [descr:dxListOptions.onContentReady]
    
    
     */
    onContentReady: EventEmitter<ContentReadyEvent>;
    /**
    
     * [descr:dxListOptions.onDisposing]
    
    
     */
    onDisposing: EventEmitter<DisposingEvent>;
    /**
    
     * [descr:dxListOptions.onGroupRendered]
    
    
     */
    onGroupRendered: EventEmitter<GroupRenderedEvent>;
    /**
    
     * [descr:dxListOptions.onInitialized]
    
    
     */
    onInitialized: EventEmitter<InitializedEvent>;
    /**
    
     * [descr:dxListOptions.onItemClick]
    
    
     */
    onItemClick: EventEmitter<ItemClickEvent>;
    /**
    
     * [descr:dxListOptions.onItemContextMenu]
    
    
     */
    onItemContextMenu: EventEmitter<ItemContextMenuEvent>;
    /**
    
     * [descr:dxListOptions.onItemDeleted]
    
    
     */
    onItemDeleted: EventEmitter<ItemDeletedEvent>;
    /**
    
     * [descr:dxListOptions.onItemDeleting]
    
    
     */
    onItemDeleting: EventEmitter<ItemDeletingEvent>;
    /**
    
     * [descr:dxListOptions.onItemHold]
    
    
     */
    onItemHold: EventEmitter<ItemHoldEvent>;
    /**
    
     * [descr:dxListOptions.onItemRendered]
    
    
     */
    onItemRendered: EventEmitter<ItemRenderedEvent>;
    /**
    
     * [descr:dxListOptions.onItemReordered]
    
    
     */
    onItemReordered: EventEmitter<ItemReorderedEvent>;
    /**
    
     * [descr:dxListOptions.onItemSwipe]
    
    
     */
    onItemSwipe: EventEmitter<ItemSwipeEvent>;
    /**
    
     * [descr:dxListOptions.onOptionChanged]
    
    
     */
    onOptionChanged: EventEmitter<OptionChangedEvent>;
    /**
    
     * [descr:dxListOptions.onPageLoading]
    
    
     */
    onPageLoading: EventEmitter<PageLoadingEvent>;
    /**
    
     * [descr:dxListOptions.onPullRefresh]
    
    
     */
    onPullRefresh: EventEmitter<PullRefreshEvent>;
    /**
    
     * [descr:dxListOptions.onScroll]
    
    
     */
    onScroll: EventEmitter<ScrollEvent>;
    /**
    
     * [descr:dxListOptions.onSelectAllValueChanged]
    
    
     */
    onSelectAllValueChanged: EventEmitter<SelectAllValueChangedEvent>;
    /**
    
     * [descr:dxListOptions.onSelectionChanged]
    
    
     */
    onSelectionChanged: EventEmitter<SelectionChangedEvent>;
    /**
    
     * [descr:dxListOptions.onSelectionChanging]
    
    
     */
    onSelectionChanging: EventEmitter<SelectionChangingEvent>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    accessKeyChange: EventEmitter<string | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    activeStateEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    allowItemDeletingChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    bounceEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    collapsibleGroupsChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    dataSourceChange: EventEmitter<Array<any | dxListItem | string> | DataSource | DataSourceOptions | null | Store | string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    disabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    displayExprChange: EventEmitter<((item: any) => string) | string | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    elementAttrChange: EventEmitter<Record<string, any>>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    focusStateEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    groupedChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    groupTemplateChange: EventEmitter<any>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    heightChange: EventEmitter<number | string | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    hintChange: EventEmitter<string | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    hoverStateEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    indicateLoadingChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    itemDeleteModeChange: EventEmitter<ItemDeleteMode>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    itemDraggingChange: EventEmitter<dxSortableOptions>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    itemHoldTimeoutChange: EventEmitter<number>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    itemsChange: EventEmitter<Array<any | dxListItem | string>>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    itemTemplateChange: EventEmitter<any>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    keyExprChange: EventEmitter<((item: any) => any) | null | string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    menuItemsChange: EventEmitter<{
        action?: ((itemElement: any, itemData: any) => void);
        text?: string;
    }[]>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    menuModeChange: EventEmitter<ListMenuMode>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    nextButtonTextChange: EventEmitter<string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    noDataTextChange: EventEmitter<string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    pageLoadingTextChange: EventEmitter<string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    pageLoadModeChange: EventEmitter<PageLoadMode>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    pulledDownTextChange: EventEmitter<string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    pullingDownTextChange: EventEmitter<string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    pullRefreshEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    refreshingTextChange: EventEmitter<string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    repaintChangesOnlyChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    rtlEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    scrollByContentChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    scrollByThumbChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    scrollingEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    searchEditorOptionsChange: EventEmitter<dxTextBoxOptions<any>>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    searchEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    searchExprChange: EventEmitter<Array<Function | string> | Function | string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    searchModeChange: EventEmitter<SearchMode>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    searchTimeoutChange: EventEmitter<number | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    searchValueChange: EventEmitter<string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    selectAllModeChange: EventEmitter<SelectAllMode>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    selectAllTextChange: EventEmitter<string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    selectByClickChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    selectedItemKeysChange: EventEmitter<Array<any>>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    selectedItemsChange: EventEmitter<Array<any>>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    selectionModeChange: EventEmitter<SingleMultipleAllOrNone>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    showScrollbarChange: EventEmitter<ScrollbarMode>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    showSelectionControlsChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    tabIndexChange: EventEmitter<number>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    useNativeScrollingChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    visibleChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    widthChange: EventEmitter<number | string | undefined>;
    constructor(elementRef: ElementRef, ngZone: NgZone, templateHost: DxTemplateHost, _watcherHelper: WatcherHelper, _idh: IterableDifferHelper, optionHost: NestedOptionHost, transferState: TransferState, platformId: any);
    protected _createInstance(element: any, options: any): DxList<any, any>;
    ngOnDestroy(): void;
    ngOnChanges(changes: SimpleChanges): void;
    setupChanges(prop: string, changes: SimpleChanges): void;
    ngDoCheck(): void;
    _setOption(name: string, value: any): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxListComponent<any, any>, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxListComponent<any, any>, "dx-list", never, { "accessKey": { "alias": "accessKey"; "required": false; }; "activeStateEnabled": { "alias": "activeStateEnabled"; "required": false; }; "allowItemDeleting": { "alias": "allowItemDeleting"; "required": false; }; "bounceEnabled": { "alias": "bounceEnabled"; "required": false; }; "collapsibleGroups": { "alias": "collapsibleGroups"; "required": false; }; "dataSource": { "alias": "dataSource"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "displayExpr": { "alias": "displayExpr"; "required": false; }; "elementAttr": { "alias": "elementAttr"; "required": false; }; "focusStateEnabled": { "alias": "focusStateEnabled"; "required": false; }; "grouped": { "alias": "grouped"; "required": false; }; "groupTemplate": { "alias": "groupTemplate"; "required": false; }; "height": { "alias": "height"; "required": false; }; "hint": { "alias": "hint"; "required": false; }; "hoverStateEnabled": { "alias": "hoverStateEnabled"; "required": false; }; "indicateLoading": { "alias": "indicateLoading"; "required": false; }; "itemDeleteMode": { "alias": "itemDeleteMode"; "required": false; }; "itemDragging": { "alias": "itemDragging"; "required": false; }; "itemHoldTimeout": { "alias": "itemHoldTimeout"; "required": false; }; "items": { "alias": "items"; "required": false; }; "itemTemplate": { "alias": "itemTemplate"; "required": false; }; "keyExpr": { "alias": "keyExpr"; "required": false; }; "menuItems": { "alias": "menuItems"; "required": false; }; "menuMode": { "alias": "menuMode"; "required": false; }; "nextButtonText": { "alias": "nextButtonText"; "required": false; }; "noDataText": { "alias": "noDataText"; "required": false; }; "pageLoadingText": { "alias": "pageLoadingText"; "required": false; }; "pageLoadMode": { "alias": "pageLoadMode"; "required": false; }; "pulledDownText": { "alias": "pulledDownText"; "required": false; }; "pullingDownText": { "alias": "pullingDownText"; "required": false; }; "pullRefreshEnabled": { "alias": "pullRefreshEnabled"; "required": false; }; "refreshingText": { "alias": "refreshingText"; "required": false; }; "repaintChangesOnly": { "alias": "repaintChangesOnly"; "required": false; }; "rtlEnabled": { "alias": "rtlEnabled"; "required": false; }; "scrollByContent": { "alias": "scrollByContent"; "required": false; }; "scrollByThumb": { "alias": "scrollByThumb"; "required": false; }; "scrollingEnabled": { "alias": "scrollingEnabled"; "required": false; }; "searchEditorOptions": { "alias": "searchEditorOptions"; "required": false; }; "searchEnabled": { "alias": "searchEnabled"; "required": false; }; "searchExpr": { "alias": "searchExpr"; "required": false; }; "searchMode": { "alias": "searchMode"; "required": false; }; "searchTimeout": { "alias": "searchTimeout"; "required": false; }; "searchValue": { "alias": "searchValue"; "required": false; }; "selectAllMode": { "alias": "selectAllMode"; "required": false; }; "selectAllText": { "alias": "selectAllText"; "required": false; }; "selectByClick": { "alias": "selectByClick"; "required": false; }; "selectedItemKeys": { "alias": "selectedItemKeys"; "required": false; }; "selectedItems": { "alias": "selectedItems"; "required": false; }; "selectionMode": { "alias": "selectionMode"; "required": false; }; "showScrollbar": { "alias": "showScrollbar"; "required": false; }; "showSelectionControls": { "alias": "showSelectionControls"; "required": false; }; "tabIndex": { "alias": "tabIndex"; "required": false; }; "useNativeScrolling": { "alias": "useNativeScrolling"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, { "onContentReady": "onContentReady"; "onDisposing": "onDisposing"; "onGroupRendered": "onGroupRendered"; "onInitialized": "onInitialized"; "onItemClick": "onItemClick"; "onItemContextMenu": "onItemContextMenu"; "onItemDeleted": "onItemDeleted"; "onItemDeleting": "onItemDeleting"; "onItemHold": "onItemHold"; "onItemRendered": "onItemRendered"; "onItemReordered": "onItemReordered"; "onItemSwipe": "onItemSwipe"; "onOptionChanged": "onOptionChanged"; "onPageLoading": "onPageLoading"; "onPullRefresh": "onPullRefresh"; "onScroll": "onScroll"; "onSelectAllValueChanged": "onSelectAllValueChanged"; "onSelectionChanged": "onSelectionChanged"; "onSelectionChanging": "onSelectionChanging"; "accessKeyChange": "accessKeyChange"; "activeStateEnabledChange": "activeStateEnabledChange"; "allowItemDeletingChange": "allowItemDeletingChange"; "bounceEnabledChange": "bounceEnabledChange"; "collapsibleGroupsChange": "collapsibleGroupsChange"; "dataSourceChange": "dataSourceChange"; "disabledChange": "disabledChange"; "displayExprChange": "displayExprChange"; "elementAttrChange": "elementAttrChange"; "focusStateEnabledChange": "focusStateEnabledChange"; "groupedChange": "groupedChange"; "groupTemplateChange": "groupTemplateChange"; "heightChange": "heightChange"; "hintChange": "hintChange"; "hoverStateEnabledChange": "hoverStateEnabledChange"; "indicateLoadingChange": "indicateLoadingChange"; "itemDeleteModeChange": "itemDeleteModeChange"; "itemDraggingChange": "itemDraggingChange"; "itemHoldTimeoutChange": "itemHoldTimeoutChange"; "itemsChange": "itemsChange"; "itemTemplateChange": "itemTemplateChange"; "keyExprChange": "keyExprChange"; "menuItemsChange": "menuItemsChange"; "menuModeChange": "menuModeChange"; "nextButtonTextChange": "nextButtonTextChange"; "noDataTextChange": "noDataTextChange"; "pageLoadingTextChange": "pageLoadingTextChange"; "pageLoadModeChange": "pageLoadModeChange"; "pulledDownTextChange": "pulledDownTextChange"; "pullingDownTextChange": "pullingDownTextChange"; "pullRefreshEnabledChange": "pullRefreshEnabledChange"; "refreshingTextChange": "refreshingTextChange"; "repaintChangesOnlyChange": "repaintChangesOnlyChange"; "rtlEnabledChange": "rtlEnabledChange"; "scrollByContentChange": "scrollByContentChange"; "scrollByThumbChange": "scrollByThumbChange"; "scrollingEnabledChange": "scrollingEnabledChange"; "searchEditorOptionsChange": "searchEditorOptionsChange"; "searchEnabledChange": "searchEnabledChange"; "searchExprChange": "searchExprChange"; "searchModeChange": "searchModeChange"; "searchTimeoutChange": "searchTimeoutChange"; "searchValueChange": "searchValueChange"; "selectAllModeChange": "selectAllModeChange"; "selectAllTextChange": "selectAllTextChange"; "selectByClickChange": "selectByClickChange"; "selectedItemKeysChange": "selectedItemKeysChange"; "selectedItemsChange": "selectedItemsChange"; "selectionModeChange": "selectionModeChange"; "showScrollbarChange": "showScrollbarChange"; "showSelectionControlsChange": "showSelectionControlsChange"; "tabIndexChange": "tabIndexChange"; "useNativeScrollingChange": "useNativeScrollingChange"; "visibleChange": "visibleChange"; "widthChange": "widthChange"; }, ["_buttonsContentChildren", "_itemsContentChildren", "_menuItemsContentChildren"], never, true, never>;
}
declare class DxListModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxListModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxListModule, never, [typeof DxListComponent, typeof i1.DxoItemDraggingModule, typeof i1.DxoCursorOffsetModule, typeof i1.DxiItemModule, typeof i1.DxoSearchEditorOptionsModule, typeof i1.DxiButtonModule, typeof i1.DxoOptionsModule, typeof i2.DxiListButtonModule, typeof i2.DxoListCursorOffsetModule, typeof i2.DxiListItemModule, typeof i2.DxoListItemDraggingModule, typeof i2.DxiListMenuItemModule, typeof i2.DxoListOptionsModule, typeof i2.DxoListSearchEditorOptionsModule, typeof i3.DxIntegrationModule, typeof i3.DxTemplateModule], [typeof DxListComponent, typeof i1.DxoItemDraggingModule, typeof i1.DxoCursorOffsetModule, typeof i1.DxiItemModule, typeof i1.DxoSearchEditorOptionsModule, typeof i1.DxiButtonModule, typeof i1.DxoOptionsModule, typeof i2.DxiListButtonModule, typeof i2.DxoListCursorOffsetModule, typeof i2.DxiListItemModule, typeof i2.DxoListItemDraggingModule, typeof i2.DxiListMenuItemModule, typeof i2.DxoListOptionsModule, typeof i2.DxoListSearchEditorOptionsModule, typeof i3.DxTemplateModule]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxListModule>;
}

export { DxListComponent, DxListModule };
//# sourceMappingURL=index.d.ts.map
