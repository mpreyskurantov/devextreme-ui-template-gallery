import * as i0 from '@angular/core';
import { OnDestroy, OnInit } from '@angular/core';
import { Format, VerticalEdge, TooltipShowMode } from 'devextreme/common';
import { NestedOption, NestedOptionHost } from 'devextreme-angular/core';
import { Format as Format$1 } from 'devextreme/common/core/localization';

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoSliderFormatComponent extends NestedOption implements OnDestroy, OnInit {
    get currency(): string;
    set currency(value: string);
    get formatter(): ((value: number | Date) => string);
    set formatter(value: ((value: number | Date) => string));
    get parser(): ((value: string) => number | Date);
    set parser(value: ((value: string) => number | Date));
    get precision(): number;
    set precision(value: number);
    get type(): Format | string;
    set type(value: Format | string);
    get useCurrencyAccountingStyle(): boolean;
    set useCurrencyAccountingStyle(value: boolean);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoSliderFormatComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoSliderFormatComponent, "dxo-slider-format", never, { "currency": { "alias": "currency"; "required": false; }; "formatter": { "alias": "formatter"; "required": false; }; "parser": { "alias": "parser"; "required": false; }; "precision": { "alias": "precision"; "required": false; }; "type": { "alias": "type"; "required": false; }; "useCurrencyAccountingStyle": { "alias": "useCurrencyAccountingStyle"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoSliderFormatModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoSliderFormatModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoSliderFormatModule, never, [typeof DxoSliderFormatComponent], [typeof DxoSliderFormatComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoSliderFormatModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoSliderLabelComponent extends NestedOption implements OnDestroy, OnInit {
    get format(): Format$1;
    set format(value: Format$1);
    get position(): VerticalEdge;
    set position(value: VerticalEdge);
    get visible(): boolean;
    set visible(value: boolean);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoSliderLabelComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoSliderLabelComponent, "dxo-slider-label", never, { "format": { "alias": "format"; "required": false; }; "position": { "alias": "position"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoSliderLabelModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoSliderLabelModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoSliderLabelModule, never, [typeof DxoSliderLabelComponent], [typeof DxoSliderLabelComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoSliderLabelModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoSliderTooltipComponent extends NestedOption implements OnDestroy, OnInit {
    get enabled(): boolean;
    set enabled(value: boolean);
    get format(): Format$1;
    set format(value: Format$1);
    get position(): VerticalEdge;
    set position(value: VerticalEdge);
    get showMode(): TooltipShowMode;
    set showMode(value: TooltipShowMode);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoSliderTooltipComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoSliderTooltipComponent, "dxo-slider-tooltip", never, { "enabled": { "alias": "enabled"; "required": false; }; "format": { "alias": "format"; "required": false; }; "position": { "alias": "position"; "required": false; }; "showMode": { "alias": "showMode"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoSliderTooltipModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoSliderTooltipModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoSliderTooltipModule, never, [typeof DxoSliderTooltipComponent], [typeof DxoSliderTooltipComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoSliderTooltipModule>;
}

export { DxoSliderFormatComponent, DxoSliderFormatModule, DxoSliderLabelComponent, DxoSliderLabelModule, DxoSliderTooltipComponent, DxoSliderTooltipModule };
//# sourceMappingURL=index.d.ts.map
