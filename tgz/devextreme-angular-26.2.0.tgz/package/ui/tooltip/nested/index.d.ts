import * as i0 from '@angular/core';
import { OnDestroy, OnInit } from '@angular/core';
import { AnimationConfig, CollisionResolution, PositionConfig, AnimationState, AnimationType, CollisionResolutionCombination } from 'devextreme/common/core/animation';
import { NestedOption, NestedOptionHost } from 'devextreme-angular/core';
import { HorizontalAlignment, VerticalAlignment, Direction, PositionAlignment } from 'devextreme/common';

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoTooltipAnimationComponent extends NestedOption implements OnDestroy, OnInit {
    get hide(): AnimationConfig;
    set hide(value: AnimationConfig);
    get show(): AnimationConfig;
    set show(value: AnimationConfig);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTooltipAnimationComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoTooltipAnimationComponent, "dxo-tooltip-animation", never, { "hide": { "alias": "hide"; "required": false; }; "show": { "alias": "show"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoTooltipAnimationModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTooltipAnimationModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoTooltipAnimationModule, never, [typeof DxoTooltipAnimationComponent], [typeof DxoTooltipAnimationComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoTooltipAnimationModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoTooltipAtComponent extends NestedOption implements OnDestroy, OnInit {
    get x(): HorizontalAlignment;
    set x(value: HorizontalAlignment);
    get y(): VerticalAlignment;
    set y(value: VerticalAlignment);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTooltipAtComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoTooltipAtComponent, "dxo-tooltip-at", never, { "x": { "alias": "x"; "required": false; }; "y": { "alias": "y"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoTooltipAtModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTooltipAtModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoTooltipAtModule, never, [typeof DxoTooltipAtComponent], [typeof DxoTooltipAtComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoTooltipAtModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoTooltipBoundaryOffsetComponent extends NestedOption implements OnDestroy, OnInit {
    get x(): number;
    set x(value: number);
    get y(): number;
    set y(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTooltipBoundaryOffsetComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoTooltipBoundaryOffsetComponent, "dxo-tooltip-boundary-offset", never, { "x": { "alias": "x"; "required": false; }; "y": { "alias": "y"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoTooltipBoundaryOffsetModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTooltipBoundaryOffsetModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoTooltipBoundaryOffsetModule, never, [typeof DxoTooltipBoundaryOffsetComponent], [typeof DxoTooltipBoundaryOffsetComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoTooltipBoundaryOffsetModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoTooltipCollisionComponent extends NestedOption implements OnDestroy, OnInit {
    get x(): CollisionResolution;
    set x(value: CollisionResolution);
    get y(): CollisionResolution;
    set y(value: CollisionResolution);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTooltipCollisionComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoTooltipCollisionComponent, "dxo-tooltip-collision", never, { "x": { "alias": "x"; "required": false; }; "y": { "alias": "y"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoTooltipCollisionModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTooltipCollisionModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoTooltipCollisionModule, never, [typeof DxoTooltipCollisionComponent], [typeof DxoTooltipCollisionComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoTooltipCollisionModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoTooltipFromComponent extends NestedOption implements OnDestroy, OnInit {
    get left(): number;
    set left(value: number);
    get opacity(): number;
    set opacity(value: number);
    get position(): PositionConfig;
    set position(value: PositionConfig);
    get scale(): number;
    set scale(value: number);
    get top(): number;
    set top(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTooltipFromComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoTooltipFromComponent, "dxo-tooltip-from", never, { "left": { "alias": "left"; "required": false; }; "opacity": { "alias": "opacity"; "required": false; }; "position": { "alias": "position"; "required": false; }; "scale": { "alias": "scale"; "required": false; }; "top": { "alias": "top"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoTooltipFromModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTooltipFromModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoTooltipFromModule, never, [typeof DxoTooltipFromComponent], [typeof DxoTooltipFromComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoTooltipFromModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoTooltipHideEventComponent extends NestedOption implements OnDestroy, OnInit {
    get delay(): number | undefined;
    set delay(value: number | undefined);
    get name(): string | undefined;
    set name(value: string | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTooltipHideEventComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoTooltipHideEventComponent, "dxo-tooltip-hide-event", never, { "delay": { "alias": "delay"; "required": false; }; "name": { "alias": "name"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoTooltipHideEventModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTooltipHideEventModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoTooltipHideEventModule, never, [typeof DxoTooltipHideEventComponent], [typeof DxoTooltipHideEventComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoTooltipHideEventModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoTooltipHideComponent extends NestedOption implements OnDestroy, OnInit {
    get complete(): (($element: any, config: AnimationConfig) => void);
    set complete(value: (($element: any, config: AnimationConfig) => void));
    get delay(): number;
    set delay(value: number);
    get direction(): Direction | undefined;
    set direction(value: Direction | undefined);
    get duration(): number;
    set duration(value: number);
    get easing(): string;
    set easing(value: string);
    get from(): AnimationState;
    set from(value: AnimationState);
    get staggerDelay(): number | undefined;
    set staggerDelay(value: number | undefined);
    get start(): (($element: any, config: AnimationConfig) => void);
    set start(value: (($element: any, config: AnimationConfig) => void));
    get to(): AnimationState;
    set to(value: AnimationState);
    get type(): AnimationType;
    set type(value: AnimationType);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTooltipHideComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoTooltipHideComponent, "dxo-tooltip-hide", never, { "complete": { "alias": "complete"; "required": false; }; "delay": { "alias": "delay"; "required": false; }; "direction": { "alias": "direction"; "required": false; }; "duration": { "alias": "duration"; "required": false; }; "easing": { "alias": "easing"; "required": false; }; "from": { "alias": "from"; "required": false; }; "staggerDelay": { "alias": "staggerDelay"; "required": false; }; "start": { "alias": "start"; "required": false; }; "to": { "alias": "to"; "required": false; }; "type": { "alias": "type"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoTooltipHideModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTooltipHideModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoTooltipHideModule, never, [typeof DxoTooltipHideComponent], [typeof DxoTooltipHideComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoTooltipHideModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoTooltipMyComponent extends NestedOption implements OnDestroy, OnInit {
    get x(): HorizontalAlignment;
    set x(value: HorizontalAlignment);
    get y(): VerticalAlignment;
    set y(value: VerticalAlignment);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTooltipMyComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoTooltipMyComponent, "dxo-tooltip-my", never, { "x": { "alias": "x"; "required": false; }; "y": { "alias": "y"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoTooltipMyModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTooltipMyModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoTooltipMyModule, never, [typeof DxoTooltipMyComponent], [typeof DxoTooltipMyComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoTooltipMyModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoTooltipOffsetComponent extends NestedOption implements OnDestroy, OnInit {
    get x(): number;
    set x(value: number);
    get y(): number;
    set y(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTooltipOffsetComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoTooltipOffsetComponent, "dxo-tooltip-offset", never, { "x": { "alias": "x"; "required": false; }; "y": { "alias": "y"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoTooltipOffsetModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTooltipOffsetModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoTooltipOffsetModule, never, [typeof DxoTooltipOffsetComponent], [typeof DxoTooltipOffsetComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoTooltipOffsetModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoTooltipPositionComponent extends NestedOption implements OnDestroy, OnInit {
    get at(): PositionAlignment | {
        x?: HorizontalAlignment;
        y?: VerticalAlignment;
    };
    set at(value: PositionAlignment | {
        x?: HorizontalAlignment;
        y?: VerticalAlignment;
    });
    get boundary(): any | string;
    set boundary(value: any | string);
    get boundaryOffset(): string | {
        x?: number;
        y?: number;
    };
    set boundaryOffset(value: string | {
        x?: number;
        y?: number;
    });
    get collision(): CollisionResolutionCombination | {
        x?: CollisionResolution;
        y?: CollisionResolution;
    };
    set collision(value: CollisionResolutionCombination | {
        x?: CollisionResolution;
        y?: CollisionResolution;
    });
    get my(): PositionAlignment | {
        x?: HorizontalAlignment;
        y?: VerticalAlignment;
    };
    set my(value: PositionAlignment | {
        x?: HorizontalAlignment;
        y?: VerticalAlignment;
    });
    get of(): any | string;
    set of(value: any | string);
    get offset(): string | {
        x?: number;
        y?: number;
    };
    set offset(value: string | {
        x?: number;
        y?: number;
    });
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTooltipPositionComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoTooltipPositionComponent, "dxo-tooltip-position", never, { "at": { "alias": "at"; "required": false; }; "boundary": { "alias": "boundary"; "required": false; }; "boundaryOffset": { "alias": "boundaryOffset"; "required": false; }; "collision": { "alias": "collision"; "required": false; }; "my": { "alias": "my"; "required": false; }; "of": { "alias": "of"; "required": false; }; "offset": { "alias": "offset"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoTooltipPositionModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTooltipPositionModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoTooltipPositionModule, never, [typeof DxoTooltipPositionComponent], [typeof DxoTooltipPositionComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoTooltipPositionModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoTooltipShowEventComponent extends NestedOption implements OnDestroy, OnInit {
    get delay(): number | undefined;
    set delay(value: number | undefined);
    get name(): string | undefined;
    set name(value: string | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTooltipShowEventComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoTooltipShowEventComponent, "dxo-tooltip-show-event", never, { "delay": { "alias": "delay"; "required": false; }; "name": { "alias": "name"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoTooltipShowEventModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTooltipShowEventModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoTooltipShowEventModule, never, [typeof DxoTooltipShowEventComponent], [typeof DxoTooltipShowEventComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoTooltipShowEventModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoTooltipShowComponent extends NestedOption implements OnDestroy, OnInit {
    get complete(): (($element: any, config: AnimationConfig) => void);
    set complete(value: (($element: any, config: AnimationConfig) => void));
    get delay(): number;
    set delay(value: number);
    get direction(): Direction | undefined;
    set direction(value: Direction | undefined);
    get duration(): number;
    set duration(value: number);
    get easing(): string;
    set easing(value: string);
    get from(): AnimationState;
    set from(value: AnimationState);
    get staggerDelay(): number | undefined;
    set staggerDelay(value: number | undefined);
    get start(): (($element: any, config: AnimationConfig) => void);
    set start(value: (($element: any, config: AnimationConfig) => void));
    get to(): AnimationState;
    set to(value: AnimationState);
    get type(): AnimationType;
    set type(value: AnimationType);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTooltipShowComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoTooltipShowComponent, "dxo-tooltip-show", never, { "complete": { "alias": "complete"; "required": false; }; "delay": { "alias": "delay"; "required": false; }; "direction": { "alias": "direction"; "required": false; }; "duration": { "alias": "duration"; "required": false; }; "easing": { "alias": "easing"; "required": false; }; "from": { "alias": "from"; "required": false; }; "staggerDelay": { "alias": "staggerDelay"; "required": false; }; "start": { "alias": "start"; "required": false; }; "to": { "alias": "to"; "required": false; }; "type": { "alias": "type"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoTooltipShowModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTooltipShowModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoTooltipShowModule, never, [typeof DxoTooltipShowComponent], [typeof DxoTooltipShowComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoTooltipShowModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoTooltipToComponent extends NestedOption implements OnDestroy, OnInit {
    get left(): number;
    set left(value: number);
    get opacity(): number;
    set opacity(value: number);
    get position(): PositionConfig;
    set position(value: PositionConfig);
    get scale(): number;
    set scale(value: number);
    get top(): number;
    set top(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTooltipToComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoTooltipToComponent, "dxo-tooltip-to", never, { "left": { "alias": "left"; "required": false; }; "opacity": { "alias": "opacity"; "required": false; }; "position": { "alias": "position"; "required": false; }; "scale": { "alias": "scale"; "required": false; }; "top": { "alias": "top"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoTooltipToModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTooltipToModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoTooltipToModule, never, [typeof DxoTooltipToComponent], [typeof DxoTooltipToComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoTooltipToModule>;
}

export { DxoTooltipAnimationComponent, DxoTooltipAnimationModule, DxoTooltipAtComponent, DxoTooltipAtModule, DxoTooltipBoundaryOffsetComponent, DxoTooltipBoundaryOffsetModule, DxoTooltipCollisionComponent, DxoTooltipCollisionModule, DxoTooltipFromComponent, DxoTooltipFromModule, DxoTooltipHideComponent, DxoTooltipHideEventComponent, DxoTooltipHideEventModule, DxoTooltipHideModule, DxoTooltipMyComponent, DxoTooltipMyModule, DxoTooltipOffsetComponent, DxoTooltipOffsetModule, DxoTooltipPositionComponent, DxoTooltipPositionModule, DxoTooltipShowComponent, DxoTooltipShowEventComponent, DxoTooltipShowEventModule, DxoTooltipShowModule, DxoTooltipToComponent, DxoTooltipToModule };
//# sourceMappingURL=index.d.ts.map
