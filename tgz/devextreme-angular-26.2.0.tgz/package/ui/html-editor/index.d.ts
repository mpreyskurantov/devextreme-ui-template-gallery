import * as i0 from '@angular/core';
import { OnDestroy, OnChanges, DoCheck, QueryList, EventEmitter, ElementRef, NgZone, TransferState, SimpleChanges } from '@angular/core';
import { AIIntegration } from 'devextreme/common/ai-integration';
import DxHtmlEditor, { Converter, dxHtmlEditorImageUpload, dxHtmlEditorMediaResizing, dxHtmlEditorMention, dxHtmlEditorTableContextMenu, dxHtmlEditorTableResizing, dxHtmlEditorToolbar, dxHtmlEditorVariables, ContentReadyEvent, DisposingEvent, FocusInEvent, FocusOutEvent, InitializedEvent, OptionChangedEvent, ValueChangedEvent } from 'devextreme/ui/html_editor';
import { EditorStyle, ValidationMessageMode, Position, ValidationStatus } from 'devextreme/common';
import { ControlValueAccessor } from '@angular/forms';
import * as i3 from 'devextreme-angular/core';
import { DxComponent, CollectionNestedOption, DxTemplateHost, WatcherHelper, IterableDifferHelper, NestedOptionHost } from 'devextreme-angular/core';
import * as i1 from 'devextreme-angular/ui/nested';
import * as i2 from 'devextreme-angular/ui/html-editor/nested';
export * from 'devextreme-angular/ui/html-editor/nested';
import * as html_editor_types from 'devextreme/ui/html_editor_types';
export { html_editor_types as DxHtmlEditorTypes };

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

/**
 * [descr:dxHtmlEditor]

 */
declare class DxHtmlEditorComponent extends DxComponent implements OnDestroy, ControlValueAccessor, OnChanges, DoCheck {
    private _watcherHelper;
    private _idh;
    set _commandsContentChildren(value: QueryList<CollectionNestedOption>);
    set _itemsContentChildren(value: QueryList<CollectionNestedOption>);
    set _mentionsContentChildren(value: QueryList<CollectionNestedOption>);
    set _tabsContentChildren(value: QueryList<CollectionNestedOption>);
    instance: DxHtmlEditor;
    /**
     * [descr:WidgetOptions.accessKey]
    
     */
    get accessKey(): string | undefined;
    set accessKey(value: string | undefined);
    /**
     * [descr:WidgetOptions.activeStateEnabled]
    
     */
    get activeStateEnabled(): boolean;
    set activeStateEnabled(value: boolean);
    /**
     * [descr:dxHtmlEditorOptions.aiIntegration]
    
     */
    get aiIntegration(): AIIntegration | undefined;
    set aiIntegration(value: AIIntegration | undefined);
    /**
     * [descr:dxHtmlEditorOptions.allowSoftLineBreak]
    
     */
    get allowSoftLineBreak(): boolean;
    set allowSoftLineBreak(value: boolean);
    /**
     * [descr:dxHtmlEditorOptions.converter]
    
     */
    get converter(): Converter | undefined;
    set converter(value: Converter | undefined);
    /**
     * [descr:dxHtmlEditorOptions.customizeModules]
    
     */
    get customizeModules(): ((config: any) => void);
    set customizeModules(value: ((config: any) => void));
    /**
     * [descr:WidgetOptions.disabled]
    
     */
    get disabled(): boolean;
    set disabled(value: boolean);
    /**
     * [descr:DOMComponentOptions.elementAttr]
    
     */
    get elementAttr(): Record<string, any>;
    set elementAttr(value: Record<string, any>);
    /**
     * [descr:dxHtmlEditorOptions.focusStateEnabled]
    
     */
    get focusStateEnabled(): boolean;
    set focusStateEnabled(value: boolean);
    /**
     * [descr:DOMComponentOptions.height]
    
     */
    get height(): number | string | undefined;
    set height(value: number | string | undefined);
    /**
     * [descr:WidgetOptions.hint]
    
     */
    get hint(): string | undefined;
    set hint(value: string | undefined);
    /**
     * [descr:WidgetOptions.hoverStateEnabled]
    
     */
    get hoverStateEnabled(): boolean;
    set hoverStateEnabled(value: boolean);
    /**
     * [descr:dxHtmlEditorOptions.imageUpload]
    
     */
    get imageUpload(): dxHtmlEditorImageUpload;
    set imageUpload(value: dxHtmlEditorImageUpload);
    /**
     * [descr:EditorOptions.isDirty]
    
     */
    get isDirty(): boolean;
    set isDirty(value: boolean);
    /**
     * [descr:EditorOptions.isValid]
    
     */
    get isValid(): boolean;
    set isValid(value: boolean);
    /**
     * [descr:dxHtmlEditorOptions.mediaResizing]
    
     */
    get mediaResizing(): dxHtmlEditorMediaResizing | null;
    set mediaResizing(value: dxHtmlEditorMediaResizing | null);
    /**
     * [descr:dxHtmlEditorOptions.mentions]
    
     */
    get mentions(): Array<dxHtmlEditorMention> | null;
    set mentions(value: Array<dxHtmlEditorMention> | null);
    /**
     * [descr:dxHtmlEditorOptions.name]
    
     */
    get name(): string;
    set name(value: string);
    /**
     * [descr:dxHtmlEditorOptions.placeholder]
    
     */
    get placeholder(): string;
    set placeholder(value: string);
    /**
     * [descr:EditorOptions.readOnly]
    
     */
    get readOnly(): boolean;
    set readOnly(value: boolean);
    /**
     * [descr:DOMComponentOptions.rtlEnabled]
    
     */
    get rtlEnabled(): boolean;
    set rtlEnabled(value: boolean);
    /**
     * [descr:dxHtmlEditorOptions.stylingMode]
    
     */
    get stylingMode(): EditorStyle;
    set stylingMode(value: EditorStyle);
    /**
     * [descr:WidgetOptions.tabIndex]
    
     */
    get tabIndex(): number;
    set tabIndex(value: number);
    /**
     * [descr:dxHtmlEditorOptions.tableContextMenu]
    
     */
    get tableContextMenu(): dxHtmlEditorTableContextMenu | null;
    set tableContextMenu(value: dxHtmlEditorTableContextMenu | null);
    /**
     * [descr:dxHtmlEditorOptions.tableResizing]
    
     */
    get tableResizing(): dxHtmlEditorTableResizing | null;
    set tableResizing(value: dxHtmlEditorTableResizing | null);
    /**
     * [descr:dxHtmlEditorOptions.toolbar]
    
     */
    get toolbar(): dxHtmlEditorToolbar | null;
    set toolbar(value: dxHtmlEditorToolbar | null);
    /**
     * [descr:EditorOptions.validationError]
    
     */
    get validationError(): any | null;
    set validationError(value: any | null);
    /**
     * [descr:EditorOptions.validationErrors]
    
     */
    get validationErrors(): Array<any> | null;
    set validationErrors(value: Array<any> | null);
    /**
     * [descr:EditorOptions.validationMessageMode]
    
     */
    get validationMessageMode(): ValidationMessageMode;
    set validationMessageMode(value: ValidationMessageMode);
    /**
     * [descr:EditorOptions.validationMessagePosition]
    
     */
    get validationMessagePosition(): Position;
    set validationMessagePosition(value: Position);
    /**
     * [descr:EditorOptions.validationStatus]
    
     */
    get validationStatus(): ValidationStatus;
    set validationStatus(value: ValidationStatus);
    /**
     * [descr:EditorOptions.value]
    
     */
    get value(): any | null;
    set value(value: any | null);
    /**
     * [descr:dxHtmlEditorOptions.variables]
    
     */
    get variables(): dxHtmlEditorVariables | null;
    set variables(value: dxHtmlEditorVariables | null);
    /**
     * [descr:WidgetOptions.visible]
    
     */
    get visible(): boolean;
    set visible(value: boolean);
    /**
     * [descr:DOMComponentOptions.width]
    
     */
    get width(): number | string | undefined;
    set width(value: number | string | undefined);
    /**
    
     * [descr:dxHtmlEditorOptions.onContentReady]
    
    
     */
    onContentReady: EventEmitter<ContentReadyEvent>;
    /**
    
     * [descr:dxHtmlEditorOptions.onDisposing]
    
    
     */
    onDisposing: EventEmitter<DisposingEvent>;
    /**
    
     * [descr:dxHtmlEditorOptions.onFocusIn]
    
    
     */
    onFocusIn: EventEmitter<FocusInEvent>;
    /**
    
     * [descr:dxHtmlEditorOptions.onFocusOut]
    
    
     */
    onFocusOut: EventEmitter<FocusOutEvent>;
    /**
    
     * [descr:dxHtmlEditorOptions.onInitialized]
    
    
     */
    onInitialized: EventEmitter<InitializedEvent>;
    /**
    
     * [descr:dxHtmlEditorOptions.onOptionChanged]
    
    
     */
    onOptionChanged: EventEmitter<OptionChangedEvent>;
    /**
    
     * [descr:dxHtmlEditorOptions.onValueChanged]
    
    
     */
    onValueChanged: EventEmitter<ValueChangedEvent>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    accessKeyChange: EventEmitter<string | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    activeStateEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    aiIntegrationChange: EventEmitter<AIIntegration | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    allowSoftLineBreakChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    converterChange: EventEmitter<Converter | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    customizeModulesChange: EventEmitter<((config: any) => void)>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    disabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    elementAttrChange: EventEmitter<Record<string, any>>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    focusStateEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    heightChange: EventEmitter<number | string | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    hintChange: EventEmitter<string | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    hoverStateEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    imageUploadChange: EventEmitter<dxHtmlEditorImageUpload>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    isDirtyChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    isValidChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    mediaResizingChange: EventEmitter<dxHtmlEditorMediaResizing | null>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    mentionsChange: EventEmitter<Array<dxHtmlEditorMention> | null>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    nameChange: EventEmitter<string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    placeholderChange: EventEmitter<string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    readOnlyChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    rtlEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    stylingModeChange: EventEmitter<EditorStyle>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    tabIndexChange: EventEmitter<number>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    tableContextMenuChange: EventEmitter<dxHtmlEditorTableContextMenu | null>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    tableResizingChange: EventEmitter<dxHtmlEditorTableResizing | null>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    toolbarChange: EventEmitter<dxHtmlEditorToolbar | null>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    validationErrorChange: EventEmitter<any | null>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    validationErrorsChange: EventEmitter<Array<any> | null>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    validationMessageModeChange: EventEmitter<ValidationMessageMode>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    validationMessagePositionChange: EventEmitter<Position>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    validationStatusChange: EventEmitter<ValidationStatus>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    valueChange: EventEmitter<any | null>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    variablesChange: EventEmitter<dxHtmlEditorVariables | null>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    visibleChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    widthChange: EventEmitter<number | string | undefined>;
    /**
    
     * [descr:undefined]
    
    
     */
    onBlur: EventEmitter<any>;
    change(_: any): void;
    touched: (_: any) => void;
    constructor(elementRef: ElementRef, ngZone: NgZone, templateHost: DxTemplateHost, _watcherHelper: WatcherHelper, _idh: IterableDifferHelper, optionHost: NestedOptionHost, transferState: TransferState, platformId: any);
    protected _createInstance(element: any, options: any): DxHtmlEditor;
    writeValue(value: any): void;
    setDisabledState(isDisabled: boolean): void;
    registerOnChange(fn: (_: any) => void): void;
    registerOnTouched(fn: () => void): void;
    _createWidget(element: any): void;
    ngOnDestroy(): void;
    ngOnChanges(changes: SimpleChanges): void;
    setupChanges(prop: string, changes: SimpleChanges): void;
    ngDoCheck(): void;
    _setOption(name: string, value: any): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxHtmlEditorComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxHtmlEditorComponent, "dx-html-editor", never, { "accessKey": { "alias": "accessKey"; "required": false; }; "activeStateEnabled": { "alias": "activeStateEnabled"; "required": false; }; "aiIntegration": { "alias": "aiIntegration"; "required": false; }; "allowSoftLineBreak": { "alias": "allowSoftLineBreak"; "required": false; }; "converter": { "alias": "converter"; "required": false; }; "customizeModules": { "alias": "customizeModules"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "elementAttr": { "alias": "elementAttr"; "required": false; }; "focusStateEnabled": { "alias": "focusStateEnabled"; "required": false; }; "height": { "alias": "height"; "required": false; }; "hint": { "alias": "hint"; "required": false; }; "hoverStateEnabled": { "alias": "hoverStateEnabled"; "required": false; }; "imageUpload": { "alias": "imageUpload"; "required": false; }; "isDirty": { "alias": "isDirty"; "required": false; }; "isValid": { "alias": "isValid"; "required": false; }; "mediaResizing": { "alias": "mediaResizing"; "required": false; }; "mentions": { "alias": "mentions"; "required": false; }; "name": { "alias": "name"; "required": false; }; "placeholder": { "alias": "placeholder"; "required": false; }; "readOnly": { "alias": "readOnly"; "required": false; }; "rtlEnabled": { "alias": "rtlEnabled"; "required": false; }; "stylingMode": { "alias": "stylingMode"; "required": false; }; "tabIndex": { "alias": "tabIndex"; "required": false; }; "tableContextMenu": { "alias": "tableContextMenu"; "required": false; }; "tableResizing": { "alias": "tableResizing"; "required": false; }; "toolbar": { "alias": "toolbar"; "required": false; }; "validationError": { "alias": "validationError"; "required": false; }; "validationErrors": { "alias": "validationErrors"; "required": false; }; "validationMessageMode": { "alias": "validationMessageMode"; "required": false; }; "validationMessagePosition": { "alias": "validationMessagePosition"; "required": false; }; "validationStatus": { "alias": "validationStatus"; "required": false; }; "value": { "alias": "value"; "required": false; }; "variables": { "alias": "variables"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, { "onContentReady": "onContentReady"; "onDisposing": "onDisposing"; "onFocusIn": "onFocusIn"; "onFocusOut": "onFocusOut"; "onInitialized": "onInitialized"; "onOptionChanged": "onOptionChanged"; "onValueChanged": "onValueChanged"; "accessKeyChange": "accessKeyChange"; "activeStateEnabledChange": "activeStateEnabledChange"; "aiIntegrationChange": "aiIntegrationChange"; "allowSoftLineBreakChange": "allowSoftLineBreakChange"; "converterChange": "converterChange"; "customizeModulesChange": "customizeModulesChange"; "disabledChange": "disabledChange"; "elementAttrChange": "elementAttrChange"; "focusStateEnabledChange": "focusStateEnabledChange"; "heightChange": "heightChange"; "hintChange": "hintChange"; "hoverStateEnabledChange": "hoverStateEnabledChange"; "imageUploadChange": "imageUploadChange"; "isDirtyChange": "isDirtyChange"; "isValidChange": "isValidChange"; "mediaResizingChange": "mediaResizingChange"; "mentionsChange": "mentionsChange"; "nameChange": "nameChange"; "placeholderChange": "placeholderChange"; "readOnlyChange": "readOnlyChange"; "rtlEnabledChange": "rtlEnabledChange"; "stylingModeChange": "stylingModeChange"; "tabIndexChange": "tabIndexChange"; "tableContextMenuChange": "tableContextMenuChange"; "tableResizingChange": "tableResizingChange"; "toolbarChange": "toolbarChange"; "validationErrorChange": "validationErrorChange"; "validationErrorsChange": "validationErrorsChange"; "validationMessageModeChange": "validationMessageModeChange"; "validationMessagePositionChange": "validationMessagePositionChange"; "validationStatusChange": "validationStatusChange"; "valueChange": "valueChange"; "variablesChange": "variablesChange"; "visibleChange": "visibleChange"; "widthChange": "widthChange"; "onBlur": "onBlur"; }, ["_commandsContentChildren", "_itemsContentChildren", "_mentionsContentChildren", "_tabsContentChildren"], ["*"], true, never>;
}
declare class DxHtmlEditorModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxHtmlEditorModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxHtmlEditorModule, never, [typeof DxHtmlEditorComponent, typeof i1.DxoConverterModule, typeof i1.DxoImageUploadModule, typeof i1.DxoFileUploaderOptionsModule, typeof i1.DxiTabModule, typeof i1.DxoMediaResizingModule, typeof i1.DxiMentionModule, typeof i1.DxoTableContextMenuModule, typeof i1.DxiItemModule, typeof i1.DxoTableResizingModule, typeof i1.DxoToolbarModule, typeof i1.DxiCommandModule, typeof i1.DxoVariablesModule, typeof i2.DxiHtmlEditorCommandModule, typeof i2.DxoHtmlEditorConverterModule, typeof i2.DxoHtmlEditorFileUploaderOptionsModule, typeof i2.DxoHtmlEditorImageUploadModule, typeof i2.DxiHtmlEditorItemModule, typeof i2.DxoHtmlEditorMediaResizingModule, typeof i2.DxiHtmlEditorMentionModule, typeof i2.DxiHtmlEditorTabModule, typeof i2.DxoHtmlEditorTableContextMenuModule, typeof i2.DxiHtmlEditorTableContextMenuItemModule, typeof i2.DxoHtmlEditorTableResizingModule, typeof i2.DxoHtmlEditorToolbarModule, typeof i2.DxiHtmlEditorToolbarItemModule, typeof i2.DxoHtmlEditorVariablesModule, typeof i3.DxIntegrationModule, typeof i3.DxTemplateModule], [typeof DxHtmlEditorComponent, typeof i1.DxoConverterModule, typeof i1.DxoImageUploadModule, typeof i1.DxoFileUploaderOptionsModule, typeof i1.DxiTabModule, typeof i1.DxoMediaResizingModule, typeof i1.DxiMentionModule, typeof i1.DxoTableContextMenuModule, typeof i1.DxiItemModule, typeof i1.DxoTableResizingModule, typeof i1.DxoToolbarModule, typeof i1.DxiCommandModule, typeof i1.DxoVariablesModule, typeof i2.DxiHtmlEditorCommandModule, typeof i2.DxoHtmlEditorConverterModule, typeof i2.DxoHtmlEditorFileUploaderOptionsModule, typeof i2.DxoHtmlEditorImageUploadModule, typeof i2.DxiHtmlEditorItemModule, typeof i2.DxoHtmlEditorMediaResizingModule, typeof i2.DxiHtmlEditorMentionModule, typeof i2.DxiHtmlEditorTabModule, typeof i2.DxoHtmlEditorTableContextMenuModule, typeof i2.DxiHtmlEditorTableContextMenuItemModule, typeof i2.DxoHtmlEditorTableResizingModule, typeof i2.DxoHtmlEditorToolbarModule, typeof i2.DxiHtmlEditorToolbarItemModule, typeof i2.DxoHtmlEditorVariablesModule, typeof i3.DxTemplateModule]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxHtmlEditorModule>;
}

export { DxHtmlEditorComponent, DxHtmlEditorModule };
//# sourceMappingURL=index.d.ts.map
