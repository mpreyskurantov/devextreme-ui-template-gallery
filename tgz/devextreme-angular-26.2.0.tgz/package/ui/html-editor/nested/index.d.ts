import { AICommandNameExtended, HtmlEditorImageUploadMode, dxHtmlEditorImageUploadTabItem, HtmlEditorImageUploadTab, dxHtmlEditorTableContextMenuItem, HtmlEditorPredefinedContextMenuItem, HtmlEditorPredefinedToolbarItem, AICommand, AICommandName, AIToolbarItem, dxHtmlEditorToolbarItem } from 'devextreme/ui/html_editor';
import { CollectionNestedOption, NestedOptionHost, NestedOption, IDxTemplateHost, DxTemplateHost, DxTemplateDirective } from 'devextreme-angular/core';
import * as i0 from '@angular/core';
import { OnDestroy, OnInit, EventEmitter, QueryList, AfterViewInit, Renderer2, ElementRef } from '@angular/core';
import UploadInfo from 'devextreme/file_management/upload_info';
import { BeforeSendEvent, ContentReadyEvent, DisposingEvent, DropZoneEnterEvent, DropZoneLeaveEvent, FilesUploadedEvent, InitializedEvent, OptionChangedEvent, ProgressEvent, UploadAbortedEvent, UploadedEvent, UploadErrorEvent, UploadStartedEvent, ValueChangedEvent, UploadHttpMethod, FileUploadMode, dxFileUploaderOptions } from 'devextreme/ui/file_uploader';
import { ValidationStatus, ToolbarItemLocation, ToolbarItemComponent } from 'devextreme/common';
import { LocateInMenuMode, ShowTextMode } from 'devextreme/ui/toolbar';
import DataSource, { DataSourceOptions } from 'devextreme/data/data_source';
import { Store } from 'devextreme/data/store';

declare class DxiHtmlEditorCommandComponent extends CollectionNestedOption {
    get name(): AICommandNameExtended;
    set name(value: AICommandNameExtended);
    get options(): any;
    set options(value: any);
    get prompt(): ((param: string) => string);
    set prompt(value: ((param: string) => string));
    get text(): string;
    set text(value: string);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiHtmlEditorCommandComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiHtmlEditorCommandComponent, "dxi-html-editor-command", never, { "name": { "alias": "name"; "required": false; }; "options": { "alias": "options"; "required": false; }; "prompt": { "alias": "prompt"; "required": false; }; "text": { "alias": "text"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxiHtmlEditorCommandModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiHtmlEditorCommandModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiHtmlEditorCommandModule, never, [typeof DxiHtmlEditorCommandComponent], [typeof DxiHtmlEditorCommandComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiHtmlEditorCommandModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoHtmlEditorConverterComponent extends NestedOption implements OnDestroy, OnInit {
    get fromHtml(): ((value: string) => string);
    set fromHtml(value: ((value: string) => string));
    get toHtml(): ((value: string) => string);
    set toHtml(value: ((value: string) => string));
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoHtmlEditorConverterComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoHtmlEditorConverterComponent, "dxo-html-editor-converter", never, { "fromHtml": { "alias": "fromHtml"; "required": false; }; "toHtml": { "alias": "toHtml"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoHtmlEditorConverterModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoHtmlEditorConverterModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoHtmlEditorConverterModule, never, [typeof DxoHtmlEditorConverterComponent], [typeof DxoHtmlEditorConverterComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoHtmlEditorConverterModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoHtmlEditorFileUploaderOptionsComponent extends NestedOption implements OnDestroy, OnInit {
    get abortUpload(): ((file: any, uploadInfo?: UploadInfo) => any);
    set abortUpload(value: ((file: any, uploadInfo?: UploadInfo) => any));
    get accept(): string;
    set accept(value: string);
    get accessKey(): string | undefined;
    set accessKey(value: string | undefined);
    get activeStateEnabled(): boolean;
    set activeStateEnabled(value: boolean);
    get allowCanceling(): boolean;
    set allowCanceling(value: boolean);
    get allowedFileExtensions(): Array<string>;
    set allowedFileExtensions(value: Array<string>);
    get chunkSize(): number;
    set chunkSize(value: number);
    get dialogTrigger(): any | string | undefined;
    set dialogTrigger(value: any | string | undefined);
    get disabled(): boolean;
    set disabled(value: boolean);
    get dropZone(): any | string | undefined;
    set dropZone(value: any | string | undefined);
    get elementAttr(): Record<string, any>;
    set elementAttr(value: Record<string, any>);
    get focusStateEnabled(): boolean;
    set focusStateEnabled(value: boolean);
    get height(): number | string | undefined;
    set height(value: number | string | undefined);
    get hint(): string | undefined;
    set hint(value: string | undefined);
    get hoverStateEnabled(): boolean;
    set hoverStateEnabled(value: boolean);
    get inputAttr(): any;
    set inputAttr(value: any);
    get invalidFileExtensionMessage(): string;
    set invalidFileExtensionMessage(value: string);
    get invalidMaxFileSizeMessage(): string;
    set invalidMaxFileSizeMessage(value: string);
    get invalidMinFileSizeMessage(): string;
    set invalidMinFileSizeMessage(value: string);
    get isDirty(): boolean;
    set isDirty(value: boolean);
    get isValid(): boolean;
    set isValid(value: boolean);
    get labelText(): string;
    set labelText(value: string);
    get maxFileSize(): number;
    set maxFileSize(value: number);
    get minFileSize(): number;
    set minFileSize(value: number);
    get multiple(): boolean;
    set multiple(value: boolean);
    get name(): string;
    set name(value: string);
    get onBeforeSend(): ((e: BeforeSendEvent) => void) | undefined;
    set onBeforeSend(value: ((e: BeforeSendEvent) => void) | undefined);
    get onContentReady(): ((e: ContentReadyEvent) => void);
    set onContentReady(value: ((e: ContentReadyEvent) => void));
    get onDisposing(): ((e: DisposingEvent) => void);
    set onDisposing(value: ((e: DisposingEvent) => void));
    get onDropZoneEnter(): ((e: DropZoneEnterEvent) => void) | undefined;
    set onDropZoneEnter(value: ((e: DropZoneEnterEvent) => void) | undefined);
    get onDropZoneLeave(): ((e: DropZoneLeaveEvent) => void) | undefined;
    set onDropZoneLeave(value: ((e: DropZoneLeaveEvent) => void) | undefined);
    get onFilesUploaded(): ((e: FilesUploadedEvent) => void) | undefined;
    set onFilesUploaded(value: ((e: FilesUploadedEvent) => void) | undefined);
    get onInitialized(): ((e: InitializedEvent) => void);
    set onInitialized(value: ((e: InitializedEvent) => void));
    get onOptionChanged(): ((e: OptionChangedEvent) => void);
    set onOptionChanged(value: ((e: OptionChangedEvent) => void));
    get onProgress(): ((e: ProgressEvent) => void) | undefined;
    set onProgress(value: ((e: ProgressEvent) => void) | undefined);
    get onUploadAborted(): ((e: UploadAbortedEvent) => void) | undefined;
    set onUploadAborted(value: ((e: UploadAbortedEvent) => void) | undefined);
    get onUploaded(): ((e: UploadedEvent) => void) | undefined;
    set onUploaded(value: ((e: UploadedEvent) => void) | undefined);
    get onUploadError(): ((e: UploadErrorEvent) => void) | undefined;
    set onUploadError(value: ((e: UploadErrorEvent) => void) | undefined);
    get onUploadStarted(): ((e: UploadStartedEvent) => void) | undefined;
    set onUploadStarted(value: ((e: UploadStartedEvent) => void) | undefined);
    get onValueChanged(): ((e: ValueChangedEvent) => void) | undefined;
    set onValueChanged(value: ((e: ValueChangedEvent) => void) | undefined);
    get progress(): number;
    set progress(value: number);
    get readOnly(): boolean;
    set readOnly(value: boolean);
    get readyToUploadMessage(): string;
    set readyToUploadMessage(value: string);
    get rtlEnabled(): boolean;
    set rtlEnabled(value: boolean);
    get selectButtonText(): string;
    set selectButtonText(value: string);
    get showFileList(): boolean;
    set showFileList(value: boolean);
    get tabIndex(): number;
    set tabIndex(value: number);
    get uploadAbortedMessage(): string;
    set uploadAbortedMessage(value: string);
    get uploadButtonText(): string;
    set uploadButtonText(value: string);
    get uploadChunk(): ((file: any, uploadInfo: UploadInfo) => any);
    set uploadChunk(value: ((file: any, uploadInfo: UploadInfo) => any));
    get uploadCustomData(): any;
    set uploadCustomData(value: any);
    get uploadedMessage(): string;
    set uploadedMessage(value: string);
    get uploadFailedMessage(): string;
    set uploadFailedMessage(value: string);
    get uploadFile(): ((file: any, progressCallback: Function) => any);
    set uploadFile(value: ((file: any, progressCallback: Function) => any));
    get uploadHeaders(): any;
    set uploadHeaders(value: any);
    get uploadMethod(): UploadHttpMethod;
    set uploadMethod(value: UploadHttpMethod);
    get uploadMode(): FileUploadMode;
    set uploadMode(value: FileUploadMode);
    get uploadUrl(): string;
    set uploadUrl(value: string);
    get validationError(): any | null;
    set validationError(value: any | null);
    get validationErrors(): Array<any> | null;
    set validationErrors(value: Array<any> | null);
    get validationStatus(): ValidationStatus;
    set validationStatus(value: ValidationStatus);
    get value(): Array<any>;
    set value(value: Array<any>);
    get visible(): boolean;
    set visible(value: boolean);
    get width(): number | string | undefined;
    set width(value: number | string | undefined);
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    valueChange: EventEmitter<Array<any>>;
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoHtmlEditorFileUploaderOptionsComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoHtmlEditorFileUploaderOptionsComponent, "dxo-html-editor-file-uploader-options", never, { "abortUpload": { "alias": "abortUpload"; "required": false; }; "accept": { "alias": "accept"; "required": false; }; "accessKey": { "alias": "accessKey"; "required": false; }; "activeStateEnabled": { "alias": "activeStateEnabled"; "required": false; }; "allowCanceling": { "alias": "allowCanceling"; "required": false; }; "allowedFileExtensions": { "alias": "allowedFileExtensions"; "required": false; }; "chunkSize": { "alias": "chunkSize"; "required": false; }; "dialogTrigger": { "alias": "dialogTrigger"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "dropZone": { "alias": "dropZone"; "required": false; }; "elementAttr": { "alias": "elementAttr"; "required": false; }; "focusStateEnabled": { "alias": "focusStateEnabled"; "required": false; }; "height": { "alias": "height"; "required": false; }; "hint": { "alias": "hint"; "required": false; }; "hoverStateEnabled": { "alias": "hoverStateEnabled"; "required": false; }; "inputAttr": { "alias": "inputAttr"; "required": false; }; "invalidFileExtensionMessage": { "alias": "invalidFileExtensionMessage"; "required": false; }; "invalidMaxFileSizeMessage": { "alias": "invalidMaxFileSizeMessage"; "required": false; }; "invalidMinFileSizeMessage": { "alias": "invalidMinFileSizeMessage"; "required": false; }; "isDirty": { "alias": "isDirty"; "required": false; }; "isValid": { "alias": "isValid"; "required": false; }; "labelText": { "alias": "labelText"; "required": false; }; "maxFileSize": { "alias": "maxFileSize"; "required": false; }; "minFileSize": { "alias": "minFileSize"; "required": false; }; "multiple": { "alias": "multiple"; "required": false; }; "name": { "alias": "name"; "required": false; }; "onBeforeSend": { "alias": "onBeforeSend"; "required": false; }; "onContentReady": { "alias": "onContentReady"; "required": false; }; "onDisposing": { "alias": "onDisposing"; "required": false; }; "onDropZoneEnter": { "alias": "onDropZoneEnter"; "required": false; }; "onDropZoneLeave": { "alias": "onDropZoneLeave"; "required": false; }; "onFilesUploaded": { "alias": "onFilesUploaded"; "required": false; }; "onInitialized": { "alias": "onInitialized"; "required": false; }; "onOptionChanged": { "alias": "onOptionChanged"; "required": false; }; "onProgress": { "alias": "onProgress"; "required": false; }; "onUploadAborted": { "alias": "onUploadAborted"; "required": false; }; "onUploaded": { "alias": "onUploaded"; "required": false; }; "onUploadError": { "alias": "onUploadError"; "required": false; }; "onUploadStarted": { "alias": "onUploadStarted"; "required": false; }; "onValueChanged": { "alias": "onValueChanged"; "required": false; }; "progress": { "alias": "progress"; "required": false; }; "readOnly": { "alias": "readOnly"; "required": false; }; "readyToUploadMessage": { "alias": "readyToUploadMessage"; "required": false; }; "rtlEnabled": { "alias": "rtlEnabled"; "required": false; }; "selectButtonText": { "alias": "selectButtonText"; "required": false; }; "showFileList": { "alias": "showFileList"; "required": false; }; "tabIndex": { "alias": "tabIndex"; "required": false; }; "uploadAbortedMessage": { "alias": "uploadAbortedMessage"; "required": false; }; "uploadButtonText": { "alias": "uploadButtonText"; "required": false; }; "uploadChunk": { "alias": "uploadChunk"; "required": false; }; "uploadCustomData": { "alias": "uploadCustomData"; "required": false; }; "uploadedMessage": { "alias": "uploadedMessage"; "required": false; }; "uploadFailedMessage": { "alias": "uploadFailedMessage"; "required": false; }; "uploadFile": { "alias": "uploadFile"; "required": false; }; "uploadHeaders": { "alias": "uploadHeaders"; "required": false; }; "uploadMethod": { "alias": "uploadMethod"; "required": false; }; "uploadMode": { "alias": "uploadMode"; "required": false; }; "uploadUrl": { "alias": "uploadUrl"; "required": false; }; "validationError": { "alias": "validationError"; "required": false; }; "validationErrors": { "alias": "validationErrors"; "required": false; }; "validationStatus": { "alias": "validationStatus"; "required": false; }; "value": { "alias": "value"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, { "valueChange": "valueChange"; }, never, never, true, never>;
}
declare class DxoHtmlEditorFileUploaderOptionsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoHtmlEditorFileUploaderOptionsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoHtmlEditorFileUploaderOptionsModule, never, [typeof DxoHtmlEditorFileUploaderOptionsComponent], [typeof DxoHtmlEditorFileUploaderOptionsComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoHtmlEditorFileUploaderOptionsModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoHtmlEditorImageUploadComponent extends NestedOption implements OnDestroy, OnInit {
    set _tabsContentChildren(value: QueryList<CollectionNestedOption>);
    get fileUploaderOptions(): dxFileUploaderOptions;
    set fileUploaderOptions(value: dxFileUploaderOptions);
    get fileUploadMode(): HtmlEditorImageUploadMode;
    set fileUploadMode(value: HtmlEditorImageUploadMode);
    get tabs(): Array<dxHtmlEditorImageUploadTabItem | HtmlEditorImageUploadTab>;
    set tabs(value: Array<dxHtmlEditorImageUploadTabItem | HtmlEditorImageUploadTab>);
    get uploadDirectory(): string | undefined;
    set uploadDirectory(value: string | undefined);
    get uploadUrl(): string | undefined;
    set uploadUrl(value: string | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoHtmlEditorImageUploadComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoHtmlEditorImageUploadComponent, "dxo-html-editor-image-upload", never, { "fileUploaderOptions": { "alias": "fileUploaderOptions"; "required": false; }; "fileUploadMode": { "alias": "fileUploadMode"; "required": false; }; "tabs": { "alias": "tabs"; "required": false; }; "uploadDirectory": { "alias": "uploadDirectory"; "required": false; }; "uploadUrl": { "alias": "uploadUrl"; "required": false; }; }, {}, ["_tabsContentChildren"], never, true, never>;
}
declare class DxoHtmlEditorImageUploadModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoHtmlEditorImageUploadModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoHtmlEditorImageUploadModule, never, [typeof DxoHtmlEditorImageUploadComponent], [typeof DxoHtmlEditorImageUploadComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoHtmlEditorImageUploadModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxiHtmlEditorItemComponent extends CollectionNestedOption implements AfterViewInit, IDxTemplateHost {
    private renderer;
    private document;
    private element;
    set _commandsContentChildren(value: QueryList<CollectionNestedOption>);
    set _itemsContentChildren(value: QueryList<CollectionNestedOption>);
    get beginGroup(): boolean;
    set beginGroup(value: boolean);
    get closeMenuOnClick(): boolean;
    set closeMenuOnClick(value: boolean);
    get disabled(): boolean;
    set disabled(value: boolean);
    get icon(): string;
    set icon(value: string);
    get items(): Array<dxHtmlEditorTableContextMenuItem | HtmlEditorPredefinedContextMenuItem>;
    set items(value: Array<dxHtmlEditorTableContextMenuItem | HtmlEditorPredefinedContextMenuItem>);
    get name(): HtmlEditorPredefinedContextMenuItem | undefined | HtmlEditorPredefinedToolbarItem | string;
    set name(value: HtmlEditorPredefinedContextMenuItem | undefined | HtmlEditorPredefinedToolbarItem | string);
    get selectable(): boolean;
    set selectable(value: boolean);
    get selected(): boolean;
    set selected(value: boolean);
    get template(): any;
    set template(value: any);
    get text(): string;
    set text(value: string);
    get visible(): boolean;
    set visible(value: boolean);
    get acceptedValues(): Array<boolean | number | string>;
    set acceptedValues(value: Array<boolean | number | string>);
    get commands(): Array<AICommand | AICommandName>;
    set commands(value: Array<AICommand | AICommandName>);
    get cssClass(): string | undefined;
    set cssClass(value: string | undefined);
    get html(): string;
    set html(value: string);
    get locateInMenu(): LocateInMenuMode;
    set locateInMenu(value: LocateInMenuMode);
    get location(): ToolbarItemLocation;
    set location(value: ToolbarItemLocation);
    get menuItemTemplate(): any;
    set menuItemTemplate(value: any);
    get options(): any;
    set options(value: any);
    get showText(): ShowTextMode;
    set showText(value: ShowTextMode);
    get widget(): ToolbarItemComponent;
    set widget(value: ToolbarItemComponent);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost, renderer: Renderer2, document: any, templateHost: DxTemplateHost, element: ElementRef);
    setTemplate(template: DxTemplateDirective): void;
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiHtmlEditorItemComponent, [{ host: true; skipSelf: true; }, { host: true; }, null, null, { host: true; }, null]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiHtmlEditorItemComponent, "dxi-html-editor-item", never, { "beginGroup": { "alias": "beginGroup"; "required": false; }; "closeMenuOnClick": { "alias": "closeMenuOnClick"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "icon": { "alias": "icon"; "required": false; }; "items": { "alias": "items"; "required": false; }; "name": { "alias": "name"; "required": false; }; "selectable": { "alias": "selectable"; "required": false; }; "selected": { "alias": "selected"; "required": false; }; "template": { "alias": "template"; "required": false; }; "text": { "alias": "text"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "acceptedValues": { "alias": "acceptedValues"; "required": false; }; "commands": { "alias": "commands"; "required": false; }; "cssClass": { "alias": "cssClass"; "required": false; }; "html": { "alias": "html"; "required": false; }; "locateInMenu": { "alias": "locateInMenu"; "required": false; }; "location": { "alias": "location"; "required": false; }; "menuItemTemplate": { "alias": "menuItemTemplate"; "required": false; }; "options": { "alias": "options"; "required": false; }; "showText": { "alias": "showText"; "required": false; }; "widget": { "alias": "widget"; "required": false; }; }, {}, ["_commandsContentChildren", "_itemsContentChildren"], ["*"], true, never>;
}
declare class DxiHtmlEditorItemModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiHtmlEditorItemModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiHtmlEditorItemModule, never, [typeof DxiHtmlEditorItemComponent], [typeof DxiHtmlEditorItemComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiHtmlEditorItemModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoHtmlEditorMediaResizingComponent extends NestedOption implements OnDestroy, OnInit {
    get allowedTargets(): Array<string>;
    set allowedTargets(value: Array<string>);
    get enabled(): boolean;
    set enabled(value: boolean);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoHtmlEditorMediaResizingComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoHtmlEditorMediaResizingComponent, "dxo-html-editor-media-resizing", never, { "allowedTargets": { "alias": "allowedTargets"; "required": false; }; "enabled": { "alias": "enabled"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoHtmlEditorMediaResizingModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoHtmlEditorMediaResizingModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoHtmlEditorMediaResizingModule, never, [typeof DxoHtmlEditorMediaResizingComponent], [typeof DxoHtmlEditorMediaResizingComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoHtmlEditorMediaResizingModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxiHtmlEditorMentionComponent extends CollectionNestedOption implements AfterViewInit, IDxTemplateHost {
    private renderer;
    private document;
    private element;
    get dataSource(): Array<any> | DataSource | DataSourceOptions | null | Store | string;
    set dataSource(value: Array<any> | DataSource | DataSourceOptions | null | Store | string);
    get displayExpr(): ((item: any) => string) | string;
    set displayExpr(value: ((item: any) => string) | string);
    get itemTemplate(): any;
    set itemTemplate(value: any);
    get marker(): string;
    set marker(value: string);
    get minSearchLength(): number;
    set minSearchLength(value: number);
    get searchExpr(): Array<Function | string> | Function | string;
    set searchExpr(value: Array<Function | string> | Function | string);
    get searchTimeout(): number;
    set searchTimeout(value: number);
    get template(): any;
    set template(value: any);
    get valueExpr(): Function | string;
    set valueExpr(value: Function | string);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost, renderer: Renderer2, document: any, templateHost: DxTemplateHost, element: ElementRef);
    setTemplate(template: DxTemplateDirective): void;
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiHtmlEditorMentionComponent, [{ host: true; skipSelf: true; }, { host: true; }, null, null, { host: true; }, null]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiHtmlEditorMentionComponent, "dxi-html-editor-mention", never, { "dataSource": { "alias": "dataSource"; "required": false; }; "displayExpr": { "alias": "displayExpr"; "required": false; }; "itemTemplate": { "alias": "itemTemplate"; "required": false; }; "marker": { "alias": "marker"; "required": false; }; "minSearchLength": { "alias": "minSearchLength"; "required": false; }; "searchExpr": { "alias": "searchExpr"; "required": false; }; "searchTimeout": { "alias": "searchTimeout"; "required": false; }; "template": { "alias": "template"; "required": false; }; "valueExpr": { "alias": "valueExpr"; "required": false; }; }, {}, never, ["*"], true, never>;
}
declare class DxiHtmlEditorMentionModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiHtmlEditorMentionModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiHtmlEditorMentionModule, never, [typeof DxiHtmlEditorMentionComponent], [typeof DxiHtmlEditorMentionComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiHtmlEditorMentionModule>;
}

declare class DxiHtmlEditorTabComponent extends CollectionNestedOption {
    get name(): HtmlEditorImageUploadTab | undefined;
    set name(value: HtmlEditorImageUploadTab | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiHtmlEditorTabComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiHtmlEditorTabComponent, "dxi-html-editor-tab", never, { "name": { "alias": "name"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxiHtmlEditorTabModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiHtmlEditorTabModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiHtmlEditorTabModule, never, [typeof DxiHtmlEditorTabComponent], [typeof DxiHtmlEditorTabComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiHtmlEditorTabModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxiHtmlEditorTableContextMenuItemComponent extends CollectionNestedOption implements AfterViewInit, IDxTemplateHost {
    private renderer;
    private document;
    private element;
    set _itemsContentChildren(value: QueryList<CollectionNestedOption>);
    get beginGroup(): boolean;
    set beginGroup(value: boolean);
    get closeMenuOnClick(): boolean;
    set closeMenuOnClick(value: boolean);
    get disabled(): boolean;
    set disabled(value: boolean);
    get icon(): string;
    set icon(value: string);
    get items(): Array<dxHtmlEditorTableContextMenuItem | HtmlEditorPredefinedContextMenuItem>;
    set items(value: Array<dxHtmlEditorTableContextMenuItem | HtmlEditorPredefinedContextMenuItem>);
    get name(): HtmlEditorPredefinedContextMenuItem | undefined;
    set name(value: HtmlEditorPredefinedContextMenuItem | undefined);
    get selectable(): boolean;
    set selectable(value: boolean);
    get selected(): boolean;
    set selected(value: boolean);
    get template(): any;
    set template(value: any);
    get text(): string;
    set text(value: string);
    get visible(): boolean;
    set visible(value: boolean);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost, renderer: Renderer2, document: any, templateHost: DxTemplateHost, element: ElementRef);
    setTemplate(template: DxTemplateDirective): void;
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiHtmlEditorTableContextMenuItemComponent, [{ host: true; skipSelf: true; }, { host: true; }, null, null, { host: true; }, null]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiHtmlEditorTableContextMenuItemComponent, "dxi-html-editor-table-context-menu-item", never, { "beginGroup": { "alias": "beginGroup"; "required": false; }; "closeMenuOnClick": { "alias": "closeMenuOnClick"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "icon": { "alias": "icon"; "required": false; }; "items": { "alias": "items"; "required": false; }; "name": { "alias": "name"; "required": false; }; "selectable": { "alias": "selectable"; "required": false; }; "selected": { "alias": "selected"; "required": false; }; "template": { "alias": "template"; "required": false; }; "text": { "alias": "text"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; }, {}, ["_itemsContentChildren"], ["*"], true, never>;
}
declare class DxiHtmlEditorTableContextMenuItemModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiHtmlEditorTableContextMenuItemModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiHtmlEditorTableContextMenuItemModule, never, [typeof DxiHtmlEditorTableContextMenuItemComponent], [typeof DxiHtmlEditorTableContextMenuItemComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiHtmlEditorTableContextMenuItemModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoHtmlEditorTableContextMenuComponent extends NestedOption implements OnDestroy, OnInit {
    set _itemsContentChildren(value: QueryList<CollectionNestedOption>);
    get enabled(): boolean;
    set enabled(value: boolean);
    get items(): Array<dxHtmlEditorTableContextMenuItem | HtmlEditorPredefinedContextMenuItem>;
    set items(value: Array<dxHtmlEditorTableContextMenuItem | HtmlEditorPredefinedContextMenuItem>);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoHtmlEditorTableContextMenuComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoHtmlEditorTableContextMenuComponent, "dxo-html-editor-table-context-menu", never, { "enabled": { "alias": "enabled"; "required": false; }; "items": { "alias": "items"; "required": false; }; }, {}, ["_itemsContentChildren"], never, true, never>;
}
declare class DxoHtmlEditorTableContextMenuModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoHtmlEditorTableContextMenuModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoHtmlEditorTableContextMenuModule, never, [typeof DxoHtmlEditorTableContextMenuComponent], [typeof DxoHtmlEditorTableContextMenuComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoHtmlEditorTableContextMenuModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoHtmlEditorTableResizingComponent extends NestedOption implements OnDestroy, OnInit {
    get enabled(): boolean;
    set enabled(value: boolean);
    get minColumnWidth(): number;
    set minColumnWidth(value: number);
    get minRowHeight(): number;
    set minRowHeight(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoHtmlEditorTableResizingComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoHtmlEditorTableResizingComponent, "dxo-html-editor-table-resizing", never, { "enabled": { "alias": "enabled"; "required": false; }; "minColumnWidth": { "alias": "minColumnWidth"; "required": false; }; "minRowHeight": { "alias": "minRowHeight"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoHtmlEditorTableResizingModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoHtmlEditorTableResizingModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoHtmlEditorTableResizingModule, never, [typeof DxoHtmlEditorTableResizingComponent], [typeof DxoHtmlEditorTableResizingComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoHtmlEditorTableResizingModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxiHtmlEditorToolbarItemComponent extends CollectionNestedOption implements AfterViewInit, IDxTemplateHost {
    private renderer;
    private document;
    private element;
    set _commandsContentChildren(value: QueryList<CollectionNestedOption>);
    get acceptedValues(): Array<boolean | number | string>;
    set acceptedValues(value: Array<boolean | number | string>);
    get commands(): Array<AICommand | AICommandName>;
    set commands(value: Array<AICommand | AICommandName>);
    get cssClass(): string | undefined;
    set cssClass(value: string | undefined);
    get disabled(): boolean;
    set disabled(value: boolean);
    get html(): string;
    set html(value: string);
    get locateInMenu(): LocateInMenuMode;
    set locateInMenu(value: LocateInMenuMode);
    get location(): ToolbarItemLocation;
    set location(value: ToolbarItemLocation);
    get menuItemTemplate(): any;
    set menuItemTemplate(value: any);
    get name(): HtmlEditorPredefinedToolbarItem | string | string;
    set name(value: HtmlEditorPredefinedToolbarItem | string | string);
    get options(): any;
    set options(value: any);
    get showText(): ShowTextMode;
    set showText(value: ShowTextMode);
    get template(): any;
    set template(value: any);
    get text(): string;
    set text(value: string);
    get visible(): boolean;
    set visible(value: boolean);
    get widget(): ToolbarItemComponent;
    set widget(value: ToolbarItemComponent);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost, renderer: Renderer2, document: any, templateHost: DxTemplateHost, element: ElementRef);
    setTemplate(template: DxTemplateDirective): void;
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiHtmlEditorToolbarItemComponent, [{ host: true; skipSelf: true; }, { host: true; }, null, null, { host: true; }, null]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiHtmlEditorToolbarItemComponent, "dxi-html-editor-toolbar-item", never, { "acceptedValues": { "alias": "acceptedValues"; "required": false; }; "commands": { "alias": "commands"; "required": false; }; "cssClass": { "alias": "cssClass"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "html": { "alias": "html"; "required": false; }; "locateInMenu": { "alias": "locateInMenu"; "required": false; }; "location": { "alias": "location"; "required": false; }; "menuItemTemplate": { "alias": "menuItemTemplate"; "required": false; }; "name": { "alias": "name"; "required": false; }; "options": { "alias": "options"; "required": false; }; "showText": { "alias": "showText"; "required": false; }; "template": { "alias": "template"; "required": false; }; "text": { "alias": "text"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "widget": { "alias": "widget"; "required": false; }; }, {}, ["_commandsContentChildren"], ["*"], true, never>;
}
declare class DxiHtmlEditorToolbarItemModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiHtmlEditorToolbarItemModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiHtmlEditorToolbarItemModule, never, [typeof DxiHtmlEditorToolbarItemComponent], [typeof DxiHtmlEditorToolbarItemComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiHtmlEditorToolbarItemModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoHtmlEditorToolbarComponent extends NestedOption implements OnDestroy, OnInit {
    set _itemsContentChildren(value: QueryList<CollectionNestedOption>);
    get container(): any | string;
    set container(value: any | string);
    get items(): Array<AIToolbarItem | dxHtmlEditorToolbarItem | HtmlEditorPredefinedToolbarItem>;
    set items(value: Array<AIToolbarItem | dxHtmlEditorToolbarItem | HtmlEditorPredefinedToolbarItem>);
    get multiline(): boolean;
    set multiline(value: boolean);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoHtmlEditorToolbarComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoHtmlEditorToolbarComponent, "dxo-html-editor-toolbar", never, { "container": { "alias": "container"; "required": false; }; "items": { "alias": "items"; "required": false; }; "multiline": { "alias": "multiline"; "required": false; }; }, {}, ["_itemsContentChildren"], never, true, never>;
}
declare class DxoHtmlEditorToolbarModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoHtmlEditorToolbarModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoHtmlEditorToolbarModule, never, [typeof DxoHtmlEditorToolbarComponent], [typeof DxoHtmlEditorToolbarComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoHtmlEditorToolbarModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoHtmlEditorVariablesComponent extends NestedOption implements OnDestroy, OnInit {
    get dataSource(): Array<string> | DataSource | DataSourceOptions | null | Store | string;
    set dataSource(value: Array<string> | DataSource | DataSourceOptions | null | Store | string);
    get escapeChar(): Array<string> | string;
    set escapeChar(value: Array<string> | string);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoHtmlEditorVariablesComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoHtmlEditorVariablesComponent, "dxo-html-editor-variables", never, { "dataSource": { "alias": "dataSource"; "required": false; }; "escapeChar": { "alias": "escapeChar"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoHtmlEditorVariablesModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoHtmlEditorVariablesModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoHtmlEditorVariablesModule, never, [typeof DxoHtmlEditorVariablesComponent], [typeof DxoHtmlEditorVariablesComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoHtmlEditorVariablesModule>;
}

export { DxiHtmlEditorCommandComponent, DxiHtmlEditorCommandModule, DxiHtmlEditorItemComponent, DxiHtmlEditorItemModule, DxiHtmlEditorMentionComponent, DxiHtmlEditorMentionModule, DxiHtmlEditorTabComponent, DxiHtmlEditorTabModule, DxiHtmlEditorTableContextMenuItemComponent, DxiHtmlEditorTableContextMenuItemModule, DxiHtmlEditorToolbarItemComponent, DxiHtmlEditorToolbarItemModule, DxoHtmlEditorConverterComponent, DxoHtmlEditorConverterModule, DxoHtmlEditorFileUploaderOptionsComponent, DxoHtmlEditorFileUploaderOptionsModule, DxoHtmlEditorImageUploadComponent, DxoHtmlEditorImageUploadModule, DxoHtmlEditorMediaResizingComponent, DxoHtmlEditorMediaResizingModule, DxoHtmlEditorTableContextMenuComponent, DxoHtmlEditorTableContextMenuModule, DxoHtmlEditorTableResizingComponent, DxoHtmlEditorTableResizingModule, DxoHtmlEditorToolbarComponent, DxoHtmlEditorToolbarModule, DxoHtmlEditorVariablesComponent, DxoHtmlEditorVariablesModule };
//# sourceMappingURL=index.d.ts.map
