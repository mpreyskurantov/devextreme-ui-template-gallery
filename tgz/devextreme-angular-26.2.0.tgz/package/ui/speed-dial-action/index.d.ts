import * as i0 from '@angular/core';
import { OnDestroy, EventEmitter, ElementRef, NgZone, TransferState } from '@angular/core';
import DxSpeedDialAction, { ClickEvent, ContentReadyEvent, DisposingEvent, InitializedEvent, OptionChangedEvent } from 'devextreme/ui/speed_dial_action';
import * as i1 from 'devextreme-angular/core';
import { DxComponent, DxTemplateHost, WatcherHelper, NestedOptionHost } from 'devextreme-angular/core';
import * as speed_dial_action_types from 'devextreme/ui/speed_dial_action_types';
export { speed_dial_action_types as DxSpeedDialActionTypes };

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

/**
 * [descr:dxSpeedDialAction]

 */
declare class DxSpeedDialActionComponent extends DxComponent implements OnDestroy {
    instance: DxSpeedDialAction;
    /**
     * [descr:WidgetOptions.accessKey]
    
     */
    get accessKey(): string | undefined;
    set accessKey(value: string | undefined);
    /**
     * [descr:WidgetOptions.activeStateEnabled]
    
     */
    get activeStateEnabled(): boolean;
    set activeStateEnabled(value: boolean);
    /**
     * [descr:DOMComponentOptions.elementAttr]
    
     */
    get elementAttr(): Record<string, any>;
    set elementAttr(value: Record<string, any>);
    /**
     * [descr:WidgetOptions.focusStateEnabled]
    
     */
    get focusStateEnabled(): boolean;
    set focusStateEnabled(value: boolean);
    /**
     * [descr:WidgetOptions.hint]
    
     */
    get hint(): string | undefined;
    set hint(value: string | undefined);
    /**
     * [descr:WidgetOptions.hoverStateEnabled]
    
     */
    get hoverStateEnabled(): boolean;
    set hoverStateEnabled(value: boolean);
    /**
     * [descr:dxSpeedDialActionOptions.icon]
    
     */
    get icon(): string;
    set icon(value: string);
    /**
     * [descr:dxSpeedDialActionOptions.index]
    
     */
    get index(): number;
    set index(value: number);
    /**
     * [descr:dxSpeedDialActionOptions.label]
    
     */
    get label(): string;
    set label(value: string);
    /**
     * [descr:DOMComponentOptions.rtlEnabled]
    
     */
    get rtlEnabled(): boolean;
    set rtlEnabled(value: boolean);
    /**
     * [descr:WidgetOptions.tabIndex]
    
     */
    get tabIndex(): number;
    set tabIndex(value: number);
    /**
     * [descr:dxSpeedDialActionOptions.visible]
    
     */
    get visible(): boolean;
    set visible(value: boolean);
    /**
    
     * [descr:dxSpeedDialActionOptions.onClick]
    
    
     */
    onClick: EventEmitter<ClickEvent>;
    /**
    
     * [descr:dxSpeedDialActionOptions.onContentReady]
    
    
     */
    onContentReady: EventEmitter<ContentReadyEvent>;
    /**
    
     * [descr:dxSpeedDialActionOptions.onDisposing]
    
    
     */
    onDisposing: EventEmitter<DisposingEvent>;
    /**
    
     * [descr:dxSpeedDialActionOptions.onInitialized]
    
    
     */
    onInitialized: EventEmitter<InitializedEvent>;
    /**
    
     * [descr:dxSpeedDialActionOptions.onOptionChanged]
    
    
     */
    onOptionChanged: EventEmitter<OptionChangedEvent>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    accessKeyChange: EventEmitter<string | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    activeStateEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    elementAttrChange: EventEmitter<Record<string, any>>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    focusStateEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    hintChange: EventEmitter<string | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    hoverStateEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    iconChange: EventEmitter<string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    indexChange: EventEmitter<number>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    labelChange: EventEmitter<string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    rtlEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    tabIndexChange: EventEmitter<number>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    visibleChange: EventEmitter<boolean>;
    constructor(elementRef: ElementRef, ngZone: NgZone, templateHost: DxTemplateHost, _watcherHelper: WatcherHelper, optionHost: NestedOptionHost, transferState: TransferState, platformId: any);
    protected _createInstance(element: any, options: any): DxSpeedDialAction;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxSpeedDialActionComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxSpeedDialActionComponent, "dx-speed-dial-action", never, { "accessKey": { "alias": "accessKey"; "required": false; }; "activeStateEnabled": { "alias": "activeStateEnabled"; "required": false; }; "elementAttr": { "alias": "elementAttr"; "required": false; }; "focusStateEnabled": { "alias": "focusStateEnabled"; "required": false; }; "hint": { "alias": "hint"; "required": false; }; "hoverStateEnabled": { "alias": "hoverStateEnabled"; "required": false; }; "icon": { "alias": "icon"; "required": false; }; "index": { "alias": "index"; "required": false; }; "label": { "alias": "label"; "required": false; }; "rtlEnabled": { "alias": "rtlEnabled"; "required": false; }; "tabIndex": { "alias": "tabIndex"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; }, { "onClick": "onClick"; "onContentReady": "onContentReady"; "onDisposing": "onDisposing"; "onInitialized": "onInitialized"; "onOptionChanged": "onOptionChanged"; "accessKeyChange": "accessKeyChange"; "activeStateEnabledChange": "activeStateEnabledChange"; "elementAttrChange": "elementAttrChange"; "focusStateEnabledChange": "focusStateEnabledChange"; "hintChange": "hintChange"; "hoverStateEnabledChange": "hoverStateEnabledChange"; "iconChange": "iconChange"; "indexChange": "indexChange"; "labelChange": "labelChange"; "rtlEnabledChange": "rtlEnabledChange"; "tabIndexChange": "tabIndexChange"; "visibleChange": "visibleChange"; }, never, never, true, never>;
}
declare class DxSpeedDialActionModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxSpeedDialActionModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxSpeedDialActionModule, never, [typeof DxSpeedDialActionComponent, typeof i1.DxIntegrationModule, typeof i1.DxTemplateModule], [typeof DxSpeedDialActionComponent, typeof i1.DxTemplateModule]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxSpeedDialActionModule>;
}

export { DxSpeedDialActionComponent, DxSpeedDialActionModule };
//# sourceMappingURL=index.d.ts.map
