import * as i0 from '@angular/core';
import { OnDestroy, OnChanges, DoCheck, QueryList, EventEmitter, ElementRef, NgZone, TransferState, SimpleChanges } from '@angular/core';
import DxGallery, { dxGalleryItem, ContentReadyEvent, DisposingEvent, InitializedEvent, ItemClickEvent, ItemContextMenuEvent, ItemHoldEvent, ItemRenderedEvent, OptionChangedEvent, SelectionChangedEvent } from 'devextreme/ui/gallery';
export { ExplicitTypes } from 'devextreme/ui/gallery';
import DataSource, { DataSourceOptions } from 'devextreme/data/data_source';
import { Store } from 'devextreme/data/store';
import * as i3 from 'devextreme-angular/core';
import { DxComponent, CollectionNestedOption, DxTemplateHost, WatcherHelper, IterableDifferHelper, NestedOptionHost } from 'devextreme-angular/core';
import * as i1 from 'devextreme-angular/ui/nested';
import * as i2 from 'devextreme-angular/ui/gallery/nested';
export * from 'devextreme-angular/ui/gallery/nested';
import * as gallery_types from 'devextreme/ui/gallery_types';
export { gallery_types as DxGalleryTypes };

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

/**
 * [descr:dxGallery]

 */
declare class DxGalleryComponent<TItem = any, TKey = any> extends DxComponent implements OnDestroy, OnChanges, DoCheck {
    private _watcherHelper;
    private _idh;
    set _itemsContentChildren(value: QueryList<CollectionNestedOption>);
    instance: DxGallery<TItem, TKey>;
    /**
     * [descr:WidgetOptions.accessKey]
    
     */
    get accessKey(): string | undefined;
    set accessKey(value: string | undefined);
    /**
     * [descr:dxGalleryOptions.animationDuration]
    
     */
    get animationDuration(): number;
    set animationDuration(value: number);
    /**
     * [descr:dxGalleryOptions.animationEnabled]
    
     */
    get animationEnabled(): boolean;
    set animationEnabled(value: boolean);
    /**
     * [descr:dxGalleryOptions.dataSource]
    
     */
    get dataSource(): Array<any | dxGalleryItem | string> | DataSource | DataSourceOptions | null | Store | string;
    set dataSource(value: Array<any | dxGalleryItem | string> | DataSource | DataSourceOptions | null | Store | string);
    /**
     * [descr:WidgetOptions.disabled]
    
     */
    get disabled(): boolean;
    set disabled(value: boolean);
    /**
     * [descr:DOMComponentOptions.elementAttr]
    
     */
    get elementAttr(): Record<string, any>;
    set elementAttr(value: Record<string, any>);
    /**
     * [descr:dxGalleryOptions.focusStateEnabled]
    
     */
    get focusStateEnabled(): boolean;
    set focusStateEnabled(value: boolean);
    /**
     * [descr:DOMComponentOptions.height]
    
     */
    get height(): number | string | undefined;
    set height(value: number | string | undefined);
    /**
     * [descr:WidgetOptions.hint]
    
     */
    get hint(): string | undefined;
    set hint(value: string | undefined);
    /**
     * [descr:WidgetOptions.hoverStateEnabled]
    
     */
    get hoverStateEnabled(): boolean;
    set hoverStateEnabled(value: boolean);
    /**
     * [descr:dxGalleryOptions.indicatorEnabled]
    
     */
    get indicatorEnabled(): boolean;
    set indicatorEnabled(value: boolean);
    /**
     * [descr:dxGalleryOptions.initialItemWidth]
    
     */
    get initialItemWidth(): number | undefined;
    set initialItemWidth(value: number | undefined);
    /**
     * [descr:CollectionWidgetOptions.itemHoldTimeout]
    
     */
    get itemHoldTimeout(): number;
    set itemHoldTimeout(value: number);
    /**
     * [descr:dxGalleryOptions.items]
    
     */
    get items(): Array<any | dxGalleryItem | string>;
    set items(value: Array<any | dxGalleryItem | string>);
    /**
     * [descr:CollectionWidgetOptions.itemTemplate]
    
     */
    get itemTemplate(): any;
    set itemTemplate(value: any);
    /**
     * [descr:dxGalleryOptions.loop]
    
     */
    get loop(): boolean;
    set loop(value: boolean);
    /**
     * [descr:dxGalleryOptions.noDataText]
    
     */
    get noDataText(): string;
    set noDataText(value: string);
    /**
     * [descr:DOMComponentOptions.rtlEnabled]
    
     */
    get rtlEnabled(): boolean;
    set rtlEnabled(value: boolean);
    /**
     * [descr:dxGalleryOptions.selectedIndex]
    
     */
    get selectedIndex(): number;
    set selectedIndex(value: number);
    /**
     * [descr:CollectionWidgetOptions.selectedItem]
    
     */
    get selectedItem(): any | null;
    set selectedItem(value: any | null);
    /**
     * [descr:dxGalleryOptions.showIndicator]
    
     */
    get showIndicator(): boolean;
    set showIndicator(value: boolean);
    /**
     * [descr:dxGalleryOptions.showNavButtons]
    
     */
    get showNavButtons(): boolean;
    set showNavButtons(value: boolean);
    /**
     * [descr:dxGalleryOptions.slideshowDelay]
    
     */
    get slideshowDelay(): number;
    set slideshowDelay(value: number);
    /**
     * [descr:dxGalleryOptions.stretchImages]
    
     */
    get stretchImages(): boolean;
    set stretchImages(value: boolean);
    /**
     * [descr:dxGalleryOptions.swipeEnabled]
    
     */
    get swipeEnabled(): boolean;
    set swipeEnabled(value: boolean);
    /**
     * [descr:WidgetOptions.tabIndex]
    
     */
    get tabIndex(): number;
    set tabIndex(value: number);
    /**
     * [descr:WidgetOptions.visible]
    
     */
    get visible(): boolean;
    set visible(value: boolean);
    /**
     * [descr:DOMComponentOptions.width]
    
     */
    get width(): number | string | undefined;
    set width(value: number | string | undefined);
    /**
     * [descr:dxGalleryOptions.wrapAround]
    
     */
    get wrapAround(): boolean;
    set wrapAround(value: boolean);
    /**
    
     * [descr:dxGalleryOptions.onContentReady]
    
    
     */
    onContentReady: EventEmitter<ContentReadyEvent>;
    /**
    
     * [descr:dxGalleryOptions.onDisposing]
    
    
     */
    onDisposing: EventEmitter<DisposingEvent>;
    /**
    
     * [descr:dxGalleryOptions.onInitialized]
    
    
     */
    onInitialized: EventEmitter<InitializedEvent>;
    /**
    
     * [descr:dxGalleryOptions.onItemClick]
    
    
     */
    onItemClick: EventEmitter<ItemClickEvent>;
    /**
    
     * [descr:dxGalleryOptions.onItemContextMenu]
    
    
     */
    onItemContextMenu: EventEmitter<ItemContextMenuEvent>;
    /**
    
     * [descr:dxGalleryOptions.onItemHold]
    
    
     */
    onItemHold: EventEmitter<ItemHoldEvent>;
    /**
    
     * [descr:dxGalleryOptions.onItemRendered]
    
    
     */
    onItemRendered: EventEmitter<ItemRenderedEvent>;
    /**
    
     * [descr:dxGalleryOptions.onOptionChanged]
    
    
     */
    onOptionChanged: EventEmitter<OptionChangedEvent>;
    /**
    
     * [descr:dxGalleryOptions.onSelectionChanged]
    
    
     */
    onSelectionChanged: EventEmitter<SelectionChangedEvent>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    accessKeyChange: EventEmitter<string | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    animationDurationChange: EventEmitter<number>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    animationEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    dataSourceChange: EventEmitter<Array<any | dxGalleryItem | string> | DataSource | DataSourceOptions | null | Store | string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    disabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    elementAttrChange: EventEmitter<Record<string, any>>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    focusStateEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    heightChange: EventEmitter<number | string | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    hintChange: EventEmitter<string | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    hoverStateEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    indicatorEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    initialItemWidthChange: EventEmitter<number | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    itemHoldTimeoutChange: EventEmitter<number>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    itemsChange: EventEmitter<Array<any | dxGalleryItem | string>>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    itemTemplateChange: EventEmitter<any>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    loopChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    noDataTextChange: EventEmitter<string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    rtlEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    selectedIndexChange: EventEmitter<number>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    selectedItemChange: EventEmitter<any | null>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    showIndicatorChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    showNavButtonsChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    slideshowDelayChange: EventEmitter<number>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    stretchImagesChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    swipeEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    tabIndexChange: EventEmitter<number>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    visibleChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    widthChange: EventEmitter<number | string | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    wrapAroundChange: EventEmitter<boolean>;
    constructor(elementRef: ElementRef, ngZone: NgZone, templateHost: DxTemplateHost, _watcherHelper: WatcherHelper, _idh: IterableDifferHelper, optionHost: NestedOptionHost, transferState: TransferState, platformId: any);
    protected _createInstance(element: any, options: any): DxGallery<any, any>;
    ngOnDestroy(): void;
    ngOnChanges(changes: SimpleChanges): void;
    setupChanges(prop: string, changes: SimpleChanges): void;
    ngDoCheck(): void;
    _setOption(name: string, value: any): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxGalleryComponent<any, any>, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxGalleryComponent<any, any>, "dx-gallery", never, { "accessKey": { "alias": "accessKey"; "required": false; }; "animationDuration": { "alias": "animationDuration"; "required": false; }; "animationEnabled": { "alias": "animationEnabled"; "required": false; }; "dataSource": { "alias": "dataSource"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "elementAttr": { "alias": "elementAttr"; "required": false; }; "focusStateEnabled": { "alias": "focusStateEnabled"; "required": false; }; "height": { "alias": "height"; "required": false; }; "hint": { "alias": "hint"; "required": false; }; "hoverStateEnabled": { "alias": "hoverStateEnabled"; "required": false; }; "indicatorEnabled": { "alias": "indicatorEnabled"; "required": false; }; "initialItemWidth": { "alias": "initialItemWidth"; "required": false; }; "itemHoldTimeout": { "alias": "itemHoldTimeout"; "required": false; }; "items": { "alias": "items"; "required": false; }; "itemTemplate": { "alias": "itemTemplate"; "required": false; }; "loop": { "alias": "loop"; "required": false; }; "noDataText": { "alias": "noDataText"; "required": false; }; "rtlEnabled": { "alias": "rtlEnabled"; "required": false; }; "selectedIndex": { "alias": "selectedIndex"; "required": false; }; "selectedItem": { "alias": "selectedItem"; "required": false; }; "showIndicator": { "alias": "showIndicator"; "required": false; }; "showNavButtons": { "alias": "showNavButtons"; "required": false; }; "slideshowDelay": { "alias": "slideshowDelay"; "required": false; }; "stretchImages": { "alias": "stretchImages"; "required": false; }; "swipeEnabled": { "alias": "swipeEnabled"; "required": false; }; "tabIndex": { "alias": "tabIndex"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; "wrapAround": { "alias": "wrapAround"; "required": false; }; }, { "onContentReady": "onContentReady"; "onDisposing": "onDisposing"; "onInitialized": "onInitialized"; "onItemClick": "onItemClick"; "onItemContextMenu": "onItemContextMenu"; "onItemHold": "onItemHold"; "onItemRendered": "onItemRendered"; "onOptionChanged": "onOptionChanged"; "onSelectionChanged": "onSelectionChanged"; "accessKeyChange": "accessKeyChange"; "animationDurationChange": "animationDurationChange"; "animationEnabledChange": "animationEnabledChange"; "dataSourceChange": "dataSourceChange"; "disabledChange": "disabledChange"; "elementAttrChange": "elementAttrChange"; "focusStateEnabledChange": "focusStateEnabledChange"; "heightChange": "heightChange"; "hintChange": "hintChange"; "hoverStateEnabledChange": "hoverStateEnabledChange"; "indicatorEnabledChange": "indicatorEnabledChange"; "initialItemWidthChange": "initialItemWidthChange"; "itemHoldTimeoutChange": "itemHoldTimeoutChange"; "itemsChange": "itemsChange"; "itemTemplateChange": "itemTemplateChange"; "loopChange": "loopChange"; "noDataTextChange": "noDataTextChange"; "rtlEnabledChange": "rtlEnabledChange"; "selectedIndexChange": "selectedIndexChange"; "selectedItemChange": "selectedItemChange"; "showIndicatorChange": "showIndicatorChange"; "showNavButtonsChange": "showNavButtonsChange"; "slideshowDelayChange": "slideshowDelayChange"; "stretchImagesChange": "stretchImagesChange"; "swipeEnabledChange": "swipeEnabledChange"; "tabIndexChange": "tabIndexChange"; "visibleChange": "visibleChange"; "widthChange": "widthChange"; "wrapAroundChange": "wrapAroundChange"; }, ["_itemsContentChildren"], never, true, never>;
}
declare class DxGalleryModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxGalleryModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxGalleryModule, never, [typeof DxGalleryComponent, typeof i1.DxiItemModule, typeof i2.DxiGalleryItemModule, typeof i3.DxIntegrationModule, typeof i3.DxTemplateModule], [typeof DxGalleryComponent, typeof i1.DxiItemModule, typeof i2.DxiGalleryItemModule, typeof i3.DxTemplateModule]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxGalleryModule>;
}

export { DxGalleryComponent, DxGalleryModule };
//# sourceMappingURL=index.d.ts.map
