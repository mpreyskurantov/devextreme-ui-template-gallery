import * as i0 from '@angular/core';
import { OnDestroy, OnInit } from '@angular/core';
import { NestedOption, NestedOptionHost } from 'devextreme-angular/core';
import { ApplyChangesMode, HeaderFilterSearchConfig, StateStoreType } from 'devextreme/common/grids';
import { FieldChooserLayout, ScrollMode, Mode, SearchMode } from 'devextreme/common';

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoPivotGridExportComponent extends NestedOption implements OnDestroy, OnInit {
    get enabled(): boolean;
    set enabled(value: boolean);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPivotGridExportComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoPivotGridExportComponent, "dxo-pivot-grid-export", never, { "enabled": { "alias": "enabled"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoPivotGridExportModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPivotGridExportModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoPivotGridExportModule, never, [typeof DxoPivotGridExportComponent], [typeof DxoPivotGridExportComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoPivotGridExportModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoPivotGridFieldChooserTextsComponent extends NestedOption implements OnDestroy, OnInit {
    get allFields(): string;
    set allFields(value: string);
    get columnFields(): string;
    set columnFields(value: string);
    get dataFields(): string;
    set dataFields(value: string);
    get filterFields(): string;
    set filterFields(value: string);
    get rowFields(): string;
    set rowFields(value: string);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPivotGridFieldChooserTextsComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoPivotGridFieldChooserTextsComponent, "dxo-pivot-grid-field-chooser-texts", never, { "allFields": { "alias": "allFields"; "required": false; }; "columnFields": { "alias": "columnFields"; "required": false; }; "dataFields": { "alias": "dataFields"; "required": false; }; "filterFields": { "alias": "filterFields"; "required": false; }; "rowFields": { "alias": "rowFields"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoPivotGridFieldChooserTextsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPivotGridFieldChooserTextsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoPivotGridFieldChooserTextsModule, never, [typeof DxoPivotGridFieldChooserTextsComponent], [typeof DxoPivotGridFieldChooserTextsComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoPivotGridFieldChooserTextsModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoPivotGridFieldChooserComponent extends NestedOption implements OnDestroy, OnInit {
    get allowSearch(): boolean;
    set allowSearch(value: boolean);
    get applyChangesMode(): ApplyChangesMode;
    set applyChangesMode(value: ApplyChangesMode);
    get enabled(): boolean;
    set enabled(value: boolean);
    get height(): number | string;
    set height(value: number | string);
    get layout(): FieldChooserLayout;
    set layout(value: FieldChooserLayout);
    get searchTimeout(): number;
    set searchTimeout(value: number);
    get texts(): {
        allFields?: string;
        columnFields?: string;
        dataFields?: string;
        filterFields?: string;
        rowFields?: string;
    };
    set texts(value: {
        allFields?: string;
        columnFields?: string;
        dataFields?: string;
        filterFields?: string;
        rowFields?: string;
    });
    get title(): string;
    set title(value: string);
    get width(): number | string;
    set width(value: number | string);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPivotGridFieldChooserComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoPivotGridFieldChooserComponent, "dxo-pivot-grid-field-chooser", never, { "allowSearch": { "alias": "allowSearch"; "required": false; }; "applyChangesMode": { "alias": "applyChangesMode"; "required": false; }; "enabled": { "alias": "enabled"; "required": false; }; "height": { "alias": "height"; "required": false; }; "layout": { "alias": "layout"; "required": false; }; "searchTimeout": { "alias": "searchTimeout"; "required": false; }; "texts": { "alias": "texts"; "required": false; }; "title": { "alias": "title"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoPivotGridFieldChooserModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPivotGridFieldChooserModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoPivotGridFieldChooserModule, never, [typeof DxoPivotGridFieldChooserComponent], [typeof DxoPivotGridFieldChooserComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoPivotGridFieldChooserModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoPivotGridFieldPanelTextsComponent extends NestedOption implements OnDestroy, OnInit {
    get columnFieldArea(): string;
    set columnFieldArea(value: string);
    get dataFieldArea(): string;
    set dataFieldArea(value: string);
    get filterFieldArea(): string;
    set filterFieldArea(value: string);
    get rowFieldArea(): string;
    set rowFieldArea(value: string);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPivotGridFieldPanelTextsComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoPivotGridFieldPanelTextsComponent, "dxo-pivot-grid-field-panel-texts", never, { "columnFieldArea": { "alias": "columnFieldArea"; "required": false; }; "dataFieldArea": { "alias": "dataFieldArea"; "required": false; }; "filterFieldArea": { "alias": "filterFieldArea"; "required": false; }; "rowFieldArea": { "alias": "rowFieldArea"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoPivotGridFieldPanelTextsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPivotGridFieldPanelTextsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoPivotGridFieldPanelTextsModule, never, [typeof DxoPivotGridFieldPanelTextsComponent], [typeof DxoPivotGridFieldPanelTextsComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoPivotGridFieldPanelTextsModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoPivotGridFieldPanelComponent extends NestedOption implements OnDestroy, OnInit {
    get allowFieldDragging(): boolean;
    set allowFieldDragging(value: boolean);
    get showColumnFields(): boolean;
    set showColumnFields(value: boolean);
    get showDataFields(): boolean;
    set showDataFields(value: boolean);
    get showFilterFields(): boolean;
    set showFilterFields(value: boolean);
    get showRowFields(): boolean;
    set showRowFields(value: boolean);
    get texts(): {
        columnFieldArea?: string;
        dataFieldArea?: string;
        filterFieldArea?: string;
        rowFieldArea?: string;
    };
    set texts(value: {
        columnFieldArea?: string;
        dataFieldArea?: string;
        filterFieldArea?: string;
        rowFieldArea?: string;
    });
    get visible(): boolean;
    set visible(value: boolean);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPivotGridFieldPanelComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoPivotGridFieldPanelComponent, "dxo-pivot-grid-field-panel", never, { "allowFieldDragging": { "alias": "allowFieldDragging"; "required": false; }; "showColumnFields": { "alias": "showColumnFields"; "required": false; }; "showDataFields": { "alias": "showDataFields"; "required": false; }; "showFilterFields": { "alias": "showFilterFields"; "required": false; }; "showRowFields": { "alias": "showRowFields"; "required": false; }; "texts": { "alias": "texts"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoPivotGridFieldPanelModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPivotGridFieldPanelModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoPivotGridFieldPanelModule, never, [typeof DxoPivotGridFieldPanelComponent], [typeof DxoPivotGridFieldPanelComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoPivotGridFieldPanelModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoPivotGridHeaderFilterTextsComponent extends NestedOption implements OnDestroy, OnInit {
    get cancel(): string;
    set cancel(value: string);
    get emptyValue(): string;
    set emptyValue(value: string);
    get ok(): string;
    set ok(value: string);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPivotGridHeaderFilterTextsComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoPivotGridHeaderFilterTextsComponent, "dxo-pivot-grid-header-filter-texts", never, { "cancel": { "alias": "cancel"; "required": false; }; "emptyValue": { "alias": "emptyValue"; "required": false; }; "ok": { "alias": "ok"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoPivotGridHeaderFilterTextsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPivotGridHeaderFilterTextsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoPivotGridHeaderFilterTextsModule, never, [typeof DxoPivotGridHeaderFilterTextsComponent], [typeof DxoPivotGridHeaderFilterTextsComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoPivotGridHeaderFilterTextsModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoPivotGridHeaderFilterComponent extends NestedOption implements OnDestroy, OnInit {
    get allowSearch(): boolean;
    set allowSearch(value: boolean);
    get allowSelectAll(): boolean;
    set allowSelectAll(value: boolean);
    get height(): number;
    set height(value: number);
    get search(): HeaderFilterSearchConfig;
    set search(value: HeaderFilterSearchConfig);
    get searchTimeout(): number;
    set searchTimeout(value: number);
    get showRelevantValues(): boolean;
    set showRelevantValues(value: boolean);
    get texts(): {
        cancel?: string;
        emptyValue?: string;
        ok?: string;
    };
    set texts(value: {
        cancel?: string;
        emptyValue?: string;
        ok?: string;
    });
    get width(): number;
    set width(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPivotGridHeaderFilterComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoPivotGridHeaderFilterComponent, "dxo-pivot-grid-header-filter", never, { "allowSearch": { "alias": "allowSearch"; "required": false; }; "allowSelectAll": { "alias": "allowSelectAll"; "required": false; }; "height": { "alias": "height"; "required": false; }; "search": { "alias": "search"; "required": false; }; "searchTimeout": { "alias": "searchTimeout"; "required": false; }; "showRelevantValues": { "alias": "showRelevantValues"; "required": false; }; "texts": { "alias": "texts"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoPivotGridHeaderFilterModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPivotGridHeaderFilterModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoPivotGridHeaderFilterModule, never, [typeof DxoPivotGridHeaderFilterComponent], [typeof DxoPivotGridHeaderFilterComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoPivotGridHeaderFilterModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoPivotGridLoadPanelComponent extends NestedOption implements OnDestroy, OnInit {
    get enabled(): boolean;
    set enabled(value: boolean);
    get height(): number;
    set height(value: number);
    get indicatorSrc(): string;
    set indicatorSrc(value: string);
    get shading(): boolean;
    set shading(value: boolean);
    get shadingColor(): string;
    set shadingColor(value: string);
    get showIndicator(): boolean;
    set showIndicator(value: boolean);
    get showPane(): boolean;
    set showPane(value: boolean);
    get text(): string;
    set text(value: string);
    get width(): number;
    set width(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPivotGridLoadPanelComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoPivotGridLoadPanelComponent, "dxo-pivot-grid-load-panel", never, { "enabled": { "alias": "enabled"; "required": false; }; "height": { "alias": "height"; "required": false; }; "indicatorSrc": { "alias": "indicatorSrc"; "required": false; }; "shading": { "alias": "shading"; "required": false; }; "shadingColor": { "alias": "shadingColor"; "required": false; }; "showIndicator": { "alias": "showIndicator"; "required": false; }; "showPane": { "alias": "showPane"; "required": false; }; "text": { "alias": "text"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoPivotGridLoadPanelModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPivotGridLoadPanelModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoPivotGridLoadPanelModule, never, [typeof DxoPivotGridLoadPanelComponent], [typeof DxoPivotGridLoadPanelComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoPivotGridLoadPanelModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoPivotGridPivotGridTextsComponent extends NestedOption implements OnDestroy, OnInit {
    get collapseAll(): string;
    set collapseAll(value: string);
    get dataNotAvailable(): string;
    set dataNotAvailable(value: string);
    get expandAll(): string;
    set expandAll(value: string);
    get exportToExcel(): string;
    set exportToExcel(value: string);
    get grandTotal(): string;
    set grandTotal(value: string);
    get noData(): string;
    set noData(value: string);
    get removeAllSorting(): string;
    set removeAllSorting(value: string);
    get showFieldChooser(): string;
    set showFieldChooser(value: string);
    get sortColumnBySummary(): string;
    set sortColumnBySummary(value: string);
    get sortRowBySummary(): string;
    set sortRowBySummary(value: string);
    get total(): string;
    set total(value: string);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPivotGridPivotGridTextsComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoPivotGridPivotGridTextsComponent, "dxo-pivot-grid-pivot-grid-texts", never, { "collapseAll": { "alias": "collapseAll"; "required": false; }; "dataNotAvailable": { "alias": "dataNotAvailable"; "required": false; }; "expandAll": { "alias": "expandAll"; "required": false; }; "exportToExcel": { "alias": "exportToExcel"; "required": false; }; "grandTotal": { "alias": "grandTotal"; "required": false; }; "noData": { "alias": "noData"; "required": false; }; "removeAllSorting": { "alias": "removeAllSorting"; "required": false; }; "showFieldChooser": { "alias": "showFieldChooser"; "required": false; }; "sortColumnBySummary": { "alias": "sortColumnBySummary"; "required": false; }; "sortRowBySummary": { "alias": "sortRowBySummary"; "required": false; }; "total": { "alias": "total"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoPivotGridPivotGridTextsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPivotGridPivotGridTextsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoPivotGridPivotGridTextsModule, never, [typeof DxoPivotGridPivotGridTextsComponent], [typeof DxoPivotGridPivotGridTextsComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoPivotGridPivotGridTextsModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoPivotGridScrollingComponent extends NestedOption implements OnDestroy, OnInit {
    get mode(): ScrollMode;
    set mode(value: ScrollMode);
    get useNative(): boolean | Mode;
    set useNative(value: boolean | Mode);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPivotGridScrollingComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoPivotGridScrollingComponent, "dxo-pivot-grid-scrolling", never, { "mode": { "alias": "mode"; "required": false; }; "useNative": { "alias": "useNative"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoPivotGridScrollingModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPivotGridScrollingModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoPivotGridScrollingModule, never, [typeof DxoPivotGridScrollingComponent], [typeof DxoPivotGridScrollingComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoPivotGridScrollingModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoPivotGridSearchComponent extends NestedOption implements OnDestroy, OnInit {
    get editorOptions(): any;
    set editorOptions(value: any);
    get enabled(): boolean;
    set enabled(value: boolean);
    get mode(): SearchMode;
    set mode(value: SearchMode);
    get timeout(): number;
    set timeout(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPivotGridSearchComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoPivotGridSearchComponent, "dxo-pivot-grid-search", never, { "editorOptions": { "alias": "editorOptions"; "required": false; }; "enabled": { "alias": "enabled"; "required": false; }; "mode": { "alias": "mode"; "required": false; }; "timeout": { "alias": "timeout"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoPivotGridSearchModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPivotGridSearchModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoPivotGridSearchModule, never, [typeof DxoPivotGridSearchComponent], [typeof DxoPivotGridSearchComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoPivotGridSearchModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoPivotGridStateStoringComponent extends NestedOption implements OnDestroy, OnInit {
    get customLoad(): Function;
    set customLoad(value: Function);
    get customSave(): ((state: any) => void);
    set customSave(value: ((state: any) => void));
    get enabled(): boolean;
    set enabled(value: boolean);
    get savingTimeout(): number;
    set savingTimeout(value: number);
    get storageKey(): string | undefined;
    set storageKey(value: string | undefined);
    get type(): StateStoreType;
    set type(value: StateStoreType);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPivotGridStateStoringComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoPivotGridStateStoringComponent, "dxo-pivot-grid-state-storing", never, { "customLoad": { "alias": "customLoad"; "required": false; }; "customSave": { "alias": "customSave"; "required": false; }; "enabled": { "alias": "enabled"; "required": false; }; "savingTimeout": { "alias": "savingTimeout"; "required": false; }; "storageKey": { "alias": "storageKey"; "required": false; }; "type": { "alias": "type"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoPivotGridStateStoringModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPivotGridStateStoringModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoPivotGridStateStoringModule, never, [typeof DxoPivotGridStateStoringComponent], [typeof DxoPivotGridStateStoringComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoPivotGridStateStoringModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoPivotGridTextsComponent extends NestedOption implements OnDestroy, OnInit {
    get allFields(): string;
    set allFields(value: string);
    get columnFields(): string;
    set columnFields(value: string);
    get dataFields(): string;
    set dataFields(value: string);
    get filterFields(): string;
    set filterFields(value: string);
    get rowFields(): string;
    set rowFields(value: string);
    get columnFieldArea(): string;
    set columnFieldArea(value: string);
    get dataFieldArea(): string;
    set dataFieldArea(value: string);
    get filterFieldArea(): string;
    set filterFieldArea(value: string);
    get rowFieldArea(): string;
    set rowFieldArea(value: string);
    get cancel(): string;
    set cancel(value: string);
    get emptyValue(): string;
    set emptyValue(value: string);
    get ok(): string;
    set ok(value: string);
    get collapseAll(): string;
    set collapseAll(value: string);
    get dataNotAvailable(): string;
    set dataNotAvailable(value: string);
    get expandAll(): string;
    set expandAll(value: string);
    get exportToExcel(): string;
    set exportToExcel(value: string);
    get grandTotal(): string;
    set grandTotal(value: string);
    get noData(): string;
    set noData(value: string);
    get removeAllSorting(): string;
    set removeAllSorting(value: string);
    get showFieldChooser(): string;
    set showFieldChooser(value: string);
    get sortColumnBySummary(): string;
    set sortColumnBySummary(value: string);
    get sortRowBySummary(): string;
    set sortRowBySummary(value: string);
    get total(): string;
    set total(value: string);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPivotGridTextsComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoPivotGridTextsComponent, "dxo-pivot-grid-texts", never, { "allFields": { "alias": "allFields"; "required": false; }; "columnFields": { "alias": "columnFields"; "required": false; }; "dataFields": { "alias": "dataFields"; "required": false; }; "filterFields": { "alias": "filterFields"; "required": false; }; "rowFields": { "alias": "rowFields"; "required": false; }; "columnFieldArea": { "alias": "columnFieldArea"; "required": false; }; "dataFieldArea": { "alias": "dataFieldArea"; "required": false; }; "filterFieldArea": { "alias": "filterFieldArea"; "required": false; }; "rowFieldArea": { "alias": "rowFieldArea"; "required": false; }; "cancel": { "alias": "cancel"; "required": false; }; "emptyValue": { "alias": "emptyValue"; "required": false; }; "ok": { "alias": "ok"; "required": false; }; "collapseAll": { "alias": "collapseAll"; "required": false; }; "dataNotAvailable": { "alias": "dataNotAvailable"; "required": false; }; "expandAll": { "alias": "expandAll"; "required": false; }; "exportToExcel": { "alias": "exportToExcel"; "required": false; }; "grandTotal": { "alias": "grandTotal"; "required": false; }; "noData": { "alias": "noData"; "required": false; }; "removeAllSorting": { "alias": "removeAllSorting"; "required": false; }; "showFieldChooser": { "alias": "showFieldChooser"; "required": false; }; "sortColumnBySummary": { "alias": "sortColumnBySummary"; "required": false; }; "sortRowBySummary": { "alias": "sortRowBySummary"; "required": false; }; "total": { "alias": "total"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoPivotGridTextsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPivotGridTextsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoPivotGridTextsModule, never, [typeof DxoPivotGridTextsComponent], [typeof DxoPivotGridTextsComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoPivotGridTextsModule>;
}

export { DxoPivotGridExportComponent, DxoPivotGridExportModule, DxoPivotGridFieldChooserComponent, DxoPivotGridFieldChooserModule, DxoPivotGridFieldChooserTextsComponent, DxoPivotGridFieldChooserTextsModule, DxoPivotGridFieldPanelComponent, DxoPivotGridFieldPanelModule, DxoPivotGridFieldPanelTextsComponent, DxoPivotGridFieldPanelTextsModule, DxoPivotGridHeaderFilterComponent, DxoPivotGridHeaderFilterModule, DxoPivotGridHeaderFilterTextsComponent, DxoPivotGridHeaderFilterTextsModule, DxoPivotGridLoadPanelComponent, DxoPivotGridLoadPanelModule, DxoPivotGridPivotGridTextsComponent, DxoPivotGridPivotGridTextsModule, DxoPivotGridScrollingComponent, DxoPivotGridScrollingModule, DxoPivotGridSearchComponent, DxoPivotGridSearchModule, DxoPivotGridStateStoringComponent, DxoPivotGridStateStoringModule, DxoPivotGridTextsComponent, DxoPivotGridTextsModule };
//# sourceMappingURL=index.d.ts.map
