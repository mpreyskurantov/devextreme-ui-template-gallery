import * as i0 from '@angular/core';
import { OnDestroy, OnChanges, DoCheck, EventEmitter, ElementRef, NgZone, TransferState, SimpleChanges } from '@angular/core';
import DxPivotGrid, { PivotGridDataFieldArea, PivotGridRowHeaderLayout, PivotGridTotalDisplayMode, CellClickEvent, CellPreparedEvent, ContentReadyEvent, ContextMenuPreparingEvent, DisposingEvent, ExportingEvent, InitializedEvent, OptionChangedEvent } from 'devextreme/ui/pivot_grid';
import PivotGridDataSource, { PivotGridDataSourceOptions } from 'devextreme/ui/pivot_grid/data_source';
import { ApplyChangesMode, HeaderFilterSearchConfig, StateStoreType } from 'devextreme/common/grids';
import { FieldChooserLayout, ScrollMode, Mode } from 'devextreme/common';
import * as i3 from 'devextreme-angular/core';
import { DxComponent, DxTemplateHost, WatcherHelper, IterableDifferHelper, NestedOptionHost } from 'devextreme-angular/core';
import * as i1 from 'devextreme-angular/ui/nested';
import * as i2 from 'devextreme-angular/ui/pivot-grid/nested';
export * from 'devextreme-angular/ui/pivot-grid/nested';
import * as pivot_grid_types from 'devextreme/ui/pivot_grid_types';
export { pivot_grid_types as DxPivotGridTypes };

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

/**
 * [descr:dxPivotGrid]

 */
declare class DxPivotGridComponent extends DxComponent implements OnDestroy, OnChanges, DoCheck {
    private _watcherHelper;
    private _idh;
    instance: DxPivotGrid;
    /**
     * [descr:dxPivotGridOptions.allowExpandAll]
    
     */
    get allowExpandAll(): boolean;
    set allowExpandAll(value: boolean);
    /**
     * [descr:dxPivotGridOptions.allowFiltering]
    
     */
    get allowFiltering(): boolean;
    set allowFiltering(value: boolean);
    /**
     * [descr:dxPivotGridOptions.allowSorting]
    
     */
    get allowSorting(): boolean;
    set allowSorting(value: boolean);
    /**
     * [descr:dxPivotGridOptions.allowSortingBySummary]
    
     */
    get allowSortingBySummary(): boolean;
    set allowSortingBySummary(value: boolean);
    /**
     * [descr:dxPivotGridOptions.dataFieldArea]
    
     */
    get dataFieldArea(): PivotGridDataFieldArea;
    set dataFieldArea(value: PivotGridDataFieldArea);
    /**
     * [descr:dxPivotGridOptions.dataSource]
    
     */
    get dataSource(): Array<any> | null | PivotGridDataSource | PivotGridDataSourceOptions;
    set dataSource(value: Array<any> | null | PivotGridDataSource | PivotGridDataSourceOptions);
    /**
     * [descr:WidgetOptions.disabled]
    
     */
    get disabled(): boolean;
    set disabled(value: boolean);
    /**
     * [descr:DOMComponentOptions.elementAttr]
    
     */
    get elementAttr(): Record<string, any>;
    set elementAttr(value: Record<string, any>);
    /**
     * [descr:dxPivotGridOptions.encodeHtml]
    
     */
    get encodeHtml(): boolean;
    set encodeHtml(value: boolean);
    /**
     * [descr:dxPivotGridOptions.export]
    
     */
    get export(): {
        enabled?: boolean;
    };
    set export(value: {
        enabled?: boolean;
    });
    /**
     * [descr:dxPivotGridOptions.fieldChooser]
    
     */
    get fieldChooser(): {
        allowSearch?: boolean;
        applyChangesMode?: ApplyChangesMode;
        enabled?: boolean;
        height?: number | string;
        layout?: FieldChooserLayout;
        searchTimeout?: number;
        texts?: {
            allFields?: string;
            columnFields?: string;
            dataFields?: string;
            filterFields?: string;
            rowFields?: string;
        };
        title?: string;
        width?: number | string;
    };
    set fieldChooser(value: {
        allowSearch?: boolean;
        applyChangesMode?: ApplyChangesMode;
        enabled?: boolean;
        height?: number | string;
        layout?: FieldChooserLayout;
        searchTimeout?: number;
        texts?: {
            allFields?: string;
            columnFields?: string;
            dataFields?: string;
            filterFields?: string;
            rowFields?: string;
        };
        title?: string;
        width?: number | string;
    });
    /**
     * [descr:dxPivotGridOptions.fieldPanel]
    
     */
    get fieldPanel(): {
        allowFieldDragging?: boolean;
        showColumnFields?: boolean;
        showDataFields?: boolean;
        showFilterFields?: boolean;
        showRowFields?: boolean;
        texts?: {
            columnFieldArea?: string;
            dataFieldArea?: string;
            filterFieldArea?: string;
            rowFieldArea?: string;
        };
        visible?: boolean;
    };
    set fieldPanel(value: {
        allowFieldDragging?: boolean;
        showColumnFields?: boolean;
        showDataFields?: boolean;
        showFilterFields?: boolean;
        showRowFields?: boolean;
        texts?: {
            columnFieldArea?: string;
            dataFieldArea?: string;
            filterFieldArea?: string;
            rowFieldArea?: string;
        };
        visible?: boolean;
    });
    /**
     * [descr:dxPivotGridOptions.headerFilter]
    
     */
    get headerFilter(): {
        allowSearch?: boolean;
        allowSelectAll?: boolean;
        height?: number;
        search?: HeaderFilterSearchConfig;
        searchTimeout?: number;
        showRelevantValues?: boolean;
        texts?: {
            cancel?: string;
            emptyValue?: string;
            ok?: string;
        };
        width?: number;
    };
    set headerFilter(value: {
        allowSearch?: boolean;
        allowSelectAll?: boolean;
        height?: number;
        search?: HeaderFilterSearchConfig;
        searchTimeout?: number;
        showRelevantValues?: boolean;
        texts?: {
            cancel?: string;
            emptyValue?: string;
            ok?: string;
        };
        width?: number;
    });
    /**
     * [descr:DOMComponentOptions.height]
    
     */
    get height(): number | string | undefined;
    set height(value: number | string | undefined);
    /**
     * [descr:dxPivotGridOptions.hideEmptySummaryCells]
    
     */
    get hideEmptySummaryCells(): boolean;
    set hideEmptySummaryCells(value: boolean);
    /**
     * [descr:WidgetOptions.hint]
    
     */
    get hint(): string | undefined;
    set hint(value: string | undefined);
    /**
     * [descr:dxPivotGridOptions.loadPanel]
    
     */
    get loadPanel(): {
        enabled?: boolean;
        height?: number;
        indicatorSrc?: string;
        shading?: boolean;
        shadingColor?: string;
        showIndicator?: boolean;
        showPane?: boolean;
        text?: string;
        width?: number;
    };
    set loadPanel(value: {
        enabled?: boolean;
        height?: number;
        indicatorSrc?: string;
        shading?: boolean;
        shadingColor?: string;
        showIndicator?: boolean;
        showPane?: boolean;
        text?: string;
        width?: number;
    });
    /**
     * [descr:dxPivotGridOptions.rowHeaderLayout]
    
     */
    get rowHeaderLayout(): PivotGridRowHeaderLayout;
    set rowHeaderLayout(value: PivotGridRowHeaderLayout);
    /**
     * [descr:DOMComponentOptions.rtlEnabled]
    
     */
    get rtlEnabled(): boolean;
    set rtlEnabled(value: boolean);
    /**
     * [descr:dxPivotGridOptions.scrolling]
    
     */
    get scrolling(): {
        mode?: ScrollMode;
        useNative?: boolean | Mode;
    };
    set scrolling(value: {
        mode?: ScrollMode;
        useNative?: boolean | Mode;
    });
    /**
     * [descr:dxPivotGridOptions.showBorders]
    
     */
    get showBorders(): boolean;
    set showBorders(value: boolean);
    /**
     * [descr:dxPivotGridOptions.showColumnGrandTotals]
    
     */
    get showColumnGrandTotals(): boolean;
    set showColumnGrandTotals(value: boolean);
    /**
     * [descr:dxPivotGridOptions.showColumnTotals]
    
     */
    get showColumnTotals(): boolean;
    set showColumnTotals(value: boolean);
    /**
     * [descr:dxPivotGridOptions.showRowGrandTotals]
    
     */
    get showRowGrandTotals(): boolean;
    set showRowGrandTotals(value: boolean);
    /**
     * [descr:dxPivotGridOptions.showRowTotals]
    
     */
    get showRowTotals(): boolean;
    set showRowTotals(value: boolean);
    /**
     * [descr:dxPivotGridOptions.showTotalsPrior]
    
     */
    get showTotalsPrior(): PivotGridTotalDisplayMode;
    set showTotalsPrior(value: PivotGridTotalDisplayMode);
    /**
     * [descr:dxPivotGridOptions.stateStoring]
    
     */
    get stateStoring(): {
        customLoad?: Function;
        customSave?: ((state: any) => void);
        enabled?: boolean;
        savingTimeout?: number;
        storageKey?: string | undefined;
        type?: StateStoreType;
    };
    set stateStoring(value: {
        customLoad?: Function;
        customSave?: ((state: any) => void);
        enabled?: boolean;
        savingTimeout?: number;
        storageKey?: string | undefined;
        type?: StateStoreType;
    });
    /**
     * [descr:WidgetOptions.tabIndex]
    
     */
    get tabIndex(): number;
    set tabIndex(value: number);
    /**
     * [descr:dxPivotGridOptions.texts]
    
     */
    get texts(): {
        collapseAll?: string;
        dataNotAvailable?: string;
        expandAll?: string;
        exportToExcel?: string;
        grandTotal?: string;
        noData?: string;
        removeAllSorting?: string;
        showFieldChooser?: string;
        sortColumnBySummary?: string;
        sortRowBySummary?: string;
        total?: string;
    };
    set texts(value: {
        collapseAll?: string;
        dataNotAvailable?: string;
        expandAll?: string;
        exportToExcel?: string;
        grandTotal?: string;
        noData?: string;
        removeAllSorting?: string;
        showFieldChooser?: string;
        sortColumnBySummary?: string;
        sortRowBySummary?: string;
        total?: string;
    });
    /**
     * [descr:WidgetOptions.visible]
    
     */
    get visible(): boolean;
    set visible(value: boolean);
    /**
     * [descr:DOMComponentOptions.width]
    
     */
    get width(): number | string | undefined;
    set width(value: number | string | undefined);
    /**
     * [descr:dxPivotGridOptions.wordWrapEnabled]
    
     */
    get wordWrapEnabled(): boolean;
    set wordWrapEnabled(value: boolean);
    /**
    
     * [descr:dxPivotGridOptions.onCellClick]
    
    
     */
    onCellClick: EventEmitter<CellClickEvent>;
    /**
    
     * [descr:dxPivotGridOptions.onCellPrepared]
    
    
     */
    onCellPrepared: EventEmitter<CellPreparedEvent>;
    /**
    
     * [descr:dxPivotGridOptions.onContentReady]
    
    
     */
    onContentReady: EventEmitter<ContentReadyEvent>;
    /**
    
     * [descr:dxPivotGridOptions.onContextMenuPreparing]
    
    
     */
    onContextMenuPreparing: EventEmitter<ContextMenuPreparingEvent>;
    /**
    
     * [descr:dxPivotGridOptions.onDisposing]
    
    
     */
    onDisposing: EventEmitter<DisposingEvent>;
    /**
    
     * [descr:dxPivotGridOptions.onExporting]
    
    
     */
    onExporting: EventEmitter<ExportingEvent>;
    /**
    
     * [descr:dxPivotGridOptions.onInitialized]
    
    
     */
    onInitialized: EventEmitter<InitializedEvent>;
    /**
    
     * [descr:dxPivotGridOptions.onOptionChanged]
    
    
     */
    onOptionChanged: EventEmitter<OptionChangedEvent>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    allowExpandAllChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    allowFilteringChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    allowSortingChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    allowSortingBySummaryChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    dataFieldAreaChange: EventEmitter<PivotGridDataFieldArea>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    dataSourceChange: EventEmitter<Array<any> | null | PivotGridDataSource | PivotGridDataSourceOptions>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    disabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    elementAttrChange: EventEmitter<Record<string, any>>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    encodeHtmlChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    exportChange: EventEmitter<{
        enabled?: boolean;
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    fieldChooserChange: EventEmitter<{
        allowSearch?: boolean;
        applyChangesMode?: ApplyChangesMode;
        enabled?: boolean;
        height?: number | string;
        layout?: FieldChooserLayout;
        searchTimeout?: number;
        texts?: {
            allFields?: string;
            columnFields?: string;
            dataFields?: string;
            filterFields?: string;
            rowFields?: string;
        };
        title?: string;
        width?: number | string;
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    fieldPanelChange: EventEmitter<{
        allowFieldDragging?: boolean;
        showColumnFields?: boolean;
        showDataFields?: boolean;
        showFilterFields?: boolean;
        showRowFields?: boolean;
        texts?: {
            columnFieldArea?: string;
            dataFieldArea?: string;
            filterFieldArea?: string;
            rowFieldArea?: string;
        };
        visible?: boolean;
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    headerFilterChange: EventEmitter<{
        allowSearch?: boolean;
        allowSelectAll?: boolean;
        height?: number;
        search?: HeaderFilterSearchConfig;
        searchTimeout?: number;
        showRelevantValues?: boolean;
        texts?: {
            cancel?: string;
            emptyValue?: string;
            ok?: string;
        };
        width?: number;
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    heightChange: EventEmitter<number | string | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    hideEmptySummaryCellsChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    hintChange: EventEmitter<string | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    loadPanelChange: EventEmitter<{
        enabled?: boolean;
        height?: number;
        indicatorSrc?: string;
        shading?: boolean;
        shadingColor?: string;
        showIndicator?: boolean;
        showPane?: boolean;
        text?: string;
        width?: number;
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    rowHeaderLayoutChange: EventEmitter<PivotGridRowHeaderLayout>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    rtlEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    scrollingChange: EventEmitter<{
        mode?: ScrollMode;
        useNative?: boolean | Mode;
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    showBordersChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    showColumnGrandTotalsChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    showColumnTotalsChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    showRowGrandTotalsChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    showRowTotalsChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    showTotalsPriorChange: EventEmitter<PivotGridTotalDisplayMode>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    stateStoringChange: EventEmitter<{
        customLoad?: Function;
        customSave?: ((state: any) => void);
        enabled?: boolean;
        savingTimeout?: number;
        storageKey?: string | undefined;
        type?: StateStoreType;
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    tabIndexChange: EventEmitter<number>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    textsChange: EventEmitter<{
        collapseAll?: string;
        dataNotAvailable?: string;
        expandAll?: string;
        exportToExcel?: string;
        grandTotal?: string;
        noData?: string;
        removeAllSorting?: string;
        showFieldChooser?: string;
        sortColumnBySummary?: string;
        sortRowBySummary?: string;
        total?: string;
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    visibleChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    widthChange: EventEmitter<number | string | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    wordWrapEnabledChange: EventEmitter<boolean>;
    constructor(elementRef: ElementRef, ngZone: NgZone, templateHost: DxTemplateHost, _watcherHelper: WatcherHelper, _idh: IterableDifferHelper, optionHost: NestedOptionHost, transferState: TransferState, platformId: any);
    protected _createInstance(element: any, options: any): DxPivotGrid;
    ngOnDestroy(): void;
    ngOnChanges(changes: SimpleChanges): void;
    setupChanges(prop: string, changes: SimpleChanges): void;
    ngDoCheck(): void;
    _setOption(name: string, value: any): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxPivotGridComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxPivotGridComponent, "dx-pivot-grid", never, { "allowExpandAll": { "alias": "allowExpandAll"; "required": false; }; "allowFiltering": { "alias": "allowFiltering"; "required": false; }; "allowSorting": { "alias": "allowSorting"; "required": false; }; "allowSortingBySummary": { "alias": "allowSortingBySummary"; "required": false; }; "dataFieldArea": { "alias": "dataFieldArea"; "required": false; }; "dataSource": { "alias": "dataSource"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "elementAttr": { "alias": "elementAttr"; "required": false; }; "encodeHtml": { "alias": "encodeHtml"; "required": false; }; "export": { "alias": "export"; "required": false; }; "fieldChooser": { "alias": "fieldChooser"; "required": false; }; "fieldPanel": { "alias": "fieldPanel"; "required": false; }; "headerFilter": { "alias": "headerFilter"; "required": false; }; "height": { "alias": "height"; "required": false; }; "hideEmptySummaryCells": { "alias": "hideEmptySummaryCells"; "required": false; }; "hint": { "alias": "hint"; "required": false; }; "loadPanel": { "alias": "loadPanel"; "required": false; }; "rowHeaderLayout": { "alias": "rowHeaderLayout"; "required": false; }; "rtlEnabled": { "alias": "rtlEnabled"; "required": false; }; "scrolling": { "alias": "scrolling"; "required": false; }; "showBorders": { "alias": "showBorders"; "required": false; }; "showColumnGrandTotals": { "alias": "showColumnGrandTotals"; "required": false; }; "showColumnTotals": { "alias": "showColumnTotals"; "required": false; }; "showRowGrandTotals": { "alias": "showRowGrandTotals"; "required": false; }; "showRowTotals": { "alias": "showRowTotals"; "required": false; }; "showTotalsPrior": { "alias": "showTotalsPrior"; "required": false; }; "stateStoring": { "alias": "stateStoring"; "required": false; }; "tabIndex": { "alias": "tabIndex"; "required": false; }; "texts": { "alias": "texts"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; "wordWrapEnabled": { "alias": "wordWrapEnabled"; "required": false; }; }, { "onCellClick": "onCellClick"; "onCellPrepared": "onCellPrepared"; "onContentReady": "onContentReady"; "onContextMenuPreparing": "onContextMenuPreparing"; "onDisposing": "onDisposing"; "onExporting": "onExporting"; "onInitialized": "onInitialized"; "onOptionChanged": "onOptionChanged"; "allowExpandAllChange": "allowExpandAllChange"; "allowFilteringChange": "allowFilteringChange"; "allowSortingChange": "allowSortingChange"; "allowSortingBySummaryChange": "allowSortingBySummaryChange"; "dataFieldAreaChange": "dataFieldAreaChange"; "dataSourceChange": "dataSourceChange"; "disabledChange": "disabledChange"; "elementAttrChange": "elementAttrChange"; "encodeHtmlChange": "encodeHtmlChange"; "exportChange": "exportChange"; "fieldChooserChange": "fieldChooserChange"; "fieldPanelChange": "fieldPanelChange"; "headerFilterChange": "headerFilterChange"; "heightChange": "heightChange"; "hideEmptySummaryCellsChange": "hideEmptySummaryCellsChange"; "hintChange": "hintChange"; "loadPanelChange": "loadPanelChange"; "rowHeaderLayoutChange": "rowHeaderLayoutChange"; "rtlEnabledChange": "rtlEnabledChange"; "scrollingChange": "scrollingChange"; "showBordersChange": "showBordersChange"; "showColumnGrandTotalsChange": "showColumnGrandTotalsChange"; "showColumnTotalsChange": "showColumnTotalsChange"; "showRowGrandTotalsChange": "showRowGrandTotalsChange"; "showRowTotalsChange": "showRowTotalsChange"; "showTotalsPriorChange": "showTotalsPriorChange"; "stateStoringChange": "stateStoringChange"; "tabIndexChange": "tabIndexChange"; "textsChange": "textsChange"; "visibleChange": "visibleChange"; "widthChange": "widthChange"; "wordWrapEnabledChange": "wordWrapEnabledChange"; }, never, never, true, never>;
}
declare class DxPivotGridModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxPivotGridModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxPivotGridModule, never, [typeof DxPivotGridComponent, typeof i1.DxoExportModule, typeof i1.DxoFieldChooserModule, typeof i1.DxoTextsModule, typeof i1.DxoFieldPanelModule, typeof i1.DxoHeaderFilterModule, typeof i1.DxoSearchModule, typeof i1.DxoLoadPanelModule, typeof i1.DxoScrollingModule, typeof i1.DxoStateStoringModule, typeof i2.DxoPivotGridExportModule, typeof i2.DxoPivotGridFieldChooserModule, typeof i2.DxoPivotGridFieldChooserTextsModule, typeof i2.DxoPivotGridFieldPanelModule, typeof i2.DxoPivotGridFieldPanelTextsModule, typeof i2.DxoPivotGridHeaderFilterModule, typeof i2.DxoPivotGridHeaderFilterTextsModule, typeof i2.DxoPivotGridLoadPanelModule, typeof i2.DxoPivotGridPivotGridTextsModule, typeof i2.DxoPivotGridScrollingModule, typeof i2.DxoPivotGridSearchModule, typeof i2.DxoPivotGridStateStoringModule, typeof i2.DxoPivotGridTextsModule, typeof i3.DxIntegrationModule, typeof i3.DxTemplateModule], [typeof DxPivotGridComponent, typeof i1.DxoExportModule, typeof i1.DxoFieldChooserModule, typeof i1.DxoTextsModule, typeof i1.DxoFieldPanelModule, typeof i1.DxoHeaderFilterModule, typeof i1.DxoSearchModule, typeof i1.DxoLoadPanelModule, typeof i1.DxoScrollingModule, typeof i1.DxoStateStoringModule, typeof i2.DxoPivotGridExportModule, typeof i2.DxoPivotGridFieldChooserModule, typeof i2.DxoPivotGridFieldChooserTextsModule, typeof i2.DxoPivotGridFieldPanelModule, typeof i2.DxoPivotGridFieldPanelTextsModule, typeof i2.DxoPivotGridHeaderFilterModule, typeof i2.DxoPivotGridHeaderFilterTextsModule, typeof i2.DxoPivotGridLoadPanelModule, typeof i2.DxoPivotGridPivotGridTextsModule, typeof i2.DxoPivotGridScrollingModule, typeof i2.DxoPivotGridSearchModule, typeof i2.DxoPivotGridStateStoringModule, typeof i2.DxoPivotGridTextsModule, typeof i3.DxTemplateModule]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxPivotGridModule>;
}

export { DxPivotGridComponent, DxPivotGridModule };
//# sourceMappingURL=index.d.ts.map
