import * as i0 from '@angular/core';
import { OnDestroy, OnInit, EventEmitter, QueryList } from '@angular/core';
import { AnimationEaseMode, DashStyle, Font, LabelOverlap, ChartsColor, Palette, PaletteExtensionMode, TextOverflow, WordWrap } from 'devextreme/common/charts';
import { NestedOption, NestedOptionHost, CollectionNestedOption } from 'devextreme-angular/core';
import { ExportFormat, Format, Orientation, HorizontalAlignment, VerticalAlignment, HorizontalEdge, VerticalEdge } from 'devextreme/common';
import { Format as Format$1 } from 'devextreme/common/core/localization';

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoLinearGaugeAnimationComponent extends NestedOption implements OnDestroy, OnInit {
    get duration(): number;
    set duration(value: number);
    get easing(): AnimationEaseMode;
    set easing(value: AnimationEaseMode);
    get enabled(): boolean;
    set enabled(value: boolean);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoLinearGaugeAnimationComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoLinearGaugeAnimationComponent, "dxo-linear-gauge-animation", never, { "duration": { "alias": "duration"; "required": false; }; "easing": { "alias": "easing"; "required": false; }; "enabled": { "alias": "enabled"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoLinearGaugeAnimationModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoLinearGaugeAnimationModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoLinearGaugeAnimationModule, never, [typeof DxoLinearGaugeAnimationComponent], [typeof DxoLinearGaugeAnimationComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoLinearGaugeAnimationModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoLinearGaugeBackgroundColorComponent extends NestedOption implements OnDestroy, OnInit {
    get base(): string | undefined;
    set base(value: string | undefined);
    get fillId(): string | undefined;
    set fillId(value: string | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoLinearGaugeBackgroundColorComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoLinearGaugeBackgroundColorComponent, "dxo-linear-gauge-background-color", never, { "base": { "alias": "base"; "required": false; }; "fillId": { "alias": "fillId"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoLinearGaugeBackgroundColorModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoLinearGaugeBackgroundColorModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoLinearGaugeBackgroundColorModule, never, [typeof DxoLinearGaugeBackgroundColorComponent], [typeof DxoLinearGaugeBackgroundColorComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoLinearGaugeBackgroundColorModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoLinearGaugeBorderComponent extends NestedOption implements OnDestroy, OnInit {
    get color(): string;
    set color(value: string);
    get dashStyle(): DashStyle;
    set dashStyle(value: DashStyle);
    get opacity(): number | undefined;
    set opacity(value: number | undefined);
    get visible(): boolean;
    set visible(value: boolean);
    get width(): number;
    set width(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoLinearGaugeBorderComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoLinearGaugeBorderComponent, "dxo-linear-gauge-border", never, { "color": { "alias": "color"; "required": false; }; "dashStyle": { "alias": "dashStyle"; "required": false; }; "opacity": { "alias": "opacity"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoLinearGaugeBorderModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoLinearGaugeBorderModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoLinearGaugeBorderModule, never, [typeof DxoLinearGaugeBorderComponent], [typeof DxoLinearGaugeBorderComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoLinearGaugeBorderModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoLinearGaugeColorComponent extends NestedOption implements OnDestroy, OnInit {
    get base(): string | undefined;
    set base(value: string | undefined);
    get fillId(): string | undefined;
    set fillId(value: string | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoLinearGaugeColorComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoLinearGaugeColorComponent, "dxo-linear-gauge-color", never, { "base": { "alias": "base"; "required": false; }; "fillId": { "alias": "fillId"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoLinearGaugeColorModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoLinearGaugeColorModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoLinearGaugeColorModule, never, [typeof DxoLinearGaugeColorComponent], [typeof DxoLinearGaugeColorComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoLinearGaugeColorModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoLinearGaugeExportComponent extends NestedOption implements OnDestroy, OnInit {
    get backgroundColor(): string;
    set backgroundColor(value: string);
    get enabled(): boolean;
    set enabled(value: boolean);
    get fileName(): string;
    set fileName(value: string);
    get formats(): Array<ExportFormat>;
    set formats(value: Array<ExportFormat>);
    get margin(): number;
    set margin(value: number);
    get printingEnabled(): boolean;
    set printingEnabled(value: boolean);
    get svgToCanvas(): ((svg: any, canvas: any) => any) | undefined;
    set svgToCanvas(value: ((svg: any, canvas: any) => any) | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoLinearGaugeExportComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoLinearGaugeExportComponent, "dxo-linear-gauge-export", never, { "backgroundColor": { "alias": "backgroundColor"; "required": false; }; "enabled": { "alias": "enabled"; "required": false; }; "fileName": { "alias": "fileName"; "required": false; }; "formats": { "alias": "formats"; "required": false; }; "margin": { "alias": "margin"; "required": false; }; "printingEnabled": { "alias": "printingEnabled"; "required": false; }; "svgToCanvas": { "alias": "svgToCanvas"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoLinearGaugeExportModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoLinearGaugeExportModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoLinearGaugeExportModule, never, [typeof DxoLinearGaugeExportComponent], [typeof DxoLinearGaugeExportComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoLinearGaugeExportModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoLinearGaugeFontComponent extends NestedOption implements OnDestroy, OnInit {
    get color(): string;
    set color(value: string);
    get family(): string;
    set family(value: string);
    get opacity(): number;
    set opacity(value: number);
    get size(): number | string;
    set size(value: number | string);
    get weight(): number;
    set weight(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoLinearGaugeFontComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoLinearGaugeFontComponent, "dxo-linear-gauge-font", never, { "color": { "alias": "color"; "required": false; }; "family": { "alias": "family"; "required": false; }; "opacity": { "alias": "opacity"; "required": false; }; "size": { "alias": "size"; "required": false; }; "weight": { "alias": "weight"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoLinearGaugeFontModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoLinearGaugeFontModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoLinearGaugeFontModule, never, [typeof DxoLinearGaugeFontComponent], [typeof DxoLinearGaugeFontComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoLinearGaugeFontModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoLinearGaugeFormatComponent extends NestedOption implements OnDestroy, OnInit {
    get currency(): string;
    set currency(value: string);
    get formatter(): ((value: number | Date) => string);
    set formatter(value: ((value: number | Date) => string));
    get parser(): ((value: string) => number | Date);
    set parser(value: ((value: string) => number | Date));
    get precision(): number;
    set precision(value: number);
    get type(): Format | string;
    set type(value: Format | string);
    get useCurrencyAccountingStyle(): boolean;
    set useCurrencyAccountingStyle(value: boolean);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoLinearGaugeFormatComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoLinearGaugeFormatComponent, "dxo-linear-gauge-format", never, { "currency": { "alias": "currency"; "required": false; }; "formatter": { "alias": "formatter"; "required": false; }; "parser": { "alias": "parser"; "required": false; }; "precision": { "alias": "precision"; "required": false; }; "type": { "alias": "type"; "required": false; }; "useCurrencyAccountingStyle": { "alias": "useCurrencyAccountingStyle"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoLinearGaugeFormatModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoLinearGaugeFormatModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoLinearGaugeFormatModule, never, [typeof DxoLinearGaugeFormatComponent], [typeof DxoLinearGaugeFormatComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoLinearGaugeFormatModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoLinearGaugeGeometryComponent extends NestedOption implements OnDestroy, OnInit {
    get orientation(): Orientation;
    set orientation(value: Orientation);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoLinearGaugeGeometryComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoLinearGaugeGeometryComponent, "dxo-linear-gauge-geometry", never, { "orientation": { "alias": "orientation"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoLinearGaugeGeometryModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoLinearGaugeGeometryModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoLinearGaugeGeometryModule, never, [typeof DxoLinearGaugeGeometryComponent], [typeof DxoLinearGaugeGeometryComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoLinearGaugeGeometryModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoLinearGaugeLabelComponent extends NestedOption implements OnDestroy, OnInit {
    get customizeText(): ((scaleValue: {
        value: number;
        valueText: string;
    }) => string);
    set customizeText(value: ((scaleValue: {
        value: number;
        valueText: string;
    }) => string));
    get font(): Font;
    set font(value: Font);
    get format(): Format$1 | undefined;
    set format(value: Format$1 | undefined);
    get indentFromTick(): number;
    set indentFromTick(value: number);
    get overlappingBehavior(): LabelOverlap;
    set overlappingBehavior(value: LabelOverlap);
    get useRangeColors(): boolean;
    set useRangeColors(value: boolean);
    get visible(): boolean;
    set visible(value: boolean);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoLinearGaugeLabelComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoLinearGaugeLabelComponent, "dxo-linear-gauge-label", never, { "customizeText": { "alias": "customizeText"; "required": false; }; "font": { "alias": "font"; "required": false; }; "format": { "alias": "format"; "required": false; }; "indentFromTick": { "alias": "indentFromTick"; "required": false; }; "overlappingBehavior": { "alias": "overlappingBehavior"; "required": false; }; "useRangeColors": { "alias": "useRangeColors"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoLinearGaugeLabelModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoLinearGaugeLabelModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoLinearGaugeLabelModule, never, [typeof DxoLinearGaugeLabelComponent], [typeof DxoLinearGaugeLabelComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoLinearGaugeLabelModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoLinearGaugeLoadingIndicatorComponent extends NestedOption implements OnDestroy, OnInit {
    get backgroundColor(): string;
    set backgroundColor(value: string);
    get font(): Font;
    set font(value: Font);
    get show(): boolean;
    set show(value: boolean);
    get text(): string;
    set text(value: string);
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    showChange: EventEmitter<boolean>;
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoLinearGaugeLoadingIndicatorComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoLinearGaugeLoadingIndicatorComponent, "dxo-linear-gauge-loading-indicator", never, { "backgroundColor": { "alias": "backgroundColor"; "required": false; }; "font": { "alias": "font"; "required": false; }; "show": { "alias": "show"; "required": false; }; "text": { "alias": "text"; "required": false; }; }, { "showChange": "showChange"; }, never, never, true, never>;
}
declare class DxoLinearGaugeLoadingIndicatorModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoLinearGaugeLoadingIndicatorModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoLinearGaugeLoadingIndicatorModule, never, [typeof DxoLinearGaugeLoadingIndicatorComponent], [typeof DxoLinearGaugeLoadingIndicatorComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoLinearGaugeLoadingIndicatorModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoLinearGaugeMarginComponent extends NestedOption implements OnDestroy, OnInit {
    get bottom(): number;
    set bottom(value: number);
    get left(): number;
    set left(value: number);
    get right(): number;
    set right(value: number);
    get top(): number;
    set top(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoLinearGaugeMarginComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoLinearGaugeMarginComponent, "dxo-linear-gauge-margin", never, { "bottom": { "alias": "bottom"; "required": false; }; "left": { "alias": "left"; "required": false; }; "right": { "alias": "right"; "required": false; }; "top": { "alias": "top"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoLinearGaugeMarginModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoLinearGaugeMarginModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoLinearGaugeMarginModule, never, [typeof DxoLinearGaugeMarginComponent], [typeof DxoLinearGaugeMarginComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoLinearGaugeMarginModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoLinearGaugeMinorTickComponent extends NestedOption implements OnDestroy, OnInit {
    get color(): string;
    set color(value: string);
    get length(): number;
    set length(value: number);
    get opacity(): number;
    set opacity(value: number);
    get visible(): boolean;
    set visible(value: boolean);
    get width(): number;
    set width(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoLinearGaugeMinorTickComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoLinearGaugeMinorTickComponent, "dxo-linear-gauge-minor-tick", never, { "color": { "alias": "color"; "required": false; }; "length": { "alias": "length"; "required": false; }; "opacity": { "alias": "opacity"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoLinearGaugeMinorTickModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoLinearGaugeMinorTickModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoLinearGaugeMinorTickModule, never, [typeof DxoLinearGaugeMinorTickComponent], [typeof DxoLinearGaugeMinorTickComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoLinearGaugeMinorTickModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoLinearGaugeRangeContainerComponent extends NestedOption implements OnDestroy, OnInit {
    set _rangesContentChildren(value: QueryList<CollectionNestedOption>);
    get backgroundColor(): ChartsColor | string;
    set backgroundColor(value: ChartsColor | string);
    get horizontalOrientation(): HorizontalAlignment;
    set horizontalOrientation(value: HorizontalAlignment);
    get offset(): number;
    set offset(value: number);
    get palette(): Array<string> | Palette;
    set palette(value: Array<string> | Palette);
    get paletteExtensionMode(): PaletteExtensionMode;
    set paletteExtensionMode(value: PaletteExtensionMode);
    get ranges(): {
        color?: ChartsColor | string;
        endValue?: number;
        startValue?: number;
    }[];
    set ranges(value: {
        color?: ChartsColor | string;
        endValue?: number;
        startValue?: number;
    }[]);
    get verticalOrientation(): VerticalAlignment;
    set verticalOrientation(value: VerticalAlignment);
    get width(): number | {
        end?: number;
        start?: number;
    };
    set width(value: number | {
        end?: number;
        start?: number;
    });
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoLinearGaugeRangeContainerComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoLinearGaugeRangeContainerComponent, "dxo-linear-gauge-range-container", never, { "backgroundColor": { "alias": "backgroundColor"; "required": false; }; "horizontalOrientation": { "alias": "horizontalOrientation"; "required": false; }; "offset": { "alias": "offset"; "required": false; }; "palette": { "alias": "palette"; "required": false; }; "paletteExtensionMode": { "alias": "paletteExtensionMode"; "required": false; }; "ranges": { "alias": "ranges"; "required": false; }; "verticalOrientation": { "alias": "verticalOrientation"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, ["_rangesContentChildren"], never, true, never>;
}
declare class DxoLinearGaugeRangeContainerModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoLinearGaugeRangeContainerModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoLinearGaugeRangeContainerModule, never, [typeof DxoLinearGaugeRangeContainerComponent], [typeof DxoLinearGaugeRangeContainerComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoLinearGaugeRangeContainerModule>;
}

declare class DxiLinearGaugeRangeComponent extends CollectionNestedOption {
    get color(): ChartsColor | string;
    set color(value: ChartsColor | string);
    get endValue(): number;
    set endValue(value: number);
    get startValue(): number;
    set startValue(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiLinearGaugeRangeComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiLinearGaugeRangeComponent, "dxi-linear-gauge-range", never, { "color": { "alias": "color"; "required": false; }; "endValue": { "alias": "endValue"; "required": false; }; "startValue": { "alias": "startValue"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxiLinearGaugeRangeModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiLinearGaugeRangeModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiLinearGaugeRangeModule, never, [typeof DxiLinearGaugeRangeComponent], [typeof DxiLinearGaugeRangeComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiLinearGaugeRangeModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoLinearGaugeScaleComponent extends NestedOption implements OnDestroy, OnInit {
    get allowDecimals(): boolean | undefined;
    set allowDecimals(value: boolean | undefined);
    get customMinorTicks(): Array<number> | undefined;
    set customMinorTicks(value: Array<number> | undefined);
    get customTicks(): Array<number> | undefined;
    set customTicks(value: Array<number> | undefined);
    get endValue(): number;
    set endValue(value: number);
    get horizontalOrientation(): HorizontalAlignment;
    set horizontalOrientation(value: HorizontalAlignment);
    get label(): {
        customizeText?: ((scaleValue: {
            value: number;
            valueText: string;
        }) => string);
        font?: Font;
        format?: Format$1 | undefined;
        indentFromTick?: number;
        overlappingBehavior?: LabelOverlap;
        useRangeColors?: boolean;
        visible?: boolean;
    };
    set label(value: {
        customizeText?: ((scaleValue: {
            value: number;
            valueText: string;
        }) => string);
        font?: Font;
        format?: Format$1 | undefined;
        indentFromTick?: number;
        overlappingBehavior?: LabelOverlap;
        useRangeColors?: boolean;
        visible?: boolean;
    });
    get minorTick(): {
        color?: string;
        length?: number;
        opacity?: number;
        visible?: boolean;
        width?: number;
    };
    set minorTick(value: {
        color?: string;
        length?: number;
        opacity?: number;
        visible?: boolean;
        width?: number;
    });
    get minorTickInterval(): number | undefined;
    set minorTickInterval(value: number | undefined);
    get scaleDivisionFactor(): number;
    set scaleDivisionFactor(value: number);
    get startValue(): number;
    set startValue(value: number);
    get tick(): {
        color?: string;
        length?: number;
        opacity?: number;
        visible?: boolean;
        width?: number;
    };
    set tick(value: {
        color?: string;
        length?: number;
        opacity?: number;
        visible?: boolean;
        width?: number;
    });
    get tickInterval(): number | undefined;
    set tickInterval(value: number | undefined);
    get verticalOrientation(): VerticalAlignment;
    set verticalOrientation(value: VerticalAlignment);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoLinearGaugeScaleComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoLinearGaugeScaleComponent, "dxo-linear-gauge-scale", never, { "allowDecimals": { "alias": "allowDecimals"; "required": false; }; "customMinorTicks": { "alias": "customMinorTicks"; "required": false; }; "customTicks": { "alias": "customTicks"; "required": false; }; "endValue": { "alias": "endValue"; "required": false; }; "horizontalOrientation": { "alias": "horizontalOrientation"; "required": false; }; "label": { "alias": "label"; "required": false; }; "minorTick": { "alias": "minorTick"; "required": false; }; "minorTickInterval": { "alias": "minorTickInterval"; "required": false; }; "scaleDivisionFactor": { "alias": "scaleDivisionFactor"; "required": false; }; "startValue": { "alias": "startValue"; "required": false; }; "tick": { "alias": "tick"; "required": false; }; "tickInterval": { "alias": "tickInterval"; "required": false; }; "verticalOrientation": { "alias": "verticalOrientation"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoLinearGaugeScaleModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoLinearGaugeScaleModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoLinearGaugeScaleModule, never, [typeof DxoLinearGaugeScaleComponent], [typeof DxoLinearGaugeScaleComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoLinearGaugeScaleModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoLinearGaugeShadowComponent extends NestedOption implements OnDestroy, OnInit {
    get blur(): number;
    set blur(value: number);
    get color(): string;
    set color(value: string);
    get offsetX(): number;
    set offsetX(value: number);
    get offsetY(): number;
    set offsetY(value: number);
    get opacity(): number;
    set opacity(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoLinearGaugeShadowComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoLinearGaugeShadowComponent, "dxo-linear-gauge-shadow", never, { "blur": { "alias": "blur"; "required": false; }; "color": { "alias": "color"; "required": false; }; "offsetX": { "alias": "offsetX"; "required": false; }; "offsetY": { "alias": "offsetY"; "required": false; }; "opacity": { "alias": "opacity"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoLinearGaugeShadowModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoLinearGaugeShadowModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoLinearGaugeShadowModule, never, [typeof DxoLinearGaugeShadowComponent], [typeof DxoLinearGaugeShadowComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoLinearGaugeShadowModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoLinearGaugeSizeComponent extends NestedOption implements OnDestroy, OnInit {
    get height(): number | undefined;
    set height(value: number | undefined);
    get width(): number | undefined;
    set width(value: number | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoLinearGaugeSizeComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoLinearGaugeSizeComponent, "dxo-linear-gauge-size", never, { "height": { "alias": "height"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoLinearGaugeSizeModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoLinearGaugeSizeModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoLinearGaugeSizeModule, never, [typeof DxoLinearGaugeSizeComponent], [typeof DxoLinearGaugeSizeComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoLinearGaugeSizeModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoLinearGaugeSubtitleComponent extends NestedOption implements OnDestroy, OnInit {
    get font(): Font;
    set font(value: Font);
    get offset(): number;
    set offset(value: number);
    get text(): string | undefined;
    set text(value: string | undefined);
    get textOverflow(): TextOverflow;
    set textOverflow(value: TextOverflow);
    get wordWrap(): WordWrap;
    set wordWrap(value: WordWrap);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoLinearGaugeSubtitleComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoLinearGaugeSubtitleComponent, "dxo-linear-gauge-subtitle", never, { "font": { "alias": "font"; "required": false; }; "offset": { "alias": "offset"; "required": false; }; "text": { "alias": "text"; "required": false; }; "textOverflow": { "alias": "textOverflow"; "required": false; }; "wordWrap": { "alias": "wordWrap"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoLinearGaugeSubtitleModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoLinearGaugeSubtitleModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoLinearGaugeSubtitleModule, never, [typeof DxoLinearGaugeSubtitleComponent], [typeof DxoLinearGaugeSubtitleComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoLinearGaugeSubtitleModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoLinearGaugeSubvalueIndicatorComponent extends NestedOption implements OnDestroy, OnInit {
    get arrowLength(): number;
    set arrowLength(value: number);
    get backgroundColor(): string;
    set backgroundColor(value: string);
    get baseValue(): number | undefined;
    set baseValue(value: number | undefined);
    get beginAdaptingAtRadius(): number;
    set beginAdaptingAtRadius(value: number);
    get color(): ChartsColor | string;
    set color(value: ChartsColor | string);
    get horizontalOrientation(): HorizontalEdge;
    set horizontalOrientation(value: HorizontalEdge);
    get indentFromCenter(): number;
    set indentFromCenter(value: number);
    get length(): number;
    set length(value: number);
    get offset(): number;
    set offset(value: number);
    get palette(): Array<string> | Palette;
    set palette(value: Array<string> | Palette);
    get secondColor(): string;
    set secondColor(value: string);
    get secondFraction(): number;
    set secondFraction(value: number);
    get size(): number;
    set size(value: number);
    get spindleGapSize(): number;
    set spindleGapSize(value: number);
    get spindleSize(): number;
    set spindleSize(value: number);
    get text(): {
        customizeText?: ((indicatedValue: {
            value: number;
            valueText: string;
        }) => string) | undefined;
        font?: Font;
        format?: Format$1 | undefined;
        indent?: number;
    };
    set text(value: {
        customizeText?: ((indicatedValue: {
            value: number;
            valueText: string;
        }) => string) | undefined;
        font?: Font;
        format?: Format$1 | undefined;
        indent?: number;
    });
    get type(): "circle" | "rangeBar" | "rectangle" | "rectangleNeedle" | "rhombus" | "textCloud" | "triangleMarker" | "triangleNeedle" | "twoColorNeedle";
    set type(value: "circle" | "rangeBar" | "rectangle" | "rectangleNeedle" | "rhombus" | "textCloud" | "triangleMarker" | "triangleNeedle" | "twoColorNeedle");
    get verticalOrientation(): VerticalEdge;
    set verticalOrientation(value: VerticalEdge);
    get width(): number;
    set width(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoLinearGaugeSubvalueIndicatorComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoLinearGaugeSubvalueIndicatorComponent, "dxo-linear-gauge-subvalue-indicator", never, { "arrowLength": { "alias": "arrowLength"; "required": false; }; "backgroundColor": { "alias": "backgroundColor"; "required": false; }; "baseValue": { "alias": "baseValue"; "required": false; }; "beginAdaptingAtRadius": { "alias": "beginAdaptingAtRadius"; "required": false; }; "color": { "alias": "color"; "required": false; }; "horizontalOrientation": { "alias": "horizontalOrientation"; "required": false; }; "indentFromCenter": { "alias": "indentFromCenter"; "required": false; }; "length": { "alias": "length"; "required": false; }; "offset": { "alias": "offset"; "required": false; }; "palette": { "alias": "palette"; "required": false; }; "secondColor": { "alias": "secondColor"; "required": false; }; "secondFraction": { "alias": "secondFraction"; "required": false; }; "size": { "alias": "size"; "required": false; }; "spindleGapSize": { "alias": "spindleGapSize"; "required": false; }; "spindleSize": { "alias": "spindleSize"; "required": false; }; "text": { "alias": "text"; "required": false; }; "type": { "alias": "type"; "required": false; }; "verticalOrientation": { "alias": "verticalOrientation"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoLinearGaugeSubvalueIndicatorModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoLinearGaugeSubvalueIndicatorModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoLinearGaugeSubvalueIndicatorModule, never, [typeof DxoLinearGaugeSubvalueIndicatorComponent], [typeof DxoLinearGaugeSubvalueIndicatorComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoLinearGaugeSubvalueIndicatorModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoLinearGaugeTextComponent extends NestedOption implements OnDestroy, OnInit {
    get customizeText(): ((indicatedValue: {
        value: number;
        valueText: string;
    }) => string) | undefined;
    set customizeText(value: ((indicatedValue: {
        value: number;
        valueText: string;
    }) => string) | undefined);
    get font(): Font;
    set font(value: Font);
    get format(): Format$1 | undefined;
    set format(value: Format$1 | undefined);
    get indent(): number;
    set indent(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoLinearGaugeTextComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoLinearGaugeTextComponent, "dxo-linear-gauge-text", never, { "customizeText": { "alias": "customizeText"; "required": false; }; "font": { "alias": "font"; "required": false; }; "format": { "alias": "format"; "required": false; }; "indent": { "alias": "indent"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoLinearGaugeTextModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoLinearGaugeTextModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoLinearGaugeTextModule, never, [typeof DxoLinearGaugeTextComponent], [typeof DxoLinearGaugeTextComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoLinearGaugeTextModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoLinearGaugeTickComponent extends NestedOption implements OnDestroy, OnInit {
    get color(): string;
    set color(value: string);
    get length(): number;
    set length(value: number);
    get opacity(): number;
    set opacity(value: number);
    get visible(): boolean;
    set visible(value: boolean);
    get width(): number;
    set width(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoLinearGaugeTickComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoLinearGaugeTickComponent, "dxo-linear-gauge-tick", never, { "color": { "alias": "color"; "required": false; }; "length": { "alias": "length"; "required": false; }; "opacity": { "alias": "opacity"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoLinearGaugeTickModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoLinearGaugeTickModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoLinearGaugeTickModule, never, [typeof DxoLinearGaugeTickComponent], [typeof DxoLinearGaugeTickComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoLinearGaugeTickModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoLinearGaugeTitleComponent extends NestedOption implements OnDestroy, OnInit {
    get font(): Font;
    set font(value: Font);
    get horizontalAlignment(): HorizontalAlignment;
    set horizontalAlignment(value: HorizontalAlignment);
    get margin(): number | {
        bottom?: number;
        left?: number;
        right?: number;
        top?: number;
    };
    set margin(value: number | {
        bottom?: number;
        left?: number;
        right?: number;
        top?: number;
    });
    get placeholderSize(): number | undefined;
    set placeholderSize(value: number | undefined);
    get subtitle(): string | {
        font?: Font;
        offset?: number;
        text?: string | undefined;
        textOverflow?: TextOverflow;
        wordWrap?: WordWrap;
    };
    set subtitle(value: string | {
        font?: Font;
        offset?: number;
        text?: string | undefined;
        textOverflow?: TextOverflow;
        wordWrap?: WordWrap;
    });
    get text(): string | undefined;
    set text(value: string | undefined);
    get textOverflow(): TextOverflow;
    set textOverflow(value: TextOverflow);
    get verticalAlignment(): VerticalEdge;
    set verticalAlignment(value: VerticalEdge);
    get wordWrap(): WordWrap;
    set wordWrap(value: WordWrap);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoLinearGaugeTitleComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoLinearGaugeTitleComponent, "dxo-linear-gauge-title", never, { "font": { "alias": "font"; "required": false; }; "horizontalAlignment": { "alias": "horizontalAlignment"; "required": false; }; "margin": { "alias": "margin"; "required": false; }; "placeholderSize": { "alias": "placeholderSize"; "required": false; }; "subtitle": { "alias": "subtitle"; "required": false; }; "text": { "alias": "text"; "required": false; }; "textOverflow": { "alias": "textOverflow"; "required": false; }; "verticalAlignment": { "alias": "verticalAlignment"; "required": false; }; "wordWrap": { "alias": "wordWrap"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoLinearGaugeTitleModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoLinearGaugeTitleModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoLinearGaugeTitleModule, never, [typeof DxoLinearGaugeTitleComponent], [typeof DxoLinearGaugeTitleComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoLinearGaugeTitleModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoLinearGaugeTooltipComponent extends NestedOption implements OnDestroy, OnInit {
    get arrowLength(): number;
    set arrowLength(value: number);
    get border(): {
        color?: string;
        dashStyle?: DashStyle;
        opacity?: number | undefined;
        visible?: boolean;
        width?: number;
    };
    set border(value: {
        color?: string;
        dashStyle?: DashStyle;
        opacity?: number | undefined;
        visible?: boolean;
        width?: number;
    });
    get color(): string;
    set color(value: string);
    get container(): any | string | undefined;
    set container(value: any | string | undefined);
    get contentTemplate(): any;
    set contentTemplate(value: any);
    get cornerRadius(): number;
    set cornerRadius(value: number);
    get customizeTooltip(): ((scaleValue: {
        value: number;
        valueText: string;
    }) => Record<string, any>) | undefined;
    set customizeTooltip(value: ((scaleValue: {
        value: number;
        valueText: string;
    }) => Record<string, any>) | undefined);
    get enabled(): boolean;
    set enabled(value: boolean);
    get font(): Font;
    set font(value: Font);
    get format(): Format$1 | undefined;
    set format(value: Format$1 | undefined);
    get interactive(): boolean;
    set interactive(value: boolean);
    get opacity(): number | undefined;
    set opacity(value: number | undefined);
    get paddingLeftRight(): number;
    set paddingLeftRight(value: number);
    get paddingTopBottom(): number;
    set paddingTopBottom(value: number);
    get shadow(): {
        blur?: number;
        color?: string;
        offsetX?: number;
        offsetY?: number;
        opacity?: number;
    };
    set shadow(value: {
        blur?: number;
        color?: string;
        offsetX?: number;
        offsetY?: number;
        opacity?: number;
    });
    get zIndex(): number | undefined;
    set zIndex(value: number | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoLinearGaugeTooltipComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoLinearGaugeTooltipComponent, "dxo-linear-gauge-tooltip", never, { "arrowLength": { "alias": "arrowLength"; "required": false; }; "border": { "alias": "border"; "required": false; }; "color": { "alias": "color"; "required": false; }; "container": { "alias": "container"; "required": false; }; "contentTemplate": { "alias": "contentTemplate"; "required": false; }; "cornerRadius": { "alias": "cornerRadius"; "required": false; }; "customizeTooltip": { "alias": "customizeTooltip"; "required": false; }; "enabled": { "alias": "enabled"; "required": false; }; "font": { "alias": "font"; "required": false; }; "format": { "alias": "format"; "required": false; }; "interactive": { "alias": "interactive"; "required": false; }; "opacity": { "alias": "opacity"; "required": false; }; "paddingLeftRight": { "alias": "paddingLeftRight"; "required": false; }; "paddingTopBottom": { "alias": "paddingTopBottom"; "required": false; }; "shadow": { "alias": "shadow"; "required": false; }; "zIndex": { "alias": "zIndex"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoLinearGaugeTooltipModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoLinearGaugeTooltipModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoLinearGaugeTooltipModule, never, [typeof DxoLinearGaugeTooltipComponent], [typeof DxoLinearGaugeTooltipComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoLinearGaugeTooltipModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoLinearGaugeValueIndicatorComponent extends NestedOption implements OnDestroy, OnInit {
    get arrowLength(): number;
    set arrowLength(value: number);
    get backgroundColor(): string;
    set backgroundColor(value: string);
    get baseValue(): number | undefined;
    set baseValue(value: number | undefined);
    get beginAdaptingAtRadius(): number;
    set beginAdaptingAtRadius(value: number);
    get color(): ChartsColor | string;
    set color(value: ChartsColor | string);
    get horizontalOrientation(): HorizontalEdge;
    set horizontalOrientation(value: HorizontalEdge);
    get indentFromCenter(): number;
    set indentFromCenter(value: number);
    get length(): number;
    set length(value: number);
    get offset(): number;
    set offset(value: number);
    get palette(): Array<string> | Palette;
    set palette(value: Array<string> | Palette);
    get secondColor(): string;
    set secondColor(value: string);
    get secondFraction(): number;
    set secondFraction(value: number);
    get size(): number;
    set size(value: number);
    get spindleGapSize(): number;
    set spindleGapSize(value: number);
    get spindleSize(): number;
    set spindleSize(value: number);
    get text(): {
        customizeText?: ((indicatedValue: {
            value: number;
            valueText: string;
        }) => string) | undefined;
        font?: Font;
        format?: Format$1 | undefined;
        indent?: number;
    };
    set text(value: {
        customizeText?: ((indicatedValue: {
            value: number;
            valueText: string;
        }) => string) | undefined;
        font?: Font;
        format?: Format$1 | undefined;
        indent?: number;
    });
    get type(): "circle" | "rangeBar" | "rectangle" | "rectangleNeedle" | "rhombus" | "textCloud" | "triangleMarker" | "triangleNeedle" | "twoColorNeedle";
    set type(value: "circle" | "rangeBar" | "rectangle" | "rectangleNeedle" | "rhombus" | "textCloud" | "triangleMarker" | "triangleNeedle" | "twoColorNeedle");
    get verticalOrientation(): VerticalEdge;
    set verticalOrientation(value: VerticalEdge);
    get width(): number;
    set width(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoLinearGaugeValueIndicatorComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoLinearGaugeValueIndicatorComponent, "dxo-linear-gauge-value-indicator", never, { "arrowLength": { "alias": "arrowLength"; "required": false; }; "backgroundColor": { "alias": "backgroundColor"; "required": false; }; "baseValue": { "alias": "baseValue"; "required": false; }; "beginAdaptingAtRadius": { "alias": "beginAdaptingAtRadius"; "required": false; }; "color": { "alias": "color"; "required": false; }; "horizontalOrientation": { "alias": "horizontalOrientation"; "required": false; }; "indentFromCenter": { "alias": "indentFromCenter"; "required": false; }; "length": { "alias": "length"; "required": false; }; "offset": { "alias": "offset"; "required": false; }; "palette": { "alias": "palette"; "required": false; }; "secondColor": { "alias": "secondColor"; "required": false; }; "secondFraction": { "alias": "secondFraction"; "required": false; }; "size": { "alias": "size"; "required": false; }; "spindleGapSize": { "alias": "spindleGapSize"; "required": false; }; "spindleSize": { "alias": "spindleSize"; "required": false; }; "text": { "alias": "text"; "required": false; }; "type": { "alias": "type"; "required": false; }; "verticalOrientation": { "alias": "verticalOrientation"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoLinearGaugeValueIndicatorModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoLinearGaugeValueIndicatorModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoLinearGaugeValueIndicatorModule, never, [typeof DxoLinearGaugeValueIndicatorComponent], [typeof DxoLinearGaugeValueIndicatorComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoLinearGaugeValueIndicatorModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoLinearGaugeWidthComponent extends NestedOption implements OnDestroy, OnInit {
    get end(): number;
    set end(value: number);
    get start(): number;
    set start(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoLinearGaugeWidthComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoLinearGaugeWidthComponent, "dxo-linear-gauge-width", never, { "end": { "alias": "end"; "required": false; }; "start": { "alias": "start"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoLinearGaugeWidthModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoLinearGaugeWidthModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoLinearGaugeWidthModule, never, [typeof DxoLinearGaugeWidthComponent], [typeof DxoLinearGaugeWidthComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoLinearGaugeWidthModule>;
}

export { DxiLinearGaugeRangeComponent, DxiLinearGaugeRangeModule, DxoLinearGaugeAnimationComponent, DxoLinearGaugeAnimationModule, DxoLinearGaugeBackgroundColorComponent, DxoLinearGaugeBackgroundColorModule, DxoLinearGaugeBorderComponent, DxoLinearGaugeBorderModule, DxoLinearGaugeColorComponent, DxoLinearGaugeColorModule, DxoLinearGaugeExportComponent, DxoLinearGaugeExportModule, DxoLinearGaugeFontComponent, DxoLinearGaugeFontModule, DxoLinearGaugeFormatComponent, DxoLinearGaugeFormatModule, DxoLinearGaugeGeometryComponent, DxoLinearGaugeGeometryModule, DxoLinearGaugeLabelComponent, DxoLinearGaugeLabelModule, DxoLinearGaugeLoadingIndicatorComponent, DxoLinearGaugeLoadingIndicatorModule, DxoLinearGaugeMarginComponent, DxoLinearGaugeMarginModule, DxoLinearGaugeMinorTickComponent, DxoLinearGaugeMinorTickModule, DxoLinearGaugeRangeContainerComponent, DxoLinearGaugeRangeContainerModule, DxoLinearGaugeScaleComponent, DxoLinearGaugeScaleModule, DxoLinearGaugeShadowComponent, DxoLinearGaugeShadowModule, DxoLinearGaugeSizeComponent, DxoLinearGaugeSizeModule, DxoLinearGaugeSubtitleComponent, DxoLinearGaugeSubtitleModule, DxoLinearGaugeSubvalueIndicatorComponent, DxoLinearGaugeSubvalueIndicatorModule, DxoLinearGaugeTextComponent, DxoLinearGaugeTextModule, DxoLinearGaugeTickComponent, DxoLinearGaugeTickModule, DxoLinearGaugeTitleComponent, DxoLinearGaugeTitleModule, DxoLinearGaugeTooltipComponent, DxoLinearGaugeTooltipModule, DxoLinearGaugeValueIndicatorComponent, DxoLinearGaugeValueIndicatorModule, DxoLinearGaugeWidthComponent, DxoLinearGaugeWidthModule };
//# sourceMappingURL=index.d.ts.map
