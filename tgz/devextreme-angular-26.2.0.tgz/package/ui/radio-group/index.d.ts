import * as i0 from '@angular/core';
import { OnDestroy, OnChanges, DoCheck, QueryList, EventEmitter, ElementRef, NgZone, TransferState, SimpleChanges } from '@angular/core';
import { CollectionWidgetItem } from 'devextreme/ui/collection/ui.collection_widget.base';
import DataSource, { DataSourceOptions } from 'devextreme/data/data_source';
import { Store } from 'devextreme/data/store';
import { Orientation, ValidationMessageMode, Position, ValidationStatus } from 'devextreme/common';
import DxRadioGroup, { ContentReadyEvent, DisposingEvent, InitializedEvent, OptionChangedEvent, ValueChangedEvent } from 'devextreme/ui/radio_group';
import { ControlValueAccessor } from '@angular/forms';
import * as i3 from 'devextreme-angular/core';
import { DxComponent, CollectionNestedOption, DxTemplateHost, WatcherHelper, IterableDifferHelper, NestedOptionHost } from 'devextreme-angular/core';
import * as i1 from 'devextreme-angular/ui/nested';
import * as i2 from 'devextreme-angular/ui/radio-group/nested';
export * from 'devextreme-angular/ui/radio-group/nested';
import * as radio_group_types from 'devextreme/ui/radio_group_types';
export { radio_group_types as DxRadioGroupTypes };

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

/**
 * [descr:dxRadioGroup]

 */
declare class DxRadioGroupComponent extends DxComponent implements OnDestroy, ControlValueAccessor, OnChanges, DoCheck {
    private _watcherHelper;
    private _idh;
    set _itemsContentChildren(value: QueryList<CollectionNestedOption>);
    instance: DxRadioGroup;
    /**
     * [descr:WidgetOptions.accessKey]
    
     */
    get accessKey(): string | undefined;
    set accessKey(value: string | undefined);
    /**
     * [descr:dxRadioGroupOptions.activeStateEnabled]
    
     */
    get activeStateEnabled(): boolean;
    set activeStateEnabled(value: boolean);
    /**
     * [descr:DataExpressionMixinOptions.dataSource]
    
     */
    get dataSource(): Array<any | CollectionWidgetItem> | DataSource | DataSourceOptions | null | Store | string;
    set dataSource(value: Array<any | CollectionWidgetItem> | DataSource | DataSourceOptions | null | Store | string);
    /**
     * [descr:WidgetOptions.disabled]
    
     */
    get disabled(): boolean;
    set disabled(value: boolean);
    /**
     * [descr:DataExpressionMixinOptions.displayExpr]
    
     */
    get displayExpr(): ((item: any) => string) | string | undefined;
    set displayExpr(value: ((item: any) => string) | string | undefined);
    /**
     * [descr:DOMComponentOptions.elementAttr]
    
     */
    get elementAttr(): Record<string, any>;
    set elementAttr(value: Record<string, any>);
    /**
     * [descr:dxRadioGroupOptions.focusStateEnabled]
    
     */
    get focusStateEnabled(): boolean;
    set focusStateEnabled(value: boolean);
    /**
     * [descr:DOMComponentOptions.height]
    
     */
    get height(): number | string | undefined;
    set height(value: number | string | undefined);
    /**
     * [descr:WidgetOptions.hint]
    
     */
    get hint(): string | undefined;
    set hint(value: string | undefined);
    /**
     * [descr:dxRadioGroupOptions.hoverStateEnabled]
    
     */
    get hoverStateEnabled(): boolean;
    set hoverStateEnabled(value: boolean);
    /**
     * [descr:EditorOptions.isDirty]
    
     */
    get isDirty(): boolean;
    set isDirty(value: boolean);
    /**
     * [descr:EditorOptions.isValid]
    
     */
    get isValid(): boolean;
    set isValid(value: boolean);
    /**
     * [descr:DataExpressionMixinOptions.items]
    
     */
    get items(): Array<any | CollectionWidgetItem>;
    set items(value: Array<any | CollectionWidgetItem>);
    /**
     * [descr:DataExpressionMixinOptions.itemTemplate]
    
     */
    get itemTemplate(): any;
    set itemTemplate(value: any);
    /**
     * [descr:dxRadioGroupOptions.layout]
    
     */
    get layout(): Orientation;
    set layout(value: Orientation);
    /**
     * [descr:dxRadioGroupOptions.name]
    
     */
    get name(): string;
    set name(value: string);
    /**
     * [descr:EditorOptions.readOnly]
    
     */
    get readOnly(): boolean;
    set readOnly(value: boolean);
    /**
     * [descr:DOMComponentOptions.rtlEnabled]
    
     */
    get rtlEnabled(): boolean;
    set rtlEnabled(value: boolean);
    /**
     * [descr:WidgetOptions.tabIndex]
    
     */
    get tabIndex(): number;
    set tabIndex(value: number);
    /**
     * [descr:EditorOptions.validationError]
    
     */
    get validationError(): any | null;
    set validationError(value: any | null);
    /**
     * [descr:EditorOptions.validationErrors]
    
     */
    get validationErrors(): Array<any> | null;
    set validationErrors(value: Array<any> | null);
    /**
     * [descr:EditorOptions.validationMessageMode]
    
     */
    get validationMessageMode(): ValidationMessageMode;
    set validationMessageMode(value: ValidationMessageMode);
    /**
     * [descr:EditorOptions.validationMessagePosition]
    
     */
    get validationMessagePosition(): Position;
    set validationMessagePosition(value: Position);
    /**
     * [descr:EditorOptions.validationStatus]
    
     */
    get validationStatus(): ValidationStatus;
    set validationStatus(value: ValidationStatus);
    /**
     * [descr:dxRadioGroupOptions.value]
    
     */
    get value(): any;
    set value(value: any);
    /**
     * [descr:DataExpressionMixinOptions.valueExpr]
    
     */
    get valueExpr(): ((item: any) => string | number | boolean) | string;
    set valueExpr(value: ((item: any) => string | number | boolean) | string);
    /**
     * [descr:WidgetOptions.visible]
    
     */
    get visible(): boolean;
    set visible(value: boolean);
    /**
     * [descr:DOMComponentOptions.width]
    
     */
    get width(): number | string | undefined;
    set width(value: number | string | undefined);
    /**
    
     * [descr:dxRadioGroupOptions.onContentReady]
    
    
     */
    onContentReady: EventEmitter<ContentReadyEvent>;
    /**
    
     * [descr:dxRadioGroupOptions.onDisposing]
    
    
     */
    onDisposing: EventEmitter<DisposingEvent>;
    /**
    
     * [descr:dxRadioGroupOptions.onInitialized]
    
    
     */
    onInitialized: EventEmitter<InitializedEvent>;
    /**
    
     * [descr:dxRadioGroupOptions.onOptionChanged]
    
    
     */
    onOptionChanged: EventEmitter<OptionChangedEvent>;
    /**
    
     * [descr:dxRadioGroupOptions.onValueChanged]
    
    
     */
    onValueChanged: EventEmitter<ValueChangedEvent>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    accessKeyChange: EventEmitter<string | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    activeStateEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    dataSourceChange: EventEmitter<Array<any | CollectionWidgetItem> | DataSource | DataSourceOptions | null | Store | string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    disabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    displayExprChange: EventEmitter<((item: any) => string) | string | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    elementAttrChange: EventEmitter<Record<string, any>>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    focusStateEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    heightChange: EventEmitter<number | string | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    hintChange: EventEmitter<string | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    hoverStateEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    isDirtyChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    isValidChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    itemsChange: EventEmitter<Array<any | CollectionWidgetItem>>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    itemTemplateChange: EventEmitter<any>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    layoutChange: EventEmitter<Orientation>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    nameChange: EventEmitter<string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    readOnlyChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    rtlEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    tabIndexChange: EventEmitter<number>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    validationErrorChange: EventEmitter<any | null>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    validationErrorsChange: EventEmitter<Array<any> | null>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    validationMessageModeChange: EventEmitter<ValidationMessageMode>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    validationMessagePositionChange: EventEmitter<Position>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    validationStatusChange: EventEmitter<ValidationStatus>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    valueChange: EventEmitter<any>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    valueExprChange: EventEmitter<((item: any) => string | number | boolean) | string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    visibleChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    widthChange: EventEmitter<number | string | undefined>;
    /**
    
     * [descr:undefined]
    
    
     */
    onBlur: EventEmitter<any>;
    change(_: any): void;
    touched: (_: any) => void;
    constructor(elementRef: ElementRef, ngZone: NgZone, templateHost: DxTemplateHost, _watcherHelper: WatcherHelper, _idh: IterableDifferHelper, optionHost: NestedOptionHost, transferState: TransferState, platformId: any);
    protected _createInstance(element: any, options: any): DxRadioGroup;
    writeValue(value: any): void;
    setDisabledState(isDisabled: boolean): void;
    registerOnChange(fn: (_: any) => void): void;
    registerOnTouched(fn: () => void): void;
    _createWidget(element: any): void;
    ngOnDestroy(): void;
    ngOnChanges(changes: SimpleChanges): void;
    setupChanges(prop: string, changes: SimpleChanges): void;
    ngDoCheck(): void;
    _setOption(name: string, value: any): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxRadioGroupComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxRadioGroupComponent, "dx-radio-group", never, { "accessKey": { "alias": "accessKey"; "required": false; }; "activeStateEnabled": { "alias": "activeStateEnabled"; "required": false; }; "dataSource": { "alias": "dataSource"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "displayExpr": { "alias": "displayExpr"; "required": false; }; "elementAttr": { "alias": "elementAttr"; "required": false; }; "focusStateEnabled": { "alias": "focusStateEnabled"; "required": false; }; "height": { "alias": "height"; "required": false; }; "hint": { "alias": "hint"; "required": false; }; "hoverStateEnabled": { "alias": "hoverStateEnabled"; "required": false; }; "isDirty": { "alias": "isDirty"; "required": false; }; "isValid": { "alias": "isValid"; "required": false; }; "items": { "alias": "items"; "required": false; }; "itemTemplate": { "alias": "itemTemplate"; "required": false; }; "layout": { "alias": "layout"; "required": false; }; "name": { "alias": "name"; "required": false; }; "readOnly": { "alias": "readOnly"; "required": false; }; "rtlEnabled": { "alias": "rtlEnabled"; "required": false; }; "tabIndex": { "alias": "tabIndex"; "required": false; }; "validationError": { "alias": "validationError"; "required": false; }; "validationErrors": { "alias": "validationErrors"; "required": false; }; "validationMessageMode": { "alias": "validationMessageMode"; "required": false; }; "validationMessagePosition": { "alias": "validationMessagePosition"; "required": false; }; "validationStatus": { "alias": "validationStatus"; "required": false; }; "value": { "alias": "value"; "required": false; }; "valueExpr": { "alias": "valueExpr"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, { "onContentReady": "onContentReady"; "onDisposing": "onDisposing"; "onInitialized": "onInitialized"; "onOptionChanged": "onOptionChanged"; "onValueChanged": "onValueChanged"; "accessKeyChange": "accessKeyChange"; "activeStateEnabledChange": "activeStateEnabledChange"; "dataSourceChange": "dataSourceChange"; "disabledChange": "disabledChange"; "displayExprChange": "displayExprChange"; "elementAttrChange": "elementAttrChange"; "focusStateEnabledChange": "focusStateEnabledChange"; "heightChange": "heightChange"; "hintChange": "hintChange"; "hoverStateEnabledChange": "hoverStateEnabledChange"; "isDirtyChange": "isDirtyChange"; "isValidChange": "isValidChange"; "itemsChange": "itemsChange"; "itemTemplateChange": "itemTemplateChange"; "layoutChange": "layoutChange"; "nameChange": "nameChange"; "readOnlyChange": "readOnlyChange"; "rtlEnabledChange": "rtlEnabledChange"; "tabIndexChange": "tabIndexChange"; "validationErrorChange": "validationErrorChange"; "validationErrorsChange": "validationErrorsChange"; "validationMessageModeChange": "validationMessageModeChange"; "validationMessagePositionChange": "validationMessagePositionChange"; "validationStatusChange": "validationStatusChange"; "valueChange": "valueChange"; "valueExprChange": "valueExprChange"; "visibleChange": "visibleChange"; "widthChange": "widthChange"; "onBlur": "onBlur"; }, ["_itemsContentChildren"], never, true, never>;
}
declare class DxRadioGroupModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxRadioGroupModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxRadioGroupModule, never, [typeof DxRadioGroupComponent, typeof i1.DxiItemModule, typeof i2.DxiRadioGroupItemModule, typeof i3.DxIntegrationModule, typeof i3.DxTemplateModule], [typeof DxRadioGroupComponent, typeof i1.DxiItemModule, typeof i2.DxiRadioGroupItemModule, typeof i3.DxTemplateModule]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxRadioGroupModule>;
}

export { DxRadioGroupComponent, DxRadioGroupModule };
//# sourceMappingURL=index.d.ts.map
