import * as i0 from '@angular/core';
import { OnDestroy, OnChanges, DoCheck, QueryList, EventEmitter, ElementRef, NgZone, TransferState, SimpleChanges } from '@angular/core';
import DxSplitter, { dxSplitterItem, ContentReadyEvent, DisposingEvent, InitializedEvent, ItemClickEvent, ItemCollapsedEvent, ItemContextMenuEvent, ItemExpandedEvent, ItemRenderedEvent, OptionChangedEvent, ResizeEvent, ResizeEndEvent, ResizeStartEvent } from 'devextreme/ui/splitter';
export { ExplicitTypes } from 'devextreme/ui/splitter';
import DataSource, { DataSourceOptions } from 'devextreme/data/data_source';
import { Store } from 'devextreme/data/store';
import { Orientation } from 'devextreme/common';
import * as i3 from 'devextreme-angular/core';
import { DxComponent, CollectionNestedOption, DxTemplateHost, WatcherHelper, IterableDifferHelper, NestedOptionHost } from 'devextreme-angular/core';
import * as i1 from 'devextreme-angular/ui/nested';
import * as i2 from 'devextreme-angular/ui/splitter/nested';
export * from 'devextreme-angular/ui/splitter/nested';
import * as splitter_types from 'devextreme/ui/splitter_types';
export { splitter_types as DxSplitterTypes };

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

/**
 * [descr:dxSplitter]

 */
declare class DxSplitterComponent<TItem = any, TKey = any> extends DxComponent implements OnDestroy, OnChanges, DoCheck {
    private _watcherHelper;
    private _idh;
    set _itemsContentChildren(value: QueryList<CollectionNestedOption>);
    instance: DxSplitter<TItem, TKey>;
    /**
     * [descr:dxSplitterOptions.allowKeyboardNavigation]
    
     */
    get allowKeyboardNavigation(): boolean;
    set allowKeyboardNavigation(value: boolean);
    /**
     * [descr:dxSplitterOptions.dataSource]
    
     */
    get dataSource(): Array<dxSplitterItem> | DataSource | DataSourceOptions | null | Store | string;
    set dataSource(value: Array<dxSplitterItem> | DataSource | DataSourceOptions | null | Store | string);
    /**
     * [descr:WidgetOptions.disabled]
    
     */
    get disabled(): boolean;
    set disabled(value: boolean);
    /**
     * [descr:DOMComponentOptions.elementAttr]
    
     */
    get elementAttr(): Record<string, any>;
    set elementAttr(value: Record<string, any>);
    /**
     * [descr:DOMComponentOptions.height]
    
     */
    get height(): number | string | undefined;
    set height(value: number | string | undefined);
    /**
     * [descr:WidgetOptions.hoverStateEnabled]
    
     */
    get hoverStateEnabled(): boolean;
    set hoverStateEnabled(value: boolean);
    /**
     * [descr:dxSplitterOptions.items]
    
     */
    get items(): Array<dxSplitterItem>;
    set items(value: Array<dxSplitterItem>);
    /**
     * [descr:CollectionWidgetOptions.itemTemplate]
    
     */
    get itemTemplate(): any;
    set itemTemplate(value: any);
    /**
     * [descr:dxSplitterOptions.orientation]
    
     */
    get orientation(): Orientation;
    set orientation(value: Orientation);
    /**
     * [descr:DOMComponentOptions.rtlEnabled]
    
     */
    get rtlEnabled(): boolean;
    set rtlEnabled(value: boolean);
    /**
     * [descr:dxSplitterOptions.separatorSize]
    
     */
    get separatorSize(): number;
    set separatorSize(value: number);
    /**
     * [descr:WidgetOptions.visible]
    
     */
    get visible(): boolean;
    set visible(value: boolean);
    /**
     * [descr:DOMComponentOptions.width]
    
     */
    get width(): number | string | undefined;
    set width(value: number | string | undefined);
    /**
    
     * [descr:dxSplitterOptions.onContentReady]
    
    
     */
    onContentReady: EventEmitter<ContentReadyEvent>;
    /**
    
     * [descr:dxSplitterOptions.onDisposing]
    
    
     */
    onDisposing: EventEmitter<DisposingEvent>;
    /**
    
     * [descr:dxSplitterOptions.onInitialized]
    
    
     */
    onInitialized: EventEmitter<InitializedEvent>;
    /**
    
     * [descr:dxSplitterOptions.onItemClick]
    
    
     */
    onItemClick: EventEmitter<ItemClickEvent>;
    /**
    
     * [descr:dxSplitterOptions.onItemCollapsed]
    
    
     */
    onItemCollapsed: EventEmitter<ItemCollapsedEvent>;
    /**
    
     * [descr:dxSplitterOptions.onItemContextMenu]
    
    
     */
    onItemContextMenu: EventEmitter<ItemContextMenuEvent>;
    /**
    
     * [descr:dxSplitterOptions.onItemExpanded]
    
    
     */
    onItemExpanded: EventEmitter<ItemExpandedEvent>;
    /**
    
     * [descr:dxSplitterOptions.onItemRendered]
    
    
     */
    onItemRendered: EventEmitter<ItemRenderedEvent>;
    /**
    
     * [descr:dxSplitterOptions.onOptionChanged]
    
    
     */
    onOptionChanged: EventEmitter<OptionChangedEvent>;
    /**
    
     * [descr:dxSplitterOptions.onResize]
    
    
     */
    onResize: EventEmitter<ResizeEvent>;
    /**
    
     * [descr:dxSplitterOptions.onResizeEnd]
    
    
     */
    onResizeEnd: EventEmitter<ResizeEndEvent>;
    /**
    
     * [descr:dxSplitterOptions.onResizeStart]
    
    
     */
    onResizeStart: EventEmitter<ResizeStartEvent>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    allowKeyboardNavigationChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    dataSourceChange: EventEmitter<Array<dxSplitterItem> | DataSource | DataSourceOptions | null | Store | string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    disabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    elementAttrChange: EventEmitter<Record<string, any>>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    heightChange: EventEmitter<number | string | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    hoverStateEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    itemsChange: EventEmitter<Array<dxSplitterItem>>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    itemTemplateChange: EventEmitter<any>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    orientationChange: EventEmitter<Orientation>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    rtlEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    separatorSizeChange: EventEmitter<number>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    visibleChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    widthChange: EventEmitter<number | string | undefined>;
    constructor(elementRef: ElementRef, ngZone: NgZone, templateHost: DxTemplateHost, _watcherHelper: WatcherHelper, _idh: IterableDifferHelper, optionHost: NestedOptionHost, transferState: TransferState, platformId: any);
    protected _createInstance(element: any, options: any): DxSplitter<any, any>;
    ngOnDestroy(): void;
    ngOnChanges(changes: SimpleChanges): void;
    setupChanges(prop: string, changes: SimpleChanges): void;
    ngDoCheck(): void;
    _setOption(name: string, value: any): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxSplitterComponent<any, any>, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxSplitterComponent<any, any>, "dx-splitter", never, { "allowKeyboardNavigation": { "alias": "allowKeyboardNavigation"; "required": false; }; "dataSource": { "alias": "dataSource"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "elementAttr": { "alias": "elementAttr"; "required": false; }; "height": { "alias": "height"; "required": false; }; "hoverStateEnabled": { "alias": "hoverStateEnabled"; "required": false; }; "items": { "alias": "items"; "required": false; }; "itemTemplate": { "alias": "itemTemplate"; "required": false; }; "orientation": { "alias": "orientation"; "required": false; }; "rtlEnabled": { "alias": "rtlEnabled"; "required": false; }; "separatorSize": { "alias": "separatorSize"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, { "onContentReady": "onContentReady"; "onDisposing": "onDisposing"; "onInitialized": "onInitialized"; "onItemClick": "onItemClick"; "onItemCollapsed": "onItemCollapsed"; "onItemContextMenu": "onItemContextMenu"; "onItemExpanded": "onItemExpanded"; "onItemRendered": "onItemRendered"; "onOptionChanged": "onOptionChanged"; "onResize": "onResize"; "onResizeEnd": "onResizeEnd"; "onResizeStart": "onResizeStart"; "allowKeyboardNavigationChange": "allowKeyboardNavigationChange"; "dataSourceChange": "dataSourceChange"; "disabledChange": "disabledChange"; "elementAttrChange": "elementAttrChange"; "heightChange": "heightChange"; "hoverStateEnabledChange": "hoverStateEnabledChange"; "itemsChange": "itemsChange"; "itemTemplateChange": "itemTemplateChange"; "orientationChange": "orientationChange"; "rtlEnabledChange": "rtlEnabledChange"; "separatorSizeChange": "separatorSizeChange"; "visibleChange": "visibleChange"; "widthChange": "widthChange"; }, ["_itemsContentChildren"], never, true, never>;
}
declare class DxSplitterModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxSplitterModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxSplitterModule, never, [typeof DxSplitterComponent, typeof i1.DxiItemModule, typeof i1.DxoSplitterModule, typeof i2.DxiSplitterItemModule, typeof i3.DxIntegrationModule, typeof i3.DxTemplateModule], [typeof DxSplitterComponent, typeof i1.DxiItemModule, typeof i1.DxoSplitterModule, typeof i2.DxiSplitterItemModule, typeof i3.DxTemplateModule]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxSplitterModule>;
}

export { DxSplitterComponent, DxSplitterModule };
//# sourceMappingURL=index.d.ts.map
