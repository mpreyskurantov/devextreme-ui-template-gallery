import * as i0 from '@angular/core';
import { AfterViewInit, Renderer2, ElementRef } from '@angular/core';
import { dxSplitterOptions } from 'devextreme/ui/splitter';
import { CollectionNestedOption, IDxTemplateHost, NestedOptionHost, DxTemplateHost, DxTemplateDirective } from 'devextreme-angular/core';

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxiSplitterItemComponent extends CollectionNestedOption implements AfterViewInit, IDxTemplateHost {
    private renderer;
    private document;
    private element;
    get collapsed(): boolean;
    set collapsed(value: boolean);
    get collapsedSize(): number | string | undefined;
    set collapsedSize(value: number | string | undefined);
    get collapsible(): boolean;
    set collapsible(value: boolean);
    get maxSize(): number | string | undefined;
    set maxSize(value: number | string | undefined);
    get minSize(): number | string | undefined;
    set minSize(value: number | string | undefined);
    get resizable(): boolean;
    set resizable(value: boolean);
    get size(): number | string | undefined;
    set size(value: number | string | undefined);
    get splitter(): dxSplitterOptions | undefined;
    set splitter(value: dxSplitterOptions | undefined);
    get template(): any;
    set template(value: any);
    get text(): string;
    set text(value: string);
    get visible(): boolean;
    set visible(value: boolean);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost, renderer: Renderer2, document: any, templateHost: DxTemplateHost, element: ElementRef);
    setTemplate(template: DxTemplateDirective): void;
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiSplitterItemComponent, [{ host: true; skipSelf: true; }, { host: true; }, null, null, { host: true; }, null]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiSplitterItemComponent, "dxi-splitter-item", never, { "collapsed": { "alias": "collapsed"; "required": false; }; "collapsedSize": { "alias": "collapsedSize"; "required": false; }; "collapsible": { "alias": "collapsible"; "required": false; }; "maxSize": { "alias": "maxSize"; "required": false; }; "minSize": { "alias": "minSize"; "required": false; }; "resizable": { "alias": "resizable"; "required": false; }; "size": { "alias": "size"; "required": false; }; "splitter": { "alias": "splitter"; "required": false; }; "template": { "alias": "template"; "required": false; }; "text": { "alias": "text"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; }, {}, never, ["*"], true, never>;
}
declare class DxiSplitterItemModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiSplitterItemModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiSplitterItemModule, never, [typeof DxiSplitterItemComponent], [typeof DxiSplitterItemComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiSplitterItemModule>;
}

export { DxiSplitterItemComponent, DxiSplitterItemModule };
//# sourceMappingURL=index.d.ts.map
