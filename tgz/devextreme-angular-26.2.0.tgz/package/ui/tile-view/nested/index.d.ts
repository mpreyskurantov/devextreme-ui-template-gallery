import * as i0 from '@angular/core';
import { AfterViewInit, Renderer2, ElementRef } from '@angular/core';
import { CollectionNestedOption, IDxTemplateHost, NestedOptionHost, DxTemplateHost, DxTemplateDirective } from 'devextreme-angular/core';

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxiTileViewItemComponent extends CollectionNestedOption implements AfterViewInit, IDxTemplateHost {
    private renderer;
    private document;
    private element;
    get disabled(): boolean;
    set disabled(value: boolean);
    get heightRatio(): number;
    set heightRatio(value: number);
    get html(): string;
    set html(value: string);
    get template(): any;
    set template(value: any);
    get text(): string;
    set text(value: string);
    get visible(): boolean;
    set visible(value: boolean);
    get widthRatio(): number;
    set widthRatio(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost, renderer: Renderer2, document: any, templateHost: DxTemplateHost, element: ElementRef);
    setTemplate(template: DxTemplateDirective): void;
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiTileViewItemComponent, [{ host: true; skipSelf: true; }, { host: true; }, null, null, { host: true; }, null]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiTileViewItemComponent, "dxi-tile-view-item", never, { "disabled": { "alias": "disabled"; "required": false; }; "heightRatio": { "alias": "heightRatio"; "required": false; }; "html": { "alias": "html"; "required": false; }; "template": { "alias": "template"; "required": false; }; "text": { "alias": "text"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "widthRatio": { "alias": "widthRatio"; "required": false; }; }, {}, never, ["*"], true, never>;
}
declare class DxiTileViewItemModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiTileViewItemModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiTileViewItemModule, never, [typeof DxiTileViewItemComponent], [typeof DxiTileViewItemComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiTileViewItemModule>;
}

export { DxiTileViewItemComponent, DxiTileViewItemModule };
//# sourceMappingURL=index.d.ts.map
