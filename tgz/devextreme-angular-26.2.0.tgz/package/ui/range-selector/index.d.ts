import * as i0 from '@angular/core';
import { OnDestroy, OnChanges, DoCheck, QueryList, EventEmitter, ElementRef, NgZone, TransferState, SimpleChanges } from '@angular/core';
import * as CommonChartTypes from 'devextreme/common/charts';
import { Palette, PaletteExtensionMode, ChartsDataType, Font, TimeInterval, ScaleBreak, ScaleBreakLineStyle, DiscreteAxisDivisionMode, LabelOverlap, VisualRangeUpdateMode, Theme, TextOverflow, WordWrap } from 'devextreme/common/charts';
import DxRangeSelector, { BackgroundImageLocation, ChartAxisScale, AxisScale, DisposingEvent, DrawnEvent, ExportedEvent, ExportingEvent, FileSavingEvent, IncidentOccurredEvent, InitializedEvent, OptionChangedEvent, ValueChangedEvent } from 'devextreme/viz/range_selector';
import { SliderValueChangeMode, ExportFormat, HorizontalAlignment, VerticalEdge } from 'devextreme/common';
import { dxChartCommonSeriesSettings } from 'devextreme/viz/chart';
import { ChartSeries } from 'devextreme/viz/common';
import DataSource, { DataSourceOptions } from 'devextreme/data/data_source';
import { Store } from 'devextreme/data/store';
import { Format } from 'devextreme/common/core/localization';
import { ControlValueAccessor } from '@angular/forms';
import * as i3 from 'devextreme-angular/core';
import { DxComponent, CollectionNestedOption, DxTemplateHost, WatcherHelper, IterableDifferHelper, NestedOptionHost } from 'devextreme-angular/core';
import * as i1 from 'devextreme-angular/ui/nested';
import * as i2 from 'devextreme-angular/ui/range-selector/nested';
export * from 'devextreme-angular/ui/range-selector/nested';
import * as range_selector_types from 'devextreme/viz/range_selector_types';
export { range_selector_types as DxRangeSelectorTypes };

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

/**
 * [descr:dxRangeSelector]

 */
declare class DxRangeSelectorComponent extends DxComponent implements OnDestroy, ControlValueAccessor, OnChanges, DoCheck {
    private _watcherHelper;
    private _idh;
    set _breaksContentChildren(value: QueryList<CollectionNestedOption>);
    set _seriesContentChildren(value: QueryList<CollectionNestedOption>);
    instance: DxRangeSelector;
    /**
     * [descr:dxRangeSelectorOptions.background]
    
     */
    get background(): {
        color?: string;
        image?: {
            location?: BackgroundImageLocation;
            url?: string | undefined;
        };
        visible?: boolean;
    };
    set background(value: {
        color?: string;
        image?: {
            location?: BackgroundImageLocation;
            url?: string | undefined;
        };
        visible?: boolean;
    });
    /**
     * [descr:dxRangeSelectorOptions.behavior]
    
     */
    get behavior(): {
        allowSlidersSwap?: boolean;
        animationEnabled?: boolean;
        manualRangeSelectionEnabled?: boolean;
        moveSelectedRangeByClick?: boolean;
        snapToTicks?: boolean;
        valueChangeMode?: SliderValueChangeMode;
    };
    set behavior(value: {
        allowSlidersSwap?: boolean;
        animationEnabled?: boolean;
        manualRangeSelectionEnabled?: boolean;
        moveSelectedRangeByClick?: boolean;
        snapToTicks?: boolean;
        valueChangeMode?: SliderValueChangeMode;
    });
    /**
     * [descr:dxRangeSelectorOptions.chart]
    
     */
    get chart(): {
        barGroupPadding?: number;
        barGroupWidth?: number | undefined;
        bottomIndent?: number;
        commonSeriesSettings?: dxChartCommonSeriesSettings;
        dataPrepareSettings?: {
            checkTypeForAllData?: boolean;
            convertToAxisDataType?: boolean;
            sortingMethod?: boolean | ((a: {
                arg: Date | number | string;
                val: Date | number | string;
            }, b: {
                arg: Date | number | string;
                val: Date | number | string;
            }) => number);
        };
        maxBubbleSize?: number;
        minBubbleSize?: number;
        negativesAsZeroes?: boolean;
        palette?: Array<string> | Palette;
        paletteExtensionMode?: PaletteExtensionMode;
        series?: Array<ChartSeries> | ChartSeries | undefined;
        seriesTemplate?: any;
        topIndent?: number;
        valueAxis?: {
            inverted?: boolean;
            logarithmBase?: number;
            max?: number | undefined;
            min?: number | undefined;
            type?: ChartAxisScale | undefined;
            valueType?: ChartsDataType | undefined;
        };
    };
    set chart(value: {
        barGroupPadding?: number;
        barGroupWidth?: number | undefined;
        bottomIndent?: number;
        commonSeriesSettings?: dxChartCommonSeriesSettings;
        dataPrepareSettings?: {
            checkTypeForAllData?: boolean;
            convertToAxisDataType?: boolean;
            sortingMethod?: boolean | ((a: {
                arg: Date | number | string;
                val: Date | number | string;
            }, b: {
                arg: Date | number | string;
                val: Date | number | string;
            }) => number);
        };
        maxBubbleSize?: number;
        minBubbleSize?: number;
        negativesAsZeroes?: boolean;
        palette?: Array<string> | Palette;
        paletteExtensionMode?: PaletteExtensionMode;
        series?: Array<ChartSeries> | ChartSeries | undefined;
        seriesTemplate?: any;
        topIndent?: number;
        valueAxis?: {
            inverted?: boolean;
            logarithmBase?: number;
            max?: number | undefined;
            min?: number | undefined;
            type?: ChartAxisScale | undefined;
            valueType?: ChartsDataType | undefined;
        };
    });
    /**
     * [descr:dxRangeSelectorOptions.containerBackgroundColor]
    
     */
    get containerBackgroundColor(): string;
    set containerBackgroundColor(value: string);
    /**
     * [descr:dxRangeSelectorOptions.dataSource]
    
     */
    get dataSource(): Array<any> | DataSource | DataSourceOptions | null | Store | string;
    set dataSource(value: Array<any> | DataSource | DataSourceOptions | null | Store | string);
    /**
     * [descr:dxRangeSelectorOptions.dataSourceField]
    
     */
    get dataSourceField(): string;
    set dataSourceField(value: string);
    /**
     * [descr:BaseWidgetOptions.disabled]
    
     */
    get disabled(): boolean;
    set disabled(value: boolean);
    /**
     * [descr:DOMComponentOptions.elementAttr]
    
     */
    get elementAttr(): Record<string, any>;
    set elementAttr(value: Record<string, any>);
    /**
     * [descr:BaseWidgetOptions.encodeHtml]
    
     */
    get encodeHtml(): boolean;
    set encodeHtml(value: boolean);
    /**
     * [descr:BaseWidgetOptions.export]
    
     */
    get export(): {
        backgroundColor?: string;
        enabled?: boolean;
        fileName?: string;
        formats?: Array<ExportFormat>;
        margin?: number;
        printingEnabled?: boolean;
        svgToCanvas?: ((svg: any, canvas: any) => any) | undefined;
    };
    set export(value: {
        backgroundColor?: string;
        enabled?: boolean;
        fileName?: string;
        formats?: Array<ExportFormat>;
        margin?: number;
        printingEnabled?: boolean;
        svgToCanvas?: ((svg: any, canvas: any) => any) | undefined;
    });
    /**
     * [descr:dxRangeSelectorOptions.indent]
    
     */
    get indent(): {
        left?: number | undefined;
        right?: number | undefined;
    };
    set indent(value: {
        left?: number | undefined;
        right?: number | undefined;
    });
    /**
     * [descr:BaseWidgetOptions.loadingIndicator]
    
     */
    get loadingIndicator(): {
        backgroundColor?: string;
        enabled?: boolean;
        font?: Font;
        show?: boolean;
        text?: string;
    };
    set loadingIndicator(value: {
        backgroundColor?: string;
        enabled?: boolean;
        font?: Font;
        show?: boolean;
        text?: string;
    });
    /**
     * [descr:BaseWidgetOptions.margin]
    
     */
    get margin(): {
        bottom?: number;
        left?: number;
        right?: number;
        top?: number;
    };
    set margin(value: {
        bottom?: number;
        left?: number;
        right?: number;
        top?: number;
    });
    /**
     * [descr:BaseWidgetOptions.pathModified]
    
     */
    get pathModified(): boolean;
    set pathModified(value: boolean);
    /**
     * [descr:BaseWidgetOptions.redrawOnResize]
    
     */
    get redrawOnResize(): boolean;
    set redrawOnResize(value: boolean);
    /**
     * [descr:BaseWidgetOptions.rtlEnabled]
    
     */
    get rtlEnabled(): boolean;
    set rtlEnabled(value: boolean);
    /**
     * [descr:dxRangeSelectorOptions.scale]
    
     */
    get scale(): {
        aggregationGroupWidth?: number | undefined;
        aggregationInterval?: number | TimeInterval | {
            days?: number;
            hours?: number;
            milliseconds?: number;
            minutes?: number;
            months?: number;
            quarters?: number;
            seconds?: number;
            weeks?: number;
            years?: number;
        };
        allowDecimals?: boolean | undefined;
        breaks?: Array<ScaleBreak> | undefined | {
            endValue?: Date | number | string | undefined;
            startValue?: Date | number | string | undefined;
        }[];
        breakStyle?: {
            color?: string;
            line?: ScaleBreakLineStyle;
            width?: number;
        };
        categories?: Array<Date | number | string>;
        discreteAxisDivisionMode?: DiscreteAxisDivisionMode;
        endOnTick?: boolean;
        endValue?: Date | number | string | undefined;
        holidays?: Array<Date | string> | Array<number> | undefined;
        label?: {
            customizeText?: ((scaleValue: {
                value: Date | number | string;
                valueText: string;
            }) => string);
            font?: Font;
            format?: Format | undefined;
            overlappingBehavior?: LabelOverlap;
            topIndent?: number;
            visible?: boolean;
        };
        linearThreshold?: number;
        logarithmBase?: number;
        marker?: {
            label?: {
                customizeText?: ((markerValue: {
                    value: Date | number;
                    valueText: string;
                }) => string);
                format?: Format | undefined;
            };
            separatorHeight?: number;
            textLeftIndent?: number;
            textTopIndent?: number;
            topIndent?: number;
            visible?: boolean;
        };
        maxRange?: number | TimeInterval | {
            days?: number;
            hours?: number;
            milliseconds?: number;
            minutes?: number;
            months?: number;
            quarters?: number;
            seconds?: number;
            weeks?: number;
            years?: number;
        };
        minorTick?: {
            color?: string;
            opacity?: number;
            visible?: boolean;
            width?: number;
        };
        minorTickCount?: number | undefined;
        minorTickInterval?: number | TimeInterval | {
            days?: number;
            hours?: number;
            milliseconds?: number;
            minutes?: number;
            months?: number;
            quarters?: number;
            seconds?: number;
            weeks?: number;
            years?: number;
        };
        minRange?: number | TimeInterval | {
            days?: number;
            hours?: number;
            milliseconds?: number;
            minutes?: number;
            months?: number;
            quarters?: number;
            seconds?: number;
            weeks?: number;
            years?: number;
        };
        placeholderHeight?: number | undefined;
        showCustomBoundaryTicks?: boolean;
        singleWorkdays?: Array<Date | string> | Array<number> | undefined;
        startValue?: Date | number | string | undefined;
        tick?: {
            color?: string;
            opacity?: number;
            width?: number;
        };
        tickInterval?: number | TimeInterval | {
            days?: number;
            hours?: number;
            milliseconds?: number;
            minutes?: number;
            months?: number;
            quarters?: number;
            seconds?: number;
            weeks?: number;
            years?: number;
        };
        type?: AxisScale | undefined;
        valueType?: ChartsDataType | undefined;
        workdaysOnly?: boolean;
        workWeek?: Array<number>;
    };
    set scale(value: {
        aggregationGroupWidth?: number | undefined;
        aggregationInterval?: number | TimeInterval | {
            days?: number;
            hours?: number;
            milliseconds?: number;
            minutes?: number;
            months?: number;
            quarters?: number;
            seconds?: number;
            weeks?: number;
            years?: number;
        };
        allowDecimals?: boolean | undefined;
        breaks?: Array<ScaleBreak> | undefined | {
            endValue?: Date | number | string | undefined;
            startValue?: Date | number | string | undefined;
        }[];
        breakStyle?: {
            color?: string;
            line?: ScaleBreakLineStyle;
            width?: number;
        };
        categories?: Array<Date | number | string>;
        discreteAxisDivisionMode?: DiscreteAxisDivisionMode;
        endOnTick?: boolean;
        endValue?: Date | number | string | undefined;
        holidays?: Array<Date | string> | Array<number> | undefined;
        label?: {
            customizeText?: ((scaleValue: {
                value: Date | number | string;
                valueText: string;
            }) => string);
            font?: Font;
            format?: Format | undefined;
            overlappingBehavior?: LabelOverlap;
            topIndent?: number;
            visible?: boolean;
        };
        linearThreshold?: number;
        logarithmBase?: number;
        marker?: {
            label?: {
                customizeText?: ((markerValue: {
                    value: Date | number;
                    valueText: string;
                }) => string);
                format?: Format | undefined;
            };
            separatorHeight?: number;
            textLeftIndent?: number;
            textTopIndent?: number;
            topIndent?: number;
            visible?: boolean;
        };
        maxRange?: number | TimeInterval | {
            days?: number;
            hours?: number;
            milliseconds?: number;
            minutes?: number;
            months?: number;
            quarters?: number;
            seconds?: number;
            weeks?: number;
            years?: number;
        };
        minorTick?: {
            color?: string;
            opacity?: number;
            visible?: boolean;
            width?: number;
        };
        minorTickCount?: number | undefined;
        minorTickInterval?: number | TimeInterval | {
            days?: number;
            hours?: number;
            milliseconds?: number;
            minutes?: number;
            months?: number;
            quarters?: number;
            seconds?: number;
            weeks?: number;
            years?: number;
        };
        minRange?: number | TimeInterval | {
            days?: number;
            hours?: number;
            milliseconds?: number;
            minutes?: number;
            months?: number;
            quarters?: number;
            seconds?: number;
            weeks?: number;
            years?: number;
        };
        placeholderHeight?: number | undefined;
        showCustomBoundaryTicks?: boolean;
        singleWorkdays?: Array<Date | string> | Array<number> | undefined;
        startValue?: Date | number | string | undefined;
        tick?: {
            color?: string;
            opacity?: number;
            width?: number;
        };
        tickInterval?: number | TimeInterval | {
            days?: number;
            hours?: number;
            milliseconds?: number;
            minutes?: number;
            months?: number;
            quarters?: number;
            seconds?: number;
            weeks?: number;
            years?: number;
        };
        type?: AxisScale | undefined;
        valueType?: ChartsDataType | undefined;
        workdaysOnly?: boolean;
        workWeek?: Array<number>;
    });
    /**
     * [descr:dxRangeSelectorOptions.selectedRangeColor]
    
     */
    get selectedRangeColor(): string;
    set selectedRangeColor(value: string);
    /**
     * [descr:dxRangeSelectorOptions.selectedRangeUpdateMode]
    
     */
    get selectedRangeUpdateMode(): VisualRangeUpdateMode;
    set selectedRangeUpdateMode(value: VisualRangeUpdateMode);
    /**
     * [descr:dxRangeSelectorOptions.shutter]
    
     */
    get shutter(): {
        color?: string | undefined;
        opacity?: number;
    };
    set shutter(value: {
        color?: string | undefined;
        opacity?: number;
    });
    /**
     * [descr:BaseWidgetOptions.size]
    
     */
    get size(): {
        height?: number | undefined;
        width?: number | undefined;
    };
    set size(value: {
        height?: number | undefined;
        width?: number | undefined;
    });
    /**
     * [descr:dxRangeSelectorOptions.sliderHandle]
    
     */
    get sliderHandle(): {
        color?: string;
        opacity?: number;
        width?: number;
    };
    set sliderHandle(value: {
        color?: string;
        opacity?: number;
        width?: number;
    });
    /**
     * [descr:dxRangeSelectorOptions.sliderMarker]
    
     */
    get sliderMarker(): {
        color?: string;
        customizeText?: ((scaleValue: {
            value: Date | number | string;
            valueText: string;
        }) => string);
        font?: Font;
        format?: Format | undefined;
        invalidRangeColor?: string;
        paddingLeftRight?: number;
        paddingTopBottom?: number;
        placeholderHeight?: number | undefined;
        visible?: boolean;
    };
    set sliderMarker(value: {
        color?: string;
        customizeText?: ((scaleValue: {
            value: Date | number | string;
            valueText: string;
        }) => string);
        font?: Font;
        format?: Format | undefined;
        invalidRangeColor?: string;
        paddingLeftRight?: number;
        paddingTopBottom?: number;
        placeholderHeight?: number | undefined;
        visible?: boolean;
    });
    /**
     * [descr:BaseWidgetOptions.theme]
    
     */
    get theme(): Theme;
    set theme(value: Theme);
    /**
     * [descr:BaseWidgetOptions.title]
    
     */
    get title(): string | {
        font?: Font;
        horizontalAlignment?: HorizontalAlignment;
        margin?: number | {
            bottom?: number;
            left?: number;
            right?: number;
            top?: number;
        };
        placeholderSize?: number | undefined;
        subtitle?: string | {
            font?: Font;
            offset?: number;
            text?: string | undefined;
            textOverflow?: TextOverflow;
            wordWrap?: WordWrap;
        };
        text?: string | undefined;
        textOverflow?: TextOverflow;
        verticalAlignment?: VerticalEdge;
        wordWrap?: WordWrap;
    };
    set title(value: string | {
        font?: Font;
        horizontalAlignment?: HorizontalAlignment;
        margin?: number | {
            bottom?: number;
            left?: number;
            right?: number;
            top?: number;
        };
        placeholderSize?: number | undefined;
        subtitle?: string | {
            font?: Font;
            offset?: number;
            text?: string | undefined;
            textOverflow?: TextOverflow;
            wordWrap?: WordWrap;
        };
        text?: string | undefined;
        textOverflow?: TextOverflow;
        verticalAlignment?: VerticalEdge;
        wordWrap?: WordWrap;
    });
    /**
     * [descr:dxRangeSelectorOptions.value]
    
     */
    get value(): Array<Date | number | string> | CommonChartTypes.VisualRange;
    set value(value: Array<Date | number | string> | CommonChartTypes.VisualRange);
    /**
    
     * [descr:dxRangeSelectorOptions.onDisposing]
    
    
     */
    onDisposing: EventEmitter<DisposingEvent>;
    /**
    
     * [descr:dxRangeSelectorOptions.onDrawn]
    
    
     */
    onDrawn: EventEmitter<DrawnEvent>;
    /**
    
     * [descr:dxRangeSelectorOptions.onExported]
    
    
     */
    onExported: EventEmitter<ExportedEvent>;
    /**
    
     * [descr:dxRangeSelectorOptions.onExporting]
    
    
     */
    onExporting: EventEmitter<ExportingEvent>;
    /**
    
     * [descr:dxRangeSelectorOptions.onFileSaving]
    
    
     */
    onFileSaving: EventEmitter<FileSavingEvent>;
    /**
    
     * [descr:dxRangeSelectorOptions.onIncidentOccurred]
    
    
     */
    onIncidentOccurred: EventEmitter<IncidentOccurredEvent>;
    /**
    
     * [descr:dxRangeSelectorOptions.onInitialized]
    
    
     */
    onInitialized: EventEmitter<InitializedEvent>;
    /**
    
     * [descr:dxRangeSelectorOptions.onOptionChanged]
    
    
     */
    onOptionChanged: EventEmitter<OptionChangedEvent>;
    /**
    
     * [descr:dxRangeSelectorOptions.onValueChanged]
    
    
     */
    onValueChanged: EventEmitter<ValueChangedEvent>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    backgroundChange: EventEmitter<{
        color?: string;
        image?: {
            location?: BackgroundImageLocation;
            url?: string | undefined;
        };
        visible?: boolean;
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    behaviorChange: EventEmitter<{
        allowSlidersSwap?: boolean;
        animationEnabled?: boolean;
        manualRangeSelectionEnabled?: boolean;
        moveSelectedRangeByClick?: boolean;
        snapToTicks?: boolean;
        valueChangeMode?: SliderValueChangeMode;
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    chartChange: EventEmitter<{
        barGroupPadding?: number;
        barGroupWidth?: number | undefined;
        bottomIndent?: number;
        commonSeriesSettings?: dxChartCommonSeriesSettings;
        dataPrepareSettings?: {
            checkTypeForAllData?: boolean;
            convertToAxisDataType?: boolean;
            sortingMethod?: boolean | ((a: {
                arg: Date | number | string;
                val: Date | number | string;
            }, b: {
                arg: Date | number | string;
                val: Date | number | string;
            }) => number);
        };
        maxBubbleSize?: number;
        minBubbleSize?: number;
        negativesAsZeroes?: boolean;
        palette?: Array<string> | Palette;
        paletteExtensionMode?: PaletteExtensionMode;
        series?: Array<ChartSeries> | ChartSeries | undefined;
        seriesTemplate?: any;
        topIndent?: number;
        valueAxis?: {
            inverted?: boolean;
            logarithmBase?: number;
            max?: number | undefined;
            min?: number | undefined;
            type?: ChartAxisScale | undefined;
            valueType?: ChartsDataType | undefined;
        };
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    containerBackgroundColorChange: EventEmitter<string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    dataSourceChange: EventEmitter<Array<any> | DataSource | DataSourceOptions | null | Store | string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    dataSourceFieldChange: EventEmitter<string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    disabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    elementAttrChange: EventEmitter<Record<string, any>>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    encodeHtmlChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    exportChange: EventEmitter<{
        backgroundColor?: string;
        enabled?: boolean;
        fileName?: string;
        formats?: Array<ExportFormat>;
        margin?: number;
        printingEnabled?: boolean;
        svgToCanvas?: ((svg: any, canvas: any) => any) | undefined;
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    indentChange: EventEmitter<{
        left?: number | undefined;
        right?: number | undefined;
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    loadingIndicatorChange: EventEmitter<{
        backgroundColor?: string;
        enabled?: boolean;
        font?: Font;
        show?: boolean;
        text?: string;
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    marginChange: EventEmitter<{
        bottom?: number;
        left?: number;
        right?: number;
        top?: number;
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    pathModifiedChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    redrawOnResizeChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    rtlEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    scaleChange: EventEmitter<{
        aggregationGroupWidth?: number | undefined;
        aggregationInterval?: number | TimeInterval | {
            days?: number;
            hours?: number;
            milliseconds?: number;
            minutes?: number;
            months?: number;
            quarters?: number;
            seconds?: number;
            weeks?: number;
            years?: number;
        };
        allowDecimals?: boolean | undefined;
        breaks?: Array<ScaleBreak> | undefined | {
            endValue?: Date | number | string | undefined;
            startValue?: Date | number | string | undefined;
        }[];
        breakStyle?: {
            color?: string;
            line?: ScaleBreakLineStyle;
            width?: number;
        };
        categories?: Array<Date | number | string>;
        discreteAxisDivisionMode?: DiscreteAxisDivisionMode;
        endOnTick?: boolean;
        endValue?: Date | number | string | undefined;
        holidays?: Array<Date | string> | Array<number> | undefined;
        label?: {
            customizeText?: ((scaleValue: {
                value: Date | number | string;
                valueText: string;
            }) => string);
            font?: Font;
            format?: Format | undefined;
            overlappingBehavior?: LabelOverlap;
            topIndent?: number;
            visible?: boolean;
        };
        linearThreshold?: number;
        logarithmBase?: number;
        marker?: {
            label?: {
                customizeText?: ((markerValue: {
                    value: Date | number;
                    valueText: string;
                }) => string);
                format?: Format | undefined;
            };
            separatorHeight?: number;
            textLeftIndent?: number;
            textTopIndent?: number;
            topIndent?: number;
            visible?: boolean;
        };
        maxRange?: number | TimeInterval | {
            days?: number;
            hours?: number;
            milliseconds?: number;
            minutes?: number;
            months?: number;
            quarters?: number;
            seconds?: number;
            weeks?: number;
            years?: number;
        };
        minorTick?: {
            color?: string;
            opacity?: number;
            visible?: boolean;
            width?: number;
        };
        minorTickCount?: number | undefined;
        minorTickInterval?: number | TimeInterval | {
            days?: number;
            hours?: number;
            milliseconds?: number;
            minutes?: number;
            months?: number;
            quarters?: number;
            seconds?: number;
            weeks?: number;
            years?: number;
        };
        minRange?: number | TimeInterval | {
            days?: number;
            hours?: number;
            milliseconds?: number;
            minutes?: number;
            months?: number;
            quarters?: number;
            seconds?: number;
            weeks?: number;
            years?: number;
        };
        placeholderHeight?: number | undefined;
        showCustomBoundaryTicks?: boolean;
        singleWorkdays?: Array<Date | string> | Array<number> | undefined;
        startValue?: Date | number | string | undefined;
        tick?: {
            color?: string;
            opacity?: number;
            width?: number;
        };
        tickInterval?: number | TimeInterval | {
            days?: number;
            hours?: number;
            milliseconds?: number;
            minutes?: number;
            months?: number;
            quarters?: number;
            seconds?: number;
            weeks?: number;
            years?: number;
        };
        type?: AxisScale | undefined;
        valueType?: ChartsDataType | undefined;
        workdaysOnly?: boolean;
        workWeek?: Array<number>;
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    selectedRangeColorChange: EventEmitter<string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    selectedRangeUpdateModeChange: EventEmitter<VisualRangeUpdateMode>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    shutterChange: EventEmitter<{
        color?: string | undefined;
        opacity?: number;
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    sizeChange: EventEmitter<{
        height?: number | undefined;
        width?: number | undefined;
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    sliderHandleChange: EventEmitter<{
        color?: string;
        opacity?: number;
        width?: number;
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    sliderMarkerChange: EventEmitter<{
        color?: string;
        customizeText?: ((scaleValue: {
            value: Date | number | string;
            valueText: string;
        }) => string);
        font?: Font;
        format?: Format | undefined;
        invalidRangeColor?: string;
        paddingLeftRight?: number;
        paddingTopBottom?: number;
        placeholderHeight?: number | undefined;
        visible?: boolean;
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    themeChange: EventEmitter<Theme>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    titleChange: EventEmitter<string | {
        font?: Font;
        horizontalAlignment?: HorizontalAlignment;
        margin?: number | {
            bottom?: number;
            left?: number;
            right?: number;
            top?: number;
        };
        placeholderSize?: number | undefined;
        subtitle?: string | {
            font?: Font;
            offset?: number;
            text?: string | undefined;
            textOverflow?: TextOverflow;
            wordWrap?: WordWrap;
        };
        text?: string | undefined;
        textOverflow?: TextOverflow;
        verticalAlignment?: VerticalEdge;
        wordWrap?: WordWrap;
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    valueChange: EventEmitter<Array<Date | number | string> | CommonChartTypes.VisualRange>;
    /**
    
     * [descr:undefined]
    
    
     */
    onBlur: EventEmitter<any>;
    change(_: any): void;
    touched: (_: any) => void;
    constructor(elementRef: ElementRef, ngZone: NgZone, templateHost: DxTemplateHost, _watcherHelper: WatcherHelper, _idh: IterableDifferHelper, optionHost: NestedOptionHost, transferState: TransferState, platformId: any);
    protected _createInstance(element: any, options: any): DxRangeSelector;
    writeValue(value: any): void;
    registerOnChange(fn: (_: any) => void): void;
    registerOnTouched(fn: () => void): void;
    _createWidget(element: any): void;
    ngOnDestroy(): void;
    ngOnChanges(changes: SimpleChanges): void;
    setupChanges(prop: string, changes: SimpleChanges): void;
    ngDoCheck(): void;
    _setOption(name: string, value: any): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxRangeSelectorComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxRangeSelectorComponent, "dx-range-selector", never, { "background": { "alias": "background"; "required": false; }; "behavior": { "alias": "behavior"; "required": false; }; "chart": { "alias": "chart"; "required": false; }; "containerBackgroundColor": { "alias": "containerBackgroundColor"; "required": false; }; "dataSource": { "alias": "dataSource"; "required": false; }; "dataSourceField": { "alias": "dataSourceField"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "elementAttr": { "alias": "elementAttr"; "required": false; }; "encodeHtml": { "alias": "encodeHtml"; "required": false; }; "export": { "alias": "export"; "required": false; }; "indent": { "alias": "indent"; "required": false; }; "loadingIndicator": { "alias": "loadingIndicator"; "required": false; }; "margin": { "alias": "margin"; "required": false; }; "pathModified": { "alias": "pathModified"; "required": false; }; "redrawOnResize": { "alias": "redrawOnResize"; "required": false; }; "rtlEnabled": { "alias": "rtlEnabled"; "required": false; }; "scale": { "alias": "scale"; "required": false; }; "selectedRangeColor": { "alias": "selectedRangeColor"; "required": false; }; "selectedRangeUpdateMode": { "alias": "selectedRangeUpdateMode"; "required": false; }; "shutter": { "alias": "shutter"; "required": false; }; "size": { "alias": "size"; "required": false; }; "sliderHandle": { "alias": "sliderHandle"; "required": false; }; "sliderMarker": { "alias": "sliderMarker"; "required": false; }; "theme": { "alias": "theme"; "required": false; }; "title": { "alias": "title"; "required": false; }; "value": { "alias": "value"; "required": false; }; }, { "onDisposing": "onDisposing"; "onDrawn": "onDrawn"; "onExported": "onExported"; "onExporting": "onExporting"; "onFileSaving": "onFileSaving"; "onIncidentOccurred": "onIncidentOccurred"; "onInitialized": "onInitialized"; "onOptionChanged": "onOptionChanged"; "onValueChanged": "onValueChanged"; "backgroundChange": "backgroundChange"; "behaviorChange": "behaviorChange"; "chartChange": "chartChange"; "containerBackgroundColorChange": "containerBackgroundColorChange"; "dataSourceChange": "dataSourceChange"; "dataSourceFieldChange": "dataSourceFieldChange"; "disabledChange": "disabledChange"; "elementAttrChange": "elementAttrChange"; "encodeHtmlChange": "encodeHtmlChange"; "exportChange": "exportChange"; "indentChange": "indentChange"; "loadingIndicatorChange": "loadingIndicatorChange"; "marginChange": "marginChange"; "pathModifiedChange": "pathModifiedChange"; "redrawOnResizeChange": "redrawOnResizeChange"; "rtlEnabledChange": "rtlEnabledChange"; "scaleChange": "scaleChange"; "selectedRangeColorChange": "selectedRangeColorChange"; "selectedRangeUpdateModeChange": "selectedRangeUpdateModeChange"; "shutterChange": "shutterChange"; "sizeChange": "sizeChange"; "sliderHandleChange": "sliderHandleChange"; "sliderMarkerChange": "sliderMarkerChange"; "themeChange": "themeChange"; "titleChange": "titleChange"; "valueChange": "valueChange"; "onBlur": "onBlur"; }, ["_breaksContentChildren", "_seriesContentChildren"], never, true, never>;
}
declare class DxRangeSelectorModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxRangeSelectorModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxRangeSelectorModule, never, [typeof DxRangeSelectorComponent, typeof i1.DxoBackgroundModule, typeof i1.DxoImageModule, typeof i1.DxoBehaviorModule, typeof i1.DxoChartModule, typeof i1.DxoCommonSeriesSettingsModule, typeof i1.DxoAggregationModule, typeof i1.DxoAreaModule, typeof i1.DxoBorderModule, typeof i1.DxoHoverStyleModule, typeof i1.DxoHatchingModule, typeof i1.DxoLabelModule, typeof i1.DxoConnectorModule, typeof i1.DxoPointModule, typeof i1.DxoHeightModule, typeof i1.DxoUrlModule, typeof i1.DxoWidthModule, typeof i1.DxoSelectionStyleModule, typeof i1.DxoReductionModule, typeof i1.DxoValueErrorBarModule, typeof i1.DxoBarModule, typeof i1.DxoBubbleModule, typeof i1.DxoCandlestickModule, typeof i1.DxoColorModule, typeof i1.DxoFullstackedareaModule, typeof i1.DxoFullstackedbarModule, typeof i1.DxoFullstackedlineModule, typeof i1.DxoFullstackedsplineModule, typeof i1.DxoFullstackedsplineareaModule, typeof i1.DxoArgumentFormatModule, typeof i1.DxoFontModule, typeof i1.DxoFormatModule, typeof i1.DxoLineModule, typeof i1.DxoRangeareaModule, typeof i1.DxoRangebarModule, typeof i1.DxoScatterModule, typeof i1.DxoSplineModule, typeof i1.DxoSplineareaModule, typeof i1.DxoStackedareaModule, typeof i1.DxoStackedbarModule, typeof i1.DxoStackedlineModule, typeof i1.DxoStackedsplineModule, typeof i1.DxoStackedsplineareaModule, typeof i1.DxoStepareaModule, typeof i1.DxoSteplineModule, typeof i1.DxoStockModule, typeof i1.DxoDataPrepareSettingsModule, typeof i1.DxiSeriesModule, typeof i1.DxoSeriesTemplateModule, typeof i1.DxoValueAxisModule, typeof i1.DxoExportModule, typeof i1.DxoIndentModule, typeof i1.DxoLoadingIndicatorModule, typeof i1.DxoMarginModule, typeof i1.DxoScaleModule, typeof i1.DxoAggregationIntervalModule, typeof i1.DxiBreakModule, typeof i1.DxoBreakStyleModule, typeof i1.DxoMarkerModule, typeof i1.DxoMaxRangeModule, typeof i1.DxoMinorTickModule, typeof i1.DxoMinorTickIntervalModule, typeof i1.DxoMinRangeModule, typeof i1.DxoTickModule, typeof i1.DxoTickIntervalModule, typeof i1.DxoShutterModule, typeof i1.DxoSizeModule, typeof i1.DxoSliderHandleModule, typeof i1.DxoSliderMarkerModule, typeof i1.DxoTitleModule, typeof i1.DxoSubtitleModule, typeof i2.DxoRangeSelectorAggregationModule, typeof i2.DxoRangeSelectorAggregationIntervalModule, typeof i2.DxoRangeSelectorArgumentFormatModule, typeof i2.DxoRangeSelectorBackgroundModule, typeof i2.DxoRangeSelectorBackgroundImageModule, typeof i2.DxoRangeSelectorBehaviorModule, typeof i2.DxoRangeSelectorBorderModule, typeof i2.DxiRangeSelectorBreakModule, typeof i2.DxoRangeSelectorBreakStyleModule, typeof i2.DxoRangeSelectorChartModule, typeof i2.DxoRangeSelectorColorModule, typeof i2.DxoRangeSelectorCommonSeriesSettingsModule, typeof i2.DxoRangeSelectorCommonSeriesSettingsHoverStyleModule, typeof i2.DxoRangeSelectorCommonSeriesSettingsLabelModule, typeof i2.DxoRangeSelectorCommonSeriesSettingsSelectionStyleModule, typeof i2.DxoRangeSelectorConnectorModule, typeof i2.DxoRangeSelectorDataPrepareSettingsModule, typeof i2.DxoRangeSelectorExportModule, typeof i2.DxoRangeSelectorFontModule, typeof i2.DxoRangeSelectorFormatModule, typeof i2.DxoRangeSelectorHatchingModule, typeof i2.DxoRangeSelectorHeightModule, typeof i2.DxoRangeSelectorHoverStyleModule, typeof i2.DxoRangeSelectorImageModule, typeof i2.DxoRangeSelectorIndentModule, typeof i2.DxoRangeSelectorLabelModule, typeof i2.DxoRangeSelectorLengthModule, typeof i2.DxoRangeSelectorLoadingIndicatorModule, typeof i2.DxoRangeSelectorMarginModule, typeof i2.DxoRangeSelectorMarkerModule, typeof i2.DxoRangeSelectorMarkerLabelModule, typeof i2.DxoRangeSelectorMaxRangeModule, typeof i2.DxoRangeSelectorMinorTickModule, typeof i2.DxoRangeSelectorMinorTickIntervalModule, typeof i2.DxoRangeSelectorMinRangeModule, typeof i2.DxoRangeSelectorPointModule, typeof i2.DxoRangeSelectorPointBorderModule, typeof i2.DxoRangeSelectorPointHoverStyleModule, typeof i2.DxoRangeSelectorPointImageModule, typeof i2.DxoRangeSelectorPointSelectionStyleModule, typeof i2.DxoRangeSelectorReductionModule, typeof i2.DxoRangeSelectorScaleModule, typeof i2.DxoRangeSelectorScaleLabelModule, typeof i2.DxoRangeSelectorSelectionStyleModule, typeof i2.DxiRangeSelectorSeriesModule, typeof i2.DxoRangeSelectorSeriesBorderModule, typeof i2.DxoRangeSelectorSeriesTemplateModule, typeof i2.DxoRangeSelectorShutterModule, typeof i2.DxoRangeSelectorSizeModule, typeof i2.DxoRangeSelectorSliderHandleModule, typeof i2.DxoRangeSelectorSliderMarkerModule, typeof i2.DxoRangeSelectorSubtitleModule, typeof i2.DxoRangeSelectorTickModule, typeof i2.DxoRangeSelectorTickIntervalModule, typeof i2.DxoRangeSelectorTitleModule, typeof i2.DxoRangeSelectorUrlModule, typeof i2.DxoRangeSelectorValueModule, typeof i2.DxoRangeSelectorValueAxisModule, typeof i2.DxoRangeSelectorValueErrorBarModule, typeof i2.DxoRangeSelectorWidthModule, typeof i3.DxIntegrationModule, typeof i3.DxTemplateModule], [typeof DxRangeSelectorComponent, typeof i1.DxoBackgroundModule, typeof i1.DxoImageModule, typeof i1.DxoBehaviorModule, typeof i1.DxoChartModule, typeof i1.DxoCommonSeriesSettingsModule, typeof i1.DxoAggregationModule, typeof i1.DxoAreaModule, typeof i1.DxoBorderModule, typeof i1.DxoHoverStyleModule, typeof i1.DxoHatchingModule, typeof i1.DxoLabelModule, typeof i1.DxoConnectorModule, typeof i1.DxoPointModule, typeof i1.DxoHeightModule, typeof i1.DxoUrlModule, typeof i1.DxoWidthModule, typeof i1.DxoSelectionStyleModule, typeof i1.DxoReductionModule, typeof i1.DxoValueErrorBarModule, typeof i1.DxoBarModule, typeof i1.DxoBubbleModule, typeof i1.DxoCandlestickModule, typeof i1.DxoColorModule, typeof i1.DxoFullstackedareaModule, typeof i1.DxoFullstackedbarModule, typeof i1.DxoFullstackedlineModule, typeof i1.DxoFullstackedsplineModule, typeof i1.DxoFullstackedsplineareaModule, typeof i1.DxoArgumentFormatModule, typeof i1.DxoFontModule, typeof i1.DxoFormatModule, typeof i1.DxoLineModule, typeof i1.DxoRangeareaModule, typeof i1.DxoRangebarModule, typeof i1.DxoScatterModule, typeof i1.DxoSplineModule, typeof i1.DxoSplineareaModule, typeof i1.DxoStackedareaModule, typeof i1.DxoStackedbarModule, typeof i1.DxoStackedlineModule, typeof i1.DxoStackedsplineModule, typeof i1.DxoStackedsplineareaModule, typeof i1.DxoStepareaModule, typeof i1.DxoSteplineModule, typeof i1.DxoStockModule, typeof i1.DxoDataPrepareSettingsModule, typeof i1.DxiSeriesModule, typeof i1.DxoSeriesTemplateModule, typeof i1.DxoValueAxisModule, typeof i1.DxoExportModule, typeof i1.DxoIndentModule, typeof i1.DxoLoadingIndicatorModule, typeof i1.DxoMarginModule, typeof i1.DxoScaleModule, typeof i1.DxoAggregationIntervalModule, typeof i1.DxiBreakModule, typeof i1.DxoBreakStyleModule, typeof i1.DxoMarkerModule, typeof i1.DxoMaxRangeModule, typeof i1.DxoMinorTickModule, typeof i1.DxoMinorTickIntervalModule, typeof i1.DxoMinRangeModule, typeof i1.DxoTickModule, typeof i1.DxoTickIntervalModule, typeof i1.DxoShutterModule, typeof i1.DxoSizeModule, typeof i1.DxoSliderHandleModule, typeof i1.DxoSliderMarkerModule, typeof i1.DxoTitleModule, typeof i1.DxoSubtitleModule, typeof i2.DxoRangeSelectorAggregationModule, typeof i2.DxoRangeSelectorAggregationIntervalModule, typeof i2.DxoRangeSelectorArgumentFormatModule, typeof i2.DxoRangeSelectorBackgroundModule, typeof i2.DxoRangeSelectorBackgroundImageModule, typeof i2.DxoRangeSelectorBehaviorModule, typeof i2.DxoRangeSelectorBorderModule, typeof i2.DxiRangeSelectorBreakModule, typeof i2.DxoRangeSelectorBreakStyleModule, typeof i2.DxoRangeSelectorChartModule, typeof i2.DxoRangeSelectorColorModule, typeof i2.DxoRangeSelectorCommonSeriesSettingsModule, typeof i2.DxoRangeSelectorCommonSeriesSettingsHoverStyleModule, typeof i2.DxoRangeSelectorCommonSeriesSettingsLabelModule, typeof i2.DxoRangeSelectorCommonSeriesSettingsSelectionStyleModule, typeof i2.DxoRangeSelectorConnectorModule, typeof i2.DxoRangeSelectorDataPrepareSettingsModule, typeof i2.DxoRangeSelectorExportModule, typeof i2.DxoRangeSelectorFontModule, typeof i2.DxoRangeSelectorFormatModule, typeof i2.DxoRangeSelectorHatchingModule, typeof i2.DxoRangeSelectorHeightModule, typeof i2.DxoRangeSelectorHoverStyleModule, typeof i2.DxoRangeSelectorImageModule, typeof i2.DxoRangeSelectorIndentModule, typeof i2.DxoRangeSelectorLabelModule, typeof i2.DxoRangeSelectorLengthModule, typeof i2.DxoRangeSelectorLoadingIndicatorModule, typeof i2.DxoRangeSelectorMarginModule, typeof i2.DxoRangeSelectorMarkerModule, typeof i2.DxoRangeSelectorMarkerLabelModule, typeof i2.DxoRangeSelectorMaxRangeModule, typeof i2.DxoRangeSelectorMinorTickModule, typeof i2.DxoRangeSelectorMinorTickIntervalModule, typeof i2.DxoRangeSelectorMinRangeModule, typeof i2.DxoRangeSelectorPointModule, typeof i2.DxoRangeSelectorPointBorderModule, typeof i2.DxoRangeSelectorPointHoverStyleModule, typeof i2.DxoRangeSelectorPointImageModule, typeof i2.DxoRangeSelectorPointSelectionStyleModule, typeof i2.DxoRangeSelectorReductionModule, typeof i2.DxoRangeSelectorScaleModule, typeof i2.DxoRangeSelectorScaleLabelModule, typeof i2.DxoRangeSelectorSelectionStyleModule, typeof i2.DxiRangeSelectorSeriesModule, typeof i2.DxoRangeSelectorSeriesBorderModule, typeof i2.DxoRangeSelectorSeriesTemplateModule, typeof i2.DxoRangeSelectorShutterModule, typeof i2.DxoRangeSelectorSizeModule, typeof i2.DxoRangeSelectorSliderHandleModule, typeof i2.DxoRangeSelectorSliderMarkerModule, typeof i2.DxoRangeSelectorSubtitleModule, typeof i2.DxoRangeSelectorTickModule, typeof i2.DxoRangeSelectorTickIntervalModule, typeof i2.DxoRangeSelectorTitleModule, typeof i2.DxoRangeSelectorUrlModule, typeof i2.DxoRangeSelectorValueModule, typeof i2.DxoRangeSelectorValueAxisModule, typeof i2.DxoRangeSelectorValueErrorBarModule, typeof i2.DxoRangeSelectorWidthModule, typeof i3.DxTemplateModule]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxRangeSelectorModule>;
}

export { DxRangeSelectorComponent, DxRangeSelectorModule };
//# sourceMappingURL=index.d.ts.map
