import * as i0 from '@angular/core';
import { OnDestroy, OnInit, QueryList, EventEmitter } from '@angular/core';
import { NestedOption, NestedOptionHost, CollectionNestedOption } from 'devextreme-angular/core';
import { chartPointAggregationInfoObject, chartSeriesObject, ChartSeriesAggregationMethod, dxChartCommonSeriesSettings, FinancialChartReductionLevel } from 'devextreme/viz/chart';
import { Format, SliderValueChangeMode, HorizontalAlignment, ExportFormat, VerticalEdge } from 'devextreme/common';
import { BackgroundImageLocation, ChartAxisScale, AxisScale } from 'devextreme/viz/range_selector';
import { DashStyle, ScaleBreakLineStyle, Palette, PaletteExtensionMode, ChartsDataType, ChartsColor, HatchDirection, Font, RelativePosition, SeriesHoverMode, PointInteractionMode, PointSymbol, SeriesSelectionMode, SeriesType, ValueErrorBarDisplayMode, ValueErrorBarType, LabelOverlap, TimeInterval, ScaleBreak, DiscreteAxisDivisionMode, TextOverflow, WordWrap } from 'devextreme/common/charts';
import { ChartSeries } from 'devextreme/viz/common';
import { Format as Format$1 } from 'devextreme/common/core/localization';

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoRangeSelectorAggregationIntervalComponent extends NestedOption implements OnDestroy, OnInit {
    get days(): number;
    set days(value: number);
    get hours(): number;
    set hours(value: number);
    get milliseconds(): number;
    set milliseconds(value: number);
    get minutes(): number;
    set minutes(value: number);
    get months(): number;
    set months(value: number);
    get quarters(): number;
    set quarters(value: number);
    get seconds(): number;
    set seconds(value: number);
    get weeks(): number;
    set weeks(value: number);
    get years(): number;
    set years(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoRangeSelectorAggregationIntervalComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoRangeSelectorAggregationIntervalComponent, "dxo-range-selector-aggregation-interval", never, { "days": { "alias": "days"; "required": false; }; "hours": { "alias": "hours"; "required": false; }; "milliseconds": { "alias": "milliseconds"; "required": false; }; "minutes": { "alias": "minutes"; "required": false; }; "months": { "alias": "months"; "required": false; }; "quarters": { "alias": "quarters"; "required": false; }; "seconds": { "alias": "seconds"; "required": false; }; "weeks": { "alias": "weeks"; "required": false; }; "years": { "alias": "years"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoRangeSelectorAggregationIntervalModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoRangeSelectorAggregationIntervalModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoRangeSelectorAggregationIntervalModule, never, [typeof DxoRangeSelectorAggregationIntervalComponent], [typeof DxoRangeSelectorAggregationIntervalComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoRangeSelectorAggregationIntervalModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoRangeSelectorAggregationComponent extends NestedOption implements OnDestroy, OnInit {
    get calculate(): ((aggregationInfo: chartPointAggregationInfoObject, series: chartSeriesObject) => Record<string, any> | Array<Record<string, any>>) | undefined;
    set calculate(value: ((aggregationInfo: chartPointAggregationInfoObject, series: chartSeriesObject) => Record<string, any> | Array<Record<string, any>>) | undefined);
    get enabled(): boolean;
    set enabled(value: boolean);
    get method(): ChartSeriesAggregationMethod;
    set method(value: ChartSeriesAggregationMethod);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoRangeSelectorAggregationComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoRangeSelectorAggregationComponent, "dxo-range-selector-aggregation", never, { "calculate": { "alias": "calculate"; "required": false; }; "enabled": { "alias": "enabled"; "required": false; }; "method": { "alias": "method"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoRangeSelectorAggregationModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoRangeSelectorAggregationModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoRangeSelectorAggregationModule, never, [typeof DxoRangeSelectorAggregationComponent], [typeof DxoRangeSelectorAggregationComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoRangeSelectorAggregationModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoRangeSelectorArgumentFormatComponent extends NestedOption implements OnDestroy, OnInit {
    get currency(): string;
    set currency(value: string);
    get formatter(): ((value: number | Date) => string);
    set formatter(value: ((value: number | Date) => string));
    get parser(): ((value: string) => number | Date);
    set parser(value: ((value: string) => number | Date));
    get precision(): number;
    set precision(value: number);
    get type(): Format | string;
    set type(value: Format | string);
    get useCurrencyAccountingStyle(): boolean;
    set useCurrencyAccountingStyle(value: boolean);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoRangeSelectorArgumentFormatComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoRangeSelectorArgumentFormatComponent, "dxo-range-selector-argument-format", never, { "currency": { "alias": "currency"; "required": false; }; "formatter": { "alias": "formatter"; "required": false; }; "parser": { "alias": "parser"; "required": false; }; "precision": { "alias": "precision"; "required": false; }; "type": { "alias": "type"; "required": false; }; "useCurrencyAccountingStyle": { "alias": "useCurrencyAccountingStyle"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoRangeSelectorArgumentFormatModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoRangeSelectorArgumentFormatModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoRangeSelectorArgumentFormatModule, never, [typeof DxoRangeSelectorArgumentFormatComponent], [typeof DxoRangeSelectorArgumentFormatComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoRangeSelectorArgumentFormatModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoRangeSelectorBackgroundImageComponent extends NestedOption implements OnDestroy, OnInit {
    get location(): BackgroundImageLocation;
    set location(value: BackgroundImageLocation);
    get url(): string | undefined;
    set url(value: string | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoRangeSelectorBackgroundImageComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoRangeSelectorBackgroundImageComponent, "dxo-range-selector-background-image", never, { "location": { "alias": "location"; "required": false; }; "url": { "alias": "url"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoRangeSelectorBackgroundImageModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoRangeSelectorBackgroundImageModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoRangeSelectorBackgroundImageModule, never, [typeof DxoRangeSelectorBackgroundImageComponent], [typeof DxoRangeSelectorBackgroundImageComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoRangeSelectorBackgroundImageModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoRangeSelectorBackgroundComponent extends NestedOption implements OnDestroy, OnInit {
    get color(): string;
    set color(value: string);
    get image(): {
        location?: BackgroundImageLocation;
        url?: string | undefined;
    };
    set image(value: {
        location?: BackgroundImageLocation;
        url?: string | undefined;
    });
    get visible(): boolean;
    set visible(value: boolean);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoRangeSelectorBackgroundComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoRangeSelectorBackgroundComponent, "dxo-range-selector-background", never, { "color": { "alias": "color"; "required": false; }; "image": { "alias": "image"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoRangeSelectorBackgroundModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoRangeSelectorBackgroundModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoRangeSelectorBackgroundModule, never, [typeof DxoRangeSelectorBackgroundComponent], [typeof DxoRangeSelectorBackgroundComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoRangeSelectorBackgroundModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoRangeSelectorBehaviorComponent extends NestedOption implements OnDestroy, OnInit {
    get allowSlidersSwap(): boolean;
    set allowSlidersSwap(value: boolean);
    get animationEnabled(): boolean;
    set animationEnabled(value: boolean);
    get manualRangeSelectionEnabled(): boolean;
    set manualRangeSelectionEnabled(value: boolean);
    get moveSelectedRangeByClick(): boolean;
    set moveSelectedRangeByClick(value: boolean);
    get snapToTicks(): boolean;
    set snapToTicks(value: boolean);
    get valueChangeMode(): SliderValueChangeMode;
    set valueChangeMode(value: SliderValueChangeMode);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoRangeSelectorBehaviorComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoRangeSelectorBehaviorComponent, "dxo-range-selector-behavior", never, { "allowSlidersSwap": { "alias": "allowSlidersSwap"; "required": false; }; "animationEnabled": { "alias": "animationEnabled"; "required": false; }; "manualRangeSelectionEnabled": { "alias": "manualRangeSelectionEnabled"; "required": false; }; "moveSelectedRangeByClick": { "alias": "moveSelectedRangeByClick"; "required": false; }; "snapToTicks": { "alias": "snapToTicks"; "required": false; }; "valueChangeMode": { "alias": "valueChangeMode"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoRangeSelectorBehaviorModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoRangeSelectorBehaviorModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoRangeSelectorBehaviorModule, never, [typeof DxoRangeSelectorBehaviorComponent], [typeof DxoRangeSelectorBehaviorComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoRangeSelectorBehaviorModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoRangeSelectorBorderComponent extends NestedOption implements OnDestroy, OnInit {
    get color(): string | undefined;
    set color(value: string | undefined);
    get dashStyle(): DashStyle | undefined;
    set dashStyle(value: DashStyle | undefined);
    get visible(): boolean;
    set visible(value: boolean);
    get width(): number;
    set width(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoRangeSelectorBorderComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoRangeSelectorBorderComponent, "dxo-range-selector-border", never, { "color": { "alias": "color"; "required": false; }; "dashStyle": { "alias": "dashStyle"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoRangeSelectorBorderModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoRangeSelectorBorderModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoRangeSelectorBorderModule, never, [typeof DxoRangeSelectorBorderComponent], [typeof DxoRangeSelectorBorderComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoRangeSelectorBorderModule>;
}

declare class DxiRangeSelectorBreakComponent extends CollectionNestedOption {
    get endValue(): Date | number | string | undefined;
    set endValue(value: Date | number | string | undefined);
    get startValue(): Date | number | string | undefined;
    set startValue(value: Date | number | string | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiRangeSelectorBreakComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiRangeSelectorBreakComponent, "dxi-range-selector-break", never, { "endValue": { "alias": "endValue"; "required": false; }; "startValue": { "alias": "startValue"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxiRangeSelectorBreakModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiRangeSelectorBreakModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiRangeSelectorBreakModule, never, [typeof DxiRangeSelectorBreakComponent], [typeof DxiRangeSelectorBreakComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiRangeSelectorBreakModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoRangeSelectorBreakStyleComponent extends NestedOption implements OnDestroy, OnInit {
    get color(): string;
    set color(value: string);
    get line(): ScaleBreakLineStyle;
    set line(value: ScaleBreakLineStyle);
    get width(): number;
    set width(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoRangeSelectorBreakStyleComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoRangeSelectorBreakStyleComponent, "dxo-range-selector-break-style", never, { "color": { "alias": "color"; "required": false; }; "line": { "alias": "line"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoRangeSelectorBreakStyleModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoRangeSelectorBreakStyleModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoRangeSelectorBreakStyleModule, never, [typeof DxoRangeSelectorBreakStyleComponent], [typeof DxoRangeSelectorBreakStyleComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoRangeSelectorBreakStyleModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoRangeSelectorChartComponent extends NestedOption implements OnDestroy, OnInit {
    set _seriesContentChildren(value: QueryList<CollectionNestedOption>);
    get barGroupPadding(): number;
    set barGroupPadding(value: number);
    get barGroupWidth(): number | undefined;
    set barGroupWidth(value: number | undefined);
    get bottomIndent(): number;
    set bottomIndent(value: number);
    get commonSeriesSettings(): dxChartCommonSeriesSettings;
    set commonSeriesSettings(value: dxChartCommonSeriesSettings);
    get dataPrepareSettings(): {
        checkTypeForAllData?: boolean;
        convertToAxisDataType?: boolean;
        sortingMethod?: boolean | ((a: {
            arg: Date | number | string;
            val: Date | number | string;
        }, b: {
            arg: Date | number | string;
            val: Date | number | string;
        }) => number);
    };
    set dataPrepareSettings(value: {
        checkTypeForAllData?: boolean;
        convertToAxisDataType?: boolean;
        sortingMethod?: boolean | ((a: {
            arg: Date | number | string;
            val: Date | number | string;
        }, b: {
            arg: Date | number | string;
            val: Date | number | string;
        }) => number);
    });
    get maxBubbleSize(): number;
    set maxBubbleSize(value: number);
    get minBubbleSize(): number;
    set minBubbleSize(value: number);
    get negativesAsZeroes(): boolean;
    set negativesAsZeroes(value: boolean);
    get palette(): Array<string> | Palette;
    set palette(value: Array<string> | Palette);
    get paletteExtensionMode(): PaletteExtensionMode;
    set paletteExtensionMode(value: PaletteExtensionMode);
    get series(): Array<ChartSeries> | ChartSeries | undefined;
    set series(value: Array<ChartSeries> | ChartSeries | undefined);
    get seriesTemplate(): any;
    set seriesTemplate(value: any);
    get topIndent(): number;
    set topIndent(value: number);
    get valueAxis(): {
        inverted?: boolean;
        logarithmBase?: number;
        max?: number | undefined;
        min?: number | undefined;
        type?: ChartAxisScale | undefined;
        valueType?: ChartsDataType | undefined;
    };
    set valueAxis(value: {
        inverted?: boolean;
        logarithmBase?: number;
        max?: number | undefined;
        min?: number | undefined;
        type?: ChartAxisScale | undefined;
        valueType?: ChartsDataType | undefined;
    });
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoRangeSelectorChartComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoRangeSelectorChartComponent, "dxo-range-selector-chart", never, { "barGroupPadding": { "alias": "barGroupPadding"; "required": false; }; "barGroupWidth": { "alias": "barGroupWidth"; "required": false; }; "bottomIndent": { "alias": "bottomIndent"; "required": false; }; "commonSeriesSettings": { "alias": "commonSeriesSettings"; "required": false; }; "dataPrepareSettings": { "alias": "dataPrepareSettings"; "required": false; }; "maxBubbleSize": { "alias": "maxBubbleSize"; "required": false; }; "minBubbleSize": { "alias": "minBubbleSize"; "required": false; }; "negativesAsZeroes": { "alias": "negativesAsZeroes"; "required": false; }; "palette": { "alias": "palette"; "required": false; }; "paletteExtensionMode": { "alias": "paletteExtensionMode"; "required": false; }; "series": { "alias": "series"; "required": false; }; "seriesTemplate": { "alias": "seriesTemplate"; "required": false; }; "topIndent": { "alias": "topIndent"; "required": false; }; "valueAxis": { "alias": "valueAxis"; "required": false; }; }, {}, ["_seriesContentChildren"], never, true, never>;
}
declare class DxoRangeSelectorChartModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoRangeSelectorChartModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoRangeSelectorChartModule, never, [typeof DxoRangeSelectorChartComponent], [typeof DxoRangeSelectorChartComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoRangeSelectorChartModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoRangeSelectorColorComponent extends NestedOption implements OnDestroy, OnInit {
    get base(): string | undefined;
    set base(value: string | undefined);
    get fillId(): string | undefined;
    set fillId(value: string | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoRangeSelectorColorComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoRangeSelectorColorComponent, "dxo-range-selector-color", never, { "base": { "alias": "base"; "required": false; }; "fillId": { "alias": "fillId"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoRangeSelectorColorModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoRangeSelectorColorModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoRangeSelectorColorModule, never, [typeof DxoRangeSelectorColorComponent], [typeof DxoRangeSelectorColorComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoRangeSelectorColorModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoRangeSelectorCommonSeriesSettingsHoverStyleComponent extends NestedOption implements OnDestroy, OnInit {
    get border(): {
        color?: string | undefined;
        dashStyle?: DashStyle | undefined;
        visible?: boolean;
        width?: number;
    };
    set border(value: {
        color?: string | undefined;
        dashStyle?: DashStyle | undefined;
        visible?: boolean;
        width?: number;
    });
    get color(): ChartsColor | string | undefined;
    set color(value: ChartsColor | string | undefined);
    get dashStyle(): DashStyle;
    set dashStyle(value: DashStyle);
    get hatching(): {
        direction?: HatchDirection;
        opacity?: number;
        step?: number;
        width?: number;
    };
    set hatching(value: {
        direction?: HatchDirection;
        opacity?: number;
        step?: number;
        width?: number;
    });
    get highlight(): boolean;
    set highlight(value: boolean);
    get width(): number;
    set width(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoRangeSelectorCommonSeriesSettingsHoverStyleComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoRangeSelectorCommonSeriesSettingsHoverStyleComponent, "dxo-range-selector-common-series-settings-hover-style", never, { "border": { "alias": "border"; "required": false; }; "color": { "alias": "color"; "required": false; }; "dashStyle": { "alias": "dashStyle"; "required": false; }; "hatching": { "alias": "hatching"; "required": false; }; "highlight": { "alias": "highlight"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoRangeSelectorCommonSeriesSettingsHoverStyleModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoRangeSelectorCommonSeriesSettingsHoverStyleModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoRangeSelectorCommonSeriesSettingsHoverStyleModule, never, [typeof DxoRangeSelectorCommonSeriesSettingsHoverStyleComponent], [typeof DxoRangeSelectorCommonSeriesSettingsHoverStyleComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoRangeSelectorCommonSeriesSettingsHoverStyleModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoRangeSelectorCommonSeriesSettingsLabelComponent extends NestedOption implements OnDestroy, OnInit {
    get alignment(): HorizontalAlignment;
    set alignment(value: HorizontalAlignment);
    get argumentFormat(): Format$1 | undefined;
    set argumentFormat(value: Format$1 | undefined);
    get backgroundColor(): string | undefined;
    set backgroundColor(value: string | undefined);
    get border(): {
        color?: string | undefined;
        dashStyle?: DashStyle | undefined;
        visible?: boolean;
        width?: number;
    };
    set border(value: {
        color?: string | undefined;
        dashStyle?: DashStyle | undefined;
        visible?: boolean;
        width?: number;
    });
    get connector(): {
        color?: string | undefined;
        visible?: boolean;
        width?: number;
    };
    set connector(value: {
        color?: string | undefined;
        visible?: boolean;
        width?: number;
    });
    get customizeText(): ((pointInfo: any) => string);
    set customizeText(value: ((pointInfo: any) => string));
    get displayFormat(): string | undefined;
    set displayFormat(value: string | undefined);
    get font(): Font;
    set font(value: Font);
    get format(): Format$1 | undefined;
    set format(value: Format$1 | undefined);
    get horizontalOffset(): number;
    set horizontalOffset(value: number);
    get position(): RelativePosition;
    set position(value: RelativePosition);
    get rotationAngle(): number;
    set rotationAngle(value: number);
    get showForZeroValues(): boolean;
    set showForZeroValues(value: boolean);
    get verticalOffset(): number;
    set verticalOffset(value: number);
    get visible(): boolean;
    set visible(value: boolean);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoRangeSelectorCommonSeriesSettingsLabelComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoRangeSelectorCommonSeriesSettingsLabelComponent, "dxo-range-selector-common-series-settings-label", never, { "alignment": { "alias": "alignment"; "required": false; }; "argumentFormat": { "alias": "argumentFormat"; "required": false; }; "backgroundColor": { "alias": "backgroundColor"; "required": false; }; "border": { "alias": "border"; "required": false; }; "connector": { "alias": "connector"; "required": false; }; "customizeText": { "alias": "customizeText"; "required": false; }; "displayFormat": { "alias": "displayFormat"; "required": false; }; "font": { "alias": "font"; "required": false; }; "format": { "alias": "format"; "required": false; }; "horizontalOffset": { "alias": "horizontalOffset"; "required": false; }; "position": { "alias": "position"; "required": false; }; "rotationAngle": { "alias": "rotationAngle"; "required": false; }; "showForZeroValues": { "alias": "showForZeroValues"; "required": false; }; "verticalOffset": { "alias": "verticalOffset"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoRangeSelectorCommonSeriesSettingsLabelModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoRangeSelectorCommonSeriesSettingsLabelModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoRangeSelectorCommonSeriesSettingsLabelModule, never, [typeof DxoRangeSelectorCommonSeriesSettingsLabelComponent], [typeof DxoRangeSelectorCommonSeriesSettingsLabelComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoRangeSelectorCommonSeriesSettingsLabelModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoRangeSelectorCommonSeriesSettingsSelectionStyleComponent extends NestedOption implements OnDestroy, OnInit {
    get border(): {
        color?: string | undefined;
        dashStyle?: DashStyle | undefined;
        visible?: boolean;
        width?: number;
    };
    set border(value: {
        color?: string | undefined;
        dashStyle?: DashStyle | undefined;
        visible?: boolean;
        width?: number;
    });
    get color(): ChartsColor | string | undefined;
    set color(value: ChartsColor | string | undefined);
    get dashStyle(): DashStyle;
    set dashStyle(value: DashStyle);
    get hatching(): {
        direction?: HatchDirection;
        opacity?: number;
        step?: number;
        width?: number;
    };
    set hatching(value: {
        direction?: HatchDirection;
        opacity?: number;
        step?: number;
        width?: number;
    });
    get highlight(): boolean;
    set highlight(value: boolean);
    get width(): number;
    set width(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoRangeSelectorCommonSeriesSettingsSelectionStyleComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoRangeSelectorCommonSeriesSettingsSelectionStyleComponent, "dxo-range-selector-common-series-settings-selection-style", never, { "border": { "alias": "border"; "required": false; }; "color": { "alias": "color"; "required": false; }; "dashStyle": { "alias": "dashStyle"; "required": false; }; "hatching": { "alias": "hatching"; "required": false; }; "highlight": { "alias": "highlight"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoRangeSelectorCommonSeriesSettingsSelectionStyleModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoRangeSelectorCommonSeriesSettingsSelectionStyleModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoRangeSelectorCommonSeriesSettingsSelectionStyleModule, never, [typeof DxoRangeSelectorCommonSeriesSettingsSelectionStyleComponent], [typeof DxoRangeSelectorCommonSeriesSettingsSelectionStyleComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoRangeSelectorCommonSeriesSettingsSelectionStyleModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoRangeSelectorCommonSeriesSettingsComponent extends NestedOption implements OnDestroy, OnInit {
    get aggregation(): {
        calculate?: ((aggregationInfo: chartPointAggregationInfoObject, series: chartSeriesObject) => Record<string, any> | Array<Record<string, any>>) | undefined;
        enabled?: boolean;
        method?: ChartSeriesAggregationMethod;
    };
    set aggregation(value: {
        calculate?: ((aggregationInfo: chartPointAggregationInfoObject, series: chartSeriesObject) => Record<string, any> | Array<Record<string, any>>) | undefined;
        enabled?: boolean;
        method?: ChartSeriesAggregationMethod;
    });
    get area(): any;
    set area(value: any);
    get argumentField(): string;
    set argumentField(value: string);
    get axis(): string | undefined;
    set axis(value: string | undefined);
    get bar(): any;
    set bar(value: any);
    get barOverlapGroup(): string | undefined;
    set barOverlapGroup(value: string | undefined);
    get barPadding(): number | undefined;
    set barPadding(value: number | undefined);
    get barWidth(): number | undefined;
    set barWidth(value: number | undefined);
    get border(): {
        color?: string | undefined;
        dashStyle?: DashStyle | undefined;
        visible?: boolean;
        width?: number;
    };
    set border(value: {
        color?: string | undefined;
        dashStyle?: DashStyle | undefined;
        visible?: boolean;
        width?: number;
    });
    get bubble(): any;
    set bubble(value: any);
    get candlestick(): any;
    set candlestick(value: any);
    get closeValueField(): string;
    set closeValueField(value: string);
    get color(): ChartsColor | string | undefined;
    set color(value: ChartsColor | string | undefined);
    get cornerRadius(): number;
    set cornerRadius(value: number);
    get dashStyle(): DashStyle;
    set dashStyle(value: DashStyle);
    get fullstackedarea(): any;
    set fullstackedarea(value: any);
    get fullstackedbar(): any;
    set fullstackedbar(value: any);
    get fullstackedline(): any;
    set fullstackedline(value: any);
    get fullstackedspline(): any;
    set fullstackedspline(value: any);
    get fullstackedsplinearea(): any;
    set fullstackedsplinearea(value: any);
    get highValueField(): string;
    set highValueField(value: string);
    get hoverMode(): SeriesHoverMode;
    set hoverMode(value: SeriesHoverMode);
    get hoverStyle(): {
        border?: {
            color?: string | undefined;
            dashStyle?: DashStyle | undefined;
            visible?: boolean;
            width?: number;
        };
        color?: ChartsColor | string | undefined;
        dashStyle?: DashStyle;
        hatching?: {
            direction?: HatchDirection;
            opacity?: number;
            step?: number;
            width?: number;
        };
        highlight?: boolean;
        width?: number;
    };
    set hoverStyle(value: {
        border?: {
            color?: string | undefined;
            dashStyle?: DashStyle | undefined;
            visible?: boolean;
            width?: number;
        };
        color?: ChartsColor | string | undefined;
        dashStyle?: DashStyle;
        hatching?: {
            direction?: HatchDirection;
            opacity?: number;
            step?: number;
            width?: number;
        };
        highlight?: boolean;
        width?: number;
    });
    get ignoreEmptyPoints(): boolean;
    set ignoreEmptyPoints(value: boolean);
    get innerColor(): string;
    set innerColor(value: string);
    get label(): {
        alignment?: HorizontalAlignment;
        argumentFormat?: Format$1 | undefined;
        backgroundColor?: string | undefined;
        border?: {
            color?: string | undefined;
            dashStyle?: DashStyle | undefined;
            visible?: boolean;
            width?: number;
        };
        connector?: {
            color?: string | undefined;
            visible?: boolean;
            width?: number;
        };
        customizeText?: ((pointInfo: any) => string);
        displayFormat?: string | undefined;
        font?: Font;
        format?: Format$1 | undefined;
        horizontalOffset?: number;
        position?: RelativePosition;
        rotationAngle?: number;
        showForZeroValues?: boolean;
        verticalOffset?: number;
        visible?: boolean;
    };
    set label(value: {
        alignment?: HorizontalAlignment;
        argumentFormat?: Format$1 | undefined;
        backgroundColor?: string | undefined;
        border?: {
            color?: string | undefined;
            dashStyle?: DashStyle | undefined;
            visible?: boolean;
            width?: number;
        };
        connector?: {
            color?: string | undefined;
            visible?: boolean;
            width?: number;
        };
        customizeText?: ((pointInfo: any) => string);
        displayFormat?: string | undefined;
        font?: Font;
        format?: Format$1 | undefined;
        horizontalOffset?: number;
        position?: RelativePosition;
        rotationAngle?: number;
        showForZeroValues?: boolean;
        verticalOffset?: number;
        visible?: boolean;
    });
    get line(): any;
    set line(value: any);
    get lowValueField(): string;
    set lowValueField(value: string);
    get maxLabelCount(): number | undefined;
    set maxLabelCount(value: number | undefined);
    get minBarSize(): number | undefined;
    set minBarSize(value: number | undefined);
    get opacity(): number;
    set opacity(value: number);
    get openValueField(): string;
    set openValueField(value: string);
    get pane(): string;
    set pane(value: string);
    get point(): {
        border?: {
            color?: string | undefined;
            visible?: boolean;
            width?: number;
        };
        color?: ChartsColor | string | undefined;
        hoverMode?: PointInteractionMode;
        hoverStyle?: {
            border?: {
                color?: string | undefined;
                visible?: boolean;
                width?: number;
            };
            color?: ChartsColor | string | undefined;
            size?: number | undefined;
        };
        image?: string | undefined | {
            height?: number | {
                rangeMaxPoint?: number | undefined;
                rangeMinPoint?: number | undefined;
            };
            url?: string | undefined | {
                rangeMaxPoint?: string | undefined;
                rangeMinPoint?: string | undefined;
            };
            width?: number | {
                rangeMaxPoint?: number | undefined;
                rangeMinPoint?: number | undefined;
            };
        };
        selectionMode?: PointInteractionMode;
        selectionStyle?: {
            border?: {
                color?: string | undefined;
                visible?: boolean;
                width?: number;
            };
            color?: ChartsColor | string | undefined;
            size?: number | undefined;
        };
        size?: number;
        symbol?: PointSymbol;
        visible?: boolean;
    };
    set point(value: {
        border?: {
            color?: string | undefined;
            visible?: boolean;
            width?: number;
        };
        color?: ChartsColor | string | undefined;
        hoverMode?: PointInteractionMode;
        hoverStyle?: {
            border?: {
                color?: string | undefined;
                visible?: boolean;
                width?: number;
            };
            color?: ChartsColor | string | undefined;
            size?: number | undefined;
        };
        image?: string | undefined | {
            height?: number | {
                rangeMaxPoint?: number | undefined;
                rangeMinPoint?: number | undefined;
            };
            url?: string | undefined | {
                rangeMaxPoint?: string | undefined;
                rangeMinPoint?: string | undefined;
            };
            width?: number | {
                rangeMaxPoint?: number | undefined;
                rangeMinPoint?: number | undefined;
            };
        };
        selectionMode?: PointInteractionMode;
        selectionStyle?: {
            border?: {
                color?: string | undefined;
                visible?: boolean;
                width?: number;
            };
            color?: ChartsColor | string | undefined;
            size?: number | undefined;
        };
        size?: number;
        symbol?: PointSymbol;
        visible?: boolean;
    });
    get rangearea(): any;
    set rangearea(value: any);
    get rangebar(): any;
    set rangebar(value: any);
    get rangeValue1Field(): string;
    set rangeValue1Field(value: string);
    get rangeValue2Field(): string;
    set rangeValue2Field(value: string);
    get reduction(): {
        color?: string;
        level?: FinancialChartReductionLevel;
    };
    set reduction(value: {
        color?: string;
        level?: FinancialChartReductionLevel;
    });
    get scatter(): any;
    set scatter(value: any);
    get selectionMode(): SeriesSelectionMode;
    set selectionMode(value: SeriesSelectionMode);
    get selectionStyle(): {
        border?: {
            color?: string | undefined;
            dashStyle?: DashStyle | undefined;
            visible?: boolean;
            width?: number;
        };
        color?: ChartsColor | string | undefined;
        dashStyle?: DashStyle;
        hatching?: {
            direction?: HatchDirection;
            opacity?: number;
            step?: number;
            width?: number;
        };
        highlight?: boolean;
        width?: number;
    };
    set selectionStyle(value: {
        border?: {
            color?: string | undefined;
            dashStyle?: DashStyle | undefined;
            visible?: boolean;
            width?: number;
        };
        color?: ChartsColor | string | undefined;
        dashStyle?: DashStyle;
        hatching?: {
            direction?: HatchDirection;
            opacity?: number;
            step?: number;
            width?: number;
        };
        highlight?: boolean;
        width?: number;
    });
    get showInLegend(): boolean;
    set showInLegend(value: boolean);
    get sizeField(): string;
    set sizeField(value: string);
    get spline(): any;
    set spline(value: any);
    get splinearea(): any;
    set splinearea(value: any);
    get stack(): string;
    set stack(value: string);
    get stackedarea(): any;
    set stackedarea(value: any);
    get stackedbar(): any;
    set stackedbar(value: any);
    get stackedline(): any;
    set stackedline(value: any);
    get stackedspline(): any;
    set stackedspline(value: any);
    get stackedsplinearea(): any;
    set stackedsplinearea(value: any);
    get steparea(): any;
    set steparea(value: any);
    get stepline(): any;
    set stepline(value: any);
    get stock(): any;
    set stock(value: any);
    get tagField(): string;
    set tagField(value: string);
    get type(): SeriesType;
    set type(value: SeriesType);
    get valueErrorBar(): {
        color?: string;
        displayMode?: ValueErrorBarDisplayMode;
        edgeLength?: number;
        highValueField?: string | undefined;
        lineWidth?: number;
        lowValueField?: string | undefined;
        opacity?: number | undefined;
        type?: undefined | ValueErrorBarType;
        value?: number;
    };
    set valueErrorBar(value: {
        color?: string;
        displayMode?: ValueErrorBarDisplayMode;
        edgeLength?: number;
        highValueField?: string | undefined;
        lineWidth?: number;
        lowValueField?: string | undefined;
        opacity?: number | undefined;
        type?: undefined | ValueErrorBarType;
        value?: number;
    });
    get valueField(): string;
    set valueField(value: string);
    get visible(): boolean;
    set visible(value: boolean);
    get width(): number;
    set width(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoRangeSelectorCommonSeriesSettingsComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoRangeSelectorCommonSeriesSettingsComponent, "dxo-range-selector-common-series-settings", never, { "aggregation": { "alias": "aggregation"; "required": false; }; "area": { "alias": "area"; "required": false; }; "argumentField": { "alias": "argumentField"; "required": false; }; "axis": { "alias": "axis"; "required": false; }; "bar": { "alias": "bar"; "required": false; }; "barOverlapGroup": { "alias": "barOverlapGroup"; "required": false; }; "barPadding": { "alias": "barPadding"; "required": false; }; "barWidth": { "alias": "barWidth"; "required": false; }; "border": { "alias": "border"; "required": false; }; "bubble": { "alias": "bubble"; "required": false; }; "candlestick": { "alias": "candlestick"; "required": false; }; "closeValueField": { "alias": "closeValueField"; "required": false; }; "color": { "alias": "color"; "required": false; }; "cornerRadius": { "alias": "cornerRadius"; "required": false; }; "dashStyle": { "alias": "dashStyle"; "required": false; }; "fullstackedarea": { "alias": "fullstackedarea"; "required": false; }; "fullstackedbar": { "alias": "fullstackedbar"; "required": false; }; "fullstackedline": { "alias": "fullstackedline"; "required": false; }; "fullstackedspline": { "alias": "fullstackedspline"; "required": false; }; "fullstackedsplinearea": { "alias": "fullstackedsplinearea"; "required": false; }; "highValueField": { "alias": "highValueField"; "required": false; }; "hoverMode": { "alias": "hoverMode"; "required": false; }; "hoverStyle": { "alias": "hoverStyle"; "required": false; }; "ignoreEmptyPoints": { "alias": "ignoreEmptyPoints"; "required": false; }; "innerColor": { "alias": "innerColor"; "required": false; }; "label": { "alias": "label"; "required": false; }; "line": { "alias": "line"; "required": false; }; "lowValueField": { "alias": "lowValueField"; "required": false; }; "maxLabelCount": { "alias": "maxLabelCount"; "required": false; }; "minBarSize": { "alias": "minBarSize"; "required": false; }; "opacity": { "alias": "opacity"; "required": false; }; "openValueField": { "alias": "openValueField"; "required": false; }; "pane": { "alias": "pane"; "required": false; }; "point": { "alias": "point"; "required": false; }; "rangearea": { "alias": "rangearea"; "required": false; }; "rangebar": { "alias": "rangebar"; "required": false; }; "rangeValue1Field": { "alias": "rangeValue1Field"; "required": false; }; "rangeValue2Field": { "alias": "rangeValue2Field"; "required": false; }; "reduction": { "alias": "reduction"; "required": false; }; "scatter": { "alias": "scatter"; "required": false; }; "selectionMode": { "alias": "selectionMode"; "required": false; }; "selectionStyle": { "alias": "selectionStyle"; "required": false; }; "showInLegend": { "alias": "showInLegend"; "required": false; }; "sizeField": { "alias": "sizeField"; "required": false; }; "spline": { "alias": "spline"; "required": false; }; "splinearea": { "alias": "splinearea"; "required": false; }; "stack": { "alias": "stack"; "required": false; }; "stackedarea": { "alias": "stackedarea"; "required": false; }; "stackedbar": { "alias": "stackedbar"; "required": false; }; "stackedline": { "alias": "stackedline"; "required": false; }; "stackedspline": { "alias": "stackedspline"; "required": false; }; "stackedsplinearea": { "alias": "stackedsplinearea"; "required": false; }; "steparea": { "alias": "steparea"; "required": false; }; "stepline": { "alias": "stepline"; "required": false; }; "stock": { "alias": "stock"; "required": false; }; "tagField": { "alias": "tagField"; "required": false; }; "type": { "alias": "type"; "required": false; }; "valueErrorBar": { "alias": "valueErrorBar"; "required": false; }; "valueField": { "alias": "valueField"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoRangeSelectorCommonSeriesSettingsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoRangeSelectorCommonSeriesSettingsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoRangeSelectorCommonSeriesSettingsModule, never, [typeof DxoRangeSelectorCommonSeriesSettingsComponent], [typeof DxoRangeSelectorCommonSeriesSettingsComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoRangeSelectorCommonSeriesSettingsModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoRangeSelectorConnectorComponent extends NestedOption implements OnDestroy, OnInit {
    get color(): string | undefined;
    set color(value: string | undefined);
    get visible(): boolean;
    set visible(value: boolean);
    get width(): number;
    set width(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoRangeSelectorConnectorComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoRangeSelectorConnectorComponent, "dxo-range-selector-connector", never, { "color": { "alias": "color"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoRangeSelectorConnectorModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoRangeSelectorConnectorModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoRangeSelectorConnectorModule, never, [typeof DxoRangeSelectorConnectorComponent], [typeof DxoRangeSelectorConnectorComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoRangeSelectorConnectorModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoRangeSelectorDataPrepareSettingsComponent extends NestedOption implements OnDestroy, OnInit {
    get checkTypeForAllData(): boolean;
    set checkTypeForAllData(value: boolean);
    get convertToAxisDataType(): boolean;
    set convertToAxisDataType(value: boolean);
    get sortingMethod(): boolean | ((a: {
        arg: Date | number | string;
        val: Date | number | string;
    }, b: {
        arg: Date | number | string;
        val: Date | number | string;
    }) => number);
    set sortingMethod(value: boolean | ((a: {
        arg: Date | number | string;
        val: Date | number | string;
    }, b: {
        arg: Date | number | string;
        val: Date | number | string;
    }) => number));
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoRangeSelectorDataPrepareSettingsComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoRangeSelectorDataPrepareSettingsComponent, "dxo-range-selector-data-prepare-settings", never, { "checkTypeForAllData": { "alias": "checkTypeForAllData"; "required": false; }; "convertToAxisDataType": { "alias": "convertToAxisDataType"; "required": false; }; "sortingMethod": { "alias": "sortingMethod"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoRangeSelectorDataPrepareSettingsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoRangeSelectorDataPrepareSettingsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoRangeSelectorDataPrepareSettingsModule, never, [typeof DxoRangeSelectorDataPrepareSettingsComponent], [typeof DxoRangeSelectorDataPrepareSettingsComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoRangeSelectorDataPrepareSettingsModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoRangeSelectorExportComponent extends NestedOption implements OnDestroy, OnInit {
    get backgroundColor(): string;
    set backgroundColor(value: string);
    get enabled(): boolean;
    set enabled(value: boolean);
    get fileName(): string;
    set fileName(value: string);
    get formats(): Array<ExportFormat>;
    set formats(value: Array<ExportFormat>);
    get margin(): number;
    set margin(value: number);
    get printingEnabled(): boolean;
    set printingEnabled(value: boolean);
    get svgToCanvas(): ((svg: any, canvas: any) => any) | undefined;
    set svgToCanvas(value: ((svg: any, canvas: any) => any) | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoRangeSelectorExportComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoRangeSelectorExportComponent, "dxo-range-selector-export", never, { "backgroundColor": { "alias": "backgroundColor"; "required": false; }; "enabled": { "alias": "enabled"; "required": false; }; "fileName": { "alias": "fileName"; "required": false; }; "formats": { "alias": "formats"; "required": false; }; "margin": { "alias": "margin"; "required": false; }; "printingEnabled": { "alias": "printingEnabled"; "required": false; }; "svgToCanvas": { "alias": "svgToCanvas"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoRangeSelectorExportModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoRangeSelectorExportModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoRangeSelectorExportModule, never, [typeof DxoRangeSelectorExportComponent], [typeof DxoRangeSelectorExportComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoRangeSelectorExportModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoRangeSelectorFontComponent extends NestedOption implements OnDestroy, OnInit {
    get color(): string;
    set color(value: string);
    get family(): string;
    set family(value: string);
    get opacity(): number;
    set opacity(value: number);
    get size(): number | string;
    set size(value: number | string);
    get weight(): number;
    set weight(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoRangeSelectorFontComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoRangeSelectorFontComponent, "dxo-range-selector-font", never, { "color": { "alias": "color"; "required": false; }; "family": { "alias": "family"; "required": false; }; "opacity": { "alias": "opacity"; "required": false; }; "size": { "alias": "size"; "required": false; }; "weight": { "alias": "weight"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoRangeSelectorFontModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoRangeSelectorFontModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoRangeSelectorFontModule, never, [typeof DxoRangeSelectorFontComponent], [typeof DxoRangeSelectorFontComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoRangeSelectorFontModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoRangeSelectorFormatComponent extends NestedOption implements OnDestroy, OnInit {
    get currency(): string;
    set currency(value: string);
    get formatter(): ((value: number | Date) => string);
    set formatter(value: ((value: number | Date) => string));
    get parser(): ((value: string) => number | Date);
    set parser(value: ((value: string) => number | Date));
    get precision(): number;
    set precision(value: number);
    get type(): Format | string;
    set type(value: Format | string);
    get useCurrencyAccountingStyle(): boolean;
    set useCurrencyAccountingStyle(value: boolean);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoRangeSelectorFormatComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoRangeSelectorFormatComponent, "dxo-range-selector-format", never, { "currency": { "alias": "currency"; "required": false; }; "formatter": { "alias": "formatter"; "required": false; }; "parser": { "alias": "parser"; "required": false; }; "precision": { "alias": "precision"; "required": false; }; "type": { "alias": "type"; "required": false; }; "useCurrencyAccountingStyle": { "alias": "useCurrencyAccountingStyle"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoRangeSelectorFormatModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoRangeSelectorFormatModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoRangeSelectorFormatModule, never, [typeof DxoRangeSelectorFormatComponent], [typeof DxoRangeSelectorFormatComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoRangeSelectorFormatModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoRangeSelectorHatchingComponent extends NestedOption implements OnDestroy, OnInit {
    get direction(): HatchDirection;
    set direction(value: HatchDirection);
    get opacity(): number;
    set opacity(value: number);
    get step(): number;
    set step(value: number);
    get width(): number;
    set width(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoRangeSelectorHatchingComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoRangeSelectorHatchingComponent, "dxo-range-selector-hatching", never, { "direction": { "alias": "direction"; "required": false; }; "opacity": { "alias": "opacity"; "required": false; }; "step": { "alias": "step"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoRangeSelectorHatchingModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoRangeSelectorHatchingModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoRangeSelectorHatchingModule, never, [typeof DxoRangeSelectorHatchingComponent], [typeof DxoRangeSelectorHatchingComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoRangeSelectorHatchingModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoRangeSelectorHeightComponent extends NestedOption implements OnDestroy, OnInit {
    get rangeMaxPoint(): number | undefined;
    set rangeMaxPoint(value: number | undefined);
    get rangeMinPoint(): number | undefined;
    set rangeMinPoint(value: number | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoRangeSelectorHeightComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoRangeSelectorHeightComponent, "dxo-range-selector-height", never, { "rangeMaxPoint": { "alias": "rangeMaxPoint"; "required": false; }; "rangeMinPoint": { "alias": "rangeMinPoint"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoRangeSelectorHeightModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoRangeSelectorHeightModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoRangeSelectorHeightModule, never, [typeof DxoRangeSelectorHeightComponent], [typeof DxoRangeSelectorHeightComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoRangeSelectorHeightModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoRangeSelectorHoverStyleComponent extends NestedOption implements OnDestroy, OnInit {
    get border(): {
        color?: string | undefined;
        dashStyle?: DashStyle | undefined;
        visible?: boolean;
        width?: number;
    };
    set border(value: {
        color?: string | undefined;
        dashStyle?: DashStyle | undefined;
        visible?: boolean;
        width?: number;
    });
    get color(): ChartsColor | string | undefined;
    set color(value: ChartsColor | string | undefined);
    get dashStyle(): DashStyle;
    set dashStyle(value: DashStyle);
    get hatching(): {
        direction?: HatchDirection;
        opacity?: number;
        step?: number;
        width?: number;
    };
    set hatching(value: {
        direction?: HatchDirection;
        opacity?: number;
        step?: number;
        width?: number;
    });
    get highlight(): boolean;
    set highlight(value: boolean);
    get width(): number;
    set width(value: number);
    get size(): number | undefined;
    set size(value: number | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoRangeSelectorHoverStyleComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoRangeSelectorHoverStyleComponent, "dxo-range-selector-hover-style", never, { "border": { "alias": "border"; "required": false; }; "color": { "alias": "color"; "required": false; }; "dashStyle": { "alias": "dashStyle"; "required": false; }; "hatching": { "alias": "hatching"; "required": false; }; "highlight": { "alias": "highlight"; "required": false; }; "width": { "alias": "width"; "required": false; }; "size": { "alias": "size"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoRangeSelectorHoverStyleModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoRangeSelectorHoverStyleModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoRangeSelectorHoverStyleModule, never, [typeof DxoRangeSelectorHoverStyleComponent], [typeof DxoRangeSelectorHoverStyleComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoRangeSelectorHoverStyleModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoRangeSelectorImageComponent extends NestedOption implements OnDestroy, OnInit {
    get location(): BackgroundImageLocation;
    set location(value: BackgroundImageLocation);
    get url(): string | undefined | {
        rangeMaxPoint?: string | undefined;
        rangeMinPoint?: string | undefined;
    };
    set url(value: string | undefined | {
        rangeMaxPoint?: string | undefined;
        rangeMinPoint?: string | undefined;
    });
    get height(): number | {
        rangeMaxPoint?: number | undefined;
        rangeMinPoint?: number | undefined;
    };
    set height(value: number | {
        rangeMaxPoint?: number | undefined;
        rangeMinPoint?: number | undefined;
    });
    get width(): number | {
        rangeMaxPoint?: number | undefined;
        rangeMinPoint?: number | undefined;
    };
    set width(value: number | {
        rangeMaxPoint?: number | undefined;
        rangeMinPoint?: number | undefined;
    });
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoRangeSelectorImageComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoRangeSelectorImageComponent, "dxo-range-selector-image", never, { "location": { "alias": "location"; "required": false; }; "url": { "alias": "url"; "required": false; }; "height": { "alias": "height"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoRangeSelectorImageModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoRangeSelectorImageModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoRangeSelectorImageModule, never, [typeof DxoRangeSelectorImageComponent], [typeof DxoRangeSelectorImageComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoRangeSelectorImageModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoRangeSelectorIndentComponent extends NestedOption implements OnDestroy, OnInit {
    get left(): number | undefined;
    set left(value: number | undefined);
    get right(): number | undefined;
    set right(value: number | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoRangeSelectorIndentComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoRangeSelectorIndentComponent, "dxo-range-selector-indent", never, { "left": { "alias": "left"; "required": false; }; "right": { "alias": "right"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoRangeSelectorIndentModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoRangeSelectorIndentModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoRangeSelectorIndentModule, never, [typeof DxoRangeSelectorIndentComponent], [typeof DxoRangeSelectorIndentComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoRangeSelectorIndentModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoRangeSelectorLabelComponent extends NestedOption implements OnDestroy, OnInit {
    get alignment(): HorizontalAlignment;
    set alignment(value: HorizontalAlignment);
    get argumentFormat(): Format$1 | undefined;
    set argumentFormat(value: Format$1 | undefined);
    get backgroundColor(): string | undefined;
    set backgroundColor(value: string | undefined);
    get border(): {
        color?: string | undefined;
        dashStyle?: DashStyle | undefined;
        visible?: boolean;
        width?: number;
    };
    set border(value: {
        color?: string | undefined;
        dashStyle?: DashStyle | undefined;
        visible?: boolean;
        width?: number;
    });
    get connector(): {
        color?: string | undefined;
        visible?: boolean;
        width?: number;
    };
    set connector(value: {
        color?: string | undefined;
        visible?: boolean;
        width?: number;
    });
    get customizeText(): ((pointInfo: any) => string);
    set customizeText(value: ((pointInfo: any) => string));
    get displayFormat(): string | undefined;
    set displayFormat(value: string | undefined);
    get font(): Font;
    set font(value: Font);
    get format(): Format$1 | undefined;
    set format(value: Format$1 | undefined);
    get horizontalOffset(): number;
    set horizontalOffset(value: number);
    get position(): RelativePosition;
    set position(value: RelativePosition);
    get rotationAngle(): number;
    set rotationAngle(value: number);
    get showForZeroValues(): boolean;
    set showForZeroValues(value: boolean);
    get verticalOffset(): number;
    set verticalOffset(value: number);
    get visible(): boolean;
    set visible(value: boolean);
    get overlappingBehavior(): LabelOverlap;
    set overlappingBehavior(value: LabelOverlap);
    get topIndent(): number;
    set topIndent(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoRangeSelectorLabelComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoRangeSelectorLabelComponent, "dxo-range-selector-label", never, { "alignment": { "alias": "alignment"; "required": false; }; "argumentFormat": { "alias": "argumentFormat"; "required": false; }; "backgroundColor": { "alias": "backgroundColor"; "required": false; }; "border": { "alias": "border"; "required": false; }; "connector": { "alias": "connector"; "required": false; }; "customizeText": { "alias": "customizeText"; "required": false; }; "displayFormat": { "alias": "displayFormat"; "required": false; }; "font": { "alias": "font"; "required": false; }; "format": { "alias": "format"; "required": false; }; "horizontalOffset": { "alias": "horizontalOffset"; "required": false; }; "position": { "alias": "position"; "required": false; }; "rotationAngle": { "alias": "rotationAngle"; "required": false; }; "showForZeroValues": { "alias": "showForZeroValues"; "required": false; }; "verticalOffset": { "alias": "verticalOffset"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "overlappingBehavior": { "alias": "overlappingBehavior"; "required": false; }; "topIndent": { "alias": "topIndent"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoRangeSelectorLabelModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoRangeSelectorLabelModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoRangeSelectorLabelModule, never, [typeof DxoRangeSelectorLabelComponent], [typeof DxoRangeSelectorLabelComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoRangeSelectorLabelModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoRangeSelectorLengthComponent extends NestedOption implements OnDestroy, OnInit {
    get days(): number;
    set days(value: number);
    get hours(): number;
    set hours(value: number);
    get milliseconds(): number;
    set milliseconds(value: number);
    get minutes(): number;
    set minutes(value: number);
    get months(): number;
    set months(value: number);
    get quarters(): number;
    set quarters(value: number);
    get seconds(): number;
    set seconds(value: number);
    get weeks(): number;
    set weeks(value: number);
    get years(): number;
    set years(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoRangeSelectorLengthComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoRangeSelectorLengthComponent, "dxo-range-selector-length", never, { "days": { "alias": "days"; "required": false; }; "hours": { "alias": "hours"; "required": false; }; "milliseconds": { "alias": "milliseconds"; "required": false; }; "minutes": { "alias": "minutes"; "required": false; }; "months": { "alias": "months"; "required": false; }; "quarters": { "alias": "quarters"; "required": false; }; "seconds": { "alias": "seconds"; "required": false; }; "weeks": { "alias": "weeks"; "required": false; }; "years": { "alias": "years"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoRangeSelectorLengthModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoRangeSelectorLengthModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoRangeSelectorLengthModule, never, [typeof DxoRangeSelectorLengthComponent], [typeof DxoRangeSelectorLengthComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoRangeSelectorLengthModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoRangeSelectorLoadingIndicatorComponent extends NestedOption implements OnDestroy, OnInit {
    get backgroundColor(): string;
    set backgroundColor(value: string);
    get enabled(): boolean;
    set enabled(value: boolean);
    get font(): Font;
    set font(value: Font);
    get show(): boolean;
    set show(value: boolean);
    get text(): string;
    set text(value: string);
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    showChange: EventEmitter<boolean>;
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoRangeSelectorLoadingIndicatorComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoRangeSelectorLoadingIndicatorComponent, "dxo-range-selector-loading-indicator", never, { "backgroundColor": { "alias": "backgroundColor"; "required": false; }; "enabled": { "alias": "enabled"; "required": false; }; "font": { "alias": "font"; "required": false; }; "show": { "alias": "show"; "required": false; }; "text": { "alias": "text"; "required": false; }; }, { "showChange": "showChange"; }, never, never, true, never>;
}
declare class DxoRangeSelectorLoadingIndicatorModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoRangeSelectorLoadingIndicatorModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoRangeSelectorLoadingIndicatorModule, never, [typeof DxoRangeSelectorLoadingIndicatorComponent], [typeof DxoRangeSelectorLoadingIndicatorComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoRangeSelectorLoadingIndicatorModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoRangeSelectorMarginComponent extends NestedOption implements OnDestroy, OnInit {
    get bottom(): number;
    set bottom(value: number);
    get left(): number;
    set left(value: number);
    get right(): number;
    set right(value: number);
    get top(): number;
    set top(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoRangeSelectorMarginComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoRangeSelectorMarginComponent, "dxo-range-selector-margin", never, { "bottom": { "alias": "bottom"; "required": false; }; "left": { "alias": "left"; "required": false; }; "right": { "alias": "right"; "required": false; }; "top": { "alias": "top"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoRangeSelectorMarginModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoRangeSelectorMarginModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoRangeSelectorMarginModule, never, [typeof DxoRangeSelectorMarginComponent], [typeof DxoRangeSelectorMarginComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoRangeSelectorMarginModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoRangeSelectorMarkerLabelComponent extends NestedOption implements OnDestroy, OnInit {
    get customizeText(): ((markerValue: {
        value: Date | number;
        valueText: string;
    }) => string);
    set customizeText(value: ((markerValue: {
        value: Date | number;
        valueText: string;
    }) => string));
    get format(): Format$1 | undefined;
    set format(value: Format$1 | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoRangeSelectorMarkerLabelComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoRangeSelectorMarkerLabelComponent, "dxo-range-selector-marker-label", never, { "customizeText": { "alias": "customizeText"; "required": false; }; "format": { "alias": "format"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoRangeSelectorMarkerLabelModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoRangeSelectorMarkerLabelModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoRangeSelectorMarkerLabelModule, never, [typeof DxoRangeSelectorMarkerLabelComponent], [typeof DxoRangeSelectorMarkerLabelComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoRangeSelectorMarkerLabelModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoRangeSelectorMarkerComponent extends NestedOption implements OnDestroy, OnInit {
    get label(): {
        customizeText?: ((markerValue: {
            value: Date | number;
            valueText: string;
        }) => string);
        format?: Format$1 | undefined;
    };
    set label(value: {
        customizeText?: ((markerValue: {
            value: Date | number;
            valueText: string;
        }) => string);
        format?: Format$1 | undefined;
    });
    get separatorHeight(): number;
    set separatorHeight(value: number);
    get textLeftIndent(): number;
    set textLeftIndent(value: number);
    get textTopIndent(): number;
    set textTopIndent(value: number);
    get topIndent(): number;
    set topIndent(value: number);
    get visible(): boolean;
    set visible(value: boolean);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoRangeSelectorMarkerComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoRangeSelectorMarkerComponent, "dxo-range-selector-marker", never, { "label": { "alias": "label"; "required": false; }; "separatorHeight": { "alias": "separatorHeight"; "required": false; }; "textLeftIndent": { "alias": "textLeftIndent"; "required": false; }; "textTopIndent": { "alias": "textTopIndent"; "required": false; }; "topIndent": { "alias": "topIndent"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoRangeSelectorMarkerModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoRangeSelectorMarkerModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoRangeSelectorMarkerModule, never, [typeof DxoRangeSelectorMarkerComponent], [typeof DxoRangeSelectorMarkerComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoRangeSelectorMarkerModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoRangeSelectorMaxRangeComponent extends NestedOption implements OnDestroy, OnInit {
    get days(): number;
    set days(value: number);
    get hours(): number;
    set hours(value: number);
    get milliseconds(): number;
    set milliseconds(value: number);
    get minutes(): number;
    set minutes(value: number);
    get months(): number;
    set months(value: number);
    get quarters(): number;
    set quarters(value: number);
    get seconds(): number;
    set seconds(value: number);
    get weeks(): number;
    set weeks(value: number);
    get years(): number;
    set years(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoRangeSelectorMaxRangeComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoRangeSelectorMaxRangeComponent, "dxo-range-selector-max-range", never, { "days": { "alias": "days"; "required": false; }; "hours": { "alias": "hours"; "required": false; }; "milliseconds": { "alias": "milliseconds"; "required": false; }; "minutes": { "alias": "minutes"; "required": false; }; "months": { "alias": "months"; "required": false; }; "quarters": { "alias": "quarters"; "required": false; }; "seconds": { "alias": "seconds"; "required": false; }; "weeks": { "alias": "weeks"; "required": false; }; "years": { "alias": "years"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoRangeSelectorMaxRangeModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoRangeSelectorMaxRangeModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoRangeSelectorMaxRangeModule, never, [typeof DxoRangeSelectorMaxRangeComponent], [typeof DxoRangeSelectorMaxRangeComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoRangeSelectorMaxRangeModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoRangeSelectorMinRangeComponent extends NestedOption implements OnDestroy, OnInit {
    get days(): number;
    set days(value: number);
    get hours(): number;
    set hours(value: number);
    get milliseconds(): number;
    set milliseconds(value: number);
    get minutes(): number;
    set minutes(value: number);
    get months(): number;
    set months(value: number);
    get quarters(): number;
    set quarters(value: number);
    get seconds(): number;
    set seconds(value: number);
    get weeks(): number;
    set weeks(value: number);
    get years(): number;
    set years(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoRangeSelectorMinRangeComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoRangeSelectorMinRangeComponent, "dxo-range-selector-min-range", never, { "days": { "alias": "days"; "required": false; }; "hours": { "alias": "hours"; "required": false; }; "milliseconds": { "alias": "milliseconds"; "required": false; }; "minutes": { "alias": "minutes"; "required": false; }; "months": { "alias": "months"; "required": false; }; "quarters": { "alias": "quarters"; "required": false; }; "seconds": { "alias": "seconds"; "required": false; }; "weeks": { "alias": "weeks"; "required": false; }; "years": { "alias": "years"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoRangeSelectorMinRangeModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoRangeSelectorMinRangeModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoRangeSelectorMinRangeModule, never, [typeof DxoRangeSelectorMinRangeComponent], [typeof DxoRangeSelectorMinRangeComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoRangeSelectorMinRangeModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoRangeSelectorMinorTickIntervalComponent extends NestedOption implements OnDestroy, OnInit {
    get days(): number;
    set days(value: number);
    get hours(): number;
    set hours(value: number);
    get milliseconds(): number;
    set milliseconds(value: number);
    get minutes(): number;
    set minutes(value: number);
    get months(): number;
    set months(value: number);
    get quarters(): number;
    set quarters(value: number);
    get seconds(): number;
    set seconds(value: number);
    get weeks(): number;
    set weeks(value: number);
    get years(): number;
    set years(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoRangeSelectorMinorTickIntervalComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoRangeSelectorMinorTickIntervalComponent, "dxo-range-selector-minor-tick-interval", never, { "days": { "alias": "days"; "required": false; }; "hours": { "alias": "hours"; "required": false; }; "milliseconds": { "alias": "milliseconds"; "required": false; }; "minutes": { "alias": "minutes"; "required": false; }; "months": { "alias": "months"; "required": false; }; "quarters": { "alias": "quarters"; "required": false; }; "seconds": { "alias": "seconds"; "required": false; }; "weeks": { "alias": "weeks"; "required": false; }; "years": { "alias": "years"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoRangeSelectorMinorTickIntervalModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoRangeSelectorMinorTickIntervalModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoRangeSelectorMinorTickIntervalModule, never, [typeof DxoRangeSelectorMinorTickIntervalComponent], [typeof DxoRangeSelectorMinorTickIntervalComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoRangeSelectorMinorTickIntervalModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoRangeSelectorMinorTickComponent extends NestedOption implements OnDestroy, OnInit {
    get color(): string;
    set color(value: string);
    get opacity(): number;
    set opacity(value: number);
    get visible(): boolean;
    set visible(value: boolean);
    get width(): number;
    set width(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoRangeSelectorMinorTickComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoRangeSelectorMinorTickComponent, "dxo-range-selector-minor-tick", never, { "color": { "alias": "color"; "required": false; }; "opacity": { "alias": "opacity"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoRangeSelectorMinorTickModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoRangeSelectorMinorTickModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoRangeSelectorMinorTickModule, never, [typeof DxoRangeSelectorMinorTickComponent], [typeof DxoRangeSelectorMinorTickComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoRangeSelectorMinorTickModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoRangeSelectorPointBorderComponent extends NestedOption implements OnDestroy, OnInit {
    get color(): string | undefined;
    set color(value: string | undefined);
    get visible(): boolean;
    set visible(value: boolean);
    get width(): number;
    set width(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoRangeSelectorPointBorderComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoRangeSelectorPointBorderComponent, "dxo-range-selector-point-border", never, { "color": { "alias": "color"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoRangeSelectorPointBorderModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoRangeSelectorPointBorderModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoRangeSelectorPointBorderModule, never, [typeof DxoRangeSelectorPointBorderComponent], [typeof DxoRangeSelectorPointBorderComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoRangeSelectorPointBorderModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoRangeSelectorPointHoverStyleComponent extends NestedOption implements OnDestroy, OnInit {
    get border(): {
        color?: string | undefined;
        visible?: boolean;
        width?: number;
    };
    set border(value: {
        color?: string | undefined;
        visible?: boolean;
        width?: number;
    });
    get color(): ChartsColor | string | undefined;
    set color(value: ChartsColor | string | undefined);
    get size(): number | undefined;
    set size(value: number | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoRangeSelectorPointHoverStyleComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoRangeSelectorPointHoverStyleComponent, "dxo-range-selector-point-hover-style", never, { "border": { "alias": "border"; "required": false; }; "color": { "alias": "color"; "required": false; }; "size": { "alias": "size"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoRangeSelectorPointHoverStyleModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoRangeSelectorPointHoverStyleModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoRangeSelectorPointHoverStyleModule, never, [typeof DxoRangeSelectorPointHoverStyleComponent], [typeof DxoRangeSelectorPointHoverStyleComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoRangeSelectorPointHoverStyleModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoRangeSelectorPointImageComponent extends NestedOption implements OnDestroy, OnInit {
    get height(): number | {
        rangeMaxPoint?: number | undefined;
        rangeMinPoint?: number | undefined;
    };
    set height(value: number | {
        rangeMaxPoint?: number | undefined;
        rangeMinPoint?: number | undefined;
    });
    get url(): string | undefined | {
        rangeMaxPoint?: string | undefined;
        rangeMinPoint?: string | undefined;
    };
    set url(value: string | undefined | {
        rangeMaxPoint?: string | undefined;
        rangeMinPoint?: string | undefined;
    });
    get width(): number | {
        rangeMaxPoint?: number | undefined;
        rangeMinPoint?: number | undefined;
    };
    set width(value: number | {
        rangeMaxPoint?: number | undefined;
        rangeMinPoint?: number | undefined;
    });
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoRangeSelectorPointImageComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoRangeSelectorPointImageComponent, "dxo-range-selector-point-image", never, { "height": { "alias": "height"; "required": false; }; "url": { "alias": "url"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoRangeSelectorPointImageModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoRangeSelectorPointImageModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoRangeSelectorPointImageModule, never, [typeof DxoRangeSelectorPointImageComponent], [typeof DxoRangeSelectorPointImageComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoRangeSelectorPointImageModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoRangeSelectorPointSelectionStyleComponent extends NestedOption implements OnDestroy, OnInit {
    get border(): {
        color?: string | undefined;
        visible?: boolean;
        width?: number;
    };
    set border(value: {
        color?: string | undefined;
        visible?: boolean;
        width?: number;
    });
    get color(): ChartsColor | string | undefined;
    set color(value: ChartsColor | string | undefined);
    get size(): number | undefined;
    set size(value: number | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoRangeSelectorPointSelectionStyleComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoRangeSelectorPointSelectionStyleComponent, "dxo-range-selector-point-selection-style", never, { "border": { "alias": "border"; "required": false; }; "color": { "alias": "color"; "required": false; }; "size": { "alias": "size"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoRangeSelectorPointSelectionStyleModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoRangeSelectorPointSelectionStyleModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoRangeSelectorPointSelectionStyleModule, never, [typeof DxoRangeSelectorPointSelectionStyleComponent], [typeof DxoRangeSelectorPointSelectionStyleComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoRangeSelectorPointSelectionStyleModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoRangeSelectorPointComponent extends NestedOption implements OnDestroy, OnInit {
    get border(): {
        color?: string | undefined;
        visible?: boolean;
        width?: number;
    };
    set border(value: {
        color?: string | undefined;
        visible?: boolean;
        width?: number;
    });
    get color(): ChartsColor | string | undefined;
    set color(value: ChartsColor | string | undefined);
    get hoverMode(): PointInteractionMode;
    set hoverMode(value: PointInteractionMode);
    get hoverStyle(): {
        border?: {
            color?: string | undefined;
            visible?: boolean;
            width?: number;
        };
        color?: ChartsColor | string | undefined;
        size?: number | undefined;
    };
    set hoverStyle(value: {
        border?: {
            color?: string | undefined;
            visible?: boolean;
            width?: number;
        };
        color?: ChartsColor | string | undefined;
        size?: number | undefined;
    });
    get image(): string | undefined | {
        height?: number | {
            rangeMaxPoint?: number | undefined;
            rangeMinPoint?: number | undefined;
        };
        url?: string | undefined | {
            rangeMaxPoint?: string | undefined;
            rangeMinPoint?: string | undefined;
        };
        width?: number | {
            rangeMaxPoint?: number | undefined;
            rangeMinPoint?: number | undefined;
        };
    };
    set image(value: string | undefined | {
        height?: number | {
            rangeMaxPoint?: number | undefined;
            rangeMinPoint?: number | undefined;
        };
        url?: string | undefined | {
            rangeMaxPoint?: string | undefined;
            rangeMinPoint?: string | undefined;
        };
        width?: number | {
            rangeMaxPoint?: number | undefined;
            rangeMinPoint?: number | undefined;
        };
    });
    get selectionMode(): PointInteractionMode;
    set selectionMode(value: PointInteractionMode);
    get selectionStyle(): {
        border?: {
            color?: string | undefined;
            visible?: boolean;
            width?: number;
        };
        color?: ChartsColor | string | undefined;
        size?: number | undefined;
    };
    set selectionStyle(value: {
        border?: {
            color?: string | undefined;
            visible?: boolean;
            width?: number;
        };
        color?: ChartsColor | string | undefined;
        size?: number | undefined;
    });
    get size(): number;
    set size(value: number);
    get symbol(): PointSymbol;
    set symbol(value: PointSymbol);
    get visible(): boolean;
    set visible(value: boolean);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoRangeSelectorPointComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoRangeSelectorPointComponent, "dxo-range-selector-point", never, { "border": { "alias": "border"; "required": false; }; "color": { "alias": "color"; "required": false; }; "hoverMode": { "alias": "hoverMode"; "required": false; }; "hoverStyle": { "alias": "hoverStyle"; "required": false; }; "image": { "alias": "image"; "required": false; }; "selectionMode": { "alias": "selectionMode"; "required": false; }; "selectionStyle": { "alias": "selectionStyle"; "required": false; }; "size": { "alias": "size"; "required": false; }; "symbol": { "alias": "symbol"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoRangeSelectorPointModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoRangeSelectorPointModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoRangeSelectorPointModule, never, [typeof DxoRangeSelectorPointComponent], [typeof DxoRangeSelectorPointComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoRangeSelectorPointModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoRangeSelectorReductionComponent extends NestedOption implements OnDestroy, OnInit {
    get color(): string;
    set color(value: string);
    get level(): FinancialChartReductionLevel;
    set level(value: FinancialChartReductionLevel);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoRangeSelectorReductionComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoRangeSelectorReductionComponent, "dxo-range-selector-reduction", never, { "color": { "alias": "color"; "required": false; }; "level": { "alias": "level"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoRangeSelectorReductionModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoRangeSelectorReductionModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoRangeSelectorReductionModule, never, [typeof DxoRangeSelectorReductionComponent], [typeof DxoRangeSelectorReductionComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoRangeSelectorReductionModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoRangeSelectorScaleLabelComponent extends NestedOption implements OnDestroy, OnInit {
    get customizeText(): ((scaleValue: {
        value: Date | number | string;
        valueText: string;
    }) => string);
    set customizeText(value: ((scaleValue: {
        value: Date | number | string;
        valueText: string;
    }) => string));
    get font(): Font;
    set font(value: Font);
    get format(): Format$1 | undefined;
    set format(value: Format$1 | undefined);
    get overlappingBehavior(): LabelOverlap;
    set overlappingBehavior(value: LabelOverlap);
    get topIndent(): number;
    set topIndent(value: number);
    get visible(): boolean;
    set visible(value: boolean);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoRangeSelectorScaleLabelComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoRangeSelectorScaleLabelComponent, "dxo-range-selector-scale-label", never, { "customizeText": { "alias": "customizeText"; "required": false; }; "font": { "alias": "font"; "required": false; }; "format": { "alias": "format"; "required": false; }; "overlappingBehavior": { "alias": "overlappingBehavior"; "required": false; }; "topIndent": { "alias": "topIndent"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoRangeSelectorScaleLabelModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoRangeSelectorScaleLabelModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoRangeSelectorScaleLabelModule, never, [typeof DxoRangeSelectorScaleLabelComponent], [typeof DxoRangeSelectorScaleLabelComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoRangeSelectorScaleLabelModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoRangeSelectorScaleComponent extends NestedOption implements OnDestroy, OnInit {
    set _breaksContentChildren(value: QueryList<CollectionNestedOption>);
    get aggregationGroupWidth(): number | undefined;
    set aggregationGroupWidth(value: number | undefined);
    get aggregationInterval(): number | TimeInterval | {
        days?: number;
        hours?: number;
        milliseconds?: number;
        minutes?: number;
        months?: number;
        quarters?: number;
        seconds?: number;
        weeks?: number;
        years?: number;
    };
    set aggregationInterval(value: number | TimeInterval | {
        days?: number;
        hours?: number;
        milliseconds?: number;
        minutes?: number;
        months?: number;
        quarters?: number;
        seconds?: number;
        weeks?: number;
        years?: number;
    });
    get allowDecimals(): boolean | undefined;
    set allowDecimals(value: boolean | undefined);
    get breaks(): Array<ScaleBreak> | undefined | {
        endValue?: Date | number | string | undefined;
        startValue?: Date | number | string | undefined;
    }[];
    set breaks(value: Array<ScaleBreak> | undefined | {
        endValue?: Date | number | string | undefined;
        startValue?: Date | number | string | undefined;
    }[]);
    get breakStyle(): {
        color?: string;
        line?: ScaleBreakLineStyle;
        width?: number;
    };
    set breakStyle(value: {
        color?: string;
        line?: ScaleBreakLineStyle;
        width?: number;
    });
    get categories(): Array<Date | number | string>;
    set categories(value: Array<Date | number | string>);
    get discreteAxisDivisionMode(): DiscreteAxisDivisionMode;
    set discreteAxisDivisionMode(value: DiscreteAxisDivisionMode);
    get endOnTick(): boolean;
    set endOnTick(value: boolean);
    get endValue(): Date | number | string | undefined;
    set endValue(value: Date | number | string | undefined);
    get holidays(): Array<Date | string> | Array<number> | undefined;
    set holidays(value: Array<Date | string> | Array<number> | undefined);
    get label(): {
        customizeText?: ((scaleValue: {
            value: Date | number | string;
            valueText: string;
        }) => string);
        font?: Font;
        format?: Format$1 | undefined;
        overlappingBehavior?: LabelOverlap;
        topIndent?: number;
        visible?: boolean;
    };
    set label(value: {
        customizeText?: ((scaleValue: {
            value: Date | number | string;
            valueText: string;
        }) => string);
        font?: Font;
        format?: Format$1 | undefined;
        overlappingBehavior?: LabelOverlap;
        topIndent?: number;
        visible?: boolean;
    });
    get linearThreshold(): number;
    set linearThreshold(value: number);
    get logarithmBase(): number;
    set logarithmBase(value: number);
    get marker(): {
        label?: {
            customizeText?: ((markerValue: {
                value: Date | number;
                valueText: string;
            }) => string);
            format?: Format$1 | undefined;
        };
        separatorHeight?: number;
        textLeftIndent?: number;
        textTopIndent?: number;
        topIndent?: number;
        visible?: boolean;
    };
    set marker(value: {
        label?: {
            customizeText?: ((markerValue: {
                value: Date | number;
                valueText: string;
            }) => string);
            format?: Format$1 | undefined;
        };
        separatorHeight?: number;
        textLeftIndent?: number;
        textTopIndent?: number;
        topIndent?: number;
        visible?: boolean;
    });
    get maxRange(): number | TimeInterval | {
        days?: number;
        hours?: number;
        milliseconds?: number;
        minutes?: number;
        months?: number;
        quarters?: number;
        seconds?: number;
        weeks?: number;
        years?: number;
    };
    set maxRange(value: number | TimeInterval | {
        days?: number;
        hours?: number;
        milliseconds?: number;
        minutes?: number;
        months?: number;
        quarters?: number;
        seconds?: number;
        weeks?: number;
        years?: number;
    });
    get minorTick(): {
        color?: string;
        opacity?: number;
        visible?: boolean;
        width?: number;
    };
    set minorTick(value: {
        color?: string;
        opacity?: number;
        visible?: boolean;
        width?: number;
    });
    get minorTickCount(): number | undefined;
    set minorTickCount(value: number | undefined);
    get minorTickInterval(): number | TimeInterval | {
        days?: number;
        hours?: number;
        milliseconds?: number;
        minutes?: number;
        months?: number;
        quarters?: number;
        seconds?: number;
        weeks?: number;
        years?: number;
    };
    set minorTickInterval(value: number | TimeInterval | {
        days?: number;
        hours?: number;
        milliseconds?: number;
        minutes?: number;
        months?: number;
        quarters?: number;
        seconds?: number;
        weeks?: number;
        years?: number;
    });
    get minRange(): number | TimeInterval | {
        days?: number;
        hours?: number;
        milliseconds?: number;
        minutes?: number;
        months?: number;
        quarters?: number;
        seconds?: number;
        weeks?: number;
        years?: number;
    };
    set minRange(value: number | TimeInterval | {
        days?: number;
        hours?: number;
        milliseconds?: number;
        minutes?: number;
        months?: number;
        quarters?: number;
        seconds?: number;
        weeks?: number;
        years?: number;
    });
    get placeholderHeight(): number | undefined;
    set placeholderHeight(value: number | undefined);
    get showCustomBoundaryTicks(): boolean;
    set showCustomBoundaryTicks(value: boolean);
    get singleWorkdays(): Array<Date | string> | Array<number> | undefined;
    set singleWorkdays(value: Array<Date | string> | Array<number> | undefined);
    get startValue(): Date | number | string | undefined;
    set startValue(value: Date | number | string | undefined);
    get tick(): {
        color?: string;
        opacity?: number;
        width?: number;
    };
    set tick(value: {
        color?: string;
        opacity?: number;
        width?: number;
    });
    get tickInterval(): number | TimeInterval | {
        days?: number;
        hours?: number;
        milliseconds?: number;
        minutes?: number;
        months?: number;
        quarters?: number;
        seconds?: number;
        weeks?: number;
        years?: number;
    };
    set tickInterval(value: number | TimeInterval | {
        days?: number;
        hours?: number;
        milliseconds?: number;
        minutes?: number;
        months?: number;
        quarters?: number;
        seconds?: number;
        weeks?: number;
        years?: number;
    });
    get type(): AxisScale | undefined;
    set type(value: AxisScale | undefined);
    get valueType(): ChartsDataType | undefined;
    set valueType(value: ChartsDataType | undefined);
    get workdaysOnly(): boolean;
    set workdaysOnly(value: boolean);
    get workWeek(): Array<number>;
    set workWeek(value: Array<number>);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoRangeSelectorScaleComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoRangeSelectorScaleComponent, "dxo-range-selector-scale", never, { "aggregationGroupWidth": { "alias": "aggregationGroupWidth"; "required": false; }; "aggregationInterval": { "alias": "aggregationInterval"; "required": false; }; "allowDecimals": { "alias": "allowDecimals"; "required": false; }; "breaks": { "alias": "breaks"; "required": false; }; "breakStyle": { "alias": "breakStyle"; "required": false; }; "categories": { "alias": "categories"; "required": false; }; "discreteAxisDivisionMode": { "alias": "discreteAxisDivisionMode"; "required": false; }; "endOnTick": { "alias": "endOnTick"; "required": false; }; "endValue": { "alias": "endValue"; "required": false; }; "holidays": { "alias": "holidays"; "required": false; }; "label": { "alias": "label"; "required": false; }; "linearThreshold": { "alias": "linearThreshold"; "required": false; }; "logarithmBase": { "alias": "logarithmBase"; "required": false; }; "marker": { "alias": "marker"; "required": false; }; "maxRange": { "alias": "maxRange"; "required": false; }; "minorTick": { "alias": "minorTick"; "required": false; }; "minorTickCount": { "alias": "minorTickCount"; "required": false; }; "minorTickInterval": { "alias": "minorTickInterval"; "required": false; }; "minRange": { "alias": "minRange"; "required": false; }; "placeholderHeight": { "alias": "placeholderHeight"; "required": false; }; "showCustomBoundaryTicks": { "alias": "showCustomBoundaryTicks"; "required": false; }; "singleWorkdays": { "alias": "singleWorkdays"; "required": false; }; "startValue": { "alias": "startValue"; "required": false; }; "tick": { "alias": "tick"; "required": false; }; "tickInterval": { "alias": "tickInterval"; "required": false; }; "type": { "alias": "type"; "required": false; }; "valueType": { "alias": "valueType"; "required": false; }; "workdaysOnly": { "alias": "workdaysOnly"; "required": false; }; "workWeek": { "alias": "workWeek"; "required": false; }; }, {}, ["_breaksContentChildren"], never, true, never>;
}
declare class DxoRangeSelectorScaleModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoRangeSelectorScaleModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoRangeSelectorScaleModule, never, [typeof DxoRangeSelectorScaleComponent], [typeof DxoRangeSelectorScaleComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoRangeSelectorScaleModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoRangeSelectorSelectionStyleComponent extends NestedOption implements OnDestroy, OnInit {
    get border(): {
        color?: string | undefined;
        visible?: boolean;
        width?: number;
        dashStyle?: DashStyle | undefined;
    };
    set border(value: {
        color?: string | undefined;
        visible?: boolean;
        width?: number;
        dashStyle?: DashStyle | undefined;
    });
    get color(): ChartsColor | string | undefined;
    set color(value: ChartsColor | string | undefined);
    get size(): number | undefined;
    set size(value: number | undefined);
    get dashStyle(): DashStyle;
    set dashStyle(value: DashStyle);
    get hatching(): {
        direction?: HatchDirection;
        opacity?: number;
        step?: number;
        width?: number;
    };
    set hatching(value: {
        direction?: HatchDirection;
        opacity?: number;
        step?: number;
        width?: number;
    });
    get highlight(): boolean;
    set highlight(value: boolean);
    get width(): number;
    set width(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoRangeSelectorSelectionStyleComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoRangeSelectorSelectionStyleComponent, "dxo-range-selector-selection-style", never, { "border": { "alias": "border"; "required": false; }; "color": { "alias": "color"; "required": false; }; "size": { "alias": "size"; "required": false; }; "dashStyle": { "alias": "dashStyle"; "required": false; }; "hatching": { "alias": "hatching"; "required": false; }; "highlight": { "alias": "highlight"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoRangeSelectorSelectionStyleModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoRangeSelectorSelectionStyleModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoRangeSelectorSelectionStyleModule, never, [typeof DxoRangeSelectorSelectionStyleComponent], [typeof DxoRangeSelectorSelectionStyleComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoRangeSelectorSelectionStyleModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoRangeSelectorSeriesBorderComponent extends NestedOption implements OnDestroy, OnInit {
    get color(): string | undefined;
    set color(value: string | undefined);
    get dashStyle(): DashStyle | undefined;
    set dashStyle(value: DashStyle | undefined);
    get visible(): boolean;
    set visible(value: boolean);
    get width(): number;
    set width(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoRangeSelectorSeriesBorderComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoRangeSelectorSeriesBorderComponent, "dxo-range-selector-series-border", never, { "color": { "alias": "color"; "required": false; }; "dashStyle": { "alias": "dashStyle"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoRangeSelectorSeriesBorderModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoRangeSelectorSeriesBorderModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoRangeSelectorSeriesBorderModule, never, [typeof DxoRangeSelectorSeriesBorderComponent], [typeof DxoRangeSelectorSeriesBorderComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoRangeSelectorSeriesBorderModule>;
}

declare class DxiRangeSelectorSeriesComponent extends CollectionNestedOption {
    get aggregation(): {
        calculate?: ((aggregationInfo: chartPointAggregationInfoObject, series: chartSeriesObject) => Record<string, any> | Array<Record<string, any>>) | undefined;
        enabled?: boolean;
        method?: ChartSeriesAggregationMethod;
    };
    set aggregation(value: {
        calculate?: ((aggregationInfo: chartPointAggregationInfoObject, series: chartSeriesObject) => Record<string, any> | Array<Record<string, any>>) | undefined;
        enabled?: boolean;
        method?: ChartSeriesAggregationMethod;
    });
    get argumentField(): string;
    set argumentField(value: string);
    get axis(): string | undefined;
    set axis(value: string | undefined);
    get barOverlapGroup(): string | undefined;
    set barOverlapGroup(value: string | undefined);
    get barPadding(): number | undefined;
    set barPadding(value: number | undefined);
    get barWidth(): number | undefined;
    set barWidth(value: number | undefined);
    get border(): {
        color?: string | undefined;
        dashStyle?: DashStyle | undefined;
        visible?: boolean;
        width?: number;
    };
    set border(value: {
        color?: string | undefined;
        dashStyle?: DashStyle | undefined;
        visible?: boolean;
        width?: number;
    });
    get closeValueField(): string;
    set closeValueField(value: string);
    get color(): ChartsColor | string | undefined;
    set color(value: ChartsColor | string | undefined);
    get cornerRadius(): number;
    set cornerRadius(value: number);
    get dashStyle(): DashStyle;
    set dashStyle(value: DashStyle);
    get highValueField(): string;
    set highValueField(value: string);
    get hoverMode(): SeriesHoverMode;
    set hoverMode(value: SeriesHoverMode);
    get hoverStyle(): {
        border?: {
            color?: string | undefined;
            dashStyle?: DashStyle | undefined;
            visible?: boolean;
            width?: number;
        };
        color?: ChartsColor | string | undefined;
        dashStyle?: DashStyle;
        hatching?: {
            direction?: HatchDirection;
            opacity?: number;
            step?: number;
            width?: number;
        };
        highlight?: boolean;
        width?: number;
    };
    set hoverStyle(value: {
        border?: {
            color?: string | undefined;
            dashStyle?: DashStyle | undefined;
            visible?: boolean;
            width?: number;
        };
        color?: ChartsColor | string | undefined;
        dashStyle?: DashStyle;
        hatching?: {
            direction?: HatchDirection;
            opacity?: number;
            step?: number;
            width?: number;
        };
        highlight?: boolean;
        width?: number;
    });
    get ignoreEmptyPoints(): boolean;
    set ignoreEmptyPoints(value: boolean);
    get innerColor(): string;
    set innerColor(value: string);
    get label(): {
        alignment?: HorizontalAlignment;
        argumentFormat?: Format$1 | undefined;
        backgroundColor?: string | undefined;
        border?: {
            color?: string | undefined;
            dashStyle?: DashStyle | undefined;
            visible?: boolean;
            width?: number;
        };
        connector?: {
            color?: string | undefined;
            visible?: boolean;
            width?: number;
        };
        customizeText?: ((pointInfo: any) => string);
        displayFormat?: string | undefined;
        font?: Font;
        format?: Format$1 | undefined;
        horizontalOffset?: number;
        position?: RelativePosition;
        rotationAngle?: number;
        showForZeroValues?: boolean;
        verticalOffset?: number;
        visible?: boolean;
    };
    set label(value: {
        alignment?: HorizontalAlignment;
        argumentFormat?: Format$1 | undefined;
        backgroundColor?: string | undefined;
        border?: {
            color?: string | undefined;
            dashStyle?: DashStyle | undefined;
            visible?: boolean;
            width?: number;
        };
        connector?: {
            color?: string | undefined;
            visible?: boolean;
            width?: number;
        };
        customizeText?: ((pointInfo: any) => string);
        displayFormat?: string | undefined;
        font?: Font;
        format?: Format$1 | undefined;
        horizontalOffset?: number;
        position?: RelativePosition;
        rotationAngle?: number;
        showForZeroValues?: boolean;
        verticalOffset?: number;
        visible?: boolean;
    });
    get lowValueField(): string;
    set lowValueField(value: string);
    get maxLabelCount(): number | undefined;
    set maxLabelCount(value: number | undefined);
    get minBarSize(): number | undefined;
    set minBarSize(value: number | undefined);
    get name(): string | undefined;
    set name(value: string | undefined);
    get opacity(): number;
    set opacity(value: number);
    get openValueField(): string;
    set openValueField(value: string);
    get pane(): string;
    set pane(value: string);
    get point(): {
        border?: {
            color?: string | undefined;
            visible?: boolean;
            width?: number;
        };
        color?: ChartsColor | string | undefined;
        hoverMode?: PointInteractionMode;
        hoverStyle?: {
            border?: {
                color?: string | undefined;
                visible?: boolean;
                width?: number;
            };
            color?: ChartsColor | string | undefined;
            size?: number | undefined;
        };
        image?: string | undefined | {
            height?: number | {
                rangeMaxPoint?: number | undefined;
                rangeMinPoint?: number | undefined;
            };
            url?: string | undefined | {
                rangeMaxPoint?: string | undefined;
                rangeMinPoint?: string | undefined;
            };
            width?: number | {
                rangeMaxPoint?: number | undefined;
                rangeMinPoint?: number | undefined;
            };
        };
        selectionMode?: PointInteractionMode;
        selectionStyle?: {
            border?: {
                color?: string | undefined;
                visible?: boolean;
                width?: number;
            };
            color?: ChartsColor | string | undefined;
            size?: number | undefined;
        };
        size?: number;
        symbol?: PointSymbol;
        visible?: boolean;
    };
    set point(value: {
        border?: {
            color?: string | undefined;
            visible?: boolean;
            width?: number;
        };
        color?: ChartsColor | string | undefined;
        hoverMode?: PointInteractionMode;
        hoverStyle?: {
            border?: {
                color?: string | undefined;
                visible?: boolean;
                width?: number;
            };
            color?: ChartsColor | string | undefined;
            size?: number | undefined;
        };
        image?: string | undefined | {
            height?: number | {
                rangeMaxPoint?: number | undefined;
                rangeMinPoint?: number | undefined;
            };
            url?: string | undefined | {
                rangeMaxPoint?: string | undefined;
                rangeMinPoint?: string | undefined;
            };
            width?: number | {
                rangeMaxPoint?: number | undefined;
                rangeMinPoint?: number | undefined;
            };
        };
        selectionMode?: PointInteractionMode;
        selectionStyle?: {
            border?: {
                color?: string | undefined;
                visible?: boolean;
                width?: number;
            };
            color?: ChartsColor | string | undefined;
            size?: number | undefined;
        };
        size?: number;
        symbol?: PointSymbol;
        visible?: boolean;
    });
    get rangeValue1Field(): string;
    set rangeValue1Field(value: string);
    get rangeValue2Field(): string;
    set rangeValue2Field(value: string);
    get reduction(): {
        color?: string;
        level?: FinancialChartReductionLevel;
    };
    set reduction(value: {
        color?: string;
        level?: FinancialChartReductionLevel;
    });
    get selectionMode(): SeriesSelectionMode;
    set selectionMode(value: SeriesSelectionMode);
    get selectionStyle(): {
        border?: {
            color?: string | undefined;
            dashStyle?: DashStyle | undefined;
            visible?: boolean;
            width?: number;
        };
        color?: ChartsColor | string | undefined;
        dashStyle?: DashStyle;
        hatching?: {
            direction?: HatchDirection;
            opacity?: number;
            step?: number;
            width?: number;
        };
        highlight?: boolean;
        width?: number;
    };
    set selectionStyle(value: {
        border?: {
            color?: string | undefined;
            dashStyle?: DashStyle | undefined;
            visible?: boolean;
            width?: number;
        };
        color?: ChartsColor | string | undefined;
        dashStyle?: DashStyle;
        hatching?: {
            direction?: HatchDirection;
            opacity?: number;
            step?: number;
            width?: number;
        };
        highlight?: boolean;
        width?: number;
    });
    get showInLegend(): boolean;
    set showInLegend(value: boolean);
    get sizeField(): string;
    set sizeField(value: string);
    get stack(): string;
    set stack(value: string);
    get tag(): any | undefined;
    set tag(value: any | undefined);
    get tagField(): string;
    set tagField(value: string);
    get type(): SeriesType;
    set type(value: SeriesType);
    get valueErrorBar(): {
        color?: string;
        displayMode?: ValueErrorBarDisplayMode;
        edgeLength?: number;
        highValueField?: string | undefined;
        lineWidth?: number;
        lowValueField?: string | undefined;
        opacity?: number | undefined;
        type?: undefined | ValueErrorBarType;
        value?: number;
    };
    set valueErrorBar(value: {
        color?: string;
        displayMode?: ValueErrorBarDisplayMode;
        edgeLength?: number;
        highValueField?: string | undefined;
        lineWidth?: number;
        lowValueField?: string | undefined;
        opacity?: number | undefined;
        type?: undefined | ValueErrorBarType;
        value?: number;
    });
    get valueField(): string;
    set valueField(value: string);
    get visible(): boolean;
    set visible(value: boolean);
    get width(): number;
    set width(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiRangeSelectorSeriesComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiRangeSelectorSeriesComponent, "dxi-range-selector-series", never, { "aggregation": { "alias": "aggregation"; "required": false; }; "argumentField": { "alias": "argumentField"; "required": false; }; "axis": { "alias": "axis"; "required": false; }; "barOverlapGroup": { "alias": "barOverlapGroup"; "required": false; }; "barPadding": { "alias": "barPadding"; "required": false; }; "barWidth": { "alias": "barWidth"; "required": false; }; "border": { "alias": "border"; "required": false; }; "closeValueField": { "alias": "closeValueField"; "required": false; }; "color": { "alias": "color"; "required": false; }; "cornerRadius": { "alias": "cornerRadius"; "required": false; }; "dashStyle": { "alias": "dashStyle"; "required": false; }; "highValueField": { "alias": "highValueField"; "required": false; }; "hoverMode": { "alias": "hoverMode"; "required": false; }; "hoverStyle": { "alias": "hoverStyle"; "required": false; }; "ignoreEmptyPoints": { "alias": "ignoreEmptyPoints"; "required": false; }; "innerColor": { "alias": "innerColor"; "required": false; }; "label": { "alias": "label"; "required": false; }; "lowValueField": { "alias": "lowValueField"; "required": false; }; "maxLabelCount": { "alias": "maxLabelCount"; "required": false; }; "minBarSize": { "alias": "minBarSize"; "required": false; }; "name": { "alias": "name"; "required": false; }; "opacity": { "alias": "opacity"; "required": false; }; "openValueField": { "alias": "openValueField"; "required": false; }; "pane": { "alias": "pane"; "required": false; }; "point": { "alias": "point"; "required": false; }; "rangeValue1Field": { "alias": "rangeValue1Field"; "required": false; }; "rangeValue2Field": { "alias": "rangeValue2Field"; "required": false; }; "reduction": { "alias": "reduction"; "required": false; }; "selectionMode": { "alias": "selectionMode"; "required": false; }; "selectionStyle": { "alias": "selectionStyle"; "required": false; }; "showInLegend": { "alias": "showInLegend"; "required": false; }; "sizeField": { "alias": "sizeField"; "required": false; }; "stack": { "alias": "stack"; "required": false; }; "tag": { "alias": "tag"; "required": false; }; "tagField": { "alias": "tagField"; "required": false; }; "type": { "alias": "type"; "required": false; }; "valueErrorBar": { "alias": "valueErrorBar"; "required": false; }; "valueField": { "alias": "valueField"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxiRangeSelectorSeriesModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiRangeSelectorSeriesModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiRangeSelectorSeriesModule, never, [typeof DxiRangeSelectorSeriesComponent], [typeof DxiRangeSelectorSeriesComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiRangeSelectorSeriesModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoRangeSelectorSeriesTemplateComponent extends NestedOption implements OnDestroy, OnInit {
    get customizeSeries(): ((seriesName: any) => ChartSeries);
    set customizeSeries(value: ((seriesName: any) => ChartSeries));
    get nameField(): string;
    set nameField(value: string);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoRangeSelectorSeriesTemplateComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoRangeSelectorSeriesTemplateComponent, "dxo-range-selector-series-template", never, { "customizeSeries": { "alias": "customizeSeries"; "required": false; }; "nameField": { "alias": "nameField"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoRangeSelectorSeriesTemplateModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoRangeSelectorSeriesTemplateModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoRangeSelectorSeriesTemplateModule, never, [typeof DxoRangeSelectorSeriesTemplateComponent], [typeof DxoRangeSelectorSeriesTemplateComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoRangeSelectorSeriesTemplateModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoRangeSelectorShutterComponent extends NestedOption implements OnDestroy, OnInit {
    get color(): string | undefined;
    set color(value: string | undefined);
    get opacity(): number;
    set opacity(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoRangeSelectorShutterComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoRangeSelectorShutterComponent, "dxo-range-selector-shutter", never, { "color": { "alias": "color"; "required": false; }; "opacity": { "alias": "opacity"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoRangeSelectorShutterModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoRangeSelectorShutterModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoRangeSelectorShutterModule, never, [typeof DxoRangeSelectorShutterComponent], [typeof DxoRangeSelectorShutterComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoRangeSelectorShutterModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoRangeSelectorSizeComponent extends NestedOption implements OnDestroy, OnInit {
    get height(): number | undefined;
    set height(value: number | undefined);
    get width(): number | undefined;
    set width(value: number | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoRangeSelectorSizeComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoRangeSelectorSizeComponent, "dxo-range-selector-size", never, { "height": { "alias": "height"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoRangeSelectorSizeModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoRangeSelectorSizeModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoRangeSelectorSizeModule, never, [typeof DxoRangeSelectorSizeComponent], [typeof DxoRangeSelectorSizeComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoRangeSelectorSizeModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoRangeSelectorSliderHandleComponent extends NestedOption implements OnDestroy, OnInit {
    get color(): string;
    set color(value: string);
    get opacity(): number;
    set opacity(value: number);
    get width(): number;
    set width(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoRangeSelectorSliderHandleComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoRangeSelectorSliderHandleComponent, "dxo-range-selector-slider-handle", never, { "color": { "alias": "color"; "required": false; }; "opacity": { "alias": "opacity"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoRangeSelectorSliderHandleModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoRangeSelectorSliderHandleModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoRangeSelectorSliderHandleModule, never, [typeof DxoRangeSelectorSliderHandleComponent], [typeof DxoRangeSelectorSliderHandleComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoRangeSelectorSliderHandleModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoRangeSelectorSliderMarkerComponent extends NestedOption implements OnDestroy, OnInit {
    get color(): string;
    set color(value: string);
    get customizeText(): ((scaleValue: {
        value: Date | number | string;
        valueText: string;
    }) => string);
    set customizeText(value: ((scaleValue: {
        value: Date | number | string;
        valueText: string;
    }) => string));
    get font(): Font;
    set font(value: Font);
    get format(): Format$1 | undefined;
    set format(value: Format$1 | undefined);
    get invalidRangeColor(): string;
    set invalidRangeColor(value: string);
    get paddingLeftRight(): number;
    set paddingLeftRight(value: number);
    get paddingTopBottom(): number;
    set paddingTopBottom(value: number);
    get placeholderHeight(): number | undefined;
    set placeholderHeight(value: number | undefined);
    get visible(): boolean;
    set visible(value: boolean);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoRangeSelectorSliderMarkerComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoRangeSelectorSliderMarkerComponent, "dxo-range-selector-slider-marker", never, { "color": { "alias": "color"; "required": false; }; "customizeText": { "alias": "customizeText"; "required": false; }; "font": { "alias": "font"; "required": false; }; "format": { "alias": "format"; "required": false; }; "invalidRangeColor": { "alias": "invalidRangeColor"; "required": false; }; "paddingLeftRight": { "alias": "paddingLeftRight"; "required": false; }; "paddingTopBottom": { "alias": "paddingTopBottom"; "required": false; }; "placeholderHeight": { "alias": "placeholderHeight"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoRangeSelectorSliderMarkerModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoRangeSelectorSliderMarkerModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoRangeSelectorSliderMarkerModule, never, [typeof DxoRangeSelectorSliderMarkerComponent], [typeof DxoRangeSelectorSliderMarkerComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoRangeSelectorSliderMarkerModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoRangeSelectorSubtitleComponent extends NestedOption implements OnDestroy, OnInit {
    get font(): Font;
    set font(value: Font);
    get offset(): number;
    set offset(value: number);
    get text(): string | undefined;
    set text(value: string | undefined);
    get textOverflow(): TextOverflow;
    set textOverflow(value: TextOverflow);
    get wordWrap(): WordWrap;
    set wordWrap(value: WordWrap);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoRangeSelectorSubtitleComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoRangeSelectorSubtitleComponent, "dxo-range-selector-subtitle", never, { "font": { "alias": "font"; "required": false; }; "offset": { "alias": "offset"; "required": false; }; "text": { "alias": "text"; "required": false; }; "textOverflow": { "alias": "textOverflow"; "required": false; }; "wordWrap": { "alias": "wordWrap"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoRangeSelectorSubtitleModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoRangeSelectorSubtitleModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoRangeSelectorSubtitleModule, never, [typeof DxoRangeSelectorSubtitleComponent], [typeof DxoRangeSelectorSubtitleComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoRangeSelectorSubtitleModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoRangeSelectorTickIntervalComponent extends NestedOption implements OnDestroy, OnInit {
    get days(): number;
    set days(value: number);
    get hours(): number;
    set hours(value: number);
    get milliseconds(): number;
    set milliseconds(value: number);
    get minutes(): number;
    set minutes(value: number);
    get months(): number;
    set months(value: number);
    get quarters(): number;
    set quarters(value: number);
    get seconds(): number;
    set seconds(value: number);
    get weeks(): number;
    set weeks(value: number);
    get years(): number;
    set years(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoRangeSelectorTickIntervalComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoRangeSelectorTickIntervalComponent, "dxo-range-selector-tick-interval", never, { "days": { "alias": "days"; "required": false; }; "hours": { "alias": "hours"; "required": false; }; "milliseconds": { "alias": "milliseconds"; "required": false; }; "minutes": { "alias": "minutes"; "required": false; }; "months": { "alias": "months"; "required": false; }; "quarters": { "alias": "quarters"; "required": false; }; "seconds": { "alias": "seconds"; "required": false; }; "weeks": { "alias": "weeks"; "required": false; }; "years": { "alias": "years"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoRangeSelectorTickIntervalModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoRangeSelectorTickIntervalModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoRangeSelectorTickIntervalModule, never, [typeof DxoRangeSelectorTickIntervalComponent], [typeof DxoRangeSelectorTickIntervalComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoRangeSelectorTickIntervalModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoRangeSelectorTickComponent extends NestedOption implements OnDestroy, OnInit {
    get color(): string;
    set color(value: string);
    get opacity(): number;
    set opacity(value: number);
    get width(): number;
    set width(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoRangeSelectorTickComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoRangeSelectorTickComponent, "dxo-range-selector-tick", never, { "color": { "alias": "color"; "required": false; }; "opacity": { "alias": "opacity"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoRangeSelectorTickModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoRangeSelectorTickModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoRangeSelectorTickModule, never, [typeof DxoRangeSelectorTickComponent], [typeof DxoRangeSelectorTickComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoRangeSelectorTickModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoRangeSelectorTitleComponent extends NestedOption implements OnDestroy, OnInit {
    get font(): Font;
    set font(value: Font);
    get horizontalAlignment(): HorizontalAlignment;
    set horizontalAlignment(value: HorizontalAlignment);
    get margin(): number | {
        bottom?: number;
        left?: number;
        right?: number;
        top?: number;
    };
    set margin(value: number | {
        bottom?: number;
        left?: number;
        right?: number;
        top?: number;
    });
    get placeholderSize(): number | undefined;
    set placeholderSize(value: number | undefined);
    get subtitle(): string | {
        font?: Font;
        offset?: number;
        text?: string | undefined;
        textOverflow?: TextOverflow;
        wordWrap?: WordWrap;
    };
    set subtitle(value: string | {
        font?: Font;
        offset?: number;
        text?: string | undefined;
        textOverflow?: TextOverflow;
        wordWrap?: WordWrap;
    });
    get text(): string | undefined;
    set text(value: string | undefined);
    get textOverflow(): TextOverflow;
    set textOverflow(value: TextOverflow);
    get verticalAlignment(): VerticalEdge;
    set verticalAlignment(value: VerticalEdge);
    get wordWrap(): WordWrap;
    set wordWrap(value: WordWrap);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoRangeSelectorTitleComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoRangeSelectorTitleComponent, "dxo-range-selector-title", never, { "font": { "alias": "font"; "required": false; }; "horizontalAlignment": { "alias": "horizontalAlignment"; "required": false; }; "margin": { "alias": "margin"; "required": false; }; "placeholderSize": { "alias": "placeholderSize"; "required": false; }; "subtitle": { "alias": "subtitle"; "required": false; }; "text": { "alias": "text"; "required": false; }; "textOverflow": { "alias": "textOverflow"; "required": false; }; "verticalAlignment": { "alias": "verticalAlignment"; "required": false; }; "wordWrap": { "alias": "wordWrap"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoRangeSelectorTitleModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoRangeSelectorTitleModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoRangeSelectorTitleModule, never, [typeof DxoRangeSelectorTitleComponent], [typeof DxoRangeSelectorTitleComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoRangeSelectorTitleModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoRangeSelectorUrlComponent extends NestedOption implements OnDestroy, OnInit {
    get rangeMaxPoint(): string | undefined;
    set rangeMaxPoint(value: string | undefined);
    get rangeMinPoint(): string | undefined;
    set rangeMinPoint(value: string | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoRangeSelectorUrlComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoRangeSelectorUrlComponent, "dxo-range-selector-url", never, { "rangeMaxPoint": { "alias": "rangeMaxPoint"; "required": false; }; "rangeMinPoint": { "alias": "rangeMinPoint"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoRangeSelectorUrlModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoRangeSelectorUrlModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoRangeSelectorUrlModule, never, [typeof DxoRangeSelectorUrlComponent], [typeof DxoRangeSelectorUrlComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoRangeSelectorUrlModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoRangeSelectorValueAxisComponent extends NestedOption implements OnDestroy, OnInit {
    get inverted(): boolean;
    set inverted(value: boolean);
    get logarithmBase(): number;
    set logarithmBase(value: number);
    get max(): number | undefined;
    set max(value: number | undefined);
    get min(): number | undefined;
    set min(value: number | undefined);
    get type(): ChartAxisScale | undefined;
    set type(value: ChartAxisScale | undefined);
    get valueType(): ChartsDataType | undefined;
    set valueType(value: ChartsDataType | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoRangeSelectorValueAxisComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoRangeSelectorValueAxisComponent, "dxo-range-selector-value-axis", never, { "inverted": { "alias": "inverted"; "required": false; }; "logarithmBase": { "alias": "logarithmBase"; "required": false; }; "max": { "alias": "max"; "required": false; }; "min": { "alias": "min"; "required": false; }; "type": { "alias": "type"; "required": false; }; "valueType": { "alias": "valueType"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoRangeSelectorValueAxisModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoRangeSelectorValueAxisModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoRangeSelectorValueAxisModule, never, [typeof DxoRangeSelectorValueAxisComponent], [typeof DxoRangeSelectorValueAxisComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoRangeSelectorValueAxisModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoRangeSelectorValueErrorBarComponent extends NestedOption implements OnDestroy, OnInit {
    get color(): string;
    set color(value: string);
    get displayMode(): ValueErrorBarDisplayMode;
    set displayMode(value: ValueErrorBarDisplayMode);
    get edgeLength(): number;
    set edgeLength(value: number);
    get highValueField(): string | undefined;
    set highValueField(value: string | undefined);
    get lineWidth(): number;
    set lineWidth(value: number);
    get lowValueField(): string | undefined;
    set lowValueField(value: string | undefined);
    get opacity(): number | undefined;
    set opacity(value: number | undefined);
    get type(): undefined | ValueErrorBarType;
    set type(value: undefined | ValueErrorBarType);
    get value(): number;
    set value(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoRangeSelectorValueErrorBarComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoRangeSelectorValueErrorBarComponent, "dxo-range-selector-value-error-bar", never, { "color": { "alias": "color"; "required": false; }; "displayMode": { "alias": "displayMode"; "required": false; }; "edgeLength": { "alias": "edgeLength"; "required": false; }; "highValueField": { "alias": "highValueField"; "required": false; }; "lineWidth": { "alias": "lineWidth"; "required": false; }; "lowValueField": { "alias": "lowValueField"; "required": false; }; "opacity": { "alias": "opacity"; "required": false; }; "type": { "alias": "type"; "required": false; }; "value": { "alias": "value"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoRangeSelectorValueErrorBarModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoRangeSelectorValueErrorBarModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoRangeSelectorValueErrorBarModule, never, [typeof DxoRangeSelectorValueErrorBarComponent], [typeof DxoRangeSelectorValueErrorBarComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoRangeSelectorValueErrorBarModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoRangeSelectorValueComponent extends NestedOption implements OnDestroy, OnInit {
    get endValue(): Date | number | string | undefined;
    set endValue(value: Date | number | string | undefined);
    get length(): number | TimeInterval | undefined | {
        days?: number;
        hours?: number;
        milliseconds?: number;
        minutes?: number;
        months?: number;
        quarters?: number;
        seconds?: number;
        weeks?: number;
        years?: number;
    };
    set length(value: number | TimeInterval | undefined | {
        days?: number;
        hours?: number;
        milliseconds?: number;
        minutes?: number;
        months?: number;
        quarters?: number;
        seconds?: number;
        weeks?: number;
        years?: number;
    });
    get startValue(): Date | number | string | undefined;
    set startValue(value: Date | number | string | undefined);
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    endValueChange: EventEmitter<Date | number | string | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    startValueChange: EventEmitter<Date | number | string | undefined>;
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoRangeSelectorValueComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoRangeSelectorValueComponent, "dxo-range-selector-value", never, { "endValue": { "alias": "endValue"; "required": false; }; "length": { "alias": "length"; "required": false; }; "startValue": { "alias": "startValue"; "required": false; }; }, { "endValueChange": "endValueChange"; "startValueChange": "startValueChange"; }, never, never, true, never>;
}
declare class DxoRangeSelectorValueModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoRangeSelectorValueModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoRangeSelectorValueModule, never, [typeof DxoRangeSelectorValueComponent], [typeof DxoRangeSelectorValueComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoRangeSelectorValueModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoRangeSelectorWidthComponent extends NestedOption implements OnDestroy, OnInit {
    get rangeMaxPoint(): number | undefined;
    set rangeMaxPoint(value: number | undefined);
    get rangeMinPoint(): number | undefined;
    set rangeMinPoint(value: number | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoRangeSelectorWidthComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoRangeSelectorWidthComponent, "dxo-range-selector-width", never, { "rangeMaxPoint": { "alias": "rangeMaxPoint"; "required": false; }; "rangeMinPoint": { "alias": "rangeMinPoint"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoRangeSelectorWidthModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoRangeSelectorWidthModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoRangeSelectorWidthModule, never, [typeof DxoRangeSelectorWidthComponent], [typeof DxoRangeSelectorWidthComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoRangeSelectorWidthModule>;
}

export { DxiRangeSelectorBreakComponent, DxiRangeSelectorBreakModule, DxiRangeSelectorSeriesComponent, DxiRangeSelectorSeriesModule, DxoRangeSelectorAggregationComponent, DxoRangeSelectorAggregationIntervalComponent, DxoRangeSelectorAggregationIntervalModule, DxoRangeSelectorAggregationModule, DxoRangeSelectorArgumentFormatComponent, DxoRangeSelectorArgumentFormatModule, DxoRangeSelectorBackgroundComponent, DxoRangeSelectorBackgroundImageComponent, DxoRangeSelectorBackgroundImageModule, DxoRangeSelectorBackgroundModule, DxoRangeSelectorBehaviorComponent, DxoRangeSelectorBehaviorModule, DxoRangeSelectorBorderComponent, DxoRangeSelectorBorderModule, DxoRangeSelectorBreakStyleComponent, DxoRangeSelectorBreakStyleModule, DxoRangeSelectorChartComponent, DxoRangeSelectorChartModule, DxoRangeSelectorColorComponent, DxoRangeSelectorColorModule, DxoRangeSelectorCommonSeriesSettingsComponent, DxoRangeSelectorCommonSeriesSettingsHoverStyleComponent, DxoRangeSelectorCommonSeriesSettingsHoverStyleModule, DxoRangeSelectorCommonSeriesSettingsLabelComponent, DxoRangeSelectorCommonSeriesSettingsLabelModule, DxoRangeSelectorCommonSeriesSettingsModule, DxoRangeSelectorCommonSeriesSettingsSelectionStyleComponent, DxoRangeSelectorCommonSeriesSettingsSelectionStyleModule, DxoRangeSelectorConnectorComponent, DxoRangeSelectorConnectorModule, DxoRangeSelectorDataPrepareSettingsComponent, DxoRangeSelectorDataPrepareSettingsModule, DxoRangeSelectorExportComponent, DxoRangeSelectorExportModule, DxoRangeSelectorFontComponent, DxoRangeSelectorFontModule, DxoRangeSelectorFormatComponent, DxoRangeSelectorFormatModule, DxoRangeSelectorHatchingComponent, DxoRangeSelectorHatchingModule, DxoRangeSelectorHeightComponent, DxoRangeSelectorHeightModule, DxoRangeSelectorHoverStyleComponent, DxoRangeSelectorHoverStyleModule, DxoRangeSelectorImageComponent, DxoRangeSelectorImageModule, DxoRangeSelectorIndentComponent, DxoRangeSelectorIndentModule, DxoRangeSelectorLabelComponent, DxoRangeSelectorLabelModule, DxoRangeSelectorLengthComponent, DxoRangeSelectorLengthModule, DxoRangeSelectorLoadingIndicatorComponent, DxoRangeSelectorLoadingIndicatorModule, DxoRangeSelectorMarginComponent, DxoRangeSelectorMarginModule, DxoRangeSelectorMarkerComponent, DxoRangeSelectorMarkerLabelComponent, DxoRangeSelectorMarkerLabelModule, DxoRangeSelectorMarkerModule, DxoRangeSelectorMaxRangeComponent, DxoRangeSelectorMaxRangeModule, DxoRangeSelectorMinRangeComponent, DxoRangeSelectorMinRangeModule, DxoRangeSelectorMinorTickComponent, DxoRangeSelectorMinorTickIntervalComponent, DxoRangeSelectorMinorTickIntervalModule, DxoRangeSelectorMinorTickModule, DxoRangeSelectorPointBorderComponent, DxoRangeSelectorPointBorderModule, DxoRangeSelectorPointComponent, DxoRangeSelectorPointHoverStyleComponent, DxoRangeSelectorPointHoverStyleModule, DxoRangeSelectorPointImageComponent, DxoRangeSelectorPointImageModule, DxoRangeSelectorPointModule, DxoRangeSelectorPointSelectionStyleComponent, DxoRangeSelectorPointSelectionStyleModule, DxoRangeSelectorReductionComponent, DxoRangeSelectorReductionModule, DxoRangeSelectorScaleComponent, DxoRangeSelectorScaleLabelComponent, DxoRangeSelectorScaleLabelModule, DxoRangeSelectorScaleModule, DxoRangeSelectorSelectionStyleComponent, DxoRangeSelectorSelectionStyleModule, DxoRangeSelectorSeriesBorderComponent, DxoRangeSelectorSeriesBorderModule, DxoRangeSelectorSeriesTemplateComponent, DxoRangeSelectorSeriesTemplateModule, DxoRangeSelectorShutterComponent, DxoRangeSelectorShutterModule, DxoRangeSelectorSizeComponent, DxoRangeSelectorSizeModule, DxoRangeSelectorSliderHandleComponent, DxoRangeSelectorSliderHandleModule, DxoRangeSelectorSliderMarkerComponent, DxoRangeSelectorSliderMarkerModule, DxoRangeSelectorSubtitleComponent, DxoRangeSelectorSubtitleModule, DxoRangeSelectorTickComponent, DxoRangeSelectorTickIntervalComponent, DxoRangeSelectorTickIntervalModule, DxoRangeSelectorTickModule, DxoRangeSelectorTitleComponent, DxoRangeSelectorTitleModule, DxoRangeSelectorUrlComponent, DxoRangeSelectorUrlModule, DxoRangeSelectorValueAxisComponent, DxoRangeSelectorValueAxisModule, DxoRangeSelectorValueComponent, DxoRangeSelectorValueErrorBarComponent, DxoRangeSelectorValueErrorBarModule, DxoRangeSelectorValueModule, DxoRangeSelectorWidthComponent, DxoRangeSelectorWidthModule };
//# sourceMappingURL=index.d.ts.map
