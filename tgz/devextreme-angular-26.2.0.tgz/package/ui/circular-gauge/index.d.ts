import * as i0 from '@angular/core';
import { OnDestroy, OnChanges, DoCheck, QueryList, EventEmitter, ElementRef, NgZone, TransferState, SimpleChanges } from '@angular/core';
import { AnimationEaseMode, Font, ChartsColor, Palette, PaletteExtensionMode, LabelOverlap, Theme, TextOverflow, WordWrap, DashStyle } from 'devextreme/common/charts';
import { ExportFormat, HorizontalAlignment, VerticalEdge } from 'devextreme/common';
import DxCircularGauge, { CircularGaugeElementOrientation, CircularGaugeLabelOverlap, DisposingEvent, DrawnEvent, ExportedEvent, ExportingEvent, FileSavingEvent, IncidentOccurredEvent, InitializedEvent, OptionChangedEvent, TooltipHiddenEvent, TooltipShownEvent } from 'devextreme/viz/circular_gauge';
import { Format } from 'devextreme/common/core/localization';
import { GaugeIndicator } from 'devextreme/viz/gauges/base_gauge';
import * as i3 from 'devextreme-angular/core';
import { DxComponent, CollectionNestedOption, DxTemplateHost, WatcherHelper, IterableDifferHelper, NestedOptionHost } from 'devextreme-angular/core';
import * as i1 from 'devextreme-angular/ui/nested';
import * as i2 from 'devextreme-angular/ui/circular-gauge/nested';
export * from 'devextreme-angular/ui/circular-gauge/nested';
import * as circular_gauge_types from 'devextreme/viz/circular_gauge_types';
export { circular_gauge_types as DxCircularGaugeTypes };

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

/**
 * [descr:dxCircularGauge]

 */
declare class DxCircularGaugeComponent extends DxComponent implements OnDestroy, OnChanges, DoCheck {
    private _watcherHelper;
    private _idh;
    set _rangesContentChildren(value: QueryList<CollectionNestedOption>);
    instance: DxCircularGauge;
    /**
     * [descr:BaseGaugeOptions.animation]
    
     */
    get animation(): {
        duration?: number;
        easing?: AnimationEaseMode;
        enabled?: boolean;
    };
    set animation(value: {
        duration?: number;
        easing?: AnimationEaseMode;
        enabled?: boolean;
    });
    /**
     * [descr:dxCircularGaugeOptions.centerTemplate]
    
     */
    get centerTemplate(): any;
    set centerTemplate(value: any);
    /**
     * [descr:BaseGaugeOptions.containerBackgroundColor]
    
     */
    get containerBackgroundColor(): string;
    set containerBackgroundColor(value: string);
    /**
     * [descr:BaseWidgetOptions.disabled]
    
     */
    get disabled(): boolean;
    set disabled(value: boolean);
    /**
     * [descr:DOMComponentOptions.elementAttr]
    
     */
    get elementAttr(): Record<string, any>;
    set elementAttr(value: Record<string, any>);
    /**
     * [descr:BaseWidgetOptions.encodeHtml]
    
     */
    get encodeHtml(): boolean;
    set encodeHtml(value: boolean);
    /**
     * [descr:BaseWidgetOptions.export]
    
     */
    get export(): {
        backgroundColor?: string;
        enabled?: boolean;
        fileName?: string;
        formats?: Array<ExportFormat>;
        margin?: number;
        printingEnabled?: boolean;
        svgToCanvas?: ((svg: any, canvas: any) => any) | undefined;
    };
    set export(value: {
        backgroundColor?: string;
        enabled?: boolean;
        fileName?: string;
        formats?: Array<ExportFormat>;
        margin?: number;
        printingEnabled?: boolean;
        svgToCanvas?: ((svg: any, canvas: any) => any) | undefined;
    });
    /**
     * [descr:dxCircularGaugeOptions.geometry]
    
     */
    get geometry(): {
        endAngle?: number;
        startAngle?: number;
    };
    set geometry(value: {
        endAngle?: number;
        startAngle?: number;
    });
    /**
     * [descr:BaseGaugeOptions.loadingIndicator]
    
     */
    get loadingIndicator(): {
        backgroundColor?: string;
        font?: Font;
        show?: boolean;
        text?: string;
    };
    set loadingIndicator(value: {
        backgroundColor?: string;
        font?: Font;
        show?: boolean;
        text?: string;
    });
    /**
     * [descr:BaseWidgetOptions.margin]
    
     */
    get margin(): {
        bottom?: number;
        left?: number;
        right?: number;
        top?: number;
    };
    set margin(value: {
        bottom?: number;
        left?: number;
        right?: number;
        top?: number;
    });
    /**
     * [descr:BaseWidgetOptions.pathModified]
    
     */
    get pathModified(): boolean;
    set pathModified(value: boolean);
    /**
     * [descr:dxCircularGaugeOptions.rangeContainer]
    
     */
    get rangeContainer(): {
        backgroundColor?: ChartsColor | string;
        offset?: number;
        orientation?: CircularGaugeElementOrientation;
        palette?: Array<string> | Palette;
        paletteExtensionMode?: PaletteExtensionMode;
        ranges?: {
            color?: ChartsColor | string;
            endValue?: number;
            startValue?: number;
        }[];
        width?: number;
    };
    set rangeContainer(value: {
        backgroundColor?: ChartsColor | string;
        offset?: number;
        orientation?: CircularGaugeElementOrientation;
        palette?: Array<string> | Palette;
        paletteExtensionMode?: PaletteExtensionMode;
        ranges?: {
            color?: ChartsColor | string;
            endValue?: number;
            startValue?: number;
        }[];
        width?: number;
    });
    /**
     * [descr:BaseWidgetOptions.redrawOnResize]
    
     */
    get redrawOnResize(): boolean;
    set redrawOnResize(value: boolean);
    /**
     * [descr:BaseWidgetOptions.rtlEnabled]
    
     */
    get rtlEnabled(): boolean;
    set rtlEnabled(value: boolean);
    /**
     * [descr:dxCircularGaugeOptions.scale]
    
     */
    get scale(): {
        allowDecimals?: boolean | undefined;
        customMinorTicks?: Array<number> | undefined;
        customTicks?: Array<number> | undefined;
        endValue?: number;
        label?: {
            customizeText?: ((scaleValue: {
                value: number;
                valueText: string;
            }) => string);
            font?: Font;
            format?: Format | undefined;
            hideFirstOrLast?: CircularGaugeLabelOverlap;
            indentFromTick?: number;
            overlappingBehavior?: LabelOverlap;
            useRangeColors?: boolean;
            visible?: boolean;
        };
        minorTick?: {
            color?: string;
            length?: number;
            opacity?: number;
            visible?: boolean;
            width?: number;
        };
        minorTickInterval?: number | undefined;
        orientation?: CircularGaugeElementOrientation;
        scaleDivisionFactor?: number;
        startValue?: number;
        tick?: {
            color?: string;
            length?: number;
            opacity?: number;
            visible?: boolean;
            width?: number;
        };
        tickInterval?: number | undefined;
    };
    set scale(value: {
        allowDecimals?: boolean | undefined;
        customMinorTicks?: Array<number> | undefined;
        customTicks?: Array<number> | undefined;
        endValue?: number;
        label?: {
            customizeText?: ((scaleValue: {
                value: number;
                valueText: string;
            }) => string);
            font?: Font;
            format?: Format | undefined;
            hideFirstOrLast?: CircularGaugeLabelOverlap;
            indentFromTick?: number;
            overlappingBehavior?: LabelOverlap;
            useRangeColors?: boolean;
            visible?: boolean;
        };
        minorTick?: {
            color?: string;
            length?: number;
            opacity?: number;
            visible?: boolean;
            width?: number;
        };
        minorTickInterval?: number | undefined;
        orientation?: CircularGaugeElementOrientation;
        scaleDivisionFactor?: number;
        startValue?: number;
        tick?: {
            color?: string;
            length?: number;
            opacity?: number;
            visible?: boolean;
            width?: number;
        };
        tickInterval?: number | undefined;
    });
    /**
     * [descr:BaseWidgetOptions.size]
    
     */
    get size(): {
        height?: number | undefined;
        width?: number | undefined;
    };
    set size(value: {
        height?: number | undefined;
        width?: number | undefined;
    });
    /**
     * [descr:dxCircularGaugeOptions.subvalueIndicator]
    
     */
    get subvalueIndicator(): GaugeIndicator | {
        type?: "rectangleNeedle" | "triangleNeedle" | "twoColorNeedle" | "rangeBar" | "triangleMarker" | "textCloud";
    };
    set subvalueIndicator(value: GaugeIndicator | {
        type?: "rectangleNeedle" | "triangleNeedle" | "twoColorNeedle" | "rangeBar" | "triangleMarker" | "textCloud";
    });
    /**
     * [descr:BaseGaugeOptions.subvalues]
    
     */
    get subvalues(): Array<number> | undefined;
    set subvalues(value: Array<number> | undefined);
    /**
     * [descr:BaseWidgetOptions.theme]
    
     */
    get theme(): Theme;
    set theme(value: Theme);
    /**
     * [descr:BaseWidgetOptions.title]
    
     */
    get title(): string | {
        font?: Font;
        horizontalAlignment?: HorizontalAlignment;
        margin?: number | {
            bottom?: number;
            left?: number;
            right?: number;
            top?: number;
        };
        placeholderSize?: number | undefined;
        subtitle?: string | {
            font?: Font;
            offset?: number;
            text?: string | undefined;
            textOverflow?: TextOverflow;
            wordWrap?: WordWrap;
        };
        text?: string | undefined;
        textOverflow?: TextOverflow;
        verticalAlignment?: VerticalEdge;
        wordWrap?: WordWrap;
    };
    set title(value: string | {
        font?: Font;
        horizontalAlignment?: HorizontalAlignment;
        margin?: number | {
            bottom?: number;
            left?: number;
            right?: number;
            top?: number;
        };
        placeholderSize?: number | undefined;
        subtitle?: string | {
            font?: Font;
            offset?: number;
            text?: string | undefined;
            textOverflow?: TextOverflow;
            wordWrap?: WordWrap;
        };
        text?: string | undefined;
        textOverflow?: TextOverflow;
        verticalAlignment?: VerticalEdge;
        wordWrap?: WordWrap;
    });
    /**
     * [descr:BaseGaugeOptions.tooltip]
    
     */
    get tooltip(): {
        arrowLength?: number;
        border?: {
            color?: string;
            dashStyle?: DashStyle;
            opacity?: number | undefined;
            visible?: boolean;
            width?: number;
        };
        color?: string;
        container?: any | string | undefined;
        contentTemplate?: any;
        cornerRadius?: number;
        customizeTooltip?: ((scaleValue: {
            value: number;
            valueText: string;
        }) => Record<string, any>) | undefined;
        enabled?: boolean;
        font?: Font;
        format?: Format | undefined;
        interactive?: boolean;
        opacity?: number | undefined;
        paddingLeftRight?: number;
        paddingTopBottom?: number;
        shadow?: {
            blur?: number;
            color?: string;
            offsetX?: number;
            offsetY?: number;
            opacity?: number;
        };
        zIndex?: number | undefined;
    };
    set tooltip(value: {
        arrowLength?: number;
        border?: {
            color?: string;
            dashStyle?: DashStyle;
            opacity?: number | undefined;
            visible?: boolean;
            width?: number;
        };
        color?: string;
        container?: any | string | undefined;
        contentTemplate?: any;
        cornerRadius?: number;
        customizeTooltip?: ((scaleValue: {
            value: number;
            valueText: string;
        }) => Record<string, any>) | undefined;
        enabled?: boolean;
        font?: Font;
        format?: Format | undefined;
        interactive?: boolean;
        opacity?: number | undefined;
        paddingLeftRight?: number;
        paddingTopBottom?: number;
        shadow?: {
            blur?: number;
            color?: string;
            offsetX?: number;
            offsetY?: number;
            opacity?: number;
        };
        zIndex?: number | undefined;
    });
    /**
     * [descr:BaseGaugeOptions.value]
    
     */
    get value(): number | undefined;
    set value(value: number | undefined);
    /**
     * [descr:dxCircularGaugeOptions.valueIndicator]
    
     */
    get valueIndicator(): GaugeIndicator | {
        type?: "rectangleNeedle" | "triangleNeedle" | "twoColorNeedle" | "rangeBar" | "triangleMarker" | "textCloud";
    };
    set valueIndicator(value: GaugeIndicator | {
        type?: "rectangleNeedle" | "triangleNeedle" | "twoColorNeedle" | "rangeBar" | "triangleMarker" | "textCloud";
    });
    /**
    
     * [descr:dxCircularGaugeOptions.onDisposing]
    
    
     */
    onDisposing: EventEmitter<DisposingEvent>;
    /**
    
     * [descr:dxCircularGaugeOptions.onDrawn]
    
    
     */
    onDrawn: EventEmitter<DrawnEvent>;
    /**
    
     * [descr:dxCircularGaugeOptions.onExported]
    
    
     */
    onExported: EventEmitter<ExportedEvent>;
    /**
    
     * [descr:dxCircularGaugeOptions.onExporting]
    
    
     */
    onExporting: EventEmitter<ExportingEvent>;
    /**
    
     * [descr:dxCircularGaugeOptions.onFileSaving]
    
    
     */
    onFileSaving: EventEmitter<FileSavingEvent>;
    /**
    
     * [descr:dxCircularGaugeOptions.onIncidentOccurred]
    
    
     */
    onIncidentOccurred: EventEmitter<IncidentOccurredEvent>;
    /**
    
     * [descr:dxCircularGaugeOptions.onInitialized]
    
    
     */
    onInitialized: EventEmitter<InitializedEvent>;
    /**
    
     * [descr:dxCircularGaugeOptions.onOptionChanged]
    
    
     */
    onOptionChanged: EventEmitter<OptionChangedEvent>;
    /**
    
     * [descr:dxCircularGaugeOptions.onTooltipHidden]
    
    
     */
    onTooltipHidden: EventEmitter<TooltipHiddenEvent>;
    /**
    
     * [descr:dxCircularGaugeOptions.onTooltipShown]
    
    
     */
    onTooltipShown: EventEmitter<TooltipShownEvent>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    animationChange: EventEmitter<{
        duration?: number;
        easing?: AnimationEaseMode;
        enabled?: boolean;
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    centerTemplateChange: EventEmitter<any>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    containerBackgroundColorChange: EventEmitter<string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    disabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    elementAttrChange: EventEmitter<Record<string, any>>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    encodeHtmlChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    exportChange: EventEmitter<{
        backgroundColor?: string;
        enabled?: boolean;
        fileName?: string;
        formats?: Array<ExportFormat>;
        margin?: number;
        printingEnabled?: boolean;
        svgToCanvas?: ((svg: any, canvas: any) => any) | undefined;
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    geometryChange: EventEmitter<{
        endAngle?: number;
        startAngle?: number;
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    loadingIndicatorChange: EventEmitter<{
        backgroundColor?: string;
        font?: Font;
        show?: boolean;
        text?: string;
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    marginChange: EventEmitter<{
        bottom?: number;
        left?: number;
        right?: number;
        top?: number;
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    pathModifiedChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    rangeContainerChange: EventEmitter<{
        backgroundColor?: ChartsColor | string;
        offset?: number;
        orientation?: CircularGaugeElementOrientation;
        palette?: Array<string> | Palette;
        paletteExtensionMode?: PaletteExtensionMode;
        ranges?: {
            color?: ChartsColor | string;
            endValue?: number;
            startValue?: number;
        }[];
        width?: number;
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    redrawOnResizeChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    rtlEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    scaleChange: EventEmitter<{
        allowDecimals?: boolean | undefined;
        customMinorTicks?: Array<number> | undefined;
        customTicks?: Array<number> | undefined;
        endValue?: number;
        label?: {
            customizeText?: ((scaleValue: {
                value: number;
                valueText: string;
            }) => string);
            font?: Font;
            format?: Format | undefined;
            hideFirstOrLast?: CircularGaugeLabelOverlap;
            indentFromTick?: number;
            overlappingBehavior?: LabelOverlap;
            useRangeColors?: boolean;
            visible?: boolean;
        };
        minorTick?: {
            color?: string;
            length?: number;
            opacity?: number;
            visible?: boolean;
            width?: number;
        };
        minorTickInterval?: number | undefined;
        orientation?: CircularGaugeElementOrientation;
        scaleDivisionFactor?: number;
        startValue?: number;
        tick?: {
            color?: string;
            length?: number;
            opacity?: number;
            visible?: boolean;
            width?: number;
        };
        tickInterval?: number | undefined;
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    sizeChange: EventEmitter<{
        height?: number | undefined;
        width?: number | undefined;
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    subvalueIndicatorChange: EventEmitter<GaugeIndicator | {
        type?: "rectangleNeedle" | "triangleNeedle" | "twoColorNeedle" | "rangeBar" | "triangleMarker" | "textCloud";
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    subvaluesChange: EventEmitter<Array<number> | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    themeChange: EventEmitter<Theme>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    titleChange: EventEmitter<string | {
        font?: Font;
        horizontalAlignment?: HorizontalAlignment;
        margin?: number | {
            bottom?: number;
            left?: number;
            right?: number;
            top?: number;
        };
        placeholderSize?: number | undefined;
        subtitle?: string | {
            font?: Font;
            offset?: number;
            text?: string | undefined;
            textOverflow?: TextOverflow;
            wordWrap?: WordWrap;
        };
        text?: string | undefined;
        textOverflow?: TextOverflow;
        verticalAlignment?: VerticalEdge;
        wordWrap?: WordWrap;
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    tooltipChange: EventEmitter<{
        arrowLength?: number;
        border?: {
            color?: string;
            dashStyle?: DashStyle;
            opacity?: number | undefined;
            visible?: boolean;
            width?: number;
        };
        color?: string;
        container?: any | string | undefined;
        contentTemplate?: any;
        cornerRadius?: number;
        customizeTooltip?: ((scaleValue: {
            value: number;
            valueText: string;
        }) => Record<string, any>) | undefined;
        enabled?: boolean;
        font?: Font;
        format?: Format | undefined;
        interactive?: boolean;
        opacity?: number | undefined;
        paddingLeftRight?: number;
        paddingTopBottom?: number;
        shadow?: {
            blur?: number;
            color?: string;
            offsetX?: number;
            offsetY?: number;
            opacity?: number;
        };
        zIndex?: number | undefined;
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    valueChange: EventEmitter<number | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    valueIndicatorChange: EventEmitter<GaugeIndicator | {
        type?: "rectangleNeedle" | "triangleNeedle" | "twoColorNeedle" | "rangeBar" | "triangleMarker" | "textCloud";
    }>;
    constructor(elementRef: ElementRef, ngZone: NgZone, templateHost: DxTemplateHost, _watcherHelper: WatcherHelper, _idh: IterableDifferHelper, optionHost: NestedOptionHost, transferState: TransferState, platformId: any);
    protected _createInstance(element: any, options: any): DxCircularGauge;
    ngOnDestroy(): void;
    ngOnChanges(changes: SimpleChanges): void;
    setupChanges(prop: string, changes: SimpleChanges): void;
    ngDoCheck(): void;
    _setOption(name: string, value: any): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxCircularGaugeComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxCircularGaugeComponent, "dx-circular-gauge", never, { "animation": { "alias": "animation"; "required": false; }; "centerTemplate": { "alias": "centerTemplate"; "required": false; }; "containerBackgroundColor": { "alias": "containerBackgroundColor"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "elementAttr": { "alias": "elementAttr"; "required": false; }; "encodeHtml": { "alias": "encodeHtml"; "required": false; }; "export": { "alias": "export"; "required": false; }; "geometry": { "alias": "geometry"; "required": false; }; "loadingIndicator": { "alias": "loadingIndicator"; "required": false; }; "margin": { "alias": "margin"; "required": false; }; "pathModified": { "alias": "pathModified"; "required": false; }; "rangeContainer": { "alias": "rangeContainer"; "required": false; }; "redrawOnResize": { "alias": "redrawOnResize"; "required": false; }; "rtlEnabled": { "alias": "rtlEnabled"; "required": false; }; "scale": { "alias": "scale"; "required": false; }; "size": { "alias": "size"; "required": false; }; "subvalueIndicator": { "alias": "subvalueIndicator"; "required": false; }; "subvalues": { "alias": "subvalues"; "required": false; }; "theme": { "alias": "theme"; "required": false; }; "title": { "alias": "title"; "required": false; }; "tooltip": { "alias": "tooltip"; "required": false; }; "value": { "alias": "value"; "required": false; }; "valueIndicator": { "alias": "valueIndicator"; "required": false; }; }, { "onDisposing": "onDisposing"; "onDrawn": "onDrawn"; "onExported": "onExported"; "onExporting": "onExporting"; "onFileSaving": "onFileSaving"; "onIncidentOccurred": "onIncidentOccurred"; "onInitialized": "onInitialized"; "onOptionChanged": "onOptionChanged"; "onTooltipHidden": "onTooltipHidden"; "onTooltipShown": "onTooltipShown"; "animationChange": "animationChange"; "centerTemplateChange": "centerTemplateChange"; "containerBackgroundColorChange": "containerBackgroundColorChange"; "disabledChange": "disabledChange"; "elementAttrChange": "elementAttrChange"; "encodeHtmlChange": "encodeHtmlChange"; "exportChange": "exportChange"; "geometryChange": "geometryChange"; "loadingIndicatorChange": "loadingIndicatorChange"; "marginChange": "marginChange"; "pathModifiedChange": "pathModifiedChange"; "rangeContainerChange": "rangeContainerChange"; "redrawOnResizeChange": "redrawOnResizeChange"; "rtlEnabledChange": "rtlEnabledChange"; "scaleChange": "scaleChange"; "sizeChange": "sizeChange"; "subvalueIndicatorChange": "subvalueIndicatorChange"; "subvaluesChange": "subvaluesChange"; "themeChange": "themeChange"; "titleChange": "titleChange"; "tooltipChange": "tooltipChange"; "valueChange": "valueChange"; "valueIndicatorChange": "valueIndicatorChange"; }, ["_rangesContentChildren"], never, true, never>;
}
declare class DxCircularGaugeModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxCircularGaugeModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxCircularGaugeModule, never, [typeof DxCircularGaugeComponent, typeof i1.DxoAnimationModule, typeof i1.DxoExportModule, typeof i1.DxoGeometryModule, typeof i1.DxoLoadingIndicatorModule, typeof i1.DxoFontModule, typeof i1.DxoMarginModule, typeof i1.DxoRangeContainerModule, typeof i1.DxoBackgroundColorModule, typeof i1.DxiRangeModule, typeof i1.DxoColorModule, typeof i1.DxoScaleModule, typeof i1.DxoLabelModule, typeof i1.DxoFormatModule, typeof i1.DxoMinorTickModule, typeof i1.DxoTickModule, typeof i1.DxoSizeModule, typeof i1.DxoSubvalueIndicatorModule, typeof i1.DxoTextModule, typeof i1.DxoTitleModule, typeof i1.DxoSubtitleModule, typeof i1.DxoTooltipModule, typeof i1.DxoBorderModule, typeof i1.DxoShadowModule, typeof i1.DxoValueIndicatorModule, typeof i2.DxoCircularGaugeAnimationModule, typeof i2.DxoCircularGaugeBackgroundColorModule, typeof i2.DxoCircularGaugeBorderModule, typeof i2.DxoCircularGaugeColorModule, typeof i2.DxoCircularGaugeExportModule, typeof i2.DxoCircularGaugeFontModule, typeof i2.DxoCircularGaugeFormatModule, typeof i2.DxoCircularGaugeGeometryModule, typeof i2.DxoCircularGaugeLabelModule, typeof i2.DxoCircularGaugeLoadingIndicatorModule, typeof i2.DxoCircularGaugeMarginModule, typeof i2.DxoCircularGaugeMinorTickModule, typeof i2.DxiCircularGaugeRangeModule, typeof i2.DxoCircularGaugeRangeContainerModule, typeof i2.DxoCircularGaugeScaleModule, typeof i2.DxoCircularGaugeShadowModule, typeof i2.DxoCircularGaugeSizeModule, typeof i2.DxoCircularGaugeSubtitleModule, typeof i2.DxoCircularGaugeSubvalueIndicatorModule, typeof i2.DxoCircularGaugeTextModule, typeof i2.DxoCircularGaugeTickModule, typeof i2.DxoCircularGaugeTitleModule, typeof i2.DxoCircularGaugeTooltipModule, typeof i2.DxoCircularGaugeValueIndicatorModule, typeof i3.DxIntegrationModule, typeof i3.DxTemplateModule], [typeof DxCircularGaugeComponent, typeof i1.DxoAnimationModule, typeof i1.DxoExportModule, typeof i1.DxoGeometryModule, typeof i1.DxoLoadingIndicatorModule, typeof i1.DxoFontModule, typeof i1.DxoMarginModule, typeof i1.DxoRangeContainerModule, typeof i1.DxoBackgroundColorModule, typeof i1.DxiRangeModule, typeof i1.DxoColorModule, typeof i1.DxoScaleModule, typeof i1.DxoLabelModule, typeof i1.DxoFormatModule, typeof i1.DxoMinorTickModule, typeof i1.DxoTickModule, typeof i1.DxoSizeModule, typeof i1.DxoSubvalueIndicatorModule, typeof i1.DxoTextModule, typeof i1.DxoTitleModule, typeof i1.DxoSubtitleModule, typeof i1.DxoTooltipModule, typeof i1.DxoBorderModule, typeof i1.DxoShadowModule, typeof i1.DxoValueIndicatorModule, typeof i2.DxoCircularGaugeAnimationModule, typeof i2.DxoCircularGaugeBackgroundColorModule, typeof i2.DxoCircularGaugeBorderModule, typeof i2.DxoCircularGaugeColorModule, typeof i2.DxoCircularGaugeExportModule, typeof i2.DxoCircularGaugeFontModule, typeof i2.DxoCircularGaugeFormatModule, typeof i2.DxoCircularGaugeGeometryModule, typeof i2.DxoCircularGaugeLabelModule, typeof i2.DxoCircularGaugeLoadingIndicatorModule, typeof i2.DxoCircularGaugeMarginModule, typeof i2.DxoCircularGaugeMinorTickModule, typeof i2.DxiCircularGaugeRangeModule, typeof i2.DxoCircularGaugeRangeContainerModule, typeof i2.DxoCircularGaugeScaleModule, typeof i2.DxoCircularGaugeShadowModule, typeof i2.DxoCircularGaugeSizeModule, typeof i2.DxoCircularGaugeSubtitleModule, typeof i2.DxoCircularGaugeSubvalueIndicatorModule, typeof i2.DxoCircularGaugeTextModule, typeof i2.DxoCircularGaugeTickModule, typeof i2.DxoCircularGaugeTitleModule, typeof i2.DxoCircularGaugeTooltipModule, typeof i2.DxoCircularGaugeValueIndicatorModule, typeof i3.DxTemplateModule]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxCircularGaugeModule>;
}

export { DxCircularGaugeComponent, DxCircularGaugeModule };
//# sourceMappingURL=index.d.ts.map
