import * as i0 from '@angular/core';
import { OnDestroy, OnInit, EventEmitter, QueryList } from '@angular/core';
import { AnimationEaseMode, DashStyle, Font, LabelOverlap, ChartsColor, Palette, PaletteExtensionMode, TextOverflow, WordWrap } from 'devextreme/common/charts';
import { NestedOption, NestedOptionHost, CollectionNestedOption } from 'devextreme-angular/core';
import { ExportFormat, Format, HorizontalEdge, VerticalEdge, HorizontalAlignment } from 'devextreme/common';
import { Format as Format$1 } from 'devextreme/common/core/localization';
import { CircularGaugeLabelOverlap, CircularGaugeElementOrientation } from 'devextreme/viz/circular_gauge';

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoCircularGaugeAnimationComponent extends NestedOption implements OnDestroy, OnInit {
    get duration(): number;
    set duration(value: number);
    get easing(): AnimationEaseMode;
    set easing(value: AnimationEaseMode);
    get enabled(): boolean;
    set enabled(value: boolean);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoCircularGaugeAnimationComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoCircularGaugeAnimationComponent, "dxo-circular-gauge-animation", never, { "duration": { "alias": "duration"; "required": false; }; "easing": { "alias": "easing"; "required": false; }; "enabled": { "alias": "enabled"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoCircularGaugeAnimationModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoCircularGaugeAnimationModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoCircularGaugeAnimationModule, never, [typeof DxoCircularGaugeAnimationComponent], [typeof DxoCircularGaugeAnimationComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoCircularGaugeAnimationModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoCircularGaugeBackgroundColorComponent extends NestedOption implements OnDestroy, OnInit {
    get base(): string | undefined;
    set base(value: string | undefined);
    get fillId(): string | undefined;
    set fillId(value: string | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoCircularGaugeBackgroundColorComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoCircularGaugeBackgroundColorComponent, "dxo-circular-gauge-background-color", never, { "base": { "alias": "base"; "required": false; }; "fillId": { "alias": "fillId"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoCircularGaugeBackgroundColorModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoCircularGaugeBackgroundColorModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoCircularGaugeBackgroundColorModule, never, [typeof DxoCircularGaugeBackgroundColorComponent], [typeof DxoCircularGaugeBackgroundColorComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoCircularGaugeBackgroundColorModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoCircularGaugeBorderComponent extends NestedOption implements OnDestroy, OnInit {
    get color(): string;
    set color(value: string);
    get dashStyle(): DashStyle;
    set dashStyle(value: DashStyle);
    get opacity(): number | undefined;
    set opacity(value: number | undefined);
    get visible(): boolean;
    set visible(value: boolean);
    get width(): number;
    set width(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoCircularGaugeBorderComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoCircularGaugeBorderComponent, "dxo-circular-gauge-border", never, { "color": { "alias": "color"; "required": false; }; "dashStyle": { "alias": "dashStyle"; "required": false; }; "opacity": { "alias": "opacity"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoCircularGaugeBorderModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoCircularGaugeBorderModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoCircularGaugeBorderModule, never, [typeof DxoCircularGaugeBorderComponent], [typeof DxoCircularGaugeBorderComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoCircularGaugeBorderModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoCircularGaugeColorComponent extends NestedOption implements OnDestroy, OnInit {
    get base(): string | undefined;
    set base(value: string | undefined);
    get fillId(): string | undefined;
    set fillId(value: string | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoCircularGaugeColorComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoCircularGaugeColorComponent, "dxo-circular-gauge-color", never, { "base": { "alias": "base"; "required": false; }; "fillId": { "alias": "fillId"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoCircularGaugeColorModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoCircularGaugeColorModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoCircularGaugeColorModule, never, [typeof DxoCircularGaugeColorComponent], [typeof DxoCircularGaugeColorComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoCircularGaugeColorModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoCircularGaugeExportComponent extends NestedOption implements OnDestroy, OnInit {
    get backgroundColor(): string;
    set backgroundColor(value: string);
    get enabled(): boolean;
    set enabled(value: boolean);
    get fileName(): string;
    set fileName(value: string);
    get formats(): Array<ExportFormat>;
    set formats(value: Array<ExportFormat>);
    get margin(): number;
    set margin(value: number);
    get printingEnabled(): boolean;
    set printingEnabled(value: boolean);
    get svgToCanvas(): ((svg: any, canvas: any) => any) | undefined;
    set svgToCanvas(value: ((svg: any, canvas: any) => any) | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoCircularGaugeExportComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoCircularGaugeExportComponent, "dxo-circular-gauge-export", never, { "backgroundColor": { "alias": "backgroundColor"; "required": false; }; "enabled": { "alias": "enabled"; "required": false; }; "fileName": { "alias": "fileName"; "required": false; }; "formats": { "alias": "formats"; "required": false; }; "margin": { "alias": "margin"; "required": false; }; "printingEnabled": { "alias": "printingEnabled"; "required": false; }; "svgToCanvas": { "alias": "svgToCanvas"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoCircularGaugeExportModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoCircularGaugeExportModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoCircularGaugeExportModule, never, [typeof DxoCircularGaugeExportComponent], [typeof DxoCircularGaugeExportComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoCircularGaugeExportModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoCircularGaugeFontComponent extends NestedOption implements OnDestroy, OnInit {
    get color(): string;
    set color(value: string);
    get family(): string;
    set family(value: string);
    get opacity(): number;
    set opacity(value: number);
    get size(): number | string;
    set size(value: number | string);
    get weight(): number;
    set weight(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoCircularGaugeFontComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoCircularGaugeFontComponent, "dxo-circular-gauge-font", never, { "color": { "alias": "color"; "required": false; }; "family": { "alias": "family"; "required": false; }; "opacity": { "alias": "opacity"; "required": false; }; "size": { "alias": "size"; "required": false; }; "weight": { "alias": "weight"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoCircularGaugeFontModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoCircularGaugeFontModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoCircularGaugeFontModule, never, [typeof DxoCircularGaugeFontComponent], [typeof DxoCircularGaugeFontComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoCircularGaugeFontModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoCircularGaugeFormatComponent extends NestedOption implements OnDestroy, OnInit {
    get currency(): string;
    set currency(value: string);
    get formatter(): ((value: number | Date) => string);
    set formatter(value: ((value: number | Date) => string));
    get parser(): ((value: string) => number | Date);
    set parser(value: ((value: string) => number | Date));
    get precision(): number;
    set precision(value: number);
    get type(): Format | string;
    set type(value: Format | string);
    get useCurrencyAccountingStyle(): boolean;
    set useCurrencyAccountingStyle(value: boolean);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoCircularGaugeFormatComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoCircularGaugeFormatComponent, "dxo-circular-gauge-format", never, { "currency": { "alias": "currency"; "required": false; }; "formatter": { "alias": "formatter"; "required": false; }; "parser": { "alias": "parser"; "required": false; }; "precision": { "alias": "precision"; "required": false; }; "type": { "alias": "type"; "required": false; }; "useCurrencyAccountingStyle": { "alias": "useCurrencyAccountingStyle"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoCircularGaugeFormatModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoCircularGaugeFormatModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoCircularGaugeFormatModule, never, [typeof DxoCircularGaugeFormatComponent], [typeof DxoCircularGaugeFormatComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoCircularGaugeFormatModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoCircularGaugeGeometryComponent extends NestedOption implements OnDestroy, OnInit {
    get endAngle(): number;
    set endAngle(value: number);
    get startAngle(): number;
    set startAngle(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoCircularGaugeGeometryComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoCircularGaugeGeometryComponent, "dxo-circular-gauge-geometry", never, { "endAngle": { "alias": "endAngle"; "required": false; }; "startAngle": { "alias": "startAngle"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoCircularGaugeGeometryModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoCircularGaugeGeometryModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoCircularGaugeGeometryModule, never, [typeof DxoCircularGaugeGeometryComponent], [typeof DxoCircularGaugeGeometryComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoCircularGaugeGeometryModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoCircularGaugeLabelComponent extends NestedOption implements OnDestroy, OnInit {
    get customizeText(): ((scaleValue: {
        value: number;
        valueText: string;
    }) => string);
    set customizeText(value: ((scaleValue: {
        value: number;
        valueText: string;
    }) => string));
    get font(): Font;
    set font(value: Font);
    get format(): Format$1 | undefined;
    set format(value: Format$1 | undefined);
    get hideFirstOrLast(): CircularGaugeLabelOverlap;
    set hideFirstOrLast(value: CircularGaugeLabelOverlap);
    get indentFromTick(): number;
    set indentFromTick(value: number);
    get overlappingBehavior(): LabelOverlap;
    set overlappingBehavior(value: LabelOverlap);
    get useRangeColors(): boolean;
    set useRangeColors(value: boolean);
    get visible(): boolean;
    set visible(value: boolean);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoCircularGaugeLabelComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoCircularGaugeLabelComponent, "dxo-circular-gauge-label", never, { "customizeText": { "alias": "customizeText"; "required": false; }; "font": { "alias": "font"; "required": false; }; "format": { "alias": "format"; "required": false; }; "hideFirstOrLast": { "alias": "hideFirstOrLast"; "required": false; }; "indentFromTick": { "alias": "indentFromTick"; "required": false; }; "overlappingBehavior": { "alias": "overlappingBehavior"; "required": false; }; "useRangeColors": { "alias": "useRangeColors"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoCircularGaugeLabelModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoCircularGaugeLabelModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoCircularGaugeLabelModule, never, [typeof DxoCircularGaugeLabelComponent], [typeof DxoCircularGaugeLabelComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoCircularGaugeLabelModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoCircularGaugeLoadingIndicatorComponent extends NestedOption implements OnDestroy, OnInit {
    get backgroundColor(): string;
    set backgroundColor(value: string);
    get font(): Font;
    set font(value: Font);
    get show(): boolean;
    set show(value: boolean);
    get text(): string;
    set text(value: string);
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    showChange: EventEmitter<boolean>;
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoCircularGaugeLoadingIndicatorComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoCircularGaugeLoadingIndicatorComponent, "dxo-circular-gauge-loading-indicator", never, { "backgroundColor": { "alias": "backgroundColor"; "required": false; }; "font": { "alias": "font"; "required": false; }; "show": { "alias": "show"; "required": false; }; "text": { "alias": "text"; "required": false; }; }, { "showChange": "showChange"; }, never, never, true, never>;
}
declare class DxoCircularGaugeLoadingIndicatorModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoCircularGaugeLoadingIndicatorModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoCircularGaugeLoadingIndicatorModule, never, [typeof DxoCircularGaugeLoadingIndicatorComponent], [typeof DxoCircularGaugeLoadingIndicatorComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoCircularGaugeLoadingIndicatorModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoCircularGaugeMarginComponent extends NestedOption implements OnDestroy, OnInit {
    get bottom(): number;
    set bottom(value: number);
    get left(): number;
    set left(value: number);
    get right(): number;
    set right(value: number);
    get top(): number;
    set top(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoCircularGaugeMarginComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoCircularGaugeMarginComponent, "dxo-circular-gauge-margin", never, { "bottom": { "alias": "bottom"; "required": false; }; "left": { "alias": "left"; "required": false; }; "right": { "alias": "right"; "required": false; }; "top": { "alias": "top"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoCircularGaugeMarginModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoCircularGaugeMarginModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoCircularGaugeMarginModule, never, [typeof DxoCircularGaugeMarginComponent], [typeof DxoCircularGaugeMarginComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoCircularGaugeMarginModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoCircularGaugeMinorTickComponent extends NestedOption implements OnDestroy, OnInit {
    get color(): string;
    set color(value: string);
    get length(): number;
    set length(value: number);
    get opacity(): number;
    set opacity(value: number);
    get visible(): boolean;
    set visible(value: boolean);
    get width(): number;
    set width(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoCircularGaugeMinorTickComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoCircularGaugeMinorTickComponent, "dxo-circular-gauge-minor-tick", never, { "color": { "alias": "color"; "required": false; }; "length": { "alias": "length"; "required": false; }; "opacity": { "alias": "opacity"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoCircularGaugeMinorTickModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoCircularGaugeMinorTickModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoCircularGaugeMinorTickModule, never, [typeof DxoCircularGaugeMinorTickComponent], [typeof DxoCircularGaugeMinorTickComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoCircularGaugeMinorTickModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoCircularGaugeRangeContainerComponent extends NestedOption implements OnDestroy, OnInit {
    set _rangesContentChildren(value: QueryList<CollectionNestedOption>);
    get backgroundColor(): ChartsColor | string;
    set backgroundColor(value: ChartsColor | string);
    get offset(): number;
    set offset(value: number);
    get orientation(): CircularGaugeElementOrientation;
    set orientation(value: CircularGaugeElementOrientation);
    get palette(): Array<string> | Palette;
    set palette(value: Array<string> | Palette);
    get paletteExtensionMode(): PaletteExtensionMode;
    set paletteExtensionMode(value: PaletteExtensionMode);
    get ranges(): {
        color?: ChartsColor | string;
        endValue?: number;
        startValue?: number;
    }[];
    set ranges(value: {
        color?: ChartsColor | string;
        endValue?: number;
        startValue?: number;
    }[]);
    get width(): number;
    set width(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoCircularGaugeRangeContainerComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoCircularGaugeRangeContainerComponent, "dxo-circular-gauge-range-container", never, { "backgroundColor": { "alias": "backgroundColor"; "required": false; }; "offset": { "alias": "offset"; "required": false; }; "orientation": { "alias": "orientation"; "required": false; }; "palette": { "alias": "palette"; "required": false; }; "paletteExtensionMode": { "alias": "paletteExtensionMode"; "required": false; }; "ranges": { "alias": "ranges"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, ["_rangesContentChildren"], never, true, never>;
}
declare class DxoCircularGaugeRangeContainerModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoCircularGaugeRangeContainerModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoCircularGaugeRangeContainerModule, never, [typeof DxoCircularGaugeRangeContainerComponent], [typeof DxoCircularGaugeRangeContainerComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoCircularGaugeRangeContainerModule>;
}

declare class DxiCircularGaugeRangeComponent extends CollectionNestedOption {
    get color(): ChartsColor | string;
    set color(value: ChartsColor | string);
    get endValue(): number;
    set endValue(value: number);
    get startValue(): number;
    set startValue(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiCircularGaugeRangeComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiCircularGaugeRangeComponent, "dxi-circular-gauge-range", never, { "color": { "alias": "color"; "required": false; }; "endValue": { "alias": "endValue"; "required": false; }; "startValue": { "alias": "startValue"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxiCircularGaugeRangeModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiCircularGaugeRangeModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiCircularGaugeRangeModule, never, [typeof DxiCircularGaugeRangeComponent], [typeof DxiCircularGaugeRangeComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiCircularGaugeRangeModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoCircularGaugeScaleComponent extends NestedOption implements OnDestroy, OnInit {
    get allowDecimals(): boolean | undefined;
    set allowDecimals(value: boolean | undefined);
    get customMinorTicks(): Array<number> | undefined;
    set customMinorTicks(value: Array<number> | undefined);
    get customTicks(): Array<number> | undefined;
    set customTicks(value: Array<number> | undefined);
    get endValue(): number;
    set endValue(value: number);
    get label(): {
        customizeText?: ((scaleValue: {
            value: number;
            valueText: string;
        }) => string);
        font?: Font;
        format?: Format$1 | undefined;
        hideFirstOrLast?: CircularGaugeLabelOverlap;
        indentFromTick?: number;
        overlappingBehavior?: LabelOverlap;
        useRangeColors?: boolean;
        visible?: boolean;
    };
    set label(value: {
        customizeText?: ((scaleValue: {
            value: number;
            valueText: string;
        }) => string);
        font?: Font;
        format?: Format$1 | undefined;
        hideFirstOrLast?: CircularGaugeLabelOverlap;
        indentFromTick?: number;
        overlappingBehavior?: LabelOverlap;
        useRangeColors?: boolean;
        visible?: boolean;
    });
    get minorTick(): {
        color?: string;
        length?: number;
        opacity?: number;
        visible?: boolean;
        width?: number;
    };
    set minorTick(value: {
        color?: string;
        length?: number;
        opacity?: number;
        visible?: boolean;
        width?: number;
    });
    get minorTickInterval(): number | undefined;
    set minorTickInterval(value: number | undefined);
    get orientation(): CircularGaugeElementOrientation;
    set orientation(value: CircularGaugeElementOrientation);
    get scaleDivisionFactor(): number;
    set scaleDivisionFactor(value: number);
    get startValue(): number;
    set startValue(value: number);
    get tick(): {
        color?: string;
        length?: number;
        opacity?: number;
        visible?: boolean;
        width?: number;
    };
    set tick(value: {
        color?: string;
        length?: number;
        opacity?: number;
        visible?: boolean;
        width?: number;
    });
    get tickInterval(): number | undefined;
    set tickInterval(value: number | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoCircularGaugeScaleComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoCircularGaugeScaleComponent, "dxo-circular-gauge-scale", never, { "allowDecimals": { "alias": "allowDecimals"; "required": false; }; "customMinorTicks": { "alias": "customMinorTicks"; "required": false; }; "customTicks": { "alias": "customTicks"; "required": false; }; "endValue": { "alias": "endValue"; "required": false; }; "label": { "alias": "label"; "required": false; }; "minorTick": { "alias": "minorTick"; "required": false; }; "minorTickInterval": { "alias": "minorTickInterval"; "required": false; }; "orientation": { "alias": "orientation"; "required": false; }; "scaleDivisionFactor": { "alias": "scaleDivisionFactor"; "required": false; }; "startValue": { "alias": "startValue"; "required": false; }; "tick": { "alias": "tick"; "required": false; }; "tickInterval": { "alias": "tickInterval"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoCircularGaugeScaleModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoCircularGaugeScaleModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoCircularGaugeScaleModule, never, [typeof DxoCircularGaugeScaleComponent], [typeof DxoCircularGaugeScaleComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoCircularGaugeScaleModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoCircularGaugeShadowComponent extends NestedOption implements OnDestroy, OnInit {
    get blur(): number;
    set blur(value: number);
    get color(): string;
    set color(value: string);
    get offsetX(): number;
    set offsetX(value: number);
    get offsetY(): number;
    set offsetY(value: number);
    get opacity(): number;
    set opacity(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoCircularGaugeShadowComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoCircularGaugeShadowComponent, "dxo-circular-gauge-shadow", never, { "blur": { "alias": "blur"; "required": false; }; "color": { "alias": "color"; "required": false; }; "offsetX": { "alias": "offsetX"; "required": false; }; "offsetY": { "alias": "offsetY"; "required": false; }; "opacity": { "alias": "opacity"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoCircularGaugeShadowModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoCircularGaugeShadowModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoCircularGaugeShadowModule, never, [typeof DxoCircularGaugeShadowComponent], [typeof DxoCircularGaugeShadowComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoCircularGaugeShadowModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoCircularGaugeSizeComponent extends NestedOption implements OnDestroy, OnInit {
    get height(): number | undefined;
    set height(value: number | undefined);
    get width(): number | undefined;
    set width(value: number | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoCircularGaugeSizeComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoCircularGaugeSizeComponent, "dxo-circular-gauge-size", never, { "height": { "alias": "height"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoCircularGaugeSizeModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoCircularGaugeSizeModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoCircularGaugeSizeModule, never, [typeof DxoCircularGaugeSizeComponent], [typeof DxoCircularGaugeSizeComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoCircularGaugeSizeModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoCircularGaugeSubtitleComponent extends NestedOption implements OnDestroy, OnInit {
    get font(): Font;
    set font(value: Font);
    get offset(): number;
    set offset(value: number);
    get text(): string | undefined;
    set text(value: string | undefined);
    get textOverflow(): TextOverflow;
    set textOverflow(value: TextOverflow);
    get wordWrap(): WordWrap;
    set wordWrap(value: WordWrap);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoCircularGaugeSubtitleComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoCircularGaugeSubtitleComponent, "dxo-circular-gauge-subtitle", never, { "font": { "alias": "font"; "required": false; }; "offset": { "alias": "offset"; "required": false; }; "text": { "alias": "text"; "required": false; }; "textOverflow": { "alias": "textOverflow"; "required": false; }; "wordWrap": { "alias": "wordWrap"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoCircularGaugeSubtitleModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoCircularGaugeSubtitleModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoCircularGaugeSubtitleModule, never, [typeof DxoCircularGaugeSubtitleComponent], [typeof DxoCircularGaugeSubtitleComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoCircularGaugeSubtitleModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoCircularGaugeSubvalueIndicatorComponent extends NestedOption implements OnDestroy, OnInit {
    get arrowLength(): number;
    set arrowLength(value: number);
    get backgroundColor(): string;
    set backgroundColor(value: string);
    get baseValue(): number | undefined;
    set baseValue(value: number | undefined);
    get beginAdaptingAtRadius(): number;
    set beginAdaptingAtRadius(value: number);
    get color(): ChartsColor | string;
    set color(value: ChartsColor | string);
    get horizontalOrientation(): HorizontalEdge;
    set horizontalOrientation(value: HorizontalEdge);
    get indentFromCenter(): number;
    set indentFromCenter(value: number);
    get length(): number;
    set length(value: number);
    get offset(): number;
    set offset(value: number);
    get palette(): Array<string> | Palette;
    set palette(value: Array<string> | Palette);
    get secondColor(): string;
    set secondColor(value: string);
    get secondFraction(): number;
    set secondFraction(value: number);
    get size(): number;
    set size(value: number);
    get spindleGapSize(): number;
    set spindleGapSize(value: number);
    get spindleSize(): number;
    set spindleSize(value: number);
    get text(): {
        customizeText?: ((indicatedValue: {
            value: number;
            valueText: string;
        }) => string) | undefined;
        font?: Font;
        format?: Format$1 | undefined;
        indent?: number;
    };
    set text(value: {
        customizeText?: ((indicatedValue: {
            value: number;
            valueText: string;
        }) => string) | undefined;
        font?: Font;
        format?: Format$1 | undefined;
        indent?: number;
    });
    get type(): "circle" | "rangeBar" | "rectangle" | "rectangleNeedle" | "rhombus" | "textCloud" | "triangleMarker" | "triangleNeedle" | "twoColorNeedle";
    set type(value: "circle" | "rangeBar" | "rectangle" | "rectangleNeedle" | "rhombus" | "textCloud" | "triangleMarker" | "triangleNeedle" | "twoColorNeedle");
    get verticalOrientation(): VerticalEdge;
    set verticalOrientation(value: VerticalEdge);
    get width(): number;
    set width(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoCircularGaugeSubvalueIndicatorComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoCircularGaugeSubvalueIndicatorComponent, "dxo-circular-gauge-subvalue-indicator", never, { "arrowLength": { "alias": "arrowLength"; "required": false; }; "backgroundColor": { "alias": "backgroundColor"; "required": false; }; "baseValue": { "alias": "baseValue"; "required": false; }; "beginAdaptingAtRadius": { "alias": "beginAdaptingAtRadius"; "required": false; }; "color": { "alias": "color"; "required": false; }; "horizontalOrientation": { "alias": "horizontalOrientation"; "required": false; }; "indentFromCenter": { "alias": "indentFromCenter"; "required": false; }; "length": { "alias": "length"; "required": false; }; "offset": { "alias": "offset"; "required": false; }; "palette": { "alias": "palette"; "required": false; }; "secondColor": { "alias": "secondColor"; "required": false; }; "secondFraction": { "alias": "secondFraction"; "required": false; }; "size": { "alias": "size"; "required": false; }; "spindleGapSize": { "alias": "spindleGapSize"; "required": false; }; "spindleSize": { "alias": "spindleSize"; "required": false; }; "text": { "alias": "text"; "required": false; }; "type": { "alias": "type"; "required": false; }; "verticalOrientation": { "alias": "verticalOrientation"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoCircularGaugeSubvalueIndicatorModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoCircularGaugeSubvalueIndicatorModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoCircularGaugeSubvalueIndicatorModule, never, [typeof DxoCircularGaugeSubvalueIndicatorComponent], [typeof DxoCircularGaugeSubvalueIndicatorComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoCircularGaugeSubvalueIndicatorModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoCircularGaugeTextComponent extends NestedOption implements OnDestroy, OnInit {
    get customizeText(): ((indicatedValue: {
        value: number;
        valueText: string;
    }) => string) | undefined;
    set customizeText(value: ((indicatedValue: {
        value: number;
        valueText: string;
    }) => string) | undefined);
    get font(): Font;
    set font(value: Font);
    get format(): Format$1 | undefined;
    set format(value: Format$1 | undefined);
    get indent(): number;
    set indent(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoCircularGaugeTextComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoCircularGaugeTextComponent, "dxo-circular-gauge-text", never, { "customizeText": { "alias": "customizeText"; "required": false; }; "font": { "alias": "font"; "required": false; }; "format": { "alias": "format"; "required": false; }; "indent": { "alias": "indent"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoCircularGaugeTextModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoCircularGaugeTextModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoCircularGaugeTextModule, never, [typeof DxoCircularGaugeTextComponent], [typeof DxoCircularGaugeTextComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoCircularGaugeTextModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoCircularGaugeTickComponent extends NestedOption implements OnDestroy, OnInit {
    get color(): string;
    set color(value: string);
    get length(): number;
    set length(value: number);
    get opacity(): number;
    set opacity(value: number);
    get visible(): boolean;
    set visible(value: boolean);
    get width(): number;
    set width(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoCircularGaugeTickComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoCircularGaugeTickComponent, "dxo-circular-gauge-tick", never, { "color": { "alias": "color"; "required": false; }; "length": { "alias": "length"; "required": false; }; "opacity": { "alias": "opacity"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoCircularGaugeTickModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoCircularGaugeTickModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoCircularGaugeTickModule, never, [typeof DxoCircularGaugeTickComponent], [typeof DxoCircularGaugeTickComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoCircularGaugeTickModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoCircularGaugeTitleComponent extends NestedOption implements OnDestroy, OnInit {
    get font(): Font;
    set font(value: Font);
    get horizontalAlignment(): HorizontalAlignment;
    set horizontalAlignment(value: HorizontalAlignment);
    get margin(): number | {
        bottom?: number;
        left?: number;
        right?: number;
        top?: number;
    };
    set margin(value: number | {
        bottom?: number;
        left?: number;
        right?: number;
        top?: number;
    });
    get placeholderSize(): number | undefined;
    set placeholderSize(value: number | undefined);
    get subtitle(): string | {
        font?: Font;
        offset?: number;
        text?: string | undefined;
        textOverflow?: TextOverflow;
        wordWrap?: WordWrap;
    };
    set subtitle(value: string | {
        font?: Font;
        offset?: number;
        text?: string | undefined;
        textOverflow?: TextOverflow;
        wordWrap?: WordWrap;
    });
    get text(): string | undefined;
    set text(value: string | undefined);
    get textOverflow(): TextOverflow;
    set textOverflow(value: TextOverflow);
    get verticalAlignment(): VerticalEdge;
    set verticalAlignment(value: VerticalEdge);
    get wordWrap(): WordWrap;
    set wordWrap(value: WordWrap);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoCircularGaugeTitleComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoCircularGaugeTitleComponent, "dxo-circular-gauge-title", never, { "font": { "alias": "font"; "required": false; }; "horizontalAlignment": { "alias": "horizontalAlignment"; "required": false; }; "margin": { "alias": "margin"; "required": false; }; "placeholderSize": { "alias": "placeholderSize"; "required": false; }; "subtitle": { "alias": "subtitle"; "required": false; }; "text": { "alias": "text"; "required": false; }; "textOverflow": { "alias": "textOverflow"; "required": false; }; "verticalAlignment": { "alias": "verticalAlignment"; "required": false; }; "wordWrap": { "alias": "wordWrap"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoCircularGaugeTitleModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoCircularGaugeTitleModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoCircularGaugeTitleModule, never, [typeof DxoCircularGaugeTitleComponent], [typeof DxoCircularGaugeTitleComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoCircularGaugeTitleModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoCircularGaugeTooltipComponent extends NestedOption implements OnDestroy, OnInit {
    get arrowLength(): number;
    set arrowLength(value: number);
    get border(): {
        color?: string;
        dashStyle?: DashStyle;
        opacity?: number | undefined;
        visible?: boolean;
        width?: number;
    };
    set border(value: {
        color?: string;
        dashStyle?: DashStyle;
        opacity?: number | undefined;
        visible?: boolean;
        width?: number;
    });
    get color(): string;
    set color(value: string);
    get container(): any | string | undefined;
    set container(value: any | string | undefined);
    get contentTemplate(): any;
    set contentTemplate(value: any);
    get cornerRadius(): number;
    set cornerRadius(value: number);
    get customizeTooltip(): ((scaleValue: {
        value: number;
        valueText: string;
    }) => Record<string, any>) | undefined;
    set customizeTooltip(value: ((scaleValue: {
        value: number;
        valueText: string;
    }) => Record<string, any>) | undefined);
    get enabled(): boolean;
    set enabled(value: boolean);
    get font(): Font;
    set font(value: Font);
    get format(): Format$1 | undefined;
    set format(value: Format$1 | undefined);
    get interactive(): boolean;
    set interactive(value: boolean);
    get opacity(): number | undefined;
    set opacity(value: number | undefined);
    get paddingLeftRight(): number;
    set paddingLeftRight(value: number);
    get paddingTopBottom(): number;
    set paddingTopBottom(value: number);
    get shadow(): {
        blur?: number;
        color?: string;
        offsetX?: number;
        offsetY?: number;
        opacity?: number;
    };
    set shadow(value: {
        blur?: number;
        color?: string;
        offsetX?: number;
        offsetY?: number;
        opacity?: number;
    });
    get zIndex(): number | undefined;
    set zIndex(value: number | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoCircularGaugeTooltipComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoCircularGaugeTooltipComponent, "dxo-circular-gauge-tooltip", never, { "arrowLength": { "alias": "arrowLength"; "required": false; }; "border": { "alias": "border"; "required": false; }; "color": { "alias": "color"; "required": false; }; "container": { "alias": "container"; "required": false; }; "contentTemplate": { "alias": "contentTemplate"; "required": false; }; "cornerRadius": { "alias": "cornerRadius"; "required": false; }; "customizeTooltip": { "alias": "customizeTooltip"; "required": false; }; "enabled": { "alias": "enabled"; "required": false; }; "font": { "alias": "font"; "required": false; }; "format": { "alias": "format"; "required": false; }; "interactive": { "alias": "interactive"; "required": false; }; "opacity": { "alias": "opacity"; "required": false; }; "paddingLeftRight": { "alias": "paddingLeftRight"; "required": false; }; "paddingTopBottom": { "alias": "paddingTopBottom"; "required": false; }; "shadow": { "alias": "shadow"; "required": false; }; "zIndex": { "alias": "zIndex"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoCircularGaugeTooltipModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoCircularGaugeTooltipModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoCircularGaugeTooltipModule, never, [typeof DxoCircularGaugeTooltipComponent], [typeof DxoCircularGaugeTooltipComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoCircularGaugeTooltipModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoCircularGaugeValueIndicatorComponent extends NestedOption implements OnDestroy, OnInit {
    get arrowLength(): number;
    set arrowLength(value: number);
    get backgroundColor(): string;
    set backgroundColor(value: string);
    get baseValue(): number | undefined;
    set baseValue(value: number | undefined);
    get beginAdaptingAtRadius(): number;
    set beginAdaptingAtRadius(value: number);
    get color(): ChartsColor | string;
    set color(value: ChartsColor | string);
    get horizontalOrientation(): HorizontalEdge;
    set horizontalOrientation(value: HorizontalEdge);
    get indentFromCenter(): number;
    set indentFromCenter(value: number);
    get length(): number;
    set length(value: number);
    get offset(): number;
    set offset(value: number);
    get palette(): Array<string> | Palette;
    set palette(value: Array<string> | Palette);
    get secondColor(): string;
    set secondColor(value: string);
    get secondFraction(): number;
    set secondFraction(value: number);
    get size(): number;
    set size(value: number);
    get spindleGapSize(): number;
    set spindleGapSize(value: number);
    get spindleSize(): number;
    set spindleSize(value: number);
    get text(): {
        customizeText?: ((indicatedValue: {
            value: number;
            valueText: string;
        }) => string) | undefined;
        font?: Font;
        format?: Format$1 | undefined;
        indent?: number;
    };
    set text(value: {
        customizeText?: ((indicatedValue: {
            value: number;
            valueText: string;
        }) => string) | undefined;
        font?: Font;
        format?: Format$1 | undefined;
        indent?: number;
    });
    get type(): "circle" | "rangeBar" | "rectangle" | "rectangleNeedle" | "rhombus" | "textCloud" | "triangleMarker" | "triangleNeedle" | "twoColorNeedle";
    set type(value: "circle" | "rangeBar" | "rectangle" | "rectangleNeedle" | "rhombus" | "textCloud" | "triangleMarker" | "triangleNeedle" | "twoColorNeedle");
    get verticalOrientation(): VerticalEdge;
    set verticalOrientation(value: VerticalEdge);
    get width(): number;
    set width(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoCircularGaugeValueIndicatorComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoCircularGaugeValueIndicatorComponent, "dxo-circular-gauge-value-indicator", never, { "arrowLength": { "alias": "arrowLength"; "required": false; }; "backgroundColor": { "alias": "backgroundColor"; "required": false; }; "baseValue": { "alias": "baseValue"; "required": false; }; "beginAdaptingAtRadius": { "alias": "beginAdaptingAtRadius"; "required": false; }; "color": { "alias": "color"; "required": false; }; "horizontalOrientation": { "alias": "horizontalOrientation"; "required": false; }; "indentFromCenter": { "alias": "indentFromCenter"; "required": false; }; "length": { "alias": "length"; "required": false; }; "offset": { "alias": "offset"; "required": false; }; "palette": { "alias": "palette"; "required": false; }; "secondColor": { "alias": "secondColor"; "required": false; }; "secondFraction": { "alias": "secondFraction"; "required": false; }; "size": { "alias": "size"; "required": false; }; "spindleGapSize": { "alias": "spindleGapSize"; "required": false; }; "spindleSize": { "alias": "spindleSize"; "required": false; }; "text": { "alias": "text"; "required": false; }; "type": { "alias": "type"; "required": false; }; "verticalOrientation": { "alias": "verticalOrientation"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoCircularGaugeValueIndicatorModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoCircularGaugeValueIndicatorModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoCircularGaugeValueIndicatorModule, never, [typeof DxoCircularGaugeValueIndicatorComponent], [typeof DxoCircularGaugeValueIndicatorComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoCircularGaugeValueIndicatorModule>;
}

export { DxiCircularGaugeRangeComponent, DxiCircularGaugeRangeModule, DxoCircularGaugeAnimationComponent, DxoCircularGaugeAnimationModule, DxoCircularGaugeBackgroundColorComponent, DxoCircularGaugeBackgroundColorModule, DxoCircularGaugeBorderComponent, DxoCircularGaugeBorderModule, DxoCircularGaugeColorComponent, DxoCircularGaugeColorModule, DxoCircularGaugeExportComponent, DxoCircularGaugeExportModule, DxoCircularGaugeFontComponent, DxoCircularGaugeFontModule, DxoCircularGaugeFormatComponent, DxoCircularGaugeFormatModule, DxoCircularGaugeGeometryComponent, DxoCircularGaugeGeometryModule, DxoCircularGaugeLabelComponent, DxoCircularGaugeLabelModule, DxoCircularGaugeLoadingIndicatorComponent, DxoCircularGaugeLoadingIndicatorModule, DxoCircularGaugeMarginComponent, DxoCircularGaugeMarginModule, DxoCircularGaugeMinorTickComponent, DxoCircularGaugeMinorTickModule, DxoCircularGaugeRangeContainerComponent, DxoCircularGaugeRangeContainerModule, DxoCircularGaugeScaleComponent, DxoCircularGaugeScaleModule, DxoCircularGaugeShadowComponent, DxoCircularGaugeShadowModule, DxoCircularGaugeSizeComponent, DxoCircularGaugeSizeModule, DxoCircularGaugeSubtitleComponent, DxoCircularGaugeSubtitleModule, DxoCircularGaugeSubvalueIndicatorComponent, DxoCircularGaugeSubvalueIndicatorModule, DxoCircularGaugeTextComponent, DxoCircularGaugeTextModule, DxoCircularGaugeTickComponent, DxoCircularGaugeTickModule, DxoCircularGaugeTitleComponent, DxoCircularGaugeTitleModule, DxoCircularGaugeTooltipComponent, DxoCircularGaugeTooltipModule, DxoCircularGaugeValueIndicatorComponent, DxoCircularGaugeValueIndicatorModule };
//# sourceMappingURL=index.d.ts.map
