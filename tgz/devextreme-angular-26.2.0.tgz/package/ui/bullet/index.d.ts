import * as i0 from '@angular/core';
import { OnDestroy, EventEmitter, ElementRef, NgZone, TransferState } from '@angular/core';
import DxBullet, { DisposingEvent, DrawnEvent, ExportedEvent, ExportingEvent, FileSavingEvent, IncidentOccurredEvent, InitializedEvent, OptionChangedEvent, TooltipHiddenEvent, TooltipShownEvent } from 'devextreme/viz/bullet';
import { Theme, DashStyle, Font } from 'devextreme/common/charts';
import { Format } from 'devextreme/common/core/localization';
import * as i3 from 'devextreme-angular/core';
import { DxComponent, DxTemplateHost, WatcherHelper, NestedOptionHost } from 'devextreme-angular/core';
import * as i1 from 'devextreme-angular/ui/nested';
import * as i2 from 'devextreme-angular/ui/bullet/nested';
export * from 'devextreme-angular/ui/bullet/nested';
import * as bullet_types from 'devextreme/viz/bullet_types';
export { bullet_types as DxBulletTypes };

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

/**
 * [descr:dxBullet]

 */
declare class DxBulletComponent extends DxComponent implements OnDestroy {
    instance: DxBullet;
    /**
     * [descr:dxBulletOptions.color]
    
     */
    get color(): string;
    set color(value: string);
    /**
     * [descr:BaseWidgetOptions.disabled]
    
     */
    get disabled(): boolean;
    set disabled(value: boolean);
    /**
     * [descr:DOMComponentOptions.elementAttr]
    
     */
    get elementAttr(): Record<string, any>;
    set elementAttr(value: Record<string, any>);
    /**
     * [descr:BaseWidgetOptions.encodeHtml]
    
     */
    get encodeHtml(): boolean;
    set encodeHtml(value: boolean);
    /**
     * [descr:dxBulletOptions.endScaleValue]
    
     */
    get endScaleValue(): number | undefined;
    set endScaleValue(value: number | undefined);
    /**
     * [descr:BaseWidgetOptions.margin]
    
     */
    get margin(): {
        bottom?: number;
        left?: number;
        right?: number;
        top?: number;
    };
    set margin(value: {
        bottom?: number;
        left?: number;
        right?: number;
        top?: number;
    });
    /**
     * [descr:BaseWidgetOptions.pathModified]
    
     */
    get pathModified(): boolean;
    set pathModified(value: boolean);
    /**
     * [descr:BaseWidgetOptions.rtlEnabled]
    
     */
    get rtlEnabled(): boolean;
    set rtlEnabled(value: boolean);
    /**
     * [descr:dxBulletOptions.showTarget]
    
     */
    get showTarget(): boolean;
    set showTarget(value: boolean);
    /**
     * [descr:dxBulletOptions.showZeroLevel]
    
     */
    get showZeroLevel(): boolean;
    set showZeroLevel(value: boolean);
    /**
     * [descr:BaseWidgetOptions.size]
    
     */
    get size(): {
        height?: number | undefined;
        width?: number | undefined;
    };
    set size(value: {
        height?: number | undefined;
        width?: number | undefined;
    });
    /**
     * [descr:dxBulletOptions.startScaleValue]
    
     */
    get startScaleValue(): number;
    set startScaleValue(value: number);
    /**
     * [descr:dxBulletOptions.target]
    
     */
    get target(): number;
    set target(value: number);
    /**
     * [descr:dxBulletOptions.targetColor]
    
     */
    get targetColor(): string;
    set targetColor(value: string);
    /**
     * [descr:dxBulletOptions.targetWidth]
    
     */
    get targetWidth(): number;
    set targetWidth(value: number);
    /**
     * [descr:BaseWidgetOptions.theme]
    
     */
    get theme(): Theme;
    set theme(value: Theme);
    /**
     * [descr:BaseSparklineOptions.tooltip]
    
     */
    get tooltip(): {
        arrowLength?: number;
        border?: {
            color?: string;
            dashStyle?: DashStyle;
            opacity?: number | undefined;
            visible?: boolean;
            width?: number;
        };
        color?: string;
        container?: any | string | undefined;
        contentTemplate?: any;
        cornerRadius?: number;
        customizeTooltip?: ((pointsInfo: any) => Record<string, any>) | undefined;
        enabled?: boolean;
        font?: Font;
        format?: Format | undefined;
        interactive?: boolean;
        opacity?: number | undefined;
        paddingLeftRight?: number;
        paddingTopBottom?: number;
        shadow?: {
            blur?: number;
            color?: string;
            offsetX?: number;
            offsetY?: number;
            opacity?: number;
        };
        zIndex?: number | undefined;
    };
    set tooltip(value: {
        arrowLength?: number;
        border?: {
            color?: string;
            dashStyle?: DashStyle;
            opacity?: number | undefined;
            visible?: boolean;
            width?: number;
        };
        color?: string;
        container?: any | string | undefined;
        contentTemplate?: any;
        cornerRadius?: number;
        customizeTooltip?: ((pointsInfo: any) => Record<string, any>) | undefined;
        enabled?: boolean;
        font?: Font;
        format?: Format | undefined;
        interactive?: boolean;
        opacity?: number | undefined;
        paddingLeftRight?: number;
        paddingTopBottom?: number;
        shadow?: {
            blur?: number;
            color?: string;
            offsetX?: number;
            offsetY?: number;
            opacity?: number;
        };
        zIndex?: number | undefined;
    });
    /**
     * [descr:dxBulletOptions.value]
    
     */
    get value(): number;
    set value(value: number);
    /**
    
     * [descr:dxBulletOptions.onDisposing]
    
    
     */
    onDisposing: EventEmitter<DisposingEvent>;
    /**
    
     * [descr:dxBulletOptions.onDrawn]
    
    
     */
    onDrawn: EventEmitter<DrawnEvent>;
    /**
    
     * [descr:dxBulletOptions.onExported]
    
    
     */
    onExported: EventEmitter<ExportedEvent>;
    /**
    
     * [descr:dxBulletOptions.onExporting]
    
    
     */
    onExporting: EventEmitter<ExportingEvent>;
    /**
    
     * [descr:dxBulletOptions.onFileSaving]
    
    
     */
    onFileSaving: EventEmitter<FileSavingEvent>;
    /**
    
     * [descr:dxBulletOptions.onIncidentOccurred]
    
    
     */
    onIncidentOccurred: EventEmitter<IncidentOccurredEvent>;
    /**
    
     * [descr:dxBulletOptions.onInitialized]
    
    
     */
    onInitialized: EventEmitter<InitializedEvent>;
    /**
    
     * [descr:dxBulletOptions.onOptionChanged]
    
    
     */
    onOptionChanged: EventEmitter<OptionChangedEvent>;
    /**
    
     * [descr:dxBulletOptions.onTooltipHidden]
    
    
     */
    onTooltipHidden: EventEmitter<TooltipHiddenEvent>;
    /**
    
     * [descr:dxBulletOptions.onTooltipShown]
    
    
     */
    onTooltipShown: EventEmitter<TooltipShownEvent>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    colorChange: EventEmitter<string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    disabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    elementAttrChange: EventEmitter<Record<string, any>>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    encodeHtmlChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    endScaleValueChange: EventEmitter<number | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    marginChange: EventEmitter<{
        bottom?: number;
        left?: number;
        right?: number;
        top?: number;
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    pathModifiedChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    rtlEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    showTargetChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    showZeroLevelChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    sizeChange: EventEmitter<{
        height?: number | undefined;
        width?: number | undefined;
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    startScaleValueChange: EventEmitter<number>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    targetChange: EventEmitter<number>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    targetColorChange: EventEmitter<string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    targetWidthChange: EventEmitter<number>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    themeChange: EventEmitter<Theme>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    tooltipChange: EventEmitter<{
        arrowLength?: number;
        border?: {
            color?: string;
            dashStyle?: DashStyle;
            opacity?: number | undefined;
            visible?: boolean;
            width?: number;
        };
        color?: string;
        container?: any | string | undefined;
        contentTemplate?: any;
        cornerRadius?: number;
        customizeTooltip?: ((pointsInfo: any) => Record<string, any>) | undefined;
        enabled?: boolean;
        font?: Font;
        format?: Format | undefined;
        interactive?: boolean;
        opacity?: number | undefined;
        paddingLeftRight?: number;
        paddingTopBottom?: number;
        shadow?: {
            blur?: number;
            color?: string;
            offsetX?: number;
            offsetY?: number;
            opacity?: number;
        };
        zIndex?: number | undefined;
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    valueChange: EventEmitter<number>;
    constructor(elementRef: ElementRef, ngZone: NgZone, templateHost: DxTemplateHost, _watcherHelper: WatcherHelper, optionHost: NestedOptionHost, transferState: TransferState, platformId: any);
    protected _createInstance(element: any, options: any): DxBullet;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxBulletComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxBulletComponent, "dx-bullet", never, { "color": { "alias": "color"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "elementAttr": { "alias": "elementAttr"; "required": false; }; "encodeHtml": { "alias": "encodeHtml"; "required": false; }; "endScaleValue": { "alias": "endScaleValue"; "required": false; }; "margin": { "alias": "margin"; "required": false; }; "pathModified": { "alias": "pathModified"; "required": false; }; "rtlEnabled": { "alias": "rtlEnabled"; "required": false; }; "showTarget": { "alias": "showTarget"; "required": false; }; "showZeroLevel": { "alias": "showZeroLevel"; "required": false; }; "size": { "alias": "size"; "required": false; }; "startScaleValue": { "alias": "startScaleValue"; "required": false; }; "target": { "alias": "target"; "required": false; }; "targetColor": { "alias": "targetColor"; "required": false; }; "targetWidth": { "alias": "targetWidth"; "required": false; }; "theme": { "alias": "theme"; "required": false; }; "tooltip": { "alias": "tooltip"; "required": false; }; "value": { "alias": "value"; "required": false; }; }, { "onDisposing": "onDisposing"; "onDrawn": "onDrawn"; "onExported": "onExported"; "onExporting": "onExporting"; "onFileSaving": "onFileSaving"; "onIncidentOccurred": "onIncidentOccurred"; "onInitialized": "onInitialized"; "onOptionChanged": "onOptionChanged"; "onTooltipHidden": "onTooltipHidden"; "onTooltipShown": "onTooltipShown"; "colorChange": "colorChange"; "disabledChange": "disabledChange"; "elementAttrChange": "elementAttrChange"; "encodeHtmlChange": "encodeHtmlChange"; "endScaleValueChange": "endScaleValueChange"; "marginChange": "marginChange"; "pathModifiedChange": "pathModifiedChange"; "rtlEnabledChange": "rtlEnabledChange"; "showTargetChange": "showTargetChange"; "showZeroLevelChange": "showZeroLevelChange"; "sizeChange": "sizeChange"; "startScaleValueChange": "startScaleValueChange"; "targetChange": "targetChange"; "targetColorChange": "targetColorChange"; "targetWidthChange": "targetWidthChange"; "themeChange": "themeChange"; "tooltipChange": "tooltipChange"; "valueChange": "valueChange"; }, never, never, true, never>;
}
declare class DxBulletModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxBulletModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxBulletModule, never, [typeof DxBulletComponent, typeof i1.DxoMarginModule, typeof i1.DxoSizeModule, typeof i1.DxoTooltipModule, typeof i1.DxoBorderModule, typeof i1.DxoFontModule, typeof i1.DxoFormatModule, typeof i1.DxoShadowModule, typeof i2.DxoBulletBorderModule, typeof i2.DxoBulletFontModule, typeof i2.DxoBulletFormatModule, typeof i2.DxoBulletMarginModule, typeof i2.DxoBulletShadowModule, typeof i2.DxoBulletSizeModule, typeof i2.DxoBulletTooltipModule, typeof i3.DxIntegrationModule, typeof i3.DxTemplateModule], [typeof DxBulletComponent, typeof i1.DxoMarginModule, typeof i1.DxoSizeModule, typeof i1.DxoTooltipModule, typeof i1.DxoBorderModule, typeof i1.DxoFontModule, typeof i1.DxoFormatModule, typeof i1.DxoShadowModule, typeof i2.DxoBulletBorderModule, typeof i2.DxoBulletFontModule, typeof i2.DxoBulletFormatModule, typeof i2.DxoBulletMarginModule, typeof i2.DxoBulletShadowModule, typeof i2.DxoBulletSizeModule, typeof i2.DxoBulletTooltipModule, typeof i3.DxTemplateModule]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxBulletModule>;
}

export { DxBulletComponent, DxBulletModule };
//# sourceMappingURL=index.d.ts.map
