import * as i0 from '@angular/core';
import { OnDestroy, OnChanges, DoCheck, EventEmitter, ElementRef, NgZone, TransferState, SimpleChanges } from '@angular/core';
import UploadInfo from 'devextreme/file_management/upload_info';
import DxFileUploader, { UploadHttpMethod, FileUploadMode, BeforeSendEvent, ContentReadyEvent, DisposingEvent, DropZoneEnterEvent, DropZoneLeaveEvent, FilesUploadedEvent, InitializedEvent, OptionChangedEvent, ProgressEvent, UploadAbortedEvent, UploadedEvent, UploadErrorEvent, UploadStartedEvent, ValueChangedEvent } from 'devextreme/ui/file_uploader';
import { ValidationStatus } from 'devextreme/common';
import { ControlValueAccessor } from '@angular/forms';
import * as i1 from 'devextreme-angular/core';
import { DxComponent, DxTemplateHost, WatcherHelper, IterableDifferHelper, NestedOptionHost } from 'devextreme-angular/core';
import * as file_uploader_types from 'devextreme/ui/file_uploader_types';
export { file_uploader_types as DxFileUploaderTypes };

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

/**
 * [descr:dxFileUploader]

 */
declare class DxFileUploaderComponent extends DxComponent implements OnDestroy, ControlValueAccessor, OnChanges, DoCheck {
    private _watcherHelper;
    private _idh;
    instance: DxFileUploader;
    /**
     * [descr:dxFileUploaderOptions.abortUpload]
    
     */
    get abortUpload(): ((file: any, uploadInfo?: UploadInfo) => any);
    set abortUpload(value: ((file: any, uploadInfo?: UploadInfo) => any));
    /**
     * [descr:dxFileUploaderOptions.accept]
    
     */
    get accept(): string;
    set accept(value: string);
    /**
     * [descr:WidgetOptions.accessKey]
    
     */
    get accessKey(): string | undefined;
    set accessKey(value: string | undefined);
    /**
     * [descr:WidgetOptions.activeStateEnabled]
    
     */
    get activeStateEnabled(): boolean;
    set activeStateEnabled(value: boolean);
    /**
     * [descr:dxFileUploaderOptions.allowCanceling]
    
     */
    get allowCanceling(): boolean;
    set allowCanceling(value: boolean);
    /**
     * [descr:dxFileUploaderOptions.allowedFileExtensions]
    
     */
    get allowedFileExtensions(): Array<string>;
    set allowedFileExtensions(value: Array<string>);
    /**
     * [descr:dxFileUploaderOptions.chunkSize]
    
     */
    get chunkSize(): number;
    set chunkSize(value: number);
    /**
     * [descr:dxFileUploaderOptions.dialogTrigger]
    
     */
    get dialogTrigger(): any | string | undefined;
    set dialogTrigger(value: any | string | undefined);
    /**
     * [descr:WidgetOptions.disabled]
    
     */
    get disabled(): boolean;
    set disabled(value: boolean);
    /**
     * [descr:dxFileUploaderOptions.dropZone]
    
     */
    get dropZone(): any | string | undefined;
    set dropZone(value: any | string | undefined);
    /**
     * [descr:DOMComponentOptions.elementAttr]
    
     */
    get elementAttr(): Record<string, any>;
    set elementAttr(value: Record<string, any>);
    /**
     * [descr:dxFileUploaderOptions.focusStateEnabled]
    
     */
    get focusStateEnabled(): boolean;
    set focusStateEnabled(value: boolean);
    /**
     * [descr:DOMComponentOptions.height]
    
     */
    get height(): number | string | undefined;
    set height(value: number | string | undefined);
    /**
     * [descr:WidgetOptions.hint]
    
     */
    get hint(): string | undefined;
    set hint(value: string | undefined);
    /**
     * [descr:dxFileUploaderOptions.hoverStateEnabled]
    
     */
    get hoverStateEnabled(): boolean;
    set hoverStateEnabled(value: boolean);
    /**
     * [descr:dxFileUploaderOptions.inputAttr]
    
     */
    get inputAttr(): any;
    set inputAttr(value: any);
    /**
     * [descr:dxFileUploaderOptions.invalidFileExtensionMessage]
    
     */
    get invalidFileExtensionMessage(): string;
    set invalidFileExtensionMessage(value: string);
    /**
     * [descr:dxFileUploaderOptions.invalidMaxFileSizeMessage]
    
     */
    get invalidMaxFileSizeMessage(): string;
    set invalidMaxFileSizeMessage(value: string);
    /**
     * [descr:dxFileUploaderOptions.invalidMinFileSizeMessage]
    
     */
    get invalidMinFileSizeMessage(): string;
    set invalidMinFileSizeMessage(value: string);
    /**
     * [descr:EditorOptions.isDirty]
    
     */
    get isDirty(): boolean;
    set isDirty(value: boolean);
    /**
     * [descr:EditorOptions.isValid]
    
     */
    get isValid(): boolean;
    set isValid(value: boolean);
    /**
     * [descr:dxFileUploaderOptions.labelText]
    
     */
    get labelText(): string;
    set labelText(value: string);
    /**
     * [descr:dxFileUploaderOptions.maxFileSize]
    
     */
    get maxFileSize(): number;
    set maxFileSize(value: number);
    /**
     * [descr:dxFileUploaderOptions.minFileSize]
    
     */
    get minFileSize(): number;
    set minFileSize(value: number);
    /**
     * [descr:dxFileUploaderOptions.multiple]
    
     */
    get multiple(): boolean;
    set multiple(value: boolean);
    /**
     * [descr:dxFileUploaderOptions.name]
    
     */
    get name(): string;
    set name(value: string);
    /**
     * [descr:dxFileUploaderOptions.progress]
    
     */
    get progress(): number;
    set progress(value: number);
    /**
     * [descr:EditorOptions.readOnly]
    
     */
    get readOnly(): boolean;
    set readOnly(value: boolean);
    /**
     * [descr:dxFileUploaderOptions.readyToUploadMessage]
    
     */
    get readyToUploadMessage(): string;
    set readyToUploadMessage(value: string);
    /**
     * [descr:DOMComponentOptions.rtlEnabled]
    
     */
    get rtlEnabled(): boolean;
    set rtlEnabled(value: boolean);
    /**
     * [descr:dxFileUploaderOptions.selectButtonText]
    
     */
    get selectButtonText(): string;
    set selectButtonText(value: string);
    /**
     * [descr:dxFileUploaderOptions.showFileList]
    
     */
    get showFileList(): boolean;
    set showFileList(value: boolean);
    /**
     * [descr:WidgetOptions.tabIndex]
    
     */
    get tabIndex(): number;
    set tabIndex(value: number);
    /**
     * [descr:dxFileUploaderOptions.uploadAbortedMessage]
    
     */
    get uploadAbortedMessage(): string;
    set uploadAbortedMessage(value: string);
    /**
     * [descr:dxFileUploaderOptions.uploadButtonText]
    
     */
    get uploadButtonText(): string;
    set uploadButtonText(value: string);
    /**
     * [descr:dxFileUploaderOptions.uploadChunk]
    
     */
    get uploadChunk(): ((file: any, uploadInfo: UploadInfo) => any);
    set uploadChunk(value: ((file: any, uploadInfo: UploadInfo) => any));
    /**
     * [descr:dxFileUploaderOptions.uploadCustomData]
    
     */
    get uploadCustomData(): any;
    set uploadCustomData(value: any);
    /**
     * [descr:dxFileUploaderOptions.uploadedMessage]
    
     */
    get uploadedMessage(): string;
    set uploadedMessage(value: string);
    /**
     * [descr:dxFileUploaderOptions.uploadFailedMessage]
    
     */
    get uploadFailedMessage(): string;
    set uploadFailedMessage(value: string);
    /**
     * [descr:dxFileUploaderOptions.uploadFile]
    
     */
    get uploadFile(): ((file: any, progressCallback: Function) => any);
    set uploadFile(value: ((file: any, progressCallback: Function) => any));
    /**
     * [descr:dxFileUploaderOptions.uploadHeaders]
    
     */
    get uploadHeaders(): any;
    set uploadHeaders(value: any);
    /**
     * [descr:dxFileUploaderOptions.uploadMethod]
    
     */
    get uploadMethod(): UploadHttpMethod;
    set uploadMethod(value: UploadHttpMethod);
    /**
     * [descr:dxFileUploaderOptions.uploadMode]
    
     */
    get uploadMode(): FileUploadMode;
    set uploadMode(value: FileUploadMode);
    /**
     * [descr:dxFileUploaderOptions.uploadUrl]
    
     */
    get uploadUrl(): string;
    set uploadUrl(value: string);
    /**
     * [descr:EditorOptions.validationError]
    
     */
    get validationError(): any | null;
    set validationError(value: any | null);
    /**
     * [descr:EditorOptions.validationErrors]
    
     */
    get validationErrors(): Array<any> | null;
    set validationErrors(value: Array<any> | null);
    /**
     * [descr:EditorOptions.validationStatus]
    
     */
    get validationStatus(): ValidationStatus;
    set validationStatus(value: ValidationStatus);
    /**
     * [descr:dxFileUploaderOptions.value]
    
     */
    get value(): Array<any>;
    set value(value: Array<any>);
    /**
     * [descr:WidgetOptions.visible]
    
     */
    get visible(): boolean;
    set visible(value: boolean);
    /**
     * [descr:DOMComponentOptions.width]
    
     */
    get width(): number | string | undefined;
    set width(value: number | string | undefined);
    /**
    
     * [descr:dxFileUploaderOptions.onBeforeSend]
    
    
     */
    onBeforeSend: EventEmitter<BeforeSendEvent>;
    /**
    
     * [descr:dxFileUploaderOptions.onContentReady]
    
    
     */
    onContentReady: EventEmitter<ContentReadyEvent>;
    /**
    
     * [descr:dxFileUploaderOptions.onDisposing]
    
    
     */
    onDisposing: EventEmitter<DisposingEvent>;
    /**
    
     * [descr:dxFileUploaderOptions.onDropZoneEnter]
    
    
     */
    onDropZoneEnter: EventEmitter<DropZoneEnterEvent>;
    /**
    
     * [descr:dxFileUploaderOptions.onDropZoneLeave]
    
    
     */
    onDropZoneLeave: EventEmitter<DropZoneLeaveEvent>;
    /**
    
     * [descr:dxFileUploaderOptions.onFilesUploaded]
    
    
     */
    onFilesUploaded: EventEmitter<FilesUploadedEvent>;
    /**
    
     * [descr:dxFileUploaderOptions.onInitialized]
    
    
     */
    onInitialized: EventEmitter<InitializedEvent>;
    /**
    
     * [descr:dxFileUploaderOptions.onOptionChanged]
    
    
     */
    onOptionChanged: EventEmitter<OptionChangedEvent>;
    /**
    
     * [descr:dxFileUploaderOptions.onProgress]
    
    
     */
    onProgress: EventEmitter<ProgressEvent>;
    /**
    
     * [descr:dxFileUploaderOptions.onUploadAborted]
    
    
     */
    onUploadAborted: EventEmitter<UploadAbortedEvent>;
    /**
    
     * [descr:dxFileUploaderOptions.onUploaded]
    
    
     */
    onUploaded: EventEmitter<UploadedEvent>;
    /**
    
     * [descr:dxFileUploaderOptions.onUploadError]
    
    
     */
    onUploadError: EventEmitter<UploadErrorEvent>;
    /**
    
     * [descr:dxFileUploaderOptions.onUploadStarted]
    
    
     */
    onUploadStarted: EventEmitter<UploadStartedEvent>;
    /**
    
     * [descr:dxFileUploaderOptions.onValueChanged]
    
    
     */
    onValueChanged: EventEmitter<ValueChangedEvent>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    abortUploadChange: EventEmitter<((file: any, uploadInfo?: UploadInfo) => any)>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    acceptChange: EventEmitter<string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    accessKeyChange: EventEmitter<string | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    activeStateEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    allowCancelingChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    allowedFileExtensionsChange: EventEmitter<Array<string>>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    chunkSizeChange: EventEmitter<number>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    dialogTriggerChange: EventEmitter<any | string | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    disabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    dropZoneChange: EventEmitter<any | string | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    elementAttrChange: EventEmitter<Record<string, any>>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    focusStateEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    heightChange: EventEmitter<number | string | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    hintChange: EventEmitter<string | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    hoverStateEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    inputAttrChange: EventEmitter<any>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    invalidFileExtensionMessageChange: EventEmitter<string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    invalidMaxFileSizeMessageChange: EventEmitter<string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    invalidMinFileSizeMessageChange: EventEmitter<string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    isDirtyChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    isValidChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    labelTextChange: EventEmitter<string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    maxFileSizeChange: EventEmitter<number>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    minFileSizeChange: EventEmitter<number>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    multipleChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    nameChange: EventEmitter<string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    progressChange: EventEmitter<number>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    readOnlyChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    readyToUploadMessageChange: EventEmitter<string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    rtlEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    selectButtonTextChange: EventEmitter<string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    showFileListChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    tabIndexChange: EventEmitter<number>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    uploadAbortedMessageChange: EventEmitter<string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    uploadButtonTextChange: EventEmitter<string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    uploadChunkChange: EventEmitter<((file: any, uploadInfo: UploadInfo) => any)>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    uploadCustomDataChange: EventEmitter<any>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    uploadedMessageChange: EventEmitter<string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    uploadFailedMessageChange: EventEmitter<string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    uploadFileChange: EventEmitter<((file: any, progressCallback: Function) => any)>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    uploadHeadersChange: EventEmitter<any>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    uploadMethodChange: EventEmitter<UploadHttpMethod>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    uploadModeChange: EventEmitter<FileUploadMode>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    uploadUrlChange: EventEmitter<string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    validationErrorChange: EventEmitter<any | null>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    validationErrorsChange: EventEmitter<Array<any> | null>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    validationStatusChange: EventEmitter<ValidationStatus>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    valueChange: EventEmitter<Array<any>>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    visibleChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    widthChange: EventEmitter<number | string | undefined>;
    /**
    
     * [descr:undefined]
    
    
     */
    onBlur: EventEmitter<any>;
    change(_: any): void;
    touched: (_: any) => void;
    constructor(elementRef: ElementRef, ngZone: NgZone, templateHost: DxTemplateHost, _watcherHelper: WatcherHelper, _idh: IterableDifferHelper, optionHost: NestedOptionHost, transferState: TransferState, platformId: any);
    protected _createInstance(element: any, options: any): DxFileUploader;
    writeValue(value: any): void;
    setDisabledState(isDisabled: boolean): void;
    registerOnChange(fn: (_: any) => void): void;
    registerOnTouched(fn: () => void): void;
    _createWidget(element: any): void;
    ngOnDestroy(): void;
    ngOnChanges(changes: SimpleChanges): void;
    setupChanges(prop: string, changes: SimpleChanges): void;
    ngDoCheck(): void;
    _setOption(name: string, value: any): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxFileUploaderComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxFileUploaderComponent, "dx-file-uploader", never, { "abortUpload": { "alias": "abortUpload"; "required": false; }; "accept": { "alias": "accept"; "required": false; }; "accessKey": { "alias": "accessKey"; "required": false; }; "activeStateEnabled": { "alias": "activeStateEnabled"; "required": false; }; "allowCanceling": { "alias": "allowCanceling"; "required": false; }; "allowedFileExtensions": { "alias": "allowedFileExtensions"; "required": false; }; "chunkSize": { "alias": "chunkSize"; "required": false; }; "dialogTrigger": { "alias": "dialogTrigger"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "dropZone": { "alias": "dropZone"; "required": false; }; "elementAttr": { "alias": "elementAttr"; "required": false; }; "focusStateEnabled": { "alias": "focusStateEnabled"; "required": false; }; "height": { "alias": "height"; "required": false; }; "hint": { "alias": "hint"; "required": false; }; "hoverStateEnabled": { "alias": "hoverStateEnabled"; "required": false; }; "inputAttr": { "alias": "inputAttr"; "required": false; }; "invalidFileExtensionMessage": { "alias": "invalidFileExtensionMessage"; "required": false; }; "invalidMaxFileSizeMessage": { "alias": "invalidMaxFileSizeMessage"; "required": false; }; "invalidMinFileSizeMessage": { "alias": "invalidMinFileSizeMessage"; "required": false; }; "isDirty": { "alias": "isDirty"; "required": false; }; "isValid": { "alias": "isValid"; "required": false; }; "labelText": { "alias": "labelText"; "required": false; }; "maxFileSize": { "alias": "maxFileSize"; "required": false; }; "minFileSize": { "alias": "minFileSize"; "required": false; }; "multiple": { "alias": "multiple"; "required": false; }; "name": { "alias": "name"; "required": false; }; "progress": { "alias": "progress"; "required": false; }; "readOnly": { "alias": "readOnly"; "required": false; }; "readyToUploadMessage": { "alias": "readyToUploadMessage"; "required": false; }; "rtlEnabled": { "alias": "rtlEnabled"; "required": false; }; "selectButtonText": { "alias": "selectButtonText"; "required": false; }; "showFileList": { "alias": "showFileList"; "required": false; }; "tabIndex": { "alias": "tabIndex"; "required": false; }; "uploadAbortedMessage": { "alias": "uploadAbortedMessage"; "required": false; }; "uploadButtonText": { "alias": "uploadButtonText"; "required": false; }; "uploadChunk": { "alias": "uploadChunk"; "required": false; }; "uploadCustomData": { "alias": "uploadCustomData"; "required": false; }; "uploadedMessage": { "alias": "uploadedMessage"; "required": false; }; "uploadFailedMessage": { "alias": "uploadFailedMessage"; "required": false; }; "uploadFile": { "alias": "uploadFile"; "required": false; }; "uploadHeaders": { "alias": "uploadHeaders"; "required": false; }; "uploadMethod": { "alias": "uploadMethod"; "required": false; }; "uploadMode": { "alias": "uploadMode"; "required": false; }; "uploadUrl": { "alias": "uploadUrl"; "required": false; }; "validationError": { "alias": "validationError"; "required": false; }; "validationErrors": { "alias": "validationErrors"; "required": false; }; "validationStatus": { "alias": "validationStatus"; "required": false; }; "value": { "alias": "value"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, { "onBeforeSend": "onBeforeSend"; "onContentReady": "onContentReady"; "onDisposing": "onDisposing"; "onDropZoneEnter": "onDropZoneEnter"; "onDropZoneLeave": "onDropZoneLeave"; "onFilesUploaded": "onFilesUploaded"; "onInitialized": "onInitialized"; "onOptionChanged": "onOptionChanged"; "onProgress": "onProgress"; "onUploadAborted": "onUploadAborted"; "onUploaded": "onUploaded"; "onUploadError": "onUploadError"; "onUploadStarted": "onUploadStarted"; "onValueChanged": "onValueChanged"; "abortUploadChange": "abortUploadChange"; "acceptChange": "acceptChange"; "accessKeyChange": "accessKeyChange"; "activeStateEnabledChange": "activeStateEnabledChange"; "allowCancelingChange": "allowCancelingChange"; "allowedFileExtensionsChange": "allowedFileExtensionsChange"; "chunkSizeChange": "chunkSizeChange"; "dialogTriggerChange": "dialogTriggerChange"; "disabledChange": "disabledChange"; "dropZoneChange": "dropZoneChange"; "elementAttrChange": "elementAttrChange"; "focusStateEnabledChange": "focusStateEnabledChange"; "heightChange": "heightChange"; "hintChange": "hintChange"; "hoverStateEnabledChange": "hoverStateEnabledChange"; "inputAttrChange": "inputAttrChange"; "invalidFileExtensionMessageChange": "invalidFileExtensionMessageChange"; "invalidMaxFileSizeMessageChange": "invalidMaxFileSizeMessageChange"; "invalidMinFileSizeMessageChange": "invalidMinFileSizeMessageChange"; "isDirtyChange": "isDirtyChange"; "isValidChange": "isValidChange"; "labelTextChange": "labelTextChange"; "maxFileSizeChange": "maxFileSizeChange"; "minFileSizeChange": "minFileSizeChange"; "multipleChange": "multipleChange"; "nameChange": "nameChange"; "progressChange": "progressChange"; "readOnlyChange": "readOnlyChange"; "readyToUploadMessageChange": "readyToUploadMessageChange"; "rtlEnabledChange": "rtlEnabledChange"; "selectButtonTextChange": "selectButtonTextChange"; "showFileListChange": "showFileListChange"; "tabIndexChange": "tabIndexChange"; "uploadAbortedMessageChange": "uploadAbortedMessageChange"; "uploadButtonTextChange": "uploadButtonTextChange"; "uploadChunkChange": "uploadChunkChange"; "uploadCustomDataChange": "uploadCustomDataChange"; "uploadedMessageChange": "uploadedMessageChange"; "uploadFailedMessageChange": "uploadFailedMessageChange"; "uploadFileChange": "uploadFileChange"; "uploadHeadersChange": "uploadHeadersChange"; "uploadMethodChange": "uploadMethodChange"; "uploadModeChange": "uploadModeChange"; "uploadUrlChange": "uploadUrlChange"; "validationErrorChange": "validationErrorChange"; "validationErrorsChange": "validationErrorsChange"; "validationStatusChange": "validationStatusChange"; "valueChange": "valueChange"; "visibleChange": "visibleChange"; "widthChange": "widthChange"; "onBlur": "onBlur"; }, never, never, true, never>;
}
declare class DxFileUploaderModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxFileUploaderModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxFileUploaderModule, never, [typeof DxFileUploaderComponent, typeof i1.DxIntegrationModule, typeof i1.DxTemplateModule], [typeof DxFileUploaderComponent, typeof i1.DxTemplateModule]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxFileUploaderModule>;
}

export { DxFileUploaderComponent, DxFileUploaderModule };
//# sourceMappingURL=index.d.ts.map
