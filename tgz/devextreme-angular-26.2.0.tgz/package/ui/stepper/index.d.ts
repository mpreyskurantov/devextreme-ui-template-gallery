import * as i0 from '@angular/core';
import { OnDestroy, OnChanges, DoCheck, QueryList, EventEmitter, ElementRef, NgZone, TransferState, SimpleChanges } from '@angular/core';
import DxStepper, { dxStepperItem, DisposingEvent, InitializedEvent, ItemClickEvent, ItemContextMenuEvent, ItemRenderedEvent, OptionChangedEvent, SelectionChangedEvent, SelectionChangingEvent } from 'devextreme/ui/stepper';
export { ExplicitTypes } from 'devextreme/ui/stepper';
import DataSource, { DataSourceOptions } from 'devextreme/data/data_source';
import { Store } from 'devextreme/data/store';
import { Orientation } from 'devextreme/common';
import * as i2 from 'devextreme-angular/core';
import { DxComponent, CollectionNestedOption, DxTemplateHost, WatcherHelper, IterableDifferHelper, NestedOptionHost } from 'devextreme-angular/core';
import * as i1 from 'devextreme-angular/ui/stepper/nested';
export * from 'devextreme-angular/ui/stepper/nested';
import * as stepper_types from 'devextreme/ui/stepper_types';
export { stepper_types as DxStepperTypes };

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxStepperComponent<TItem = any, TKey = any> extends DxComponent implements OnDestroy, OnChanges, DoCheck {
    private _watcherHelper;
    private _idh;
    set _itemsContentChildren(value: QueryList<CollectionNestedOption>);
    instance: DxStepper<TItem, TKey>;
    get accessKey(): string | undefined;
    set accessKey(value: string | undefined);
    get activeStateEnabled(): boolean;
    set activeStateEnabled(value: boolean);
    get dataSource(): Array<dxStepperItem> | DataSource | DataSourceOptions | null | Store | string;
    set dataSource(value: Array<dxStepperItem> | DataSource | DataSourceOptions | null | Store | string);
    get disabled(): boolean;
    set disabled(value: boolean);
    get elementAttr(): Record<string, any>;
    set elementAttr(value: Record<string, any>);
    get focusStateEnabled(): boolean;
    set focusStateEnabled(value: boolean);
    get height(): number | string | undefined;
    set height(value: number | string | undefined);
    get hint(): string | undefined;
    set hint(value: string | undefined);
    get hoverStateEnabled(): boolean;
    set hoverStateEnabled(value: boolean);
    get items(): Array<dxStepperItem>;
    set items(value: Array<dxStepperItem>);
    get itemTemplate(): any;
    set itemTemplate(value: any);
    get linear(): boolean;
    set linear(value: boolean);
    get orientation(): Orientation;
    set orientation(value: Orientation);
    get rtlEnabled(): boolean;
    set rtlEnabled(value: boolean);
    get selectedIndex(): number;
    set selectedIndex(value: number);
    get selectedItem(): any | null;
    set selectedItem(value: any | null);
    get selectOnFocus(): boolean;
    set selectOnFocus(value: boolean);
    get tabIndex(): number;
    set tabIndex(value: number);
    get visible(): boolean;
    set visible(value: boolean);
    get width(): number | string | undefined;
    set width(value: number | string | undefined);
    /**
    
     * [descr:undefined]
    
    
     */
    onDisposing: EventEmitter<DisposingEvent>;
    /**
    
     * [descr:undefined]
    
    
     */
    onInitialized: EventEmitter<InitializedEvent>;
    /**
    
     * [descr:undefined]
    
    
     */
    onItemClick: EventEmitter<ItemClickEvent>;
    /**
    
     * [descr:undefined]
    
    
     */
    onItemContextMenu: EventEmitter<ItemContextMenuEvent>;
    /**
    
     * [descr:undefined]
    
    
     */
    onItemRendered: EventEmitter<ItemRenderedEvent>;
    /**
    
     * [descr:undefined]
    
    
     */
    onOptionChanged: EventEmitter<OptionChangedEvent>;
    /**
    
     * [descr:undefined]
    
    
     */
    onSelectionChanged: EventEmitter<SelectionChangedEvent>;
    /**
    
     * [descr:undefined]
    
    
     */
    onSelectionChanging: EventEmitter<SelectionChangingEvent>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    accessKeyChange: EventEmitter<string | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    activeStateEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    dataSourceChange: EventEmitter<Array<dxStepperItem> | DataSource | DataSourceOptions | null | Store | string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    disabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    elementAttrChange: EventEmitter<Record<string, any>>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    focusStateEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    heightChange: EventEmitter<number | string | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    hintChange: EventEmitter<string | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    hoverStateEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    itemsChange: EventEmitter<Array<dxStepperItem>>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    itemTemplateChange: EventEmitter<any>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    linearChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    orientationChange: EventEmitter<Orientation>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    rtlEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    selectedIndexChange: EventEmitter<number>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    selectedItemChange: EventEmitter<any | null>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    selectOnFocusChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    tabIndexChange: EventEmitter<number>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    visibleChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    widthChange: EventEmitter<number | string | undefined>;
    constructor(elementRef: ElementRef, ngZone: NgZone, templateHost: DxTemplateHost, _watcherHelper: WatcherHelper, _idh: IterableDifferHelper, optionHost: NestedOptionHost, transferState: TransferState, platformId: any);
    protected _createInstance(element: any, options: any): DxStepper<any, any>;
    ngOnDestroy(): void;
    ngOnChanges(changes: SimpleChanges): void;
    setupChanges(prop: string, changes: SimpleChanges): void;
    ngDoCheck(): void;
    _setOption(name: string, value: any): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxStepperComponent<any, any>, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxStepperComponent<any, any>, "dx-stepper", never, { "accessKey": { "alias": "accessKey"; "required": false; }; "activeStateEnabled": { "alias": "activeStateEnabled"; "required": false; }; "dataSource": { "alias": "dataSource"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "elementAttr": { "alias": "elementAttr"; "required": false; }; "focusStateEnabled": { "alias": "focusStateEnabled"; "required": false; }; "height": { "alias": "height"; "required": false; }; "hint": { "alias": "hint"; "required": false; }; "hoverStateEnabled": { "alias": "hoverStateEnabled"; "required": false; }; "items": { "alias": "items"; "required": false; }; "itemTemplate": { "alias": "itemTemplate"; "required": false; }; "linear": { "alias": "linear"; "required": false; }; "orientation": { "alias": "orientation"; "required": false; }; "rtlEnabled": { "alias": "rtlEnabled"; "required": false; }; "selectedIndex": { "alias": "selectedIndex"; "required": false; }; "selectedItem": { "alias": "selectedItem"; "required": false; }; "selectOnFocus": { "alias": "selectOnFocus"; "required": false; }; "tabIndex": { "alias": "tabIndex"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, { "onDisposing": "onDisposing"; "onInitialized": "onInitialized"; "onItemClick": "onItemClick"; "onItemContextMenu": "onItemContextMenu"; "onItemRendered": "onItemRendered"; "onOptionChanged": "onOptionChanged"; "onSelectionChanged": "onSelectionChanged"; "onSelectionChanging": "onSelectionChanging"; "accessKeyChange": "accessKeyChange"; "activeStateEnabledChange": "activeStateEnabledChange"; "dataSourceChange": "dataSourceChange"; "disabledChange": "disabledChange"; "elementAttrChange": "elementAttrChange"; "focusStateEnabledChange": "focusStateEnabledChange"; "heightChange": "heightChange"; "hintChange": "hintChange"; "hoverStateEnabledChange": "hoverStateEnabledChange"; "itemsChange": "itemsChange"; "itemTemplateChange": "itemTemplateChange"; "linearChange": "linearChange"; "orientationChange": "orientationChange"; "rtlEnabledChange": "rtlEnabledChange"; "selectedIndexChange": "selectedIndexChange"; "selectedItemChange": "selectedItemChange"; "selectOnFocusChange": "selectOnFocusChange"; "tabIndexChange": "tabIndexChange"; "visibleChange": "visibleChange"; "widthChange": "widthChange"; }, ["_itemsContentChildren"], never, true, never>;
}
declare class DxStepperModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxStepperModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxStepperModule, never, [typeof DxStepperComponent, typeof i1.DxiStepperItemModule, typeof i2.DxIntegrationModule, typeof i2.DxTemplateModule], [typeof DxStepperComponent, typeof i1.DxiStepperItemModule, typeof i2.DxTemplateModule]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxStepperModule>;
}

export { DxStepperComponent, DxStepperModule };
//# sourceMappingURL=index.d.ts.map
