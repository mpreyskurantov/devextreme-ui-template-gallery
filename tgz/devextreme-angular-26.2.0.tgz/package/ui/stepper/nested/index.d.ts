import * as i0 from '@angular/core';
import { AfterViewInit, Renderer2, ElementRef } from '@angular/core';
import { CollectionNestedOption, IDxTemplateHost, NestedOptionHost, DxTemplateHost, DxTemplateDirective } from 'devextreme-angular/core';

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxiStepperItemComponent extends CollectionNestedOption implements AfterViewInit, IDxTemplateHost {
    private renderer;
    private document;
    private element;
    get disabled(): boolean;
    set disabled(value: boolean);
    get hint(): string;
    set hint(value: string);
    get icon(): string;
    set icon(value: string);
    get isValid(): boolean;
    set isValid(value: boolean);
    get label(): string;
    set label(value: string);
    get optional(): boolean;
    set optional(value: boolean);
    get template(): any;
    set template(value: any);
    get text(): string;
    set text(value: string);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost, renderer: Renderer2, document: any, templateHost: DxTemplateHost, element: ElementRef);
    setTemplate(template: DxTemplateDirective): void;
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiStepperItemComponent, [{ host: true; skipSelf: true; }, { host: true; }, null, null, { host: true; }, null]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiStepperItemComponent, "dxi-stepper-item", never, { "disabled": { "alias": "disabled"; "required": false; }; "hint": { "alias": "hint"; "required": false; }; "icon": { "alias": "icon"; "required": false; }; "isValid": { "alias": "isValid"; "required": false; }; "label": { "alias": "label"; "required": false; }; "optional": { "alias": "optional"; "required": false; }; "template": { "alias": "template"; "required": false; }; "text": { "alias": "text"; "required": false; }; }, {}, never, ["*"], true, never>;
}
declare class DxiStepperItemModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiStepperItemModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiStepperItemModule, never, [typeof DxiStepperItemComponent], [typeof DxiStepperItemComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiStepperItemModule>;
}

export { DxiStepperItemComponent, DxiStepperItemModule };
//# sourceMappingURL=index.d.ts.map
