import * as i0 from '@angular/core';
import { OnDestroy, OnChanges, DoCheck, QueryList, EventEmitter, ElementRef, NgZone, TransferState, SimpleChanges } from '@angular/core';
import { AIIntegration } from 'devextreme/common/ai-integration';
import { Mode } from 'devextreme/common';
import DxForm, { dxFormSimpleItem, dxFormGroupItem, dxFormTabbedItem, dxFormEmptyItem, dxFormButtonItem, LabelLocation, FormLabelMode, ContentReadyEvent, DisposingEvent, EditorEnterKeyEvent, FieldDataChangedEvent, InitializedEvent, OptionChangedEvent, SmartPastedEvent, SmartPastingEvent } from 'devextreme/ui/form';
import * as i3 from 'devextreme-angular/core';
import { DxComponent, CollectionNestedOption, DxTemplateHost, WatcherHelper, IterableDifferHelper, NestedOptionHost } from 'devextreme-angular/core';
import * as i1 from 'devextreme-angular/ui/nested';
import * as i2 from 'devextreme-angular/ui/form/nested';
export * from 'devextreme-angular/ui/form/nested';
import * as form_types from 'devextreme/ui/form_types';
export { form_types as DxFormTypes };

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

/**
 * [descr:dxForm]

 */
declare class DxFormComponent extends DxComponent implements OnDestroy, OnChanges, DoCheck {
    private _watcherHelper;
    private _idh;
    set _validationRulesContentChildren(value: QueryList<CollectionNestedOption>);
    set _itemsContentChildren(value: QueryList<CollectionNestedOption>);
    set _tabsContentChildren(value: QueryList<CollectionNestedOption>);
    instance: DxForm;
    /**
     * [descr:WidgetOptions.accessKey]
    
     */
    get accessKey(): string | undefined;
    set accessKey(value: string | undefined);
    /**
     * [descr:WidgetOptions.activeStateEnabled]
    
     */
    get activeStateEnabled(): boolean;
    set activeStateEnabled(value: boolean);
    get aiIntegration(): AIIntegration | undefined;
    set aiIntegration(value: AIIntegration | undefined);
    /**
     * [descr:dxFormOptions.alignItemLabels]
    
     */
    get alignItemLabels(): boolean;
    set alignItemLabels(value: boolean);
    /**
     * [descr:dxFormOptions.alignItemLabelsInAllGroups]
    
     */
    get alignItemLabelsInAllGroups(): boolean;
    set alignItemLabelsInAllGroups(value: boolean);
    /**
     * [descr:dxFormOptions.colCount]
    
     */
    get colCount(): Mode | number;
    set colCount(value: Mode | number);
    /**
     * [descr:dxFormOptions.colCountByScreen]
    
     */
    get colCountByScreen(): {
        lg?: number | undefined;
        md?: number | undefined;
        sm?: number | undefined;
        xs?: number | undefined;
    };
    set colCountByScreen(value: {
        lg?: number | undefined;
        md?: number | undefined;
        sm?: number | undefined;
        xs?: number | undefined;
    });
    /**
     * [descr:dxFormOptions.customizeItem]
    
     */
    get customizeItem(): ((item: dxFormSimpleItem | dxFormGroupItem | dxFormTabbedItem | dxFormEmptyItem | dxFormButtonItem) => void);
    set customizeItem(value: ((item: dxFormSimpleItem | dxFormGroupItem | dxFormTabbedItem | dxFormEmptyItem | dxFormButtonItem) => void));
    /**
     * [descr:WidgetOptions.disabled]
    
     */
    get disabled(): boolean;
    set disabled(value: boolean);
    /**
     * [descr:DOMComponentOptions.elementAttr]
    
     */
    get elementAttr(): Record<string, any>;
    set elementAttr(value: Record<string, any>);
    /**
     * [descr:WidgetOptions.focusStateEnabled]
    
     */
    get focusStateEnabled(): boolean;
    set focusStateEnabled(value: boolean);
    /**
     * [descr:dxFormOptions.formData]
    
     */
    get formData(): any;
    set formData(value: any);
    /**
     * [descr:DOMComponentOptions.height]
    
     */
    get height(): number | string | undefined;
    set height(value: number | string | undefined);
    /**
     * [descr:WidgetOptions.hint]
    
     */
    get hint(): string | undefined;
    set hint(value: string | undefined);
    /**
     * [descr:WidgetOptions.hoverStateEnabled]
    
     */
    get hoverStateEnabled(): boolean;
    set hoverStateEnabled(value: boolean);
    /**
     * [descr:dxFormOptions.isDirty]
    
     */
    get isDirty(): boolean;
    set isDirty(value: boolean);
    /**
     * [descr:dxFormOptions.items]
    
     */
    get items(): Array<dxFormButtonItem | dxFormEmptyItem | dxFormGroupItem | dxFormSimpleItem | dxFormTabbedItem>;
    set items(value: Array<dxFormButtonItem | dxFormEmptyItem | dxFormGroupItem | dxFormSimpleItem | dxFormTabbedItem>);
    /**
     * [descr:dxFormOptions.labelLocation]
    
     */
    get labelLocation(): LabelLocation;
    set labelLocation(value: LabelLocation);
    /**
     * [descr:dxFormOptions.labelMode]
    
     */
    get labelMode(): FormLabelMode;
    set labelMode(value: FormLabelMode);
    /**
     * [descr:dxFormOptions.minColWidth]
    
     */
    get minColWidth(): number;
    set minColWidth(value: number);
    /**
     * [descr:dxFormOptions.optionalMark]
    
     */
    get optionalMark(): string;
    set optionalMark(value: string);
    /**
     * [descr:dxFormOptions.readOnly]
    
     */
    get readOnly(): boolean;
    set readOnly(value: boolean);
    /**
     * [descr:dxFormOptions.requiredMark]
    
     */
    get requiredMark(): string;
    set requiredMark(value: string);
    /**
     * [descr:dxFormOptions.requiredMessage]
    
     */
    get requiredMessage(): string;
    set requiredMessage(value: string);
    /**
     * [descr:DOMComponentOptions.rtlEnabled]
    
     */
    get rtlEnabled(): boolean;
    set rtlEnabled(value: boolean);
    /**
     * [descr:dxFormOptions.screenByWidth]
    
     */
    get screenByWidth(): Function;
    set screenByWidth(value: Function);
    /**
     * [descr:dxFormOptions.scrollingEnabled]
    
     */
    get scrollingEnabled(): boolean;
    set scrollingEnabled(value: boolean);
    /**
     * [descr:dxFormOptions.showColonAfterLabel]
    
     */
    get showColonAfterLabel(): boolean;
    set showColonAfterLabel(value: boolean);
    /**
     * [descr:dxFormOptions.showOptionalMark]
    
     */
    get showOptionalMark(): boolean;
    set showOptionalMark(value: boolean);
    /**
     * [descr:dxFormOptions.showRequiredMark]
    
     */
    get showRequiredMark(): boolean;
    set showRequiredMark(value: boolean);
    /**
     * [descr:dxFormOptions.showValidationSummary]
    
     */
    get showValidationSummary(): boolean;
    set showValidationSummary(value: boolean);
    /**
     * [descr:WidgetOptions.tabIndex]
    
     */
    get tabIndex(): number;
    set tabIndex(value: number);
    /**
     * [descr:dxFormOptions.validationGroup]
    
     */
    get validationGroup(): string | undefined;
    set validationGroup(value: string | undefined);
    /**
     * [descr:WidgetOptions.visible]
    
     */
    get visible(): boolean;
    set visible(value: boolean);
    /**
     * [descr:DOMComponentOptions.width]
    
     */
    get width(): number | string | undefined;
    set width(value: number | string | undefined);
    /**
    
     * [descr:dxFormOptions.onContentReady]
    
    
     */
    onContentReady: EventEmitter<ContentReadyEvent>;
    /**
    
     * [descr:dxFormOptions.onDisposing]
    
    
     */
    onDisposing: EventEmitter<DisposingEvent>;
    /**
    
     * [descr:dxFormOptions.onEditorEnterKey]
    
    
     */
    onEditorEnterKey: EventEmitter<EditorEnterKeyEvent>;
    /**
    
     * [descr:dxFormOptions.onFieldDataChanged]
    
    
     */
    onFieldDataChanged: EventEmitter<FieldDataChangedEvent>;
    /**
    
     * [descr:dxFormOptions.onInitialized]
    
    
     */
    onInitialized: EventEmitter<InitializedEvent>;
    /**
    
     * [descr:dxFormOptions.onOptionChanged]
    
    
     */
    onOptionChanged: EventEmitter<OptionChangedEvent>;
    /**
    
     * [descr:undefined]
    
    
     */
    onSmartPasted: EventEmitter<SmartPastedEvent>;
    /**
    
     * [descr:undefined]
    
    
     */
    onSmartPasting: EventEmitter<SmartPastingEvent>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    accessKeyChange: EventEmitter<string | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    activeStateEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    aiIntegrationChange: EventEmitter<AIIntegration | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    alignItemLabelsChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    alignItemLabelsInAllGroupsChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    colCountChange: EventEmitter<Mode | number>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    colCountByScreenChange: EventEmitter<{
        lg?: number | undefined;
        md?: number | undefined;
        sm?: number | undefined;
        xs?: number | undefined;
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    customizeItemChange: EventEmitter<((item: dxFormSimpleItem | dxFormGroupItem | dxFormTabbedItem | dxFormEmptyItem | dxFormButtonItem) => void)>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    disabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    elementAttrChange: EventEmitter<Record<string, any>>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    focusStateEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    formDataChange: EventEmitter<any>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    heightChange: EventEmitter<number | string | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    hintChange: EventEmitter<string | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    hoverStateEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    isDirtyChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    itemsChange: EventEmitter<Array<dxFormButtonItem | dxFormEmptyItem | dxFormGroupItem | dxFormSimpleItem | dxFormTabbedItem>>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    labelLocationChange: EventEmitter<LabelLocation>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    labelModeChange: EventEmitter<FormLabelMode>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    minColWidthChange: EventEmitter<number>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    optionalMarkChange: EventEmitter<string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    readOnlyChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    requiredMarkChange: EventEmitter<string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    requiredMessageChange: EventEmitter<string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    rtlEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    screenByWidthChange: EventEmitter<Function>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    scrollingEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    showColonAfterLabelChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    showOptionalMarkChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    showRequiredMarkChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    showValidationSummaryChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    tabIndexChange: EventEmitter<number>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    validationGroupChange: EventEmitter<string | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    visibleChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    widthChange: EventEmitter<number | string | undefined>;
    constructor(elementRef: ElementRef, ngZone: NgZone, templateHost: DxTemplateHost, _watcherHelper: WatcherHelper, _idh: IterableDifferHelper, optionHost: NestedOptionHost, transferState: TransferState, platformId: any);
    protected _createInstance(element: any, options: any): DxForm;
    ngOnDestroy(): void;
    ngOnChanges(changes: SimpleChanges): void;
    setupChanges(prop: string, changes: SimpleChanges): void;
    ngDoCheck(): void;
    _setOption(name: string, value: any): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxFormComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxFormComponent, "dx-form", never, { "accessKey": { "alias": "accessKey"; "required": false; }; "activeStateEnabled": { "alias": "activeStateEnabled"; "required": false; }; "aiIntegration": { "alias": "aiIntegration"; "required": false; }; "alignItemLabels": { "alias": "alignItemLabels"; "required": false; }; "alignItemLabelsInAllGroups": { "alias": "alignItemLabelsInAllGroups"; "required": false; }; "colCount": { "alias": "colCount"; "required": false; }; "colCountByScreen": { "alias": "colCountByScreen"; "required": false; }; "customizeItem": { "alias": "customizeItem"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "elementAttr": { "alias": "elementAttr"; "required": false; }; "focusStateEnabled": { "alias": "focusStateEnabled"; "required": false; }; "formData": { "alias": "formData"; "required": false; }; "height": { "alias": "height"; "required": false; }; "hint": { "alias": "hint"; "required": false; }; "hoverStateEnabled": { "alias": "hoverStateEnabled"; "required": false; }; "isDirty": { "alias": "isDirty"; "required": false; }; "items": { "alias": "items"; "required": false; }; "labelLocation": { "alias": "labelLocation"; "required": false; }; "labelMode": { "alias": "labelMode"; "required": false; }; "minColWidth": { "alias": "minColWidth"; "required": false; }; "optionalMark": { "alias": "optionalMark"; "required": false; }; "readOnly": { "alias": "readOnly"; "required": false; }; "requiredMark": { "alias": "requiredMark"; "required": false; }; "requiredMessage": { "alias": "requiredMessage"; "required": false; }; "rtlEnabled": { "alias": "rtlEnabled"; "required": false; }; "screenByWidth": { "alias": "screenByWidth"; "required": false; }; "scrollingEnabled": { "alias": "scrollingEnabled"; "required": false; }; "showColonAfterLabel": { "alias": "showColonAfterLabel"; "required": false; }; "showOptionalMark": { "alias": "showOptionalMark"; "required": false; }; "showRequiredMark": { "alias": "showRequiredMark"; "required": false; }; "showValidationSummary": { "alias": "showValidationSummary"; "required": false; }; "tabIndex": { "alias": "tabIndex"; "required": false; }; "validationGroup": { "alias": "validationGroup"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, { "onContentReady": "onContentReady"; "onDisposing": "onDisposing"; "onEditorEnterKey": "onEditorEnterKey"; "onFieldDataChanged": "onFieldDataChanged"; "onInitialized": "onInitialized"; "onOptionChanged": "onOptionChanged"; "onSmartPasted": "onSmartPasted"; "onSmartPasting": "onSmartPasting"; "accessKeyChange": "accessKeyChange"; "activeStateEnabledChange": "activeStateEnabledChange"; "aiIntegrationChange": "aiIntegrationChange"; "alignItemLabelsChange": "alignItemLabelsChange"; "alignItemLabelsInAllGroupsChange": "alignItemLabelsInAllGroupsChange"; "colCountChange": "colCountChange"; "colCountByScreenChange": "colCountByScreenChange"; "customizeItemChange": "customizeItemChange"; "disabledChange": "disabledChange"; "elementAttrChange": "elementAttrChange"; "focusStateEnabledChange": "focusStateEnabledChange"; "formDataChange": "formDataChange"; "heightChange": "heightChange"; "hintChange": "hintChange"; "hoverStateEnabledChange": "hoverStateEnabledChange"; "isDirtyChange": "isDirtyChange"; "itemsChange": "itemsChange"; "labelLocationChange": "labelLocationChange"; "labelModeChange": "labelModeChange"; "minColWidthChange": "minColWidthChange"; "optionalMarkChange": "optionalMarkChange"; "readOnlyChange": "readOnlyChange"; "requiredMarkChange": "requiredMarkChange"; "requiredMessageChange": "requiredMessageChange"; "rtlEnabledChange": "rtlEnabledChange"; "screenByWidthChange": "screenByWidthChange"; "scrollingEnabledChange": "scrollingEnabledChange"; "showColonAfterLabelChange": "showColonAfterLabelChange"; "showOptionalMarkChange": "showOptionalMarkChange"; "showRequiredMarkChange": "showRequiredMarkChange"; "showValidationSummaryChange": "showValidationSummaryChange"; "tabIndexChange": "tabIndexChange"; "validationGroupChange": "validationGroupChange"; "visibleChange": "visibleChange"; "widthChange": "widthChange"; }, ["_validationRulesContentChildren", "_itemsContentChildren", "_tabsContentChildren"], never, true, never>;
}
declare class DxFormModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxFormModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxFormModule, never, [typeof DxFormComponent, typeof i1.DxoColCountByScreenModule, typeof i1.DxiItemModule, typeof i1.DxoLabelModule, typeof i1.DxiValidationRuleModule, typeof i1.DxoTabPanelOptionsModule, typeof i1.DxiTabModule, typeof i1.DxoButtonOptionsModule, typeof i2.DxoFormAIOptionsModule, typeof i2.DxiFormAsyncRuleModule, typeof i2.DxiFormButtonItemModule, typeof i2.DxoFormButtonOptionsModule, typeof i2.DxoFormColCountByScreenModule, typeof i2.DxiFormCompareRuleModule, typeof i2.DxiFormCustomRuleModule, typeof i2.DxiFormEmailRuleModule, typeof i2.DxiFormEmptyItemModule, typeof i2.DxiFormGroupItemModule, typeof i2.DxiFormItemModule, typeof i2.DxoFormLabelModule, typeof i2.DxiFormNumericRuleModule, typeof i2.DxiFormPatternRuleModule, typeof i2.DxiFormRangeRuleModule, typeof i2.DxiFormRequiredRuleModule, typeof i2.DxiFormSimpleItemModule, typeof i2.DxiFormStringLengthRuleModule, typeof i2.DxiFormTabModule, typeof i2.DxiFormTabbedItemModule, typeof i2.DxoFormTabPanelOptionsModule, typeof i2.DxiFormTabPanelOptionsItemModule, typeof i2.DxiFormValidationRuleModule, typeof i3.DxIntegrationModule, typeof i3.DxTemplateModule], [typeof DxFormComponent, typeof i1.DxoColCountByScreenModule, typeof i1.DxiItemModule, typeof i1.DxoLabelModule, typeof i1.DxiValidationRuleModule, typeof i1.DxoTabPanelOptionsModule, typeof i1.DxiTabModule, typeof i1.DxoButtonOptionsModule, typeof i2.DxoFormAIOptionsModule, typeof i2.DxiFormAsyncRuleModule, typeof i2.DxiFormButtonItemModule, typeof i2.DxoFormButtonOptionsModule, typeof i2.DxoFormColCountByScreenModule, typeof i2.DxiFormCompareRuleModule, typeof i2.DxiFormCustomRuleModule, typeof i2.DxiFormEmailRuleModule, typeof i2.DxiFormEmptyItemModule, typeof i2.DxiFormGroupItemModule, typeof i2.DxiFormItemModule, typeof i2.DxoFormLabelModule, typeof i2.DxiFormNumericRuleModule, typeof i2.DxiFormPatternRuleModule, typeof i2.DxiFormRangeRuleModule, typeof i2.DxiFormRequiredRuleModule, typeof i2.DxiFormSimpleItemModule, typeof i2.DxiFormStringLengthRuleModule, typeof i2.DxiFormTabModule, typeof i2.DxiFormTabbedItemModule, typeof i2.DxoFormTabPanelOptionsModule, typeof i2.DxiFormTabPanelOptionsItemModule, typeof i2.DxiFormValidationRuleModule, typeof i3.DxTemplateModule]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxFormModule>;
}

export { DxFormComponent, DxFormModule };
//# sourceMappingURL=index.d.ts.map
