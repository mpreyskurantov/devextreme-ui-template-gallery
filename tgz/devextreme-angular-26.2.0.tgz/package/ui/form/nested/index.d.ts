import * as i0 from '@angular/core';
import { OnDestroy, OnInit, AfterViewInit, Renderer2, ElementRef, QueryList, EventEmitter } from '@angular/core';
import { NestedOption, NestedOptionHost, CollectionNestedOption, IDxTemplateHost, DxTemplateHost, DxTemplateDirective } from 'devextreme-angular/core';
import * as CommonTypes from 'devextreme/common';
import { ValidationRuleType, HorizontalAlignment, VerticalAlignment, ButtonStyle, ButtonType, ComparisonOperator, TabsIconPosition, TabsStyle, Position } from 'devextreme/common';
import { dxButtonOptions, ClickEvent, ContentReadyEvent, DisposingEvent, InitializedEvent, OptionChangedEvent } from 'devextreme/ui/button';
import { FormItemType, FormPredefinedButtonItem, dxFormButtonItem, dxFormEmptyItem, dxFormGroupItem, dxFormSimpleItem, dxFormTabbedItem, FormItemComponent, LabelLocation } from 'devextreme/ui/form';
import { dxTabPanelOptions, dxTabPanelItem, ContentReadyEvent as ContentReadyEvent$1, DisposingEvent as DisposingEvent$1, InitializedEvent as InitializedEvent$1, ItemClickEvent, ItemContextMenuEvent, ItemHoldEvent, ItemRenderedEvent, OptionChangedEvent as OptionChangedEvent$1, SelectionChangedEvent, SelectionChangingEvent, TitleClickEvent, TitleHoldEvent, TitleRenderedEvent } from 'devextreme/ui/tab_panel';
import DataSource, { DataSourceOptions } from 'devextreme/data/data_source';
import { Store } from 'devextreme/data/store';

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoFormAIOptionsComponent extends NestedOption implements OnDestroy, OnInit {
    get disabled(): boolean;
    set disabled(value: boolean);
    get instruction(): string | undefined;
    set instruction(value: string | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoFormAIOptionsComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoFormAIOptionsComponent, "dxo-form-ai-options", never, { "disabled": { "alias": "disabled"; "required": false; }; "instruction": { "alias": "instruction"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoFormAIOptionsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoFormAIOptionsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoFormAIOptionsModule, never, [typeof DxoFormAIOptionsComponent], [typeof DxoFormAIOptionsComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoFormAIOptionsModule>;
}

declare class DxiFormAsyncRuleComponent extends CollectionNestedOption {
    get ignoreEmptyValue(): boolean;
    set ignoreEmptyValue(value: boolean);
    get message(): string;
    set message(value: string);
    get reevaluate(): boolean;
    set reevaluate(value: boolean);
    get type(): ValidationRuleType;
    set type(value: ValidationRuleType);
    get validationCallback(): ((options: {
        column: Record<string, any>;
        data: Record<string, any>;
        formItem: Record<string, any>;
        rule: Record<string, any>;
        validator: Record<string, any>;
        value: any;
    }) => any);
    set validationCallback(value: ((options: {
        column: Record<string, any>;
        data: Record<string, any>;
        formItem: Record<string, any>;
        rule: Record<string, any>;
        validator: Record<string, any>;
        value: any;
    }) => any));
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiFormAsyncRuleComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiFormAsyncRuleComponent, "dxi-form-async-rule", never, { "ignoreEmptyValue": { "alias": "ignoreEmptyValue"; "required": false; }; "message": { "alias": "message"; "required": false; }; "reevaluate": { "alias": "reevaluate"; "required": false; }; "type": { "alias": "type"; "required": false; }; "validationCallback": { "alias": "validationCallback"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxiFormAsyncRuleModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiFormAsyncRuleModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiFormAsyncRuleModule, never, [typeof DxiFormAsyncRuleComponent], [typeof DxiFormAsyncRuleComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiFormAsyncRuleModule>;
}

declare class DxiFormButtonItemComponent extends CollectionNestedOption {
    get buttonOptions(): dxButtonOptions | undefined;
    set buttonOptions(value: dxButtonOptions | undefined);
    get colSpan(): number | undefined;
    set colSpan(value: number | undefined);
    get cssClass(): string | undefined;
    set cssClass(value: string | undefined);
    get horizontalAlignment(): HorizontalAlignment;
    set horizontalAlignment(value: HorizontalAlignment);
    get itemType(): FormItemType;
    set itemType(value: FormItemType);
    get name(): FormPredefinedButtonItem | string | undefined;
    set name(value: FormPredefinedButtonItem | string | undefined);
    get verticalAlignment(): VerticalAlignment;
    set verticalAlignment(value: VerticalAlignment);
    get visible(): boolean;
    set visible(value: boolean);
    get visibleIndex(): number | undefined;
    set visibleIndex(value: number | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiFormButtonItemComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiFormButtonItemComponent, "dxi-form-button-item", never, { "buttonOptions": { "alias": "buttonOptions"; "required": false; }; "colSpan": { "alias": "colSpan"; "required": false; }; "cssClass": { "alias": "cssClass"; "required": false; }; "horizontalAlignment": { "alias": "horizontalAlignment"; "required": false; }; "itemType": { "alias": "itemType"; "required": false; }; "name": { "alias": "name"; "required": false; }; "verticalAlignment": { "alias": "verticalAlignment"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "visibleIndex": { "alias": "visibleIndex"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxiFormButtonItemModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiFormButtonItemModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiFormButtonItemModule, never, [typeof DxiFormButtonItemComponent], [typeof DxiFormButtonItemComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiFormButtonItemModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoFormButtonOptionsComponent extends NestedOption implements AfterViewInit, OnDestroy, OnInit, IDxTemplateHost {
    private renderer;
    private document;
    private element;
    get accessKey(): string | undefined;
    set accessKey(value: string | undefined);
    get activeStateEnabled(): boolean;
    set activeStateEnabled(value: boolean);
    get disabled(): boolean;
    set disabled(value: boolean);
    get elementAttr(): Record<string, any>;
    set elementAttr(value: Record<string, any>);
    get focusStateEnabled(): boolean;
    set focusStateEnabled(value: boolean);
    get height(): number | string | undefined;
    set height(value: number | string | undefined);
    get hint(): string | undefined;
    set hint(value: string | undefined);
    get hoverStateEnabled(): boolean;
    set hoverStateEnabled(value: boolean);
    get icon(): string;
    set icon(value: string);
    get onClick(): ((e: ClickEvent) => void) | undefined;
    set onClick(value: ((e: ClickEvent) => void) | undefined);
    get onContentReady(): ((e: ContentReadyEvent) => void);
    set onContentReady(value: ((e: ContentReadyEvent) => void));
    get onDisposing(): ((e: DisposingEvent) => void);
    set onDisposing(value: ((e: DisposingEvent) => void));
    get onInitialized(): ((e: InitializedEvent) => void);
    set onInitialized(value: ((e: InitializedEvent) => void));
    get onOptionChanged(): ((e: OptionChangedEvent) => void);
    set onOptionChanged(value: ((e: OptionChangedEvent) => void));
    get rtlEnabled(): boolean;
    set rtlEnabled(value: boolean);
    get stylingMode(): ButtonStyle;
    set stylingMode(value: ButtonStyle);
    get tabIndex(): number;
    set tabIndex(value: number);
    get template(): any;
    set template(value: any);
    get text(): string;
    set text(value: string);
    get type(): ButtonType | string;
    set type(value: ButtonType | string);
    get useSubmitBehavior(): boolean;
    set useSubmitBehavior(value: boolean);
    get validationGroup(): string | undefined;
    set validationGroup(value: string | undefined);
    get visible(): boolean;
    set visible(value: boolean);
    get width(): number | string | undefined;
    set width(value: number | string | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost, renderer: Renderer2, document: any, templateHost: DxTemplateHost, element: ElementRef);
    setTemplate(template: DxTemplateDirective): void;
    ngAfterViewInit(): void;
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoFormButtonOptionsComponent, [{ host: true; skipSelf: true; }, { host: true; }, null, null, { host: true; }, null]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoFormButtonOptionsComponent, "dxo-form-button-options", never, { "accessKey": { "alias": "accessKey"; "required": false; }; "activeStateEnabled": { "alias": "activeStateEnabled"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "elementAttr": { "alias": "elementAttr"; "required": false; }; "focusStateEnabled": { "alias": "focusStateEnabled"; "required": false; }; "height": { "alias": "height"; "required": false; }; "hint": { "alias": "hint"; "required": false; }; "hoverStateEnabled": { "alias": "hoverStateEnabled"; "required": false; }; "icon": { "alias": "icon"; "required": false; }; "onClick": { "alias": "onClick"; "required": false; }; "onContentReady": { "alias": "onContentReady"; "required": false; }; "onDisposing": { "alias": "onDisposing"; "required": false; }; "onInitialized": { "alias": "onInitialized"; "required": false; }; "onOptionChanged": { "alias": "onOptionChanged"; "required": false; }; "rtlEnabled": { "alias": "rtlEnabled"; "required": false; }; "stylingMode": { "alias": "stylingMode"; "required": false; }; "tabIndex": { "alias": "tabIndex"; "required": false; }; "template": { "alias": "template"; "required": false; }; "text": { "alias": "text"; "required": false; }; "type": { "alias": "type"; "required": false; }; "useSubmitBehavior": { "alias": "useSubmitBehavior"; "required": false; }; "validationGroup": { "alias": "validationGroup"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, ["*"], true, never>;
}
declare class DxoFormButtonOptionsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoFormButtonOptionsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoFormButtonOptionsModule, never, [typeof DxoFormButtonOptionsComponent], [typeof DxoFormButtonOptionsComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoFormButtonOptionsModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoFormColCountByScreenComponent extends NestedOption implements OnDestroy, OnInit {
    get lg(): number | undefined;
    set lg(value: number | undefined);
    get md(): number | undefined;
    set md(value: number | undefined);
    get sm(): number | undefined;
    set sm(value: number | undefined);
    get xs(): number | undefined;
    set xs(value: number | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoFormColCountByScreenComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoFormColCountByScreenComponent, "dxo-form-col-count-by-screen", never, { "lg": { "alias": "lg"; "required": false; }; "md": { "alias": "md"; "required": false; }; "sm": { "alias": "sm"; "required": false; }; "xs": { "alias": "xs"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoFormColCountByScreenModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoFormColCountByScreenModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoFormColCountByScreenModule, never, [typeof DxoFormColCountByScreenComponent], [typeof DxoFormColCountByScreenComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoFormColCountByScreenModule>;
}

declare class DxiFormCompareRuleComponent extends CollectionNestedOption {
    get comparisonTarget(): Function;
    set comparisonTarget(value: Function);
    get comparisonType(): ComparisonOperator;
    set comparisonType(value: ComparisonOperator);
    get ignoreEmptyValue(): boolean;
    set ignoreEmptyValue(value: boolean);
    get message(): string;
    set message(value: string);
    get type(): ValidationRuleType;
    set type(value: ValidationRuleType);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiFormCompareRuleComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiFormCompareRuleComponent, "dxi-form-compare-rule", never, { "comparisonTarget": { "alias": "comparisonTarget"; "required": false; }; "comparisonType": { "alias": "comparisonType"; "required": false; }; "ignoreEmptyValue": { "alias": "ignoreEmptyValue"; "required": false; }; "message": { "alias": "message"; "required": false; }; "type": { "alias": "type"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxiFormCompareRuleModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiFormCompareRuleModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiFormCompareRuleModule, never, [typeof DxiFormCompareRuleComponent], [typeof DxiFormCompareRuleComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiFormCompareRuleModule>;
}

declare class DxiFormCustomRuleComponent extends CollectionNestedOption {
    get ignoreEmptyValue(): boolean;
    set ignoreEmptyValue(value: boolean);
    get message(): string;
    set message(value: string);
    get reevaluate(): boolean;
    set reevaluate(value: boolean);
    get type(): ValidationRuleType;
    set type(value: ValidationRuleType);
    get validationCallback(): ((options: {
        column: Record<string, any>;
        data: Record<string, any>;
        formItem: Record<string, any>;
        rule: Record<string, any>;
        validator: Record<string, any>;
        value: any;
    }) => boolean);
    set validationCallback(value: ((options: {
        column: Record<string, any>;
        data: Record<string, any>;
        formItem: Record<string, any>;
        rule: Record<string, any>;
        validator: Record<string, any>;
        value: any;
    }) => boolean));
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiFormCustomRuleComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiFormCustomRuleComponent, "dxi-form-custom-rule", never, { "ignoreEmptyValue": { "alias": "ignoreEmptyValue"; "required": false; }; "message": { "alias": "message"; "required": false; }; "reevaluate": { "alias": "reevaluate"; "required": false; }; "type": { "alias": "type"; "required": false; }; "validationCallback": { "alias": "validationCallback"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxiFormCustomRuleModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiFormCustomRuleModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiFormCustomRuleModule, never, [typeof DxiFormCustomRuleComponent], [typeof DxiFormCustomRuleComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiFormCustomRuleModule>;
}

declare class DxiFormEmailRuleComponent extends CollectionNestedOption {
    get ignoreEmptyValue(): boolean;
    set ignoreEmptyValue(value: boolean);
    get message(): string;
    set message(value: string);
    get type(): ValidationRuleType;
    set type(value: ValidationRuleType);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiFormEmailRuleComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiFormEmailRuleComponent, "dxi-form-email-rule", never, { "ignoreEmptyValue": { "alias": "ignoreEmptyValue"; "required": false; }; "message": { "alias": "message"; "required": false; }; "type": { "alias": "type"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxiFormEmailRuleModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiFormEmailRuleModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiFormEmailRuleModule, never, [typeof DxiFormEmailRuleComponent], [typeof DxiFormEmailRuleComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiFormEmailRuleModule>;
}

declare class DxiFormEmptyItemComponent extends CollectionNestedOption {
    get colSpan(): number | undefined;
    set colSpan(value: number | undefined);
    get cssClass(): string | undefined;
    set cssClass(value: string | undefined);
    get itemType(): FormItemType;
    set itemType(value: FormItemType);
    get name(): string | undefined;
    set name(value: string | undefined);
    get visible(): boolean;
    set visible(value: boolean);
    get visibleIndex(): number | undefined;
    set visibleIndex(value: number | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiFormEmptyItemComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiFormEmptyItemComponent, "dxi-form-empty-item", never, { "colSpan": { "alias": "colSpan"; "required": false; }; "cssClass": { "alias": "cssClass"; "required": false; }; "itemType": { "alias": "itemType"; "required": false; }; "name": { "alias": "name"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "visibleIndex": { "alias": "visibleIndex"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxiFormEmptyItemModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiFormEmptyItemModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiFormEmptyItemModule, never, [typeof DxiFormEmptyItemComponent], [typeof DxiFormEmptyItemComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiFormEmptyItemModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxiFormGroupItemComponent extends CollectionNestedOption implements AfterViewInit, IDxTemplateHost {
    private renderer;
    private document;
    private element;
    set _itemsContentChildren(value: QueryList<CollectionNestedOption>);
    get alignItemLabels(): boolean;
    set alignItemLabels(value: boolean);
    get caption(): string | undefined;
    set caption(value: string | undefined);
    get captionTemplate(): any;
    set captionTemplate(value: any);
    get colCount(): number;
    set colCount(value: number);
    get colCountByScreen(): {
        lg?: number | undefined;
        md?: number | undefined;
        sm?: number | undefined;
        xs?: number | undefined;
    };
    set colCountByScreen(value: {
        lg?: number | undefined;
        md?: number | undefined;
        sm?: number | undefined;
        xs?: number | undefined;
    });
    get colSpan(): number | undefined;
    set colSpan(value: number | undefined);
    get cssClass(): string | undefined;
    set cssClass(value: string | undefined);
    get items(): Array<dxFormButtonItem | dxFormEmptyItem | dxFormGroupItem | dxFormSimpleItem | dxFormTabbedItem>;
    set items(value: Array<dxFormButtonItem | dxFormEmptyItem | dxFormGroupItem | dxFormSimpleItem | dxFormTabbedItem>);
    get itemType(): FormItemType;
    set itemType(value: FormItemType);
    get name(): string | undefined;
    set name(value: string | undefined);
    get template(): any;
    set template(value: any);
    get visible(): boolean;
    set visible(value: boolean);
    get visibleIndex(): number | undefined;
    set visibleIndex(value: number | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost, renderer: Renderer2, document: any, templateHost: DxTemplateHost, element: ElementRef);
    setTemplate(template: DxTemplateDirective): void;
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiFormGroupItemComponent, [{ host: true; skipSelf: true; }, { host: true; }, null, null, { host: true; }, null]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiFormGroupItemComponent, "dxi-form-group-item", never, { "alignItemLabels": { "alias": "alignItemLabels"; "required": false; }; "caption": { "alias": "caption"; "required": false; }; "captionTemplate": { "alias": "captionTemplate"; "required": false; }; "colCount": { "alias": "colCount"; "required": false; }; "colCountByScreen": { "alias": "colCountByScreen"; "required": false; }; "colSpan": { "alias": "colSpan"; "required": false; }; "cssClass": { "alias": "cssClass"; "required": false; }; "items": { "alias": "items"; "required": false; }; "itemType": { "alias": "itemType"; "required": false; }; "name": { "alias": "name"; "required": false; }; "template": { "alias": "template"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "visibleIndex": { "alias": "visibleIndex"; "required": false; }; }, {}, ["_itemsContentChildren"], ["*"], true, never>;
}
declare class DxiFormGroupItemModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiFormGroupItemModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiFormGroupItemModule, never, [typeof DxiFormGroupItemComponent], [typeof DxiFormGroupItemComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiFormGroupItemModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxiFormItemComponent extends CollectionNestedOption implements AfterViewInit, IDxTemplateHost {
    private renderer;
    private document;
    private element;
    set _validationRulesContentChildren(value: QueryList<CollectionNestedOption>);
    set _tabsContentChildren(value: QueryList<CollectionNestedOption>);
    set _itemsContentChildren(value: QueryList<CollectionNestedOption>);
    get badge(): string;
    set badge(value: string);
    get disabled(): boolean;
    set disabled(value: boolean);
    get html(): string;
    set html(value: string);
    get icon(): string;
    set icon(value: string);
    get tabTemplate(): any;
    set tabTemplate(value: any);
    get template(): any;
    set template(value: any);
    get text(): string;
    set text(value: string);
    get title(): string;
    set title(value: string);
    get visible(): boolean;
    set visible(value: boolean);
    get aiOptions(): {
        disabled?: boolean;
        instruction?: string | undefined;
    };
    set aiOptions(value: {
        disabled?: boolean;
        instruction?: string | undefined;
    });
    get colSpan(): number | undefined;
    set colSpan(value: number | undefined);
    get cssClass(): string | undefined;
    set cssClass(value: string | undefined);
    get dataField(): string | undefined;
    set dataField(value: string | undefined);
    get editorOptions(): any | undefined;
    set editorOptions(value: any | undefined);
    get editorType(): FormItemComponent;
    set editorType(value: FormItemComponent);
    get helpText(): string | undefined;
    set helpText(value: string | undefined);
    get isRequired(): boolean | undefined;
    set isRequired(value: boolean | undefined);
    get itemType(): FormItemType;
    set itemType(value: FormItemType);
    get label(): {
        alignment?: HorizontalAlignment;
        location?: LabelLocation;
        showColon?: boolean;
        template?: any;
        text?: string | undefined;
        visible?: boolean;
    };
    set label(value: {
        alignment?: HorizontalAlignment;
        location?: LabelLocation;
        showColon?: boolean;
        template?: any;
        text?: string | undefined;
        visible?: boolean;
    });
    get name(): string | undefined | FormPredefinedButtonItem;
    set name(value: string | undefined | FormPredefinedButtonItem);
    get validationRules(): Array<CommonTypes.ValidationRule>;
    set validationRules(value: Array<CommonTypes.ValidationRule>);
    get visibleIndex(): number | undefined;
    set visibleIndex(value: number | undefined);
    get alignItemLabels(): boolean;
    set alignItemLabels(value: boolean);
    get caption(): string | undefined;
    set caption(value: string | undefined);
    get captionTemplate(): any;
    set captionTemplate(value: any);
    get colCount(): number;
    set colCount(value: number);
    get colCountByScreen(): {
        lg?: number | undefined;
        md?: number | undefined;
        sm?: number | undefined;
        xs?: number | undefined;
    };
    set colCountByScreen(value: {
        lg?: number | undefined;
        md?: number | undefined;
        sm?: number | undefined;
        xs?: number | undefined;
    });
    get items(): Array<dxFormButtonItem | dxFormEmptyItem | dxFormGroupItem | dxFormSimpleItem | dxFormTabbedItem>;
    set items(value: Array<dxFormButtonItem | dxFormEmptyItem | dxFormGroupItem | dxFormSimpleItem | dxFormTabbedItem>);
    get tabPanelOptions(): dxTabPanelOptions | undefined;
    set tabPanelOptions(value: dxTabPanelOptions | undefined);
    get tabs(): {
        alignItemLabels?: boolean;
        badge?: string | undefined;
        colCount?: number;
        colCountByScreen?: {
            lg?: number | undefined;
            md?: number | undefined;
            sm?: number | undefined;
            xs?: number | undefined;
        };
        disabled?: boolean;
        icon?: string | undefined;
        items?: Array<dxFormButtonItem | dxFormEmptyItem | dxFormGroupItem | dxFormSimpleItem | dxFormTabbedItem>;
        tabTemplate?: any;
        template?: any;
        title?: string | undefined;
    }[];
    set tabs(value: {
        alignItemLabels?: boolean;
        badge?: string | undefined;
        colCount?: number;
        colCountByScreen?: {
            lg?: number | undefined;
            md?: number | undefined;
            sm?: number | undefined;
            xs?: number | undefined;
        };
        disabled?: boolean;
        icon?: string | undefined;
        items?: Array<dxFormButtonItem | dxFormEmptyItem | dxFormGroupItem | dxFormSimpleItem | dxFormTabbedItem>;
        tabTemplate?: any;
        template?: any;
        title?: string | undefined;
    }[]);
    get buttonOptions(): dxButtonOptions | undefined;
    set buttonOptions(value: dxButtonOptions | undefined);
    get horizontalAlignment(): HorizontalAlignment;
    set horizontalAlignment(value: HorizontalAlignment);
    get verticalAlignment(): VerticalAlignment;
    set verticalAlignment(value: VerticalAlignment);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost, renderer: Renderer2, document: any, templateHost: DxTemplateHost, element: ElementRef);
    setTemplate(template: DxTemplateDirective): void;
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiFormItemComponent, [{ host: true; skipSelf: true; }, { host: true; }, null, null, { host: true; }, null]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiFormItemComponent, "dxi-form-item", never, { "badge": { "alias": "badge"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "html": { "alias": "html"; "required": false; }; "icon": { "alias": "icon"; "required": false; }; "tabTemplate": { "alias": "tabTemplate"; "required": false; }; "template": { "alias": "template"; "required": false; }; "text": { "alias": "text"; "required": false; }; "title": { "alias": "title"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "aiOptions": { "alias": "aiOptions"; "required": false; }; "colSpan": { "alias": "colSpan"; "required": false; }; "cssClass": { "alias": "cssClass"; "required": false; }; "dataField": { "alias": "dataField"; "required": false; }; "editorOptions": { "alias": "editorOptions"; "required": false; }; "editorType": { "alias": "editorType"; "required": false; }; "helpText": { "alias": "helpText"; "required": false; }; "isRequired": { "alias": "isRequired"; "required": false; }; "itemType": { "alias": "itemType"; "required": false; }; "label": { "alias": "label"; "required": false; }; "name": { "alias": "name"; "required": false; }; "validationRules": { "alias": "validationRules"; "required": false; }; "visibleIndex": { "alias": "visibleIndex"; "required": false; }; "alignItemLabels": { "alias": "alignItemLabels"; "required": false; }; "caption": { "alias": "caption"; "required": false; }; "captionTemplate": { "alias": "captionTemplate"; "required": false; }; "colCount": { "alias": "colCount"; "required": false; }; "colCountByScreen": { "alias": "colCountByScreen"; "required": false; }; "items": { "alias": "items"; "required": false; }; "tabPanelOptions": { "alias": "tabPanelOptions"; "required": false; }; "tabs": { "alias": "tabs"; "required": false; }; "buttonOptions": { "alias": "buttonOptions"; "required": false; }; "horizontalAlignment": { "alias": "horizontalAlignment"; "required": false; }; "verticalAlignment": { "alias": "verticalAlignment"; "required": false; }; }, {}, ["_validationRulesContentChildren", "_tabsContentChildren", "_itemsContentChildren"], ["*"], true, never>;
}
declare class DxiFormItemModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiFormItemModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiFormItemModule, never, [typeof DxiFormItemComponent], [typeof DxiFormItemComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiFormItemModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoFormLabelComponent extends NestedOption implements AfterViewInit, OnDestroy, OnInit, IDxTemplateHost {
    private renderer;
    private document;
    private element;
    get alignment(): HorizontalAlignment;
    set alignment(value: HorizontalAlignment);
    get location(): LabelLocation;
    set location(value: LabelLocation);
    get showColon(): boolean;
    set showColon(value: boolean);
    get template(): any;
    set template(value: any);
    get text(): string | undefined;
    set text(value: string | undefined);
    get visible(): boolean;
    set visible(value: boolean);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost, renderer: Renderer2, document: any, templateHost: DxTemplateHost, element: ElementRef);
    setTemplate(template: DxTemplateDirective): void;
    ngAfterViewInit(): void;
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoFormLabelComponent, [{ host: true; skipSelf: true; }, { host: true; }, null, null, { host: true; }, null]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoFormLabelComponent, "dxo-form-label", never, { "alignment": { "alias": "alignment"; "required": false; }; "location": { "alias": "location"; "required": false; }; "showColon": { "alias": "showColon"; "required": false; }; "template": { "alias": "template"; "required": false; }; "text": { "alias": "text"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; }, {}, never, ["*"], true, never>;
}
declare class DxoFormLabelModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoFormLabelModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoFormLabelModule, never, [typeof DxoFormLabelComponent], [typeof DxoFormLabelComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoFormLabelModule>;
}

declare class DxiFormNumericRuleComponent extends CollectionNestedOption {
    get ignoreEmptyValue(): boolean;
    set ignoreEmptyValue(value: boolean);
    get message(): string;
    set message(value: string);
    get type(): ValidationRuleType;
    set type(value: ValidationRuleType);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiFormNumericRuleComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiFormNumericRuleComponent, "dxi-form-numeric-rule", never, { "ignoreEmptyValue": { "alias": "ignoreEmptyValue"; "required": false; }; "message": { "alias": "message"; "required": false; }; "type": { "alias": "type"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxiFormNumericRuleModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiFormNumericRuleModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiFormNumericRuleModule, never, [typeof DxiFormNumericRuleComponent], [typeof DxiFormNumericRuleComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiFormNumericRuleModule>;
}

declare class DxiFormPatternRuleComponent extends CollectionNestedOption {
    get ignoreEmptyValue(): boolean;
    set ignoreEmptyValue(value: boolean);
    get message(): string;
    set message(value: string);
    get pattern(): RegExp | string;
    set pattern(value: RegExp | string);
    get type(): ValidationRuleType;
    set type(value: ValidationRuleType);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiFormPatternRuleComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiFormPatternRuleComponent, "dxi-form-pattern-rule", never, { "ignoreEmptyValue": { "alias": "ignoreEmptyValue"; "required": false; }; "message": { "alias": "message"; "required": false; }; "pattern": { "alias": "pattern"; "required": false; }; "type": { "alias": "type"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxiFormPatternRuleModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiFormPatternRuleModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiFormPatternRuleModule, never, [typeof DxiFormPatternRuleComponent], [typeof DxiFormPatternRuleComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiFormPatternRuleModule>;
}

declare class DxiFormRangeRuleComponent extends CollectionNestedOption {
    get ignoreEmptyValue(): boolean;
    set ignoreEmptyValue(value: boolean);
    get max(): Date | number | string;
    set max(value: Date | number | string);
    get message(): string;
    set message(value: string);
    get min(): Date | number | string;
    set min(value: Date | number | string);
    get reevaluate(): boolean;
    set reevaluate(value: boolean);
    get type(): ValidationRuleType;
    set type(value: ValidationRuleType);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiFormRangeRuleComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiFormRangeRuleComponent, "dxi-form-range-rule", never, { "ignoreEmptyValue": { "alias": "ignoreEmptyValue"; "required": false; }; "max": { "alias": "max"; "required": false; }; "message": { "alias": "message"; "required": false; }; "min": { "alias": "min"; "required": false; }; "reevaluate": { "alias": "reevaluate"; "required": false; }; "type": { "alias": "type"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxiFormRangeRuleModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiFormRangeRuleModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiFormRangeRuleModule, never, [typeof DxiFormRangeRuleComponent], [typeof DxiFormRangeRuleComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiFormRangeRuleModule>;
}

declare class DxiFormRequiredRuleComponent extends CollectionNestedOption {
    get message(): string;
    set message(value: string);
    get trim(): boolean;
    set trim(value: boolean);
    get type(): ValidationRuleType;
    set type(value: ValidationRuleType);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiFormRequiredRuleComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiFormRequiredRuleComponent, "dxi-form-required-rule", never, { "message": { "alias": "message"; "required": false; }; "trim": { "alias": "trim"; "required": false; }; "type": { "alias": "type"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxiFormRequiredRuleModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiFormRequiredRuleModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiFormRequiredRuleModule, never, [typeof DxiFormRequiredRuleComponent], [typeof DxiFormRequiredRuleComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiFormRequiredRuleModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxiFormSimpleItemComponent extends CollectionNestedOption implements AfterViewInit, IDxTemplateHost {
    private renderer;
    private document;
    private element;
    set _validationRulesContentChildren(value: QueryList<CollectionNestedOption>);
    get aiOptions(): {
        disabled?: boolean;
        instruction?: string | undefined;
    };
    set aiOptions(value: {
        disabled?: boolean;
        instruction?: string | undefined;
    });
    get colSpan(): number | undefined;
    set colSpan(value: number | undefined);
    get cssClass(): string | undefined;
    set cssClass(value: string | undefined);
    get dataField(): string | undefined;
    set dataField(value: string | undefined);
    get editorOptions(): any | undefined;
    set editorOptions(value: any | undefined);
    get editorType(): FormItemComponent;
    set editorType(value: FormItemComponent);
    get helpText(): string | undefined;
    set helpText(value: string | undefined);
    get isRequired(): boolean | undefined;
    set isRequired(value: boolean | undefined);
    get itemType(): FormItemType;
    set itemType(value: FormItemType);
    get label(): {
        alignment?: HorizontalAlignment;
        location?: LabelLocation;
        showColon?: boolean;
        template?: any;
        text?: string | undefined;
        visible?: boolean;
    };
    set label(value: {
        alignment?: HorizontalAlignment;
        location?: LabelLocation;
        showColon?: boolean;
        template?: any;
        text?: string | undefined;
        visible?: boolean;
    });
    get name(): string | undefined;
    set name(value: string | undefined);
    get template(): any;
    set template(value: any);
    get validationRules(): Array<CommonTypes.ValidationRule>;
    set validationRules(value: Array<CommonTypes.ValidationRule>);
    get visible(): boolean;
    set visible(value: boolean);
    get visibleIndex(): number | undefined;
    set visibleIndex(value: number | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost, renderer: Renderer2, document: any, templateHost: DxTemplateHost, element: ElementRef);
    setTemplate(template: DxTemplateDirective): void;
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiFormSimpleItemComponent, [{ host: true; skipSelf: true; }, { host: true; }, null, null, { host: true; }, null]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiFormSimpleItemComponent, "dxi-form-simple-item", never, { "aiOptions": { "alias": "aiOptions"; "required": false; }; "colSpan": { "alias": "colSpan"; "required": false; }; "cssClass": { "alias": "cssClass"; "required": false; }; "dataField": { "alias": "dataField"; "required": false; }; "editorOptions": { "alias": "editorOptions"; "required": false; }; "editorType": { "alias": "editorType"; "required": false; }; "helpText": { "alias": "helpText"; "required": false; }; "isRequired": { "alias": "isRequired"; "required": false; }; "itemType": { "alias": "itemType"; "required": false; }; "label": { "alias": "label"; "required": false; }; "name": { "alias": "name"; "required": false; }; "template": { "alias": "template"; "required": false; }; "validationRules": { "alias": "validationRules"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "visibleIndex": { "alias": "visibleIndex"; "required": false; }; }, {}, ["_validationRulesContentChildren"], ["*"], true, never>;
}
declare class DxiFormSimpleItemModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiFormSimpleItemModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiFormSimpleItemModule, never, [typeof DxiFormSimpleItemComponent], [typeof DxiFormSimpleItemComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiFormSimpleItemModule>;
}

declare class DxiFormStringLengthRuleComponent extends CollectionNestedOption {
    get ignoreEmptyValue(): boolean;
    set ignoreEmptyValue(value: boolean);
    get max(): number;
    set max(value: number);
    get message(): string;
    set message(value: string);
    get min(): number;
    set min(value: number);
    get trim(): boolean;
    set trim(value: boolean);
    get type(): ValidationRuleType;
    set type(value: ValidationRuleType);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiFormStringLengthRuleComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiFormStringLengthRuleComponent, "dxi-form-string-length-rule", never, { "ignoreEmptyValue": { "alias": "ignoreEmptyValue"; "required": false; }; "max": { "alias": "max"; "required": false; }; "message": { "alias": "message"; "required": false; }; "min": { "alias": "min"; "required": false; }; "trim": { "alias": "trim"; "required": false; }; "type": { "alias": "type"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxiFormStringLengthRuleModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiFormStringLengthRuleModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiFormStringLengthRuleModule, never, [typeof DxiFormStringLengthRuleComponent], [typeof DxiFormStringLengthRuleComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiFormStringLengthRuleModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxiFormTabComponent extends CollectionNestedOption implements AfterViewInit, IDxTemplateHost {
    private renderer;
    private document;
    private element;
    set _itemsContentChildren(value: QueryList<CollectionNestedOption>);
    get alignItemLabels(): boolean;
    set alignItemLabels(value: boolean);
    get badge(): string | undefined;
    set badge(value: string | undefined);
    get colCount(): number;
    set colCount(value: number);
    get colCountByScreen(): {
        lg?: number | undefined;
        md?: number | undefined;
        sm?: number | undefined;
        xs?: number | undefined;
    };
    set colCountByScreen(value: {
        lg?: number | undefined;
        md?: number | undefined;
        sm?: number | undefined;
        xs?: number | undefined;
    });
    get disabled(): boolean;
    set disabled(value: boolean);
    get icon(): string | undefined;
    set icon(value: string | undefined);
    get items(): Array<dxFormButtonItem | dxFormEmptyItem | dxFormGroupItem | dxFormSimpleItem | dxFormTabbedItem>;
    set items(value: Array<dxFormButtonItem | dxFormEmptyItem | dxFormGroupItem | dxFormSimpleItem | dxFormTabbedItem>);
    get tabTemplate(): any;
    set tabTemplate(value: any);
    get template(): any;
    set template(value: any);
    get title(): string | undefined;
    set title(value: string | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost, renderer: Renderer2, document: any, templateHost: DxTemplateHost, element: ElementRef);
    setTemplate(template: DxTemplateDirective): void;
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiFormTabComponent, [{ host: true; skipSelf: true; }, { host: true; }, null, null, { host: true; }, null]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiFormTabComponent, "dxi-form-tab", never, { "alignItemLabels": { "alias": "alignItemLabels"; "required": false; }; "badge": { "alias": "badge"; "required": false; }; "colCount": { "alias": "colCount"; "required": false; }; "colCountByScreen": { "alias": "colCountByScreen"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "icon": { "alias": "icon"; "required": false; }; "items": { "alias": "items"; "required": false; }; "tabTemplate": { "alias": "tabTemplate"; "required": false; }; "template": { "alias": "template"; "required": false; }; "title": { "alias": "title"; "required": false; }; }, {}, ["_itemsContentChildren"], ["*"], true, never>;
}
declare class DxiFormTabModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiFormTabModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiFormTabModule, never, [typeof DxiFormTabComponent], [typeof DxiFormTabComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiFormTabModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxiFormTabPanelOptionsItemComponent extends CollectionNestedOption implements AfterViewInit, IDxTemplateHost {
    private renderer;
    private document;
    private element;
    get badge(): string;
    set badge(value: string);
    get disabled(): boolean;
    set disabled(value: boolean);
    get html(): string;
    set html(value: string);
    get icon(): string;
    set icon(value: string);
    get tabTemplate(): any;
    set tabTemplate(value: any);
    get template(): any;
    set template(value: any);
    get text(): string;
    set text(value: string);
    get title(): string;
    set title(value: string);
    get visible(): boolean;
    set visible(value: boolean);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost, renderer: Renderer2, document: any, templateHost: DxTemplateHost, element: ElementRef);
    setTemplate(template: DxTemplateDirective): void;
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiFormTabPanelOptionsItemComponent, [{ host: true; skipSelf: true; }, { host: true; }, null, null, { host: true; }, null]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiFormTabPanelOptionsItemComponent, "dxi-form-tab-panel-options-item", never, { "badge": { "alias": "badge"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "html": { "alias": "html"; "required": false; }; "icon": { "alias": "icon"; "required": false; }; "tabTemplate": { "alias": "tabTemplate"; "required": false; }; "template": { "alias": "template"; "required": false; }; "text": { "alias": "text"; "required": false; }; "title": { "alias": "title"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; }, {}, never, ["*"], true, never>;
}
declare class DxiFormTabPanelOptionsItemModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiFormTabPanelOptionsItemModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiFormTabPanelOptionsItemModule, never, [typeof DxiFormTabPanelOptionsItemComponent], [typeof DxiFormTabPanelOptionsItemComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiFormTabPanelOptionsItemModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoFormTabPanelOptionsComponent extends NestedOption implements OnDestroy, OnInit {
    set _itemsContentChildren(value: QueryList<CollectionNestedOption>);
    get accessKey(): string | undefined;
    set accessKey(value: string | undefined);
    get activeStateEnabled(): boolean;
    set activeStateEnabled(value: boolean);
    get animationEnabled(): boolean;
    set animationEnabled(value: boolean);
    get dataSource(): Array<any | dxTabPanelItem | string> | DataSource | DataSourceOptions | null | Store | string;
    set dataSource(value: Array<any | dxTabPanelItem | string> | DataSource | DataSourceOptions | null | Store | string);
    get deferRendering(): boolean;
    set deferRendering(value: boolean);
    get disabled(): boolean;
    set disabled(value: boolean);
    get elementAttr(): Record<string, any>;
    set elementAttr(value: Record<string, any>);
    get focusStateEnabled(): boolean;
    set focusStateEnabled(value: boolean);
    get height(): number | string | undefined;
    set height(value: number | string | undefined);
    get hint(): string | undefined;
    set hint(value: string | undefined);
    get hoverStateEnabled(): boolean;
    set hoverStateEnabled(value: boolean);
    get iconPosition(): TabsIconPosition;
    set iconPosition(value: TabsIconPosition);
    get itemHoldTimeout(): number;
    set itemHoldTimeout(value: number);
    get items(): Array<any | dxTabPanelItem | string>;
    set items(value: Array<any | dxTabPanelItem | string>);
    get itemTemplate(): any;
    set itemTemplate(value: any);
    get itemTitleTemplate(): any;
    set itemTitleTemplate(value: any);
    get keyExpr(): ((item: any) => any) | string;
    set keyExpr(value: ((item: any) => any) | string);
    get loop(): boolean;
    set loop(value: boolean);
    get noDataText(): string;
    set noDataText(value: string);
    get onContentReady(): ((e: ContentReadyEvent$1) => void);
    set onContentReady(value: ((e: ContentReadyEvent$1) => void));
    get onDisposing(): ((e: DisposingEvent$1) => void);
    set onDisposing(value: ((e: DisposingEvent$1) => void));
    get onInitialized(): ((e: InitializedEvent$1) => void);
    set onInitialized(value: ((e: InitializedEvent$1) => void));
    get onItemClick(): ((e: ItemClickEvent) => void);
    set onItemClick(value: ((e: ItemClickEvent) => void));
    get onItemContextMenu(): ((e: ItemContextMenuEvent) => void);
    set onItemContextMenu(value: ((e: ItemContextMenuEvent) => void));
    get onItemHold(): ((e: ItemHoldEvent) => void);
    set onItemHold(value: ((e: ItemHoldEvent) => void));
    get onItemRendered(): ((e: ItemRenderedEvent) => void);
    set onItemRendered(value: ((e: ItemRenderedEvent) => void));
    get onOptionChanged(): ((e: OptionChangedEvent$1) => void);
    set onOptionChanged(value: ((e: OptionChangedEvent$1) => void));
    get onSelectionChanged(): ((e: SelectionChangedEvent) => void);
    set onSelectionChanged(value: ((e: SelectionChangedEvent) => void));
    get onSelectionChanging(): ((e: SelectionChangingEvent) => void);
    set onSelectionChanging(value: ((e: SelectionChangingEvent) => void));
    get onTitleClick(): ((e: TitleClickEvent) => void);
    set onTitleClick(value: ((e: TitleClickEvent) => void));
    get onTitleHold(): ((e: TitleHoldEvent) => void) | undefined;
    set onTitleHold(value: ((e: TitleHoldEvent) => void) | undefined);
    get onTitleRendered(): ((e: TitleRenderedEvent) => void) | undefined;
    set onTitleRendered(value: ((e: TitleRenderedEvent) => void) | undefined);
    get repaintChangesOnly(): boolean;
    set repaintChangesOnly(value: boolean);
    get rtlEnabled(): boolean;
    set rtlEnabled(value: boolean);
    get scrollByContent(): boolean;
    set scrollByContent(value: boolean);
    get scrollingEnabled(): boolean;
    set scrollingEnabled(value: boolean);
    get selectedIndex(): number;
    set selectedIndex(value: number);
    get selectedItem(): any | null;
    set selectedItem(value: any | null);
    get showNavButtons(): boolean;
    set showNavButtons(value: boolean);
    get stylingMode(): TabsStyle;
    set stylingMode(value: TabsStyle);
    get swipeEnabled(): boolean;
    set swipeEnabled(value: boolean);
    get tabIndex(): number;
    set tabIndex(value: number);
    get tabsPosition(): Position;
    set tabsPosition(value: Position);
    get visible(): boolean;
    set visible(value: boolean);
    get width(): number | string | undefined;
    set width(value: number | string | undefined);
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    itemsChange: EventEmitter<Array<any | dxTabPanelItem | string>>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    selectedIndexChange: EventEmitter<number>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    selectedItemChange: EventEmitter<any | null>;
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoFormTabPanelOptionsComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoFormTabPanelOptionsComponent, "dxo-form-tab-panel-options", never, { "accessKey": { "alias": "accessKey"; "required": false; }; "activeStateEnabled": { "alias": "activeStateEnabled"; "required": false; }; "animationEnabled": { "alias": "animationEnabled"; "required": false; }; "dataSource": { "alias": "dataSource"; "required": false; }; "deferRendering": { "alias": "deferRendering"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "elementAttr": { "alias": "elementAttr"; "required": false; }; "focusStateEnabled": { "alias": "focusStateEnabled"; "required": false; }; "height": { "alias": "height"; "required": false; }; "hint": { "alias": "hint"; "required": false; }; "hoverStateEnabled": { "alias": "hoverStateEnabled"; "required": false; }; "iconPosition": { "alias": "iconPosition"; "required": false; }; "itemHoldTimeout": { "alias": "itemHoldTimeout"; "required": false; }; "items": { "alias": "items"; "required": false; }; "itemTemplate": { "alias": "itemTemplate"; "required": false; }; "itemTitleTemplate": { "alias": "itemTitleTemplate"; "required": false; }; "keyExpr": { "alias": "keyExpr"; "required": false; }; "loop": { "alias": "loop"; "required": false; }; "noDataText": { "alias": "noDataText"; "required": false; }; "onContentReady": { "alias": "onContentReady"; "required": false; }; "onDisposing": { "alias": "onDisposing"; "required": false; }; "onInitialized": { "alias": "onInitialized"; "required": false; }; "onItemClick": { "alias": "onItemClick"; "required": false; }; "onItemContextMenu": { "alias": "onItemContextMenu"; "required": false; }; "onItemHold": { "alias": "onItemHold"; "required": false; }; "onItemRendered": { "alias": "onItemRendered"; "required": false; }; "onOptionChanged": { "alias": "onOptionChanged"; "required": false; }; "onSelectionChanged": { "alias": "onSelectionChanged"; "required": false; }; "onSelectionChanging": { "alias": "onSelectionChanging"; "required": false; }; "onTitleClick": { "alias": "onTitleClick"; "required": false; }; "onTitleHold": { "alias": "onTitleHold"; "required": false; }; "onTitleRendered": { "alias": "onTitleRendered"; "required": false; }; "repaintChangesOnly": { "alias": "repaintChangesOnly"; "required": false; }; "rtlEnabled": { "alias": "rtlEnabled"; "required": false; }; "scrollByContent": { "alias": "scrollByContent"; "required": false; }; "scrollingEnabled": { "alias": "scrollingEnabled"; "required": false; }; "selectedIndex": { "alias": "selectedIndex"; "required": false; }; "selectedItem": { "alias": "selectedItem"; "required": false; }; "showNavButtons": { "alias": "showNavButtons"; "required": false; }; "stylingMode": { "alias": "stylingMode"; "required": false; }; "swipeEnabled": { "alias": "swipeEnabled"; "required": false; }; "tabIndex": { "alias": "tabIndex"; "required": false; }; "tabsPosition": { "alias": "tabsPosition"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, { "itemsChange": "itemsChange"; "selectedIndexChange": "selectedIndexChange"; "selectedItemChange": "selectedItemChange"; }, ["_itemsContentChildren"], never, true, never>;
}
declare class DxoFormTabPanelOptionsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoFormTabPanelOptionsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoFormTabPanelOptionsModule, never, [typeof DxoFormTabPanelOptionsComponent], [typeof DxoFormTabPanelOptionsComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoFormTabPanelOptionsModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxiFormTabbedItemComponent extends CollectionNestedOption {
    set _tabsContentChildren(value: QueryList<CollectionNestedOption>);
    get colSpan(): number | undefined;
    set colSpan(value: number | undefined);
    get cssClass(): string | undefined;
    set cssClass(value: string | undefined);
    get itemType(): FormItemType;
    set itemType(value: FormItemType);
    get name(): string | undefined;
    set name(value: string | undefined);
    get tabPanelOptions(): dxTabPanelOptions | undefined;
    set tabPanelOptions(value: dxTabPanelOptions | undefined);
    get tabs(): {
        alignItemLabels?: boolean;
        badge?: string | undefined;
        colCount?: number;
        colCountByScreen?: {
            lg?: number | undefined;
            md?: number | undefined;
            sm?: number | undefined;
            xs?: number | undefined;
        };
        disabled?: boolean;
        icon?: string | undefined;
        items?: Array<dxFormButtonItem | dxFormEmptyItem | dxFormGroupItem | dxFormSimpleItem | dxFormTabbedItem>;
        tabTemplate?: any;
        template?: any;
        title?: string | undefined;
    }[];
    set tabs(value: {
        alignItemLabels?: boolean;
        badge?: string | undefined;
        colCount?: number;
        colCountByScreen?: {
            lg?: number | undefined;
            md?: number | undefined;
            sm?: number | undefined;
            xs?: number | undefined;
        };
        disabled?: boolean;
        icon?: string | undefined;
        items?: Array<dxFormButtonItem | dxFormEmptyItem | dxFormGroupItem | dxFormSimpleItem | dxFormTabbedItem>;
        tabTemplate?: any;
        template?: any;
        title?: string | undefined;
    }[]);
    get visible(): boolean;
    set visible(value: boolean);
    get visibleIndex(): number | undefined;
    set visibleIndex(value: number | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiFormTabbedItemComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiFormTabbedItemComponent, "dxi-form-tabbed-item", never, { "colSpan": { "alias": "colSpan"; "required": false; }; "cssClass": { "alias": "cssClass"; "required": false; }; "itemType": { "alias": "itemType"; "required": false; }; "name": { "alias": "name"; "required": false; }; "tabPanelOptions": { "alias": "tabPanelOptions"; "required": false; }; "tabs": { "alias": "tabs"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "visibleIndex": { "alias": "visibleIndex"; "required": false; }; }, {}, ["_tabsContentChildren"], never, true, never>;
}
declare class DxiFormTabbedItemModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiFormTabbedItemModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiFormTabbedItemModule, never, [typeof DxiFormTabbedItemComponent], [typeof DxiFormTabbedItemComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiFormTabbedItemModule>;
}

declare class DxiFormValidationRuleComponent extends CollectionNestedOption {
    get message(): string;
    set message(value: string);
    get trim(): boolean;
    set trim(value: boolean);
    get type(): ValidationRuleType;
    set type(value: ValidationRuleType);
    get ignoreEmptyValue(): boolean;
    set ignoreEmptyValue(value: boolean);
    get max(): Date | number | string;
    set max(value: Date | number | string);
    get min(): Date | number | string;
    set min(value: Date | number | string);
    get reevaluate(): boolean;
    set reevaluate(value: boolean);
    get validationCallback(): ((options: {
        column: Record<string, any>;
        data: Record<string, any>;
        formItem: Record<string, any>;
        rule: Record<string, any>;
        validator: Record<string, any>;
        value: any;
    }) => boolean);
    set validationCallback(value: ((options: {
        column: Record<string, any>;
        data: Record<string, any>;
        formItem: Record<string, any>;
        rule: Record<string, any>;
        validator: Record<string, any>;
        value: any;
    }) => boolean));
    get comparisonTarget(): Function;
    set comparisonTarget(value: Function);
    get comparisonType(): ComparisonOperator;
    set comparisonType(value: ComparisonOperator);
    get pattern(): RegExp | string;
    set pattern(value: RegExp | string);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiFormValidationRuleComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiFormValidationRuleComponent, "dxi-form-validation-rule", never, { "message": { "alias": "message"; "required": false; }; "trim": { "alias": "trim"; "required": false; }; "type": { "alias": "type"; "required": false; }; "ignoreEmptyValue": { "alias": "ignoreEmptyValue"; "required": false; }; "max": { "alias": "max"; "required": false; }; "min": { "alias": "min"; "required": false; }; "reevaluate": { "alias": "reevaluate"; "required": false; }; "validationCallback": { "alias": "validationCallback"; "required": false; }; "comparisonTarget": { "alias": "comparisonTarget"; "required": false; }; "comparisonType": { "alias": "comparisonType"; "required": false; }; "pattern": { "alias": "pattern"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxiFormValidationRuleModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiFormValidationRuleModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiFormValidationRuleModule, never, [typeof DxiFormValidationRuleComponent], [typeof DxiFormValidationRuleComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiFormValidationRuleModule>;
}

export { DxiFormAsyncRuleComponent, DxiFormAsyncRuleModule, DxiFormButtonItemComponent, DxiFormButtonItemModule, DxiFormCompareRuleComponent, DxiFormCompareRuleModule, DxiFormCustomRuleComponent, DxiFormCustomRuleModule, DxiFormEmailRuleComponent, DxiFormEmailRuleModule, DxiFormEmptyItemComponent, DxiFormEmptyItemModule, DxiFormGroupItemComponent, DxiFormGroupItemModule, DxiFormItemComponent, DxiFormItemModule, DxiFormNumericRuleComponent, DxiFormNumericRuleModule, DxiFormPatternRuleComponent, DxiFormPatternRuleModule, DxiFormRangeRuleComponent, DxiFormRangeRuleModule, DxiFormRequiredRuleComponent, DxiFormRequiredRuleModule, DxiFormSimpleItemComponent, DxiFormSimpleItemModule, DxiFormStringLengthRuleComponent, DxiFormStringLengthRuleModule, DxiFormTabComponent, DxiFormTabModule, DxiFormTabPanelOptionsItemComponent, DxiFormTabPanelOptionsItemModule, DxiFormTabbedItemComponent, DxiFormTabbedItemModule, DxiFormValidationRuleComponent, DxiFormValidationRuleModule, DxoFormAIOptionsComponent, DxoFormAIOptionsModule, DxoFormButtonOptionsComponent, DxoFormButtonOptionsModule, DxoFormColCountByScreenComponent, DxoFormColCountByScreenModule, DxoFormLabelComponent, DxoFormLabelModule, DxoFormTabPanelOptionsComponent, DxoFormTabPanelOptionsModule };
//# sourceMappingURL=index.d.ts.map
