import * as i0 from '@angular/core';
import { OnDestroy, EventEmitter, ElementRef, NgZone, TransferState } from '@angular/core';
import DxSpeechToText, { CustomSpeechRecognizer, SpeechRecognitionConfig, ContentReadyEvent, DisposingEvent, EndEvent, ErrorEvent, InitializedEvent, OptionChangedEvent, ResultEvent, StartClickEvent, StopClickEvent } from 'devextreme/ui/speech_to_text';
import { ButtonStyle, ButtonType } from 'devextreme/common';
import * as i2 from 'devextreme-angular/core';
import { DxComponent, DxTemplateHost, WatcherHelper, NestedOptionHost } from 'devextreme-angular/core';
import * as i1 from 'devextreme-angular/ui/speech-to-text/nested';
export * from 'devextreme-angular/ui/speech-to-text/nested';
import * as speech_to_text_types from 'devextreme/ui/speech_to_text_types';
export { speech_to_text_types as DxSpeechToTextTypes };

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxSpeechToTextComponent extends DxComponent implements OnDestroy {
    instance: DxSpeechToText;
    get accessKey(): string | undefined;
    set accessKey(value: string | undefined);
    get activeStateEnabled(): boolean;
    set activeStateEnabled(value: boolean);
    get customSpeechRecognizer(): CustomSpeechRecognizer;
    set customSpeechRecognizer(value: CustomSpeechRecognizer);
    get disabled(): boolean;
    set disabled(value: boolean);
    get elementAttr(): Record<string, any>;
    set elementAttr(value: Record<string, any>);
    get focusStateEnabled(): boolean;
    set focusStateEnabled(value: boolean);
    get height(): number | string | undefined;
    set height(value: number | string | undefined);
    get hint(): string | undefined;
    set hint(value: string | undefined);
    get hoverStateEnabled(): boolean;
    set hoverStateEnabled(value: boolean);
    get rtlEnabled(): boolean;
    set rtlEnabled(value: boolean);
    get speechRecognitionConfig(): Record<string, any> | SpeechRecognitionConfig;
    set speechRecognitionConfig(value: Record<string, any> | SpeechRecognitionConfig);
    get startIcon(): string;
    set startIcon(value: string);
    get startText(): string;
    set startText(value: string);
    get stopIcon(): string;
    set stopIcon(value: string);
    get stopText(): string;
    set stopText(value: string);
    get stylingMode(): ButtonStyle;
    set stylingMode(value: ButtonStyle);
    get tabIndex(): number;
    set tabIndex(value: number);
    get type(): ButtonType | string;
    set type(value: ButtonType | string);
    get visible(): boolean;
    set visible(value: boolean);
    get width(): number | string | undefined;
    set width(value: number | string | undefined);
    /**
    
     * [descr:undefined]
    
    
     */
    onContentReady: EventEmitter<ContentReadyEvent>;
    /**
    
     * [descr:undefined]
    
    
     */
    onDisposing: EventEmitter<DisposingEvent>;
    /**
    
     * [descr:undefined]
    
    
     */
    onEnd: EventEmitter<EndEvent>;
    /**
    
     * [descr:undefined]
    
    
     */
    onError: EventEmitter<ErrorEvent>;
    /**
    
     * [descr:undefined]
    
    
     */
    onInitialized: EventEmitter<InitializedEvent>;
    /**
    
     * [descr:undefined]
    
    
     */
    onOptionChanged: EventEmitter<OptionChangedEvent>;
    /**
    
     * [descr:undefined]
    
    
     */
    onResult: EventEmitter<ResultEvent>;
    /**
    
     * [descr:undefined]
    
    
     */
    onStartClick: EventEmitter<StartClickEvent>;
    /**
    
     * [descr:undefined]
    
    
     */
    onStopClick: EventEmitter<StopClickEvent>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    accessKeyChange: EventEmitter<string | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    activeStateEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    customSpeechRecognizerChange: EventEmitter<CustomSpeechRecognizer>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    disabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    elementAttrChange: EventEmitter<Record<string, any>>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    focusStateEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    heightChange: EventEmitter<number | string | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    hintChange: EventEmitter<string | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    hoverStateEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    rtlEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    speechRecognitionConfigChange: EventEmitter<Record<string, any> | SpeechRecognitionConfig>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    startIconChange: EventEmitter<string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    startTextChange: EventEmitter<string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    stopIconChange: EventEmitter<string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    stopTextChange: EventEmitter<string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    stylingModeChange: EventEmitter<ButtonStyle>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    tabIndexChange: EventEmitter<number>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    typeChange: EventEmitter<ButtonType | string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    visibleChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    widthChange: EventEmitter<number | string | undefined>;
    constructor(elementRef: ElementRef, ngZone: NgZone, templateHost: DxTemplateHost, _watcherHelper: WatcherHelper, optionHost: NestedOptionHost, transferState: TransferState, platformId: any);
    protected _createInstance(element: any, options: any): DxSpeechToText;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxSpeechToTextComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxSpeechToTextComponent, "dx-speech-to-text", never, { "accessKey": { "alias": "accessKey"; "required": false; }; "activeStateEnabled": { "alias": "activeStateEnabled"; "required": false; }; "customSpeechRecognizer": { "alias": "customSpeechRecognizer"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "elementAttr": { "alias": "elementAttr"; "required": false; }; "focusStateEnabled": { "alias": "focusStateEnabled"; "required": false; }; "height": { "alias": "height"; "required": false; }; "hint": { "alias": "hint"; "required": false; }; "hoverStateEnabled": { "alias": "hoverStateEnabled"; "required": false; }; "rtlEnabled": { "alias": "rtlEnabled"; "required": false; }; "speechRecognitionConfig": { "alias": "speechRecognitionConfig"; "required": false; }; "startIcon": { "alias": "startIcon"; "required": false; }; "startText": { "alias": "startText"; "required": false; }; "stopIcon": { "alias": "stopIcon"; "required": false; }; "stopText": { "alias": "stopText"; "required": false; }; "stylingMode": { "alias": "stylingMode"; "required": false; }; "tabIndex": { "alias": "tabIndex"; "required": false; }; "type": { "alias": "type"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, { "onContentReady": "onContentReady"; "onDisposing": "onDisposing"; "onEnd": "onEnd"; "onError": "onError"; "onInitialized": "onInitialized"; "onOptionChanged": "onOptionChanged"; "onResult": "onResult"; "onStartClick": "onStartClick"; "onStopClick": "onStopClick"; "accessKeyChange": "accessKeyChange"; "activeStateEnabledChange": "activeStateEnabledChange"; "customSpeechRecognizerChange": "customSpeechRecognizerChange"; "disabledChange": "disabledChange"; "elementAttrChange": "elementAttrChange"; "focusStateEnabledChange": "focusStateEnabledChange"; "heightChange": "heightChange"; "hintChange": "hintChange"; "hoverStateEnabledChange": "hoverStateEnabledChange"; "rtlEnabledChange": "rtlEnabledChange"; "speechRecognitionConfigChange": "speechRecognitionConfigChange"; "startIconChange": "startIconChange"; "startTextChange": "startTextChange"; "stopIconChange": "stopIconChange"; "stopTextChange": "stopTextChange"; "stylingModeChange": "stylingModeChange"; "tabIndexChange": "tabIndexChange"; "typeChange": "typeChange"; "visibleChange": "visibleChange"; "widthChange": "widthChange"; }, never, never, true, never>;
}
declare class DxSpeechToTextModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxSpeechToTextModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxSpeechToTextModule, never, [typeof DxSpeechToTextComponent, typeof i1.DxoSpeechToTextCustomSpeechRecognizerModule, typeof i1.DxoSpeechToTextSpeechRecognitionConfigModule, typeof i2.DxIntegrationModule, typeof i2.DxTemplateModule], [typeof DxSpeechToTextComponent, typeof i1.DxoSpeechToTextCustomSpeechRecognizerModule, typeof i1.DxoSpeechToTextSpeechRecognitionConfigModule, typeof i2.DxTemplateModule]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxSpeechToTextModule>;
}

export { DxSpeechToTextComponent, DxSpeechToTextModule };
//# sourceMappingURL=index.d.ts.map
