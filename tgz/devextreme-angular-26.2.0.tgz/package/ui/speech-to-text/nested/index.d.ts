import * as i0 from '@angular/core';
import { OnDestroy, OnInit } from '@angular/core';
import { NestedOption, NestedOptionHost } from 'devextreme-angular/core';

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoSpeechToTextCustomSpeechRecognizerComponent extends NestedOption implements OnDestroy, OnInit {
    get enabled(): boolean;
    set enabled(value: boolean);
    get isListening(): boolean;
    set isListening(value: boolean);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoSpeechToTextCustomSpeechRecognizerComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoSpeechToTextCustomSpeechRecognizerComponent, "dxo-speech-to-text-custom-speech-recognizer", never, { "enabled": { "alias": "enabled"; "required": false; }; "isListening": { "alias": "isListening"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoSpeechToTextCustomSpeechRecognizerModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoSpeechToTextCustomSpeechRecognizerModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoSpeechToTextCustomSpeechRecognizerModule, never, [typeof DxoSpeechToTextCustomSpeechRecognizerComponent], [typeof DxoSpeechToTextCustomSpeechRecognizerComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoSpeechToTextCustomSpeechRecognizerModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoSpeechToTextSpeechRecognitionConfigComponent extends NestedOption implements OnDestroy, OnInit {
    get continuous(): boolean;
    set continuous(value: boolean);
    get grammars(): Array<string>;
    set grammars(value: Array<string>);
    get interimResults(): boolean;
    set interimResults(value: boolean);
    get lang(): string;
    set lang(value: string);
    get maxAlternatives(): number;
    set maxAlternatives(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoSpeechToTextSpeechRecognitionConfigComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoSpeechToTextSpeechRecognitionConfigComponent, "dxo-speech-to-text-speech-recognition-config", never, { "continuous": { "alias": "continuous"; "required": false; }; "grammars": { "alias": "grammars"; "required": false; }; "interimResults": { "alias": "interimResults"; "required": false; }; "lang": { "alias": "lang"; "required": false; }; "maxAlternatives": { "alias": "maxAlternatives"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoSpeechToTextSpeechRecognitionConfigModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoSpeechToTextSpeechRecognitionConfigModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoSpeechToTextSpeechRecognitionConfigModule, never, [typeof DxoSpeechToTextSpeechRecognitionConfigComponent], [typeof DxoSpeechToTextSpeechRecognitionConfigComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoSpeechToTextSpeechRecognitionConfigModule>;
}

export { DxoSpeechToTextCustomSpeechRecognizerComponent, DxoSpeechToTextCustomSpeechRecognizerModule, DxoSpeechToTextSpeechRecognitionConfigComponent, DxoSpeechToTextSpeechRecognitionConfigModule };
//# sourceMappingURL=index.d.ts.map
