import * as i0 from '@angular/core';
import { OnDestroy, OnInit } from '@angular/core';
import { AnimationConfig, CollisionResolution, PositionConfig, AnimationState, AnimationType, CollisionResolutionCombination } from 'devextreme/common/core/animation';
import { NestedOption, NestedOptionHost } from 'devextreme-angular/core';
import { HorizontalAlignment, VerticalAlignment, Direction, PositionAlignment } from 'devextreme/common';
import { LoadingAnimationType } from 'devextreme/ui/load_indicator';

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoLoadPanelAnimationComponent extends NestedOption implements OnDestroy, OnInit {
    get hide(): AnimationConfig;
    set hide(value: AnimationConfig);
    get show(): AnimationConfig;
    set show(value: AnimationConfig);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoLoadPanelAnimationComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoLoadPanelAnimationComponent, "dxo-load-panel-animation", never, { "hide": { "alias": "hide"; "required": false; }; "show": { "alias": "show"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoLoadPanelAnimationModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoLoadPanelAnimationModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoLoadPanelAnimationModule, never, [typeof DxoLoadPanelAnimationComponent], [typeof DxoLoadPanelAnimationComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoLoadPanelAnimationModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoLoadPanelAtComponent extends NestedOption implements OnDestroy, OnInit {
    get x(): HorizontalAlignment;
    set x(value: HorizontalAlignment);
    get y(): VerticalAlignment;
    set y(value: VerticalAlignment);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoLoadPanelAtComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoLoadPanelAtComponent, "dxo-load-panel-at", never, { "x": { "alias": "x"; "required": false; }; "y": { "alias": "y"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoLoadPanelAtModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoLoadPanelAtModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoLoadPanelAtModule, never, [typeof DxoLoadPanelAtComponent], [typeof DxoLoadPanelAtComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoLoadPanelAtModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoLoadPanelBoundaryOffsetComponent extends NestedOption implements OnDestroy, OnInit {
    get x(): number;
    set x(value: number);
    get y(): number;
    set y(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoLoadPanelBoundaryOffsetComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoLoadPanelBoundaryOffsetComponent, "dxo-load-panel-boundary-offset", never, { "x": { "alias": "x"; "required": false; }; "y": { "alias": "y"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoLoadPanelBoundaryOffsetModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoLoadPanelBoundaryOffsetModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoLoadPanelBoundaryOffsetModule, never, [typeof DxoLoadPanelBoundaryOffsetComponent], [typeof DxoLoadPanelBoundaryOffsetComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoLoadPanelBoundaryOffsetModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoLoadPanelCollisionComponent extends NestedOption implements OnDestroy, OnInit {
    get x(): CollisionResolution;
    set x(value: CollisionResolution);
    get y(): CollisionResolution;
    set y(value: CollisionResolution);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoLoadPanelCollisionComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoLoadPanelCollisionComponent, "dxo-load-panel-collision", never, { "x": { "alias": "x"; "required": false; }; "y": { "alias": "y"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoLoadPanelCollisionModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoLoadPanelCollisionModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoLoadPanelCollisionModule, never, [typeof DxoLoadPanelCollisionComponent], [typeof DxoLoadPanelCollisionComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoLoadPanelCollisionModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoLoadPanelFromComponent extends NestedOption implements OnDestroy, OnInit {
    get left(): number;
    set left(value: number);
    get opacity(): number;
    set opacity(value: number);
    get position(): PositionConfig;
    set position(value: PositionConfig);
    get scale(): number;
    set scale(value: number);
    get top(): number;
    set top(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoLoadPanelFromComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoLoadPanelFromComponent, "dxo-load-panel-from", never, { "left": { "alias": "left"; "required": false; }; "opacity": { "alias": "opacity"; "required": false; }; "position": { "alias": "position"; "required": false; }; "scale": { "alias": "scale"; "required": false; }; "top": { "alias": "top"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoLoadPanelFromModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoLoadPanelFromModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoLoadPanelFromModule, never, [typeof DxoLoadPanelFromComponent], [typeof DxoLoadPanelFromComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoLoadPanelFromModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoLoadPanelHideComponent extends NestedOption implements OnDestroy, OnInit {
    get complete(): (($element: any, config: AnimationConfig) => void);
    set complete(value: (($element: any, config: AnimationConfig) => void));
    get delay(): number;
    set delay(value: number);
    get direction(): Direction | undefined;
    set direction(value: Direction | undefined);
    get duration(): number;
    set duration(value: number);
    get easing(): string;
    set easing(value: string);
    get from(): AnimationState;
    set from(value: AnimationState);
    get staggerDelay(): number | undefined;
    set staggerDelay(value: number | undefined);
    get start(): (($element: any, config: AnimationConfig) => void);
    set start(value: (($element: any, config: AnimationConfig) => void));
    get to(): AnimationState;
    set to(value: AnimationState);
    get type(): AnimationType;
    set type(value: AnimationType);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoLoadPanelHideComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoLoadPanelHideComponent, "dxo-load-panel-hide", never, { "complete": { "alias": "complete"; "required": false; }; "delay": { "alias": "delay"; "required": false; }; "direction": { "alias": "direction"; "required": false; }; "duration": { "alias": "duration"; "required": false; }; "easing": { "alias": "easing"; "required": false; }; "from": { "alias": "from"; "required": false; }; "staggerDelay": { "alias": "staggerDelay"; "required": false; }; "start": { "alias": "start"; "required": false; }; "to": { "alias": "to"; "required": false; }; "type": { "alias": "type"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoLoadPanelHideModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoLoadPanelHideModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoLoadPanelHideModule, never, [typeof DxoLoadPanelHideComponent], [typeof DxoLoadPanelHideComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoLoadPanelHideModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoLoadPanelIndicatorOptionsComponent extends NestedOption implements OnDestroy, OnInit {
    get animationType(): LoadingAnimationType;
    set animationType(value: LoadingAnimationType);
    get height(): number | string | undefined;
    set height(value: number | string | undefined);
    get src(): string;
    set src(value: string);
    get width(): number | string | undefined;
    set width(value: number | string | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoLoadPanelIndicatorOptionsComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoLoadPanelIndicatorOptionsComponent, "dxo-load-panel-indicator-options", never, { "animationType": { "alias": "animationType"; "required": false; }; "height": { "alias": "height"; "required": false; }; "src": { "alias": "src"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoLoadPanelIndicatorOptionsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoLoadPanelIndicatorOptionsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoLoadPanelIndicatorOptionsModule, never, [typeof DxoLoadPanelIndicatorOptionsComponent], [typeof DxoLoadPanelIndicatorOptionsComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoLoadPanelIndicatorOptionsModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoLoadPanelMyComponent extends NestedOption implements OnDestroy, OnInit {
    get x(): HorizontalAlignment;
    set x(value: HorizontalAlignment);
    get y(): VerticalAlignment;
    set y(value: VerticalAlignment);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoLoadPanelMyComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoLoadPanelMyComponent, "dxo-load-panel-my", never, { "x": { "alias": "x"; "required": false; }; "y": { "alias": "y"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoLoadPanelMyModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoLoadPanelMyModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoLoadPanelMyModule, never, [typeof DxoLoadPanelMyComponent], [typeof DxoLoadPanelMyComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoLoadPanelMyModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoLoadPanelOffsetComponent extends NestedOption implements OnDestroy, OnInit {
    get x(): number;
    set x(value: number);
    get y(): number;
    set y(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoLoadPanelOffsetComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoLoadPanelOffsetComponent, "dxo-load-panel-offset", never, { "x": { "alias": "x"; "required": false; }; "y": { "alias": "y"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoLoadPanelOffsetModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoLoadPanelOffsetModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoLoadPanelOffsetModule, never, [typeof DxoLoadPanelOffsetComponent], [typeof DxoLoadPanelOffsetComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoLoadPanelOffsetModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoLoadPanelPositionComponent extends NestedOption implements OnDestroy, OnInit {
    get at(): PositionAlignment | {
        x?: HorizontalAlignment;
        y?: VerticalAlignment;
    };
    set at(value: PositionAlignment | {
        x?: HorizontalAlignment;
        y?: VerticalAlignment;
    });
    get boundary(): any | string;
    set boundary(value: any | string);
    get boundaryOffset(): string | {
        x?: number;
        y?: number;
    };
    set boundaryOffset(value: string | {
        x?: number;
        y?: number;
    });
    get collision(): CollisionResolutionCombination | {
        x?: CollisionResolution;
        y?: CollisionResolution;
    };
    set collision(value: CollisionResolutionCombination | {
        x?: CollisionResolution;
        y?: CollisionResolution;
    });
    get my(): PositionAlignment | {
        x?: HorizontalAlignment;
        y?: VerticalAlignment;
    };
    set my(value: PositionAlignment | {
        x?: HorizontalAlignment;
        y?: VerticalAlignment;
    });
    get of(): any | string;
    set of(value: any | string);
    get offset(): string | {
        x?: number;
        y?: number;
    };
    set offset(value: string | {
        x?: number;
        y?: number;
    });
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoLoadPanelPositionComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoLoadPanelPositionComponent, "dxo-load-panel-position", never, { "at": { "alias": "at"; "required": false; }; "boundary": { "alias": "boundary"; "required": false; }; "boundaryOffset": { "alias": "boundaryOffset"; "required": false; }; "collision": { "alias": "collision"; "required": false; }; "my": { "alias": "my"; "required": false; }; "of": { "alias": "of"; "required": false; }; "offset": { "alias": "offset"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoLoadPanelPositionModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoLoadPanelPositionModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoLoadPanelPositionModule, never, [typeof DxoLoadPanelPositionComponent], [typeof DxoLoadPanelPositionComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoLoadPanelPositionModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoLoadPanelShowComponent extends NestedOption implements OnDestroy, OnInit {
    get complete(): (($element: any, config: AnimationConfig) => void);
    set complete(value: (($element: any, config: AnimationConfig) => void));
    get delay(): number;
    set delay(value: number);
    get direction(): Direction | undefined;
    set direction(value: Direction | undefined);
    get duration(): number;
    set duration(value: number);
    get easing(): string;
    set easing(value: string);
    get from(): AnimationState;
    set from(value: AnimationState);
    get staggerDelay(): number | undefined;
    set staggerDelay(value: number | undefined);
    get start(): (($element: any, config: AnimationConfig) => void);
    set start(value: (($element: any, config: AnimationConfig) => void));
    get to(): AnimationState;
    set to(value: AnimationState);
    get type(): AnimationType;
    set type(value: AnimationType);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoLoadPanelShowComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoLoadPanelShowComponent, "dxo-load-panel-show", never, { "complete": { "alias": "complete"; "required": false; }; "delay": { "alias": "delay"; "required": false; }; "direction": { "alias": "direction"; "required": false; }; "duration": { "alias": "duration"; "required": false; }; "easing": { "alias": "easing"; "required": false; }; "from": { "alias": "from"; "required": false; }; "staggerDelay": { "alias": "staggerDelay"; "required": false; }; "start": { "alias": "start"; "required": false; }; "to": { "alias": "to"; "required": false; }; "type": { "alias": "type"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoLoadPanelShowModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoLoadPanelShowModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoLoadPanelShowModule, never, [typeof DxoLoadPanelShowComponent], [typeof DxoLoadPanelShowComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoLoadPanelShowModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoLoadPanelToComponent extends NestedOption implements OnDestroy, OnInit {
    get left(): number;
    set left(value: number);
    get opacity(): number;
    set opacity(value: number);
    get position(): PositionConfig;
    set position(value: PositionConfig);
    get scale(): number;
    set scale(value: number);
    get top(): number;
    set top(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoLoadPanelToComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoLoadPanelToComponent, "dxo-load-panel-to", never, { "left": { "alias": "left"; "required": false; }; "opacity": { "alias": "opacity"; "required": false; }; "position": { "alias": "position"; "required": false; }; "scale": { "alias": "scale"; "required": false; }; "top": { "alias": "top"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoLoadPanelToModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoLoadPanelToModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoLoadPanelToModule, never, [typeof DxoLoadPanelToComponent], [typeof DxoLoadPanelToComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoLoadPanelToModule>;
}

export { DxoLoadPanelAnimationComponent, DxoLoadPanelAnimationModule, DxoLoadPanelAtComponent, DxoLoadPanelAtModule, DxoLoadPanelBoundaryOffsetComponent, DxoLoadPanelBoundaryOffsetModule, DxoLoadPanelCollisionComponent, DxoLoadPanelCollisionModule, DxoLoadPanelFromComponent, DxoLoadPanelFromModule, DxoLoadPanelHideComponent, DxoLoadPanelHideModule, DxoLoadPanelIndicatorOptionsComponent, DxoLoadPanelIndicatorOptionsModule, DxoLoadPanelMyComponent, DxoLoadPanelMyModule, DxoLoadPanelOffsetComponent, DxoLoadPanelOffsetModule, DxoLoadPanelPositionComponent, DxoLoadPanelPositionModule, DxoLoadPanelShowComponent, DxoLoadPanelShowModule, DxoLoadPanelToComponent, DxoLoadPanelToModule };
//# sourceMappingURL=index.d.ts.map
