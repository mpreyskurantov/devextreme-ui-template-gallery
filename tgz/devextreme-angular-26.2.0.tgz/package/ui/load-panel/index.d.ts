import * as i0 from '@angular/core';
import { OnDestroy, EventEmitter, ElementRef, NgZone, TransferState } from '@angular/core';
import { AnimationConfig, PositionConfig } from 'devextreme/common/core/animation';
import { event } from 'devextreme/events/events.types';
import DxLoadPanel, { LoadPanelIndicatorProperties, ContentReadyEvent, DisposingEvent, HiddenEvent, HidingEvent, InitializedEvent, OptionChangedEvent, ShowingEvent, ShownEvent } from 'devextreme/ui/load_panel';
import { PositionAlignment } from 'devextreme/common';
import * as i3 from 'devextreme-angular/core';
import { DxComponent, DxTemplateHost, WatcherHelper, NestedOptionHost } from 'devextreme-angular/core';
import * as i1 from 'devextreme-angular/ui/nested';
import * as i2 from 'devextreme-angular/ui/load-panel/nested';
export * from 'devextreme-angular/ui/load-panel/nested';
import * as load_panel_types from 'devextreme/ui/load_panel_types';
export { load_panel_types as DxLoadPanelTypes };

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

/**
 * [descr:dxLoadPanel]

 */
declare class DxLoadPanelComponent extends DxComponent implements OnDestroy {
    instance: DxLoadPanel;
    /**
     * [descr:dxLoadPanelOptions.animation]
    
     */
    get animation(): {
        hide?: AnimationConfig;
        show?: AnimationConfig;
    };
    set animation(value: {
        hide?: AnimationConfig;
        show?: AnimationConfig;
    });
    /**
     * [descr:dxLoadPanelOptions.container]
    
     */
    get container(): any | string | undefined;
    set container(value: any | string | undefined);
    /**
     * [descr:dxOverlayOptions.deferRendering]
    
     */
    get deferRendering(): boolean;
    set deferRendering(value: boolean);
    /**
     * [descr:dxLoadPanelOptions.delay]
    
     */
    get delay(): number;
    set delay(value: number);
    /**
     * [descr:dxLoadPanelOptions.focusStateEnabled]
    
     */
    get focusStateEnabled(): boolean;
    set focusStateEnabled(value: boolean);
    /**
     * [descr:dxLoadPanelOptions.height]
    
     */
    get height(): number | string;
    set height(value: number | string);
    /**
     * [descr:dxOverlayOptions.hideOnOutsideClick]
    
     */
    get hideOnOutsideClick(): boolean | ((event: event) => boolean);
    set hideOnOutsideClick(value: boolean | ((event: event) => boolean));
    /**
     * [descr:dxOverlayOptions.hideOnParentScroll]
    
     */
    get hideOnParentScroll(): boolean;
    set hideOnParentScroll(value: boolean);
    /**
     * [descr:WidgetOptions.hint]
    
     */
    get hint(): string | undefined;
    set hint(value: string | undefined);
    /**
     * [descr:WidgetOptions.hoverStateEnabled]
    
     */
    get hoverStateEnabled(): boolean;
    set hoverStateEnabled(value: boolean);
    get indicatorOptions(): LoadPanelIndicatorProperties;
    set indicatorOptions(value: LoadPanelIndicatorProperties);
    /**
     * [descr:dxLoadPanelOptions.indicatorSrc]
    
     * @deprecated [depNote:dxLoadPanelOptions.indicatorSrc]
    
     */
    get indicatorSrc(): string;
    set indicatorSrc(value: string);
    /**
     * [descr:dxLoadPanelOptions.maxHeight]
    
     */
    get maxHeight(): number | string;
    set maxHeight(value: number | string);
    /**
     * [descr:dxLoadPanelOptions.maxWidth]
    
     */
    get maxWidth(): number | string;
    set maxWidth(value: number | string);
    /**
     * [descr:dxLoadPanelOptions.message]
    
     */
    get message(): string;
    set message(value: string);
    /**
     * [descr:dxOverlayOptions.minHeight]
    
     */
    get minHeight(): number | string;
    set minHeight(value: number | string);
    /**
     * [descr:dxOverlayOptions.minWidth]
    
     */
    get minWidth(): number | string;
    set minWidth(value: number | string);
    /**
     * [descr:dxLoadPanelOptions.position]
    
     */
    get position(): Function | PositionAlignment | PositionConfig;
    set position(value: Function | PositionAlignment | PositionConfig);
    /**
     * [descr:DOMComponentOptions.rtlEnabled]
    
     */
    get rtlEnabled(): boolean;
    set rtlEnabled(value: boolean);
    /**
     * [descr:dxOverlayOptions.shading]
    
     */
    get shading(): boolean;
    set shading(value: boolean);
    /**
     * [descr:dxLoadPanelOptions.shadingColor]
    
     */
    get shadingColor(): string;
    set shadingColor(value: string);
    /**
     * [descr:dxLoadPanelOptions.showIndicator]
    
     */
    get showIndicator(): boolean;
    set showIndicator(value: boolean);
    /**
     * [descr:dxLoadPanelOptions.showPane]
    
     */
    get showPane(): boolean;
    set showPane(value: boolean);
    /**
     * [descr:dxOverlayOptions.visible]
    
     */
    get visible(): boolean;
    set visible(value: boolean);
    /**
     * [descr:dxLoadPanelOptions.width]
    
     */
    get width(): number | string;
    set width(value: number | string);
    /**
     * [descr:dxOverlayOptions.wrapperAttr]
    
     */
    get wrapperAttr(): any;
    set wrapperAttr(value: any);
    /**
    
     * [descr:dxLoadPanelOptions.onContentReady]
    
    
     */
    onContentReady: EventEmitter<ContentReadyEvent>;
    /**
    
     * [descr:dxLoadPanelOptions.onDisposing]
    
    
     */
    onDisposing: EventEmitter<DisposingEvent>;
    /**
    
     * [descr:dxLoadPanelOptions.onHidden]
    
    
     */
    onHidden: EventEmitter<HiddenEvent>;
    /**
    
     * [descr:dxLoadPanelOptions.onHiding]
    
    
     */
    onHiding: EventEmitter<HidingEvent>;
    /**
    
     * [descr:dxLoadPanelOptions.onInitialized]
    
    
     */
    onInitialized: EventEmitter<InitializedEvent>;
    /**
    
     * [descr:dxLoadPanelOptions.onOptionChanged]
    
    
     */
    onOptionChanged: EventEmitter<OptionChangedEvent>;
    /**
    
     * [descr:dxLoadPanelOptions.onShowing]
    
    
     */
    onShowing: EventEmitter<ShowingEvent>;
    /**
    
     * [descr:dxLoadPanelOptions.onShown]
    
    
     */
    onShown: EventEmitter<ShownEvent>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    animationChange: EventEmitter<{
        hide?: AnimationConfig;
        show?: AnimationConfig;
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    containerChange: EventEmitter<any | string | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    deferRenderingChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    delayChange: EventEmitter<number>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    focusStateEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    heightChange: EventEmitter<number | string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    hideOnOutsideClickChange: EventEmitter<boolean | ((event: event) => boolean)>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    hideOnParentScrollChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    hintChange: EventEmitter<string | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    hoverStateEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    indicatorOptionsChange: EventEmitter<LoadPanelIndicatorProperties>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    indicatorSrcChange: EventEmitter<string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    maxHeightChange: EventEmitter<number | string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    maxWidthChange: EventEmitter<number | string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    messageChange: EventEmitter<string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    minHeightChange: EventEmitter<number | string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    minWidthChange: EventEmitter<number | string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    positionChange: EventEmitter<Function | PositionAlignment | PositionConfig>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    rtlEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    shadingChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    shadingColorChange: EventEmitter<string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    showIndicatorChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    showPaneChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    visibleChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    widthChange: EventEmitter<number | string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    wrapperAttrChange: EventEmitter<any>;
    constructor(elementRef: ElementRef, ngZone: NgZone, templateHost: DxTemplateHost, _watcherHelper: WatcherHelper, optionHost: NestedOptionHost, transferState: TransferState, platformId: any);
    protected _createInstance(element: any, options: any): DxLoadPanel;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxLoadPanelComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxLoadPanelComponent, "dx-load-panel", never, { "animation": { "alias": "animation"; "required": false; }; "container": { "alias": "container"; "required": false; }; "deferRendering": { "alias": "deferRendering"; "required": false; }; "delay": { "alias": "delay"; "required": false; }; "focusStateEnabled": { "alias": "focusStateEnabled"; "required": false; }; "height": { "alias": "height"; "required": false; }; "hideOnOutsideClick": { "alias": "hideOnOutsideClick"; "required": false; }; "hideOnParentScroll": { "alias": "hideOnParentScroll"; "required": false; }; "hint": { "alias": "hint"; "required": false; }; "hoverStateEnabled": { "alias": "hoverStateEnabled"; "required": false; }; "indicatorOptions": { "alias": "indicatorOptions"; "required": false; }; "indicatorSrc": { "alias": "indicatorSrc"; "required": false; }; "maxHeight": { "alias": "maxHeight"; "required": false; }; "maxWidth": { "alias": "maxWidth"; "required": false; }; "message": { "alias": "message"; "required": false; }; "minHeight": { "alias": "minHeight"; "required": false; }; "minWidth": { "alias": "minWidth"; "required": false; }; "position": { "alias": "position"; "required": false; }; "rtlEnabled": { "alias": "rtlEnabled"; "required": false; }; "shading": { "alias": "shading"; "required": false; }; "shadingColor": { "alias": "shadingColor"; "required": false; }; "showIndicator": { "alias": "showIndicator"; "required": false; }; "showPane": { "alias": "showPane"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; "wrapperAttr": { "alias": "wrapperAttr"; "required": false; }; }, { "onContentReady": "onContentReady"; "onDisposing": "onDisposing"; "onHidden": "onHidden"; "onHiding": "onHiding"; "onInitialized": "onInitialized"; "onOptionChanged": "onOptionChanged"; "onShowing": "onShowing"; "onShown": "onShown"; "animationChange": "animationChange"; "containerChange": "containerChange"; "deferRenderingChange": "deferRenderingChange"; "delayChange": "delayChange"; "focusStateEnabledChange": "focusStateEnabledChange"; "heightChange": "heightChange"; "hideOnOutsideClickChange": "hideOnOutsideClickChange"; "hideOnParentScrollChange": "hideOnParentScrollChange"; "hintChange": "hintChange"; "hoverStateEnabledChange": "hoverStateEnabledChange"; "indicatorOptionsChange": "indicatorOptionsChange"; "indicatorSrcChange": "indicatorSrcChange"; "maxHeightChange": "maxHeightChange"; "maxWidthChange": "maxWidthChange"; "messageChange": "messageChange"; "minHeightChange": "minHeightChange"; "minWidthChange": "minWidthChange"; "positionChange": "positionChange"; "rtlEnabledChange": "rtlEnabledChange"; "shadingChange": "shadingChange"; "shadingColorChange": "shadingColorChange"; "showIndicatorChange": "showIndicatorChange"; "showPaneChange": "showPaneChange"; "visibleChange": "visibleChange"; "widthChange": "widthChange"; "wrapperAttrChange": "wrapperAttrChange"; }, never, never, true, never>;
}
declare class DxLoadPanelModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxLoadPanelModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxLoadPanelModule, never, [typeof DxLoadPanelComponent, typeof i1.DxoAnimationModule, typeof i1.DxoHideModule, typeof i1.DxoFromModule, typeof i1.DxoPositionModule, typeof i1.DxoAtModule, typeof i1.DxoBoundaryOffsetModule, typeof i1.DxoCollisionModule, typeof i1.DxoMyModule, typeof i1.DxoOffsetModule, typeof i1.DxoToModule, typeof i1.DxoShowModule, typeof i2.DxoLoadPanelAnimationModule, typeof i2.DxoLoadPanelAtModule, typeof i2.DxoLoadPanelBoundaryOffsetModule, typeof i2.DxoLoadPanelCollisionModule, typeof i2.DxoLoadPanelFromModule, typeof i2.DxoLoadPanelHideModule, typeof i2.DxoLoadPanelIndicatorOptionsModule, typeof i2.DxoLoadPanelMyModule, typeof i2.DxoLoadPanelOffsetModule, typeof i2.DxoLoadPanelPositionModule, typeof i2.DxoLoadPanelShowModule, typeof i2.DxoLoadPanelToModule, typeof i3.DxIntegrationModule, typeof i3.DxTemplateModule], [typeof DxLoadPanelComponent, typeof i1.DxoAnimationModule, typeof i1.DxoHideModule, typeof i1.DxoFromModule, typeof i1.DxoPositionModule, typeof i1.DxoAtModule, typeof i1.DxoBoundaryOffsetModule, typeof i1.DxoCollisionModule, typeof i1.DxoMyModule, typeof i1.DxoOffsetModule, typeof i1.DxoToModule, typeof i1.DxoShowModule, typeof i2.DxoLoadPanelAnimationModule, typeof i2.DxoLoadPanelAtModule, typeof i2.DxoLoadPanelBoundaryOffsetModule, typeof i2.DxoLoadPanelCollisionModule, typeof i2.DxoLoadPanelFromModule, typeof i2.DxoLoadPanelHideModule, typeof i2.DxoLoadPanelIndicatorOptionsModule, typeof i2.DxoLoadPanelMyModule, typeof i2.DxoLoadPanelOffsetModule, typeof i2.DxoLoadPanelPositionModule, typeof i2.DxoLoadPanelShowModule, typeof i2.DxoLoadPanelToModule, typeof i3.DxTemplateModule]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxLoadPanelModule>;
}

export { DxLoadPanelComponent, DxLoadPanelModule };
//# sourceMappingURL=index.d.ts.map
