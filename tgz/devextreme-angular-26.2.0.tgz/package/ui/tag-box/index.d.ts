import * as i0 from '@angular/core';
import { OnDestroy, OnChanges, DoCheck, QueryList, EventEmitter, ElementRef, NgZone, TransferState, SimpleChanges } from '@angular/core';
import { ApplyValueMode, TextEditorButton, LabelMode, SimplifiedSearchMode, SelectAllMode, EditorStyle, ValidationMessageMode, Mode, Position, ValidationStatus } from 'devextreme/common';
import { DropDownPredefinedButton, FieldAddons } from 'devextreme/ui/drop_down_editor/ui.drop_down_editor';
import { CollectionWidgetItem } from 'devextreme/ui/collection/ui.collection_widget.base';
import DataSource, { DataSourceOptions } from 'devextreme/data/data_source';
import { Store } from 'devextreme/data/store';
import { dxPopupOptions } from 'devextreme/ui/popup';
import DxTagBox, { ChangeEvent, ClosedEvent, ContentReadyEvent, CustomItemCreatingEvent, DisposingEvent, EnterKeyEvent, FocusInEvent, FocusOutEvent, InitializedEvent, InputEvent, ItemClickEvent, KeyDownEvent, KeyUpEvent, MultiTagPreparingEvent, OpenedEvent, OptionChangedEvent, SelectAllValueChangedEvent, SelectionChangedEvent, ValueChangedEvent } from 'devextreme/ui/tag_box';
import { ControlValueAccessor } from '@angular/forms';
import * as i3 from 'devextreme-angular/core';
import { DxComponent, CollectionNestedOption, DxTemplateHost, WatcherHelper, IterableDifferHelper, NestedOptionHost } from 'devextreme-angular/core';
import * as i1 from 'devextreme-angular/ui/nested';
import * as i2 from 'devextreme-angular/ui/tag-box/nested';
export * from 'devextreme-angular/ui/tag-box/nested';
import * as tag_box_types from 'devextreme/ui/tag_box_types';
export { tag_box_types as DxTagBoxTypes };

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

/**
 * [descr:dxTagBox]

 */
declare class DxTagBoxComponent extends DxComponent implements OnDestroy, ControlValueAccessor, OnChanges, DoCheck {
    private _watcherHelper;
    private _idh;
    set _buttonsContentChildren(value: QueryList<CollectionNestedOption>);
    set _itemsContentChildren(value: QueryList<CollectionNestedOption>);
    set _toolbarItemsContentChildren(value: QueryList<CollectionNestedOption>);
    instance: DxTagBox;
    /**
     * [descr:dxSelectBoxOptions.acceptCustomValue]
    
     */
    get acceptCustomValue(): boolean;
    set acceptCustomValue(value: boolean);
    /**
     * [descr:WidgetOptions.accessKey]
    
     */
    get accessKey(): string | undefined;
    set accessKey(value: string | undefined);
    /**
     * [descr:dxDropDownEditorOptions.activeStateEnabled]
    
     */
    get activeStateEnabled(): boolean;
    set activeStateEnabled(value: boolean);
    /**
     * [descr:dxTagBoxOptions.applyValueMode]
    
     */
    get applyValueMode(): ApplyValueMode;
    set applyValueMode(value: ApplyValueMode);
    /**
     * [descr:dxDropDownEditorOptions.buttons]
    
     */
    get buttons(): Array<DropDownPredefinedButton | TextEditorButton> | undefined;
    set buttons(value: Array<DropDownPredefinedButton | TextEditorButton> | undefined);
    /**
     * [descr:dxSelectBoxOptions.customItemCreateEvent]
    
     */
    get customItemCreateEvent(): string;
    set customItemCreateEvent(value: string);
    /**
     * [descr:DataExpressionMixinOptions.dataSource]
    
     */
    get dataSource(): Array<any | CollectionWidgetItem> | DataSource | DataSourceOptions | null | Store | string;
    set dataSource(value: Array<any | CollectionWidgetItem> | DataSource | DataSourceOptions | null | Store | string);
    /**
     * [descr:dxDropDownEditorOptions.deferRendering]
    
     */
    get deferRendering(): boolean;
    set deferRendering(value: boolean);
    /**
     * [descr:WidgetOptions.disabled]
    
     */
    get disabled(): boolean;
    set disabled(value: boolean);
    /**
     * [descr:DataExpressionMixinOptions.displayExpr]
    
     */
    get displayExpr(): ((item: any) => string) | string | undefined;
    set displayExpr(value: ((item: any) => string) | string | undefined);
    /**
     * [descr:dxDropDownEditorOptions.dropDownButtonTemplate]
    
     */
    get dropDownButtonTemplate(): any;
    set dropDownButtonTemplate(value: any);
    /**
     * [descr:dxSelectBoxOptions.dropDownOptions]
    
     */
    get dropDownOptions(): dxPopupOptions<any>;
    set dropDownOptions(value: dxPopupOptions<any>);
    /**
     * [descr:DOMComponentOptions.elementAttr]
    
     */
    get elementAttr(): Record<string, any>;
    set elementAttr(value: Record<string, any>);
    /**
     * [descr:dxSelectBoxOptions.fieldAddons]
    
     */
    get fieldAddons(): FieldAddons | null;
    set fieldAddons(value: FieldAddons | null);
    /**
     * [descr:dxSelectBoxOptions.fieldTemplate]
    
     * @deprecated [depNote:dxSelectBoxOptions.fieldTemplate]
    
     */
    get fieldTemplate(): any;
    set fieldTemplate(value: any);
    /**
     * [descr:dxTextEditorOptions.focusStateEnabled]
    
     */
    get focusStateEnabled(): boolean;
    set focusStateEnabled(value: boolean);
    /**
     * [descr:dxDropDownListOptions.grouped]
    
     */
    get grouped(): boolean;
    set grouped(value: boolean);
    /**
     * [descr:dxDropDownListOptions.groupTemplate]
    
     */
    get groupTemplate(): any;
    set groupTemplate(value: any);
    /**
     * [descr:DOMComponentOptions.height]
    
     */
    get height(): number | string | undefined;
    set height(value: number | string | undefined);
    /**
     * [descr:dxTagBoxOptions.hideSelectedItems]
    
     */
    get hideSelectedItems(): boolean;
    set hideSelectedItems(value: boolean);
    /**
     * [descr:WidgetOptions.hint]
    
     */
    get hint(): string | undefined;
    set hint(value: string | undefined);
    /**
     * [descr:dxTextEditorOptions.hoverStateEnabled]
    
     */
    get hoverStateEnabled(): boolean;
    set hoverStateEnabled(value: boolean);
    /**
     * [descr:dxTextEditorOptions.inputAttr]
    
     */
    get inputAttr(): any;
    set inputAttr(value: any);
    /**
     * [descr:EditorOptions.isDirty]
    
     */
    get isDirty(): boolean;
    set isDirty(value: boolean);
    /**
     * [descr:EditorOptions.isValid]
    
     */
    get isValid(): boolean;
    set isValid(value: boolean);
    /**
     * [descr:DataExpressionMixinOptions.items]
    
     */
    get items(): Array<any | CollectionWidgetItem>;
    set items(value: Array<any | CollectionWidgetItem>);
    /**
     * [descr:DataExpressionMixinOptions.itemTemplate]
    
     */
    get itemTemplate(): any;
    set itemTemplate(value: any);
    /**
     * [descr:dxTextEditorOptions.label]
    
     */
    get label(): string;
    set label(value: string);
    /**
     * [descr:dxTextEditorOptions.labelMode]
    
     */
    get labelMode(): LabelMode;
    set labelMode(value: LabelMode);
    /**
     * [descr:dxTagBoxOptions.maxDisplayedTags]
    
     */
    get maxDisplayedTags(): number | undefined;
    set maxDisplayedTags(value: number | undefined);
    /**
     * [descr:dxTagBoxOptions.maxFilterQueryLength]
    
     */
    get maxFilterQueryLength(): number;
    set maxFilterQueryLength(value: number);
    /**
     * [descr:dxTextBoxOptions.maxLength]
    
     */
    get maxLength(): null | number | string;
    set maxLength(value: null | number | string);
    /**
     * [descr:dxDropDownListOptions.minSearchLength]
    
     */
    get minSearchLength(): number;
    set minSearchLength(value: number);
    /**
     * [descr:dxTagBoxOptions.multiline]
    
     */
    get multiline(): boolean;
    set multiline(value: boolean);
    /**
     * [descr:dxTextEditorOptions.name]
    
     */
    get name(): string;
    set name(value: string);
    /**
     * [descr:dxDropDownListOptions.noDataText]
    
     */
    get noDataText(): string;
    set noDataText(value: string);
    /**
     * [descr:dxDropDownEditorOptions.opened]
    
     */
    get opened(): boolean;
    set opened(value: boolean);
    /**
     * [descr:dxSelectBoxOptions.openOnFieldClick]
    
     */
    get openOnFieldClick(): boolean;
    set openOnFieldClick(value: boolean);
    /**
     * [descr:dxSelectBoxOptions.placeholder]
    
     */
    get placeholder(): string;
    set placeholder(value: string);
    /**
     * [descr:EditorOptions.readOnly]
    
     */
    get readOnly(): boolean;
    set readOnly(value: boolean);
    /**
     * [descr:DOMComponentOptions.rtlEnabled]
    
     */
    get rtlEnabled(): boolean;
    set rtlEnabled(value: boolean);
    /**
     * [descr:dxDropDownListOptions.searchEnabled]
    
     */
    get searchEnabled(): boolean;
    set searchEnabled(value: boolean);
    /**
     * [descr:dxDropDownListOptions.searchExpr]
    
     */
    get searchExpr(): Array<Function | string> | Function | string;
    set searchExpr(value: Array<Function | string> | Function | string);
    /**
     * [descr:dxDropDownListOptions.searchMode]
    
     */
    get searchMode(): SimplifiedSearchMode;
    set searchMode(value: SimplifiedSearchMode);
    /**
     * [descr:dxDropDownListOptions.searchTimeout]
    
     */
    get searchTimeout(): number;
    set searchTimeout(value: number);
    /**
     * [descr:dxTagBoxOptions.selectAllMode]
    
     */
    get selectAllMode(): SelectAllMode;
    set selectAllMode(value: SelectAllMode);
    /**
     * [descr:dxTagBoxOptions.selectAllText]
    
     */
    get selectAllText(): string;
    set selectAllText(value: string);
    /**
     * [descr:dxTagBoxOptions.selectedItems]
    
     */
    get selectedItems(): Array<any | number | string>;
    set selectedItems(value: Array<any | number | string>);
    /**
     * [descr:dxTextEditorOptions.showClearButton]
    
     */
    get showClearButton(): boolean;
    set showClearButton(value: boolean);
    /**
     * [descr:dxDropDownListOptions.showDataBeforeSearch]
    
     */
    get showDataBeforeSearch(): boolean;
    set showDataBeforeSearch(value: boolean);
    /**
     * [descr:dxTagBoxOptions.showDropDownButton]
    
     */
    get showDropDownButton(): boolean;
    set showDropDownButton(value: boolean);
    /**
     * [descr:dxTagBoxOptions.showMultiTagOnly]
    
     */
    get showMultiTagOnly(): boolean;
    set showMultiTagOnly(value: boolean);
    /**
     * [descr:dxSelectBoxOptions.showSelectionControls]
    
     */
    get showSelectionControls(): boolean;
    set showSelectionControls(value: boolean);
    /**
     * [descr:dxTextEditorOptions.stylingMode]
    
     */
    get stylingMode(): EditorStyle;
    set stylingMode(value: EditorStyle);
    /**
     * [descr:WidgetOptions.tabIndex]
    
     */
    get tabIndex(): number;
    set tabIndex(value: number);
    /**
     * [descr:dxTagBoxOptions.tagTemplate]
    
     */
    get tagTemplate(): any;
    set tagTemplate(value: any);
    /**
     * [descr:dxTextEditorOptions.text]
    
     */
    get text(): string;
    set text(value: string);
    /**
     * [descr:dxDropDownListOptions.useItemTextAsTitle]
    
     */
    get useItemTextAsTitle(): boolean;
    set useItemTextAsTitle(value: boolean);
    /**
     * [descr:EditorOptions.validationError]
    
     */
    get validationError(): any | null;
    set validationError(value: any | null);
    /**
     * [descr:EditorOptions.validationErrors]
    
     */
    get validationErrors(): Array<any> | null;
    set validationErrors(value: Array<any> | null);
    /**
     * [descr:EditorOptions.validationMessageMode]
    
     */
    get validationMessageMode(): ValidationMessageMode;
    set validationMessageMode(value: ValidationMessageMode);
    /**
     * [descr:dxDropDownEditorOptions.validationMessagePosition]
    
     */
    get validationMessagePosition(): Mode | Position;
    set validationMessagePosition(value: Mode | Position);
    /**
     * [descr:EditorOptions.validationStatus]
    
     */
    get validationStatus(): ValidationStatus;
    set validationStatus(value: ValidationStatus);
    /**
     * [descr:dxTagBoxOptions.value]
    
     */
    get value(): Array<any | number | string>;
    set value(value: Array<any | number | string>);
    /**
     * [descr:dxDropDownListOptions.valueChangeEvent]
    
     */
    get valueChangeEvent(): string;
    set valueChangeEvent(value: string);
    /**
     * [descr:DataExpressionMixinOptions.valueExpr]
    
     */
    get valueExpr(): ((item: any) => string | number | boolean) | string;
    set valueExpr(value: ((item: any) => string | number | boolean) | string);
    /**
     * [descr:WidgetOptions.visible]
    
     */
    get visible(): boolean;
    set visible(value: boolean);
    /**
     * [descr:DOMComponentOptions.width]
    
     */
    get width(): number | string | undefined;
    set width(value: number | string | undefined);
    /**
     * [descr:dxDropDownListOptions.wrapItemText]
    
     */
    get wrapItemText(): boolean;
    set wrapItemText(value: boolean);
    /**
    
     * [descr:dxTagBoxOptions.onChange]
    
    
     */
    onChange: EventEmitter<ChangeEvent>;
    /**
    
     * [descr:dxTagBoxOptions.onClosed]
    
    
     */
    onClosed: EventEmitter<ClosedEvent>;
    /**
    
     * [descr:dxTagBoxOptions.onContentReady]
    
    
     */
    onContentReady: EventEmitter<ContentReadyEvent>;
    /**
    
     * [descr:dxTagBoxOptions.onCustomItemCreating]
    
    
     */
    onCustomItemCreating: EventEmitter<CustomItemCreatingEvent>;
    /**
    
     * [descr:dxTagBoxOptions.onDisposing]
    
    
     */
    onDisposing: EventEmitter<DisposingEvent>;
    /**
    
     * [descr:dxTagBoxOptions.onEnterKey]
    
    
     */
    onEnterKey: EventEmitter<EnterKeyEvent>;
    /**
    
     * [descr:dxTagBoxOptions.onFocusIn]
    
    
     */
    onFocusIn: EventEmitter<FocusInEvent>;
    /**
    
     * [descr:dxTagBoxOptions.onFocusOut]
    
    
     */
    onFocusOut: EventEmitter<FocusOutEvent>;
    /**
    
     * [descr:dxTagBoxOptions.onInitialized]
    
    
     */
    onInitialized: EventEmitter<InitializedEvent>;
    /**
    
     * [descr:dxTagBoxOptions.onInput]
    
    
     */
    onInput: EventEmitter<InputEvent>;
    /**
    
     * [descr:dxTagBoxOptions.onItemClick]
    
    
     */
    onItemClick: EventEmitter<ItemClickEvent>;
    /**
    
     * [descr:dxTagBoxOptions.onKeyDown]
    
    
     */
    onKeyDown: EventEmitter<KeyDownEvent>;
    /**
    
     * [descr:dxTagBoxOptions.onKeyUp]
    
    
     */
    onKeyUp: EventEmitter<KeyUpEvent>;
    /**
    
     * [descr:dxTagBoxOptions.onMultiTagPreparing]
    
    
     */
    onMultiTagPreparing: EventEmitter<MultiTagPreparingEvent>;
    /**
    
     * [descr:dxTagBoxOptions.onOpened]
    
    
     */
    onOpened: EventEmitter<OpenedEvent>;
    /**
    
     * [descr:dxTagBoxOptions.onOptionChanged]
    
    
     */
    onOptionChanged: EventEmitter<OptionChangedEvent>;
    /**
    
     * [descr:dxTagBoxOptions.onSelectAllValueChanged]
    
    
     */
    onSelectAllValueChanged: EventEmitter<SelectAllValueChangedEvent>;
    /**
    
     * [descr:dxTagBoxOptions.onSelectionChanged]
    
    
     */
    onSelectionChanged: EventEmitter<SelectionChangedEvent>;
    /**
    
     * [descr:dxTagBoxOptions.onValueChanged]
    
    
     */
    onValueChanged: EventEmitter<ValueChangedEvent>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    acceptCustomValueChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    accessKeyChange: EventEmitter<string | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    activeStateEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    applyValueModeChange: EventEmitter<ApplyValueMode>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    buttonsChange: EventEmitter<Array<DropDownPredefinedButton | TextEditorButton> | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    customItemCreateEventChange: EventEmitter<string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    dataSourceChange: EventEmitter<Array<any | CollectionWidgetItem> | DataSource | DataSourceOptions | null | Store | string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    deferRenderingChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    disabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    displayExprChange: EventEmitter<((item: any) => string) | string | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    dropDownButtonTemplateChange: EventEmitter<any>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    dropDownOptionsChange: EventEmitter<dxPopupOptions<any>>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    elementAttrChange: EventEmitter<Record<string, any>>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    fieldAddonsChange: EventEmitter<FieldAddons | null>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    fieldTemplateChange: EventEmitter<any>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    focusStateEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    groupedChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    groupTemplateChange: EventEmitter<any>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    heightChange: EventEmitter<number | string | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    hideSelectedItemsChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    hintChange: EventEmitter<string | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    hoverStateEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    inputAttrChange: EventEmitter<any>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    isDirtyChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    isValidChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    itemsChange: EventEmitter<Array<any | CollectionWidgetItem>>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    itemTemplateChange: EventEmitter<any>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    labelChange: EventEmitter<string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    labelModeChange: EventEmitter<LabelMode>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    maxDisplayedTagsChange: EventEmitter<number | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    maxFilterQueryLengthChange: EventEmitter<number>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    maxLengthChange: EventEmitter<null | number | string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    minSearchLengthChange: EventEmitter<number>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    multilineChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    nameChange: EventEmitter<string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    noDataTextChange: EventEmitter<string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    openedChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    openOnFieldClickChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    placeholderChange: EventEmitter<string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    readOnlyChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    rtlEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    searchEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    searchExprChange: EventEmitter<Array<Function | string> | Function | string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    searchModeChange: EventEmitter<SimplifiedSearchMode>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    searchTimeoutChange: EventEmitter<number>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    selectAllModeChange: EventEmitter<SelectAllMode>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    selectAllTextChange: EventEmitter<string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    selectedItemsChange: EventEmitter<Array<any | number | string>>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    showClearButtonChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    showDataBeforeSearchChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    showDropDownButtonChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    showMultiTagOnlyChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    showSelectionControlsChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    stylingModeChange: EventEmitter<EditorStyle>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    tabIndexChange: EventEmitter<number>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    tagTemplateChange: EventEmitter<any>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    textChange: EventEmitter<string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    useItemTextAsTitleChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    validationErrorChange: EventEmitter<any | null>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    validationErrorsChange: EventEmitter<Array<any> | null>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    validationMessageModeChange: EventEmitter<ValidationMessageMode>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    validationMessagePositionChange: EventEmitter<Mode | Position>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    validationStatusChange: EventEmitter<ValidationStatus>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    valueChange: EventEmitter<Array<any | number | string>>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    valueChangeEventChange: EventEmitter<string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    valueExprChange: EventEmitter<((item: any) => string | number | boolean) | string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    visibleChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    widthChange: EventEmitter<number | string | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    wrapItemTextChange: EventEmitter<boolean>;
    /**
    
     * [descr:undefined]
    
    
     */
    onBlur: EventEmitter<any>;
    change(_: any): void;
    touched: (_: any) => void;
    constructor(elementRef: ElementRef, ngZone: NgZone, templateHost: DxTemplateHost, _watcherHelper: WatcherHelper, _idh: IterableDifferHelper, optionHost: NestedOptionHost, transferState: TransferState, platformId: any);
    protected _createInstance(element: any, options: any): DxTagBox;
    writeValue(value: any): void;
    setDisabledState(isDisabled: boolean): void;
    registerOnChange(fn: (_: any) => void): void;
    registerOnTouched(fn: () => void): void;
    _createWidget(element: any): void;
    ngOnDestroy(): void;
    ngOnChanges(changes: SimpleChanges): void;
    setupChanges(prop: string, changes: SimpleChanges): void;
    ngDoCheck(): void;
    _setOption(name: string, value: any): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxTagBoxComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxTagBoxComponent, "dx-tag-box", never, { "acceptCustomValue": { "alias": "acceptCustomValue"; "required": false; }; "accessKey": { "alias": "accessKey"; "required": false; }; "activeStateEnabled": { "alias": "activeStateEnabled"; "required": false; }; "applyValueMode": { "alias": "applyValueMode"; "required": false; }; "buttons": { "alias": "buttons"; "required": false; }; "customItemCreateEvent": { "alias": "customItemCreateEvent"; "required": false; }; "dataSource": { "alias": "dataSource"; "required": false; }; "deferRendering": { "alias": "deferRendering"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "displayExpr": { "alias": "displayExpr"; "required": false; }; "dropDownButtonTemplate": { "alias": "dropDownButtonTemplate"; "required": false; }; "dropDownOptions": { "alias": "dropDownOptions"; "required": false; }; "elementAttr": { "alias": "elementAttr"; "required": false; }; "fieldAddons": { "alias": "fieldAddons"; "required": false; }; "fieldTemplate": { "alias": "fieldTemplate"; "required": false; }; "focusStateEnabled": { "alias": "focusStateEnabled"; "required": false; }; "grouped": { "alias": "grouped"; "required": false; }; "groupTemplate": { "alias": "groupTemplate"; "required": false; }; "height": { "alias": "height"; "required": false; }; "hideSelectedItems": { "alias": "hideSelectedItems"; "required": false; }; "hint": { "alias": "hint"; "required": false; }; "hoverStateEnabled": { "alias": "hoverStateEnabled"; "required": false; }; "inputAttr": { "alias": "inputAttr"; "required": false; }; "isDirty": { "alias": "isDirty"; "required": false; }; "isValid": { "alias": "isValid"; "required": false; }; "items": { "alias": "items"; "required": false; }; "itemTemplate": { "alias": "itemTemplate"; "required": false; }; "label": { "alias": "label"; "required": false; }; "labelMode": { "alias": "labelMode"; "required": false; }; "maxDisplayedTags": { "alias": "maxDisplayedTags"; "required": false; }; "maxFilterQueryLength": { "alias": "maxFilterQueryLength"; "required": false; }; "maxLength": { "alias": "maxLength"; "required": false; }; "minSearchLength": { "alias": "minSearchLength"; "required": false; }; "multiline": { "alias": "multiline"; "required": false; }; "name": { "alias": "name"; "required": false; }; "noDataText": { "alias": "noDataText"; "required": false; }; "opened": { "alias": "opened"; "required": false; }; "openOnFieldClick": { "alias": "openOnFieldClick"; "required": false; }; "placeholder": { "alias": "placeholder"; "required": false; }; "readOnly": { "alias": "readOnly"; "required": false; }; "rtlEnabled": { "alias": "rtlEnabled"; "required": false; }; "searchEnabled": { "alias": "searchEnabled"; "required": false; }; "searchExpr": { "alias": "searchExpr"; "required": false; }; "searchMode": { "alias": "searchMode"; "required": false; }; "searchTimeout": { "alias": "searchTimeout"; "required": false; }; "selectAllMode": { "alias": "selectAllMode"; "required": false; }; "selectAllText": { "alias": "selectAllText"; "required": false; }; "selectedItems": { "alias": "selectedItems"; "required": false; }; "showClearButton": { "alias": "showClearButton"; "required": false; }; "showDataBeforeSearch": { "alias": "showDataBeforeSearch"; "required": false; }; "showDropDownButton": { "alias": "showDropDownButton"; "required": false; }; "showMultiTagOnly": { "alias": "showMultiTagOnly"; "required": false; }; "showSelectionControls": { "alias": "showSelectionControls"; "required": false; }; "stylingMode": { "alias": "stylingMode"; "required": false; }; "tabIndex": { "alias": "tabIndex"; "required": false; }; "tagTemplate": { "alias": "tagTemplate"; "required": false; }; "text": { "alias": "text"; "required": false; }; "useItemTextAsTitle": { "alias": "useItemTextAsTitle"; "required": false; }; "validationError": { "alias": "validationError"; "required": false; }; "validationErrors": { "alias": "validationErrors"; "required": false; }; "validationMessageMode": { "alias": "validationMessageMode"; "required": false; }; "validationMessagePosition": { "alias": "validationMessagePosition"; "required": false; }; "validationStatus": { "alias": "validationStatus"; "required": false; }; "value": { "alias": "value"; "required": false; }; "valueChangeEvent": { "alias": "valueChangeEvent"; "required": false; }; "valueExpr": { "alias": "valueExpr"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; "wrapItemText": { "alias": "wrapItemText"; "required": false; }; }, { "onChange": "onChange"; "onClosed": "onClosed"; "onContentReady": "onContentReady"; "onCustomItemCreating": "onCustomItemCreating"; "onDisposing": "onDisposing"; "onEnterKey": "onEnterKey"; "onFocusIn": "onFocusIn"; "onFocusOut": "onFocusOut"; "onInitialized": "onInitialized"; "onInput": "onInput"; "onItemClick": "onItemClick"; "onKeyDown": "onKeyDown"; "onKeyUp": "onKeyUp"; "onMultiTagPreparing": "onMultiTagPreparing"; "onOpened": "onOpened"; "onOptionChanged": "onOptionChanged"; "onSelectAllValueChanged": "onSelectAllValueChanged"; "onSelectionChanged": "onSelectionChanged"; "onValueChanged": "onValueChanged"; "acceptCustomValueChange": "acceptCustomValueChange"; "accessKeyChange": "accessKeyChange"; "activeStateEnabledChange": "activeStateEnabledChange"; "applyValueModeChange": "applyValueModeChange"; "buttonsChange": "buttonsChange"; "customItemCreateEventChange": "customItemCreateEventChange"; "dataSourceChange": "dataSourceChange"; "deferRenderingChange": "deferRenderingChange"; "disabledChange": "disabledChange"; "displayExprChange": "displayExprChange"; "dropDownButtonTemplateChange": "dropDownButtonTemplateChange"; "dropDownOptionsChange": "dropDownOptionsChange"; "elementAttrChange": "elementAttrChange"; "fieldAddonsChange": "fieldAddonsChange"; "fieldTemplateChange": "fieldTemplateChange"; "focusStateEnabledChange": "focusStateEnabledChange"; "groupedChange": "groupedChange"; "groupTemplateChange": "groupTemplateChange"; "heightChange": "heightChange"; "hideSelectedItemsChange": "hideSelectedItemsChange"; "hintChange": "hintChange"; "hoverStateEnabledChange": "hoverStateEnabledChange"; "inputAttrChange": "inputAttrChange"; "isDirtyChange": "isDirtyChange"; "isValidChange": "isValidChange"; "itemsChange": "itemsChange"; "itemTemplateChange": "itemTemplateChange"; "labelChange": "labelChange"; "labelModeChange": "labelModeChange"; "maxDisplayedTagsChange": "maxDisplayedTagsChange"; "maxFilterQueryLengthChange": "maxFilterQueryLengthChange"; "maxLengthChange": "maxLengthChange"; "minSearchLengthChange": "minSearchLengthChange"; "multilineChange": "multilineChange"; "nameChange": "nameChange"; "noDataTextChange": "noDataTextChange"; "openedChange": "openedChange"; "openOnFieldClickChange": "openOnFieldClickChange"; "placeholderChange": "placeholderChange"; "readOnlyChange": "readOnlyChange"; "rtlEnabledChange": "rtlEnabledChange"; "searchEnabledChange": "searchEnabledChange"; "searchExprChange": "searchExprChange"; "searchModeChange": "searchModeChange"; "searchTimeoutChange": "searchTimeoutChange"; "selectAllModeChange": "selectAllModeChange"; "selectAllTextChange": "selectAllTextChange"; "selectedItemsChange": "selectedItemsChange"; "showClearButtonChange": "showClearButtonChange"; "showDataBeforeSearchChange": "showDataBeforeSearchChange"; "showDropDownButtonChange": "showDropDownButtonChange"; "showMultiTagOnlyChange": "showMultiTagOnlyChange"; "showSelectionControlsChange": "showSelectionControlsChange"; "stylingModeChange": "stylingModeChange"; "tabIndexChange": "tabIndexChange"; "tagTemplateChange": "tagTemplateChange"; "textChange": "textChange"; "useItemTextAsTitleChange": "useItemTextAsTitleChange"; "validationErrorChange": "validationErrorChange"; "validationErrorsChange": "validationErrorsChange"; "validationMessageModeChange": "validationMessageModeChange"; "validationMessagePositionChange": "validationMessagePositionChange"; "validationStatusChange": "validationStatusChange"; "valueChange": "valueChange"; "valueChangeEventChange": "valueChangeEventChange"; "valueExprChange": "valueExprChange"; "visibleChange": "visibleChange"; "widthChange": "widthChange"; "wrapItemTextChange": "wrapItemTextChange"; "onBlur": "onBlur"; }, ["_buttonsContentChildren", "_itemsContentChildren", "_toolbarItemsContentChildren"], never, true, never>;
}
declare class DxTagBoxModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxTagBoxModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxTagBoxModule, never, [typeof DxTagBoxComponent, typeof i1.DxiButtonModule, typeof i1.DxoOptionsModule, typeof i1.DxoDropDownOptionsModule, typeof i1.DxoAnimationModule, typeof i1.DxoHideModule, typeof i1.DxoFromModule, typeof i1.DxoPositionModule, typeof i1.DxoAtModule, typeof i1.DxoBoundaryOffsetModule, typeof i1.DxoCollisionModule, typeof i1.DxoMyModule, typeof i1.DxoOffsetModule, typeof i1.DxoToModule, typeof i1.DxoShowModule, typeof i1.DxiItemModule, typeof i2.DxoTagBoxAnimationModule, typeof i2.DxoTagBoxAtModule, typeof i2.DxoTagBoxBoundaryOffsetModule, typeof i2.DxiTagBoxButtonModule, typeof i2.DxoTagBoxCollisionModule, typeof i2.DxoTagBoxDropDownOptionsModule, typeof i2.DxoTagBoxFieldAddonsModule, typeof i2.DxoTagBoxFromModule, typeof i2.DxoTagBoxHideModule, typeof i2.DxiTagBoxItemModule, typeof i2.DxoTagBoxMyModule, typeof i2.DxoTagBoxOffsetModule, typeof i2.DxoTagBoxOptionsModule, typeof i2.DxoTagBoxPositionModule, typeof i2.DxoTagBoxShowModule, typeof i2.DxoTagBoxToModule, typeof i2.DxiTagBoxToolbarItemModule, typeof i3.DxIntegrationModule, typeof i3.DxTemplateModule], [typeof DxTagBoxComponent, typeof i1.DxiButtonModule, typeof i1.DxoOptionsModule, typeof i1.DxoDropDownOptionsModule, typeof i1.DxoAnimationModule, typeof i1.DxoHideModule, typeof i1.DxoFromModule, typeof i1.DxoPositionModule, typeof i1.DxoAtModule, typeof i1.DxoBoundaryOffsetModule, typeof i1.DxoCollisionModule, typeof i1.DxoMyModule, typeof i1.DxoOffsetModule, typeof i1.DxoToModule, typeof i1.DxoShowModule, typeof i1.DxiItemModule, typeof i2.DxoTagBoxAnimationModule, typeof i2.DxoTagBoxAtModule, typeof i2.DxoTagBoxBoundaryOffsetModule, typeof i2.DxiTagBoxButtonModule, typeof i2.DxoTagBoxCollisionModule, typeof i2.DxoTagBoxDropDownOptionsModule, typeof i2.DxoTagBoxFieldAddonsModule, typeof i2.DxoTagBoxFromModule, typeof i2.DxoTagBoxHideModule, typeof i2.DxiTagBoxItemModule, typeof i2.DxoTagBoxMyModule, typeof i2.DxoTagBoxOffsetModule, typeof i2.DxoTagBoxOptionsModule, typeof i2.DxoTagBoxPositionModule, typeof i2.DxoTagBoxShowModule, typeof i2.DxoTagBoxToModule, typeof i2.DxiTagBoxToolbarItemModule, typeof i3.DxTemplateModule]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxTagBoxModule>;
}

export { DxTagBoxComponent, DxTagBoxModule };
//# sourceMappingURL=index.d.ts.map
