import * as i0 from '@angular/core';
import { OnDestroy, EventEmitter, ElementRef, NgZone, TransferState } from '@angular/core';
import DxValidationGroup, { DisposingEvent, InitializedEvent, OptionChangedEvent } from 'devextreme/ui/validation_group';
import * as i1 from 'devextreme-angular/core';
import { DxComponent, DxTemplateHost, WatcherHelper, NestedOptionHost } from 'devextreme-angular/core';
import * as validation_group_types from 'devextreme/ui/validation_group_types';
export { validation_group_types as DxValidationGroupTypes };

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

/**
 * [descr:dxValidationGroup]

 */
declare class DxValidationGroupComponent extends DxComponent implements OnDestroy {
    instance: DxValidationGroup;
    /**
     * [descr:DOMComponentOptions.elementAttr]
    
     */
    get elementAttr(): Record<string, any>;
    set elementAttr(value: Record<string, any>);
    /**
     * [descr:DOMComponentOptions.height]
    
     */
    get height(): number | string | undefined;
    set height(value: number | string | undefined);
    /**
     * [descr:DOMComponentOptions.width]
    
     */
    get width(): number | string | undefined;
    set width(value: number | string | undefined);
    /**
    
     * [descr:dxValidationGroupOptions.onDisposing]
    
    
     */
    onDisposing: EventEmitter<DisposingEvent>;
    /**
    
     * [descr:dxValidationGroupOptions.onInitialized]
    
    
     */
    onInitialized: EventEmitter<InitializedEvent>;
    /**
    
     * [descr:dxValidationGroupOptions.onOptionChanged]
    
    
     */
    onOptionChanged: EventEmitter<OptionChangedEvent>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    elementAttrChange: EventEmitter<Record<string, any>>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    heightChange: EventEmitter<number | string | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    widthChange: EventEmitter<number | string | undefined>;
    constructor(elementRef: ElementRef, ngZone: NgZone, templateHost: DxTemplateHost, _watcherHelper: WatcherHelper, optionHost: NestedOptionHost, transferState: TransferState, platformId: any);
    protected _createInstance(element: any, options: any): DxValidationGroup;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxValidationGroupComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxValidationGroupComponent, "dx-validation-group", never, { "elementAttr": { "alias": "elementAttr"; "required": false; }; "height": { "alias": "height"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, { "onDisposing": "onDisposing"; "onInitialized": "onInitialized"; "onOptionChanged": "onOptionChanged"; "elementAttrChange": "elementAttrChange"; "heightChange": "heightChange"; "widthChange": "widthChange"; }, never, ["*"], true, never>;
}
declare class DxValidationGroupModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxValidationGroupModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxValidationGroupModule, never, [typeof DxValidationGroupComponent, typeof i1.DxIntegrationModule, typeof i1.DxTemplateModule], [typeof DxValidationGroupComponent, typeof i1.DxTemplateModule]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxValidationGroupModule>;
}

export { DxValidationGroupComponent, DxValidationGroupModule };
//# sourceMappingURL=index.d.ts.map
