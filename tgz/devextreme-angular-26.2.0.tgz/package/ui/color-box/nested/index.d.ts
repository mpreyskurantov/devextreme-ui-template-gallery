import * as i0 from '@angular/core';
import { OnDestroy, OnInit, QueryList, EventEmitter, AfterViewInit, Renderer2, ElementRef } from '@angular/core';
import { AnimationConfig, CollisionResolution, PositionConfig, AnimationState, AnimationType, CollisionResolutionCombination } from 'devextreme/common/core/animation';
import { NestedOption, NestedOptionHost, CollectionNestedOption, IDxTemplateHost, DxTemplateHost, DxTemplateDirective } from 'devextreme-angular/core';
import { HorizontalAlignment, VerticalAlignment, TextEditorButtonLocation, PositionAlignment, Direction, ButtonStyle, ButtonType, ToolbarItemLocation, ToolbarItemComponent } from 'devextreme/common';
import { dxButtonOptions, ClickEvent, ContentReadyEvent, DisposingEvent, InitializedEvent, OptionChangedEvent } from 'devextreme/ui/button';
import dxOverlay from 'devextreme/ui/overlay';
import DOMComponent from 'devextreme/core/dom_component';
import { event } from 'devextreme/events/events.types';
import { EventInfo } from 'devextreme/common/core/events';
import { Component } from 'devextreme/core/component';
import dxPopup, { dxPopupToolbarItem, ToolbarLocation } from 'devextreme/ui/popup';
import { LocateInMenuMode, ShowTextMode } from 'devextreme/ui/toolbar';

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoColorBoxAnimationComponent extends NestedOption implements OnDestroy, OnInit {
    get hide(): AnimationConfig;
    set hide(value: AnimationConfig);
    get show(): AnimationConfig;
    set show(value: AnimationConfig);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoColorBoxAnimationComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoColorBoxAnimationComponent, "dxo-color-box-animation", never, { "hide": { "alias": "hide"; "required": false; }; "show": { "alias": "show"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoColorBoxAnimationModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoColorBoxAnimationModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoColorBoxAnimationModule, never, [typeof DxoColorBoxAnimationComponent], [typeof DxoColorBoxAnimationComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoColorBoxAnimationModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoColorBoxAtComponent extends NestedOption implements OnDestroy, OnInit {
    get x(): HorizontalAlignment;
    set x(value: HorizontalAlignment);
    get y(): VerticalAlignment;
    set y(value: VerticalAlignment);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoColorBoxAtComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoColorBoxAtComponent, "dxo-color-box-at", never, { "x": { "alias": "x"; "required": false; }; "y": { "alias": "y"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoColorBoxAtModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoColorBoxAtModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoColorBoxAtModule, never, [typeof DxoColorBoxAtComponent], [typeof DxoColorBoxAtComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoColorBoxAtModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoColorBoxBoundaryOffsetComponent extends NestedOption implements OnDestroy, OnInit {
    get x(): number;
    set x(value: number);
    get y(): number;
    set y(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoColorBoxBoundaryOffsetComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoColorBoxBoundaryOffsetComponent, "dxo-color-box-boundary-offset", never, { "x": { "alias": "x"; "required": false; }; "y": { "alias": "y"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoColorBoxBoundaryOffsetModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoColorBoxBoundaryOffsetModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoColorBoxBoundaryOffsetModule, never, [typeof DxoColorBoxBoundaryOffsetComponent], [typeof DxoColorBoxBoundaryOffsetComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoColorBoxBoundaryOffsetModule>;
}

declare class DxiColorBoxButtonComponent extends CollectionNestedOption {
    get location(): TextEditorButtonLocation;
    set location(value: TextEditorButtonLocation);
    get name(): string | undefined;
    set name(value: string | undefined);
    get options(): dxButtonOptions | undefined;
    set options(value: dxButtonOptions | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiColorBoxButtonComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiColorBoxButtonComponent, "dxi-color-box-button", never, { "location": { "alias": "location"; "required": false; }; "name": { "alias": "name"; "required": false; }; "options": { "alias": "options"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxiColorBoxButtonModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiColorBoxButtonModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiColorBoxButtonModule, never, [typeof DxiColorBoxButtonComponent], [typeof DxiColorBoxButtonComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiColorBoxButtonModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoColorBoxCollisionComponent extends NestedOption implements OnDestroy, OnInit {
    get x(): CollisionResolution;
    set x(value: CollisionResolution);
    get y(): CollisionResolution;
    set y(value: CollisionResolution);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoColorBoxCollisionComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoColorBoxCollisionComponent, "dxo-color-box-collision", never, { "x": { "alias": "x"; "required": false; }; "y": { "alias": "y"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoColorBoxCollisionModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoColorBoxCollisionModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoColorBoxCollisionModule, never, [typeof DxoColorBoxCollisionComponent], [typeof DxoColorBoxCollisionComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoColorBoxCollisionModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoColorBoxDropDownOptionsComponent extends NestedOption implements OnDestroy, OnInit {
    set _toolbarItemsContentChildren(value: QueryList<CollectionNestedOption>);
    get accessKey(): string | undefined;
    set accessKey(value: string | undefined);
    get animation(): {
        hide?: AnimationConfig;
        show?: AnimationConfig;
    };
    set animation(value: {
        hide?: AnimationConfig;
        show?: AnimationConfig;
    });
    get container(): any | string | undefined;
    set container(value: any | string | undefined);
    get contentTemplate(): any;
    set contentTemplate(value: any);
    get deferRendering(): boolean;
    set deferRendering(value: boolean);
    get disabled(): boolean;
    set disabled(value: boolean);
    get dragAndResizeArea(): any | string | undefined;
    set dragAndResizeArea(value: any | string | undefined);
    get dragEnabled(): boolean;
    set dragEnabled(value: boolean);
    get dragOutsideBoundary(): boolean;
    set dragOutsideBoundary(value: boolean);
    get enableBodyScroll(): boolean;
    set enableBodyScroll(value: boolean);
    get focusStateEnabled(): boolean;
    set focusStateEnabled(value: boolean);
    get fullScreen(): boolean;
    set fullScreen(value: boolean);
    get height(): number | string;
    set height(value: number | string);
    get hideOnOutsideClick(): boolean | ((event: event) => boolean);
    set hideOnOutsideClick(value: boolean | ((event: event) => boolean));
    get hideOnParentScroll(): boolean;
    set hideOnParentScroll(value: boolean);
    get hint(): string | undefined;
    set hint(value: string | undefined);
    get hoverStateEnabled(): boolean;
    set hoverStateEnabled(value: boolean);
    get maxHeight(): number | string;
    set maxHeight(value: number | string);
    get maxWidth(): number | string;
    set maxWidth(value: number | string);
    get minHeight(): number | string;
    set minHeight(value: number | string);
    get minWidth(): number | string;
    set minWidth(value: number | string);
    get onContentReady(): ((e: EventInfo<any>) => void) | undefined;
    set onContentReady(value: ((e: EventInfo<any>) => void) | undefined);
    get onDisposing(): ((e: EventInfo<any>) => void) | undefined;
    set onDisposing(value: ((e: EventInfo<any>) => void) | undefined);
    get onHidden(): ((e: EventInfo<any>) => void);
    set onHidden(value: ((e: EventInfo<any>) => void));
    get onHiding(): ((e: {
        cancel: boolean | any;
        component: dxOverlay<any>;
        element: any;
        model: any;
    }) => void);
    set onHiding(value: ((e: {
        cancel: boolean | any;
        component: dxOverlay<any>;
        element: any;
        model: any;
    }) => void));
    get onInitialized(): ((e: {
        component: Component<any>;
        element: any;
    }) => void) | undefined;
    set onInitialized(value: ((e: {
        component: Component<any>;
        element: any;
    }) => void) | undefined);
    get onOptionChanged(): ((e: {
        component: DOMComponent;
        element: any;
        fullName: string;
        model: any;
        name: string;
        previousValue: any;
        value: any;
    }) => void) | undefined;
    set onOptionChanged(value: ((e: {
        component: DOMComponent;
        element: any;
        fullName: string;
        model: any;
        name: string;
        previousValue: any;
        value: any;
    }) => void) | undefined);
    get onResize(): ((e: {
        component: dxPopup;
        element: any;
        event: event;
        height: number;
        model: any;
        width: number;
    }) => void) | undefined;
    set onResize(value: ((e: {
        component: dxPopup;
        element: any;
        event: event;
        height: number;
        model: any;
        width: number;
    }) => void) | undefined);
    get onResizeEnd(): ((e: {
        component: dxPopup;
        element: any;
        event: event;
        height: number;
        model: any;
        width: number;
    }) => void) | undefined;
    set onResizeEnd(value: ((e: {
        component: dxPopup;
        element: any;
        event: event;
        height: number;
        model: any;
        width: number;
    }) => void) | undefined);
    get onResizeStart(): ((e: {
        component: dxPopup;
        element: any;
        event: event;
        height: number;
        model: any;
        width: number;
    }) => void) | undefined;
    set onResizeStart(value: ((e: {
        component: dxPopup;
        element: any;
        event: event;
        height: number;
        model: any;
        width: number;
    }) => void) | undefined);
    get onShowing(): ((e: {
        cancel: boolean | any;
        component: dxOverlay<any>;
        element: any;
        model: any;
    }) => void);
    set onShowing(value: ((e: {
        cancel: boolean | any;
        component: dxOverlay<any>;
        element: any;
        model: any;
    }) => void));
    get onShown(): ((e: EventInfo<any>) => void);
    set onShown(value: ((e: EventInfo<any>) => void));
    get onTitleRendered(): ((e: {
        component: dxPopup;
        element: any;
        model: any;
        titleElement: any;
    }) => void) | undefined;
    set onTitleRendered(value: ((e: {
        component: dxPopup;
        element: any;
        model: any;
        titleElement: any;
    }) => void) | undefined);
    get position(): Function | PositionAlignment | PositionConfig;
    set position(value: Function | PositionAlignment | PositionConfig);
    get resizeEnabled(): boolean;
    set resizeEnabled(value: boolean);
    get restorePosition(): boolean;
    set restorePosition(value: boolean);
    get rtlEnabled(): boolean;
    set rtlEnabled(value: boolean);
    get shading(): boolean;
    set shading(value: boolean);
    get shadingColor(): string;
    set shadingColor(value: string);
    get showCloseButton(): boolean;
    set showCloseButton(value: boolean);
    get showTitle(): boolean;
    set showTitle(value: boolean);
    get tabFocusLoopEnabled(): boolean;
    set tabFocusLoopEnabled(value: boolean);
    get tabIndex(): number;
    set tabIndex(value: number);
    get title(): string;
    set title(value: string);
    get titleTemplate(): any;
    set titleTemplate(value: any);
    get toolbarItems(): Array<dxPopupToolbarItem>;
    set toolbarItems(value: Array<dxPopupToolbarItem>);
    get visible(): boolean;
    set visible(value: boolean);
    get width(): number | string;
    set width(value: number | string);
    get wrapperAttr(): any;
    set wrapperAttr(value: any);
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    heightChange: EventEmitter<number | string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    positionChange: EventEmitter<Function | PositionAlignment | PositionConfig>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    visibleChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    widthChange: EventEmitter<number | string>;
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoColorBoxDropDownOptionsComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoColorBoxDropDownOptionsComponent, "dxo-color-box-drop-down-options", never, { "accessKey": { "alias": "accessKey"; "required": false; }; "animation": { "alias": "animation"; "required": false; }; "container": { "alias": "container"; "required": false; }; "contentTemplate": { "alias": "contentTemplate"; "required": false; }; "deferRendering": { "alias": "deferRendering"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "dragAndResizeArea": { "alias": "dragAndResizeArea"; "required": false; }; "dragEnabled": { "alias": "dragEnabled"; "required": false; }; "dragOutsideBoundary": { "alias": "dragOutsideBoundary"; "required": false; }; "enableBodyScroll": { "alias": "enableBodyScroll"; "required": false; }; "focusStateEnabled": { "alias": "focusStateEnabled"; "required": false; }; "fullScreen": { "alias": "fullScreen"; "required": false; }; "height": { "alias": "height"; "required": false; }; "hideOnOutsideClick": { "alias": "hideOnOutsideClick"; "required": false; }; "hideOnParentScroll": { "alias": "hideOnParentScroll"; "required": false; }; "hint": { "alias": "hint"; "required": false; }; "hoverStateEnabled": { "alias": "hoverStateEnabled"; "required": false; }; "maxHeight": { "alias": "maxHeight"; "required": false; }; "maxWidth": { "alias": "maxWidth"; "required": false; }; "minHeight": { "alias": "minHeight"; "required": false; }; "minWidth": { "alias": "minWidth"; "required": false; }; "onContentReady": { "alias": "onContentReady"; "required": false; }; "onDisposing": { "alias": "onDisposing"; "required": false; }; "onHidden": { "alias": "onHidden"; "required": false; }; "onHiding": { "alias": "onHiding"; "required": false; }; "onInitialized": { "alias": "onInitialized"; "required": false; }; "onOptionChanged": { "alias": "onOptionChanged"; "required": false; }; "onResize": { "alias": "onResize"; "required": false; }; "onResizeEnd": { "alias": "onResizeEnd"; "required": false; }; "onResizeStart": { "alias": "onResizeStart"; "required": false; }; "onShowing": { "alias": "onShowing"; "required": false; }; "onShown": { "alias": "onShown"; "required": false; }; "onTitleRendered": { "alias": "onTitleRendered"; "required": false; }; "position": { "alias": "position"; "required": false; }; "resizeEnabled": { "alias": "resizeEnabled"; "required": false; }; "restorePosition": { "alias": "restorePosition"; "required": false; }; "rtlEnabled": { "alias": "rtlEnabled"; "required": false; }; "shading": { "alias": "shading"; "required": false; }; "shadingColor": { "alias": "shadingColor"; "required": false; }; "showCloseButton": { "alias": "showCloseButton"; "required": false; }; "showTitle": { "alias": "showTitle"; "required": false; }; "tabFocusLoopEnabled": { "alias": "tabFocusLoopEnabled"; "required": false; }; "tabIndex": { "alias": "tabIndex"; "required": false; }; "title": { "alias": "title"; "required": false; }; "titleTemplate": { "alias": "titleTemplate"; "required": false; }; "toolbarItems": { "alias": "toolbarItems"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; "wrapperAttr": { "alias": "wrapperAttr"; "required": false; }; }, { "heightChange": "heightChange"; "positionChange": "positionChange"; "visibleChange": "visibleChange"; "widthChange": "widthChange"; }, ["_toolbarItemsContentChildren"], never, true, never>;
}
declare class DxoColorBoxDropDownOptionsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoColorBoxDropDownOptionsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoColorBoxDropDownOptionsModule, never, [typeof DxoColorBoxDropDownOptionsComponent], [typeof DxoColorBoxDropDownOptionsComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoColorBoxDropDownOptionsModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoColorBoxFieldAddonsComponent extends NestedOption implements OnDestroy, OnInit {
    get afterTemplate(): any;
    set afterTemplate(value: any);
    get beforeTemplate(): any;
    set beforeTemplate(value: any);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoColorBoxFieldAddonsComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoColorBoxFieldAddonsComponent, "dxo-color-box-field-addons", never, { "afterTemplate": { "alias": "afterTemplate"; "required": false; }; "beforeTemplate": { "alias": "beforeTemplate"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoColorBoxFieldAddonsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoColorBoxFieldAddonsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoColorBoxFieldAddonsModule, never, [typeof DxoColorBoxFieldAddonsComponent], [typeof DxoColorBoxFieldAddonsComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoColorBoxFieldAddonsModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoColorBoxFromComponent extends NestedOption implements OnDestroy, OnInit {
    get left(): number;
    set left(value: number);
    get opacity(): number;
    set opacity(value: number);
    get position(): PositionConfig;
    set position(value: PositionConfig);
    get scale(): number;
    set scale(value: number);
    get top(): number;
    set top(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoColorBoxFromComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoColorBoxFromComponent, "dxo-color-box-from", never, { "left": { "alias": "left"; "required": false; }; "opacity": { "alias": "opacity"; "required": false; }; "position": { "alias": "position"; "required": false; }; "scale": { "alias": "scale"; "required": false; }; "top": { "alias": "top"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoColorBoxFromModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoColorBoxFromModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoColorBoxFromModule, never, [typeof DxoColorBoxFromComponent], [typeof DxoColorBoxFromComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoColorBoxFromModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoColorBoxHideComponent extends NestedOption implements OnDestroy, OnInit {
    get complete(): (($element: any, config: AnimationConfig) => void);
    set complete(value: (($element: any, config: AnimationConfig) => void));
    get delay(): number;
    set delay(value: number);
    get direction(): Direction | undefined;
    set direction(value: Direction | undefined);
    get duration(): number;
    set duration(value: number);
    get easing(): string;
    set easing(value: string);
    get from(): AnimationState;
    set from(value: AnimationState);
    get staggerDelay(): number | undefined;
    set staggerDelay(value: number | undefined);
    get start(): (($element: any, config: AnimationConfig) => void);
    set start(value: (($element: any, config: AnimationConfig) => void));
    get to(): AnimationState;
    set to(value: AnimationState);
    get type(): AnimationType;
    set type(value: AnimationType);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoColorBoxHideComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoColorBoxHideComponent, "dxo-color-box-hide", never, { "complete": { "alias": "complete"; "required": false; }; "delay": { "alias": "delay"; "required": false; }; "direction": { "alias": "direction"; "required": false; }; "duration": { "alias": "duration"; "required": false; }; "easing": { "alias": "easing"; "required": false; }; "from": { "alias": "from"; "required": false; }; "staggerDelay": { "alias": "staggerDelay"; "required": false; }; "start": { "alias": "start"; "required": false; }; "to": { "alias": "to"; "required": false; }; "type": { "alias": "type"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoColorBoxHideModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoColorBoxHideModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoColorBoxHideModule, never, [typeof DxoColorBoxHideComponent], [typeof DxoColorBoxHideComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoColorBoxHideModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoColorBoxMyComponent extends NestedOption implements OnDestroy, OnInit {
    get x(): HorizontalAlignment;
    set x(value: HorizontalAlignment);
    get y(): VerticalAlignment;
    set y(value: VerticalAlignment);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoColorBoxMyComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoColorBoxMyComponent, "dxo-color-box-my", never, { "x": { "alias": "x"; "required": false; }; "y": { "alias": "y"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoColorBoxMyModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoColorBoxMyModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoColorBoxMyModule, never, [typeof DxoColorBoxMyComponent], [typeof DxoColorBoxMyComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoColorBoxMyModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoColorBoxOffsetComponent extends NestedOption implements OnDestroy, OnInit {
    get x(): number;
    set x(value: number);
    get y(): number;
    set y(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoColorBoxOffsetComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoColorBoxOffsetComponent, "dxo-color-box-offset", never, { "x": { "alias": "x"; "required": false; }; "y": { "alias": "y"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoColorBoxOffsetModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoColorBoxOffsetModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoColorBoxOffsetModule, never, [typeof DxoColorBoxOffsetComponent], [typeof DxoColorBoxOffsetComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoColorBoxOffsetModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoColorBoxOptionsComponent extends NestedOption implements AfterViewInit, OnDestroy, OnInit, IDxTemplateHost {
    private renderer;
    private document;
    private element;
    get accessKey(): string | undefined;
    set accessKey(value: string | undefined);
    get activeStateEnabled(): boolean;
    set activeStateEnabled(value: boolean);
    get disabled(): boolean;
    set disabled(value: boolean);
    get elementAttr(): Record<string, any>;
    set elementAttr(value: Record<string, any>);
    get focusStateEnabled(): boolean;
    set focusStateEnabled(value: boolean);
    get height(): number | string | undefined;
    set height(value: number | string | undefined);
    get hint(): string | undefined;
    set hint(value: string | undefined);
    get hoverStateEnabled(): boolean;
    set hoverStateEnabled(value: boolean);
    get icon(): string;
    set icon(value: string);
    get onClick(): ((e: ClickEvent) => void) | undefined;
    set onClick(value: ((e: ClickEvent) => void) | undefined);
    get onContentReady(): ((e: ContentReadyEvent) => void);
    set onContentReady(value: ((e: ContentReadyEvent) => void));
    get onDisposing(): ((e: DisposingEvent) => void);
    set onDisposing(value: ((e: DisposingEvent) => void));
    get onInitialized(): ((e: InitializedEvent) => void);
    set onInitialized(value: ((e: InitializedEvent) => void));
    get onOptionChanged(): ((e: OptionChangedEvent) => void);
    set onOptionChanged(value: ((e: OptionChangedEvent) => void));
    get rtlEnabled(): boolean;
    set rtlEnabled(value: boolean);
    get stylingMode(): ButtonStyle;
    set stylingMode(value: ButtonStyle);
    get tabIndex(): number;
    set tabIndex(value: number);
    get template(): any;
    set template(value: any);
    get text(): string;
    set text(value: string);
    get type(): ButtonType | string;
    set type(value: ButtonType | string);
    get useSubmitBehavior(): boolean;
    set useSubmitBehavior(value: boolean);
    get validationGroup(): string | undefined;
    set validationGroup(value: string | undefined);
    get visible(): boolean;
    set visible(value: boolean);
    get width(): number | string | undefined;
    set width(value: number | string | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost, renderer: Renderer2, document: any, templateHost: DxTemplateHost, element: ElementRef);
    setTemplate(template: DxTemplateDirective): void;
    ngAfterViewInit(): void;
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoColorBoxOptionsComponent, [{ host: true; skipSelf: true; }, { host: true; }, null, null, { host: true; }, null]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoColorBoxOptionsComponent, "dxo-color-box-options", never, { "accessKey": { "alias": "accessKey"; "required": false; }; "activeStateEnabled": { "alias": "activeStateEnabled"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "elementAttr": { "alias": "elementAttr"; "required": false; }; "focusStateEnabled": { "alias": "focusStateEnabled"; "required": false; }; "height": { "alias": "height"; "required": false; }; "hint": { "alias": "hint"; "required": false; }; "hoverStateEnabled": { "alias": "hoverStateEnabled"; "required": false; }; "icon": { "alias": "icon"; "required": false; }; "onClick": { "alias": "onClick"; "required": false; }; "onContentReady": { "alias": "onContentReady"; "required": false; }; "onDisposing": { "alias": "onDisposing"; "required": false; }; "onInitialized": { "alias": "onInitialized"; "required": false; }; "onOptionChanged": { "alias": "onOptionChanged"; "required": false; }; "rtlEnabled": { "alias": "rtlEnabled"; "required": false; }; "stylingMode": { "alias": "stylingMode"; "required": false; }; "tabIndex": { "alias": "tabIndex"; "required": false; }; "template": { "alias": "template"; "required": false; }; "text": { "alias": "text"; "required": false; }; "type": { "alias": "type"; "required": false; }; "useSubmitBehavior": { "alias": "useSubmitBehavior"; "required": false; }; "validationGroup": { "alias": "validationGroup"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, ["*"], true, never>;
}
declare class DxoColorBoxOptionsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoColorBoxOptionsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoColorBoxOptionsModule, never, [typeof DxoColorBoxOptionsComponent], [typeof DxoColorBoxOptionsComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoColorBoxOptionsModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoColorBoxPositionComponent extends NestedOption implements OnDestroy, OnInit {
    get at(): PositionAlignment | {
        x?: HorizontalAlignment;
        y?: VerticalAlignment;
    };
    set at(value: PositionAlignment | {
        x?: HorizontalAlignment;
        y?: VerticalAlignment;
    });
    get boundary(): any | string;
    set boundary(value: any | string);
    get boundaryOffset(): string | {
        x?: number;
        y?: number;
    };
    set boundaryOffset(value: string | {
        x?: number;
        y?: number;
    });
    get collision(): CollisionResolutionCombination | {
        x?: CollisionResolution;
        y?: CollisionResolution;
    };
    set collision(value: CollisionResolutionCombination | {
        x?: CollisionResolution;
        y?: CollisionResolution;
    });
    get my(): PositionAlignment | {
        x?: HorizontalAlignment;
        y?: VerticalAlignment;
    };
    set my(value: PositionAlignment | {
        x?: HorizontalAlignment;
        y?: VerticalAlignment;
    });
    get of(): any | string;
    set of(value: any | string);
    get offset(): string | {
        x?: number;
        y?: number;
    };
    set offset(value: string | {
        x?: number;
        y?: number;
    });
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoColorBoxPositionComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoColorBoxPositionComponent, "dxo-color-box-position", never, { "at": { "alias": "at"; "required": false; }; "boundary": { "alias": "boundary"; "required": false; }; "boundaryOffset": { "alias": "boundaryOffset"; "required": false; }; "collision": { "alias": "collision"; "required": false; }; "my": { "alias": "my"; "required": false; }; "of": { "alias": "of"; "required": false; }; "offset": { "alias": "offset"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoColorBoxPositionModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoColorBoxPositionModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoColorBoxPositionModule, never, [typeof DxoColorBoxPositionComponent], [typeof DxoColorBoxPositionComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoColorBoxPositionModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoColorBoxShowComponent extends NestedOption implements OnDestroy, OnInit {
    get complete(): (($element: any, config: AnimationConfig) => void);
    set complete(value: (($element: any, config: AnimationConfig) => void));
    get delay(): number;
    set delay(value: number);
    get direction(): Direction | undefined;
    set direction(value: Direction | undefined);
    get duration(): number;
    set duration(value: number);
    get easing(): string;
    set easing(value: string);
    get from(): AnimationState;
    set from(value: AnimationState);
    get staggerDelay(): number | undefined;
    set staggerDelay(value: number | undefined);
    get start(): (($element: any, config: AnimationConfig) => void);
    set start(value: (($element: any, config: AnimationConfig) => void));
    get to(): AnimationState;
    set to(value: AnimationState);
    get type(): AnimationType;
    set type(value: AnimationType);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoColorBoxShowComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoColorBoxShowComponent, "dxo-color-box-show", never, { "complete": { "alias": "complete"; "required": false; }; "delay": { "alias": "delay"; "required": false; }; "direction": { "alias": "direction"; "required": false; }; "duration": { "alias": "duration"; "required": false; }; "easing": { "alias": "easing"; "required": false; }; "from": { "alias": "from"; "required": false; }; "staggerDelay": { "alias": "staggerDelay"; "required": false; }; "start": { "alias": "start"; "required": false; }; "to": { "alias": "to"; "required": false; }; "type": { "alias": "type"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoColorBoxShowModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoColorBoxShowModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoColorBoxShowModule, never, [typeof DxoColorBoxShowComponent], [typeof DxoColorBoxShowComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoColorBoxShowModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoColorBoxToComponent extends NestedOption implements OnDestroy, OnInit {
    get left(): number;
    set left(value: number);
    get opacity(): number;
    set opacity(value: number);
    get position(): PositionConfig;
    set position(value: PositionConfig);
    get scale(): number;
    set scale(value: number);
    get top(): number;
    set top(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoColorBoxToComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoColorBoxToComponent, "dxo-color-box-to", never, { "left": { "alias": "left"; "required": false; }; "opacity": { "alias": "opacity"; "required": false; }; "position": { "alias": "position"; "required": false; }; "scale": { "alias": "scale"; "required": false; }; "top": { "alias": "top"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoColorBoxToModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoColorBoxToModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoColorBoxToModule, never, [typeof DxoColorBoxToComponent], [typeof DxoColorBoxToComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoColorBoxToModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxiColorBoxToolbarItemComponent extends CollectionNestedOption implements AfterViewInit, IDxTemplateHost {
    private renderer;
    private document;
    private element;
    get cssClass(): string | undefined;
    set cssClass(value: string | undefined);
    get disabled(): boolean;
    set disabled(value: boolean);
    get html(): string;
    set html(value: string);
    get locateInMenu(): LocateInMenuMode;
    set locateInMenu(value: LocateInMenuMode);
    get location(): ToolbarItemLocation;
    set location(value: ToolbarItemLocation);
    get menuItemTemplate(): any;
    set menuItemTemplate(value: any);
    get options(): any;
    set options(value: any);
    get showText(): ShowTextMode;
    set showText(value: ShowTextMode);
    get template(): any;
    set template(value: any);
    get text(): string;
    set text(value: string);
    get toolbar(): ToolbarLocation;
    set toolbar(value: ToolbarLocation);
    get visible(): boolean;
    set visible(value: boolean);
    get widget(): ToolbarItemComponent;
    set widget(value: ToolbarItemComponent);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost, renderer: Renderer2, document: any, templateHost: DxTemplateHost, element: ElementRef);
    setTemplate(template: DxTemplateDirective): void;
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiColorBoxToolbarItemComponent, [{ host: true; skipSelf: true; }, { host: true; }, null, null, { host: true; }, null]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiColorBoxToolbarItemComponent, "dxi-color-box-toolbar-item", never, { "cssClass": { "alias": "cssClass"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "html": { "alias": "html"; "required": false; }; "locateInMenu": { "alias": "locateInMenu"; "required": false; }; "location": { "alias": "location"; "required": false; }; "menuItemTemplate": { "alias": "menuItemTemplate"; "required": false; }; "options": { "alias": "options"; "required": false; }; "showText": { "alias": "showText"; "required": false; }; "template": { "alias": "template"; "required": false; }; "text": { "alias": "text"; "required": false; }; "toolbar": { "alias": "toolbar"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "widget": { "alias": "widget"; "required": false; }; }, {}, never, ["*"], true, never>;
}
declare class DxiColorBoxToolbarItemModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiColorBoxToolbarItemModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiColorBoxToolbarItemModule, never, [typeof DxiColorBoxToolbarItemComponent], [typeof DxiColorBoxToolbarItemComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiColorBoxToolbarItemModule>;
}

export { DxiColorBoxButtonComponent, DxiColorBoxButtonModule, DxiColorBoxToolbarItemComponent, DxiColorBoxToolbarItemModule, DxoColorBoxAnimationComponent, DxoColorBoxAnimationModule, DxoColorBoxAtComponent, DxoColorBoxAtModule, DxoColorBoxBoundaryOffsetComponent, DxoColorBoxBoundaryOffsetModule, DxoColorBoxCollisionComponent, DxoColorBoxCollisionModule, DxoColorBoxDropDownOptionsComponent, DxoColorBoxDropDownOptionsModule, DxoColorBoxFieldAddonsComponent, DxoColorBoxFieldAddonsModule, DxoColorBoxFromComponent, DxoColorBoxFromModule, DxoColorBoxHideComponent, DxoColorBoxHideModule, DxoColorBoxMyComponent, DxoColorBoxMyModule, DxoColorBoxOffsetComponent, DxoColorBoxOffsetModule, DxoColorBoxOptionsComponent, DxoColorBoxOptionsModule, DxoColorBoxPositionComponent, DxoColorBoxPositionModule, DxoColorBoxShowComponent, DxoColorBoxShowModule, DxoColorBoxToComponent, DxoColorBoxToModule };
//# sourceMappingURL=index.d.ts.map
