import * as i0 from '@angular/core';
import { OnDestroy, OnInit } from '@angular/core';
import { NestedOption, NestedOptionHost } from 'devextreme-angular/core';

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoDraggableCursorOffsetComponent extends NestedOption implements OnDestroy, OnInit {
    get x(): number;
    set x(value: number);
    get y(): number;
    set y(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDraggableCursorOffsetComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoDraggableCursorOffsetComponent, "dxo-draggable-cursor-offset", never, { "x": { "alias": "x"; "required": false; }; "y": { "alias": "y"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoDraggableCursorOffsetModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDraggableCursorOffsetModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoDraggableCursorOffsetModule, never, [typeof DxoDraggableCursorOffsetComponent], [typeof DxoDraggableCursorOffsetComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoDraggableCursorOffsetModule>;
}

export { DxoDraggableCursorOffsetComponent, DxoDraggableCursorOffsetModule };
//# sourceMappingURL=index.d.ts.map
