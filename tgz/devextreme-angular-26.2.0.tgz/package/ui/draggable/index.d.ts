import * as i0 from '@angular/core';
import { OnDestroy, EventEmitter, ElementRef, NgZone, TransferState } from '@angular/core';
import { DragDirection } from 'devextreme/common';
import DxDraggable, { DisposingEvent, DragEndEvent, DragMoveEvent, DragStartEvent, InitializedEvent, OptionChangedEvent } from 'devextreme/ui/draggable';
import * as i3 from 'devextreme-angular/core';
import { DxComponent, DxTemplateHost, WatcherHelper, NestedOptionHost } from 'devextreme-angular/core';
import * as i1 from 'devextreme-angular/ui/nested';
import * as i2 from 'devextreme-angular/ui/draggable/nested';
export * from 'devextreme-angular/ui/draggable/nested';
import * as draggable_types from 'devextreme/ui/draggable_types';
export { draggable_types as DxDraggableTypes };

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

/**
 * [descr:dxDraggable]

 */
declare class DxDraggableComponent extends DxComponent implements OnDestroy {
    instance: DxDraggable;
    /**
     * [descr:DraggableBaseOptions.autoScroll]
    
     */
    get autoScroll(): boolean;
    set autoScroll(value: boolean);
    /**
     * [descr:DraggableBaseOptions.boundary]
    
     */
    get boundary(): any | string | undefined;
    set boundary(value: any | string | undefined);
    /**
     * [descr:dxDraggableOptions.clone]
    
     */
    get clone(): boolean;
    set clone(value: boolean);
    /**
     * [descr:DraggableBaseOptions.container]
    
     */
    get container(): any | string | undefined;
    set container(value: any | string | undefined);
    /**
     * [descr:DraggableBaseOptions.cursorOffset]
    
     */
    get cursorOffset(): string | {
        x?: number;
        y?: number;
    };
    set cursorOffset(value: string | {
        x?: number;
        y?: number;
    });
    /**
     * [descr:DraggableBaseOptions.data]
    
     */
    get data(): any | undefined;
    set data(value: any | undefined);
    /**
     * [descr:DraggableBaseOptions.dragDirection]
    
     */
    get dragDirection(): DragDirection;
    set dragDirection(value: DragDirection);
    /**
     * [descr:dxDraggableOptions.dragTemplate]
    
     */
    get dragTemplate(): any;
    set dragTemplate(value: any);
    /**
     * [descr:DOMComponentOptions.elementAttr]
    
     */
    get elementAttr(): Record<string, any>;
    set elementAttr(value: Record<string, any>);
    /**
     * [descr:DraggableBaseOptions.group]
    
     */
    get group(): string | undefined;
    set group(value: string | undefined);
    /**
     * [descr:DraggableBaseOptions.handle]
    
     */
    get handle(): string;
    set handle(value: string);
    /**
     * [descr:DOMComponentOptions.height]
    
     */
    get height(): number | string | undefined;
    set height(value: number | string | undefined);
    /**
     * [descr:DOMComponentOptions.rtlEnabled]
    
     */
    get rtlEnabled(): boolean;
    set rtlEnabled(value: boolean);
    /**
     * [descr:DraggableBaseOptions.scrollSensitivity]
    
     */
    get scrollSensitivity(): number;
    set scrollSensitivity(value: number);
    /**
     * [descr:DraggableBaseOptions.scrollSpeed]
    
     */
    get scrollSpeed(): number;
    set scrollSpeed(value: number);
    /**
     * [descr:DOMComponentOptions.width]
    
     */
    get width(): number | string | undefined;
    set width(value: number | string | undefined);
    /**
    
     * [descr:dxDraggableOptions.onDisposing]
    
    
     */
    onDisposing: EventEmitter<DisposingEvent>;
    /**
    
     * [descr:dxDraggableOptions.onDragEnd]
    
    
     */
    onDragEnd: EventEmitter<DragEndEvent>;
    /**
    
     * [descr:dxDraggableOptions.onDragMove]
    
    
     */
    onDragMove: EventEmitter<DragMoveEvent>;
    /**
    
     * [descr:dxDraggableOptions.onDragStart]
    
    
     */
    onDragStart: EventEmitter<DragStartEvent>;
    /**
    
     * [descr:dxDraggableOptions.onInitialized]
    
    
     */
    onInitialized: EventEmitter<InitializedEvent>;
    /**
    
     * [descr:dxDraggableOptions.onOptionChanged]
    
    
     */
    onOptionChanged: EventEmitter<OptionChangedEvent>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    autoScrollChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    boundaryChange: EventEmitter<any | string | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    cloneChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    containerChange: EventEmitter<any | string | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    cursorOffsetChange: EventEmitter<string | {
        x?: number;
        y?: number;
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    dataChange: EventEmitter<any | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    dragDirectionChange: EventEmitter<DragDirection>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    dragTemplateChange: EventEmitter<any>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    elementAttrChange: EventEmitter<Record<string, any>>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    groupChange: EventEmitter<string | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    handleChange: EventEmitter<string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    heightChange: EventEmitter<number | string | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    rtlEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    scrollSensitivityChange: EventEmitter<number>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    scrollSpeedChange: EventEmitter<number>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    widthChange: EventEmitter<number | string | undefined>;
    constructor(elementRef: ElementRef, ngZone: NgZone, templateHost: DxTemplateHost, _watcherHelper: WatcherHelper, optionHost: NestedOptionHost, transferState: TransferState, platformId: any);
    protected _createInstance(element: any, options: any): DxDraggable;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxDraggableComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxDraggableComponent, "dx-draggable", never, { "autoScroll": { "alias": "autoScroll"; "required": false; }; "boundary": { "alias": "boundary"; "required": false; }; "clone": { "alias": "clone"; "required": false; }; "container": { "alias": "container"; "required": false; }; "cursorOffset": { "alias": "cursorOffset"; "required": false; }; "data": { "alias": "data"; "required": false; }; "dragDirection": { "alias": "dragDirection"; "required": false; }; "dragTemplate": { "alias": "dragTemplate"; "required": false; }; "elementAttr": { "alias": "elementAttr"; "required": false; }; "group": { "alias": "group"; "required": false; }; "handle": { "alias": "handle"; "required": false; }; "height": { "alias": "height"; "required": false; }; "rtlEnabled": { "alias": "rtlEnabled"; "required": false; }; "scrollSensitivity": { "alias": "scrollSensitivity"; "required": false; }; "scrollSpeed": { "alias": "scrollSpeed"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, { "onDisposing": "onDisposing"; "onDragEnd": "onDragEnd"; "onDragMove": "onDragMove"; "onDragStart": "onDragStart"; "onInitialized": "onInitialized"; "onOptionChanged": "onOptionChanged"; "autoScrollChange": "autoScrollChange"; "boundaryChange": "boundaryChange"; "cloneChange": "cloneChange"; "containerChange": "containerChange"; "cursorOffsetChange": "cursorOffsetChange"; "dataChange": "dataChange"; "dragDirectionChange": "dragDirectionChange"; "dragTemplateChange": "dragTemplateChange"; "elementAttrChange": "elementAttrChange"; "groupChange": "groupChange"; "handleChange": "handleChange"; "heightChange": "heightChange"; "rtlEnabledChange": "rtlEnabledChange"; "scrollSensitivityChange": "scrollSensitivityChange"; "scrollSpeedChange": "scrollSpeedChange"; "widthChange": "widthChange"; }, never, ["*"], true, never>;
}
declare class DxDraggableModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxDraggableModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxDraggableModule, never, [typeof DxDraggableComponent, typeof i1.DxoCursorOffsetModule, typeof i2.DxoDraggableCursorOffsetModule, typeof i3.DxIntegrationModule, typeof i3.DxTemplateModule], [typeof DxDraggableComponent, typeof i1.DxoCursorOffsetModule, typeof i2.DxoDraggableCursorOffsetModule, typeof i3.DxTemplateModule]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxDraggableModule>;
}

export { DxDraggableComponent, DxDraggableModule };
//# sourceMappingURL=index.d.ts.map
