import * as i0 from '@angular/core';
import { OnDestroy, OnChanges, DoCheck, QueryList, EventEmitter, ElementRef, NgZone, TransferState, SimpleChanges } from '@angular/core';
import DxVectorMap, { dxVectorMapAnnotationConfig, dxVectorMapCommonAnnotationConfig, MapLayerElement, VectorMapMarkerType, VectorMapLayerType, VectorMapLegendItem, VectorMapMarkerShape, CenterChangedEvent, ClickEvent, DisposingEvent, DrawnEvent, ExportedEvent, ExportingEvent, FileSavingEvent, IncidentOccurredEvent, InitializedEvent, OptionChangedEvent, SelectionChangedEvent, TooltipHiddenEvent, TooltipShownEvent, ZoomFactorChangedEvent } from 'devextreme/viz/vector_map';
import { HorizontalAlignment, VerticalEdge, ExportFormat, SingleMultipleOrNone, Position, Orientation } from 'devextreme/common';
import DataSource, { DataSourceOptions } from 'devextreme/data/data_source';
import { Store } from 'devextreme/data/store';
import { Font, Palette, DashStyle, Theme, TextOverflow, WordWrap } from 'devextreme/common/charts';
import { VectorMapProjection, VectorMapProjectionConfig } from 'devextreme/viz/vector_map/projection';
import * as i3 from 'devextreme-angular/core';
import { DxComponent, CollectionNestedOption, DxTemplateHost, WatcherHelper, IterableDifferHelper, NestedOptionHost } from 'devextreme-angular/core';
import * as i1 from 'devextreme-angular/ui/nested';
import * as i2 from 'devextreme-angular/ui/vector-map/nested';
export * from 'devextreme-angular/ui/vector-map/nested';
import * as vector_map_types from 'devextreme/viz/vector_map_types';
export { vector_map_types as DxVectorMapTypes };

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

/**
 * [descr:dxVectorMap]

 */
declare class DxVectorMapComponent extends DxComponent implements OnDestroy, OnChanges, DoCheck {
    private _watcherHelper;
    private _idh;
    set _annotationsContentChildren(value: QueryList<CollectionNestedOption>);
    set _layersContentChildren(value: QueryList<CollectionNestedOption>);
    set _legendsContentChildren(value: QueryList<CollectionNestedOption>);
    instance: DxVectorMap;
    /**
     * [descr:dxVectorMapOptions.annotations]
    
     */
    get annotations(): Array<any | dxVectorMapAnnotationConfig>;
    set annotations(value: Array<any | dxVectorMapAnnotationConfig>);
    /**
     * [descr:dxVectorMapOptions.background]
    
     */
    get background(): {
        borderColor?: string;
        color?: string;
    };
    set background(value: {
        borderColor?: string;
        color?: string;
    });
    /**
     * [descr:dxVectorMapOptions.bounds]
    
     */
    get bounds(): Array<number> | undefined;
    set bounds(value: Array<number> | undefined);
    /**
     * [descr:dxVectorMapOptions.center]
    
     */
    get center(): Array<number>;
    set center(value: Array<number>);
    /**
     * [descr:dxVectorMapOptions.commonAnnotationSettings]
    
     */
    get commonAnnotationSettings(): dxVectorMapCommonAnnotationConfig;
    set commonAnnotationSettings(value: dxVectorMapCommonAnnotationConfig);
    /**
     * [descr:dxVectorMapOptions.controlBar]
    
     */
    get controlBar(): {
        borderColor?: string;
        color?: string;
        enabled?: boolean;
        horizontalAlignment?: HorizontalAlignment;
        margin?: number;
        opacity?: number;
        panVisible?: boolean;
        verticalAlignment?: VerticalEdge;
        zoomVisible?: boolean;
    };
    set controlBar(value: {
        borderColor?: string;
        color?: string;
        enabled?: boolean;
        horizontalAlignment?: HorizontalAlignment;
        margin?: number;
        opacity?: number;
        panVisible?: boolean;
        verticalAlignment?: VerticalEdge;
        zoomVisible?: boolean;
    });
    /**
     * [descr:dxVectorMapOptions.customizeAnnotation]
    
     */
    get customizeAnnotation(): ((annotation: dxVectorMapAnnotationConfig | any) => dxVectorMapAnnotationConfig) | undefined;
    set customizeAnnotation(value: ((annotation: dxVectorMapAnnotationConfig | any) => dxVectorMapAnnotationConfig) | undefined);
    /**
     * [descr:BaseWidgetOptions.disabled]
    
     */
    get disabled(): boolean;
    set disabled(value: boolean);
    /**
     * [descr:DOMComponentOptions.elementAttr]
    
     */
    get elementAttr(): Record<string, any>;
    set elementAttr(value: Record<string, any>);
    /**
     * [descr:BaseWidgetOptions.encodeHtml]
    
     */
    get encodeHtml(): boolean;
    set encodeHtml(value: boolean);
    /**
     * [descr:BaseWidgetOptions.export]
    
     */
    get export(): {
        backgroundColor?: string;
        enabled?: boolean;
        fileName?: string;
        formats?: Array<ExportFormat>;
        margin?: number;
        printingEnabled?: boolean;
        svgToCanvas?: ((svg: any, canvas: any) => any) | undefined;
    };
    set export(value: {
        backgroundColor?: string;
        enabled?: boolean;
        fileName?: string;
        formats?: Array<ExportFormat>;
        margin?: number;
        printingEnabled?: boolean;
        svgToCanvas?: ((svg: any, canvas: any) => any) | undefined;
    });
    /**
     * [descr:dxVectorMapOptions.layers]
    
     */
    get layers(): {
        borderColor?: string;
        borderWidth?: number;
        color?: string;
        colorGroupingField?: string | undefined;
        colorGroups?: Array<number> | undefined;
        customize?: ((elements: Array<MapLayerElement>) => void);
        dataField?: string | undefined;
        dataSource?: Array<any> | DataSource | DataSourceOptions | null | Record<string, any> | Store | string;
        elementType?: VectorMapMarkerType;
        hoveredBorderColor?: string;
        hoveredBorderWidth?: number;
        hoveredColor?: string;
        hoverEnabled?: boolean;
        label?: {
            dataField?: string;
            enabled?: boolean;
            font?: Font;
        };
        maxSize?: number;
        minSize?: number;
        name?: string;
        opacity?: number;
        palette?: Array<string> | Palette;
        paletteIndex?: number;
        paletteSize?: number;
        selectedBorderColor?: string;
        selectedBorderWidth?: number;
        selectedColor?: string;
        selectionMode?: SingleMultipleOrNone;
        size?: number;
        sizeGroupingField?: string | undefined;
        sizeGroups?: Array<number> | undefined;
        type?: VectorMapLayerType;
    }[];
    set layers(value: {
        borderColor?: string;
        borderWidth?: number;
        color?: string;
        colorGroupingField?: string | undefined;
        colorGroups?: Array<number> | undefined;
        customize?: ((elements: Array<MapLayerElement>) => void);
        dataField?: string | undefined;
        dataSource?: Array<any> | DataSource | DataSourceOptions | null | Record<string, any> | Store | string;
        elementType?: VectorMapMarkerType;
        hoveredBorderColor?: string;
        hoveredBorderWidth?: number;
        hoveredColor?: string;
        hoverEnabled?: boolean;
        label?: {
            dataField?: string;
            enabled?: boolean;
            font?: Font;
        };
        maxSize?: number;
        minSize?: number;
        name?: string;
        opacity?: number;
        palette?: Array<string> | Palette;
        paletteIndex?: number;
        paletteSize?: number;
        selectedBorderColor?: string;
        selectedBorderWidth?: number;
        selectedColor?: string;
        selectionMode?: SingleMultipleOrNone;
        size?: number;
        sizeGroupingField?: string | undefined;
        sizeGroups?: Array<number> | undefined;
        type?: VectorMapLayerType;
    }[]);
    /**
     * [descr:dxVectorMapOptions.legends]
    
     */
    get legends(): {
        backgroundColor?: string | undefined;
        border?: {
            color?: string;
            cornerRadius?: number;
            dashStyle?: DashStyle;
            opacity?: number | undefined;
            visible?: boolean;
            width?: number;
        };
        columnCount?: number;
        columnItemSpacing?: number;
        customizeHint?: ((itemInfo: {
            color: string;
            end: number;
            index: number;
            size: number;
            start: number;
        }) => string);
        customizeItems?: ((items: Array<VectorMapLegendItem>) => Array<VectorMapLegendItem>);
        customizeText?: ((itemInfo: {
            color: string;
            end: number;
            index: number;
            size: number;
            start: number;
        }) => string);
        font?: Font;
        horizontalAlignment?: HorizontalAlignment;
        itemsAlignment?: HorizontalAlignment | undefined;
        itemTextPosition?: Position | undefined;
        margin?: number | {
            bottom?: number;
            left?: number;
            right?: number;
            top?: number;
        };
        markerColor?: string | undefined;
        markerShape?: VectorMapMarkerShape;
        markerSize?: number;
        markerTemplate?: any;
        orientation?: Orientation | undefined;
        paddingLeftRight?: number;
        paddingTopBottom?: number;
        rowCount?: number;
        rowItemSpacing?: number;
        source?: {
            grouping?: string;
            layer?: string;
        };
        title?: string | {
            font?: Font;
            horizontalAlignment?: HorizontalAlignment | undefined;
            margin?: {
                bottom?: number;
                left?: number;
                right?: number;
                top?: number;
            };
            placeholderSize?: number | undefined;
            subtitle?: string | {
                font?: Font;
                offset?: number;
                text?: string | undefined;
            };
            text?: string | undefined;
            verticalAlignment?: VerticalEdge;
        };
        verticalAlignment?: VerticalEdge;
        visible?: boolean;
    }[];
    set legends(value: {
        backgroundColor?: string | undefined;
        border?: {
            color?: string;
            cornerRadius?: number;
            dashStyle?: DashStyle;
            opacity?: number | undefined;
            visible?: boolean;
            width?: number;
        };
        columnCount?: number;
        columnItemSpacing?: number;
        customizeHint?: ((itemInfo: {
            color: string;
            end: number;
            index: number;
            size: number;
            start: number;
        }) => string);
        customizeItems?: ((items: Array<VectorMapLegendItem>) => Array<VectorMapLegendItem>);
        customizeText?: ((itemInfo: {
            color: string;
            end: number;
            index: number;
            size: number;
            start: number;
        }) => string);
        font?: Font;
        horizontalAlignment?: HorizontalAlignment;
        itemsAlignment?: HorizontalAlignment | undefined;
        itemTextPosition?: Position | undefined;
        margin?: number | {
            bottom?: number;
            left?: number;
            right?: number;
            top?: number;
        };
        markerColor?: string | undefined;
        markerShape?: VectorMapMarkerShape;
        markerSize?: number;
        markerTemplate?: any;
        orientation?: Orientation | undefined;
        paddingLeftRight?: number;
        paddingTopBottom?: number;
        rowCount?: number;
        rowItemSpacing?: number;
        source?: {
            grouping?: string;
            layer?: string;
        };
        title?: string | {
            font?: Font;
            horizontalAlignment?: HorizontalAlignment | undefined;
            margin?: {
                bottom?: number;
                left?: number;
                right?: number;
                top?: number;
            };
            placeholderSize?: number | undefined;
            subtitle?: string | {
                font?: Font;
                offset?: number;
                text?: string | undefined;
            };
            text?: string | undefined;
            verticalAlignment?: VerticalEdge;
        };
        verticalAlignment?: VerticalEdge;
        visible?: boolean;
    }[]);
    /**
     * [descr:BaseWidgetOptions.loadingIndicator]
    
     */
    get loadingIndicator(): {
        backgroundColor?: string;
        enabled?: boolean;
        font?: Font;
        show?: boolean;
        text?: string;
    };
    set loadingIndicator(value: {
        backgroundColor?: string;
        enabled?: boolean;
        font?: Font;
        show?: boolean;
        text?: string;
    });
    /**
     * [descr:dxVectorMapOptions.maxZoomFactor]
    
     */
    get maxZoomFactor(): number;
    set maxZoomFactor(value: number);
    /**
     * [descr:dxVectorMapOptions.panningEnabled]
    
     */
    get panningEnabled(): boolean;
    set panningEnabled(value: boolean);
    /**
     * [descr:BaseWidgetOptions.pathModified]
    
     */
    get pathModified(): boolean;
    set pathModified(value: boolean);
    /**
     * [descr:dxVectorMapOptions.projection]
    
     */
    get projection(): Record<string, any> | string | VectorMapProjection | VectorMapProjectionConfig;
    set projection(value: Record<string, any> | string | VectorMapProjection | VectorMapProjectionConfig);
    /**
     * [descr:BaseWidgetOptions.redrawOnResize]
    
     */
    get redrawOnResize(): boolean;
    set redrawOnResize(value: boolean);
    /**
     * [descr:BaseWidgetOptions.rtlEnabled]
    
     */
    get rtlEnabled(): boolean;
    set rtlEnabled(value: boolean);
    /**
     * [descr:BaseWidgetOptions.size]
    
     */
    get size(): {
        height?: number | undefined;
        width?: number | undefined;
    };
    set size(value: {
        height?: number | undefined;
        width?: number | undefined;
    });
    /**
     * [descr:BaseWidgetOptions.theme]
    
     */
    get theme(): Theme;
    set theme(value: Theme);
    /**
     * [descr:BaseWidgetOptions.title]
    
     */
    get title(): string | {
        font?: Font;
        horizontalAlignment?: HorizontalAlignment;
        margin?: number | {
            bottom?: number;
            left?: number;
            right?: number;
            top?: number;
        };
        placeholderSize?: number | undefined;
        subtitle?: string | {
            font?: Font;
            offset?: number;
            text?: string | undefined;
            textOverflow?: TextOverflow;
            wordWrap?: WordWrap;
        };
        text?: string | undefined;
        textOverflow?: TextOverflow;
        verticalAlignment?: VerticalEdge;
        wordWrap?: WordWrap;
    };
    set title(value: string | {
        font?: Font;
        horizontalAlignment?: HorizontalAlignment;
        margin?: number | {
            bottom?: number;
            left?: number;
            right?: number;
            top?: number;
        };
        placeholderSize?: number | undefined;
        subtitle?: string | {
            font?: Font;
            offset?: number;
            text?: string | undefined;
            textOverflow?: TextOverflow;
            wordWrap?: WordWrap;
        };
        text?: string | undefined;
        textOverflow?: TextOverflow;
        verticalAlignment?: VerticalEdge;
        wordWrap?: WordWrap;
    });
    /**
     * [descr:dxVectorMapOptions.tooltip]
    
     */
    get tooltip(): {
        arrowLength?: number;
        border?: {
            color?: string;
            dashStyle?: DashStyle;
            opacity?: number | undefined;
            visible?: boolean;
            width?: number;
        };
        color?: string;
        container?: any | string | undefined;
        contentTemplate?: any;
        cornerRadius?: number;
        customizeTooltip?: ((info: MapLayerElement) => Record<string, any>) | undefined;
        enabled?: boolean;
        font?: Font;
        opacity?: number | undefined;
        paddingLeftRight?: number;
        paddingTopBottom?: number;
        shadow?: {
            blur?: number;
            color?: string;
            offsetX?: number;
            offsetY?: number;
            opacity?: number;
        };
        zIndex?: number | undefined;
    };
    set tooltip(value: {
        arrowLength?: number;
        border?: {
            color?: string;
            dashStyle?: DashStyle;
            opacity?: number | undefined;
            visible?: boolean;
            width?: number;
        };
        color?: string;
        container?: any | string | undefined;
        contentTemplate?: any;
        cornerRadius?: number;
        customizeTooltip?: ((info: MapLayerElement) => Record<string, any>) | undefined;
        enabled?: boolean;
        font?: Font;
        opacity?: number | undefined;
        paddingLeftRight?: number;
        paddingTopBottom?: number;
        shadow?: {
            blur?: number;
            color?: string;
            offsetX?: number;
            offsetY?: number;
            opacity?: number;
        };
        zIndex?: number | undefined;
    });
    /**
     * [descr:dxVectorMapOptions.touchEnabled]
    
     */
    get touchEnabled(): boolean;
    set touchEnabled(value: boolean);
    /**
     * [descr:dxVectorMapOptions.wheelEnabled]
    
     */
    get wheelEnabled(): boolean;
    set wheelEnabled(value: boolean);
    /**
     * [descr:dxVectorMapOptions.zoomFactor]
    
     */
    get zoomFactor(): number;
    set zoomFactor(value: number);
    /**
     * [descr:dxVectorMapOptions.zoomingEnabled]
    
     */
    get zoomingEnabled(): boolean;
    set zoomingEnabled(value: boolean);
    /**
    
     * [descr:dxVectorMapOptions.onCenterChanged]
    
    
     */
    onCenterChanged: EventEmitter<CenterChangedEvent>;
    /**
    
     * [descr:dxVectorMapOptions.onClick]
    
    
     */
    onClick: EventEmitter<ClickEvent>;
    /**
    
     * [descr:dxVectorMapOptions.onDisposing]
    
    
     */
    onDisposing: EventEmitter<DisposingEvent>;
    /**
    
     * [descr:dxVectorMapOptions.onDrawn]
    
    
     */
    onDrawn: EventEmitter<DrawnEvent>;
    /**
    
     * [descr:dxVectorMapOptions.onExported]
    
    
     */
    onExported: EventEmitter<ExportedEvent>;
    /**
    
     * [descr:dxVectorMapOptions.onExporting]
    
    
     */
    onExporting: EventEmitter<ExportingEvent>;
    /**
    
     * [descr:dxVectorMapOptions.onFileSaving]
    
    
     */
    onFileSaving: EventEmitter<FileSavingEvent>;
    /**
    
     * [descr:dxVectorMapOptions.onIncidentOccurred]
    
    
     */
    onIncidentOccurred: EventEmitter<IncidentOccurredEvent>;
    /**
    
     * [descr:dxVectorMapOptions.onInitialized]
    
    
     */
    onInitialized: EventEmitter<InitializedEvent>;
    /**
    
     * [descr:dxVectorMapOptions.onOptionChanged]
    
    
     */
    onOptionChanged: EventEmitter<OptionChangedEvent>;
    /**
    
     * [descr:dxVectorMapOptions.onSelectionChanged]
    
    
     */
    onSelectionChanged: EventEmitter<SelectionChangedEvent>;
    /**
    
     * [descr:dxVectorMapOptions.onTooltipHidden]
    
    
     */
    onTooltipHidden: EventEmitter<TooltipHiddenEvent>;
    /**
    
     * [descr:dxVectorMapOptions.onTooltipShown]
    
    
     */
    onTooltipShown: EventEmitter<TooltipShownEvent>;
    /**
    
     * [descr:dxVectorMapOptions.onZoomFactorChanged]
    
    
     */
    onZoomFactorChanged: EventEmitter<ZoomFactorChangedEvent>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    annotationsChange: EventEmitter<Array<any | dxVectorMapAnnotationConfig>>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    backgroundChange: EventEmitter<{
        borderColor?: string;
        color?: string;
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    boundsChange: EventEmitter<Array<number> | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    centerChange: EventEmitter<Array<number>>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    commonAnnotationSettingsChange: EventEmitter<dxVectorMapCommonAnnotationConfig>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    controlBarChange: EventEmitter<{
        borderColor?: string;
        color?: string;
        enabled?: boolean;
        horizontalAlignment?: HorizontalAlignment;
        margin?: number;
        opacity?: number;
        panVisible?: boolean;
        verticalAlignment?: VerticalEdge;
        zoomVisible?: boolean;
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    customizeAnnotationChange: EventEmitter<((annotation: dxVectorMapAnnotationConfig | any) => dxVectorMapAnnotationConfig) | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    disabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    elementAttrChange: EventEmitter<Record<string, any>>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    encodeHtmlChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    exportChange: EventEmitter<{
        backgroundColor?: string;
        enabled?: boolean;
        fileName?: string;
        formats?: Array<ExportFormat>;
        margin?: number;
        printingEnabled?: boolean;
        svgToCanvas?: ((svg: any, canvas: any) => any) | undefined;
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    layersChange: EventEmitter<{
        borderColor?: string;
        borderWidth?: number;
        color?: string;
        colorGroupingField?: string | undefined;
        colorGroups?: Array<number> | undefined;
        customize?: ((elements: Array<MapLayerElement>) => void);
        dataField?: string | undefined;
        dataSource?: Array<any> | DataSource | DataSourceOptions | null | Record<string, any> | Store | string;
        elementType?: VectorMapMarkerType;
        hoveredBorderColor?: string;
        hoveredBorderWidth?: number;
        hoveredColor?: string;
        hoverEnabled?: boolean;
        label?: {
            dataField?: string;
            enabled?: boolean;
            font?: Font;
        };
        maxSize?: number;
        minSize?: number;
        name?: string;
        opacity?: number;
        palette?: Array<string> | Palette;
        paletteIndex?: number;
        paletteSize?: number;
        selectedBorderColor?: string;
        selectedBorderWidth?: number;
        selectedColor?: string;
        selectionMode?: SingleMultipleOrNone;
        size?: number;
        sizeGroupingField?: string | undefined;
        sizeGroups?: Array<number> | undefined;
        type?: VectorMapLayerType;
    }[]>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    legendsChange: EventEmitter<{
        backgroundColor?: string | undefined;
        border?: {
            color?: string;
            cornerRadius?: number;
            dashStyle?: DashStyle;
            opacity?: number | undefined;
            visible?: boolean;
            width?: number;
        };
        columnCount?: number;
        columnItemSpacing?: number;
        customizeHint?: ((itemInfo: {
            color: string;
            end: number;
            index: number;
            size: number;
            start: number;
        }) => string);
        customizeItems?: ((items: Array<VectorMapLegendItem>) => Array<VectorMapLegendItem>);
        customizeText?: ((itemInfo: {
            color: string;
            end: number;
            index: number;
            size: number;
            start: number;
        }) => string);
        font?: Font;
        horizontalAlignment?: HorizontalAlignment;
        itemsAlignment?: HorizontalAlignment | undefined;
        itemTextPosition?: Position | undefined;
        margin?: number | {
            bottom?: number;
            left?: number;
            right?: number;
            top?: number;
        };
        markerColor?: string | undefined;
        markerShape?: VectorMapMarkerShape;
        markerSize?: number;
        markerTemplate?: any;
        orientation?: Orientation | undefined;
        paddingLeftRight?: number;
        paddingTopBottom?: number;
        rowCount?: number;
        rowItemSpacing?: number;
        source?: {
            grouping?: string;
            layer?: string;
        };
        title?: string | {
            font?: Font;
            horizontalAlignment?: HorizontalAlignment | undefined;
            margin?: {
                bottom?: number;
                left?: number;
                right?: number;
                top?: number;
            };
            placeholderSize?: number | undefined;
            subtitle?: string | {
                font?: Font;
                offset?: number;
                text?: string | undefined;
            };
            text?: string | undefined;
            verticalAlignment?: VerticalEdge;
        };
        verticalAlignment?: VerticalEdge;
        visible?: boolean;
    }[]>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    loadingIndicatorChange: EventEmitter<{
        backgroundColor?: string;
        enabled?: boolean;
        font?: Font;
        show?: boolean;
        text?: string;
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    maxZoomFactorChange: EventEmitter<number>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    panningEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    pathModifiedChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    projectionChange: EventEmitter<Record<string, any> | string | VectorMapProjection | VectorMapProjectionConfig>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    redrawOnResizeChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    rtlEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    sizeChange: EventEmitter<{
        height?: number | undefined;
        width?: number | undefined;
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    themeChange: EventEmitter<Theme>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    titleChange: EventEmitter<string | {
        font?: Font;
        horizontalAlignment?: HorizontalAlignment;
        margin?: number | {
            bottom?: number;
            left?: number;
            right?: number;
            top?: number;
        };
        placeholderSize?: number | undefined;
        subtitle?: string | {
            font?: Font;
            offset?: number;
            text?: string | undefined;
            textOverflow?: TextOverflow;
            wordWrap?: WordWrap;
        };
        text?: string | undefined;
        textOverflow?: TextOverflow;
        verticalAlignment?: VerticalEdge;
        wordWrap?: WordWrap;
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    tooltipChange: EventEmitter<{
        arrowLength?: number;
        border?: {
            color?: string;
            dashStyle?: DashStyle;
            opacity?: number | undefined;
            visible?: boolean;
            width?: number;
        };
        color?: string;
        container?: any | string | undefined;
        contentTemplate?: any;
        cornerRadius?: number;
        customizeTooltip?: ((info: MapLayerElement) => Record<string, any>) | undefined;
        enabled?: boolean;
        font?: Font;
        opacity?: number | undefined;
        paddingLeftRight?: number;
        paddingTopBottom?: number;
        shadow?: {
            blur?: number;
            color?: string;
            offsetX?: number;
            offsetY?: number;
            opacity?: number;
        };
        zIndex?: number | undefined;
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    touchEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    wheelEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    zoomFactorChange: EventEmitter<number>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    zoomingEnabledChange: EventEmitter<boolean>;
    constructor(elementRef: ElementRef, ngZone: NgZone, templateHost: DxTemplateHost, _watcherHelper: WatcherHelper, _idh: IterableDifferHelper, optionHost: NestedOptionHost, transferState: TransferState, platformId: any);
    protected _createInstance(element: any, options: any): DxVectorMap;
    ngOnDestroy(): void;
    ngOnChanges(changes: SimpleChanges): void;
    setupChanges(prop: string, changes: SimpleChanges): void;
    ngDoCheck(): void;
    _setOption(name: string, value: any): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxVectorMapComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxVectorMapComponent, "dx-vector-map", never, { "annotations": { "alias": "annotations"; "required": false; }; "background": { "alias": "background"; "required": false; }; "bounds": { "alias": "bounds"; "required": false; }; "center": { "alias": "center"; "required": false; }; "commonAnnotationSettings": { "alias": "commonAnnotationSettings"; "required": false; }; "controlBar": { "alias": "controlBar"; "required": false; }; "customizeAnnotation": { "alias": "customizeAnnotation"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "elementAttr": { "alias": "elementAttr"; "required": false; }; "encodeHtml": { "alias": "encodeHtml"; "required": false; }; "export": { "alias": "export"; "required": false; }; "layers": { "alias": "layers"; "required": false; }; "legends": { "alias": "legends"; "required": false; }; "loadingIndicator": { "alias": "loadingIndicator"; "required": false; }; "maxZoomFactor": { "alias": "maxZoomFactor"; "required": false; }; "panningEnabled": { "alias": "panningEnabled"; "required": false; }; "pathModified": { "alias": "pathModified"; "required": false; }; "projection": { "alias": "projection"; "required": false; }; "redrawOnResize": { "alias": "redrawOnResize"; "required": false; }; "rtlEnabled": { "alias": "rtlEnabled"; "required": false; }; "size": { "alias": "size"; "required": false; }; "theme": { "alias": "theme"; "required": false; }; "title": { "alias": "title"; "required": false; }; "tooltip": { "alias": "tooltip"; "required": false; }; "touchEnabled": { "alias": "touchEnabled"; "required": false; }; "wheelEnabled": { "alias": "wheelEnabled"; "required": false; }; "zoomFactor": { "alias": "zoomFactor"; "required": false; }; "zoomingEnabled": { "alias": "zoomingEnabled"; "required": false; }; }, { "onCenterChanged": "onCenterChanged"; "onClick": "onClick"; "onDisposing": "onDisposing"; "onDrawn": "onDrawn"; "onExported": "onExported"; "onExporting": "onExporting"; "onFileSaving": "onFileSaving"; "onIncidentOccurred": "onIncidentOccurred"; "onInitialized": "onInitialized"; "onOptionChanged": "onOptionChanged"; "onSelectionChanged": "onSelectionChanged"; "onTooltipHidden": "onTooltipHidden"; "onTooltipShown": "onTooltipShown"; "onZoomFactorChanged": "onZoomFactorChanged"; "annotationsChange": "annotationsChange"; "backgroundChange": "backgroundChange"; "boundsChange": "boundsChange"; "centerChange": "centerChange"; "commonAnnotationSettingsChange": "commonAnnotationSettingsChange"; "controlBarChange": "controlBarChange"; "customizeAnnotationChange": "customizeAnnotationChange"; "disabledChange": "disabledChange"; "elementAttrChange": "elementAttrChange"; "encodeHtmlChange": "encodeHtmlChange"; "exportChange": "exportChange"; "layersChange": "layersChange"; "legendsChange": "legendsChange"; "loadingIndicatorChange": "loadingIndicatorChange"; "maxZoomFactorChange": "maxZoomFactorChange"; "panningEnabledChange": "panningEnabledChange"; "pathModifiedChange": "pathModifiedChange"; "projectionChange": "projectionChange"; "redrawOnResizeChange": "redrawOnResizeChange"; "rtlEnabledChange": "rtlEnabledChange"; "sizeChange": "sizeChange"; "themeChange": "themeChange"; "titleChange": "titleChange"; "tooltipChange": "tooltipChange"; "touchEnabledChange": "touchEnabledChange"; "wheelEnabledChange": "wheelEnabledChange"; "zoomFactorChange": "zoomFactorChange"; "zoomingEnabledChange": "zoomingEnabledChange"; }, ["_annotationsContentChildren", "_layersContentChildren", "_legendsContentChildren"], never, true, never>;
}
declare class DxVectorMapModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxVectorMapModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxVectorMapModule, never, [typeof DxVectorMapComponent, typeof i1.DxiAnnotationModule, typeof i1.DxoBorderModule, typeof i1.DxoFontModule, typeof i1.DxoImageModule, typeof i1.DxoShadowModule, typeof i1.DxoBackgroundModule, typeof i1.DxoCommonAnnotationSettingsModule, typeof i1.DxoControlBarModule, typeof i1.DxoExportModule, typeof i1.DxiLayerModule, typeof i1.DxoLabelModule, typeof i1.DxiLegendModule, typeof i1.DxoMarginModule, typeof i1.DxoSourceModule, typeof i1.DxoTitleModule, typeof i1.DxoSubtitleModule, typeof i1.DxoLoadingIndicatorModule, typeof i1.DxoProjectionModule, typeof i1.DxoSizeModule, typeof i1.DxoTooltipModule, typeof i2.DxiVectorMapAnnotationModule, typeof i2.DxoVectorMapAnnotationBorderModule, typeof i2.DxoVectorMapBackgroundModule, typeof i2.DxoVectorMapBorderModule, typeof i2.DxoVectorMapCommonAnnotationSettingsModule, typeof i2.DxoVectorMapControlBarModule, typeof i2.DxoVectorMapExportModule, typeof i2.DxoVectorMapFontModule, typeof i2.DxoVectorMapImageModule, typeof i2.DxoVectorMapLabelModule, typeof i2.DxiVectorMapLayerModule, typeof i2.DxiVectorMapLegendModule, typeof i2.DxoVectorMapLegendTitleModule, typeof i2.DxoVectorMapLegendTitleSubtitleModule, typeof i2.DxoVectorMapLoadingIndicatorModule, typeof i2.DxoVectorMapMarginModule, typeof i2.DxoVectorMapProjectionModule, typeof i2.DxoVectorMapShadowModule, typeof i2.DxoVectorMapSizeModule, typeof i2.DxoVectorMapSourceModule, typeof i2.DxoVectorMapSubtitleModule, typeof i2.DxoVectorMapTitleModule, typeof i2.DxoVectorMapTooltipModule, typeof i2.DxoVectorMapTooltipBorderModule, typeof i2.DxoVectorMapVectorMapTitleModule, typeof i2.DxoVectorMapVectorMapTitleSubtitleModule, typeof i3.DxIntegrationModule, typeof i3.DxTemplateModule], [typeof DxVectorMapComponent, typeof i1.DxiAnnotationModule, typeof i1.DxoBorderModule, typeof i1.DxoFontModule, typeof i1.DxoImageModule, typeof i1.DxoShadowModule, typeof i1.DxoBackgroundModule, typeof i1.DxoCommonAnnotationSettingsModule, typeof i1.DxoControlBarModule, typeof i1.DxoExportModule, typeof i1.DxiLayerModule, typeof i1.DxoLabelModule, typeof i1.DxiLegendModule, typeof i1.DxoMarginModule, typeof i1.DxoSourceModule, typeof i1.DxoTitleModule, typeof i1.DxoSubtitleModule, typeof i1.DxoLoadingIndicatorModule, typeof i1.DxoProjectionModule, typeof i1.DxoSizeModule, typeof i1.DxoTooltipModule, typeof i2.DxiVectorMapAnnotationModule, typeof i2.DxoVectorMapAnnotationBorderModule, typeof i2.DxoVectorMapBackgroundModule, typeof i2.DxoVectorMapBorderModule, typeof i2.DxoVectorMapCommonAnnotationSettingsModule, typeof i2.DxoVectorMapControlBarModule, typeof i2.DxoVectorMapExportModule, typeof i2.DxoVectorMapFontModule, typeof i2.DxoVectorMapImageModule, typeof i2.DxoVectorMapLabelModule, typeof i2.DxiVectorMapLayerModule, typeof i2.DxiVectorMapLegendModule, typeof i2.DxoVectorMapLegendTitleModule, typeof i2.DxoVectorMapLegendTitleSubtitleModule, typeof i2.DxoVectorMapLoadingIndicatorModule, typeof i2.DxoVectorMapMarginModule, typeof i2.DxoVectorMapProjectionModule, typeof i2.DxoVectorMapShadowModule, typeof i2.DxoVectorMapSizeModule, typeof i2.DxoVectorMapSourceModule, typeof i2.DxoVectorMapSubtitleModule, typeof i2.DxoVectorMapTitleModule, typeof i2.DxoVectorMapTooltipModule, typeof i2.DxoVectorMapTooltipBorderModule, typeof i2.DxoVectorMapVectorMapTitleModule, typeof i2.DxoVectorMapVectorMapTitleSubtitleModule, typeof i3.DxTemplateModule]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxVectorMapModule>;
}

export { DxVectorMapComponent, DxVectorMapModule };
//# sourceMappingURL=index.d.ts.map
