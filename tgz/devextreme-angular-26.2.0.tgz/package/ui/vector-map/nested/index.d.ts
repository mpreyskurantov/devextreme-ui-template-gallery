import * as i0 from '@angular/core';
import { OnDestroy, OnInit, AfterViewInit, Renderer2, ElementRef, EventEmitter } from '@angular/core';
import { DashStyle, Font, TextOverflow, AnnotationType, WordWrap, Palette } from 'devextreme/common/charts';
import { NestedOption, NestedOptionHost, CollectionNestedOption, IDxTemplateHost, DxTemplateHost, DxTemplateDirective } from 'devextreme-angular/core';
import { dxVectorMapAnnotationConfig, MapLayerElement, VectorMapMarkerType, VectorMapLayerType, VectorMapLegendItem, VectorMapMarkerShape } from 'devextreme/viz/vector_map';
import { HorizontalAlignment, VerticalEdge, ExportFormat, SingleMultipleOrNone, Position, Orientation } from 'devextreme/common';
import DataSource, { DataSourceOptions } from 'devextreme/data/data_source';
import { Store } from 'devextreme/data/store';

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoVectorMapAnnotationBorderComponent extends NestedOption implements OnDestroy, OnInit {
    get color(): string;
    set color(value: string);
    get cornerRadius(): number;
    set cornerRadius(value: number);
    get dashStyle(): DashStyle;
    set dashStyle(value: DashStyle);
    get opacity(): number | undefined;
    set opacity(value: number | undefined);
    get visible(): boolean;
    set visible(value: boolean);
    get width(): number;
    set width(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoVectorMapAnnotationBorderComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoVectorMapAnnotationBorderComponent, "dxo-vector-map-annotation-border", never, { "color": { "alias": "color"; "required": false; }; "cornerRadius": { "alias": "cornerRadius"; "required": false; }; "dashStyle": { "alias": "dashStyle"; "required": false; }; "opacity": { "alias": "opacity"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoVectorMapAnnotationBorderModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoVectorMapAnnotationBorderModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoVectorMapAnnotationBorderModule, never, [typeof DxoVectorMapAnnotationBorderComponent], [typeof DxoVectorMapAnnotationBorderComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoVectorMapAnnotationBorderModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxiVectorMapAnnotationComponent extends CollectionNestedOption implements AfterViewInit, IDxTemplateHost {
    private renderer;
    private document;
    private element;
    get allowDragging(): boolean;
    set allowDragging(value: boolean);
    get arrowLength(): number;
    set arrowLength(value: number);
    get arrowWidth(): number;
    set arrowWidth(value: number);
    get border(): {
        color?: string;
        cornerRadius?: number;
        dashStyle?: DashStyle;
        opacity?: number | undefined;
        visible?: boolean;
        width?: number;
    };
    set border(value: {
        color?: string;
        cornerRadius?: number;
        dashStyle?: DashStyle;
        opacity?: number | undefined;
        visible?: boolean;
        width?: number;
    });
    get color(): string;
    set color(value: string);
    get coordinates(): Array<number> | undefined;
    set coordinates(value: Array<number> | undefined);
    get customizeTooltip(): ((annotation: dxVectorMapAnnotationConfig | any) => Record<string, any>) | undefined;
    set customizeTooltip(value: ((annotation: dxVectorMapAnnotationConfig | any) => Record<string, any>) | undefined);
    get data(): any;
    set data(value: any);
    get description(): string | undefined;
    set description(value: string | undefined);
    get font(): Font;
    set font(value: Font);
    get height(): number | undefined;
    set height(value: number | undefined);
    get image(): string | {
        height?: number;
        url?: string | undefined;
        width?: number;
    };
    set image(value: string | {
        height?: number;
        url?: string | undefined;
        width?: number;
    });
    get name(): string | undefined;
    set name(value: string | undefined);
    get offsetX(): number | undefined;
    set offsetX(value: number | undefined);
    get offsetY(): number | undefined;
    set offsetY(value: number | undefined);
    get opacity(): number;
    set opacity(value: number);
    get paddingLeftRight(): number;
    set paddingLeftRight(value: number);
    get paddingTopBottom(): number;
    set paddingTopBottom(value: number);
    get shadow(): {
        blur?: number;
        color?: string;
        offsetX?: number;
        offsetY?: number;
        opacity?: number;
    };
    set shadow(value: {
        blur?: number;
        color?: string;
        offsetX?: number;
        offsetY?: number;
        opacity?: number;
    });
    get template(): any;
    set template(value: any);
    get text(): string | undefined;
    set text(value: string | undefined);
    get textOverflow(): TextOverflow;
    set textOverflow(value: TextOverflow);
    get tooltipEnabled(): boolean;
    set tooltipEnabled(value: boolean);
    get tooltipTemplate(): any;
    set tooltipTemplate(value: any);
    get type(): AnnotationType | undefined;
    set type(value: AnnotationType | undefined);
    get width(): number | undefined;
    set width(value: number | undefined);
    get wordWrap(): WordWrap;
    set wordWrap(value: WordWrap);
    get x(): number | undefined;
    set x(value: number | undefined);
    get y(): number | undefined;
    set y(value: number | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost, renderer: Renderer2, document: any, templateHost: DxTemplateHost, element: ElementRef);
    setTemplate(template: DxTemplateDirective): void;
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiVectorMapAnnotationComponent, [{ host: true; skipSelf: true; }, { host: true; }, null, null, { host: true; }, null]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiVectorMapAnnotationComponent, "dxi-vector-map-annotation", never, { "allowDragging": { "alias": "allowDragging"; "required": false; }; "arrowLength": { "alias": "arrowLength"; "required": false; }; "arrowWidth": { "alias": "arrowWidth"; "required": false; }; "border": { "alias": "border"; "required": false; }; "color": { "alias": "color"; "required": false; }; "coordinates": { "alias": "coordinates"; "required": false; }; "customizeTooltip": { "alias": "customizeTooltip"; "required": false; }; "data": { "alias": "data"; "required": false; }; "description": { "alias": "description"; "required": false; }; "font": { "alias": "font"; "required": false; }; "height": { "alias": "height"; "required": false; }; "image": { "alias": "image"; "required": false; }; "name": { "alias": "name"; "required": false; }; "offsetX": { "alias": "offsetX"; "required": false; }; "offsetY": { "alias": "offsetY"; "required": false; }; "opacity": { "alias": "opacity"; "required": false; }; "paddingLeftRight": { "alias": "paddingLeftRight"; "required": false; }; "paddingTopBottom": { "alias": "paddingTopBottom"; "required": false; }; "shadow": { "alias": "shadow"; "required": false; }; "template": { "alias": "template"; "required": false; }; "text": { "alias": "text"; "required": false; }; "textOverflow": { "alias": "textOverflow"; "required": false; }; "tooltipEnabled": { "alias": "tooltipEnabled"; "required": false; }; "tooltipTemplate": { "alias": "tooltipTemplate"; "required": false; }; "type": { "alias": "type"; "required": false; }; "width": { "alias": "width"; "required": false; }; "wordWrap": { "alias": "wordWrap"; "required": false; }; "x": { "alias": "x"; "required": false; }; "y": { "alias": "y"; "required": false; }; }, {}, never, ["*"], true, never>;
}
declare class DxiVectorMapAnnotationModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiVectorMapAnnotationModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiVectorMapAnnotationModule, never, [typeof DxiVectorMapAnnotationComponent], [typeof DxiVectorMapAnnotationComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiVectorMapAnnotationModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoVectorMapBackgroundComponent extends NestedOption implements OnDestroy, OnInit {
    get borderColor(): string;
    set borderColor(value: string);
    get color(): string;
    set color(value: string);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoVectorMapBackgroundComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoVectorMapBackgroundComponent, "dxo-vector-map-background", never, { "borderColor": { "alias": "borderColor"; "required": false; }; "color": { "alias": "color"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoVectorMapBackgroundModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoVectorMapBackgroundModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoVectorMapBackgroundModule, never, [typeof DxoVectorMapBackgroundComponent], [typeof DxoVectorMapBackgroundComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoVectorMapBackgroundModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoVectorMapBorderComponent extends NestedOption implements OnDestroy, OnInit {
    get color(): string;
    set color(value: string);
    get cornerRadius(): number;
    set cornerRadius(value: number);
    get dashStyle(): DashStyle;
    set dashStyle(value: DashStyle);
    get opacity(): number | undefined;
    set opacity(value: number | undefined);
    get visible(): boolean;
    set visible(value: boolean);
    get width(): number;
    set width(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoVectorMapBorderComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoVectorMapBorderComponent, "dxo-vector-map-border", never, { "color": { "alias": "color"; "required": false; }; "cornerRadius": { "alias": "cornerRadius"; "required": false; }; "dashStyle": { "alias": "dashStyle"; "required": false; }; "opacity": { "alias": "opacity"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoVectorMapBorderModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoVectorMapBorderModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoVectorMapBorderModule, never, [typeof DxoVectorMapBorderComponent], [typeof DxoVectorMapBorderComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoVectorMapBorderModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoVectorMapCommonAnnotationSettingsComponent extends NestedOption implements AfterViewInit, OnDestroy, OnInit, IDxTemplateHost {
    private renderer;
    private document;
    private element;
    get allowDragging(): boolean;
    set allowDragging(value: boolean);
    get arrowLength(): number;
    set arrowLength(value: number);
    get arrowWidth(): number;
    set arrowWidth(value: number);
    get border(): {
        color?: string;
        cornerRadius?: number;
        dashStyle?: DashStyle;
        opacity?: number | undefined;
        visible?: boolean;
        width?: number;
    };
    set border(value: {
        color?: string;
        cornerRadius?: number;
        dashStyle?: DashStyle;
        opacity?: number | undefined;
        visible?: boolean;
        width?: number;
    });
    get color(): string;
    set color(value: string);
    get coordinates(): Array<number> | undefined;
    set coordinates(value: Array<number> | undefined);
    get customizeTooltip(): ((annotation: dxVectorMapAnnotationConfig | any) => Record<string, any>) | undefined;
    set customizeTooltip(value: ((annotation: dxVectorMapAnnotationConfig | any) => Record<string, any>) | undefined);
    get data(): any;
    set data(value: any);
    get description(): string | undefined;
    set description(value: string | undefined);
    get font(): Font;
    set font(value: Font);
    get height(): number | undefined;
    set height(value: number | undefined);
    get image(): string | {
        height?: number;
        url?: string | undefined;
        width?: number;
    };
    set image(value: string | {
        height?: number;
        url?: string | undefined;
        width?: number;
    });
    get offsetX(): number | undefined;
    set offsetX(value: number | undefined);
    get offsetY(): number | undefined;
    set offsetY(value: number | undefined);
    get opacity(): number;
    set opacity(value: number);
    get paddingLeftRight(): number;
    set paddingLeftRight(value: number);
    get paddingTopBottom(): number;
    set paddingTopBottom(value: number);
    get shadow(): {
        blur?: number;
        color?: string;
        offsetX?: number;
        offsetY?: number;
        opacity?: number;
    };
    set shadow(value: {
        blur?: number;
        color?: string;
        offsetX?: number;
        offsetY?: number;
        opacity?: number;
    });
    get template(): any;
    set template(value: any);
    get text(): string | undefined;
    set text(value: string | undefined);
    get textOverflow(): TextOverflow;
    set textOverflow(value: TextOverflow);
    get tooltipEnabled(): boolean;
    set tooltipEnabled(value: boolean);
    get tooltipTemplate(): any;
    set tooltipTemplate(value: any);
    get type(): AnnotationType | undefined;
    set type(value: AnnotationType | undefined);
    get width(): number | undefined;
    set width(value: number | undefined);
    get wordWrap(): WordWrap;
    set wordWrap(value: WordWrap);
    get x(): number | undefined;
    set x(value: number | undefined);
    get y(): number | undefined;
    set y(value: number | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost, renderer: Renderer2, document: any, templateHost: DxTemplateHost, element: ElementRef);
    setTemplate(template: DxTemplateDirective): void;
    ngAfterViewInit(): void;
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoVectorMapCommonAnnotationSettingsComponent, [{ host: true; skipSelf: true; }, { host: true; }, null, null, { host: true; }, null]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoVectorMapCommonAnnotationSettingsComponent, "dxo-vector-map-common-annotation-settings", never, { "allowDragging": { "alias": "allowDragging"; "required": false; }; "arrowLength": { "alias": "arrowLength"; "required": false; }; "arrowWidth": { "alias": "arrowWidth"; "required": false; }; "border": { "alias": "border"; "required": false; }; "color": { "alias": "color"; "required": false; }; "coordinates": { "alias": "coordinates"; "required": false; }; "customizeTooltip": { "alias": "customizeTooltip"; "required": false; }; "data": { "alias": "data"; "required": false; }; "description": { "alias": "description"; "required": false; }; "font": { "alias": "font"; "required": false; }; "height": { "alias": "height"; "required": false; }; "image": { "alias": "image"; "required": false; }; "offsetX": { "alias": "offsetX"; "required": false; }; "offsetY": { "alias": "offsetY"; "required": false; }; "opacity": { "alias": "opacity"; "required": false; }; "paddingLeftRight": { "alias": "paddingLeftRight"; "required": false; }; "paddingTopBottom": { "alias": "paddingTopBottom"; "required": false; }; "shadow": { "alias": "shadow"; "required": false; }; "template": { "alias": "template"; "required": false; }; "text": { "alias": "text"; "required": false; }; "textOverflow": { "alias": "textOverflow"; "required": false; }; "tooltipEnabled": { "alias": "tooltipEnabled"; "required": false; }; "tooltipTemplate": { "alias": "tooltipTemplate"; "required": false; }; "type": { "alias": "type"; "required": false; }; "width": { "alias": "width"; "required": false; }; "wordWrap": { "alias": "wordWrap"; "required": false; }; "x": { "alias": "x"; "required": false; }; "y": { "alias": "y"; "required": false; }; }, {}, never, ["*"], true, never>;
}
declare class DxoVectorMapCommonAnnotationSettingsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoVectorMapCommonAnnotationSettingsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoVectorMapCommonAnnotationSettingsModule, never, [typeof DxoVectorMapCommonAnnotationSettingsComponent], [typeof DxoVectorMapCommonAnnotationSettingsComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoVectorMapCommonAnnotationSettingsModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoVectorMapControlBarComponent extends NestedOption implements OnDestroy, OnInit {
    get borderColor(): string;
    set borderColor(value: string);
    get color(): string;
    set color(value: string);
    get enabled(): boolean;
    set enabled(value: boolean);
    get horizontalAlignment(): HorizontalAlignment;
    set horizontalAlignment(value: HorizontalAlignment);
    get margin(): number;
    set margin(value: number);
    get opacity(): number;
    set opacity(value: number);
    get panVisible(): boolean;
    set panVisible(value: boolean);
    get verticalAlignment(): VerticalEdge;
    set verticalAlignment(value: VerticalEdge);
    get zoomVisible(): boolean;
    set zoomVisible(value: boolean);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoVectorMapControlBarComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoVectorMapControlBarComponent, "dxo-vector-map-control-bar", never, { "borderColor": { "alias": "borderColor"; "required": false; }; "color": { "alias": "color"; "required": false; }; "enabled": { "alias": "enabled"; "required": false; }; "horizontalAlignment": { "alias": "horizontalAlignment"; "required": false; }; "margin": { "alias": "margin"; "required": false; }; "opacity": { "alias": "opacity"; "required": false; }; "panVisible": { "alias": "panVisible"; "required": false; }; "verticalAlignment": { "alias": "verticalAlignment"; "required": false; }; "zoomVisible": { "alias": "zoomVisible"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoVectorMapControlBarModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoVectorMapControlBarModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoVectorMapControlBarModule, never, [typeof DxoVectorMapControlBarComponent], [typeof DxoVectorMapControlBarComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoVectorMapControlBarModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoVectorMapExportComponent extends NestedOption implements OnDestroy, OnInit {
    get backgroundColor(): string;
    set backgroundColor(value: string);
    get enabled(): boolean;
    set enabled(value: boolean);
    get fileName(): string;
    set fileName(value: string);
    get formats(): Array<ExportFormat>;
    set formats(value: Array<ExportFormat>);
    get margin(): number;
    set margin(value: number);
    get printingEnabled(): boolean;
    set printingEnabled(value: boolean);
    get svgToCanvas(): ((svg: any, canvas: any) => any) | undefined;
    set svgToCanvas(value: ((svg: any, canvas: any) => any) | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoVectorMapExportComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoVectorMapExportComponent, "dxo-vector-map-export", never, { "backgroundColor": { "alias": "backgroundColor"; "required": false; }; "enabled": { "alias": "enabled"; "required": false; }; "fileName": { "alias": "fileName"; "required": false; }; "formats": { "alias": "formats"; "required": false; }; "margin": { "alias": "margin"; "required": false; }; "printingEnabled": { "alias": "printingEnabled"; "required": false; }; "svgToCanvas": { "alias": "svgToCanvas"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoVectorMapExportModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoVectorMapExportModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoVectorMapExportModule, never, [typeof DxoVectorMapExportComponent], [typeof DxoVectorMapExportComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoVectorMapExportModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoVectorMapFontComponent extends NestedOption implements OnDestroy, OnInit {
    get color(): string;
    set color(value: string);
    get family(): string;
    set family(value: string);
    get opacity(): number;
    set opacity(value: number);
    get size(): number | string;
    set size(value: number | string);
    get weight(): number;
    set weight(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoVectorMapFontComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoVectorMapFontComponent, "dxo-vector-map-font", never, { "color": { "alias": "color"; "required": false; }; "family": { "alias": "family"; "required": false; }; "opacity": { "alias": "opacity"; "required": false; }; "size": { "alias": "size"; "required": false; }; "weight": { "alias": "weight"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoVectorMapFontModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoVectorMapFontModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoVectorMapFontModule, never, [typeof DxoVectorMapFontComponent], [typeof DxoVectorMapFontComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoVectorMapFontModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoVectorMapImageComponent extends NestedOption implements OnDestroy, OnInit {
    get height(): number;
    set height(value: number);
    get url(): string | undefined;
    set url(value: string | undefined);
    get width(): number;
    set width(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoVectorMapImageComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoVectorMapImageComponent, "dxo-vector-map-image", never, { "height": { "alias": "height"; "required": false; }; "url": { "alias": "url"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoVectorMapImageModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoVectorMapImageModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoVectorMapImageModule, never, [typeof DxoVectorMapImageComponent], [typeof DxoVectorMapImageComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoVectorMapImageModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoVectorMapLabelComponent extends NestedOption implements OnDestroy, OnInit {
    get dataField(): string;
    set dataField(value: string);
    get enabled(): boolean;
    set enabled(value: boolean);
    get font(): Font;
    set font(value: Font);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoVectorMapLabelComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoVectorMapLabelComponent, "dxo-vector-map-label", never, { "dataField": { "alias": "dataField"; "required": false; }; "enabled": { "alias": "enabled"; "required": false; }; "font": { "alias": "font"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoVectorMapLabelModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoVectorMapLabelModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoVectorMapLabelModule, never, [typeof DxoVectorMapLabelComponent], [typeof DxoVectorMapLabelComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoVectorMapLabelModule>;
}

declare class DxiVectorMapLayerComponent extends CollectionNestedOption {
    get borderColor(): string;
    set borderColor(value: string);
    get borderWidth(): number;
    set borderWidth(value: number);
    get color(): string;
    set color(value: string);
    get colorGroupingField(): string | undefined;
    set colorGroupingField(value: string | undefined);
    get colorGroups(): Array<number> | undefined;
    set colorGroups(value: Array<number> | undefined);
    get customize(): ((elements: Array<MapLayerElement>) => void);
    set customize(value: ((elements: Array<MapLayerElement>) => void));
    get dataField(): string | undefined;
    set dataField(value: string | undefined);
    get dataSource(): Array<any> | DataSource | DataSourceOptions | null | Record<string, any> | Store | string;
    set dataSource(value: Array<any> | DataSource | DataSourceOptions | null | Record<string, any> | Store | string);
    get elementType(): VectorMapMarkerType;
    set elementType(value: VectorMapMarkerType);
    get hoveredBorderColor(): string;
    set hoveredBorderColor(value: string);
    get hoveredBorderWidth(): number;
    set hoveredBorderWidth(value: number);
    get hoveredColor(): string;
    set hoveredColor(value: string);
    get hoverEnabled(): boolean;
    set hoverEnabled(value: boolean);
    get label(): {
        dataField?: string;
        enabled?: boolean;
        font?: Font;
    };
    set label(value: {
        dataField?: string;
        enabled?: boolean;
        font?: Font;
    });
    get maxSize(): number;
    set maxSize(value: number);
    get minSize(): number;
    set minSize(value: number);
    get name(): string;
    set name(value: string);
    get opacity(): number;
    set opacity(value: number);
    get palette(): Array<string> | Palette;
    set palette(value: Array<string> | Palette);
    get paletteIndex(): number;
    set paletteIndex(value: number);
    get paletteSize(): number;
    set paletteSize(value: number);
    get selectedBorderColor(): string;
    set selectedBorderColor(value: string);
    get selectedBorderWidth(): number;
    set selectedBorderWidth(value: number);
    get selectedColor(): string;
    set selectedColor(value: string);
    get selectionMode(): SingleMultipleOrNone;
    set selectionMode(value: SingleMultipleOrNone);
    get size(): number;
    set size(value: number);
    get sizeGroupingField(): string | undefined;
    set sizeGroupingField(value: string | undefined);
    get sizeGroups(): Array<number> | undefined;
    set sizeGroups(value: Array<number> | undefined);
    get type(): VectorMapLayerType;
    set type(value: VectorMapLayerType);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiVectorMapLayerComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiVectorMapLayerComponent, "dxi-vector-map-layer", never, { "borderColor": { "alias": "borderColor"; "required": false; }; "borderWidth": { "alias": "borderWidth"; "required": false; }; "color": { "alias": "color"; "required": false; }; "colorGroupingField": { "alias": "colorGroupingField"; "required": false; }; "colorGroups": { "alias": "colorGroups"; "required": false; }; "customize": { "alias": "customize"; "required": false; }; "dataField": { "alias": "dataField"; "required": false; }; "dataSource": { "alias": "dataSource"; "required": false; }; "elementType": { "alias": "elementType"; "required": false; }; "hoveredBorderColor": { "alias": "hoveredBorderColor"; "required": false; }; "hoveredBorderWidth": { "alias": "hoveredBorderWidth"; "required": false; }; "hoveredColor": { "alias": "hoveredColor"; "required": false; }; "hoverEnabled": { "alias": "hoverEnabled"; "required": false; }; "label": { "alias": "label"; "required": false; }; "maxSize": { "alias": "maxSize"; "required": false; }; "minSize": { "alias": "minSize"; "required": false; }; "name": { "alias": "name"; "required": false; }; "opacity": { "alias": "opacity"; "required": false; }; "palette": { "alias": "palette"; "required": false; }; "paletteIndex": { "alias": "paletteIndex"; "required": false; }; "paletteSize": { "alias": "paletteSize"; "required": false; }; "selectedBorderColor": { "alias": "selectedBorderColor"; "required": false; }; "selectedBorderWidth": { "alias": "selectedBorderWidth"; "required": false; }; "selectedColor": { "alias": "selectedColor"; "required": false; }; "selectionMode": { "alias": "selectionMode"; "required": false; }; "size": { "alias": "size"; "required": false; }; "sizeGroupingField": { "alias": "sizeGroupingField"; "required": false; }; "sizeGroups": { "alias": "sizeGroups"; "required": false; }; "type": { "alias": "type"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxiVectorMapLayerModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiVectorMapLayerModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiVectorMapLayerModule, never, [typeof DxiVectorMapLayerComponent], [typeof DxiVectorMapLayerComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiVectorMapLayerModule>;
}

declare class DxiVectorMapLegendComponent extends CollectionNestedOption {
    get backgroundColor(): string | undefined;
    set backgroundColor(value: string | undefined);
    get border(): {
        color?: string;
        cornerRadius?: number;
        dashStyle?: DashStyle;
        opacity?: number | undefined;
        visible?: boolean;
        width?: number;
    };
    set border(value: {
        color?: string;
        cornerRadius?: number;
        dashStyle?: DashStyle;
        opacity?: number | undefined;
        visible?: boolean;
        width?: number;
    });
    get columnCount(): number;
    set columnCount(value: number);
    get columnItemSpacing(): number;
    set columnItemSpacing(value: number);
    get customizeHint(): ((itemInfo: {
        color: string;
        end: number;
        index: number;
        size: number;
        start: number;
    }) => string);
    set customizeHint(value: ((itemInfo: {
        color: string;
        end: number;
        index: number;
        size: number;
        start: number;
    }) => string));
    get customizeItems(): ((items: Array<VectorMapLegendItem>) => Array<VectorMapLegendItem>);
    set customizeItems(value: ((items: Array<VectorMapLegendItem>) => Array<VectorMapLegendItem>));
    get customizeText(): ((itemInfo: {
        color: string;
        end: number;
        index: number;
        size: number;
        start: number;
    }) => string);
    set customizeText(value: ((itemInfo: {
        color: string;
        end: number;
        index: number;
        size: number;
        start: number;
    }) => string));
    get font(): Font;
    set font(value: Font);
    get horizontalAlignment(): HorizontalAlignment;
    set horizontalAlignment(value: HorizontalAlignment);
    get itemsAlignment(): HorizontalAlignment | undefined;
    set itemsAlignment(value: HorizontalAlignment | undefined);
    get itemTextPosition(): Position | undefined;
    set itemTextPosition(value: Position | undefined);
    get margin(): number | {
        bottom?: number;
        left?: number;
        right?: number;
        top?: number;
    };
    set margin(value: number | {
        bottom?: number;
        left?: number;
        right?: number;
        top?: number;
    });
    get markerColor(): string | undefined;
    set markerColor(value: string | undefined);
    get markerShape(): VectorMapMarkerShape;
    set markerShape(value: VectorMapMarkerShape);
    get markerSize(): number;
    set markerSize(value: number);
    get markerTemplate(): any;
    set markerTemplate(value: any);
    get orientation(): Orientation | undefined;
    set orientation(value: Orientation | undefined);
    get paddingLeftRight(): number;
    set paddingLeftRight(value: number);
    get paddingTopBottom(): number;
    set paddingTopBottom(value: number);
    get rowCount(): number;
    set rowCount(value: number);
    get rowItemSpacing(): number;
    set rowItemSpacing(value: number);
    get source(): {
        grouping?: string;
        layer?: string;
    };
    set source(value: {
        grouping?: string;
        layer?: string;
    });
    get title(): string | {
        font?: Font;
        horizontalAlignment?: HorizontalAlignment | undefined;
        margin?: {
            bottom?: number;
            left?: number;
            right?: number;
            top?: number;
        };
        placeholderSize?: number | undefined;
        subtitle?: string | {
            font?: Font;
            offset?: number;
            text?: string | undefined;
        };
        text?: string | undefined;
        verticalAlignment?: VerticalEdge;
    };
    set title(value: string | {
        font?: Font;
        horizontalAlignment?: HorizontalAlignment | undefined;
        margin?: {
            bottom?: number;
            left?: number;
            right?: number;
            top?: number;
        };
        placeholderSize?: number | undefined;
        subtitle?: string | {
            font?: Font;
            offset?: number;
            text?: string | undefined;
        };
        text?: string | undefined;
        verticalAlignment?: VerticalEdge;
    });
    get verticalAlignment(): VerticalEdge;
    set verticalAlignment(value: VerticalEdge);
    get visible(): boolean;
    set visible(value: boolean);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiVectorMapLegendComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiVectorMapLegendComponent, "dxi-vector-map-legend", never, { "backgroundColor": { "alias": "backgroundColor"; "required": false; }; "border": { "alias": "border"; "required": false; }; "columnCount": { "alias": "columnCount"; "required": false; }; "columnItemSpacing": { "alias": "columnItemSpacing"; "required": false; }; "customizeHint": { "alias": "customizeHint"; "required": false; }; "customizeItems": { "alias": "customizeItems"; "required": false; }; "customizeText": { "alias": "customizeText"; "required": false; }; "font": { "alias": "font"; "required": false; }; "horizontalAlignment": { "alias": "horizontalAlignment"; "required": false; }; "itemsAlignment": { "alias": "itemsAlignment"; "required": false; }; "itemTextPosition": { "alias": "itemTextPosition"; "required": false; }; "margin": { "alias": "margin"; "required": false; }; "markerColor": { "alias": "markerColor"; "required": false; }; "markerShape": { "alias": "markerShape"; "required": false; }; "markerSize": { "alias": "markerSize"; "required": false; }; "markerTemplate": { "alias": "markerTemplate"; "required": false; }; "orientation": { "alias": "orientation"; "required": false; }; "paddingLeftRight": { "alias": "paddingLeftRight"; "required": false; }; "paddingTopBottom": { "alias": "paddingTopBottom"; "required": false; }; "rowCount": { "alias": "rowCount"; "required": false; }; "rowItemSpacing": { "alias": "rowItemSpacing"; "required": false; }; "source": { "alias": "source"; "required": false; }; "title": { "alias": "title"; "required": false; }; "verticalAlignment": { "alias": "verticalAlignment"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxiVectorMapLegendModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiVectorMapLegendModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiVectorMapLegendModule, never, [typeof DxiVectorMapLegendComponent], [typeof DxiVectorMapLegendComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiVectorMapLegendModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoVectorMapLegendTitleSubtitleComponent extends NestedOption implements OnDestroy, OnInit {
    get font(): Font;
    set font(value: Font);
    get offset(): number;
    set offset(value: number);
    get text(): string | undefined;
    set text(value: string | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoVectorMapLegendTitleSubtitleComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoVectorMapLegendTitleSubtitleComponent, "dxo-vector-map-legend-title-subtitle", never, { "font": { "alias": "font"; "required": false; }; "offset": { "alias": "offset"; "required": false; }; "text": { "alias": "text"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoVectorMapLegendTitleSubtitleModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoVectorMapLegendTitleSubtitleModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoVectorMapLegendTitleSubtitleModule, never, [typeof DxoVectorMapLegendTitleSubtitleComponent], [typeof DxoVectorMapLegendTitleSubtitleComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoVectorMapLegendTitleSubtitleModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoVectorMapLegendTitleComponent extends NestedOption implements OnDestroy, OnInit {
    get font(): Font;
    set font(value: Font);
    get horizontalAlignment(): HorizontalAlignment | undefined;
    set horizontalAlignment(value: HorizontalAlignment | undefined);
    get margin(): {
        bottom?: number;
        left?: number;
        right?: number;
        top?: number;
    };
    set margin(value: {
        bottom?: number;
        left?: number;
        right?: number;
        top?: number;
    });
    get placeholderSize(): number | undefined;
    set placeholderSize(value: number | undefined);
    get subtitle(): string | {
        font?: Font;
        offset?: number;
        text?: string | undefined;
    };
    set subtitle(value: string | {
        font?: Font;
        offset?: number;
        text?: string | undefined;
    });
    get text(): string | undefined;
    set text(value: string | undefined);
    get verticalAlignment(): VerticalEdge;
    set verticalAlignment(value: VerticalEdge);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoVectorMapLegendTitleComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoVectorMapLegendTitleComponent, "dxo-vector-map-legend-title", never, { "font": { "alias": "font"; "required": false; }; "horizontalAlignment": { "alias": "horizontalAlignment"; "required": false; }; "margin": { "alias": "margin"; "required": false; }; "placeholderSize": { "alias": "placeholderSize"; "required": false; }; "subtitle": { "alias": "subtitle"; "required": false; }; "text": { "alias": "text"; "required": false; }; "verticalAlignment": { "alias": "verticalAlignment"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoVectorMapLegendTitleModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoVectorMapLegendTitleModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoVectorMapLegendTitleModule, never, [typeof DxoVectorMapLegendTitleComponent], [typeof DxoVectorMapLegendTitleComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoVectorMapLegendTitleModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoVectorMapLoadingIndicatorComponent extends NestedOption implements OnDestroy, OnInit {
    get backgroundColor(): string;
    set backgroundColor(value: string);
    get enabled(): boolean;
    set enabled(value: boolean);
    get font(): Font;
    set font(value: Font);
    get show(): boolean;
    set show(value: boolean);
    get text(): string;
    set text(value: string);
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    showChange: EventEmitter<boolean>;
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoVectorMapLoadingIndicatorComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoVectorMapLoadingIndicatorComponent, "dxo-vector-map-loading-indicator", never, { "backgroundColor": { "alias": "backgroundColor"; "required": false; }; "enabled": { "alias": "enabled"; "required": false; }; "font": { "alias": "font"; "required": false; }; "show": { "alias": "show"; "required": false; }; "text": { "alias": "text"; "required": false; }; }, { "showChange": "showChange"; }, never, never, true, never>;
}
declare class DxoVectorMapLoadingIndicatorModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoVectorMapLoadingIndicatorModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoVectorMapLoadingIndicatorModule, never, [typeof DxoVectorMapLoadingIndicatorComponent], [typeof DxoVectorMapLoadingIndicatorComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoVectorMapLoadingIndicatorModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoVectorMapMarginComponent extends NestedOption implements OnDestroy, OnInit {
    get bottom(): number;
    set bottom(value: number);
    get left(): number;
    set left(value: number);
    get right(): number;
    set right(value: number);
    get top(): number;
    set top(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoVectorMapMarginComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoVectorMapMarginComponent, "dxo-vector-map-margin", never, { "bottom": { "alias": "bottom"; "required": false; }; "left": { "alias": "left"; "required": false; }; "right": { "alias": "right"; "required": false; }; "top": { "alias": "top"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoVectorMapMarginModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoVectorMapMarginModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoVectorMapMarginModule, never, [typeof DxoVectorMapMarginComponent], [typeof DxoVectorMapMarginComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoVectorMapMarginModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoVectorMapProjectionComponent extends NestedOption implements OnDestroy, OnInit {
    get aspectRatio(): number;
    set aspectRatio(value: number);
    get from(): ((coordinates: Array<number>) => Array<number>);
    set from(value: ((coordinates: Array<number>) => Array<number>));
    get to(): ((coordinates: Array<number>) => Array<number>);
    set to(value: ((coordinates: Array<number>) => Array<number>));
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoVectorMapProjectionComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoVectorMapProjectionComponent, "dxo-vector-map-projection", never, { "aspectRatio": { "alias": "aspectRatio"; "required": false; }; "from": { "alias": "from"; "required": false; }; "to": { "alias": "to"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoVectorMapProjectionModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoVectorMapProjectionModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoVectorMapProjectionModule, never, [typeof DxoVectorMapProjectionComponent], [typeof DxoVectorMapProjectionComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoVectorMapProjectionModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoVectorMapShadowComponent extends NestedOption implements OnDestroy, OnInit {
    get blur(): number;
    set blur(value: number);
    get color(): string;
    set color(value: string);
    get offsetX(): number;
    set offsetX(value: number);
    get offsetY(): number;
    set offsetY(value: number);
    get opacity(): number;
    set opacity(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoVectorMapShadowComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoVectorMapShadowComponent, "dxo-vector-map-shadow", never, { "blur": { "alias": "blur"; "required": false; }; "color": { "alias": "color"; "required": false; }; "offsetX": { "alias": "offsetX"; "required": false; }; "offsetY": { "alias": "offsetY"; "required": false; }; "opacity": { "alias": "opacity"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoVectorMapShadowModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoVectorMapShadowModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoVectorMapShadowModule, never, [typeof DxoVectorMapShadowComponent], [typeof DxoVectorMapShadowComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoVectorMapShadowModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoVectorMapSizeComponent extends NestedOption implements OnDestroy, OnInit {
    get height(): number | undefined;
    set height(value: number | undefined);
    get width(): number | undefined;
    set width(value: number | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoVectorMapSizeComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoVectorMapSizeComponent, "dxo-vector-map-size", never, { "height": { "alias": "height"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoVectorMapSizeModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoVectorMapSizeModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoVectorMapSizeModule, never, [typeof DxoVectorMapSizeComponent], [typeof DxoVectorMapSizeComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoVectorMapSizeModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoVectorMapSourceComponent extends NestedOption implements OnDestroy, OnInit {
    get grouping(): string;
    set grouping(value: string);
    get layer(): string;
    set layer(value: string);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoVectorMapSourceComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoVectorMapSourceComponent, "dxo-vector-map-source", never, { "grouping": { "alias": "grouping"; "required": false; }; "layer": { "alias": "layer"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoVectorMapSourceModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoVectorMapSourceModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoVectorMapSourceModule, never, [typeof DxoVectorMapSourceComponent], [typeof DxoVectorMapSourceComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoVectorMapSourceModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoVectorMapSubtitleComponent extends NestedOption implements OnDestroy, OnInit {
    get font(): Font;
    set font(value: Font);
    get offset(): number;
    set offset(value: number);
    get text(): string | undefined;
    set text(value: string | undefined);
    get textOverflow(): TextOverflow;
    set textOverflow(value: TextOverflow);
    get wordWrap(): WordWrap;
    set wordWrap(value: WordWrap);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoVectorMapSubtitleComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoVectorMapSubtitleComponent, "dxo-vector-map-subtitle", never, { "font": { "alias": "font"; "required": false; }; "offset": { "alias": "offset"; "required": false; }; "text": { "alias": "text"; "required": false; }; "textOverflow": { "alias": "textOverflow"; "required": false; }; "wordWrap": { "alias": "wordWrap"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoVectorMapSubtitleModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoVectorMapSubtitleModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoVectorMapSubtitleModule, never, [typeof DxoVectorMapSubtitleComponent], [typeof DxoVectorMapSubtitleComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoVectorMapSubtitleModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoVectorMapTitleComponent extends NestedOption implements OnDestroy, OnInit {
    get font(): Font;
    set font(value: Font);
    get horizontalAlignment(): HorizontalAlignment | undefined;
    set horizontalAlignment(value: HorizontalAlignment | undefined);
    get margin(): number | {
        bottom?: number;
        left?: number;
        right?: number;
        top?: number;
    };
    set margin(value: number | {
        bottom?: number;
        left?: number;
        right?: number;
        top?: number;
    });
    get placeholderSize(): number | undefined;
    set placeholderSize(value: number | undefined);
    get subtitle(): string | {
        font?: Font;
        offset?: number;
        text?: string | undefined;
        textOverflow?: TextOverflow;
        wordWrap?: WordWrap;
    };
    set subtitle(value: string | {
        font?: Font;
        offset?: number;
        text?: string | undefined;
        textOverflow?: TextOverflow;
        wordWrap?: WordWrap;
    });
    get text(): string | undefined;
    set text(value: string | undefined);
    get verticalAlignment(): VerticalEdge;
    set verticalAlignment(value: VerticalEdge);
    get textOverflow(): TextOverflow;
    set textOverflow(value: TextOverflow);
    get wordWrap(): WordWrap;
    set wordWrap(value: WordWrap);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoVectorMapTitleComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoVectorMapTitleComponent, "dxo-vector-map-title", never, { "font": { "alias": "font"; "required": false; }; "horizontalAlignment": { "alias": "horizontalAlignment"; "required": false; }; "margin": { "alias": "margin"; "required": false; }; "placeholderSize": { "alias": "placeholderSize"; "required": false; }; "subtitle": { "alias": "subtitle"; "required": false; }; "text": { "alias": "text"; "required": false; }; "verticalAlignment": { "alias": "verticalAlignment"; "required": false; }; "textOverflow": { "alias": "textOverflow"; "required": false; }; "wordWrap": { "alias": "wordWrap"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoVectorMapTitleModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoVectorMapTitleModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoVectorMapTitleModule, never, [typeof DxoVectorMapTitleComponent], [typeof DxoVectorMapTitleComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoVectorMapTitleModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoVectorMapTooltipBorderComponent extends NestedOption implements OnDestroy, OnInit {
    get color(): string;
    set color(value: string);
    get dashStyle(): DashStyle;
    set dashStyle(value: DashStyle);
    get opacity(): number | undefined;
    set opacity(value: number | undefined);
    get visible(): boolean;
    set visible(value: boolean);
    get width(): number;
    set width(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoVectorMapTooltipBorderComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoVectorMapTooltipBorderComponent, "dxo-vector-map-tooltip-border", never, { "color": { "alias": "color"; "required": false; }; "dashStyle": { "alias": "dashStyle"; "required": false; }; "opacity": { "alias": "opacity"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoVectorMapTooltipBorderModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoVectorMapTooltipBorderModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoVectorMapTooltipBorderModule, never, [typeof DxoVectorMapTooltipBorderComponent], [typeof DxoVectorMapTooltipBorderComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoVectorMapTooltipBorderModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoVectorMapTooltipComponent extends NestedOption implements OnDestroy, OnInit {
    get arrowLength(): number;
    set arrowLength(value: number);
    get border(): {
        color?: string;
        dashStyle?: DashStyle;
        opacity?: number | undefined;
        visible?: boolean;
        width?: number;
    };
    set border(value: {
        color?: string;
        dashStyle?: DashStyle;
        opacity?: number | undefined;
        visible?: boolean;
        width?: number;
    });
    get color(): string;
    set color(value: string);
    get container(): any | string | undefined;
    set container(value: any | string | undefined);
    get contentTemplate(): any;
    set contentTemplate(value: any);
    get cornerRadius(): number;
    set cornerRadius(value: number);
    get customizeTooltip(): ((info: MapLayerElement) => Record<string, any>) | undefined;
    set customizeTooltip(value: ((info: MapLayerElement) => Record<string, any>) | undefined);
    get enabled(): boolean;
    set enabled(value: boolean);
    get font(): Font;
    set font(value: Font);
    get opacity(): number | undefined;
    set opacity(value: number | undefined);
    get paddingLeftRight(): number;
    set paddingLeftRight(value: number);
    get paddingTopBottom(): number;
    set paddingTopBottom(value: number);
    get shadow(): {
        blur?: number;
        color?: string;
        offsetX?: number;
        offsetY?: number;
        opacity?: number;
    };
    set shadow(value: {
        blur?: number;
        color?: string;
        offsetX?: number;
        offsetY?: number;
        opacity?: number;
    });
    get zIndex(): number | undefined;
    set zIndex(value: number | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoVectorMapTooltipComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoVectorMapTooltipComponent, "dxo-vector-map-tooltip", never, { "arrowLength": { "alias": "arrowLength"; "required": false; }; "border": { "alias": "border"; "required": false; }; "color": { "alias": "color"; "required": false; }; "container": { "alias": "container"; "required": false; }; "contentTemplate": { "alias": "contentTemplate"; "required": false; }; "cornerRadius": { "alias": "cornerRadius"; "required": false; }; "customizeTooltip": { "alias": "customizeTooltip"; "required": false; }; "enabled": { "alias": "enabled"; "required": false; }; "font": { "alias": "font"; "required": false; }; "opacity": { "alias": "opacity"; "required": false; }; "paddingLeftRight": { "alias": "paddingLeftRight"; "required": false; }; "paddingTopBottom": { "alias": "paddingTopBottom"; "required": false; }; "shadow": { "alias": "shadow"; "required": false; }; "zIndex": { "alias": "zIndex"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoVectorMapTooltipModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoVectorMapTooltipModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoVectorMapTooltipModule, never, [typeof DxoVectorMapTooltipComponent], [typeof DxoVectorMapTooltipComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoVectorMapTooltipModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoVectorMapVectorMapTitleSubtitleComponent extends NestedOption implements OnDestroy, OnInit {
    get font(): Font;
    set font(value: Font);
    get offset(): number;
    set offset(value: number);
    get text(): string | undefined;
    set text(value: string | undefined);
    get textOverflow(): TextOverflow;
    set textOverflow(value: TextOverflow);
    get wordWrap(): WordWrap;
    set wordWrap(value: WordWrap);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoVectorMapVectorMapTitleSubtitleComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoVectorMapVectorMapTitleSubtitleComponent, "dxo-vector-map-vector-map-title-subtitle", never, { "font": { "alias": "font"; "required": false; }; "offset": { "alias": "offset"; "required": false; }; "text": { "alias": "text"; "required": false; }; "textOverflow": { "alias": "textOverflow"; "required": false; }; "wordWrap": { "alias": "wordWrap"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoVectorMapVectorMapTitleSubtitleModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoVectorMapVectorMapTitleSubtitleModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoVectorMapVectorMapTitleSubtitleModule, never, [typeof DxoVectorMapVectorMapTitleSubtitleComponent], [typeof DxoVectorMapVectorMapTitleSubtitleComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoVectorMapVectorMapTitleSubtitleModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoVectorMapVectorMapTitleComponent extends NestedOption implements OnDestroy, OnInit {
    get font(): Font;
    set font(value: Font);
    get horizontalAlignment(): HorizontalAlignment;
    set horizontalAlignment(value: HorizontalAlignment);
    get margin(): number | {
        bottom?: number;
        left?: number;
        right?: number;
        top?: number;
    };
    set margin(value: number | {
        bottom?: number;
        left?: number;
        right?: number;
        top?: number;
    });
    get placeholderSize(): number | undefined;
    set placeholderSize(value: number | undefined);
    get subtitle(): string | {
        font?: Font;
        offset?: number;
        text?: string | undefined;
        textOverflow?: TextOverflow;
        wordWrap?: WordWrap;
    };
    set subtitle(value: string | {
        font?: Font;
        offset?: number;
        text?: string | undefined;
        textOverflow?: TextOverflow;
        wordWrap?: WordWrap;
    });
    get text(): string | undefined;
    set text(value: string | undefined);
    get textOverflow(): TextOverflow;
    set textOverflow(value: TextOverflow);
    get verticalAlignment(): VerticalEdge;
    set verticalAlignment(value: VerticalEdge);
    get wordWrap(): WordWrap;
    set wordWrap(value: WordWrap);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoVectorMapVectorMapTitleComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoVectorMapVectorMapTitleComponent, "dxo-vector-map-vector-map-title", never, { "font": { "alias": "font"; "required": false; }; "horizontalAlignment": { "alias": "horizontalAlignment"; "required": false; }; "margin": { "alias": "margin"; "required": false; }; "placeholderSize": { "alias": "placeholderSize"; "required": false; }; "subtitle": { "alias": "subtitle"; "required": false; }; "text": { "alias": "text"; "required": false; }; "textOverflow": { "alias": "textOverflow"; "required": false; }; "verticalAlignment": { "alias": "verticalAlignment"; "required": false; }; "wordWrap": { "alias": "wordWrap"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoVectorMapVectorMapTitleModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoVectorMapVectorMapTitleModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoVectorMapVectorMapTitleModule, never, [typeof DxoVectorMapVectorMapTitleComponent], [typeof DxoVectorMapVectorMapTitleComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoVectorMapVectorMapTitleModule>;
}

export { DxiVectorMapAnnotationComponent, DxiVectorMapAnnotationModule, DxiVectorMapLayerComponent, DxiVectorMapLayerModule, DxiVectorMapLegendComponent, DxiVectorMapLegendModule, DxoVectorMapAnnotationBorderComponent, DxoVectorMapAnnotationBorderModule, DxoVectorMapBackgroundComponent, DxoVectorMapBackgroundModule, DxoVectorMapBorderComponent, DxoVectorMapBorderModule, DxoVectorMapCommonAnnotationSettingsComponent, DxoVectorMapCommonAnnotationSettingsModule, DxoVectorMapControlBarComponent, DxoVectorMapControlBarModule, DxoVectorMapExportComponent, DxoVectorMapExportModule, DxoVectorMapFontComponent, DxoVectorMapFontModule, DxoVectorMapImageComponent, DxoVectorMapImageModule, DxoVectorMapLabelComponent, DxoVectorMapLabelModule, DxoVectorMapLegendTitleComponent, DxoVectorMapLegendTitleModule, DxoVectorMapLegendTitleSubtitleComponent, DxoVectorMapLegendTitleSubtitleModule, DxoVectorMapLoadingIndicatorComponent, DxoVectorMapLoadingIndicatorModule, DxoVectorMapMarginComponent, DxoVectorMapMarginModule, DxoVectorMapProjectionComponent, DxoVectorMapProjectionModule, DxoVectorMapShadowComponent, DxoVectorMapShadowModule, DxoVectorMapSizeComponent, DxoVectorMapSizeModule, DxoVectorMapSourceComponent, DxoVectorMapSourceModule, DxoVectorMapSubtitleComponent, DxoVectorMapSubtitleModule, DxoVectorMapTitleComponent, DxoVectorMapTitleModule, DxoVectorMapTooltipBorderComponent, DxoVectorMapTooltipBorderModule, DxoVectorMapTooltipComponent, DxoVectorMapTooltipModule, DxoVectorMapVectorMapTitleComponent, DxoVectorMapVectorMapTitleModule, DxoVectorMapVectorMapTitleSubtitleComponent, DxoVectorMapVectorMapTitleSubtitleModule };
//# sourceMappingURL=index.d.ts.map
