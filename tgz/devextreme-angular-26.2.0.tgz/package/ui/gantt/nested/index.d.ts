import * as i0 from '@angular/core';
import { EventEmitter, OnDestroy, OnInit, AfterViewInit, QueryList, Renderer2, ElementRef } from '@angular/core';
import { HorizontalAlignment, DataType, SortOrder, SearchMode, Format as Format$1, ToolbarItemLocation, ToolbarItemComponent, SingleMultipleOrNone } from 'devextreme/common';
import { FilterOperation, FilterType, ColumnHeaderFilter, SelectedFilterOperation, HeaderFilterGroupInterval, ColumnHeaderFilterSearchConfig, HeaderFilterSearchConfig } from 'devextreme/common/grids';
import { Format } from 'devextreme/common/core/localization';
import { CollectionNestedOption, NestedOptionHost, NestedOption, IDxTemplateHost, DxTemplateHost, DxTemplateDirective } from 'devextreme-angular/core';
import DataSource, { DataSourceOptions } from 'devextreme/data/data_source';
import { Store } from 'devextreme/data/store';
import { dxContextMenuItem } from 'devextreme/ui/context_menu';
import { GanttPredefinedContextMenuItem, dxGanttContextMenuItem, dxGanttFilterRowOperationDescriptions, dxGanttHeaderFilterTexts, GanttPredefinedToolbarItem, GanttScaleType, dxGanttToolbarItem } from 'devextreme/ui/gantt';
import { LocateInMenuMode, ShowTextMode } from 'devextreme/ui/toolbar';

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxiGanttColumnComponent extends CollectionNestedOption {
    get alignment(): HorizontalAlignment | undefined;
    set alignment(value: HorizontalAlignment | undefined);
    get allowFiltering(): boolean;
    set allowFiltering(value: boolean);
    get allowHeaderFiltering(): boolean;
    set allowHeaderFiltering(value: boolean);
    get allowSorting(): boolean;
    set allowSorting(value: boolean);
    get calculateCellValue(): ((rowData: any) => any);
    set calculateCellValue(value: ((rowData: any) => any));
    get calculateDisplayValue(): ((rowData: any) => any) | string;
    set calculateDisplayValue(value: ((rowData: any) => any) | string);
    get calculateFilterExpression(): ((filterValue: any, selectedFilterOperation: string | null, target: string) => string | Function | Array<any>);
    set calculateFilterExpression(value: ((filterValue: any, selectedFilterOperation: string | null, target: string) => string | Function | Array<any>));
    get calculateSortValue(): ((rowData: any) => any) | string;
    set calculateSortValue(value: ((rowData: any) => any) | string);
    get caption(): string | undefined;
    set caption(value: string | undefined);
    get cellTemplate(): any;
    set cellTemplate(value: any);
    get cssClass(): string | undefined;
    set cssClass(value: string | undefined);
    get customizeText(): ((cellInfo: {
        groupInterval: string | number;
        target: string;
        value: any;
        valueText: string;
    }) => string);
    set customizeText(value: ((cellInfo: {
        groupInterval: string | number;
        target: string;
        value: any;
        valueText: string;
    }) => string));
    get dataField(): string | undefined;
    set dataField(value: string | undefined);
    get dataType(): DataType | undefined;
    set dataType(value: DataType | undefined);
    get encodeHtml(): boolean;
    set encodeHtml(value: boolean);
    get falseText(): string;
    set falseText(value: string);
    get filterOperations(): Array<FilterOperation | string>;
    set filterOperations(value: Array<FilterOperation | string>);
    get filterType(): FilterType;
    set filterType(value: FilterType);
    get filterValue(): any | undefined;
    set filterValue(value: any | undefined);
    get filterValues(): Array<any>;
    set filterValues(value: Array<any>);
    get format(): Format;
    set format(value: Format);
    get headerCellTemplate(): any;
    set headerCellTemplate(value: any);
    get headerFilter(): ColumnHeaderFilter | undefined;
    set headerFilter(value: ColumnHeaderFilter | undefined);
    get minWidth(): number | undefined;
    set minWidth(value: number | undefined);
    get selectedFilterOperation(): SelectedFilterOperation | undefined;
    set selectedFilterOperation(value: SelectedFilterOperation | undefined);
    get sortIndex(): number | undefined;
    set sortIndex(value: number | undefined);
    get sortingMethod(): ((value1: any, value2: any) => number) | undefined;
    set sortingMethod(value: ((value1: any, value2: any) => number) | undefined);
    get sortOrder(): SortOrder | undefined;
    set sortOrder(value: SortOrder | undefined);
    get trueText(): string;
    set trueText(value: string);
    get visible(): boolean;
    set visible(value: boolean);
    get visibleIndex(): number | undefined;
    set visibleIndex(value: number | undefined);
    get width(): number | string | undefined;
    set width(value: number | string | undefined);
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    filterValueChange: EventEmitter<any | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    filterValuesChange: EventEmitter<Array<any>>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    selectedFilterOperationChange: EventEmitter<SelectedFilterOperation | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    sortIndexChange: EventEmitter<number | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    sortOrderChange: EventEmitter<SortOrder | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    visibleChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    visibleIndexChange: EventEmitter<number | undefined>;
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiGanttColumnComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiGanttColumnComponent, "dxi-gantt-column", never, { "alignment": { "alias": "alignment"; "required": false; }; "allowFiltering": { "alias": "allowFiltering"; "required": false; }; "allowHeaderFiltering": { "alias": "allowHeaderFiltering"; "required": false; }; "allowSorting": { "alias": "allowSorting"; "required": false; }; "calculateCellValue": { "alias": "calculateCellValue"; "required": false; }; "calculateDisplayValue": { "alias": "calculateDisplayValue"; "required": false; }; "calculateFilterExpression": { "alias": "calculateFilterExpression"; "required": false; }; "calculateSortValue": { "alias": "calculateSortValue"; "required": false; }; "caption": { "alias": "caption"; "required": false; }; "cellTemplate": { "alias": "cellTemplate"; "required": false; }; "cssClass": { "alias": "cssClass"; "required": false; }; "customizeText": { "alias": "customizeText"; "required": false; }; "dataField": { "alias": "dataField"; "required": false; }; "dataType": { "alias": "dataType"; "required": false; }; "encodeHtml": { "alias": "encodeHtml"; "required": false; }; "falseText": { "alias": "falseText"; "required": false; }; "filterOperations": { "alias": "filterOperations"; "required": false; }; "filterType": { "alias": "filterType"; "required": false; }; "filterValue": { "alias": "filterValue"; "required": false; }; "filterValues": { "alias": "filterValues"; "required": false; }; "format": { "alias": "format"; "required": false; }; "headerCellTemplate": { "alias": "headerCellTemplate"; "required": false; }; "headerFilter": { "alias": "headerFilter"; "required": false; }; "minWidth": { "alias": "minWidth"; "required": false; }; "selectedFilterOperation": { "alias": "selectedFilterOperation"; "required": false; }; "sortIndex": { "alias": "sortIndex"; "required": false; }; "sortingMethod": { "alias": "sortingMethod"; "required": false; }; "sortOrder": { "alias": "sortOrder"; "required": false; }; "trueText": { "alias": "trueText"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "visibleIndex": { "alias": "visibleIndex"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, { "filterValueChange": "filterValueChange"; "filterValuesChange": "filterValuesChange"; "selectedFilterOperationChange": "selectedFilterOperationChange"; "sortIndexChange": "sortIndexChange"; "sortOrderChange": "sortOrderChange"; "visibleChange": "visibleChange"; "visibleIndexChange": "visibleIndexChange"; }, never, never, true, never>;
}
declare class DxiGanttColumnModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiGanttColumnModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiGanttColumnModule, never, [typeof DxiGanttColumnComponent], [typeof DxiGanttColumnComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiGanttColumnModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoGanttColumnHeaderFilterSearchComponent extends NestedOption implements OnDestroy, OnInit {
    get editorOptions(): any;
    set editorOptions(value: any);
    get enabled(): boolean;
    set enabled(value: boolean);
    get mode(): SearchMode;
    set mode(value: SearchMode);
    get searchExpr(): Array<Function | string> | Function | string | undefined;
    set searchExpr(value: Array<Function | string> | Function | string | undefined);
    get timeout(): number;
    set timeout(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoGanttColumnHeaderFilterSearchComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoGanttColumnHeaderFilterSearchComponent, "dxo-gantt-column-header-filter-search", never, { "editorOptions": { "alias": "editorOptions"; "required": false; }; "enabled": { "alias": "enabled"; "required": false; }; "mode": { "alias": "mode"; "required": false; }; "searchExpr": { "alias": "searchExpr"; "required": false; }; "timeout": { "alias": "timeout"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoGanttColumnHeaderFilterSearchModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoGanttColumnHeaderFilterSearchModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoGanttColumnHeaderFilterSearchModule, never, [typeof DxoGanttColumnHeaderFilterSearchComponent], [typeof DxoGanttColumnHeaderFilterSearchComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoGanttColumnHeaderFilterSearchModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoGanttColumnHeaderFilterComponent extends NestedOption implements OnDestroy, OnInit {
    get allowSearch(): boolean;
    set allowSearch(value: boolean);
    get allowSelectAll(): boolean;
    set allowSelectAll(value: boolean);
    get dataSource(): Array<any> | DataSourceOptions | ((options: {
        component: Record<string, any>;
        dataSource: DataSourceOptions | null;
    }) => void) | null | Store | undefined;
    set dataSource(value: Array<any> | DataSourceOptions | ((options: {
        component: Record<string, any>;
        dataSource: DataSourceOptions | null;
    }) => void) | null | Store | undefined);
    get groupInterval(): Array<number | string> | HeaderFilterGroupInterval | number | undefined;
    set groupInterval(value: Array<number | string> | HeaderFilterGroupInterval | number | undefined);
    get height(): number | string | undefined;
    set height(value: number | string | undefined);
    get search(): ColumnHeaderFilterSearchConfig;
    set search(value: ColumnHeaderFilterSearchConfig);
    get searchMode(): SearchMode;
    set searchMode(value: SearchMode);
    get width(): number | string | undefined;
    set width(value: number | string | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoGanttColumnHeaderFilterComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoGanttColumnHeaderFilterComponent, "dxo-gantt-column-header-filter", never, { "allowSearch": { "alias": "allowSearch"; "required": false; }; "allowSelectAll": { "alias": "allowSelectAll"; "required": false; }; "dataSource": { "alias": "dataSource"; "required": false; }; "groupInterval": { "alias": "groupInterval"; "required": false; }; "height": { "alias": "height"; "required": false; }; "search": { "alias": "search"; "required": false; }; "searchMode": { "alias": "searchMode"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoGanttColumnHeaderFilterModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoGanttColumnHeaderFilterModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoGanttColumnHeaderFilterModule, never, [typeof DxoGanttColumnHeaderFilterComponent], [typeof DxoGanttColumnHeaderFilterComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoGanttColumnHeaderFilterModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxiGanttContextMenuItemComponent extends CollectionNestedOption implements AfterViewInit, IDxTemplateHost {
    private renderer;
    private document;
    private element;
    set _itemsContentChildren(value: QueryList<CollectionNestedOption>);
    get beginGroup(): boolean;
    set beginGroup(value: boolean);
    get closeMenuOnClick(): boolean;
    set closeMenuOnClick(value: boolean);
    get disabled(): boolean;
    set disabled(value: boolean);
    get icon(): string;
    set icon(value: string);
    get items(): Array<dxContextMenuItem>;
    set items(value: Array<dxContextMenuItem>);
    get name(): GanttPredefinedContextMenuItem | string;
    set name(value: GanttPredefinedContextMenuItem | string);
    get selectable(): boolean;
    set selectable(value: boolean);
    get selected(): boolean;
    set selected(value: boolean);
    get template(): any;
    set template(value: any);
    get text(): string;
    set text(value: string);
    get visible(): boolean;
    set visible(value: boolean);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost, renderer: Renderer2, document: any, templateHost: DxTemplateHost, element: ElementRef);
    setTemplate(template: DxTemplateDirective): void;
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiGanttContextMenuItemComponent, [{ host: true; skipSelf: true; }, { host: true; }, null, null, { host: true; }, null]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiGanttContextMenuItemComponent, "dxi-gantt-context-menu-item", never, { "beginGroup": { "alias": "beginGroup"; "required": false; }; "closeMenuOnClick": { "alias": "closeMenuOnClick"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "icon": { "alias": "icon"; "required": false; }; "items": { "alias": "items"; "required": false; }; "name": { "alias": "name"; "required": false; }; "selectable": { "alias": "selectable"; "required": false; }; "selected": { "alias": "selected"; "required": false; }; "template": { "alias": "template"; "required": false; }; "text": { "alias": "text"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; }, {}, ["_itemsContentChildren"], ["*"], true, never>;
}
declare class DxiGanttContextMenuItemModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiGanttContextMenuItemModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiGanttContextMenuItemModule, never, [typeof DxiGanttContextMenuItemComponent], [typeof DxiGanttContextMenuItemComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiGanttContextMenuItemModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxiGanttContextMenuItemItemComponent extends CollectionNestedOption implements AfterViewInit, IDxTemplateHost {
    private renderer;
    private document;
    private element;
    set _itemsContentChildren(value: QueryList<CollectionNestedOption>);
    get beginGroup(): boolean;
    set beginGroup(value: boolean);
    get closeMenuOnClick(): boolean;
    set closeMenuOnClick(value: boolean);
    get disabled(): boolean;
    set disabled(value: boolean);
    get icon(): string;
    set icon(value: string);
    get items(): Array<dxContextMenuItem>;
    set items(value: Array<dxContextMenuItem>);
    get selectable(): boolean;
    set selectable(value: boolean);
    get selected(): boolean;
    set selected(value: boolean);
    get template(): any;
    set template(value: any);
    get text(): string;
    set text(value: string);
    get visible(): boolean;
    set visible(value: boolean);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost, renderer: Renderer2, document: any, templateHost: DxTemplateHost, element: ElementRef);
    setTemplate(template: DxTemplateDirective): void;
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiGanttContextMenuItemItemComponent, [{ host: true; skipSelf: true; }, { host: true; }, null, null, { host: true; }, null]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiGanttContextMenuItemItemComponent, "dxi-gantt-context-menu-item-item", never, { "beginGroup": { "alias": "beginGroup"; "required": false; }; "closeMenuOnClick": { "alias": "closeMenuOnClick"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "icon": { "alias": "icon"; "required": false; }; "items": { "alias": "items"; "required": false; }; "selectable": { "alias": "selectable"; "required": false; }; "selected": { "alias": "selected"; "required": false; }; "template": { "alias": "template"; "required": false; }; "text": { "alias": "text"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; }, {}, ["_itemsContentChildren"], ["*"], true, never>;
}
declare class DxiGanttContextMenuItemItemModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiGanttContextMenuItemItemModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiGanttContextMenuItemItemModule, never, [typeof DxiGanttContextMenuItemItemComponent], [typeof DxiGanttContextMenuItemItemComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiGanttContextMenuItemItemModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoGanttContextMenuComponent extends NestedOption implements OnDestroy, OnInit {
    set _itemsContentChildren(value: QueryList<CollectionNestedOption>);
    get enabled(): boolean;
    set enabled(value: boolean);
    get items(): Array<dxGanttContextMenuItem | GanttPredefinedContextMenuItem>;
    set items(value: Array<dxGanttContextMenuItem | GanttPredefinedContextMenuItem>);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoGanttContextMenuComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoGanttContextMenuComponent, "dxo-gantt-context-menu", never, { "enabled": { "alias": "enabled"; "required": false; }; "items": { "alias": "items"; "required": false; }; }, {}, ["_itemsContentChildren"], never, true, never>;
}
declare class DxoGanttContextMenuModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoGanttContextMenuModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoGanttContextMenuModule, never, [typeof DxoGanttContextMenuComponent], [typeof DxoGanttContextMenuComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoGanttContextMenuModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoGanttDependenciesComponent extends NestedOption implements OnDestroy, OnInit {
    get dataSource(): Array<any> | DataSource | DataSourceOptions | null | Store | string;
    set dataSource(value: Array<any> | DataSource | DataSourceOptions | null | Store | string);
    get keyExpr(): ((dependency: any) => any) | string;
    set keyExpr(value: ((dependency: any) => any) | string);
    get predecessorIdExpr(): ((dependency: any, value: any) => any) | string;
    set predecessorIdExpr(value: ((dependency: any, value: any) => any) | string);
    get successorIdExpr(): ((dependency: any, value: any) => any) | string;
    set successorIdExpr(value: ((dependency: any, value: any) => any) | string);
    get typeExpr(): ((dependency: any, value: any) => any) | string;
    set typeExpr(value: ((dependency: any, value: any) => any) | string);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoGanttDependenciesComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoGanttDependenciesComponent, "dxo-gantt-dependencies", never, { "dataSource": { "alias": "dataSource"; "required": false; }; "keyExpr": { "alias": "keyExpr"; "required": false; }; "predecessorIdExpr": { "alias": "predecessorIdExpr"; "required": false; }; "successorIdExpr": { "alias": "successorIdExpr"; "required": false; }; "typeExpr": { "alias": "typeExpr"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoGanttDependenciesModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoGanttDependenciesModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoGanttDependenciesModule, never, [typeof DxoGanttDependenciesComponent], [typeof DxoGanttDependenciesComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoGanttDependenciesModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoGanttEditingComponent extends NestedOption implements OnDestroy, OnInit {
    get allowDependencyAdding(): boolean;
    set allowDependencyAdding(value: boolean);
    get allowDependencyDeleting(): boolean;
    set allowDependencyDeleting(value: boolean);
    get allowResourceAdding(): boolean;
    set allowResourceAdding(value: boolean);
    get allowResourceDeleting(): boolean;
    set allowResourceDeleting(value: boolean);
    get allowResourceUpdating(): boolean;
    set allowResourceUpdating(value: boolean);
    get allowTaskAdding(): boolean;
    set allowTaskAdding(value: boolean);
    get allowTaskDeleting(): boolean;
    set allowTaskDeleting(value: boolean);
    get allowTaskResourceUpdating(): boolean;
    set allowTaskResourceUpdating(value: boolean);
    get allowTaskUpdating(): boolean;
    set allowTaskUpdating(value: boolean);
    get enabled(): boolean;
    set enabled(value: boolean);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoGanttEditingComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoGanttEditingComponent, "dxo-gantt-editing", never, { "allowDependencyAdding": { "alias": "allowDependencyAdding"; "required": false; }; "allowDependencyDeleting": { "alias": "allowDependencyDeleting"; "required": false; }; "allowResourceAdding": { "alias": "allowResourceAdding"; "required": false; }; "allowResourceDeleting": { "alias": "allowResourceDeleting"; "required": false; }; "allowResourceUpdating": { "alias": "allowResourceUpdating"; "required": false; }; "allowTaskAdding": { "alias": "allowTaskAdding"; "required": false; }; "allowTaskDeleting": { "alias": "allowTaskDeleting"; "required": false; }; "allowTaskResourceUpdating": { "alias": "allowTaskResourceUpdating"; "required": false; }; "allowTaskUpdating": { "alias": "allowTaskUpdating"; "required": false; }; "enabled": { "alias": "enabled"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoGanttEditingModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoGanttEditingModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoGanttEditingModule, never, [typeof DxoGanttEditingComponent], [typeof DxoGanttEditingComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoGanttEditingModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoGanttFilterRowComponent extends NestedOption implements OnDestroy, OnInit {
    get betweenEndText(): string;
    set betweenEndText(value: string);
    get betweenStartText(): string;
    set betweenStartText(value: string);
    get operationDescriptions(): dxGanttFilterRowOperationDescriptions;
    set operationDescriptions(value: dxGanttFilterRowOperationDescriptions);
    get resetOperationText(): string;
    set resetOperationText(value: string);
    get showAllText(): string;
    set showAllText(value: string);
    get showOperationChooser(): boolean;
    set showOperationChooser(value: boolean);
    get visible(): boolean;
    set visible(value: boolean);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoGanttFilterRowComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoGanttFilterRowComponent, "dxo-gantt-filter-row", never, { "betweenEndText": { "alias": "betweenEndText"; "required": false; }; "betweenStartText": { "alias": "betweenStartText"; "required": false; }; "operationDescriptions": { "alias": "operationDescriptions"; "required": false; }; "resetOperationText": { "alias": "resetOperationText"; "required": false; }; "showAllText": { "alias": "showAllText"; "required": false; }; "showOperationChooser": { "alias": "showOperationChooser"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoGanttFilterRowModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoGanttFilterRowModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoGanttFilterRowModule, never, [typeof DxoGanttFilterRowComponent], [typeof DxoGanttFilterRowComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoGanttFilterRowModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoGanttFormatComponent extends NestedOption implements OnDestroy, OnInit {
    get currency(): string;
    set currency(value: string);
    get formatter(): ((value: number | Date) => string);
    set formatter(value: ((value: number | Date) => string));
    get parser(): ((value: string) => number | Date);
    set parser(value: ((value: string) => number | Date));
    get precision(): number;
    set precision(value: number);
    get type(): Format$1 | string;
    set type(value: Format$1 | string);
    get useCurrencyAccountingStyle(): boolean;
    set useCurrencyAccountingStyle(value: boolean);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoGanttFormatComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoGanttFormatComponent, "dxo-gantt-format", never, { "currency": { "alias": "currency"; "required": false; }; "formatter": { "alias": "formatter"; "required": false; }; "parser": { "alias": "parser"; "required": false; }; "precision": { "alias": "precision"; "required": false; }; "type": { "alias": "type"; "required": false; }; "useCurrencyAccountingStyle": { "alias": "useCurrencyAccountingStyle"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoGanttFormatModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoGanttFormatModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoGanttFormatModule, never, [typeof DxoGanttFormatComponent], [typeof DxoGanttFormatComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoGanttFormatModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoGanttGanttHeaderFilterSearchComponent extends NestedOption implements OnDestroy, OnInit {
    get editorOptions(): any;
    set editorOptions(value: any);
    get enabled(): boolean;
    set enabled(value: boolean);
    get mode(): SearchMode;
    set mode(value: SearchMode);
    get timeout(): number;
    set timeout(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoGanttGanttHeaderFilterSearchComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoGanttGanttHeaderFilterSearchComponent, "dxo-gantt-gantt-header-filter-search", never, { "editorOptions": { "alias": "editorOptions"; "required": false; }; "enabled": { "alias": "enabled"; "required": false; }; "mode": { "alias": "mode"; "required": false; }; "timeout": { "alias": "timeout"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoGanttGanttHeaderFilterSearchModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoGanttGanttHeaderFilterSearchModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoGanttGanttHeaderFilterSearchModule, never, [typeof DxoGanttGanttHeaderFilterSearchComponent], [typeof DxoGanttGanttHeaderFilterSearchComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoGanttGanttHeaderFilterSearchModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoGanttGanttHeaderFilterComponent extends NestedOption implements OnDestroy, OnInit {
    get allowSearch(): boolean;
    set allowSearch(value: boolean);
    get allowSelectAll(): boolean;
    set allowSelectAll(value: boolean);
    get height(): number;
    set height(value: number);
    get search(): HeaderFilterSearchConfig;
    set search(value: HeaderFilterSearchConfig);
    get searchTimeout(): number;
    set searchTimeout(value: number);
    get texts(): dxGanttHeaderFilterTexts;
    set texts(value: dxGanttHeaderFilterTexts);
    get visible(): boolean;
    set visible(value: boolean);
    get width(): number;
    set width(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoGanttGanttHeaderFilterComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoGanttGanttHeaderFilterComponent, "dxo-gantt-gantt-header-filter", never, { "allowSearch": { "alias": "allowSearch"; "required": false; }; "allowSelectAll": { "alias": "allowSelectAll"; "required": false; }; "height": { "alias": "height"; "required": false; }; "search": { "alias": "search"; "required": false; }; "searchTimeout": { "alias": "searchTimeout"; "required": false; }; "texts": { "alias": "texts"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoGanttGanttHeaderFilterModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoGanttGanttHeaderFilterModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoGanttGanttHeaderFilterModule, never, [typeof DxoGanttGanttHeaderFilterComponent], [typeof DxoGanttGanttHeaderFilterComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoGanttGanttHeaderFilterModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoGanttHeaderFilterComponent extends NestedOption implements OnDestroy, OnInit {
    get allowSearch(): boolean;
    set allowSearch(value: boolean);
    get allowSelectAll(): boolean;
    set allowSelectAll(value: boolean);
    get dataSource(): Array<any> | DataSourceOptions | ((options: {
        component: Record<string, any>;
        dataSource: DataSourceOptions | null;
    }) => void) | null | Store | undefined;
    set dataSource(value: Array<any> | DataSourceOptions | ((options: {
        component: Record<string, any>;
        dataSource: DataSourceOptions | null;
    }) => void) | null | Store | undefined);
    get groupInterval(): Array<number | string> | HeaderFilterGroupInterval | number | undefined;
    set groupInterval(value: Array<number | string> | HeaderFilterGroupInterval | number | undefined);
    get height(): number | string | undefined;
    set height(value: number | string | undefined);
    get search(): ColumnHeaderFilterSearchConfig | HeaderFilterSearchConfig;
    set search(value: ColumnHeaderFilterSearchConfig | HeaderFilterSearchConfig);
    get searchMode(): SearchMode;
    set searchMode(value: SearchMode);
    get width(): number | string | undefined;
    set width(value: number | string | undefined);
    get searchTimeout(): number;
    set searchTimeout(value: number);
    get texts(): dxGanttHeaderFilterTexts;
    set texts(value: dxGanttHeaderFilterTexts);
    get visible(): boolean;
    set visible(value: boolean);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoGanttHeaderFilterComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoGanttHeaderFilterComponent, "dxo-gantt-header-filter", never, { "allowSearch": { "alias": "allowSearch"; "required": false; }; "allowSelectAll": { "alias": "allowSelectAll"; "required": false; }; "dataSource": { "alias": "dataSource"; "required": false; }; "groupInterval": { "alias": "groupInterval"; "required": false; }; "height": { "alias": "height"; "required": false; }; "search": { "alias": "search"; "required": false; }; "searchMode": { "alias": "searchMode"; "required": false; }; "width": { "alias": "width"; "required": false; }; "searchTimeout": { "alias": "searchTimeout"; "required": false; }; "texts": { "alias": "texts"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoGanttHeaderFilterModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoGanttHeaderFilterModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoGanttHeaderFilterModule, never, [typeof DxoGanttHeaderFilterComponent], [typeof DxoGanttHeaderFilterComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoGanttHeaderFilterModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxiGanttItemComponent extends CollectionNestedOption implements AfterViewInit, IDxTemplateHost {
    private renderer;
    private document;
    private element;
    set _itemsContentChildren(value: QueryList<CollectionNestedOption>);
    get beginGroup(): boolean;
    set beginGroup(value: boolean);
    get closeMenuOnClick(): boolean;
    set closeMenuOnClick(value: boolean);
    get disabled(): boolean;
    set disabled(value: boolean);
    get icon(): string;
    set icon(value: string);
    get items(): Array<dxContextMenuItem>;
    set items(value: Array<dxContextMenuItem>);
    get name(): GanttPredefinedContextMenuItem | string | GanttPredefinedToolbarItem;
    set name(value: GanttPredefinedContextMenuItem | string | GanttPredefinedToolbarItem);
    get selectable(): boolean;
    set selectable(value: boolean);
    get selected(): boolean;
    set selected(value: boolean);
    get template(): any;
    set template(value: any);
    get text(): string;
    set text(value: string);
    get visible(): boolean;
    set visible(value: boolean);
    get cssClass(): string | undefined;
    set cssClass(value: string | undefined);
    get html(): string;
    set html(value: string);
    get locateInMenu(): LocateInMenuMode;
    set locateInMenu(value: LocateInMenuMode);
    get location(): ToolbarItemLocation;
    set location(value: ToolbarItemLocation);
    get menuItemTemplate(): any;
    set menuItemTemplate(value: any);
    get options(): any;
    set options(value: any);
    get showText(): ShowTextMode;
    set showText(value: ShowTextMode);
    get widget(): ToolbarItemComponent;
    set widget(value: ToolbarItemComponent);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost, renderer: Renderer2, document: any, templateHost: DxTemplateHost, element: ElementRef);
    setTemplate(template: DxTemplateDirective): void;
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiGanttItemComponent, [{ host: true; skipSelf: true; }, { host: true; }, null, null, { host: true; }, null]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiGanttItemComponent, "dxi-gantt-item", never, { "beginGroup": { "alias": "beginGroup"; "required": false; }; "closeMenuOnClick": { "alias": "closeMenuOnClick"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "icon": { "alias": "icon"; "required": false; }; "items": { "alias": "items"; "required": false; }; "name": { "alias": "name"; "required": false; }; "selectable": { "alias": "selectable"; "required": false; }; "selected": { "alias": "selected"; "required": false; }; "template": { "alias": "template"; "required": false; }; "text": { "alias": "text"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "cssClass": { "alias": "cssClass"; "required": false; }; "html": { "alias": "html"; "required": false; }; "locateInMenu": { "alias": "locateInMenu"; "required": false; }; "location": { "alias": "location"; "required": false; }; "menuItemTemplate": { "alias": "menuItemTemplate"; "required": false; }; "options": { "alias": "options"; "required": false; }; "showText": { "alias": "showText"; "required": false; }; "widget": { "alias": "widget"; "required": false; }; }, {}, ["_itemsContentChildren"], ["*"], true, never>;
}
declare class DxiGanttItemModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiGanttItemModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiGanttItemModule, never, [typeof DxiGanttItemComponent], [typeof DxiGanttItemComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiGanttItemModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoGanttOperationDescriptionsComponent extends NestedOption implements OnDestroy, OnInit {
    get between(): string;
    set between(value: string);
    get contains(): string;
    set contains(value: string);
    get endsWith(): string;
    set endsWith(value: string);
    get equal(): string;
    set equal(value: string);
    get greaterThan(): string;
    set greaterThan(value: string);
    get greaterThanOrEqual(): string;
    set greaterThanOrEqual(value: string);
    get lessThan(): string;
    set lessThan(value: string);
    get lessThanOrEqual(): string;
    set lessThanOrEqual(value: string);
    get notContains(): string;
    set notContains(value: string);
    get notEqual(): string;
    set notEqual(value: string);
    get startsWith(): string;
    set startsWith(value: string);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoGanttOperationDescriptionsComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoGanttOperationDescriptionsComponent, "dxo-gantt-operation-descriptions", never, { "between": { "alias": "between"; "required": false; }; "contains": { "alias": "contains"; "required": false; }; "endsWith": { "alias": "endsWith"; "required": false; }; "equal": { "alias": "equal"; "required": false; }; "greaterThan": { "alias": "greaterThan"; "required": false; }; "greaterThanOrEqual": { "alias": "greaterThanOrEqual"; "required": false; }; "lessThan": { "alias": "lessThan"; "required": false; }; "lessThanOrEqual": { "alias": "lessThanOrEqual"; "required": false; }; "notContains": { "alias": "notContains"; "required": false; }; "notEqual": { "alias": "notEqual"; "required": false; }; "startsWith": { "alias": "startsWith"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoGanttOperationDescriptionsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoGanttOperationDescriptionsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoGanttOperationDescriptionsModule, never, [typeof DxoGanttOperationDescriptionsComponent], [typeof DxoGanttOperationDescriptionsComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoGanttOperationDescriptionsModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoGanttResourceAssignmentsComponent extends NestedOption implements OnDestroy, OnInit {
    get dataSource(): Array<any> | DataSource | DataSourceOptions | null | Store | string;
    set dataSource(value: Array<any> | DataSource | DataSourceOptions | null | Store | string);
    get keyExpr(): ((resourceAssignment: any) => any) | string;
    set keyExpr(value: ((resourceAssignment: any) => any) | string);
    get resourceIdExpr(): ((resourceAssignment: any, value: any) => any) | string;
    set resourceIdExpr(value: ((resourceAssignment: any, value: any) => any) | string);
    get taskIdExpr(): ((resourceAssignment: any, value: any) => any) | string;
    set taskIdExpr(value: ((resourceAssignment: any, value: any) => any) | string);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoGanttResourceAssignmentsComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoGanttResourceAssignmentsComponent, "dxo-gantt-resource-assignments", never, { "dataSource": { "alias": "dataSource"; "required": false; }; "keyExpr": { "alias": "keyExpr"; "required": false; }; "resourceIdExpr": { "alias": "resourceIdExpr"; "required": false; }; "taskIdExpr": { "alias": "taskIdExpr"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoGanttResourceAssignmentsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoGanttResourceAssignmentsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoGanttResourceAssignmentsModule, never, [typeof DxoGanttResourceAssignmentsComponent], [typeof DxoGanttResourceAssignmentsComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoGanttResourceAssignmentsModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoGanttResourcesComponent extends NestedOption implements OnDestroy, OnInit {
    get colorExpr(): ((resource: any, value: any) => any) | string;
    set colorExpr(value: ((resource: any, value: any) => any) | string);
    get dataSource(): Array<any> | DataSource | DataSourceOptions | null | Store | string;
    set dataSource(value: Array<any> | DataSource | DataSourceOptions | null | Store | string);
    get keyExpr(): ((resource: any) => any) | string;
    set keyExpr(value: ((resource: any) => any) | string);
    get textExpr(): ((resource: any, value: any) => string) | string;
    set textExpr(value: ((resource: any, value: any) => string) | string);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoGanttResourcesComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoGanttResourcesComponent, "dxo-gantt-resources", never, { "colorExpr": { "alias": "colorExpr"; "required": false; }; "dataSource": { "alias": "dataSource"; "required": false; }; "keyExpr": { "alias": "keyExpr"; "required": false; }; "textExpr": { "alias": "textExpr"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoGanttResourcesModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoGanttResourcesModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoGanttResourcesModule, never, [typeof DxoGanttResourcesComponent], [typeof DxoGanttResourcesComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoGanttResourcesModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoGanttScaleTypeRangeComponent extends NestedOption implements OnDestroy, OnInit {
    get max(): GanttScaleType;
    set max(value: GanttScaleType);
    get min(): GanttScaleType;
    set min(value: GanttScaleType);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoGanttScaleTypeRangeComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoGanttScaleTypeRangeComponent, "dxo-gantt-scale-type-range", never, { "max": { "alias": "max"; "required": false; }; "min": { "alias": "min"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoGanttScaleTypeRangeModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoGanttScaleTypeRangeModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoGanttScaleTypeRangeModule, never, [typeof DxoGanttScaleTypeRangeComponent], [typeof DxoGanttScaleTypeRangeComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoGanttScaleTypeRangeModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoGanttSearchComponent extends NestedOption implements OnDestroy, OnInit {
    get editorOptions(): any;
    set editorOptions(value: any);
    get enabled(): boolean;
    set enabled(value: boolean);
    get mode(): SearchMode;
    set mode(value: SearchMode);
    get searchExpr(): Array<Function | string> | Function | string | undefined;
    set searchExpr(value: Array<Function | string> | Function | string | undefined);
    get timeout(): number;
    set timeout(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoGanttSearchComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoGanttSearchComponent, "dxo-gantt-search", never, { "editorOptions": { "alias": "editorOptions"; "required": false; }; "enabled": { "alias": "enabled"; "required": false; }; "mode": { "alias": "mode"; "required": false; }; "searchExpr": { "alias": "searchExpr"; "required": false; }; "timeout": { "alias": "timeout"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoGanttSearchModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoGanttSearchModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoGanttSearchModule, never, [typeof DxoGanttSearchComponent], [typeof DxoGanttSearchComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoGanttSearchModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoGanttSortingComponent extends NestedOption implements OnDestroy, OnInit {
    get ascendingText(): string;
    set ascendingText(value: string);
    get clearText(): string;
    set clearText(value: string);
    get descendingText(): string;
    set descendingText(value: string);
    get mode(): SingleMultipleOrNone | string;
    set mode(value: SingleMultipleOrNone | string);
    get showSortIndexes(): boolean;
    set showSortIndexes(value: boolean);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoGanttSortingComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoGanttSortingComponent, "dxo-gantt-sorting", never, { "ascendingText": { "alias": "ascendingText"; "required": false; }; "clearText": { "alias": "clearText"; "required": false; }; "descendingText": { "alias": "descendingText"; "required": false; }; "mode": { "alias": "mode"; "required": false; }; "showSortIndexes": { "alias": "showSortIndexes"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoGanttSortingModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoGanttSortingModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoGanttSortingModule, never, [typeof DxoGanttSortingComponent], [typeof DxoGanttSortingComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoGanttSortingModule>;
}

declare class DxiGanttStripLineComponent extends CollectionNestedOption {
    get cssClass(): string | undefined;
    set cssClass(value: string | undefined);
    get end(): Date | (() => Date | number | string) | number | string | undefined;
    set end(value: Date | (() => Date | number | string) | number | string | undefined);
    get start(): Date | (() => Date | number | string) | number | string | undefined;
    set start(value: Date | (() => Date | number | string) | number | string | undefined);
    get title(): string | undefined;
    set title(value: string | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiGanttStripLineComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiGanttStripLineComponent, "dxi-gantt-strip-line", never, { "cssClass": { "alias": "cssClass"; "required": false; }; "end": { "alias": "end"; "required": false; }; "start": { "alias": "start"; "required": false; }; "title": { "alias": "title"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxiGanttStripLineModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiGanttStripLineModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiGanttStripLineModule, never, [typeof DxiGanttStripLineComponent], [typeof DxiGanttStripLineComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiGanttStripLineModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoGanttTasksComponent extends NestedOption implements OnDestroy, OnInit {
    get colorExpr(): ((task: any, value: any) => any) | string;
    set colorExpr(value: ((task: any, value: any) => any) | string);
    get dataSource(): Array<any> | DataSource | DataSourceOptions | null | Store | string;
    set dataSource(value: Array<any> | DataSource | DataSourceOptions | null | Store | string);
    get endExpr(): ((task: any, value: any) => any) | string;
    set endExpr(value: ((task: any, value: any) => any) | string);
    get keyExpr(): ((task: any) => any) | string;
    set keyExpr(value: ((task: any) => any) | string);
    get parentIdExpr(): ((task: any, value: any) => any) | string;
    set parentIdExpr(value: ((task: any, value: any) => any) | string);
    get progressExpr(): ((task: any, value: any) => any) | string;
    set progressExpr(value: ((task: any, value: any) => any) | string);
    get startExpr(): ((task: any, value: any) => any) | string;
    set startExpr(value: ((task: any, value: any) => any) | string);
    get titleExpr(): ((task: any, value: any) => any) | string;
    set titleExpr(value: ((task: any, value: any) => any) | string);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoGanttTasksComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoGanttTasksComponent, "dxo-gantt-tasks", never, { "colorExpr": { "alias": "colorExpr"; "required": false; }; "dataSource": { "alias": "dataSource"; "required": false; }; "endExpr": { "alias": "endExpr"; "required": false; }; "keyExpr": { "alias": "keyExpr"; "required": false; }; "parentIdExpr": { "alias": "parentIdExpr"; "required": false; }; "progressExpr": { "alias": "progressExpr"; "required": false; }; "startExpr": { "alias": "startExpr"; "required": false; }; "titleExpr": { "alias": "titleExpr"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoGanttTasksModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoGanttTasksModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoGanttTasksModule, never, [typeof DxoGanttTasksComponent], [typeof DxoGanttTasksComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoGanttTasksModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoGanttTextsComponent extends NestedOption implements OnDestroy, OnInit {
    get cancel(): string;
    set cancel(value: string);
    get emptyValue(): string;
    set emptyValue(value: string);
    get ok(): string;
    set ok(value: string);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoGanttTextsComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoGanttTextsComponent, "dxo-gantt-texts", never, { "cancel": { "alias": "cancel"; "required": false; }; "emptyValue": { "alias": "emptyValue"; "required": false; }; "ok": { "alias": "ok"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoGanttTextsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoGanttTextsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoGanttTextsModule, never, [typeof DxoGanttTextsComponent], [typeof DxoGanttTextsComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoGanttTextsModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxiGanttToolbarItemComponent extends CollectionNestedOption implements AfterViewInit, IDxTemplateHost {
    private renderer;
    private document;
    private element;
    get cssClass(): string | undefined;
    set cssClass(value: string | undefined);
    get disabled(): boolean;
    set disabled(value: boolean);
    get html(): string;
    set html(value: string);
    get locateInMenu(): LocateInMenuMode;
    set locateInMenu(value: LocateInMenuMode);
    get location(): ToolbarItemLocation;
    set location(value: ToolbarItemLocation);
    get menuItemTemplate(): any;
    set menuItemTemplate(value: any);
    get name(): GanttPredefinedToolbarItem | string;
    set name(value: GanttPredefinedToolbarItem | string);
    get options(): any;
    set options(value: any);
    get showText(): ShowTextMode;
    set showText(value: ShowTextMode);
    get template(): any;
    set template(value: any);
    get text(): string;
    set text(value: string);
    get visible(): boolean;
    set visible(value: boolean);
    get widget(): ToolbarItemComponent;
    set widget(value: ToolbarItemComponent);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost, renderer: Renderer2, document: any, templateHost: DxTemplateHost, element: ElementRef);
    setTemplate(template: DxTemplateDirective): void;
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiGanttToolbarItemComponent, [{ host: true; skipSelf: true; }, { host: true; }, null, null, { host: true; }, null]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiGanttToolbarItemComponent, "dxi-gantt-toolbar-item", never, { "cssClass": { "alias": "cssClass"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "html": { "alias": "html"; "required": false; }; "locateInMenu": { "alias": "locateInMenu"; "required": false; }; "location": { "alias": "location"; "required": false; }; "menuItemTemplate": { "alias": "menuItemTemplate"; "required": false; }; "name": { "alias": "name"; "required": false; }; "options": { "alias": "options"; "required": false; }; "showText": { "alias": "showText"; "required": false; }; "template": { "alias": "template"; "required": false; }; "text": { "alias": "text"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "widget": { "alias": "widget"; "required": false; }; }, {}, never, ["*"], true, never>;
}
declare class DxiGanttToolbarItemModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiGanttToolbarItemModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiGanttToolbarItemModule, never, [typeof DxiGanttToolbarItemComponent], [typeof DxiGanttToolbarItemComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiGanttToolbarItemModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoGanttToolbarComponent extends NestedOption implements OnDestroy, OnInit {
    set _itemsContentChildren(value: QueryList<CollectionNestedOption>);
    get items(): Array<dxGanttToolbarItem | GanttPredefinedToolbarItem>;
    set items(value: Array<dxGanttToolbarItem | GanttPredefinedToolbarItem>);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoGanttToolbarComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoGanttToolbarComponent, "dxo-gantt-toolbar", never, { "items": { "alias": "items"; "required": false; }; }, {}, ["_itemsContentChildren"], never, true, never>;
}
declare class DxoGanttToolbarModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoGanttToolbarModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoGanttToolbarModule, never, [typeof DxoGanttToolbarComponent], [typeof DxoGanttToolbarComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoGanttToolbarModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoGanttValidationComponent extends NestedOption implements OnDestroy, OnInit {
    get autoUpdateParentTasks(): boolean;
    set autoUpdateParentTasks(value: boolean);
    get enablePredecessorGap(): boolean;
    set enablePredecessorGap(value: boolean);
    get validateDependencies(): boolean;
    set validateDependencies(value: boolean);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoGanttValidationComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoGanttValidationComponent, "dxo-gantt-validation", never, { "autoUpdateParentTasks": { "alias": "autoUpdateParentTasks"; "required": false; }; "enablePredecessorGap": { "alias": "enablePredecessorGap"; "required": false; }; "validateDependencies": { "alias": "validateDependencies"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoGanttValidationModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoGanttValidationModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoGanttValidationModule, never, [typeof DxoGanttValidationComponent], [typeof DxoGanttValidationComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoGanttValidationModule>;
}

export { DxiGanttColumnComponent, DxiGanttColumnModule, DxiGanttContextMenuItemComponent, DxiGanttContextMenuItemItemComponent, DxiGanttContextMenuItemItemModule, DxiGanttContextMenuItemModule, DxiGanttItemComponent, DxiGanttItemModule, DxiGanttStripLineComponent, DxiGanttStripLineModule, DxiGanttToolbarItemComponent, DxiGanttToolbarItemModule, DxoGanttColumnHeaderFilterComponent, DxoGanttColumnHeaderFilterModule, DxoGanttColumnHeaderFilterSearchComponent, DxoGanttColumnHeaderFilterSearchModule, DxoGanttContextMenuComponent, DxoGanttContextMenuModule, DxoGanttDependenciesComponent, DxoGanttDependenciesModule, DxoGanttEditingComponent, DxoGanttEditingModule, DxoGanttFilterRowComponent, DxoGanttFilterRowModule, DxoGanttFormatComponent, DxoGanttFormatModule, DxoGanttGanttHeaderFilterComponent, DxoGanttGanttHeaderFilterModule, DxoGanttGanttHeaderFilterSearchComponent, DxoGanttGanttHeaderFilterSearchModule, DxoGanttHeaderFilterComponent, DxoGanttHeaderFilterModule, DxoGanttOperationDescriptionsComponent, DxoGanttOperationDescriptionsModule, DxoGanttResourceAssignmentsComponent, DxoGanttResourceAssignmentsModule, DxoGanttResourcesComponent, DxoGanttResourcesModule, DxoGanttScaleTypeRangeComponent, DxoGanttScaleTypeRangeModule, DxoGanttSearchComponent, DxoGanttSearchModule, DxoGanttSortingComponent, DxoGanttSortingModule, DxoGanttTasksComponent, DxoGanttTasksModule, DxoGanttTextsComponent, DxoGanttTextsModule, DxoGanttToolbarComponent, DxoGanttToolbarModule, DxoGanttValidationComponent, DxoGanttValidationModule };
//# sourceMappingURL=index.d.ts.map
