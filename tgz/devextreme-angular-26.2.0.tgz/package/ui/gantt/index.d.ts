import * as i0 from '@angular/core';
import { OnDestroy, OnChanges, DoCheck, QueryList, EventEmitter, ElementRef, NgZone, TransferState, SimpleChanges } from '@angular/core';
import DxGantt, { dxGanttColumn, dxGanttContextMenu, dxGanttFilterRow, dxGanttHeaderFilter, GanttScaleType, dxGanttSorting, dxGanttStripLine, GanttTaskTitlePosition, dxGanttToolbar, ContentReadyEvent, ContextMenuPreparingEvent, CustomCommandEvent, DependencyDeletedEvent, DependencyDeletingEvent, DependencyInsertedEvent, DependencyInsertingEvent, DisposingEvent, InitializedEvent, OptionChangedEvent, ResourceAssignedEvent, ResourceAssigningEvent, ResourceDeletedEvent, ResourceDeletingEvent, ResourceInsertedEvent, ResourceInsertingEvent, ResourceManagerDialogShowingEvent, ResourceUnassignedEvent, ResourceUnassigningEvent, ScaleCellPreparedEvent, SelectionChangedEvent, TaskClickEvent, TaskDblClickEvent, TaskDeletedEvent, TaskDeletingEvent, TaskEditDialogShowingEvent, TaskInsertedEvent, TaskInsertingEvent, TaskMovingEvent, TaskUpdatedEvent, TaskUpdatingEvent } from 'devextreme/ui/gantt';
import DataSource, { DataSourceOptions } from 'devextreme/data/data_source';
import { Store } from 'devextreme/data/store';
import { DayOfWeek } from 'devextreme/common';
import * as i3 from 'devextreme-angular/core';
import { DxComponent, CollectionNestedOption, DxTemplateHost, WatcherHelper, IterableDifferHelper, NestedOptionHost } from 'devextreme-angular/core';
import * as i1 from 'devextreme-angular/ui/nested';
import * as i2 from 'devextreme-angular/ui/gantt/nested';
export * from 'devextreme-angular/ui/gantt/nested';
import * as gantt_types from 'devextreme/ui/gantt_types';
export { gantt_types as DxGanttTypes };

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

/**
 * [descr:dxGantt]

 */
declare class DxGanttComponent extends DxComponent implements OnDestroy, OnChanges, DoCheck {
    private _watcherHelper;
    private _idh;
    set _columnsContentChildren(value: QueryList<CollectionNestedOption>);
    set _itemsContentChildren(value: QueryList<CollectionNestedOption>);
    set _stripLinesContentChildren(value: QueryList<CollectionNestedOption>);
    instance: DxGantt;
    /**
     * [descr:WidgetOptions.accessKey]
    
     */
    get accessKey(): string | undefined;
    set accessKey(value: string | undefined);
    /**
     * [descr:WidgetOptions.activeStateEnabled]
    
     */
    get activeStateEnabled(): boolean;
    set activeStateEnabled(value: boolean);
    /**
     * [descr:dxGanttOptions.allowSelection]
    
     */
    get allowSelection(): boolean;
    set allowSelection(value: boolean);
    /**
     * [descr:dxGanttOptions.columns]
    
     */
    get columns(): Array<dxGanttColumn | string>;
    set columns(value: Array<dxGanttColumn | string>);
    /**
     * [descr:dxGanttOptions.contextMenu]
    
     */
    get contextMenu(): dxGanttContextMenu;
    set contextMenu(value: dxGanttContextMenu);
    /**
     * [descr:dxGanttOptions.dependencies]
    
     */
    get dependencies(): {
        dataSource?: Array<any> | DataSource | DataSourceOptions | null | Store | string;
        keyExpr?: ((dependency: any) => any) | string;
        predecessorIdExpr?: ((dependency: any, value: any) => any) | string;
        successorIdExpr?: ((dependency: any, value: any) => any) | string;
        typeExpr?: ((dependency: any, value: any) => any) | string;
    };
    set dependencies(value: {
        dataSource?: Array<any> | DataSource | DataSourceOptions | null | Store | string;
        keyExpr?: ((dependency: any) => any) | string;
        predecessorIdExpr?: ((dependency: any, value: any) => any) | string;
        successorIdExpr?: ((dependency: any, value: any) => any) | string;
        typeExpr?: ((dependency: any, value: any) => any) | string;
    });
    /**
     * [descr:WidgetOptions.disabled]
    
     */
    get disabled(): boolean;
    set disabled(value: boolean);
    /**
     * [descr:dxGanttOptions.editing]
    
     */
    get editing(): {
        allowDependencyAdding?: boolean;
        allowDependencyDeleting?: boolean;
        allowResourceAdding?: boolean;
        allowResourceDeleting?: boolean;
        allowResourceUpdating?: boolean;
        allowTaskAdding?: boolean;
        allowTaskDeleting?: boolean;
        allowTaskResourceUpdating?: boolean;
        allowTaskUpdating?: boolean;
        enabled?: boolean;
    };
    set editing(value: {
        allowDependencyAdding?: boolean;
        allowDependencyDeleting?: boolean;
        allowResourceAdding?: boolean;
        allowResourceDeleting?: boolean;
        allowResourceUpdating?: boolean;
        allowTaskAdding?: boolean;
        allowTaskDeleting?: boolean;
        allowTaskResourceUpdating?: boolean;
        allowTaskUpdating?: boolean;
        enabled?: boolean;
    });
    /**
     * [descr:DOMComponentOptions.elementAttr]
    
     */
    get elementAttr(): Record<string, any>;
    set elementAttr(value: Record<string, any>);
    /**
     * [descr:dxGanttOptions.endDateRange]
    
     */
    get endDateRange(): Date | undefined;
    set endDateRange(value: Date | undefined);
    /**
     * [descr:dxGanttOptions.filterRow]
    
     */
    get filterRow(): dxGanttFilterRow;
    set filterRow(value: dxGanttFilterRow);
    /**
     * [descr:dxGanttOptions.firstDayOfWeek]
    
     */
    get firstDayOfWeek(): DayOfWeek | undefined;
    set firstDayOfWeek(value: DayOfWeek | undefined);
    /**
     * [descr:WidgetOptions.focusStateEnabled]
    
     */
    get focusStateEnabled(): boolean;
    set focusStateEnabled(value: boolean);
    /**
     * [descr:dxGanttOptions.headerFilter]
    
     */
    get headerFilter(): dxGanttHeaderFilter;
    set headerFilter(value: dxGanttHeaderFilter);
    /**
     * [descr:DOMComponentOptions.height]
    
     */
    get height(): number | string | undefined;
    set height(value: number | string | undefined);
    /**
     * [descr:WidgetOptions.hint]
    
     */
    get hint(): string | undefined;
    set hint(value: string | undefined);
    /**
     * [descr:WidgetOptions.hoverStateEnabled]
    
     */
    get hoverStateEnabled(): boolean;
    set hoverStateEnabled(value: boolean);
    /**
     * [descr:dxGanttOptions.resourceAssignments]
    
     */
    get resourceAssignments(): {
        dataSource?: Array<any> | DataSource | DataSourceOptions | null | Store | string;
        keyExpr?: ((resourceAssignment: any) => any) | string;
        resourceIdExpr?: ((resourceAssignment: any, value: any) => any) | string;
        taskIdExpr?: ((resourceAssignment: any, value: any) => any) | string;
    };
    set resourceAssignments(value: {
        dataSource?: Array<any> | DataSource | DataSourceOptions | null | Store | string;
        keyExpr?: ((resourceAssignment: any) => any) | string;
        resourceIdExpr?: ((resourceAssignment: any, value: any) => any) | string;
        taskIdExpr?: ((resourceAssignment: any, value: any) => any) | string;
    });
    /**
     * [descr:dxGanttOptions.resources]
    
     */
    get resources(): {
        colorExpr?: ((resource: any, value: any) => any) | string;
        dataSource?: Array<any> | DataSource | DataSourceOptions | null | Store | string;
        keyExpr?: ((resource: any) => any) | string;
        textExpr?: ((resource: any, value: any) => string) | string;
    };
    set resources(value: {
        colorExpr?: ((resource: any, value: any) => any) | string;
        dataSource?: Array<any> | DataSource | DataSourceOptions | null | Store | string;
        keyExpr?: ((resource: any) => any) | string;
        textExpr?: ((resource: any, value: any) => string) | string;
    });
    /**
     * [descr:dxGanttOptions.rootValue]
    
     */
    get rootValue(): any;
    set rootValue(value: any);
    /**
     * [descr:dxGanttOptions.scaleType]
    
     */
    get scaleType(): GanttScaleType;
    set scaleType(value: GanttScaleType);
    /**
     * [descr:dxGanttOptions.scaleTypeRange]
    
     */
    get scaleTypeRange(): {
        max?: GanttScaleType;
        min?: GanttScaleType;
    };
    set scaleTypeRange(value: {
        max?: GanttScaleType;
        min?: GanttScaleType;
    });
    /**
     * [descr:dxGanttOptions.selectedRowKey]
    
     */
    get selectedRowKey(): any | undefined;
    set selectedRowKey(value: any | undefined);
    /**
     * [descr:dxGanttOptions.showDependencies]
    
     */
    get showDependencies(): boolean;
    set showDependencies(value: boolean);
    /**
     * [descr:dxGanttOptions.showResources]
    
     */
    get showResources(): boolean;
    set showResources(value: boolean);
    /**
     * [descr:dxGanttOptions.showRowLines]
    
     */
    get showRowLines(): boolean;
    set showRowLines(value: boolean);
    /**
     * [descr:dxGanttOptions.sorting]
    
     */
    get sorting(): dxGanttSorting;
    set sorting(value: dxGanttSorting);
    /**
     * [descr:dxGanttOptions.startDateRange]
    
     */
    get startDateRange(): Date | undefined;
    set startDateRange(value: Date | undefined);
    /**
     * [descr:dxGanttOptions.stripLines]
    
     */
    get stripLines(): Array<dxGanttStripLine>;
    set stripLines(value: Array<dxGanttStripLine>);
    /**
     * [descr:WidgetOptions.tabIndex]
    
     */
    get tabIndex(): number;
    set tabIndex(value: number);
    /**
     * [descr:dxGanttOptions.taskContentTemplate]
    
     */
    get taskContentTemplate(): any;
    set taskContentTemplate(value: any);
    /**
     * [descr:dxGanttOptions.taskListWidth]
    
     */
    get taskListWidth(): number;
    set taskListWidth(value: number);
    /**
     * [descr:dxGanttOptions.taskProgressTooltipContentTemplate]
    
     */
    get taskProgressTooltipContentTemplate(): any;
    set taskProgressTooltipContentTemplate(value: any);
    /**
     * [descr:dxGanttOptions.tasks]
    
     */
    get tasks(): {
        colorExpr?: ((task: any, value: any) => any) | string;
        dataSource?: Array<any> | DataSource | DataSourceOptions | null | Store | string;
        endExpr?: ((task: any, value: any) => any) | string;
        keyExpr?: ((task: any) => any) | string;
        parentIdExpr?: ((task: any, value: any) => any) | string;
        progressExpr?: ((task: any, value: any) => any) | string;
        startExpr?: ((task: any, value: any) => any) | string;
        titleExpr?: ((task: any, value: any) => any) | string;
    };
    set tasks(value: {
        colorExpr?: ((task: any, value: any) => any) | string;
        dataSource?: Array<any> | DataSource | DataSourceOptions | null | Store | string;
        endExpr?: ((task: any, value: any) => any) | string;
        keyExpr?: ((task: any) => any) | string;
        parentIdExpr?: ((task: any, value: any) => any) | string;
        progressExpr?: ((task: any, value: any) => any) | string;
        startExpr?: ((task: any, value: any) => any) | string;
        titleExpr?: ((task: any, value: any) => any) | string;
    });
    /**
     * [descr:dxGanttOptions.taskTimeTooltipContentTemplate]
    
     */
    get taskTimeTooltipContentTemplate(): any;
    set taskTimeTooltipContentTemplate(value: any);
    /**
     * [descr:dxGanttOptions.taskTitlePosition]
    
     */
    get taskTitlePosition(): GanttTaskTitlePosition;
    set taskTitlePosition(value: GanttTaskTitlePosition);
    /**
     * [descr:dxGanttOptions.taskTooltipContentTemplate]
    
     */
    get taskTooltipContentTemplate(): any;
    set taskTooltipContentTemplate(value: any);
    /**
     * [descr:dxGanttOptions.toolbar]
    
     */
    get toolbar(): dxGanttToolbar;
    set toolbar(value: dxGanttToolbar);
    /**
     * [descr:dxGanttOptions.validation]
    
     */
    get validation(): {
        autoUpdateParentTasks?: boolean;
        enablePredecessorGap?: boolean;
        validateDependencies?: boolean;
    };
    set validation(value: {
        autoUpdateParentTasks?: boolean;
        enablePredecessorGap?: boolean;
        validateDependencies?: boolean;
    });
    /**
     * [descr:WidgetOptions.visible]
    
     */
    get visible(): boolean;
    set visible(value: boolean);
    /**
     * [descr:DOMComponentOptions.width]
    
     */
    get width(): number | string | undefined;
    set width(value: number | string | undefined);
    /**
    
     * [descr:dxGanttOptions.onContentReady]
    
    
     */
    onContentReady: EventEmitter<ContentReadyEvent>;
    /**
    
     * [descr:dxGanttOptions.onContextMenuPreparing]
    
    
     */
    onContextMenuPreparing: EventEmitter<ContextMenuPreparingEvent>;
    /**
    
     * [descr:dxGanttOptions.onCustomCommand]
    
    
     */
    onCustomCommand: EventEmitter<CustomCommandEvent>;
    /**
    
     * [descr:dxGanttOptions.onDependencyDeleted]
    
    
     */
    onDependencyDeleted: EventEmitter<DependencyDeletedEvent>;
    /**
    
     * [descr:dxGanttOptions.onDependencyDeleting]
    
    
     */
    onDependencyDeleting: EventEmitter<DependencyDeletingEvent>;
    /**
    
     * [descr:dxGanttOptions.onDependencyInserted]
    
    
     */
    onDependencyInserted: EventEmitter<DependencyInsertedEvent>;
    /**
    
     * [descr:dxGanttOptions.onDependencyInserting]
    
    
     */
    onDependencyInserting: EventEmitter<DependencyInsertingEvent>;
    /**
    
     * [descr:dxGanttOptions.onDisposing]
    
    
     */
    onDisposing: EventEmitter<DisposingEvent>;
    /**
    
     * [descr:dxGanttOptions.onInitialized]
    
    
     */
    onInitialized: EventEmitter<InitializedEvent>;
    /**
    
     * [descr:dxGanttOptions.onOptionChanged]
    
    
     */
    onOptionChanged: EventEmitter<OptionChangedEvent>;
    /**
    
     * [descr:dxGanttOptions.onResourceAssigned]
    
    
     */
    onResourceAssigned: EventEmitter<ResourceAssignedEvent>;
    /**
    
     * [descr:dxGanttOptions.onResourceAssigning]
    
    
     */
    onResourceAssigning: EventEmitter<ResourceAssigningEvent>;
    /**
    
     * [descr:dxGanttOptions.onResourceDeleted]
    
    
     */
    onResourceDeleted: EventEmitter<ResourceDeletedEvent>;
    /**
    
     * [descr:dxGanttOptions.onResourceDeleting]
    
    
     */
    onResourceDeleting: EventEmitter<ResourceDeletingEvent>;
    /**
    
     * [descr:dxGanttOptions.onResourceInserted]
    
    
     */
    onResourceInserted: EventEmitter<ResourceInsertedEvent>;
    /**
    
     * [descr:dxGanttOptions.onResourceInserting]
    
    
     */
    onResourceInserting: EventEmitter<ResourceInsertingEvent>;
    /**
    
     * [descr:dxGanttOptions.onResourceManagerDialogShowing]
    
    
     */
    onResourceManagerDialogShowing: EventEmitter<ResourceManagerDialogShowingEvent>;
    /**
    
     * [descr:dxGanttOptions.onResourceUnassigned]
    
    
     */
    onResourceUnassigned: EventEmitter<ResourceUnassignedEvent>;
    /**
    
     * [descr:dxGanttOptions.onResourceUnassigning]
    
    
     */
    onResourceUnassigning: EventEmitter<ResourceUnassigningEvent>;
    /**
    
     * [descr:dxGanttOptions.onScaleCellPrepared]
    
    
     */
    onScaleCellPrepared: EventEmitter<ScaleCellPreparedEvent>;
    /**
    
     * [descr:dxGanttOptions.onSelectionChanged]
    
    
     */
    onSelectionChanged: EventEmitter<SelectionChangedEvent>;
    /**
    
     * [descr:dxGanttOptions.onTaskClick]
    
    
     */
    onTaskClick: EventEmitter<TaskClickEvent>;
    /**
    
     * [descr:dxGanttOptions.onTaskDblClick]
    
    
     */
    onTaskDblClick: EventEmitter<TaskDblClickEvent>;
    /**
    
     * [descr:dxGanttOptions.onTaskDeleted]
    
    
     */
    onTaskDeleted: EventEmitter<TaskDeletedEvent>;
    /**
    
     * [descr:dxGanttOptions.onTaskDeleting]
    
    
     */
    onTaskDeleting: EventEmitter<TaskDeletingEvent>;
    /**
    
     * [descr:dxGanttOptions.onTaskEditDialogShowing]
    
    
     */
    onTaskEditDialogShowing: EventEmitter<TaskEditDialogShowingEvent>;
    /**
    
     * [descr:dxGanttOptions.onTaskInserted]
    
    
     */
    onTaskInserted: EventEmitter<TaskInsertedEvent>;
    /**
    
     * [descr:dxGanttOptions.onTaskInserting]
    
    
     */
    onTaskInserting: EventEmitter<TaskInsertingEvent>;
    /**
    
     * [descr:dxGanttOptions.onTaskMoving]
    
    
     */
    onTaskMoving: EventEmitter<TaskMovingEvent>;
    /**
    
     * [descr:dxGanttOptions.onTaskUpdated]
    
    
     */
    onTaskUpdated: EventEmitter<TaskUpdatedEvent>;
    /**
    
     * [descr:dxGanttOptions.onTaskUpdating]
    
    
     */
    onTaskUpdating: EventEmitter<TaskUpdatingEvent>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    accessKeyChange: EventEmitter<string | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    activeStateEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    allowSelectionChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    columnsChange: EventEmitter<Array<dxGanttColumn | string>>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    contextMenuChange: EventEmitter<dxGanttContextMenu>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    dependenciesChange: EventEmitter<{
        dataSource?: Array<any> | DataSource | DataSourceOptions | null | Store | string;
        keyExpr?: ((dependency: any) => any) | string;
        predecessorIdExpr?: ((dependency: any, value: any) => any) | string;
        successorIdExpr?: ((dependency: any, value: any) => any) | string;
        typeExpr?: ((dependency: any, value: any) => any) | string;
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    disabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    editingChange: EventEmitter<{
        allowDependencyAdding?: boolean;
        allowDependencyDeleting?: boolean;
        allowResourceAdding?: boolean;
        allowResourceDeleting?: boolean;
        allowResourceUpdating?: boolean;
        allowTaskAdding?: boolean;
        allowTaskDeleting?: boolean;
        allowTaskResourceUpdating?: boolean;
        allowTaskUpdating?: boolean;
        enabled?: boolean;
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    elementAttrChange: EventEmitter<Record<string, any>>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    endDateRangeChange: EventEmitter<Date | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    filterRowChange: EventEmitter<dxGanttFilterRow>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    firstDayOfWeekChange: EventEmitter<DayOfWeek | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    focusStateEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    headerFilterChange: EventEmitter<dxGanttHeaderFilter>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    heightChange: EventEmitter<number | string | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    hintChange: EventEmitter<string | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    hoverStateEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    resourceAssignmentsChange: EventEmitter<{
        dataSource?: Array<any> | DataSource | DataSourceOptions | null | Store | string;
        keyExpr?: ((resourceAssignment: any) => any) | string;
        resourceIdExpr?: ((resourceAssignment: any, value: any) => any) | string;
        taskIdExpr?: ((resourceAssignment: any, value: any) => any) | string;
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    resourcesChange: EventEmitter<{
        colorExpr?: ((resource: any, value: any) => any) | string;
        dataSource?: Array<any> | DataSource | DataSourceOptions | null | Store | string;
        keyExpr?: ((resource: any) => any) | string;
        textExpr?: ((resource: any, value: any) => string) | string;
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    rootValueChange: EventEmitter<any>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    scaleTypeChange: EventEmitter<GanttScaleType>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    scaleTypeRangeChange: EventEmitter<{
        max?: GanttScaleType;
        min?: GanttScaleType;
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    selectedRowKeyChange: EventEmitter<any | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    showDependenciesChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    showResourcesChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    showRowLinesChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    sortingChange: EventEmitter<dxGanttSorting>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    startDateRangeChange: EventEmitter<Date | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    stripLinesChange: EventEmitter<Array<dxGanttStripLine>>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    tabIndexChange: EventEmitter<number>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    taskContentTemplateChange: EventEmitter<any>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    taskListWidthChange: EventEmitter<number>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    taskProgressTooltipContentTemplateChange: EventEmitter<any>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    tasksChange: EventEmitter<{
        colorExpr?: ((task: any, value: any) => any) | string;
        dataSource?: Array<any> | DataSource | DataSourceOptions | null | Store | string;
        endExpr?: ((task: any, value: any) => any) | string;
        keyExpr?: ((task: any) => any) | string;
        parentIdExpr?: ((task: any, value: any) => any) | string;
        progressExpr?: ((task: any, value: any) => any) | string;
        startExpr?: ((task: any, value: any) => any) | string;
        titleExpr?: ((task: any, value: any) => any) | string;
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    taskTimeTooltipContentTemplateChange: EventEmitter<any>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    taskTitlePositionChange: EventEmitter<GanttTaskTitlePosition>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    taskTooltipContentTemplateChange: EventEmitter<any>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    toolbarChange: EventEmitter<dxGanttToolbar>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    validationChange: EventEmitter<{
        autoUpdateParentTasks?: boolean;
        enablePredecessorGap?: boolean;
        validateDependencies?: boolean;
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    visibleChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    widthChange: EventEmitter<number | string | undefined>;
    constructor(elementRef: ElementRef, ngZone: NgZone, templateHost: DxTemplateHost, _watcherHelper: WatcherHelper, _idh: IterableDifferHelper, optionHost: NestedOptionHost, transferState: TransferState, platformId: any);
    protected _createInstance(element: any, options: any): DxGantt;
    ngOnDestroy(): void;
    ngOnChanges(changes: SimpleChanges): void;
    setupChanges(prop: string, changes: SimpleChanges): void;
    ngDoCheck(): void;
    _setOption(name: string, value: any): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxGanttComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxGanttComponent, "dx-gantt", never, { "accessKey": { "alias": "accessKey"; "required": false; }; "activeStateEnabled": { "alias": "activeStateEnabled"; "required": false; }; "allowSelection": { "alias": "allowSelection"; "required": false; }; "columns": { "alias": "columns"; "required": false; }; "contextMenu": { "alias": "contextMenu"; "required": false; }; "dependencies": { "alias": "dependencies"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "editing": { "alias": "editing"; "required": false; }; "elementAttr": { "alias": "elementAttr"; "required": false; }; "endDateRange": { "alias": "endDateRange"; "required": false; }; "filterRow": { "alias": "filterRow"; "required": false; }; "firstDayOfWeek": { "alias": "firstDayOfWeek"; "required": false; }; "focusStateEnabled": { "alias": "focusStateEnabled"; "required": false; }; "headerFilter": { "alias": "headerFilter"; "required": false; }; "height": { "alias": "height"; "required": false; }; "hint": { "alias": "hint"; "required": false; }; "hoverStateEnabled": { "alias": "hoverStateEnabled"; "required": false; }; "resourceAssignments": { "alias": "resourceAssignments"; "required": false; }; "resources": { "alias": "resources"; "required": false; }; "rootValue": { "alias": "rootValue"; "required": false; }; "scaleType": { "alias": "scaleType"; "required": false; }; "scaleTypeRange": { "alias": "scaleTypeRange"; "required": false; }; "selectedRowKey": { "alias": "selectedRowKey"; "required": false; }; "showDependencies": { "alias": "showDependencies"; "required": false; }; "showResources": { "alias": "showResources"; "required": false; }; "showRowLines": { "alias": "showRowLines"; "required": false; }; "sorting": { "alias": "sorting"; "required": false; }; "startDateRange": { "alias": "startDateRange"; "required": false; }; "stripLines": { "alias": "stripLines"; "required": false; }; "tabIndex": { "alias": "tabIndex"; "required": false; }; "taskContentTemplate": { "alias": "taskContentTemplate"; "required": false; }; "taskListWidth": { "alias": "taskListWidth"; "required": false; }; "taskProgressTooltipContentTemplate": { "alias": "taskProgressTooltipContentTemplate"; "required": false; }; "tasks": { "alias": "tasks"; "required": false; }; "taskTimeTooltipContentTemplate": { "alias": "taskTimeTooltipContentTemplate"; "required": false; }; "taskTitlePosition": { "alias": "taskTitlePosition"; "required": false; }; "taskTooltipContentTemplate": { "alias": "taskTooltipContentTemplate"; "required": false; }; "toolbar": { "alias": "toolbar"; "required": false; }; "validation": { "alias": "validation"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, { "onContentReady": "onContentReady"; "onContextMenuPreparing": "onContextMenuPreparing"; "onCustomCommand": "onCustomCommand"; "onDependencyDeleted": "onDependencyDeleted"; "onDependencyDeleting": "onDependencyDeleting"; "onDependencyInserted": "onDependencyInserted"; "onDependencyInserting": "onDependencyInserting"; "onDisposing": "onDisposing"; "onInitialized": "onInitialized"; "onOptionChanged": "onOptionChanged"; "onResourceAssigned": "onResourceAssigned"; "onResourceAssigning": "onResourceAssigning"; "onResourceDeleted": "onResourceDeleted"; "onResourceDeleting": "onResourceDeleting"; "onResourceInserted": "onResourceInserted"; "onResourceInserting": "onResourceInserting"; "onResourceManagerDialogShowing": "onResourceManagerDialogShowing"; "onResourceUnassigned": "onResourceUnassigned"; "onResourceUnassigning": "onResourceUnassigning"; "onScaleCellPrepared": "onScaleCellPrepared"; "onSelectionChanged": "onSelectionChanged"; "onTaskClick": "onTaskClick"; "onTaskDblClick": "onTaskDblClick"; "onTaskDeleted": "onTaskDeleted"; "onTaskDeleting": "onTaskDeleting"; "onTaskEditDialogShowing": "onTaskEditDialogShowing"; "onTaskInserted": "onTaskInserted"; "onTaskInserting": "onTaskInserting"; "onTaskMoving": "onTaskMoving"; "onTaskUpdated": "onTaskUpdated"; "onTaskUpdating": "onTaskUpdating"; "accessKeyChange": "accessKeyChange"; "activeStateEnabledChange": "activeStateEnabledChange"; "allowSelectionChange": "allowSelectionChange"; "columnsChange": "columnsChange"; "contextMenuChange": "contextMenuChange"; "dependenciesChange": "dependenciesChange"; "disabledChange": "disabledChange"; "editingChange": "editingChange"; "elementAttrChange": "elementAttrChange"; "endDateRangeChange": "endDateRangeChange"; "filterRowChange": "filterRowChange"; "firstDayOfWeekChange": "firstDayOfWeekChange"; "focusStateEnabledChange": "focusStateEnabledChange"; "headerFilterChange": "headerFilterChange"; "heightChange": "heightChange"; "hintChange": "hintChange"; "hoverStateEnabledChange": "hoverStateEnabledChange"; "resourceAssignmentsChange": "resourceAssignmentsChange"; "resourcesChange": "resourcesChange"; "rootValueChange": "rootValueChange"; "scaleTypeChange": "scaleTypeChange"; "scaleTypeRangeChange": "scaleTypeRangeChange"; "selectedRowKeyChange": "selectedRowKeyChange"; "showDependenciesChange": "showDependenciesChange"; "showResourcesChange": "showResourcesChange"; "showRowLinesChange": "showRowLinesChange"; "sortingChange": "sortingChange"; "startDateRangeChange": "startDateRangeChange"; "stripLinesChange": "stripLinesChange"; "tabIndexChange": "tabIndexChange"; "taskContentTemplateChange": "taskContentTemplateChange"; "taskListWidthChange": "taskListWidthChange"; "taskProgressTooltipContentTemplateChange": "taskProgressTooltipContentTemplateChange"; "tasksChange": "tasksChange"; "taskTimeTooltipContentTemplateChange": "taskTimeTooltipContentTemplateChange"; "taskTitlePositionChange": "taskTitlePositionChange"; "taskTooltipContentTemplateChange": "taskTooltipContentTemplateChange"; "toolbarChange": "toolbarChange"; "validationChange": "validationChange"; "visibleChange": "visibleChange"; "widthChange": "widthChange"; }, ["_columnsContentChildren", "_itemsContentChildren", "_stripLinesContentChildren"], never, true, never>;
}
declare class DxGanttModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxGanttModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxGanttModule, never, [typeof DxGanttComponent, typeof i1.DxiColumnModule, typeof i1.DxoFormatModule, typeof i1.DxoHeaderFilterModule, typeof i1.DxoSearchModule, typeof i1.DxoContextMenuModule, typeof i1.DxiItemModule, typeof i1.DxoDependenciesModule, typeof i1.DxoEditingModule, typeof i1.DxoFilterRowModule, typeof i1.DxoOperationDescriptionsModule, typeof i1.DxoTextsModule, typeof i1.DxoResourceAssignmentsModule, typeof i1.DxoResourcesModule, typeof i1.DxoScaleTypeRangeModule, typeof i1.DxoSortingModule, typeof i1.DxiStripLineModule, typeof i1.DxoTasksModule, typeof i1.DxoToolbarModule, typeof i1.DxoValidationModule, typeof i2.DxiGanttColumnModule, typeof i2.DxoGanttColumnHeaderFilterModule, typeof i2.DxoGanttColumnHeaderFilterSearchModule, typeof i2.DxoGanttContextMenuModule, typeof i2.DxiGanttContextMenuItemModule, typeof i2.DxiGanttContextMenuItemItemModule, typeof i2.DxoGanttDependenciesModule, typeof i2.DxoGanttEditingModule, typeof i2.DxoGanttFilterRowModule, typeof i2.DxoGanttFormatModule, typeof i2.DxoGanttGanttHeaderFilterModule, typeof i2.DxoGanttGanttHeaderFilterSearchModule, typeof i2.DxoGanttHeaderFilterModule, typeof i2.DxiGanttItemModule, typeof i2.DxoGanttOperationDescriptionsModule, typeof i2.DxoGanttResourceAssignmentsModule, typeof i2.DxoGanttResourcesModule, typeof i2.DxoGanttScaleTypeRangeModule, typeof i2.DxoGanttSearchModule, typeof i2.DxoGanttSortingModule, typeof i2.DxiGanttStripLineModule, typeof i2.DxoGanttTasksModule, typeof i2.DxoGanttTextsModule, typeof i2.DxoGanttToolbarModule, typeof i2.DxiGanttToolbarItemModule, typeof i2.DxoGanttValidationModule, typeof i3.DxIntegrationModule, typeof i3.DxTemplateModule], [typeof DxGanttComponent, typeof i1.DxiColumnModule, typeof i1.DxoFormatModule, typeof i1.DxoHeaderFilterModule, typeof i1.DxoSearchModule, typeof i1.DxoContextMenuModule, typeof i1.DxiItemModule, typeof i1.DxoDependenciesModule, typeof i1.DxoEditingModule, typeof i1.DxoFilterRowModule, typeof i1.DxoOperationDescriptionsModule, typeof i1.DxoTextsModule, typeof i1.DxoResourceAssignmentsModule, typeof i1.DxoResourcesModule, typeof i1.DxoScaleTypeRangeModule, typeof i1.DxoSortingModule, typeof i1.DxiStripLineModule, typeof i1.DxoTasksModule, typeof i1.DxoToolbarModule, typeof i1.DxoValidationModule, typeof i2.DxiGanttColumnModule, typeof i2.DxoGanttColumnHeaderFilterModule, typeof i2.DxoGanttColumnHeaderFilterSearchModule, typeof i2.DxoGanttContextMenuModule, typeof i2.DxiGanttContextMenuItemModule, typeof i2.DxiGanttContextMenuItemItemModule, typeof i2.DxoGanttDependenciesModule, typeof i2.DxoGanttEditingModule, typeof i2.DxoGanttFilterRowModule, typeof i2.DxoGanttFormatModule, typeof i2.DxoGanttGanttHeaderFilterModule, typeof i2.DxoGanttGanttHeaderFilterSearchModule, typeof i2.DxoGanttHeaderFilterModule, typeof i2.DxiGanttItemModule, typeof i2.DxoGanttOperationDescriptionsModule, typeof i2.DxoGanttResourceAssignmentsModule, typeof i2.DxoGanttResourcesModule, typeof i2.DxoGanttScaleTypeRangeModule, typeof i2.DxoGanttSearchModule, typeof i2.DxoGanttSortingModule, typeof i2.DxiGanttStripLineModule, typeof i2.DxoGanttTasksModule, typeof i2.DxoGanttTextsModule, typeof i2.DxoGanttToolbarModule, typeof i2.DxiGanttToolbarItemModule, typeof i2.DxoGanttValidationModule, typeof i3.DxTemplateModule]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxGanttModule>;
}

export { DxGanttComponent, DxGanttModule };
//# sourceMappingURL=index.d.ts.map
