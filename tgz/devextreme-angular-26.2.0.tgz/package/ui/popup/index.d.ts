import * as i0 from '@angular/core';
import { OnDestroy, OnChanges, DoCheck, QueryList, EventEmitter, ElementRef, NgZone, TransferState, SimpleChanges, Injector, ApplicationRef, RendererFactory2, Type, ComponentRef } from '@angular/core';
import { AnimationConfig, PositionConfig } from 'devextreme/common/core/animation';
import { event } from 'devextreme/events/events.types';
import { EventInfo } from 'devextreme/common/core/events';
import { PositionAlignment } from 'devextreme/common';
import DxPopup, { dxPopupToolbarItem } from 'devextreme/ui/popup';
import * as i3 from 'devextreme-angular/core';
import { DxComponent, CollectionNestedOption, DxTemplateHost, WatcherHelper, IterableDifferHelper, NestedOptionHost } from 'devextreme-angular/core';
import * as i1 from 'devextreme-angular/ui/nested';
import * as i2 from 'devextreme-angular/ui/popup/nested';
export * from 'devextreme-angular/ui/popup/nested';
import * as DxPopupTypes from 'devextreme/ui/popup_types';
export { DxPopupTypes };

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

/**
 * [descr:dxPopup]

 */
declare class DxPopupComponent extends DxComponent implements OnDestroy, OnChanges, DoCheck {
    private _watcherHelper;
    private _idh;
    set _toolbarItemsContentChildren(value: QueryList<CollectionNestedOption>);
    instance: DxPopup;
    /**
     * [descr:WidgetOptions.accessKey]
    
     */
    get accessKey(): string | undefined;
    set accessKey(value: string | undefined);
    /**
     * [descr:dxPopupOptions.animation]
    
     */
    get animation(): {
        hide?: AnimationConfig;
        show?: AnimationConfig;
    };
    set animation(value: {
        hide?: AnimationConfig;
        show?: AnimationConfig;
    });
    /**
     * [descr:dxPopupOptions.container]
    
     */
    get container(): any | string | undefined;
    set container(value: any | string | undefined);
    /**
     * [descr:dxOverlayOptions.contentTemplate]
    
     */
    get contentTemplate(): any;
    set contentTemplate(value: any);
    /**
     * [descr:dxOverlayOptions.deferRendering]
    
     */
    get deferRendering(): boolean;
    set deferRendering(value: boolean);
    /**
     * [descr:WidgetOptions.disabled]
    
     */
    get disabled(): boolean;
    set disabled(value: boolean);
    /**
     * [descr:dxPopupOptions.dragAndResizeArea]
    
     */
    get dragAndResizeArea(): any | string | undefined;
    set dragAndResizeArea(value: any | string | undefined);
    /**
     * [descr:dxPopupOptions.dragEnabled]
    
     */
    get dragEnabled(): boolean;
    set dragEnabled(value: boolean);
    /**
     * [descr:dxPopupOptions.dragOutsideBoundary]
    
     */
    get dragOutsideBoundary(): boolean;
    set dragOutsideBoundary(value: boolean);
    /**
     * [descr:dxPopupOptions.enableBodyScroll]
    
     */
    get enableBodyScroll(): boolean;
    set enableBodyScroll(value: boolean);
    /**
     * [descr:dxPopupOptions.focusStateEnabled]
    
     */
    get focusStateEnabled(): boolean;
    set focusStateEnabled(value: boolean);
    /**
     * [descr:dxPopupOptions.fullScreen]
    
     */
    get fullScreen(): boolean;
    set fullScreen(value: boolean);
    /**
     * [descr:dxPopupOptions.height]
    
     */
    get height(): number | string;
    set height(value: number | string);
    /**
     * [descr:dxOverlayOptions.hideOnOutsideClick]
    
     */
    get hideOnOutsideClick(): boolean | ((event: event) => boolean);
    set hideOnOutsideClick(value: boolean | ((event: event) => boolean));
    /**
     * [descr:dxOverlayOptions.hideOnParentScroll]
    
     */
    get hideOnParentScroll(): boolean;
    set hideOnParentScroll(value: boolean);
    /**
     * [descr:WidgetOptions.hint]
    
     */
    get hint(): string | undefined;
    set hint(value: string | undefined);
    /**
     * [descr:WidgetOptions.hoverStateEnabled]
    
     */
    get hoverStateEnabled(): boolean;
    set hoverStateEnabled(value: boolean);
    /**
     * [descr:dxOverlayOptions.maxHeight]
    
     */
    get maxHeight(): number | string;
    set maxHeight(value: number | string);
    /**
     * [descr:dxOverlayOptions.maxWidth]
    
     */
    get maxWidth(): number | string;
    set maxWidth(value: number | string);
    /**
     * [descr:dxOverlayOptions.minHeight]
    
     */
    get minHeight(): number | string;
    set minHeight(value: number | string);
    /**
     * [descr:dxOverlayOptions.minWidth]
    
     */
    get minWidth(): number | string;
    set minWidth(value: number | string);
    /**
     * [descr:dxPopupOptions.position]
    
     */
    get position(): Function | PositionAlignment | PositionConfig;
    set position(value: Function | PositionAlignment | PositionConfig);
    /**
     * [descr:dxPopupOptions.resizeEnabled]
    
     */
    get resizeEnabled(): boolean;
    set resizeEnabled(value: boolean);
    /**
     * [descr:dxPopupOptions.restorePosition]
    
     */
    get restorePosition(): boolean;
    set restorePosition(value: boolean);
    /**
     * [descr:DOMComponentOptions.rtlEnabled]
    
     */
    get rtlEnabled(): boolean;
    set rtlEnabled(value: boolean);
    /**
     * [descr:dxOverlayOptions.shading]
    
     */
    get shading(): boolean;
    set shading(value: boolean);
    /**
     * [descr:dxOverlayOptions.shadingColor]
    
     */
    get shadingColor(): string;
    set shadingColor(value: string);
    /**
     * [descr:dxPopupOptions.showCloseButton]
    
     */
    get showCloseButton(): boolean;
    set showCloseButton(value: boolean);
    /**
     * [descr:dxPopupOptions.showTitle]
    
     */
    get showTitle(): boolean;
    set showTitle(value: boolean);
    get tabFocusLoopEnabled(): boolean;
    set tabFocusLoopEnabled(value: boolean);
    /**
     * [descr:WidgetOptions.tabIndex]
    
     */
    get tabIndex(): number;
    set tabIndex(value: number);
    /**
     * [descr:dxPopupOptions.title]
    
     */
    get title(): string;
    set title(value: string);
    /**
     * [descr:dxPopupOptions.titleTemplate]
    
     */
    get titleTemplate(): any;
    set titleTemplate(value: any);
    /**
     * [descr:dxPopupOptions.toolbarItems]
    
     */
    get toolbarItems(): Array<dxPopupToolbarItem>;
    set toolbarItems(value: Array<dxPopupToolbarItem>);
    /**
     * [descr:dxOverlayOptions.visible]
    
     */
    get visible(): boolean;
    set visible(value: boolean);
    /**
     * [descr:dxPopupOptions.width]
    
     */
    get width(): number | string;
    set width(value: number | string);
    /**
     * [descr:dxOverlayOptions.wrapperAttr]
    
     */
    get wrapperAttr(): any;
    set wrapperAttr(value: any);
    /**
    
     * [descr:WidgetOptions.onContentReady]
    
    
     */
    onContentReady: EventEmitter<EventInfo<any>>;
    /**
    
     * [descr:DOMComponentOptions.onDisposing]
    
    
     */
    onDisposing: EventEmitter<EventInfo<any>>;
    /**
    
     * [descr:dxOverlayOptions.onHidden]
    
    
     */
    onHidden: EventEmitter<EventInfo<any>>;
    /**
    
     * [descr:dxOverlayOptions.onHiding]
    
    
     */
    onHiding: EventEmitter<Object>;
    /**
    
     * [descr:ComponentOptions.onInitialized]
    
    
     */
    onInitialized: EventEmitter<Object>;
    /**
    
     * [descr:DOMComponentOptions.onOptionChanged]
    
    
     */
    onOptionChanged: EventEmitter<Object>;
    /**
    
     * [descr:dxPopupOptions.onResize]
    
    
     */
    onResize: EventEmitter<Object>;
    /**
    
     * [descr:dxPopupOptions.onResizeEnd]
    
    
     */
    onResizeEnd: EventEmitter<Object>;
    /**
    
     * [descr:dxPopupOptions.onResizeStart]
    
    
     */
    onResizeStart: EventEmitter<Object>;
    /**
    
     * [descr:dxOverlayOptions.onShowing]
    
    
     */
    onShowing: EventEmitter<Object>;
    /**
    
     * [descr:dxOverlayOptions.onShown]
    
    
     */
    onShown: EventEmitter<EventInfo<any>>;
    /**
    
     * [descr:dxPopupOptions.onTitleRendered]
    
    
     */
    onTitleRendered: EventEmitter<Object>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    accessKeyChange: EventEmitter<string | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    animationChange: EventEmitter<{
        hide?: AnimationConfig;
        show?: AnimationConfig;
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    containerChange: EventEmitter<any | string | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    contentTemplateChange: EventEmitter<any>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    deferRenderingChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    disabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    dragAndResizeAreaChange: EventEmitter<any | string | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    dragEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    dragOutsideBoundaryChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    enableBodyScrollChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    focusStateEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    fullScreenChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    heightChange: EventEmitter<number | string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    hideOnOutsideClickChange: EventEmitter<boolean | ((event: event) => boolean)>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    hideOnParentScrollChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    hintChange: EventEmitter<string | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    hoverStateEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    maxHeightChange: EventEmitter<number | string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    maxWidthChange: EventEmitter<number | string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    minHeightChange: EventEmitter<number | string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    minWidthChange: EventEmitter<number | string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    positionChange: EventEmitter<Function | PositionAlignment | PositionConfig>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    resizeEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    restorePositionChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    rtlEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    shadingChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    shadingColorChange: EventEmitter<string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    showCloseButtonChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    showTitleChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    tabFocusLoopEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    tabIndexChange: EventEmitter<number>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    titleChange: EventEmitter<string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    titleTemplateChange: EventEmitter<any>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    toolbarItemsChange: EventEmitter<Array<dxPopupToolbarItem>>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    visibleChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    widthChange: EventEmitter<number | string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    wrapperAttrChange: EventEmitter<any>;
    constructor(elementRef: ElementRef, ngZone: NgZone, templateHost: DxTemplateHost, _watcherHelper: WatcherHelper, _idh: IterableDifferHelper, optionHost: NestedOptionHost, transferState: TransferState, platformId: any);
    protected _createInstance(element: any, options: any): DxPopup<any>;
    ngOnDestroy(): void;
    ngOnChanges(changes: SimpleChanges): void;
    setupChanges(prop: string, changes: SimpleChanges): void;
    ngDoCheck(): void;
    _setOption(name: string, value: any): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxPopupComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxPopupComponent, "dx-popup", never, { "accessKey": { "alias": "accessKey"; "required": false; }; "animation": { "alias": "animation"; "required": false; }; "container": { "alias": "container"; "required": false; }; "contentTemplate": { "alias": "contentTemplate"; "required": false; }; "deferRendering": { "alias": "deferRendering"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "dragAndResizeArea": { "alias": "dragAndResizeArea"; "required": false; }; "dragEnabled": { "alias": "dragEnabled"; "required": false; }; "dragOutsideBoundary": { "alias": "dragOutsideBoundary"; "required": false; }; "enableBodyScroll": { "alias": "enableBodyScroll"; "required": false; }; "focusStateEnabled": { "alias": "focusStateEnabled"; "required": false; }; "fullScreen": { "alias": "fullScreen"; "required": false; }; "height": { "alias": "height"; "required": false; }; "hideOnOutsideClick": { "alias": "hideOnOutsideClick"; "required": false; }; "hideOnParentScroll": { "alias": "hideOnParentScroll"; "required": false; }; "hint": { "alias": "hint"; "required": false; }; "hoverStateEnabled": { "alias": "hoverStateEnabled"; "required": false; }; "maxHeight": { "alias": "maxHeight"; "required": false; }; "maxWidth": { "alias": "maxWidth"; "required": false; }; "minHeight": { "alias": "minHeight"; "required": false; }; "minWidth": { "alias": "minWidth"; "required": false; }; "position": { "alias": "position"; "required": false; }; "resizeEnabled": { "alias": "resizeEnabled"; "required": false; }; "restorePosition": { "alias": "restorePosition"; "required": false; }; "rtlEnabled": { "alias": "rtlEnabled"; "required": false; }; "shading": { "alias": "shading"; "required": false; }; "shadingColor": { "alias": "shadingColor"; "required": false; }; "showCloseButton": { "alias": "showCloseButton"; "required": false; }; "showTitle": { "alias": "showTitle"; "required": false; }; "tabFocusLoopEnabled": { "alias": "tabFocusLoopEnabled"; "required": false; }; "tabIndex": { "alias": "tabIndex"; "required": false; }; "title": { "alias": "title"; "required": false; }; "titleTemplate": { "alias": "titleTemplate"; "required": false; }; "toolbarItems": { "alias": "toolbarItems"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; "wrapperAttr": { "alias": "wrapperAttr"; "required": false; }; }, { "onContentReady": "onContentReady"; "onDisposing": "onDisposing"; "onHidden": "onHidden"; "onHiding": "onHiding"; "onInitialized": "onInitialized"; "onOptionChanged": "onOptionChanged"; "onResize": "onResize"; "onResizeEnd": "onResizeEnd"; "onResizeStart": "onResizeStart"; "onShowing": "onShowing"; "onShown": "onShown"; "onTitleRendered": "onTitleRendered"; "accessKeyChange": "accessKeyChange"; "animationChange": "animationChange"; "containerChange": "containerChange"; "contentTemplateChange": "contentTemplateChange"; "deferRenderingChange": "deferRenderingChange"; "disabledChange": "disabledChange"; "dragAndResizeAreaChange": "dragAndResizeAreaChange"; "dragEnabledChange": "dragEnabledChange"; "dragOutsideBoundaryChange": "dragOutsideBoundaryChange"; "enableBodyScrollChange": "enableBodyScrollChange"; "focusStateEnabledChange": "focusStateEnabledChange"; "fullScreenChange": "fullScreenChange"; "heightChange": "heightChange"; "hideOnOutsideClickChange": "hideOnOutsideClickChange"; "hideOnParentScrollChange": "hideOnParentScrollChange"; "hintChange": "hintChange"; "hoverStateEnabledChange": "hoverStateEnabledChange"; "maxHeightChange": "maxHeightChange"; "maxWidthChange": "maxWidthChange"; "minHeightChange": "minHeightChange"; "minWidthChange": "minWidthChange"; "positionChange": "positionChange"; "resizeEnabledChange": "resizeEnabledChange"; "restorePositionChange": "restorePositionChange"; "rtlEnabledChange": "rtlEnabledChange"; "shadingChange": "shadingChange"; "shadingColorChange": "shadingColorChange"; "showCloseButtonChange": "showCloseButtonChange"; "showTitleChange": "showTitleChange"; "tabFocusLoopEnabledChange": "tabFocusLoopEnabledChange"; "tabIndexChange": "tabIndexChange"; "titleChange": "titleChange"; "titleTemplateChange": "titleTemplateChange"; "toolbarItemsChange": "toolbarItemsChange"; "visibleChange": "visibleChange"; "widthChange": "widthChange"; "wrapperAttrChange": "wrapperAttrChange"; }, ["_toolbarItemsContentChildren"], ["*"], true, never>;
}
declare class DxPopupModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxPopupModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxPopupModule, never, [typeof DxPopupComponent, typeof i1.DxoAnimationModule, typeof i1.DxoHideModule, typeof i1.DxoFromModule, typeof i1.DxoPositionModule, typeof i1.DxoAtModule, typeof i1.DxoBoundaryOffsetModule, typeof i1.DxoCollisionModule, typeof i1.DxoMyModule, typeof i1.DxoOffsetModule, typeof i1.DxoToModule, typeof i1.DxoShowModule, typeof i2.DxoPopupAnimationModule, typeof i2.DxoPopupAtModule, typeof i2.DxoPopupBoundaryOffsetModule, typeof i2.DxoPopupCollisionModule, typeof i2.DxoPopupFromModule, typeof i2.DxoPopupHideModule, typeof i2.DxoPopupMyModule, typeof i2.DxoPopupOffsetModule, typeof i2.DxoPopupPositionModule, typeof i2.DxoPopupShowModule, typeof i2.DxoPopupToModule, typeof i2.DxiPopupToolbarItemModule, typeof i3.DxIntegrationModule, typeof i3.DxTemplateModule], [typeof DxPopupComponent, typeof i1.DxoAnimationModule, typeof i1.DxoHideModule, typeof i1.DxoFromModule, typeof i1.DxoPositionModule, typeof i1.DxoAtModule, typeof i1.DxoBoundaryOffsetModule, typeof i1.DxoCollisionModule, typeof i1.DxoMyModule, typeof i1.DxoOffsetModule, typeof i1.DxoToModule, typeof i1.DxoShowModule, typeof i2.DxoPopupAnimationModule, typeof i2.DxoPopupAtModule, typeof i2.DxoPopupBoundaryOffsetModule, typeof i2.DxoPopupCollisionModule, typeof i2.DxoPopupFromModule, typeof i2.DxoPopupHideModule, typeof i2.DxoPopupMyModule, typeof i2.DxoPopupOffsetModule, typeof i2.DxoPopupPositionModule, typeof i2.DxoPopupShowModule, typeof i2.DxoPopupToModule, typeof i2.DxiPopupToolbarItemModule, typeof i3.DxTemplateModule]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxPopupModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

type DxPopupServiceComponent<T = any> = DxPopupComponent & {
    contentRef: ComponentRef<T>;
};
declare class DxPopupService {
    private readonly injector;
    private readonly applicationRef;
    private readonly rendererFactory;
    constructor(injector: Injector, applicationRef: ApplicationRef, rendererFactory: RendererFactory2);
    open<T>(contentComponent: Type<T>, popupOptions?: DxPopupTypes.Properties): DxPopupServiceComponent<T>;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxPopupService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<DxPopupService>;
}

export { DxPopupComponent, DxPopupModule, DxPopupService };
export type { DxPopupServiceComponent };
//# sourceMappingURL=index.d.ts.map
