import * as i0 from '@angular/core';
import { OnDestroy, OnChanges, DoCheck, QueryList, EventEmitter, ElementRef, NgZone, TransferState, SimpleChanges } from '@angular/core';
import DxNumberBox, { NumberBoxPredefinedButton, NumberBoxType, ChangeEvent, ContentReadyEvent, CopyEvent, CutEvent, DisposingEvent, EnterKeyEvent, FocusInEvent, FocusOutEvent, InitializedEvent, InputEvent, KeyDownEvent, KeyUpEvent, OptionChangedEvent, PasteEvent, ValueChangedEvent } from 'devextreme/ui/number_box';
import { TextEditorButton, LabelMode, EditorStyle, ValidationMessageMode, Position, ValidationStatus } from 'devextreme/common';
import { Format } from 'devextreme/common/core/localization';
import { ControlValueAccessor } from '@angular/forms';
import * as i3 from 'devextreme-angular/core';
import { DxComponent, CollectionNestedOption, DxTemplateHost, WatcherHelper, IterableDifferHelper, NestedOptionHost } from 'devextreme-angular/core';
import * as i1 from 'devextreme-angular/ui/nested';
import * as i2 from 'devextreme-angular/ui/number-box/nested';
export * from 'devextreme-angular/ui/number-box/nested';
import * as number_box_types from 'devextreme/ui/number_box_types';
export { number_box_types as DxNumberBoxTypes };

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

/**
 * [descr:dxNumberBox]

 */
declare class DxNumberBoxComponent extends DxComponent implements OnDestroy, ControlValueAccessor, OnChanges, DoCheck {
    private _watcherHelper;
    private _idh;
    set _buttonsContentChildren(value: QueryList<CollectionNestedOption>);
    instance: DxNumberBox;
    /**
     * [descr:WidgetOptions.accessKey]
    
     */
    get accessKey(): string | undefined;
    set accessKey(value: string | undefined);
    /**
     * [descr:WidgetOptions.activeStateEnabled]
    
     */
    get activeStateEnabled(): boolean;
    set activeStateEnabled(value: boolean);
    /**
     * [descr:dxNumberBoxOptions.buttons]
    
     */
    get buttons(): Array<NumberBoxPredefinedButton | TextEditorButton> | undefined;
    set buttons(value: Array<NumberBoxPredefinedButton | TextEditorButton> | undefined);
    /**
     * [descr:WidgetOptions.disabled]
    
     */
    get disabled(): boolean;
    set disabled(value: boolean);
    /**
     * [descr:DOMComponentOptions.elementAttr]
    
     */
    get elementAttr(): Record<string, any>;
    set elementAttr(value: Record<string, any>);
    /**
     * [descr:dxTextEditorOptions.focusStateEnabled]
    
     */
    get focusStateEnabled(): boolean;
    set focusStateEnabled(value: boolean);
    /**
     * [descr:dxNumberBoxOptions.format]
    
     */
    get format(): Format;
    set format(value: Format);
    /**
     * [descr:DOMComponentOptions.height]
    
     */
    get height(): number | string | undefined;
    set height(value: number | string | undefined);
    /**
     * [descr:WidgetOptions.hint]
    
     */
    get hint(): string | undefined;
    set hint(value: string | undefined);
    /**
     * [descr:dxTextEditorOptions.hoverStateEnabled]
    
     */
    get hoverStateEnabled(): boolean;
    set hoverStateEnabled(value: boolean);
    /**
     * [descr:dxTextEditorOptions.inputAttr]
    
     */
    get inputAttr(): any;
    set inputAttr(value: any);
    /**
     * [descr:dxNumberBoxOptions.invalidValueMessage]
    
     */
    get invalidValueMessage(): string;
    set invalidValueMessage(value: string);
    /**
     * [descr:EditorOptions.isDirty]
    
     */
    get isDirty(): boolean;
    set isDirty(value: boolean);
    /**
     * [descr:EditorOptions.isValid]
    
     */
    get isValid(): boolean;
    set isValid(value: boolean);
    /**
     * [descr:dxTextEditorOptions.label]
    
     */
    get label(): string;
    set label(value: string);
    /**
     * [descr:dxTextEditorOptions.labelMode]
    
     */
    get labelMode(): LabelMode;
    set labelMode(value: LabelMode);
    /**
     * [descr:dxNumberBoxOptions.max]
    
     */
    get max(): number | undefined;
    set max(value: number | undefined);
    /**
     * [descr:dxNumberBoxOptions.min]
    
     */
    get min(): number | undefined;
    set min(value: number | undefined);
    /**
     * [descr:dxNumberBoxOptions.mode]
    
     */
    get mode(): NumberBoxType;
    set mode(value: NumberBoxType);
    /**
     * [descr:dxTextEditorOptions.name]
    
     */
    get name(): string;
    set name(value: string);
    /**
     * [descr:dxTextEditorOptions.placeholder]
    
     */
    get placeholder(): string;
    set placeholder(value: string);
    /**
     * [descr:EditorOptions.readOnly]
    
     */
    get readOnly(): boolean;
    set readOnly(value: boolean);
    /**
     * [descr:DOMComponentOptions.rtlEnabled]
    
     */
    get rtlEnabled(): boolean;
    set rtlEnabled(value: boolean);
    /**
     * [descr:dxTextEditorOptions.showClearButton]
    
     */
    get showClearButton(): boolean;
    set showClearButton(value: boolean);
    /**
     * [descr:dxNumberBoxOptions.showSpinButtons]
    
     */
    get showSpinButtons(): boolean;
    set showSpinButtons(value: boolean);
    /**
     * [descr:dxNumberBoxOptions.step]
    
     */
    get step(): number;
    set step(value: number);
    /**
     * [descr:dxTextEditorOptions.stylingMode]
    
     */
    get stylingMode(): EditorStyle;
    set stylingMode(value: EditorStyle);
    /**
     * [descr:WidgetOptions.tabIndex]
    
     */
    get tabIndex(): number;
    set tabIndex(value: number);
    /**
     * [descr:dxTextEditorOptions.text]
    
     */
    get text(): string;
    set text(value: string);
    /**
     * [descr:dxNumberBoxOptions.useLargeSpinButtons]
    
     */
    get useLargeSpinButtons(): boolean;
    set useLargeSpinButtons(value: boolean);
    /**
     * [descr:EditorOptions.validationError]
    
     */
    get validationError(): any | null;
    set validationError(value: any | null);
    /**
     * [descr:EditorOptions.validationErrors]
    
     */
    get validationErrors(): Array<any> | null;
    set validationErrors(value: Array<any> | null);
    /**
     * [descr:EditorOptions.validationMessageMode]
    
     */
    get validationMessageMode(): ValidationMessageMode;
    set validationMessageMode(value: ValidationMessageMode);
    /**
     * [descr:EditorOptions.validationMessagePosition]
    
     */
    get validationMessagePosition(): Position;
    set validationMessagePosition(value: Position);
    /**
     * [descr:EditorOptions.validationStatus]
    
     */
    get validationStatus(): ValidationStatus;
    set validationStatus(value: ValidationStatus);
    /**
     * [descr:dxNumberBoxOptions.value]
    
     */
    get value(): number;
    set value(value: number);
    /**
     * [descr:dxTextEditorOptions.valueChangeEvent]
    
     */
    get valueChangeEvent(): string;
    set valueChangeEvent(value: string);
    /**
     * [descr:WidgetOptions.visible]
    
     */
    get visible(): boolean;
    set visible(value: boolean);
    /**
     * [descr:DOMComponentOptions.width]
    
     */
    get width(): number | string | undefined;
    set width(value: number | string | undefined);
    /**
    
     * [descr:dxNumberBoxOptions.onChange]
    
    
     */
    onChange: EventEmitter<ChangeEvent>;
    /**
    
     * [descr:dxNumberBoxOptions.onContentReady]
    
    
     */
    onContentReady: EventEmitter<ContentReadyEvent>;
    /**
    
     * [descr:dxNumberBoxOptions.onCopy]
    
    
     */
    onCopy: EventEmitter<CopyEvent>;
    /**
    
     * [descr:dxNumberBoxOptions.onCut]
    
    
     */
    onCut: EventEmitter<CutEvent>;
    /**
    
     * [descr:dxNumberBoxOptions.onDisposing]
    
    
     */
    onDisposing: EventEmitter<DisposingEvent>;
    /**
    
     * [descr:dxNumberBoxOptions.onEnterKey]
    
    
     */
    onEnterKey: EventEmitter<EnterKeyEvent>;
    /**
    
     * [descr:dxNumberBoxOptions.onFocusIn]
    
    
     */
    onFocusIn: EventEmitter<FocusInEvent>;
    /**
    
     * [descr:dxNumberBoxOptions.onFocusOut]
    
    
     */
    onFocusOut: EventEmitter<FocusOutEvent>;
    /**
    
     * [descr:dxNumberBoxOptions.onInitialized]
    
    
     */
    onInitialized: EventEmitter<InitializedEvent>;
    /**
    
     * [descr:dxNumberBoxOptions.onInput]
    
    
     */
    onInput: EventEmitter<InputEvent>;
    /**
    
     * [descr:dxNumberBoxOptions.onKeyDown]
    
    
     */
    onKeyDown: EventEmitter<KeyDownEvent>;
    /**
    
     * [descr:dxNumberBoxOptions.onKeyUp]
    
    
     */
    onKeyUp: EventEmitter<KeyUpEvent>;
    /**
    
     * [descr:dxNumberBoxOptions.onOptionChanged]
    
    
     */
    onOptionChanged: EventEmitter<OptionChangedEvent>;
    /**
    
     * [descr:dxNumberBoxOptions.onPaste]
    
    
     */
    onPaste: EventEmitter<PasteEvent>;
    /**
    
     * [descr:dxNumberBoxOptions.onValueChanged]
    
    
     */
    onValueChanged: EventEmitter<ValueChangedEvent>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    accessKeyChange: EventEmitter<string | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    activeStateEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    buttonsChange: EventEmitter<Array<NumberBoxPredefinedButton | TextEditorButton> | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    disabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    elementAttrChange: EventEmitter<Record<string, any>>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    focusStateEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    formatChange: EventEmitter<Format>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    heightChange: EventEmitter<number | string | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    hintChange: EventEmitter<string | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    hoverStateEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    inputAttrChange: EventEmitter<any>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    invalidValueMessageChange: EventEmitter<string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    isDirtyChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    isValidChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    labelChange: EventEmitter<string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    labelModeChange: EventEmitter<LabelMode>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    maxChange: EventEmitter<number | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    minChange: EventEmitter<number | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    modeChange: EventEmitter<NumberBoxType>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    nameChange: EventEmitter<string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    placeholderChange: EventEmitter<string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    readOnlyChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    rtlEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    showClearButtonChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    showSpinButtonsChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    stepChange: EventEmitter<number>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    stylingModeChange: EventEmitter<EditorStyle>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    tabIndexChange: EventEmitter<number>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    textChange: EventEmitter<string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    useLargeSpinButtonsChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    validationErrorChange: EventEmitter<any | null>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    validationErrorsChange: EventEmitter<Array<any> | null>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    validationMessageModeChange: EventEmitter<ValidationMessageMode>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    validationMessagePositionChange: EventEmitter<Position>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    validationStatusChange: EventEmitter<ValidationStatus>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    valueChange: EventEmitter<number>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    valueChangeEventChange: EventEmitter<string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    visibleChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    widthChange: EventEmitter<number | string | undefined>;
    /**
    
     * [descr:undefined]
    
    
     */
    onBlur: EventEmitter<any>;
    change(_: any): void;
    touched: (_: any) => void;
    constructor(elementRef: ElementRef, ngZone: NgZone, templateHost: DxTemplateHost, _watcherHelper: WatcherHelper, _idh: IterableDifferHelper, optionHost: NestedOptionHost, transferState: TransferState, platformId: any);
    protected _createInstance(element: any, options: any): DxNumberBox;
    writeValue(value: any): void;
    setDisabledState(isDisabled: boolean): void;
    registerOnChange(fn: (_: any) => void): void;
    registerOnTouched(fn: () => void): void;
    _createWidget(element: any): void;
    ngOnDestroy(): void;
    ngOnChanges(changes: SimpleChanges): void;
    setupChanges(prop: string, changes: SimpleChanges): void;
    ngDoCheck(): void;
    _setOption(name: string, value: any): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxNumberBoxComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxNumberBoxComponent, "dx-number-box", never, { "accessKey": { "alias": "accessKey"; "required": false; }; "activeStateEnabled": { "alias": "activeStateEnabled"; "required": false; }; "buttons": { "alias": "buttons"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "elementAttr": { "alias": "elementAttr"; "required": false; }; "focusStateEnabled": { "alias": "focusStateEnabled"; "required": false; }; "format": { "alias": "format"; "required": false; }; "height": { "alias": "height"; "required": false; }; "hint": { "alias": "hint"; "required": false; }; "hoverStateEnabled": { "alias": "hoverStateEnabled"; "required": false; }; "inputAttr": { "alias": "inputAttr"; "required": false; }; "invalidValueMessage": { "alias": "invalidValueMessage"; "required": false; }; "isDirty": { "alias": "isDirty"; "required": false; }; "isValid": { "alias": "isValid"; "required": false; }; "label": { "alias": "label"; "required": false; }; "labelMode": { "alias": "labelMode"; "required": false; }; "max": { "alias": "max"; "required": false; }; "min": { "alias": "min"; "required": false; }; "mode": { "alias": "mode"; "required": false; }; "name": { "alias": "name"; "required": false; }; "placeholder": { "alias": "placeholder"; "required": false; }; "readOnly": { "alias": "readOnly"; "required": false; }; "rtlEnabled": { "alias": "rtlEnabled"; "required": false; }; "showClearButton": { "alias": "showClearButton"; "required": false; }; "showSpinButtons": { "alias": "showSpinButtons"; "required": false; }; "step": { "alias": "step"; "required": false; }; "stylingMode": { "alias": "stylingMode"; "required": false; }; "tabIndex": { "alias": "tabIndex"; "required": false; }; "text": { "alias": "text"; "required": false; }; "useLargeSpinButtons": { "alias": "useLargeSpinButtons"; "required": false; }; "validationError": { "alias": "validationError"; "required": false; }; "validationErrors": { "alias": "validationErrors"; "required": false; }; "validationMessageMode": { "alias": "validationMessageMode"; "required": false; }; "validationMessagePosition": { "alias": "validationMessagePosition"; "required": false; }; "validationStatus": { "alias": "validationStatus"; "required": false; }; "value": { "alias": "value"; "required": false; }; "valueChangeEvent": { "alias": "valueChangeEvent"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, { "onChange": "onChange"; "onContentReady": "onContentReady"; "onCopy": "onCopy"; "onCut": "onCut"; "onDisposing": "onDisposing"; "onEnterKey": "onEnterKey"; "onFocusIn": "onFocusIn"; "onFocusOut": "onFocusOut"; "onInitialized": "onInitialized"; "onInput": "onInput"; "onKeyDown": "onKeyDown"; "onKeyUp": "onKeyUp"; "onOptionChanged": "onOptionChanged"; "onPaste": "onPaste"; "onValueChanged": "onValueChanged"; "accessKeyChange": "accessKeyChange"; "activeStateEnabledChange": "activeStateEnabledChange"; "buttonsChange": "buttonsChange"; "disabledChange": "disabledChange"; "elementAttrChange": "elementAttrChange"; "focusStateEnabledChange": "focusStateEnabledChange"; "formatChange": "formatChange"; "heightChange": "heightChange"; "hintChange": "hintChange"; "hoverStateEnabledChange": "hoverStateEnabledChange"; "inputAttrChange": "inputAttrChange"; "invalidValueMessageChange": "invalidValueMessageChange"; "isDirtyChange": "isDirtyChange"; "isValidChange": "isValidChange"; "labelChange": "labelChange"; "labelModeChange": "labelModeChange"; "maxChange": "maxChange"; "minChange": "minChange"; "modeChange": "modeChange"; "nameChange": "nameChange"; "placeholderChange": "placeholderChange"; "readOnlyChange": "readOnlyChange"; "rtlEnabledChange": "rtlEnabledChange"; "showClearButtonChange": "showClearButtonChange"; "showSpinButtonsChange": "showSpinButtonsChange"; "stepChange": "stepChange"; "stylingModeChange": "stylingModeChange"; "tabIndexChange": "tabIndexChange"; "textChange": "textChange"; "useLargeSpinButtonsChange": "useLargeSpinButtonsChange"; "validationErrorChange": "validationErrorChange"; "validationErrorsChange": "validationErrorsChange"; "validationMessageModeChange": "validationMessageModeChange"; "validationMessagePositionChange": "validationMessagePositionChange"; "validationStatusChange": "validationStatusChange"; "valueChange": "valueChange"; "valueChangeEventChange": "valueChangeEventChange"; "visibleChange": "visibleChange"; "widthChange": "widthChange"; "onBlur": "onBlur"; }, ["_buttonsContentChildren"], never, true, never>;
}
declare class DxNumberBoxModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxNumberBoxModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxNumberBoxModule, never, [typeof DxNumberBoxComponent, typeof i1.DxiButtonModule, typeof i1.DxoOptionsModule, typeof i1.DxoFormatModule, typeof i2.DxiNumberBoxButtonModule, typeof i2.DxoNumberBoxFormatModule, typeof i2.DxoNumberBoxOptionsModule, typeof i3.DxIntegrationModule, typeof i3.DxTemplateModule], [typeof DxNumberBoxComponent, typeof i1.DxiButtonModule, typeof i1.DxoOptionsModule, typeof i1.DxoFormatModule, typeof i2.DxiNumberBoxButtonModule, typeof i2.DxoNumberBoxFormatModule, typeof i2.DxoNumberBoxOptionsModule, typeof i3.DxTemplateModule]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxNumberBoxModule>;
}

export { DxNumberBoxComponent, DxNumberBoxModule };
//# sourceMappingURL=index.d.ts.map
