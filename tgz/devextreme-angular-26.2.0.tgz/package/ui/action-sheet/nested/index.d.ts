import * as i0 from '@angular/core';
import { AfterViewInit, Renderer2, ElementRef } from '@angular/core';
import { NativeEventInfo } from 'devextreme/common/core/events';
import { ButtonStyle, ButtonType } from 'devextreme/common';
import { CollectionNestedOption, IDxTemplateHost, NestedOptionHost, DxTemplateHost, DxTemplateDirective } from 'devextreme-angular/core';

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxiActionSheetItemComponent extends CollectionNestedOption implements AfterViewInit, IDxTemplateHost {
    private renderer;
    private document;
    private element;
    get disabled(): boolean;
    set disabled(value: boolean);
    get icon(): string;
    set icon(value: string);
    get onClick(): ((e: NativeEventInfo<any>) => void);
    set onClick(value: ((e: NativeEventInfo<any>) => void));
    get stylingMode(): ButtonStyle;
    set stylingMode(value: ButtonStyle);
    get template(): any;
    set template(value: any);
    get text(): string;
    set text(value: string);
    get type(): ButtonType | string;
    set type(value: ButtonType | string);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost, renderer: Renderer2, document: any, templateHost: DxTemplateHost, element: ElementRef);
    setTemplate(template: DxTemplateDirective): void;
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiActionSheetItemComponent, [{ host: true; skipSelf: true; }, { host: true; }, null, null, { host: true; }, null]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiActionSheetItemComponent, "dxi-action-sheet-item", never, { "disabled": { "alias": "disabled"; "required": false; }; "icon": { "alias": "icon"; "required": false; }; "onClick": { "alias": "onClick"; "required": false; }; "stylingMode": { "alias": "stylingMode"; "required": false; }; "template": { "alias": "template"; "required": false; }; "text": { "alias": "text"; "required": false; }; "type": { "alias": "type"; "required": false; }; }, {}, never, ["*"], true, never>;
}
declare class DxiActionSheetItemModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiActionSheetItemModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiActionSheetItemModule, never, [typeof DxiActionSheetItemComponent], [typeof DxiActionSheetItemComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiActionSheetItemModule>;
}

export { DxiActionSheetItemComponent, DxiActionSheetItemModule };
//# sourceMappingURL=index.d.ts.map
