import * as i0 from '@angular/core';
import { OnDestroy, OnChanges, DoCheck, QueryList, EventEmitter, ElementRef, NgZone, TransferState, SimpleChanges } from '@angular/core';
import DxActionSheet, { dxActionSheetItem, CancelClickEvent, ContentReadyEvent, DisposingEvent, InitializedEvent, ItemClickEvent, ItemContextMenuEvent, ItemHoldEvent, ItemRenderedEvent, OptionChangedEvent } from 'devextreme/ui/action_sheet';
export { ExplicitTypes } from 'devextreme/ui/action_sheet';
import DataSource, { DataSourceOptions } from 'devextreme/data/data_source';
import { Store } from 'devextreme/data/store';
import * as i3 from 'devextreme-angular/core';
import { DxComponent, CollectionNestedOption, DxTemplateHost, WatcherHelper, IterableDifferHelper, NestedOptionHost } from 'devextreme-angular/core';
import * as i1 from 'devextreme-angular/ui/nested';
import * as i2 from 'devextreme-angular/ui/action-sheet/nested';
export * from 'devextreme-angular/ui/action-sheet/nested';
import * as action_sheet_types from 'devextreme/ui/action_sheet_types';
export { action_sheet_types as DxActionSheetTypes };

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

/**
 * [descr:dxActionSheet]

 */
declare class DxActionSheetComponent<TItem = any, TKey = any> extends DxComponent implements OnDestroy, OnChanges, DoCheck {
    private _watcherHelper;
    private _idh;
    set _itemsContentChildren(value: QueryList<CollectionNestedOption>);
    instance: DxActionSheet<TItem, TKey>;
    /**
     * [descr:dxActionSheetOptions.cancelText]
    
     */
    get cancelText(): string;
    set cancelText(value: string);
    /**
     * [descr:dxActionSheetOptions.dataSource]
    
     */
    get dataSource(): Array<any | dxActionSheetItem | string> | DataSource | DataSourceOptions | null | Store | string;
    set dataSource(value: Array<any | dxActionSheetItem | string> | DataSource | DataSourceOptions | null | Store | string);
    /**
     * [descr:WidgetOptions.disabled]
    
     */
    get disabled(): boolean;
    set disabled(value: boolean);
    /**
     * [descr:DOMComponentOptions.elementAttr]
    
     */
    get elementAttr(): Record<string, any>;
    set elementAttr(value: Record<string, any>);
    /**
     * [descr:DOMComponentOptions.height]
    
     */
    get height(): number | string | undefined;
    set height(value: number | string | undefined);
    /**
     * [descr:WidgetOptions.hint]
    
     */
    get hint(): string | undefined;
    set hint(value: string | undefined);
    /**
     * [descr:WidgetOptions.hoverStateEnabled]
    
     */
    get hoverStateEnabled(): boolean;
    set hoverStateEnabled(value: boolean);
    /**
     * [descr:CollectionWidgetOptions.itemHoldTimeout]
    
     */
    get itemHoldTimeout(): number;
    set itemHoldTimeout(value: number);
    /**
     * [descr:dxActionSheetOptions.items]
    
     */
    get items(): Array<any | dxActionSheetItem | string>;
    set items(value: Array<any | dxActionSheetItem | string>);
    /**
     * [descr:CollectionWidgetOptions.itemTemplate]
    
     */
    get itemTemplate(): any;
    set itemTemplate(value: any);
    /**
     * [descr:DOMComponentOptions.rtlEnabled]
    
     */
    get rtlEnabled(): boolean;
    set rtlEnabled(value: boolean);
    /**
     * [descr:dxActionSheetOptions.showCancelButton]
    
     */
    get showCancelButton(): boolean;
    set showCancelButton(value: boolean);
    /**
     * [descr:dxActionSheetOptions.showTitle]
    
     */
    get showTitle(): boolean;
    set showTitle(value: boolean);
    /**
     * [descr:dxActionSheetOptions.target]
    
     */
    get target(): any | string;
    set target(value: any | string);
    /**
     * [descr:dxActionSheetOptions.title]
    
     */
    get title(): string;
    set title(value: string);
    /**
     * [descr:dxActionSheetOptions.usePopover]
    
     */
    get usePopover(): boolean;
    set usePopover(value: boolean);
    /**
     * [descr:dxActionSheetOptions.visible]
    
     */
    get visible(): boolean;
    set visible(value: boolean);
    /**
     * [descr:DOMComponentOptions.width]
    
     */
    get width(): number | string | undefined;
    set width(value: number | string | undefined);
    /**
    
     * [descr:dxActionSheetOptions.onCancelClick]
    
    
     */
    onCancelClick: EventEmitter<CancelClickEvent>;
    /**
    
     * [descr:dxActionSheetOptions.onContentReady]
    
    
     */
    onContentReady: EventEmitter<ContentReadyEvent>;
    /**
    
     * [descr:dxActionSheetOptions.onDisposing]
    
    
     */
    onDisposing: EventEmitter<DisposingEvent>;
    /**
    
     * [descr:dxActionSheetOptions.onInitialized]
    
    
     */
    onInitialized: EventEmitter<InitializedEvent>;
    /**
    
     * [descr:dxActionSheetOptions.onItemClick]
    
    
     */
    onItemClick: EventEmitter<ItemClickEvent>;
    /**
    
     * [descr:dxActionSheetOptions.onItemContextMenu]
    
    
     */
    onItemContextMenu: EventEmitter<ItemContextMenuEvent>;
    /**
    
     * [descr:dxActionSheetOptions.onItemHold]
    
    
     */
    onItemHold: EventEmitter<ItemHoldEvent>;
    /**
    
     * [descr:dxActionSheetOptions.onItemRendered]
    
    
     */
    onItemRendered: EventEmitter<ItemRenderedEvent>;
    /**
    
     * [descr:dxActionSheetOptions.onOptionChanged]
    
    
     */
    onOptionChanged: EventEmitter<OptionChangedEvent>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    cancelTextChange: EventEmitter<string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    dataSourceChange: EventEmitter<Array<any | dxActionSheetItem | string> | DataSource | DataSourceOptions | null | Store | string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    disabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    elementAttrChange: EventEmitter<Record<string, any>>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    heightChange: EventEmitter<number | string | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    hintChange: EventEmitter<string | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    hoverStateEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    itemHoldTimeoutChange: EventEmitter<number>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    itemsChange: EventEmitter<Array<any | dxActionSheetItem | string>>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    itemTemplateChange: EventEmitter<any>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    rtlEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    showCancelButtonChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    showTitleChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    targetChange: EventEmitter<any | string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    titleChange: EventEmitter<string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    usePopoverChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    visibleChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    widthChange: EventEmitter<number | string | undefined>;
    constructor(elementRef: ElementRef, ngZone: NgZone, templateHost: DxTemplateHost, _watcherHelper: WatcherHelper, _idh: IterableDifferHelper, optionHost: NestedOptionHost, transferState: TransferState, platformId: any);
    protected _createInstance(element: any, options: any): DxActionSheet<any, any>;
    ngOnDestroy(): void;
    ngOnChanges(changes: SimpleChanges): void;
    setupChanges(prop: string, changes: SimpleChanges): void;
    ngDoCheck(): void;
    _setOption(name: string, value: any): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxActionSheetComponent<any, any>, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxActionSheetComponent<any, any>, "dx-action-sheet", never, { "cancelText": { "alias": "cancelText"; "required": false; }; "dataSource": { "alias": "dataSource"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "elementAttr": { "alias": "elementAttr"; "required": false; }; "height": { "alias": "height"; "required": false; }; "hint": { "alias": "hint"; "required": false; }; "hoverStateEnabled": { "alias": "hoverStateEnabled"; "required": false; }; "itemHoldTimeout": { "alias": "itemHoldTimeout"; "required": false; }; "items": { "alias": "items"; "required": false; }; "itemTemplate": { "alias": "itemTemplate"; "required": false; }; "rtlEnabled": { "alias": "rtlEnabled"; "required": false; }; "showCancelButton": { "alias": "showCancelButton"; "required": false; }; "showTitle": { "alias": "showTitle"; "required": false; }; "target": { "alias": "target"; "required": false; }; "title": { "alias": "title"; "required": false; }; "usePopover": { "alias": "usePopover"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, { "onCancelClick": "onCancelClick"; "onContentReady": "onContentReady"; "onDisposing": "onDisposing"; "onInitialized": "onInitialized"; "onItemClick": "onItemClick"; "onItemContextMenu": "onItemContextMenu"; "onItemHold": "onItemHold"; "onItemRendered": "onItemRendered"; "onOptionChanged": "onOptionChanged"; "cancelTextChange": "cancelTextChange"; "dataSourceChange": "dataSourceChange"; "disabledChange": "disabledChange"; "elementAttrChange": "elementAttrChange"; "heightChange": "heightChange"; "hintChange": "hintChange"; "hoverStateEnabledChange": "hoverStateEnabledChange"; "itemHoldTimeoutChange": "itemHoldTimeoutChange"; "itemsChange": "itemsChange"; "itemTemplateChange": "itemTemplateChange"; "rtlEnabledChange": "rtlEnabledChange"; "showCancelButtonChange": "showCancelButtonChange"; "showTitleChange": "showTitleChange"; "targetChange": "targetChange"; "titleChange": "titleChange"; "usePopoverChange": "usePopoverChange"; "visibleChange": "visibleChange"; "widthChange": "widthChange"; }, ["_itemsContentChildren"], never, true, never>;
}
declare class DxActionSheetModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxActionSheetModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxActionSheetModule, never, [typeof DxActionSheetComponent, typeof i1.DxiItemModule, typeof i2.DxiActionSheetItemModule, typeof i3.DxIntegrationModule, typeof i3.DxTemplateModule], [typeof DxActionSheetComponent, typeof i1.DxiItemModule, typeof i2.DxiActionSheetItemModule, typeof i3.DxTemplateModule]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxActionSheetModule>;
}

export { DxActionSheetComponent, DxActionSheetModule };
//# sourceMappingURL=index.d.ts.map
