import * as i0 from '@angular/core';
import { OnDestroy, OnInit, QueryList, EventEmitter, AfterViewInit, Renderer2, ElementRef } from '@angular/core';
import { NestedOption, NestedOptionHost, CollectionNestedOption, IDxTemplateHost, DxTemplateHost, DxTemplateDirective } from 'devextreme-angular/core';
import { ChartSeriesAggregationMethod, FinancialChartReductionLevel, AggregatedPointsPosition, ChartLabelDisplayMode, ChartTooltipLocation, ChartZoomAndPanMode, EventKeyModifier } from 'devextreme/viz/chart';
import { AnimationEaseMode, DashStyle, Font, TextOverflow, AnnotationType, WordWrap, ChartsColor, SeriesHoverMode, HatchDirection, RelativePosition, LabelPosition, PointInteractionMode, PointSymbol, SeriesSelectionMode, SeriesType, ValueErrorBarDisplayMode, ValueErrorBarType, ChartsDataType, TimeInterval, ScaleBreak, ScaleBreakLineStyle, DiscreteAxisDivisionMode, ArgumentAxisHoverMode, ChartsAxisLabelOverlap, LabelOverlap, AxisScaleType, VisualRange, VisualRangeUpdateMode, Palette, PaletteExtensionMode, LegendHoverMode, ValueAxisVisualRangeUpdateMode } from 'devextreme/common/charts';
import { AnimationConfig, CollisionResolution, PositionConfig, AnimationState, AnimationType, CollisionResolutionCombination } from 'devextreme/common/core/animation';
import { PieChartAnnotationLocation, PieChartSeriesInteractionMode, SmallValuesGroupingMode, PieChartLegendHoverMode } from 'devextreme/viz/pie_chart';
import { HorizontalAlignment, VerticalAlignment, Position, Format as Format$1, Orientation, SliderValueChangeMode, TextEditorButtonLocation, ButtonStyle, ButtonType, DayOfWeek, ValidationMessageMode, ValidationStatus, SortOrder, DataType, RequiredRule, NumericRule, RangeRule, StringLengthRule, CustomRule, CompareRule, PatternRule, EmailRule, AsyncRule, ToolbarItemLocation, VerticalEdge, PositionAlignment, ExportFormat, FieldChooserLayout, ToolbarItemComponent, Mode, SearchMode, Direction, DragDirection, DragHighlight, HorizontalEdge, SingleMultipleOrNone, DisplayMode, ScrollMode, ScrollbarMode, TextBoxPredefinedButton, TextEditorButton, LabelMode, MaskMode, EditorStyle, SelectAllMode, SubmenuShowMode, TabsIconPosition, TabsStyle, TooltipShowMode, ValidationRuleType, ComparisonOperator } from 'devextreme/common';
import { Format } from 'devextreme/common/core/localization';
import { PolarChartSeriesType } from 'devextreme/viz/polar_chart';
import { DataLayoutType, CustomCommand, Command, ShapeCategory, ToolboxDisplayMode, ShapeType, ConnectorLineEnd, ConnectorLineType, PanelVisibility } from 'devextreme/ui/diagram';
import { BackgroundImageLocation, ChartAxisScale, AxisScale } from 'devextreme/viz/range_selector';
import { Distribution, CrosswiseDistribution, dxBoxItem, BoxDirection, Properties, ContentReadyEvent, DisposingEvent, InitializedEvent, ItemClickEvent, ItemContextMenuEvent, ItemHoldEvent, ItemRenderedEvent, OptionChangedEvent } from 'devextreme/ui/box';
import { Store } from 'devextreme/data';
import DataSource, { Options } from 'devextreme/data/data_source';
import { Properties as Properties$1, ClickEvent, ContentReadyEvent as ContentReadyEvent$1, DisposingEvent as DisposingEvent$1, InitializedEvent as InitializedEvent$1, OptionChangedEvent as OptionChangedEvent$1 } from 'devextreme/ui/button';
import { DataGridPredefinedColumnButton, ColumnButtonClickEvent, dxDataGridColumnButton, dxDataGridColumn, DataGridCommandColumnType, DataGridExportFormat, DataGridPredefinedToolbarItem, DataGridScrollMode, SelectionSensitivity, dxDataGridToolbarItem } from 'devextreme/ui/data_grid';
import { TreeListPredefinedColumnButton, dxTreeListColumnButton, dxTreeListColumn, TreeListCommandColumnType, TreeListPredefinedToolbarItem, dxTreeListToolbarItem } from 'devextreme/ui/tree_list';
import { CalendarZoomLevel, DisposingEvent as DisposingEvent$2, InitializedEvent as InitializedEvent$2, OptionChangedEvent as OptionChangedEvent$2, ValueChangedEvent, CalendarSelectionMode, WeekNumberRule } from 'devextreme/ui/calendar';
import { DataChangeType, ColumnChooserMode, ColumnChooserSearchConfig, ColumnChooserSelectionConfig, FilterOperation, FilterType, FixedPosition, ColumnHeaderFilter, SelectedFilterOperation, DataChange, GridsEditMode, NewRowPosition, GridsEditRefreshMode, StartEditAction, ApplyChangesMode, FilterPanelTexts, ApplyFilterMode, SummaryType, GroupExpandMode, HeaderFilterGroupInterval, ColumnHeaderFilterSearchConfig, HeaderFilterSearchConfig, HeaderFilterTexts, EnterKeyAction, EnterKeyDirection, PagerPageSize, DataRenderMode, SelectionColumnDisplayMode, StateStoreType } from 'devextreme/common/grids';
import { ChartSeries } from 'devextreme/viz/common';
import { TreeMapColorizerType } from 'devextreme/viz/tree_map';
import { UserDefinedElement } from 'devextreme/core/element';
import { SimpleItem, Properties as Properties$2, FormItemComponent, FormItemType, LabelLocation, GroupItem, TabbedItem, EmptyItem, ButtonItem, FormLabelMode, ContentReadyEvent as ContentReadyEvent$4, DisposingEvent as DisposingEvent$5, EditorEnterKeyEvent, FieldDataChangedEvent, InitializedEvent as InitializedEvent$5, OptionChangedEvent as OptionChangedEvent$5 } from 'devextreme/ui/form';
import { AICommandNameExtended, HtmlEditorImageUploadMode, dxHtmlEditorImageUploadTabItem, HtmlEditorImageUploadTab, HtmlEditorPredefinedContextMenuItem, HtmlEditorPredefinedToolbarItem, AICommandName, AICommand, dxHtmlEditorToolbarItem, AIToolbarItem } from 'devextreme/ui/html_editor';
import { dxContextMenuItem } from 'devextreme/ui/context_menu';
import { dxFileManagerContextMenuItem, FileManagerPredefinedContextMenuItem, dxFileManagerDetailsColumn, FileManagerPredefinedToolbarItem, FileManagerItemViewMode, dxFileManagerToolbarItem } from 'devextreme/ui/file_manager';
import { GanttPredefinedContextMenuItem, dxGanttFilterRowOperationDescriptions, dxGanttHeaderFilterTexts, GanttPredefinedToolbarItem, GanttScaleType, dxGanttToolbarItem } from 'devextreme/ui/gantt';
import { dxPopupToolbarItem, Properties as Properties$3, ToolbarLocation } from 'devextreme/ui/popup';
import { FilterBuilderOperation, dxFilterBuilderCustomOperation, dxFilterBuilderField, GroupOperation, ContentReadyEvent as ContentReadyEvent$3, DisposingEvent as DisposingEvent$4, EditorPreparedEvent, EditorPreparingEvent, InitializedEvent as InitializedEvent$4, OptionChangedEvent as OptionChangedEvent$4, ValueChangedEvent as ValueChangedEvent$2 } from 'devextreme/ui/filter_builder';
import { LocateInMenuMode, ShowTextMode } from 'devextreme/ui/toolbar';
import { BeforeSendEvent, ContentReadyEvent as ContentReadyEvent$2, DisposingEvent as DisposingEvent$3, DropZoneEnterEvent, DropZoneLeaveEvent, FilesUploadedEvent, InitializedEvent as InitializedEvent$3, OptionChangedEvent as OptionChangedEvent$3, ProgressEvent, UploadAbortedEvent, UploadedEvent, UploadErrorEvent, UploadStartedEvent, ValueChangedEvent as ValueChangedEvent$1, UploadHttpMethod, FileUploadMode, dxFileUploaderOptions } from 'devextreme/ui/file_uploader';
import { AddEvent, DisposingEvent as DisposingEvent$6, DragChangeEvent, DragEndEvent, DragMoveEvent, DragStartEvent, InitializedEvent as InitializedEvent$6, OptionChangedEvent as OptionChangedEvent$6, RemoveEvent, ReorderEvent } from 'devextreme/ui/sortable';
import { User } from 'devextreme/ui/chat';
import { dxMenuItem } from 'devextreme/ui/menu';
import { Properties as Properties$5, dxSplitterItem, ContentReadyEvent as ContentReadyEvent$6, DisposingEvent as DisposingEvent$8, InitializedEvent as InitializedEvent$8, ItemClickEvent as ItemClickEvent$1, ItemCollapsedEvent, ItemContextMenuEvent as ItemContextMenuEvent$1, ItemExpandedEvent, ItemRenderedEvent as ItemRenderedEvent$1, OptionChangedEvent as OptionChangedEvent$8, ResizeEvent, ResizeEndEvent, ResizeStartEvent } from 'devextreme/ui/splitter';
import { Properties as Properties$4, dxTabPanelItem, ContentReadyEvent as ContentReadyEvent$7, DisposingEvent as DisposingEvent$9, InitializedEvent as InitializedEvent$9, ItemClickEvent as ItemClickEvent$2, ItemContextMenuEvent as ItemContextMenuEvent$2, ItemHoldEvent as ItemHoldEvent$1, ItemRenderedEvent as ItemRenderedEvent$2, OptionChangedEvent as OptionChangedEvent$9, SelectionChangedEvent, SelectionChangingEvent, TitleClickEvent, TitleHoldEvent, TitleRenderedEvent } from 'devextreme/ui/tab_panel';
import { dxTreeViewItem } from 'devextreme/ui/tree_view';
import { CircularGaugeLabelOverlap, CircularGaugeElementOrientation } from 'devextreme/viz/circular_gauge';
import { VectorMapMarkerType, VectorMapLayerType, VectorMapMarkerShape } from 'devextreme/viz/vector_map';
import { SankeyColorMode } from 'devextreme/viz/sankey';
import { RouteMode } from 'devextreme/ui/map';
import { TextBoxType, ChangeEvent, ContentReadyEvent as ContentReadyEvent$5, CopyEvent, CutEvent, DisposingEvent as DisposingEvent$7, EnterKeyEvent, FocusInEvent, FocusOutEvent, InitializedEvent as InitializedEvent$7, InputEvent, KeyDownEvent, KeyUpEvent, OptionChangedEvent as OptionChangedEvent$7, PasteEvent, ValueChangedEvent as ValueChangedEvent$3 } from 'devextreme/ui/text_box';
import { AllDayPanelMode, CellAppointmentsLimit, dxSchedulerScrolling, ViewType } from 'devextreme/ui/scheduler';

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoAdapterComponent extends NestedOption implements OnDestroy, OnInit {
    get applyValidationResults(): Function;
    set applyValidationResults(value: Function);
    get bypass(): Function;
    set bypass(value: Function);
    get focus(): Function;
    set focus(value: Function);
    get getValue(): Function;
    set getValue(value: Function);
    get reset(): Function;
    set reset(value: Function);
    get validationRequestsCallbacks(): Array<Function>;
    set validationRequestsCallbacks(value: Array<Function>);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoAdapterComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoAdapterComponent, "dxo-adapter", never, { "applyValidationResults": { "alias": "applyValidationResults"; "required": false; }; "bypass": { "alias": "bypass"; "required": false; }; "focus": { "alias": "focus"; "required": false; }; "getValue": { "alias": "getValue"; "required": false; }; "reset": { "alias": "reset"; "required": false; }; "validationRequestsCallbacks": { "alias": "validationRequestsCallbacks"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoAdapterModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoAdapterModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoAdapterModule, never, [typeof DxoAdapterComponent], [typeof DxoAdapterComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoAdapterModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoAdaptiveLayoutComponent extends NestedOption implements OnDestroy, OnInit {
    get height(): number;
    set height(value: number);
    get keepLabels(): boolean;
    set keepLabels(value: boolean);
    get width(): number;
    set width(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoAdaptiveLayoutComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoAdaptiveLayoutComponent, "dxo-adaptive-layout", never, { "height": { "alias": "height"; "required": false; }; "keepLabels": { "alias": "keepLabels"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoAdaptiveLayoutModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoAdaptiveLayoutModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoAdaptiveLayoutModule, never, [typeof DxoAdaptiveLayoutComponent], [typeof DxoAdaptiveLayoutComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoAdaptiveLayoutModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoAggregationIntervalComponent extends NestedOption implements OnDestroy, OnInit {
    get days(): number;
    set days(value: number);
    get hours(): number;
    set hours(value: number);
    get milliseconds(): number;
    set milliseconds(value: number);
    get minutes(): number;
    set minutes(value: number);
    get months(): number;
    set months(value: number);
    get quarters(): number;
    set quarters(value: number);
    get seconds(): number;
    set seconds(value: number);
    get weeks(): number;
    set weeks(value: number);
    get years(): number;
    set years(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoAggregationIntervalComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoAggregationIntervalComponent, "dxo-aggregation-interval", never, { "days": { "alias": "days"; "required": false; }; "hours": { "alias": "hours"; "required": false; }; "milliseconds": { "alias": "milliseconds"; "required": false; }; "minutes": { "alias": "minutes"; "required": false; }; "months": { "alias": "months"; "required": false; }; "quarters": { "alias": "quarters"; "required": false; }; "seconds": { "alias": "seconds"; "required": false; }; "weeks": { "alias": "weeks"; "required": false; }; "years": { "alias": "years"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoAggregationIntervalModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoAggregationIntervalModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoAggregationIntervalModule, never, [typeof DxoAggregationIntervalComponent], [typeof DxoAggregationIntervalComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoAggregationIntervalModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoAggregationComponent extends NestedOption implements OnDestroy, OnInit {
    get calculate(): Function | undefined;
    set calculate(value: Function | undefined);
    get enabled(): boolean;
    set enabled(value: boolean);
    get method(): ChartSeriesAggregationMethod;
    set method(value: ChartSeriesAggregationMethod);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoAggregationComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoAggregationComponent, "dxo-aggregation", never, { "calculate": { "alias": "calculate"; "required": false; }; "enabled": { "alias": "enabled"; "required": false; }; "method": { "alias": "method"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoAggregationModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoAggregationModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoAggregationModule, never, [typeof DxoAggregationComponent], [typeof DxoAggregationComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoAggregationModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare abstract class DxiAlert extends CollectionNestedOption {
    get id(): number | string;
    set id(value: number | string);
    get message(): string;
    set message(value: string);
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiAlert, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiAlert, "ng-component", never, {}, {}, never, never, true, never>;
}

declare class DxiAlertComponent extends DxiAlert {
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiAlertComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiAlertComponent, "dxi-alert", never, { "id": { "alias": "id"; "required": false; }; "message": { "alias": "message"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxiAlertModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiAlertModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiAlertModule, never, [typeof DxiAlertComponent], [typeof DxiAlertComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiAlertModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoAnimationComponent extends NestedOption implements OnDestroy, OnInit {
    get hide(): AnimationConfig;
    set hide(value: AnimationConfig);
    get show(): AnimationConfig;
    set show(value: AnimationConfig);
    get duration(): number;
    set duration(value: number);
    get easing(): AnimationEaseMode;
    set easing(value: AnimationEaseMode);
    get enabled(): boolean;
    set enabled(value: boolean);
    get maxPointCountSupported(): number;
    set maxPointCountSupported(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoAnimationComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoAnimationComponent, "dxo-animation", never, { "hide": { "alias": "hide"; "required": false; }; "show": { "alias": "show"; "required": false; }; "duration": { "alias": "duration"; "required": false; }; "easing": { "alias": "easing"; "required": false; }; "enabled": { "alias": "enabled"; "required": false; }; "maxPointCountSupported": { "alias": "maxPointCountSupported"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoAnimationModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoAnimationModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoAnimationModule, never, [typeof DxoAnimationComponent], [typeof DxoAnimationComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoAnimationModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare abstract class DxiChartAnnotationConfig extends CollectionNestedOption {
    get allowDragging(): boolean;
    set allowDragging(value: boolean);
    get argument(): Date | number | string | undefined;
    set argument(value: Date | number | string | undefined);
    get arrowLength(): number;
    set arrowLength(value: number);
    get arrowWidth(): number;
    set arrowWidth(value: number);
    get axis(): string | undefined;
    set axis(value: string | undefined);
    get border(): {
        color?: string;
        cornerRadius?: number;
        dashStyle?: DashStyle;
        opacity?: number | undefined;
        visible?: boolean;
        width?: number;
    };
    set border(value: {
        color?: string;
        cornerRadius?: number;
        dashStyle?: DashStyle;
        opacity?: number | undefined;
        visible?: boolean;
        width?: number;
    });
    get color(): string;
    set color(value: string);
    get customizeTooltip(): Function | undefined;
    set customizeTooltip(value: Function | undefined);
    get data(): any;
    set data(value: any);
    get description(): string | undefined;
    set description(value: string | undefined);
    get font(): Font;
    set font(value: Font);
    get height(): number | undefined;
    set height(value: number | undefined);
    get image(): string | {
        height?: number;
        url?: string | undefined;
        width?: number;
    };
    set image(value: string | {
        height?: number;
        url?: string | undefined;
        width?: number;
    });
    get name(): string | undefined;
    set name(value: string | undefined);
    get offsetX(): number | undefined;
    set offsetX(value: number | undefined);
    get offsetY(): number | undefined;
    set offsetY(value: number | undefined);
    get opacity(): number;
    set opacity(value: number);
    get paddingLeftRight(): number;
    set paddingLeftRight(value: number);
    get paddingTopBottom(): number;
    set paddingTopBottom(value: number);
    get series(): string | undefined;
    set series(value: string | undefined);
    get shadow(): {
        blur?: number;
        color?: string;
        offsetX?: number;
        offsetY?: number;
        opacity?: number;
    };
    set shadow(value: {
        blur?: number;
        color?: string;
        offsetX?: number;
        offsetY?: number;
        opacity?: number;
    });
    get template(): any | undefined;
    set template(value: any | undefined);
    get text(): string | undefined;
    set text(value: string | undefined);
    get textOverflow(): TextOverflow;
    set textOverflow(value: TextOverflow);
    get tooltipEnabled(): boolean;
    set tooltipEnabled(value: boolean);
    get tooltipTemplate(): any | undefined;
    set tooltipTemplate(value: any | undefined);
    get type(): AnnotationType | undefined;
    set type(value: AnnotationType | undefined);
    get value(): Date | number | string | undefined;
    set value(value: Date | number | string | undefined);
    get width(): number | undefined;
    set width(value: number | undefined);
    get wordWrap(): WordWrap;
    set wordWrap(value: WordWrap);
    get x(): number | undefined;
    set x(value: number | undefined);
    get y(): number | undefined;
    set y(value: number | undefined);
    get location(): PieChartAnnotationLocation;
    set location(value: PieChartAnnotationLocation);
    get angle(): number | undefined;
    set angle(value: number | undefined);
    get radius(): number | undefined;
    set radius(value: number | undefined);
    get coordinates(): undefined | Array<number>;
    set coordinates(value: undefined | Array<number>);
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiChartAnnotationConfig, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiChartAnnotationConfig, "ng-component", never, {}, {}, never, never, true, never>;
}

declare class DxiAnnotationComponent extends DxiChartAnnotationConfig {
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiAnnotationComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiAnnotationComponent, "dxi-annotation", never, { "allowDragging": { "alias": "allowDragging"; "required": false; }; "argument": { "alias": "argument"; "required": false; }; "arrowLength": { "alias": "arrowLength"; "required": false; }; "arrowWidth": { "alias": "arrowWidth"; "required": false; }; "axis": { "alias": "axis"; "required": false; }; "border": { "alias": "border"; "required": false; }; "color": { "alias": "color"; "required": false; }; "customizeTooltip": { "alias": "customizeTooltip"; "required": false; }; "data": { "alias": "data"; "required": false; }; "description": { "alias": "description"; "required": false; }; "font": { "alias": "font"; "required": false; }; "height": { "alias": "height"; "required": false; }; "image": { "alias": "image"; "required": false; }; "name": { "alias": "name"; "required": false; }; "offsetX": { "alias": "offsetX"; "required": false; }; "offsetY": { "alias": "offsetY"; "required": false; }; "opacity": { "alias": "opacity"; "required": false; }; "paddingLeftRight": { "alias": "paddingLeftRight"; "required": false; }; "paddingTopBottom": { "alias": "paddingTopBottom"; "required": false; }; "series": { "alias": "series"; "required": false; }; "shadow": { "alias": "shadow"; "required": false; }; "template": { "alias": "template"; "required": false; }; "text": { "alias": "text"; "required": false; }; "textOverflow": { "alias": "textOverflow"; "required": false; }; "tooltipEnabled": { "alias": "tooltipEnabled"; "required": false; }; "tooltipTemplate": { "alias": "tooltipTemplate"; "required": false; }; "type": { "alias": "type"; "required": false; }; "value": { "alias": "value"; "required": false; }; "width": { "alias": "width"; "required": false; }; "wordWrap": { "alias": "wordWrap"; "required": false; }; "x": { "alias": "x"; "required": false; }; "y": { "alias": "y"; "required": false; }; "location": { "alias": "location"; "required": false; }; "angle": { "alias": "angle"; "required": false; }; "radius": { "alias": "radius"; "required": false; }; "coordinates": { "alias": "coordinates"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxiAnnotationModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiAnnotationModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiAnnotationModule, never, [typeof DxiAnnotationComponent], [typeof DxiAnnotationComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiAnnotationModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoApiKeyComponent extends NestedOption implements OnDestroy, OnInit {
    get azure(): string;
    set azure(value: string);
    get bing(): string;
    set bing(value: string);
    get google(): string;
    set google(value: string);
    get googleStatic(): string;
    set googleStatic(value: string);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoApiKeyComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoApiKeyComponent, "dxo-api-key", never, { "azure": { "alias": "azure"; "required": false; }; "bing": { "alias": "bing"; "required": false; }; "google": { "alias": "google"; "required": false; }; "googleStatic": { "alias": "googleStatic"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoApiKeyModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoApiKeyModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoApiKeyModule, never, [typeof DxoApiKeyComponent], [typeof DxoApiKeyComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoApiKeyModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoAppointmentDraggingComponent extends NestedOption implements OnDestroy, OnInit {
    get autoScroll(): boolean;
    set autoScroll(value: boolean);
    get data(): any | undefined;
    set data(value: any | undefined);
    get group(): string | undefined;
    set group(value: string | undefined);
    get onAdd(): Function;
    set onAdd(value: Function);
    get onDragEnd(): Function;
    set onDragEnd(value: Function);
    get onDragMove(): Function;
    set onDragMove(value: Function);
    get onDragStart(): Function;
    set onDragStart(value: Function);
    get onRemove(): Function;
    set onRemove(value: Function);
    get scrollSensitivity(): number;
    set scrollSensitivity(value: number);
    get scrollSpeed(): number;
    set scrollSpeed(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoAppointmentDraggingComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoAppointmentDraggingComponent, "dxo-appointment-dragging", never, { "autoScroll": { "alias": "autoScroll"; "required": false; }; "data": { "alias": "data"; "required": false; }; "group": { "alias": "group"; "required": false; }; "onAdd": { "alias": "onAdd"; "required": false; }; "onDragEnd": { "alias": "onDragEnd"; "required": false; }; "onDragMove": { "alias": "onDragMove"; "required": false; }; "onDragStart": { "alias": "onDragStart"; "required": false; }; "onRemove": { "alias": "onRemove"; "required": false; }; "scrollSensitivity": { "alias": "scrollSensitivity"; "required": false; }; "scrollSpeed": { "alias": "scrollSpeed"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoAppointmentDraggingModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoAppointmentDraggingModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoAppointmentDraggingModule, never, [typeof DxoAppointmentDraggingComponent], [typeof DxoAppointmentDraggingComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoAppointmentDraggingModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare abstract class DxoChartCommonSeriesSettings extends NestedOption {
    get aggregation(): {
        calculate?: Function | undefined;
        enabled?: boolean;
        method?: ChartSeriesAggregationMethod;
    };
    set aggregation(value: {
        calculate?: Function | undefined;
        enabled?: boolean;
        method?: ChartSeriesAggregationMethod;
    });
    get area(): any;
    set area(value: any);
    get argumentField(): string;
    set argumentField(value: string);
    get axis(): string | undefined;
    set axis(value: string | undefined);
    get bar(): any;
    set bar(value: any);
    get barOverlapGroup(): string | undefined;
    set barOverlapGroup(value: string | undefined);
    get barPadding(): number | undefined;
    set barPadding(value: number | undefined);
    get barWidth(): number | undefined;
    set barWidth(value: number | undefined);
    get border(): {
        color?: string | undefined;
        dashStyle?: DashStyle | undefined;
        visible?: boolean;
        width?: number;
    };
    set border(value: {
        color?: string | undefined;
        dashStyle?: DashStyle | undefined;
        visible?: boolean;
        width?: number;
    });
    get bubble(): any;
    set bubble(value: any);
    get candlestick(): any;
    set candlestick(value: any);
    get closeValueField(): string;
    set closeValueField(value: string);
    get color(): ChartsColor | string | undefined;
    set color(value: ChartsColor | string | undefined);
    get cornerRadius(): number;
    set cornerRadius(value: number);
    get dashStyle(): DashStyle;
    set dashStyle(value: DashStyle);
    get fullstackedarea(): any;
    set fullstackedarea(value: any);
    get fullstackedbar(): any;
    set fullstackedbar(value: any);
    get fullstackedline(): any;
    set fullstackedline(value: any);
    get fullstackedspline(): any;
    set fullstackedspline(value: any);
    get fullstackedsplinearea(): any;
    set fullstackedsplinearea(value: any);
    get highValueField(): string;
    set highValueField(value: string);
    get hoverMode(): SeriesHoverMode | PieChartSeriesInteractionMode;
    set hoverMode(value: SeriesHoverMode | PieChartSeriesInteractionMode);
    get hoverStyle(): {
        border?: {
            color?: string | undefined;
            dashStyle?: DashStyle | undefined;
            visible?: boolean;
            width?: number;
        };
        color?: ChartsColor | string | undefined;
        dashStyle?: DashStyle;
        hatching?: {
            direction?: HatchDirection;
            opacity?: number;
            step?: number;
            width?: number;
        };
        highlight?: boolean;
        width?: number;
    } | {
        border?: {
            color?: string | undefined;
            dashStyle?: DashStyle | undefined;
            visible?: boolean;
            width?: number;
        };
        color?: ChartsColor | string | undefined;
        hatching?: {
            direction?: HatchDirection;
            opacity?: number;
            step?: number;
            width?: number;
        };
        highlight?: boolean;
    };
    set hoverStyle(value: {
        border?: {
            color?: string | undefined;
            dashStyle?: DashStyle | undefined;
            visible?: boolean;
            width?: number;
        };
        color?: ChartsColor | string | undefined;
        dashStyle?: DashStyle;
        hatching?: {
            direction?: HatchDirection;
            opacity?: number;
            step?: number;
            width?: number;
        };
        highlight?: boolean;
        width?: number;
    } | {
        border?: {
            color?: string | undefined;
            dashStyle?: DashStyle | undefined;
            visible?: boolean;
            width?: number;
        };
        color?: ChartsColor | string | undefined;
        hatching?: {
            direction?: HatchDirection;
            opacity?: number;
            step?: number;
            width?: number;
        };
        highlight?: boolean;
    });
    get ignoreEmptyPoints(): boolean;
    set ignoreEmptyPoints(value: boolean);
    get innerColor(): string;
    set innerColor(value: string);
    get label(): {
        alignment?: HorizontalAlignment;
        argumentFormat?: Format | string | undefined;
        backgroundColor?: string | undefined;
        border?: {
            color?: string | undefined;
            dashStyle?: DashStyle | undefined;
            visible?: boolean;
            width?: number;
        };
        connector?: {
            color?: string | undefined;
            visible?: boolean;
            width?: number;
        };
        customizeText?: Function;
        displayFormat?: string | undefined;
        font?: Font;
        format?: Format | string | undefined;
        horizontalOffset?: number;
        position?: RelativePosition;
        rotationAngle?: number;
        showForZeroValues?: boolean;
        verticalOffset?: number;
        visible?: boolean;
    } | {
        argumentFormat?: Format | string | undefined;
        backgroundColor?: string | undefined;
        border?: {
            color?: string | undefined;
            dashStyle?: DashStyle | undefined;
            visible?: boolean;
            width?: number;
        };
        connector?: {
            color?: string | undefined;
            visible?: boolean;
            width?: number;
        };
        customizeText?: Function;
        displayFormat?: string | undefined;
        font?: Font;
        format?: Format | string | undefined;
        position?: LabelPosition;
        radialOffset?: number;
        rotationAngle?: number;
        textOverflow?: TextOverflow;
        visible?: boolean;
        wordWrap?: WordWrap;
    } | {
        argumentFormat?: Format | string | undefined;
        backgroundColor?: string | undefined;
        border?: {
            color?: string | undefined;
            dashStyle?: DashStyle | undefined;
            visible?: boolean;
            width?: number;
        };
        connector?: {
            color?: string | undefined;
            visible?: boolean;
            width?: number;
        };
        customizeText?: Function;
        displayFormat?: string | undefined;
        font?: Font;
        format?: Format | string | undefined;
        position?: RelativePosition;
        rotationAngle?: number;
        showForZeroValues?: boolean;
        visible?: boolean;
    };
    set label(value: {
        alignment?: HorizontalAlignment;
        argumentFormat?: Format | string | undefined;
        backgroundColor?: string | undefined;
        border?: {
            color?: string | undefined;
            dashStyle?: DashStyle | undefined;
            visible?: boolean;
            width?: number;
        };
        connector?: {
            color?: string | undefined;
            visible?: boolean;
            width?: number;
        };
        customizeText?: Function;
        displayFormat?: string | undefined;
        font?: Font;
        format?: Format | string | undefined;
        horizontalOffset?: number;
        position?: RelativePosition;
        rotationAngle?: number;
        showForZeroValues?: boolean;
        verticalOffset?: number;
        visible?: boolean;
    } | {
        argumentFormat?: Format | string | undefined;
        backgroundColor?: string | undefined;
        border?: {
            color?: string | undefined;
            dashStyle?: DashStyle | undefined;
            visible?: boolean;
            width?: number;
        };
        connector?: {
            color?: string | undefined;
            visible?: boolean;
            width?: number;
        };
        customizeText?: Function;
        displayFormat?: string | undefined;
        font?: Font;
        format?: Format | string | undefined;
        position?: LabelPosition;
        radialOffset?: number;
        rotationAngle?: number;
        textOverflow?: TextOverflow;
        visible?: boolean;
        wordWrap?: WordWrap;
    } | {
        argumentFormat?: Format | string | undefined;
        backgroundColor?: string | undefined;
        border?: {
            color?: string | undefined;
            dashStyle?: DashStyle | undefined;
            visible?: boolean;
            width?: number;
        };
        connector?: {
            color?: string | undefined;
            visible?: boolean;
            width?: number;
        };
        customizeText?: Function;
        displayFormat?: string | undefined;
        font?: Font;
        format?: Format | string | undefined;
        position?: RelativePosition;
        rotationAngle?: number;
        showForZeroValues?: boolean;
        visible?: boolean;
    });
    get line(): any;
    set line(value: any);
    get lowValueField(): string;
    set lowValueField(value: string);
    get maxLabelCount(): number | undefined;
    set maxLabelCount(value: number | undefined);
    get minBarSize(): number | undefined;
    set minBarSize(value: number | undefined);
    get opacity(): number;
    set opacity(value: number);
    get openValueField(): string;
    set openValueField(value: string);
    get pane(): string;
    set pane(value: string);
    get point(): {
        border?: {
            color?: string | undefined;
            visible?: boolean;
            width?: number;
        };
        color?: ChartsColor | string | undefined;
        hoverMode?: PointInteractionMode;
        hoverStyle?: {
            border?: {
                color?: string | undefined;
                visible?: boolean;
                width?: number;
            };
            color?: ChartsColor | string | undefined;
            size?: number | undefined;
        };
        image?: string | undefined | {
            height?: number | {
                rangeMaxPoint?: number | undefined;
                rangeMinPoint?: number | undefined;
            };
            url?: string | undefined | {
                rangeMaxPoint?: string | undefined;
                rangeMinPoint?: string | undefined;
            };
            width?: number | {
                rangeMaxPoint?: number | undefined;
                rangeMinPoint?: number | undefined;
            };
        };
        selectionMode?: PointInteractionMode;
        selectionStyle?: {
            border?: {
                color?: string | undefined;
                visible?: boolean;
                width?: number;
            };
            color?: ChartsColor | string | undefined;
            size?: number | undefined;
        };
        size?: number;
        symbol?: PointSymbol;
        visible?: boolean;
    } | {
        border?: {
            color?: string | undefined;
            visible?: boolean;
            width?: number;
        };
        color?: ChartsColor | string | undefined;
        hoverMode?: PointInteractionMode;
        hoverStyle?: {
            border?: {
                color?: string | undefined;
                visible?: boolean;
                width?: number;
            };
            color?: ChartsColor | string | undefined;
            size?: number;
        };
        image?: string | undefined | {
            height?: number;
            url?: string | undefined;
            width?: number;
        };
        selectionMode?: PointInteractionMode;
        selectionStyle?: {
            border?: {
                color?: string | undefined;
                visible?: boolean;
                width?: number;
            };
            color?: ChartsColor | string | undefined;
            size?: number;
        };
        size?: number;
        symbol?: PointSymbol;
        visible?: boolean;
    };
    set point(value: {
        border?: {
            color?: string | undefined;
            visible?: boolean;
            width?: number;
        };
        color?: ChartsColor | string | undefined;
        hoverMode?: PointInteractionMode;
        hoverStyle?: {
            border?: {
                color?: string | undefined;
                visible?: boolean;
                width?: number;
            };
            color?: ChartsColor | string | undefined;
            size?: number | undefined;
        };
        image?: string | undefined | {
            height?: number | {
                rangeMaxPoint?: number | undefined;
                rangeMinPoint?: number | undefined;
            };
            url?: string | undefined | {
                rangeMaxPoint?: string | undefined;
                rangeMinPoint?: string | undefined;
            };
            width?: number | {
                rangeMaxPoint?: number | undefined;
                rangeMinPoint?: number | undefined;
            };
        };
        selectionMode?: PointInteractionMode;
        selectionStyle?: {
            border?: {
                color?: string | undefined;
                visible?: boolean;
                width?: number;
            };
            color?: ChartsColor | string | undefined;
            size?: number | undefined;
        };
        size?: number;
        symbol?: PointSymbol;
        visible?: boolean;
    } | {
        border?: {
            color?: string | undefined;
            visible?: boolean;
            width?: number;
        };
        color?: ChartsColor | string | undefined;
        hoverMode?: PointInteractionMode;
        hoverStyle?: {
            border?: {
                color?: string | undefined;
                visible?: boolean;
                width?: number;
            };
            color?: ChartsColor | string | undefined;
            size?: number;
        };
        image?: string | undefined | {
            height?: number;
            url?: string | undefined;
            width?: number;
        };
        selectionMode?: PointInteractionMode;
        selectionStyle?: {
            border?: {
                color?: string | undefined;
                visible?: boolean;
                width?: number;
            };
            color?: ChartsColor | string | undefined;
            size?: number;
        };
        size?: number;
        symbol?: PointSymbol;
        visible?: boolean;
    });
    get rangearea(): any;
    set rangearea(value: any);
    get rangebar(): any;
    set rangebar(value: any);
    get rangeValue1Field(): string;
    set rangeValue1Field(value: string);
    get rangeValue2Field(): string;
    set rangeValue2Field(value: string);
    get reduction(): {
        color?: string;
        level?: FinancialChartReductionLevel;
    };
    set reduction(value: {
        color?: string;
        level?: FinancialChartReductionLevel;
    });
    get scatter(): any;
    set scatter(value: any);
    get selectionMode(): SeriesSelectionMode | PieChartSeriesInteractionMode;
    set selectionMode(value: SeriesSelectionMode | PieChartSeriesInteractionMode);
    get selectionStyle(): {
        border?: {
            color?: string | undefined;
            dashStyle?: DashStyle | undefined;
            visible?: boolean;
            width?: number;
        };
        color?: ChartsColor | string | undefined;
        dashStyle?: DashStyle;
        hatching?: {
            direction?: HatchDirection;
            opacity?: number;
            step?: number;
            width?: number;
        };
        highlight?: boolean;
        width?: number;
    } | {
        border?: {
            color?: string | undefined;
            dashStyle?: DashStyle | undefined;
            visible?: boolean;
            width?: number;
        };
        color?: ChartsColor | string | undefined;
        hatching?: {
            direction?: HatchDirection;
            opacity?: number;
            step?: number;
            width?: number;
        };
        highlight?: boolean;
    };
    set selectionStyle(value: {
        border?: {
            color?: string | undefined;
            dashStyle?: DashStyle | undefined;
            visible?: boolean;
            width?: number;
        };
        color?: ChartsColor | string | undefined;
        dashStyle?: DashStyle;
        hatching?: {
            direction?: HatchDirection;
            opacity?: number;
            step?: number;
            width?: number;
        };
        highlight?: boolean;
        width?: number;
    } | {
        border?: {
            color?: string | undefined;
            dashStyle?: DashStyle | undefined;
            visible?: boolean;
            width?: number;
        };
        color?: ChartsColor | string | undefined;
        hatching?: {
            direction?: HatchDirection;
            opacity?: number;
            step?: number;
            width?: number;
        };
        highlight?: boolean;
    });
    get showInLegend(): boolean;
    set showInLegend(value: boolean);
    get sizeField(): string;
    set sizeField(value: string);
    get spline(): any;
    set spline(value: any);
    get splinearea(): any;
    set splinearea(value: any);
    get stack(): string;
    set stack(value: string);
    get stackedarea(): any;
    set stackedarea(value: any);
    get stackedbar(): any;
    set stackedbar(value: any);
    get stackedline(): any;
    set stackedline(value: any);
    get stackedspline(): any;
    set stackedspline(value: any);
    get stackedsplinearea(): any;
    set stackedsplinearea(value: any);
    get steparea(): any;
    set steparea(value: any);
    get stepline(): any;
    set stepline(value: any);
    get stock(): any;
    set stock(value: any);
    get tagField(): string;
    set tagField(value: string);
    get type(): SeriesType | PolarChartSeriesType;
    set type(value: SeriesType | PolarChartSeriesType);
    get valueErrorBar(): {
        color?: string;
        displayMode?: ValueErrorBarDisplayMode;
        edgeLength?: number;
        highValueField?: string | undefined;
        lineWidth?: number;
        lowValueField?: string | undefined;
        opacity?: number | undefined;
        type?: ValueErrorBarType | undefined;
        value?: number;
    };
    set valueErrorBar(value: {
        color?: string;
        displayMode?: ValueErrorBarDisplayMode;
        edgeLength?: number;
        highValueField?: string | undefined;
        lineWidth?: number;
        lowValueField?: string | undefined;
        opacity?: number | undefined;
        type?: ValueErrorBarType | undefined;
        value?: number;
    });
    get valueField(): string;
    set valueField(value: string);
    get visible(): boolean;
    set visible(value: boolean);
    get width(): number;
    set width(value: number);
    get argumentType(): ChartsDataType | undefined;
    set argumentType(value: ChartsDataType | undefined);
    get minSegmentSize(): number | undefined;
    set minSegmentSize(value: number | undefined);
    get smallValuesGrouping(): {
        groupName?: string;
        mode?: SmallValuesGroupingMode;
        threshold?: number | undefined;
        topCount?: number | undefined;
    };
    set smallValuesGrouping(value: {
        groupName?: string;
        mode?: SmallValuesGroupingMode;
        threshold?: number | undefined;
        topCount?: number | undefined;
    });
    get closed(): boolean;
    set closed(value: boolean);
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChartCommonSeriesSettings, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoChartCommonSeriesSettings, "ng-component", never, {}, {}, never, never, true, never>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoAreaComponent extends DxoChartCommonSeriesSettings implements OnDestroy, OnInit {
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoAreaComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoAreaComponent, "dxo-area", never, { "aggregation": { "alias": "aggregation"; "required": false; }; "area": { "alias": "area"; "required": false; }; "argumentField": { "alias": "argumentField"; "required": false; }; "axis": { "alias": "axis"; "required": false; }; "bar": { "alias": "bar"; "required": false; }; "barOverlapGroup": { "alias": "barOverlapGroup"; "required": false; }; "barPadding": { "alias": "barPadding"; "required": false; }; "barWidth": { "alias": "barWidth"; "required": false; }; "border": { "alias": "border"; "required": false; }; "bubble": { "alias": "bubble"; "required": false; }; "candlestick": { "alias": "candlestick"; "required": false; }; "closeValueField": { "alias": "closeValueField"; "required": false; }; "color": { "alias": "color"; "required": false; }; "cornerRadius": { "alias": "cornerRadius"; "required": false; }; "dashStyle": { "alias": "dashStyle"; "required": false; }; "fullstackedarea": { "alias": "fullstackedarea"; "required": false; }; "fullstackedbar": { "alias": "fullstackedbar"; "required": false; }; "fullstackedline": { "alias": "fullstackedline"; "required": false; }; "fullstackedspline": { "alias": "fullstackedspline"; "required": false; }; "fullstackedsplinearea": { "alias": "fullstackedsplinearea"; "required": false; }; "highValueField": { "alias": "highValueField"; "required": false; }; "hoverMode": { "alias": "hoverMode"; "required": false; }; "hoverStyle": { "alias": "hoverStyle"; "required": false; }; "ignoreEmptyPoints": { "alias": "ignoreEmptyPoints"; "required": false; }; "innerColor": { "alias": "innerColor"; "required": false; }; "label": { "alias": "label"; "required": false; }; "line": { "alias": "line"; "required": false; }; "lowValueField": { "alias": "lowValueField"; "required": false; }; "maxLabelCount": { "alias": "maxLabelCount"; "required": false; }; "minBarSize": { "alias": "minBarSize"; "required": false; }; "opacity": { "alias": "opacity"; "required": false; }; "openValueField": { "alias": "openValueField"; "required": false; }; "pane": { "alias": "pane"; "required": false; }; "point": { "alias": "point"; "required": false; }; "rangearea": { "alias": "rangearea"; "required": false; }; "rangebar": { "alias": "rangebar"; "required": false; }; "rangeValue1Field": { "alias": "rangeValue1Field"; "required": false; }; "rangeValue2Field": { "alias": "rangeValue2Field"; "required": false; }; "reduction": { "alias": "reduction"; "required": false; }; "scatter": { "alias": "scatter"; "required": false; }; "selectionMode": { "alias": "selectionMode"; "required": false; }; "selectionStyle": { "alias": "selectionStyle"; "required": false; }; "showInLegend": { "alias": "showInLegend"; "required": false; }; "sizeField": { "alias": "sizeField"; "required": false; }; "spline": { "alias": "spline"; "required": false; }; "splinearea": { "alias": "splinearea"; "required": false; }; "stack": { "alias": "stack"; "required": false; }; "stackedarea": { "alias": "stackedarea"; "required": false; }; "stackedbar": { "alias": "stackedbar"; "required": false; }; "stackedline": { "alias": "stackedline"; "required": false; }; "stackedspline": { "alias": "stackedspline"; "required": false; }; "stackedsplinearea": { "alias": "stackedsplinearea"; "required": false; }; "steparea": { "alias": "steparea"; "required": false; }; "stepline": { "alias": "stepline"; "required": false; }; "stock": { "alias": "stock"; "required": false; }; "tagField": { "alias": "tagField"; "required": false; }; "type": { "alias": "type"; "required": false; }; "valueErrorBar": { "alias": "valueErrorBar"; "required": false; }; "valueField": { "alias": "valueField"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; "closed": { "alias": "closed"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoAreaModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoAreaModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoAreaModule, never, [typeof DxoAreaComponent], [typeof DxoAreaComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoAreaModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoArgumentAxisComponent extends NestedOption implements OnDestroy, OnInit {
    set _breaksContentChildren(value: QueryList<CollectionNestedOption>);
    set _constantLinesContentChildren(value: QueryList<CollectionNestedOption>);
    set _stripsContentChildren(value: QueryList<CollectionNestedOption>);
    get aggregatedPointsPosition(): AggregatedPointsPosition;
    set aggregatedPointsPosition(value: AggregatedPointsPosition);
    get aggregationGroupWidth(): number | undefined;
    set aggregationGroupWidth(value: number | undefined);
    get aggregationInterval(): TimeInterval | number | {
        days?: number;
        hours?: number;
        milliseconds?: number;
        minutes?: number;
        months?: number;
        quarters?: number;
        seconds?: number;
        weeks?: number;
        years?: number;
    };
    set aggregationInterval(value: TimeInterval | number | {
        days?: number;
        hours?: number;
        milliseconds?: number;
        minutes?: number;
        months?: number;
        quarters?: number;
        seconds?: number;
        weeks?: number;
        years?: number;
    });
    get allowDecimals(): boolean | undefined;
    set allowDecimals(value: boolean | undefined);
    get argumentType(): ChartsDataType | undefined;
    set argumentType(value: ChartsDataType | undefined);
    get axisDivisionFactor(): number;
    set axisDivisionFactor(value: number);
    get breaks(): undefined | Array<ScaleBreak>;
    set breaks(value: undefined | Array<ScaleBreak>);
    get breakStyle(): {
        color?: string;
        line?: ScaleBreakLineStyle;
        width?: number;
    };
    set breakStyle(value: {
        color?: string;
        line?: ScaleBreakLineStyle;
        width?: number;
    });
    get categories(): Array<number | string | Date>;
    set categories(value: Array<number | string | Date>);
    get color(): string;
    set color(value: string);
    get constantLines(): Array<any | {
        color?: string;
        dashStyle?: DashStyle;
        displayBehindSeries?: boolean;
        extendAxis?: boolean;
        label?: {
            font?: Font;
            horizontalAlignment?: HorizontalAlignment;
            position?: RelativePosition;
            text?: string | undefined;
            verticalAlignment?: VerticalAlignment;
            visible?: boolean;
        };
        paddingLeftRight?: number;
        paddingTopBottom?: number;
        value?: Date | number | string | undefined;
        width?: number;
    } | {
        color?: string;
        dashStyle?: DashStyle;
        displayBehindSeries?: boolean;
        extendAxis?: boolean;
        label?: {
            font?: Font;
            text?: string | undefined;
            visible?: boolean;
        };
        value?: Date | number | string | undefined;
        width?: number;
    }>;
    set constantLines(value: Array<any | {
        color?: string;
        dashStyle?: DashStyle;
        displayBehindSeries?: boolean;
        extendAxis?: boolean;
        label?: {
            font?: Font;
            horizontalAlignment?: HorizontalAlignment;
            position?: RelativePosition;
            text?: string | undefined;
            verticalAlignment?: VerticalAlignment;
            visible?: boolean;
        };
        paddingLeftRight?: number;
        paddingTopBottom?: number;
        value?: Date | number | string | undefined;
        width?: number;
    } | {
        color?: string;
        dashStyle?: DashStyle;
        displayBehindSeries?: boolean;
        extendAxis?: boolean;
        label?: {
            font?: Font;
            text?: string | undefined;
            visible?: boolean;
        };
        value?: Date | number | string | undefined;
        width?: number;
    }>);
    get constantLineStyle(): {
        color?: string;
        dashStyle?: DashStyle;
        label?: {
            font?: Font;
            horizontalAlignment?: HorizontalAlignment;
            position?: RelativePosition;
            verticalAlignment?: VerticalAlignment;
            visible?: boolean;
        };
        paddingLeftRight?: number;
        paddingTopBottom?: number;
        width?: number;
    } | {
        color?: string;
        dashStyle?: DashStyle;
        label?: {
            font?: Font;
            visible?: boolean;
        };
        width?: number;
    };
    set constantLineStyle(value: {
        color?: string;
        dashStyle?: DashStyle;
        label?: {
            font?: Font;
            horizontalAlignment?: HorizontalAlignment;
            position?: RelativePosition;
            verticalAlignment?: VerticalAlignment;
            visible?: boolean;
        };
        paddingLeftRight?: number;
        paddingTopBottom?: number;
        width?: number;
    } | {
        color?: string;
        dashStyle?: DashStyle;
        label?: {
            font?: Font;
            visible?: boolean;
        };
        width?: number;
    });
    get customPosition(): Date | number | string | undefined;
    set customPosition(value: Date | number | string | undefined);
    get customPositionAxis(): string | undefined;
    set customPositionAxis(value: string | undefined);
    get discreteAxisDivisionMode(): DiscreteAxisDivisionMode;
    set discreteAxisDivisionMode(value: DiscreteAxisDivisionMode);
    get endOnTick(): boolean | undefined;
    set endOnTick(value: boolean | undefined);
    get grid(): {
        color?: string;
        opacity?: number | undefined;
        visible?: boolean;
        width?: number;
    };
    set grid(value: {
        color?: string;
        opacity?: number | undefined;
        visible?: boolean;
        width?: number;
    });
    get holidays(): undefined | Array<Date | string | number>;
    set holidays(value: undefined | Array<Date | string | number>);
    get hoverMode(): ArgumentAxisHoverMode;
    set hoverMode(value: ArgumentAxisHoverMode);
    get inverted(): boolean;
    set inverted(value: boolean);
    get label(): {
        alignment?: HorizontalAlignment | undefined;
        customizeHint?: Function;
        customizeText?: Function;
        displayMode?: ChartLabelDisplayMode;
        font?: Font;
        format?: Format | string | undefined;
        indentFromAxis?: number;
        overlappingBehavior?: ChartsAxisLabelOverlap;
        position?: RelativePosition | Position;
        rotationAngle?: number;
        staggeringSpacing?: number;
        template?: any | undefined;
        textOverflow?: TextOverflow;
        visible?: boolean;
        wordWrap?: WordWrap;
    } | {
        customizeHint?: Function;
        customizeText?: Function;
        font?: Font;
        format?: Format | string | undefined;
        indentFromAxis?: number;
        overlappingBehavior?: LabelOverlap;
        visible?: boolean;
    };
    set label(value: {
        alignment?: HorizontalAlignment | undefined;
        customizeHint?: Function;
        customizeText?: Function;
        displayMode?: ChartLabelDisplayMode;
        font?: Font;
        format?: Format | string | undefined;
        indentFromAxis?: number;
        overlappingBehavior?: ChartsAxisLabelOverlap;
        position?: RelativePosition | Position;
        rotationAngle?: number;
        staggeringSpacing?: number;
        template?: any | undefined;
        textOverflow?: TextOverflow;
        visible?: boolean;
        wordWrap?: WordWrap;
    } | {
        customizeHint?: Function;
        customizeText?: Function;
        font?: Font;
        format?: Format | string | undefined;
        indentFromAxis?: number;
        overlappingBehavior?: LabelOverlap;
        visible?: boolean;
    });
    get linearThreshold(): number | undefined;
    set linearThreshold(value: number | undefined);
    get logarithmBase(): number;
    set logarithmBase(value: number);
    get maxValueMargin(): number | undefined;
    set maxValueMargin(value: number | undefined);
    get minorGrid(): {
        color?: string;
        opacity?: number | undefined;
        visible?: boolean;
        width?: number;
    };
    set minorGrid(value: {
        color?: string;
        opacity?: number | undefined;
        visible?: boolean;
        width?: number;
    });
    get minorTick(): {
        color?: string;
        length?: number;
        opacity?: number;
        shift?: number;
        visible?: boolean;
        width?: number;
    };
    set minorTick(value: {
        color?: string;
        length?: number;
        opacity?: number;
        shift?: number;
        visible?: boolean;
        width?: number;
    });
    get minorTickCount(): number | undefined;
    set minorTickCount(value: number | undefined);
    get minorTickInterval(): TimeInterval | number | {
        days?: number;
        hours?: number;
        milliseconds?: number;
        minutes?: number;
        months?: number;
        quarters?: number;
        seconds?: number;
        weeks?: number;
        years?: number;
    };
    set minorTickInterval(value: TimeInterval | number | {
        days?: number;
        hours?: number;
        milliseconds?: number;
        minutes?: number;
        months?: number;
        quarters?: number;
        seconds?: number;
        weeks?: number;
        years?: number;
    });
    get minValueMargin(): number | undefined;
    set minValueMargin(value: number | undefined);
    get minVisualRangeLength(): TimeInterval | number | undefined | {
        days?: number;
        hours?: number;
        milliseconds?: number;
        minutes?: number;
        months?: number;
        quarters?: number;
        seconds?: number;
        weeks?: number;
        years?: number;
    };
    set minVisualRangeLength(value: TimeInterval | number | undefined | {
        days?: number;
        hours?: number;
        milliseconds?: number;
        minutes?: number;
        months?: number;
        quarters?: number;
        seconds?: number;
        weeks?: number;
        years?: number;
    });
    get offset(): number | undefined;
    set offset(value: number | undefined);
    get opacity(): number | undefined;
    set opacity(value: number | undefined);
    get placeholderSize(): number | null;
    set placeholderSize(value: number | null);
    get position(): Position;
    set position(value: Position);
    get singleWorkdays(): undefined | Array<Date | string | number>;
    set singleWorkdays(value: undefined | Array<Date | string | number>);
    get strips(): Array<any | {
        color?: string | undefined;
        endValue?: Date | number | string | undefined;
        label?: {
            font?: Font;
            horizontalAlignment?: HorizontalAlignment;
            text?: string | undefined;
            verticalAlignment?: VerticalAlignment;
        };
        paddingLeftRight?: number;
        paddingTopBottom?: number;
        startValue?: Date | number | string | undefined;
    } | {
        color?: string | undefined;
        endValue?: Date | number | string | undefined;
        label?: {
            font?: Font;
            text?: string | undefined;
        };
        startValue?: Date | number | string | undefined;
    }>;
    set strips(value: Array<any | {
        color?: string | undefined;
        endValue?: Date | number | string | undefined;
        label?: {
            font?: Font;
            horizontalAlignment?: HorizontalAlignment;
            text?: string | undefined;
            verticalAlignment?: VerticalAlignment;
        };
        paddingLeftRight?: number;
        paddingTopBottom?: number;
        startValue?: Date | number | string | undefined;
    } | {
        color?: string | undefined;
        endValue?: Date | number | string | undefined;
        label?: {
            font?: Font;
            text?: string | undefined;
        };
        startValue?: Date | number | string | undefined;
    }>);
    get stripStyle(): {
        label?: {
            font?: Font;
            horizontalAlignment?: HorizontalAlignment;
            verticalAlignment?: VerticalAlignment;
        };
        paddingLeftRight?: number;
        paddingTopBottom?: number;
    } | {
        label?: {
            font?: Font;
        };
    };
    set stripStyle(value: {
        label?: {
            font?: Font;
            horizontalAlignment?: HorizontalAlignment;
            verticalAlignment?: VerticalAlignment;
        };
        paddingLeftRight?: number;
        paddingTopBottom?: number;
    } | {
        label?: {
            font?: Font;
        };
    });
    get tick(): {
        color?: string;
        length?: number;
        opacity?: number | undefined;
        shift?: number;
        visible?: boolean;
        width?: number;
    };
    set tick(value: {
        color?: string;
        length?: number;
        opacity?: number | undefined;
        shift?: number;
        visible?: boolean;
        width?: number;
    });
    get tickInterval(): TimeInterval | number | {
        days?: number;
        hours?: number;
        milliseconds?: number;
        minutes?: number;
        months?: number;
        quarters?: number;
        seconds?: number;
        weeks?: number;
        years?: number;
    };
    set tickInterval(value: TimeInterval | number | {
        days?: number;
        hours?: number;
        milliseconds?: number;
        minutes?: number;
        months?: number;
        quarters?: number;
        seconds?: number;
        weeks?: number;
        years?: number;
    });
    get title(): string | {
        alignment?: HorizontalAlignment;
        font?: Font;
        margin?: number;
        text?: string | undefined;
        textOverflow?: TextOverflow;
        wordWrap?: WordWrap;
    };
    set title(value: string | {
        alignment?: HorizontalAlignment;
        font?: Font;
        margin?: number;
        text?: string | undefined;
        textOverflow?: TextOverflow;
        wordWrap?: WordWrap;
    });
    get type(): AxisScaleType | undefined;
    set type(value: AxisScaleType | undefined);
    get valueMarginsEnabled(): boolean;
    set valueMarginsEnabled(value: boolean);
    get visible(): boolean;
    set visible(value: boolean);
    get visualRange(): VisualRange | Array<number | string | Date>;
    set visualRange(value: VisualRange | Array<number | string | Date>);
    get visualRangeUpdateMode(): VisualRangeUpdateMode;
    set visualRangeUpdateMode(value: VisualRangeUpdateMode);
    get wholeRange(): VisualRange | undefined | Array<number | string | Date>;
    set wholeRange(value: VisualRange | undefined | Array<number | string | Date>);
    get width(): number;
    set width(value: number);
    get workdaysOnly(): boolean;
    set workdaysOnly(value: boolean);
    get workWeek(): Array<number>;
    set workWeek(value: Array<number>);
    get firstPointOnStartAngle(): boolean;
    set firstPointOnStartAngle(value: boolean);
    get originValue(): number | undefined;
    set originValue(value: number | undefined);
    get period(): number | undefined;
    set period(value: number | undefined);
    get startAngle(): number;
    set startAngle(value: number);
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    categoriesChange: EventEmitter<Array<number | string | Date>>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    visualRangeChange: EventEmitter<VisualRange | Array<number | string | Date>>;
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoArgumentAxisComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoArgumentAxisComponent, "dxo-argument-axis", never, { "aggregatedPointsPosition": { "alias": "aggregatedPointsPosition"; "required": false; }; "aggregationGroupWidth": { "alias": "aggregationGroupWidth"; "required": false; }; "aggregationInterval": { "alias": "aggregationInterval"; "required": false; }; "allowDecimals": { "alias": "allowDecimals"; "required": false; }; "argumentType": { "alias": "argumentType"; "required": false; }; "axisDivisionFactor": { "alias": "axisDivisionFactor"; "required": false; }; "breaks": { "alias": "breaks"; "required": false; }; "breakStyle": { "alias": "breakStyle"; "required": false; }; "categories": { "alias": "categories"; "required": false; }; "color": { "alias": "color"; "required": false; }; "constantLines": { "alias": "constantLines"; "required": false; }; "constantLineStyle": { "alias": "constantLineStyle"; "required": false; }; "customPosition": { "alias": "customPosition"; "required": false; }; "customPositionAxis": { "alias": "customPositionAxis"; "required": false; }; "discreteAxisDivisionMode": { "alias": "discreteAxisDivisionMode"; "required": false; }; "endOnTick": { "alias": "endOnTick"; "required": false; }; "grid": { "alias": "grid"; "required": false; }; "holidays": { "alias": "holidays"; "required": false; }; "hoverMode": { "alias": "hoverMode"; "required": false; }; "inverted": { "alias": "inverted"; "required": false; }; "label": { "alias": "label"; "required": false; }; "linearThreshold": { "alias": "linearThreshold"; "required": false; }; "logarithmBase": { "alias": "logarithmBase"; "required": false; }; "maxValueMargin": { "alias": "maxValueMargin"; "required": false; }; "minorGrid": { "alias": "minorGrid"; "required": false; }; "minorTick": { "alias": "minorTick"; "required": false; }; "minorTickCount": { "alias": "minorTickCount"; "required": false; }; "minorTickInterval": { "alias": "minorTickInterval"; "required": false; }; "minValueMargin": { "alias": "minValueMargin"; "required": false; }; "minVisualRangeLength": { "alias": "minVisualRangeLength"; "required": false; }; "offset": { "alias": "offset"; "required": false; }; "opacity": { "alias": "opacity"; "required": false; }; "placeholderSize": { "alias": "placeholderSize"; "required": false; }; "position": { "alias": "position"; "required": false; }; "singleWorkdays": { "alias": "singleWorkdays"; "required": false; }; "strips": { "alias": "strips"; "required": false; }; "stripStyle": { "alias": "stripStyle"; "required": false; }; "tick": { "alias": "tick"; "required": false; }; "tickInterval": { "alias": "tickInterval"; "required": false; }; "title": { "alias": "title"; "required": false; }; "type": { "alias": "type"; "required": false; }; "valueMarginsEnabled": { "alias": "valueMarginsEnabled"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "visualRange": { "alias": "visualRange"; "required": false; }; "visualRangeUpdateMode": { "alias": "visualRangeUpdateMode"; "required": false; }; "wholeRange": { "alias": "wholeRange"; "required": false; }; "width": { "alias": "width"; "required": false; }; "workdaysOnly": { "alias": "workdaysOnly"; "required": false; }; "workWeek": { "alias": "workWeek"; "required": false; }; "firstPointOnStartAngle": { "alias": "firstPointOnStartAngle"; "required": false; }; "originValue": { "alias": "originValue"; "required": false; }; "period": { "alias": "period"; "required": false; }; "startAngle": { "alias": "startAngle"; "required": false; }; }, { "categoriesChange": "categoriesChange"; "visualRangeChange": "visualRangeChange"; }, ["_breaksContentChildren", "_constantLinesContentChildren", "_stripsContentChildren"], never, true, never>;
}
declare class DxoArgumentAxisModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoArgumentAxisModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoArgumentAxisModule, never, [typeof DxoArgumentAxisComponent], [typeof DxoArgumentAxisComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoArgumentAxisModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare abstract class DxoFormat extends NestedOption {
    get currency(): string;
    set currency(value: string);
    get formatter(): Function;
    set formatter(value: Function);
    get parser(): Function;
    set parser(value: Function);
    get precision(): number;
    set precision(value: number);
    get type(): Format$1 | string;
    set type(value: Format$1 | string);
    get useCurrencyAccountingStyle(): boolean;
    set useCurrencyAccountingStyle(value: boolean);
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoFormat, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoFormat, "ng-component", never, {}, {}, never, never, true, never>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoArgumentFormatComponent extends DxoFormat implements OnDestroy, OnInit {
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoArgumentFormatComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoArgumentFormatComponent, "dxo-argument-format", never, { "currency": { "alias": "currency"; "required": false; }; "formatter": { "alias": "formatter"; "required": false; }; "parser": { "alias": "parser"; "required": false; }; "precision": { "alias": "precision"; "required": false; }; "type": { "alias": "type"; "required": false; }; "useCurrencyAccountingStyle": { "alias": "useCurrencyAccountingStyle"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoArgumentFormatModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoArgumentFormatModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoArgumentFormatModule, never, [typeof DxoArgumentFormatComponent], [typeof DxoArgumentFormatComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoArgumentFormatModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoAtComponent extends NestedOption implements OnDestroy, OnInit {
    get x(): HorizontalAlignment;
    set x(value: HorizontalAlignment);
    get y(): VerticalAlignment;
    set y(value: VerticalAlignment);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoAtComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoAtComponent, "dxo-at", never, { "x": { "alias": "x"; "required": false; }; "y": { "alias": "y"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoAtModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoAtModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoAtModule, never, [typeof DxoAtComponent], [typeof DxoAtComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoAtModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare abstract class DxoUser extends NestedOption {
    get avatarAlt(): string;
    set avatarAlt(value: string);
    get avatarUrl(): string;
    set avatarUrl(value: string);
    get id(): number | string;
    set id(value: number | string);
    get name(): string;
    set name(value: string);
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoUser, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoUser, "ng-component", never, {}, {}, never, never, true, never>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoAuthorComponent extends DxoUser implements OnDestroy, OnInit {
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoAuthorComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoAuthorComponent, "dxo-author", never, { "avatarAlt": { "alias": "avatarAlt"; "required": false; }; "avatarUrl": { "alias": "avatarUrl"; "required": false; }; "id": { "alias": "id"; "required": false; }; "name": { "alias": "name"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoAuthorModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoAuthorModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoAuthorModule, never, [typeof DxoAuthorComponent], [typeof DxoAuthorComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoAuthorModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoAutoLayoutComponent extends NestedOption implements OnDestroy, OnInit {
    get orientation(): Orientation;
    set orientation(value: Orientation);
    get type(): DataLayoutType;
    set type(value: DataLayoutType);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoAutoLayoutComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoAutoLayoutComponent, "dxo-auto-layout", never, { "orientation": { "alias": "orientation"; "required": false; }; "type": { "alias": "type"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoAutoLayoutModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoAutoLayoutModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoAutoLayoutModule, never, [typeof DxoAutoLayoutComponent], [typeof DxoAutoLayoutComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoAutoLayoutModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare abstract class DxoChartsColor extends NestedOption {
    get base(): string | undefined;
    set base(value: string | undefined);
    get fillId(): string | undefined;
    set fillId(value: string | undefined);
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChartsColor, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoChartsColor, "ng-component", never, {}, {}, never, never, true, never>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoBackgroundColorComponent extends DxoChartsColor implements OnDestroy, OnInit {
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoBackgroundColorComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoBackgroundColorComponent, "dxo-background-color", never, { "base": { "alias": "base"; "required": false; }; "fillId": { "alias": "fillId"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoBackgroundColorModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoBackgroundColorModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoBackgroundColorModule, never, [typeof DxoBackgroundColorComponent], [typeof DxoBackgroundColorComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoBackgroundColorModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoBackgroundComponent extends NestedOption implements OnDestroy, OnInit {
    get color(): string;
    set color(value: string);
    get image(): {
        location?: BackgroundImageLocation;
        url?: string | undefined;
    };
    set image(value: {
        location?: BackgroundImageLocation;
        url?: string | undefined;
    });
    get visible(): boolean;
    set visible(value: boolean);
    get borderColor(): string;
    set borderColor(value: string);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoBackgroundComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoBackgroundComponent, "dxo-background", never, { "color": { "alias": "color"; "required": false; }; "image": { "alias": "image"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "borderColor": { "alias": "borderColor"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoBackgroundModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoBackgroundModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoBackgroundModule, never, [typeof DxoBackgroundComponent], [typeof DxoBackgroundComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoBackgroundModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoBarComponent extends DxoChartCommonSeriesSettings implements OnDestroy, OnInit {
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoBarComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoBarComponent, "dxo-bar", never, { "aggregation": { "alias": "aggregation"; "required": false; }; "area": { "alias": "area"; "required": false; }; "argumentField": { "alias": "argumentField"; "required": false; }; "axis": { "alias": "axis"; "required": false; }; "bar": { "alias": "bar"; "required": false; }; "barOverlapGroup": { "alias": "barOverlapGroup"; "required": false; }; "barPadding": { "alias": "barPadding"; "required": false; }; "barWidth": { "alias": "barWidth"; "required": false; }; "border": { "alias": "border"; "required": false; }; "bubble": { "alias": "bubble"; "required": false; }; "candlestick": { "alias": "candlestick"; "required": false; }; "closeValueField": { "alias": "closeValueField"; "required": false; }; "color": { "alias": "color"; "required": false; }; "cornerRadius": { "alias": "cornerRadius"; "required": false; }; "dashStyle": { "alias": "dashStyle"; "required": false; }; "fullstackedarea": { "alias": "fullstackedarea"; "required": false; }; "fullstackedbar": { "alias": "fullstackedbar"; "required": false; }; "fullstackedline": { "alias": "fullstackedline"; "required": false; }; "fullstackedspline": { "alias": "fullstackedspline"; "required": false; }; "fullstackedsplinearea": { "alias": "fullstackedsplinearea"; "required": false; }; "highValueField": { "alias": "highValueField"; "required": false; }; "hoverMode": { "alias": "hoverMode"; "required": false; }; "hoverStyle": { "alias": "hoverStyle"; "required": false; }; "ignoreEmptyPoints": { "alias": "ignoreEmptyPoints"; "required": false; }; "innerColor": { "alias": "innerColor"; "required": false; }; "label": { "alias": "label"; "required": false; }; "line": { "alias": "line"; "required": false; }; "lowValueField": { "alias": "lowValueField"; "required": false; }; "maxLabelCount": { "alias": "maxLabelCount"; "required": false; }; "minBarSize": { "alias": "minBarSize"; "required": false; }; "opacity": { "alias": "opacity"; "required": false; }; "openValueField": { "alias": "openValueField"; "required": false; }; "pane": { "alias": "pane"; "required": false; }; "point": { "alias": "point"; "required": false; }; "rangearea": { "alias": "rangearea"; "required": false; }; "rangebar": { "alias": "rangebar"; "required": false; }; "rangeValue1Field": { "alias": "rangeValue1Field"; "required": false; }; "rangeValue2Field": { "alias": "rangeValue2Field"; "required": false; }; "reduction": { "alias": "reduction"; "required": false; }; "scatter": { "alias": "scatter"; "required": false; }; "selectionMode": { "alias": "selectionMode"; "required": false; }; "selectionStyle": { "alias": "selectionStyle"; "required": false; }; "showInLegend": { "alias": "showInLegend"; "required": false; }; "sizeField": { "alias": "sizeField"; "required": false; }; "spline": { "alias": "spline"; "required": false; }; "splinearea": { "alias": "splinearea"; "required": false; }; "stack": { "alias": "stack"; "required": false; }; "stackedarea": { "alias": "stackedarea"; "required": false; }; "stackedbar": { "alias": "stackedbar"; "required": false; }; "stackedline": { "alias": "stackedline"; "required": false; }; "stackedspline": { "alias": "stackedspline"; "required": false; }; "stackedsplinearea": { "alias": "stackedsplinearea"; "required": false; }; "steparea": { "alias": "steparea"; "required": false; }; "stepline": { "alias": "stepline"; "required": false; }; "stock": { "alias": "stock"; "required": false; }; "tagField": { "alias": "tagField"; "required": false; }; "type": { "alias": "type"; "required": false; }; "valueErrorBar": { "alias": "valueErrorBar"; "required": false; }; "valueField": { "alias": "valueField"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; "closed": { "alias": "closed"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoBarModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoBarModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoBarModule, never, [typeof DxoBarComponent], [typeof DxoBarComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoBarModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoBehaviorComponent extends NestedOption implements OnDestroy, OnInit {
    get allowSlidersSwap(): boolean;
    set allowSlidersSwap(value: boolean);
    get animationEnabled(): boolean;
    set animationEnabled(value: boolean);
    get manualRangeSelectionEnabled(): boolean;
    set manualRangeSelectionEnabled(value: boolean);
    get moveSelectedRangeByClick(): boolean;
    set moveSelectedRangeByClick(value: boolean);
    get snapToTicks(): boolean;
    set snapToTicks(value: boolean);
    get valueChangeMode(): SliderValueChangeMode;
    set valueChangeMode(value: SliderValueChangeMode);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoBehaviorComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoBehaviorComponent, "dxo-behavior", never, { "allowSlidersSwap": { "alias": "allowSlidersSwap"; "required": false; }; "animationEnabled": { "alias": "animationEnabled"; "required": false; }; "manualRangeSelectionEnabled": { "alias": "manualRangeSelectionEnabled"; "required": false; }; "moveSelectedRangeByClick": { "alias": "moveSelectedRangeByClick"; "required": false; }; "snapToTicks": { "alias": "snapToTicks"; "required": false; }; "valueChangeMode": { "alias": "valueChangeMode"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoBehaviorModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoBehaviorModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoBehaviorModule, never, [typeof DxoBehaviorComponent], [typeof DxoBehaviorComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoBehaviorModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoBorderComponent extends NestedOption implements OnDestroy, OnInit {
    get color(): string | undefined;
    set color(value: string | undefined);
    get cornerRadius(): number;
    set cornerRadius(value: number);
    get dashStyle(): DashStyle | undefined;
    set dashStyle(value: DashStyle | undefined);
    get opacity(): number | undefined;
    set opacity(value: number | undefined);
    get visible(): boolean | undefined;
    set visible(value: boolean | undefined);
    get width(): number | undefined;
    set width(value: number | undefined);
    get bottom(): boolean;
    set bottom(value: boolean);
    get left(): boolean;
    set left(value: boolean);
    get right(): boolean;
    set right(value: boolean);
    get top(): boolean;
    set top(value: boolean);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoBorderComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoBorderComponent, "dxo-border", never, { "color": { "alias": "color"; "required": false; }; "cornerRadius": { "alias": "cornerRadius"; "required": false; }; "dashStyle": { "alias": "dashStyle"; "required": false; }; "opacity": { "alias": "opacity"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; "bottom": { "alias": "bottom"; "required": false; }; "left": { "alias": "left"; "required": false; }; "right": { "alias": "right"; "required": false; }; "top": { "alias": "top"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoBorderModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoBorderModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoBorderModule, never, [typeof DxoBorderComponent], [typeof DxoBorderComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoBorderModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoBoundaryOffsetComponent extends NestedOption implements OnDestroy, OnInit {
    get x(): number;
    set x(value: number);
    get y(): number;
    set y(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoBoundaryOffsetComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoBoundaryOffsetComponent, "dxo-boundary-offset", never, { "x": { "alias": "x"; "required": false; }; "y": { "alias": "y"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoBoundaryOffsetModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoBoundaryOffsetModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoBoundaryOffsetModule, never, [typeof DxoBoundaryOffsetComponent], [typeof DxoBoundaryOffsetComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoBoundaryOffsetModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare abstract class DxoBoxOptions extends NestedOption {
    get align(): Distribution;
    set align(value: Distribution);
    get crossAlign(): CrosswiseDistribution;
    set crossAlign(value: CrosswiseDistribution);
    get dataSource(): Store | DataSource | Options | null | string | Array<dxBoxItem | string | any>;
    set dataSource(value: Store | DataSource | Options | null | string | Array<dxBoxItem | string | any>);
    get direction(): BoxDirection;
    set direction(value: BoxDirection);
    get disabled(): boolean;
    set disabled(value: boolean);
    get elementAttr(): any;
    set elementAttr(value: any);
    get height(): number | string | undefined;
    set height(value: number | string | undefined);
    get hoverStateEnabled(): boolean;
    set hoverStateEnabled(value: boolean);
    get itemHoldTimeout(): number;
    set itemHoldTimeout(value: number);
    get items(): Array<string | any | {
        baseSize?: number | string;
        box?: Properties | undefined;
        disabled?: boolean;
        html?: string;
        ratio?: number;
        shrink?: number;
        template?: any;
        text?: string;
        visible?: boolean;
    }>;
    set items(value: Array<string | any | {
        baseSize?: number | string;
        box?: Properties | undefined;
        disabled?: boolean;
        html?: string;
        ratio?: number;
        shrink?: number;
        template?: any;
        text?: string;
        visible?: boolean;
    }>);
    get itemTemplate(): any;
    set itemTemplate(value: any);
    get onContentReady(): ((e: ContentReadyEvent) => void);
    set onContentReady(value: ((e: ContentReadyEvent) => void));
    get onDisposing(): ((e: DisposingEvent) => void);
    set onDisposing(value: ((e: DisposingEvent) => void));
    get onInitialized(): ((e: InitializedEvent) => void);
    set onInitialized(value: ((e: InitializedEvent) => void));
    get onItemClick(): ((e: ItemClickEvent) => void);
    set onItemClick(value: ((e: ItemClickEvent) => void));
    get onItemContextMenu(): ((e: ItemContextMenuEvent) => void);
    set onItemContextMenu(value: ((e: ItemContextMenuEvent) => void));
    get onItemHold(): ((e: ItemHoldEvent) => void);
    set onItemHold(value: ((e: ItemHoldEvent) => void));
    get onItemRendered(): ((e: ItemRenderedEvent) => void);
    set onItemRendered(value: ((e: ItemRenderedEvent) => void));
    get onOptionChanged(): ((e: OptionChangedEvent) => void);
    set onOptionChanged(value: ((e: OptionChangedEvent) => void));
    get rtlEnabled(): boolean;
    set rtlEnabled(value: boolean);
    get visible(): boolean;
    set visible(value: boolean);
    get width(): number | string | undefined;
    set width(value: number | string | undefined);
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoBoxOptions, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoBoxOptions, "ng-component", never, {}, {}, never, never, true, never>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoBoxComponent extends DxoBoxOptions implements OnDestroy, OnInit {
    set _itemsContentChildren(value: QueryList<CollectionNestedOption>);
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    itemsChange: EventEmitter<Array<string | any | {
        baseSize?: number | string;
        box?: Properties | undefined;
        disabled?: boolean;
        html?: string;
        ratio?: number;
        shrink?: number;
        template?: any;
        text?: string;
        visible?: boolean;
    }>>;
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoBoxComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoBoxComponent, "dxo-box", never, { "align": { "alias": "align"; "required": false; }; "crossAlign": { "alias": "crossAlign"; "required": false; }; "dataSource": { "alias": "dataSource"; "required": false; }; "direction": { "alias": "direction"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "elementAttr": { "alias": "elementAttr"; "required": false; }; "height": { "alias": "height"; "required": false; }; "hoverStateEnabled": { "alias": "hoverStateEnabled"; "required": false; }; "itemHoldTimeout": { "alias": "itemHoldTimeout"; "required": false; }; "items": { "alias": "items"; "required": false; }; "itemTemplate": { "alias": "itemTemplate"; "required": false; }; "onContentReady": { "alias": "onContentReady"; "required": false; }; "onDisposing": { "alias": "onDisposing"; "required": false; }; "onInitialized": { "alias": "onInitialized"; "required": false; }; "onItemClick": { "alias": "onItemClick"; "required": false; }; "onItemContextMenu": { "alias": "onItemContextMenu"; "required": false; }; "onItemHold": { "alias": "onItemHold"; "required": false; }; "onItemRendered": { "alias": "onItemRendered"; "required": false; }; "onOptionChanged": { "alias": "onOptionChanged"; "required": false; }; "rtlEnabled": { "alias": "rtlEnabled"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, { "itemsChange": "itemsChange"; }, ["_itemsContentChildren"], never, true, never>;
}
declare class DxoBoxModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoBoxModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoBoxModule, never, [typeof DxoBoxComponent], [typeof DxoBoxComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoBoxModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare abstract class DxiVizScaleBreak extends CollectionNestedOption {
    get endValue(): Date | number | string | undefined;
    set endValue(value: Date | number | string | undefined);
    get startValue(): Date | number | string | undefined;
    set startValue(value: Date | number | string | undefined);
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiVizScaleBreak, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiVizScaleBreak, "ng-component", never, {}, {}, never, never, true, never>;
}

declare class DxiBreakComponent extends DxiVizScaleBreak {
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiBreakComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiBreakComponent, "dxi-break", never, { "endValue": { "alias": "endValue"; "required": false; }; "startValue": { "alias": "startValue"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxiBreakModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiBreakModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiBreakModule, never, [typeof DxiBreakComponent], [typeof DxiBreakComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiBreakModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoBreakStyleComponent extends NestedOption implements OnDestroy, OnInit {
    get color(): string;
    set color(value: string);
    get line(): ScaleBreakLineStyle;
    set line(value: ScaleBreakLineStyle);
    get width(): number;
    set width(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoBreakStyleComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoBreakStyleComponent, "dxo-break-style", never, { "color": { "alias": "color"; "required": false; }; "line": { "alias": "line"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoBreakStyleModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoBreakStyleModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoBreakStyleModule, never, [typeof DxoBreakStyleComponent], [typeof DxoBreakStyleComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoBreakStyleModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoBubbleComponent extends DxoChartCommonSeriesSettings implements OnDestroy, OnInit {
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoBubbleComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoBubbleComponent, "dxo-bubble", never, { "aggregation": { "alias": "aggregation"; "required": false; }; "area": { "alias": "area"; "required": false; }; "argumentField": { "alias": "argumentField"; "required": false; }; "axis": { "alias": "axis"; "required": false; }; "bar": { "alias": "bar"; "required": false; }; "barOverlapGroup": { "alias": "barOverlapGroup"; "required": false; }; "barPadding": { "alias": "barPadding"; "required": false; }; "barWidth": { "alias": "barWidth"; "required": false; }; "border": { "alias": "border"; "required": false; }; "bubble": { "alias": "bubble"; "required": false; }; "candlestick": { "alias": "candlestick"; "required": false; }; "closeValueField": { "alias": "closeValueField"; "required": false; }; "color": { "alias": "color"; "required": false; }; "cornerRadius": { "alias": "cornerRadius"; "required": false; }; "dashStyle": { "alias": "dashStyle"; "required": false; }; "fullstackedarea": { "alias": "fullstackedarea"; "required": false; }; "fullstackedbar": { "alias": "fullstackedbar"; "required": false; }; "fullstackedline": { "alias": "fullstackedline"; "required": false; }; "fullstackedspline": { "alias": "fullstackedspline"; "required": false; }; "fullstackedsplinearea": { "alias": "fullstackedsplinearea"; "required": false; }; "highValueField": { "alias": "highValueField"; "required": false; }; "hoverMode": { "alias": "hoverMode"; "required": false; }; "hoverStyle": { "alias": "hoverStyle"; "required": false; }; "ignoreEmptyPoints": { "alias": "ignoreEmptyPoints"; "required": false; }; "innerColor": { "alias": "innerColor"; "required": false; }; "label": { "alias": "label"; "required": false; }; "line": { "alias": "line"; "required": false; }; "lowValueField": { "alias": "lowValueField"; "required": false; }; "maxLabelCount": { "alias": "maxLabelCount"; "required": false; }; "minBarSize": { "alias": "minBarSize"; "required": false; }; "opacity": { "alias": "opacity"; "required": false; }; "openValueField": { "alias": "openValueField"; "required": false; }; "pane": { "alias": "pane"; "required": false; }; "point": { "alias": "point"; "required": false; }; "rangearea": { "alias": "rangearea"; "required": false; }; "rangebar": { "alias": "rangebar"; "required": false; }; "rangeValue1Field": { "alias": "rangeValue1Field"; "required": false; }; "rangeValue2Field": { "alias": "rangeValue2Field"; "required": false; }; "reduction": { "alias": "reduction"; "required": false; }; "scatter": { "alias": "scatter"; "required": false; }; "selectionMode": { "alias": "selectionMode"; "required": false; }; "selectionStyle": { "alias": "selectionStyle"; "required": false; }; "showInLegend": { "alias": "showInLegend"; "required": false; }; "sizeField": { "alias": "sizeField"; "required": false; }; "spline": { "alias": "spline"; "required": false; }; "splinearea": { "alias": "splinearea"; "required": false; }; "stack": { "alias": "stack"; "required": false; }; "stackedarea": { "alias": "stackedarea"; "required": false; }; "stackedbar": { "alias": "stackedbar"; "required": false; }; "stackedline": { "alias": "stackedline"; "required": false; }; "stackedspline": { "alias": "stackedspline"; "required": false; }; "stackedsplinearea": { "alias": "stackedsplinearea"; "required": false; }; "steparea": { "alias": "steparea"; "required": false; }; "stepline": { "alias": "stepline"; "required": false; }; "stock": { "alias": "stock"; "required": false; }; "tagField": { "alias": "tagField"; "required": false; }; "type": { "alias": "type"; "required": false; }; "valueErrorBar": { "alias": "valueErrorBar"; "required": false; }; "valueField": { "alias": "valueField"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoBubbleModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoBubbleModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoBubbleModule, never, [typeof DxoBubbleComponent], [typeof DxoBubbleComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoBubbleModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare abstract class DxiTextEditorButton extends CollectionNestedOption {
    get location(): TextEditorButtonLocation;
    set location(value: TextEditorButtonLocation);
    get name(): string | undefined | DataGridPredefinedColumnButton | TreeListPredefinedColumnButton;
    set name(value: string | undefined | DataGridPredefinedColumnButton | TreeListPredefinedColumnButton);
    get options(): Properties$1 | undefined;
    set options(value: Properties$1 | undefined);
    get cssClass(): string;
    set cssClass(value: string);
    get disabled(): boolean | Function;
    set disabled(value: boolean | Function);
    get hint(): string;
    set hint(value: string);
    get icon(): string;
    set icon(value: string);
    get onClick(): ((e: ColumnButtonClickEvent) => void);
    set onClick(value: ((e: ColumnButtonClickEvent) => void));
    get template(): any;
    set template(value: any);
    get text(): string;
    set text(value: string);
    get visible(): boolean | Function;
    set visible(value: boolean | Function);
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiTextEditorButton, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiTextEditorButton, "ng-component", never, {}, {}, never, never, true, never>;
}

declare class DxiButtonComponent extends DxiTextEditorButton {
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiButtonComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiButtonComponent, "dxi-button", never, { "location": { "alias": "location"; "required": false; }; "name": { "alias": "name"; "required": false; }; "options": { "alias": "options"; "required": false; }; "cssClass": { "alias": "cssClass"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "hint": { "alias": "hint"; "required": false; }; "icon": { "alias": "icon"; "required": false; }; "onClick": { "alias": "onClick"; "required": false; }; "template": { "alias": "template"; "required": false; }; "text": { "alias": "text"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxiButtonModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiButtonModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiButtonModule, never, [typeof DxiButtonComponent], [typeof DxiButtonComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiButtonModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare abstract class DxoButtonOptions extends NestedOption {
    get accessKey(): string | undefined;
    set accessKey(value: string | undefined);
    get activeStateEnabled(): boolean;
    set activeStateEnabled(value: boolean);
    get disabled(): boolean;
    set disabled(value: boolean);
    get elementAttr(): any;
    set elementAttr(value: any);
    get focusStateEnabled(): boolean;
    set focusStateEnabled(value: boolean);
    get height(): number | string | undefined;
    set height(value: number | string | undefined);
    get hint(): string | undefined;
    set hint(value: string | undefined);
    get hoverStateEnabled(): boolean;
    set hoverStateEnabled(value: boolean);
    get icon(): string;
    set icon(value: string);
    get onClick(): ((e: ClickEvent) => void);
    set onClick(value: ((e: ClickEvent) => void));
    get onContentReady(): ((e: ContentReadyEvent$1) => void);
    set onContentReady(value: ((e: ContentReadyEvent$1) => void));
    get onDisposing(): ((e: DisposingEvent$1) => void);
    set onDisposing(value: ((e: DisposingEvent$1) => void));
    get onInitialized(): ((e: InitializedEvent$1) => void);
    set onInitialized(value: ((e: InitializedEvent$1) => void));
    get onOptionChanged(): ((e: OptionChangedEvent$1) => void);
    set onOptionChanged(value: ((e: OptionChangedEvent$1) => void));
    get rtlEnabled(): boolean;
    set rtlEnabled(value: boolean);
    get stylingMode(): ButtonStyle;
    set stylingMode(value: ButtonStyle);
    get tabIndex(): number;
    set tabIndex(value: number);
    get template(): any;
    set template(value: any);
    get text(): string;
    set text(value: string);
    get type(): ButtonType | string;
    set type(value: ButtonType | string);
    get useSubmitBehavior(): boolean;
    set useSubmitBehavior(value: boolean);
    get validationGroup(): string | undefined;
    set validationGroup(value: string | undefined);
    get visible(): boolean;
    set visible(value: boolean);
    get width(): number | string | undefined;
    set width(value: number | string | undefined);
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoButtonOptions, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoButtonOptions, "ng-component", never, {}, {}, never, never, true, never>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoButtonOptionsComponent extends DxoButtonOptions implements OnDestroy, OnInit {
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoButtonOptionsComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoButtonOptionsComponent, "dxo-button-options", never, { "accessKey": { "alias": "accessKey"; "required": false; }; "activeStateEnabled": { "alias": "activeStateEnabled"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "elementAttr": { "alias": "elementAttr"; "required": false; }; "focusStateEnabled": { "alias": "focusStateEnabled"; "required": false; }; "height": { "alias": "height"; "required": false; }; "hint": { "alias": "hint"; "required": false; }; "hoverStateEnabled": { "alias": "hoverStateEnabled"; "required": false; }; "icon": { "alias": "icon"; "required": false; }; "onClick": { "alias": "onClick"; "required": false; }; "onContentReady": { "alias": "onContentReady"; "required": false; }; "onDisposing": { "alias": "onDisposing"; "required": false; }; "onInitialized": { "alias": "onInitialized"; "required": false; }; "onOptionChanged": { "alias": "onOptionChanged"; "required": false; }; "rtlEnabled": { "alias": "rtlEnabled"; "required": false; }; "stylingMode": { "alias": "stylingMode"; "required": false; }; "tabIndex": { "alias": "tabIndex"; "required": false; }; "template": { "alias": "template"; "required": false; }; "text": { "alias": "text"; "required": false; }; "type": { "alias": "type"; "required": false; }; "useSubmitBehavior": { "alias": "useSubmitBehavior"; "required": false; }; "validationGroup": { "alias": "validationGroup"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoButtonOptionsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoButtonOptionsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoButtonOptionsModule, never, [typeof DxoButtonOptionsComponent], [typeof DxoButtonOptionsComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoButtonOptionsModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare abstract class DxoCalendarOptions extends NestedOption {
    get accessKey(): string | undefined;
    set accessKey(value: string | undefined);
    get activeStateEnabled(): boolean;
    set activeStateEnabled(value: boolean);
    get cellTemplate(): any;
    set cellTemplate(value: any);
    get dateSerializationFormat(): string | undefined;
    set dateSerializationFormat(value: string | undefined);
    get disabled(): boolean;
    set disabled(value: boolean);
    get disabledDates(): Function | null | Array<Date>;
    set disabledDates(value: Function | null | Array<Date>);
    get elementAttr(): any;
    set elementAttr(value: any);
    get firstDayOfWeek(): DayOfWeek | undefined;
    set firstDayOfWeek(value: DayOfWeek | undefined);
    get focusStateEnabled(): boolean;
    set focusStateEnabled(value: boolean);
    get height(): number | string | undefined;
    set height(value: number | string | undefined);
    get hint(): string | undefined;
    set hint(value: string | undefined);
    get hoverStateEnabled(): boolean;
    set hoverStateEnabled(value: boolean);
    get isDirty(): boolean;
    set isDirty(value: boolean);
    get isValid(): boolean;
    set isValid(value: boolean);
    get max(): Date | number | null | string;
    set max(value: Date | number | null | string);
    get maxZoomLevel(): CalendarZoomLevel;
    set maxZoomLevel(value: CalendarZoomLevel);
    get min(): Date | number | null | string;
    set min(value: Date | number | null | string);
    get minZoomLevel(): CalendarZoomLevel;
    set minZoomLevel(value: CalendarZoomLevel);
    get name(): string;
    set name(value: string);
    get onDisposing(): ((e: DisposingEvent$2) => void);
    set onDisposing(value: ((e: DisposingEvent$2) => void));
    get onInitialized(): ((e: InitializedEvent$2) => void);
    set onInitialized(value: ((e: InitializedEvent$2) => void));
    get onOptionChanged(): ((e: OptionChangedEvent$2) => void);
    set onOptionChanged(value: ((e: OptionChangedEvent$2) => void));
    get onValueChanged(): ((e: ValueChangedEvent) => void);
    set onValueChanged(value: ((e: ValueChangedEvent) => void));
    get readOnly(): boolean;
    set readOnly(value: boolean);
    get rtlEnabled(): boolean;
    set rtlEnabled(value: boolean);
    get selectionMode(): CalendarSelectionMode;
    set selectionMode(value: CalendarSelectionMode);
    get selectWeekOnClick(): boolean;
    set selectWeekOnClick(value: boolean);
    get showTodayButton(): boolean;
    set showTodayButton(value: boolean);
    get showWeekNumbers(): boolean;
    set showWeekNumbers(value: boolean);
    get tabIndex(): number;
    set tabIndex(value: number);
    get validationError(): any | null;
    set validationError(value: any | null);
    get validationErrors(): null | Array<any>;
    set validationErrors(value: null | Array<any>);
    get validationMessageMode(): ValidationMessageMode;
    set validationMessageMode(value: ValidationMessageMode);
    get validationMessagePosition(): Position;
    set validationMessagePosition(value: Position);
    get validationStatus(): ValidationStatus;
    set validationStatus(value: ValidationStatus);
    get value(): Date | number | null | string | Array<Date | number | string | null>;
    set value(value: Date | number | null | string | Array<Date | number | string | null>);
    get visible(): boolean;
    set visible(value: boolean);
    get weekNumberRule(): WeekNumberRule;
    set weekNumberRule(value: WeekNumberRule);
    get width(): number | string | undefined;
    set width(value: number | string | undefined);
    get zoomLevel(): CalendarZoomLevel;
    set zoomLevel(value: CalendarZoomLevel);
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoCalendarOptions, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoCalendarOptions, "ng-component", never, {}, {}, never, never, true, never>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoCalendarOptionsComponent extends DxoCalendarOptions implements OnDestroy, OnInit {
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    valueChange: EventEmitter<Date | number | null | string | Array<Date | number | string | null>>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    zoomLevelChange: EventEmitter<CalendarZoomLevel>;
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoCalendarOptionsComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoCalendarOptionsComponent, "dxo-calendar-options", never, { "accessKey": { "alias": "accessKey"; "required": false; }; "activeStateEnabled": { "alias": "activeStateEnabled"; "required": false; }; "cellTemplate": { "alias": "cellTemplate"; "required": false; }; "dateSerializationFormat": { "alias": "dateSerializationFormat"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "disabledDates": { "alias": "disabledDates"; "required": false; }; "elementAttr": { "alias": "elementAttr"; "required": false; }; "firstDayOfWeek": { "alias": "firstDayOfWeek"; "required": false; }; "focusStateEnabled": { "alias": "focusStateEnabled"; "required": false; }; "height": { "alias": "height"; "required": false; }; "hint": { "alias": "hint"; "required": false; }; "hoverStateEnabled": { "alias": "hoverStateEnabled"; "required": false; }; "isDirty": { "alias": "isDirty"; "required": false; }; "isValid": { "alias": "isValid"; "required": false; }; "max": { "alias": "max"; "required": false; }; "maxZoomLevel": { "alias": "maxZoomLevel"; "required": false; }; "min": { "alias": "min"; "required": false; }; "minZoomLevel": { "alias": "minZoomLevel"; "required": false; }; "name": { "alias": "name"; "required": false; }; "onDisposing": { "alias": "onDisposing"; "required": false; }; "onInitialized": { "alias": "onInitialized"; "required": false; }; "onOptionChanged": { "alias": "onOptionChanged"; "required": false; }; "onValueChanged": { "alias": "onValueChanged"; "required": false; }; "readOnly": { "alias": "readOnly"; "required": false; }; "rtlEnabled": { "alias": "rtlEnabled"; "required": false; }; "selectionMode": { "alias": "selectionMode"; "required": false; }; "selectWeekOnClick": { "alias": "selectWeekOnClick"; "required": false; }; "showTodayButton": { "alias": "showTodayButton"; "required": false; }; "showWeekNumbers": { "alias": "showWeekNumbers"; "required": false; }; "tabIndex": { "alias": "tabIndex"; "required": false; }; "validationError": { "alias": "validationError"; "required": false; }; "validationErrors": { "alias": "validationErrors"; "required": false; }; "validationMessageMode": { "alias": "validationMessageMode"; "required": false; }; "validationMessagePosition": { "alias": "validationMessagePosition"; "required": false; }; "validationStatus": { "alias": "validationStatus"; "required": false; }; "value": { "alias": "value"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "weekNumberRule": { "alias": "weekNumberRule"; "required": false; }; "width": { "alias": "width"; "required": false; }; "zoomLevel": { "alias": "zoomLevel"; "required": false; }; }, { "valueChange": "valueChange"; "zoomLevelChange": "zoomLevelChange"; }, never, never, true, never>;
}
declare class DxoCalendarOptionsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoCalendarOptionsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoCalendarOptionsModule, never, [typeof DxoCalendarOptionsComponent], [typeof DxoCalendarOptionsComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoCalendarOptionsModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoCandlestickComponent extends DxoChartCommonSeriesSettings implements OnDestroy, OnInit {
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoCandlestickComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoCandlestickComponent, "dxo-candlestick", never, { "aggregation": { "alias": "aggregation"; "required": false; }; "area": { "alias": "area"; "required": false; }; "argumentField": { "alias": "argumentField"; "required": false; }; "axis": { "alias": "axis"; "required": false; }; "bar": { "alias": "bar"; "required": false; }; "barOverlapGroup": { "alias": "barOverlapGroup"; "required": false; }; "barPadding": { "alias": "barPadding"; "required": false; }; "barWidth": { "alias": "barWidth"; "required": false; }; "border": { "alias": "border"; "required": false; }; "bubble": { "alias": "bubble"; "required": false; }; "candlestick": { "alias": "candlestick"; "required": false; }; "closeValueField": { "alias": "closeValueField"; "required": false; }; "color": { "alias": "color"; "required": false; }; "cornerRadius": { "alias": "cornerRadius"; "required": false; }; "dashStyle": { "alias": "dashStyle"; "required": false; }; "fullstackedarea": { "alias": "fullstackedarea"; "required": false; }; "fullstackedbar": { "alias": "fullstackedbar"; "required": false; }; "fullstackedline": { "alias": "fullstackedline"; "required": false; }; "fullstackedspline": { "alias": "fullstackedspline"; "required": false; }; "fullstackedsplinearea": { "alias": "fullstackedsplinearea"; "required": false; }; "highValueField": { "alias": "highValueField"; "required": false; }; "hoverMode": { "alias": "hoverMode"; "required": false; }; "hoverStyle": { "alias": "hoverStyle"; "required": false; }; "ignoreEmptyPoints": { "alias": "ignoreEmptyPoints"; "required": false; }; "innerColor": { "alias": "innerColor"; "required": false; }; "label": { "alias": "label"; "required": false; }; "line": { "alias": "line"; "required": false; }; "lowValueField": { "alias": "lowValueField"; "required": false; }; "maxLabelCount": { "alias": "maxLabelCount"; "required": false; }; "minBarSize": { "alias": "minBarSize"; "required": false; }; "opacity": { "alias": "opacity"; "required": false; }; "openValueField": { "alias": "openValueField"; "required": false; }; "pane": { "alias": "pane"; "required": false; }; "point": { "alias": "point"; "required": false; }; "rangearea": { "alias": "rangearea"; "required": false; }; "rangebar": { "alias": "rangebar"; "required": false; }; "rangeValue1Field": { "alias": "rangeValue1Field"; "required": false; }; "rangeValue2Field": { "alias": "rangeValue2Field"; "required": false; }; "reduction": { "alias": "reduction"; "required": false; }; "scatter": { "alias": "scatter"; "required": false; }; "selectionMode": { "alias": "selectionMode"; "required": false; }; "selectionStyle": { "alias": "selectionStyle"; "required": false; }; "showInLegend": { "alias": "showInLegend"; "required": false; }; "sizeField": { "alias": "sizeField"; "required": false; }; "spline": { "alias": "spline"; "required": false; }; "splinearea": { "alias": "splinearea"; "required": false; }; "stack": { "alias": "stack"; "required": false; }; "stackedarea": { "alias": "stackedarea"; "required": false; }; "stackedbar": { "alias": "stackedbar"; "required": false; }; "stackedline": { "alias": "stackedline"; "required": false; }; "stackedspline": { "alias": "stackedspline"; "required": false; }; "stackedsplinearea": { "alias": "stackedsplinearea"; "required": false; }; "steparea": { "alias": "steparea"; "required": false; }; "stepline": { "alias": "stepline"; "required": false; }; "stock": { "alias": "stock"; "required": false; }; "tagField": { "alias": "tagField"; "required": false; }; "type": { "alias": "type"; "required": false; }; "valueErrorBar": { "alias": "valueErrorBar"; "required": false; }; "valueField": { "alias": "valueField"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoCandlestickModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoCandlestickModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoCandlestickModule, never, [typeof DxoCandlestickComponent], [typeof DxoCandlestickComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoCandlestickModule>;
}

declare class DxiCenterComponent extends CollectionNestedOption {
    get lat(): number;
    set lat(value: number);
    get lng(): number;
    set lng(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiCenterComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiCenterComponent, "dxi-center", never, { "lat": { "alias": "lat"; "required": false; }; "lng": { "alias": "lng"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxiCenterModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiCenterModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiCenterModule, never, [typeof DxiCenterComponent], [typeof DxiCenterComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiCenterModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare abstract class DxiDataChange extends CollectionNestedOption {
    get data(): any;
    set data(value: any);
    get insertAfterKey(): any;
    set insertAfterKey(value: any);
    get insertBeforeKey(): any;
    set insertBeforeKey(value: any);
    get key(): any;
    set key(value: any);
    get type(): DataChangeType;
    set type(value: DataChangeType);
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiDataChange, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiDataChange, "ng-component", never, {}, {}, never, never, true, never>;
}

declare class DxiChangeComponent extends DxiDataChange {
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiChangeComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiChangeComponent, "dxi-change", never, { "data": { "alias": "data"; "required": false; }; "insertAfterKey": { "alias": "insertAfterKey"; "required": false; }; "insertBeforeKey": { "alias": "insertBeforeKey"; "required": false; }; "key": { "alias": "key"; "required": false; }; "type": { "alias": "type"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxiChangeModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiChangeModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiChangeModule, never, [typeof DxiChangeComponent], [typeof DxiChangeComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiChangeModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoChartComponent extends NestedOption implements OnDestroy, OnInit {
    set _seriesContentChildren(value: QueryList<CollectionNestedOption>);
    get barGroupPadding(): number;
    set barGroupPadding(value: number);
    get barGroupWidth(): number | undefined;
    set barGroupWidth(value: number | undefined);
    get bottomIndent(): number;
    set bottomIndent(value: number);
    get commonSeriesSettings(): any;
    set commonSeriesSettings(value: any);
    get dataPrepareSettings(): {
        checkTypeForAllData?: boolean;
        convertToAxisDataType?: boolean;
        sortingMethod?: boolean | Function;
    };
    set dataPrepareSettings(value: {
        checkTypeForAllData?: boolean;
        convertToAxisDataType?: boolean;
        sortingMethod?: boolean | Function;
    });
    get maxBubbleSize(): number;
    set maxBubbleSize(value: number);
    get minBubbleSize(): number;
    set minBubbleSize(value: number);
    get negativesAsZeroes(): boolean;
    set negativesAsZeroes(value: boolean);
    get palette(): Palette | string | Array<string>;
    set palette(value: Palette | string | Array<string>);
    get paletteExtensionMode(): PaletteExtensionMode;
    set paletteExtensionMode(value: PaletteExtensionMode);
    get series(): ChartSeries | any | undefined | Array<ChartSeries | any>;
    set series(value: ChartSeries | any | undefined | Array<ChartSeries | any>);
    get seriesTemplate(): {
        customizeSeries?: Function;
        nameField?: string;
    };
    set seriesTemplate(value: {
        customizeSeries?: Function;
        nameField?: string;
    });
    get topIndent(): number;
    set topIndent(value: number);
    get valueAxis(): {
        inverted?: boolean;
        logarithmBase?: number;
        max?: number | undefined;
        min?: number | undefined;
        type?: ChartAxisScale | undefined;
        valueType?: ChartsDataType | undefined;
    };
    set valueAxis(value: {
        inverted?: boolean;
        logarithmBase?: number;
        max?: number | undefined;
        min?: number | undefined;
        type?: ChartAxisScale | undefined;
        valueType?: ChartsDataType | undefined;
    });
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChartComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoChartComponent, "dxo-chart", never, { "barGroupPadding": { "alias": "barGroupPadding"; "required": false; }; "barGroupWidth": { "alias": "barGroupWidth"; "required": false; }; "bottomIndent": { "alias": "bottomIndent"; "required": false; }; "commonSeriesSettings": { "alias": "commonSeriesSettings"; "required": false; }; "dataPrepareSettings": { "alias": "dataPrepareSettings"; "required": false; }; "maxBubbleSize": { "alias": "maxBubbleSize"; "required": false; }; "minBubbleSize": { "alias": "minBubbleSize"; "required": false; }; "negativesAsZeroes": { "alias": "negativesAsZeroes"; "required": false; }; "palette": { "alias": "palette"; "required": false; }; "paletteExtensionMode": { "alias": "paletteExtensionMode"; "required": false; }; "series": { "alias": "series"; "required": false; }; "seriesTemplate": { "alias": "seriesTemplate"; "required": false; }; "topIndent": { "alias": "topIndent"; "required": false; }; "valueAxis": { "alias": "valueAxis"; "required": false; }; }, {}, ["_seriesContentChildren"], never, true, never>;
}
declare class DxoChartModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChartModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoChartModule, never, [typeof DxoChartComponent], [typeof DxoChartComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoChartModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoColCountByScreenComponent extends NestedOption implements OnDestroy, OnInit {
    get lg(): number | undefined;
    set lg(value: number | undefined);
    get md(): number | undefined;
    set md(value: number | undefined);
    get sm(): number | undefined;
    set sm(value: number | undefined);
    get xs(): number | undefined;
    set xs(value: number | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoColCountByScreenComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoColCountByScreenComponent, "dxo-col-count-by-screen", never, { "lg": { "alias": "lg"; "required": false; }; "md": { "alias": "md"; "required": false; }; "sm": { "alias": "sm"; "required": false; }; "xs": { "alias": "xs"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoColCountByScreenModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoColCountByScreenModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoColCountByScreenModule, never, [typeof DxoColCountByScreenComponent], [typeof DxoColCountByScreenComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoColCountByScreenModule>;
}

declare class DxiColComponent extends CollectionNestedOption {
    get baseSize(): number | string;
    set baseSize(value: number | string);
    get ratio(): number;
    set ratio(value: number);
    get screen(): string | undefined;
    set screen(value: string | undefined);
    get shrink(): number;
    set shrink(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiColComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiColComponent, "dxi-col", never, { "baseSize": { "alias": "baseSize"; "required": false; }; "ratio": { "alias": "ratio"; "required": false; }; "screen": { "alias": "screen"; "required": false; }; "shrink": { "alias": "shrink"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxiColModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiColModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiColModule, never, [typeof DxiColComponent], [typeof DxiColComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiColModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoCollisionComponent extends NestedOption implements OnDestroy, OnInit {
    get x(): CollisionResolution;
    set x(value: CollisionResolution);
    get y(): CollisionResolution;
    set y(value: CollisionResolution);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoCollisionComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoCollisionComponent, "dxo-collision", never, { "x": { "alias": "x"; "required": false; }; "y": { "alias": "y"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoCollisionModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoCollisionModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoCollisionModule, never, [typeof DxoCollisionComponent], [typeof DxoCollisionComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoCollisionModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoColorComponent extends DxoChartsColor implements OnDestroy, OnInit {
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoColorComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoColorComponent, "dxo-color", never, { "base": { "alias": "base"; "required": false; }; "fillId": { "alias": "fillId"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoColorModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoColorModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoColorModule, never, [typeof DxoColorComponent], [typeof DxoColorComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoColorModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoColorizerComponent extends NestedOption implements OnDestroy, OnInit {
    get colorCodeField(): string | undefined;
    set colorCodeField(value: string | undefined);
    get colorizeGroups(): boolean;
    set colorizeGroups(value: boolean);
    get palette(): Palette | string | Array<string>;
    set palette(value: Palette | string | Array<string>);
    get paletteExtensionMode(): PaletteExtensionMode;
    set paletteExtensionMode(value: PaletteExtensionMode);
    get range(): undefined | Array<number>;
    set range(value: undefined | Array<number>);
    get type(): TreeMapColorizerType | undefined;
    set type(value: TreeMapColorizerType | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoColorizerComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoColorizerComponent, "dxo-colorizer", never, { "colorCodeField": { "alias": "colorCodeField"; "required": false; }; "colorizeGroups": { "alias": "colorizeGroups"; "required": false; }; "palette": { "alias": "palette"; "required": false; }; "paletteExtensionMode": { "alias": "paletteExtensionMode"; "required": false; }; "range": { "alias": "range"; "required": false; }; "type": { "alias": "type"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoColorizerModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoColorizerModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoColorizerModule, never, [typeof DxoColorizerComponent], [typeof DxoColorizerComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoColorizerModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare abstract class DxoColumnChooser extends NestedOption {
    get allowSearch(): boolean;
    set allowSearch(value: boolean);
    get container(): UserDefinedElement | string | undefined;
    set container(value: UserDefinedElement | string | undefined);
    get emptyPanelText(): string;
    set emptyPanelText(value: string);
    get enabled(): boolean;
    set enabled(value: boolean);
    get height(): number | string;
    set height(value: number | string);
    get mode(): ColumnChooserMode;
    set mode(value: ColumnChooserMode);
    get position(): PositionConfig | undefined;
    set position(value: PositionConfig | undefined);
    get search(): ColumnChooserSearchConfig;
    set search(value: ColumnChooserSearchConfig);
    get searchTimeout(): number;
    set searchTimeout(value: number);
    get selection(): ColumnChooserSelectionConfig;
    set selection(value: ColumnChooserSelectionConfig);
    get sortOrder(): SortOrder | undefined;
    set sortOrder(value: SortOrder | undefined);
    get title(): string;
    set title(value: string);
    get width(): number | string;
    set width(value: number | string);
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoColumnChooser, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoColumnChooser, "ng-component", never, {}, {}, never, never, true, never>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoColumnChooserComponent extends DxoColumnChooser implements OnDestroy, OnInit {
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoColumnChooserComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoColumnChooserComponent, "dxo-column-chooser", never, { "allowSearch": { "alias": "allowSearch"; "required": false; }; "container": { "alias": "container"; "required": false; }; "emptyPanelText": { "alias": "emptyPanelText"; "required": false; }; "enabled": { "alias": "enabled"; "required": false; }; "height": { "alias": "height"; "required": false; }; "mode": { "alias": "mode"; "required": false; }; "position": { "alias": "position"; "required": false; }; "search": { "alias": "search"; "required": false; }; "searchTimeout": { "alias": "searchTimeout"; "required": false; }; "selection": { "alias": "selection"; "required": false; }; "sortOrder": { "alias": "sortOrder"; "required": false; }; "title": { "alias": "title"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoColumnChooserModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoColumnChooserModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoColumnChooserModule, never, [typeof DxoColumnChooserComponent], [typeof DxoColumnChooserComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoColumnChooserModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare abstract class DxiDataGridColumn extends CollectionNestedOption {
    get alignment(): HorizontalAlignment | string | undefined;
    set alignment(value: HorizontalAlignment | string | undefined);
    get allowEditing(): boolean;
    set allowEditing(value: boolean);
    get allowExporting(): boolean;
    set allowExporting(value: boolean);
    get allowFiltering(): boolean;
    set allowFiltering(value: boolean);
    get allowFixing(): boolean;
    set allowFixing(value: boolean);
    get allowGrouping(): boolean;
    set allowGrouping(value: boolean);
    get allowHeaderFiltering(): boolean;
    set allowHeaderFiltering(value: boolean);
    get allowHiding(): boolean;
    set allowHiding(value: boolean);
    get allowReordering(): boolean;
    set allowReordering(value: boolean);
    get allowResizing(): boolean;
    set allowResizing(value: boolean);
    get allowSearch(): boolean;
    set allowSearch(value: boolean);
    get allowSorting(): boolean;
    set allowSorting(value: boolean);
    get autoExpandGroup(): boolean;
    set autoExpandGroup(value: boolean);
    get buttons(): Array<DataGridPredefinedColumnButton | dxDataGridColumnButton | TreeListPredefinedColumnButton | dxTreeListColumnButton>;
    set buttons(value: Array<DataGridPredefinedColumnButton | dxDataGridColumnButton | TreeListPredefinedColumnButton | dxTreeListColumnButton>);
    get calculateCellValue(): Function;
    set calculateCellValue(value: Function);
    get calculateDisplayValue(): Function | string;
    set calculateDisplayValue(value: Function | string);
    get calculateFilterExpression(): Function;
    set calculateFilterExpression(value: Function);
    get calculateGroupValue(): Function | string;
    set calculateGroupValue(value: Function | string);
    get calculateSortValue(): Function | string;
    set calculateSortValue(value: Function | string);
    get caption(): string | undefined;
    set caption(value: string | undefined);
    get cellTemplate(): any;
    set cellTemplate(value: any);
    get columns(): Array<dxDataGridColumn | string | dxTreeListColumn>;
    set columns(value: Array<dxDataGridColumn | string | dxTreeListColumn>);
    get cssClass(): string | undefined;
    set cssClass(value: string | undefined);
    get customizeText(): Function;
    set customizeText(value: Function);
    get dataField(): string | undefined;
    set dataField(value: string | undefined);
    get dataType(): DataType | undefined;
    set dataType(value: DataType | undefined);
    get editCellTemplate(): any;
    set editCellTemplate(value: any);
    get editorOptions(): any;
    set editorOptions(value: any);
    get encodeHtml(): boolean;
    set encodeHtml(value: boolean);
    get falseText(): string;
    set falseText(value: string);
    get filterOperations(): Array<FilterOperation | string>;
    set filterOperations(value: Array<FilterOperation | string>);
    get filterType(): FilterType;
    set filterType(value: FilterType);
    get filterValue(): any | undefined;
    set filterValue(value: any | undefined);
    get filterValues(): Array<any>;
    set filterValues(value: Array<any>);
    get fixed(): boolean;
    set fixed(value: boolean);
    get fixedPosition(): FixedPosition | undefined;
    set fixedPosition(value: FixedPosition | undefined);
    get format(): Format | string;
    set format(value: Format | string);
    get formItem(): SimpleItem;
    set formItem(value: SimpleItem);
    get groupCellTemplate(): any;
    set groupCellTemplate(value: any);
    get groupIndex(): number | undefined;
    set groupIndex(value: number | undefined);
    get headerCellTemplate(): any;
    set headerCellTemplate(value: any);
    get headerFilter(): ColumnHeaderFilter | undefined;
    set headerFilter(value: ColumnHeaderFilter | undefined);
    get hidingPriority(): number | undefined;
    set hidingPriority(value: number | undefined);
    get isBand(): boolean | undefined;
    set isBand(value: boolean | undefined);
    get lookup(): {
        allowClearing?: boolean;
        calculateCellValue?: Function;
        dataSource?: Store | Options | Function | null | undefined | Array<any>;
        displayExpr?: Function | string | undefined;
        valueExpr?: string | undefined;
    };
    set lookup(value: {
        allowClearing?: boolean;
        calculateCellValue?: Function;
        dataSource?: Store | Options | Function | null | undefined | Array<any>;
        displayExpr?: Function | string | undefined;
        valueExpr?: string | undefined;
    });
    get minWidth(): number | undefined;
    set minWidth(value: number | undefined);
    get name(): string | undefined;
    set name(value: string | undefined);
    get ownerBand(): number | undefined;
    set ownerBand(value: number | undefined);
    get renderAsync(): boolean;
    set renderAsync(value: boolean);
    get selectedFilterOperation(): SelectedFilterOperation | undefined;
    set selectedFilterOperation(value: SelectedFilterOperation | undefined);
    get setCellValue(): Function;
    set setCellValue(value: Function);
    get showEditorAlways(): boolean;
    set showEditorAlways(value: boolean);
    get showInColumnChooser(): boolean;
    set showInColumnChooser(value: boolean);
    get showWhenGrouped(): boolean;
    set showWhenGrouped(value: boolean);
    get sortIndex(): number | undefined;
    set sortIndex(value: number | undefined);
    get sortingMethod(): Function | undefined;
    set sortingMethod(value: Function | undefined);
    get sortOrder(): SortOrder | string | undefined;
    set sortOrder(value: SortOrder | string | undefined);
    get trueText(): string;
    set trueText(value: string);
    get type(): DataGridCommandColumnType | TreeListCommandColumnType;
    set type(value: DataGridCommandColumnType | TreeListCommandColumnType);
    get validationRules(): Array<RequiredRule | NumericRule | RangeRule | StringLengthRule | CustomRule | CompareRule | PatternRule | EmailRule | AsyncRule>;
    set validationRules(value: Array<RequiredRule | NumericRule | RangeRule | StringLengthRule | CustomRule | CompareRule | PatternRule | EmailRule | AsyncRule>);
    get visible(): boolean;
    set visible(value: boolean);
    get visibleIndex(): number | undefined;
    set visibleIndex(value: number | undefined);
    get width(): number | string | undefined;
    set width(value: number | string | undefined);
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiDataGridColumn, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiDataGridColumn, "ng-component", never, {}, {}, never, never, true, never>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxiColumnComponent extends DxiDataGridColumn {
    set _buttonsContentChildren(value: QueryList<CollectionNestedOption>);
    set _columnsContentChildren(value: QueryList<CollectionNestedOption>);
    set _validationRulesContentChildren(value: QueryList<CollectionNestedOption>);
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    filterValueChange: EventEmitter<any | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    filterValuesChange: EventEmitter<Array<any>>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    groupIndexChange: EventEmitter<number | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    selectedFilterOperationChange: EventEmitter<SelectedFilterOperation | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    sortIndexChange: EventEmitter<number | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    sortOrderChange: EventEmitter<SortOrder | string | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    visibleChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    visibleIndexChange: EventEmitter<number | undefined>;
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiColumnComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiColumnComponent, "dxi-column", never, { "alignment": { "alias": "alignment"; "required": false; }; "allowEditing": { "alias": "allowEditing"; "required": false; }; "allowExporting": { "alias": "allowExporting"; "required": false; }; "allowFiltering": { "alias": "allowFiltering"; "required": false; }; "allowFixing": { "alias": "allowFixing"; "required": false; }; "allowGrouping": { "alias": "allowGrouping"; "required": false; }; "allowHeaderFiltering": { "alias": "allowHeaderFiltering"; "required": false; }; "allowHiding": { "alias": "allowHiding"; "required": false; }; "allowReordering": { "alias": "allowReordering"; "required": false; }; "allowResizing": { "alias": "allowResizing"; "required": false; }; "allowSearch": { "alias": "allowSearch"; "required": false; }; "allowSorting": { "alias": "allowSorting"; "required": false; }; "autoExpandGroup": { "alias": "autoExpandGroup"; "required": false; }; "buttons": { "alias": "buttons"; "required": false; }; "calculateCellValue": { "alias": "calculateCellValue"; "required": false; }; "calculateDisplayValue": { "alias": "calculateDisplayValue"; "required": false; }; "calculateFilterExpression": { "alias": "calculateFilterExpression"; "required": false; }; "calculateGroupValue": { "alias": "calculateGroupValue"; "required": false; }; "calculateSortValue": { "alias": "calculateSortValue"; "required": false; }; "caption": { "alias": "caption"; "required": false; }; "cellTemplate": { "alias": "cellTemplate"; "required": false; }; "columns": { "alias": "columns"; "required": false; }; "cssClass": { "alias": "cssClass"; "required": false; }; "customizeText": { "alias": "customizeText"; "required": false; }; "dataField": { "alias": "dataField"; "required": false; }; "dataType": { "alias": "dataType"; "required": false; }; "editCellTemplate": { "alias": "editCellTemplate"; "required": false; }; "editorOptions": { "alias": "editorOptions"; "required": false; }; "encodeHtml": { "alias": "encodeHtml"; "required": false; }; "falseText": { "alias": "falseText"; "required": false; }; "filterOperations": { "alias": "filterOperations"; "required": false; }; "filterType": { "alias": "filterType"; "required": false; }; "filterValue": { "alias": "filterValue"; "required": false; }; "filterValues": { "alias": "filterValues"; "required": false; }; "fixed": { "alias": "fixed"; "required": false; }; "fixedPosition": { "alias": "fixedPosition"; "required": false; }; "format": { "alias": "format"; "required": false; }; "formItem": { "alias": "formItem"; "required": false; }; "groupCellTemplate": { "alias": "groupCellTemplate"; "required": false; }; "groupIndex": { "alias": "groupIndex"; "required": false; }; "headerCellTemplate": { "alias": "headerCellTemplate"; "required": false; }; "headerFilter": { "alias": "headerFilter"; "required": false; }; "hidingPriority": { "alias": "hidingPriority"; "required": false; }; "isBand": { "alias": "isBand"; "required": false; }; "lookup": { "alias": "lookup"; "required": false; }; "minWidth": { "alias": "minWidth"; "required": false; }; "name": { "alias": "name"; "required": false; }; "ownerBand": { "alias": "ownerBand"; "required": false; }; "renderAsync": { "alias": "renderAsync"; "required": false; }; "selectedFilterOperation": { "alias": "selectedFilterOperation"; "required": false; }; "setCellValue": { "alias": "setCellValue"; "required": false; }; "showEditorAlways": { "alias": "showEditorAlways"; "required": false; }; "showInColumnChooser": { "alias": "showInColumnChooser"; "required": false; }; "showWhenGrouped": { "alias": "showWhenGrouped"; "required": false; }; "sortIndex": { "alias": "sortIndex"; "required": false; }; "sortingMethod": { "alias": "sortingMethod"; "required": false; }; "sortOrder": { "alias": "sortOrder"; "required": false; }; "trueText": { "alias": "trueText"; "required": false; }; "type": { "alias": "type"; "required": false; }; "validationRules": { "alias": "validationRules"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "visibleIndex": { "alias": "visibleIndex"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, { "filterValueChange": "filterValueChange"; "filterValuesChange": "filterValuesChange"; "groupIndexChange": "groupIndexChange"; "selectedFilterOperationChange": "selectedFilterOperationChange"; "sortIndexChange": "sortIndexChange"; "sortOrderChange": "sortOrderChange"; "visibleChange": "visibleChange"; "visibleIndexChange": "visibleIndexChange"; }, ["_buttonsContentChildren", "_columnsContentChildren", "_validationRulesContentChildren"], never, true, never>;
}
declare class DxiColumnModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiColumnModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiColumnModule, never, [typeof DxiColumnComponent], [typeof DxiColumnComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiColumnModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoColumnFixingComponent extends NestedOption implements OnDestroy, OnInit {
    get enabled(): boolean;
    set enabled(value: boolean);
    get icons(): {
        fix?: string;
        leftPosition?: string;
        rightPosition?: string;
        stickyPosition?: string;
        unfix?: string;
    };
    set icons(value: {
        fix?: string;
        leftPosition?: string;
        rightPosition?: string;
        stickyPosition?: string;
        unfix?: string;
    });
    get texts(): {
        fix?: string;
        leftPosition?: string;
        rightPosition?: string;
        stickyPosition?: string;
        unfix?: string;
    };
    set texts(value: {
        fix?: string;
        leftPosition?: string;
        rightPosition?: string;
        stickyPosition?: string;
        unfix?: string;
    });
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoColumnFixingComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoColumnFixingComponent, "dxo-column-fixing", never, { "enabled": { "alias": "enabled"; "required": false; }; "icons": { "alias": "icons"; "required": false; }; "texts": { "alias": "texts"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoColumnFixingModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoColumnFixingModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoColumnFixingModule, never, [typeof DxoColumnFixingComponent], [typeof DxoColumnFixingComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoColumnFixingModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare abstract class DxiDiagramCustomCommand extends CollectionNestedOption {
    get icon(): string;
    set icon(value: string);
    get items(): Array<CustomCommand | Command>;
    set items(value: Array<CustomCommand | Command>);
    get location(): ToolbarItemLocation;
    set location(value: ToolbarItemLocation);
    get name(): Command | string | AICommandNameExtended;
    set name(value: Command | string | AICommandNameExtended);
    get text(): string;
    set text(value: string);
    get options(): any;
    set options(value: any);
    get prompt(): Function;
    set prompt(value: Function);
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiDiagramCustomCommand, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiDiagramCustomCommand, "ng-component", never, {}, {}, never, never, true, never>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxiCommandComponent extends DxiDiagramCustomCommand {
    set _itemsContentChildren(value: QueryList<CollectionNestedOption>);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiCommandComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiCommandComponent, "dxi-command", never, { "icon": { "alias": "icon"; "required": false; }; "items": { "alias": "items"; "required": false; }; "location": { "alias": "location"; "required": false; }; "name": { "alias": "name"; "required": false; }; "text": { "alias": "text"; "required": false; }; "options": { "alias": "options"; "required": false; }; "prompt": { "alias": "prompt"; "required": false; }; }, {}, ["_itemsContentChildren"], never, true, never>;
}
declare class DxiCommandModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiCommandModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiCommandModule, never, [typeof DxiCommandComponent], [typeof DxiCommandComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiCommandModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare abstract class DxoChartCommonAnnotationConfig extends NestedOption {
    get allowDragging(): boolean;
    set allowDragging(value: boolean);
    get argument(): Date | number | string | undefined;
    set argument(value: Date | number | string | undefined);
    get arrowLength(): number;
    set arrowLength(value: number);
    get arrowWidth(): number;
    set arrowWidth(value: number);
    get axis(): string | undefined;
    set axis(value: string | undefined);
    get border(): {
        color?: string;
        cornerRadius?: number;
        dashStyle?: DashStyle;
        opacity?: number | undefined;
        visible?: boolean;
        width?: number;
    };
    set border(value: {
        color?: string;
        cornerRadius?: number;
        dashStyle?: DashStyle;
        opacity?: number | undefined;
        visible?: boolean;
        width?: number;
    });
    get color(): string;
    set color(value: string);
    get customizeTooltip(): Function | undefined;
    set customizeTooltip(value: Function | undefined);
    get data(): any;
    set data(value: any);
    get description(): string | undefined;
    set description(value: string | undefined);
    get font(): Font;
    set font(value: Font);
    get height(): number | undefined;
    set height(value: number | undefined);
    get image(): string | {
        height?: number;
        url?: string | undefined;
        width?: number;
    };
    set image(value: string | {
        height?: number;
        url?: string | undefined;
        width?: number;
    });
    get offsetX(): number | undefined;
    set offsetX(value: number | undefined);
    get offsetY(): number | undefined;
    set offsetY(value: number | undefined);
    get opacity(): number;
    set opacity(value: number);
    get paddingLeftRight(): number;
    set paddingLeftRight(value: number);
    get paddingTopBottom(): number;
    set paddingTopBottom(value: number);
    get series(): string | undefined;
    set series(value: string | undefined);
    get shadow(): {
        blur?: number;
        color?: string;
        offsetX?: number;
        offsetY?: number;
        opacity?: number;
    };
    set shadow(value: {
        blur?: number;
        color?: string;
        offsetX?: number;
        offsetY?: number;
        opacity?: number;
    });
    get template(): any | undefined;
    set template(value: any | undefined);
    get text(): string | undefined;
    set text(value: string | undefined);
    get textOverflow(): TextOverflow;
    set textOverflow(value: TextOverflow);
    get tooltipEnabled(): boolean;
    set tooltipEnabled(value: boolean);
    get tooltipTemplate(): any | undefined;
    set tooltipTemplate(value: any | undefined);
    get type(): AnnotationType | undefined;
    set type(value: AnnotationType | undefined);
    get value(): Date | number | string | undefined;
    set value(value: Date | number | string | undefined);
    get width(): number | undefined;
    set width(value: number | undefined);
    get wordWrap(): WordWrap;
    set wordWrap(value: WordWrap);
    get x(): number | undefined;
    set x(value: number | undefined);
    get y(): number | undefined;
    set y(value: number | undefined);
    get location(): PieChartAnnotationLocation;
    set location(value: PieChartAnnotationLocation);
    get angle(): number | undefined;
    set angle(value: number | undefined);
    get radius(): number | undefined;
    set radius(value: number | undefined);
    get coordinates(): undefined | Array<number>;
    set coordinates(value: undefined | Array<number>);
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChartCommonAnnotationConfig, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoChartCommonAnnotationConfig, "ng-component", never, {}, {}, never, never, true, never>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoCommonAnnotationSettingsComponent extends DxoChartCommonAnnotationConfig implements OnDestroy, OnInit {
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoCommonAnnotationSettingsComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoCommonAnnotationSettingsComponent, "dxo-common-annotation-settings", never, { "allowDragging": { "alias": "allowDragging"; "required": false; }; "argument": { "alias": "argument"; "required": false; }; "arrowLength": { "alias": "arrowLength"; "required": false; }; "arrowWidth": { "alias": "arrowWidth"; "required": false; }; "axis": { "alias": "axis"; "required": false; }; "border": { "alias": "border"; "required": false; }; "color": { "alias": "color"; "required": false; }; "customizeTooltip": { "alias": "customizeTooltip"; "required": false; }; "data": { "alias": "data"; "required": false; }; "description": { "alias": "description"; "required": false; }; "font": { "alias": "font"; "required": false; }; "height": { "alias": "height"; "required": false; }; "image": { "alias": "image"; "required": false; }; "offsetX": { "alias": "offsetX"; "required": false; }; "offsetY": { "alias": "offsetY"; "required": false; }; "opacity": { "alias": "opacity"; "required": false; }; "paddingLeftRight": { "alias": "paddingLeftRight"; "required": false; }; "paddingTopBottom": { "alias": "paddingTopBottom"; "required": false; }; "series": { "alias": "series"; "required": false; }; "shadow": { "alias": "shadow"; "required": false; }; "template": { "alias": "template"; "required": false; }; "text": { "alias": "text"; "required": false; }; "textOverflow": { "alias": "textOverflow"; "required": false; }; "tooltipEnabled": { "alias": "tooltipEnabled"; "required": false; }; "tooltipTemplate": { "alias": "tooltipTemplate"; "required": false; }; "type": { "alias": "type"; "required": false; }; "value": { "alias": "value"; "required": false; }; "width": { "alias": "width"; "required": false; }; "wordWrap": { "alias": "wordWrap"; "required": false; }; "x": { "alias": "x"; "required": false; }; "y": { "alias": "y"; "required": false; }; "location": { "alias": "location"; "required": false; }; "angle": { "alias": "angle"; "required": false; }; "radius": { "alias": "radius"; "required": false; }; "coordinates": { "alias": "coordinates"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoCommonAnnotationSettingsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoCommonAnnotationSettingsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoCommonAnnotationSettingsModule, never, [typeof DxoCommonAnnotationSettingsComponent], [typeof DxoCommonAnnotationSettingsComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoCommonAnnotationSettingsModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoCommonAxisSettingsComponent extends NestedOption implements OnDestroy, OnInit {
    get aggregatedPointsPosition(): AggregatedPointsPosition;
    set aggregatedPointsPosition(value: AggregatedPointsPosition);
    get allowDecimals(): boolean | undefined;
    set allowDecimals(value: boolean | undefined);
    get breakStyle(): {
        color?: string;
        line?: ScaleBreakLineStyle;
        width?: number;
    };
    set breakStyle(value: {
        color?: string;
        line?: ScaleBreakLineStyle;
        width?: number;
    });
    get color(): string;
    set color(value: string);
    get constantLineStyle(): {
        color?: string;
        dashStyle?: DashStyle;
        label?: {
            font?: Font;
            position?: RelativePosition;
            visible?: boolean;
        };
        paddingLeftRight?: number;
        paddingTopBottom?: number;
        width?: number;
    } | {
        color?: string;
        dashStyle?: DashStyle;
        label?: {
            font?: Font;
            visible?: boolean;
        };
        width?: number;
    };
    set constantLineStyle(value: {
        color?: string;
        dashStyle?: DashStyle;
        label?: {
            font?: Font;
            position?: RelativePosition;
            visible?: boolean;
        };
        paddingLeftRight?: number;
        paddingTopBottom?: number;
        width?: number;
    } | {
        color?: string;
        dashStyle?: DashStyle;
        label?: {
            font?: Font;
            visible?: boolean;
        };
        width?: number;
    });
    get discreteAxisDivisionMode(): DiscreteAxisDivisionMode;
    set discreteAxisDivisionMode(value: DiscreteAxisDivisionMode);
    get endOnTick(): boolean | undefined;
    set endOnTick(value: boolean | undefined);
    get grid(): {
        color?: string;
        opacity?: number | undefined;
        visible?: boolean;
        width?: number;
    };
    set grid(value: {
        color?: string;
        opacity?: number | undefined;
        visible?: boolean;
        width?: number;
    });
    get inverted(): boolean;
    set inverted(value: boolean);
    get label(): {
        alignment?: HorizontalAlignment | undefined;
        displayMode?: ChartLabelDisplayMode;
        font?: Font;
        indentFromAxis?: number;
        overlappingBehavior?: ChartsAxisLabelOverlap;
        position?: RelativePosition | Position;
        rotationAngle?: number;
        staggeringSpacing?: number;
        template?: any | undefined;
        textOverflow?: TextOverflow;
        visible?: boolean;
        wordWrap?: WordWrap;
    } | {
        font?: Font;
        indentFromAxis?: number;
        overlappingBehavior?: LabelOverlap;
        visible?: boolean;
    };
    set label(value: {
        alignment?: HorizontalAlignment | undefined;
        displayMode?: ChartLabelDisplayMode;
        font?: Font;
        indentFromAxis?: number;
        overlappingBehavior?: ChartsAxisLabelOverlap;
        position?: RelativePosition | Position;
        rotationAngle?: number;
        staggeringSpacing?: number;
        template?: any | undefined;
        textOverflow?: TextOverflow;
        visible?: boolean;
        wordWrap?: WordWrap;
    } | {
        font?: Font;
        indentFromAxis?: number;
        overlappingBehavior?: LabelOverlap;
        visible?: boolean;
    });
    get maxValueMargin(): number | undefined;
    set maxValueMargin(value: number | undefined);
    get minorGrid(): {
        color?: string;
        opacity?: number | undefined;
        visible?: boolean;
        width?: number;
    };
    set minorGrid(value: {
        color?: string;
        opacity?: number | undefined;
        visible?: boolean;
        width?: number;
    });
    get minorTick(): {
        color?: string;
        length?: number;
        opacity?: number;
        shift?: number;
        visible?: boolean;
        width?: number;
    } | {
        color?: string;
        length?: number;
        opacity?: number;
        visible?: boolean;
        width?: number;
    };
    set minorTick(value: {
        color?: string;
        length?: number;
        opacity?: number;
        shift?: number;
        visible?: boolean;
        width?: number;
    } | {
        color?: string;
        length?: number;
        opacity?: number;
        visible?: boolean;
        width?: number;
    });
    get minValueMargin(): number | undefined;
    set minValueMargin(value: number | undefined);
    get opacity(): number | undefined;
    set opacity(value: number | undefined);
    get placeholderSize(): number | null;
    set placeholderSize(value: number | null);
    get stripStyle(): {
        label?: {
            font?: Font;
            horizontalAlignment?: HorizontalAlignment;
            verticalAlignment?: VerticalAlignment;
        };
        paddingLeftRight?: number;
        paddingTopBottom?: number;
    } | {
        label?: {
            font?: Font;
        };
    };
    set stripStyle(value: {
        label?: {
            font?: Font;
            horizontalAlignment?: HorizontalAlignment;
            verticalAlignment?: VerticalAlignment;
        };
        paddingLeftRight?: number;
        paddingTopBottom?: number;
    } | {
        label?: {
            font?: Font;
        };
    });
    get tick(): {
        color?: string;
        length?: number;
        opacity?: number | undefined;
        shift?: number;
        visible?: boolean;
        width?: number;
    } | {
        color?: string;
        length?: number;
        opacity?: number | undefined;
        visible?: boolean;
        width?: number;
    };
    set tick(value: {
        color?: string;
        length?: number;
        opacity?: number | undefined;
        shift?: number;
        visible?: boolean;
        width?: number;
    } | {
        color?: string;
        length?: number;
        opacity?: number | undefined;
        visible?: boolean;
        width?: number;
    });
    get title(): {
        alignment?: HorizontalAlignment;
        font?: Font;
        margin?: number;
        textOverflow?: TextOverflow;
        wordWrap?: WordWrap;
    };
    set title(value: {
        alignment?: HorizontalAlignment;
        font?: Font;
        margin?: number;
        textOverflow?: TextOverflow;
        wordWrap?: WordWrap;
    });
    get valueMarginsEnabled(): boolean;
    set valueMarginsEnabled(value: boolean);
    get visible(): boolean;
    set visible(value: boolean);
    get width(): number;
    set width(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoCommonAxisSettingsComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoCommonAxisSettingsComponent, "dxo-common-axis-settings", never, { "aggregatedPointsPosition": { "alias": "aggregatedPointsPosition"; "required": false; }; "allowDecimals": { "alias": "allowDecimals"; "required": false; }; "breakStyle": { "alias": "breakStyle"; "required": false; }; "color": { "alias": "color"; "required": false; }; "constantLineStyle": { "alias": "constantLineStyle"; "required": false; }; "discreteAxisDivisionMode": { "alias": "discreteAxisDivisionMode"; "required": false; }; "endOnTick": { "alias": "endOnTick"; "required": false; }; "grid": { "alias": "grid"; "required": false; }; "inverted": { "alias": "inverted"; "required": false; }; "label": { "alias": "label"; "required": false; }; "maxValueMargin": { "alias": "maxValueMargin"; "required": false; }; "minorGrid": { "alias": "minorGrid"; "required": false; }; "minorTick": { "alias": "minorTick"; "required": false; }; "minValueMargin": { "alias": "minValueMargin"; "required": false; }; "opacity": { "alias": "opacity"; "required": false; }; "placeholderSize": { "alias": "placeholderSize"; "required": false; }; "stripStyle": { "alias": "stripStyle"; "required": false; }; "tick": { "alias": "tick"; "required": false; }; "title": { "alias": "title"; "required": false; }; "valueMarginsEnabled": { "alias": "valueMarginsEnabled"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoCommonAxisSettingsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoCommonAxisSettingsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoCommonAxisSettingsModule, never, [typeof DxoCommonAxisSettingsComponent], [typeof DxoCommonAxisSettingsComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoCommonAxisSettingsModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoCommonPaneSettingsComponent extends NestedOption implements OnDestroy, OnInit {
    get backgroundColor(): ChartsColor | string;
    set backgroundColor(value: ChartsColor | string);
    get border(): {
        bottom?: boolean;
        color?: string;
        dashStyle?: DashStyle;
        left?: boolean;
        opacity?: number | undefined;
        right?: boolean;
        top?: boolean;
        visible?: boolean;
        width?: number;
    };
    set border(value: {
        bottom?: boolean;
        color?: string;
        dashStyle?: DashStyle;
        left?: boolean;
        opacity?: number | undefined;
        right?: boolean;
        top?: boolean;
        visible?: boolean;
        width?: number;
    });
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoCommonPaneSettingsComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoCommonPaneSettingsComponent, "dxo-common-pane-settings", never, { "backgroundColor": { "alias": "backgroundColor"; "required": false; }; "border": { "alias": "border"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoCommonPaneSettingsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoCommonPaneSettingsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoCommonPaneSettingsModule, never, [typeof DxoCommonPaneSettingsComponent], [typeof DxoCommonPaneSettingsComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoCommonPaneSettingsModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoCommonSeriesSettingsComponent extends DxoChartCommonSeriesSettings implements OnDestroy, OnInit {
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoCommonSeriesSettingsComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoCommonSeriesSettingsComponent, "dxo-common-series-settings", never, { "aggregation": { "alias": "aggregation"; "required": false; }; "area": { "alias": "area"; "required": false; }; "argumentField": { "alias": "argumentField"; "required": false; }; "axis": { "alias": "axis"; "required": false; }; "bar": { "alias": "bar"; "required": false; }; "barOverlapGroup": { "alias": "barOverlapGroup"; "required": false; }; "barPadding": { "alias": "barPadding"; "required": false; }; "barWidth": { "alias": "barWidth"; "required": false; }; "border": { "alias": "border"; "required": false; }; "bubble": { "alias": "bubble"; "required": false; }; "candlestick": { "alias": "candlestick"; "required": false; }; "closeValueField": { "alias": "closeValueField"; "required": false; }; "color": { "alias": "color"; "required": false; }; "cornerRadius": { "alias": "cornerRadius"; "required": false; }; "dashStyle": { "alias": "dashStyle"; "required": false; }; "fullstackedarea": { "alias": "fullstackedarea"; "required": false; }; "fullstackedbar": { "alias": "fullstackedbar"; "required": false; }; "fullstackedline": { "alias": "fullstackedline"; "required": false; }; "fullstackedspline": { "alias": "fullstackedspline"; "required": false; }; "fullstackedsplinearea": { "alias": "fullstackedsplinearea"; "required": false; }; "highValueField": { "alias": "highValueField"; "required": false; }; "hoverMode": { "alias": "hoverMode"; "required": false; }; "hoverStyle": { "alias": "hoverStyle"; "required": false; }; "ignoreEmptyPoints": { "alias": "ignoreEmptyPoints"; "required": false; }; "innerColor": { "alias": "innerColor"; "required": false; }; "label": { "alias": "label"; "required": false; }; "line": { "alias": "line"; "required": false; }; "lowValueField": { "alias": "lowValueField"; "required": false; }; "maxLabelCount": { "alias": "maxLabelCount"; "required": false; }; "minBarSize": { "alias": "minBarSize"; "required": false; }; "opacity": { "alias": "opacity"; "required": false; }; "openValueField": { "alias": "openValueField"; "required": false; }; "pane": { "alias": "pane"; "required": false; }; "point": { "alias": "point"; "required": false; }; "rangearea": { "alias": "rangearea"; "required": false; }; "rangebar": { "alias": "rangebar"; "required": false; }; "rangeValue1Field": { "alias": "rangeValue1Field"; "required": false; }; "rangeValue2Field": { "alias": "rangeValue2Field"; "required": false; }; "reduction": { "alias": "reduction"; "required": false; }; "scatter": { "alias": "scatter"; "required": false; }; "selectionMode": { "alias": "selectionMode"; "required": false; }; "selectionStyle": { "alias": "selectionStyle"; "required": false; }; "showInLegend": { "alias": "showInLegend"; "required": false; }; "sizeField": { "alias": "sizeField"; "required": false; }; "spline": { "alias": "spline"; "required": false; }; "splinearea": { "alias": "splinearea"; "required": false; }; "stack": { "alias": "stack"; "required": false; }; "stackedarea": { "alias": "stackedarea"; "required": false; }; "stackedbar": { "alias": "stackedbar"; "required": false; }; "stackedline": { "alias": "stackedline"; "required": false; }; "stackedspline": { "alias": "stackedspline"; "required": false; }; "stackedsplinearea": { "alias": "stackedsplinearea"; "required": false; }; "steparea": { "alias": "steparea"; "required": false; }; "stepline": { "alias": "stepline"; "required": false; }; "stock": { "alias": "stock"; "required": false; }; "tagField": { "alias": "tagField"; "required": false; }; "type": { "alias": "type"; "required": false; }; "valueErrorBar": { "alias": "valueErrorBar"; "required": false; }; "valueField": { "alias": "valueField"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; "argumentType": { "alias": "argumentType"; "required": false; }; "minSegmentSize": { "alias": "minSegmentSize"; "required": false; }; "smallValuesGrouping": { "alias": "smallValuesGrouping"; "required": false; }; "closed": { "alias": "closed"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoCommonSeriesSettingsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoCommonSeriesSettingsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoCommonSeriesSettingsModule, never, [typeof DxoCommonSeriesSettingsComponent], [typeof DxoCommonSeriesSettingsComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoCommonSeriesSettingsModule>;
}

declare class DxiConnectionPointComponent extends CollectionNestedOption {
    get x(): number;
    set x(value: number);
    get y(): number;
    set y(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiConnectionPointComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiConnectionPointComponent, "dxi-connection-point", never, { "x": { "alias": "x"; "required": false; }; "y": { "alias": "y"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxiConnectionPointModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiConnectionPointModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiConnectionPointModule, never, [typeof DxiConnectionPointComponent], [typeof DxiConnectionPointComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiConnectionPointModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoConnectorComponent extends NestedOption implements OnDestroy, OnInit {
    get color(): string | undefined;
    set color(value: string | undefined);
    get visible(): boolean;
    set visible(value: boolean);
    get width(): number;
    set width(value: number);
    get opacity(): number;
    set opacity(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoConnectorComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoConnectorComponent, "dxo-connector", never, { "color": { "alias": "color"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; "opacity": { "alias": "opacity"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoConnectorModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoConnectorModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoConnectorModule, never, [typeof DxoConnectorComponent], [typeof DxoConnectorComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoConnectorModule>;
}

declare class DxiConstantLineComponent extends CollectionNestedOption {
    get color(): string;
    set color(value: string);
    get dashStyle(): DashStyle;
    set dashStyle(value: DashStyle);
    get displayBehindSeries(): boolean;
    set displayBehindSeries(value: boolean);
    get extendAxis(): boolean;
    set extendAxis(value: boolean);
    get label(): {
        font?: Font;
        horizontalAlignment?: HorizontalAlignment;
        position?: RelativePosition;
        text?: string | undefined;
        verticalAlignment?: VerticalAlignment;
        visible?: boolean;
    } | {
        font?: Font;
        text?: string | undefined;
        visible?: boolean;
    };
    set label(value: {
        font?: Font;
        horizontalAlignment?: HorizontalAlignment;
        position?: RelativePosition;
        text?: string | undefined;
        verticalAlignment?: VerticalAlignment;
        visible?: boolean;
    } | {
        font?: Font;
        text?: string | undefined;
        visible?: boolean;
    });
    get paddingLeftRight(): number;
    set paddingLeftRight(value: number);
    get paddingTopBottom(): number;
    set paddingTopBottom(value: number);
    get value(): Date | number | string | undefined;
    set value(value: Date | number | string | undefined);
    get width(): number;
    set width(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiConstantLineComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiConstantLineComponent, "dxi-constant-line", never, { "color": { "alias": "color"; "required": false; }; "dashStyle": { "alias": "dashStyle"; "required": false; }; "displayBehindSeries": { "alias": "displayBehindSeries"; "required": false; }; "extendAxis": { "alias": "extendAxis"; "required": false; }; "label": { "alias": "label"; "required": false; }; "paddingLeftRight": { "alias": "paddingLeftRight"; "required": false; }; "paddingTopBottom": { "alias": "paddingTopBottom"; "required": false; }; "value": { "alias": "value"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxiConstantLineModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiConstantLineModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiConstantLineModule, never, [typeof DxiConstantLineComponent], [typeof DxiConstantLineComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiConstantLineModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoConstantLineStyleComponent extends NestedOption implements OnDestroy, OnInit {
    get color(): string;
    set color(value: string);
    get dashStyle(): DashStyle;
    set dashStyle(value: DashStyle);
    get label(): {
        font?: Font;
        horizontalAlignment?: HorizontalAlignment;
        position?: RelativePosition;
        verticalAlignment?: VerticalAlignment;
        visible?: boolean;
    } | {
        font?: Font;
        position?: RelativePosition;
        visible?: boolean;
    } | {
        font?: Font;
        visible?: boolean;
    };
    set label(value: {
        font?: Font;
        horizontalAlignment?: HorizontalAlignment;
        position?: RelativePosition;
        verticalAlignment?: VerticalAlignment;
        visible?: boolean;
    } | {
        font?: Font;
        position?: RelativePosition;
        visible?: boolean;
    } | {
        font?: Font;
        visible?: boolean;
    });
    get paddingLeftRight(): number;
    set paddingLeftRight(value: number);
    get paddingTopBottom(): number;
    set paddingTopBottom(value: number);
    get width(): number;
    set width(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoConstantLineStyleComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoConstantLineStyleComponent, "dxo-constant-line-style", never, { "color": { "alias": "color"; "required": false; }; "dashStyle": { "alias": "dashStyle"; "required": false; }; "label": { "alias": "label"; "required": false; }; "paddingLeftRight": { "alias": "paddingLeftRight"; "required": false; }; "paddingTopBottom": { "alias": "paddingTopBottom"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoConstantLineStyleModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoConstantLineStyleModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoConstantLineStyleModule, never, [typeof DxoConstantLineStyleComponent], [typeof DxoConstantLineStyleComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoConstantLineStyleModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare abstract class DxoFileManagerContextMenu extends NestedOption {
    get commands(): Array<CustomCommand | Command>;
    set commands(value: Array<CustomCommand | Command>);
    get enabled(): boolean;
    set enabled(value: boolean);
    get items(): Array<dxFileManagerContextMenuItem | FileManagerPredefinedContextMenuItem | GanttPredefinedContextMenuItem | any | {
        beginGroup?: boolean;
        closeMenuOnClick?: boolean;
        disabled?: boolean;
        icon?: string;
        items?: Array<dxContextMenuItem>;
        name?: GanttPredefinedContextMenuItem | string;
        selectable?: boolean;
        selected?: boolean;
        template?: any;
        text?: string;
        visible?: boolean;
    }>;
    set items(value: Array<dxFileManagerContextMenuItem | FileManagerPredefinedContextMenuItem | GanttPredefinedContextMenuItem | any | {
        beginGroup?: boolean;
        closeMenuOnClick?: boolean;
        disabled?: boolean;
        icon?: string;
        items?: Array<dxContextMenuItem>;
        name?: GanttPredefinedContextMenuItem | string;
        selectable?: boolean;
        selected?: boolean;
        template?: any;
        text?: string;
        visible?: boolean;
    }>);
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoFileManagerContextMenu, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoFileManagerContextMenu, "ng-component", never, {}, {}, never, never, true, never>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoContextMenuComponent extends DxoFileManagerContextMenu implements OnDestroy, OnInit {
    set _commandsContentChildren(value: QueryList<CollectionNestedOption>);
    set _itemsContentChildren(value: QueryList<CollectionNestedOption>);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoContextMenuComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoContextMenuComponent, "dxo-context-menu", never, { "commands": { "alias": "commands"; "required": false; }; "enabled": { "alias": "enabled"; "required": false; }; "items": { "alias": "items"; "required": false; }; }, {}, ["_commandsContentChildren", "_itemsContentChildren"], never, true, never>;
}
declare class DxoContextMenuModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoContextMenuModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoContextMenuModule, never, [typeof DxoContextMenuComponent], [typeof DxoContextMenuComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoContextMenuModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoContextToolboxComponent extends NestedOption implements OnDestroy, OnInit {
    get category(): ShapeCategory | string;
    set category(value: ShapeCategory | string);
    get displayMode(): ToolboxDisplayMode;
    set displayMode(value: ToolboxDisplayMode);
    get enabled(): boolean;
    set enabled(value: boolean);
    get shapeIconsPerRow(): number;
    set shapeIconsPerRow(value: number);
    get shapes(): Array<ShapeType | string>;
    set shapes(value: Array<ShapeType | string>);
    get width(): number;
    set width(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoContextToolboxComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoContextToolboxComponent, "dxo-context-toolbox", never, { "category": { "alias": "category"; "required": false; }; "displayMode": { "alias": "displayMode"; "required": false; }; "enabled": { "alias": "enabled"; "required": false; }; "shapeIconsPerRow": { "alias": "shapeIconsPerRow"; "required": false; }; "shapes": { "alias": "shapes"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoContextToolboxModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoContextToolboxModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoContextToolboxModule, never, [typeof DxoContextToolboxComponent], [typeof DxoContextToolboxComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoContextToolboxModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoControlBarComponent extends NestedOption implements OnDestroy, OnInit {
    get borderColor(): string;
    set borderColor(value: string);
    get color(): string;
    set color(value: string);
    get enabled(): boolean;
    set enabled(value: boolean);
    get horizontalAlignment(): HorizontalAlignment;
    set horizontalAlignment(value: HorizontalAlignment);
    get margin(): number;
    set margin(value: number);
    get opacity(): number;
    set opacity(value: number);
    get panVisible(): boolean;
    set panVisible(value: boolean);
    get verticalAlignment(): VerticalEdge;
    set verticalAlignment(value: VerticalEdge);
    get zoomVisible(): boolean;
    set zoomVisible(value: boolean);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoControlBarComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoControlBarComponent, "dxo-control-bar", never, { "borderColor": { "alias": "borderColor"; "required": false; }; "color": { "alias": "color"; "required": false; }; "enabled": { "alias": "enabled"; "required": false; }; "horizontalAlignment": { "alias": "horizontalAlignment"; "required": false; }; "margin": { "alias": "margin"; "required": false; }; "opacity": { "alias": "opacity"; "required": false; }; "panVisible": { "alias": "panVisible"; "required": false; }; "verticalAlignment": { "alias": "verticalAlignment"; "required": false; }; "zoomVisible": { "alias": "zoomVisible"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoControlBarModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoControlBarModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoControlBarModule, never, [typeof DxoControlBarComponent], [typeof DxoControlBarComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoControlBarModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare abstract class DxoConverter extends NestedOption {
    get fromHtml(): Function;
    set fromHtml(value: Function);
    get toHtml(): Function;
    set toHtml(value: Function);
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoConverter, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoConverter, "ng-component", never, {}, {}, never, never, true, never>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoConverterComponent extends DxoConverter implements OnDestroy, OnInit {
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoConverterComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoConverterComponent, "dxo-converter", never, { "fromHtml": { "alias": "fromHtml"; "required": false; }; "toHtml": { "alias": "toHtml"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoConverterModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoConverterModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoConverterModule, never, [typeof DxoConverterComponent], [typeof DxoConverterComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoConverterModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoCrosshairComponent extends NestedOption implements OnDestroy, OnInit {
    get color(): string;
    set color(value: string);
    get dashStyle(): DashStyle;
    set dashStyle(value: DashStyle);
    get enabled(): boolean;
    set enabled(value: boolean);
    get horizontalLine(): boolean | {
        color?: string;
        dashStyle?: DashStyle;
        label?: {
            backgroundColor?: string;
            customizeText?: Function;
            font?: Font;
            format?: Format | string | undefined;
            visible?: boolean;
        };
        opacity?: number | undefined;
        visible?: boolean;
        width?: number;
    };
    set horizontalLine(value: boolean | {
        color?: string;
        dashStyle?: DashStyle;
        label?: {
            backgroundColor?: string;
            customizeText?: Function;
            font?: Font;
            format?: Format | string | undefined;
            visible?: boolean;
        };
        opacity?: number | undefined;
        visible?: boolean;
        width?: number;
    });
    get label(): {
        backgroundColor?: string;
        customizeText?: Function;
        font?: Font;
        format?: Format | string | undefined;
        visible?: boolean;
    };
    set label(value: {
        backgroundColor?: string;
        customizeText?: Function;
        font?: Font;
        format?: Format | string | undefined;
        visible?: boolean;
    });
    get opacity(): number | undefined;
    set opacity(value: number | undefined);
    get verticalLine(): boolean | {
        color?: string;
        dashStyle?: DashStyle;
        label?: {
            backgroundColor?: string;
            customizeText?: Function;
            font?: Font;
            format?: Format | string | undefined;
            visible?: boolean;
        };
        opacity?: number | undefined;
        visible?: boolean;
        width?: number;
    };
    set verticalLine(value: boolean | {
        color?: string;
        dashStyle?: DashStyle;
        label?: {
            backgroundColor?: string;
            customizeText?: Function;
            font?: Font;
            format?: Format | string | undefined;
            visible?: boolean;
        };
        opacity?: number | undefined;
        visible?: boolean;
        width?: number;
    });
    get width(): number;
    set width(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoCrosshairComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoCrosshairComponent, "dxo-crosshair", never, { "color": { "alias": "color"; "required": false; }; "dashStyle": { "alias": "dashStyle"; "required": false; }; "enabled": { "alias": "enabled"; "required": false; }; "horizontalLine": { "alias": "horizontalLine"; "required": false; }; "label": { "alias": "label"; "required": false; }; "opacity": { "alias": "opacity"; "required": false; }; "verticalLine": { "alias": "verticalLine"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoCrosshairModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoCrosshairModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoCrosshairModule, never, [typeof DxoCrosshairComponent], [typeof DxoCrosshairComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoCrosshairModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoCursorOffsetComponent extends NestedOption implements OnDestroy, OnInit {
    get x(): number;
    set x(value: number);
    get y(): number;
    set y(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoCursorOffsetComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoCursorOffsetComponent, "dxo-cursor-offset", never, { "x": { "alias": "x"; "required": false; }; "y": { "alias": "y"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoCursorOffsetModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoCursorOffsetModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoCursorOffsetModule, never, [typeof DxoCursorOffsetComponent], [typeof DxoCursorOffsetComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoCursorOffsetModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare abstract class DxiFilterBuilderCustomOperation extends CollectionNestedOption {
    get calculateFilterExpression(): Function;
    set calculateFilterExpression(value: Function);
    get caption(): string | undefined;
    set caption(value: string | undefined);
    get customizeText(): Function;
    set customizeText(value: Function);
    get dataTypes(): any | undefined | Array<DataType>;
    set dataTypes(value: any | undefined | Array<DataType>);
    get editorTemplate(): any;
    set editorTemplate(value: any);
    get hasValue(): boolean;
    set hasValue(value: boolean);
    get icon(): string | undefined;
    set icon(value: string | undefined);
    get name(): string | undefined;
    set name(value: string | undefined);
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiFilterBuilderCustomOperation, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiFilterBuilderCustomOperation, "ng-component", never, {}, {}, never, never, true, never>;
}

declare class DxiCustomOperationComponent extends DxiFilterBuilderCustomOperation {
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiCustomOperationComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiCustomOperationComponent, "dxi-custom-operation", never, { "calculateFilterExpression": { "alias": "calculateFilterExpression"; "required": false; }; "caption": { "alias": "caption"; "required": false; }; "customizeText": { "alias": "customizeText"; "required": false; }; "dataTypes": { "alias": "dataTypes"; "required": false; }; "editorTemplate": { "alias": "editorTemplate"; "required": false; }; "hasValue": { "alias": "hasValue"; "required": false; }; "icon": { "alias": "icon"; "required": false; }; "name": { "alias": "name"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxiCustomOperationModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiCustomOperationModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiCustomOperationModule, never, [typeof DxiCustomOperationComponent], [typeof DxiCustomOperationComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiCustomOperationModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxiCustomShapeComponent extends CollectionNestedOption implements AfterViewInit, IDxTemplateHost {
    private renderer;
    private document;
    private element;
    set _connectionPointsContentChildren(value: QueryList<CollectionNestedOption>);
    get allowEditImage(): boolean;
    set allowEditImage(value: boolean);
    get allowEditText(): boolean;
    set allowEditText(value: boolean);
    get allowResize(): boolean;
    set allowResize(value: boolean);
    get backgroundImageHeight(): number;
    set backgroundImageHeight(value: number);
    get backgroundImageLeft(): number;
    set backgroundImageLeft(value: number);
    get backgroundImageToolboxUrl(): string;
    set backgroundImageToolboxUrl(value: string);
    get backgroundImageTop(): number;
    set backgroundImageTop(value: number);
    get backgroundImageUrl(): string;
    set backgroundImageUrl(value: string);
    get backgroundImageWidth(): number;
    set backgroundImageWidth(value: number);
    get baseType(): ShapeType | string;
    set baseType(value: ShapeType | string);
    get category(): string;
    set category(value: string);
    get connectionPoints(): Array<any | {
        x?: number;
        y?: number;
    }>;
    set connectionPoints(value: Array<any | {
        x?: number;
        y?: number;
    }>);
    get defaultHeight(): number;
    set defaultHeight(value: number);
    get defaultImageUrl(): string;
    set defaultImageUrl(value: string);
    get defaultText(): string;
    set defaultText(value: string);
    get defaultWidth(): number;
    set defaultWidth(value: number);
    get imageHeight(): number;
    set imageHeight(value: number);
    get imageLeft(): number;
    set imageLeft(value: number);
    get imageTop(): number;
    set imageTop(value: number);
    get imageWidth(): number;
    set imageWidth(value: number);
    get keepRatioOnAutoSize(): boolean;
    set keepRatioOnAutoSize(value: boolean);
    get maxHeight(): number;
    set maxHeight(value: number);
    get maxWidth(): number;
    set maxWidth(value: number);
    get minHeight(): number;
    set minHeight(value: number);
    get minWidth(): number;
    set minWidth(value: number);
    get template(): any;
    set template(value: any);
    get templateHeight(): number;
    set templateHeight(value: number);
    get templateLeft(): number;
    set templateLeft(value: number);
    get templateTop(): number;
    set templateTop(value: number);
    get templateWidth(): number;
    set templateWidth(value: number);
    get textHeight(): number;
    set textHeight(value: number);
    get textLeft(): number;
    set textLeft(value: number);
    get textTop(): number;
    set textTop(value: number);
    get textWidth(): number;
    set textWidth(value: number);
    get title(): string;
    set title(value: string);
    get toolboxTemplate(): any;
    set toolboxTemplate(value: any);
    get toolboxWidthToHeightRatio(): number;
    set toolboxWidthToHeightRatio(value: number);
    get type(): string;
    set type(value: string);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost, renderer: Renderer2, document: any, templateHost: DxTemplateHost, element: ElementRef);
    setTemplate(template: DxTemplateDirective): void;
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiCustomShapeComponent, [{ host: true; skipSelf: true; }, { host: true; }, null, null, { host: true; }, null]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiCustomShapeComponent, "dxi-custom-shape", never, { "allowEditImage": { "alias": "allowEditImage"; "required": false; }; "allowEditText": { "alias": "allowEditText"; "required": false; }; "allowResize": { "alias": "allowResize"; "required": false; }; "backgroundImageHeight": { "alias": "backgroundImageHeight"; "required": false; }; "backgroundImageLeft": { "alias": "backgroundImageLeft"; "required": false; }; "backgroundImageToolboxUrl": { "alias": "backgroundImageToolboxUrl"; "required": false; }; "backgroundImageTop": { "alias": "backgroundImageTop"; "required": false; }; "backgroundImageUrl": { "alias": "backgroundImageUrl"; "required": false; }; "backgroundImageWidth": { "alias": "backgroundImageWidth"; "required": false; }; "baseType": { "alias": "baseType"; "required": false; }; "category": { "alias": "category"; "required": false; }; "connectionPoints": { "alias": "connectionPoints"; "required": false; }; "defaultHeight": { "alias": "defaultHeight"; "required": false; }; "defaultImageUrl": { "alias": "defaultImageUrl"; "required": false; }; "defaultText": { "alias": "defaultText"; "required": false; }; "defaultWidth": { "alias": "defaultWidth"; "required": false; }; "imageHeight": { "alias": "imageHeight"; "required": false; }; "imageLeft": { "alias": "imageLeft"; "required": false; }; "imageTop": { "alias": "imageTop"; "required": false; }; "imageWidth": { "alias": "imageWidth"; "required": false; }; "keepRatioOnAutoSize": { "alias": "keepRatioOnAutoSize"; "required": false; }; "maxHeight": { "alias": "maxHeight"; "required": false; }; "maxWidth": { "alias": "maxWidth"; "required": false; }; "minHeight": { "alias": "minHeight"; "required": false; }; "minWidth": { "alias": "minWidth"; "required": false; }; "template": { "alias": "template"; "required": false; }; "templateHeight": { "alias": "templateHeight"; "required": false; }; "templateLeft": { "alias": "templateLeft"; "required": false; }; "templateTop": { "alias": "templateTop"; "required": false; }; "templateWidth": { "alias": "templateWidth"; "required": false; }; "textHeight": { "alias": "textHeight"; "required": false; }; "textLeft": { "alias": "textLeft"; "required": false; }; "textTop": { "alias": "textTop"; "required": false; }; "textWidth": { "alias": "textWidth"; "required": false; }; "title": { "alias": "title"; "required": false; }; "toolboxTemplate": { "alias": "toolboxTemplate"; "required": false; }; "toolboxWidthToHeightRatio": { "alias": "toolboxWidthToHeightRatio"; "required": false; }; "type": { "alias": "type"; "required": false; }; }, {}, ["_connectionPointsContentChildren"], ["*"], true, never>;
}
declare class DxiCustomShapeModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiCustomShapeModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiCustomShapeModule, never, [typeof DxiCustomShapeComponent], [typeof DxiCustomShapeComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiCustomShapeModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoDataPrepareSettingsComponent extends NestedOption implements OnDestroy, OnInit {
    get checkTypeForAllData(): boolean;
    set checkTypeForAllData(value: boolean);
    get convertToAxisDataType(): boolean;
    set convertToAxisDataType(value: boolean);
    get sortingMethod(): boolean | Function;
    set sortingMethod(value: boolean | Function);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDataPrepareSettingsComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoDataPrepareSettingsComponent, "dxo-data-prepare-settings", never, { "checkTypeForAllData": { "alias": "checkTypeForAllData"; "required": false; }; "convertToAxisDataType": { "alias": "convertToAxisDataType"; "required": false; }; "sortingMethod": { "alias": "sortingMethod"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoDataPrepareSettingsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDataPrepareSettingsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoDataPrepareSettingsModule, never, [typeof DxoDataPrepareSettingsComponent], [typeof DxoDataPrepareSettingsComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoDataPrepareSettingsModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoDayHeaderFormatComponent extends DxoFormat implements OnDestroy, OnInit {
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDayHeaderFormatComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoDayHeaderFormatComponent, "dxo-day-header-format", never, { "currency": { "alias": "currency"; "required": false; }; "formatter": { "alias": "formatter"; "required": false; }; "parser": { "alias": "parser"; "required": false; }; "precision": { "alias": "precision"; "required": false; }; "type": { "alias": "type"; "required": false; }; "useCurrencyAccountingStyle": { "alias": "useCurrencyAccountingStyle"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoDayHeaderFormatModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDayHeaderFormatModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoDayHeaderFormatModule, never, [typeof DxoDayHeaderFormatComponent], [typeof DxoDayHeaderFormatComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoDayHeaderFormatModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoDefaultItemPropertiesComponent extends NestedOption implements OnDestroy, OnInit {
    get connectorLineEnd(): ConnectorLineEnd;
    set connectorLineEnd(value: ConnectorLineEnd);
    get connectorLineStart(): ConnectorLineEnd;
    set connectorLineStart(value: ConnectorLineEnd);
    get connectorLineType(): ConnectorLineType;
    set connectorLineType(value: ConnectorLineType);
    get shapeMaxHeight(): number | undefined;
    set shapeMaxHeight(value: number | undefined);
    get shapeMaxWidth(): number | undefined;
    set shapeMaxWidth(value: number | undefined);
    get shapeMinHeight(): number | undefined;
    set shapeMinHeight(value: number | undefined);
    get shapeMinWidth(): number | undefined;
    set shapeMinWidth(value: number | undefined);
    get style(): any;
    set style(value: any);
    get textStyle(): any;
    set textStyle(value: any);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDefaultItemPropertiesComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoDefaultItemPropertiesComponent, "dxo-default-item-properties", never, { "connectorLineEnd": { "alias": "connectorLineEnd"; "required": false; }; "connectorLineStart": { "alias": "connectorLineStart"; "required": false; }; "connectorLineType": { "alias": "connectorLineType"; "required": false; }; "shapeMaxHeight": { "alias": "shapeMaxHeight"; "required": false; }; "shapeMaxWidth": { "alias": "shapeMaxWidth"; "required": false; }; "shapeMinHeight": { "alias": "shapeMinHeight"; "required": false; }; "shapeMinWidth": { "alias": "shapeMinWidth"; "required": false; }; "style": { "alias": "style"; "required": false; }; "textStyle": { "alias": "textStyle"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoDefaultItemPropertiesModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDefaultItemPropertiesModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoDefaultItemPropertiesModule, never, [typeof DxoDefaultItemPropertiesComponent], [typeof DxoDefaultItemPropertiesComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoDefaultItemPropertiesModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoDelayComponent extends NestedOption implements OnDestroy, OnInit {
    get hide(): number;
    set hide(value: number);
    get show(): number;
    set show(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDelayComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoDelayComponent, "dxo-delay", never, { "hide": { "alias": "hide"; "required": false; }; "show": { "alias": "show"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoDelayModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDelayModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoDelayModule, never, [typeof DxoDelayComponent], [typeof DxoDelayComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoDelayModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoDependenciesComponent extends NestedOption implements OnDestroy, OnInit {
    get dataSource(): Store | DataSource | Options | null | string | Array<any>;
    set dataSource(value: Store | DataSource | Options | null | string | Array<any>);
    get keyExpr(): Function | string;
    set keyExpr(value: Function | string);
    get predecessorIdExpr(): Function | string;
    set predecessorIdExpr(value: Function | string);
    get successorIdExpr(): Function | string;
    set successorIdExpr(value: Function | string);
    get typeExpr(): Function | string;
    set typeExpr(value: Function | string);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDependenciesComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoDependenciesComponent, "dxo-dependencies", never, { "dataSource": { "alias": "dataSource"; "required": false; }; "keyExpr": { "alias": "keyExpr"; "required": false; }; "predecessorIdExpr": { "alias": "predecessorIdExpr"; "required": false; }; "successorIdExpr": { "alias": "successorIdExpr"; "required": false; }; "typeExpr": { "alias": "typeExpr"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoDependenciesModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDependenciesModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoDependenciesModule, never, [typeof DxoDependenciesComponent], [typeof DxoDependenciesComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoDependenciesModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoDetailsComponent extends NestedOption implements OnDestroy, OnInit {
    set _columnsContentChildren(value: QueryList<CollectionNestedOption>);
    get columns(): Array<dxFileManagerDetailsColumn | string>;
    set columns(value: Array<dxFileManagerDetailsColumn | string>);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDetailsComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoDetailsComponent, "dxo-details", never, { "columns": { "alias": "columns"; "required": false; }; }, {}, ["_columnsContentChildren"], never, true, never>;
}
declare class DxoDetailsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDetailsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoDetailsModule, never, [typeof DxoDetailsComponent], [typeof DxoDetailsComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoDetailsModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoDisplayFormatComponent extends DxoFormat implements OnDestroy, OnInit {
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDisplayFormatComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoDisplayFormatComponent, "dxo-display-format", never, { "currency": { "alias": "currency"; "required": false; }; "formatter": { "alias": "formatter"; "required": false; }; "parser": { "alias": "parser"; "required": false; }; "precision": { "alias": "precision"; "required": false; }; "type": { "alias": "type"; "required": false; }; "useCurrencyAccountingStyle": { "alias": "useCurrencyAccountingStyle"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoDisplayFormatModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDisplayFormatModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoDisplayFormatModule, never, [typeof DxoDisplayFormatComponent], [typeof DxoDisplayFormatComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoDisplayFormatModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoDragBoxStyleComponent extends NestedOption implements OnDestroy, OnInit {
    get color(): string | undefined;
    set color(value: string | undefined);
    get opacity(): number | undefined;
    set opacity(value: number | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDragBoxStyleComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoDragBoxStyleComponent, "dxo-drag-box-style", never, { "color": { "alias": "color"; "required": false; }; "opacity": { "alias": "opacity"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoDragBoxStyleModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDragBoxStyleModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoDragBoxStyleModule, never, [typeof DxoDragBoxStyleComponent], [typeof DxoDragBoxStyleComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoDragBoxStyleModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare abstract class DxoPopupOptions extends NestedOption {
    get accessKey(): string | undefined;
    set accessKey(value: string | undefined);
    get animation(): {
        hide?: AnimationConfig;
        show?: AnimationConfig;
    };
    set animation(value: {
        hide?: AnimationConfig;
        show?: AnimationConfig;
    });
    get container(): UserDefinedElement | string | undefined;
    set container(value: UserDefinedElement | string | undefined);
    get contentTemplate(): any;
    set contentTemplate(value: any);
    get deferRendering(): boolean;
    set deferRendering(value: boolean);
    get disabled(): boolean;
    set disabled(value: boolean);
    get dragAndResizeArea(): UserDefinedElement | string | undefined;
    set dragAndResizeArea(value: UserDefinedElement | string | undefined);
    get dragEnabled(): boolean;
    set dragEnabled(value: boolean);
    get dragOutsideBoundary(): boolean;
    set dragOutsideBoundary(value: boolean);
    get enableBodyScroll(): boolean;
    set enableBodyScroll(value: boolean);
    get focusStateEnabled(): boolean;
    set focusStateEnabled(value: boolean);
    get fullScreen(): boolean;
    set fullScreen(value: boolean);
    get height(): number | string;
    set height(value: number | string);
    get hideOnOutsideClick(): boolean | Function;
    set hideOnOutsideClick(value: boolean | Function);
    get hideOnParentScroll(): boolean;
    set hideOnParentScroll(value: boolean);
    get hint(): string | undefined;
    set hint(value: string | undefined);
    get hoverStateEnabled(): boolean;
    set hoverStateEnabled(value: boolean);
    get maxHeight(): number | string;
    set maxHeight(value: number | string);
    get maxWidth(): number | string;
    set maxWidth(value: number | string);
    get minHeight(): number | string;
    set minHeight(value: number | string);
    get minWidth(): number | string;
    set minWidth(value: number | string);
    get onContentReady(): Function | undefined;
    set onContentReady(value: Function | undefined);
    get onDisposing(): Function | undefined;
    set onDisposing(value: Function | undefined);
    get onHidden(): Function;
    set onHidden(value: Function);
    get onHiding(): Function;
    set onHiding(value: Function);
    get onInitialized(): Function | undefined;
    set onInitialized(value: Function | undefined);
    get onOptionChanged(): Function | undefined;
    set onOptionChanged(value: Function | undefined);
    get onResize(): Function | undefined;
    set onResize(value: Function | undefined);
    get onResizeEnd(): Function | undefined;
    set onResizeEnd(value: Function | undefined);
    get onResizeStart(): Function | undefined;
    set onResizeStart(value: Function | undefined);
    get onShowing(): Function;
    set onShowing(value: Function);
    get onShown(): Function;
    set onShown(value: Function);
    get onTitleRendered(): Function | undefined;
    set onTitleRendered(value: Function | undefined);
    get position(): PositionAlignment | PositionConfig | Function | Position;
    set position(value: PositionAlignment | PositionConfig | Function | Position);
    get resizeEnabled(): boolean;
    set resizeEnabled(value: boolean);
    get restorePosition(): boolean;
    set restorePosition(value: boolean);
    get rtlEnabled(): boolean;
    set rtlEnabled(value: boolean);
    get shading(): boolean;
    set shading(value: boolean);
    get shadingColor(): string;
    set shadingColor(value: string);
    get showCloseButton(): boolean;
    set showCloseButton(value: boolean);
    get showTitle(): boolean;
    set showTitle(value: boolean);
    get tabIndex(): number;
    set tabIndex(value: number);
    get title(): string;
    set title(value: string);
    get titleTemplate(): any;
    set titleTemplate(value: any);
    get toolbarItems(): Array<dxPopupToolbarItem>;
    set toolbarItems(value: Array<dxPopupToolbarItem>);
    get visible(): boolean;
    set visible(value: boolean);
    get width(): number | string;
    set width(value: number | string);
    get wrapperAttr(): any;
    set wrapperAttr(value: any);
    get hideEvent(): string | undefined | {
        delay?: number | undefined;
        name?: string | undefined;
    };
    set hideEvent(value: string | undefined | {
        delay?: number | undefined;
        name?: string | undefined;
    });
    get showEvent(): string | undefined | {
        delay?: number | undefined;
        name?: string | undefined;
    };
    set showEvent(value: string | undefined | {
        delay?: number | undefined;
        name?: string | undefined;
    });
    get target(): UserDefinedElement | string | undefined;
    set target(value: UserDefinedElement | string | undefined);
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPopupOptions, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoPopupOptions, "ng-component", never, {}, {}, never, never, true, never>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoDropDownOptionsComponent extends DxoPopupOptions implements OnDestroy, OnInit {
    set _toolbarItemsContentChildren(value: QueryList<CollectionNestedOption>);
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    heightChange: EventEmitter<number | string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    positionChange: EventEmitter<PositionAlignment | PositionConfig | Function>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    visibleChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    widthChange: EventEmitter<number | string>;
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDropDownOptionsComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoDropDownOptionsComponent, "dxo-drop-down-options", never, { "accessKey": { "alias": "accessKey"; "required": false; }; "animation": { "alias": "animation"; "required": false; }; "container": { "alias": "container"; "required": false; }; "contentTemplate": { "alias": "contentTemplate"; "required": false; }; "deferRendering": { "alias": "deferRendering"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "dragAndResizeArea": { "alias": "dragAndResizeArea"; "required": false; }; "dragEnabled": { "alias": "dragEnabled"; "required": false; }; "dragOutsideBoundary": { "alias": "dragOutsideBoundary"; "required": false; }; "enableBodyScroll": { "alias": "enableBodyScroll"; "required": false; }; "focusStateEnabled": { "alias": "focusStateEnabled"; "required": false; }; "fullScreen": { "alias": "fullScreen"; "required": false; }; "height": { "alias": "height"; "required": false; }; "hideOnOutsideClick": { "alias": "hideOnOutsideClick"; "required": false; }; "hideOnParentScroll": { "alias": "hideOnParentScroll"; "required": false; }; "hint": { "alias": "hint"; "required": false; }; "hoverStateEnabled": { "alias": "hoverStateEnabled"; "required": false; }; "maxHeight": { "alias": "maxHeight"; "required": false; }; "maxWidth": { "alias": "maxWidth"; "required": false; }; "minHeight": { "alias": "minHeight"; "required": false; }; "minWidth": { "alias": "minWidth"; "required": false; }; "onContentReady": { "alias": "onContentReady"; "required": false; }; "onDisposing": { "alias": "onDisposing"; "required": false; }; "onHidden": { "alias": "onHidden"; "required": false; }; "onHiding": { "alias": "onHiding"; "required": false; }; "onInitialized": { "alias": "onInitialized"; "required": false; }; "onOptionChanged": { "alias": "onOptionChanged"; "required": false; }; "onResize": { "alias": "onResize"; "required": false; }; "onResizeEnd": { "alias": "onResizeEnd"; "required": false; }; "onResizeStart": { "alias": "onResizeStart"; "required": false; }; "onShowing": { "alias": "onShowing"; "required": false; }; "onShown": { "alias": "onShown"; "required": false; }; "onTitleRendered": { "alias": "onTitleRendered"; "required": false; }; "position": { "alias": "position"; "required": false; }; "resizeEnabled": { "alias": "resizeEnabled"; "required": false; }; "restorePosition": { "alias": "restorePosition"; "required": false; }; "rtlEnabled": { "alias": "rtlEnabled"; "required": false; }; "shading": { "alias": "shading"; "required": false; }; "shadingColor": { "alias": "shadingColor"; "required": false; }; "showCloseButton": { "alias": "showCloseButton"; "required": false; }; "showTitle": { "alias": "showTitle"; "required": false; }; "tabIndex": { "alias": "tabIndex"; "required": false; }; "title": { "alias": "title"; "required": false; }; "titleTemplate": { "alias": "titleTemplate"; "required": false; }; "toolbarItems": { "alias": "toolbarItems"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; "wrapperAttr": { "alias": "wrapperAttr"; "required": false; }; "hideEvent": { "alias": "hideEvent"; "required": false; }; "showEvent": { "alias": "showEvent"; "required": false; }; "target": { "alias": "target"; "required": false; }; }, { "heightChange": "heightChange"; "positionChange": "positionChange"; "visibleChange": "visibleChange"; "widthChange": "widthChange"; }, ["_toolbarItemsContentChildren"], never, true, never>;
}
declare class DxoDropDownOptionsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDropDownOptionsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoDropDownOptionsModule, never, [typeof DxoDropDownOptionsComponent], [typeof DxoDropDownOptionsComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoDropDownOptionsModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoEdgesComponent extends NestedOption implements OnDestroy, OnInit {
    get customDataExpr(): Function | string | undefined;
    set customDataExpr(value: Function | string | undefined);
    get dataSource(): Store | DataSource | Options | null | string | Array<any>;
    set dataSource(value: Store | DataSource | Options | null | string | Array<any>);
    get fromExpr(): Function | string;
    set fromExpr(value: Function | string);
    get fromLineEndExpr(): Function | string | undefined;
    set fromLineEndExpr(value: Function | string | undefined);
    get fromPointIndexExpr(): Function | string | undefined;
    set fromPointIndexExpr(value: Function | string | undefined);
    get keyExpr(): Function | string;
    set keyExpr(value: Function | string);
    get lineTypeExpr(): Function | string | undefined;
    set lineTypeExpr(value: Function | string | undefined);
    get lockedExpr(): Function | string | undefined;
    set lockedExpr(value: Function | string | undefined);
    get pointsExpr(): Function | string | undefined;
    set pointsExpr(value: Function | string | undefined);
    get styleExpr(): Function | string | undefined;
    set styleExpr(value: Function | string | undefined);
    get textExpr(): Function | string | undefined;
    set textExpr(value: Function | string | undefined);
    get textStyleExpr(): Function | string | undefined;
    set textStyleExpr(value: Function | string | undefined);
    get toExpr(): Function | string;
    set toExpr(value: Function | string);
    get toLineEndExpr(): Function | string | undefined;
    set toLineEndExpr(value: Function | string | undefined);
    get toPointIndexExpr(): Function | string | undefined;
    set toPointIndexExpr(value: Function | string | undefined);
    get zIndexExpr(): Function | string | undefined;
    set zIndexExpr(value: Function | string | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoEdgesComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoEdgesComponent, "dxo-edges", never, { "customDataExpr": { "alias": "customDataExpr"; "required": false; }; "dataSource": { "alias": "dataSource"; "required": false; }; "fromExpr": { "alias": "fromExpr"; "required": false; }; "fromLineEndExpr": { "alias": "fromLineEndExpr"; "required": false; }; "fromPointIndexExpr": { "alias": "fromPointIndexExpr"; "required": false; }; "keyExpr": { "alias": "keyExpr"; "required": false; }; "lineTypeExpr": { "alias": "lineTypeExpr"; "required": false; }; "lockedExpr": { "alias": "lockedExpr"; "required": false; }; "pointsExpr": { "alias": "pointsExpr"; "required": false; }; "styleExpr": { "alias": "styleExpr"; "required": false; }; "textExpr": { "alias": "textExpr"; "required": false; }; "textStyleExpr": { "alias": "textStyleExpr"; "required": false; }; "toExpr": { "alias": "toExpr"; "required": false; }; "toLineEndExpr": { "alias": "toLineEndExpr"; "required": false; }; "toPointIndexExpr": { "alias": "toPointIndexExpr"; "required": false; }; "zIndexExpr": { "alias": "zIndexExpr"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoEdgesModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoEdgesModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoEdgesModule, never, [typeof DxoEdgesComponent], [typeof DxoEdgesComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoEdgesModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoEditingComponent extends NestedOption implements OnDestroy, OnInit {
    set _changesContentChildren(value: QueryList<CollectionNestedOption>);
    get allowDeleting(): boolean | Function;
    set allowDeleting(value: boolean | Function);
    get allowUpdating(): boolean | Function;
    set allowUpdating(value: boolean | Function);
    get allowAdding(): boolean | Function;
    set allowAdding(value: boolean | Function);
    get changes(): Array<DataChange>;
    set changes(value: Array<DataChange>);
    get confirmDelete(): boolean;
    set confirmDelete(value: boolean);
    get editColumnName(): string | undefined;
    set editColumnName(value: string | undefined);
    get editRowKey(): any | undefined;
    set editRowKey(value: any | undefined);
    get form(): Properties$2;
    set form(value: Properties$2);
    get mode(): GridsEditMode;
    set mode(value: GridsEditMode);
    get newRowPosition(): NewRowPosition;
    set newRowPosition(value: NewRowPosition);
    get popup(): Properties$3;
    set popup(value: Properties$3);
    get refreshMode(): GridsEditRefreshMode;
    set refreshMode(value: GridsEditRefreshMode);
    get selectTextOnEditStart(): boolean;
    set selectTextOnEditStart(value: boolean);
    get startEditAction(): StartEditAction;
    set startEditAction(value: StartEditAction);
    get texts(): {
        addRow?: string;
        cancelAllChanges?: string;
        cancelRowChanges?: string;
        confirmDeleteMessage?: string;
        confirmDeleteTitle?: string;
        deleteRow?: string;
        editRow?: string;
        saveAllChanges?: string;
        saveRowChanges?: string;
        undeleteRow?: string;
        validationCancelChanges?: string;
    } | {
        addRow?: string;
        addRowToNode?: string;
        cancelAllChanges?: string;
        cancelRowChanges?: string;
        confirmDeleteMessage?: string;
        confirmDeleteTitle?: string;
        deleteRow?: string;
        editRow?: string;
        saveAllChanges?: string;
        saveRowChanges?: string;
        undeleteRow?: string;
        validationCancelChanges?: string;
    };
    set texts(value: {
        addRow?: string;
        cancelAllChanges?: string;
        cancelRowChanges?: string;
        confirmDeleteMessage?: string;
        confirmDeleteTitle?: string;
        deleteRow?: string;
        editRow?: string;
        saveAllChanges?: string;
        saveRowChanges?: string;
        undeleteRow?: string;
        validationCancelChanges?: string;
    } | {
        addRow?: string;
        addRowToNode?: string;
        cancelAllChanges?: string;
        cancelRowChanges?: string;
        confirmDeleteMessage?: string;
        confirmDeleteTitle?: string;
        deleteRow?: string;
        editRow?: string;
        saveAllChanges?: string;
        saveRowChanges?: string;
        undeleteRow?: string;
        validationCancelChanges?: string;
    });
    get useIcons(): boolean;
    set useIcons(value: boolean);
    get allowAddShape(): boolean;
    set allowAddShape(value: boolean);
    get allowChangeConnection(): boolean;
    set allowChangeConnection(value: boolean);
    get allowChangeConnectorPoints(): boolean;
    set allowChangeConnectorPoints(value: boolean);
    get allowChangeConnectorText(): boolean;
    set allowChangeConnectorText(value: boolean);
    get allowChangeShapeText(): boolean;
    set allowChangeShapeText(value: boolean);
    get allowDeleteConnector(): boolean;
    set allowDeleteConnector(value: boolean);
    get allowDeleteShape(): boolean;
    set allowDeleteShape(value: boolean);
    get allowMoveShape(): boolean;
    set allowMoveShape(value: boolean);
    get allowResizeShape(): boolean;
    set allowResizeShape(value: boolean);
    get allowDependencyAdding(): boolean;
    set allowDependencyAdding(value: boolean);
    get allowDependencyDeleting(): boolean;
    set allowDependencyDeleting(value: boolean);
    get allowResourceAdding(): boolean;
    set allowResourceAdding(value: boolean);
    get allowResourceDeleting(): boolean;
    set allowResourceDeleting(value: boolean);
    get allowResourceUpdating(): boolean;
    set allowResourceUpdating(value: boolean);
    get allowTaskAdding(): boolean;
    set allowTaskAdding(value: boolean);
    get allowTaskDeleting(): boolean;
    set allowTaskDeleting(value: boolean);
    get allowTaskResourceUpdating(): boolean;
    set allowTaskResourceUpdating(value: boolean);
    get allowTaskUpdating(): boolean;
    set allowTaskUpdating(value: boolean);
    get enabled(): boolean;
    set enabled(value: boolean);
    get allowDragging(): boolean;
    set allowDragging(value: boolean);
    get allowResizing(): boolean;
    set allowResizing(value: boolean);
    get allowTimeZoneEditing(): boolean;
    set allowTimeZoneEditing(value: boolean);
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    changesChange: EventEmitter<Array<DataChange>>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    editColumnNameChange: EventEmitter<string | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    editRowKeyChange: EventEmitter<any | undefined>;
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoEditingComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoEditingComponent, "dxo-editing", never, { "allowDeleting": { "alias": "allowDeleting"; "required": false; }; "allowUpdating": { "alias": "allowUpdating"; "required": false; }; "allowAdding": { "alias": "allowAdding"; "required": false; }; "changes": { "alias": "changes"; "required": false; }; "confirmDelete": { "alias": "confirmDelete"; "required": false; }; "editColumnName": { "alias": "editColumnName"; "required": false; }; "editRowKey": { "alias": "editRowKey"; "required": false; }; "form": { "alias": "form"; "required": false; }; "mode": { "alias": "mode"; "required": false; }; "newRowPosition": { "alias": "newRowPosition"; "required": false; }; "popup": { "alias": "popup"; "required": false; }; "refreshMode": { "alias": "refreshMode"; "required": false; }; "selectTextOnEditStart": { "alias": "selectTextOnEditStart"; "required": false; }; "startEditAction": { "alias": "startEditAction"; "required": false; }; "texts": { "alias": "texts"; "required": false; }; "useIcons": { "alias": "useIcons"; "required": false; }; "allowAddShape": { "alias": "allowAddShape"; "required": false; }; "allowChangeConnection": { "alias": "allowChangeConnection"; "required": false; }; "allowChangeConnectorPoints": { "alias": "allowChangeConnectorPoints"; "required": false; }; "allowChangeConnectorText": { "alias": "allowChangeConnectorText"; "required": false; }; "allowChangeShapeText": { "alias": "allowChangeShapeText"; "required": false; }; "allowDeleteConnector": { "alias": "allowDeleteConnector"; "required": false; }; "allowDeleteShape": { "alias": "allowDeleteShape"; "required": false; }; "allowMoveShape": { "alias": "allowMoveShape"; "required": false; }; "allowResizeShape": { "alias": "allowResizeShape"; "required": false; }; "allowDependencyAdding": { "alias": "allowDependencyAdding"; "required": false; }; "allowDependencyDeleting": { "alias": "allowDependencyDeleting"; "required": false; }; "allowResourceAdding": { "alias": "allowResourceAdding"; "required": false; }; "allowResourceDeleting": { "alias": "allowResourceDeleting"; "required": false; }; "allowResourceUpdating": { "alias": "allowResourceUpdating"; "required": false; }; "allowTaskAdding": { "alias": "allowTaskAdding"; "required": false; }; "allowTaskDeleting": { "alias": "allowTaskDeleting"; "required": false; }; "allowTaskResourceUpdating": { "alias": "allowTaskResourceUpdating"; "required": false; }; "allowTaskUpdating": { "alias": "allowTaskUpdating"; "required": false; }; "enabled": { "alias": "enabled"; "required": false; }; "allowDragging": { "alias": "allowDragging"; "required": false; }; "allowResizing": { "alias": "allowResizing"; "required": false; }; "allowTimeZoneEditing": { "alias": "allowTimeZoneEditing"; "required": false; }; }, { "changesChange": "changesChange"; "editColumnNameChange": "editColumnNameChange"; "editRowKeyChange": "editRowKeyChange"; }, ["_changesContentChildren"], never, true, never>;
}
declare class DxoEditingModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoEditingModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoEditingModule, never, [typeof DxoEditingComponent], [typeof DxoEditingComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoEditingModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoExportComponent extends NestedOption implements OnDestroy, OnInit {
    get backgroundColor(): string;
    set backgroundColor(value: string);
    get enabled(): boolean;
    set enabled(value: boolean);
    get fileName(): string;
    set fileName(value: string);
    get formats(): any | Array<ExportFormat | DataGridExportFormat | string>;
    set formats(value: any | Array<ExportFormat | DataGridExportFormat | string>);
    get margin(): number;
    set margin(value: number);
    get printingEnabled(): boolean;
    set printingEnabled(value: boolean);
    get svgToCanvas(): Function | undefined;
    set svgToCanvas(value: Function | undefined);
    get allowExportSelectedData(): boolean;
    set allowExportSelectedData(value: boolean);
    get texts(): {
        exportAll?: string;
        exportSelectedRows?: string;
        exportTo?: string;
    };
    set texts(value: {
        exportAll?: string;
        exportSelectedRows?: string;
        exportTo?: string;
    });
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoExportComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoExportComponent, "dxo-export", never, { "backgroundColor": { "alias": "backgroundColor"; "required": false; }; "enabled": { "alias": "enabled"; "required": false; }; "fileName": { "alias": "fileName"; "required": false; }; "formats": { "alias": "formats"; "required": false; }; "margin": { "alias": "margin"; "required": false; }; "printingEnabled": { "alias": "printingEnabled"; "required": false; }; "svgToCanvas": { "alias": "svgToCanvas"; "required": false; }; "allowExportSelectedData": { "alias": "allowExportSelectedData"; "required": false; }; "texts": { "alias": "texts"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoExportModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoExportModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoExportModule, never, [typeof DxoExportComponent], [typeof DxoExportComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoExportModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoFieldChooserComponent extends NestedOption implements OnDestroy, OnInit {
    get allowSearch(): boolean;
    set allowSearch(value: boolean);
    get applyChangesMode(): ApplyChangesMode;
    set applyChangesMode(value: ApplyChangesMode);
    get enabled(): boolean;
    set enabled(value: boolean);
    get height(): number | string;
    set height(value: number | string);
    get layout(): FieldChooserLayout;
    set layout(value: FieldChooserLayout);
    get searchTimeout(): number;
    set searchTimeout(value: number);
    get texts(): {
        allFields?: string;
        columnFields?: string;
        dataFields?: string;
        filterFields?: string;
        rowFields?: string;
    };
    set texts(value: {
        allFields?: string;
        columnFields?: string;
        dataFields?: string;
        filterFields?: string;
        rowFields?: string;
    });
    get title(): string;
    set title(value: string);
    get width(): number | string;
    set width(value: number | string);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoFieldChooserComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoFieldChooserComponent, "dxo-field-chooser", never, { "allowSearch": { "alias": "allowSearch"; "required": false; }; "applyChangesMode": { "alias": "applyChangesMode"; "required": false; }; "enabled": { "alias": "enabled"; "required": false; }; "height": { "alias": "height"; "required": false; }; "layout": { "alias": "layout"; "required": false; }; "searchTimeout": { "alias": "searchTimeout"; "required": false; }; "texts": { "alias": "texts"; "required": false; }; "title": { "alias": "title"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoFieldChooserModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoFieldChooserModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoFieldChooserModule, never, [typeof DxoFieldChooserComponent], [typeof DxoFieldChooserComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoFieldChooserModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare abstract class DxiFilterBuilderField extends CollectionNestedOption {
    get calculateFilterExpression(): Function;
    set calculateFilterExpression(value: Function);
    get caption(): string | undefined;
    set caption(value: string | undefined);
    get customizeText(): Function;
    set customizeText(value: Function);
    get dataField(): string | undefined;
    set dataField(value: string | undefined);
    get dataType(): DataType;
    set dataType(value: DataType);
    get editorOptions(): any;
    set editorOptions(value: any);
    get editorTemplate(): any;
    set editorTemplate(value: any);
    get falseText(): string;
    set falseText(value: string);
    get filterOperations(): Array<FilterBuilderOperation | string>;
    set filterOperations(value: Array<FilterBuilderOperation | string>);
    get format(): Format | string;
    set format(value: Format | string);
    get lookup(): {
        allowClearing?: boolean;
        dataSource?: Store | Options | undefined | Array<any>;
        displayExpr?: Function | string | undefined;
        valueExpr?: Function | string | undefined;
    };
    set lookup(value: {
        allowClearing?: boolean;
        dataSource?: Store | Options | undefined | Array<any>;
        displayExpr?: Function | string | undefined;
        valueExpr?: Function | string | undefined;
    });
    get name(): string | undefined;
    set name(value: string | undefined);
    get trueText(): string;
    set trueText(value: string);
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiFilterBuilderField, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiFilterBuilderField, "ng-component", never, {}, {}, never, never, true, never>;
}

declare class DxiFieldComponent extends DxiFilterBuilderField {
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiFieldComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiFieldComponent, "dxi-field", never, { "calculateFilterExpression": { "alias": "calculateFilterExpression"; "required": false; }; "caption": { "alias": "caption"; "required": false; }; "customizeText": { "alias": "customizeText"; "required": false; }; "dataField": { "alias": "dataField"; "required": false; }; "dataType": { "alias": "dataType"; "required": false; }; "editorOptions": { "alias": "editorOptions"; "required": false; }; "editorTemplate": { "alias": "editorTemplate"; "required": false; }; "falseText": { "alias": "falseText"; "required": false; }; "filterOperations": { "alias": "filterOperations"; "required": false; }; "format": { "alias": "format"; "required": false; }; "lookup": { "alias": "lookup"; "required": false; }; "name": { "alias": "name"; "required": false; }; "trueText": { "alias": "trueText"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxiFieldModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiFieldModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiFieldModule, never, [typeof DxiFieldComponent], [typeof DxiFieldComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiFieldModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoFieldPanelComponent extends NestedOption implements OnDestroy, OnInit {
    get allowFieldDragging(): boolean;
    set allowFieldDragging(value: boolean);
    get showColumnFields(): boolean;
    set showColumnFields(value: boolean);
    get showDataFields(): boolean;
    set showDataFields(value: boolean);
    get showFilterFields(): boolean;
    set showFilterFields(value: boolean);
    get showRowFields(): boolean;
    set showRowFields(value: boolean);
    get texts(): {
        columnFieldArea?: string;
        dataFieldArea?: string;
        filterFieldArea?: string;
        rowFieldArea?: string;
    };
    set texts(value: {
        columnFieldArea?: string;
        dataFieldArea?: string;
        filterFieldArea?: string;
        rowFieldArea?: string;
    });
    get visible(): boolean;
    set visible(value: boolean);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoFieldPanelComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoFieldPanelComponent, "dxo-field-panel", never, { "allowFieldDragging": { "alias": "allowFieldDragging"; "required": false; }; "showColumnFields": { "alias": "showColumnFields"; "required": false; }; "showDataFields": { "alias": "showDataFields"; "required": false; }; "showFilterFields": { "alias": "showFilterFields"; "required": false; }; "showRowFields": { "alias": "showRowFields"; "required": false; }; "texts": { "alias": "texts"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoFieldPanelModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoFieldPanelModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoFieldPanelModule, never, [typeof DxoFieldPanelComponent], [typeof DxoFieldPanelComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoFieldPanelModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare abstract class DxiFileManagerToolbarItem extends CollectionNestedOption {
    get cssClass(): string | undefined;
    set cssClass(value: string | undefined);
    get disabled(): boolean;
    set disabled(value: boolean);
    get icon(): string;
    set icon(value: string);
    get locateInMenu(): LocateInMenuMode;
    set locateInMenu(value: LocateInMenuMode);
    get location(): ToolbarItemLocation;
    set location(value: ToolbarItemLocation);
    get name(): FileManagerPredefinedToolbarItem | string;
    set name(value: FileManagerPredefinedToolbarItem | string);
    get options(): any;
    set options(value: any);
    get showText(): ShowTextMode;
    set showText(value: ShowTextMode);
    get text(): string;
    set text(value: string);
    get visible(): boolean | undefined;
    set visible(value: boolean | undefined);
    get widget(): ToolbarItemComponent;
    set widget(value: ToolbarItemComponent);
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiFileManagerToolbarItem, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiFileManagerToolbarItem, "ng-component", never, {}, {}, never, never, true, never>;
}

declare class DxiFileSelectionItemComponent extends DxiFileManagerToolbarItem {
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiFileSelectionItemComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiFileSelectionItemComponent, "dxi-file-selection-item", never, { "cssClass": { "alias": "cssClass"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "icon": { "alias": "icon"; "required": false; }; "locateInMenu": { "alias": "locateInMenu"; "required": false; }; "location": { "alias": "location"; "required": false; }; "name": { "alias": "name"; "required": false; }; "options": { "alias": "options"; "required": false; }; "showText": { "alias": "showText"; "required": false; }; "text": { "alias": "text"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "widget": { "alias": "widget"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxiFileSelectionItemModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiFileSelectionItemModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiFileSelectionItemModule, never, [typeof DxiFileSelectionItemComponent], [typeof DxiFileSelectionItemComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiFileSelectionItemModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare abstract class DxoFileUploaderOptions extends NestedOption {
    get abortUpload(): Function;
    set abortUpload(value: Function);
    get accept(): string;
    set accept(value: string);
    get accessKey(): string | undefined;
    set accessKey(value: string | undefined);
    get activeStateEnabled(): boolean;
    set activeStateEnabled(value: boolean);
    get allowCanceling(): boolean;
    set allowCanceling(value: boolean);
    get allowedFileExtensions(): Array<string>;
    set allowedFileExtensions(value: Array<string>);
    get chunkSize(): number;
    set chunkSize(value: number);
    get dialogTrigger(): UserDefinedElement | string | undefined;
    set dialogTrigger(value: UserDefinedElement | string | undefined);
    get disabled(): boolean;
    set disabled(value: boolean);
    get dropZone(): UserDefinedElement | string | undefined;
    set dropZone(value: UserDefinedElement | string | undefined);
    get elementAttr(): any;
    set elementAttr(value: any);
    get focusStateEnabled(): boolean;
    set focusStateEnabled(value: boolean);
    get height(): number | string | undefined;
    set height(value: number | string | undefined);
    get hint(): string | undefined;
    set hint(value: string | undefined);
    get hoverStateEnabled(): boolean;
    set hoverStateEnabled(value: boolean);
    get inputAttr(): any;
    set inputAttr(value: any);
    get invalidFileExtensionMessage(): string;
    set invalidFileExtensionMessage(value: string);
    get invalidMaxFileSizeMessage(): string;
    set invalidMaxFileSizeMessage(value: string);
    get invalidMinFileSizeMessage(): string;
    set invalidMinFileSizeMessage(value: string);
    get isDirty(): boolean;
    set isDirty(value: boolean);
    get isValid(): boolean;
    set isValid(value: boolean);
    get labelText(): string;
    set labelText(value: string);
    get maxFileSize(): number;
    set maxFileSize(value: number);
    get minFileSize(): number;
    set minFileSize(value: number);
    get multiple(): boolean;
    set multiple(value: boolean);
    get name(): string;
    set name(value: string);
    get onBeforeSend(): ((e: BeforeSendEvent) => void);
    set onBeforeSend(value: ((e: BeforeSendEvent) => void));
    get onContentReady(): ((e: ContentReadyEvent$2) => void);
    set onContentReady(value: ((e: ContentReadyEvent$2) => void));
    get onDisposing(): ((e: DisposingEvent$3) => void);
    set onDisposing(value: ((e: DisposingEvent$3) => void));
    get onDropZoneEnter(): ((e: DropZoneEnterEvent) => void);
    set onDropZoneEnter(value: ((e: DropZoneEnterEvent) => void));
    get onDropZoneLeave(): ((e: DropZoneLeaveEvent) => void);
    set onDropZoneLeave(value: ((e: DropZoneLeaveEvent) => void));
    get onFilesUploaded(): ((e: FilesUploadedEvent) => void);
    set onFilesUploaded(value: ((e: FilesUploadedEvent) => void));
    get onInitialized(): ((e: InitializedEvent$3) => void);
    set onInitialized(value: ((e: InitializedEvent$3) => void));
    get onOptionChanged(): ((e: OptionChangedEvent$3) => void);
    set onOptionChanged(value: ((e: OptionChangedEvent$3) => void));
    get onProgress(): ((e: ProgressEvent) => void);
    set onProgress(value: ((e: ProgressEvent) => void));
    get onUploadAborted(): ((e: UploadAbortedEvent) => void);
    set onUploadAborted(value: ((e: UploadAbortedEvent) => void));
    get onUploaded(): ((e: UploadedEvent) => void);
    set onUploaded(value: ((e: UploadedEvent) => void));
    get onUploadError(): ((e: UploadErrorEvent) => void);
    set onUploadError(value: ((e: UploadErrorEvent) => void));
    get onUploadStarted(): ((e: UploadStartedEvent) => void);
    set onUploadStarted(value: ((e: UploadStartedEvent) => void));
    get onValueChanged(): ((e: ValueChangedEvent$1) => void);
    set onValueChanged(value: ((e: ValueChangedEvent$1) => void));
    get progress(): number;
    set progress(value: number);
    get readOnly(): boolean;
    set readOnly(value: boolean);
    get readyToUploadMessage(): string;
    set readyToUploadMessage(value: string);
    get rtlEnabled(): boolean;
    set rtlEnabled(value: boolean);
    get selectButtonText(): string;
    set selectButtonText(value: string);
    get showFileList(): boolean;
    set showFileList(value: boolean);
    get tabIndex(): number;
    set tabIndex(value: number);
    get uploadAbortedMessage(): string;
    set uploadAbortedMessage(value: string);
    get uploadButtonText(): string;
    set uploadButtonText(value: string);
    get uploadChunk(): Function;
    set uploadChunk(value: Function);
    get uploadCustomData(): any;
    set uploadCustomData(value: any);
    get uploadedMessage(): string;
    set uploadedMessage(value: string);
    get uploadFailedMessage(): string;
    set uploadFailedMessage(value: string);
    get uploadFile(): Function;
    set uploadFile(value: Function);
    get uploadHeaders(): any;
    set uploadHeaders(value: any);
    get uploadMethod(): UploadHttpMethod;
    set uploadMethod(value: UploadHttpMethod);
    get uploadMode(): FileUploadMode;
    set uploadMode(value: FileUploadMode);
    get uploadUrl(): string;
    set uploadUrl(value: string);
    get validationError(): any | null;
    set validationError(value: any | null);
    get validationErrors(): null | Array<any>;
    set validationErrors(value: null | Array<any>);
    get validationStatus(): ValidationStatus;
    set validationStatus(value: ValidationStatus);
    get value(): Array<any>;
    set value(value: Array<any>);
    get visible(): boolean;
    set visible(value: boolean);
    get width(): number | string | undefined;
    set width(value: number | string | undefined);
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoFileUploaderOptions, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoFileUploaderOptions, "ng-component", never, {}, {}, never, never, true, never>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoFileUploaderOptionsComponent extends DxoFileUploaderOptions implements OnDestroy, OnInit {
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    valueChange: EventEmitter<Array<any>>;
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoFileUploaderOptionsComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoFileUploaderOptionsComponent, "dxo-file-uploader-options", never, { "abortUpload": { "alias": "abortUpload"; "required": false; }; "accept": { "alias": "accept"; "required": false; }; "accessKey": { "alias": "accessKey"; "required": false; }; "activeStateEnabled": { "alias": "activeStateEnabled"; "required": false; }; "allowCanceling": { "alias": "allowCanceling"; "required": false; }; "allowedFileExtensions": { "alias": "allowedFileExtensions"; "required": false; }; "chunkSize": { "alias": "chunkSize"; "required": false; }; "dialogTrigger": { "alias": "dialogTrigger"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "dropZone": { "alias": "dropZone"; "required": false; }; "elementAttr": { "alias": "elementAttr"; "required": false; }; "focusStateEnabled": { "alias": "focusStateEnabled"; "required": false; }; "height": { "alias": "height"; "required": false; }; "hint": { "alias": "hint"; "required": false; }; "hoverStateEnabled": { "alias": "hoverStateEnabled"; "required": false; }; "inputAttr": { "alias": "inputAttr"; "required": false; }; "invalidFileExtensionMessage": { "alias": "invalidFileExtensionMessage"; "required": false; }; "invalidMaxFileSizeMessage": { "alias": "invalidMaxFileSizeMessage"; "required": false; }; "invalidMinFileSizeMessage": { "alias": "invalidMinFileSizeMessage"; "required": false; }; "isDirty": { "alias": "isDirty"; "required": false; }; "isValid": { "alias": "isValid"; "required": false; }; "labelText": { "alias": "labelText"; "required": false; }; "maxFileSize": { "alias": "maxFileSize"; "required": false; }; "minFileSize": { "alias": "minFileSize"; "required": false; }; "multiple": { "alias": "multiple"; "required": false; }; "name": { "alias": "name"; "required": false; }; "onBeforeSend": { "alias": "onBeforeSend"; "required": false; }; "onContentReady": { "alias": "onContentReady"; "required": false; }; "onDisposing": { "alias": "onDisposing"; "required": false; }; "onDropZoneEnter": { "alias": "onDropZoneEnter"; "required": false; }; "onDropZoneLeave": { "alias": "onDropZoneLeave"; "required": false; }; "onFilesUploaded": { "alias": "onFilesUploaded"; "required": false; }; "onInitialized": { "alias": "onInitialized"; "required": false; }; "onOptionChanged": { "alias": "onOptionChanged"; "required": false; }; "onProgress": { "alias": "onProgress"; "required": false; }; "onUploadAborted": { "alias": "onUploadAborted"; "required": false; }; "onUploaded": { "alias": "onUploaded"; "required": false; }; "onUploadError": { "alias": "onUploadError"; "required": false; }; "onUploadStarted": { "alias": "onUploadStarted"; "required": false; }; "onValueChanged": { "alias": "onValueChanged"; "required": false; }; "progress": { "alias": "progress"; "required": false; }; "readOnly": { "alias": "readOnly"; "required": false; }; "readyToUploadMessage": { "alias": "readyToUploadMessage"; "required": false; }; "rtlEnabled": { "alias": "rtlEnabled"; "required": false; }; "selectButtonText": { "alias": "selectButtonText"; "required": false; }; "showFileList": { "alias": "showFileList"; "required": false; }; "tabIndex": { "alias": "tabIndex"; "required": false; }; "uploadAbortedMessage": { "alias": "uploadAbortedMessage"; "required": false; }; "uploadButtonText": { "alias": "uploadButtonText"; "required": false; }; "uploadChunk": { "alias": "uploadChunk"; "required": false; }; "uploadCustomData": { "alias": "uploadCustomData"; "required": false; }; "uploadedMessage": { "alias": "uploadedMessage"; "required": false; }; "uploadFailedMessage": { "alias": "uploadFailedMessage"; "required": false; }; "uploadFile": { "alias": "uploadFile"; "required": false; }; "uploadHeaders": { "alias": "uploadHeaders"; "required": false; }; "uploadMethod": { "alias": "uploadMethod"; "required": false; }; "uploadMode": { "alias": "uploadMode"; "required": false; }; "uploadUrl": { "alias": "uploadUrl"; "required": false; }; "validationError": { "alias": "validationError"; "required": false; }; "validationErrors": { "alias": "validationErrors"; "required": false; }; "validationStatus": { "alias": "validationStatus"; "required": false; }; "value": { "alias": "value"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, { "valueChange": "valueChange"; }, never, never, true, never>;
}
declare class DxoFileUploaderOptionsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoFileUploaderOptionsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoFileUploaderOptionsModule, never, [typeof DxoFileUploaderOptionsComponent], [typeof DxoFileUploaderOptionsComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoFileUploaderOptionsModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoFilterBuilderPopupComponent extends DxoPopupOptions implements OnDestroy, OnInit {
    set _toolbarItemsContentChildren(value: QueryList<CollectionNestedOption>);
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    heightChange: EventEmitter<number | string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    positionChange: EventEmitter<PositionAlignment | PositionConfig | Function>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    visibleChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    widthChange: EventEmitter<number | string>;
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoFilterBuilderPopupComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoFilterBuilderPopupComponent, "dxo-filter-builder-popup", never, { "accessKey": { "alias": "accessKey"; "required": false; }; "animation": { "alias": "animation"; "required": false; }; "container": { "alias": "container"; "required": false; }; "contentTemplate": { "alias": "contentTemplate"; "required": false; }; "deferRendering": { "alias": "deferRendering"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "dragAndResizeArea": { "alias": "dragAndResizeArea"; "required": false; }; "dragEnabled": { "alias": "dragEnabled"; "required": false; }; "dragOutsideBoundary": { "alias": "dragOutsideBoundary"; "required": false; }; "enableBodyScroll": { "alias": "enableBodyScroll"; "required": false; }; "focusStateEnabled": { "alias": "focusStateEnabled"; "required": false; }; "fullScreen": { "alias": "fullScreen"; "required": false; }; "height": { "alias": "height"; "required": false; }; "hideOnOutsideClick": { "alias": "hideOnOutsideClick"; "required": false; }; "hideOnParentScroll": { "alias": "hideOnParentScroll"; "required": false; }; "hint": { "alias": "hint"; "required": false; }; "hoverStateEnabled": { "alias": "hoverStateEnabled"; "required": false; }; "maxHeight": { "alias": "maxHeight"; "required": false; }; "maxWidth": { "alias": "maxWidth"; "required": false; }; "minHeight": { "alias": "minHeight"; "required": false; }; "minWidth": { "alias": "minWidth"; "required": false; }; "onContentReady": { "alias": "onContentReady"; "required": false; }; "onDisposing": { "alias": "onDisposing"; "required": false; }; "onHidden": { "alias": "onHidden"; "required": false; }; "onHiding": { "alias": "onHiding"; "required": false; }; "onInitialized": { "alias": "onInitialized"; "required": false; }; "onOptionChanged": { "alias": "onOptionChanged"; "required": false; }; "onResize": { "alias": "onResize"; "required": false; }; "onResizeEnd": { "alias": "onResizeEnd"; "required": false; }; "onResizeStart": { "alias": "onResizeStart"; "required": false; }; "onShowing": { "alias": "onShowing"; "required": false; }; "onShown": { "alias": "onShown"; "required": false; }; "onTitleRendered": { "alias": "onTitleRendered"; "required": false; }; "position": { "alias": "position"; "required": false; }; "resizeEnabled": { "alias": "resizeEnabled"; "required": false; }; "restorePosition": { "alias": "restorePosition"; "required": false; }; "rtlEnabled": { "alias": "rtlEnabled"; "required": false; }; "shading": { "alias": "shading"; "required": false; }; "shadingColor": { "alias": "shadingColor"; "required": false; }; "showCloseButton": { "alias": "showCloseButton"; "required": false; }; "showTitle": { "alias": "showTitle"; "required": false; }; "tabIndex": { "alias": "tabIndex"; "required": false; }; "title": { "alias": "title"; "required": false; }; "titleTemplate": { "alias": "titleTemplate"; "required": false; }; "toolbarItems": { "alias": "toolbarItems"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; "wrapperAttr": { "alias": "wrapperAttr"; "required": false; }; }, { "heightChange": "heightChange"; "positionChange": "positionChange"; "visibleChange": "visibleChange"; "widthChange": "widthChange"; }, ["_toolbarItemsContentChildren"], never, true, never>;
}
declare class DxoFilterBuilderPopupModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoFilterBuilderPopupModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoFilterBuilderPopupModule, never, [typeof DxoFilterBuilderPopupComponent], [typeof DxoFilterBuilderPopupComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoFilterBuilderPopupModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare abstract class DxoFilterBuilderOptions extends NestedOption {
    get accessKey(): string | undefined;
    set accessKey(value: string | undefined);
    get activeStateEnabled(): boolean;
    set activeStateEnabled(value: boolean);
    get allowHierarchicalFields(): boolean;
    set allowHierarchicalFields(value: boolean);
    get customOperations(): Array<dxFilterBuilderCustomOperation>;
    set customOperations(value: Array<dxFilterBuilderCustomOperation>);
    get disabled(): boolean;
    set disabled(value: boolean);
    get elementAttr(): any;
    set elementAttr(value: any);
    get fields(): Array<dxFilterBuilderField>;
    set fields(value: Array<dxFilterBuilderField>);
    get filterOperationDescriptions(): {
        between?: string;
        contains?: string;
        endsWith?: string;
        equal?: string;
        greaterThan?: string;
        greaterThanOrEqual?: string;
        isBlank?: string;
        isNotBlank?: string;
        lessThan?: string;
        lessThanOrEqual?: string;
        notContains?: string;
        notEqual?: string;
        startsWith?: string;
    };
    set filterOperationDescriptions(value: {
        between?: string;
        contains?: string;
        endsWith?: string;
        equal?: string;
        greaterThan?: string;
        greaterThanOrEqual?: string;
        isBlank?: string;
        isNotBlank?: string;
        lessThan?: string;
        lessThanOrEqual?: string;
        notContains?: string;
        notEqual?: string;
        startsWith?: string;
    });
    get focusStateEnabled(): boolean;
    set focusStateEnabled(value: boolean);
    get groupOperationDescriptions(): {
        and?: string;
        notAnd?: string;
        notOr?: string;
        or?: string;
    };
    set groupOperationDescriptions(value: {
        and?: string;
        notAnd?: string;
        notOr?: string;
        or?: string;
    });
    get groupOperations(): any | Array<GroupOperation>;
    set groupOperations(value: any | Array<GroupOperation>);
    get height(): number | string | undefined;
    set height(value: number | string | undefined);
    get hint(): string | undefined;
    set hint(value: string | undefined);
    get hoverStateEnabled(): boolean;
    set hoverStateEnabled(value: boolean);
    get maxGroupLevel(): number | undefined;
    set maxGroupLevel(value: number | undefined);
    get onContentReady(): ((e: ContentReadyEvent$3) => void);
    set onContentReady(value: ((e: ContentReadyEvent$3) => void));
    get onDisposing(): ((e: DisposingEvent$4) => void);
    set onDisposing(value: ((e: DisposingEvent$4) => void));
    get onEditorPrepared(): ((e: EditorPreparedEvent) => void);
    set onEditorPrepared(value: ((e: EditorPreparedEvent) => void));
    get onEditorPreparing(): ((e: EditorPreparingEvent) => void);
    set onEditorPreparing(value: ((e: EditorPreparingEvent) => void));
    get onInitialized(): ((e: InitializedEvent$4) => void);
    set onInitialized(value: ((e: InitializedEvent$4) => void));
    get onOptionChanged(): ((e: OptionChangedEvent$4) => void);
    set onOptionChanged(value: ((e: OptionChangedEvent$4) => void));
    get onValueChanged(): ((e: ValueChangedEvent$2) => void);
    set onValueChanged(value: ((e: ValueChangedEvent$2) => void));
    get rtlEnabled(): boolean;
    set rtlEnabled(value: boolean);
    get tabIndex(): number;
    set tabIndex(value: number);
    get value(): any;
    set value(value: any);
    get visible(): boolean;
    set visible(value: boolean);
    get width(): number | string | undefined;
    set width(value: number | string | undefined);
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoFilterBuilderOptions, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoFilterBuilderOptions, "ng-component", never, {}, {}, never, never, true, never>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoFilterBuilderComponent extends DxoFilterBuilderOptions implements OnDestroy, OnInit {
    set _customOperationsContentChildren(value: QueryList<CollectionNestedOption>);
    set _fieldsContentChildren(value: QueryList<CollectionNestedOption>);
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    valueChange: EventEmitter<any>;
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoFilterBuilderComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoFilterBuilderComponent, "dxo-filter-builder", never, { "accessKey": { "alias": "accessKey"; "required": false; }; "activeStateEnabled": { "alias": "activeStateEnabled"; "required": false; }; "allowHierarchicalFields": { "alias": "allowHierarchicalFields"; "required": false; }; "customOperations": { "alias": "customOperations"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "elementAttr": { "alias": "elementAttr"; "required": false; }; "fields": { "alias": "fields"; "required": false; }; "filterOperationDescriptions": { "alias": "filterOperationDescriptions"; "required": false; }; "focusStateEnabled": { "alias": "focusStateEnabled"; "required": false; }; "groupOperationDescriptions": { "alias": "groupOperationDescriptions"; "required": false; }; "groupOperations": { "alias": "groupOperations"; "required": false; }; "height": { "alias": "height"; "required": false; }; "hint": { "alias": "hint"; "required": false; }; "hoverStateEnabled": { "alias": "hoverStateEnabled"; "required": false; }; "maxGroupLevel": { "alias": "maxGroupLevel"; "required": false; }; "onContentReady": { "alias": "onContentReady"; "required": false; }; "onDisposing": { "alias": "onDisposing"; "required": false; }; "onEditorPrepared": { "alias": "onEditorPrepared"; "required": false; }; "onEditorPreparing": { "alias": "onEditorPreparing"; "required": false; }; "onInitialized": { "alias": "onInitialized"; "required": false; }; "onOptionChanged": { "alias": "onOptionChanged"; "required": false; }; "onValueChanged": { "alias": "onValueChanged"; "required": false; }; "rtlEnabled": { "alias": "rtlEnabled"; "required": false; }; "tabIndex": { "alias": "tabIndex"; "required": false; }; "value": { "alias": "value"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, { "valueChange": "valueChange"; }, ["_customOperationsContentChildren", "_fieldsContentChildren"], never, true, never>;
}
declare class DxoFilterBuilderModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoFilterBuilderModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoFilterBuilderModule, never, [typeof DxoFilterBuilderComponent], [typeof DxoFilterBuilderComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoFilterBuilderModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoFilterOperationDescriptionsComponent extends NestedOption implements OnDestroy, OnInit {
    get between(): string;
    set between(value: string);
    get contains(): string;
    set contains(value: string);
    get endsWith(): string;
    set endsWith(value: string);
    get equal(): string;
    set equal(value: string);
    get greaterThan(): string;
    set greaterThan(value: string);
    get greaterThanOrEqual(): string;
    set greaterThanOrEqual(value: string);
    get isBlank(): string;
    set isBlank(value: string);
    get isNotBlank(): string;
    set isNotBlank(value: string);
    get lessThan(): string;
    set lessThan(value: string);
    get lessThanOrEqual(): string;
    set lessThanOrEqual(value: string);
    get notContains(): string;
    set notContains(value: string);
    get notEqual(): string;
    set notEqual(value: string);
    get startsWith(): string;
    set startsWith(value: string);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoFilterOperationDescriptionsComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoFilterOperationDescriptionsComponent, "dxo-filter-operation-descriptions", never, { "between": { "alias": "between"; "required": false; }; "contains": { "alias": "contains"; "required": false; }; "endsWith": { "alias": "endsWith"; "required": false; }; "equal": { "alias": "equal"; "required": false; }; "greaterThan": { "alias": "greaterThan"; "required": false; }; "greaterThanOrEqual": { "alias": "greaterThanOrEqual"; "required": false; }; "isBlank": { "alias": "isBlank"; "required": false; }; "isNotBlank": { "alias": "isNotBlank"; "required": false; }; "lessThan": { "alias": "lessThan"; "required": false; }; "lessThanOrEqual": { "alias": "lessThanOrEqual"; "required": false; }; "notContains": { "alias": "notContains"; "required": false; }; "notEqual": { "alias": "notEqual"; "required": false; }; "startsWith": { "alias": "startsWith"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoFilterOperationDescriptionsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoFilterOperationDescriptionsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoFilterOperationDescriptionsModule, never, [typeof DxoFilterOperationDescriptionsComponent], [typeof DxoFilterOperationDescriptionsComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoFilterOperationDescriptionsModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare abstract class DxoFilterPanel extends NestedOption {
    get customizeText(): Function;
    set customizeText(value: Function);
    get filterEnabled(): boolean;
    set filterEnabled(value: boolean);
    get texts(): FilterPanelTexts;
    set texts(value: FilterPanelTexts);
    get visible(): boolean;
    set visible(value: boolean);
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoFilterPanel, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoFilterPanel, "ng-component", never, {}, {}, never, never, true, never>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoFilterPanelComponent extends DxoFilterPanel implements OnDestroy, OnInit {
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    filterEnabledChange: EventEmitter<boolean>;
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoFilterPanelComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoFilterPanelComponent, "dxo-filter-panel", never, { "customizeText": { "alias": "customizeText"; "required": false; }; "filterEnabled": { "alias": "filterEnabled"; "required": false; }; "texts": { "alias": "texts"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; }, { "filterEnabledChange": "filterEnabledChange"; }, never, never, true, never>;
}
declare class DxoFilterPanelModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoFilterPanelModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoFilterPanelModule, never, [typeof DxoFilterPanelComponent], [typeof DxoFilterPanelComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoFilterPanelModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare abstract class DxoGanttFilterRow extends NestedOption {
    get applyFilter(): ApplyFilterMode;
    set applyFilter(value: ApplyFilterMode);
    get applyFilterText(): string;
    set applyFilterText(value: string);
    get betweenEndText(): string;
    set betweenEndText(value: string);
    get betweenStartText(): string;
    set betweenStartText(value: string);
    get operationDescriptions(): {
        between?: string;
        contains?: string;
        endsWith?: string;
        equal?: string;
        greaterThan?: string;
        greaterThanOrEqual?: string;
        lessThan?: string;
        lessThanOrEqual?: string;
        notContains?: string;
        notEqual?: string;
        startsWith?: string;
    } | dxGanttFilterRowOperationDescriptions;
    set operationDescriptions(value: {
        between?: string;
        contains?: string;
        endsWith?: string;
        equal?: string;
        greaterThan?: string;
        greaterThanOrEqual?: string;
        lessThan?: string;
        lessThanOrEqual?: string;
        notContains?: string;
        notEqual?: string;
        startsWith?: string;
    } | dxGanttFilterRowOperationDescriptions);
    get resetOperationText(): string;
    set resetOperationText(value: string);
    get showAllText(): string;
    set showAllText(value: string);
    get showOperationChooser(): boolean;
    set showOperationChooser(value: boolean);
    get visible(): boolean;
    set visible(value: boolean);
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoGanttFilterRow, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoGanttFilterRow, "ng-component", never, {}, {}, never, never, true, never>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoFilterRowComponent extends DxoGanttFilterRow implements OnDestroy, OnInit {
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoFilterRowComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoFilterRowComponent, "dxo-filter-row", never, { "applyFilter": { "alias": "applyFilter"; "required": false; }; "applyFilterText": { "alias": "applyFilterText"; "required": false; }; "betweenEndText": { "alias": "betweenEndText"; "required": false; }; "betweenStartText": { "alias": "betweenStartText"; "required": false; }; "operationDescriptions": { "alias": "operationDescriptions"; "required": false; }; "resetOperationText": { "alias": "resetOperationText"; "required": false; }; "showAllText": { "alias": "showAllText"; "required": false; }; "showOperationChooser": { "alias": "showOperationChooser"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoFilterRowModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoFilterRowModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoFilterRowModule, never, [typeof DxoFilterRowComponent], [typeof DxoFilterRowComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoFilterRowModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare abstract class DxoVizFont extends NestedOption {
    get color(): string;
    set color(value: string);
    get family(): string;
    set family(value: string);
    get opacity(): number;
    set opacity(value: number);
    get size(): number | string;
    set size(value: number | string);
    get weight(): number;
    set weight(value: number);
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoVizFont, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoVizFont, "ng-component", never, {}, {}, never, never, true, never>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoFontComponent extends DxoVizFont implements OnDestroy, OnInit {
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoFontComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoFontComponent, "dxo-font", never, { "color": { "alias": "color"; "required": false; }; "family": { "alias": "family"; "required": false; }; "opacity": { "alias": "opacity"; "required": false; }; "size": { "alias": "size"; "required": false; }; "weight": { "alias": "weight"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoFontModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoFontModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoFontModule, never, [typeof DxoFontComponent], [typeof DxoFontComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoFontModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare abstract class DxoFormSimpleItem extends NestedOption {
    get colSpan(): number | undefined;
    set colSpan(value: number | undefined);
    get cssClass(): string | undefined;
    set cssClass(value: string | undefined);
    get dataField(): string | undefined;
    set dataField(value: string | undefined);
    get editorOptions(): any | undefined;
    set editorOptions(value: any | undefined);
    get editorType(): FormItemComponent;
    set editorType(value: FormItemComponent);
    get helpText(): string | undefined;
    set helpText(value: string | undefined);
    get isRequired(): boolean | undefined;
    set isRequired(value: boolean | undefined);
    get itemType(): FormItemType;
    set itemType(value: FormItemType);
    get label(): {
        alignment?: HorizontalAlignment;
        location?: LabelLocation;
        showColon?: boolean;
        template?: any;
        text?: string | undefined;
        visible?: boolean;
    };
    set label(value: {
        alignment?: HorizontalAlignment;
        location?: LabelLocation;
        showColon?: boolean;
        template?: any;
        text?: string | undefined;
        visible?: boolean;
    });
    get name(): string | undefined;
    set name(value: string | undefined);
    get template(): any;
    set template(value: any);
    get validationRules(): Array<RequiredRule | NumericRule | RangeRule | StringLengthRule | CustomRule | CompareRule | PatternRule | EmailRule | AsyncRule>;
    set validationRules(value: Array<RequiredRule | NumericRule | RangeRule | StringLengthRule | CustomRule | CompareRule | PatternRule | EmailRule | AsyncRule>);
    get visible(): boolean;
    set visible(value: boolean);
    get visibleIndex(): number | undefined;
    set visibleIndex(value: number | undefined);
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoFormSimpleItem, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoFormSimpleItem, "ng-component", never, {}, {}, never, never, true, never>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoFormItemComponent extends DxoFormSimpleItem implements OnDestroy, OnInit {
    set _validationRulesContentChildren(value: QueryList<CollectionNestedOption>);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoFormItemComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoFormItemComponent, "dxo-form-item", never, { "colSpan": { "alias": "colSpan"; "required": false; }; "cssClass": { "alias": "cssClass"; "required": false; }; "dataField": { "alias": "dataField"; "required": false; }; "editorOptions": { "alias": "editorOptions"; "required": false; }; "editorType": { "alias": "editorType"; "required": false; }; "helpText": { "alias": "helpText"; "required": false; }; "isRequired": { "alias": "isRequired"; "required": false; }; "itemType": { "alias": "itemType"; "required": false; }; "label": { "alias": "label"; "required": false; }; "name": { "alias": "name"; "required": false; }; "template": { "alias": "template"; "required": false; }; "validationRules": { "alias": "validationRules"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "visibleIndex": { "alias": "visibleIndex"; "required": false; }; }, {}, ["_validationRulesContentChildren"], never, true, never>;
}
declare class DxoFormItemModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoFormItemModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoFormItemModule, never, [typeof DxoFormItemComponent], [typeof DxoFormItemComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoFormItemModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare abstract class DxoFormOptions extends NestedOption {
    get accessKey(): string | undefined;
    set accessKey(value: string | undefined);
    get activeStateEnabled(): boolean;
    set activeStateEnabled(value: boolean);
    get alignItemLabels(): boolean;
    set alignItemLabels(value: boolean);
    get alignItemLabelsInAllGroups(): boolean;
    set alignItemLabelsInAllGroups(value: boolean);
    get colCount(): Mode | number;
    set colCount(value: Mode | number);
    get colCountByScreen(): {
        lg?: number | undefined;
        md?: number | undefined;
        sm?: number | undefined;
        xs?: number | undefined;
    };
    set colCountByScreen(value: {
        lg?: number | undefined;
        md?: number | undefined;
        sm?: number | undefined;
        xs?: number | undefined;
    });
    get customizeItem(): Function;
    set customizeItem(value: Function);
    get disabled(): boolean;
    set disabled(value: boolean);
    get elementAttr(): any;
    set elementAttr(value: any);
    get focusStateEnabled(): boolean;
    set focusStateEnabled(value: boolean);
    get formData(): any;
    set formData(value: any);
    get height(): number | string | undefined;
    set height(value: number | string | undefined);
    get hint(): string | undefined;
    set hint(value: string | undefined);
    get hoverStateEnabled(): boolean;
    set hoverStateEnabled(value: boolean);
    get isDirty(): boolean;
    set isDirty(value: boolean);
    get items(): Array<SimpleItem | GroupItem | TabbedItem | EmptyItem | ButtonItem>;
    set items(value: Array<SimpleItem | GroupItem | TabbedItem | EmptyItem | ButtonItem>);
    get labelLocation(): LabelLocation;
    set labelLocation(value: LabelLocation);
    get labelMode(): FormLabelMode;
    set labelMode(value: FormLabelMode);
    get minColWidth(): number;
    set minColWidth(value: number);
    get onContentReady(): ((e: ContentReadyEvent$4) => void);
    set onContentReady(value: ((e: ContentReadyEvent$4) => void));
    get onDisposing(): ((e: DisposingEvent$5) => void);
    set onDisposing(value: ((e: DisposingEvent$5) => void));
    get onEditorEnterKey(): ((e: EditorEnterKeyEvent) => void);
    set onEditorEnterKey(value: ((e: EditorEnterKeyEvent) => void));
    get onFieldDataChanged(): ((e: FieldDataChangedEvent) => void);
    set onFieldDataChanged(value: ((e: FieldDataChangedEvent) => void));
    get onInitialized(): ((e: InitializedEvent$5) => void);
    set onInitialized(value: ((e: InitializedEvent$5) => void));
    get onOptionChanged(): ((e: OptionChangedEvent$5) => void);
    set onOptionChanged(value: ((e: OptionChangedEvent$5) => void));
    get optionalMark(): string;
    set optionalMark(value: string);
    get readOnly(): boolean;
    set readOnly(value: boolean);
    get requiredMark(): string;
    set requiredMark(value: string);
    get requiredMessage(): string;
    set requiredMessage(value: string);
    get rtlEnabled(): boolean;
    set rtlEnabled(value: boolean);
    get screenByWidth(): Function;
    set screenByWidth(value: Function);
    get scrollingEnabled(): boolean;
    set scrollingEnabled(value: boolean);
    get showColonAfterLabel(): boolean;
    set showColonAfterLabel(value: boolean);
    get showOptionalMark(): boolean;
    set showOptionalMark(value: boolean);
    get showRequiredMark(): boolean;
    set showRequiredMark(value: boolean);
    get showValidationSummary(): boolean;
    set showValidationSummary(value: boolean);
    get tabIndex(): number;
    set tabIndex(value: number);
    get validationGroup(): string | undefined;
    set validationGroup(value: string | undefined);
    get visible(): boolean;
    set visible(value: boolean);
    get width(): number | string | undefined;
    set width(value: number | string | undefined);
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoFormOptions, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoFormOptions, "ng-component", never, {}, {}, never, never, true, never>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoFormComponent extends DxoFormOptions implements OnDestroy, OnInit {
    set _itemsContentChildren(value: QueryList<CollectionNestedOption>);
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    formDataChange: EventEmitter<any>;
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoFormComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoFormComponent, "dxo-form", never, { "accessKey": { "alias": "accessKey"; "required": false; }; "activeStateEnabled": { "alias": "activeStateEnabled"; "required": false; }; "alignItemLabels": { "alias": "alignItemLabels"; "required": false; }; "alignItemLabelsInAllGroups": { "alias": "alignItemLabelsInAllGroups"; "required": false; }; "colCount": { "alias": "colCount"; "required": false; }; "colCountByScreen": { "alias": "colCountByScreen"; "required": false; }; "customizeItem": { "alias": "customizeItem"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "elementAttr": { "alias": "elementAttr"; "required": false; }; "focusStateEnabled": { "alias": "focusStateEnabled"; "required": false; }; "formData": { "alias": "formData"; "required": false; }; "height": { "alias": "height"; "required": false; }; "hint": { "alias": "hint"; "required": false; }; "hoverStateEnabled": { "alias": "hoverStateEnabled"; "required": false; }; "isDirty": { "alias": "isDirty"; "required": false; }; "items": { "alias": "items"; "required": false; }; "labelLocation": { "alias": "labelLocation"; "required": false; }; "labelMode": { "alias": "labelMode"; "required": false; }; "minColWidth": { "alias": "minColWidth"; "required": false; }; "onContentReady": { "alias": "onContentReady"; "required": false; }; "onDisposing": { "alias": "onDisposing"; "required": false; }; "onEditorEnterKey": { "alias": "onEditorEnterKey"; "required": false; }; "onFieldDataChanged": { "alias": "onFieldDataChanged"; "required": false; }; "onInitialized": { "alias": "onInitialized"; "required": false; }; "onOptionChanged": { "alias": "onOptionChanged"; "required": false; }; "optionalMark": { "alias": "optionalMark"; "required": false; }; "readOnly": { "alias": "readOnly"; "required": false; }; "requiredMark": { "alias": "requiredMark"; "required": false; }; "requiredMessage": { "alias": "requiredMessage"; "required": false; }; "rtlEnabled": { "alias": "rtlEnabled"; "required": false; }; "screenByWidth": { "alias": "screenByWidth"; "required": false; }; "scrollingEnabled": { "alias": "scrollingEnabled"; "required": false; }; "showColonAfterLabel": { "alias": "showColonAfterLabel"; "required": false; }; "showOptionalMark": { "alias": "showOptionalMark"; "required": false; }; "showRequiredMark": { "alias": "showRequiredMark"; "required": false; }; "showValidationSummary": { "alias": "showValidationSummary"; "required": false; }; "tabIndex": { "alias": "tabIndex"; "required": false; }; "validationGroup": { "alias": "validationGroup"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, { "formDataChange": "formDataChange"; }, ["_itemsContentChildren"], never, true, never>;
}
declare class DxoFormModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoFormModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoFormModule, never, [typeof DxoFormComponent], [typeof DxoFormComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoFormModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoFormatComponent extends DxoFormat implements OnDestroy, OnInit {
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoFormatComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoFormatComponent, "dxo-format", never, { "currency": { "alias": "currency"; "required": false; }; "formatter": { "alias": "formatter"; "required": false; }; "parser": { "alias": "parser"; "required": false; }; "precision": { "alias": "precision"; "required": false; }; "type": { "alias": "type"; "required": false; }; "useCurrencyAccountingStyle": { "alias": "useCurrencyAccountingStyle"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoFormatModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoFormatModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoFormatModule, never, [typeof DxoFormatComponent], [typeof DxoFormatComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoFormatModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare abstract class DxoAnimationState extends NestedOption {
    get left(): number;
    set left(value: number);
    get opacity(): number;
    set opacity(value: number);
    get position(): PositionConfig;
    set position(value: PositionConfig);
    get scale(): number;
    set scale(value: number);
    get top(): number;
    set top(value: number);
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoAnimationState, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoAnimationState, "ng-component", never, {}, {}, never, never, true, never>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoFromComponent extends DxoAnimationState implements OnDestroy, OnInit {
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoFromComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoFromComponent, "dxo-from", never, { "left": { "alias": "left"; "required": false; }; "opacity": { "alias": "opacity"; "required": false; }; "position": { "alias": "position"; "required": false; }; "scale": { "alias": "scale"; "required": false; }; "top": { "alias": "top"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoFromModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoFromModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoFromModule, never, [typeof DxoFromComponent], [typeof DxoFromComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoFromModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoFullstackedareaComponent extends DxoChartCommonSeriesSettings implements OnDestroy, OnInit {
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoFullstackedareaComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoFullstackedareaComponent, "dxo-fullstackedarea", never, { "aggregation": { "alias": "aggregation"; "required": false; }; "area": { "alias": "area"; "required": false; }; "argumentField": { "alias": "argumentField"; "required": false; }; "axis": { "alias": "axis"; "required": false; }; "bar": { "alias": "bar"; "required": false; }; "barOverlapGroup": { "alias": "barOverlapGroup"; "required": false; }; "barPadding": { "alias": "barPadding"; "required": false; }; "barWidth": { "alias": "barWidth"; "required": false; }; "border": { "alias": "border"; "required": false; }; "bubble": { "alias": "bubble"; "required": false; }; "candlestick": { "alias": "candlestick"; "required": false; }; "closeValueField": { "alias": "closeValueField"; "required": false; }; "color": { "alias": "color"; "required": false; }; "cornerRadius": { "alias": "cornerRadius"; "required": false; }; "dashStyle": { "alias": "dashStyle"; "required": false; }; "fullstackedarea": { "alias": "fullstackedarea"; "required": false; }; "fullstackedbar": { "alias": "fullstackedbar"; "required": false; }; "fullstackedline": { "alias": "fullstackedline"; "required": false; }; "fullstackedspline": { "alias": "fullstackedspline"; "required": false; }; "fullstackedsplinearea": { "alias": "fullstackedsplinearea"; "required": false; }; "highValueField": { "alias": "highValueField"; "required": false; }; "hoverMode": { "alias": "hoverMode"; "required": false; }; "hoverStyle": { "alias": "hoverStyle"; "required": false; }; "ignoreEmptyPoints": { "alias": "ignoreEmptyPoints"; "required": false; }; "innerColor": { "alias": "innerColor"; "required": false; }; "label": { "alias": "label"; "required": false; }; "line": { "alias": "line"; "required": false; }; "lowValueField": { "alias": "lowValueField"; "required": false; }; "maxLabelCount": { "alias": "maxLabelCount"; "required": false; }; "minBarSize": { "alias": "minBarSize"; "required": false; }; "opacity": { "alias": "opacity"; "required": false; }; "openValueField": { "alias": "openValueField"; "required": false; }; "pane": { "alias": "pane"; "required": false; }; "point": { "alias": "point"; "required": false; }; "rangearea": { "alias": "rangearea"; "required": false; }; "rangebar": { "alias": "rangebar"; "required": false; }; "rangeValue1Field": { "alias": "rangeValue1Field"; "required": false; }; "rangeValue2Field": { "alias": "rangeValue2Field"; "required": false; }; "reduction": { "alias": "reduction"; "required": false; }; "scatter": { "alias": "scatter"; "required": false; }; "selectionMode": { "alias": "selectionMode"; "required": false; }; "selectionStyle": { "alias": "selectionStyle"; "required": false; }; "showInLegend": { "alias": "showInLegend"; "required": false; }; "sizeField": { "alias": "sizeField"; "required": false; }; "spline": { "alias": "spline"; "required": false; }; "splinearea": { "alias": "splinearea"; "required": false; }; "stack": { "alias": "stack"; "required": false; }; "stackedarea": { "alias": "stackedarea"; "required": false; }; "stackedbar": { "alias": "stackedbar"; "required": false; }; "stackedline": { "alias": "stackedline"; "required": false; }; "stackedspline": { "alias": "stackedspline"; "required": false; }; "stackedsplinearea": { "alias": "stackedsplinearea"; "required": false; }; "steparea": { "alias": "steparea"; "required": false; }; "stepline": { "alias": "stepline"; "required": false; }; "stock": { "alias": "stock"; "required": false; }; "tagField": { "alias": "tagField"; "required": false; }; "type": { "alias": "type"; "required": false; }; "valueErrorBar": { "alias": "valueErrorBar"; "required": false; }; "valueField": { "alias": "valueField"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoFullstackedareaModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoFullstackedareaModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoFullstackedareaModule, never, [typeof DxoFullstackedareaComponent], [typeof DxoFullstackedareaComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoFullstackedareaModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoFullstackedbarComponent extends DxoChartCommonSeriesSettings implements OnDestroy, OnInit {
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoFullstackedbarComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoFullstackedbarComponent, "dxo-fullstackedbar", never, { "aggregation": { "alias": "aggregation"; "required": false; }; "area": { "alias": "area"; "required": false; }; "argumentField": { "alias": "argumentField"; "required": false; }; "axis": { "alias": "axis"; "required": false; }; "bar": { "alias": "bar"; "required": false; }; "barOverlapGroup": { "alias": "barOverlapGroup"; "required": false; }; "barPadding": { "alias": "barPadding"; "required": false; }; "barWidth": { "alias": "barWidth"; "required": false; }; "border": { "alias": "border"; "required": false; }; "bubble": { "alias": "bubble"; "required": false; }; "candlestick": { "alias": "candlestick"; "required": false; }; "closeValueField": { "alias": "closeValueField"; "required": false; }; "color": { "alias": "color"; "required": false; }; "cornerRadius": { "alias": "cornerRadius"; "required": false; }; "dashStyle": { "alias": "dashStyle"; "required": false; }; "fullstackedarea": { "alias": "fullstackedarea"; "required": false; }; "fullstackedbar": { "alias": "fullstackedbar"; "required": false; }; "fullstackedline": { "alias": "fullstackedline"; "required": false; }; "fullstackedspline": { "alias": "fullstackedspline"; "required": false; }; "fullstackedsplinearea": { "alias": "fullstackedsplinearea"; "required": false; }; "highValueField": { "alias": "highValueField"; "required": false; }; "hoverMode": { "alias": "hoverMode"; "required": false; }; "hoverStyle": { "alias": "hoverStyle"; "required": false; }; "ignoreEmptyPoints": { "alias": "ignoreEmptyPoints"; "required": false; }; "innerColor": { "alias": "innerColor"; "required": false; }; "label": { "alias": "label"; "required": false; }; "line": { "alias": "line"; "required": false; }; "lowValueField": { "alias": "lowValueField"; "required": false; }; "maxLabelCount": { "alias": "maxLabelCount"; "required": false; }; "minBarSize": { "alias": "minBarSize"; "required": false; }; "opacity": { "alias": "opacity"; "required": false; }; "openValueField": { "alias": "openValueField"; "required": false; }; "pane": { "alias": "pane"; "required": false; }; "point": { "alias": "point"; "required": false; }; "rangearea": { "alias": "rangearea"; "required": false; }; "rangebar": { "alias": "rangebar"; "required": false; }; "rangeValue1Field": { "alias": "rangeValue1Field"; "required": false; }; "rangeValue2Field": { "alias": "rangeValue2Field"; "required": false; }; "reduction": { "alias": "reduction"; "required": false; }; "scatter": { "alias": "scatter"; "required": false; }; "selectionMode": { "alias": "selectionMode"; "required": false; }; "selectionStyle": { "alias": "selectionStyle"; "required": false; }; "showInLegend": { "alias": "showInLegend"; "required": false; }; "sizeField": { "alias": "sizeField"; "required": false; }; "spline": { "alias": "spline"; "required": false; }; "splinearea": { "alias": "splinearea"; "required": false; }; "stack": { "alias": "stack"; "required": false; }; "stackedarea": { "alias": "stackedarea"; "required": false; }; "stackedbar": { "alias": "stackedbar"; "required": false; }; "stackedline": { "alias": "stackedline"; "required": false; }; "stackedspline": { "alias": "stackedspline"; "required": false; }; "stackedsplinearea": { "alias": "stackedsplinearea"; "required": false; }; "steparea": { "alias": "steparea"; "required": false; }; "stepline": { "alias": "stepline"; "required": false; }; "stock": { "alias": "stock"; "required": false; }; "tagField": { "alias": "tagField"; "required": false; }; "type": { "alias": "type"; "required": false; }; "valueErrorBar": { "alias": "valueErrorBar"; "required": false; }; "valueField": { "alias": "valueField"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoFullstackedbarModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoFullstackedbarModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoFullstackedbarModule, never, [typeof DxoFullstackedbarComponent], [typeof DxoFullstackedbarComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoFullstackedbarModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoFullstackedlineComponent extends DxoChartCommonSeriesSettings implements OnDestroy, OnInit {
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoFullstackedlineComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoFullstackedlineComponent, "dxo-fullstackedline", never, { "aggregation": { "alias": "aggregation"; "required": false; }; "area": { "alias": "area"; "required": false; }; "argumentField": { "alias": "argumentField"; "required": false; }; "axis": { "alias": "axis"; "required": false; }; "bar": { "alias": "bar"; "required": false; }; "barOverlapGroup": { "alias": "barOverlapGroup"; "required": false; }; "barPadding": { "alias": "barPadding"; "required": false; }; "barWidth": { "alias": "barWidth"; "required": false; }; "border": { "alias": "border"; "required": false; }; "bubble": { "alias": "bubble"; "required": false; }; "candlestick": { "alias": "candlestick"; "required": false; }; "closeValueField": { "alias": "closeValueField"; "required": false; }; "color": { "alias": "color"; "required": false; }; "cornerRadius": { "alias": "cornerRadius"; "required": false; }; "dashStyle": { "alias": "dashStyle"; "required": false; }; "fullstackedarea": { "alias": "fullstackedarea"; "required": false; }; "fullstackedbar": { "alias": "fullstackedbar"; "required": false; }; "fullstackedline": { "alias": "fullstackedline"; "required": false; }; "fullstackedspline": { "alias": "fullstackedspline"; "required": false; }; "fullstackedsplinearea": { "alias": "fullstackedsplinearea"; "required": false; }; "highValueField": { "alias": "highValueField"; "required": false; }; "hoverMode": { "alias": "hoverMode"; "required": false; }; "hoverStyle": { "alias": "hoverStyle"; "required": false; }; "ignoreEmptyPoints": { "alias": "ignoreEmptyPoints"; "required": false; }; "innerColor": { "alias": "innerColor"; "required": false; }; "label": { "alias": "label"; "required": false; }; "line": { "alias": "line"; "required": false; }; "lowValueField": { "alias": "lowValueField"; "required": false; }; "maxLabelCount": { "alias": "maxLabelCount"; "required": false; }; "minBarSize": { "alias": "minBarSize"; "required": false; }; "opacity": { "alias": "opacity"; "required": false; }; "openValueField": { "alias": "openValueField"; "required": false; }; "pane": { "alias": "pane"; "required": false; }; "point": { "alias": "point"; "required": false; }; "rangearea": { "alias": "rangearea"; "required": false; }; "rangebar": { "alias": "rangebar"; "required": false; }; "rangeValue1Field": { "alias": "rangeValue1Field"; "required": false; }; "rangeValue2Field": { "alias": "rangeValue2Field"; "required": false; }; "reduction": { "alias": "reduction"; "required": false; }; "scatter": { "alias": "scatter"; "required": false; }; "selectionMode": { "alias": "selectionMode"; "required": false; }; "selectionStyle": { "alias": "selectionStyle"; "required": false; }; "showInLegend": { "alias": "showInLegend"; "required": false; }; "sizeField": { "alias": "sizeField"; "required": false; }; "spline": { "alias": "spline"; "required": false; }; "splinearea": { "alias": "splinearea"; "required": false; }; "stack": { "alias": "stack"; "required": false; }; "stackedarea": { "alias": "stackedarea"; "required": false; }; "stackedbar": { "alias": "stackedbar"; "required": false; }; "stackedline": { "alias": "stackedline"; "required": false; }; "stackedspline": { "alias": "stackedspline"; "required": false; }; "stackedsplinearea": { "alias": "stackedsplinearea"; "required": false; }; "steparea": { "alias": "steparea"; "required": false; }; "stepline": { "alias": "stepline"; "required": false; }; "stock": { "alias": "stock"; "required": false; }; "tagField": { "alias": "tagField"; "required": false; }; "type": { "alias": "type"; "required": false; }; "valueErrorBar": { "alias": "valueErrorBar"; "required": false; }; "valueField": { "alias": "valueField"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoFullstackedlineModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoFullstackedlineModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoFullstackedlineModule, never, [typeof DxoFullstackedlineComponent], [typeof DxoFullstackedlineComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoFullstackedlineModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoFullstackedsplineComponent extends DxoChartCommonSeriesSettings implements OnDestroy, OnInit {
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoFullstackedsplineComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoFullstackedsplineComponent, "dxo-fullstackedspline", never, { "aggregation": { "alias": "aggregation"; "required": false; }; "area": { "alias": "area"; "required": false; }; "argumentField": { "alias": "argumentField"; "required": false; }; "axis": { "alias": "axis"; "required": false; }; "bar": { "alias": "bar"; "required": false; }; "barOverlapGroup": { "alias": "barOverlapGroup"; "required": false; }; "barPadding": { "alias": "barPadding"; "required": false; }; "barWidth": { "alias": "barWidth"; "required": false; }; "border": { "alias": "border"; "required": false; }; "bubble": { "alias": "bubble"; "required": false; }; "candlestick": { "alias": "candlestick"; "required": false; }; "closeValueField": { "alias": "closeValueField"; "required": false; }; "color": { "alias": "color"; "required": false; }; "cornerRadius": { "alias": "cornerRadius"; "required": false; }; "dashStyle": { "alias": "dashStyle"; "required": false; }; "fullstackedarea": { "alias": "fullstackedarea"; "required": false; }; "fullstackedbar": { "alias": "fullstackedbar"; "required": false; }; "fullstackedline": { "alias": "fullstackedline"; "required": false; }; "fullstackedspline": { "alias": "fullstackedspline"; "required": false; }; "fullstackedsplinearea": { "alias": "fullstackedsplinearea"; "required": false; }; "highValueField": { "alias": "highValueField"; "required": false; }; "hoverMode": { "alias": "hoverMode"; "required": false; }; "hoverStyle": { "alias": "hoverStyle"; "required": false; }; "ignoreEmptyPoints": { "alias": "ignoreEmptyPoints"; "required": false; }; "innerColor": { "alias": "innerColor"; "required": false; }; "label": { "alias": "label"; "required": false; }; "line": { "alias": "line"; "required": false; }; "lowValueField": { "alias": "lowValueField"; "required": false; }; "maxLabelCount": { "alias": "maxLabelCount"; "required": false; }; "minBarSize": { "alias": "minBarSize"; "required": false; }; "opacity": { "alias": "opacity"; "required": false; }; "openValueField": { "alias": "openValueField"; "required": false; }; "pane": { "alias": "pane"; "required": false; }; "point": { "alias": "point"; "required": false; }; "rangearea": { "alias": "rangearea"; "required": false; }; "rangebar": { "alias": "rangebar"; "required": false; }; "rangeValue1Field": { "alias": "rangeValue1Field"; "required": false; }; "rangeValue2Field": { "alias": "rangeValue2Field"; "required": false; }; "reduction": { "alias": "reduction"; "required": false; }; "scatter": { "alias": "scatter"; "required": false; }; "selectionMode": { "alias": "selectionMode"; "required": false; }; "selectionStyle": { "alias": "selectionStyle"; "required": false; }; "showInLegend": { "alias": "showInLegend"; "required": false; }; "sizeField": { "alias": "sizeField"; "required": false; }; "spline": { "alias": "spline"; "required": false; }; "splinearea": { "alias": "splinearea"; "required": false; }; "stack": { "alias": "stack"; "required": false; }; "stackedarea": { "alias": "stackedarea"; "required": false; }; "stackedbar": { "alias": "stackedbar"; "required": false; }; "stackedline": { "alias": "stackedline"; "required": false; }; "stackedspline": { "alias": "stackedspline"; "required": false; }; "stackedsplinearea": { "alias": "stackedsplinearea"; "required": false; }; "steparea": { "alias": "steparea"; "required": false; }; "stepline": { "alias": "stepline"; "required": false; }; "stock": { "alias": "stock"; "required": false; }; "tagField": { "alias": "tagField"; "required": false; }; "type": { "alias": "type"; "required": false; }; "valueErrorBar": { "alias": "valueErrorBar"; "required": false; }; "valueField": { "alias": "valueField"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoFullstackedsplineModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoFullstackedsplineModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoFullstackedsplineModule, never, [typeof DxoFullstackedsplineComponent], [typeof DxoFullstackedsplineComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoFullstackedsplineModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoFullstackedsplineareaComponent extends DxoChartCommonSeriesSettings implements OnDestroy, OnInit {
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoFullstackedsplineareaComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoFullstackedsplineareaComponent, "dxo-fullstackedsplinearea", never, { "aggregation": { "alias": "aggregation"; "required": false; }; "area": { "alias": "area"; "required": false; }; "argumentField": { "alias": "argumentField"; "required": false; }; "axis": { "alias": "axis"; "required": false; }; "bar": { "alias": "bar"; "required": false; }; "barOverlapGroup": { "alias": "barOverlapGroup"; "required": false; }; "barPadding": { "alias": "barPadding"; "required": false; }; "barWidth": { "alias": "barWidth"; "required": false; }; "border": { "alias": "border"; "required": false; }; "bubble": { "alias": "bubble"; "required": false; }; "candlestick": { "alias": "candlestick"; "required": false; }; "closeValueField": { "alias": "closeValueField"; "required": false; }; "color": { "alias": "color"; "required": false; }; "cornerRadius": { "alias": "cornerRadius"; "required": false; }; "dashStyle": { "alias": "dashStyle"; "required": false; }; "fullstackedarea": { "alias": "fullstackedarea"; "required": false; }; "fullstackedbar": { "alias": "fullstackedbar"; "required": false; }; "fullstackedline": { "alias": "fullstackedline"; "required": false; }; "fullstackedspline": { "alias": "fullstackedspline"; "required": false; }; "fullstackedsplinearea": { "alias": "fullstackedsplinearea"; "required": false; }; "highValueField": { "alias": "highValueField"; "required": false; }; "hoverMode": { "alias": "hoverMode"; "required": false; }; "hoverStyle": { "alias": "hoverStyle"; "required": false; }; "ignoreEmptyPoints": { "alias": "ignoreEmptyPoints"; "required": false; }; "innerColor": { "alias": "innerColor"; "required": false; }; "label": { "alias": "label"; "required": false; }; "line": { "alias": "line"; "required": false; }; "lowValueField": { "alias": "lowValueField"; "required": false; }; "maxLabelCount": { "alias": "maxLabelCount"; "required": false; }; "minBarSize": { "alias": "minBarSize"; "required": false; }; "opacity": { "alias": "opacity"; "required": false; }; "openValueField": { "alias": "openValueField"; "required": false; }; "pane": { "alias": "pane"; "required": false; }; "point": { "alias": "point"; "required": false; }; "rangearea": { "alias": "rangearea"; "required": false; }; "rangebar": { "alias": "rangebar"; "required": false; }; "rangeValue1Field": { "alias": "rangeValue1Field"; "required": false; }; "rangeValue2Field": { "alias": "rangeValue2Field"; "required": false; }; "reduction": { "alias": "reduction"; "required": false; }; "scatter": { "alias": "scatter"; "required": false; }; "selectionMode": { "alias": "selectionMode"; "required": false; }; "selectionStyle": { "alias": "selectionStyle"; "required": false; }; "showInLegend": { "alias": "showInLegend"; "required": false; }; "sizeField": { "alias": "sizeField"; "required": false; }; "spline": { "alias": "spline"; "required": false; }; "splinearea": { "alias": "splinearea"; "required": false; }; "stack": { "alias": "stack"; "required": false; }; "stackedarea": { "alias": "stackedarea"; "required": false; }; "stackedbar": { "alias": "stackedbar"; "required": false; }; "stackedline": { "alias": "stackedline"; "required": false; }; "stackedspline": { "alias": "stackedspline"; "required": false; }; "stackedsplinearea": { "alias": "stackedsplinearea"; "required": false; }; "steparea": { "alias": "steparea"; "required": false; }; "stepline": { "alias": "stepline"; "required": false; }; "stock": { "alias": "stock"; "required": false; }; "tagField": { "alias": "tagField"; "required": false; }; "type": { "alias": "type"; "required": false; }; "valueErrorBar": { "alias": "valueErrorBar"; "required": false; }; "valueField": { "alias": "valueField"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoFullstackedsplineareaModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoFullstackedsplineareaModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoFullstackedsplineareaModule, never, [typeof DxoFullstackedsplineareaComponent], [typeof DxoFullstackedsplineareaComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoFullstackedsplineareaModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoGeometryComponent extends NestedOption implements OnDestroy, OnInit {
    get endAngle(): number;
    set endAngle(value: number);
    get startAngle(): number;
    set startAngle(value: number);
    get orientation(): Orientation;
    set orientation(value: Orientation);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoGeometryComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoGeometryComponent, "dxo-geometry", never, { "endAngle": { "alias": "endAngle"; "required": false; }; "startAngle": { "alias": "startAngle"; "required": false; }; "orientation": { "alias": "orientation"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoGeometryModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoGeometryModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoGeometryModule, never, [typeof DxoGeometryComponent], [typeof DxoGeometryComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoGeometryModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoGridSizeComponent extends NestedOption implements OnDestroy, OnInit {
    get items(): Array<number>;
    set items(value: Array<number>);
    get value(): number;
    set value(value: number);
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    valueChange: EventEmitter<number>;
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoGridSizeComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoGridSizeComponent, "dxo-grid-size", never, { "items": { "alias": "items"; "required": false; }; "value": { "alias": "value"; "required": false; }; }, { "valueChange": "valueChange"; }, never, never, true, never>;
}
declare class DxoGridSizeModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoGridSizeModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoGridSizeModule, never, [typeof DxoGridSizeComponent], [typeof DxoGridSizeComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoGridSizeModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoGridComponent extends NestedOption implements OnDestroy, OnInit {
    get color(): string;
    set color(value: string);
    get opacity(): number | undefined;
    set opacity(value: number | undefined);
    get visible(): boolean;
    set visible(value: boolean);
    get width(): number;
    set width(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoGridComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoGridComponent, "dxo-grid", never, { "color": { "alias": "color"; "required": false; }; "opacity": { "alias": "opacity"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoGridModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoGridModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoGridModule, never, [typeof DxoGridComponent], [typeof DxoGridComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoGridModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxiGroupComponent extends CollectionNestedOption {
    set _commandsContentChildren(value: QueryList<CollectionNestedOption>);
    get commands(): Array<CustomCommand | Command>;
    set commands(value: Array<CustomCommand | Command>);
    get title(): string;
    set title(value: string);
    get category(): ShapeCategory | string;
    set category(value: ShapeCategory | string);
    get displayMode(): ToolboxDisplayMode;
    set displayMode(value: ToolboxDisplayMode);
    get expanded(): boolean;
    set expanded(value: boolean);
    get shapes(): Array<ShapeType | string>;
    set shapes(value: Array<ShapeType | string>);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiGroupComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiGroupComponent, "dxi-group", never, { "commands": { "alias": "commands"; "required": false; }; "title": { "alias": "title"; "required": false; }; "category": { "alias": "category"; "required": false; }; "displayMode": { "alias": "displayMode"; "required": false; }; "expanded": { "alias": "expanded"; "required": false; }; "shapes": { "alias": "shapes"; "required": false; }; }, {}, ["_commandsContentChildren"], never, true, never>;
}
declare class DxiGroupModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiGroupModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiGroupModule, never, [typeof DxiGroupComponent], [typeof DxiGroupComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiGroupModule>;
}

declare class DxiGroupItemComponent extends CollectionNestedOption {
    get alignByColumn(): boolean;
    set alignByColumn(value: boolean);
    get column(): string | undefined;
    set column(value: string | undefined);
    get customizeText(): Function;
    set customizeText(value: Function);
    get displayFormat(): string | undefined;
    set displayFormat(value: string | undefined);
    get name(): string | undefined;
    set name(value: string | undefined);
    get showInColumn(): string | undefined;
    set showInColumn(value: string | undefined);
    get showInGroupFooter(): boolean;
    set showInGroupFooter(value: boolean);
    get skipEmptyValues(): boolean;
    set skipEmptyValues(value: boolean);
    get summaryType(): SummaryType | string | undefined;
    set summaryType(value: SummaryType | string | undefined);
    get valueFormat(): Format | string | undefined;
    set valueFormat(value: Format | string | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiGroupItemComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiGroupItemComponent, "dxi-group-item", never, { "alignByColumn": { "alias": "alignByColumn"; "required": false; }; "column": { "alias": "column"; "required": false; }; "customizeText": { "alias": "customizeText"; "required": false; }; "displayFormat": { "alias": "displayFormat"; "required": false; }; "name": { "alias": "name"; "required": false; }; "showInColumn": { "alias": "showInColumn"; "required": false; }; "showInGroupFooter": { "alias": "showInGroupFooter"; "required": false; }; "skipEmptyValues": { "alias": "skipEmptyValues"; "required": false; }; "summaryType": { "alias": "summaryType"; "required": false; }; "valueFormat": { "alias": "valueFormat"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxiGroupItemModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiGroupItemModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiGroupItemModule, never, [typeof DxiGroupItemComponent], [typeof DxiGroupItemComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiGroupItemModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoGroupOperationDescriptionsComponent extends NestedOption implements OnDestroy, OnInit {
    get and(): string;
    set and(value: string);
    get notAnd(): string;
    set notAnd(value: string);
    get notOr(): string;
    set notOr(value: string);
    get or(): string;
    set or(value: string);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoGroupOperationDescriptionsComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoGroupOperationDescriptionsComponent, "dxo-group-operation-descriptions", never, { "and": { "alias": "and"; "required": false; }; "notAnd": { "alias": "notAnd"; "required": false; }; "notOr": { "alias": "notOr"; "required": false; }; "or": { "alias": "or"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoGroupOperationDescriptionsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoGroupOperationDescriptionsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoGroupOperationDescriptionsModule, never, [typeof DxoGroupOperationDescriptionsComponent], [typeof DxoGroupOperationDescriptionsComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoGroupOperationDescriptionsModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoGroupPanelComponent extends NestedOption implements OnDestroy, OnInit {
    get allowColumnDragging(): boolean;
    set allowColumnDragging(value: boolean);
    get emptyPanelText(): string;
    set emptyPanelText(value: string);
    get visible(): Mode | boolean;
    set visible(value: Mode | boolean);
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    visibleChange: EventEmitter<Mode | boolean>;
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoGroupPanelComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoGroupPanelComponent, "dxo-group-panel", never, { "allowColumnDragging": { "alias": "allowColumnDragging"; "required": false; }; "emptyPanelText": { "alias": "emptyPanelText"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; }, { "visibleChange": "visibleChange"; }, never, never, true, never>;
}
declare class DxoGroupPanelModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoGroupPanelModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoGroupPanelModule, never, [typeof DxoGroupPanelComponent], [typeof DxoGroupPanelComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoGroupPanelModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoGroupComponent extends NestedOption implements OnDestroy, OnInit {
    get border(): {
        color?: string | undefined;
        width?: number | undefined;
    };
    set border(value: {
        color?: string | undefined;
        width?: number | undefined;
    });
    get color(): string;
    set color(value: string);
    get headerHeight(): number | undefined;
    set headerHeight(value: number | undefined);
    get hoverEnabled(): boolean | undefined;
    set hoverEnabled(value: boolean | undefined);
    get hoverStyle(): {
        border?: {
            color?: string | undefined;
            width?: number | undefined;
        };
        color?: string | undefined;
    };
    set hoverStyle(value: {
        border?: {
            color?: string | undefined;
            width?: number | undefined;
        };
        color?: string | undefined;
    });
    get label(): {
        font?: Font;
        textOverflow?: TextOverflow;
        visible?: boolean;
    };
    set label(value: {
        font?: Font;
        textOverflow?: TextOverflow;
        visible?: boolean;
    });
    get padding(): number;
    set padding(value: number);
    get selectionStyle(): {
        border?: {
            color?: string | undefined;
            width?: number | undefined;
        };
        color?: string | undefined;
    };
    set selectionStyle(value: {
        border?: {
            color?: string | undefined;
            width?: number | undefined;
        };
        color?: string | undefined;
    });
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoGroupComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoGroupComponent, "dxo-group", never, { "border": { "alias": "border"; "required": false; }; "color": { "alias": "color"; "required": false; }; "headerHeight": { "alias": "headerHeight"; "required": false; }; "hoverEnabled": { "alias": "hoverEnabled"; "required": false; }; "hoverStyle": { "alias": "hoverStyle"; "required": false; }; "label": { "alias": "label"; "required": false; }; "padding": { "alias": "padding"; "required": false; }; "selectionStyle": { "alias": "selectionStyle"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoGroupModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoGroupModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoGroupModule, never, [typeof DxoGroupComponent], [typeof DxoGroupComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoGroupModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoGroupingComponent extends NestedOption implements OnDestroy, OnInit {
    get allowCollapsing(): boolean;
    set allowCollapsing(value: boolean);
    get autoExpandAll(): boolean;
    set autoExpandAll(value: boolean);
    get contextMenuEnabled(): boolean;
    set contextMenuEnabled(value: boolean);
    get expandMode(): GroupExpandMode;
    set expandMode(value: GroupExpandMode);
    get texts(): {
        groupByThisColumn?: string;
        groupContinuedMessage?: string;
        groupContinuesMessage?: string;
        ungroup?: string;
        ungroupAll?: string;
    };
    set texts(value: {
        groupByThisColumn?: string;
        groupContinuedMessage?: string;
        groupContinuesMessage?: string;
        ungroup?: string;
        ungroupAll?: string;
    });
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoGroupingComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoGroupingComponent, "dxo-grouping", never, { "allowCollapsing": { "alias": "allowCollapsing"; "required": false; }; "autoExpandAll": { "alias": "autoExpandAll"; "required": false; }; "contextMenuEnabled": { "alias": "contextMenuEnabled"; "required": false; }; "expandMode": { "alias": "expandMode"; "required": false; }; "texts": { "alias": "texts"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoGroupingModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoGroupingModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoGroupingModule, never, [typeof DxoGroupingComponent], [typeof DxoGroupingComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoGroupingModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoHatchingComponent extends NestedOption implements OnDestroy, OnInit {
    get direction(): HatchDirection;
    set direction(value: HatchDirection);
    get opacity(): number;
    set opacity(value: number);
    get step(): number;
    set step(value: number);
    get width(): number;
    set width(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoHatchingComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoHatchingComponent, "dxo-hatching", never, { "direction": { "alias": "direction"; "required": false; }; "opacity": { "alias": "opacity"; "required": false; }; "step": { "alias": "step"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoHatchingModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoHatchingModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoHatchingModule, never, [typeof DxoHatchingComponent], [typeof DxoHatchingComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoHatchingModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare abstract class DxoColumnHeaderFilter extends NestedOption {
    get allowSearch(): boolean;
    set allowSearch(value: boolean);
    get allowSelectAll(): boolean;
    set allowSelectAll(value: boolean);
    get dataSource(): Store | Options | Function | null | undefined | Array<any>;
    set dataSource(value: Store | Options | Function | null | undefined | Array<any>);
    get groupInterval(): HeaderFilterGroupInterval | number | undefined | Array<string | number>;
    set groupInterval(value: HeaderFilterGroupInterval | number | undefined | Array<string | number>);
    get height(): number | string | undefined;
    set height(value: number | string | undefined);
    get search(): ColumnHeaderFilterSearchConfig | HeaderFilterSearchConfig;
    set search(value: ColumnHeaderFilterSearchConfig | HeaderFilterSearchConfig);
    get searchMode(): SearchMode;
    set searchMode(value: SearchMode);
    get width(): number | string | undefined;
    set width(value: number | string | undefined);
    get searchTimeout(): number;
    set searchTimeout(value: number);
    get texts(): HeaderFilterTexts | dxGanttHeaderFilterTexts | {
        cancel?: string;
        emptyValue?: string;
        ok?: string;
    };
    set texts(value: HeaderFilterTexts | dxGanttHeaderFilterTexts | {
        cancel?: string;
        emptyValue?: string;
        ok?: string;
    });
    get visible(): boolean;
    set visible(value: boolean);
    get showRelevantValues(): boolean;
    set showRelevantValues(value: boolean);
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoColumnHeaderFilter, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoColumnHeaderFilter, "ng-component", never, {}, {}, never, never, true, never>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoHeaderFilterComponent extends DxoColumnHeaderFilter implements OnDestroy, OnInit {
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoHeaderFilterComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoHeaderFilterComponent, "dxo-header-filter", never, { "allowSearch": { "alias": "allowSearch"; "required": false; }; "allowSelectAll": { "alias": "allowSelectAll"; "required": false; }; "dataSource": { "alias": "dataSource"; "required": false; }; "groupInterval": { "alias": "groupInterval"; "required": false; }; "height": { "alias": "height"; "required": false; }; "search": { "alias": "search"; "required": false; }; "searchMode": { "alias": "searchMode"; "required": false; }; "width": { "alias": "width"; "required": false; }; "searchTimeout": { "alias": "searchTimeout"; "required": false; }; "texts": { "alias": "texts"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "showRelevantValues": { "alias": "showRelevantValues"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoHeaderFilterModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoHeaderFilterModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoHeaderFilterModule, never, [typeof DxoHeaderFilterComponent], [typeof DxoHeaderFilterComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoHeaderFilterModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoHeightComponent extends NestedOption implements OnDestroy, OnInit {
    get rangeMaxPoint(): number | undefined;
    set rangeMaxPoint(value: number | undefined);
    get rangeMinPoint(): number | undefined;
    set rangeMinPoint(value: number | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoHeightComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoHeightComponent, "dxo-height", never, { "rangeMaxPoint": { "alias": "rangeMaxPoint"; "required": false; }; "rangeMinPoint": { "alias": "rangeMinPoint"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoHeightModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoHeightModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoHeightModule, never, [typeof DxoHeightComponent], [typeof DxoHeightComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoHeightModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoHideEventComponent extends NestedOption implements OnDestroy, OnInit {
    get delay(): number | undefined;
    set delay(value: number | undefined);
    get name(): string | undefined;
    set name(value: string | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoHideEventComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoHideEventComponent, "dxo-hide-event", never, { "delay": { "alias": "delay"; "required": false; }; "name": { "alias": "name"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoHideEventModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoHideEventModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoHideEventModule, never, [typeof DxoHideEventComponent], [typeof DxoHideEventComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoHideEventModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare abstract class DxoAnimationConfig extends NestedOption {
    get complete(): Function;
    set complete(value: Function);
    get delay(): number;
    set delay(value: number);
    get direction(): Direction | undefined;
    set direction(value: Direction | undefined);
    get duration(): number;
    set duration(value: number);
    get easing(): string;
    set easing(value: string);
    get from(): AnimationState;
    set from(value: AnimationState);
    get staggerDelay(): number | undefined;
    set staggerDelay(value: number | undefined);
    get start(): Function;
    set start(value: Function);
    get to(): AnimationState;
    set to(value: AnimationState);
    get type(): AnimationType;
    set type(value: AnimationType);
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoAnimationConfig, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoAnimationConfig, "ng-component", never, {}, {}, never, never, true, never>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoHideComponent extends DxoAnimationConfig implements OnDestroy, OnInit {
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoHideComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoHideComponent, "dxo-hide", never, { "complete": { "alias": "complete"; "required": false; }; "delay": { "alias": "delay"; "required": false; }; "direction": { "alias": "direction"; "required": false; }; "duration": { "alias": "duration"; "required": false; }; "easing": { "alias": "easing"; "required": false; }; "from": { "alias": "from"; "required": false; }; "staggerDelay": { "alias": "staggerDelay"; "required": false; }; "start": { "alias": "start"; "required": false; }; "to": { "alias": "to"; "required": false; }; "type": { "alias": "type"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoHideModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoHideModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoHideModule, never, [typeof DxoHideComponent], [typeof DxoHideComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoHideModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoHistoryToolbarComponent extends NestedOption implements OnDestroy, OnInit {
    set _commandsContentChildren(value: QueryList<CollectionNestedOption>);
    get commands(): Array<CustomCommand | Command>;
    set commands(value: Array<CustomCommand | Command>);
    get visible(): boolean;
    set visible(value: boolean);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoHistoryToolbarComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoHistoryToolbarComponent, "dxo-history-toolbar", never, { "commands": { "alias": "commands"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; }, {}, ["_commandsContentChildren"], never, true, never>;
}
declare class DxoHistoryToolbarModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoHistoryToolbarModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoHistoryToolbarModule, never, [typeof DxoHistoryToolbarComponent], [typeof DxoHistoryToolbarComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoHistoryToolbarModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoHorizontalLineComponent extends NestedOption implements OnDestroy, OnInit {
    get color(): string;
    set color(value: string);
    get dashStyle(): DashStyle;
    set dashStyle(value: DashStyle);
    get label(): {
        backgroundColor?: string;
        customizeText?: Function;
        font?: Font;
        format?: Format | string | undefined;
        visible?: boolean;
    };
    set label(value: {
        backgroundColor?: string;
        customizeText?: Function;
        font?: Font;
        format?: Format | string | undefined;
        visible?: boolean;
    });
    get opacity(): number | undefined;
    set opacity(value: number | undefined);
    get visible(): boolean;
    set visible(value: boolean);
    get width(): number;
    set width(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoHorizontalLineComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoHorizontalLineComponent, "dxo-horizontal-line", never, { "color": { "alias": "color"; "required": false; }; "dashStyle": { "alias": "dashStyle"; "required": false; }; "label": { "alias": "label"; "required": false; }; "opacity": { "alias": "opacity"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoHorizontalLineModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoHorizontalLineModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoHorizontalLineModule, never, [typeof DxoHorizontalLineComponent], [typeof DxoHorizontalLineComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoHorizontalLineModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoHoverStyleComponent extends NestedOption implements OnDestroy, OnInit {
    get border(): {
        color?: string | undefined;
        dashStyle?: DashStyle | undefined;
        visible?: boolean;
        width?: number;
    } | {
        color?: string | undefined;
        visible?: boolean;
        width?: number;
    } | {
        color?: string | undefined;
        visible?: boolean | undefined;
        width?: number | undefined;
    } | {
        color?: string | undefined;
        width?: number | undefined;
    };
    set border(value: {
        color?: string | undefined;
        dashStyle?: DashStyle | undefined;
        visible?: boolean;
        width?: number;
    } | {
        color?: string | undefined;
        visible?: boolean;
        width?: number;
    } | {
        color?: string | undefined;
        visible?: boolean | undefined;
        width?: number | undefined;
    } | {
        color?: string | undefined;
        width?: number | undefined;
    });
    get color(): ChartsColor | string | undefined;
    set color(value: ChartsColor | string | undefined);
    get dashStyle(): DashStyle;
    set dashStyle(value: DashStyle);
    get hatching(): {
        direction?: HatchDirection;
        opacity?: number;
        step?: number;
        width?: number;
    };
    set hatching(value: {
        direction?: HatchDirection;
        opacity?: number;
        step?: number;
        width?: number;
    });
    get highlight(): boolean;
    set highlight(value: boolean);
    get width(): number;
    set width(value: number);
    get size(): number | undefined;
    set size(value: number | undefined);
    get opacity(): number | undefined;
    set opacity(value: number | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoHoverStyleComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoHoverStyleComponent, "dxo-hover-style", never, { "border": { "alias": "border"; "required": false; }; "color": { "alias": "color"; "required": false; }; "dashStyle": { "alias": "dashStyle"; "required": false; }; "hatching": { "alias": "hatching"; "required": false; }; "highlight": { "alias": "highlight"; "required": false; }; "width": { "alias": "width"; "required": false; }; "size": { "alias": "size"; "required": false; }; "opacity": { "alias": "opacity"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoHoverStyleModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoHoverStyleModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoHoverStyleModule, never, [typeof DxoHoverStyleComponent], [typeof DxoHoverStyleComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoHoverStyleModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoIconsComponent extends NestedOption implements OnDestroy, OnInit {
    get fix(): string;
    set fix(value: string);
    get leftPosition(): string;
    set leftPosition(value: string);
    get rightPosition(): string;
    set rightPosition(value: string);
    get stickyPosition(): string;
    set stickyPosition(value: string);
    get unfix(): string;
    set unfix(value: string);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoIconsComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoIconsComponent, "dxo-icons", never, { "fix": { "alias": "fix"; "required": false; }; "leftPosition": { "alias": "leftPosition"; "required": false; }; "rightPosition": { "alias": "rightPosition"; "required": false; }; "stickyPosition": { "alias": "stickyPosition"; "required": false; }; "unfix": { "alias": "unfix"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoIconsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoIconsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoIconsModule, never, [typeof DxoIconsComponent], [typeof DxoIconsComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoIconsModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare abstract class DxoHtmlEditorImageUpload extends NestedOption {
    get fileUploaderOptions(): dxFileUploaderOptions;
    set fileUploaderOptions(value: dxFileUploaderOptions);
    get fileUploadMode(): HtmlEditorImageUploadMode;
    set fileUploadMode(value: HtmlEditorImageUploadMode);
    get tabs(): Array<dxHtmlEditorImageUploadTabItem | HtmlEditorImageUploadTab>;
    set tabs(value: Array<dxHtmlEditorImageUploadTabItem | HtmlEditorImageUploadTab>);
    get uploadDirectory(): string | undefined;
    set uploadDirectory(value: string | undefined);
    get uploadUrl(): string | undefined;
    set uploadUrl(value: string | undefined);
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoHtmlEditorImageUpload, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoHtmlEditorImageUpload, "ng-component", never, {}, {}, never, never, true, never>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoImageUploadComponent extends DxoHtmlEditorImageUpload implements OnDestroy, OnInit {
    set _tabsContentChildren(value: QueryList<CollectionNestedOption>);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoImageUploadComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoImageUploadComponent, "dxo-image-upload", never, { "fileUploaderOptions": { "alias": "fileUploaderOptions"; "required": false; }; "fileUploadMode": { "alias": "fileUploadMode"; "required": false; }; "tabs": { "alias": "tabs"; "required": false; }; "uploadDirectory": { "alias": "uploadDirectory"; "required": false; }; "uploadUrl": { "alias": "uploadUrl"; "required": false; }; }, {}, ["_tabsContentChildren"], never, true, never>;
}
declare class DxoImageUploadModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoImageUploadModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoImageUploadModule, never, [typeof DxoImageUploadComponent], [typeof DxoImageUploadComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoImageUploadModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoImageComponent extends NestedOption implements OnDestroy, OnInit {
    get height(): number | {
        rangeMaxPoint?: number | undefined;
        rangeMinPoint?: number | undefined;
    };
    set height(value: number | {
        rangeMaxPoint?: number | undefined;
        rangeMinPoint?: number | undefined;
    });
    get url(): string | undefined | {
        rangeMaxPoint?: string | undefined;
        rangeMinPoint?: string | undefined;
    };
    set url(value: string | undefined | {
        rangeMaxPoint?: string | undefined;
        rangeMinPoint?: string | undefined;
    });
    get width(): number | {
        rangeMaxPoint?: number | undefined;
        rangeMinPoint?: number | undefined;
    };
    set width(value: number | {
        rangeMaxPoint?: number | undefined;
        rangeMinPoint?: number | undefined;
    });
    get location(): BackgroundImageLocation;
    set location(value: BackgroundImageLocation);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoImageComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoImageComponent, "dxo-image", never, { "height": { "alias": "height"; "required": false; }; "url": { "alias": "url"; "required": false; }; "width": { "alias": "width"; "required": false; }; "location": { "alias": "location"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoImageModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoImageModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoImageModule, never, [typeof DxoImageComponent], [typeof DxoImageComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoImageModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoIndentComponent extends NestedOption implements OnDestroy, OnInit {
    get left(): number | undefined;
    set left(value: number | undefined);
    get right(): number | undefined;
    set right(value: number | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoIndentComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoIndentComponent, "dxo-indent", never, { "left": { "alias": "left"; "required": false; }; "right": { "alias": "right"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoIndentModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoIndentModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoIndentModule, never, [typeof DxoIndentComponent], [typeof DxoIndentComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoIndentModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare abstract class DxoSortableOptions extends NestedOption {
    get allowDropInsideItem(): boolean;
    set allowDropInsideItem(value: boolean);
    get allowReordering(): boolean;
    set allowReordering(value: boolean);
    get autoScroll(): boolean;
    set autoScroll(value: boolean);
    get boundary(): UserDefinedElement | string | undefined;
    set boundary(value: UserDefinedElement | string | undefined);
    get container(): UserDefinedElement | string | undefined;
    set container(value: UserDefinedElement | string | undefined);
    get cursorOffset(): string | {
        x?: number;
        y?: number;
    };
    set cursorOffset(value: string | {
        x?: number;
        y?: number;
    });
    get data(): any | undefined;
    set data(value: any | undefined);
    get dragDirection(): DragDirection;
    set dragDirection(value: DragDirection);
    get dragTemplate(): any | undefined;
    set dragTemplate(value: any | undefined);
    get dropFeedbackMode(): DragHighlight;
    set dropFeedbackMode(value: DragHighlight);
    get elementAttr(): any;
    set elementAttr(value: any);
    get filter(): string;
    set filter(value: string);
    get group(): string | undefined;
    set group(value: string | undefined);
    get handle(): string;
    set handle(value: string);
    get height(): number | string | undefined;
    set height(value: number | string | undefined);
    get itemOrientation(): Orientation;
    set itemOrientation(value: Orientation);
    get moveItemOnDrop(): boolean;
    set moveItemOnDrop(value: boolean);
    get onAdd(): ((e: AddEvent) => void);
    set onAdd(value: ((e: AddEvent) => void));
    get onDisposing(): ((e: DisposingEvent$6) => void);
    set onDisposing(value: ((e: DisposingEvent$6) => void));
    get onDragChange(): ((e: DragChangeEvent) => void);
    set onDragChange(value: ((e: DragChangeEvent) => void));
    get onDragEnd(): ((e: DragEndEvent) => void);
    set onDragEnd(value: ((e: DragEndEvent) => void));
    get onDragMove(): ((e: DragMoveEvent) => void);
    set onDragMove(value: ((e: DragMoveEvent) => void));
    get onDragStart(): ((e: DragStartEvent) => void);
    set onDragStart(value: ((e: DragStartEvent) => void));
    get onInitialized(): ((e: InitializedEvent$6) => void);
    set onInitialized(value: ((e: InitializedEvent$6) => void));
    get onOptionChanged(): ((e: OptionChangedEvent$6) => void);
    set onOptionChanged(value: ((e: OptionChangedEvent$6) => void));
    get onRemove(): ((e: RemoveEvent) => void);
    set onRemove(value: ((e: RemoveEvent) => void));
    get onReorder(): ((e: ReorderEvent) => void);
    set onReorder(value: ((e: ReorderEvent) => void));
    get rtlEnabled(): boolean;
    set rtlEnabled(value: boolean);
    get scrollSensitivity(): number;
    set scrollSensitivity(value: number);
    get scrollSpeed(): number;
    set scrollSpeed(value: number);
    get width(): number | string | undefined;
    set width(value: number | string | undefined);
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoSortableOptions, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoSortableOptions, "ng-component", never, {}, {}, never, never, true, never>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoItemDraggingComponent extends DxoSortableOptions implements OnDestroy, OnInit {
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoItemDraggingComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoItemDraggingComponent, "dxo-item-dragging", never, { "allowDropInsideItem": { "alias": "allowDropInsideItem"; "required": false; }; "allowReordering": { "alias": "allowReordering"; "required": false; }; "autoScroll": { "alias": "autoScroll"; "required": false; }; "boundary": { "alias": "boundary"; "required": false; }; "container": { "alias": "container"; "required": false; }; "cursorOffset": { "alias": "cursorOffset"; "required": false; }; "data": { "alias": "data"; "required": false; }; "dragDirection": { "alias": "dragDirection"; "required": false; }; "dragTemplate": { "alias": "dragTemplate"; "required": false; }; "dropFeedbackMode": { "alias": "dropFeedbackMode"; "required": false; }; "elementAttr": { "alias": "elementAttr"; "required": false; }; "filter": { "alias": "filter"; "required": false; }; "group": { "alias": "group"; "required": false; }; "handle": { "alias": "handle"; "required": false; }; "height": { "alias": "height"; "required": false; }; "itemOrientation": { "alias": "itemOrientation"; "required": false; }; "moveItemOnDrop": { "alias": "moveItemOnDrop"; "required": false; }; "onAdd": { "alias": "onAdd"; "required": false; }; "onDisposing": { "alias": "onDisposing"; "required": false; }; "onDragChange": { "alias": "onDragChange"; "required": false; }; "onDragEnd": { "alias": "onDragEnd"; "required": false; }; "onDragMove": { "alias": "onDragMove"; "required": false; }; "onDragStart": { "alias": "onDragStart"; "required": false; }; "onInitialized": { "alias": "onInitialized"; "required": false; }; "onOptionChanged": { "alias": "onOptionChanged"; "required": false; }; "onRemove": { "alias": "onRemove"; "required": false; }; "onReorder": { "alias": "onReorder"; "required": false; }; "rtlEnabled": { "alias": "rtlEnabled"; "required": false; }; "scrollSensitivity": { "alias": "scrollSensitivity"; "required": false; }; "scrollSpeed": { "alias": "scrollSpeed"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoItemDraggingModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoItemDraggingModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoItemDraggingModule, never, [typeof DxoItemDraggingComponent], [typeof DxoItemDraggingComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoItemDraggingModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare abstract class DxiButtonGroupItem extends CollectionNestedOption {
    get disabled(): boolean;
    set disabled(value: boolean);
    get html(): string;
    set html(value: string);
    get icon(): string;
    set icon(value: string);
    get template(): any;
    set template(value: any);
    get text(): string;
    set text(value: string);
    get title(): string;
    set title(value: string);
    get titleTemplate(): any;
    set titleTemplate(value: any);
    get visible(): boolean | undefined;
    set visible(value: boolean | undefined);
    get onClick(): Function;
    set onClick(value: Function);
    get stylingMode(): ButtonStyle;
    set stylingMode(value: ButtonStyle);
    get type(): ButtonType | string;
    set type(value: ButtonType | string);
    get baseSize(): number | string;
    set baseSize(value: number | string);
    get box(): Properties | undefined;
    set box(value: Properties | undefined);
    get ratio(): number;
    set ratio(value: number);
    get shrink(): number;
    set shrink(value: number);
    get elementAttr(): any;
    set elementAttr(value: any);
    get hint(): string;
    set hint(value: string);
    get alt(): string;
    set alt(value: string);
    get author(): User;
    set author(value: User);
    get id(): number | string | undefined;
    set id(value: number | string | undefined);
    get isDeleted(): boolean;
    set isDeleted(value: boolean);
    get isEdited(): boolean;
    set isEdited(value: boolean);
    get src(): string;
    set src(value: string);
    get timestamp(): Date | number | string;
    set timestamp(value: Date | number | string);
    get beginGroup(): boolean;
    set beginGroup(value: boolean);
    get closeMenuOnClick(): boolean;
    set closeMenuOnClick(value: boolean);
    get items(): Array<dxContextMenuItem | SimpleItem | GroupItem | TabbedItem | EmptyItem | ButtonItem | CustomCommand | Command | dxFileManagerContextMenuItem | HtmlEditorPredefinedContextMenuItem | any | dxMenuItem | dxTreeViewItem>;
    set items(value: Array<dxContextMenuItem | SimpleItem | GroupItem | TabbedItem | EmptyItem | ButtonItem | CustomCommand | Command | dxFileManagerContextMenuItem | HtmlEditorPredefinedContextMenuItem | any | dxMenuItem | dxTreeViewItem>);
    get selectable(): boolean;
    set selectable(value: boolean);
    get selected(): boolean;
    set selected(value: boolean);
    get colSpan(): number | undefined;
    set colSpan(value: number | undefined);
    get cssClass(): string | undefined;
    set cssClass(value: string | undefined);
    get dataField(): string | undefined;
    set dataField(value: string | undefined);
    get editorOptions(): any | undefined;
    set editorOptions(value: any | undefined);
    get editorType(): FormItemComponent;
    set editorType(value: FormItemComponent);
    get helpText(): string | undefined;
    set helpText(value: string | undefined);
    get isRequired(): boolean | undefined;
    set isRequired(value: boolean | undefined);
    get itemType(): FormItemType;
    set itemType(value: FormItemType);
    get label(): {
        alignment?: HorizontalAlignment;
        location?: LabelLocation;
        showColon?: boolean;
        template?: any;
        text?: string | undefined;
        visible?: boolean;
    };
    set label(value: {
        alignment?: HorizontalAlignment;
        location?: LabelLocation;
        showColon?: boolean;
        template?: any;
        text?: string | undefined;
        visible?: boolean;
    });
    get name(): string | undefined | DataGridPredefinedToolbarItem | Command | FileManagerPredefinedContextMenuItem | FileManagerPredefinedToolbarItem | GanttPredefinedContextMenuItem | GanttPredefinedToolbarItem | HtmlEditorPredefinedContextMenuItem | HtmlEditorPredefinedToolbarItem | TreeListPredefinedToolbarItem;
    set name(value: string | undefined | DataGridPredefinedToolbarItem | Command | FileManagerPredefinedContextMenuItem | FileManagerPredefinedToolbarItem | GanttPredefinedContextMenuItem | GanttPredefinedToolbarItem | HtmlEditorPredefinedContextMenuItem | HtmlEditorPredefinedToolbarItem | TreeListPredefinedToolbarItem);
    get validationRules(): Array<RequiredRule | NumericRule | RangeRule | StringLengthRule | CustomRule | CompareRule | PatternRule | EmailRule | AsyncRule>;
    set validationRules(value: Array<RequiredRule | NumericRule | RangeRule | StringLengthRule | CustomRule | CompareRule | PatternRule | EmailRule | AsyncRule>);
    get visibleIndex(): number | undefined;
    set visibleIndex(value: number | undefined);
    get alignItemLabels(): boolean;
    set alignItemLabels(value: boolean);
    get caption(): string | undefined;
    set caption(value: string | undefined);
    get captionTemplate(): any;
    set captionTemplate(value: any);
    get colCount(): number;
    set colCount(value: number);
    get colCountByScreen(): {
        lg?: number | undefined;
        md?: number | undefined;
        sm?: number | undefined;
        xs?: number | undefined;
    };
    set colCountByScreen(value: {
        lg?: number | undefined;
        md?: number | undefined;
        sm?: number | undefined;
        xs?: number | undefined;
    });
    get tabPanelOptions(): Properties$4 | undefined;
    set tabPanelOptions(value: Properties$4 | undefined);
    get tabs(): Array<any | {
        alignItemLabels?: boolean;
        badge?: string | undefined;
        colCount?: number;
        colCountByScreen?: {
            lg?: number | undefined;
            md?: number | undefined;
            sm?: number | undefined;
            xs?: number | undefined;
        };
        disabled?: boolean;
        icon?: string | undefined;
        items?: Array<SimpleItem | GroupItem | TabbedItem | EmptyItem | ButtonItem>;
        tabTemplate?: any | undefined;
        template?: any | undefined;
        title?: string | undefined;
    }>;
    set tabs(value: Array<any | {
        alignItemLabels?: boolean;
        badge?: string | undefined;
        colCount?: number;
        colCountByScreen?: {
            lg?: number | undefined;
            md?: number | undefined;
            sm?: number | undefined;
            xs?: number | undefined;
        };
        disabled?: boolean;
        icon?: string | undefined;
        items?: Array<SimpleItem | GroupItem | TabbedItem | EmptyItem | ButtonItem>;
        tabTemplate?: any | undefined;
        template?: any | undefined;
        title?: string | undefined;
    }>);
    get badge(): string;
    set badge(value: string);
    get tabTemplate(): any;
    set tabTemplate(value: any);
    get buttonOptions(): Properties$1 | undefined;
    set buttonOptions(value: Properties$1 | undefined);
    get horizontalAlignment(): HorizontalAlignment;
    set horizontalAlignment(value: HorizontalAlignment);
    get verticalAlignment(): VerticalAlignment;
    set verticalAlignment(value: VerticalAlignment);
    get locateInMenu(): LocateInMenuMode;
    set locateInMenu(value: LocateInMenuMode);
    get location(): ToolbarItemLocation | Array<any | {
        col?: number;
        colspan?: number | undefined;
        row?: number;
        rowspan?: number | undefined;
        screen?: string | undefined;
    }>;
    set location(value: ToolbarItemLocation | Array<any | {
        col?: number;
        colspan?: number | undefined;
        row?: number;
        rowspan?: number | undefined;
        screen?: string | undefined;
    }>);
    get menuItemTemplate(): any;
    set menuItemTemplate(value: any);
    get options(): any;
    set options(value: any);
    get showText(): ShowTextMode;
    set showText(value: ShowTextMode);
    get widget(): ToolbarItemComponent;
    set widget(value: ToolbarItemComponent);
    get height(): number;
    set height(value: number);
    get width(): number;
    set width(value: number);
    get imageAlt(): string;
    set imageAlt(value: string);
    get imageSrc(): string;
    set imageSrc(value: string);
    get acceptedValues(): Array<string | number | boolean>;
    set acceptedValues(value: Array<string | number | boolean>);
    get commands(): Array<AICommandName | AICommand>;
    set commands(value: Array<AICommandName | AICommand>);
    get key(): string;
    set key(value: string);
    get showChevron(): boolean;
    set showChevron(value: boolean);
    get linkAttr(): any;
    set linkAttr(value: any);
    get url(): string;
    set url(value: string);
    get collapsed(): boolean;
    set collapsed(value: boolean);
    get collapsedSize(): number | string | undefined;
    set collapsedSize(value: number | string | undefined);
    get collapsible(): boolean;
    set collapsible(value: boolean);
    get maxSize(): number | string | undefined;
    set maxSize(value: number | string | undefined);
    get minSize(): number | string | undefined;
    set minSize(value: number | string | undefined);
    get resizable(): boolean;
    set resizable(value: boolean);
    get size(): number | string | undefined;
    set size(value: number | string | undefined);
    get splitter(): Properties$5 | undefined;
    set splitter(value: Properties$5 | undefined);
    get heightRatio(): number;
    set heightRatio(value: number);
    get widthRatio(): number;
    set widthRatio(value: number);
    get expanded(): boolean;
    set expanded(value: boolean);
    get hasItems(): boolean | undefined;
    set hasItems(value: boolean | undefined);
    get parentId(): number | string | undefined;
    set parentId(value: number | string | undefined);
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiButtonGroupItem, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiButtonGroupItem, "ng-component", never, {}, {}, never, never, true, never>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxiItemComponent extends DxiButtonGroupItem implements AfterViewInit, IDxTemplateHost {
    private renderer;
    private document;
    private element;
    set _itemsContentChildren(value: QueryList<CollectionNestedOption>);
    set _validationRulesContentChildren(value: QueryList<CollectionNestedOption>);
    set _tabsContentChildren(value: QueryList<CollectionNestedOption>);
    set _commandsContentChildren(value: QueryList<CollectionNestedOption>);
    set _locationContentChildren(value: QueryList<CollectionNestedOption>);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost, renderer: Renderer2, document: any, templateHost: DxTemplateHost, element: ElementRef);
    setTemplate(template: DxTemplateDirective): void;
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiItemComponent, [{ host: true; skipSelf: true; }, { host: true; }, null, null, { host: true; }, null]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiItemComponent, "dxi-item", never, { "disabled": { "alias": "disabled"; "required": false; }; "html": { "alias": "html"; "required": false; }; "icon": { "alias": "icon"; "required": false; }; "template": { "alias": "template"; "required": false; }; "text": { "alias": "text"; "required": false; }; "title": { "alias": "title"; "required": false; }; "titleTemplate": { "alias": "titleTemplate"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "onClick": { "alias": "onClick"; "required": false; }; "stylingMode": { "alias": "stylingMode"; "required": false; }; "type": { "alias": "type"; "required": false; }; "baseSize": { "alias": "baseSize"; "required": false; }; "box": { "alias": "box"; "required": false; }; "ratio": { "alias": "ratio"; "required": false; }; "shrink": { "alias": "shrink"; "required": false; }; "elementAttr": { "alias": "elementAttr"; "required": false; }; "hint": { "alias": "hint"; "required": false; }; "alt": { "alias": "alt"; "required": false; }; "author": { "alias": "author"; "required": false; }; "id": { "alias": "id"; "required": false; }; "isDeleted": { "alias": "isDeleted"; "required": false; }; "isEdited": { "alias": "isEdited"; "required": false; }; "src": { "alias": "src"; "required": false; }; "timestamp": { "alias": "timestamp"; "required": false; }; "beginGroup": { "alias": "beginGroup"; "required": false; }; "closeMenuOnClick": { "alias": "closeMenuOnClick"; "required": false; }; "items": { "alias": "items"; "required": false; }; "selectable": { "alias": "selectable"; "required": false; }; "selected": { "alias": "selected"; "required": false; }; "colSpan": { "alias": "colSpan"; "required": false; }; "cssClass": { "alias": "cssClass"; "required": false; }; "dataField": { "alias": "dataField"; "required": false; }; "editorOptions": { "alias": "editorOptions"; "required": false; }; "editorType": { "alias": "editorType"; "required": false; }; "helpText": { "alias": "helpText"; "required": false; }; "isRequired": { "alias": "isRequired"; "required": false; }; "itemType": { "alias": "itemType"; "required": false; }; "label": { "alias": "label"; "required": false; }; "name": { "alias": "name"; "required": false; }; "validationRules": { "alias": "validationRules"; "required": false; }; "visibleIndex": { "alias": "visibleIndex"; "required": false; }; "alignItemLabels": { "alias": "alignItemLabels"; "required": false; }; "caption": { "alias": "caption"; "required": false; }; "captionTemplate": { "alias": "captionTemplate"; "required": false; }; "colCount": { "alias": "colCount"; "required": false; }; "colCountByScreen": { "alias": "colCountByScreen"; "required": false; }; "tabPanelOptions": { "alias": "tabPanelOptions"; "required": false; }; "tabs": { "alias": "tabs"; "required": false; }; "badge": { "alias": "badge"; "required": false; }; "tabTemplate": { "alias": "tabTemplate"; "required": false; }; "buttonOptions": { "alias": "buttonOptions"; "required": false; }; "horizontalAlignment": { "alias": "horizontalAlignment"; "required": false; }; "verticalAlignment": { "alias": "verticalAlignment"; "required": false; }; "locateInMenu": { "alias": "locateInMenu"; "required": false; }; "location": { "alias": "location"; "required": false; }; "menuItemTemplate": { "alias": "menuItemTemplate"; "required": false; }; "options": { "alias": "options"; "required": false; }; "showText": { "alias": "showText"; "required": false; }; "widget": { "alias": "widget"; "required": false; }; "height": { "alias": "height"; "required": false; }; "width": { "alias": "width"; "required": false; }; "imageAlt": { "alias": "imageAlt"; "required": false; }; "imageSrc": { "alias": "imageSrc"; "required": false; }; "acceptedValues": { "alias": "acceptedValues"; "required": false; }; "commands": { "alias": "commands"; "required": false; }; "key": { "alias": "key"; "required": false; }; "showChevron": { "alias": "showChevron"; "required": false; }; "linkAttr": { "alias": "linkAttr"; "required": false; }; "url": { "alias": "url"; "required": false; }; "collapsed": { "alias": "collapsed"; "required": false; }; "collapsedSize": { "alias": "collapsedSize"; "required": false; }; "collapsible": { "alias": "collapsible"; "required": false; }; "maxSize": { "alias": "maxSize"; "required": false; }; "minSize": { "alias": "minSize"; "required": false; }; "resizable": { "alias": "resizable"; "required": false; }; "size": { "alias": "size"; "required": false; }; "splitter": { "alias": "splitter"; "required": false; }; "heightRatio": { "alias": "heightRatio"; "required": false; }; "widthRatio": { "alias": "widthRatio"; "required": false; }; "expanded": { "alias": "expanded"; "required": false; }; "hasItems": { "alias": "hasItems"; "required": false; }; "parentId": { "alias": "parentId"; "required": false; }; }, {}, ["_itemsContentChildren", "_validationRulesContentChildren", "_tabsContentChildren", "_commandsContentChildren", "_locationContentChildren"], ["*"], true, never>;
}
declare class DxiItemModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiItemModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiItemModule, never, [typeof DxiItemComponent], [typeof DxiItemComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiItemModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoItemTextFormatComponent extends DxoFormat implements OnDestroy, OnInit {
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoItemTextFormatComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoItemTextFormatComponent, "dxo-item-text-format", never, { "currency": { "alias": "currency"; "required": false; }; "formatter": { "alias": "formatter"; "required": false; }; "parser": { "alias": "parser"; "required": false; }; "precision": { "alias": "precision"; "required": false; }; "type": { "alias": "type"; "required": false; }; "useCurrencyAccountingStyle": { "alias": "useCurrencyAccountingStyle"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoItemTextFormatModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoItemTextFormatModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoItemTextFormatModule, never, [typeof DxoItemTextFormatComponent], [typeof DxoItemTextFormatComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoItemTextFormatModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoItemViewComponent extends NestedOption implements OnDestroy, OnInit {
    get details(): {
        columns?: Array<dxFileManagerDetailsColumn | string>;
    };
    set details(value: {
        columns?: Array<dxFileManagerDetailsColumn | string>;
    });
    get mode(): FileManagerItemViewMode;
    set mode(value: FileManagerItemViewMode);
    get showFolders(): boolean;
    set showFolders(value: boolean);
    get showParentFolder(): boolean;
    set showParentFolder(value: boolean);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoItemViewComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoItemViewComponent, "dxo-item-view", never, { "details": { "alias": "details"; "required": false; }; "mode": { "alias": "mode"; "required": false; }; "showFolders": { "alias": "showFolders"; "required": false; }; "showParentFolder": { "alias": "showParentFolder"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoItemViewModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoItemViewModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoItemViewModule, never, [typeof DxoItemViewComponent], [typeof DxoItemViewComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoItemViewModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoItemComponent extends NestedOption implements OnDestroy, OnInit {
    get border(): {
        color?: string | undefined;
        visible?: boolean | undefined;
        width?: number | undefined;
    };
    set border(value: {
        color?: string | undefined;
        visible?: boolean | undefined;
        width?: number | undefined;
    });
    get hoverStyle(): {
        border?: {
            color?: string | undefined;
            visible?: boolean | undefined;
            width?: number | undefined;
        };
        hatching?: {
            direction?: HatchDirection;
            opacity?: number;
            step?: number;
            width?: number;
        };
    };
    set hoverStyle(value: {
        border?: {
            color?: string | undefined;
            visible?: boolean | undefined;
            width?: number | undefined;
        };
        hatching?: {
            direction?: HatchDirection;
            opacity?: number;
            step?: number;
            width?: number;
        };
    });
    get selectionStyle(): {
        border?: {
            color?: string | undefined;
            visible?: boolean | undefined;
            width?: number | undefined;
        };
        hatching?: {
            direction?: HatchDirection;
            opacity?: number;
            step?: number;
            width?: number;
        };
    };
    set selectionStyle(value: {
        border?: {
            color?: string | undefined;
            visible?: boolean | undefined;
            width?: number | undefined;
        };
        hatching?: {
            direction?: HatchDirection;
            opacity?: number;
            step?: number;
            width?: number;
        };
    });
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoItemComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoItemComponent, "dxo-item", never, { "border": { "alias": "border"; "required": false; }; "hoverStyle": { "alias": "hoverStyle"; "required": false; }; "selectionStyle": { "alias": "selectionStyle"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoItemModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoItemModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoItemModule, never, [typeof DxoItemComponent], [typeof DxoItemComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoItemModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoKeyboardNavigationComponent extends NestedOption implements OnDestroy, OnInit {
    get editOnKeyPress(): boolean;
    set editOnKeyPress(value: boolean);
    get enabled(): boolean;
    set enabled(value: boolean);
    get enterKeyAction(): EnterKeyAction;
    set enterKeyAction(value: EnterKeyAction);
    get enterKeyDirection(): EnterKeyDirection;
    set enterKeyDirection(value: EnterKeyDirection);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoKeyboardNavigationComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoKeyboardNavigationComponent, "dxo-keyboard-navigation", never, { "editOnKeyPress": { "alias": "editOnKeyPress"; "required": false; }; "enabled": { "alias": "enabled"; "required": false; }; "enterKeyAction": { "alias": "enterKeyAction"; "required": false; }; "enterKeyDirection": { "alias": "enterKeyDirection"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoKeyboardNavigationModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoKeyboardNavigationModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoKeyboardNavigationModule, never, [typeof DxoKeyboardNavigationComponent], [typeof DxoKeyboardNavigationComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoKeyboardNavigationModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoLabelComponent extends NestedOption implements AfterViewInit, OnDestroy, OnInit, IDxTemplateHost {
    private renderer;
    private document;
    private element;
    get connectorColor(): string | undefined;
    set connectorColor(value: string | undefined);
    get connectorWidth(): number;
    set connectorWidth(value: number);
    get customizeText(): Function;
    set customizeText(value: Function);
    get font(): Font;
    set font(value: Font);
    get format(): Format | string | undefined;
    set format(value: Format | string | undefined);
    get indent(): number;
    set indent(value: number);
    get visible(): boolean;
    set visible(value: boolean);
    get horizontalAlignment(): HorizontalAlignment | HorizontalEdge;
    set horizontalAlignment(value: HorizontalAlignment | HorizontalEdge);
    get position(): RelativePosition | Position | LabelPosition | VerticalEdge;
    set position(value: RelativePosition | Position | LabelPosition | VerticalEdge);
    get text(): string | undefined;
    set text(value: string | undefined);
    get verticalAlignment(): VerticalAlignment;
    set verticalAlignment(value: VerticalAlignment);
    get alignment(): HorizontalAlignment | undefined;
    set alignment(value: HorizontalAlignment | undefined);
    get customizeHint(): Function;
    set customizeHint(value: Function);
    get displayMode(): ChartLabelDisplayMode;
    set displayMode(value: ChartLabelDisplayMode);
    get indentFromAxis(): number;
    set indentFromAxis(value: number);
    get overlappingBehavior(): ChartsAxisLabelOverlap | LabelOverlap | TextOverflow;
    set overlappingBehavior(value: ChartsAxisLabelOverlap | LabelOverlap | TextOverflow);
    get rotationAngle(): number;
    set rotationAngle(value: number);
    get staggeringSpacing(): number;
    set staggeringSpacing(value: number);
    get template(): any | undefined;
    set template(value: any | undefined);
    get textOverflow(): TextOverflow;
    set textOverflow(value: TextOverflow);
    get wordWrap(): WordWrap;
    set wordWrap(value: WordWrap);
    get argumentFormat(): Format | string | undefined;
    set argumentFormat(value: Format | string | undefined);
    get backgroundColor(): string | undefined;
    set backgroundColor(value: string | undefined);
    get border(): {
        color?: string | undefined;
        dashStyle?: DashStyle | undefined;
        visible?: boolean;
        width?: number;
    } | {
        color?: string;
        dashStyle?: DashStyle;
        visible?: boolean;
        width?: number;
    } | {
        color?: string | undefined;
        visible?: boolean | undefined;
        width?: number | undefined;
    };
    set border(value: {
        color?: string | undefined;
        dashStyle?: DashStyle | undefined;
        visible?: boolean;
        width?: number;
    } | {
        color?: string;
        dashStyle?: DashStyle;
        visible?: boolean;
        width?: number;
    } | {
        color?: string | undefined;
        visible?: boolean | undefined;
        width?: number | undefined;
    });
    get connector(): {
        color?: string | undefined;
        visible?: boolean;
        width?: number;
    } | {
        color?: string | undefined;
        opacity?: number;
        visible?: boolean;
        width?: number;
    };
    set connector(value: {
        color?: string | undefined;
        visible?: boolean;
        width?: number;
    } | {
        color?: string | undefined;
        opacity?: number;
        visible?: boolean;
        width?: number;
    });
    get displayFormat(): string | undefined;
    set displayFormat(value: string | undefined);
    get horizontalOffset(): number;
    set horizontalOffset(value: number);
    get showForZeroValues(): boolean;
    set showForZeroValues(value: boolean);
    get verticalOffset(): number;
    set verticalOffset(value: number);
    get hideFirstOrLast(): CircularGaugeLabelOverlap;
    set hideFirstOrLast(value: CircularGaugeLabelOverlap);
    get indentFromTick(): number;
    set indentFromTick(value: number);
    get useRangeColors(): boolean;
    set useRangeColors(value: boolean);
    get location(): LabelLocation;
    set location(value: LabelLocation);
    get showColon(): boolean;
    set showColon(value: boolean);
    get radialOffset(): number;
    set radialOffset(value: number);
    get topIndent(): number;
    set topIndent(value: number);
    get shadow(): {
        blur?: number;
        color?: string;
        offsetX?: number;
        offsetY?: number;
        opacity?: number;
    };
    set shadow(value: {
        blur?: number;
        color?: string;
        offsetX?: number;
        offsetY?: number;
        opacity?: number;
    });
    get useNodeColors(): boolean;
    set useNodeColors(value: boolean);
    get dataField(): string;
    set dataField(value: string);
    get enabled(): boolean;
    set enabled(value: boolean);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost, renderer: Renderer2, document: any, templateHost: DxTemplateHost, element: ElementRef);
    setTemplate(template: DxTemplateDirective): void;
    ngAfterViewInit(): void;
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoLabelComponent, [{ host: true; skipSelf: true; }, { host: true; }, null, null, { host: true; }, null]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoLabelComponent, "dxo-label", never, { "connectorColor": { "alias": "connectorColor"; "required": false; }; "connectorWidth": { "alias": "connectorWidth"; "required": false; }; "customizeText": { "alias": "customizeText"; "required": false; }; "font": { "alias": "font"; "required": false; }; "format": { "alias": "format"; "required": false; }; "indent": { "alias": "indent"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "horizontalAlignment": { "alias": "horizontalAlignment"; "required": false; }; "position": { "alias": "position"; "required": false; }; "text": { "alias": "text"; "required": false; }; "verticalAlignment": { "alias": "verticalAlignment"; "required": false; }; "alignment": { "alias": "alignment"; "required": false; }; "customizeHint": { "alias": "customizeHint"; "required": false; }; "displayMode": { "alias": "displayMode"; "required": false; }; "indentFromAxis": { "alias": "indentFromAxis"; "required": false; }; "overlappingBehavior": { "alias": "overlappingBehavior"; "required": false; }; "rotationAngle": { "alias": "rotationAngle"; "required": false; }; "staggeringSpacing": { "alias": "staggeringSpacing"; "required": false; }; "template": { "alias": "template"; "required": false; }; "textOverflow": { "alias": "textOverflow"; "required": false; }; "wordWrap": { "alias": "wordWrap"; "required": false; }; "argumentFormat": { "alias": "argumentFormat"; "required": false; }; "backgroundColor": { "alias": "backgroundColor"; "required": false; }; "border": { "alias": "border"; "required": false; }; "connector": { "alias": "connector"; "required": false; }; "displayFormat": { "alias": "displayFormat"; "required": false; }; "horizontalOffset": { "alias": "horizontalOffset"; "required": false; }; "showForZeroValues": { "alias": "showForZeroValues"; "required": false; }; "verticalOffset": { "alias": "verticalOffset"; "required": false; }; "hideFirstOrLast": { "alias": "hideFirstOrLast"; "required": false; }; "indentFromTick": { "alias": "indentFromTick"; "required": false; }; "useRangeColors": { "alias": "useRangeColors"; "required": false; }; "location": { "alias": "location"; "required": false; }; "showColon": { "alias": "showColon"; "required": false; }; "radialOffset": { "alias": "radialOffset"; "required": false; }; "topIndent": { "alias": "topIndent"; "required": false; }; "shadow": { "alias": "shadow"; "required": false; }; "useNodeColors": { "alias": "useNodeColors"; "required": false; }; "dataField": { "alias": "dataField"; "required": false; }; "enabled": { "alias": "enabled"; "required": false; }; }, {}, never, ["*"], true, never>;
}
declare class DxoLabelModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoLabelModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoLabelModule, never, [typeof DxoLabelComponent], [typeof DxoLabelComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoLabelModule>;
}

declare class DxiLayerComponent extends CollectionNestedOption {
    get borderColor(): string;
    set borderColor(value: string);
    get borderWidth(): number;
    set borderWidth(value: number);
    get color(): string;
    set color(value: string);
    get colorGroupingField(): string | undefined;
    set colorGroupingField(value: string | undefined);
    get colorGroups(): undefined | Array<number>;
    set colorGroups(value: undefined | Array<number>);
    get customize(): Function;
    set customize(value: Function);
    get dataField(): string | undefined;
    set dataField(value: string | undefined);
    get dataSource(): Store | DataSource | Options | any | null | string | Array<any>;
    set dataSource(value: Store | DataSource | Options | any | null | string | Array<any>);
    get elementType(): VectorMapMarkerType;
    set elementType(value: VectorMapMarkerType);
    get hoveredBorderColor(): string;
    set hoveredBorderColor(value: string);
    get hoveredBorderWidth(): number;
    set hoveredBorderWidth(value: number);
    get hoveredColor(): string;
    set hoveredColor(value: string);
    get hoverEnabled(): boolean;
    set hoverEnabled(value: boolean);
    get label(): {
        dataField?: string;
        enabled?: boolean;
        font?: Font;
    };
    set label(value: {
        dataField?: string;
        enabled?: boolean;
        font?: Font;
    });
    get maxSize(): number;
    set maxSize(value: number);
    get minSize(): number;
    set minSize(value: number);
    get name(): string;
    set name(value: string);
    get opacity(): number;
    set opacity(value: number);
    get palette(): Palette | string | Array<string>;
    set palette(value: Palette | string | Array<string>);
    get paletteIndex(): number;
    set paletteIndex(value: number);
    get paletteSize(): number;
    set paletteSize(value: number);
    get selectedBorderColor(): string;
    set selectedBorderColor(value: string);
    get selectedBorderWidth(): number;
    set selectedBorderWidth(value: number);
    get selectedColor(): string;
    set selectedColor(value: string);
    get selectionMode(): SingleMultipleOrNone;
    set selectionMode(value: SingleMultipleOrNone);
    get size(): number;
    set size(value: number);
    get sizeGroupingField(): string | undefined;
    set sizeGroupingField(value: string | undefined);
    get sizeGroups(): undefined | Array<number>;
    set sizeGroups(value: undefined | Array<number>);
    get type(): VectorMapLayerType;
    set type(value: VectorMapLayerType);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiLayerComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiLayerComponent, "dxi-layer", never, { "borderColor": { "alias": "borderColor"; "required": false; }; "borderWidth": { "alias": "borderWidth"; "required": false; }; "color": { "alias": "color"; "required": false; }; "colorGroupingField": { "alias": "colorGroupingField"; "required": false; }; "colorGroups": { "alias": "colorGroups"; "required": false; }; "customize": { "alias": "customize"; "required": false; }; "dataField": { "alias": "dataField"; "required": false; }; "dataSource": { "alias": "dataSource"; "required": false; }; "elementType": { "alias": "elementType"; "required": false; }; "hoveredBorderColor": { "alias": "hoveredBorderColor"; "required": false; }; "hoveredBorderWidth": { "alias": "hoveredBorderWidth"; "required": false; }; "hoveredColor": { "alias": "hoveredColor"; "required": false; }; "hoverEnabled": { "alias": "hoverEnabled"; "required": false; }; "label": { "alias": "label"; "required": false; }; "maxSize": { "alias": "maxSize"; "required": false; }; "minSize": { "alias": "minSize"; "required": false; }; "name": { "alias": "name"; "required": false; }; "opacity": { "alias": "opacity"; "required": false; }; "palette": { "alias": "palette"; "required": false; }; "paletteIndex": { "alias": "paletteIndex"; "required": false; }; "paletteSize": { "alias": "paletteSize"; "required": false; }; "selectedBorderColor": { "alias": "selectedBorderColor"; "required": false; }; "selectedBorderWidth": { "alias": "selectedBorderWidth"; "required": false; }; "selectedColor": { "alias": "selectedColor"; "required": false; }; "selectionMode": { "alias": "selectionMode"; "required": false; }; "size": { "alias": "size"; "required": false; }; "sizeGroupingField": { "alias": "sizeGroupingField"; "required": false; }; "sizeGroups": { "alias": "sizeGroups"; "required": false; }; "type": { "alias": "type"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxiLayerModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiLayerModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiLayerModule, never, [typeof DxiLayerComponent], [typeof DxiLayerComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiLayerModule>;
}

declare class DxiLegendComponent extends CollectionNestedOption {
    get backgroundColor(): string | undefined;
    set backgroundColor(value: string | undefined);
    get border(): {
        color?: string;
        cornerRadius?: number;
        dashStyle?: DashStyle;
        opacity?: number | undefined;
        visible?: boolean;
        width?: number;
    };
    set border(value: {
        color?: string;
        cornerRadius?: number;
        dashStyle?: DashStyle;
        opacity?: number | undefined;
        visible?: boolean;
        width?: number;
    });
    get columnCount(): number;
    set columnCount(value: number);
    get columnItemSpacing(): number;
    set columnItemSpacing(value: number);
    get customizeHint(): Function;
    set customizeHint(value: Function);
    get customizeItems(): Function;
    set customizeItems(value: Function);
    get customizeText(): Function;
    set customizeText(value: Function);
    get font(): Font;
    set font(value: Font);
    get horizontalAlignment(): HorizontalAlignment;
    set horizontalAlignment(value: HorizontalAlignment);
    get itemsAlignment(): HorizontalAlignment | undefined;
    set itemsAlignment(value: HorizontalAlignment | undefined);
    get itemTextPosition(): Position | undefined;
    set itemTextPosition(value: Position | undefined);
    get margin(): number | {
        bottom?: number;
        left?: number;
        right?: number;
        top?: number;
    };
    set margin(value: number | {
        bottom?: number;
        left?: number;
        right?: number;
        top?: number;
    });
    get markerColor(): string | undefined;
    set markerColor(value: string | undefined);
    get markerShape(): VectorMapMarkerShape;
    set markerShape(value: VectorMapMarkerShape);
    get markerSize(): number;
    set markerSize(value: number);
    get markerTemplate(): any | undefined;
    set markerTemplate(value: any | undefined);
    get orientation(): Orientation | undefined;
    set orientation(value: Orientation | undefined);
    get paddingLeftRight(): number;
    set paddingLeftRight(value: number);
    get paddingTopBottom(): number;
    set paddingTopBottom(value: number);
    get rowCount(): number;
    set rowCount(value: number);
    get rowItemSpacing(): number;
    set rowItemSpacing(value: number);
    get source(): {
        grouping?: string;
        layer?: string;
    };
    set source(value: {
        grouping?: string;
        layer?: string;
    });
    get title(): string | {
        font?: Font;
        horizontalAlignment?: HorizontalAlignment | undefined;
        margin?: {
            bottom?: number;
            left?: number;
            right?: number;
            top?: number;
        };
        placeholderSize?: number | undefined;
        subtitle?: string | {
            font?: Font;
            offset?: number;
            text?: string | undefined;
        };
        text?: string | undefined;
        verticalAlignment?: VerticalEdge;
    };
    set title(value: string | {
        font?: Font;
        horizontalAlignment?: HorizontalAlignment | undefined;
        margin?: {
            bottom?: number;
            left?: number;
            right?: number;
            top?: number;
        };
        placeholderSize?: number | undefined;
        subtitle?: string | {
            font?: Font;
            offset?: number;
            text?: string | undefined;
        };
        text?: string | undefined;
        verticalAlignment?: VerticalEdge;
    });
    get verticalAlignment(): VerticalEdge;
    set verticalAlignment(value: VerticalEdge);
    get visible(): boolean;
    set visible(value: boolean);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiLegendComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiLegendComponent, "dxi-legend", never, { "backgroundColor": { "alias": "backgroundColor"; "required": false; }; "border": { "alias": "border"; "required": false; }; "columnCount": { "alias": "columnCount"; "required": false; }; "columnItemSpacing": { "alias": "columnItemSpacing"; "required": false; }; "customizeHint": { "alias": "customizeHint"; "required": false; }; "customizeItems": { "alias": "customizeItems"; "required": false; }; "customizeText": { "alias": "customizeText"; "required": false; }; "font": { "alias": "font"; "required": false; }; "horizontalAlignment": { "alias": "horizontalAlignment"; "required": false; }; "itemsAlignment": { "alias": "itemsAlignment"; "required": false; }; "itemTextPosition": { "alias": "itemTextPosition"; "required": false; }; "margin": { "alias": "margin"; "required": false; }; "markerColor": { "alias": "markerColor"; "required": false; }; "markerShape": { "alias": "markerShape"; "required": false; }; "markerSize": { "alias": "markerSize"; "required": false; }; "markerTemplate": { "alias": "markerTemplate"; "required": false; }; "orientation": { "alias": "orientation"; "required": false; }; "paddingLeftRight": { "alias": "paddingLeftRight"; "required": false; }; "paddingTopBottom": { "alias": "paddingTopBottom"; "required": false; }; "rowCount": { "alias": "rowCount"; "required": false; }; "rowItemSpacing": { "alias": "rowItemSpacing"; "required": false; }; "source": { "alias": "source"; "required": false; }; "title": { "alias": "title"; "required": false; }; "verticalAlignment": { "alias": "verticalAlignment"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxiLegendModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiLegendModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiLegendModule, never, [typeof DxiLegendComponent], [typeof DxiLegendComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiLegendModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoLegendComponent extends NestedOption implements OnDestroy, OnInit {
    get backgroundColor(): string | undefined;
    set backgroundColor(value: string | undefined);
    get border(): {
        color?: string;
        cornerRadius?: number;
        dashStyle?: DashStyle;
        opacity?: number | undefined;
        visible?: boolean;
        width?: number;
    };
    set border(value: {
        color?: string;
        cornerRadius?: number;
        dashStyle?: DashStyle;
        opacity?: number | undefined;
        visible?: boolean;
        width?: number;
    });
    get columnCount(): number;
    set columnCount(value: number);
    get columnItemSpacing(): number;
    set columnItemSpacing(value: number);
    get customizeHint(): Function;
    set customizeHint(value: Function);
    get customizeItems(): Function;
    set customizeItems(value: Function);
    get customizeText(): Function;
    set customizeText(value: Function);
    get font(): Font;
    set font(value: Font);
    get horizontalAlignment(): HorizontalAlignment;
    set horizontalAlignment(value: HorizontalAlignment);
    get itemsAlignment(): HorizontalAlignment | undefined;
    set itemsAlignment(value: HorizontalAlignment | undefined);
    get itemTextFormat(): Format | string | undefined;
    set itemTextFormat(value: Format | string | undefined);
    get itemTextPosition(): Position | undefined;
    set itemTextPosition(value: Position | undefined);
    get margin(): number | {
        bottom?: number;
        left?: number;
        right?: number;
        top?: number;
    };
    set margin(value: number | {
        bottom?: number;
        left?: number;
        right?: number;
        top?: number;
    });
    get markerSize(): number;
    set markerSize(value: number);
    get markerTemplate(): any | undefined;
    set markerTemplate(value: any | undefined);
    get orientation(): Orientation | undefined;
    set orientation(value: Orientation | undefined);
    get paddingLeftRight(): number;
    set paddingLeftRight(value: number);
    get paddingTopBottom(): number;
    set paddingTopBottom(value: number);
    get rowCount(): number;
    set rowCount(value: number);
    get rowItemSpacing(): number;
    set rowItemSpacing(value: number);
    get title(): string | {
        font?: Font;
        horizontalAlignment?: HorizontalAlignment | undefined;
        margin?: {
            bottom?: number;
            left?: number;
            right?: number;
            top?: number;
        };
        placeholderSize?: number | undefined;
        subtitle?: string | {
            font?: Font;
            offset?: number;
            text?: string | undefined;
        };
        text?: string | undefined;
        verticalAlignment?: VerticalEdge;
    };
    set title(value: string | {
        font?: Font;
        horizontalAlignment?: HorizontalAlignment | undefined;
        margin?: {
            bottom?: number;
            left?: number;
            right?: number;
            top?: number;
        };
        placeholderSize?: number | undefined;
        subtitle?: string | {
            font?: Font;
            offset?: number;
            text?: string | undefined;
        };
        text?: string | undefined;
        verticalAlignment?: VerticalEdge;
    });
    get verticalAlignment(): VerticalEdge;
    set verticalAlignment(value: VerticalEdge);
    get visible(): boolean;
    set visible(value: boolean);
    get hoverMode(): LegendHoverMode | PieChartLegendHoverMode;
    set hoverMode(value: LegendHoverMode | PieChartLegendHoverMode);
    get position(): RelativePosition;
    set position(value: RelativePosition);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoLegendComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoLegendComponent, "dxo-legend", never, { "backgroundColor": { "alias": "backgroundColor"; "required": false; }; "border": { "alias": "border"; "required": false; }; "columnCount": { "alias": "columnCount"; "required": false; }; "columnItemSpacing": { "alias": "columnItemSpacing"; "required": false; }; "customizeHint": { "alias": "customizeHint"; "required": false; }; "customizeItems": { "alias": "customizeItems"; "required": false; }; "customizeText": { "alias": "customizeText"; "required": false; }; "font": { "alias": "font"; "required": false; }; "horizontalAlignment": { "alias": "horizontalAlignment"; "required": false; }; "itemsAlignment": { "alias": "itemsAlignment"; "required": false; }; "itemTextFormat": { "alias": "itemTextFormat"; "required": false; }; "itemTextPosition": { "alias": "itemTextPosition"; "required": false; }; "margin": { "alias": "margin"; "required": false; }; "markerSize": { "alias": "markerSize"; "required": false; }; "markerTemplate": { "alias": "markerTemplate"; "required": false; }; "orientation": { "alias": "orientation"; "required": false; }; "paddingLeftRight": { "alias": "paddingLeftRight"; "required": false; }; "paddingTopBottom": { "alias": "paddingTopBottom"; "required": false; }; "rowCount": { "alias": "rowCount"; "required": false; }; "rowItemSpacing": { "alias": "rowItemSpacing"; "required": false; }; "title": { "alias": "title"; "required": false; }; "verticalAlignment": { "alias": "verticalAlignment"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "hoverMode": { "alias": "hoverMode"; "required": false; }; "position": { "alias": "position"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoLegendModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoLegendModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoLegendModule, never, [typeof DxoLegendComponent], [typeof DxoLegendComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoLegendModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoLineComponent extends DxoChartCommonSeriesSettings implements OnDestroy, OnInit {
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoLineComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoLineComponent, "dxo-line", never, { "aggregation": { "alias": "aggregation"; "required": false; }; "area": { "alias": "area"; "required": false; }; "argumentField": { "alias": "argumentField"; "required": false; }; "axis": { "alias": "axis"; "required": false; }; "bar": { "alias": "bar"; "required": false; }; "barOverlapGroup": { "alias": "barOverlapGroup"; "required": false; }; "barPadding": { "alias": "barPadding"; "required": false; }; "barWidth": { "alias": "barWidth"; "required": false; }; "border": { "alias": "border"; "required": false; }; "bubble": { "alias": "bubble"; "required": false; }; "candlestick": { "alias": "candlestick"; "required": false; }; "closeValueField": { "alias": "closeValueField"; "required": false; }; "color": { "alias": "color"; "required": false; }; "cornerRadius": { "alias": "cornerRadius"; "required": false; }; "dashStyle": { "alias": "dashStyle"; "required": false; }; "fullstackedarea": { "alias": "fullstackedarea"; "required": false; }; "fullstackedbar": { "alias": "fullstackedbar"; "required": false; }; "fullstackedline": { "alias": "fullstackedline"; "required": false; }; "fullstackedspline": { "alias": "fullstackedspline"; "required": false; }; "fullstackedsplinearea": { "alias": "fullstackedsplinearea"; "required": false; }; "highValueField": { "alias": "highValueField"; "required": false; }; "hoverMode": { "alias": "hoverMode"; "required": false; }; "hoverStyle": { "alias": "hoverStyle"; "required": false; }; "ignoreEmptyPoints": { "alias": "ignoreEmptyPoints"; "required": false; }; "innerColor": { "alias": "innerColor"; "required": false; }; "label": { "alias": "label"; "required": false; }; "line": { "alias": "line"; "required": false; }; "lowValueField": { "alias": "lowValueField"; "required": false; }; "maxLabelCount": { "alias": "maxLabelCount"; "required": false; }; "minBarSize": { "alias": "minBarSize"; "required": false; }; "opacity": { "alias": "opacity"; "required": false; }; "openValueField": { "alias": "openValueField"; "required": false; }; "pane": { "alias": "pane"; "required": false; }; "point": { "alias": "point"; "required": false; }; "rangearea": { "alias": "rangearea"; "required": false; }; "rangebar": { "alias": "rangebar"; "required": false; }; "rangeValue1Field": { "alias": "rangeValue1Field"; "required": false; }; "rangeValue2Field": { "alias": "rangeValue2Field"; "required": false; }; "reduction": { "alias": "reduction"; "required": false; }; "scatter": { "alias": "scatter"; "required": false; }; "selectionMode": { "alias": "selectionMode"; "required": false; }; "selectionStyle": { "alias": "selectionStyle"; "required": false; }; "showInLegend": { "alias": "showInLegend"; "required": false; }; "sizeField": { "alias": "sizeField"; "required": false; }; "spline": { "alias": "spline"; "required": false; }; "splinearea": { "alias": "splinearea"; "required": false; }; "stack": { "alias": "stack"; "required": false; }; "stackedarea": { "alias": "stackedarea"; "required": false; }; "stackedbar": { "alias": "stackedbar"; "required": false; }; "stackedline": { "alias": "stackedline"; "required": false; }; "stackedspline": { "alias": "stackedspline"; "required": false; }; "stackedsplinearea": { "alias": "stackedsplinearea"; "required": false; }; "steparea": { "alias": "steparea"; "required": false; }; "stepline": { "alias": "stepline"; "required": false; }; "stock": { "alias": "stock"; "required": false; }; "tagField": { "alias": "tagField"; "required": false; }; "type": { "alias": "type"; "required": false; }; "valueErrorBar": { "alias": "valueErrorBar"; "required": false; }; "valueField": { "alias": "valueField"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; "closed": { "alias": "closed"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoLineModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoLineModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoLineModule, never, [typeof DxoLineComponent], [typeof DxoLineComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoLineModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoLinkComponent extends NestedOption implements OnDestroy, OnInit {
    get border(): {
        color?: string | undefined;
        visible?: boolean | undefined;
        width?: number | undefined;
    };
    set border(value: {
        color?: string | undefined;
        visible?: boolean | undefined;
        width?: number | undefined;
    });
    get color(): string;
    set color(value: string);
    get colorMode(): SankeyColorMode;
    set colorMode(value: SankeyColorMode);
    get hoverStyle(): {
        border?: {
            color?: string | undefined;
            visible?: boolean | undefined;
            width?: number | undefined;
        };
        color?: string | undefined;
        hatching?: {
            direction?: HatchDirection;
            opacity?: number;
            step?: number;
            width?: number;
        };
        opacity?: number | undefined;
    };
    set hoverStyle(value: {
        border?: {
            color?: string | undefined;
            visible?: boolean | undefined;
            width?: number | undefined;
        };
        color?: string | undefined;
        hatching?: {
            direction?: HatchDirection;
            opacity?: number;
            step?: number;
            width?: number;
        };
        opacity?: number | undefined;
    });
    get opacity(): number;
    set opacity(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoLinkComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoLinkComponent, "dxo-link", never, { "border": { "alias": "border"; "required": false; }; "color": { "alias": "color"; "required": false; }; "colorMode": { "alias": "colorMode"; "required": false; }; "hoverStyle": { "alias": "hoverStyle"; "required": false; }; "opacity": { "alias": "opacity"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoLinkModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoLinkModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoLinkModule, never, [typeof DxoLinkComponent], [typeof DxoLinkComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoLinkModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoLoadPanelComponent extends NestedOption implements OnDestroy, OnInit {
    get enabled(): Mode | boolean;
    set enabled(value: Mode | boolean);
    get height(): number | string;
    set height(value: number | string);
    get indicatorSrc(): string;
    set indicatorSrc(value: string);
    get shading(): boolean;
    set shading(value: boolean);
    get shadingColor(): string;
    set shadingColor(value: string);
    get showIndicator(): boolean;
    set showIndicator(value: boolean);
    get showPane(): boolean;
    set showPane(value: boolean);
    get text(): string;
    set text(value: string);
    get width(): number | string;
    set width(value: number | string);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoLoadPanelComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoLoadPanelComponent, "dxo-load-panel", never, { "enabled": { "alias": "enabled"; "required": false; }; "height": { "alias": "height"; "required": false; }; "indicatorSrc": { "alias": "indicatorSrc"; "required": false; }; "shading": { "alias": "shading"; "required": false; }; "shadingColor": { "alias": "shadingColor"; "required": false; }; "showIndicator": { "alias": "showIndicator"; "required": false; }; "showPane": { "alias": "showPane"; "required": false; }; "text": { "alias": "text"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoLoadPanelModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoLoadPanelModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoLoadPanelModule, never, [typeof DxoLoadPanelComponent], [typeof DxoLoadPanelComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoLoadPanelModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoLoadingIndicatorComponent extends NestedOption implements OnDestroy, OnInit {
    get backgroundColor(): string;
    set backgroundColor(value: string);
    get font(): Font;
    set font(value: Font);
    get show(): boolean;
    set show(value: boolean);
    get text(): string;
    set text(value: string);
    get enabled(): boolean;
    set enabled(value: boolean);
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    showChange: EventEmitter<boolean>;
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoLoadingIndicatorComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoLoadingIndicatorComponent, "dxo-loading-indicator", never, { "backgroundColor": { "alias": "backgroundColor"; "required": false; }; "font": { "alias": "font"; "required": false; }; "show": { "alias": "show"; "required": false; }; "text": { "alias": "text"; "required": false; }; "enabled": { "alias": "enabled"; "required": false; }; }, { "showChange": "showChange"; }, never, never, true, never>;
}
declare class DxoLoadingIndicatorModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoLoadingIndicatorModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoLoadingIndicatorModule, never, [typeof DxoLoadingIndicatorComponent], [typeof DxoLoadingIndicatorComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoLoadingIndicatorModule>;
}

declare class DxiLocationComponent extends CollectionNestedOption {
    get lat(): number;
    set lat(value: number);
    get lng(): number;
    set lng(value: number);
    get col(): number;
    set col(value: number);
    get colspan(): number | undefined;
    set colspan(value: number | undefined);
    get row(): number;
    set row(value: number);
    get rowspan(): number | undefined;
    set rowspan(value: number | undefined);
    get screen(): string | undefined;
    set screen(value: string | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiLocationComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiLocationComponent, "dxi-location", never, { "lat": { "alias": "lat"; "required": false; }; "lng": { "alias": "lng"; "required": false; }; "col": { "alias": "col"; "required": false; }; "colspan": { "alias": "colspan"; "required": false; }; "row": { "alias": "row"; "required": false; }; "rowspan": { "alias": "rowspan"; "required": false; }; "screen": { "alias": "screen"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxiLocationModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiLocationModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiLocationModule, never, [typeof DxiLocationComponent], [typeof DxiLocationComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiLocationModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoLookupComponent extends NestedOption implements OnDestroy, OnInit {
    get allowClearing(): boolean;
    set allowClearing(value: boolean);
    get calculateCellValue(): Function;
    set calculateCellValue(value: Function);
    get dataSource(): Store | Options | Function | null | undefined | Array<any>;
    set dataSource(value: Store | Options | Function | null | undefined | Array<any>);
    get displayExpr(): Function | string | undefined;
    set displayExpr(value: Function | string | undefined);
    get valueExpr(): string | undefined | Function;
    set valueExpr(value: string | undefined | Function);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoLookupComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoLookupComponent, "dxo-lookup", never, { "allowClearing": { "alias": "allowClearing"; "required": false; }; "calculateCellValue": { "alias": "calculateCellValue"; "required": false; }; "dataSource": { "alias": "dataSource"; "required": false; }; "displayExpr": { "alias": "displayExpr"; "required": false; }; "valueExpr": { "alias": "valueExpr"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoLookupModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoLookupModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoLookupModule, never, [typeof DxoLookupComponent], [typeof DxoLookupComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoLookupModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoMainToolbarComponent extends NestedOption implements OnDestroy, OnInit {
    set _commandsContentChildren(value: QueryList<CollectionNestedOption>);
    get commands(): Array<CustomCommand | Command>;
    set commands(value: Array<CustomCommand | Command>);
    get visible(): boolean;
    set visible(value: boolean);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoMainToolbarComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoMainToolbarComponent, "dxo-main-toolbar", never, { "commands": { "alias": "commands"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; }, {}, ["_commandsContentChildren"], never, true, never>;
}
declare class DxoMainToolbarModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoMainToolbarModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoMainToolbarModule, never, [typeof DxoMainToolbarComponent], [typeof DxoMainToolbarComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoMainToolbarModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoMarginComponent extends NestedOption implements OnDestroy, OnInit {
    get bottom(): number;
    set bottom(value: number);
    get left(): number;
    set left(value: number);
    get right(): number;
    set right(value: number);
    get top(): number;
    set top(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoMarginComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoMarginComponent, "dxo-margin", never, { "bottom": { "alias": "bottom"; "required": false; }; "left": { "alias": "left"; "required": false; }; "right": { "alias": "right"; "required": false; }; "top": { "alias": "top"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoMarginModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoMarginModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoMarginModule, never, [typeof DxoMarginComponent], [typeof DxoMarginComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoMarginModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxiMarkerComponent extends CollectionNestedOption {
    set _locationContentChildren(value: QueryList<CollectionNestedOption>);
    get iconSrc(): string;
    set iconSrc(value: string);
    get location(): string | Array<number | {
        lat?: number;
        lng?: number;
    }>;
    set location(value: string | Array<number | {
        lat?: number;
        lng?: number;
    }>);
    get onClick(): Function;
    set onClick(value: Function);
    get tooltip(): string | {
        isShown?: boolean;
        text?: string;
    };
    set tooltip(value: string | {
        isShown?: boolean;
        text?: string;
    });
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiMarkerComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiMarkerComponent, "dxi-marker", never, { "iconSrc": { "alias": "iconSrc"; "required": false; }; "location": { "alias": "location"; "required": false; }; "onClick": { "alias": "onClick"; "required": false; }; "tooltip": { "alias": "tooltip"; "required": false; }; }, {}, ["_locationContentChildren"], never, true, never>;
}
declare class DxiMarkerModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiMarkerModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiMarkerModule, never, [typeof DxiMarkerComponent], [typeof DxiMarkerComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiMarkerModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoMarkerComponent extends NestedOption implements OnDestroy, OnInit {
    get label(): {
        customizeText?: Function;
        format?: Format | string | undefined;
    };
    set label(value: {
        customizeText?: Function;
        format?: Format | string | undefined;
    });
    get separatorHeight(): number;
    set separatorHeight(value: number);
    get textLeftIndent(): number;
    set textLeftIndent(value: number);
    get textTopIndent(): number;
    set textTopIndent(value: number);
    get topIndent(): number;
    set topIndent(value: number);
    get visible(): boolean;
    set visible(value: boolean);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoMarkerComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoMarkerComponent, "dxo-marker", never, { "label": { "alias": "label"; "required": false; }; "separatorHeight": { "alias": "separatorHeight"; "required": false; }; "textLeftIndent": { "alias": "textLeftIndent"; "required": false; }; "textTopIndent": { "alias": "textTopIndent"; "required": false; }; "topIndent": { "alias": "topIndent"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoMarkerModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoMarkerModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoMarkerModule, never, [typeof DxoMarkerComponent], [typeof DxoMarkerComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoMarkerModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoMasterDetailComponent extends NestedOption implements AfterViewInit, OnDestroy, OnInit, IDxTemplateHost {
    private renderer;
    private document;
    private element;
    get autoExpandAll(): boolean;
    set autoExpandAll(value: boolean);
    get enabled(): boolean;
    set enabled(value: boolean);
    get template(): any;
    set template(value: any);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost, renderer: Renderer2, document: any, templateHost: DxTemplateHost, element: ElementRef);
    setTemplate(template: DxTemplateDirective): void;
    ngAfterViewInit(): void;
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoMasterDetailComponent, [{ host: true; skipSelf: true; }, { host: true; }, null, null, { host: true; }, null]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoMasterDetailComponent, "dxo-master-detail", never, { "autoExpandAll": { "alias": "autoExpandAll"; "required": false; }; "enabled": { "alias": "enabled"; "required": false; }; "template": { "alias": "template"; "required": false; }; }, {}, never, ["*"], true, never>;
}
declare class DxoMasterDetailModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoMasterDetailModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoMasterDetailModule, never, [typeof DxoMasterDetailComponent], [typeof DxoMasterDetailComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoMasterDetailModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoMaxRangeComponent extends NestedOption implements OnDestroy, OnInit {
    get days(): number;
    set days(value: number);
    get hours(): number;
    set hours(value: number);
    get milliseconds(): number;
    set milliseconds(value: number);
    get minutes(): number;
    set minutes(value: number);
    get months(): number;
    set months(value: number);
    get quarters(): number;
    set quarters(value: number);
    get seconds(): number;
    set seconds(value: number);
    get weeks(): number;
    set weeks(value: number);
    get years(): number;
    set years(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoMaxRangeComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoMaxRangeComponent, "dxo-max-range", never, { "days": { "alias": "days"; "required": false; }; "hours": { "alias": "hours"; "required": false; }; "milliseconds": { "alias": "milliseconds"; "required": false; }; "minutes": { "alias": "minutes"; "required": false; }; "months": { "alias": "months"; "required": false; }; "quarters": { "alias": "quarters"; "required": false; }; "seconds": { "alias": "seconds"; "required": false; }; "weeks": { "alias": "weeks"; "required": false; }; "years": { "alias": "years"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoMaxRangeModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoMaxRangeModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoMaxRangeModule, never, [typeof DxoMaxRangeComponent], [typeof DxoMaxRangeComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoMaxRangeModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare abstract class DxoHtmlEditorMediaResizing extends NestedOption {
    get allowedTargets(): Array<string>;
    set allowedTargets(value: Array<string>);
    get enabled(): boolean;
    set enabled(value: boolean);
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoHtmlEditorMediaResizing, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoHtmlEditorMediaResizing, "ng-component", never, {}, {}, never, never, true, never>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoMediaResizingComponent extends DxoHtmlEditorMediaResizing implements OnDestroy, OnInit {
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoMediaResizingComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoMediaResizingComponent, "dxo-media-resizing", never, { "allowedTargets": { "alias": "allowedTargets"; "required": false; }; "enabled": { "alias": "enabled"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoMediaResizingModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoMediaResizingModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoMediaResizingModule, never, [typeof DxoMediaResizingComponent], [typeof DxoMediaResizingComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoMediaResizingModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare abstract class DxiHtmlEditorMention extends CollectionNestedOption {
    get dataSource(): Store | DataSource | Options | null | string | Array<any>;
    set dataSource(value: Store | DataSource | Options | null | string | Array<any>);
    get displayExpr(): Function | string;
    set displayExpr(value: Function | string);
    get itemTemplate(): any;
    set itemTemplate(value: any);
    get marker(): string;
    set marker(value: string);
    get minSearchLength(): number;
    set minSearchLength(value: number);
    get searchExpr(): Function | string | Array<Function | string>;
    set searchExpr(value: Function | string | Array<Function | string>);
    get searchTimeout(): number;
    set searchTimeout(value: number);
    get template(): any;
    set template(value: any);
    get valueExpr(): Function | string;
    set valueExpr(value: Function | string);
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiHtmlEditorMention, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiHtmlEditorMention, "ng-component", never, {}, {}, never, never, true, never>;
}

declare class DxiMentionComponent extends DxiHtmlEditorMention {
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiMentionComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiMentionComponent, "dxi-mention", never, { "dataSource": { "alias": "dataSource"; "required": false; }; "displayExpr": { "alias": "displayExpr"; "required": false; }; "itemTemplate": { "alias": "itemTemplate"; "required": false; }; "marker": { "alias": "marker"; "required": false; }; "minSearchLength": { "alias": "minSearchLength"; "required": false; }; "searchExpr": { "alias": "searchExpr"; "required": false; }; "searchTimeout": { "alias": "searchTimeout"; "required": false; }; "template": { "alias": "template"; "required": false; }; "valueExpr": { "alias": "valueExpr"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxiMentionModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiMentionModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiMentionModule, never, [typeof DxiMentionComponent], [typeof DxiMentionComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiMentionModule>;
}

declare class DxiMenuItemComponent extends CollectionNestedOption {
    get action(): Function;
    set action(value: Function);
    get text(): string;
    set text(value: string);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiMenuItemComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiMenuItemComponent, "dxi-menu-item", never, { "action": { "alias": "action"; "required": false; }; "text": { "alias": "text"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxiMenuItemModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiMenuItemModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiMenuItemModule, never, [typeof DxiMenuItemComponent], [typeof DxiMenuItemComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiMenuItemModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoMessageTimestampFormatComponent extends DxoFormat implements OnDestroy, OnInit {
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoMessageTimestampFormatComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoMessageTimestampFormatComponent, "dxo-message-timestamp-format", never, { "currency": { "alias": "currency"; "required": false; }; "formatter": { "alias": "formatter"; "required": false; }; "parser": { "alias": "parser"; "required": false; }; "precision": { "alias": "precision"; "required": false; }; "type": { "alias": "type"; "required": false; }; "useCurrencyAccountingStyle": { "alias": "useCurrencyAccountingStyle"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoMessageTimestampFormatModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoMessageTimestampFormatModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoMessageTimestampFormatModule, never, [typeof DxoMessageTimestampFormatComponent], [typeof DxoMessageTimestampFormatComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoMessageTimestampFormatModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoMinRangeComponent extends NestedOption implements OnDestroy, OnInit {
    get days(): number;
    set days(value: number);
    get hours(): number;
    set hours(value: number);
    get milliseconds(): number;
    set milliseconds(value: number);
    get minutes(): number;
    set minutes(value: number);
    get months(): number;
    set months(value: number);
    get quarters(): number;
    set quarters(value: number);
    get seconds(): number;
    set seconds(value: number);
    get weeks(): number;
    set weeks(value: number);
    get years(): number;
    set years(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoMinRangeComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoMinRangeComponent, "dxo-min-range", never, { "days": { "alias": "days"; "required": false; }; "hours": { "alias": "hours"; "required": false; }; "milliseconds": { "alias": "milliseconds"; "required": false; }; "minutes": { "alias": "minutes"; "required": false; }; "months": { "alias": "months"; "required": false; }; "quarters": { "alias": "quarters"; "required": false; }; "seconds": { "alias": "seconds"; "required": false; }; "weeks": { "alias": "weeks"; "required": false; }; "years": { "alias": "years"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoMinRangeModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoMinRangeModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoMinRangeModule, never, [typeof DxoMinRangeComponent], [typeof DxoMinRangeComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoMinRangeModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoMinVisualRangeLengthComponent extends NestedOption implements OnDestroy, OnInit {
    get days(): number;
    set days(value: number);
    get hours(): number;
    set hours(value: number);
    get milliseconds(): number;
    set milliseconds(value: number);
    get minutes(): number;
    set minutes(value: number);
    get months(): number;
    set months(value: number);
    get quarters(): number;
    set quarters(value: number);
    get seconds(): number;
    set seconds(value: number);
    get weeks(): number;
    set weeks(value: number);
    get years(): number;
    set years(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoMinVisualRangeLengthComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoMinVisualRangeLengthComponent, "dxo-min-visual-range-length", never, { "days": { "alias": "days"; "required": false; }; "hours": { "alias": "hours"; "required": false; }; "milliseconds": { "alias": "milliseconds"; "required": false; }; "minutes": { "alias": "minutes"; "required": false; }; "months": { "alias": "months"; "required": false; }; "quarters": { "alias": "quarters"; "required": false; }; "seconds": { "alias": "seconds"; "required": false; }; "weeks": { "alias": "weeks"; "required": false; }; "years": { "alias": "years"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoMinVisualRangeLengthModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoMinVisualRangeLengthModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoMinVisualRangeLengthModule, never, [typeof DxoMinVisualRangeLengthComponent], [typeof DxoMinVisualRangeLengthComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoMinVisualRangeLengthModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoMinorGridComponent extends NestedOption implements OnDestroy, OnInit {
    get color(): string;
    set color(value: string);
    get opacity(): number | undefined;
    set opacity(value: number | undefined);
    get visible(): boolean;
    set visible(value: boolean);
    get width(): number;
    set width(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoMinorGridComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoMinorGridComponent, "dxo-minor-grid", never, { "color": { "alias": "color"; "required": false; }; "opacity": { "alias": "opacity"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoMinorGridModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoMinorGridModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoMinorGridModule, never, [typeof DxoMinorGridComponent], [typeof DxoMinorGridComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoMinorGridModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoMinorTickIntervalComponent extends NestedOption implements OnDestroy, OnInit {
    get days(): number;
    set days(value: number);
    get hours(): number;
    set hours(value: number);
    get milliseconds(): number;
    set milliseconds(value: number);
    get minutes(): number;
    set minutes(value: number);
    get months(): number;
    set months(value: number);
    get quarters(): number;
    set quarters(value: number);
    get seconds(): number;
    set seconds(value: number);
    get weeks(): number;
    set weeks(value: number);
    get years(): number;
    set years(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoMinorTickIntervalComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoMinorTickIntervalComponent, "dxo-minor-tick-interval", never, { "days": { "alias": "days"; "required": false; }; "hours": { "alias": "hours"; "required": false; }; "milliseconds": { "alias": "milliseconds"; "required": false; }; "minutes": { "alias": "minutes"; "required": false; }; "months": { "alias": "months"; "required": false; }; "quarters": { "alias": "quarters"; "required": false; }; "seconds": { "alias": "seconds"; "required": false; }; "weeks": { "alias": "weeks"; "required": false; }; "years": { "alias": "years"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoMinorTickIntervalModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoMinorTickIntervalModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoMinorTickIntervalModule, never, [typeof DxoMinorTickIntervalComponent], [typeof DxoMinorTickIntervalComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoMinorTickIntervalModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoMinorTickComponent extends NestedOption implements OnDestroy, OnInit {
    get color(): string;
    set color(value: string);
    get length(): number;
    set length(value: number);
    get opacity(): number;
    set opacity(value: number);
    get shift(): number;
    set shift(value: number);
    get visible(): boolean;
    set visible(value: boolean);
    get width(): number;
    set width(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoMinorTickComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoMinorTickComponent, "dxo-minor-tick", never, { "color": { "alias": "color"; "required": false; }; "length": { "alias": "length"; "required": false; }; "opacity": { "alias": "opacity"; "required": false; }; "shift": { "alias": "shift"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoMinorTickModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoMinorTickModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoMinorTickModule, never, [typeof DxoMinorTickComponent], [typeof DxoMinorTickComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoMinorTickModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoMyComponent extends NestedOption implements OnDestroy, OnInit {
    get x(): HorizontalAlignment;
    set x(value: HorizontalAlignment);
    get y(): VerticalAlignment;
    set y(value: VerticalAlignment);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoMyComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoMyComponent, "dxo-my", never, { "x": { "alias": "x"; "required": false; }; "y": { "alias": "y"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoMyModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoMyModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoMyModule, never, [typeof DxoMyComponent], [typeof DxoMyComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoMyModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoNodeComponent extends NestedOption implements OnDestroy, OnInit {
    get border(): {
        color?: string | undefined;
        visible?: boolean | undefined;
        width?: number | undefined;
    };
    set border(value: {
        color?: string | undefined;
        visible?: boolean | undefined;
        width?: number | undefined;
    });
    get color(): string | undefined;
    set color(value: string | undefined);
    get hoverStyle(): {
        border?: {
            color?: string | undefined;
            visible?: boolean | undefined;
            width?: number | undefined;
        };
        color?: string | undefined;
        hatching?: {
            direction?: HatchDirection;
            opacity?: number;
            step?: number;
            width?: number;
        };
        opacity?: number | undefined;
    };
    set hoverStyle(value: {
        border?: {
            color?: string | undefined;
            visible?: boolean | undefined;
            width?: number | undefined;
        };
        color?: string | undefined;
        hatching?: {
            direction?: HatchDirection;
            opacity?: number;
            step?: number;
            width?: number;
        };
        opacity?: number | undefined;
    });
    get opacity(): number;
    set opacity(value: number);
    get padding(): number;
    set padding(value: number);
    get width(): number;
    set width(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoNodeComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoNodeComponent, "dxo-node", never, { "border": { "alias": "border"; "required": false; }; "color": { "alias": "color"; "required": false; }; "hoverStyle": { "alias": "hoverStyle"; "required": false; }; "opacity": { "alias": "opacity"; "required": false; }; "padding": { "alias": "padding"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoNodeModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoNodeModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoNodeModule, never, [typeof DxoNodeComponent], [typeof DxoNodeComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoNodeModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoNodesComponent extends NestedOption implements OnDestroy, OnInit {
    get autoLayout(): DataLayoutType | {
        orientation?: Orientation;
        type?: DataLayoutType;
    };
    set autoLayout(value: DataLayoutType | {
        orientation?: Orientation;
        type?: DataLayoutType;
    });
    get autoSizeEnabled(): boolean;
    set autoSizeEnabled(value: boolean);
    get containerChildrenExpr(): Function | string | undefined;
    set containerChildrenExpr(value: Function | string | undefined);
    get containerKeyExpr(): Function | string;
    set containerKeyExpr(value: Function | string);
    get customDataExpr(): Function | string | undefined;
    set customDataExpr(value: Function | string | undefined);
    get dataSource(): Store | DataSource | Options | null | string | Array<any>;
    set dataSource(value: Store | DataSource | Options | null | string | Array<any>);
    get heightExpr(): Function | string | undefined;
    set heightExpr(value: Function | string | undefined);
    get imageUrlExpr(): Function | string | undefined;
    set imageUrlExpr(value: Function | string | undefined);
    get itemsExpr(): Function | string | undefined;
    set itemsExpr(value: Function | string | undefined);
    get keyExpr(): Function | string;
    set keyExpr(value: Function | string);
    get leftExpr(): Function | string | undefined;
    set leftExpr(value: Function | string | undefined);
    get lockedExpr(): Function | string | undefined;
    set lockedExpr(value: Function | string | undefined);
    get parentKeyExpr(): Function | string | undefined;
    set parentKeyExpr(value: Function | string | undefined);
    get styleExpr(): Function | string | undefined;
    set styleExpr(value: Function | string | undefined);
    get textExpr(): Function | string;
    set textExpr(value: Function | string);
    get textStyleExpr(): Function | string | undefined;
    set textStyleExpr(value: Function | string | undefined);
    get topExpr(): Function | string | undefined;
    set topExpr(value: Function | string | undefined);
    get typeExpr(): Function | string;
    set typeExpr(value: Function | string);
    get widthExpr(): Function | string | undefined;
    set widthExpr(value: Function | string | undefined);
    get zIndexExpr(): Function | string | undefined;
    set zIndexExpr(value: Function | string | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoNodesComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoNodesComponent, "dxo-nodes", never, { "autoLayout": { "alias": "autoLayout"; "required": false; }; "autoSizeEnabled": { "alias": "autoSizeEnabled"; "required": false; }; "containerChildrenExpr": { "alias": "containerChildrenExpr"; "required": false; }; "containerKeyExpr": { "alias": "containerKeyExpr"; "required": false; }; "customDataExpr": { "alias": "customDataExpr"; "required": false; }; "dataSource": { "alias": "dataSource"; "required": false; }; "heightExpr": { "alias": "heightExpr"; "required": false; }; "imageUrlExpr": { "alias": "imageUrlExpr"; "required": false; }; "itemsExpr": { "alias": "itemsExpr"; "required": false; }; "keyExpr": { "alias": "keyExpr"; "required": false; }; "leftExpr": { "alias": "leftExpr"; "required": false; }; "lockedExpr": { "alias": "lockedExpr"; "required": false; }; "parentKeyExpr": { "alias": "parentKeyExpr"; "required": false; }; "styleExpr": { "alias": "styleExpr"; "required": false; }; "textExpr": { "alias": "textExpr"; "required": false; }; "textStyleExpr": { "alias": "textStyleExpr"; "required": false; }; "topExpr": { "alias": "topExpr"; "required": false; }; "typeExpr": { "alias": "typeExpr"; "required": false; }; "widthExpr": { "alias": "widthExpr"; "required": false; }; "zIndexExpr": { "alias": "zIndexExpr"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoNodesModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoNodesModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoNodesModule, never, [typeof DxoNodesComponent], [typeof DxoNodesComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoNodesModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoNotificationsComponent extends NestedOption implements OnDestroy, OnInit {
    get showPanel(): boolean;
    set showPanel(value: boolean);
    get showPopup(): boolean;
    set showPopup(value: boolean);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoNotificationsComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoNotificationsComponent, "dxo-notifications", never, { "showPanel": { "alias": "showPanel"; "required": false; }; "showPopup": { "alias": "showPopup"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoNotificationsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoNotificationsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoNotificationsModule, never, [typeof DxoNotificationsComponent], [typeof DxoNotificationsComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoNotificationsModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoOffsetComponent extends NestedOption implements OnDestroy, OnInit {
    get x(): number;
    set x(value: number);
    get y(): number;
    set y(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoOffsetComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoOffsetComponent, "dxo-offset", never, { "x": { "alias": "x"; "required": false; }; "y": { "alias": "y"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoOffsetModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoOffsetModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoOffsetModule, never, [typeof DxoOffsetComponent], [typeof DxoOffsetComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoOffsetModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare abstract class DxoGanttFilterRowOperationDescriptions extends NestedOption {
    get between(): string;
    set between(value: string);
    get contains(): string;
    set contains(value: string);
    get endsWith(): string;
    set endsWith(value: string);
    get equal(): string;
    set equal(value: string);
    get greaterThan(): string;
    set greaterThan(value: string);
    get greaterThanOrEqual(): string;
    set greaterThanOrEqual(value: string);
    get lessThan(): string;
    set lessThan(value: string);
    get lessThanOrEqual(): string;
    set lessThanOrEqual(value: string);
    get notContains(): string;
    set notContains(value: string);
    get notEqual(): string;
    set notEqual(value: string);
    get startsWith(): string;
    set startsWith(value: string);
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoGanttFilterRowOperationDescriptions, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoGanttFilterRowOperationDescriptions, "ng-component", never, {}, {}, never, never, true, never>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoOperationDescriptionsComponent extends DxoGanttFilterRowOperationDescriptions implements OnDestroy, OnInit {
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoOperationDescriptionsComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoOperationDescriptionsComponent, "dxo-operation-descriptions", never, { "between": { "alias": "between"; "required": false; }; "contains": { "alias": "contains"; "required": false; }; "endsWith": { "alias": "endsWith"; "required": false; }; "equal": { "alias": "equal"; "required": false; }; "greaterThan": { "alias": "greaterThan"; "required": false; }; "greaterThanOrEqual": { "alias": "greaterThanOrEqual"; "required": false; }; "lessThan": { "alias": "lessThan"; "required": false; }; "lessThanOrEqual": { "alias": "lessThanOrEqual"; "required": false; }; "notContains": { "alias": "notContains"; "required": false; }; "notEqual": { "alias": "notEqual"; "required": false; }; "startsWith": { "alias": "startsWith"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoOperationDescriptionsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoOperationDescriptionsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoOperationDescriptionsModule, never, [typeof DxoOperationDescriptionsComponent], [typeof DxoOperationDescriptionsComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoOperationDescriptionsModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoOptionsComponent extends DxoButtonOptions implements OnDestroy, OnInit {
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoOptionsComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoOptionsComponent, "dxo-options", never, { "accessKey": { "alias": "accessKey"; "required": false; }; "activeStateEnabled": { "alias": "activeStateEnabled"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "elementAttr": { "alias": "elementAttr"; "required": false; }; "focusStateEnabled": { "alias": "focusStateEnabled"; "required": false; }; "height": { "alias": "height"; "required": false; }; "hint": { "alias": "hint"; "required": false; }; "hoverStateEnabled": { "alias": "hoverStateEnabled"; "required": false; }; "icon": { "alias": "icon"; "required": false; }; "onClick": { "alias": "onClick"; "required": false; }; "onContentReady": { "alias": "onContentReady"; "required": false; }; "onDisposing": { "alias": "onDisposing"; "required": false; }; "onInitialized": { "alias": "onInitialized"; "required": false; }; "onOptionChanged": { "alias": "onOptionChanged"; "required": false; }; "rtlEnabled": { "alias": "rtlEnabled"; "required": false; }; "stylingMode": { "alias": "stylingMode"; "required": false; }; "tabIndex": { "alias": "tabIndex"; "required": false; }; "template": { "alias": "template"; "required": false; }; "text": { "alias": "text"; "required": false; }; "type": { "alias": "type"; "required": false; }; "useSubmitBehavior": { "alias": "useSubmitBehavior"; "required": false; }; "validationGroup": { "alias": "validationGroup"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoOptionsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoOptionsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoOptionsModule, never, [typeof DxoOptionsComponent], [typeof DxoOptionsComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoOptionsModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoPageSizeComponent extends NestedOption implements OnDestroy, OnInit {
    set _itemsContentChildren(value: QueryList<CollectionNestedOption>);
    get height(): number;
    set height(value: number);
    get items(): Array<any | {
        height?: number;
        text?: string;
        width?: number;
    }>;
    set items(value: Array<any | {
        height?: number;
        text?: string;
        width?: number;
    }>);
    get width(): number;
    set width(value: number);
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    heightChange: EventEmitter<number>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    widthChange: EventEmitter<number>;
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPageSizeComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoPageSizeComponent, "dxo-page-size", never, { "height": { "alias": "height"; "required": false; }; "items": { "alias": "items"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, { "heightChange": "heightChange"; "widthChange": "widthChange"; }, ["_itemsContentChildren"], never, true, never>;
}
declare class DxoPageSizeModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPageSizeModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoPageSizeModule, never, [typeof DxoPageSizeComponent], [typeof DxoPageSizeComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoPageSizeModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare abstract class DxoPager extends NestedOption {
    get allowedPageSizes(): Mode | Array<PagerPageSize | number>;
    set allowedPageSizes(value: Mode | Array<PagerPageSize | number>);
    get displayMode(): DisplayMode;
    set displayMode(value: DisplayMode);
    get infoText(): string;
    set infoText(value: string);
    get label(): string;
    set label(value: string);
    get showInfo(): boolean;
    set showInfo(value: boolean);
    get showNavigationButtons(): boolean;
    set showNavigationButtons(value: boolean);
    get showPageSizeSelector(): Mode | boolean;
    set showPageSizeSelector(value: Mode | boolean);
    get visible(): Mode | boolean;
    set visible(value: Mode | boolean);
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPager, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoPager, "ng-component", never, {}, {}, never, never, true, never>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoPagerComponent extends DxoPager implements OnDestroy, OnInit {
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPagerComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoPagerComponent, "dxo-pager", never, { "allowedPageSizes": { "alias": "allowedPageSizes"; "required": false; }; "displayMode": { "alias": "displayMode"; "required": false; }; "infoText": { "alias": "infoText"; "required": false; }; "label": { "alias": "label"; "required": false; }; "showInfo": { "alias": "showInfo"; "required": false; }; "showNavigationButtons": { "alias": "showNavigationButtons"; "required": false; }; "showPageSizeSelector": { "alias": "showPageSizeSelector"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoPagerModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPagerModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoPagerModule, never, [typeof DxoPagerComponent], [typeof DxoPagerComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoPagerModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoPagingComponent extends NestedOption implements OnDestroy, OnInit {
    get enabled(): boolean;
    set enabled(value: boolean);
    get pageIndex(): number;
    set pageIndex(value: number);
    get pageSize(): number;
    set pageSize(value: number);
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    pageIndexChange: EventEmitter<number>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    pageSizeChange: EventEmitter<number>;
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPagingComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoPagingComponent, "dxo-paging", never, { "enabled": { "alias": "enabled"; "required": false; }; "pageIndex": { "alias": "pageIndex"; "required": false; }; "pageSize": { "alias": "pageSize"; "required": false; }; }, { "pageIndexChange": "pageIndexChange"; "pageSizeChange": "pageSizeChange"; }, never, never, true, never>;
}
declare class DxoPagingModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPagingModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoPagingModule, never, [typeof DxoPagingComponent], [typeof DxoPagingComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoPagingModule>;
}

declare class DxiPaneComponent extends CollectionNestedOption {
    get backgroundColor(): ChartsColor | string;
    set backgroundColor(value: ChartsColor | string);
    get border(): {
        bottom?: boolean;
        color?: string;
        dashStyle?: DashStyle;
        left?: boolean;
        opacity?: number | undefined;
        right?: boolean;
        top?: boolean;
        visible?: boolean;
        width?: number;
    };
    set border(value: {
        bottom?: boolean;
        color?: string;
        dashStyle?: DashStyle;
        left?: boolean;
        opacity?: number | undefined;
        right?: boolean;
        top?: boolean;
        visible?: boolean;
        width?: number;
    });
    get height(): number | string | undefined;
    set height(value: number | string | undefined);
    get name(): string | undefined;
    set name(value: string | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiPaneComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiPaneComponent, "dxi-pane", never, { "backgroundColor": { "alias": "backgroundColor"; "required": false; }; "border": { "alias": "border"; "required": false; }; "height": { "alias": "height"; "required": false; }; "name": { "alias": "name"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxiPaneModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiPaneModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiPaneModule, never, [typeof DxiPaneComponent], [typeof DxiPaneComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiPaneModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoPermissionsComponent extends NestedOption implements OnDestroy, OnInit {
    get copy(): boolean;
    set copy(value: boolean);
    get create(): boolean;
    set create(value: boolean);
    get delete(): boolean;
    set delete(value: boolean);
    get download(): boolean;
    set download(value: boolean);
    get move(): boolean;
    set move(value: boolean);
    get rename(): boolean;
    set rename(value: boolean);
    get upload(): boolean;
    set upload(value: boolean);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPermissionsComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoPermissionsComponent, "dxo-permissions", never, { "copy": { "alias": "copy"; "required": false; }; "create": { "alias": "create"; "required": false; }; "delete": { "alias": "delete"; "required": false; }; "download": { "alias": "download"; "required": false; }; "move": { "alias": "move"; "required": false; }; "rename": { "alias": "rename"; "required": false; }; "upload": { "alias": "upload"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoPermissionsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPermissionsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoPermissionsModule, never, [typeof DxoPermissionsComponent], [typeof DxoPermissionsComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoPermissionsModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoPointComponent extends NestedOption implements OnDestroy, OnInit {
    get border(): {
        color?: string | undefined;
        visible?: boolean;
        width?: number;
    };
    set border(value: {
        color?: string | undefined;
        visible?: boolean;
        width?: number;
    });
    get color(): ChartsColor | string | undefined;
    set color(value: ChartsColor | string | undefined);
    get hoverMode(): PointInteractionMode;
    set hoverMode(value: PointInteractionMode);
    get hoverStyle(): {
        border?: {
            color?: string | undefined;
            visible?: boolean;
            width?: number;
        };
        color?: ChartsColor | string | undefined;
        size?: number | undefined;
    } | {
        border?: {
            color?: string | undefined;
            visible?: boolean;
            width?: number;
        };
        color?: ChartsColor | string | undefined;
        size?: number;
    };
    set hoverStyle(value: {
        border?: {
            color?: string | undefined;
            visible?: boolean;
            width?: number;
        };
        color?: ChartsColor | string | undefined;
        size?: number | undefined;
    } | {
        border?: {
            color?: string | undefined;
            visible?: boolean;
            width?: number;
        };
        color?: ChartsColor | string | undefined;
        size?: number;
    });
    get image(): string | undefined | {
        height?: number | {
            rangeMaxPoint?: number | undefined;
            rangeMinPoint?: number | undefined;
        };
        url?: string | undefined | {
            rangeMaxPoint?: string | undefined;
            rangeMinPoint?: string | undefined;
        };
        width?: number | {
            rangeMaxPoint?: number | undefined;
            rangeMinPoint?: number | undefined;
        };
    } | {
        height?: number;
        url?: string | undefined;
        width?: number;
    };
    set image(value: string | undefined | {
        height?: number | {
            rangeMaxPoint?: number | undefined;
            rangeMinPoint?: number | undefined;
        };
        url?: string | undefined | {
            rangeMaxPoint?: string | undefined;
            rangeMinPoint?: string | undefined;
        };
        width?: number | {
            rangeMaxPoint?: number | undefined;
            rangeMinPoint?: number | undefined;
        };
    } | {
        height?: number;
        url?: string | undefined;
        width?: number;
    });
    get selectionMode(): PointInteractionMode;
    set selectionMode(value: PointInteractionMode);
    get selectionStyle(): {
        border?: {
            color?: string | undefined;
            visible?: boolean;
            width?: number;
        };
        color?: ChartsColor | string | undefined;
        size?: number | undefined;
    } | {
        border?: {
            color?: string | undefined;
            visible?: boolean;
            width?: number;
        };
        color?: ChartsColor | string | undefined;
        size?: number;
    };
    set selectionStyle(value: {
        border?: {
            color?: string | undefined;
            visible?: boolean;
            width?: number;
        };
        color?: ChartsColor | string | undefined;
        size?: number | undefined;
    } | {
        border?: {
            color?: string | undefined;
            visible?: boolean;
            width?: number;
        };
        color?: ChartsColor | string | undefined;
        size?: number;
    });
    get size(): number;
    set size(value: number);
    get symbol(): PointSymbol;
    set symbol(value: PointSymbol);
    get visible(): boolean;
    set visible(value: boolean);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPointComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoPointComponent, "dxo-point", never, { "border": { "alias": "border"; "required": false; }; "color": { "alias": "color"; "required": false; }; "hoverMode": { "alias": "hoverMode"; "required": false; }; "hoverStyle": { "alias": "hoverStyle"; "required": false; }; "image": { "alias": "image"; "required": false; }; "selectionMode": { "alias": "selectionMode"; "required": false; }; "selectionStyle": { "alias": "selectionStyle"; "required": false; }; "size": { "alias": "size"; "required": false; }; "symbol": { "alias": "symbol"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoPointModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPointModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoPointModule, never, [typeof DxoPointComponent], [typeof DxoPointComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoPointModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoPopupComponent extends DxoPopupOptions implements OnDestroy, OnInit {
    set _toolbarItemsContentChildren(value: QueryList<CollectionNestedOption>);
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    heightChange: EventEmitter<number | string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    positionChange: EventEmitter<PositionAlignment | PositionConfig | Function>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    visibleChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    widthChange: EventEmitter<number | string>;
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPopupComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoPopupComponent, "dxo-popup", never, { "accessKey": { "alias": "accessKey"; "required": false; }; "animation": { "alias": "animation"; "required": false; }; "container": { "alias": "container"; "required": false; }; "contentTemplate": { "alias": "contentTemplate"; "required": false; }; "deferRendering": { "alias": "deferRendering"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "dragAndResizeArea": { "alias": "dragAndResizeArea"; "required": false; }; "dragEnabled": { "alias": "dragEnabled"; "required": false; }; "dragOutsideBoundary": { "alias": "dragOutsideBoundary"; "required": false; }; "enableBodyScroll": { "alias": "enableBodyScroll"; "required": false; }; "focusStateEnabled": { "alias": "focusStateEnabled"; "required": false; }; "fullScreen": { "alias": "fullScreen"; "required": false; }; "height": { "alias": "height"; "required": false; }; "hideOnOutsideClick": { "alias": "hideOnOutsideClick"; "required": false; }; "hideOnParentScroll": { "alias": "hideOnParentScroll"; "required": false; }; "hint": { "alias": "hint"; "required": false; }; "hoverStateEnabled": { "alias": "hoverStateEnabled"; "required": false; }; "maxHeight": { "alias": "maxHeight"; "required": false; }; "maxWidth": { "alias": "maxWidth"; "required": false; }; "minHeight": { "alias": "minHeight"; "required": false; }; "minWidth": { "alias": "minWidth"; "required": false; }; "onContentReady": { "alias": "onContentReady"; "required": false; }; "onDisposing": { "alias": "onDisposing"; "required": false; }; "onHidden": { "alias": "onHidden"; "required": false; }; "onHiding": { "alias": "onHiding"; "required": false; }; "onInitialized": { "alias": "onInitialized"; "required": false; }; "onOptionChanged": { "alias": "onOptionChanged"; "required": false; }; "onResize": { "alias": "onResize"; "required": false; }; "onResizeEnd": { "alias": "onResizeEnd"; "required": false; }; "onResizeStart": { "alias": "onResizeStart"; "required": false; }; "onShowing": { "alias": "onShowing"; "required": false; }; "onShown": { "alias": "onShown"; "required": false; }; "onTitleRendered": { "alias": "onTitleRendered"; "required": false; }; "position": { "alias": "position"; "required": false; }; "resizeEnabled": { "alias": "resizeEnabled"; "required": false; }; "restorePosition": { "alias": "restorePosition"; "required": false; }; "rtlEnabled": { "alias": "rtlEnabled"; "required": false; }; "shading": { "alias": "shading"; "required": false; }; "shadingColor": { "alias": "shadingColor"; "required": false; }; "showCloseButton": { "alias": "showCloseButton"; "required": false; }; "showTitle": { "alias": "showTitle"; "required": false; }; "tabIndex": { "alias": "tabIndex"; "required": false; }; "title": { "alias": "title"; "required": false; }; "titleTemplate": { "alias": "titleTemplate"; "required": false; }; "toolbarItems": { "alias": "toolbarItems"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; "wrapperAttr": { "alias": "wrapperAttr"; "required": false; }; }, { "heightChange": "heightChange"; "positionChange": "positionChange"; "visibleChange": "visibleChange"; "widthChange": "widthChange"; }, ["_toolbarItemsContentChildren"], never, true, never>;
}
declare class DxoPopupModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPopupModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoPopupModule, never, [typeof DxoPopupComponent], [typeof DxoPopupComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoPopupModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare abstract class DxoPositionConfig extends NestedOption {
    get at(): PositionAlignment | {
        x?: HorizontalAlignment;
        y?: VerticalAlignment;
    };
    set at(value: PositionAlignment | {
        x?: HorizontalAlignment;
        y?: VerticalAlignment;
    });
    get boundary(): UserDefinedElement | string | Window;
    set boundary(value: UserDefinedElement | string | Window);
    get boundaryOffset(): string | {
        x?: number;
        y?: number;
    };
    set boundaryOffset(value: string | {
        x?: number;
        y?: number;
    });
    get collision(): CollisionResolutionCombination | {
        x?: CollisionResolution;
        y?: CollisionResolution;
    };
    set collision(value: CollisionResolutionCombination | {
        x?: CollisionResolution;
        y?: CollisionResolution;
    });
    get my(): PositionAlignment | {
        x?: HorizontalAlignment;
        y?: VerticalAlignment;
    };
    set my(value: PositionAlignment | {
        x?: HorizontalAlignment;
        y?: VerticalAlignment;
    });
    get of(): UserDefinedElement | string | Window;
    set of(value: UserDefinedElement | string | Window);
    get offset(): string | {
        x?: number;
        y?: number;
    };
    set offset(value: string | {
        x?: number;
        y?: number;
    });
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPositionConfig, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoPositionConfig, "ng-component", never, {}, {}, never, never, true, never>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoPositionComponent extends DxoPositionConfig implements OnDestroy, OnInit {
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPositionComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoPositionComponent, "dxo-position", never, { "at": { "alias": "at"; "required": false; }; "boundary": { "alias": "boundary"; "required": false; }; "boundaryOffset": { "alias": "boundaryOffset"; "required": false; }; "collision": { "alias": "collision"; "required": false; }; "my": { "alias": "my"; "required": false; }; "of": { "alias": "of"; "required": false; }; "offset": { "alias": "offset"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoPositionModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPositionModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoPositionModule, never, [typeof DxoPositionComponent], [typeof DxoPositionComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoPositionModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare abstract class DxoVectorMapProjectionConfig extends NestedOption {
    get aspectRatio(): number;
    set aspectRatio(value: number);
    get from(): Function;
    set from(value: Function);
    get to(): Function;
    set to(value: Function);
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoVectorMapProjectionConfig, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoVectorMapProjectionConfig, "ng-component", never, {}, {}, never, never, true, never>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoProjectionComponent extends DxoVectorMapProjectionConfig implements OnDestroy, OnInit {
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoProjectionComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoProjectionComponent, "dxo-projection", never, { "aspectRatio": { "alias": "aspectRatio"; "required": false; }; "from": { "alias": "from"; "required": false; }; "to": { "alias": "to"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoProjectionModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoProjectionModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoProjectionModule, never, [typeof DxoProjectionComponent], [typeof DxoProjectionComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoProjectionModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoPropertiesPanelComponent extends NestedOption implements OnDestroy, OnInit {
    set _tabsContentChildren(value: QueryList<CollectionNestedOption>);
    get tabs(): Array<any | {
        commands?: Array<CustomCommand | Command>;
        groups?: Array<any | {
            commands?: Array<CustomCommand | Command>;
            title?: string;
        }>;
        title?: string;
    }>;
    set tabs(value: Array<any | {
        commands?: Array<CustomCommand | Command>;
        groups?: Array<any | {
            commands?: Array<CustomCommand | Command>;
            title?: string;
        }>;
        title?: string;
    }>);
    get visibility(): PanelVisibility;
    set visibility(value: PanelVisibility);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPropertiesPanelComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoPropertiesPanelComponent, "dxo-properties-panel", never, { "tabs": { "alias": "tabs"; "required": false; }; "visibility": { "alias": "visibility"; "required": false; }; }, {}, ["_tabsContentChildren"], never, true, never>;
}
declare class DxoPropertiesPanelModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPropertiesPanelModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoPropertiesPanelModule, never, [typeof DxoPropertiesPanelComponent], [typeof DxoPropertiesPanelComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoPropertiesPanelModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoProviderConfigComponent extends NestedOption implements OnDestroy, OnInit {
    get mapId(): string;
    set mapId(value: string);
    get useAdvancedMarkers(): boolean;
    set useAdvancedMarkers(value: boolean);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoProviderConfigComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoProviderConfigComponent, "dxo-provider-config", never, { "mapId": { "alias": "mapId"; "required": false; }; "useAdvancedMarkers": { "alias": "useAdvancedMarkers"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoProviderConfigModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoProviderConfigModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoProviderConfigModule, never, [typeof DxoProviderConfigComponent], [typeof DxoProviderConfigComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoProviderConfigModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoRangeContainerComponent extends NestedOption implements OnDestroy, OnInit {
    set _rangesContentChildren(value: QueryList<CollectionNestedOption>);
    get backgroundColor(): ChartsColor | string;
    set backgroundColor(value: ChartsColor | string);
    get offset(): number;
    set offset(value: number);
    get orientation(): CircularGaugeElementOrientation;
    set orientation(value: CircularGaugeElementOrientation);
    get palette(): Palette | string | Array<string>;
    set palette(value: Palette | string | Array<string>);
    get paletteExtensionMode(): PaletteExtensionMode;
    set paletteExtensionMode(value: PaletteExtensionMode);
    get ranges(): Array<any | {
        color?: ChartsColor | string;
        endValue?: number;
        startValue?: number;
    }>;
    set ranges(value: Array<any | {
        color?: ChartsColor | string;
        endValue?: number;
        startValue?: number;
    }>);
    get width(): number | {
        end?: number;
        start?: number;
    };
    set width(value: number | {
        end?: number;
        start?: number;
    });
    get horizontalOrientation(): HorizontalAlignment;
    set horizontalOrientation(value: HorizontalAlignment);
    get verticalOrientation(): VerticalAlignment;
    set verticalOrientation(value: VerticalAlignment);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoRangeContainerComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoRangeContainerComponent, "dxo-range-container", never, { "backgroundColor": { "alias": "backgroundColor"; "required": false; }; "offset": { "alias": "offset"; "required": false; }; "orientation": { "alias": "orientation"; "required": false; }; "palette": { "alias": "palette"; "required": false; }; "paletteExtensionMode": { "alias": "paletteExtensionMode"; "required": false; }; "ranges": { "alias": "ranges"; "required": false; }; "width": { "alias": "width"; "required": false; }; "horizontalOrientation": { "alias": "horizontalOrientation"; "required": false; }; "verticalOrientation": { "alias": "verticalOrientation"; "required": false; }; }, {}, ["_rangesContentChildren"], never, true, never>;
}
declare class DxoRangeContainerModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoRangeContainerModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoRangeContainerModule, never, [typeof DxoRangeContainerComponent], [typeof DxoRangeContainerComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoRangeContainerModule>;
}

declare class DxiRangeComponent extends CollectionNestedOption {
    get color(): ChartsColor | string;
    set color(value: ChartsColor | string);
    get endValue(): number;
    set endValue(value: number);
    get startValue(): number;
    set startValue(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiRangeComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiRangeComponent, "dxi-range", never, { "color": { "alias": "color"; "required": false; }; "endValue": { "alias": "endValue"; "required": false; }; "startValue": { "alias": "startValue"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxiRangeModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiRangeModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiRangeModule, never, [typeof DxiRangeComponent], [typeof DxiRangeComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiRangeModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoRangeareaComponent extends DxoChartCommonSeriesSettings implements OnDestroy, OnInit {
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoRangeareaComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoRangeareaComponent, "dxo-rangearea", never, { "aggregation": { "alias": "aggregation"; "required": false; }; "area": { "alias": "area"; "required": false; }; "argumentField": { "alias": "argumentField"; "required": false; }; "axis": { "alias": "axis"; "required": false; }; "bar": { "alias": "bar"; "required": false; }; "barOverlapGroup": { "alias": "barOverlapGroup"; "required": false; }; "barPadding": { "alias": "barPadding"; "required": false; }; "barWidth": { "alias": "barWidth"; "required": false; }; "border": { "alias": "border"; "required": false; }; "bubble": { "alias": "bubble"; "required": false; }; "candlestick": { "alias": "candlestick"; "required": false; }; "closeValueField": { "alias": "closeValueField"; "required": false; }; "color": { "alias": "color"; "required": false; }; "cornerRadius": { "alias": "cornerRadius"; "required": false; }; "dashStyle": { "alias": "dashStyle"; "required": false; }; "fullstackedarea": { "alias": "fullstackedarea"; "required": false; }; "fullstackedbar": { "alias": "fullstackedbar"; "required": false; }; "fullstackedline": { "alias": "fullstackedline"; "required": false; }; "fullstackedspline": { "alias": "fullstackedspline"; "required": false; }; "fullstackedsplinearea": { "alias": "fullstackedsplinearea"; "required": false; }; "highValueField": { "alias": "highValueField"; "required": false; }; "hoverMode": { "alias": "hoverMode"; "required": false; }; "hoverStyle": { "alias": "hoverStyle"; "required": false; }; "ignoreEmptyPoints": { "alias": "ignoreEmptyPoints"; "required": false; }; "innerColor": { "alias": "innerColor"; "required": false; }; "label": { "alias": "label"; "required": false; }; "line": { "alias": "line"; "required": false; }; "lowValueField": { "alias": "lowValueField"; "required": false; }; "maxLabelCount": { "alias": "maxLabelCount"; "required": false; }; "minBarSize": { "alias": "minBarSize"; "required": false; }; "opacity": { "alias": "opacity"; "required": false; }; "openValueField": { "alias": "openValueField"; "required": false; }; "pane": { "alias": "pane"; "required": false; }; "point": { "alias": "point"; "required": false; }; "rangearea": { "alias": "rangearea"; "required": false; }; "rangebar": { "alias": "rangebar"; "required": false; }; "rangeValue1Field": { "alias": "rangeValue1Field"; "required": false; }; "rangeValue2Field": { "alias": "rangeValue2Field"; "required": false; }; "reduction": { "alias": "reduction"; "required": false; }; "scatter": { "alias": "scatter"; "required": false; }; "selectionMode": { "alias": "selectionMode"; "required": false; }; "selectionStyle": { "alias": "selectionStyle"; "required": false; }; "showInLegend": { "alias": "showInLegend"; "required": false; }; "sizeField": { "alias": "sizeField"; "required": false; }; "spline": { "alias": "spline"; "required": false; }; "splinearea": { "alias": "splinearea"; "required": false; }; "stack": { "alias": "stack"; "required": false; }; "stackedarea": { "alias": "stackedarea"; "required": false; }; "stackedbar": { "alias": "stackedbar"; "required": false; }; "stackedline": { "alias": "stackedline"; "required": false; }; "stackedspline": { "alias": "stackedspline"; "required": false; }; "stackedsplinearea": { "alias": "stackedsplinearea"; "required": false; }; "steparea": { "alias": "steparea"; "required": false; }; "stepline": { "alias": "stepline"; "required": false; }; "stock": { "alias": "stock"; "required": false; }; "tagField": { "alias": "tagField"; "required": false; }; "type": { "alias": "type"; "required": false; }; "valueErrorBar": { "alias": "valueErrorBar"; "required": false; }; "valueField": { "alias": "valueField"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoRangeareaModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoRangeareaModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoRangeareaModule, never, [typeof DxoRangeareaComponent], [typeof DxoRangeareaComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoRangeareaModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoRangebarComponent extends DxoChartCommonSeriesSettings implements OnDestroy, OnInit {
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoRangebarComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoRangebarComponent, "dxo-rangebar", never, { "aggregation": { "alias": "aggregation"; "required": false; }; "area": { "alias": "area"; "required": false; }; "argumentField": { "alias": "argumentField"; "required": false; }; "axis": { "alias": "axis"; "required": false; }; "bar": { "alias": "bar"; "required": false; }; "barOverlapGroup": { "alias": "barOverlapGroup"; "required": false; }; "barPadding": { "alias": "barPadding"; "required": false; }; "barWidth": { "alias": "barWidth"; "required": false; }; "border": { "alias": "border"; "required": false; }; "bubble": { "alias": "bubble"; "required": false; }; "candlestick": { "alias": "candlestick"; "required": false; }; "closeValueField": { "alias": "closeValueField"; "required": false; }; "color": { "alias": "color"; "required": false; }; "cornerRadius": { "alias": "cornerRadius"; "required": false; }; "dashStyle": { "alias": "dashStyle"; "required": false; }; "fullstackedarea": { "alias": "fullstackedarea"; "required": false; }; "fullstackedbar": { "alias": "fullstackedbar"; "required": false; }; "fullstackedline": { "alias": "fullstackedline"; "required": false; }; "fullstackedspline": { "alias": "fullstackedspline"; "required": false; }; "fullstackedsplinearea": { "alias": "fullstackedsplinearea"; "required": false; }; "highValueField": { "alias": "highValueField"; "required": false; }; "hoverMode": { "alias": "hoverMode"; "required": false; }; "hoverStyle": { "alias": "hoverStyle"; "required": false; }; "ignoreEmptyPoints": { "alias": "ignoreEmptyPoints"; "required": false; }; "innerColor": { "alias": "innerColor"; "required": false; }; "label": { "alias": "label"; "required": false; }; "line": { "alias": "line"; "required": false; }; "lowValueField": { "alias": "lowValueField"; "required": false; }; "maxLabelCount": { "alias": "maxLabelCount"; "required": false; }; "minBarSize": { "alias": "minBarSize"; "required": false; }; "opacity": { "alias": "opacity"; "required": false; }; "openValueField": { "alias": "openValueField"; "required": false; }; "pane": { "alias": "pane"; "required": false; }; "point": { "alias": "point"; "required": false; }; "rangearea": { "alias": "rangearea"; "required": false; }; "rangebar": { "alias": "rangebar"; "required": false; }; "rangeValue1Field": { "alias": "rangeValue1Field"; "required": false; }; "rangeValue2Field": { "alias": "rangeValue2Field"; "required": false; }; "reduction": { "alias": "reduction"; "required": false; }; "scatter": { "alias": "scatter"; "required": false; }; "selectionMode": { "alias": "selectionMode"; "required": false; }; "selectionStyle": { "alias": "selectionStyle"; "required": false; }; "showInLegend": { "alias": "showInLegend"; "required": false; }; "sizeField": { "alias": "sizeField"; "required": false; }; "spline": { "alias": "spline"; "required": false; }; "splinearea": { "alias": "splinearea"; "required": false; }; "stack": { "alias": "stack"; "required": false; }; "stackedarea": { "alias": "stackedarea"; "required": false; }; "stackedbar": { "alias": "stackedbar"; "required": false; }; "stackedline": { "alias": "stackedline"; "required": false; }; "stackedspline": { "alias": "stackedspline"; "required": false; }; "stackedsplinearea": { "alias": "stackedsplinearea"; "required": false; }; "steparea": { "alias": "steparea"; "required": false; }; "stepline": { "alias": "stepline"; "required": false; }; "stock": { "alias": "stock"; "required": false; }; "tagField": { "alias": "tagField"; "required": false; }; "type": { "alias": "type"; "required": false; }; "valueErrorBar": { "alias": "valueErrorBar"; "required": false; }; "valueField": { "alias": "valueField"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoRangebarModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoRangebarModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoRangebarModule, never, [typeof DxoRangebarComponent], [typeof DxoRangebarComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoRangebarModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoReductionComponent extends NestedOption implements OnDestroy, OnInit {
    get color(): string;
    set color(value: string);
    get level(): FinancialChartReductionLevel;
    set level(value: FinancialChartReductionLevel);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoReductionComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoReductionComponent, "dxo-reduction", never, { "color": { "alias": "color"; "required": false; }; "level": { "alias": "level"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoReductionModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoReductionModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoReductionModule, never, [typeof DxoReductionComponent], [typeof DxoReductionComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoReductionModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoRemoteOperationsComponent extends NestedOption implements OnDestroy, OnInit {
    get filtering(): boolean;
    set filtering(value: boolean);
    get grouping(): boolean;
    set grouping(value: boolean);
    get groupPaging(): boolean;
    set groupPaging(value: boolean);
    get paging(): boolean;
    set paging(value: boolean);
    get sorting(): boolean;
    set sorting(value: boolean);
    get summary(): boolean;
    set summary(value: boolean);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoRemoteOperationsComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoRemoteOperationsComponent, "dxo-remote-operations", never, { "filtering": { "alias": "filtering"; "required": false; }; "grouping": { "alias": "grouping"; "required": false; }; "groupPaging": { "alias": "groupPaging"; "required": false; }; "paging": { "alias": "paging"; "required": false; }; "sorting": { "alias": "sorting"; "required": false; }; "summary": { "alias": "summary"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoRemoteOperationsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoRemoteOperationsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoRemoteOperationsModule, never, [typeof DxoRemoteOperationsComponent], [typeof DxoRemoteOperationsComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoRemoteOperationsModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoResourceAssignmentsComponent extends NestedOption implements OnDestroy, OnInit {
    get dataSource(): Store | DataSource | Options | null | string | Array<any>;
    set dataSource(value: Store | DataSource | Options | null | string | Array<any>);
    get keyExpr(): Function | string;
    set keyExpr(value: Function | string);
    get resourceIdExpr(): Function | string;
    set resourceIdExpr(value: Function | string);
    get taskIdExpr(): Function | string;
    set taskIdExpr(value: Function | string);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoResourceAssignmentsComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoResourceAssignmentsComponent, "dxo-resource-assignments", never, { "dataSource": { "alias": "dataSource"; "required": false; }; "keyExpr": { "alias": "keyExpr"; "required": false; }; "resourceIdExpr": { "alias": "resourceIdExpr"; "required": false; }; "taskIdExpr": { "alias": "taskIdExpr"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoResourceAssignmentsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoResourceAssignmentsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoResourceAssignmentsModule, never, [typeof DxoResourceAssignmentsComponent], [typeof DxoResourceAssignmentsComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoResourceAssignmentsModule>;
}

declare class DxiResourceComponent extends CollectionNestedOption {
    get allowMultiple(): boolean;
    set allowMultiple(value: boolean);
    get colorExpr(): string;
    set colorExpr(value: string);
    get dataSource(): Store | DataSource | Options | null | string | Array<any>;
    set dataSource(value: Store | DataSource | Options | null | string | Array<any>);
    get displayExpr(): Function | string;
    set displayExpr(value: Function | string);
    get fieldExpr(): string;
    set fieldExpr(value: string);
    get label(): string;
    set label(value: string);
    get useColorAsDefault(): boolean;
    set useColorAsDefault(value: boolean);
    get valueExpr(): Function | string;
    set valueExpr(value: Function | string);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiResourceComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiResourceComponent, "dxi-resource", never, { "allowMultiple": { "alias": "allowMultiple"; "required": false; }; "colorExpr": { "alias": "colorExpr"; "required": false; }; "dataSource": { "alias": "dataSource"; "required": false; }; "displayExpr": { "alias": "displayExpr"; "required": false; }; "fieldExpr": { "alias": "fieldExpr"; "required": false; }; "label": { "alias": "label"; "required": false; }; "useColorAsDefault": { "alias": "useColorAsDefault"; "required": false; }; "valueExpr": { "alias": "valueExpr"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxiResourceModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiResourceModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiResourceModule, never, [typeof DxiResourceComponent], [typeof DxiResourceComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiResourceModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoResourcesComponent extends NestedOption implements OnDestroy, OnInit {
    get colorExpr(): Function | string;
    set colorExpr(value: Function | string);
    get dataSource(): Store | DataSource | Options | null | string | Array<any>;
    set dataSource(value: Store | DataSource | Options | null | string | Array<any>);
    get keyExpr(): Function | string;
    set keyExpr(value: Function | string);
    get textExpr(): Function | string;
    set textExpr(value: Function | string);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoResourcesComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoResourcesComponent, "dxo-resources", never, { "colorExpr": { "alias": "colorExpr"; "required": false; }; "dataSource": { "alias": "dataSource"; "required": false; }; "keyExpr": { "alias": "keyExpr"; "required": false; }; "textExpr": { "alias": "textExpr"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoResourcesModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoResourcesModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoResourcesModule, never, [typeof DxoResourcesComponent], [typeof DxoResourcesComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoResourcesModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxiRouteComponent extends CollectionNestedOption {
    set _locationsContentChildren(value: QueryList<CollectionNestedOption>);
    get color(): string;
    set color(value: string);
    get locations(): Array<any | {
        lat?: number;
        lng?: number;
    }>;
    set locations(value: Array<any | {
        lat?: number;
        lng?: number;
    }>);
    get mode(): RouteMode | string;
    set mode(value: RouteMode | string);
    get opacity(): number;
    set opacity(value: number);
    get weight(): number;
    set weight(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiRouteComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiRouteComponent, "dxi-route", never, { "color": { "alias": "color"; "required": false; }; "locations": { "alias": "locations"; "required": false; }; "mode": { "alias": "mode"; "required": false; }; "opacity": { "alias": "opacity"; "required": false; }; "weight": { "alias": "weight"; "required": false; }; }, {}, ["_locationsContentChildren"], never, true, never>;
}
declare class DxiRouteModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiRouteModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiRouteModule, never, [typeof DxiRouteComponent], [typeof DxiRouteComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiRouteModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoRowDraggingComponent extends NestedOption implements OnDestroy, OnInit {
    get allowDropInsideItem(): boolean;
    set allowDropInsideItem(value: boolean);
    get allowReordering(): boolean;
    set allowReordering(value: boolean);
    get autoScroll(): boolean;
    set autoScroll(value: boolean);
    get boundary(): UserDefinedElement | string | undefined;
    set boundary(value: UserDefinedElement | string | undefined);
    get container(): UserDefinedElement | string | undefined;
    set container(value: UserDefinedElement | string | undefined);
    get cursorOffset(): string | {
        x?: number;
        y?: number;
    };
    set cursorOffset(value: string | {
        x?: number;
        y?: number;
    });
    get data(): any | undefined;
    set data(value: any | undefined);
    get dragDirection(): DragDirection;
    set dragDirection(value: DragDirection);
    get dragTemplate(): any | undefined;
    set dragTemplate(value: any | undefined);
    get dropFeedbackMode(): DragHighlight;
    set dropFeedbackMode(value: DragHighlight);
    get filter(): string;
    set filter(value: string);
    get group(): string | undefined;
    set group(value: string | undefined);
    get handle(): string;
    set handle(value: string);
    get onAdd(): Function;
    set onAdd(value: Function);
    get onDragChange(): Function;
    set onDragChange(value: Function);
    get onDragEnd(): Function;
    set onDragEnd(value: Function);
    get onDragMove(): Function;
    set onDragMove(value: Function);
    get onDragStart(): Function;
    set onDragStart(value: Function);
    get onRemove(): Function;
    set onRemove(value: Function);
    get onReorder(): Function;
    set onReorder(value: Function);
    get scrollSensitivity(): number;
    set scrollSensitivity(value: number);
    get scrollSpeed(): number;
    set scrollSpeed(value: number);
    get showDragIcons(): boolean;
    set showDragIcons(value: boolean);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoRowDraggingComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoRowDraggingComponent, "dxo-row-dragging", never, { "allowDropInsideItem": { "alias": "allowDropInsideItem"; "required": false; }; "allowReordering": { "alias": "allowReordering"; "required": false; }; "autoScroll": { "alias": "autoScroll"; "required": false; }; "boundary": { "alias": "boundary"; "required": false; }; "container": { "alias": "container"; "required": false; }; "cursorOffset": { "alias": "cursorOffset"; "required": false; }; "data": { "alias": "data"; "required": false; }; "dragDirection": { "alias": "dragDirection"; "required": false; }; "dragTemplate": { "alias": "dragTemplate"; "required": false; }; "dropFeedbackMode": { "alias": "dropFeedbackMode"; "required": false; }; "filter": { "alias": "filter"; "required": false; }; "group": { "alias": "group"; "required": false; }; "handle": { "alias": "handle"; "required": false; }; "onAdd": { "alias": "onAdd"; "required": false; }; "onDragChange": { "alias": "onDragChange"; "required": false; }; "onDragEnd": { "alias": "onDragEnd"; "required": false; }; "onDragMove": { "alias": "onDragMove"; "required": false; }; "onDragStart": { "alias": "onDragStart"; "required": false; }; "onRemove": { "alias": "onRemove"; "required": false; }; "onReorder": { "alias": "onReorder"; "required": false; }; "scrollSensitivity": { "alias": "scrollSensitivity"; "required": false; }; "scrollSpeed": { "alias": "scrollSpeed"; "required": false; }; "showDragIcons": { "alias": "showDragIcons"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoRowDraggingModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoRowDraggingModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoRowDraggingModule, never, [typeof DxoRowDraggingComponent], [typeof DxoRowDraggingComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoRowDraggingModule>;
}

declare class DxiRowComponent extends CollectionNestedOption {
    get baseSize(): number | string;
    set baseSize(value: number | string);
    get ratio(): number;
    set ratio(value: number);
    get screen(): string | undefined;
    set screen(value: string | undefined);
    get shrink(): number;
    set shrink(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiRowComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiRowComponent, "dxi-row", never, { "baseSize": { "alias": "baseSize"; "required": false; }; "ratio": { "alias": "ratio"; "required": false; }; "screen": { "alias": "screen"; "required": false; }; "shrink": { "alias": "shrink"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxiRowModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiRowModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiRowModule, never, [typeof DxiRowComponent], [typeof DxiRowComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiRowModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoScaleTypeRangeComponent extends NestedOption implements OnDestroy, OnInit {
    get max(): GanttScaleType;
    set max(value: GanttScaleType);
    get min(): GanttScaleType;
    set min(value: GanttScaleType);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoScaleTypeRangeComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoScaleTypeRangeComponent, "dxo-scale-type-range", never, { "max": { "alias": "max"; "required": false; }; "min": { "alias": "min"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoScaleTypeRangeModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoScaleTypeRangeModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoScaleTypeRangeModule, never, [typeof DxoScaleTypeRangeComponent], [typeof DxoScaleTypeRangeComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoScaleTypeRangeModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoScaleComponent extends NestedOption implements OnDestroy, OnInit {
    set _breaksContentChildren(value: QueryList<CollectionNestedOption>);
    get allowDecimals(): boolean | undefined;
    set allowDecimals(value: boolean | undefined);
    get customMinorTicks(): undefined | Array<number>;
    set customMinorTicks(value: undefined | Array<number>);
    get customTicks(): undefined | Array<number>;
    set customTicks(value: undefined | Array<number>);
    get endValue(): number | Date | string | undefined;
    set endValue(value: number | Date | string | undefined);
    get label(): {
        customizeText?: Function;
        font?: Font;
        format?: Format | string | undefined;
        hideFirstOrLast?: CircularGaugeLabelOverlap;
        indentFromTick?: number;
        overlappingBehavior?: LabelOverlap;
        useRangeColors?: boolean;
        visible?: boolean;
    } | {
        customizeText?: Function;
        font?: Font;
        format?: Format | string | undefined;
        indentFromTick?: number;
        overlappingBehavior?: LabelOverlap;
        useRangeColors?: boolean;
        visible?: boolean;
    } | {
        customizeText?: Function;
        font?: Font;
        format?: Format | string | undefined;
        overlappingBehavior?: LabelOverlap;
        topIndent?: number;
        visible?: boolean;
    };
    set label(value: {
        customizeText?: Function;
        font?: Font;
        format?: Format | string | undefined;
        hideFirstOrLast?: CircularGaugeLabelOverlap;
        indentFromTick?: number;
        overlappingBehavior?: LabelOverlap;
        useRangeColors?: boolean;
        visible?: boolean;
    } | {
        customizeText?: Function;
        font?: Font;
        format?: Format | string | undefined;
        indentFromTick?: number;
        overlappingBehavior?: LabelOverlap;
        useRangeColors?: boolean;
        visible?: boolean;
    } | {
        customizeText?: Function;
        font?: Font;
        format?: Format | string | undefined;
        overlappingBehavior?: LabelOverlap;
        topIndent?: number;
        visible?: boolean;
    });
    get minorTick(): {
        color?: string;
        length?: number;
        opacity?: number;
        visible?: boolean;
        width?: number;
    } | {
        color?: string;
        opacity?: number;
        visible?: boolean;
        width?: number;
    };
    set minorTick(value: {
        color?: string;
        length?: number;
        opacity?: number;
        visible?: boolean;
        width?: number;
    } | {
        color?: string;
        opacity?: number;
        visible?: boolean;
        width?: number;
    });
    get minorTickInterval(): number | undefined | TimeInterval | {
        days?: number;
        hours?: number;
        milliseconds?: number;
        minutes?: number;
        months?: number;
        quarters?: number;
        seconds?: number;
        weeks?: number;
        years?: number;
    };
    set minorTickInterval(value: number | undefined | TimeInterval | {
        days?: number;
        hours?: number;
        milliseconds?: number;
        minutes?: number;
        months?: number;
        quarters?: number;
        seconds?: number;
        weeks?: number;
        years?: number;
    });
    get orientation(): CircularGaugeElementOrientation;
    set orientation(value: CircularGaugeElementOrientation);
    get scaleDivisionFactor(): number;
    set scaleDivisionFactor(value: number);
    get startValue(): number | Date | string | undefined;
    set startValue(value: number | Date | string | undefined);
    get tick(): {
        color?: string;
        length?: number;
        opacity?: number;
        visible?: boolean;
        width?: number;
    } | {
        color?: string;
        opacity?: number;
        width?: number;
    };
    set tick(value: {
        color?: string;
        length?: number;
        opacity?: number;
        visible?: boolean;
        width?: number;
    } | {
        color?: string;
        opacity?: number;
        width?: number;
    });
    get tickInterval(): number | undefined | TimeInterval | {
        days?: number;
        hours?: number;
        milliseconds?: number;
        minutes?: number;
        months?: number;
        quarters?: number;
        seconds?: number;
        weeks?: number;
        years?: number;
    };
    set tickInterval(value: number | undefined | TimeInterval | {
        days?: number;
        hours?: number;
        milliseconds?: number;
        minutes?: number;
        months?: number;
        quarters?: number;
        seconds?: number;
        weeks?: number;
        years?: number;
    });
    get horizontalOrientation(): HorizontalAlignment;
    set horizontalOrientation(value: HorizontalAlignment);
    get verticalOrientation(): VerticalAlignment;
    set verticalOrientation(value: VerticalAlignment);
    get aggregationGroupWidth(): number | undefined;
    set aggregationGroupWidth(value: number | undefined);
    get aggregationInterval(): TimeInterval | number | {
        days?: number;
        hours?: number;
        milliseconds?: number;
        minutes?: number;
        months?: number;
        quarters?: number;
        seconds?: number;
        weeks?: number;
        years?: number;
    };
    set aggregationInterval(value: TimeInterval | number | {
        days?: number;
        hours?: number;
        milliseconds?: number;
        minutes?: number;
        months?: number;
        quarters?: number;
        seconds?: number;
        weeks?: number;
        years?: number;
    });
    get breaks(): undefined | Array<ScaleBreak>;
    set breaks(value: undefined | Array<ScaleBreak>);
    get breakStyle(): {
        color?: string;
        line?: ScaleBreakLineStyle;
        width?: number;
    };
    set breakStyle(value: {
        color?: string;
        line?: ScaleBreakLineStyle;
        width?: number;
    });
    get categories(): Array<number | string | Date>;
    set categories(value: Array<number | string | Date>);
    get discreteAxisDivisionMode(): DiscreteAxisDivisionMode;
    set discreteAxisDivisionMode(value: DiscreteAxisDivisionMode);
    get endOnTick(): boolean;
    set endOnTick(value: boolean);
    get holidays(): undefined | Array<Date | string | number>;
    set holidays(value: undefined | Array<Date | string | number>);
    get linearThreshold(): number;
    set linearThreshold(value: number);
    get logarithmBase(): number;
    set logarithmBase(value: number);
    get marker(): {
        label?: {
            customizeText?: Function;
            format?: Format | string | undefined;
        };
        separatorHeight?: number;
        textLeftIndent?: number;
        textTopIndent?: number;
        topIndent?: number;
        visible?: boolean;
    };
    set marker(value: {
        label?: {
            customizeText?: Function;
            format?: Format | string | undefined;
        };
        separatorHeight?: number;
        textLeftIndent?: number;
        textTopIndent?: number;
        topIndent?: number;
        visible?: boolean;
    });
    get maxRange(): TimeInterval | number | {
        days?: number;
        hours?: number;
        milliseconds?: number;
        minutes?: number;
        months?: number;
        quarters?: number;
        seconds?: number;
        weeks?: number;
        years?: number;
    };
    set maxRange(value: TimeInterval | number | {
        days?: number;
        hours?: number;
        milliseconds?: number;
        minutes?: number;
        months?: number;
        quarters?: number;
        seconds?: number;
        weeks?: number;
        years?: number;
    });
    get minorTickCount(): number | undefined;
    set minorTickCount(value: number | undefined);
    get minRange(): TimeInterval | number | {
        days?: number;
        hours?: number;
        milliseconds?: number;
        minutes?: number;
        months?: number;
        quarters?: number;
        seconds?: number;
        weeks?: number;
        years?: number;
    };
    set minRange(value: TimeInterval | number | {
        days?: number;
        hours?: number;
        milliseconds?: number;
        minutes?: number;
        months?: number;
        quarters?: number;
        seconds?: number;
        weeks?: number;
        years?: number;
    });
    get placeholderHeight(): number | undefined;
    set placeholderHeight(value: number | undefined);
    get showCustomBoundaryTicks(): boolean;
    set showCustomBoundaryTicks(value: boolean);
    get singleWorkdays(): undefined | Array<Date | string | number>;
    set singleWorkdays(value: undefined | Array<Date | string | number>);
    get type(): AxisScale | undefined;
    set type(value: AxisScale | undefined);
    get valueType(): ChartsDataType | undefined;
    set valueType(value: ChartsDataType | undefined);
    get workdaysOnly(): boolean;
    set workdaysOnly(value: boolean);
    get workWeek(): Array<number>;
    set workWeek(value: Array<number>);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoScaleComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoScaleComponent, "dxo-scale", never, { "allowDecimals": { "alias": "allowDecimals"; "required": false; }; "customMinorTicks": { "alias": "customMinorTicks"; "required": false; }; "customTicks": { "alias": "customTicks"; "required": false; }; "endValue": { "alias": "endValue"; "required": false; }; "label": { "alias": "label"; "required": false; }; "minorTick": { "alias": "minorTick"; "required": false; }; "minorTickInterval": { "alias": "minorTickInterval"; "required": false; }; "orientation": { "alias": "orientation"; "required": false; }; "scaleDivisionFactor": { "alias": "scaleDivisionFactor"; "required": false; }; "startValue": { "alias": "startValue"; "required": false; }; "tick": { "alias": "tick"; "required": false; }; "tickInterval": { "alias": "tickInterval"; "required": false; }; "horizontalOrientation": { "alias": "horizontalOrientation"; "required": false; }; "verticalOrientation": { "alias": "verticalOrientation"; "required": false; }; "aggregationGroupWidth": { "alias": "aggregationGroupWidth"; "required": false; }; "aggregationInterval": { "alias": "aggregationInterval"; "required": false; }; "breaks": { "alias": "breaks"; "required": false; }; "breakStyle": { "alias": "breakStyle"; "required": false; }; "categories": { "alias": "categories"; "required": false; }; "discreteAxisDivisionMode": { "alias": "discreteAxisDivisionMode"; "required": false; }; "endOnTick": { "alias": "endOnTick"; "required": false; }; "holidays": { "alias": "holidays"; "required": false; }; "linearThreshold": { "alias": "linearThreshold"; "required": false; }; "logarithmBase": { "alias": "logarithmBase"; "required": false; }; "marker": { "alias": "marker"; "required": false; }; "maxRange": { "alias": "maxRange"; "required": false; }; "minorTickCount": { "alias": "minorTickCount"; "required": false; }; "minRange": { "alias": "minRange"; "required": false; }; "placeholderHeight": { "alias": "placeholderHeight"; "required": false; }; "showCustomBoundaryTicks": { "alias": "showCustomBoundaryTicks"; "required": false; }; "singleWorkdays": { "alias": "singleWorkdays"; "required": false; }; "type": { "alias": "type"; "required": false; }; "valueType": { "alias": "valueType"; "required": false; }; "workdaysOnly": { "alias": "workdaysOnly"; "required": false; }; "workWeek": { "alias": "workWeek"; "required": false; }; }, {}, ["_breaksContentChildren"], never, true, never>;
}
declare class DxoScaleModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoScaleModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoScaleModule, never, [typeof DxoScaleComponent], [typeof DxoScaleComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoScaleModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoScatterComponent extends DxoChartCommonSeriesSettings implements OnDestroy, OnInit {
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoScatterComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoScatterComponent, "dxo-scatter", never, { "aggregation": { "alias": "aggregation"; "required": false; }; "area": { "alias": "area"; "required": false; }; "argumentField": { "alias": "argumentField"; "required": false; }; "axis": { "alias": "axis"; "required": false; }; "bar": { "alias": "bar"; "required": false; }; "barOverlapGroup": { "alias": "barOverlapGroup"; "required": false; }; "barPadding": { "alias": "barPadding"; "required": false; }; "barWidth": { "alias": "barWidth"; "required": false; }; "border": { "alias": "border"; "required": false; }; "bubble": { "alias": "bubble"; "required": false; }; "candlestick": { "alias": "candlestick"; "required": false; }; "closeValueField": { "alias": "closeValueField"; "required": false; }; "color": { "alias": "color"; "required": false; }; "cornerRadius": { "alias": "cornerRadius"; "required": false; }; "dashStyle": { "alias": "dashStyle"; "required": false; }; "fullstackedarea": { "alias": "fullstackedarea"; "required": false; }; "fullstackedbar": { "alias": "fullstackedbar"; "required": false; }; "fullstackedline": { "alias": "fullstackedline"; "required": false; }; "fullstackedspline": { "alias": "fullstackedspline"; "required": false; }; "fullstackedsplinearea": { "alias": "fullstackedsplinearea"; "required": false; }; "highValueField": { "alias": "highValueField"; "required": false; }; "hoverMode": { "alias": "hoverMode"; "required": false; }; "hoverStyle": { "alias": "hoverStyle"; "required": false; }; "ignoreEmptyPoints": { "alias": "ignoreEmptyPoints"; "required": false; }; "innerColor": { "alias": "innerColor"; "required": false; }; "label": { "alias": "label"; "required": false; }; "line": { "alias": "line"; "required": false; }; "lowValueField": { "alias": "lowValueField"; "required": false; }; "maxLabelCount": { "alias": "maxLabelCount"; "required": false; }; "minBarSize": { "alias": "minBarSize"; "required": false; }; "opacity": { "alias": "opacity"; "required": false; }; "openValueField": { "alias": "openValueField"; "required": false; }; "pane": { "alias": "pane"; "required": false; }; "point": { "alias": "point"; "required": false; }; "rangearea": { "alias": "rangearea"; "required": false; }; "rangebar": { "alias": "rangebar"; "required": false; }; "rangeValue1Field": { "alias": "rangeValue1Field"; "required": false; }; "rangeValue2Field": { "alias": "rangeValue2Field"; "required": false; }; "reduction": { "alias": "reduction"; "required": false; }; "scatter": { "alias": "scatter"; "required": false; }; "selectionMode": { "alias": "selectionMode"; "required": false; }; "selectionStyle": { "alias": "selectionStyle"; "required": false; }; "showInLegend": { "alias": "showInLegend"; "required": false; }; "sizeField": { "alias": "sizeField"; "required": false; }; "spline": { "alias": "spline"; "required": false; }; "splinearea": { "alias": "splinearea"; "required": false; }; "stack": { "alias": "stack"; "required": false; }; "stackedarea": { "alias": "stackedarea"; "required": false; }; "stackedbar": { "alias": "stackedbar"; "required": false; }; "stackedline": { "alias": "stackedline"; "required": false; }; "stackedspline": { "alias": "stackedspline"; "required": false; }; "stackedsplinearea": { "alias": "stackedsplinearea"; "required": false; }; "steparea": { "alias": "steparea"; "required": false; }; "stepline": { "alias": "stepline"; "required": false; }; "stock": { "alias": "stock"; "required": false; }; "tagField": { "alias": "tagField"; "required": false; }; "type": { "alias": "type"; "required": false; }; "valueErrorBar": { "alias": "valueErrorBar"; "required": false; }; "valueField": { "alias": "valueField"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; "closed": { "alias": "closed"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoScatterModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoScatterModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoScatterModule, never, [typeof DxoScatterComponent], [typeof DxoScatterComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoScatterModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoScrollBarComponent extends NestedOption implements OnDestroy, OnInit {
    get color(): string;
    set color(value: string);
    get offset(): number;
    set offset(value: number);
    get opacity(): number | undefined;
    set opacity(value: number | undefined);
    get position(): Position;
    set position(value: Position);
    get visible(): boolean;
    set visible(value: boolean);
    get width(): number;
    set width(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoScrollBarComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoScrollBarComponent, "dxo-scroll-bar", never, { "color": { "alias": "color"; "required": false; }; "offset": { "alias": "offset"; "required": false; }; "opacity": { "alias": "opacity"; "required": false; }; "position": { "alias": "position"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoScrollBarModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoScrollBarModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoScrollBarModule, never, [typeof DxoScrollBarComponent], [typeof DxoScrollBarComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoScrollBarModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare abstract class DxoSchedulerScrolling extends NestedOption {
    get columnRenderingMode(): DataRenderMode;
    set columnRenderingMode(value: DataRenderMode);
    get mode(): DataGridScrollMode | ScrollMode;
    set mode(value: DataGridScrollMode | ScrollMode);
    get preloadEnabled(): boolean;
    set preloadEnabled(value: boolean);
    get renderAsync(): boolean | undefined;
    set renderAsync(value: boolean | undefined);
    get rowRenderingMode(): DataRenderMode;
    set rowRenderingMode(value: DataRenderMode);
    get scrollByContent(): boolean;
    set scrollByContent(value: boolean);
    get scrollByThumb(): boolean;
    set scrollByThumb(value: boolean);
    get showScrollbar(): ScrollbarMode;
    set showScrollbar(value: ScrollbarMode);
    get useNative(): Mode | boolean;
    set useNative(value: Mode | boolean);
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoSchedulerScrolling, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoSchedulerScrolling, "ng-component", never, {}, {}, never, never, true, never>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoScrollingComponent extends DxoSchedulerScrolling implements OnDestroy, OnInit {
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoScrollingComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoScrollingComponent, "dxo-scrolling", never, { "columnRenderingMode": { "alias": "columnRenderingMode"; "required": false; }; "mode": { "alias": "mode"; "required": false; }; "preloadEnabled": { "alias": "preloadEnabled"; "required": false; }; "renderAsync": { "alias": "renderAsync"; "required": false; }; "rowRenderingMode": { "alias": "rowRenderingMode"; "required": false; }; "scrollByContent": { "alias": "scrollByContent"; "required": false; }; "scrollByThumb": { "alias": "scrollByThumb"; "required": false; }; "showScrollbar": { "alias": "showScrollbar"; "required": false; }; "useNative": { "alias": "useNative"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoScrollingModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoScrollingModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoScrollingModule, never, [typeof DxoScrollingComponent], [typeof DxoScrollingComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoScrollingModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare abstract class DxoTextBoxOptions extends NestedOption {
    get accessKey(): string | undefined;
    set accessKey(value: string | undefined);
    get activeStateEnabled(): boolean;
    set activeStateEnabled(value: boolean);
    get buttons(): undefined | Array<TextBoxPredefinedButton | TextEditorButton | string>;
    set buttons(value: undefined | Array<TextBoxPredefinedButton | TextEditorButton | string>);
    get disabled(): boolean;
    set disabled(value: boolean);
    get elementAttr(): any;
    set elementAttr(value: any);
    get focusStateEnabled(): boolean;
    set focusStateEnabled(value: boolean);
    get height(): number | string | undefined;
    set height(value: number | string | undefined);
    get hint(): string | undefined;
    set hint(value: string | undefined);
    get hoverStateEnabled(): boolean;
    set hoverStateEnabled(value: boolean);
    get inputAttr(): any;
    set inputAttr(value: any);
    get isDirty(): boolean;
    set isDirty(value: boolean);
    get isValid(): boolean;
    set isValid(value: boolean);
    get label(): string;
    set label(value: string);
    get labelMode(): LabelMode;
    set labelMode(value: LabelMode);
    get mask(): string;
    set mask(value: string);
    get maskChar(): string;
    set maskChar(value: string);
    get maskInvalidMessage(): string;
    set maskInvalidMessage(value: string);
    get maskRules(): any;
    set maskRules(value: any);
    get maxLength(): number | null | string;
    set maxLength(value: number | null | string);
    get mode(): TextBoxType;
    set mode(value: TextBoxType);
    get name(): string;
    set name(value: string);
    get onChange(): ((e: ChangeEvent) => void);
    set onChange(value: ((e: ChangeEvent) => void));
    get onContentReady(): ((e: ContentReadyEvent$5) => void);
    set onContentReady(value: ((e: ContentReadyEvent$5) => void));
    get onCopy(): ((e: CopyEvent) => void);
    set onCopy(value: ((e: CopyEvent) => void));
    get onCut(): ((e: CutEvent) => void);
    set onCut(value: ((e: CutEvent) => void));
    get onDisposing(): ((e: DisposingEvent$7) => void);
    set onDisposing(value: ((e: DisposingEvent$7) => void));
    get onEnterKey(): ((e: EnterKeyEvent) => void);
    set onEnterKey(value: ((e: EnterKeyEvent) => void));
    get onFocusIn(): ((e: FocusInEvent) => void);
    set onFocusIn(value: ((e: FocusInEvent) => void));
    get onFocusOut(): ((e: FocusOutEvent) => void);
    set onFocusOut(value: ((e: FocusOutEvent) => void));
    get onInitialized(): ((e: InitializedEvent$7) => void);
    set onInitialized(value: ((e: InitializedEvent$7) => void));
    get onInput(): ((e: InputEvent) => void);
    set onInput(value: ((e: InputEvent) => void));
    get onKeyDown(): ((e: KeyDownEvent) => void);
    set onKeyDown(value: ((e: KeyDownEvent) => void));
    get onKeyUp(): ((e: KeyUpEvent) => void);
    set onKeyUp(value: ((e: KeyUpEvent) => void));
    get onOptionChanged(): ((e: OptionChangedEvent$7) => void);
    set onOptionChanged(value: ((e: OptionChangedEvent$7) => void));
    get onPaste(): ((e: PasteEvent) => void);
    set onPaste(value: ((e: PasteEvent) => void));
    get onValueChanged(): ((e: ValueChangedEvent$3) => void);
    set onValueChanged(value: ((e: ValueChangedEvent$3) => void));
    get placeholder(): string;
    set placeholder(value: string);
    get readOnly(): boolean;
    set readOnly(value: boolean);
    get rtlEnabled(): boolean;
    set rtlEnabled(value: boolean);
    get showClearButton(): boolean;
    set showClearButton(value: boolean);
    get showMaskMode(): MaskMode;
    set showMaskMode(value: MaskMode);
    get spellcheck(): boolean;
    set spellcheck(value: boolean);
    get stylingMode(): EditorStyle;
    set stylingMode(value: EditorStyle);
    get tabIndex(): number;
    set tabIndex(value: number);
    get text(): string;
    set text(value: string);
    get useMaskedValue(): boolean;
    set useMaskedValue(value: boolean);
    get validationError(): any | null;
    set validationError(value: any | null);
    get validationErrors(): null | Array<any>;
    set validationErrors(value: null | Array<any>);
    get validationMessageMode(): ValidationMessageMode;
    set validationMessageMode(value: ValidationMessageMode);
    get validationMessagePosition(): Position;
    set validationMessagePosition(value: Position);
    get validationStatus(): ValidationStatus;
    set validationStatus(value: ValidationStatus);
    get value(): string;
    set value(value: string);
    get valueChangeEvent(): string;
    set valueChangeEvent(value: string);
    get visible(): boolean;
    set visible(value: boolean);
    get width(): number | string | undefined;
    set width(value: number | string | undefined);
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTextBoxOptions, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoTextBoxOptions, "ng-component", never, {}, {}, never, never, true, never>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoSearchEditorOptionsComponent extends DxoTextBoxOptions implements OnDestroy, OnInit {
    set _buttonsContentChildren(value: QueryList<CollectionNestedOption>);
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    textChange: EventEmitter<string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    valueChange: EventEmitter<string>;
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoSearchEditorOptionsComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoSearchEditorOptionsComponent, "dxo-search-editor-options", never, { "accessKey": { "alias": "accessKey"; "required": false; }; "activeStateEnabled": { "alias": "activeStateEnabled"; "required": false; }; "buttons": { "alias": "buttons"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "elementAttr": { "alias": "elementAttr"; "required": false; }; "focusStateEnabled": { "alias": "focusStateEnabled"; "required": false; }; "height": { "alias": "height"; "required": false; }; "hint": { "alias": "hint"; "required": false; }; "hoverStateEnabled": { "alias": "hoverStateEnabled"; "required": false; }; "inputAttr": { "alias": "inputAttr"; "required": false; }; "isDirty": { "alias": "isDirty"; "required": false; }; "isValid": { "alias": "isValid"; "required": false; }; "label": { "alias": "label"; "required": false; }; "labelMode": { "alias": "labelMode"; "required": false; }; "mask": { "alias": "mask"; "required": false; }; "maskChar": { "alias": "maskChar"; "required": false; }; "maskInvalidMessage": { "alias": "maskInvalidMessage"; "required": false; }; "maskRules": { "alias": "maskRules"; "required": false; }; "maxLength": { "alias": "maxLength"; "required": false; }; "mode": { "alias": "mode"; "required": false; }; "name": { "alias": "name"; "required": false; }; "onChange": { "alias": "onChange"; "required": false; }; "onContentReady": { "alias": "onContentReady"; "required": false; }; "onCopy": { "alias": "onCopy"; "required": false; }; "onCut": { "alias": "onCut"; "required": false; }; "onDisposing": { "alias": "onDisposing"; "required": false; }; "onEnterKey": { "alias": "onEnterKey"; "required": false; }; "onFocusIn": { "alias": "onFocusIn"; "required": false; }; "onFocusOut": { "alias": "onFocusOut"; "required": false; }; "onInitialized": { "alias": "onInitialized"; "required": false; }; "onInput": { "alias": "onInput"; "required": false; }; "onKeyDown": { "alias": "onKeyDown"; "required": false; }; "onKeyUp": { "alias": "onKeyUp"; "required": false; }; "onOptionChanged": { "alias": "onOptionChanged"; "required": false; }; "onPaste": { "alias": "onPaste"; "required": false; }; "onValueChanged": { "alias": "onValueChanged"; "required": false; }; "placeholder": { "alias": "placeholder"; "required": false; }; "readOnly": { "alias": "readOnly"; "required": false; }; "rtlEnabled": { "alias": "rtlEnabled"; "required": false; }; "showClearButton": { "alias": "showClearButton"; "required": false; }; "showMaskMode": { "alias": "showMaskMode"; "required": false; }; "spellcheck": { "alias": "spellcheck"; "required": false; }; "stylingMode": { "alias": "stylingMode"; "required": false; }; "tabIndex": { "alias": "tabIndex"; "required": false; }; "text": { "alias": "text"; "required": false; }; "useMaskedValue": { "alias": "useMaskedValue"; "required": false; }; "validationError": { "alias": "validationError"; "required": false; }; "validationErrors": { "alias": "validationErrors"; "required": false; }; "validationMessageMode": { "alias": "validationMessageMode"; "required": false; }; "validationMessagePosition": { "alias": "validationMessagePosition"; "required": false; }; "validationStatus": { "alias": "validationStatus"; "required": false; }; "value": { "alias": "value"; "required": false; }; "valueChangeEvent": { "alias": "valueChangeEvent"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, { "textChange": "textChange"; "valueChange": "valueChange"; }, ["_buttonsContentChildren"], never, true, never>;
}
declare class DxoSearchEditorOptionsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoSearchEditorOptionsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoSearchEditorOptionsModule, never, [typeof DxoSearchEditorOptionsComponent], [typeof DxoSearchEditorOptionsComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoSearchEditorOptionsModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare abstract class DxoSearchPanel extends NestedOption {
    get highlightCaseSensitive(): boolean;
    set highlightCaseSensitive(value: boolean);
    get highlightSearchText(): boolean;
    set highlightSearchText(value: boolean);
    get placeholder(): string;
    set placeholder(value: string);
    get searchVisibleColumnsOnly(): boolean;
    set searchVisibleColumnsOnly(value: boolean);
    get text(): string;
    set text(value: string);
    get visible(): boolean;
    set visible(value: boolean);
    get width(): number | string;
    set width(value: number | string);
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoSearchPanel, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoSearchPanel, "ng-component", never, {}, {}, never, never, true, never>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoSearchPanelComponent extends DxoSearchPanel implements OnDestroy, OnInit {
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    textChange: EventEmitter<string>;
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoSearchPanelComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoSearchPanelComponent, "dxo-search-panel", never, { "highlightCaseSensitive": { "alias": "highlightCaseSensitive"; "required": false; }; "highlightSearchText": { "alias": "highlightSearchText"; "required": false; }; "placeholder": { "alias": "placeholder"; "required": false; }; "searchVisibleColumnsOnly": { "alias": "searchVisibleColumnsOnly"; "required": false; }; "text": { "alias": "text"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, { "textChange": "textChange"; }, never, never, true, never>;
}
declare class DxoSearchPanelModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoSearchPanelModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoSearchPanelModule, never, [typeof DxoSearchPanelComponent], [typeof DxoSearchPanelComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoSearchPanelModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare abstract class DxoColumnChooserSearchConfig extends NestedOption {
    get editorOptions(): any;
    set editorOptions(value: any);
    get enabled(): boolean;
    set enabled(value: boolean);
    get timeout(): number;
    set timeout(value: number);
    get mode(): SearchMode;
    set mode(value: SearchMode);
    get searchExpr(): Function | string | undefined | Array<Function | string>;
    set searchExpr(value: Function | string | undefined | Array<Function | string>);
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoColumnChooserSearchConfig, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoColumnChooserSearchConfig, "ng-component", never, {}, {}, never, never, true, never>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoSearchComponent extends DxoColumnChooserSearchConfig implements OnDestroy, OnInit {
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoSearchComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoSearchComponent, "dxo-search", never, { "editorOptions": { "alias": "editorOptions"; "required": false; }; "enabled": { "alias": "enabled"; "required": false; }; "timeout": { "alias": "timeout"; "required": false; }; "mode": { "alias": "mode"; "required": false; }; "searchExpr": { "alias": "searchExpr"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoSearchModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoSearchModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoSearchModule, never, [typeof DxoSearchComponent], [typeof DxoSearchComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoSearchModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoSelectionStyleComponent extends NestedOption implements OnDestroy, OnInit {
    get border(): {
        color?: string | undefined;
        visible?: boolean;
        width?: number;
    } | {
        color?: string | undefined;
        dashStyle?: DashStyle | undefined;
        visible?: boolean;
        width?: number;
    } | {
        color?: string | undefined;
        visible?: boolean | undefined;
        width?: number | undefined;
    } | {
        color?: string | undefined;
        width?: number | undefined;
    };
    set border(value: {
        color?: string | undefined;
        visible?: boolean;
        width?: number;
    } | {
        color?: string | undefined;
        dashStyle?: DashStyle | undefined;
        visible?: boolean;
        width?: number;
    } | {
        color?: string | undefined;
        visible?: boolean | undefined;
        width?: number | undefined;
    } | {
        color?: string | undefined;
        width?: number | undefined;
    });
    get color(): ChartsColor | string | undefined;
    set color(value: ChartsColor | string | undefined);
    get size(): number | undefined;
    set size(value: number | undefined);
    get dashStyle(): DashStyle;
    set dashStyle(value: DashStyle);
    get hatching(): {
        direction?: HatchDirection;
        opacity?: number;
        step?: number;
        width?: number;
    };
    set hatching(value: {
        direction?: HatchDirection;
        opacity?: number;
        step?: number;
        width?: number;
    });
    get highlight(): boolean;
    set highlight(value: boolean);
    get width(): number;
    set width(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoSelectionStyleComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoSelectionStyleComponent, "dxo-selection-style", never, { "border": { "alias": "border"; "required": false; }; "color": { "alias": "color"; "required": false; }; "size": { "alias": "size"; "required": false; }; "dashStyle": { "alias": "dashStyle"; "required": false; }; "hatching": { "alias": "hatching"; "required": false; }; "highlight": { "alias": "highlight"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoSelectionStyleModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoSelectionStyleModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoSelectionStyleModule, never, [typeof DxoSelectionStyleComponent], [typeof DxoSelectionStyleComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoSelectionStyleModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare abstract class DxoColumnChooserSelectionConfig extends NestedOption {
    get allowSelectAll(): boolean;
    set allowSelectAll(value: boolean);
    get recursive(): boolean;
    set recursive(value: boolean);
    get selectByClick(): boolean;
    set selectByClick(value: boolean);
    get deferred(): boolean;
    set deferred(value: boolean);
    get mode(): SingleMultipleOrNone;
    set mode(value: SingleMultipleOrNone);
    get selectAllMode(): SelectAllMode;
    set selectAllMode(value: SelectAllMode);
    get sensitivity(): SelectionSensitivity;
    set sensitivity(value: SelectionSensitivity);
    get showCheckBoxesMode(): SelectionColumnDisplayMode;
    set showCheckBoxesMode(value: SelectionColumnDisplayMode);
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoColumnChooserSelectionConfig, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoColumnChooserSelectionConfig, "ng-component", never, {}, {}, never, never, true, never>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoSelectionComponent extends DxoColumnChooserSelectionConfig implements OnDestroy, OnInit {
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoSelectionComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoSelectionComponent, "dxo-selection", never, { "allowSelectAll": { "alias": "allowSelectAll"; "required": false; }; "recursive": { "alias": "recursive"; "required": false; }; "selectByClick": { "alias": "selectByClick"; "required": false; }; "deferred": { "alias": "deferred"; "required": false; }; "mode": { "alias": "mode"; "required": false; }; "selectAllMode": { "alias": "selectAllMode"; "required": false; }; "sensitivity": { "alias": "sensitivity"; "required": false; }; "showCheckBoxesMode": { "alias": "showCheckBoxesMode"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoSelectionModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoSelectionModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoSelectionModule, never, [typeof DxoSelectionComponent], [typeof DxoSelectionComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoSelectionModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare abstract class DxiChartSeries extends CollectionNestedOption {
    get aggregation(): {
        calculate?: Function | undefined;
        enabled?: boolean;
        method?: ChartSeriesAggregationMethod;
    };
    set aggregation(value: {
        calculate?: Function | undefined;
        enabled?: boolean;
        method?: ChartSeriesAggregationMethod;
    });
    get argumentField(): string;
    set argumentField(value: string);
    get axis(): string | undefined;
    set axis(value: string | undefined);
    get barOverlapGroup(): string | undefined;
    set barOverlapGroup(value: string | undefined);
    get barPadding(): number | undefined;
    set barPadding(value: number | undefined);
    get barWidth(): number | undefined;
    set barWidth(value: number | undefined);
    get border(): {
        color?: string | undefined;
        dashStyle?: DashStyle | undefined;
        visible?: boolean;
        width?: number;
    };
    set border(value: {
        color?: string | undefined;
        dashStyle?: DashStyle | undefined;
        visible?: boolean;
        width?: number;
    });
    get closeValueField(): string;
    set closeValueField(value: string);
    get color(): ChartsColor | string | undefined;
    set color(value: ChartsColor | string | undefined);
    get cornerRadius(): number;
    set cornerRadius(value: number);
    get dashStyle(): DashStyle;
    set dashStyle(value: DashStyle);
    get highValueField(): string;
    set highValueField(value: string);
    get hoverMode(): SeriesHoverMode | PieChartSeriesInteractionMode;
    set hoverMode(value: SeriesHoverMode | PieChartSeriesInteractionMode);
    get hoverStyle(): {
        border?: {
            color?: string | undefined;
            dashStyle?: DashStyle | undefined;
            visible?: boolean;
            width?: number;
        };
        color?: ChartsColor | string | undefined;
        dashStyle?: DashStyle;
        hatching?: {
            direction?: HatchDirection;
            opacity?: number;
            step?: number;
            width?: number;
        };
        highlight?: boolean;
        width?: number;
    } | {
        border?: {
            color?: string | undefined;
            dashStyle?: DashStyle | undefined;
            visible?: boolean;
            width?: number;
        };
        color?: ChartsColor | string | undefined;
        hatching?: {
            direction?: HatchDirection;
            opacity?: number;
            step?: number;
            width?: number;
        };
        highlight?: boolean;
    };
    set hoverStyle(value: {
        border?: {
            color?: string | undefined;
            dashStyle?: DashStyle | undefined;
            visible?: boolean;
            width?: number;
        };
        color?: ChartsColor | string | undefined;
        dashStyle?: DashStyle;
        hatching?: {
            direction?: HatchDirection;
            opacity?: number;
            step?: number;
            width?: number;
        };
        highlight?: boolean;
        width?: number;
    } | {
        border?: {
            color?: string | undefined;
            dashStyle?: DashStyle | undefined;
            visible?: boolean;
            width?: number;
        };
        color?: ChartsColor | string | undefined;
        hatching?: {
            direction?: HatchDirection;
            opacity?: number;
            step?: number;
            width?: number;
        };
        highlight?: boolean;
    });
    get ignoreEmptyPoints(): boolean;
    set ignoreEmptyPoints(value: boolean);
    get innerColor(): string;
    set innerColor(value: string);
    get label(): {
        alignment?: HorizontalAlignment;
        argumentFormat?: Format | string | undefined;
        backgroundColor?: string | undefined;
        border?: {
            color?: string | undefined;
            dashStyle?: DashStyle | undefined;
            visible?: boolean;
            width?: number;
        };
        connector?: {
            color?: string | undefined;
            visible?: boolean;
            width?: number;
        };
        customizeText?: Function;
        displayFormat?: string | undefined;
        font?: Font;
        format?: Format | string | undefined;
        horizontalOffset?: number;
        position?: RelativePosition;
        rotationAngle?: number;
        showForZeroValues?: boolean;
        verticalOffset?: number;
        visible?: boolean;
    } | {
        argumentFormat?: Format | string | undefined;
        backgroundColor?: string | undefined;
        border?: {
            color?: string | undefined;
            dashStyle?: DashStyle | undefined;
            visible?: boolean;
            width?: number;
        };
        connector?: {
            color?: string | undefined;
            visible?: boolean;
            width?: number;
        };
        customizeText?: Function;
        displayFormat?: string | undefined;
        font?: Font;
        format?: Format | string | undefined;
        position?: LabelPosition;
        radialOffset?: number;
        rotationAngle?: number;
        textOverflow?: TextOverflow;
        visible?: boolean;
        wordWrap?: WordWrap;
    } | {
        argumentFormat?: Format | string | undefined;
        backgroundColor?: string | undefined;
        border?: {
            color?: string | undefined;
            dashStyle?: DashStyle | undefined;
            visible?: boolean;
            width?: number;
        };
        connector?: {
            color?: string | undefined;
            visible?: boolean;
            width?: number;
        };
        customizeText?: Function;
        displayFormat?: string | undefined;
        font?: Font;
        format?: Format | string | undefined;
        position?: RelativePosition;
        rotationAngle?: number;
        showForZeroValues?: boolean;
        visible?: boolean;
    };
    set label(value: {
        alignment?: HorizontalAlignment;
        argumentFormat?: Format | string | undefined;
        backgroundColor?: string | undefined;
        border?: {
            color?: string | undefined;
            dashStyle?: DashStyle | undefined;
            visible?: boolean;
            width?: number;
        };
        connector?: {
            color?: string | undefined;
            visible?: boolean;
            width?: number;
        };
        customizeText?: Function;
        displayFormat?: string | undefined;
        font?: Font;
        format?: Format | string | undefined;
        horizontalOffset?: number;
        position?: RelativePosition;
        rotationAngle?: number;
        showForZeroValues?: boolean;
        verticalOffset?: number;
        visible?: boolean;
    } | {
        argumentFormat?: Format | string | undefined;
        backgroundColor?: string | undefined;
        border?: {
            color?: string | undefined;
            dashStyle?: DashStyle | undefined;
            visible?: boolean;
            width?: number;
        };
        connector?: {
            color?: string | undefined;
            visible?: boolean;
            width?: number;
        };
        customizeText?: Function;
        displayFormat?: string | undefined;
        font?: Font;
        format?: Format | string | undefined;
        position?: LabelPosition;
        radialOffset?: number;
        rotationAngle?: number;
        textOverflow?: TextOverflow;
        visible?: boolean;
        wordWrap?: WordWrap;
    } | {
        argumentFormat?: Format | string | undefined;
        backgroundColor?: string | undefined;
        border?: {
            color?: string | undefined;
            dashStyle?: DashStyle | undefined;
            visible?: boolean;
            width?: number;
        };
        connector?: {
            color?: string | undefined;
            visible?: boolean;
            width?: number;
        };
        customizeText?: Function;
        displayFormat?: string | undefined;
        font?: Font;
        format?: Format | string | undefined;
        position?: RelativePosition;
        rotationAngle?: number;
        showForZeroValues?: boolean;
        visible?: boolean;
    });
    get lowValueField(): string;
    set lowValueField(value: string);
    get maxLabelCount(): number | undefined;
    set maxLabelCount(value: number | undefined);
    get minBarSize(): number | undefined;
    set minBarSize(value: number | undefined);
    get name(): string | undefined;
    set name(value: string | undefined);
    get opacity(): number;
    set opacity(value: number);
    get openValueField(): string;
    set openValueField(value: string);
    get pane(): string;
    set pane(value: string);
    get point(): {
        border?: {
            color?: string | undefined;
            visible?: boolean;
            width?: number;
        };
        color?: ChartsColor | string | undefined;
        hoverMode?: PointInteractionMode;
        hoverStyle?: {
            border?: {
                color?: string | undefined;
                visible?: boolean;
                width?: number;
            };
            color?: ChartsColor | string | undefined;
            size?: number | undefined;
        };
        image?: string | undefined | {
            height?: number | {
                rangeMaxPoint?: number | undefined;
                rangeMinPoint?: number | undefined;
            };
            url?: string | undefined | {
                rangeMaxPoint?: string | undefined;
                rangeMinPoint?: string | undefined;
            };
            width?: number | {
                rangeMaxPoint?: number | undefined;
                rangeMinPoint?: number | undefined;
            };
        };
        selectionMode?: PointInteractionMode;
        selectionStyle?: {
            border?: {
                color?: string | undefined;
                visible?: boolean;
                width?: number;
            };
            color?: ChartsColor | string | undefined;
            size?: number | undefined;
        };
        size?: number;
        symbol?: PointSymbol;
        visible?: boolean;
    } | {
        border?: {
            color?: string | undefined;
            visible?: boolean;
            width?: number;
        };
        color?: ChartsColor | string | undefined;
        hoverMode?: PointInteractionMode;
        hoverStyle?: {
            border?: {
                color?: string | undefined;
                visible?: boolean;
                width?: number;
            };
            color?: ChartsColor | string | undefined;
            size?: number;
        };
        image?: string | undefined | {
            height?: number;
            url?: string | undefined;
            width?: number;
        };
        selectionMode?: PointInteractionMode;
        selectionStyle?: {
            border?: {
                color?: string | undefined;
                visible?: boolean;
                width?: number;
            };
            color?: ChartsColor | string | undefined;
            size?: number;
        };
        size?: number;
        symbol?: PointSymbol;
        visible?: boolean;
    };
    set point(value: {
        border?: {
            color?: string | undefined;
            visible?: boolean;
            width?: number;
        };
        color?: ChartsColor | string | undefined;
        hoverMode?: PointInteractionMode;
        hoverStyle?: {
            border?: {
                color?: string | undefined;
                visible?: boolean;
                width?: number;
            };
            color?: ChartsColor | string | undefined;
            size?: number | undefined;
        };
        image?: string | undefined | {
            height?: number | {
                rangeMaxPoint?: number | undefined;
                rangeMinPoint?: number | undefined;
            };
            url?: string | undefined | {
                rangeMaxPoint?: string | undefined;
                rangeMinPoint?: string | undefined;
            };
            width?: number | {
                rangeMaxPoint?: number | undefined;
                rangeMinPoint?: number | undefined;
            };
        };
        selectionMode?: PointInteractionMode;
        selectionStyle?: {
            border?: {
                color?: string | undefined;
                visible?: boolean;
                width?: number;
            };
            color?: ChartsColor | string | undefined;
            size?: number | undefined;
        };
        size?: number;
        symbol?: PointSymbol;
        visible?: boolean;
    } | {
        border?: {
            color?: string | undefined;
            visible?: boolean;
            width?: number;
        };
        color?: ChartsColor | string | undefined;
        hoverMode?: PointInteractionMode;
        hoverStyle?: {
            border?: {
                color?: string | undefined;
                visible?: boolean;
                width?: number;
            };
            color?: ChartsColor | string | undefined;
            size?: number;
        };
        image?: string | undefined | {
            height?: number;
            url?: string | undefined;
            width?: number;
        };
        selectionMode?: PointInteractionMode;
        selectionStyle?: {
            border?: {
                color?: string | undefined;
                visible?: boolean;
                width?: number;
            };
            color?: ChartsColor | string | undefined;
            size?: number;
        };
        size?: number;
        symbol?: PointSymbol;
        visible?: boolean;
    });
    get rangeValue1Field(): string;
    set rangeValue1Field(value: string);
    get rangeValue2Field(): string;
    set rangeValue2Field(value: string);
    get reduction(): {
        color?: string;
        level?: FinancialChartReductionLevel;
    };
    set reduction(value: {
        color?: string;
        level?: FinancialChartReductionLevel;
    });
    get selectionMode(): SeriesSelectionMode | PieChartSeriesInteractionMode;
    set selectionMode(value: SeriesSelectionMode | PieChartSeriesInteractionMode);
    get selectionStyle(): {
        border?: {
            color?: string | undefined;
            dashStyle?: DashStyle | undefined;
            visible?: boolean;
            width?: number;
        };
        color?: ChartsColor | string | undefined;
        dashStyle?: DashStyle;
        hatching?: {
            direction?: HatchDirection;
            opacity?: number;
            step?: number;
            width?: number;
        };
        highlight?: boolean;
        width?: number;
    } | {
        border?: {
            color?: string | undefined;
            dashStyle?: DashStyle | undefined;
            visible?: boolean;
            width?: number;
        };
        color?: ChartsColor | string | undefined;
        hatching?: {
            direction?: HatchDirection;
            opacity?: number;
            step?: number;
            width?: number;
        };
        highlight?: boolean;
    };
    set selectionStyle(value: {
        border?: {
            color?: string | undefined;
            dashStyle?: DashStyle | undefined;
            visible?: boolean;
            width?: number;
        };
        color?: ChartsColor | string | undefined;
        dashStyle?: DashStyle;
        hatching?: {
            direction?: HatchDirection;
            opacity?: number;
            step?: number;
            width?: number;
        };
        highlight?: boolean;
        width?: number;
    } | {
        border?: {
            color?: string | undefined;
            dashStyle?: DashStyle | undefined;
            visible?: boolean;
            width?: number;
        };
        color?: ChartsColor | string | undefined;
        hatching?: {
            direction?: HatchDirection;
            opacity?: number;
            step?: number;
            width?: number;
        };
        highlight?: boolean;
    });
    get showInLegend(): boolean;
    set showInLegend(value: boolean);
    get sizeField(): string;
    set sizeField(value: string);
    get stack(): string;
    set stack(value: string);
    get tag(): any | undefined;
    set tag(value: any | undefined);
    get tagField(): string;
    set tagField(value: string);
    get type(): SeriesType | PolarChartSeriesType;
    set type(value: SeriesType | PolarChartSeriesType);
    get valueErrorBar(): {
        color?: string;
        displayMode?: ValueErrorBarDisplayMode;
        edgeLength?: number;
        highValueField?: string | undefined;
        lineWidth?: number;
        lowValueField?: string | undefined;
        opacity?: number | undefined;
        type?: ValueErrorBarType | undefined;
        value?: number;
    };
    set valueErrorBar(value: {
        color?: string;
        displayMode?: ValueErrorBarDisplayMode;
        edgeLength?: number;
        highValueField?: string | undefined;
        lineWidth?: number;
        lowValueField?: string | undefined;
        opacity?: number | undefined;
        type?: ValueErrorBarType | undefined;
        value?: number;
    });
    get valueField(): string;
    set valueField(value: string);
    get visible(): boolean;
    set visible(value: boolean);
    get width(): number;
    set width(value: number);
    get argumentType(): ChartsDataType | undefined;
    set argumentType(value: ChartsDataType | undefined);
    get minSegmentSize(): number | undefined;
    set minSegmentSize(value: number | undefined);
    get smallValuesGrouping(): {
        groupName?: string;
        mode?: SmallValuesGroupingMode;
        threshold?: number | undefined;
        topCount?: number | undefined;
    };
    set smallValuesGrouping(value: {
        groupName?: string;
        mode?: SmallValuesGroupingMode;
        threshold?: number | undefined;
        topCount?: number | undefined;
    });
    get closed(): boolean;
    set closed(value: boolean);
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiChartSeries, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiChartSeries, "ng-component", never, {}, {}, never, never, true, never>;
}

declare class DxiSeriesComponent extends DxiChartSeries {
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiSeriesComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiSeriesComponent, "dxi-series", never, { "aggregation": { "alias": "aggregation"; "required": false; }; "argumentField": { "alias": "argumentField"; "required": false; }; "axis": { "alias": "axis"; "required": false; }; "barOverlapGroup": { "alias": "barOverlapGroup"; "required": false; }; "barPadding": { "alias": "barPadding"; "required": false; }; "barWidth": { "alias": "barWidth"; "required": false; }; "border": { "alias": "border"; "required": false; }; "closeValueField": { "alias": "closeValueField"; "required": false; }; "color": { "alias": "color"; "required": false; }; "cornerRadius": { "alias": "cornerRadius"; "required": false; }; "dashStyle": { "alias": "dashStyle"; "required": false; }; "highValueField": { "alias": "highValueField"; "required": false; }; "hoverMode": { "alias": "hoverMode"; "required": false; }; "hoverStyle": { "alias": "hoverStyle"; "required": false; }; "ignoreEmptyPoints": { "alias": "ignoreEmptyPoints"; "required": false; }; "innerColor": { "alias": "innerColor"; "required": false; }; "label": { "alias": "label"; "required": false; }; "lowValueField": { "alias": "lowValueField"; "required": false; }; "maxLabelCount": { "alias": "maxLabelCount"; "required": false; }; "minBarSize": { "alias": "minBarSize"; "required": false; }; "name": { "alias": "name"; "required": false; }; "opacity": { "alias": "opacity"; "required": false; }; "openValueField": { "alias": "openValueField"; "required": false; }; "pane": { "alias": "pane"; "required": false; }; "point": { "alias": "point"; "required": false; }; "rangeValue1Field": { "alias": "rangeValue1Field"; "required": false; }; "rangeValue2Field": { "alias": "rangeValue2Field"; "required": false; }; "reduction": { "alias": "reduction"; "required": false; }; "selectionMode": { "alias": "selectionMode"; "required": false; }; "selectionStyle": { "alias": "selectionStyle"; "required": false; }; "showInLegend": { "alias": "showInLegend"; "required": false; }; "sizeField": { "alias": "sizeField"; "required": false; }; "stack": { "alias": "stack"; "required": false; }; "tag": { "alias": "tag"; "required": false; }; "tagField": { "alias": "tagField"; "required": false; }; "type": { "alias": "type"; "required": false; }; "valueErrorBar": { "alias": "valueErrorBar"; "required": false; }; "valueField": { "alias": "valueField"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; "argumentType": { "alias": "argumentType"; "required": false; }; "minSegmentSize": { "alias": "minSegmentSize"; "required": false; }; "smallValuesGrouping": { "alias": "smallValuesGrouping"; "required": false; }; "closed": { "alias": "closed"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxiSeriesModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiSeriesModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiSeriesModule, never, [typeof DxiSeriesComponent], [typeof DxiSeriesComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiSeriesModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoSeriesTemplateComponent extends NestedOption implements OnDestroy, OnInit {
    get customizeSeries(): Function;
    set customizeSeries(value: Function);
    get nameField(): string;
    set nameField(value: string);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoSeriesTemplateComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoSeriesTemplateComponent, "dxo-series-template", never, { "customizeSeries": { "alias": "customizeSeries"; "required": false; }; "nameField": { "alias": "nameField"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoSeriesTemplateModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoSeriesTemplateModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoSeriesTemplateModule, never, [typeof DxoSeriesTemplateComponent], [typeof DxoSeriesTemplateComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoSeriesTemplateModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoShadowComponent extends NestedOption implements OnDestroy, OnInit {
    get blur(): number;
    set blur(value: number);
    get color(): string;
    set color(value: string);
    get offsetX(): number;
    set offsetX(value: number);
    get offsetY(): number;
    set offsetY(value: number);
    get opacity(): number;
    set opacity(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoShadowComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoShadowComponent, "dxo-shadow", never, { "blur": { "alias": "blur"; "required": false; }; "color": { "alias": "color"; "required": false; }; "offsetX": { "alias": "offsetX"; "required": false; }; "offsetY": { "alias": "offsetY"; "required": false; }; "opacity": { "alias": "opacity"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoShadowModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoShadowModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoShadowModule, never, [typeof DxoShadowComponent], [typeof DxoShadowComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoShadowModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoShowEventComponent extends NestedOption implements OnDestroy, OnInit {
    get delay(): number | undefined;
    set delay(value: number | undefined);
    get name(): string | undefined;
    set name(value: string | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoShowEventComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoShowEventComponent, "dxo-show-event", never, { "delay": { "alias": "delay"; "required": false; }; "name": { "alias": "name"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoShowEventModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoShowEventModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoShowEventModule, never, [typeof DxoShowEventComponent], [typeof DxoShowEventComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoShowEventModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoShowFirstSubmenuModeComponent extends NestedOption implements OnDestroy, OnInit {
    get delay(): number | {
        hide?: number;
        show?: number;
    };
    set delay(value: number | {
        hide?: number;
        show?: number;
    });
    get name(): SubmenuShowMode;
    set name(value: SubmenuShowMode);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoShowFirstSubmenuModeComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoShowFirstSubmenuModeComponent, "dxo-show-first-submenu-mode", never, { "delay": { "alias": "delay"; "required": false; }; "name": { "alias": "name"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoShowFirstSubmenuModeModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoShowFirstSubmenuModeModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoShowFirstSubmenuModeModule, never, [typeof DxoShowFirstSubmenuModeComponent], [typeof DxoShowFirstSubmenuModeComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoShowFirstSubmenuModeModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoShowSubmenuModeComponent extends NestedOption implements OnDestroy, OnInit {
    get delay(): number | {
        hide?: number;
        show?: number;
    };
    set delay(value: number | {
        hide?: number;
        show?: number;
    });
    get name(): SubmenuShowMode;
    set name(value: SubmenuShowMode);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoShowSubmenuModeComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoShowSubmenuModeComponent, "dxo-show-submenu-mode", never, { "delay": { "alias": "delay"; "required": false; }; "name": { "alias": "name"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoShowSubmenuModeModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoShowSubmenuModeModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoShowSubmenuModeModule, never, [typeof DxoShowSubmenuModeComponent], [typeof DxoShowSubmenuModeComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoShowSubmenuModeModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoShowComponent extends DxoAnimationConfig implements OnDestroy, OnInit {
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoShowComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoShowComponent, "dxo-show", never, { "complete": { "alias": "complete"; "required": false; }; "delay": { "alias": "delay"; "required": false; }; "direction": { "alias": "direction"; "required": false; }; "duration": { "alias": "duration"; "required": false; }; "easing": { "alias": "easing"; "required": false; }; "from": { "alias": "from"; "required": false; }; "staggerDelay": { "alias": "staggerDelay"; "required": false; }; "start": { "alias": "start"; "required": false; }; "to": { "alias": "to"; "required": false; }; "type": { "alias": "type"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoShowModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoShowModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoShowModule, never, [typeof DxoShowComponent], [typeof DxoShowComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoShowModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoShutterComponent extends NestedOption implements OnDestroy, OnInit {
    get color(): string | undefined;
    set color(value: string | undefined);
    get opacity(): number;
    set opacity(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoShutterComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoShutterComponent, "dxo-shutter", never, { "color": { "alias": "color"; "required": false; }; "opacity": { "alias": "opacity"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoShutterModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoShutterModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoShutterModule, never, [typeof DxoShutterComponent], [typeof DxoShutterComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoShutterModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoSizeComponent extends NestedOption implements OnDestroy, OnInit {
    get height(): number | undefined;
    set height(value: number | undefined);
    get width(): number | undefined;
    set width(value: number | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoSizeComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoSizeComponent, "dxo-size", never, { "height": { "alias": "height"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoSizeModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoSizeModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoSizeModule, never, [typeof DxoSizeComponent], [typeof DxoSizeComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoSizeModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoSliderHandleComponent extends NestedOption implements OnDestroy, OnInit {
    get color(): string;
    set color(value: string);
    get opacity(): number;
    set opacity(value: number);
    get width(): number;
    set width(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoSliderHandleComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoSliderHandleComponent, "dxo-slider-handle", never, { "color": { "alias": "color"; "required": false; }; "opacity": { "alias": "opacity"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoSliderHandleModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoSliderHandleModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoSliderHandleModule, never, [typeof DxoSliderHandleComponent], [typeof DxoSliderHandleComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoSliderHandleModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoSliderMarkerComponent extends NestedOption implements OnDestroy, OnInit {
    get color(): string;
    set color(value: string);
    get customizeText(): Function;
    set customizeText(value: Function);
    get font(): Font;
    set font(value: Font);
    get format(): Format | string | undefined;
    set format(value: Format | string | undefined);
    get invalidRangeColor(): string;
    set invalidRangeColor(value: string);
    get paddingLeftRight(): number;
    set paddingLeftRight(value: number);
    get paddingTopBottom(): number;
    set paddingTopBottom(value: number);
    get placeholderHeight(): number | undefined;
    set placeholderHeight(value: number | undefined);
    get visible(): boolean;
    set visible(value: boolean);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoSliderMarkerComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoSliderMarkerComponent, "dxo-slider-marker", never, { "color": { "alias": "color"; "required": false; }; "customizeText": { "alias": "customizeText"; "required": false; }; "font": { "alias": "font"; "required": false; }; "format": { "alias": "format"; "required": false; }; "invalidRangeColor": { "alias": "invalidRangeColor"; "required": false; }; "paddingLeftRight": { "alias": "paddingLeftRight"; "required": false; }; "paddingTopBottom": { "alias": "paddingTopBottom"; "required": false; }; "placeholderHeight": { "alias": "placeholderHeight"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoSliderMarkerModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoSliderMarkerModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoSliderMarkerModule, never, [typeof DxoSliderMarkerComponent], [typeof DxoSliderMarkerComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoSliderMarkerModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoSmallValuesGroupingComponent extends NestedOption implements OnDestroy, OnInit {
    get groupName(): string;
    set groupName(value: string);
    get mode(): SmallValuesGroupingMode;
    set mode(value: SmallValuesGroupingMode);
    get threshold(): number | undefined;
    set threshold(value: number | undefined);
    get topCount(): number | undefined;
    set topCount(value: number | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoSmallValuesGroupingComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoSmallValuesGroupingComponent, "dxo-small-values-grouping", never, { "groupName": { "alias": "groupName"; "required": false; }; "mode": { "alias": "mode"; "required": false; }; "threshold": { "alias": "threshold"; "required": false; }; "topCount": { "alias": "topCount"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoSmallValuesGroupingModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoSmallValuesGroupingModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoSmallValuesGroupingModule, never, [typeof DxoSmallValuesGroupingComponent], [typeof DxoSmallValuesGroupingComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoSmallValuesGroupingModule>;
}

declare class DxiSortByGroupSummaryInfoComponent extends CollectionNestedOption {
    get groupColumn(): string | undefined;
    set groupColumn(value: string | undefined);
    get sortOrder(): SortOrder | string | undefined;
    set sortOrder(value: SortOrder | string | undefined);
    get summaryItem(): number | string | undefined;
    set summaryItem(value: number | string | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiSortByGroupSummaryInfoComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiSortByGroupSummaryInfoComponent, "dxi-sort-by-group-summary-info", never, { "groupColumn": { "alias": "groupColumn"; "required": false; }; "sortOrder": { "alias": "sortOrder"; "required": false; }; "summaryItem": { "alias": "summaryItem"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxiSortByGroupSummaryInfoModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiSortByGroupSummaryInfoModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiSortByGroupSummaryInfoModule, never, [typeof DxiSortByGroupSummaryInfoComponent], [typeof DxiSortByGroupSummaryInfoComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiSortByGroupSummaryInfoModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare abstract class DxoSorting extends NestedOption {
    get ascendingText(): string;
    set ascendingText(value: string);
    get clearText(): string;
    set clearText(value: string);
    get descendingText(): string;
    set descendingText(value: string);
    get mode(): SingleMultipleOrNone | string;
    set mode(value: SingleMultipleOrNone | string);
    get showSortIndexes(): boolean;
    set showSortIndexes(value: boolean);
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoSorting, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoSorting, "ng-component", never, {}, {}, never, never, true, never>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoSortingComponent extends DxoSorting implements OnDestroy, OnInit {
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoSortingComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoSortingComponent, "dxo-sorting", never, { "ascendingText": { "alias": "ascendingText"; "required": false; }; "clearText": { "alias": "clearText"; "required": false; }; "descendingText": { "alias": "descendingText"; "required": false; }; "mode": { "alias": "mode"; "required": false; }; "showSortIndexes": { "alias": "showSortIndexes"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoSortingModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoSortingModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoSortingModule, never, [typeof DxoSortingComponent], [typeof DxoSortingComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoSortingModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoSourceComponent extends NestedOption implements OnDestroy, OnInit {
    get grouping(): string;
    set grouping(value: string);
    get layer(): string;
    set layer(value: string);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoSourceComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoSourceComponent, "dxo-source", never, { "grouping": { "alias": "grouping"; "required": false; }; "layer": { "alias": "layer"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoSourceModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoSourceModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoSourceModule, never, [typeof DxoSourceComponent], [typeof DxoSourceComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoSourceModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoSplineComponent extends DxoChartCommonSeriesSettings implements OnDestroy, OnInit {
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoSplineComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoSplineComponent, "dxo-spline", never, { "aggregation": { "alias": "aggregation"; "required": false; }; "area": { "alias": "area"; "required": false; }; "argumentField": { "alias": "argumentField"; "required": false; }; "axis": { "alias": "axis"; "required": false; }; "bar": { "alias": "bar"; "required": false; }; "barOverlapGroup": { "alias": "barOverlapGroup"; "required": false; }; "barPadding": { "alias": "barPadding"; "required": false; }; "barWidth": { "alias": "barWidth"; "required": false; }; "border": { "alias": "border"; "required": false; }; "bubble": { "alias": "bubble"; "required": false; }; "candlestick": { "alias": "candlestick"; "required": false; }; "closeValueField": { "alias": "closeValueField"; "required": false; }; "color": { "alias": "color"; "required": false; }; "cornerRadius": { "alias": "cornerRadius"; "required": false; }; "dashStyle": { "alias": "dashStyle"; "required": false; }; "fullstackedarea": { "alias": "fullstackedarea"; "required": false; }; "fullstackedbar": { "alias": "fullstackedbar"; "required": false; }; "fullstackedline": { "alias": "fullstackedline"; "required": false; }; "fullstackedspline": { "alias": "fullstackedspline"; "required": false; }; "fullstackedsplinearea": { "alias": "fullstackedsplinearea"; "required": false; }; "highValueField": { "alias": "highValueField"; "required": false; }; "hoverMode": { "alias": "hoverMode"; "required": false; }; "hoverStyle": { "alias": "hoverStyle"; "required": false; }; "ignoreEmptyPoints": { "alias": "ignoreEmptyPoints"; "required": false; }; "innerColor": { "alias": "innerColor"; "required": false; }; "label": { "alias": "label"; "required": false; }; "line": { "alias": "line"; "required": false; }; "lowValueField": { "alias": "lowValueField"; "required": false; }; "maxLabelCount": { "alias": "maxLabelCount"; "required": false; }; "minBarSize": { "alias": "minBarSize"; "required": false; }; "opacity": { "alias": "opacity"; "required": false; }; "openValueField": { "alias": "openValueField"; "required": false; }; "pane": { "alias": "pane"; "required": false; }; "point": { "alias": "point"; "required": false; }; "rangearea": { "alias": "rangearea"; "required": false; }; "rangebar": { "alias": "rangebar"; "required": false; }; "rangeValue1Field": { "alias": "rangeValue1Field"; "required": false; }; "rangeValue2Field": { "alias": "rangeValue2Field"; "required": false; }; "reduction": { "alias": "reduction"; "required": false; }; "scatter": { "alias": "scatter"; "required": false; }; "selectionMode": { "alias": "selectionMode"; "required": false; }; "selectionStyle": { "alias": "selectionStyle"; "required": false; }; "showInLegend": { "alias": "showInLegend"; "required": false; }; "sizeField": { "alias": "sizeField"; "required": false; }; "spline": { "alias": "spline"; "required": false; }; "splinearea": { "alias": "splinearea"; "required": false; }; "stack": { "alias": "stack"; "required": false; }; "stackedarea": { "alias": "stackedarea"; "required": false; }; "stackedbar": { "alias": "stackedbar"; "required": false; }; "stackedline": { "alias": "stackedline"; "required": false; }; "stackedspline": { "alias": "stackedspline"; "required": false; }; "stackedsplinearea": { "alias": "stackedsplinearea"; "required": false; }; "steparea": { "alias": "steparea"; "required": false; }; "stepline": { "alias": "stepline"; "required": false; }; "stock": { "alias": "stock"; "required": false; }; "tagField": { "alias": "tagField"; "required": false; }; "type": { "alias": "type"; "required": false; }; "valueErrorBar": { "alias": "valueErrorBar"; "required": false; }; "valueField": { "alias": "valueField"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoSplineModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoSplineModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoSplineModule, never, [typeof DxoSplineComponent], [typeof DxoSplineComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoSplineModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoSplineareaComponent extends DxoChartCommonSeriesSettings implements OnDestroy, OnInit {
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoSplineareaComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoSplineareaComponent, "dxo-splinearea", never, { "aggregation": { "alias": "aggregation"; "required": false; }; "area": { "alias": "area"; "required": false; }; "argumentField": { "alias": "argumentField"; "required": false; }; "axis": { "alias": "axis"; "required": false; }; "bar": { "alias": "bar"; "required": false; }; "barOverlapGroup": { "alias": "barOverlapGroup"; "required": false; }; "barPadding": { "alias": "barPadding"; "required": false; }; "barWidth": { "alias": "barWidth"; "required": false; }; "border": { "alias": "border"; "required": false; }; "bubble": { "alias": "bubble"; "required": false; }; "candlestick": { "alias": "candlestick"; "required": false; }; "closeValueField": { "alias": "closeValueField"; "required": false; }; "color": { "alias": "color"; "required": false; }; "cornerRadius": { "alias": "cornerRadius"; "required": false; }; "dashStyle": { "alias": "dashStyle"; "required": false; }; "fullstackedarea": { "alias": "fullstackedarea"; "required": false; }; "fullstackedbar": { "alias": "fullstackedbar"; "required": false; }; "fullstackedline": { "alias": "fullstackedline"; "required": false; }; "fullstackedspline": { "alias": "fullstackedspline"; "required": false; }; "fullstackedsplinearea": { "alias": "fullstackedsplinearea"; "required": false; }; "highValueField": { "alias": "highValueField"; "required": false; }; "hoverMode": { "alias": "hoverMode"; "required": false; }; "hoverStyle": { "alias": "hoverStyle"; "required": false; }; "ignoreEmptyPoints": { "alias": "ignoreEmptyPoints"; "required": false; }; "innerColor": { "alias": "innerColor"; "required": false; }; "label": { "alias": "label"; "required": false; }; "line": { "alias": "line"; "required": false; }; "lowValueField": { "alias": "lowValueField"; "required": false; }; "maxLabelCount": { "alias": "maxLabelCount"; "required": false; }; "minBarSize": { "alias": "minBarSize"; "required": false; }; "opacity": { "alias": "opacity"; "required": false; }; "openValueField": { "alias": "openValueField"; "required": false; }; "pane": { "alias": "pane"; "required": false; }; "point": { "alias": "point"; "required": false; }; "rangearea": { "alias": "rangearea"; "required": false; }; "rangebar": { "alias": "rangebar"; "required": false; }; "rangeValue1Field": { "alias": "rangeValue1Field"; "required": false; }; "rangeValue2Field": { "alias": "rangeValue2Field"; "required": false; }; "reduction": { "alias": "reduction"; "required": false; }; "scatter": { "alias": "scatter"; "required": false; }; "selectionMode": { "alias": "selectionMode"; "required": false; }; "selectionStyle": { "alias": "selectionStyle"; "required": false; }; "showInLegend": { "alias": "showInLegend"; "required": false; }; "sizeField": { "alias": "sizeField"; "required": false; }; "spline": { "alias": "spline"; "required": false; }; "splinearea": { "alias": "splinearea"; "required": false; }; "stack": { "alias": "stack"; "required": false; }; "stackedarea": { "alias": "stackedarea"; "required": false; }; "stackedbar": { "alias": "stackedbar"; "required": false; }; "stackedline": { "alias": "stackedline"; "required": false; }; "stackedspline": { "alias": "stackedspline"; "required": false; }; "stackedsplinearea": { "alias": "stackedsplinearea"; "required": false; }; "steparea": { "alias": "steparea"; "required": false; }; "stepline": { "alias": "stepline"; "required": false; }; "stock": { "alias": "stock"; "required": false; }; "tagField": { "alias": "tagField"; "required": false; }; "type": { "alias": "type"; "required": false; }; "valueErrorBar": { "alias": "valueErrorBar"; "required": false; }; "valueField": { "alias": "valueField"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoSplineareaModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoSplineareaModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoSplineareaModule, never, [typeof DxoSplineareaComponent], [typeof DxoSplineareaComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoSplineareaModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare abstract class DxoSplitterOptions extends NestedOption {
    get allowKeyboardNavigation(): boolean;
    set allowKeyboardNavigation(value: boolean);
    get dataSource(): Store | DataSource | Options | null | string | Array<dxSplitterItem>;
    set dataSource(value: Store | DataSource | Options | null | string | Array<dxSplitterItem>);
    get disabled(): boolean;
    set disabled(value: boolean);
    get elementAttr(): any;
    set elementAttr(value: any);
    get height(): number | string | undefined;
    set height(value: number | string | undefined);
    get hoverStateEnabled(): boolean;
    set hoverStateEnabled(value: boolean);
    get items(): Array<any | {
        collapsed?: boolean;
        collapsedSize?: number | string | undefined;
        collapsible?: boolean;
        maxSize?: number | string | undefined;
        minSize?: number | string | undefined;
        resizable?: boolean;
        size?: number | string | undefined;
        splitter?: Properties$5 | undefined;
        template?: any;
        text?: string;
        visible?: boolean;
    }>;
    set items(value: Array<any | {
        collapsed?: boolean;
        collapsedSize?: number | string | undefined;
        collapsible?: boolean;
        maxSize?: number | string | undefined;
        minSize?: number | string | undefined;
        resizable?: boolean;
        size?: number | string | undefined;
        splitter?: Properties$5 | undefined;
        template?: any;
        text?: string;
        visible?: boolean;
    }>);
    get itemTemplate(): any;
    set itemTemplate(value: any);
    get onContentReady(): ((e: ContentReadyEvent$6) => void);
    set onContentReady(value: ((e: ContentReadyEvent$6) => void));
    get onDisposing(): ((e: DisposingEvent$8) => void);
    set onDisposing(value: ((e: DisposingEvent$8) => void));
    get onInitialized(): ((e: InitializedEvent$8) => void);
    set onInitialized(value: ((e: InitializedEvent$8) => void));
    get onItemClick(): ((e: ItemClickEvent$1) => void);
    set onItemClick(value: ((e: ItemClickEvent$1) => void));
    get onItemCollapsed(): ((e: ItemCollapsedEvent) => void);
    set onItemCollapsed(value: ((e: ItemCollapsedEvent) => void));
    get onItemContextMenu(): ((e: ItemContextMenuEvent$1) => void);
    set onItemContextMenu(value: ((e: ItemContextMenuEvent$1) => void));
    get onItemExpanded(): ((e: ItemExpandedEvent) => void);
    set onItemExpanded(value: ((e: ItemExpandedEvent) => void));
    get onItemRendered(): ((e: ItemRenderedEvent$1) => void);
    set onItemRendered(value: ((e: ItemRenderedEvent$1) => void));
    get onOptionChanged(): ((e: OptionChangedEvent$8) => void);
    set onOptionChanged(value: ((e: OptionChangedEvent$8) => void));
    get onResize(): ((e: ResizeEvent) => void);
    set onResize(value: ((e: ResizeEvent) => void));
    get onResizeEnd(): ((e: ResizeEndEvent) => void);
    set onResizeEnd(value: ((e: ResizeEndEvent) => void));
    get onResizeStart(): ((e: ResizeStartEvent) => void);
    set onResizeStart(value: ((e: ResizeStartEvent) => void));
    get orientation(): Orientation;
    set orientation(value: Orientation);
    get rtlEnabled(): boolean;
    set rtlEnabled(value: boolean);
    get separatorSize(): number;
    set separatorSize(value: number);
    get visible(): boolean;
    set visible(value: boolean);
    get width(): number | string | undefined;
    set width(value: number | string | undefined);
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoSplitterOptions, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoSplitterOptions, "ng-component", never, {}, {}, never, never, true, never>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoSplitterComponent extends DxoSplitterOptions implements OnDestroy, OnInit {
    set _itemsContentChildren(value: QueryList<CollectionNestedOption>);
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    itemsChange: EventEmitter<Array<any | {
        collapsed?: boolean;
        collapsedSize?: number | string | undefined;
        collapsible?: boolean;
        maxSize?: number | string | undefined;
        minSize?: number | string | undefined;
        resizable?: boolean;
        size?: number | string | undefined;
        splitter?: Properties$5 | undefined;
        template?: any;
        text?: string;
        visible?: boolean;
    }>>;
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoSplitterComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoSplitterComponent, "dxo-splitter", never, { "allowKeyboardNavigation": { "alias": "allowKeyboardNavigation"; "required": false; }; "dataSource": { "alias": "dataSource"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "elementAttr": { "alias": "elementAttr"; "required": false; }; "height": { "alias": "height"; "required": false; }; "hoverStateEnabled": { "alias": "hoverStateEnabled"; "required": false; }; "items": { "alias": "items"; "required": false; }; "itemTemplate": { "alias": "itemTemplate"; "required": false; }; "onContentReady": { "alias": "onContentReady"; "required": false; }; "onDisposing": { "alias": "onDisposing"; "required": false; }; "onInitialized": { "alias": "onInitialized"; "required": false; }; "onItemClick": { "alias": "onItemClick"; "required": false; }; "onItemCollapsed": { "alias": "onItemCollapsed"; "required": false; }; "onItemContextMenu": { "alias": "onItemContextMenu"; "required": false; }; "onItemExpanded": { "alias": "onItemExpanded"; "required": false; }; "onItemRendered": { "alias": "onItemRendered"; "required": false; }; "onOptionChanged": { "alias": "onOptionChanged"; "required": false; }; "onResize": { "alias": "onResize"; "required": false; }; "onResizeEnd": { "alias": "onResizeEnd"; "required": false; }; "onResizeStart": { "alias": "onResizeStart"; "required": false; }; "orientation": { "alias": "orientation"; "required": false; }; "rtlEnabled": { "alias": "rtlEnabled"; "required": false; }; "separatorSize": { "alias": "separatorSize"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, { "itemsChange": "itemsChange"; }, ["_itemsContentChildren"], never, true, never>;
}
declare class DxoSplitterModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoSplitterModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoSplitterModule, never, [typeof DxoSplitterComponent], [typeof DxoSplitterComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoSplitterModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoStackedareaComponent extends DxoChartCommonSeriesSettings implements OnDestroy, OnInit {
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoStackedareaComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoStackedareaComponent, "dxo-stackedarea", never, { "aggregation": { "alias": "aggregation"; "required": false; }; "area": { "alias": "area"; "required": false; }; "argumentField": { "alias": "argumentField"; "required": false; }; "axis": { "alias": "axis"; "required": false; }; "bar": { "alias": "bar"; "required": false; }; "barOverlapGroup": { "alias": "barOverlapGroup"; "required": false; }; "barPadding": { "alias": "barPadding"; "required": false; }; "barWidth": { "alias": "barWidth"; "required": false; }; "border": { "alias": "border"; "required": false; }; "bubble": { "alias": "bubble"; "required": false; }; "candlestick": { "alias": "candlestick"; "required": false; }; "closeValueField": { "alias": "closeValueField"; "required": false; }; "color": { "alias": "color"; "required": false; }; "cornerRadius": { "alias": "cornerRadius"; "required": false; }; "dashStyle": { "alias": "dashStyle"; "required": false; }; "fullstackedarea": { "alias": "fullstackedarea"; "required": false; }; "fullstackedbar": { "alias": "fullstackedbar"; "required": false; }; "fullstackedline": { "alias": "fullstackedline"; "required": false; }; "fullstackedspline": { "alias": "fullstackedspline"; "required": false; }; "fullstackedsplinearea": { "alias": "fullstackedsplinearea"; "required": false; }; "highValueField": { "alias": "highValueField"; "required": false; }; "hoverMode": { "alias": "hoverMode"; "required": false; }; "hoverStyle": { "alias": "hoverStyle"; "required": false; }; "ignoreEmptyPoints": { "alias": "ignoreEmptyPoints"; "required": false; }; "innerColor": { "alias": "innerColor"; "required": false; }; "label": { "alias": "label"; "required": false; }; "line": { "alias": "line"; "required": false; }; "lowValueField": { "alias": "lowValueField"; "required": false; }; "maxLabelCount": { "alias": "maxLabelCount"; "required": false; }; "minBarSize": { "alias": "minBarSize"; "required": false; }; "opacity": { "alias": "opacity"; "required": false; }; "openValueField": { "alias": "openValueField"; "required": false; }; "pane": { "alias": "pane"; "required": false; }; "point": { "alias": "point"; "required": false; }; "rangearea": { "alias": "rangearea"; "required": false; }; "rangebar": { "alias": "rangebar"; "required": false; }; "rangeValue1Field": { "alias": "rangeValue1Field"; "required": false; }; "rangeValue2Field": { "alias": "rangeValue2Field"; "required": false; }; "reduction": { "alias": "reduction"; "required": false; }; "scatter": { "alias": "scatter"; "required": false; }; "selectionMode": { "alias": "selectionMode"; "required": false; }; "selectionStyle": { "alias": "selectionStyle"; "required": false; }; "showInLegend": { "alias": "showInLegend"; "required": false; }; "sizeField": { "alias": "sizeField"; "required": false; }; "spline": { "alias": "spline"; "required": false; }; "splinearea": { "alias": "splinearea"; "required": false; }; "stack": { "alias": "stack"; "required": false; }; "stackedarea": { "alias": "stackedarea"; "required": false; }; "stackedbar": { "alias": "stackedbar"; "required": false; }; "stackedline": { "alias": "stackedline"; "required": false; }; "stackedspline": { "alias": "stackedspline"; "required": false; }; "stackedsplinearea": { "alias": "stackedsplinearea"; "required": false; }; "steparea": { "alias": "steparea"; "required": false; }; "stepline": { "alias": "stepline"; "required": false; }; "stock": { "alias": "stock"; "required": false; }; "tagField": { "alias": "tagField"; "required": false; }; "type": { "alias": "type"; "required": false; }; "valueErrorBar": { "alias": "valueErrorBar"; "required": false; }; "valueField": { "alias": "valueField"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoStackedareaModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoStackedareaModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoStackedareaModule, never, [typeof DxoStackedareaComponent], [typeof DxoStackedareaComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoStackedareaModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoStackedbarComponent extends DxoChartCommonSeriesSettings implements OnDestroy, OnInit {
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoStackedbarComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoStackedbarComponent, "dxo-stackedbar", never, { "aggregation": { "alias": "aggregation"; "required": false; }; "area": { "alias": "area"; "required": false; }; "argumentField": { "alias": "argumentField"; "required": false; }; "axis": { "alias": "axis"; "required": false; }; "bar": { "alias": "bar"; "required": false; }; "barOverlapGroup": { "alias": "barOverlapGroup"; "required": false; }; "barPadding": { "alias": "barPadding"; "required": false; }; "barWidth": { "alias": "barWidth"; "required": false; }; "border": { "alias": "border"; "required": false; }; "bubble": { "alias": "bubble"; "required": false; }; "candlestick": { "alias": "candlestick"; "required": false; }; "closeValueField": { "alias": "closeValueField"; "required": false; }; "color": { "alias": "color"; "required": false; }; "cornerRadius": { "alias": "cornerRadius"; "required": false; }; "dashStyle": { "alias": "dashStyle"; "required": false; }; "fullstackedarea": { "alias": "fullstackedarea"; "required": false; }; "fullstackedbar": { "alias": "fullstackedbar"; "required": false; }; "fullstackedline": { "alias": "fullstackedline"; "required": false; }; "fullstackedspline": { "alias": "fullstackedspline"; "required": false; }; "fullstackedsplinearea": { "alias": "fullstackedsplinearea"; "required": false; }; "highValueField": { "alias": "highValueField"; "required": false; }; "hoverMode": { "alias": "hoverMode"; "required": false; }; "hoverStyle": { "alias": "hoverStyle"; "required": false; }; "ignoreEmptyPoints": { "alias": "ignoreEmptyPoints"; "required": false; }; "innerColor": { "alias": "innerColor"; "required": false; }; "label": { "alias": "label"; "required": false; }; "line": { "alias": "line"; "required": false; }; "lowValueField": { "alias": "lowValueField"; "required": false; }; "maxLabelCount": { "alias": "maxLabelCount"; "required": false; }; "minBarSize": { "alias": "minBarSize"; "required": false; }; "opacity": { "alias": "opacity"; "required": false; }; "openValueField": { "alias": "openValueField"; "required": false; }; "pane": { "alias": "pane"; "required": false; }; "point": { "alias": "point"; "required": false; }; "rangearea": { "alias": "rangearea"; "required": false; }; "rangebar": { "alias": "rangebar"; "required": false; }; "rangeValue1Field": { "alias": "rangeValue1Field"; "required": false; }; "rangeValue2Field": { "alias": "rangeValue2Field"; "required": false; }; "reduction": { "alias": "reduction"; "required": false; }; "scatter": { "alias": "scatter"; "required": false; }; "selectionMode": { "alias": "selectionMode"; "required": false; }; "selectionStyle": { "alias": "selectionStyle"; "required": false; }; "showInLegend": { "alias": "showInLegend"; "required": false; }; "sizeField": { "alias": "sizeField"; "required": false; }; "spline": { "alias": "spline"; "required": false; }; "splinearea": { "alias": "splinearea"; "required": false; }; "stack": { "alias": "stack"; "required": false; }; "stackedarea": { "alias": "stackedarea"; "required": false; }; "stackedbar": { "alias": "stackedbar"; "required": false; }; "stackedline": { "alias": "stackedline"; "required": false; }; "stackedspline": { "alias": "stackedspline"; "required": false; }; "stackedsplinearea": { "alias": "stackedsplinearea"; "required": false; }; "steparea": { "alias": "steparea"; "required": false; }; "stepline": { "alias": "stepline"; "required": false; }; "stock": { "alias": "stock"; "required": false; }; "tagField": { "alias": "tagField"; "required": false; }; "type": { "alias": "type"; "required": false; }; "valueErrorBar": { "alias": "valueErrorBar"; "required": false; }; "valueField": { "alias": "valueField"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; "closed": { "alias": "closed"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoStackedbarModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoStackedbarModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoStackedbarModule, never, [typeof DxoStackedbarComponent], [typeof DxoStackedbarComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoStackedbarModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoStackedlineComponent extends DxoChartCommonSeriesSettings implements OnDestroy, OnInit {
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoStackedlineComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoStackedlineComponent, "dxo-stackedline", never, { "aggregation": { "alias": "aggregation"; "required": false; }; "area": { "alias": "area"; "required": false; }; "argumentField": { "alias": "argumentField"; "required": false; }; "axis": { "alias": "axis"; "required": false; }; "bar": { "alias": "bar"; "required": false; }; "barOverlapGroup": { "alias": "barOverlapGroup"; "required": false; }; "barPadding": { "alias": "barPadding"; "required": false; }; "barWidth": { "alias": "barWidth"; "required": false; }; "border": { "alias": "border"; "required": false; }; "bubble": { "alias": "bubble"; "required": false; }; "candlestick": { "alias": "candlestick"; "required": false; }; "closeValueField": { "alias": "closeValueField"; "required": false; }; "color": { "alias": "color"; "required": false; }; "cornerRadius": { "alias": "cornerRadius"; "required": false; }; "dashStyle": { "alias": "dashStyle"; "required": false; }; "fullstackedarea": { "alias": "fullstackedarea"; "required": false; }; "fullstackedbar": { "alias": "fullstackedbar"; "required": false; }; "fullstackedline": { "alias": "fullstackedline"; "required": false; }; "fullstackedspline": { "alias": "fullstackedspline"; "required": false; }; "fullstackedsplinearea": { "alias": "fullstackedsplinearea"; "required": false; }; "highValueField": { "alias": "highValueField"; "required": false; }; "hoverMode": { "alias": "hoverMode"; "required": false; }; "hoverStyle": { "alias": "hoverStyle"; "required": false; }; "ignoreEmptyPoints": { "alias": "ignoreEmptyPoints"; "required": false; }; "innerColor": { "alias": "innerColor"; "required": false; }; "label": { "alias": "label"; "required": false; }; "line": { "alias": "line"; "required": false; }; "lowValueField": { "alias": "lowValueField"; "required": false; }; "maxLabelCount": { "alias": "maxLabelCount"; "required": false; }; "minBarSize": { "alias": "minBarSize"; "required": false; }; "opacity": { "alias": "opacity"; "required": false; }; "openValueField": { "alias": "openValueField"; "required": false; }; "pane": { "alias": "pane"; "required": false; }; "point": { "alias": "point"; "required": false; }; "rangearea": { "alias": "rangearea"; "required": false; }; "rangebar": { "alias": "rangebar"; "required": false; }; "rangeValue1Field": { "alias": "rangeValue1Field"; "required": false; }; "rangeValue2Field": { "alias": "rangeValue2Field"; "required": false; }; "reduction": { "alias": "reduction"; "required": false; }; "scatter": { "alias": "scatter"; "required": false; }; "selectionMode": { "alias": "selectionMode"; "required": false; }; "selectionStyle": { "alias": "selectionStyle"; "required": false; }; "showInLegend": { "alias": "showInLegend"; "required": false; }; "sizeField": { "alias": "sizeField"; "required": false; }; "spline": { "alias": "spline"; "required": false; }; "splinearea": { "alias": "splinearea"; "required": false; }; "stack": { "alias": "stack"; "required": false; }; "stackedarea": { "alias": "stackedarea"; "required": false; }; "stackedbar": { "alias": "stackedbar"; "required": false; }; "stackedline": { "alias": "stackedline"; "required": false; }; "stackedspline": { "alias": "stackedspline"; "required": false; }; "stackedsplinearea": { "alias": "stackedsplinearea"; "required": false; }; "steparea": { "alias": "steparea"; "required": false; }; "stepline": { "alias": "stepline"; "required": false; }; "stock": { "alias": "stock"; "required": false; }; "tagField": { "alias": "tagField"; "required": false; }; "type": { "alias": "type"; "required": false; }; "valueErrorBar": { "alias": "valueErrorBar"; "required": false; }; "valueField": { "alias": "valueField"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoStackedlineModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoStackedlineModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoStackedlineModule, never, [typeof DxoStackedlineComponent], [typeof DxoStackedlineComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoStackedlineModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoStackedsplineComponent extends DxoChartCommonSeriesSettings implements OnDestroy, OnInit {
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoStackedsplineComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoStackedsplineComponent, "dxo-stackedspline", never, { "aggregation": { "alias": "aggregation"; "required": false; }; "area": { "alias": "area"; "required": false; }; "argumentField": { "alias": "argumentField"; "required": false; }; "axis": { "alias": "axis"; "required": false; }; "bar": { "alias": "bar"; "required": false; }; "barOverlapGroup": { "alias": "barOverlapGroup"; "required": false; }; "barPadding": { "alias": "barPadding"; "required": false; }; "barWidth": { "alias": "barWidth"; "required": false; }; "border": { "alias": "border"; "required": false; }; "bubble": { "alias": "bubble"; "required": false; }; "candlestick": { "alias": "candlestick"; "required": false; }; "closeValueField": { "alias": "closeValueField"; "required": false; }; "color": { "alias": "color"; "required": false; }; "cornerRadius": { "alias": "cornerRadius"; "required": false; }; "dashStyle": { "alias": "dashStyle"; "required": false; }; "fullstackedarea": { "alias": "fullstackedarea"; "required": false; }; "fullstackedbar": { "alias": "fullstackedbar"; "required": false; }; "fullstackedline": { "alias": "fullstackedline"; "required": false; }; "fullstackedspline": { "alias": "fullstackedspline"; "required": false; }; "fullstackedsplinearea": { "alias": "fullstackedsplinearea"; "required": false; }; "highValueField": { "alias": "highValueField"; "required": false; }; "hoverMode": { "alias": "hoverMode"; "required": false; }; "hoverStyle": { "alias": "hoverStyle"; "required": false; }; "ignoreEmptyPoints": { "alias": "ignoreEmptyPoints"; "required": false; }; "innerColor": { "alias": "innerColor"; "required": false; }; "label": { "alias": "label"; "required": false; }; "line": { "alias": "line"; "required": false; }; "lowValueField": { "alias": "lowValueField"; "required": false; }; "maxLabelCount": { "alias": "maxLabelCount"; "required": false; }; "minBarSize": { "alias": "minBarSize"; "required": false; }; "opacity": { "alias": "opacity"; "required": false; }; "openValueField": { "alias": "openValueField"; "required": false; }; "pane": { "alias": "pane"; "required": false; }; "point": { "alias": "point"; "required": false; }; "rangearea": { "alias": "rangearea"; "required": false; }; "rangebar": { "alias": "rangebar"; "required": false; }; "rangeValue1Field": { "alias": "rangeValue1Field"; "required": false; }; "rangeValue2Field": { "alias": "rangeValue2Field"; "required": false; }; "reduction": { "alias": "reduction"; "required": false; }; "scatter": { "alias": "scatter"; "required": false; }; "selectionMode": { "alias": "selectionMode"; "required": false; }; "selectionStyle": { "alias": "selectionStyle"; "required": false; }; "showInLegend": { "alias": "showInLegend"; "required": false; }; "sizeField": { "alias": "sizeField"; "required": false; }; "spline": { "alias": "spline"; "required": false; }; "splinearea": { "alias": "splinearea"; "required": false; }; "stack": { "alias": "stack"; "required": false; }; "stackedarea": { "alias": "stackedarea"; "required": false; }; "stackedbar": { "alias": "stackedbar"; "required": false; }; "stackedline": { "alias": "stackedline"; "required": false; }; "stackedspline": { "alias": "stackedspline"; "required": false; }; "stackedsplinearea": { "alias": "stackedsplinearea"; "required": false; }; "steparea": { "alias": "steparea"; "required": false; }; "stepline": { "alias": "stepline"; "required": false; }; "stock": { "alias": "stock"; "required": false; }; "tagField": { "alias": "tagField"; "required": false; }; "type": { "alias": "type"; "required": false; }; "valueErrorBar": { "alias": "valueErrorBar"; "required": false; }; "valueField": { "alias": "valueField"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoStackedsplineModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoStackedsplineModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoStackedsplineModule, never, [typeof DxoStackedsplineComponent], [typeof DxoStackedsplineComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoStackedsplineModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoStackedsplineareaComponent extends DxoChartCommonSeriesSettings implements OnDestroy, OnInit {
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoStackedsplineareaComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoStackedsplineareaComponent, "dxo-stackedsplinearea", never, { "aggregation": { "alias": "aggregation"; "required": false; }; "area": { "alias": "area"; "required": false; }; "argumentField": { "alias": "argumentField"; "required": false; }; "axis": { "alias": "axis"; "required": false; }; "bar": { "alias": "bar"; "required": false; }; "barOverlapGroup": { "alias": "barOverlapGroup"; "required": false; }; "barPadding": { "alias": "barPadding"; "required": false; }; "barWidth": { "alias": "barWidth"; "required": false; }; "border": { "alias": "border"; "required": false; }; "bubble": { "alias": "bubble"; "required": false; }; "candlestick": { "alias": "candlestick"; "required": false; }; "closeValueField": { "alias": "closeValueField"; "required": false; }; "color": { "alias": "color"; "required": false; }; "cornerRadius": { "alias": "cornerRadius"; "required": false; }; "dashStyle": { "alias": "dashStyle"; "required": false; }; "fullstackedarea": { "alias": "fullstackedarea"; "required": false; }; "fullstackedbar": { "alias": "fullstackedbar"; "required": false; }; "fullstackedline": { "alias": "fullstackedline"; "required": false; }; "fullstackedspline": { "alias": "fullstackedspline"; "required": false; }; "fullstackedsplinearea": { "alias": "fullstackedsplinearea"; "required": false; }; "highValueField": { "alias": "highValueField"; "required": false; }; "hoverMode": { "alias": "hoverMode"; "required": false; }; "hoverStyle": { "alias": "hoverStyle"; "required": false; }; "ignoreEmptyPoints": { "alias": "ignoreEmptyPoints"; "required": false; }; "innerColor": { "alias": "innerColor"; "required": false; }; "label": { "alias": "label"; "required": false; }; "line": { "alias": "line"; "required": false; }; "lowValueField": { "alias": "lowValueField"; "required": false; }; "maxLabelCount": { "alias": "maxLabelCount"; "required": false; }; "minBarSize": { "alias": "minBarSize"; "required": false; }; "opacity": { "alias": "opacity"; "required": false; }; "openValueField": { "alias": "openValueField"; "required": false; }; "pane": { "alias": "pane"; "required": false; }; "point": { "alias": "point"; "required": false; }; "rangearea": { "alias": "rangearea"; "required": false; }; "rangebar": { "alias": "rangebar"; "required": false; }; "rangeValue1Field": { "alias": "rangeValue1Field"; "required": false; }; "rangeValue2Field": { "alias": "rangeValue2Field"; "required": false; }; "reduction": { "alias": "reduction"; "required": false; }; "scatter": { "alias": "scatter"; "required": false; }; "selectionMode": { "alias": "selectionMode"; "required": false; }; "selectionStyle": { "alias": "selectionStyle"; "required": false; }; "showInLegend": { "alias": "showInLegend"; "required": false; }; "sizeField": { "alias": "sizeField"; "required": false; }; "spline": { "alias": "spline"; "required": false; }; "splinearea": { "alias": "splinearea"; "required": false; }; "stack": { "alias": "stack"; "required": false; }; "stackedarea": { "alias": "stackedarea"; "required": false; }; "stackedbar": { "alias": "stackedbar"; "required": false; }; "stackedline": { "alias": "stackedline"; "required": false; }; "stackedspline": { "alias": "stackedspline"; "required": false; }; "stackedsplinearea": { "alias": "stackedsplinearea"; "required": false; }; "steparea": { "alias": "steparea"; "required": false; }; "stepline": { "alias": "stepline"; "required": false; }; "stock": { "alias": "stock"; "required": false; }; "tagField": { "alias": "tagField"; "required": false; }; "type": { "alias": "type"; "required": false; }; "valueErrorBar": { "alias": "valueErrorBar"; "required": false; }; "valueField": { "alias": "valueField"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoStackedsplineareaModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoStackedsplineareaModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoStackedsplineareaModule, never, [typeof DxoStackedsplineareaComponent], [typeof DxoStackedsplineareaComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoStackedsplineareaModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoStateStoringComponent extends NestedOption implements OnDestroy, OnInit {
    get customLoad(): Function;
    set customLoad(value: Function);
    get customSave(): Function;
    set customSave(value: Function);
    get enabled(): boolean;
    set enabled(value: boolean);
    get savingTimeout(): number;
    set savingTimeout(value: number);
    get storageKey(): string | undefined;
    set storageKey(value: string | undefined);
    get type(): StateStoreType;
    set type(value: StateStoreType);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoStateStoringComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoStateStoringComponent, "dxo-state-storing", never, { "customLoad": { "alias": "customLoad"; "required": false; }; "customSave": { "alias": "customSave"; "required": false; }; "enabled": { "alias": "enabled"; "required": false; }; "savingTimeout": { "alias": "savingTimeout"; "required": false; }; "storageKey": { "alias": "storageKey"; "required": false; }; "type": { "alias": "type"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoStateStoringModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoStateStoringModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoStateStoringModule, never, [typeof DxoStateStoringComponent], [typeof DxoStateStoringComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoStateStoringModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoStepareaComponent extends DxoChartCommonSeriesSettings implements OnDestroy, OnInit {
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoStepareaComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoStepareaComponent, "dxo-steparea", never, { "aggregation": { "alias": "aggregation"; "required": false; }; "area": { "alias": "area"; "required": false; }; "argumentField": { "alias": "argumentField"; "required": false; }; "axis": { "alias": "axis"; "required": false; }; "bar": { "alias": "bar"; "required": false; }; "barOverlapGroup": { "alias": "barOverlapGroup"; "required": false; }; "barPadding": { "alias": "barPadding"; "required": false; }; "barWidth": { "alias": "barWidth"; "required": false; }; "border": { "alias": "border"; "required": false; }; "bubble": { "alias": "bubble"; "required": false; }; "candlestick": { "alias": "candlestick"; "required": false; }; "closeValueField": { "alias": "closeValueField"; "required": false; }; "color": { "alias": "color"; "required": false; }; "cornerRadius": { "alias": "cornerRadius"; "required": false; }; "dashStyle": { "alias": "dashStyle"; "required": false; }; "fullstackedarea": { "alias": "fullstackedarea"; "required": false; }; "fullstackedbar": { "alias": "fullstackedbar"; "required": false; }; "fullstackedline": { "alias": "fullstackedline"; "required": false; }; "fullstackedspline": { "alias": "fullstackedspline"; "required": false; }; "fullstackedsplinearea": { "alias": "fullstackedsplinearea"; "required": false; }; "highValueField": { "alias": "highValueField"; "required": false; }; "hoverMode": { "alias": "hoverMode"; "required": false; }; "hoverStyle": { "alias": "hoverStyle"; "required": false; }; "ignoreEmptyPoints": { "alias": "ignoreEmptyPoints"; "required": false; }; "innerColor": { "alias": "innerColor"; "required": false; }; "label": { "alias": "label"; "required": false; }; "line": { "alias": "line"; "required": false; }; "lowValueField": { "alias": "lowValueField"; "required": false; }; "maxLabelCount": { "alias": "maxLabelCount"; "required": false; }; "minBarSize": { "alias": "minBarSize"; "required": false; }; "opacity": { "alias": "opacity"; "required": false; }; "openValueField": { "alias": "openValueField"; "required": false; }; "pane": { "alias": "pane"; "required": false; }; "point": { "alias": "point"; "required": false; }; "rangearea": { "alias": "rangearea"; "required": false; }; "rangebar": { "alias": "rangebar"; "required": false; }; "rangeValue1Field": { "alias": "rangeValue1Field"; "required": false; }; "rangeValue2Field": { "alias": "rangeValue2Field"; "required": false; }; "reduction": { "alias": "reduction"; "required": false; }; "scatter": { "alias": "scatter"; "required": false; }; "selectionMode": { "alias": "selectionMode"; "required": false; }; "selectionStyle": { "alias": "selectionStyle"; "required": false; }; "showInLegend": { "alias": "showInLegend"; "required": false; }; "sizeField": { "alias": "sizeField"; "required": false; }; "spline": { "alias": "spline"; "required": false; }; "splinearea": { "alias": "splinearea"; "required": false; }; "stack": { "alias": "stack"; "required": false; }; "stackedarea": { "alias": "stackedarea"; "required": false; }; "stackedbar": { "alias": "stackedbar"; "required": false; }; "stackedline": { "alias": "stackedline"; "required": false; }; "stackedspline": { "alias": "stackedspline"; "required": false; }; "stackedsplinearea": { "alias": "stackedsplinearea"; "required": false; }; "steparea": { "alias": "steparea"; "required": false; }; "stepline": { "alias": "stepline"; "required": false; }; "stock": { "alias": "stock"; "required": false; }; "tagField": { "alias": "tagField"; "required": false; }; "type": { "alias": "type"; "required": false; }; "valueErrorBar": { "alias": "valueErrorBar"; "required": false; }; "valueField": { "alias": "valueField"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoStepareaModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoStepareaModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoStepareaModule, never, [typeof DxoStepareaComponent], [typeof DxoStepareaComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoStepareaModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoSteplineComponent extends DxoChartCommonSeriesSettings implements OnDestroy, OnInit {
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoSteplineComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoSteplineComponent, "dxo-stepline", never, { "aggregation": { "alias": "aggregation"; "required": false; }; "area": { "alias": "area"; "required": false; }; "argumentField": { "alias": "argumentField"; "required": false; }; "axis": { "alias": "axis"; "required": false; }; "bar": { "alias": "bar"; "required": false; }; "barOverlapGroup": { "alias": "barOverlapGroup"; "required": false; }; "barPadding": { "alias": "barPadding"; "required": false; }; "barWidth": { "alias": "barWidth"; "required": false; }; "border": { "alias": "border"; "required": false; }; "bubble": { "alias": "bubble"; "required": false; }; "candlestick": { "alias": "candlestick"; "required": false; }; "closeValueField": { "alias": "closeValueField"; "required": false; }; "color": { "alias": "color"; "required": false; }; "cornerRadius": { "alias": "cornerRadius"; "required": false; }; "dashStyle": { "alias": "dashStyle"; "required": false; }; "fullstackedarea": { "alias": "fullstackedarea"; "required": false; }; "fullstackedbar": { "alias": "fullstackedbar"; "required": false; }; "fullstackedline": { "alias": "fullstackedline"; "required": false; }; "fullstackedspline": { "alias": "fullstackedspline"; "required": false; }; "fullstackedsplinearea": { "alias": "fullstackedsplinearea"; "required": false; }; "highValueField": { "alias": "highValueField"; "required": false; }; "hoverMode": { "alias": "hoverMode"; "required": false; }; "hoverStyle": { "alias": "hoverStyle"; "required": false; }; "ignoreEmptyPoints": { "alias": "ignoreEmptyPoints"; "required": false; }; "innerColor": { "alias": "innerColor"; "required": false; }; "label": { "alias": "label"; "required": false; }; "line": { "alias": "line"; "required": false; }; "lowValueField": { "alias": "lowValueField"; "required": false; }; "maxLabelCount": { "alias": "maxLabelCount"; "required": false; }; "minBarSize": { "alias": "minBarSize"; "required": false; }; "opacity": { "alias": "opacity"; "required": false; }; "openValueField": { "alias": "openValueField"; "required": false; }; "pane": { "alias": "pane"; "required": false; }; "point": { "alias": "point"; "required": false; }; "rangearea": { "alias": "rangearea"; "required": false; }; "rangebar": { "alias": "rangebar"; "required": false; }; "rangeValue1Field": { "alias": "rangeValue1Field"; "required": false; }; "rangeValue2Field": { "alias": "rangeValue2Field"; "required": false; }; "reduction": { "alias": "reduction"; "required": false; }; "scatter": { "alias": "scatter"; "required": false; }; "selectionMode": { "alias": "selectionMode"; "required": false; }; "selectionStyle": { "alias": "selectionStyle"; "required": false; }; "showInLegend": { "alias": "showInLegend"; "required": false; }; "sizeField": { "alias": "sizeField"; "required": false; }; "spline": { "alias": "spline"; "required": false; }; "splinearea": { "alias": "splinearea"; "required": false; }; "stack": { "alias": "stack"; "required": false; }; "stackedarea": { "alias": "stackedarea"; "required": false; }; "stackedbar": { "alias": "stackedbar"; "required": false; }; "stackedline": { "alias": "stackedline"; "required": false; }; "stackedspline": { "alias": "stackedspline"; "required": false; }; "stackedsplinearea": { "alias": "stackedsplinearea"; "required": false; }; "steparea": { "alias": "steparea"; "required": false; }; "stepline": { "alias": "stepline"; "required": false; }; "stock": { "alias": "stock"; "required": false; }; "tagField": { "alias": "tagField"; "required": false; }; "type": { "alias": "type"; "required": false; }; "valueErrorBar": { "alias": "valueErrorBar"; "required": false; }; "valueField": { "alias": "valueField"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoSteplineModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoSteplineModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoSteplineModule, never, [typeof DxoSteplineComponent], [typeof DxoSteplineComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoSteplineModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoStockComponent extends DxoChartCommonSeriesSettings implements OnDestroy, OnInit {
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoStockComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoStockComponent, "dxo-stock", never, { "aggregation": { "alias": "aggregation"; "required": false; }; "area": { "alias": "area"; "required": false; }; "argumentField": { "alias": "argumentField"; "required": false; }; "axis": { "alias": "axis"; "required": false; }; "bar": { "alias": "bar"; "required": false; }; "barOverlapGroup": { "alias": "barOverlapGroup"; "required": false; }; "barPadding": { "alias": "barPadding"; "required": false; }; "barWidth": { "alias": "barWidth"; "required": false; }; "border": { "alias": "border"; "required": false; }; "bubble": { "alias": "bubble"; "required": false; }; "candlestick": { "alias": "candlestick"; "required": false; }; "closeValueField": { "alias": "closeValueField"; "required": false; }; "color": { "alias": "color"; "required": false; }; "cornerRadius": { "alias": "cornerRadius"; "required": false; }; "dashStyle": { "alias": "dashStyle"; "required": false; }; "fullstackedarea": { "alias": "fullstackedarea"; "required": false; }; "fullstackedbar": { "alias": "fullstackedbar"; "required": false; }; "fullstackedline": { "alias": "fullstackedline"; "required": false; }; "fullstackedspline": { "alias": "fullstackedspline"; "required": false; }; "fullstackedsplinearea": { "alias": "fullstackedsplinearea"; "required": false; }; "highValueField": { "alias": "highValueField"; "required": false; }; "hoverMode": { "alias": "hoverMode"; "required": false; }; "hoverStyle": { "alias": "hoverStyle"; "required": false; }; "ignoreEmptyPoints": { "alias": "ignoreEmptyPoints"; "required": false; }; "innerColor": { "alias": "innerColor"; "required": false; }; "label": { "alias": "label"; "required": false; }; "line": { "alias": "line"; "required": false; }; "lowValueField": { "alias": "lowValueField"; "required": false; }; "maxLabelCount": { "alias": "maxLabelCount"; "required": false; }; "minBarSize": { "alias": "minBarSize"; "required": false; }; "opacity": { "alias": "opacity"; "required": false; }; "openValueField": { "alias": "openValueField"; "required": false; }; "pane": { "alias": "pane"; "required": false; }; "point": { "alias": "point"; "required": false; }; "rangearea": { "alias": "rangearea"; "required": false; }; "rangebar": { "alias": "rangebar"; "required": false; }; "rangeValue1Field": { "alias": "rangeValue1Field"; "required": false; }; "rangeValue2Field": { "alias": "rangeValue2Field"; "required": false; }; "reduction": { "alias": "reduction"; "required": false; }; "scatter": { "alias": "scatter"; "required": false; }; "selectionMode": { "alias": "selectionMode"; "required": false; }; "selectionStyle": { "alias": "selectionStyle"; "required": false; }; "showInLegend": { "alias": "showInLegend"; "required": false; }; "sizeField": { "alias": "sizeField"; "required": false; }; "spline": { "alias": "spline"; "required": false; }; "splinearea": { "alias": "splinearea"; "required": false; }; "stack": { "alias": "stack"; "required": false; }; "stackedarea": { "alias": "stackedarea"; "required": false; }; "stackedbar": { "alias": "stackedbar"; "required": false; }; "stackedline": { "alias": "stackedline"; "required": false; }; "stackedspline": { "alias": "stackedspline"; "required": false; }; "stackedsplinearea": { "alias": "stackedsplinearea"; "required": false; }; "steparea": { "alias": "steparea"; "required": false; }; "stepline": { "alias": "stepline"; "required": false; }; "stock": { "alias": "stock"; "required": false; }; "tagField": { "alias": "tagField"; "required": false; }; "type": { "alias": "type"; "required": false; }; "valueErrorBar": { "alias": "valueErrorBar"; "required": false; }; "valueField": { "alias": "valueField"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoStockModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoStockModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoStockModule, never, [typeof DxoStockComponent], [typeof DxoStockComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoStockModule>;
}

declare class DxiStripComponent extends CollectionNestedOption {
    get color(): string | undefined;
    set color(value: string | undefined);
    get endValue(): Date | number | string | undefined;
    set endValue(value: Date | number | string | undefined);
    get label(): {
        font?: Font;
        horizontalAlignment?: HorizontalAlignment;
        text?: string | undefined;
        verticalAlignment?: VerticalAlignment;
    } | {
        font?: Font;
        text?: string | undefined;
    };
    set label(value: {
        font?: Font;
        horizontalAlignment?: HorizontalAlignment;
        text?: string | undefined;
        verticalAlignment?: VerticalAlignment;
    } | {
        font?: Font;
        text?: string | undefined;
    });
    get paddingLeftRight(): number;
    set paddingLeftRight(value: number);
    get paddingTopBottom(): number;
    set paddingTopBottom(value: number);
    get startValue(): Date | number | string | undefined;
    set startValue(value: Date | number | string | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiStripComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiStripComponent, "dxi-strip", never, { "color": { "alias": "color"; "required": false; }; "endValue": { "alias": "endValue"; "required": false; }; "label": { "alias": "label"; "required": false; }; "paddingLeftRight": { "alias": "paddingLeftRight"; "required": false; }; "paddingTopBottom": { "alias": "paddingTopBottom"; "required": false; }; "startValue": { "alias": "startValue"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxiStripModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiStripModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiStripModule, never, [typeof DxiStripComponent], [typeof DxiStripComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiStripModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare abstract class DxiGanttStripLine extends CollectionNestedOption {
    get cssClass(): string | undefined;
    set cssClass(value: string | undefined);
    get end(): Date | number | Function | string | undefined;
    set end(value: Date | number | Function | string | undefined);
    get start(): Date | number | Function | string | undefined;
    set start(value: Date | number | Function | string | undefined);
    get title(): string | undefined;
    set title(value: string | undefined);
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiGanttStripLine, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiGanttStripLine, "ng-component", never, {}, {}, never, never, true, never>;
}

declare class DxiStripLineComponent extends DxiGanttStripLine {
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiStripLineComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiStripLineComponent, "dxi-strip-line", never, { "cssClass": { "alias": "cssClass"; "required": false; }; "end": { "alias": "end"; "required": false; }; "start": { "alias": "start"; "required": false; }; "title": { "alias": "title"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxiStripLineModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiStripLineModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiStripLineModule, never, [typeof DxiStripLineComponent], [typeof DxiStripLineComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiStripLineModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoStripStyleComponent extends NestedOption implements OnDestroy, OnInit {
    get label(): {
        font?: Font;
        horizontalAlignment?: HorizontalAlignment;
        verticalAlignment?: VerticalAlignment;
    } | {
        font?: Font;
    };
    set label(value: {
        font?: Font;
        horizontalAlignment?: HorizontalAlignment;
        verticalAlignment?: VerticalAlignment;
    } | {
        font?: Font;
    });
    get paddingLeftRight(): number;
    set paddingLeftRight(value: number);
    get paddingTopBottom(): number;
    set paddingTopBottom(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoStripStyleComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoStripStyleComponent, "dxo-strip-style", never, { "label": { "alias": "label"; "required": false; }; "paddingLeftRight": { "alias": "paddingLeftRight"; "required": false; }; "paddingTopBottom": { "alias": "paddingTopBottom"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoStripStyleModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoStripStyleModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoStripStyleModule, never, [typeof DxoStripStyleComponent], [typeof DxoStripStyleComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoStripStyleModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoSubtitleComponent extends NestedOption implements OnDestroy, OnInit {
    get font(): Font;
    set font(value: Font);
    get offset(): number;
    set offset(value: number);
    get text(): string | undefined;
    set text(value: string | undefined);
    get textOverflow(): TextOverflow;
    set textOverflow(value: TextOverflow);
    get wordWrap(): WordWrap;
    set wordWrap(value: WordWrap);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoSubtitleComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoSubtitleComponent, "dxo-subtitle", never, { "font": { "alias": "font"; "required": false; }; "offset": { "alias": "offset"; "required": false; }; "text": { "alias": "text"; "required": false; }; "textOverflow": { "alias": "textOverflow"; "required": false; }; "wordWrap": { "alias": "wordWrap"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoSubtitleModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoSubtitleModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoSubtitleModule, never, [typeof DxoSubtitleComponent], [typeof DxoSubtitleComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoSubtitleModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare abstract class DxoGaugeIndicator extends NestedOption {
    get arrowLength(): number;
    set arrowLength(value: number);
    get backgroundColor(): string;
    set backgroundColor(value: string);
    get baseValue(): number | undefined;
    set baseValue(value: number | undefined);
    get beginAdaptingAtRadius(): number;
    set beginAdaptingAtRadius(value: number);
    get color(): ChartsColor | string;
    set color(value: ChartsColor | string);
    get horizontalOrientation(): HorizontalEdge;
    set horizontalOrientation(value: HorizontalEdge);
    get indentFromCenter(): number;
    set indentFromCenter(value: number);
    get length(): number;
    set length(value: number);
    get offset(): number;
    set offset(value: number);
    get palette(): Palette | string | Array<string>;
    set palette(value: Palette | string | Array<string>);
    get secondColor(): string;
    set secondColor(value: string);
    get secondFraction(): number;
    set secondFraction(value: number);
    get size(): number;
    set size(value: number);
    get spindleGapSize(): number;
    set spindleGapSize(value: number);
    get spindleSize(): number;
    set spindleSize(value: number);
    get text(): {
        customizeText?: Function | undefined;
        font?: Font;
        format?: Format | string | undefined;
        indent?: number;
    };
    set text(value: {
        customizeText?: Function | undefined;
        font?: Font;
        format?: Format | string | undefined;
        indent?: number;
    });
    get type(): string;
    set type(value: string);
    get verticalOrientation(): VerticalEdge;
    set verticalOrientation(value: VerticalEdge);
    get width(): number;
    set width(value: number);
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoGaugeIndicator, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoGaugeIndicator, "ng-component", never, {}, {}, never, never, true, never>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoSubvalueIndicatorComponent extends DxoGaugeIndicator implements OnDestroy, OnInit {
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoSubvalueIndicatorComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoSubvalueIndicatorComponent, "dxo-subvalue-indicator", never, { "arrowLength": { "alias": "arrowLength"; "required": false; }; "backgroundColor": { "alias": "backgroundColor"; "required": false; }; "baseValue": { "alias": "baseValue"; "required": false; }; "beginAdaptingAtRadius": { "alias": "beginAdaptingAtRadius"; "required": false; }; "color": { "alias": "color"; "required": false; }; "horizontalOrientation": { "alias": "horizontalOrientation"; "required": false; }; "indentFromCenter": { "alias": "indentFromCenter"; "required": false; }; "length": { "alias": "length"; "required": false; }; "offset": { "alias": "offset"; "required": false; }; "palette": { "alias": "palette"; "required": false; }; "secondColor": { "alias": "secondColor"; "required": false; }; "secondFraction": { "alias": "secondFraction"; "required": false; }; "size": { "alias": "size"; "required": false; }; "spindleGapSize": { "alias": "spindleGapSize"; "required": false; }; "spindleSize": { "alias": "spindleSize"; "required": false; }; "text": { "alias": "text"; "required": false; }; "type": { "alias": "type"; "required": false; }; "verticalOrientation": { "alias": "verticalOrientation"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoSubvalueIndicatorModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoSubvalueIndicatorModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoSubvalueIndicatorModule, never, [typeof DxoSubvalueIndicatorComponent], [typeof DxoSubvalueIndicatorComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoSubvalueIndicatorModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoSummaryComponent extends NestedOption implements OnDestroy, OnInit {
    set _groupItemsContentChildren(value: QueryList<CollectionNestedOption>);
    set _totalItemsContentChildren(value: QueryList<CollectionNestedOption>);
    get calculateCustomSummary(): Function;
    set calculateCustomSummary(value: Function);
    get groupItems(): Array<any | {
        alignByColumn?: boolean;
        column?: string | undefined;
        customizeText?: Function;
        displayFormat?: string | undefined;
        name?: string | undefined;
        showInColumn?: string | undefined;
        showInGroupFooter?: boolean;
        skipEmptyValues?: boolean;
        summaryType?: SummaryType | string | undefined;
        valueFormat?: Format | string | undefined;
    }>;
    set groupItems(value: Array<any | {
        alignByColumn?: boolean;
        column?: string | undefined;
        customizeText?: Function;
        displayFormat?: string | undefined;
        name?: string | undefined;
        showInColumn?: string | undefined;
        showInGroupFooter?: boolean;
        skipEmptyValues?: boolean;
        summaryType?: SummaryType | string | undefined;
        valueFormat?: Format | string | undefined;
    }>);
    get recalculateWhileEditing(): boolean;
    set recalculateWhileEditing(value: boolean);
    get skipEmptyValues(): boolean;
    set skipEmptyValues(value: boolean);
    get texts(): {
        avg?: string;
        avgOtherColumn?: string;
        count?: string;
        max?: string;
        maxOtherColumn?: string;
        min?: string;
        minOtherColumn?: string;
        sum?: string;
        sumOtherColumn?: string;
    };
    set texts(value: {
        avg?: string;
        avgOtherColumn?: string;
        count?: string;
        max?: string;
        maxOtherColumn?: string;
        min?: string;
        minOtherColumn?: string;
        sum?: string;
        sumOtherColumn?: string;
    });
    get totalItems(): Array<any | {
        alignment?: HorizontalAlignment | undefined;
        column?: string | undefined;
        cssClass?: string | undefined;
        customizeText?: Function;
        displayFormat?: string | undefined;
        name?: string | undefined;
        showInColumn?: string | undefined;
        skipEmptyValues?: boolean;
        summaryType?: SummaryType | string | undefined;
        valueFormat?: Format | string | undefined;
    }>;
    set totalItems(value: Array<any | {
        alignment?: HorizontalAlignment | undefined;
        column?: string | undefined;
        cssClass?: string | undefined;
        customizeText?: Function;
        displayFormat?: string | undefined;
        name?: string | undefined;
        showInColumn?: string | undefined;
        skipEmptyValues?: boolean;
        summaryType?: SummaryType | string | undefined;
        valueFormat?: Format | string | undefined;
    }>);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoSummaryComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoSummaryComponent, "dxo-summary", never, { "calculateCustomSummary": { "alias": "calculateCustomSummary"; "required": false; }; "groupItems": { "alias": "groupItems"; "required": false; }; "recalculateWhileEditing": { "alias": "recalculateWhileEditing"; "required": false; }; "skipEmptyValues": { "alias": "skipEmptyValues"; "required": false; }; "texts": { "alias": "texts"; "required": false; }; "totalItems": { "alias": "totalItems"; "required": false; }; }, {}, ["_groupItemsContentChildren", "_totalItemsContentChildren"], never, true, never>;
}
declare class DxoSummaryModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoSummaryModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoSummaryModule, never, [typeof DxoSummaryComponent], [typeof DxoSummaryComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoSummaryModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare abstract class DxiHtmlEditorImageUploadTabItem extends CollectionNestedOption {
    get alignItemLabels(): boolean;
    set alignItemLabels(value: boolean);
    get badge(): string | undefined;
    set badge(value: string | undefined);
    get colCount(): number;
    set colCount(value: number);
    get colCountByScreen(): {
        lg?: number | undefined;
        md?: number | undefined;
        sm?: number | undefined;
        xs?: number | undefined;
    };
    set colCountByScreen(value: {
        lg?: number | undefined;
        md?: number | undefined;
        sm?: number | undefined;
        xs?: number | undefined;
    });
    get disabled(): boolean;
    set disabled(value: boolean);
    get icon(): string | undefined;
    set icon(value: string | undefined);
    get items(): Array<SimpleItem | GroupItem | TabbedItem | EmptyItem | ButtonItem>;
    set items(value: Array<SimpleItem | GroupItem | TabbedItem | EmptyItem | ButtonItem>);
    get tabTemplate(): any | undefined;
    set tabTemplate(value: any | undefined);
    get template(): any | undefined;
    set template(value: any | undefined);
    get title(): string | undefined;
    set title(value: string | undefined);
    get commands(): Array<CustomCommand | Command>;
    set commands(value: Array<CustomCommand | Command>);
    get groups(): Array<any | {
        commands?: Array<CustomCommand | Command>;
        title?: string;
    }>;
    set groups(value: Array<any | {
        commands?: Array<CustomCommand | Command>;
        title?: string;
    }>);
    get name(): HtmlEditorImageUploadTab | undefined;
    set name(value: HtmlEditorImageUploadTab | undefined);
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiHtmlEditorImageUploadTabItem, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiHtmlEditorImageUploadTabItem, "ng-component", never, {}, {}, never, never, true, never>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxiTabComponent extends DxiHtmlEditorImageUploadTabItem implements AfterViewInit, IDxTemplateHost {
    private renderer;
    private document;
    private element;
    set _itemsContentChildren(value: QueryList<CollectionNestedOption>);
    set _commandsContentChildren(value: QueryList<CollectionNestedOption>);
    set _groupsContentChildren(value: QueryList<CollectionNestedOption>);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost, renderer: Renderer2, document: any, templateHost: DxTemplateHost, element: ElementRef);
    setTemplate(template: DxTemplateDirective): void;
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiTabComponent, [{ host: true; skipSelf: true; }, { host: true; }, null, null, { host: true; }, null]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiTabComponent, "dxi-tab", never, { "alignItemLabels": { "alias": "alignItemLabels"; "required": false; }; "badge": { "alias": "badge"; "required": false; }; "colCount": { "alias": "colCount"; "required": false; }; "colCountByScreen": { "alias": "colCountByScreen"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "icon": { "alias": "icon"; "required": false; }; "items": { "alias": "items"; "required": false; }; "tabTemplate": { "alias": "tabTemplate"; "required": false; }; "template": { "alias": "template"; "required": false; }; "title": { "alias": "title"; "required": false; }; "commands": { "alias": "commands"; "required": false; }; "groups": { "alias": "groups"; "required": false; }; "name": { "alias": "name"; "required": false; }; }, {}, ["_itemsContentChildren", "_commandsContentChildren", "_groupsContentChildren"], ["*"], true, never>;
}
declare class DxiTabModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiTabModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiTabModule, never, [typeof DxiTabComponent], [typeof DxiTabComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiTabModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare abstract class DxoTabPanelOptions extends NestedOption {
    get accessKey(): string | undefined;
    set accessKey(value: string | undefined);
    get activeStateEnabled(): boolean;
    set activeStateEnabled(value: boolean);
    get animationEnabled(): boolean;
    set animationEnabled(value: boolean);
    get dataSource(): Store | DataSource | Options | null | string | Array<dxTabPanelItem | string | any>;
    set dataSource(value: Store | DataSource | Options | null | string | Array<dxTabPanelItem | string | any>);
    get deferRendering(): boolean;
    set deferRendering(value: boolean);
    get disabled(): boolean;
    set disabled(value: boolean);
    get elementAttr(): any;
    set elementAttr(value: any);
    get focusStateEnabled(): boolean;
    set focusStateEnabled(value: boolean);
    get height(): number | string | undefined;
    set height(value: number | string | undefined);
    get hint(): string | undefined;
    set hint(value: string | undefined);
    get hoverStateEnabled(): boolean;
    set hoverStateEnabled(value: boolean);
    get iconPosition(): TabsIconPosition;
    set iconPosition(value: TabsIconPosition);
    get itemHoldTimeout(): number;
    set itemHoldTimeout(value: number);
    get items(): Array<string | any | {
        badge?: string;
        disabled?: boolean;
        html?: string;
        icon?: string;
        tabTemplate?: any;
        template?: any;
        text?: string;
        title?: string;
        visible?: boolean;
    }>;
    set items(value: Array<string | any | {
        badge?: string;
        disabled?: boolean;
        html?: string;
        icon?: string;
        tabTemplate?: any;
        template?: any;
        text?: string;
        title?: string;
        visible?: boolean;
    }>);
    get itemTemplate(): any;
    set itemTemplate(value: any);
    get itemTitleTemplate(): any;
    set itemTitleTemplate(value: any);
    get keyExpr(): Function | string;
    set keyExpr(value: Function | string);
    get loop(): boolean;
    set loop(value: boolean);
    get noDataText(): string;
    set noDataText(value: string);
    get onContentReady(): ((e: ContentReadyEvent$7) => void);
    set onContentReady(value: ((e: ContentReadyEvent$7) => void));
    get onDisposing(): ((e: DisposingEvent$9) => void);
    set onDisposing(value: ((e: DisposingEvent$9) => void));
    get onInitialized(): ((e: InitializedEvent$9) => void);
    set onInitialized(value: ((e: InitializedEvent$9) => void));
    get onItemClick(): ((e: ItemClickEvent$2) => void);
    set onItemClick(value: ((e: ItemClickEvent$2) => void));
    get onItemContextMenu(): ((e: ItemContextMenuEvent$2) => void);
    set onItemContextMenu(value: ((e: ItemContextMenuEvent$2) => void));
    get onItemHold(): ((e: ItemHoldEvent$1) => void);
    set onItemHold(value: ((e: ItemHoldEvent$1) => void));
    get onItemRendered(): ((e: ItemRenderedEvent$2) => void);
    set onItemRendered(value: ((e: ItemRenderedEvent$2) => void));
    get onOptionChanged(): ((e: OptionChangedEvent$9) => void);
    set onOptionChanged(value: ((e: OptionChangedEvent$9) => void));
    get onSelectionChanged(): ((e: SelectionChangedEvent) => void);
    set onSelectionChanged(value: ((e: SelectionChangedEvent) => void));
    get onSelectionChanging(): ((e: SelectionChangingEvent) => void);
    set onSelectionChanging(value: ((e: SelectionChangingEvent) => void));
    get onTitleClick(): ((e: TitleClickEvent) => void);
    set onTitleClick(value: ((e: TitleClickEvent) => void));
    get onTitleHold(): ((e: TitleHoldEvent) => void);
    set onTitleHold(value: ((e: TitleHoldEvent) => void));
    get onTitleRendered(): ((e: TitleRenderedEvent) => void);
    set onTitleRendered(value: ((e: TitleRenderedEvent) => void));
    get repaintChangesOnly(): boolean;
    set repaintChangesOnly(value: boolean);
    get rtlEnabled(): boolean;
    set rtlEnabled(value: boolean);
    get scrollByContent(): boolean;
    set scrollByContent(value: boolean);
    get scrollingEnabled(): boolean;
    set scrollingEnabled(value: boolean);
    get selectedIndex(): number;
    set selectedIndex(value: number);
    get selectedItem(): any | null;
    set selectedItem(value: any | null);
    get showNavButtons(): boolean;
    set showNavButtons(value: boolean);
    get stylingMode(): TabsStyle;
    set stylingMode(value: TabsStyle);
    get swipeEnabled(): boolean;
    set swipeEnabled(value: boolean);
    get tabIndex(): number;
    set tabIndex(value: number);
    get tabsPosition(): Position;
    set tabsPosition(value: Position);
    get visible(): boolean;
    set visible(value: boolean);
    get width(): number | string | undefined;
    set width(value: number | string | undefined);
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTabPanelOptions, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoTabPanelOptions, "ng-component", never, {}, {}, never, never, true, never>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoTabPanelOptionsComponent extends DxoTabPanelOptions implements OnDestroy, OnInit {
    set _itemsContentChildren(value: QueryList<CollectionNestedOption>);
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    itemsChange: EventEmitter<Array<string | any | {
        badge?: string;
        disabled?: boolean;
        html?: string;
        icon?: string;
        tabTemplate?: any;
        template?: any;
        text?: string;
        title?: string;
        visible?: boolean;
    }>>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    selectedIndexChange: EventEmitter<number>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    selectedItemChange: EventEmitter<any | null>;
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTabPanelOptionsComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoTabPanelOptionsComponent, "dxo-tab-panel-options", never, { "accessKey": { "alias": "accessKey"; "required": false; }; "activeStateEnabled": { "alias": "activeStateEnabled"; "required": false; }; "animationEnabled": { "alias": "animationEnabled"; "required": false; }; "dataSource": { "alias": "dataSource"; "required": false; }; "deferRendering": { "alias": "deferRendering"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "elementAttr": { "alias": "elementAttr"; "required": false; }; "focusStateEnabled": { "alias": "focusStateEnabled"; "required": false; }; "height": { "alias": "height"; "required": false; }; "hint": { "alias": "hint"; "required": false; }; "hoverStateEnabled": { "alias": "hoverStateEnabled"; "required": false; }; "iconPosition": { "alias": "iconPosition"; "required": false; }; "itemHoldTimeout": { "alias": "itemHoldTimeout"; "required": false; }; "items": { "alias": "items"; "required": false; }; "itemTemplate": { "alias": "itemTemplate"; "required": false; }; "itemTitleTemplate": { "alias": "itemTitleTemplate"; "required": false; }; "keyExpr": { "alias": "keyExpr"; "required": false; }; "loop": { "alias": "loop"; "required": false; }; "noDataText": { "alias": "noDataText"; "required": false; }; "onContentReady": { "alias": "onContentReady"; "required": false; }; "onDisposing": { "alias": "onDisposing"; "required": false; }; "onInitialized": { "alias": "onInitialized"; "required": false; }; "onItemClick": { "alias": "onItemClick"; "required": false; }; "onItemContextMenu": { "alias": "onItemContextMenu"; "required": false; }; "onItemHold": { "alias": "onItemHold"; "required": false; }; "onItemRendered": { "alias": "onItemRendered"; "required": false; }; "onOptionChanged": { "alias": "onOptionChanged"; "required": false; }; "onSelectionChanged": { "alias": "onSelectionChanged"; "required": false; }; "onSelectionChanging": { "alias": "onSelectionChanging"; "required": false; }; "onTitleClick": { "alias": "onTitleClick"; "required": false; }; "onTitleHold": { "alias": "onTitleHold"; "required": false; }; "onTitleRendered": { "alias": "onTitleRendered"; "required": false; }; "repaintChangesOnly": { "alias": "repaintChangesOnly"; "required": false; }; "rtlEnabled": { "alias": "rtlEnabled"; "required": false; }; "scrollByContent": { "alias": "scrollByContent"; "required": false; }; "scrollingEnabled": { "alias": "scrollingEnabled"; "required": false; }; "selectedIndex": { "alias": "selectedIndex"; "required": false; }; "selectedItem": { "alias": "selectedItem"; "required": false; }; "showNavButtons": { "alias": "showNavButtons"; "required": false; }; "stylingMode": { "alias": "stylingMode"; "required": false; }; "swipeEnabled": { "alias": "swipeEnabled"; "required": false; }; "tabIndex": { "alias": "tabIndex"; "required": false; }; "tabsPosition": { "alias": "tabsPosition"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, { "itemsChange": "itemsChange"; "selectedIndexChange": "selectedIndexChange"; "selectedItemChange": "selectedItemChange"; }, ["_itemsContentChildren"], never, true, never>;
}
declare class DxoTabPanelOptionsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTabPanelOptionsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoTabPanelOptionsModule, never, [typeof DxoTabPanelOptionsComponent], [typeof DxoTabPanelOptionsComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoTabPanelOptionsModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare abstract class DxoHtmlEditorTableContextMenu extends NestedOption {
    get enabled(): boolean;
    set enabled(value: boolean);
    get items(): Array<HtmlEditorPredefinedContextMenuItem | any | {
        beginGroup?: boolean;
        closeMenuOnClick?: boolean;
        disabled?: boolean;
        icon?: string;
        items?: Array<HtmlEditorPredefinedContextMenuItem | any>;
        name?: HtmlEditorPredefinedContextMenuItem | undefined;
        selectable?: boolean;
        selected?: boolean;
        template?: any;
        text?: string;
        visible?: boolean;
    }>;
    set items(value: Array<HtmlEditorPredefinedContextMenuItem | any | {
        beginGroup?: boolean;
        closeMenuOnClick?: boolean;
        disabled?: boolean;
        icon?: string;
        items?: Array<HtmlEditorPredefinedContextMenuItem | any>;
        name?: HtmlEditorPredefinedContextMenuItem | undefined;
        selectable?: boolean;
        selected?: boolean;
        template?: any;
        text?: string;
        visible?: boolean;
    }>);
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoHtmlEditorTableContextMenu, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoHtmlEditorTableContextMenu, "ng-component", never, {}, {}, never, never, true, never>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoTableContextMenuComponent extends DxoHtmlEditorTableContextMenu implements OnDestroy, OnInit {
    set _itemsContentChildren(value: QueryList<CollectionNestedOption>);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTableContextMenuComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoTableContextMenuComponent, "dxo-table-context-menu", never, { "enabled": { "alias": "enabled"; "required": false; }; "items": { "alias": "items"; "required": false; }; }, {}, ["_itemsContentChildren"], never, true, never>;
}
declare class DxoTableContextMenuModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTableContextMenuModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoTableContextMenuModule, never, [typeof DxoTableContextMenuComponent], [typeof DxoTableContextMenuComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoTableContextMenuModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare abstract class DxoHtmlEditorTableResizing extends NestedOption {
    get enabled(): boolean;
    set enabled(value: boolean);
    get minColumnWidth(): number;
    set minColumnWidth(value: number);
    get minRowHeight(): number;
    set minRowHeight(value: number);
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoHtmlEditorTableResizing, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoHtmlEditorTableResizing, "ng-component", never, {}, {}, never, never, true, never>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoTableResizingComponent extends DxoHtmlEditorTableResizing implements OnDestroy, OnInit {
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTableResizingComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoTableResizingComponent, "dxo-table-resizing", never, { "enabled": { "alias": "enabled"; "required": false; }; "minColumnWidth": { "alias": "minColumnWidth"; "required": false; }; "minRowHeight": { "alias": "minRowHeight"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoTableResizingModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTableResizingModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoTableResizingModule, never, [typeof DxoTableResizingComponent], [typeof DxoTableResizingComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoTableResizingModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoTasksComponent extends NestedOption implements OnDestroy, OnInit {
    get colorExpr(): Function | string;
    set colorExpr(value: Function | string);
    get dataSource(): Store | DataSource | Options | null | string | Array<any>;
    set dataSource(value: Store | DataSource | Options | null | string | Array<any>);
    get endExpr(): Function | string;
    set endExpr(value: Function | string);
    get keyExpr(): Function | string;
    set keyExpr(value: Function | string);
    get parentIdExpr(): Function | string;
    set parentIdExpr(value: Function | string);
    get progressExpr(): Function | string;
    set progressExpr(value: Function | string);
    get startExpr(): Function | string;
    set startExpr(value: Function | string);
    get titleExpr(): Function | string;
    set titleExpr(value: Function | string);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTasksComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoTasksComponent, "dxo-tasks", never, { "colorExpr": { "alias": "colorExpr"; "required": false; }; "dataSource": { "alias": "dataSource"; "required": false; }; "endExpr": { "alias": "endExpr"; "required": false; }; "keyExpr": { "alias": "keyExpr"; "required": false; }; "parentIdExpr": { "alias": "parentIdExpr"; "required": false; }; "progressExpr": { "alias": "progressExpr"; "required": false; }; "startExpr": { "alias": "startExpr"; "required": false; }; "titleExpr": { "alias": "titleExpr"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoTasksModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTasksModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoTasksModule, never, [typeof DxoTasksComponent], [typeof DxoTasksComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoTasksModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoTextComponent extends NestedOption implements OnDestroy, OnInit {
    get customizeText(): Function | undefined;
    set customizeText(value: Function | undefined);
    get font(): Font;
    set font(value: Font);
    get format(): Format | string | undefined;
    set format(value: Format | string | undefined);
    get indent(): number;
    set indent(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTextComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoTextComponent, "dxo-text", never, { "customizeText": { "alias": "customizeText"; "required": false; }; "font": { "alias": "font"; "required": false; }; "format": { "alias": "format"; "required": false; }; "indent": { "alias": "indent"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoTextModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTextModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoTextModule, never, [typeof DxoTextComponent], [typeof DxoTextComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoTextModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare abstract class DxoFilterPanelTexts extends NestedOption {
    get fix(): string;
    set fix(value: string);
    get leftPosition(): string;
    set leftPosition(value: string);
    get rightPosition(): string;
    set rightPosition(value: string);
    get stickyPosition(): string;
    set stickyPosition(value: string);
    get unfix(): string;
    set unfix(value: string);
    get addRow(): string;
    set addRow(value: string);
    get cancelAllChanges(): string;
    set cancelAllChanges(value: string);
    get cancelRowChanges(): string;
    set cancelRowChanges(value: string);
    get confirmDeleteMessage(): string;
    set confirmDeleteMessage(value: string);
    get confirmDeleteTitle(): string;
    set confirmDeleteTitle(value: string);
    get deleteRow(): string;
    set deleteRow(value: string);
    get editRow(): string;
    set editRow(value: string);
    get saveAllChanges(): string;
    set saveAllChanges(value: string);
    get saveRowChanges(): string;
    set saveRowChanges(value: string);
    get undeleteRow(): string;
    set undeleteRow(value: string);
    get validationCancelChanges(): string;
    set validationCancelChanges(value: string);
    get exportAll(): string;
    set exportAll(value: string);
    get exportSelectedRows(): string;
    set exportSelectedRows(value: string);
    get exportTo(): string;
    set exportTo(value: string);
    get clearFilter(): string;
    set clearFilter(value: string);
    get createFilter(): string;
    set createFilter(value: string);
    get filterEnabledHint(): string;
    set filterEnabledHint(value: string);
    get groupByThisColumn(): string;
    set groupByThisColumn(value: string);
    get groupContinuedMessage(): string;
    set groupContinuedMessage(value: string);
    get groupContinuesMessage(): string;
    set groupContinuesMessage(value: string);
    get ungroup(): string;
    set ungroup(value: string);
    get ungroupAll(): string;
    set ungroupAll(value: string);
    get cancel(): string;
    set cancel(value: string);
    get emptyValue(): string;
    set emptyValue(value: string);
    get ok(): string;
    set ok(value: string);
    get avg(): string;
    set avg(value: string);
    get avgOtherColumn(): string;
    set avgOtherColumn(value: string);
    get count(): string;
    set count(value: string);
    get max(): string;
    set max(value: string);
    get maxOtherColumn(): string;
    set maxOtherColumn(value: string);
    get min(): string;
    set min(value: string);
    get minOtherColumn(): string;
    set minOtherColumn(value: string);
    get sum(): string;
    set sum(value: string);
    get sumOtherColumn(): string;
    set sumOtherColumn(value: string);
    get allFields(): string;
    set allFields(value: string);
    get columnFields(): string;
    set columnFields(value: string);
    get dataFields(): string;
    set dataFields(value: string);
    get filterFields(): string;
    set filterFields(value: string);
    get rowFields(): string;
    set rowFields(value: string);
    get columnFieldArea(): string;
    set columnFieldArea(value: string);
    get dataFieldArea(): string;
    set dataFieldArea(value: string);
    get filterFieldArea(): string;
    set filterFieldArea(value: string);
    get rowFieldArea(): string;
    set rowFieldArea(value: string);
    get collapseAll(): string;
    set collapseAll(value: string);
    get dataNotAvailable(): string;
    set dataNotAvailable(value: string);
    get expandAll(): string;
    set expandAll(value: string);
    get exportToExcel(): string;
    set exportToExcel(value: string);
    get grandTotal(): string;
    set grandTotal(value: string);
    get noData(): string;
    set noData(value: string);
    get removeAllSorting(): string;
    set removeAllSorting(value: string);
    get showFieldChooser(): string;
    set showFieldChooser(value: string);
    get sortColumnBySummary(): string;
    set sortColumnBySummary(value: string);
    get sortRowBySummary(): string;
    set sortRowBySummary(value: string);
    get total(): string;
    set total(value: string);
    get addRowToNode(): string;
    set addRowToNode(value: string);
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoFilterPanelTexts, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoFilterPanelTexts, "ng-component", never, {}, {}, never, never, true, never>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoTextsComponent extends DxoFilterPanelTexts implements OnDestroy, OnInit {
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTextsComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoTextsComponent, "dxo-texts", never, { "fix": { "alias": "fix"; "required": false; }; "leftPosition": { "alias": "leftPosition"; "required": false; }; "rightPosition": { "alias": "rightPosition"; "required": false; }; "stickyPosition": { "alias": "stickyPosition"; "required": false; }; "unfix": { "alias": "unfix"; "required": false; }; "addRow": { "alias": "addRow"; "required": false; }; "cancelAllChanges": { "alias": "cancelAllChanges"; "required": false; }; "cancelRowChanges": { "alias": "cancelRowChanges"; "required": false; }; "confirmDeleteMessage": { "alias": "confirmDeleteMessage"; "required": false; }; "confirmDeleteTitle": { "alias": "confirmDeleteTitle"; "required": false; }; "deleteRow": { "alias": "deleteRow"; "required": false; }; "editRow": { "alias": "editRow"; "required": false; }; "saveAllChanges": { "alias": "saveAllChanges"; "required": false; }; "saveRowChanges": { "alias": "saveRowChanges"; "required": false; }; "undeleteRow": { "alias": "undeleteRow"; "required": false; }; "validationCancelChanges": { "alias": "validationCancelChanges"; "required": false; }; "exportAll": { "alias": "exportAll"; "required": false; }; "exportSelectedRows": { "alias": "exportSelectedRows"; "required": false; }; "exportTo": { "alias": "exportTo"; "required": false; }; "clearFilter": { "alias": "clearFilter"; "required": false; }; "createFilter": { "alias": "createFilter"; "required": false; }; "filterEnabledHint": { "alias": "filterEnabledHint"; "required": false; }; "groupByThisColumn": { "alias": "groupByThisColumn"; "required": false; }; "groupContinuedMessage": { "alias": "groupContinuedMessage"; "required": false; }; "groupContinuesMessage": { "alias": "groupContinuesMessage"; "required": false; }; "ungroup": { "alias": "ungroup"; "required": false; }; "ungroupAll": { "alias": "ungroupAll"; "required": false; }; "cancel": { "alias": "cancel"; "required": false; }; "emptyValue": { "alias": "emptyValue"; "required": false; }; "ok": { "alias": "ok"; "required": false; }; "avg": { "alias": "avg"; "required": false; }; "avgOtherColumn": { "alias": "avgOtherColumn"; "required": false; }; "count": { "alias": "count"; "required": false; }; "max": { "alias": "max"; "required": false; }; "maxOtherColumn": { "alias": "maxOtherColumn"; "required": false; }; "min": { "alias": "min"; "required": false; }; "minOtherColumn": { "alias": "minOtherColumn"; "required": false; }; "sum": { "alias": "sum"; "required": false; }; "sumOtherColumn": { "alias": "sumOtherColumn"; "required": false; }; "allFields": { "alias": "allFields"; "required": false; }; "columnFields": { "alias": "columnFields"; "required": false; }; "dataFields": { "alias": "dataFields"; "required": false; }; "filterFields": { "alias": "filterFields"; "required": false; }; "rowFields": { "alias": "rowFields"; "required": false; }; "columnFieldArea": { "alias": "columnFieldArea"; "required": false; }; "dataFieldArea": { "alias": "dataFieldArea"; "required": false; }; "filterFieldArea": { "alias": "filterFieldArea"; "required": false; }; "rowFieldArea": { "alias": "rowFieldArea"; "required": false; }; "collapseAll": { "alias": "collapseAll"; "required": false; }; "dataNotAvailable": { "alias": "dataNotAvailable"; "required": false; }; "expandAll": { "alias": "expandAll"; "required": false; }; "exportToExcel": { "alias": "exportToExcel"; "required": false; }; "grandTotal": { "alias": "grandTotal"; "required": false; }; "noData": { "alias": "noData"; "required": false; }; "removeAllSorting": { "alias": "removeAllSorting"; "required": false; }; "showFieldChooser": { "alias": "showFieldChooser"; "required": false; }; "sortColumnBySummary": { "alias": "sortColumnBySummary"; "required": false; }; "sortRowBySummary": { "alias": "sortRowBySummary"; "required": false; }; "total": { "alias": "total"; "required": false; }; "addRowToNode": { "alias": "addRowToNode"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoTextsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTextsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoTextsModule, never, [typeof DxoTextsComponent], [typeof DxoTextsComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoTextsModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoTickIntervalComponent extends NestedOption implements OnDestroy, OnInit {
    get days(): number;
    set days(value: number);
    get hours(): number;
    set hours(value: number);
    get milliseconds(): number;
    set milliseconds(value: number);
    get minutes(): number;
    set minutes(value: number);
    get months(): number;
    set months(value: number);
    get quarters(): number;
    set quarters(value: number);
    get seconds(): number;
    set seconds(value: number);
    get weeks(): number;
    set weeks(value: number);
    get years(): number;
    set years(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTickIntervalComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoTickIntervalComponent, "dxo-tick-interval", never, { "days": { "alias": "days"; "required": false; }; "hours": { "alias": "hours"; "required": false; }; "milliseconds": { "alias": "milliseconds"; "required": false; }; "minutes": { "alias": "minutes"; "required": false; }; "months": { "alias": "months"; "required": false; }; "quarters": { "alias": "quarters"; "required": false; }; "seconds": { "alias": "seconds"; "required": false; }; "weeks": { "alias": "weeks"; "required": false; }; "years": { "alias": "years"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoTickIntervalModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTickIntervalModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoTickIntervalModule, never, [typeof DxoTickIntervalComponent], [typeof DxoTickIntervalComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoTickIntervalModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoTickComponent extends NestedOption implements OnDestroy, OnInit {
    get color(): string;
    set color(value: string);
    get length(): number;
    set length(value: number);
    get opacity(): number | undefined;
    set opacity(value: number | undefined);
    get shift(): number;
    set shift(value: number);
    get visible(): boolean;
    set visible(value: boolean);
    get width(): number;
    set width(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTickComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoTickComponent, "dxo-tick", never, { "color": { "alias": "color"; "required": false; }; "length": { "alias": "length"; "required": false; }; "opacity": { "alias": "opacity"; "required": false; }; "shift": { "alias": "shift"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoTickModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTickModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoTickModule, never, [typeof DxoTickComponent], [typeof DxoTickComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoTickModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoTileComponent extends NestedOption implements OnDestroy, OnInit {
    get border(): {
        color?: string | undefined;
        width?: number | undefined;
    };
    set border(value: {
        color?: string | undefined;
        width?: number | undefined;
    });
    get color(): string;
    set color(value: string);
    get hoverStyle(): {
        border?: {
            color?: string | undefined;
            width?: number | undefined;
        };
        color?: string | undefined;
    };
    set hoverStyle(value: {
        border?: {
            color?: string | undefined;
            width?: number | undefined;
        };
        color?: string | undefined;
    });
    get label(): {
        font?: Font;
        textOverflow?: TextOverflow;
        visible?: boolean;
        wordWrap?: WordWrap;
    };
    set label(value: {
        font?: Font;
        textOverflow?: TextOverflow;
        visible?: boolean;
        wordWrap?: WordWrap;
    });
    get selectionStyle(): {
        border?: {
            color?: string | undefined;
            width?: number | undefined;
        };
        color?: string | undefined;
    };
    set selectionStyle(value: {
        border?: {
            color?: string | undefined;
            width?: number | undefined;
        };
        color?: string | undefined;
    });
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTileComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoTileComponent, "dxo-tile", never, { "border": { "alias": "border"; "required": false; }; "color": { "alias": "color"; "required": false; }; "hoverStyle": { "alias": "hoverStyle"; "required": false; }; "label": { "alias": "label"; "required": false; }; "selectionStyle": { "alias": "selectionStyle"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoTileModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTileModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoTileModule, never, [typeof DxoTileComponent], [typeof DxoTileComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoTileModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoTitleComponent extends NestedOption implements OnDestroy, OnInit {
    get font(): Font;
    set font(value: Font);
    get horizontalAlignment(): HorizontalAlignment | undefined;
    set horizontalAlignment(value: HorizontalAlignment | undefined);
    get margin(): {
        bottom?: number;
        left?: number;
        right?: number;
        top?: number;
    } | number;
    set margin(value: {
        bottom?: number;
        left?: number;
        right?: number;
        top?: number;
    } | number);
    get placeholderSize(): number | undefined;
    set placeholderSize(value: number | undefined);
    get subtitle(): string | {
        font?: Font;
        offset?: number;
        text?: string | undefined;
    } | {
        font?: Font;
        offset?: number;
        text?: string | undefined;
        textOverflow?: TextOverflow;
        wordWrap?: WordWrap;
    };
    set subtitle(value: string | {
        font?: Font;
        offset?: number;
        text?: string | undefined;
    } | {
        font?: Font;
        offset?: number;
        text?: string | undefined;
        textOverflow?: TextOverflow;
        wordWrap?: WordWrap;
    });
    get text(): string | undefined;
    set text(value: string | undefined);
    get verticalAlignment(): VerticalEdge;
    set verticalAlignment(value: VerticalEdge);
    get textOverflow(): TextOverflow;
    set textOverflow(value: TextOverflow);
    get wordWrap(): WordWrap;
    set wordWrap(value: WordWrap);
    get alignment(): HorizontalAlignment;
    set alignment(value: HorizontalAlignment);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTitleComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoTitleComponent, "dxo-title", never, { "font": { "alias": "font"; "required": false; }; "horizontalAlignment": { "alias": "horizontalAlignment"; "required": false; }; "margin": { "alias": "margin"; "required": false; }; "placeholderSize": { "alias": "placeholderSize"; "required": false; }; "subtitle": { "alias": "subtitle"; "required": false; }; "text": { "alias": "text"; "required": false; }; "verticalAlignment": { "alias": "verticalAlignment"; "required": false; }; "textOverflow": { "alias": "textOverflow"; "required": false; }; "wordWrap": { "alias": "wordWrap"; "required": false; }; "alignment": { "alias": "alignment"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoTitleModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTitleModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoTitleModule, never, [typeof DxoTitleComponent], [typeof DxoTitleComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoTitleModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoToComponent extends DxoAnimationState implements OnDestroy, OnInit {
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoToComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoToComponent, "dxo-to", never, { "left": { "alias": "left"; "required": false; }; "opacity": { "alias": "opacity"; "required": false; }; "position": { "alias": "position"; "required": false; }; "scale": { "alias": "scale"; "required": false; }; "top": { "alias": "top"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoToModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoToModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoToModule, never, [typeof DxoToComponent], [typeof DxoToComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoToModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare abstract class DxiPopupToolbarItem extends CollectionNestedOption {
    get cssClass(): string | undefined;
    set cssClass(value: string | undefined);
    get disabled(): boolean;
    set disabled(value: boolean);
    get html(): string;
    set html(value: string);
    get locateInMenu(): LocateInMenuMode;
    set locateInMenu(value: LocateInMenuMode);
    get location(): ToolbarItemLocation;
    set location(value: ToolbarItemLocation);
    get menuItemTemplate(): any;
    set menuItemTemplate(value: any);
    get options(): any;
    set options(value: any);
    get showText(): ShowTextMode;
    set showText(value: ShowTextMode);
    get template(): any;
    set template(value: any);
    get text(): string;
    set text(value: string);
    get toolbar(): ToolbarLocation;
    set toolbar(value: ToolbarLocation);
    get visible(): boolean;
    set visible(value: boolean);
    get widget(): ToolbarItemComponent;
    set widget(value: ToolbarItemComponent);
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiPopupToolbarItem, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiPopupToolbarItem, "ng-component", never, {}, {}, never, never, true, never>;
}

declare class DxiToolbarItemComponent extends DxiPopupToolbarItem {
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiToolbarItemComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiToolbarItemComponent, "dxi-toolbar-item", never, { "cssClass": { "alias": "cssClass"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "html": { "alias": "html"; "required": false; }; "locateInMenu": { "alias": "locateInMenu"; "required": false; }; "location": { "alias": "location"; "required": false; }; "menuItemTemplate": { "alias": "menuItemTemplate"; "required": false; }; "options": { "alias": "options"; "required": false; }; "showText": { "alias": "showText"; "required": false; }; "template": { "alias": "template"; "required": false; }; "text": { "alias": "text"; "required": false; }; "toolbar": { "alias": "toolbar"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "widget": { "alias": "widget"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxiToolbarItemModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiToolbarItemModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiToolbarItemModule, never, [typeof DxiToolbarItemComponent], [typeof DxiToolbarItemComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiToolbarItemModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare abstract class DxoDataGridToolbar extends NestedOption {
    get disabled(): boolean;
    set disabled(value: boolean);
    get items(): Array<dxDataGridToolbarItem | DataGridPredefinedToolbarItem | dxFileManagerToolbarItem | FileManagerPredefinedToolbarItem | dxGanttToolbarItem | GanttPredefinedToolbarItem | dxHtmlEditorToolbarItem | AIToolbarItem | HtmlEditorPredefinedToolbarItem | dxTreeListToolbarItem | TreeListPredefinedToolbarItem>;
    set items(value: Array<dxDataGridToolbarItem | DataGridPredefinedToolbarItem | dxFileManagerToolbarItem | FileManagerPredefinedToolbarItem | dxGanttToolbarItem | GanttPredefinedToolbarItem | dxHtmlEditorToolbarItem | AIToolbarItem | HtmlEditorPredefinedToolbarItem | dxTreeListToolbarItem | TreeListPredefinedToolbarItem>);
    get visible(): boolean | undefined;
    set visible(value: boolean | undefined);
    get fileSelectionItems(): Array<dxFileManagerToolbarItem | FileManagerPredefinedToolbarItem>;
    set fileSelectionItems(value: Array<dxFileManagerToolbarItem | FileManagerPredefinedToolbarItem>);
    get container(): UserDefinedElement | string;
    set container(value: UserDefinedElement | string);
    get multiline(): boolean;
    set multiline(value: boolean);
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDataGridToolbar, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoDataGridToolbar, "ng-component", never, {}, {}, never, never, true, never>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoToolbarComponent extends DxoDataGridToolbar implements OnDestroy, OnInit {
    set _itemsContentChildren(value: QueryList<CollectionNestedOption>);
    set _fileSelectionItemsContentChildren(value: QueryList<CollectionNestedOption>);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoToolbarComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoToolbarComponent, "dxo-toolbar", never, { "disabled": { "alias": "disabled"; "required": false; }; "items": { "alias": "items"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "fileSelectionItems": { "alias": "fileSelectionItems"; "required": false; }; "container": { "alias": "container"; "required": false; }; "multiline": { "alias": "multiline"; "required": false; }; }, {}, ["_itemsContentChildren", "_fileSelectionItemsContentChildren"], never, true, never>;
}
declare class DxoToolbarModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoToolbarModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoToolbarModule, never, [typeof DxoToolbarComponent], [typeof DxoToolbarComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoToolbarModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoToolboxComponent extends NestedOption implements OnDestroy, OnInit {
    set _groupsContentChildren(value: QueryList<CollectionNestedOption>);
    get groups(): Array<ShapeCategory | any | {
        category?: ShapeCategory | string;
        displayMode?: ToolboxDisplayMode;
        expanded?: boolean;
        shapes?: Array<ShapeType | string>;
        title?: string;
    }>;
    set groups(value: Array<ShapeCategory | any | {
        category?: ShapeCategory | string;
        displayMode?: ToolboxDisplayMode;
        expanded?: boolean;
        shapes?: Array<ShapeType | string>;
        title?: string;
    }>);
    get shapeIconsPerRow(): number;
    set shapeIconsPerRow(value: number);
    get showSearch(): boolean;
    set showSearch(value: boolean);
    get visibility(): PanelVisibility;
    set visibility(value: PanelVisibility);
    get width(): number | undefined;
    set width(value: number | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoToolboxComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoToolboxComponent, "dxo-toolbox", never, { "groups": { "alias": "groups"; "required": false; }; "shapeIconsPerRow": { "alias": "shapeIconsPerRow"; "required": false; }; "showSearch": { "alias": "showSearch"; "required": false; }; "visibility": { "alias": "visibility"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, ["_groupsContentChildren"], never, true, never>;
}
declare class DxoToolboxModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoToolboxModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoToolboxModule, never, [typeof DxoToolboxComponent], [typeof DxoToolboxComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoToolboxModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoTooltipComponent extends NestedOption implements OnDestroy, OnInit {
    get arrowLength(): number;
    set arrowLength(value: number);
    get border(): {
        color?: string;
        dashStyle?: DashStyle;
        opacity?: number | undefined;
        visible?: boolean;
        width?: number;
    };
    set border(value: {
        color?: string;
        dashStyle?: DashStyle;
        opacity?: number | undefined;
        visible?: boolean;
        width?: number;
    });
    get color(): string;
    set color(value: string);
    get container(): UserDefinedElement | string | undefined;
    set container(value: UserDefinedElement | string | undefined);
    get contentTemplate(): any | undefined;
    set contentTemplate(value: any | undefined);
    get cornerRadius(): number;
    set cornerRadius(value: number);
    get customizeTooltip(): Function | undefined;
    set customizeTooltip(value: Function | undefined);
    get enabled(): boolean;
    set enabled(value: boolean);
    get font(): Font;
    set font(value: Font);
    get format(): Format | string | undefined;
    set format(value: Format | string | undefined);
    get interactive(): boolean;
    set interactive(value: boolean);
    get opacity(): number | undefined;
    set opacity(value: number | undefined);
    get paddingLeftRight(): number;
    set paddingLeftRight(value: number);
    get paddingTopBottom(): number;
    set paddingTopBottom(value: number);
    get shadow(): {
        blur?: number;
        color?: string;
        offsetX?: number;
        offsetY?: number;
        opacity?: number;
    };
    set shadow(value: {
        blur?: number;
        color?: string;
        offsetX?: number;
        offsetY?: number;
        opacity?: number;
    });
    get zIndex(): number | undefined;
    set zIndex(value: number | undefined);
    get argumentFormat(): Format | string | undefined;
    set argumentFormat(value: Format | string | undefined);
    get location(): ChartTooltipLocation;
    set location(value: ChartTooltipLocation);
    get shared(): boolean;
    set shared(value: boolean);
    get isShown(): boolean;
    set isShown(value: boolean);
    get text(): string;
    set text(value: string);
    get position(): VerticalEdge;
    set position(value: VerticalEdge);
    get showMode(): TooltipShowMode;
    set showMode(value: TooltipShowMode);
    get customizeLinkTooltip(): Function | undefined;
    set customizeLinkTooltip(value: Function | undefined);
    get customizeNodeTooltip(): Function | undefined;
    set customizeNodeTooltip(value: Function | undefined);
    get linkTooltipTemplate(): any | undefined;
    set linkTooltipTemplate(value: any | undefined);
    get nodeTooltipTemplate(): any | undefined;
    set nodeTooltipTemplate(value: any | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTooltipComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoTooltipComponent, "dxo-tooltip", never, { "arrowLength": { "alias": "arrowLength"; "required": false; }; "border": { "alias": "border"; "required": false; }; "color": { "alias": "color"; "required": false; }; "container": { "alias": "container"; "required": false; }; "contentTemplate": { "alias": "contentTemplate"; "required": false; }; "cornerRadius": { "alias": "cornerRadius"; "required": false; }; "customizeTooltip": { "alias": "customizeTooltip"; "required": false; }; "enabled": { "alias": "enabled"; "required": false; }; "font": { "alias": "font"; "required": false; }; "format": { "alias": "format"; "required": false; }; "interactive": { "alias": "interactive"; "required": false; }; "opacity": { "alias": "opacity"; "required": false; }; "paddingLeftRight": { "alias": "paddingLeftRight"; "required": false; }; "paddingTopBottom": { "alias": "paddingTopBottom"; "required": false; }; "shadow": { "alias": "shadow"; "required": false; }; "zIndex": { "alias": "zIndex"; "required": false; }; "argumentFormat": { "alias": "argumentFormat"; "required": false; }; "location": { "alias": "location"; "required": false; }; "shared": { "alias": "shared"; "required": false; }; "isShown": { "alias": "isShown"; "required": false; }; "text": { "alias": "text"; "required": false; }; "position": { "alias": "position"; "required": false; }; "showMode": { "alias": "showMode"; "required": false; }; "customizeLinkTooltip": { "alias": "customizeLinkTooltip"; "required": false; }; "customizeNodeTooltip": { "alias": "customizeNodeTooltip"; "required": false; }; "linkTooltipTemplate": { "alias": "linkTooltipTemplate"; "required": false; }; "nodeTooltipTemplate": { "alias": "nodeTooltipTemplate"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoTooltipModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTooltipModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoTooltipModule, never, [typeof DxoTooltipComponent], [typeof DxoTooltipComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoTooltipModule>;
}

declare class DxiTotalItemComponent extends CollectionNestedOption {
    get alignment(): HorizontalAlignment | undefined;
    set alignment(value: HorizontalAlignment | undefined);
    get column(): string | undefined;
    set column(value: string | undefined);
    get cssClass(): string | undefined;
    set cssClass(value: string | undefined);
    get customizeText(): Function;
    set customizeText(value: Function);
    get displayFormat(): string | undefined;
    set displayFormat(value: string | undefined);
    get name(): string | undefined;
    set name(value: string | undefined);
    get showInColumn(): string | undefined;
    set showInColumn(value: string | undefined);
    get skipEmptyValues(): boolean;
    set skipEmptyValues(value: boolean);
    get summaryType(): SummaryType | string | undefined;
    set summaryType(value: SummaryType | string | undefined);
    get valueFormat(): Format | string | undefined;
    set valueFormat(value: Format | string | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiTotalItemComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiTotalItemComponent, "dxi-total-item", never, { "alignment": { "alias": "alignment"; "required": false; }; "column": { "alias": "column"; "required": false; }; "cssClass": { "alias": "cssClass"; "required": false; }; "customizeText": { "alias": "customizeText"; "required": false; }; "displayFormat": { "alias": "displayFormat"; "required": false; }; "name": { "alias": "name"; "required": false; }; "showInColumn": { "alias": "showInColumn"; "required": false; }; "skipEmptyValues": { "alias": "skipEmptyValues"; "required": false; }; "summaryType": { "alias": "summaryType"; "required": false; }; "valueFormat": { "alias": "valueFormat"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxiTotalItemModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiTotalItemModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiTotalItemModule, never, [typeof DxiTotalItemComponent], [typeof DxiTotalItemComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiTotalItemModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare abstract class DxiUser extends CollectionNestedOption {
    get avatarAlt(): string;
    set avatarAlt(value: string);
    get avatarUrl(): string;
    set avatarUrl(value: string);
    get id(): number | string;
    set id(value: number | string);
    get name(): string;
    set name(value: string);
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiUser, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiUser, "base-dxi-user", never, {}, {}, never, never, true, never>;
}

declare class DxiTypingUserComponent extends DxiUser {
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiTypingUserComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiTypingUserComponent, "dxi-typing-user", never, { "avatarAlt": { "alias": "avatarAlt"; "required": false; }; "avatarUrl": { "alias": "avatarUrl"; "required": false; }; "id": { "alias": "id"; "required": false; }; "name": { "alias": "name"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxiTypingUserModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiTypingUserModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiTypingUserModule, never, [typeof DxiTypingUserComponent], [typeof DxiTypingUserComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiTypingUserModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoUploadComponent extends NestedOption implements OnDestroy, OnInit {
    get chunkSize(): number;
    set chunkSize(value: number);
    get maxFileSize(): number;
    set maxFileSize(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoUploadComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoUploadComponent, "dxo-upload", never, { "chunkSize": { "alias": "chunkSize"; "required": false; }; "maxFileSize": { "alias": "maxFileSize"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoUploadModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoUploadModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoUploadModule, never, [typeof DxoUploadComponent], [typeof DxoUploadComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoUploadModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoUrlComponent extends NestedOption implements OnDestroy, OnInit {
    get rangeMaxPoint(): string | undefined;
    set rangeMaxPoint(value: string | undefined);
    get rangeMinPoint(): string | undefined;
    set rangeMinPoint(value: string | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoUrlComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoUrlComponent, "dxo-url", never, { "rangeMaxPoint": { "alias": "rangeMaxPoint"; "required": false; }; "rangeMinPoint": { "alias": "rangeMinPoint"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoUrlModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoUrlModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoUrlModule, never, [typeof DxoUrlComponent], [typeof DxoUrlComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoUrlModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoUserComponent extends DxoUser implements OnDestroy, OnInit {
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoUserComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoUserComponent, "dxo-user", never, { "avatarAlt": { "alias": "avatarAlt"; "required": false; }; "avatarUrl": { "alias": "avatarUrl"; "required": false; }; "id": { "alias": "id"; "required": false; }; "name": { "alias": "name"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoUserModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoUserModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoUserModule, never, [typeof DxoUserComponent], [typeof DxoUserComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoUserModule>;
}

declare class DxiValidationRuleComponent extends CollectionNestedOption {
    get message(): string;
    set message(value: string);
    get trim(): boolean;
    set trim(value: boolean);
    get type(): ValidationRuleType;
    set type(value: ValidationRuleType);
    get ignoreEmptyValue(): boolean;
    set ignoreEmptyValue(value: boolean);
    get max(): Date | number | string;
    set max(value: Date | number | string);
    get min(): Date | number | string;
    set min(value: Date | number | string);
    get reevaluate(): boolean;
    set reevaluate(value: boolean);
    get validationCallback(): Function;
    set validationCallback(value: Function);
    get comparisonTarget(): Function;
    set comparisonTarget(value: Function);
    get comparisonType(): ComparisonOperator;
    set comparisonType(value: ComparisonOperator);
    get pattern(): RegExp | string;
    set pattern(value: RegExp | string);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiValidationRuleComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiValidationRuleComponent, "dxi-validation-rule", never, { "message": { "alias": "message"; "required": false; }; "trim": { "alias": "trim"; "required": false; }; "type": { "alias": "type"; "required": false; }; "ignoreEmptyValue": { "alias": "ignoreEmptyValue"; "required": false; }; "max": { "alias": "max"; "required": false; }; "min": { "alias": "min"; "required": false; }; "reevaluate": { "alias": "reevaluate"; "required": false; }; "validationCallback": { "alias": "validationCallback"; "required": false; }; "comparisonTarget": { "alias": "comparisonTarget"; "required": false; }; "comparisonType": { "alias": "comparisonType"; "required": false; }; "pattern": { "alias": "pattern"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxiValidationRuleModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiValidationRuleModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiValidationRuleModule, never, [typeof DxiValidationRuleComponent], [typeof DxiValidationRuleComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiValidationRuleModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoValidationComponent extends NestedOption implements OnDestroy, OnInit {
    get autoUpdateParentTasks(): boolean;
    set autoUpdateParentTasks(value: boolean);
    get enablePredecessorGap(): boolean;
    set enablePredecessorGap(value: boolean);
    get validateDependencies(): boolean;
    set validateDependencies(value: boolean);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoValidationComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoValidationComponent, "dxo-validation", never, { "autoUpdateParentTasks": { "alias": "autoUpdateParentTasks"; "required": false; }; "enablePredecessorGap": { "alias": "enablePredecessorGap"; "required": false; }; "validateDependencies": { "alias": "validateDependencies"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoValidationModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoValidationModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoValidationModule, never, [typeof DxoValidationComponent], [typeof DxoValidationComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoValidationModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxiValueAxisComponent extends CollectionNestedOption {
    set _breaksContentChildren(value: QueryList<CollectionNestedOption>);
    set _constantLinesContentChildren(value: QueryList<CollectionNestedOption>);
    set _stripsContentChildren(value: QueryList<CollectionNestedOption>);
    get aggregatedPointsPosition(): AggregatedPointsPosition;
    set aggregatedPointsPosition(value: AggregatedPointsPosition);
    get allowDecimals(): boolean | undefined;
    set allowDecimals(value: boolean | undefined);
    get autoBreaksEnabled(): boolean;
    set autoBreaksEnabled(value: boolean);
    get axisDivisionFactor(): number;
    set axisDivisionFactor(value: number);
    get breaks(): undefined | Array<ScaleBreak>;
    set breaks(value: undefined | Array<ScaleBreak>);
    get breakStyle(): {
        color?: string;
        line?: ScaleBreakLineStyle;
        width?: number;
    };
    set breakStyle(value: {
        color?: string;
        line?: ScaleBreakLineStyle;
        width?: number;
    });
    get categories(): Array<number | string | Date>;
    set categories(value: Array<number | string | Date>);
    get color(): string;
    set color(value: string);
    get constantLines(): Array<any | {
        color?: string;
        dashStyle?: DashStyle;
        displayBehindSeries?: boolean;
        extendAxis?: boolean;
        label?: {
            font?: Font;
            horizontalAlignment?: HorizontalAlignment;
            position?: RelativePosition;
            text?: string | undefined;
            verticalAlignment?: VerticalAlignment;
            visible?: boolean;
        };
        paddingLeftRight?: number;
        paddingTopBottom?: number;
        value?: Date | number | string | undefined;
        width?: number;
    }>;
    set constantLines(value: Array<any | {
        color?: string;
        dashStyle?: DashStyle;
        displayBehindSeries?: boolean;
        extendAxis?: boolean;
        label?: {
            font?: Font;
            horizontalAlignment?: HorizontalAlignment;
            position?: RelativePosition;
            text?: string | undefined;
            verticalAlignment?: VerticalAlignment;
            visible?: boolean;
        };
        paddingLeftRight?: number;
        paddingTopBottom?: number;
        value?: Date | number | string | undefined;
        width?: number;
    }>);
    get constantLineStyle(): {
        color?: string;
        dashStyle?: DashStyle;
        label?: {
            font?: Font;
            horizontalAlignment?: HorizontalAlignment;
            position?: RelativePosition;
            verticalAlignment?: VerticalAlignment;
            visible?: boolean;
        };
        paddingLeftRight?: number;
        paddingTopBottom?: number;
        width?: number;
    };
    set constantLineStyle(value: {
        color?: string;
        dashStyle?: DashStyle;
        label?: {
            font?: Font;
            horizontalAlignment?: HorizontalAlignment;
            position?: RelativePosition;
            verticalAlignment?: VerticalAlignment;
            visible?: boolean;
        };
        paddingLeftRight?: number;
        paddingTopBottom?: number;
        width?: number;
    });
    get customPosition(): Date | number | string | undefined;
    set customPosition(value: Date | number | string | undefined);
    get discreteAxisDivisionMode(): DiscreteAxisDivisionMode;
    set discreteAxisDivisionMode(value: DiscreteAxisDivisionMode);
    get endOnTick(): boolean | undefined;
    set endOnTick(value: boolean | undefined);
    get grid(): {
        color?: string;
        opacity?: number | undefined;
        visible?: boolean;
        width?: number;
    };
    set grid(value: {
        color?: string;
        opacity?: number | undefined;
        visible?: boolean;
        width?: number;
    });
    get inverted(): boolean;
    set inverted(value: boolean);
    get label(): {
        alignment?: HorizontalAlignment | undefined;
        customizeHint?: Function;
        customizeText?: Function;
        displayMode?: ChartLabelDisplayMode;
        font?: Font;
        format?: Format | string | undefined;
        indentFromAxis?: number;
        overlappingBehavior?: ChartsAxisLabelOverlap;
        position?: RelativePosition | Position;
        rotationAngle?: number;
        staggeringSpacing?: number;
        template?: any | undefined;
        textOverflow?: TextOverflow;
        visible?: boolean;
        wordWrap?: WordWrap;
    };
    set label(value: {
        alignment?: HorizontalAlignment | undefined;
        customizeHint?: Function;
        customizeText?: Function;
        displayMode?: ChartLabelDisplayMode;
        font?: Font;
        format?: Format | string | undefined;
        indentFromAxis?: number;
        overlappingBehavior?: ChartsAxisLabelOverlap;
        position?: RelativePosition | Position;
        rotationAngle?: number;
        staggeringSpacing?: number;
        template?: any | undefined;
        textOverflow?: TextOverflow;
        visible?: boolean;
        wordWrap?: WordWrap;
    });
    get linearThreshold(): number | undefined;
    set linearThreshold(value: number | undefined);
    get logarithmBase(): number;
    set logarithmBase(value: number);
    get maxAutoBreakCount(): number;
    set maxAutoBreakCount(value: number);
    get maxValueMargin(): number | undefined;
    set maxValueMargin(value: number | undefined);
    get minorGrid(): {
        color?: string;
        opacity?: number | undefined;
        visible?: boolean;
        width?: number;
    };
    set minorGrid(value: {
        color?: string;
        opacity?: number | undefined;
        visible?: boolean;
        width?: number;
    });
    get minorTick(): {
        color?: string;
        length?: number;
        opacity?: number;
        shift?: number;
        visible?: boolean;
        width?: number;
    };
    set minorTick(value: {
        color?: string;
        length?: number;
        opacity?: number;
        shift?: number;
        visible?: boolean;
        width?: number;
    });
    get minorTickCount(): number | undefined;
    set minorTickCount(value: number | undefined);
    get minorTickInterval(): TimeInterval | number | {
        days?: number;
        hours?: number;
        milliseconds?: number;
        minutes?: number;
        months?: number;
        quarters?: number;
        seconds?: number;
        weeks?: number;
        years?: number;
    };
    set minorTickInterval(value: TimeInterval | number | {
        days?: number;
        hours?: number;
        milliseconds?: number;
        minutes?: number;
        months?: number;
        quarters?: number;
        seconds?: number;
        weeks?: number;
        years?: number;
    });
    get minValueMargin(): number | undefined;
    set minValueMargin(value: number | undefined);
    get minVisualRangeLength(): TimeInterval | number | undefined | {
        days?: number;
        hours?: number;
        milliseconds?: number;
        minutes?: number;
        months?: number;
        quarters?: number;
        seconds?: number;
        weeks?: number;
        years?: number;
    };
    set minVisualRangeLength(value: TimeInterval | number | undefined | {
        days?: number;
        hours?: number;
        milliseconds?: number;
        minutes?: number;
        months?: number;
        quarters?: number;
        seconds?: number;
        weeks?: number;
        years?: number;
    });
    get multipleAxesSpacing(): number;
    set multipleAxesSpacing(value: number);
    get name(): string | undefined;
    set name(value: string | undefined);
    get offset(): number | undefined;
    set offset(value: number | undefined);
    get opacity(): number | undefined;
    set opacity(value: number | undefined);
    get pane(): string | undefined;
    set pane(value: string | undefined);
    get placeholderSize(): number | null;
    set placeholderSize(value: number | null);
    get position(): Position;
    set position(value: Position);
    get showZero(): boolean | undefined;
    set showZero(value: boolean | undefined);
    get strips(): Array<any | {
        color?: string | undefined;
        endValue?: Date | number | string | undefined;
        label?: {
            font?: Font;
            horizontalAlignment?: HorizontalAlignment;
            text?: string | undefined;
            verticalAlignment?: VerticalAlignment;
        };
        paddingLeftRight?: number;
        paddingTopBottom?: number;
        startValue?: Date | number | string | undefined;
    }>;
    set strips(value: Array<any | {
        color?: string | undefined;
        endValue?: Date | number | string | undefined;
        label?: {
            font?: Font;
            horizontalAlignment?: HorizontalAlignment;
            text?: string | undefined;
            verticalAlignment?: VerticalAlignment;
        };
        paddingLeftRight?: number;
        paddingTopBottom?: number;
        startValue?: Date | number | string | undefined;
    }>);
    get stripStyle(): {
        label?: {
            font?: Font;
            horizontalAlignment?: HorizontalAlignment;
            verticalAlignment?: VerticalAlignment;
        };
        paddingLeftRight?: number;
        paddingTopBottom?: number;
    };
    set stripStyle(value: {
        label?: {
            font?: Font;
            horizontalAlignment?: HorizontalAlignment;
            verticalAlignment?: VerticalAlignment;
        };
        paddingLeftRight?: number;
        paddingTopBottom?: number;
    });
    get synchronizedValue(): number | undefined;
    set synchronizedValue(value: number | undefined);
    get tick(): {
        color?: string;
        length?: number;
        opacity?: number | undefined;
        shift?: number;
        visible?: boolean;
        width?: number;
    };
    set tick(value: {
        color?: string;
        length?: number;
        opacity?: number | undefined;
        shift?: number;
        visible?: boolean;
        width?: number;
    });
    get tickInterval(): TimeInterval | number | {
        days?: number;
        hours?: number;
        milliseconds?: number;
        minutes?: number;
        months?: number;
        quarters?: number;
        seconds?: number;
        weeks?: number;
        years?: number;
    };
    set tickInterval(value: TimeInterval | number | {
        days?: number;
        hours?: number;
        milliseconds?: number;
        minutes?: number;
        months?: number;
        quarters?: number;
        seconds?: number;
        weeks?: number;
        years?: number;
    });
    get title(): string | {
        alignment?: HorizontalAlignment;
        font?: Font;
        margin?: number;
        text?: string | undefined;
        textOverflow?: TextOverflow;
        wordWrap?: WordWrap;
    };
    set title(value: string | {
        alignment?: HorizontalAlignment;
        font?: Font;
        margin?: number;
        text?: string | undefined;
        textOverflow?: TextOverflow;
        wordWrap?: WordWrap;
    });
    get type(): AxisScaleType | undefined;
    set type(value: AxisScaleType | undefined);
    get valueMarginsEnabled(): boolean;
    set valueMarginsEnabled(value: boolean);
    get valueType(): ChartsDataType | undefined;
    set valueType(value: ChartsDataType | undefined);
    get visible(): boolean;
    set visible(value: boolean);
    get visualRange(): VisualRange | Array<number | string | Date>;
    set visualRange(value: VisualRange | Array<number | string | Date>);
    get visualRangeUpdateMode(): ValueAxisVisualRangeUpdateMode;
    set visualRangeUpdateMode(value: ValueAxisVisualRangeUpdateMode);
    get wholeRange(): VisualRange | undefined | Array<number | string | Date>;
    set wholeRange(value: VisualRange | undefined | Array<number | string | Date>);
    get width(): number;
    set width(value: number);
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    categoriesChange: EventEmitter<Array<number | string | Date>>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    visualRangeChange: EventEmitter<VisualRange | Array<number | string | Date>>;
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiValueAxisComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiValueAxisComponent, "dxi-value-axis", never, { "aggregatedPointsPosition": { "alias": "aggregatedPointsPosition"; "required": false; }; "allowDecimals": { "alias": "allowDecimals"; "required": false; }; "autoBreaksEnabled": { "alias": "autoBreaksEnabled"; "required": false; }; "axisDivisionFactor": { "alias": "axisDivisionFactor"; "required": false; }; "breaks": { "alias": "breaks"; "required": false; }; "breakStyle": { "alias": "breakStyle"; "required": false; }; "categories": { "alias": "categories"; "required": false; }; "color": { "alias": "color"; "required": false; }; "constantLines": { "alias": "constantLines"; "required": false; }; "constantLineStyle": { "alias": "constantLineStyle"; "required": false; }; "customPosition": { "alias": "customPosition"; "required": false; }; "discreteAxisDivisionMode": { "alias": "discreteAxisDivisionMode"; "required": false; }; "endOnTick": { "alias": "endOnTick"; "required": false; }; "grid": { "alias": "grid"; "required": false; }; "inverted": { "alias": "inverted"; "required": false; }; "label": { "alias": "label"; "required": false; }; "linearThreshold": { "alias": "linearThreshold"; "required": false; }; "logarithmBase": { "alias": "logarithmBase"; "required": false; }; "maxAutoBreakCount": { "alias": "maxAutoBreakCount"; "required": false; }; "maxValueMargin": { "alias": "maxValueMargin"; "required": false; }; "minorGrid": { "alias": "minorGrid"; "required": false; }; "minorTick": { "alias": "minorTick"; "required": false; }; "minorTickCount": { "alias": "minorTickCount"; "required": false; }; "minorTickInterval": { "alias": "minorTickInterval"; "required": false; }; "minValueMargin": { "alias": "minValueMargin"; "required": false; }; "minVisualRangeLength": { "alias": "minVisualRangeLength"; "required": false; }; "multipleAxesSpacing": { "alias": "multipleAxesSpacing"; "required": false; }; "name": { "alias": "name"; "required": false; }; "offset": { "alias": "offset"; "required": false; }; "opacity": { "alias": "opacity"; "required": false; }; "pane": { "alias": "pane"; "required": false; }; "placeholderSize": { "alias": "placeholderSize"; "required": false; }; "position": { "alias": "position"; "required": false; }; "showZero": { "alias": "showZero"; "required": false; }; "strips": { "alias": "strips"; "required": false; }; "stripStyle": { "alias": "stripStyle"; "required": false; }; "synchronizedValue": { "alias": "synchronizedValue"; "required": false; }; "tick": { "alias": "tick"; "required": false; }; "tickInterval": { "alias": "tickInterval"; "required": false; }; "title": { "alias": "title"; "required": false; }; "type": { "alias": "type"; "required": false; }; "valueMarginsEnabled": { "alias": "valueMarginsEnabled"; "required": false; }; "valueType": { "alias": "valueType"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "visualRange": { "alias": "visualRange"; "required": false; }; "visualRangeUpdateMode": { "alias": "visualRangeUpdateMode"; "required": false; }; "wholeRange": { "alias": "wholeRange"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, { "categoriesChange": "categoriesChange"; "visualRangeChange": "visualRangeChange"; }, ["_breaksContentChildren", "_constantLinesContentChildren", "_stripsContentChildren"], never, true, never>;
}
declare class DxiValueAxisModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiValueAxisModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiValueAxisModule, never, [typeof DxiValueAxisComponent], [typeof DxiValueAxisComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiValueAxisModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoValueAxisComponent extends NestedOption implements OnDestroy, OnInit {
    set _constantLinesContentChildren(value: QueryList<CollectionNestedOption>);
    set _stripsContentChildren(value: QueryList<CollectionNestedOption>);
    get allowDecimals(): boolean | undefined;
    set allowDecimals(value: boolean | undefined);
    get axisDivisionFactor(): number;
    set axisDivisionFactor(value: number);
    get categories(): Array<number | string | Date>;
    set categories(value: Array<number | string | Date>);
    get color(): string;
    set color(value: string);
    get constantLines(): Array<any | {
        color?: string;
        dashStyle?: DashStyle;
        displayBehindSeries?: boolean;
        extendAxis?: boolean;
        label?: {
            font?: Font;
            text?: string | undefined;
            visible?: boolean;
        };
        value?: Date | number | string | undefined;
        width?: number;
    }>;
    set constantLines(value: Array<any | {
        color?: string;
        dashStyle?: DashStyle;
        displayBehindSeries?: boolean;
        extendAxis?: boolean;
        label?: {
            font?: Font;
            text?: string | undefined;
            visible?: boolean;
        };
        value?: Date | number | string | undefined;
        width?: number;
    }>);
    get constantLineStyle(): {
        color?: string;
        dashStyle?: DashStyle;
        label?: {
            font?: Font;
            visible?: boolean;
        };
        width?: number;
    };
    set constantLineStyle(value: {
        color?: string;
        dashStyle?: DashStyle;
        label?: {
            font?: Font;
            visible?: boolean;
        };
        width?: number;
    });
    get discreteAxisDivisionMode(): DiscreteAxisDivisionMode;
    set discreteAxisDivisionMode(value: DiscreteAxisDivisionMode);
    get endOnTick(): boolean;
    set endOnTick(value: boolean);
    get grid(): {
        color?: string;
        opacity?: number | undefined;
        visible?: boolean;
        width?: number;
    };
    set grid(value: {
        color?: string;
        opacity?: number | undefined;
        visible?: boolean;
        width?: number;
    });
    get inverted(): boolean;
    set inverted(value: boolean);
    get label(): {
        customizeHint?: Function;
        customizeText?: Function;
        font?: Font;
        format?: Format | string | undefined;
        indentFromAxis?: number;
        overlappingBehavior?: LabelOverlap;
        visible?: boolean;
    };
    set label(value: {
        customizeHint?: Function;
        customizeText?: Function;
        font?: Font;
        format?: Format | string | undefined;
        indentFromAxis?: number;
        overlappingBehavior?: LabelOverlap;
        visible?: boolean;
    });
    get linearThreshold(): number | undefined;
    set linearThreshold(value: number | undefined);
    get logarithmBase(): number;
    set logarithmBase(value: number);
    get maxValueMargin(): number | undefined;
    set maxValueMargin(value: number | undefined);
    get minorGrid(): {
        color?: string;
        opacity?: number | undefined;
        visible?: boolean;
        width?: number;
    };
    set minorGrid(value: {
        color?: string;
        opacity?: number | undefined;
        visible?: boolean;
        width?: number;
    });
    get minorTick(): {
        color?: string;
        length?: number;
        opacity?: number;
        visible?: boolean;
        width?: number;
    };
    set minorTick(value: {
        color?: string;
        length?: number;
        opacity?: number;
        visible?: boolean;
        width?: number;
    });
    get minorTickCount(): number | undefined;
    set minorTickCount(value: number | undefined);
    get minorTickInterval(): TimeInterval | number | {
        days?: number;
        hours?: number;
        milliseconds?: number;
        minutes?: number;
        months?: number;
        quarters?: number;
        seconds?: number;
        weeks?: number;
        years?: number;
    };
    set minorTickInterval(value: TimeInterval | number | {
        days?: number;
        hours?: number;
        milliseconds?: number;
        minutes?: number;
        months?: number;
        quarters?: number;
        seconds?: number;
        weeks?: number;
        years?: number;
    });
    get minValueMargin(): number | undefined;
    set minValueMargin(value: number | undefined);
    get minVisualRangeLength(): TimeInterval | number | undefined | {
        days?: number;
        hours?: number;
        milliseconds?: number;
        minutes?: number;
        months?: number;
        quarters?: number;
        seconds?: number;
        weeks?: number;
        years?: number;
    };
    set minVisualRangeLength(value: TimeInterval | number | undefined | {
        days?: number;
        hours?: number;
        milliseconds?: number;
        minutes?: number;
        months?: number;
        quarters?: number;
        seconds?: number;
        weeks?: number;
        years?: number;
    });
    get opacity(): number | undefined;
    set opacity(value: number | undefined);
    get showZero(): boolean | undefined;
    set showZero(value: boolean | undefined);
    get strips(): Array<any | {
        color?: string | undefined;
        endValue?: Date | number | string | undefined;
        label?: {
            font?: Font;
            text?: string | undefined;
        };
        startValue?: Date | number | string | undefined;
    }>;
    set strips(value: Array<any | {
        color?: string | undefined;
        endValue?: Date | number | string | undefined;
        label?: {
            font?: Font;
            text?: string | undefined;
        };
        startValue?: Date | number | string | undefined;
    }>);
    get stripStyle(): {
        label?: {
            font?: Font;
        };
    };
    set stripStyle(value: {
        label?: {
            font?: Font;
        };
    });
    get tick(): {
        color?: string;
        length?: number;
        opacity?: number | undefined;
        visible?: boolean;
        width?: number;
    };
    set tick(value: {
        color?: string;
        length?: number;
        opacity?: number | undefined;
        visible?: boolean;
        width?: number;
    });
    get tickInterval(): TimeInterval | number | {
        days?: number;
        hours?: number;
        milliseconds?: number;
        minutes?: number;
        months?: number;
        quarters?: number;
        seconds?: number;
        weeks?: number;
        years?: number;
    };
    set tickInterval(value: TimeInterval | number | {
        days?: number;
        hours?: number;
        milliseconds?: number;
        minutes?: number;
        months?: number;
        quarters?: number;
        seconds?: number;
        weeks?: number;
        years?: number;
    });
    get type(): AxisScaleType | undefined | ChartAxisScale;
    set type(value: AxisScaleType | undefined | ChartAxisScale);
    get valueMarginsEnabled(): boolean;
    set valueMarginsEnabled(value: boolean);
    get valueType(): ChartsDataType | undefined;
    set valueType(value: ChartsDataType | undefined);
    get visible(): boolean;
    set visible(value: boolean);
    get visualRange(): VisualRange | Array<number | string | Date>;
    set visualRange(value: VisualRange | Array<number | string | Date>);
    get visualRangeUpdateMode(): ValueAxisVisualRangeUpdateMode;
    set visualRangeUpdateMode(value: ValueAxisVisualRangeUpdateMode);
    get wholeRange(): VisualRange | undefined | Array<number | string | Date>;
    set wholeRange(value: VisualRange | undefined | Array<number | string | Date>);
    get width(): number;
    set width(value: number);
    get max(): number | undefined;
    set max(value: number | undefined);
    get min(): number | undefined;
    set min(value: number | undefined);
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    visualRangeChange: EventEmitter<VisualRange | Array<number | string | Date>>;
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoValueAxisComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoValueAxisComponent, "dxo-value-axis", never, { "allowDecimals": { "alias": "allowDecimals"; "required": false; }; "axisDivisionFactor": { "alias": "axisDivisionFactor"; "required": false; }; "categories": { "alias": "categories"; "required": false; }; "color": { "alias": "color"; "required": false; }; "constantLines": { "alias": "constantLines"; "required": false; }; "constantLineStyle": { "alias": "constantLineStyle"; "required": false; }; "discreteAxisDivisionMode": { "alias": "discreteAxisDivisionMode"; "required": false; }; "endOnTick": { "alias": "endOnTick"; "required": false; }; "grid": { "alias": "grid"; "required": false; }; "inverted": { "alias": "inverted"; "required": false; }; "label": { "alias": "label"; "required": false; }; "linearThreshold": { "alias": "linearThreshold"; "required": false; }; "logarithmBase": { "alias": "logarithmBase"; "required": false; }; "maxValueMargin": { "alias": "maxValueMargin"; "required": false; }; "minorGrid": { "alias": "minorGrid"; "required": false; }; "minorTick": { "alias": "minorTick"; "required": false; }; "minorTickCount": { "alias": "minorTickCount"; "required": false; }; "minorTickInterval": { "alias": "minorTickInterval"; "required": false; }; "minValueMargin": { "alias": "minValueMargin"; "required": false; }; "minVisualRangeLength": { "alias": "minVisualRangeLength"; "required": false; }; "opacity": { "alias": "opacity"; "required": false; }; "showZero": { "alias": "showZero"; "required": false; }; "strips": { "alias": "strips"; "required": false; }; "stripStyle": { "alias": "stripStyle"; "required": false; }; "tick": { "alias": "tick"; "required": false; }; "tickInterval": { "alias": "tickInterval"; "required": false; }; "type": { "alias": "type"; "required": false; }; "valueMarginsEnabled": { "alias": "valueMarginsEnabled"; "required": false; }; "valueType": { "alias": "valueType"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "visualRange": { "alias": "visualRange"; "required": false; }; "visualRangeUpdateMode": { "alias": "visualRangeUpdateMode"; "required": false; }; "wholeRange": { "alias": "wholeRange"; "required": false; }; "width": { "alias": "width"; "required": false; }; "max": { "alias": "max"; "required": false; }; "min": { "alias": "min"; "required": false; }; }, { "visualRangeChange": "visualRangeChange"; }, ["_constantLinesContentChildren", "_stripsContentChildren"], never, true, never>;
}
declare class DxoValueAxisModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoValueAxisModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoValueAxisModule, never, [typeof DxoValueAxisComponent], [typeof DxoValueAxisComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoValueAxisModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoValueErrorBarComponent extends NestedOption implements OnDestroy, OnInit {
    get color(): string;
    set color(value: string);
    get displayMode(): ValueErrorBarDisplayMode;
    set displayMode(value: ValueErrorBarDisplayMode);
    get edgeLength(): number;
    set edgeLength(value: number);
    get highValueField(): string | undefined;
    set highValueField(value: string | undefined);
    get lineWidth(): number;
    set lineWidth(value: number);
    get lowValueField(): string | undefined;
    set lowValueField(value: string | undefined);
    get opacity(): number | undefined;
    set opacity(value: number | undefined);
    get type(): ValueErrorBarType | undefined;
    set type(value: ValueErrorBarType | undefined);
    get value(): number;
    set value(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoValueErrorBarComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoValueErrorBarComponent, "dxo-value-error-bar", never, { "color": { "alias": "color"; "required": false; }; "displayMode": { "alias": "displayMode"; "required": false; }; "edgeLength": { "alias": "edgeLength"; "required": false; }; "highValueField": { "alias": "highValueField"; "required": false; }; "lineWidth": { "alias": "lineWidth"; "required": false; }; "lowValueField": { "alias": "lowValueField"; "required": false; }; "opacity": { "alias": "opacity"; "required": false; }; "type": { "alias": "type"; "required": false; }; "value": { "alias": "value"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoValueErrorBarModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoValueErrorBarModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoValueErrorBarModule, never, [typeof DxoValueErrorBarComponent], [typeof DxoValueErrorBarComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoValueErrorBarModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoValueFormatComponent extends DxoFormat implements OnDestroy, OnInit {
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoValueFormatComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoValueFormatComponent, "dxo-value-format", never, { "currency": { "alias": "currency"; "required": false; }; "formatter": { "alias": "formatter"; "required": false; }; "parser": { "alias": "parser"; "required": false; }; "precision": { "alias": "precision"; "required": false; }; "type": { "alias": "type"; "required": false; }; "useCurrencyAccountingStyle": { "alias": "useCurrencyAccountingStyle"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoValueFormatModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoValueFormatModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoValueFormatModule, never, [typeof DxoValueFormatComponent], [typeof DxoValueFormatComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoValueFormatModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoValueIndicatorComponent extends DxoGaugeIndicator implements OnDestroy, OnInit {
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoValueIndicatorComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoValueIndicatorComponent, "dxo-value-indicator", never, { "arrowLength": { "alias": "arrowLength"; "required": false; }; "backgroundColor": { "alias": "backgroundColor"; "required": false; }; "baseValue": { "alias": "baseValue"; "required": false; }; "beginAdaptingAtRadius": { "alias": "beginAdaptingAtRadius"; "required": false; }; "color": { "alias": "color"; "required": false; }; "horizontalOrientation": { "alias": "horizontalOrientation"; "required": false; }; "indentFromCenter": { "alias": "indentFromCenter"; "required": false; }; "length": { "alias": "length"; "required": false; }; "offset": { "alias": "offset"; "required": false; }; "palette": { "alias": "palette"; "required": false; }; "secondColor": { "alias": "secondColor"; "required": false; }; "secondFraction": { "alias": "secondFraction"; "required": false; }; "size": { "alias": "size"; "required": false; }; "spindleGapSize": { "alias": "spindleGapSize"; "required": false; }; "spindleSize": { "alias": "spindleSize"; "required": false; }; "text": { "alias": "text"; "required": false; }; "type": { "alias": "type"; "required": false; }; "verticalOrientation": { "alias": "verticalOrientation"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoValueIndicatorModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoValueIndicatorModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoValueIndicatorModule, never, [typeof DxoValueIndicatorComponent], [typeof DxoValueIndicatorComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoValueIndicatorModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare abstract class DxoHtmlEditorVariables extends NestedOption {
    get dataSource(): Store | DataSource | Options | null | string | Array<string>;
    set dataSource(value: Store | DataSource | Options | null | string | Array<string>);
    get escapeChar(): string | Array<string>;
    set escapeChar(value: string | Array<string>);
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoHtmlEditorVariables, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoHtmlEditorVariables, "ng-component", never, {}, {}, never, never, true, never>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoVariablesComponent extends DxoHtmlEditorVariables implements OnDestroy, OnInit {
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoVariablesComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoVariablesComponent, "dxo-variables", never, { "dataSource": { "alias": "dataSource"; "required": false; }; "escapeChar": { "alias": "escapeChar"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoVariablesModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoVariablesModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoVariablesModule, never, [typeof DxoVariablesComponent], [typeof DxoVariablesComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoVariablesModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoVerticalLineComponent extends NestedOption implements OnDestroy, OnInit {
    get color(): string;
    set color(value: string);
    get dashStyle(): DashStyle;
    set dashStyle(value: DashStyle);
    get label(): {
        backgroundColor?: string;
        customizeText?: Function;
        font?: Font;
        format?: Format | string | undefined;
        visible?: boolean;
    };
    set label(value: {
        backgroundColor?: string;
        customizeText?: Function;
        font?: Font;
        format?: Format | string | undefined;
        visible?: boolean;
    });
    get opacity(): number | undefined;
    set opacity(value: number | undefined);
    get visible(): boolean;
    set visible(value: boolean);
    get width(): number;
    set width(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoVerticalLineComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoVerticalLineComponent, "dxo-vertical-line", never, { "color": { "alias": "color"; "required": false; }; "dashStyle": { "alias": "dashStyle"; "required": false; }; "label": { "alias": "label"; "required": false; }; "opacity": { "alias": "opacity"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoVerticalLineModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoVerticalLineModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoVerticalLineModule, never, [typeof DxoVerticalLineComponent], [typeof DxoVerticalLineComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoVerticalLineModule>;
}

declare class DxiViewComponent extends CollectionNestedOption {
    get agendaDuration(): number;
    set agendaDuration(value: number);
    get allDayPanelMode(): AllDayPanelMode;
    set allDayPanelMode(value: AllDayPanelMode);
    get appointmentCollectorTemplate(): any;
    set appointmentCollectorTemplate(value: any);
    get appointmentTemplate(): any;
    set appointmentTemplate(value: any);
    get appointmentTooltipTemplate(): any;
    set appointmentTooltipTemplate(value: any);
    get cellDuration(): number;
    set cellDuration(value: number);
    get dataCellTemplate(): any;
    set dataCellTemplate(value: any);
    get dateCellTemplate(): any;
    set dateCellTemplate(value: any);
    get endDayHour(): number;
    set endDayHour(value: number);
    get firstDayOfWeek(): DayOfWeek | undefined;
    set firstDayOfWeek(value: DayOfWeek | undefined);
    get groupByDate(): boolean;
    set groupByDate(value: boolean);
    get groupOrientation(): Orientation;
    set groupOrientation(value: Orientation);
    get groups(): Array<string>;
    set groups(value: Array<string>);
    get intervalCount(): number;
    set intervalCount(value: number);
    get maxAppointmentsPerCell(): CellAppointmentsLimit | number;
    set maxAppointmentsPerCell(value: CellAppointmentsLimit | number);
    get name(): string | undefined;
    set name(value: string | undefined);
    get offset(): number;
    set offset(value: number);
    get resourceCellTemplate(): any;
    set resourceCellTemplate(value: any);
    get scrolling(): dxSchedulerScrolling;
    set scrolling(value: dxSchedulerScrolling);
    get startDate(): Date | number | string | undefined;
    set startDate(value: Date | number | string | undefined);
    get startDayHour(): number;
    set startDayHour(value: number);
    get timeCellTemplate(): any;
    set timeCellTemplate(value: any);
    get type(): ViewType | undefined;
    set type(value: ViewType | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiViewComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiViewComponent, "dxi-view", never, { "agendaDuration": { "alias": "agendaDuration"; "required": false; }; "allDayPanelMode": { "alias": "allDayPanelMode"; "required": false; }; "appointmentCollectorTemplate": { "alias": "appointmentCollectorTemplate"; "required": false; }; "appointmentTemplate": { "alias": "appointmentTemplate"; "required": false; }; "appointmentTooltipTemplate": { "alias": "appointmentTooltipTemplate"; "required": false; }; "cellDuration": { "alias": "cellDuration"; "required": false; }; "dataCellTemplate": { "alias": "dataCellTemplate"; "required": false; }; "dateCellTemplate": { "alias": "dateCellTemplate"; "required": false; }; "endDayHour": { "alias": "endDayHour"; "required": false; }; "firstDayOfWeek": { "alias": "firstDayOfWeek"; "required": false; }; "groupByDate": { "alias": "groupByDate"; "required": false; }; "groupOrientation": { "alias": "groupOrientation"; "required": false; }; "groups": { "alias": "groups"; "required": false; }; "intervalCount": { "alias": "intervalCount"; "required": false; }; "maxAppointmentsPerCell": { "alias": "maxAppointmentsPerCell"; "required": false; }; "name": { "alias": "name"; "required": false; }; "offset": { "alias": "offset"; "required": false; }; "resourceCellTemplate": { "alias": "resourceCellTemplate"; "required": false; }; "scrolling": { "alias": "scrolling"; "required": false; }; "startDate": { "alias": "startDate"; "required": false; }; "startDayHour": { "alias": "startDayHour"; "required": false; }; "timeCellTemplate": { "alias": "timeCellTemplate"; "required": false; }; "type": { "alias": "type"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxiViewModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiViewModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiViewModule, never, [typeof DxiViewComponent], [typeof DxiViewComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiViewModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoViewToolbarComponent extends NestedOption implements OnDestroy, OnInit {
    set _commandsContentChildren(value: QueryList<CollectionNestedOption>);
    get commands(): Array<CustomCommand | Command>;
    set commands(value: Array<CustomCommand | Command>);
    get visible(): boolean;
    set visible(value: boolean);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoViewToolbarComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoViewToolbarComponent, "dxo-view-toolbar", never, { "commands": { "alias": "commands"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; }, {}, ["_commandsContentChildren"], never, true, never>;
}
declare class DxoViewToolbarModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoViewToolbarModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoViewToolbarModule, never, [typeof DxoViewToolbarComponent], [typeof DxoViewToolbarComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoViewToolbarModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoWidthComponent extends NestedOption implements OnDestroy, OnInit {
    get rangeMaxPoint(): number | undefined;
    set rangeMaxPoint(value: number | undefined);
    get rangeMinPoint(): number | undefined;
    set rangeMinPoint(value: number | undefined);
    get end(): number;
    set end(value: number);
    get start(): number;
    set start(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoWidthComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoWidthComponent, "dxo-width", never, { "rangeMaxPoint": { "alias": "rangeMaxPoint"; "required": false; }; "rangeMinPoint": { "alias": "rangeMinPoint"; "required": false; }; "end": { "alias": "end"; "required": false; }; "start": { "alias": "start"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoWidthModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoWidthModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoWidthModule, never, [typeof DxoWidthComponent], [typeof DxoWidthComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoWidthModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoZoomAndPanComponent extends NestedOption implements OnDestroy, OnInit {
    get allowMouseWheel(): boolean;
    set allowMouseWheel(value: boolean);
    get allowTouchGestures(): boolean;
    set allowTouchGestures(value: boolean);
    get argumentAxis(): ChartZoomAndPanMode;
    set argumentAxis(value: ChartZoomAndPanMode);
    get dragBoxStyle(): {
        color?: string | undefined;
        opacity?: number | undefined;
    };
    set dragBoxStyle(value: {
        color?: string | undefined;
        opacity?: number | undefined;
    });
    get dragToZoom(): boolean;
    set dragToZoom(value: boolean);
    get panKey(): EventKeyModifier;
    set panKey(value: EventKeyModifier);
    get valueAxis(): ChartZoomAndPanMode;
    set valueAxis(value: ChartZoomAndPanMode);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoZoomAndPanComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoZoomAndPanComponent, "dxo-zoom-and-pan", never, { "allowMouseWheel": { "alias": "allowMouseWheel"; "required": false; }; "allowTouchGestures": { "alias": "allowTouchGestures"; "required": false; }; "argumentAxis": { "alias": "argumentAxis"; "required": false; }; "dragBoxStyle": { "alias": "dragBoxStyle"; "required": false; }; "dragToZoom": { "alias": "dragToZoom"; "required": false; }; "panKey": { "alias": "panKey"; "required": false; }; "valueAxis": { "alias": "valueAxis"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoZoomAndPanModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoZoomAndPanModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoZoomAndPanModule, never, [typeof DxoZoomAndPanComponent], [typeof DxoZoomAndPanComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoZoomAndPanModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoZoomLevelComponent extends NestedOption implements OnDestroy, OnInit {
    get items(): Array<number>;
    set items(value: Array<number>);
    get value(): number | undefined;
    set value(value: number | undefined);
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    valueChange: EventEmitter<number | undefined>;
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoZoomLevelComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoZoomLevelComponent, "dxo-zoom-level", never, { "items": { "alias": "items"; "required": false; }; "value": { "alias": "value"; "required": false; }; }, { "valueChange": "valueChange"; }, never, never, true, never>;
}
declare class DxoZoomLevelModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoZoomLevelModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoZoomLevelModule, never, [typeof DxoZoomLevelComponent], [typeof DxoZoomLevelComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoZoomLevelModule>;
}

export { DxiAlertComponent, DxiAlertModule, DxiAnnotationComponent, DxiAnnotationModule, DxiBreakComponent, DxiBreakModule, DxiButtonComponent, DxiButtonModule, DxiCenterComponent, DxiCenterModule, DxiChangeComponent, DxiChangeModule, DxiColComponent, DxiColModule, DxiColumnComponent, DxiColumnModule, DxiCommandComponent, DxiCommandModule, DxiConnectionPointComponent, DxiConnectionPointModule, DxiConstantLineComponent, DxiConstantLineModule, DxiCustomOperationComponent, DxiCustomOperationModule, DxiCustomShapeComponent, DxiCustomShapeModule, DxiFieldComponent, DxiFieldModule, DxiFileSelectionItemComponent, DxiFileSelectionItemModule, DxiGroupComponent, DxiGroupItemComponent, DxiGroupItemModule, DxiGroupModule, DxiItemComponent, DxiItemModule, DxiLayerComponent, DxiLayerModule, DxiLegendComponent, DxiLegendModule, DxiLocationComponent, DxiLocationModule, DxiMarkerComponent, DxiMarkerModule, DxiMentionComponent, DxiMentionModule, DxiMenuItemComponent, DxiMenuItemModule, DxiPaneComponent, DxiPaneModule, DxiRangeComponent, DxiRangeModule, DxiResourceComponent, DxiResourceModule, DxiRouteComponent, DxiRouteModule, DxiRowComponent, DxiRowModule, DxiSeriesComponent, DxiSeriesModule, DxiSortByGroupSummaryInfoComponent, DxiSortByGroupSummaryInfoModule, DxiStripComponent, DxiStripLineComponent, DxiStripLineModule, DxiStripModule, DxiTabComponent, DxiTabModule, DxiToolbarItemComponent, DxiToolbarItemModule, DxiTotalItemComponent, DxiTotalItemModule, DxiTypingUserComponent, DxiTypingUserModule, DxiValidationRuleComponent, DxiValidationRuleModule, DxiValueAxisComponent, DxiValueAxisModule, DxiViewComponent, DxiViewModule, DxoAdapterComponent, DxoAdapterModule, DxoAdaptiveLayoutComponent, DxoAdaptiveLayoutModule, DxoAggregationComponent, DxoAggregationIntervalComponent, DxoAggregationIntervalModule, DxoAggregationModule, DxoAnimationComponent, DxoAnimationModule, DxoApiKeyComponent, DxoApiKeyModule, DxoAppointmentDraggingComponent, DxoAppointmentDraggingModule, DxoAreaComponent, DxoAreaModule, DxoArgumentAxisComponent, DxoArgumentAxisModule, DxoArgumentFormatComponent, DxoArgumentFormatModule, DxoAtComponent, DxoAtModule, DxoAuthorComponent, DxoAuthorModule, DxoAutoLayoutComponent, DxoAutoLayoutModule, DxoBackgroundColorComponent, DxoBackgroundColorModule, DxoBackgroundComponent, DxoBackgroundModule, DxoBarComponent, DxoBarModule, DxoBehaviorComponent, DxoBehaviorModule, DxoBorderComponent, DxoBorderModule, DxoBoundaryOffsetComponent, DxoBoundaryOffsetModule, DxoBoxComponent, DxoBoxModule, DxoBreakStyleComponent, DxoBreakStyleModule, DxoBubbleComponent, DxoBubbleModule, DxoButtonOptionsComponent, DxoButtonOptionsModule, DxoCalendarOptionsComponent, DxoCalendarOptionsModule, DxoCandlestickComponent, DxoCandlestickModule, DxoChartComponent, DxoChartModule, DxoColCountByScreenComponent, DxoColCountByScreenModule, DxoCollisionComponent, DxoCollisionModule, DxoColorComponent, DxoColorModule, DxoColorizerComponent, DxoColorizerModule, DxoColumnChooserComponent, DxoColumnChooserModule, DxoColumnFixingComponent, DxoColumnFixingModule, DxoCommonAnnotationSettingsComponent, DxoCommonAnnotationSettingsModule, DxoCommonAxisSettingsComponent, DxoCommonAxisSettingsModule, DxoCommonPaneSettingsComponent, DxoCommonPaneSettingsModule, DxoCommonSeriesSettingsComponent, DxoCommonSeriesSettingsModule, DxoConnectorComponent, DxoConnectorModule, DxoConstantLineStyleComponent, DxoConstantLineStyleModule, DxoContextMenuComponent, DxoContextMenuModule, DxoContextToolboxComponent, DxoContextToolboxModule, DxoControlBarComponent, DxoControlBarModule, DxoConverterComponent, DxoConverterModule, DxoCrosshairComponent, DxoCrosshairModule, DxoCursorOffsetComponent, DxoCursorOffsetModule, DxoDataPrepareSettingsComponent, DxoDataPrepareSettingsModule, DxoDayHeaderFormatComponent, DxoDayHeaderFormatModule, DxoDefaultItemPropertiesComponent, DxoDefaultItemPropertiesModule, DxoDelayComponent, DxoDelayModule, DxoDependenciesComponent, DxoDependenciesModule, DxoDetailsComponent, DxoDetailsModule, DxoDisplayFormatComponent, DxoDisplayFormatModule, DxoDragBoxStyleComponent, DxoDragBoxStyleModule, DxoDropDownOptionsComponent, DxoDropDownOptionsModule, DxoEdgesComponent, DxoEdgesModule, DxoEditingComponent, DxoEditingModule, DxoExportComponent, DxoExportModule, DxoFieldChooserComponent, DxoFieldChooserModule, DxoFieldPanelComponent, DxoFieldPanelModule, DxoFileUploaderOptionsComponent, DxoFileUploaderOptionsModule, DxoFilterBuilderComponent, DxoFilterBuilderModule, DxoFilterBuilderPopupComponent, DxoFilterBuilderPopupModule, DxoFilterOperationDescriptionsComponent, DxoFilterOperationDescriptionsModule, DxoFilterPanelComponent, DxoFilterPanelModule, DxoFilterRowComponent, DxoFilterRowModule, DxoFontComponent, DxoFontModule, DxoFormComponent, DxoFormItemComponent, DxoFormItemModule, DxoFormModule, DxoFormatComponent, DxoFormatModule, DxoFromComponent, DxoFromModule, DxoFullstackedareaComponent, DxoFullstackedareaModule, DxoFullstackedbarComponent, DxoFullstackedbarModule, DxoFullstackedlineComponent, DxoFullstackedlineModule, DxoFullstackedsplineComponent, DxoFullstackedsplineModule, DxoFullstackedsplineareaComponent, DxoFullstackedsplineareaModule, DxoGeometryComponent, DxoGeometryModule, DxoGridComponent, DxoGridModule, DxoGridSizeComponent, DxoGridSizeModule, DxoGroupComponent, DxoGroupModule, DxoGroupOperationDescriptionsComponent, DxoGroupOperationDescriptionsModule, DxoGroupPanelComponent, DxoGroupPanelModule, DxoGroupingComponent, DxoGroupingModule, DxoHatchingComponent, DxoHatchingModule, DxoHeaderFilterComponent, DxoHeaderFilterModule, DxoHeightComponent, DxoHeightModule, DxoHideComponent, DxoHideEventComponent, DxoHideEventModule, DxoHideModule, DxoHistoryToolbarComponent, DxoHistoryToolbarModule, DxoHorizontalLineComponent, DxoHorizontalLineModule, DxoHoverStyleComponent, DxoHoverStyleModule, DxoIconsComponent, DxoIconsModule, DxoImageComponent, DxoImageModule, DxoImageUploadComponent, DxoImageUploadModule, DxoIndentComponent, DxoIndentModule, DxoItemComponent, DxoItemDraggingComponent, DxoItemDraggingModule, DxoItemModule, DxoItemTextFormatComponent, DxoItemTextFormatModule, DxoItemViewComponent, DxoItemViewModule, DxoKeyboardNavigationComponent, DxoKeyboardNavigationModule, DxoLabelComponent, DxoLabelModule, DxoLegendComponent, DxoLegendModule, DxoLineComponent, DxoLineModule, DxoLinkComponent, DxoLinkModule, DxoLoadPanelComponent, DxoLoadPanelModule, DxoLoadingIndicatorComponent, DxoLoadingIndicatorModule, DxoLookupComponent, DxoLookupModule, DxoMainToolbarComponent, DxoMainToolbarModule, DxoMarginComponent, DxoMarginModule, DxoMarkerComponent, DxoMarkerModule, DxoMasterDetailComponent, DxoMasterDetailModule, DxoMaxRangeComponent, DxoMaxRangeModule, DxoMediaResizingComponent, DxoMediaResizingModule, DxoMessageTimestampFormatComponent, DxoMessageTimestampFormatModule, DxoMinRangeComponent, DxoMinRangeModule, DxoMinVisualRangeLengthComponent, DxoMinVisualRangeLengthModule, DxoMinorGridComponent, DxoMinorGridModule, DxoMinorTickComponent, DxoMinorTickIntervalComponent, DxoMinorTickIntervalModule, DxoMinorTickModule, DxoMyComponent, DxoMyModule, DxoNodeComponent, DxoNodeModule, DxoNodesComponent, DxoNodesModule, DxoNotificationsComponent, DxoNotificationsModule, DxoOffsetComponent, DxoOffsetModule, DxoOperationDescriptionsComponent, DxoOperationDescriptionsModule, DxoOptionsComponent, DxoOptionsModule, DxoPageSizeComponent, DxoPageSizeModule, DxoPagerComponent, DxoPagerModule, DxoPagingComponent, DxoPagingModule, DxoPermissionsComponent, DxoPermissionsModule, DxoPointComponent, DxoPointModule, DxoPopupComponent, DxoPopupModule, DxoPositionComponent, DxoPositionModule, DxoProjectionComponent, DxoProjectionModule, DxoPropertiesPanelComponent, DxoPropertiesPanelModule, DxoProviderConfigComponent, DxoProviderConfigModule, DxoRangeContainerComponent, DxoRangeContainerModule, DxoRangeareaComponent, DxoRangeareaModule, DxoRangebarComponent, DxoRangebarModule, DxoReductionComponent, DxoReductionModule, DxoRemoteOperationsComponent, DxoRemoteOperationsModule, DxoResourceAssignmentsComponent, DxoResourceAssignmentsModule, DxoResourcesComponent, DxoResourcesModule, DxoRowDraggingComponent, DxoRowDraggingModule, DxoScaleComponent, DxoScaleModule, DxoScaleTypeRangeComponent, DxoScaleTypeRangeModule, DxoScatterComponent, DxoScatterModule, DxoScrollBarComponent, DxoScrollBarModule, DxoScrollingComponent, DxoScrollingModule, DxoSearchComponent, DxoSearchEditorOptionsComponent, DxoSearchEditorOptionsModule, DxoSearchModule, DxoSearchPanelComponent, DxoSearchPanelModule, DxoSelectionComponent, DxoSelectionModule, DxoSelectionStyleComponent, DxoSelectionStyleModule, DxoSeriesTemplateComponent, DxoSeriesTemplateModule, DxoShadowComponent, DxoShadowModule, DxoShowComponent, DxoShowEventComponent, DxoShowEventModule, DxoShowFirstSubmenuModeComponent, DxoShowFirstSubmenuModeModule, DxoShowModule, DxoShowSubmenuModeComponent, DxoShowSubmenuModeModule, DxoShutterComponent, DxoShutterModule, DxoSizeComponent, DxoSizeModule, DxoSliderHandleComponent, DxoSliderHandleModule, DxoSliderMarkerComponent, DxoSliderMarkerModule, DxoSmallValuesGroupingComponent, DxoSmallValuesGroupingModule, DxoSortingComponent, DxoSortingModule, DxoSourceComponent, DxoSourceModule, DxoSplineComponent, DxoSplineModule, DxoSplineareaComponent, DxoSplineareaModule, DxoSplitterComponent, DxoSplitterModule, DxoStackedareaComponent, DxoStackedareaModule, DxoStackedbarComponent, DxoStackedbarModule, DxoStackedlineComponent, DxoStackedlineModule, DxoStackedsplineComponent, DxoStackedsplineModule, DxoStackedsplineareaComponent, DxoStackedsplineareaModule, DxoStateStoringComponent, DxoStateStoringModule, DxoStepareaComponent, DxoStepareaModule, DxoSteplineComponent, DxoSteplineModule, DxoStockComponent, DxoStockModule, DxoStripStyleComponent, DxoStripStyleModule, DxoSubtitleComponent, DxoSubtitleModule, DxoSubvalueIndicatorComponent, DxoSubvalueIndicatorModule, DxoSummaryComponent, DxoSummaryModule, DxoTabPanelOptionsComponent, DxoTabPanelOptionsModule, DxoTableContextMenuComponent, DxoTableContextMenuModule, DxoTableResizingComponent, DxoTableResizingModule, DxoTasksComponent, DxoTasksModule, DxoTextComponent, DxoTextModule, DxoTextsComponent, DxoTextsModule, DxoTickComponent, DxoTickIntervalComponent, DxoTickIntervalModule, DxoTickModule, DxoTileComponent, DxoTileModule, DxoTitleComponent, DxoTitleModule, DxoToComponent, DxoToModule, DxoToolbarComponent, DxoToolbarModule, DxoToolboxComponent, DxoToolboxModule, DxoTooltipComponent, DxoTooltipModule, DxoUploadComponent, DxoUploadModule, DxoUrlComponent, DxoUrlModule, DxoUserComponent, DxoUserModule, DxoValidationComponent, DxoValidationModule, DxoValueAxisComponent, DxoValueAxisModule, DxoValueErrorBarComponent, DxoValueErrorBarModule, DxoValueFormatComponent, DxoValueFormatModule, DxoValueIndicatorComponent, DxoValueIndicatorModule, DxoVariablesComponent, DxoVariablesModule, DxoVerticalLineComponent, DxoVerticalLineModule, DxoViewToolbarComponent, DxoViewToolbarModule, DxoWidthComponent, DxoWidthModule, DxoZoomAndPanComponent, DxoZoomAndPanModule, DxoZoomLevelComponent, DxoZoomLevelModule };
//# sourceMappingURL=index.d.ts.map
