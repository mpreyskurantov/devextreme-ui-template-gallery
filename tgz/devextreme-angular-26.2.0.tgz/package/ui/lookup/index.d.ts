import * as i0 from '@angular/core';
import { OnDestroy, OnChanges, DoCheck, QueryList, EventEmitter, ElementRef, NgZone, TransferState, SimpleChanges } from '@angular/core';
import { ApplyValueMode, LabelMode, PageLoadMode, SimplifiedSearchMode, EditorStyle, ValidationMessageMode, Mode, Position, ValidationStatus } from 'devextreme/common';
import { CollectionWidgetItem } from 'devextreme/ui/collection/ui.collection_widget.base';
import DataSource, { DataSourceOptions } from 'devextreme/data/data_source';
import { Store } from 'devextreme/data/store';
import { dxPopoverOptions } from 'devextreme/ui/popover';
import DxLookup, { ClosedEvent, ContentReadyEvent, DisposingEvent, InitializedEvent, ItemClickEvent, OpenedEvent, OptionChangedEvent, PageLoadingEvent, PullRefreshEvent, ScrollEvent, SelectionChangedEvent, ValueChangedEvent } from 'devextreme/ui/lookup';
import { ControlValueAccessor } from '@angular/forms';
import * as i3 from 'devextreme-angular/core';
import { DxComponent, CollectionNestedOption, DxTemplateHost, WatcherHelper, IterableDifferHelper, NestedOptionHost } from 'devextreme-angular/core';
import * as i1 from 'devextreme-angular/ui/nested';
import * as i2 from 'devextreme-angular/ui/lookup/nested';
export * from 'devextreme-angular/ui/lookup/nested';
import * as lookup_types from 'devextreme/ui/lookup_types';
export { lookup_types as DxLookupTypes };

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

/**
 * [descr:dxLookup]

 */
declare class DxLookupComponent extends DxComponent implements OnDestroy, ControlValueAccessor, OnChanges, DoCheck {
    private _watcherHelper;
    private _idh;
    set _itemsContentChildren(value: QueryList<CollectionNestedOption>);
    set _toolbarItemsContentChildren(value: QueryList<CollectionNestedOption>);
    instance: DxLookup;
    /**
     * [descr:WidgetOptions.accessKey]
    
     */
    get accessKey(): string | undefined;
    set accessKey(value: string | undefined);
    /**
     * [descr:dxDropDownEditorOptions.activeStateEnabled]
    
     */
    get activeStateEnabled(): boolean;
    set activeStateEnabled(value: boolean);
    /**
     * [descr:dxLookupOptions.applyButtonText]
    
     */
    get applyButtonText(): string;
    set applyButtonText(value: string);
    /**
     * [descr:dxLookupOptions.applyValueMode]
    
     */
    get applyValueMode(): ApplyValueMode;
    set applyValueMode(value: ApplyValueMode);
    /**
     * [descr:dxLookupOptions.cancelButtonText]
    
     */
    get cancelButtonText(): string;
    set cancelButtonText(value: string);
    /**
     * [descr:dxLookupOptions.cleanSearchOnOpening]
    
     */
    get cleanSearchOnOpening(): boolean;
    set cleanSearchOnOpening(value: boolean);
    /**
     * [descr:dxLookupOptions.clearButtonText]
    
     */
    get clearButtonText(): string;
    set clearButtonText(value: string);
    /**
     * [descr:DataExpressionMixinOptions.dataSource]
    
     */
    get dataSource(): Array<any | CollectionWidgetItem> | DataSource | DataSourceOptions | null | Store | string;
    set dataSource(value: Array<any | CollectionWidgetItem> | DataSource | DataSourceOptions | null | Store | string);
    /**
     * [descr:dxDropDownEditorOptions.deferRendering]
    
     */
    get deferRendering(): boolean;
    set deferRendering(value: boolean);
    /**
     * [descr:WidgetOptions.disabled]
    
     */
    get disabled(): boolean;
    set disabled(value: boolean);
    /**
     * [descr:DataExpressionMixinOptions.displayExpr]
    
     */
    get displayExpr(): ((item: any) => string) | string | undefined;
    set displayExpr(value: ((item: any) => string) | string | undefined);
    /**
     * [descr:dxDropDownListOptions.displayValue]
    
     */
    get displayValue(): string | undefined;
    set displayValue(value: string | undefined);
    /**
     * [descr:dxLookupOptions.dropDownCentered]
    
     */
    get dropDownCentered(): boolean;
    set dropDownCentered(value: boolean);
    /**
     * [descr:dxLookupOptions.dropDownOptions]
    
     */
    get dropDownOptions(): dxPopoverOptions<any>;
    set dropDownOptions(value: dxPopoverOptions<any>);
    /**
     * [descr:DOMComponentOptions.elementAttr]
    
     */
    get elementAttr(): Record<string, any>;
    set elementAttr(value: Record<string, any>);
    /**
     * [descr:dxLookupOptions.fieldTemplate]
    
     */
    get fieldTemplate(): any;
    set fieldTemplate(value: any);
    /**
     * [descr:dxLookupOptions.focusStateEnabled]
    
     */
    get focusStateEnabled(): boolean;
    set focusStateEnabled(value: boolean);
    /**
     * [descr:dxLookupOptions.grouped]
    
     */
    get grouped(): boolean;
    set grouped(value: boolean);
    /**
     * [descr:dxLookupOptions.groupTemplate]
    
     */
    get groupTemplate(): any;
    set groupTemplate(value: any);
    /**
     * [descr:DOMComponentOptions.height]
    
     */
    get height(): number | string | undefined;
    set height(value: number | string | undefined);
    /**
     * [descr:WidgetOptions.hint]
    
     */
    get hint(): string | undefined;
    set hint(value: string | undefined);
    /**
     * [descr:dxTextEditorOptions.hoverStateEnabled]
    
     */
    get hoverStateEnabled(): boolean;
    set hoverStateEnabled(value: boolean);
    /**
     * [descr:dxTextEditorOptions.inputAttr]
    
     */
    get inputAttr(): any;
    set inputAttr(value: any);
    /**
     * [descr:EditorOptions.isDirty]
    
     */
    get isDirty(): boolean;
    set isDirty(value: boolean);
    /**
     * [descr:EditorOptions.isValid]
    
     */
    get isValid(): boolean;
    set isValid(value: boolean);
    /**
     * [descr:DataExpressionMixinOptions.items]
    
     */
    get items(): Array<any | CollectionWidgetItem>;
    set items(value: Array<any | CollectionWidgetItem>);
    /**
     * [descr:DataExpressionMixinOptions.itemTemplate]
    
     */
    get itemTemplate(): any;
    set itemTemplate(value: any);
    /**
     * [descr:dxTextEditorOptions.label]
    
     */
    get label(): string;
    set label(value: string);
    /**
     * [descr:dxTextEditorOptions.labelMode]
    
     */
    get labelMode(): LabelMode;
    set labelMode(value: LabelMode);
    /**
     * [descr:dxDropDownListOptions.minSearchLength]
    
     */
    get minSearchLength(): number;
    set minSearchLength(value: number);
    /**
     * [descr:dxTextEditorOptions.name]
    
     */
    get name(): string;
    set name(value: string);
    /**
     * [descr:dxLookupOptions.nextButtonText]
    
     */
    get nextButtonText(): string;
    set nextButtonText(value: string);
    /**
     * [descr:dxDropDownListOptions.noDataText]
    
     */
    get noDataText(): string;
    set noDataText(value: string);
    /**
     * [descr:dxDropDownEditorOptions.opened]
    
     */
    get opened(): boolean;
    set opened(value: boolean);
    /**
     * [descr:dxLookupOptions.pageLoadingText]
    
     */
    get pageLoadingText(): string;
    set pageLoadingText(value: string);
    /**
     * [descr:dxLookupOptions.pageLoadMode]
    
     */
    get pageLoadMode(): PageLoadMode;
    set pageLoadMode(value: PageLoadMode);
    /**
     * [descr:dxLookupOptions.placeholder]
    
     */
    get placeholder(): string;
    set placeholder(value: string);
    /**
     * [descr:dxLookupOptions.pulledDownText]
    
     */
    get pulledDownText(): string;
    set pulledDownText(value: string);
    /**
     * [descr:dxLookupOptions.pullingDownText]
    
     */
    get pullingDownText(): string;
    set pullingDownText(value: string);
    /**
     * [descr:dxLookupOptions.pullRefreshEnabled]
    
     */
    get pullRefreshEnabled(): boolean;
    set pullRefreshEnabled(value: boolean);
    /**
     * [descr:dxLookupOptions.refreshingText]
    
     */
    get refreshingText(): string;
    set refreshingText(value: string);
    /**
     * [descr:DOMComponentOptions.rtlEnabled]
    
     */
    get rtlEnabled(): boolean;
    set rtlEnabled(value: boolean);
    /**
     * [descr:dxLookupOptions.searchEnabled]
    
     */
    get searchEnabled(): boolean;
    set searchEnabled(value: boolean);
    /**
     * [descr:dxDropDownListOptions.searchExpr]
    
     */
    get searchExpr(): Array<Function | string> | Function | string;
    set searchExpr(value: Array<Function | string> | Function | string);
    /**
     * [descr:dxDropDownListOptions.searchMode]
    
     */
    get searchMode(): SimplifiedSearchMode;
    set searchMode(value: SimplifiedSearchMode);
    /**
     * [descr:dxLookupOptions.searchPlaceholder]
    
     */
    get searchPlaceholder(): string;
    set searchPlaceholder(value: string);
    /**
     * [descr:dxLookupOptions.searchStartEvent]
    
     */
    get searchStartEvent(): string;
    set searchStartEvent(value: string);
    /**
     * [descr:dxDropDownListOptions.searchTimeout]
    
     */
    get searchTimeout(): number;
    set searchTimeout(value: number);
    /**
     * [descr:dxDropDownListOptions.selectedItem]
    
     */
    get selectedItem(): any | null;
    set selectedItem(value: any | null);
    /**
     * [descr:dxLookupOptions.showCancelButton]
    
     */
    get showCancelButton(): boolean;
    set showCancelButton(value: boolean);
    /**
     * [descr:dxLookupOptions.showClearButton]
    
     */
    get showClearButton(): boolean;
    set showClearButton(value: boolean);
    /**
     * [descr:dxDropDownListOptions.showDataBeforeSearch]
    
     */
    get showDataBeforeSearch(): boolean;
    set showDataBeforeSearch(value: boolean);
    /**
     * [descr:dxTextEditorOptions.stylingMode]
    
     */
    get stylingMode(): EditorStyle;
    set stylingMode(value: EditorStyle);
    /**
     * [descr:WidgetOptions.tabIndex]
    
     */
    get tabIndex(): number;
    set tabIndex(value: number);
    /**
     * [descr:dxTextEditorOptions.text]
    
     */
    get text(): string;
    set text(value: string);
    /**
     * [descr:dxDropDownListOptions.useItemTextAsTitle]
    
     */
    get useItemTextAsTitle(): boolean;
    set useItemTextAsTitle(value: boolean);
    /**
     * [descr:dxLookupOptions.useNativeScrolling]
    
     */
    get useNativeScrolling(): boolean;
    set useNativeScrolling(value: boolean);
    /**
     * [descr:dxLookupOptions.usePopover]
    
     */
    get usePopover(): boolean;
    set usePopover(value: boolean);
    /**
     * [descr:EditorOptions.validationError]
    
     */
    get validationError(): any | null;
    set validationError(value: any | null);
    /**
     * [descr:EditorOptions.validationErrors]
    
     */
    get validationErrors(): Array<any> | null;
    set validationErrors(value: Array<any> | null);
    /**
     * [descr:EditorOptions.validationMessageMode]
    
     */
    get validationMessageMode(): ValidationMessageMode;
    set validationMessageMode(value: ValidationMessageMode);
    /**
     * [descr:dxDropDownEditorOptions.validationMessagePosition]
    
     */
    get validationMessagePosition(): Mode | Position;
    set validationMessagePosition(value: Mode | Position);
    /**
     * [descr:EditorOptions.validationStatus]
    
     */
    get validationStatus(): ValidationStatus;
    set validationStatus(value: ValidationStatus);
    /**
     * [descr:dxDropDownListOptions.value]
    
     */
    get value(): any;
    set value(value: any);
    /**
     * [descr:dxDropDownListOptions.valueChangeEvent]
    
     */
    get valueChangeEvent(): string;
    set valueChangeEvent(value: string);
    /**
     * [descr:DataExpressionMixinOptions.valueExpr]
    
     */
    get valueExpr(): ((item: any) => string | number | boolean) | string;
    set valueExpr(value: ((item: any) => string | number | boolean) | string);
    /**
     * [descr:WidgetOptions.visible]
    
     */
    get visible(): boolean;
    set visible(value: boolean);
    /**
     * [descr:DOMComponentOptions.width]
    
     */
    get width(): number | string | undefined;
    set width(value: number | string | undefined);
    /**
     * [descr:dxDropDownListOptions.wrapItemText]
    
     */
    get wrapItemText(): boolean;
    set wrapItemText(value: boolean);
    /**
    
     * [descr:dxLookupOptions.onClosed]
    
    
     */
    onClosed: EventEmitter<ClosedEvent>;
    /**
    
     * [descr:dxLookupOptions.onContentReady]
    
    
     */
    onContentReady: EventEmitter<ContentReadyEvent>;
    /**
    
     * [descr:dxLookupOptions.onDisposing]
    
    
     */
    onDisposing: EventEmitter<DisposingEvent>;
    /**
    
     * [descr:dxLookupOptions.onInitialized]
    
    
     */
    onInitialized: EventEmitter<InitializedEvent>;
    /**
    
     * [descr:dxLookupOptions.onItemClick]
    
    
     */
    onItemClick: EventEmitter<ItemClickEvent>;
    /**
    
     * [descr:dxLookupOptions.onOpened]
    
    
     */
    onOpened: EventEmitter<OpenedEvent>;
    /**
    
     * [descr:dxLookupOptions.onOptionChanged]
    
    
     */
    onOptionChanged: EventEmitter<OptionChangedEvent>;
    /**
    
     * [descr:dxLookupOptions.onPageLoading]
    
    
     */
    onPageLoading: EventEmitter<PageLoadingEvent>;
    /**
    
     * [descr:dxLookupOptions.onPullRefresh]
    
    
     */
    onPullRefresh: EventEmitter<PullRefreshEvent>;
    /**
    
     * [descr:dxLookupOptions.onScroll]
    
    
     */
    onScroll: EventEmitter<ScrollEvent>;
    /**
    
     * [descr:dxLookupOptions.onSelectionChanged]
    
    
     */
    onSelectionChanged: EventEmitter<SelectionChangedEvent>;
    /**
    
     * [descr:dxLookupOptions.onValueChanged]
    
    
     */
    onValueChanged: EventEmitter<ValueChangedEvent>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    accessKeyChange: EventEmitter<string | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    activeStateEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    applyButtonTextChange: EventEmitter<string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    applyValueModeChange: EventEmitter<ApplyValueMode>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    cancelButtonTextChange: EventEmitter<string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    cleanSearchOnOpeningChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    clearButtonTextChange: EventEmitter<string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    dataSourceChange: EventEmitter<Array<any | CollectionWidgetItem> | DataSource | DataSourceOptions | null | Store | string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    deferRenderingChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    disabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    displayExprChange: EventEmitter<((item: any) => string) | string | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    displayValueChange: EventEmitter<string | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    dropDownCenteredChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    dropDownOptionsChange: EventEmitter<dxPopoverOptions<any>>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    elementAttrChange: EventEmitter<Record<string, any>>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    fieldTemplateChange: EventEmitter<any>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    focusStateEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    groupedChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    groupTemplateChange: EventEmitter<any>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    heightChange: EventEmitter<number | string | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    hintChange: EventEmitter<string | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    hoverStateEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    inputAttrChange: EventEmitter<any>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    isDirtyChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    isValidChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    itemsChange: EventEmitter<Array<any | CollectionWidgetItem>>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    itemTemplateChange: EventEmitter<any>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    labelChange: EventEmitter<string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    labelModeChange: EventEmitter<LabelMode>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    minSearchLengthChange: EventEmitter<number>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    nameChange: EventEmitter<string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    nextButtonTextChange: EventEmitter<string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    noDataTextChange: EventEmitter<string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    openedChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    pageLoadingTextChange: EventEmitter<string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    pageLoadModeChange: EventEmitter<PageLoadMode>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    placeholderChange: EventEmitter<string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    pulledDownTextChange: EventEmitter<string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    pullingDownTextChange: EventEmitter<string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    pullRefreshEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    refreshingTextChange: EventEmitter<string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    rtlEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    searchEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    searchExprChange: EventEmitter<Array<Function | string> | Function | string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    searchModeChange: EventEmitter<SimplifiedSearchMode>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    searchPlaceholderChange: EventEmitter<string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    searchStartEventChange: EventEmitter<string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    searchTimeoutChange: EventEmitter<number>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    selectedItemChange: EventEmitter<any | null>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    showCancelButtonChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    showClearButtonChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    showDataBeforeSearchChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    stylingModeChange: EventEmitter<EditorStyle>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    tabIndexChange: EventEmitter<number>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    textChange: EventEmitter<string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    useItemTextAsTitleChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    useNativeScrollingChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    usePopoverChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    validationErrorChange: EventEmitter<any | null>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    validationErrorsChange: EventEmitter<Array<any> | null>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    validationMessageModeChange: EventEmitter<ValidationMessageMode>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    validationMessagePositionChange: EventEmitter<Mode | Position>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    validationStatusChange: EventEmitter<ValidationStatus>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    valueChange: EventEmitter<any>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    valueChangeEventChange: EventEmitter<string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    valueExprChange: EventEmitter<((item: any) => string | number | boolean) | string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    visibleChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    widthChange: EventEmitter<number | string | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    wrapItemTextChange: EventEmitter<boolean>;
    /**
    
     * [descr:undefined]
    
    
     */
    onBlur: EventEmitter<any>;
    change(_: any): void;
    touched: (_: any) => void;
    constructor(elementRef: ElementRef, ngZone: NgZone, templateHost: DxTemplateHost, _watcherHelper: WatcherHelper, _idh: IterableDifferHelper, optionHost: NestedOptionHost, transferState: TransferState, platformId: any);
    protected _createInstance(element: any, options: any): DxLookup;
    writeValue(value: any): void;
    setDisabledState(isDisabled: boolean): void;
    registerOnChange(fn: (_: any) => void): void;
    registerOnTouched(fn: () => void): void;
    _createWidget(element: any): void;
    ngOnDestroy(): void;
    ngOnChanges(changes: SimpleChanges): void;
    setupChanges(prop: string, changes: SimpleChanges): void;
    ngDoCheck(): void;
    _setOption(name: string, value: any): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxLookupComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxLookupComponent, "dx-lookup", never, { "accessKey": { "alias": "accessKey"; "required": false; }; "activeStateEnabled": { "alias": "activeStateEnabled"; "required": false; }; "applyButtonText": { "alias": "applyButtonText"; "required": false; }; "applyValueMode": { "alias": "applyValueMode"; "required": false; }; "cancelButtonText": { "alias": "cancelButtonText"; "required": false; }; "cleanSearchOnOpening": { "alias": "cleanSearchOnOpening"; "required": false; }; "clearButtonText": { "alias": "clearButtonText"; "required": false; }; "dataSource": { "alias": "dataSource"; "required": false; }; "deferRendering": { "alias": "deferRendering"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "displayExpr": { "alias": "displayExpr"; "required": false; }; "displayValue": { "alias": "displayValue"; "required": false; }; "dropDownCentered": { "alias": "dropDownCentered"; "required": false; }; "dropDownOptions": { "alias": "dropDownOptions"; "required": false; }; "elementAttr": { "alias": "elementAttr"; "required": false; }; "fieldTemplate": { "alias": "fieldTemplate"; "required": false; }; "focusStateEnabled": { "alias": "focusStateEnabled"; "required": false; }; "grouped": { "alias": "grouped"; "required": false; }; "groupTemplate": { "alias": "groupTemplate"; "required": false; }; "height": { "alias": "height"; "required": false; }; "hint": { "alias": "hint"; "required": false; }; "hoverStateEnabled": { "alias": "hoverStateEnabled"; "required": false; }; "inputAttr": { "alias": "inputAttr"; "required": false; }; "isDirty": { "alias": "isDirty"; "required": false; }; "isValid": { "alias": "isValid"; "required": false; }; "items": { "alias": "items"; "required": false; }; "itemTemplate": { "alias": "itemTemplate"; "required": false; }; "label": { "alias": "label"; "required": false; }; "labelMode": { "alias": "labelMode"; "required": false; }; "minSearchLength": { "alias": "minSearchLength"; "required": false; }; "name": { "alias": "name"; "required": false; }; "nextButtonText": { "alias": "nextButtonText"; "required": false; }; "noDataText": { "alias": "noDataText"; "required": false; }; "opened": { "alias": "opened"; "required": false; }; "pageLoadingText": { "alias": "pageLoadingText"; "required": false; }; "pageLoadMode": { "alias": "pageLoadMode"; "required": false; }; "placeholder": { "alias": "placeholder"; "required": false; }; "pulledDownText": { "alias": "pulledDownText"; "required": false; }; "pullingDownText": { "alias": "pullingDownText"; "required": false; }; "pullRefreshEnabled": { "alias": "pullRefreshEnabled"; "required": false; }; "refreshingText": { "alias": "refreshingText"; "required": false; }; "rtlEnabled": { "alias": "rtlEnabled"; "required": false; }; "searchEnabled": { "alias": "searchEnabled"; "required": false; }; "searchExpr": { "alias": "searchExpr"; "required": false; }; "searchMode": { "alias": "searchMode"; "required": false; }; "searchPlaceholder": { "alias": "searchPlaceholder"; "required": false; }; "searchStartEvent": { "alias": "searchStartEvent"; "required": false; }; "searchTimeout": { "alias": "searchTimeout"; "required": false; }; "selectedItem": { "alias": "selectedItem"; "required": false; }; "showCancelButton": { "alias": "showCancelButton"; "required": false; }; "showClearButton": { "alias": "showClearButton"; "required": false; }; "showDataBeforeSearch": { "alias": "showDataBeforeSearch"; "required": false; }; "stylingMode": { "alias": "stylingMode"; "required": false; }; "tabIndex": { "alias": "tabIndex"; "required": false; }; "text": { "alias": "text"; "required": false; }; "useItemTextAsTitle": { "alias": "useItemTextAsTitle"; "required": false; }; "useNativeScrolling": { "alias": "useNativeScrolling"; "required": false; }; "usePopover": { "alias": "usePopover"; "required": false; }; "validationError": { "alias": "validationError"; "required": false; }; "validationErrors": { "alias": "validationErrors"; "required": false; }; "validationMessageMode": { "alias": "validationMessageMode"; "required": false; }; "validationMessagePosition": { "alias": "validationMessagePosition"; "required": false; }; "validationStatus": { "alias": "validationStatus"; "required": false; }; "value": { "alias": "value"; "required": false; }; "valueChangeEvent": { "alias": "valueChangeEvent"; "required": false; }; "valueExpr": { "alias": "valueExpr"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; "wrapItemText": { "alias": "wrapItemText"; "required": false; }; }, { "onClosed": "onClosed"; "onContentReady": "onContentReady"; "onDisposing": "onDisposing"; "onInitialized": "onInitialized"; "onItemClick": "onItemClick"; "onOpened": "onOpened"; "onOptionChanged": "onOptionChanged"; "onPageLoading": "onPageLoading"; "onPullRefresh": "onPullRefresh"; "onScroll": "onScroll"; "onSelectionChanged": "onSelectionChanged"; "onValueChanged": "onValueChanged"; "accessKeyChange": "accessKeyChange"; "activeStateEnabledChange": "activeStateEnabledChange"; "applyButtonTextChange": "applyButtonTextChange"; "applyValueModeChange": "applyValueModeChange"; "cancelButtonTextChange": "cancelButtonTextChange"; "cleanSearchOnOpeningChange": "cleanSearchOnOpeningChange"; "clearButtonTextChange": "clearButtonTextChange"; "dataSourceChange": "dataSourceChange"; "deferRenderingChange": "deferRenderingChange"; "disabledChange": "disabledChange"; "displayExprChange": "displayExprChange"; "displayValueChange": "displayValueChange"; "dropDownCenteredChange": "dropDownCenteredChange"; "dropDownOptionsChange": "dropDownOptionsChange"; "elementAttrChange": "elementAttrChange"; "fieldTemplateChange": "fieldTemplateChange"; "focusStateEnabledChange": "focusStateEnabledChange"; "groupedChange": "groupedChange"; "groupTemplateChange": "groupTemplateChange"; "heightChange": "heightChange"; "hintChange": "hintChange"; "hoverStateEnabledChange": "hoverStateEnabledChange"; "inputAttrChange": "inputAttrChange"; "isDirtyChange": "isDirtyChange"; "isValidChange": "isValidChange"; "itemsChange": "itemsChange"; "itemTemplateChange": "itemTemplateChange"; "labelChange": "labelChange"; "labelModeChange": "labelModeChange"; "minSearchLengthChange": "minSearchLengthChange"; "nameChange": "nameChange"; "nextButtonTextChange": "nextButtonTextChange"; "noDataTextChange": "noDataTextChange"; "openedChange": "openedChange"; "pageLoadingTextChange": "pageLoadingTextChange"; "pageLoadModeChange": "pageLoadModeChange"; "placeholderChange": "placeholderChange"; "pulledDownTextChange": "pulledDownTextChange"; "pullingDownTextChange": "pullingDownTextChange"; "pullRefreshEnabledChange": "pullRefreshEnabledChange"; "refreshingTextChange": "refreshingTextChange"; "rtlEnabledChange": "rtlEnabledChange"; "searchEnabledChange": "searchEnabledChange"; "searchExprChange": "searchExprChange"; "searchModeChange": "searchModeChange"; "searchPlaceholderChange": "searchPlaceholderChange"; "searchStartEventChange": "searchStartEventChange"; "searchTimeoutChange": "searchTimeoutChange"; "selectedItemChange": "selectedItemChange"; "showCancelButtonChange": "showCancelButtonChange"; "showClearButtonChange": "showClearButtonChange"; "showDataBeforeSearchChange": "showDataBeforeSearchChange"; "stylingModeChange": "stylingModeChange"; "tabIndexChange": "tabIndexChange"; "textChange": "textChange"; "useItemTextAsTitleChange": "useItemTextAsTitleChange"; "useNativeScrollingChange": "useNativeScrollingChange"; "usePopoverChange": "usePopoverChange"; "validationErrorChange": "validationErrorChange"; "validationErrorsChange": "validationErrorsChange"; "validationMessageModeChange": "validationMessageModeChange"; "validationMessagePositionChange": "validationMessagePositionChange"; "validationStatusChange": "validationStatusChange"; "valueChange": "valueChange"; "valueChangeEventChange": "valueChangeEventChange"; "valueExprChange": "valueExprChange"; "visibleChange": "visibleChange"; "widthChange": "widthChange"; "wrapItemTextChange": "wrapItemTextChange"; "onBlur": "onBlur"; }, ["_itemsContentChildren", "_toolbarItemsContentChildren"], never, true, never>;
}
declare class DxLookupModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxLookupModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxLookupModule, never, [typeof DxLookupComponent, typeof i1.DxoDropDownOptionsModule, typeof i1.DxoAnimationModule, typeof i1.DxoHideModule, typeof i1.DxoFromModule, typeof i1.DxoPositionModule, typeof i1.DxoAtModule, typeof i1.DxoBoundaryOffsetModule, typeof i1.DxoCollisionModule, typeof i1.DxoMyModule, typeof i1.DxoOffsetModule, typeof i1.DxoToModule, typeof i1.DxoShowModule, typeof i1.DxoHideEventModule, typeof i1.DxoShowEventModule, typeof i1.DxiItemModule, typeof i2.DxoLookupAnimationModule, typeof i2.DxoLookupAtModule, typeof i2.DxoLookupBoundaryOffsetModule, typeof i2.DxoLookupCollisionModule, typeof i2.DxoLookupDropDownOptionsModule, typeof i2.DxoLookupFromModule, typeof i2.DxoLookupHideModule, typeof i2.DxoLookupHideEventModule, typeof i2.DxiLookupItemModule, typeof i2.DxoLookupMyModule, typeof i2.DxoLookupOffsetModule, typeof i2.DxoLookupPositionModule, typeof i2.DxoLookupShowModule, typeof i2.DxoLookupShowEventModule, typeof i2.DxoLookupToModule, typeof i2.DxiLookupToolbarItemModule, typeof i3.DxIntegrationModule, typeof i3.DxTemplateModule], [typeof DxLookupComponent, typeof i1.DxoDropDownOptionsModule, typeof i1.DxoAnimationModule, typeof i1.DxoHideModule, typeof i1.DxoFromModule, typeof i1.DxoPositionModule, typeof i1.DxoAtModule, typeof i1.DxoBoundaryOffsetModule, typeof i1.DxoCollisionModule, typeof i1.DxoMyModule, typeof i1.DxoOffsetModule, typeof i1.DxoToModule, typeof i1.DxoShowModule, typeof i1.DxoHideEventModule, typeof i1.DxoShowEventModule, typeof i1.DxiItemModule, typeof i2.DxoLookupAnimationModule, typeof i2.DxoLookupAtModule, typeof i2.DxoLookupBoundaryOffsetModule, typeof i2.DxoLookupCollisionModule, typeof i2.DxoLookupDropDownOptionsModule, typeof i2.DxoLookupFromModule, typeof i2.DxoLookupHideModule, typeof i2.DxoLookupHideEventModule, typeof i2.DxiLookupItemModule, typeof i2.DxoLookupMyModule, typeof i2.DxoLookupOffsetModule, typeof i2.DxoLookupPositionModule, typeof i2.DxoLookupShowModule, typeof i2.DxoLookupShowEventModule, typeof i2.DxoLookupToModule, typeof i2.DxiLookupToolbarItemModule, typeof i3.DxTemplateModule]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxLookupModule>;
}

export { DxLookupComponent, DxLookupModule };
//# sourceMappingURL=index.d.ts.map
