import * as i0 from '@angular/core';
import { OnDestroy, OnInit, AfterViewInit, Renderer2, ElementRef, QueryList, EventEmitter } from '@angular/core';
import { NestedOption, NestedOptionHost, CollectionNestedOption, IDxTemplateHost, DxTemplateHost, DxTemplateDirective } from 'devextreme-angular/core';
import dxScheduler, { AppointmentFormProperties, AppointmentFormIconsShowMode, SchedulerPredefinedToolbarItem, DateNavigatorItemProperties, SchedulerPredefinedDateNavigatorItem, dxSchedulerToolbarItem, AllDayPanelMode, CellAppointmentsLimit, dxSchedulerScrolling, SnapToCellsMode, ViewType } from 'devextreme/ui/scheduler';
import dxSortable from 'devextreme/ui/sortable';
import dxDraggable from 'devextreme/ui/draggable';
import { event } from 'devextreme/events/events.types';
import * as CommonTypes from 'devextreme/common';
import { ValidationRuleType, HorizontalAlignment, VerticalAlignment, ButtonStyle, ButtonType, ComparisonOperator, Mode, ToolbarItemLocation, ToolbarItemComponent, SingleMultipleOrNone, ScrollMode, TabsIconPosition, TabsStyle, Position, DayOfWeek, Orientation } from 'devextreme/common';
import { dxButtonOptions, ClickEvent, ContentReadyEvent, DisposingEvent, InitializedEvent, OptionChangedEvent } from 'devextreme/ui/button';
import { FormItemType, FormPredefinedButtonItem, dxFormSimpleItem, dxFormGroupItem, dxFormTabbedItem, dxFormEmptyItem, dxFormButtonItem, LabelLocation, FormLabelMode, ContentReadyEvent as ContentReadyEvent$1, DisposingEvent as DisposingEvent$1, EditorEnterKeyEvent, FieldDataChangedEvent, InitializedEvent as InitializedEvent$1, OptionChangedEvent as OptionChangedEvent$1, SmartPastedEvent, SmartPastingEvent, FormItemComponent } from 'devextreme/ui/form';
import { AIIntegration } from 'devextreme/common/ai-integration';
import { dxTabPanelOptions, dxTabPanelItem, ContentReadyEvent as ContentReadyEvent$3, DisposingEvent as DisposingEvent$3, InitializedEvent as InitializedEvent$3, ItemClickEvent as ItemClickEvent$1, ItemContextMenuEvent, ItemHoldEvent, ItemRenderedEvent, OptionChangedEvent as OptionChangedEvent$3, SelectionChangedEvent as SelectionChangedEvent$1, SelectionChangingEvent, TitleClickEvent, TitleHoldEvent, TitleRenderedEvent } from 'devextreme/ui/tab_panel';
import { LocateInMenuMode, ShowTextMode } from 'devextreme/ui/toolbar';
import { dxButtonGroupItem, ContentReadyEvent as ContentReadyEvent$2, DisposingEvent as DisposingEvent$2, InitializedEvent as InitializedEvent$2, ItemClickEvent, OptionChangedEvent as OptionChangedEvent$2, SelectionChangedEvent } from 'devextreme/ui/button_group';
import DataSource, { DataSourceOptions } from 'devextreme/data/data_source';
import { Store } from 'devextreme/data/store';

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoSchedulerAIOptionsComponent extends NestedOption implements OnDestroy, OnInit {
    get disabled(): boolean;
    set disabled(value: boolean);
    get instruction(): string | undefined;
    set instruction(value: string | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoSchedulerAIOptionsComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoSchedulerAIOptionsComponent, "dxo-scheduler-ai-options", never, { "disabled": { "alias": "disabled"; "required": false; }; "instruction": { "alias": "instruction"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoSchedulerAIOptionsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoSchedulerAIOptionsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoSchedulerAIOptionsModule, never, [typeof DxoSchedulerAIOptionsComponent], [typeof DxoSchedulerAIOptionsComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoSchedulerAIOptionsModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoSchedulerAppointmentDraggingComponent extends NestedOption implements OnDestroy, OnInit {
    get autoScroll(): boolean;
    set autoScroll(value: boolean);
    get data(): any | undefined;
    set data(value: any | undefined);
    get group(): string | undefined;
    set group(value: string | undefined);
    get onAdd(): ((e: {
        component: dxScheduler;
        event: event;
        fromComponent: dxSortable | dxDraggable;
        fromData: any;
        itemData: any;
        itemElement: any;
        toComponent: dxSortable | dxDraggable;
        toData: any;
    }) => void);
    set onAdd(value: ((e: {
        component: dxScheduler;
        event: event;
        fromComponent: dxSortable | dxDraggable;
        fromData: any;
        itemData: any;
        itemElement: any;
        toComponent: dxSortable | dxDraggable;
        toData: any;
    }) => void));
    get onDragEnd(): ((e: {
        cancel: boolean;
        component: dxScheduler;
        event: event;
        fromComponent: dxSortable | dxDraggable;
        fromData: any;
        itemData: any;
        itemElement: any;
        toComponent: dxSortable | dxDraggable;
        toData: any;
        toItemData: any;
    }) => void);
    set onDragEnd(value: ((e: {
        cancel: boolean;
        component: dxScheduler;
        event: event;
        fromComponent: dxSortable | dxDraggable;
        fromData: any;
        itemData: any;
        itemElement: any;
        toComponent: dxSortable | dxDraggable;
        toData: any;
        toItemData: any;
    }) => void));
    get onDragMove(): ((e: {
        cancel: boolean;
        component: dxScheduler;
        event: event;
        fromComponent: dxSortable | dxDraggable;
        fromData: any;
        itemData: any;
        itemElement: any;
        toComponent: dxSortable | dxDraggable;
        toData: any;
    }) => void);
    set onDragMove(value: ((e: {
        cancel: boolean;
        component: dxScheduler;
        event: event;
        fromComponent: dxSortable | dxDraggable;
        fromData: any;
        itemData: any;
        itemElement: any;
        toComponent: dxSortable | dxDraggable;
        toData: any;
    }) => void));
    get onDragStart(): ((e: {
        cancel: boolean;
        component: dxScheduler;
        event: event;
        fromData: any;
        itemData: any;
        itemElement: any;
    }) => void);
    set onDragStart(value: ((e: {
        cancel: boolean;
        component: dxScheduler;
        event: event;
        fromData: any;
        itemData: any;
        itemElement: any;
    }) => void));
    get onRemove(): ((e: {
        component: dxScheduler;
        event: event;
        fromComponent: dxSortable | dxDraggable;
        fromData: any;
        itemData: any;
        itemElement: any;
        toComponent: dxSortable | dxDraggable;
    }) => void);
    set onRemove(value: ((e: {
        component: dxScheduler;
        event: event;
        fromComponent: dxSortable | dxDraggable;
        fromData: any;
        itemData: any;
        itemElement: any;
        toComponent: dxSortable | dxDraggable;
    }) => void));
    get scrollSensitivity(): number;
    set scrollSensitivity(value: number);
    get scrollSpeed(): number;
    set scrollSpeed(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoSchedulerAppointmentDraggingComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoSchedulerAppointmentDraggingComponent, "dxo-scheduler-appointment-dragging", never, { "autoScroll": { "alias": "autoScroll"; "required": false; }; "data": { "alias": "data"; "required": false; }; "group": { "alias": "group"; "required": false; }; "onAdd": { "alias": "onAdd"; "required": false; }; "onDragEnd": { "alias": "onDragEnd"; "required": false; }; "onDragMove": { "alias": "onDragMove"; "required": false; }; "onDragStart": { "alias": "onDragStart"; "required": false; }; "onRemove": { "alias": "onRemove"; "required": false; }; "scrollSensitivity": { "alias": "scrollSensitivity"; "required": false; }; "scrollSpeed": { "alias": "scrollSpeed"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoSchedulerAppointmentDraggingModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoSchedulerAppointmentDraggingModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoSchedulerAppointmentDraggingModule, never, [typeof DxoSchedulerAppointmentDraggingComponent], [typeof DxoSchedulerAppointmentDraggingComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoSchedulerAppointmentDraggingModule>;
}

declare class DxiSchedulerAsyncRuleComponent extends CollectionNestedOption {
    get ignoreEmptyValue(): boolean;
    set ignoreEmptyValue(value: boolean);
    get message(): string;
    set message(value: string);
    get reevaluate(): boolean;
    set reevaluate(value: boolean);
    get type(): ValidationRuleType;
    set type(value: ValidationRuleType);
    get validationCallback(): ((options: {
        column: Record<string, any>;
        data: Record<string, any>;
        formItem: Record<string, any>;
        rule: Record<string, any>;
        validator: Record<string, any>;
        value: any;
    }) => any);
    set validationCallback(value: ((options: {
        column: Record<string, any>;
        data: Record<string, any>;
        formItem: Record<string, any>;
        rule: Record<string, any>;
        validator: Record<string, any>;
        value: any;
    }) => any));
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiSchedulerAsyncRuleComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiSchedulerAsyncRuleComponent, "dxi-scheduler-async-rule", never, { "ignoreEmptyValue": { "alias": "ignoreEmptyValue"; "required": false; }; "message": { "alias": "message"; "required": false; }; "reevaluate": { "alias": "reevaluate"; "required": false; }; "type": { "alias": "type"; "required": false; }; "validationCallback": { "alias": "validationCallback"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxiSchedulerAsyncRuleModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiSchedulerAsyncRuleModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiSchedulerAsyncRuleModule, never, [typeof DxiSchedulerAsyncRuleComponent], [typeof DxiSchedulerAsyncRuleComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiSchedulerAsyncRuleModule>;
}

declare class DxiSchedulerButtonItemComponent extends CollectionNestedOption {
    get buttonOptions(): dxButtonOptions | undefined;
    set buttonOptions(value: dxButtonOptions | undefined);
    get colSpan(): number | undefined;
    set colSpan(value: number | undefined);
    get cssClass(): string | undefined;
    set cssClass(value: string | undefined);
    get horizontalAlignment(): HorizontalAlignment;
    set horizontalAlignment(value: HorizontalAlignment);
    get itemType(): FormItemType;
    set itemType(value: FormItemType);
    get name(): FormPredefinedButtonItem | string | undefined;
    set name(value: FormPredefinedButtonItem | string | undefined);
    get verticalAlignment(): VerticalAlignment;
    set verticalAlignment(value: VerticalAlignment);
    get visible(): boolean;
    set visible(value: boolean);
    get visibleIndex(): number | undefined;
    set visibleIndex(value: number | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiSchedulerButtonItemComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiSchedulerButtonItemComponent, "dxi-scheduler-button-item", never, { "buttonOptions": { "alias": "buttonOptions"; "required": false; }; "colSpan": { "alias": "colSpan"; "required": false; }; "cssClass": { "alias": "cssClass"; "required": false; }; "horizontalAlignment": { "alias": "horizontalAlignment"; "required": false; }; "itemType": { "alias": "itemType"; "required": false; }; "name": { "alias": "name"; "required": false; }; "verticalAlignment": { "alias": "verticalAlignment"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "visibleIndex": { "alias": "visibleIndex"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxiSchedulerButtonItemModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiSchedulerButtonItemModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiSchedulerButtonItemModule, never, [typeof DxiSchedulerButtonItemComponent], [typeof DxiSchedulerButtonItemComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiSchedulerButtonItemModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoSchedulerButtonOptionsComponent extends NestedOption implements AfterViewInit, OnDestroy, OnInit, IDxTemplateHost {
    private renderer;
    private document;
    private element;
    get accessKey(): string | undefined;
    set accessKey(value: string | undefined);
    get activeStateEnabled(): boolean;
    set activeStateEnabled(value: boolean);
    get disabled(): boolean;
    set disabled(value: boolean);
    get elementAttr(): Record<string, any>;
    set elementAttr(value: Record<string, any>);
    get focusStateEnabled(): boolean;
    set focusStateEnabled(value: boolean);
    get height(): number | string | undefined;
    set height(value: number | string | undefined);
    get hint(): string | undefined;
    set hint(value: string | undefined);
    get hoverStateEnabled(): boolean;
    set hoverStateEnabled(value: boolean);
    get icon(): string;
    set icon(value: string);
    get onClick(): ((e: ClickEvent) => void) | undefined;
    set onClick(value: ((e: ClickEvent) => void) | undefined);
    get onContentReady(): ((e: ContentReadyEvent) => void);
    set onContentReady(value: ((e: ContentReadyEvent) => void));
    get onDisposing(): ((e: DisposingEvent) => void);
    set onDisposing(value: ((e: DisposingEvent) => void));
    get onInitialized(): ((e: InitializedEvent) => void);
    set onInitialized(value: ((e: InitializedEvent) => void));
    get onOptionChanged(): ((e: OptionChangedEvent) => void);
    set onOptionChanged(value: ((e: OptionChangedEvent) => void));
    get rtlEnabled(): boolean;
    set rtlEnabled(value: boolean);
    get stylingMode(): ButtonStyle;
    set stylingMode(value: ButtonStyle);
    get tabIndex(): number;
    set tabIndex(value: number);
    get template(): any;
    set template(value: any);
    get text(): string;
    set text(value: string);
    get type(): ButtonType | string;
    set type(value: ButtonType | string);
    get useSubmitBehavior(): boolean;
    set useSubmitBehavior(value: boolean);
    get validationGroup(): string | undefined;
    set validationGroup(value: string | undefined);
    get visible(): boolean;
    set visible(value: boolean);
    get width(): number | string | undefined;
    set width(value: number | string | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost, renderer: Renderer2, document: any, templateHost: DxTemplateHost, element: ElementRef);
    setTemplate(template: DxTemplateDirective): void;
    ngAfterViewInit(): void;
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoSchedulerButtonOptionsComponent, [{ host: true; skipSelf: true; }, { host: true; }, null, null, { host: true; }, null]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoSchedulerButtonOptionsComponent, "dxo-scheduler-button-options", never, { "accessKey": { "alias": "accessKey"; "required": false; }; "activeStateEnabled": { "alias": "activeStateEnabled"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "elementAttr": { "alias": "elementAttr"; "required": false; }; "focusStateEnabled": { "alias": "focusStateEnabled"; "required": false; }; "height": { "alias": "height"; "required": false; }; "hint": { "alias": "hint"; "required": false; }; "hoverStateEnabled": { "alias": "hoverStateEnabled"; "required": false; }; "icon": { "alias": "icon"; "required": false; }; "onClick": { "alias": "onClick"; "required": false; }; "onContentReady": { "alias": "onContentReady"; "required": false; }; "onDisposing": { "alias": "onDisposing"; "required": false; }; "onInitialized": { "alias": "onInitialized"; "required": false; }; "onOptionChanged": { "alias": "onOptionChanged"; "required": false; }; "rtlEnabled": { "alias": "rtlEnabled"; "required": false; }; "stylingMode": { "alias": "stylingMode"; "required": false; }; "tabIndex": { "alias": "tabIndex"; "required": false; }; "template": { "alias": "template"; "required": false; }; "text": { "alias": "text"; "required": false; }; "type": { "alias": "type"; "required": false; }; "useSubmitBehavior": { "alias": "useSubmitBehavior"; "required": false; }; "validationGroup": { "alias": "validationGroup"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, ["*"], true, never>;
}
declare class DxoSchedulerButtonOptionsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoSchedulerButtonOptionsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoSchedulerButtonOptionsModule, never, [typeof DxoSchedulerButtonOptionsComponent], [typeof DxoSchedulerButtonOptionsComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoSchedulerButtonOptionsModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoSchedulerColCountByScreenComponent extends NestedOption implements OnDestroy, OnInit {
    get lg(): number | undefined;
    set lg(value: number | undefined);
    get md(): number | undefined;
    set md(value: number | undefined);
    get sm(): number | undefined;
    set sm(value: number | undefined);
    get xs(): number | undefined;
    set xs(value: number | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoSchedulerColCountByScreenComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoSchedulerColCountByScreenComponent, "dxo-scheduler-col-count-by-screen", never, { "lg": { "alias": "lg"; "required": false; }; "md": { "alias": "md"; "required": false; }; "sm": { "alias": "sm"; "required": false; }; "xs": { "alias": "xs"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoSchedulerColCountByScreenModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoSchedulerColCountByScreenModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoSchedulerColCountByScreenModule, never, [typeof DxoSchedulerColCountByScreenComponent], [typeof DxoSchedulerColCountByScreenComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoSchedulerColCountByScreenModule>;
}

declare class DxiSchedulerCompareRuleComponent extends CollectionNestedOption {
    get comparisonTarget(): Function;
    set comparisonTarget(value: Function);
    get comparisonType(): ComparisonOperator;
    set comparisonType(value: ComparisonOperator);
    get ignoreEmptyValue(): boolean;
    set ignoreEmptyValue(value: boolean);
    get message(): string;
    set message(value: string);
    get type(): ValidationRuleType;
    set type(value: ValidationRuleType);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiSchedulerCompareRuleComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiSchedulerCompareRuleComponent, "dxi-scheduler-compare-rule", never, { "comparisonTarget": { "alias": "comparisonTarget"; "required": false; }; "comparisonType": { "alias": "comparisonType"; "required": false; }; "ignoreEmptyValue": { "alias": "ignoreEmptyValue"; "required": false; }; "message": { "alias": "message"; "required": false; }; "type": { "alias": "type"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxiSchedulerCompareRuleModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiSchedulerCompareRuleModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiSchedulerCompareRuleModule, never, [typeof DxiSchedulerCompareRuleComponent], [typeof DxiSchedulerCompareRuleComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiSchedulerCompareRuleModule>;
}

declare class DxiSchedulerCustomRuleComponent extends CollectionNestedOption {
    get ignoreEmptyValue(): boolean;
    set ignoreEmptyValue(value: boolean);
    get message(): string;
    set message(value: string);
    get reevaluate(): boolean;
    set reevaluate(value: boolean);
    get type(): ValidationRuleType;
    set type(value: ValidationRuleType);
    get validationCallback(): ((options: {
        column: Record<string, any>;
        data: Record<string, any>;
        formItem: Record<string, any>;
        rule: Record<string, any>;
        validator: Record<string, any>;
        value: any;
    }) => boolean);
    set validationCallback(value: ((options: {
        column: Record<string, any>;
        data: Record<string, any>;
        formItem: Record<string, any>;
        rule: Record<string, any>;
        validator: Record<string, any>;
        value: any;
    }) => boolean));
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiSchedulerCustomRuleComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiSchedulerCustomRuleComponent, "dxi-scheduler-custom-rule", never, { "ignoreEmptyValue": { "alias": "ignoreEmptyValue"; "required": false; }; "message": { "alias": "message"; "required": false; }; "reevaluate": { "alias": "reevaluate"; "required": false; }; "type": { "alias": "type"; "required": false; }; "validationCallback": { "alias": "validationCallback"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxiSchedulerCustomRuleModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiSchedulerCustomRuleModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiSchedulerCustomRuleModule, never, [typeof DxiSchedulerCustomRuleComponent], [typeof DxiSchedulerCustomRuleComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiSchedulerCustomRuleModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoSchedulerEditingComponent extends NestedOption implements OnDestroy, OnInit {
    get allowAdding(): boolean;
    set allowAdding(value: boolean);
    get allowDeleting(): boolean;
    set allowDeleting(value: boolean);
    get allowDragging(): boolean;
    set allowDragging(value: boolean);
    get allowResizing(): boolean;
    set allowResizing(value: boolean);
    get allowTimeZoneEditing(): boolean;
    set allowTimeZoneEditing(value: boolean);
    get allowUpdating(): boolean;
    set allowUpdating(value: boolean);
    get form(): AppointmentFormProperties;
    set form(value: AppointmentFormProperties);
    get popup(): Record<string, any>;
    set popup(value: Record<string, any>);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoSchedulerEditingComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoSchedulerEditingComponent, "dxo-scheduler-editing", never, { "allowAdding": { "alias": "allowAdding"; "required": false; }; "allowDeleting": { "alias": "allowDeleting"; "required": false; }; "allowDragging": { "alias": "allowDragging"; "required": false; }; "allowResizing": { "alias": "allowResizing"; "required": false; }; "allowTimeZoneEditing": { "alias": "allowTimeZoneEditing"; "required": false; }; "allowUpdating": { "alias": "allowUpdating"; "required": false; }; "form": { "alias": "form"; "required": false; }; "popup": { "alias": "popup"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoSchedulerEditingModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoSchedulerEditingModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoSchedulerEditingModule, never, [typeof DxoSchedulerEditingComponent], [typeof DxoSchedulerEditingComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoSchedulerEditingModule>;
}

declare class DxiSchedulerEmailRuleComponent extends CollectionNestedOption {
    get ignoreEmptyValue(): boolean;
    set ignoreEmptyValue(value: boolean);
    get message(): string;
    set message(value: string);
    get type(): ValidationRuleType;
    set type(value: ValidationRuleType);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiSchedulerEmailRuleComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiSchedulerEmailRuleComponent, "dxi-scheduler-email-rule", never, { "ignoreEmptyValue": { "alias": "ignoreEmptyValue"; "required": false; }; "message": { "alias": "message"; "required": false; }; "type": { "alias": "type"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxiSchedulerEmailRuleModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiSchedulerEmailRuleModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiSchedulerEmailRuleModule, never, [typeof DxiSchedulerEmailRuleComponent], [typeof DxiSchedulerEmailRuleComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiSchedulerEmailRuleModule>;
}

declare class DxiSchedulerEmptyItemComponent extends CollectionNestedOption {
    get colSpan(): number | undefined;
    set colSpan(value: number | undefined);
    get cssClass(): string | undefined;
    set cssClass(value: string | undefined);
    get itemType(): FormItemType;
    set itemType(value: FormItemType);
    get name(): string | undefined;
    set name(value: string | undefined);
    get visible(): boolean;
    set visible(value: boolean);
    get visibleIndex(): number | undefined;
    set visibleIndex(value: number | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiSchedulerEmptyItemComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiSchedulerEmptyItemComponent, "dxi-scheduler-empty-item", never, { "colSpan": { "alias": "colSpan"; "required": false; }; "cssClass": { "alias": "cssClass"; "required": false; }; "itemType": { "alias": "itemType"; "required": false; }; "name": { "alias": "name"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "visibleIndex": { "alias": "visibleIndex"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxiSchedulerEmptyItemModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiSchedulerEmptyItemModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiSchedulerEmptyItemModule, never, [typeof DxiSchedulerEmptyItemComponent], [typeof DxiSchedulerEmptyItemComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiSchedulerEmptyItemModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoSchedulerFormComponent extends NestedOption implements OnDestroy, OnInit {
    set _itemsContentChildren(value: QueryList<CollectionNestedOption>);
    get accessKey(): string | undefined;
    set accessKey(value: string | undefined);
    get activeStateEnabled(): boolean;
    set activeStateEnabled(value: boolean);
    get aiIntegration(): AIIntegration | undefined;
    set aiIntegration(value: AIIntegration | undefined);
    get alignItemLabels(): boolean;
    set alignItemLabels(value: boolean);
    get alignItemLabelsInAllGroups(): boolean;
    set alignItemLabelsInAllGroups(value: boolean);
    get colCount(): Mode | number;
    set colCount(value: Mode | number);
    get colCountByScreen(): {
        lg?: number | undefined;
        md?: number | undefined;
        sm?: number | undefined;
        xs?: number | undefined;
    };
    set colCountByScreen(value: {
        lg?: number | undefined;
        md?: number | undefined;
        sm?: number | undefined;
        xs?: number | undefined;
    });
    get customizeItem(): ((item: dxFormSimpleItem | dxFormGroupItem | dxFormTabbedItem | dxFormEmptyItem | dxFormButtonItem) => void);
    set customizeItem(value: ((item: dxFormSimpleItem | dxFormGroupItem | dxFormTabbedItem | dxFormEmptyItem | dxFormButtonItem) => void));
    get disabled(): boolean;
    set disabled(value: boolean);
    get elementAttr(): Record<string, any>;
    set elementAttr(value: Record<string, any>);
    get focusStateEnabled(): boolean;
    set focusStateEnabled(value: boolean);
    get formData(): any;
    set formData(value: any);
    get height(): number | string | undefined;
    set height(value: number | string | undefined);
    get hint(): string | undefined;
    set hint(value: string | undefined);
    get hoverStateEnabled(): boolean;
    set hoverStateEnabled(value: boolean);
    get iconsShowMode(): AppointmentFormIconsShowMode;
    set iconsShowMode(value: AppointmentFormIconsShowMode);
    get isDirty(): boolean;
    set isDirty(value: boolean);
    get items(): Array<dxFormButtonItem | dxFormEmptyItem | dxFormGroupItem | dxFormSimpleItem | dxFormTabbedItem>;
    set items(value: Array<dxFormButtonItem | dxFormEmptyItem | dxFormGroupItem | dxFormSimpleItem | dxFormTabbedItem>);
    get labelLocation(): LabelLocation;
    set labelLocation(value: LabelLocation);
    get labelMode(): FormLabelMode;
    set labelMode(value: FormLabelMode);
    get minColWidth(): number;
    set minColWidth(value: number);
    get onContentReady(): ((e: ContentReadyEvent$1) => void);
    set onContentReady(value: ((e: ContentReadyEvent$1) => void));
    get onDisposing(): ((e: DisposingEvent$1) => void);
    set onDisposing(value: ((e: DisposingEvent$1) => void));
    get onEditorEnterKey(): ((e: EditorEnterKeyEvent) => void) | undefined;
    set onEditorEnterKey(value: ((e: EditorEnterKeyEvent) => void) | undefined);
    get onFieldDataChanged(): ((e: FieldDataChangedEvent) => void) | undefined;
    set onFieldDataChanged(value: ((e: FieldDataChangedEvent) => void) | undefined);
    get onInitialized(): ((e: InitializedEvent$1) => void);
    set onInitialized(value: ((e: InitializedEvent$1) => void));
    get onOptionChanged(): ((e: OptionChangedEvent$1) => void);
    set onOptionChanged(value: ((e: OptionChangedEvent$1) => void));
    get onSmartPasted(): ((e: SmartPastedEvent) => void) | undefined;
    set onSmartPasted(value: ((e: SmartPastedEvent) => void) | undefined);
    get onSmartPasting(): ((e: SmartPastingEvent) => void) | undefined;
    set onSmartPasting(value: ((e: SmartPastingEvent) => void) | undefined);
    get optionalMark(): string;
    set optionalMark(value: string);
    get readOnly(): boolean;
    set readOnly(value: boolean);
    get requiredMark(): string;
    set requiredMark(value: string);
    get requiredMessage(): string;
    set requiredMessage(value: string);
    get rtlEnabled(): boolean;
    set rtlEnabled(value: boolean);
    get screenByWidth(): Function;
    set screenByWidth(value: Function);
    get scrollingEnabled(): boolean;
    set scrollingEnabled(value: boolean);
    get showColonAfterLabel(): boolean;
    set showColonAfterLabel(value: boolean);
    get showOptionalMark(): boolean;
    set showOptionalMark(value: boolean);
    get showRequiredMark(): boolean;
    set showRequiredMark(value: boolean);
    get showValidationSummary(): boolean;
    set showValidationSummary(value: boolean);
    get tabIndex(): number;
    set tabIndex(value: number);
    get validationGroup(): string | undefined;
    set validationGroup(value: string | undefined);
    get visible(): boolean;
    set visible(value: boolean);
    get width(): number | string | undefined;
    set width(value: number | string | undefined);
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    formDataChange: EventEmitter<any>;
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoSchedulerFormComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoSchedulerFormComponent, "dxo-scheduler-form", never, { "accessKey": { "alias": "accessKey"; "required": false; }; "activeStateEnabled": { "alias": "activeStateEnabled"; "required": false; }; "aiIntegration": { "alias": "aiIntegration"; "required": false; }; "alignItemLabels": { "alias": "alignItemLabels"; "required": false; }; "alignItemLabelsInAllGroups": { "alias": "alignItemLabelsInAllGroups"; "required": false; }; "colCount": { "alias": "colCount"; "required": false; }; "colCountByScreen": { "alias": "colCountByScreen"; "required": false; }; "customizeItem": { "alias": "customizeItem"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "elementAttr": { "alias": "elementAttr"; "required": false; }; "focusStateEnabled": { "alias": "focusStateEnabled"; "required": false; }; "formData": { "alias": "formData"; "required": false; }; "height": { "alias": "height"; "required": false; }; "hint": { "alias": "hint"; "required": false; }; "hoverStateEnabled": { "alias": "hoverStateEnabled"; "required": false; }; "iconsShowMode": { "alias": "iconsShowMode"; "required": false; }; "isDirty": { "alias": "isDirty"; "required": false; }; "items": { "alias": "items"; "required": false; }; "labelLocation": { "alias": "labelLocation"; "required": false; }; "labelMode": { "alias": "labelMode"; "required": false; }; "minColWidth": { "alias": "minColWidth"; "required": false; }; "onContentReady": { "alias": "onContentReady"; "required": false; }; "onDisposing": { "alias": "onDisposing"; "required": false; }; "onEditorEnterKey": { "alias": "onEditorEnterKey"; "required": false; }; "onFieldDataChanged": { "alias": "onFieldDataChanged"; "required": false; }; "onInitialized": { "alias": "onInitialized"; "required": false; }; "onOptionChanged": { "alias": "onOptionChanged"; "required": false; }; "onSmartPasted": { "alias": "onSmartPasted"; "required": false; }; "onSmartPasting": { "alias": "onSmartPasting"; "required": false; }; "optionalMark": { "alias": "optionalMark"; "required": false; }; "readOnly": { "alias": "readOnly"; "required": false; }; "requiredMark": { "alias": "requiredMark"; "required": false; }; "requiredMessage": { "alias": "requiredMessage"; "required": false; }; "rtlEnabled": { "alias": "rtlEnabled"; "required": false; }; "screenByWidth": { "alias": "screenByWidth"; "required": false; }; "scrollingEnabled": { "alias": "scrollingEnabled"; "required": false; }; "showColonAfterLabel": { "alias": "showColonAfterLabel"; "required": false; }; "showOptionalMark": { "alias": "showOptionalMark"; "required": false; }; "showRequiredMark": { "alias": "showRequiredMark"; "required": false; }; "showValidationSummary": { "alias": "showValidationSummary"; "required": false; }; "tabIndex": { "alias": "tabIndex"; "required": false; }; "validationGroup": { "alias": "validationGroup"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, { "formDataChange": "formDataChange"; }, ["_itemsContentChildren"], never, true, never>;
}
declare class DxoSchedulerFormModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoSchedulerFormModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoSchedulerFormModule, never, [typeof DxoSchedulerFormComponent], [typeof DxoSchedulerFormComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoSchedulerFormModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxiSchedulerGroupItemComponent extends CollectionNestedOption implements AfterViewInit, IDxTemplateHost {
    private renderer;
    private document;
    private element;
    set _itemsContentChildren(value: QueryList<CollectionNestedOption>);
    get alignItemLabels(): boolean;
    set alignItemLabels(value: boolean);
    get caption(): string | undefined;
    set caption(value: string | undefined);
    get captionTemplate(): any;
    set captionTemplate(value: any);
    get colCount(): number;
    set colCount(value: number);
    get colCountByScreen(): {
        lg?: number | undefined;
        md?: number | undefined;
        sm?: number | undefined;
        xs?: number | undefined;
    };
    set colCountByScreen(value: {
        lg?: number | undefined;
        md?: number | undefined;
        sm?: number | undefined;
        xs?: number | undefined;
    });
    get colSpan(): number | undefined;
    set colSpan(value: number | undefined);
    get cssClass(): string | undefined;
    set cssClass(value: string | undefined);
    get items(): Array<dxFormButtonItem | dxFormEmptyItem | dxFormGroupItem | dxFormSimpleItem | dxFormTabbedItem>;
    set items(value: Array<dxFormButtonItem | dxFormEmptyItem | dxFormGroupItem | dxFormSimpleItem | dxFormTabbedItem>);
    get itemType(): FormItemType;
    set itemType(value: FormItemType);
    get name(): string | undefined;
    set name(value: string | undefined);
    get template(): any;
    set template(value: any);
    get visible(): boolean;
    set visible(value: boolean);
    get visibleIndex(): number | undefined;
    set visibleIndex(value: number | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost, renderer: Renderer2, document: any, templateHost: DxTemplateHost, element: ElementRef);
    setTemplate(template: DxTemplateDirective): void;
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiSchedulerGroupItemComponent, [{ host: true; skipSelf: true; }, { host: true; }, null, null, { host: true; }, null]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiSchedulerGroupItemComponent, "dxi-scheduler-group-item", never, { "alignItemLabels": { "alias": "alignItemLabels"; "required": false; }; "caption": { "alias": "caption"; "required": false; }; "captionTemplate": { "alias": "captionTemplate"; "required": false; }; "colCount": { "alias": "colCount"; "required": false; }; "colCountByScreen": { "alias": "colCountByScreen"; "required": false; }; "colSpan": { "alias": "colSpan"; "required": false; }; "cssClass": { "alias": "cssClass"; "required": false; }; "items": { "alias": "items"; "required": false; }; "itemType": { "alias": "itemType"; "required": false; }; "name": { "alias": "name"; "required": false; }; "template": { "alias": "template"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "visibleIndex": { "alias": "visibleIndex"; "required": false; }; }, {}, ["_itemsContentChildren"], ["*"], true, never>;
}
declare class DxiSchedulerGroupItemModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiSchedulerGroupItemModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiSchedulerGroupItemModule, never, [typeof DxiSchedulerGroupItemComponent], [typeof DxiSchedulerGroupItemComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiSchedulerGroupItemModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxiSchedulerItemComponent extends CollectionNestedOption implements AfterViewInit, IDxTemplateHost {
    private renderer;
    private document;
    private element;
    set _validationRulesContentChildren(value: QueryList<CollectionNestedOption>);
    set _tabsContentChildren(value: QueryList<CollectionNestedOption>);
    set _itemsContentChildren(value: QueryList<CollectionNestedOption>);
    get badge(): string;
    set badge(value: string);
    get disabled(): boolean;
    set disabled(value: boolean);
    get html(): string;
    set html(value: string);
    get icon(): string;
    set icon(value: string);
    get tabTemplate(): any;
    set tabTemplate(value: any);
    get template(): any;
    set template(value: any);
    get text(): string;
    set text(value: string);
    get title(): string;
    set title(value: string);
    get visible(): boolean;
    set visible(value: boolean);
    get aiOptions(): {
        disabled?: boolean;
        instruction?: string | undefined;
    };
    set aiOptions(value: {
        disabled?: boolean;
        instruction?: string | undefined;
    });
    get colSpan(): number | undefined;
    set colSpan(value: number | undefined);
    get cssClass(): string | undefined;
    set cssClass(value: string | undefined);
    get dataField(): string | undefined;
    set dataField(value: string | undefined);
    get editorOptions(): any | undefined;
    set editorOptions(value: any | undefined);
    get editorType(): FormItemComponent;
    set editorType(value: FormItemComponent);
    get helpText(): string | undefined;
    set helpText(value: string | undefined);
    get isRequired(): boolean | undefined;
    set isRequired(value: boolean | undefined);
    get itemType(): FormItemType;
    set itemType(value: FormItemType);
    get label(): {
        alignment?: HorizontalAlignment;
        location?: LabelLocation;
        showColon?: boolean;
        template?: any;
        text?: string | undefined;
        visible?: boolean;
    };
    set label(value: {
        alignment?: HorizontalAlignment;
        location?: LabelLocation;
        showColon?: boolean;
        template?: any;
        text?: string | undefined;
        visible?: boolean;
    });
    get name(): string | undefined | FormPredefinedButtonItem | SchedulerPredefinedToolbarItem;
    set name(value: string | undefined | FormPredefinedButtonItem | SchedulerPredefinedToolbarItem);
    get validationRules(): Array<CommonTypes.ValidationRule>;
    set validationRules(value: Array<CommonTypes.ValidationRule>);
    get visibleIndex(): number | undefined;
    set visibleIndex(value: number | undefined);
    get alignItemLabels(): boolean;
    set alignItemLabels(value: boolean);
    get caption(): string | undefined;
    set caption(value: string | undefined);
    get captionTemplate(): any;
    set captionTemplate(value: any);
    get colCount(): number;
    set colCount(value: number);
    get colCountByScreen(): {
        lg?: number | undefined;
        md?: number | undefined;
        sm?: number | undefined;
        xs?: number | undefined;
    };
    set colCountByScreen(value: {
        lg?: number | undefined;
        md?: number | undefined;
        sm?: number | undefined;
        xs?: number | undefined;
    });
    get items(): Array<dxFormButtonItem | dxFormEmptyItem | dxFormGroupItem | dxFormSimpleItem | dxFormTabbedItem>;
    set items(value: Array<dxFormButtonItem | dxFormEmptyItem | dxFormGroupItem | dxFormSimpleItem | dxFormTabbedItem>);
    get tabPanelOptions(): dxTabPanelOptions | undefined;
    set tabPanelOptions(value: dxTabPanelOptions | undefined);
    get tabs(): {
        alignItemLabels?: boolean;
        badge?: string | undefined;
        colCount?: number;
        colCountByScreen?: {
            lg?: number | undefined;
            md?: number | undefined;
            sm?: number | undefined;
            xs?: number | undefined;
        };
        disabled?: boolean;
        icon?: string | undefined;
        items?: Array<dxFormButtonItem | dxFormEmptyItem | dxFormGroupItem | dxFormSimpleItem | dxFormTabbedItem>;
        tabTemplate?: any;
        template?: any;
        title?: string | undefined;
    }[];
    set tabs(value: {
        alignItemLabels?: boolean;
        badge?: string | undefined;
        colCount?: number;
        colCountByScreen?: {
            lg?: number | undefined;
            md?: number | undefined;
            sm?: number | undefined;
            xs?: number | undefined;
        };
        disabled?: boolean;
        icon?: string | undefined;
        items?: Array<dxFormButtonItem | dxFormEmptyItem | dxFormGroupItem | dxFormSimpleItem | dxFormTabbedItem>;
        tabTemplate?: any;
        template?: any;
        title?: string | undefined;
    }[]);
    get buttonOptions(): dxButtonOptions | undefined;
    set buttonOptions(value: dxButtonOptions | undefined);
    get horizontalAlignment(): HorizontalAlignment;
    set horizontalAlignment(value: HorizontalAlignment);
    get verticalAlignment(): VerticalAlignment;
    set verticalAlignment(value: VerticalAlignment);
    get locateInMenu(): LocateInMenuMode;
    set locateInMenu(value: LocateInMenuMode);
    get location(): ToolbarItemLocation;
    set location(value: ToolbarItemLocation);
    get menuItemTemplate(): any;
    set menuItemTemplate(value: any);
    get options(): DateNavigatorItemProperties | Record<string, any>;
    set options(value: DateNavigatorItemProperties | Record<string, any>);
    get showText(): ShowTextMode;
    set showText(value: ShowTextMode);
    get widget(): ToolbarItemComponent;
    set widget(value: ToolbarItemComponent);
    get elementAttr(): Record<string, any>;
    set elementAttr(value: Record<string, any>);
    get hint(): string;
    set hint(value: string);
    get type(): ButtonType | string;
    set type(value: ButtonType | string);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost, renderer: Renderer2, document: any, templateHost: DxTemplateHost, element: ElementRef);
    setTemplate(template: DxTemplateDirective): void;
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiSchedulerItemComponent, [{ host: true; skipSelf: true; }, { host: true; }, null, null, { host: true; }, null]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiSchedulerItemComponent, "dxi-scheduler-item", never, { "badge": { "alias": "badge"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "html": { "alias": "html"; "required": false; }; "icon": { "alias": "icon"; "required": false; }; "tabTemplate": { "alias": "tabTemplate"; "required": false; }; "template": { "alias": "template"; "required": false; }; "text": { "alias": "text"; "required": false; }; "title": { "alias": "title"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "aiOptions": { "alias": "aiOptions"; "required": false; }; "colSpan": { "alias": "colSpan"; "required": false; }; "cssClass": { "alias": "cssClass"; "required": false; }; "dataField": { "alias": "dataField"; "required": false; }; "editorOptions": { "alias": "editorOptions"; "required": false; }; "editorType": { "alias": "editorType"; "required": false; }; "helpText": { "alias": "helpText"; "required": false; }; "isRequired": { "alias": "isRequired"; "required": false; }; "itemType": { "alias": "itemType"; "required": false; }; "label": { "alias": "label"; "required": false; }; "name": { "alias": "name"; "required": false; }; "validationRules": { "alias": "validationRules"; "required": false; }; "visibleIndex": { "alias": "visibleIndex"; "required": false; }; "alignItemLabels": { "alias": "alignItemLabels"; "required": false; }; "caption": { "alias": "caption"; "required": false; }; "captionTemplate": { "alias": "captionTemplate"; "required": false; }; "colCount": { "alias": "colCount"; "required": false; }; "colCountByScreen": { "alias": "colCountByScreen"; "required": false; }; "items": { "alias": "items"; "required": false; }; "tabPanelOptions": { "alias": "tabPanelOptions"; "required": false; }; "tabs": { "alias": "tabs"; "required": false; }; "buttonOptions": { "alias": "buttonOptions"; "required": false; }; "horizontalAlignment": { "alias": "horizontalAlignment"; "required": false; }; "verticalAlignment": { "alias": "verticalAlignment"; "required": false; }; "locateInMenu": { "alias": "locateInMenu"; "required": false; }; "location": { "alias": "location"; "required": false; }; "menuItemTemplate": { "alias": "menuItemTemplate"; "required": false; }; "options": { "alias": "options"; "required": false; }; "showText": { "alias": "showText"; "required": false; }; "widget": { "alias": "widget"; "required": false; }; "elementAttr": { "alias": "elementAttr"; "required": false; }; "hint": { "alias": "hint"; "required": false; }; "type": { "alias": "type"; "required": false; }; }, {}, ["_validationRulesContentChildren", "_tabsContentChildren", "_itemsContentChildren"], ["*"], true, never>;
}
declare class DxiSchedulerItemModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiSchedulerItemModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiSchedulerItemModule, never, [typeof DxiSchedulerItemComponent], [typeof DxiSchedulerItemComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiSchedulerItemModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoSchedulerLabelComponent extends NestedOption implements AfterViewInit, OnDestroy, OnInit, IDxTemplateHost {
    private renderer;
    private document;
    private element;
    get alignment(): HorizontalAlignment;
    set alignment(value: HorizontalAlignment);
    get location(): LabelLocation;
    set location(value: LabelLocation);
    get showColon(): boolean;
    set showColon(value: boolean);
    get template(): any;
    set template(value: any);
    get text(): string | undefined;
    set text(value: string | undefined);
    get visible(): boolean;
    set visible(value: boolean);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost, renderer: Renderer2, document: any, templateHost: DxTemplateHost, element: ElementRef);
    setTemplate(template: DxTemplateDirective): void;
    ngAfterViewInit(): void;
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoSchedulerLabelComponent, [{ host: true; skipSelf: true; }, { host: true; }, null, null, { host: true; }, null]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoSchedulerLabelComponent, "dxo-scheduler-label", never, { "alignment": { "alias": "alignment"; "required": false; }; "location": { "alias": "location"; "required": false; }; "showColon": { "alias": "showColon"; "required": false; }; "template": { "alias": "template"; "required": false; }; "text": { "alias": "text"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; }, {}, never, ["*"], true, never>;
}
declare class DxoSchedulerLabelModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoSchedulerLabelModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoSchedulerLabelModule, never, [typeof DxoSchedulerLabelComponent], [typeof DxoSchedulerLabelComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoSchedulerLabelModule>;
}

declare class DxiSchedulerNumericRuleComponent extends CollectionNestedOption {
    get ignoreEmptyValue(): boolean;
    set ignoreEmptyValue(value: boolean);
    get message(): string;
    set message(value: string);
    get type(): ValidationRuleType;
    set type(value: ValidationRuleType);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiSchedulerNumericRuleComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiSchedulerNumericRuleComponent, "dxi-scheduler-numeric-rule", never, { "ignoreEmptyValue": { "alias": "ignoreEmptyValue"; "required": false; }; "message": { "alias": "message"; "required": false; }; "type": { "alias": "type"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxiSchedulerNumericRuleModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiSchedulerNumericRuleModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiSchedulerNumericRuleModule, never, [typeof DxiSchedulerNumericRuleComponent], [typeof DxiSchedulerNumericRuleComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiSchedulerNumericRuleModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxiSchedulerOptionsItemComponent extends CollectionNestedOption implements AfterViewInit, IDxTemplateHost {
    private renderer;
    private document;
    private element;
    get disabled(): boolean;
    set disabled(value: boolean);
    get elementAttr(): Record<string, any>;
    set elementAttr(value: Record<string, any>);
    get hint(): string;
    set hint(value: string);
    get icon(): string;
    set icon(value: string);
    get template(): any;
    set template(value: any);
    get text(): string;
    set text(value: string);
    get type(): ButtonType | string;
    set type(value: ButtonType | string);
    get visible(): boolean;
    set visible(value: boolean);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost, renderer: Renderer2, document: any, templateHost: DxTemplateHost, element: ElementRef);
    setTemplate(template: DxTemplateDirective): void;
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiSchedulerOptionsItemComponent, [{ host: true; skipSelf: true; }, { host: true; }, null, null, { host: true; }, null]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiSchedulerOptionsItemComponent, "dxi-scheduler-options-item", never, { "disabled": { "alias": "disabled"; "required": false; }; "elementAttr": { "alias": "elementAttr"; "required": false; }; "hint": { "alias": "hint"; "required": false; }; "icon": { "alias": "icon"; "required": false; }; "template": { "alias": "template"; "required": false; }; "text": { "alias": "text"; "required": false; }; "type": { "alias": "type"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; }, {}, never, ["*"], true, never>;
}
declare class DxiSchedulerOptionsItemModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiSchedulerOptionsItemModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiSchedulerOptionsItemModule, never, [typeof DxiSchedulerOptionsItemComponent], [typeof DxiSchedulerOptionsItemComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiSchedulerOptionsItemModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoSchedulerOptionsComponent extends NestedOption implements OnDestroy, OnInit {
    set _itemsContentChildren(value: QueryList<CollectionNestedOption>);
    get accessKey(): string | undefined;
    set accessKey(value: string | undefined);
    get activeStateEnabled(): boolean;
    set activeStateEnabled(value: boolean);
    get buttonTemplate(): any;
    set buttonTemplate(value: any);
    get disabled(): boolean;
    set disabled(value: boolean);
    get elementAttr(): Record<string, any>;
    set elementAttr(value: Record<string, any>);
    get focusStateEnabled(): boolean;
    set focusStateEnabled(value: boolean);
    get height(): number | string | undefined;
    set height(value: number | string | undefined);
    get hint(): string | undefined;
    set hint(value: string | undefined);
    get hoverStateEnabled(): boolean;
    set hoverStateEnabled(value: boolean);
    get items(): Array<dxButtonGroupItem | SchedulerPredefinedDateNavigatorItem>;
    set items(value: Array<dxButtonGroupItem | SchedulerPredefinedDateNavigatorItem>);
    get keyExpr(): ((item: any) => any) | string;
    set keyExpr(value: ((item: any) => any) | string);
    get onContentReady(): ((e: ContentReadyEvent$2) => void);
    set onContentReady(value: ((e: ContentReadyEvent$2) => void));
    get onDisposing(): ((e: DisposingEvent$2) => void);
    set onDisposing(value: ((e: DisposingEvent$2) => void));
    get onInitialized(): ((e: InitializedEvent$2) => void);
    set onInitialized(value: ((e: InitializedEvent$2) => void));
    get onItemClick(): ((e: ItemClickEvent) => void) | undefined;
    set onItemClick(value: ((e: ItemClickEvent) => void) | undefined);
    get onOptionChanged(): ((e: OptionChangedEvent$2) => void);
    set onOptionChanged(value: ((e: OptionChangedEvent$2) => void));
    get onSelectionChanged(): ((e: SelectionChangedEvent) => void) | undefined;
    set onSelectionChanged(value: ((e: SelectionChangedEvent) => void) | undefined);
    get rtlEnabled(): boolean;
    set rtlEnabled(value: boolean);
    get selectedItemKeys(): Array<any>;
    set selectedItemKeys(value: Array<any>);
    get selectedItems(): Array<any>;
    set selectedItems(value: Array<any>);
    get selectionMode(): SingleMultipleOrNone;
    set selectionMode(value: SingleMultipleOrNone);
    get stylingMode(): ButtonStyle;
    set stylingMode(value: ButtonStyle);
    get tabIndex(): number;
    set tabIndex(value: number);
    get visible(): boolean;
    set visible(value: boolean);
    get width(): number | string | undefined;
    set width(value: number | string | undefined);
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    selectedItemKeysChange: EventEmitter<Array<any>>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    selectedItemsChange: EventEmitter<Array<any>>;
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoSchedulerOptionsComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoSchedulerOptionsComponent, "dxo-scheduler-options", never, { "accessKey": { "alias": "accessKey"; "required": false; }; "activeStateEnabled": { "alias": "activeStateEnabled"; "required": false; }; "buttonTemplate": { "alias": "buttonTemplate"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "elementAttr": { "alias": "elementAttr"; "required": false; }; "focusStateEnabled": { "alias": "focusStateEnabled"; "required": false; }; "height": { "alias": "height"; "required": false; }; "hint": { "alias": "hint"; "required": false; }; "hoverStateEnabled": { "alias": "hoverStateEnabled"; "required": false; }; "items": { "alias": "items"; "required": false; }; "keyExpr": { "alias": "keyExpr"; "required": false; }; "onContentReady": { "alias": "onContentReady"; "required": false; }; "onDisposing": { "alias": "onDisposing"; "required": false; }; "onInitialized": { "alias": "onInitialized"; "required": false; }; "onItemClick": { "alias": "onItemClick"; "required": false; }; "onOptionChanged": { "alias": "onOptionChanged"; "required": false; }; "onSelectionChanged": { "alias": "onSelectionChanged"; "required": false; }; "rtlEnabled": { "alias": "rtlEnabled"; "required": false; }; "selectedItemKeys": { "alias": "selectedItemKeys"; "required": false; }; "selectedItems": { "alias": "selectedItems"; "required": false; }; "selectionMode": { "alias": "selectionMode"; "required": false; }; "stylingMode": { "alias": "stylingMode"; "required": false; }; "tabIndex": { "alias": "tabIndex"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, { "selectedItemKeysChange": "selectedItemKeysChange"; "selectedItemsChange": "selectedItemsChange"; }, ["_itemsContentChildren"], never, true, never>;
}
declare class DxoSchedulerOptionsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoSchedulerOptionsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoSchedulerOptionsModule, never, [typeof DxoSchedulerOptionsComponent], [typeof DxoSchedulerOptionsComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoSchedulerOptionsModule>;
}

declare class DxiSchedulerPatternRuleComponent extends CollectionNestedOption {
    get ignoreEmptyValue(): boolean;
    set ignoreEmptyValue(value: boolean);
    get message(): string;
    set message(value: string);
    get pattern(): RegExp | string;
    set pattern(value: RegExp | string);
    get type(): ValidationRuleType;
    set type(value: ValidationRuleType);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiSchedulerPatternRuleComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiSchedulerPatternRuleComponent, "dxi-scheduler-pattern-rule", never, { "ignoreEmptyValue": { "alias": "ignoreEmptyValue"; "required": false; }; "message": { "alias": "message"; "required": false; }; "pattern": { "alias": "pattern"; "required": false; }; "type": { "alias": "type"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxiSchedulerPatternRuleModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiSchedulerPatternRuleModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiSchedulerPatternRuleModule, never, [typeof DxiSchedulerPatternRuleComponent], [typeof DxiSchedulerPatternRuleComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiSchedulerPatternRuleModule>;
}

declare class DxiSchedulerRangeRuleComponent extends CollectionNestedOption {
    get ignoreEmptyValue(): boolean;
    set ignoreEmptyValue(value: boolean);
    get max(): Date | number | string;
    set max(value: Date | number | string);
    get message(): string;
    set message(value: string);
    get min(): Date | number | string;
    set min(value: Date | number | string);
    get reevaluate(): boolean;
    set reevaluate(value: boolean);
    get type(): ValidationRuleType;
    set type(value: ValidationRuleType);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiSchedulerRangeRuleComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiSchedulerRangeRuleComponent, "dxi-scheduler-range-rule", never, { "ignoreEmptyValue": { "alias": "ignoreEmptyValue"; "required": false; }; "max": { "alias": "max"; "required": false; }; "message": { "alias": "message"; "required": false; }; "min": { "alias": "min"; "required": false; }; "reevaluate": { "alias": "reevaluate"; "required": false; }; "type": { "alias": "type"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxiSchedulerRangeRuleModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiSchedulerRangeRuleModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiSchedulerRangeRuleModule, never, [typeof DxiSchedulerRangeRuleComponent], [typeof DxiSchedulerRangeRuleComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiSchedulerRangeRuleModule>;
}

declare class DxiSchedulerRequiredRuleComponent extends CollectionNestedOption {
    get message(): string;
    set message(value: string);
    get trim(): boolean;
    set trim(value: boolean);
    get type(): ValidationRuleType;
    set type(value: ValidationRuleType);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiSchedulerRequiredRuleComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiSchedulerRequiredRuleComponent, "dxi-scheduler-required-rule", never, { "message": { "alias": "message"; "required": false; }; "trim": { "alias": "trim"; "required": false; }; "type": { "alias": "type"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxiSchedulerRequiredRuleModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiSchedulerRequiredRuleModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiSchedulerRequiredRuleModule, never, [typeof DxiSchedulerRequiredRuleComponent], [typeof DxiSchedulerRequiredRuleComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiSchedulerRequiredRuleModule>;
}

declare class DxiSchedulerResourceComponent extends CollectionNestedOption {
    get allowMultiple(): boolean;
    set allowMultiple(value: boolean);
    get colorExpr(): string;
    set colorExpr(value: string);
    get dataSource(): Array<any> | DataSource | DataSourceOptions | null | Store | string;
    set dataSource(value: Array<any> | DataSource | DataSourceOptions | null | Store | string);
    get displayExpr(): ((resource: any) => string) | string;
    set displayExpr(value: ((resource: any) => string) | string);
    get fieldExpr(): string;
    set fieldExpr(value: string);
    get icon(): string;
    set icon(value: string);
    get label(): string;
    set label(value: string);
    get parentIdExpr(): string;
    set parentIdExpr(value: string);
    get useColorAsDefault(): boolean;
    set useColorAsDefault(value: boolean);
    get valueExpr(): Function | string;
    set valueExpr(value: Function | string);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiSchedulerResourceComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiSchedulerResourceComponent, "dxi-scheduler-resource", never, { "allowMultiple": { "alias": "allowMultiple"; "required": false; }; "colorExpr": { "alias": "colorExpr"; "required": false; }; "dataSource": { "alias": "dataSource"; "required": false; }; "displayExpr": { "alias": "displayExpr"; "required": false; }; "fieldExpr": { "alias": "fieldExpr"; "required": false; }; "icon": { "alias": "icon"; "required": false; }; "label": { "alias": "label"; "required": false; }; "parentIdExpr": { "alias": "parentIdExpr"; "required": false; }; "useColorAsDefault": { "alias": "useColorAsDefault"; "required": false; }; "valueExpr": { "alias": "valueExpr"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxiSchedulerResourceModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiSchedulerResourceModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiSchedulerResourceModule, never, [typeof DxiSchedulerResourceComponent], [typeof DxiSchedulerResourceComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiSchedulerResourceModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoSchedulerScrollingComponent extends NestedOption implements OnDestroy, OnInit {
    get mode(): ScrollMode;
    set mode(value: ScrollMode);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoSchedulerScrollingComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoSchedulerScrollingComponent, "dxo-scheduler-scrolling", never, { "mode": { "alias": "mode"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoSchedulerScrollingModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoSchedulerScrollingModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoSchedulerScrollingModule, never, [typeof DxoSchedulerScrollingComponent], [typeof DxoSchedulerScrollingComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoSchedulerScrollingModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxiSchedulerSimpleItemComponent extends CollectionNestedOption implements AfterViewInit, IDxTemplateHost {
    private renderer;
    private document;
    private element;
    set _validationRulesContentChildren(value: QueryList<CollectionNestedOption>);
    get aiOptions(): {
        disabled?: boolean;
        instruction?: string | undefined;
    };
    set aiOptions(value: {
        disabled?: boolean;
        instruction?: string | undefined;
    });
    get colSpan(): number | undefined;
    set colSpan(value: number | undefined);
    get cssClass(): string | undefined;
    set cssClass(value: string | undefined);
    get dataField(): string | undefined;
    set dataField(value: string | undefined);
    get editorOptions(): any | undefined;
    set editorOptions(value: any | undefined);
    get editorType(): FormItemComponent;
    set editorType(value: FormItemComponent);
    get helpText(): string | undefined;
    set helpText(value: string | undefined);
    get isRequired(): boolean | undefined;
    set isRequired(value: boolean | undefined);
    get itemType(): FormItemType;
    set itemType(value: FormItemType);
    get label(): {
        alignment?: HorizontalAlignment;
        location?: LabelLocation;
        showColon?: boolean;
        template?: any;
        text?: string | undefined;
        visible?: boolean;
    };
    set label(value: {
        alignment?: HorizontalAlignment;
        location?: LabelLocation;
        showColon?: boolean;
        template?: any;
        text?: string | undefined;
        visible?: boolean;
    });
    get name(): string | undefined;
    set name(value: string | undefined);
    get template(): any;
    set template(value: any);
    get validationRules(): Array<CommonTypes.ValidationRule>;
    set validationRules(value: Array<CommonTypes.ValidationRule>);
    get visible(): boolean;
    set visible(value: boolean);
    get visibleIndex(): number | undefined;
    set visibleIndex(value: number | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost, renderer: Renderer2, document: any, templateHost: DxTemplateHost, element: ElementRef);
    setTemplate(template: DxTemplateDirective): void;
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiSchedulerSimpleItemComponent, [{ host: true; skipSelf: true; }, { host: true; }, null, null, { host: true; }, null]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiSchedulerSimpleItemComponent, "dxi-scheduler-simple-item", never, { "aiOptions": { "alias": "aiOptions"; "required": false; }; "colSpan": { "alias": "colSpan"; "required": false; }; "cssClass": { "alias": "cssClass"; "required": false; }; "dataField": { "alias": "dataField"; "required": false; }; "editorOptions": { "alias": "editorOptions"; "required": false; }; "editorType": { "alias": "editorType"; "required": false; }; "helpText": { "alias": "helpText"; "required": false; }; "isRequired": { "alias": "isRequired"; "required": false; }; "itemType": { "alias": "itemType"; "required": false; }; "label": { "alias": "label"; "required": false; }; "name": { "alias": "name"; "required": false; }; "template": { "alias": "template"; "required": false; }; "validationRules": { "alias": "validationRules"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "visibleIndex": { "alias": "visibleIndex"; "required": false; }; }, {}, ["_validationRulesContentChildren"], ["*"], true, never>;
}
declare class DxiSchedulerSimpleItemModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiSchedulerSimpleItemModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiSchedulerSimpleItemModule, never, [typeof DxiSchedulerSimpleItemComponent], [typeof DxiSchedulerSimpleItemComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiSchedulerSimpleItemModule>;
}

declare class DxiSchedulerStringLengthRuleComponent extends CollectionNestedOption {
    get ignoreEmptyValue(): boolean;
    set ignoreEmptyValue(value: boolean);
    get max(): number;
    set max(value: number);
    get message(): string;
    set message(value: string);
    get min(): number;
    set min(value: number);
    get trim(): boolean;
    set trim(value: boolean);
    get type(): ValidationRuleType;
    set type(value: ValidationRuleType);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiSchedulerStringLengthRuleComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiSchedulerStringLengthRuleComponent, "dxi-scheduler-string-length-rule", never, { "ignoreEmptyValue": { "alias": "ignoreEmptyValue"; "required": false; }; "max": { "alias": "max"; "required": false; }; "message": { "alias": "message"; "required": false; }; "min": { "alias": "min"; "required": false; }; "trim": { "alias": "trim"; "required": false; }; "type": { "alias": "type"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxiSchedulerStringLengthRuleModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiSchedulerStringLengthRuleModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiSchedulerStringLengthRuleModule, never, [typeof DxiSchedulerStringLengthRuleComponent], [typeof DxiSchedulerStringLengthRuleComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiSchedulerStringLengthRuleModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxiSchedulerTabComponent extends CollectionNestedOption implements AfterViewInit, IDxTemplateHost {
    private renderer;
    private document;
    private element;
    set _itemsContentChildren(value: QueryList<CollectionNestedOption>);
    get alignItemLabels(): boolean;
    set alignItemLabels(value: boolean);
    get badge(): string | undefined;
    set badge(value: string | undefined);
    get colCount(): number;
    set colCount(value: number);
    get colCountByScreen(): {
        lg?: number | undefined;
        md?: number | undefined;
        sm?: number | undefined;
        xs?: number | undefined;
    };
    set colCountByScreen(value: {
        lg?: number | undefined;
        md?: number | undefined;
        sm?: number | undefined;
        xs?: number | undefined;
    });
    get disabled(): boolean;
    set disabled(value: boolean);
    get icon(): string | undefined;
    set icon(value: string | undefined);
    get items(): Array<dxFormButtonItem | dxFormEmptyItem | dxFormGroupItem | dxFormSimpleItem | dxFormTabbedItem>;
    set items(value: Array<dxFormButtonItem | dxFormEmptyItem | dxFormGroupItem | dxFormSimpleItem | dxFormTabbedItem>);
    get tabTemplate(): any;
    set tabTemplate(value: any);
    get template(): any;
    set template(value: any);
    get title(): string | undefined;
    set title(value: string | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost, renderer: Renderer2, document: any, templateHost: DxTemplateHost, element: ElementRef);
    setTemplate(template: DxTemplateDirective): void;
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiSchedulerTabComponent, [{ host: true; skipSelf: true; }, { host: true; }, null, null, { host: true; }, null]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiSchedulerTabComponent, "dxi-scheduler-tab", never, { "alignItemLabels": { "alias": "alignItemLabels"; "required": false; }; "badge": { "alias": "badge"; "required": false; }; "colCount": { "alias": "colCount"; "required": false; }; "colCountByScreen": { "alias": "colCountByScreen"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "icon": { "alias": "icon"; "required": false; }; "items": { "alias": "items"; "required": false; }; "tabTemplate": { "alias": "tabTemplate"; "required": false; }; "template": { "alias": "template"; "required": false; }; "title": { "alias": "title"; "required": false; }; }, {}, ["_itemsContentChildren"], ["*"], true, never>;
}
declare class DxiSchedulerTabModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiSchedulerTabModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiSchedulerTabModule, never, [typeof DxiSchedulerTabComponent], [typeof DxiSchedulerTabComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiSchedulerTabModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxiSchedulerTabPanelOptionsItemComponent extends CollectionNestedOption implements AfterViewInit, IDxTemplateHost {
    private renderer;
    private document;
    private element;
    get badge(): string;
    set badge(value: string);
    get disabled(): boolean;
    set disabled(value: boolean);
    get html(): string;
    set html(value: string);
    get icon(): string;
    set icon(value: string);
    get tabTemplate(): any;
    set tabTemplate(value: any);
    get template(): any;
    set template(value: any);
    get text(): string;
    set text(value: string);
    get title(): string;
    set title(value: string);
    get visible(): boolean;
    set visible(value: boolean);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost, renderer: Renderer2, document: any, templateHost: DxTemplateHost, element: ElementRef);
    setTemplate(template: DxTemplateDirective): void;
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiSchedulerTabPanelOptionsItemComponent, [{ host: true; skipSelf: true; }, { host: true; }, null, null, { host: true; }, null]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiSchedulerTabPanelOptionsItemComponent, "dxi-scheduler-tab-panel-options-item", never, { "badge": { "alias": "badge"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "html": { "alias": "html"; "required": false; }; "icon": { "alias": "icon"; "required": false; }; "tabTemplate": { "alias": "tabTemplate"; "required": false; }; "template": { "alias": "template"; "required": false; }; "text": { "alias": "text"; "required": false; }; "title": { "alias": "title"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; }, {}, never, ["*"], true, never>;
}
declare class DxiSchedulerTabPanelOptionsItemModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiSchedulerTabPanelOptionsItemModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiSchedulerTabPanelOptionsItemModule, never, [typeof DxiSchedulerTabPanelOptionsItemComponent], [typeof DxiSchedulerTabPanelOptionsItemComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiSchedulerTabPanelOptionsItemModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoSchedulerTabPanelOptionsComponent extends NestedOption implements OnDestroy, OnInit {
    set _itemsContentChildren(value: QueryList<CollectionNestedOption>);
    get accessKey(): string | undefined;
    set accessKey(value: string | undefined);
    get activeStateEnabled(): boolean;
    set activeStateEnabled(value: boolean);
    get animationEnabled(): boolean;
    set animationEnabled(value: boolean);
    get dataSource(): Array<any | dxTabPanelItem | string> | DataSource | DataSourceOptions | null | Store | string;
    set dataSource(value: Array<any | dxTabPanelItem | string> | DataSource | DataSourceOptions | null | Store | string);
    get deferRendering(): boolean;
    set deferRendering(value: boolean);
    get disabled(): boolean;
    set disabled(value: boolean);
    get elementAttr(): Record<string, any>;
    set elementAttr(value: Record<string, any>);
    get focusStateEnabled(): boolean;
    set focusStateEnabled(value: boolean);
    get height(): number | string | undefined;
    set height(value: number | string | undefined);
    get hint(): string | undefined;
    set hint(value: string | undefined);
    get hoverStateEnabled(): boolean;
    set hoverStateEnabled(value: boolean);
    get iconPosition(): TabsIconPosition;
    set iconPosition(value: TabsIconPosition);
    get itemHoldTimeout(): number;
    set itemHoldTimeout(value: number);
    get items(): Array<any | dxTabPanelItem | string>;
    set items(value: Array<any | dxTabPanelItem | string>);
    get itemTemplate(): any;
    set itemTemplate(value: any);
    get itemTitleTemplate(): any;
    set itemTitleTemplate(value: any);
    get keyExpr(): ((item: any) => any) | string;
    set keyExpr(value: ((item: any) => any) | string);
    get loop(): boolean;
    set loop(value: boolean);
    get noDataText(): string;
    set noDataText(value: string);
    get onContentReady(): ((e: ContentReadyEvent$3) => void);
    set onContentReady(value: ((e: ContentReadyEvent$3) => void));
    get onDisposing(): ((e: DisposingEvent$3) => void);
    set onDisposing(value: ((e: DisposingEvent$3) => void));
    get onInitialized(): ((e: InitializedEvent$3) => void);
    set onInitialized(value: ((e: InitializedEvent$3) => void));
    get onItemClick(): ((e: ItemClickEvent$1) => void);
    set onItemClick(value: ((e: ItemClickEvent$1) => void));
    get onItemContextMenu(): ((e: ItemContextMenuEvent) => void);
    set onItemContextMenu(value: ((e: ItemContextMenuEvent) => void));
    get onItemHold(): ((e: ItemHoldEvent) => void);
    set onItemHold(value: ((e: ItemHoldEvent) => void));
    get onItemRendered(): ((e: ItemRenderedEvent) => void);
    set onItemRendered(value: ((e: ItemRenderedEvent) => void));
    get onOptionChanged(): ((e: OptionChangedEvent$3) => void);
    set onOptionChanged(value: ((e: OptionChangedEvent$3) => void));
    get onSelectionChanged(): ((e: SelectionChangedEvent$1) => void);
    set onSelectionChanged(value: ((e: SelectionChangedEvent$1) => void));
    get onSelectionChanging(): ((e: SelectionChangingEvent) => void);
    set onSelectionChanging(value: ((e: SelectionChangingEvent) => void));
    get onTitleClick(): ((e: TitleClickEvent) => void);
    set onTitleClick(value: ((e: TitleClickEvent) => void));
    get onTitleHold(): ((e: TitleHoldEvent) => void) | undefined;
    set onTitleHold(value: ((e: TitleHoldEvent) => void) | undefined);
    get onTitleRendered(): ((e: TitleRenderedEvent) => void) | undefined;
    set onTitleRendered(value: ((e: TitleRenderedEvent) => void) | undefined);
    get repaintChangesOnly(): boolean;
    set repaintChangesOnly(value: boolean);
    get rtlEnabled(): boolean;
    set rtlEnabled(value: boolean);
    get scrollByContent(): boolean;
    set scrollByContent(value: boolean);
    get scrollingEnabled(): boolean;
    set scrollingEnabled(value: boolean);
    get selectedIndex(): number;
    set selectedIndex(value: number);
    get selectedItem(): any | null;
    set selectedItem(value: any | null);
    get showNavButtons(): boolean;
    set showNavButtons(value: boolean);
    get stylingMode(): TabsStyle;
    set stylingMode(value: TabsStyle);
    get swipeEnabled(): boolean;
    set swipeEnabled(value: boolean);
    get tabIndex(): number;
    set tabIndex(value: number);
    get tabsPosition(): Position;
    set tabsPosition(value: Position);
    get visible(): boolean;
    set visible(value: boolean);
    get width(): number | string | undefined;
    set width(value: number | string | undefined);
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    itemsChange: EventEmitter<Array<any | dxTabPanelItem | string>>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    selectedIndexChange: EventEmitter<number>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    selectedItemChange: EventEmitter<any | null>;
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoSchedulerTabPanelOptionsComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoSchedulerTabPanelOptionsComponent, "dxo-scheduler-tab-panel-options", never, { "accessKey": { "alias": "accessKey"; "required": false; }; "activeStateEnabled": { "alias": "activeStateEnabled"; "required": false; }; "animationEnabled": { "alias": "animationEnabled"; "required": false; }; "dataSource": { "alias": "dataSource"; "required": false; }; "deferRendering": { "alias": "deferRendering"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "elementAttr": { "alias": "elementAttr"; "required": false; }; "focusStateEnabled": { "alias": "focusStateEnabled"; "required": false; }; "height": { "alias": "height"; "required": false; }; "hint": { "alias": "hint"; "required": false; }; "hoverStateEnabled": { "alias": "hoverStateEnabled"; "required": false; }; "iconPosition": { "alias": "iconPosition"; "required": false; }; "itemHoldTimeout": { "alias": "itemHoldTimeout"; "required": false; }; "items": { "alias": "items"; "required": false; }; "itemTemplate": { "alias": "itemTemplate"; "required": false; }; "itemTitleTemplate": { "alias": "itemTitleTemplate"; "required": false; }; "keyExpr": { "alias": "keyExpr"; "required": false; }; "loop": { "alias": "loop"; "required": false; }; "noDataText": { "alias": "noDataText"; "required": false; }; "onContentReady": { "alias": "onContentReady"; "required": false; }; "onDisposing": { "alias": "onDisposing"; "required": false; }; "onInitialized": { "alias": "onInitialized"; "required": false; }; "onItemClick": { "alias": "onItemClick"; "required": false; }; "onItemContextMenu": { "alias": "onItemContextMenu"; "required": false; }; "onItemHold": { "alias": "onItemHold"; "required": false; }; "onItemRendered": { "alias": "onItemRendered"; "required": false; }; "onOptionChanged": { "alias": "onOptionChanged"; "required": false; }; "onSelectionChanged": { "alias": "onSelectionChanged"; "required": false; }; "onSelectionChanging": { "alias": "onSelectionChanging"; "required": false; }; "onTitleClick": { "alias": "onTitleClick"; "required": false; }; "onTitleHold": { "alias": "onTitleHold"; "required": false; }; "onTitleRendered": { "alias": "onTitleRendered"; "required": false; }; "repaintChangesOnly": { "alias": "repaintChangesOnly"; "required": false; }; "rtlEnabled": { "alias": "rtlEnabled"; "required": false; }; "scrollByContent": { "alias": "scrollByContent"; "required": false; }; "scrollingEnabled": { "alias": "scrollingEnabled"; "required": false; }; "selectedIndex": { "alias": "selectedIndex"; "required": false; }; "selectedItem": { "alias": "selectedItem"; "required": false; }; "showNavButtons": { "alias": "showNavButtons"; "required": false; }; "stylingMode": { "alias": "stylingMode"; "required": false; }; "swipeEnabled": { "alias": "swipeEnabled"; "required": false; }; "tabIndex": { "alias": "tabIndex"; "required": false; }; "tabsPosition": { "alias": "tabsPosition"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, { "itemsChange": "itemsChange"; "selectedIndexChange": "selectedIndexChange"; "selectedItemChange": "selectedItemChange"; }, ["_itemsContentChildren"], never, true, never>;
}
declare class DxoSchedulerTabPanelOptionsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoSchedulerTabPanelOptionsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoSchedulerTabPanelOptionsModule, never, [typeof DxoSchedulerTabPanelOptionsComponent], [typeof DxoSchedulerTabPanelOptionsComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoSchedulerTabPanelOptionsModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxiSchedulerTabbedItemComponent extends CollectionNestedOption {
    set _tabsContentChildren(value: QueryList<CollectionNestedOption>);
    get colSpan(): number | undefined;
    set colSpan(value: number | undefined);
    get cssClass(): string | undefined;
    set cssClass(value: string | undefined);
    get itemType(): FormItemType;
    set itemType(value: FormItemType);
    get name(): string | undefined;
    set name(value: string | undefined);
    get tabPanelOptions(): dxTabPanelOptions | undefined;
    set tabPanelOptions(value: dxTabPanelOptions | undefined);
    get tabs(): {
        alignItemLabels?: boolean;
        badge?: string | undefined;
        colCount?: number;
        colCountByScreen?: {
            lg?: number | undefined;
            md?: number | undefined;
            sm?: number | undefined;
            xs?: number | undefined;
        };
        disabled?: boolean;
        icon?: string | undefined;
        items?: Array<dxFormButtonItem | dxFormEmptyItem | dxFormGroupItem | dxFormSimpleItem | dxFormTabbedItem>;
        tabTemplate?: any;
        template?: any;
        title?: string | undefined;
    }[];
    set tabs(value: {
        alignItemLabels?: boolean;
        badge?: string | undefined;
        colCount?: number;
        colCountByScreen?: {
            lg?: number | undefined;
            md?: number | undefined;
            sm?: number | undefined;
            xs?: number | undefined;
        };
        disabled?: boolean;
        icon?: string | undefined;
        items?: Array<dxFormButtonItem | dxFormEmptyItem | dxFormGroupItem | dxFormSimpleItem | dxFormTabbedItem>;
        tabTemplate?: any;
        template?: any;
        title?: string | undefined;
    }[]);
    get visible(): boolean;
    set visible(value: boolean);
    get visibleIndex(): number | undefined;
    set visibleIndex(value: number | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiSchedulerTabbedItemComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiSchedulerTabbedItemComponent, "dxi-scheduler-tabbed-item", never, { "colSpan": { "alias": "colSpan"; "required": false; }; "cssClass": { "alias": "cssClass"; "required": false; }; "itemType": { "alias": "itemType"; "required": false; }; "name": { "alias": "name"; "required": false; }; "tabPanelOptions": { "alias": "tabPanelOptions"; "required": false; }; "tabs": { "alias": "tabs"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "visibleIndex": { "alias": "visibleIndex"; "required": false; }; }, {}, ["_tabsContentChildren"], never, true, never>;
}
declare class DxiSchedulerTabbedItemModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiSchedulerTabbedItemModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiSchedulerTabbedItemModule, never, [typeof DxiSchedulerTabbedItemComponent], [typeof DxiSchedulerTabbedItemComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiSchedulerTabbedItemModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxiSchedulerToolbarItemComponent extends CollectionNestedOption implements AfterViewInit, IDxTemplateHost {
    private renderer;
    private document;
    private element;
    get cssClass(): string | undefined;
    set cssClass(value: string | undefined);
    get disabled(): boolean;
    set disabled(value: boolean);
    get html(): string;
    set html(value: string);
    get locateInMenu(): LocateInMenuMode;
    set locateInMenu(value: LocateInMenuMode);
    get location(): ToolbarItemLocation;
    set location(value: ToolbarItemLocation);
    get menuItemTemplate(): any;
    set menuItemTemplate(value: any);
    get name(): SchedulerPredefinedToolbarItem;
    set name(value: SchedulerPredefinedToolbarItem);
    get options(): DateNavigatorItemProperties | Record<string, any>;
    set options(value: DateNavigatorItemProperties | Record<string, any>);
    get showText(): ShowTextMode;
    set showText(value: ShowTextMode);
    get template(): any;
    set template(value: any);
    get text(): string;
    set text(value: string);
    get visible(): boolean;
    set visible(value: boolean);
    get widget(): ToolbarItemComponent;
    set widget(value: ToolbarItemComponent);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost, renderer: Renderer2, document: any, templateHost: DxTemplateHost, element: ElementRef);
    setTemplate(template: DxTemplateDirective): void;
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiSchedulerToolbarItemComponent, [{ host: true; skipSelf: true; }, { host: true; }, null, null, { host: true; }, null]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiSchedulerToolbarItemComponent, "dxi-scheduler-toolbar-item", never, { "cssClass": { "alias": "cssClass"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "html": { "alias": "html"; "required": false; }; "locateInMenu": { "alias": "locateInMenu"; "required": false; }; "location": { "alias": "location"; "required": false; }; "menuItemTemplate": { "alias": "menuItemTemplate"; "required": false; }; "name": { "alias": "name"; "required": false; }; "options": { "alias": "options"; "required": false; }; "showText": { "alias": "showText"; "required": false; }; "template": { "alias": "template"; "required": false; }; "text": { "alias": "text"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "widget": { "alias": "widget"; "required": false; }; }, {}, never, ["*"], true, never>;
}
declare class DxiSchedulerToolbarItemModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiSchedulerToolbarItemModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiSchedulerToolbarItemModule, never, [typeof DxiSchedulerToolbarItemComponent], [typeof DxiSchedulerToolbarItemComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiSchedulerToolbarItemModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoSchedulerToolbarComponent extends NestedOption implements OnDestroy, OnInit {
    set _itemsContentChildren(value: QueryList<CollectionNestedOption>);
    get disabled(): boolean;
    set disabled(value: boolean);
    get items(): Array<dxSchedulerToolbarItem | SchedulerPredefinedToolbarItem>;
    set items(value: Array<dxSchedulerToolbarItem | SchedulerPredefinedToolbarItem>);
    get multiline(): boolean;
    set multiline(value: boolean);
    get visible(): boolean | undefined;
    set visible(value: boolean | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoSchedulerToolbarComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoSchedulerToolbarComponent, "dxo-scheduler-toolbar", never, { "disabled": { "alias": "disabled"; "required": false; }; "items": { "alias": "items"; "required": false; }; "multiline": { "alias": "multiline"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; }, {}, ["_itemsContentChildren"], never, true, never>;
}
declare class DxoSchedulerToolbarModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoSchedulerToolbarModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoSchedulerToolbarModule, never, [typeof DxoSchedulerToolbarComponent], [typeof DxoSchedulerToolbarComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoSchedulerToolbarModule>;
}

declare class DxiSchedulerValidationRuleComponent extends CollectionNestedOption {
    get message(): string;
    set message(value: string);
    get trim(): boolean;
    set trim(value: boolean);
    get type(): ValidationRuleType;
    set type(value: ValidationRuleType);
    get ignoreEmptyValue(): boolean;
    set ignoreEmptyValue(value: boolean);
    get max(): Date | number | string;
    set max(value: Date | number | string);
    get min(): Date | number | string;
    set min(value: Date | number | string);
    get reevaluate(): boolean;
    set reevaluate(value: boolean);
    get validationCallback(): ((options: {
        column: Record<string, any>;
        data: Record<string, any>;
        formItem: Record<string, any>;
        rule: Record<string, any>;
        validator: Record<string, any>;
        value: any;
    }) => boolean);
    set validationCallback(value: ((options: {
        column: Record<string, any>;
        data: Record<string, any>;
        formItem: Record<string, any>;
        rule: Record<string, any>;
        validator: Record<string, any>;
        value: any;
    }) => boolean));
    get comparisonTarget(): Function;
    set comparisonTarget(value: Function);
    get comparisonType(): ComparisonOperator;
    set comparisonType(value: ComparisonOperator);
    get pattern(): RegExp | string;
    set pattern(value: RegExp | string);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiSchedulerValidationRuleComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiSchedulerValidationRuleComponent, "dxi-scheduler-validation-rule", never, { "message": { "alias": "message"; "required": false; }; "trim": { "alias": "trim"; "required": false; }; "type": { "alias": "type"; "required": false; }; "ignoreEmptyValue": { "alias": "ignoreEmptyValue"; "required": false; }; "max": { "alias": "max"; "required": false; }; "min": { "alias": "min"; "required": false; }; "reevaluate": { "alias": "reevaluate"; "required": false; }; "validationCallback": { "alias": "validationCallback"; "required": false; }; "comparisonTarget": { "alias": "comparisonTarget"; "required": false; }; "comparisonType": { "alias": "comparisonType"; "required": false; }; "pattern": { "alias": "pattern"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxiSchedulerValidationRuleModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiSchedulerValidationRuleModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiSchedulerValidationRuleModule, never, [typeof DxiSchedulerValidationRuleComponent], [typeof DxiSchedulerValidationRuleComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiSchedulerValidationRuleModule>;
}

declare class DxiSchedulerViewComponent extends CollectionNestedOption {
    get agendaDuration(): number;
    set agendaDuration(value: number);
    get allDayPanelMode(): AllDayPanelMode;
    set allDayPanelMode(value: AllDayPanelMode);
    get appointmentCollectorTemplate(): any;
    set appointmentCollectorTemplate(value: any);
    get appointmentTemplate(): any;
    set appointmentTemplate(value: any);
    get appointmentTooltipTemplate(): any;
    set appointmentTooltipTemplate(value: any);
    get cellDuration(): number;
    set cellDuration(value: number);
    get dataCellTemplate(): any;
    set dataCellTemplate(value: any);
    get dateCellTemplate(): any;
    set dateCellTemplate(value: any);
    get endDayHour(): number;
    set endDayHour(value: number);
    get firstDayOfWeek(): DayOfWeek | undefined;
    set firstDayOfWeek(value: DayOfWeek | undefined);
    get groupByDate(): boolean;
    set groupByDate(value: boolean);
    get groupOrientation(): Orientation;
    set groupOrientation(value: Orientation);
    get groups(): Array<string>;
    set groups(value: Array<string>);
    get hiddenWeekDays(): Array<DayOfWeek> | undefined;
    set hiddenWeekDays(value: Array<DayOfWeek> | undefined);
    get intervalCount(): number;
    set intervalCount(value: number);
    get maxAppointmentsPerCell(): CellAppointmentsLimit | number;
    set maxAppointmentsPerCell(value: CellAppointmentsLimit | number);
    get name(): string | undefined;
    set name(value: string | undefined);
    get offset(): number;
    set offset(value: number);
    get resourceCellTemplate(): any;
    set resourceCellTemplate(value: any);
    get scrolling(): dxSchedulerScrolling;
    set scrolling(value: dxSchedulerScrolling);
    get snapToCellsMode(): SnapToCellsMode;
    set snapToCellsMode(value: SnapToCellsMode);
    get startDate(): Date | number | string | undefined;
    set startDate(value: Date | number | string | undefined);
    get startDayHour(): number;
    set startDayHour(value: number);
    get timeCellTemplate(): any;
    set timeCellTemplate(value: any);
    get type(): undefined | ViewType;
    set type(value: undefined | ViewType);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiSchedulerViewComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiSchedulerViewComponent, "dxi-scheduler-view", never, { "agendaDuration": { "alias": "agendaDuration"; "required": false; }; "allDayPanelMode": { "alias": "allDayPanelMode"; "required": false; }; "appointmentCollectorTemplate": { "alias": "appointmentCollectorTemplate"; "required": false; }; "appointmentTemplate": { "alias": "appointmentTemplate"; "required": false; }; "appointmentTooltipTemplate": { "alias": "appointmentTooltipTemplate"; "required": false; }; "cellDuration": { "alias": "cellDuration"; "required": false; }; "dataCellTemplate": { "alias": "dataCellTemplate"; "required": false; }; "dateCellTemplate": { "alias": "dateCellTemplate"; "required": false; }; "endDayHour": { "alias": "endDayHour"; "required": false; }; "firstDayOfWeek": { "alias": "firstDayOfWeek"; "required": false; }; "groupByDate": { "alias": "groupByDate"; "required": false; }; "groupOrientation": { "alias": "groupOrientation"; "required": false; }; "groups": { "alias": "groups"; "required": false; }; "hiddenWeekDays": { "alias": "hiddenWeekDays"; "required": false; }; "intervalCount": { "alias": "intervalCount"; "required": false; }; "maxAppointmentsPerCell": { "alias": "maxAppointmentsPerCell"; "required": false; }; "name": { "alias": "name"; "required": false; }; "offset": { "alias": "offset"; "required": false; }; "resourceCellTemplate": { "alias": "resourceCellTemplate"; "required": false; }; "scrolling": { "alias": "scrolling"; "required": false; }; "snapToCellsMode": { "alias": "snapToCellsMode"; "required": false; }; "startDate": { "alias": "startDate"; "required": false; }; "startDayHour": { "alias": "startDayHour"; "required": false; }; "timeCellTemplate": { "alias": "timeCellTemplate"; "required": false; }; "type": { "alias": "type"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxiSchedulerViewModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiSchedulerViewModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiSchedulerViewModule, never, [typeof DxiSchedulerViewComponent], [typeof DxiSchedulerViewComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiSchedulerViewModule>;
}

export { DxiSchedulerAsyncRuleComponent, DxiSchedulerAsyncRuleModule, DxiSchedulerButtonItemComponent, DxiSchedulerButtonItemModule, DxiSchedulerCompareRuleComponent, DxiSchedulerCompareRuleModule, DxiSchedulerCustomRuleComponent, DxiSchedulerCustomRuleModule, DxiSchedulerEmailRuleComponent, DxiSchedulerEmailRuleModule, DxiSchedulerEmptyItemComponent, DxiSchedulerEmptyItemModule, DxiSchedulerGroupItemComponent, DxiSchedulerGroupItemModule, DxiSchedulerItemComponent, DxiSchedulerItemModule, DxiSchedulerNumericRuleComponent, DxiSchedulerNumericRuleModule, DxiSchedulerOptionsItemComponent, DxiSchedulerOptionsItemModule, DxiSchedulerPatternRuleComponent, DxiSchedulerPatternRuleModule, DxiSchedulerRangeRuleComponent, DxiSchedulerRangeRuleModule, DxiSchedulerRequiredRuleComponent, DxiSchedulerRequiredRuleModule, DxiSchedulerResourceComponent, DxiSchedulerResourceModule, DxiSchedulerSimpleItemComponent, DxiSchedulerSimpleItemModule, DxiSchedulerStringLengthRuleComponent, DxiSchedulerStringLengthRuleModule, DxiSchedulerTabComponent, DxiSchedulerTabModule, DxiSchedulerTabPanelOptionsItemComponent, DxiSchedulerTabPanelOptionsItemModule, DxiSchedulerTabbedItemComponent, DxiSchedulerTabbedItemModule, DxiSchedulerToolbarItemComponent, DxiSchedulerToolbarItemModule, DxiSchedulerValidationRuleComponent, DxiSchedulerValidationRuleModule, DxiSchedulerViewComponent, DxiSchedulerViewModule, DxoSchedulerAIOptionsComponent, DxoSchedulerAIOptionsModule, DxoSchedulerAppointmentDraggingComponent, DxoSchedulerAppointmentDraggingModule, DxoSchedulerButtonOptionsComponent, DxoSchedulerButtonOptionsModule, DxoSchedulerColCountByScreenComponent, DxoSchedulerColCountByScreenModule, DxoSchedulerEditingComponent, DxoSchedulerEditingModule, DxoSchedulerFormComponent, DxoSchedulerFormModule, DxoSchedulerLabelComponent, DxoSchedulerLabelModule, DxoSchedulerOptionsComponent, DxoSchedulerOptionsModule, DxoSchedulerScrollingComponent, DxoSchedulerScrollingModule, DxoSchedulerTabPanelOptionsComponent, DxoSchedulerTabPanelOptionsModule, DxoSchedulerToolbarComponent, DxoSchedulerToolbarModule };
//# sourceMappingURL=index.d.ts.map
