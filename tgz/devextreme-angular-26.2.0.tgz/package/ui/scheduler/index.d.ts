import * as i0 from '@angular/core';
import { OnDestroy, OnChanges, DoCheck, QueryList, EventEmitter, ElementRef, NgZone, TransferState, SimpleChanges } from '@angular/core';
import dxSortable from 'devextreme/ui/sortable';
import dxDraggable from 'devextreme/ui/draggable';
import dxScheduler, { AllDayPanelMode, ViewType, dxSchedulerAppointment, AppointmentFormProperties, CellAppointmentsLimit, RecurrenceEditMode, dxSchedulerScrolling, SnapToCellsMode, dxSchedulerToolbar, AppointmentAddedEvent, AppointmentAddingEvent, AppointmentClickEvent, AppointmentContextMenuEvent, AppointmentDblClickEvent, AppointmentDeletedEvent, AppointmentDeletingEvent, AppointmentFormOpeningEvent, AppointmentRenderedEvent, AppointmentTooltipShowingEvent, AppointmentUpdatedEvent, AppointmentUpdatingEvent, CellClickEvent, CellContextMenuEvent, ContentReadyEvent, DisposingEvent, InitializedEvent, OptionChangedEvent, SelectionEndEvent } from 'devextreme/ui/scheduler';
import { event } from 'devextreme/events/events.types';
import DataSource, { DataSourceOptions } from 'devextreme/data/data_source';
import { Store } from 'devextreme/data/store';
import { DayOfWeek, Orientation } from 'devextreme/common';
import * as i3 from 'devextreme-angular/core';
import { DxComponent, CollectionNestedOption, DxTemplateHost, WatcherHelper, IterableDifferHelper, NestedOptionHost } from 'devextreme-angular/core';
import * as i1 from 'devextreme-angular/ui/nested';
import * as i2 from 'devextreme-angular/ui/scheduler/nested';
export * from 'devextreme-angular/ui/scheduler/nested';
import * as scheduler_types from 'devextreme/ui/scheduler_types';
export { scheduler_types as DxSchedulerTypes };

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

/**
 * [descr:dxScheduler]

 */
declare class DxSchedulerComponent extends DxComponent implements OnDestroy, OnChanges, DoCheck {
    private _watcherHelper;
    private _idh;
    set _validationRulesContentChildren(value: QueryList<CollectionNestedOption>);
    set _itemsContentChildren(value: QueryList<CollectionNestedOption>);
    set _resourcesContentChildren(value: QueryList<CollectionNestedOption>);
    set _tabsContentChildren(value: QueryList<CollectionNestedOption>);
    set _viewsContentChildren(value: QueryList<CollectionNestedOption>);
    instance: dxScheduler;
    /**
     * [descr:WidgetOptions.accessKey]
    
     */
    get accessKey(): string | undefined;
    set accessKey(value: string | undefined);
    /**
     * [descr:dxSchedulerOptions.adaptivityEnabled]
    
     */
    get adaptivityEnabled(): boolean;
    set adaptivityEnabled(value: boolean);
    /**
     * [descr:dxSchedulerOptions.allDayExpr]
    
     */
    get allDayExpr(): string;
    set allDayExpr(value: string);
    /**
     * [descr:dxSchedulerOptions.allDayPanelMode]
    
     */
    get allDayPanelMode(): AllDayPanelMode;
    set allDayPanelMode(value: AllDayPanelMode);
    /**
     * [descr:dxSchedulerOptions.appointmentCollectorTemplate]
    
     */
    get appointmentCollectorTemplate(): any;
    set appointmentCollectorTemplate(value: any);
    /**
     * [descr:dxSchedulerOptions.appointmentDragging]
    
     */
    get appointmentDragging(): {
        autoScroll?: boolean;
        data?: any | undefined;
        group?: string | undefined;
        onAdd?: ((e: {
            component: dxScheduler;
            event: event;
            fromComponent: dxSortable | dxDraggable;
            fromData: any;
            itemData: any;
            itemElement: any;
            toComponent: dxSortable | dxDraggable;
            toData: any;
        }) => void);
        onDragEnd?: ((e: {
            cancel: boolean;
            component: dxScheduler;
            event: event;
            fromComponent: dxSortable | dxDraggable;
            fromData: any;
            itemData: any;
            itemElement: any;
            toComponent: dxSortable | dxDraggable;
            toData: any;
            toItemData: any;
        }) => void);
        onDragMove?: ((e: {
            cancel: boolean;
            component: dxScheduler;
            event: event;
            fromComponent: dxSortable | dxDraggable;
            fromData: any;
            itemData: any;
            itemElement: any;
            toComponent: dxSortable | dxDraggable;
            toData: any;
        }) => void);
        onDragStart?: ((e: {
            cancel: boolean;
            component: dxScheduler;
            event: event;
            fromData: any;
            itemData: any;
            itemElement: any;
        }) => void);
        onRemove?: ((e: {
            component: dxScheduler;
            event: event;
            fromComponent: dxSortable | dxDraggable;
            fromData: any;
            itemData: any;
            itemElement: any;
            toComponent: dxSortable | dxDraggable;
        }) => void);
        scrollSensitivity?: number;
        scrollSpeed?: number;
    };
    set appointmentDragging(value: {
        autoScroll?: boolean;
        data?: any | undefined;
        group?: string | undefined;
        onAdd?: ((e: {
            component: dxScheduler;
            event: event;
            fromComponent: dxSortable | dxDraggable;
            fromData: any;
            itemData: any;
            itemElement: any;
            toComponent: dxSortable | dxDraggable;
            toData: any;
        }) => void);
        onDragEnd?: ((e: {
            cancel: boolean;
            component: dxScheduler;
            event: event;
            fromComponent: dxSortable | dxDraggable;
            fromData: any;
            itemData: any;
            itemElement: any;
            toComponent: dxSortable | dxDraggable;
            toData: any;
            toItemData: any;
        }) => void);
        onDragMove?: ((e: {
            cancel: boolean;
            component: dxScheduler;
            event: event;
            fromComponent: dxSortable | dxDraggable;
            fromData: any;
            itemData: any;
            itemElement: any;
            toComponent: dxSortable | dxDraggable;
            toData: any;
        }) => void);
        onDragStart?: ((e: {
            cancel: boolean;
            component: dxScheduler;
            event: event;
            fromData: any;
            itemData: any;
            itemElement: any;
        }) => void);
        onRemove?: ((e: {
            component: dxScheduler;
            event: event;
            fromComponent: dxSortable | dxDraggable;
            fromData: any;
            itemData: any;
            itemElement: any;
            toComponent: dxSortable | dxDraggable;
        }) => void);
        scrollSensitivity?: number;
        scrollSpeed?: number;
    });
    /**
     * [descr:dxSchedulerOptions.appointmentTemplate]
    
     */
    get appointmentTemplate(): any;
    set appointmentTemplate(value: any);
    /**
     * [descr:dxSchedulerOptions.appointmentTooltipTemplate]
    
     */
    get appointmentTooltipTemplate(): any;
    set appointmentTooltipTemplate(value: any);
    /**
     * [descr:dxSchedulerOptions.cellDuration]
    
     */
    get cellDuration(): number;
    set cellDuration(value: number);
    /**
     * [descr:dxSchedulerOptions.crossScrollingEnabled]
    
     */
    get crossScrollingEnabled(): boolean;
    set crossScrollingEnabled(value: boolean);
    /**
     * [descr:dxSchedulerOptions.currentDate]
    
     */
    get currentDate(): Date | number | string;
    set currentDate(value: Date | number | string);
    /**
     * [descr:dxSchedulerOptions.currentView]
    
     */
    get currentView(): string | ViewType;
    set currentView(value: string | ViewType);
    /**
     * [descr:dxSchedulerOptions.customizeDateNavigatorText]
    
     */
    get customizeDateNavigatorText(): ((info: {
        endDate: Date;
        startDate: Date;
        text: string;
    }) => string) | undefined;
    set customizeDateNavigatorText(value: ((info: {
        endDate: Date;
        startDate: Date;
        text: string;
    }) => string) | undefined);
    /**
     * [descr:dxSchedulerOptions.dataCellTemplate]
    
     */
    get dataCellTemplate(): any;
    set dataCellTemplate(value: any);
    /**
     * [descr:dxSchedulerOptions.dataSource]
    
     */
    get dataSource(): Array<dxSchedulerAppointment> | DataSource | DataSourceOptions | null | Store | string;
    set dataSource(value: Array<dxSchedulerAppointment> | DataSource | DataSourceOptions | null | Store | string);
    /**
     * [descr:dxSchedulerOptions.dateCellTemplate]
    
     */
    get dateCellTemplate(): any;
    set dateCellTemplate(value: any);
    /**
     * [descr:dxSchedulerOptions.dateSerializationFormat]
    
     */
    get dateSerializationFormat(): string | undefined;
    set dateSerializationFormat(value: string | undefined);
    /**
     * [descr:dxSchedulerOptions.descriptionExpr]
    
     */
    get descriptionExpr(): string;
    set descriptionExpr(value: string);
    /**
     * [descr:WidgetOptions.disabled]
    
     */
    get disabled(): boolean;
    set disabled(value: boolean);
    /**
     * [descr:dxSchedulerOptions.editing]
    
     */
    get editing(): boolean | {
        allowAdding?: boolean;
        allowDeleting?: boolean;
        allowDragging?: boolean;
        allowResizing?: boolean;
        allowTimeZoneEditing?: boolean;
        allowUpdating?: boolean;
        form?: AppointmentFormProperties;
        popup?: Record<string, any>;
    };
    set editing(value: boolean | {
        allowAdding?: boolean;
        allowDeleting?: boolean;
        allowDragging?: boolean;
        allowResizing?: boolean;
        allowTimeZoneEditing?: boolean;
        allowUpdating?: boolean;
        form?: AppointmentFormProperties;
        popup?: Record<string, any>;
    });
    /**
     * [descr:DOMComponentOptions.elementAttr]
    
     */
    get elementAttr(): Record<string, any>;
    set elementAttr(value: Record<string, any>);
    /**
     * [descr:dxSchedulerOptions.endDateExpr]
    
     */
    get endDateExpr(): string;
    set endDateExpr(value: string);
    /**
     * [descr:dxSchedulerOptions.endDateTimeZoneExpr]
    
     */
    get endDateTimeZoneExpr(): string;
    set endDateTimeZoneExpr(value: string);
    /**
     * [descr:dxSchedulerOptions.endDayHour]
    
     */
    get endDayHour(): number;
    set endDayHour(value: number);
    /**
     * [descr:dxSchedulerOptions.firstDayOfWeek]
    
     */
    get firstDayOfWeek(): DayOfWeek | undefined;
    set firstDayOfWeek(value: DayOfWeek | undefined);
    /**
     * [descr:dxSchedulerOptions.focusStateEnabled]
    
     */
    get focusStateEnabled(): boolean;
    set focusStateEnabled(value: boolean);
    /**
     * [descr:dxSchedulerOptions.groupByDate]
    
     */
    get groupByDate(): boolean;
    set groupByDate(value: boolean);
    /**
     * [descr:dxSchedulerOptions.groups]
    
     */
    get groups(): Array<string>;
    set groups(value: Array<string>);
    /**
     * [descr:DOMComponentOptions.height]
    
     */
    get height(): number | string | undefined;
    set height(value: number | string | undefined);
    get hiddenWeekDays(): Array<DayOfWeek> | undefined;
    set hiddenWeekDays(value: Array<DayOfWeek> | undefined);
    /**
     * [descr:WidgetOptions.hint]
    
     */
    get hint(): string | undefined;
    set hint(value: string | undefined);
    /**
     * [descr:dxSchedulerOptions.indicatorUpdateInterval]
    
     */
    get indicatorUpdateInterval(): number;
    set indicatorUpdateInterval(value: number);
    /**
     * [descr:dxSchedulerOptions.max]
    
     */
    get max(): Date | number | string | undefined;
    set max(value: Date | number | string | undefined);
    /**
     * [descr:dxSchedulerOptions.maxAppointmentsPerCell]
    
     */
    get maxAppointmentsPerCell(): CellAppointmentsLimit | number;
    set maxAppointmentsPerCell(value: CellAppointmentsLimit | number);
    /**
     * [descr:dxSchedulerOptions.min]
    
     */
    get min(): Date | number | string | undefined;
    set min(value: Date | number | string | undefined);
    /**
     * [descr:dxSchedulerOptions.noDataText]
    
     */
    get noDataText(): string;
    set noDataText(value: string);
    /**
     * [descr:dxSchedulerOptions.offset]
    
     */
    get offset(): number;
    set offset(value: number);
    /**
     * [descr:dxSchedulerOptions.recurrenceEditMode]
    
     */
    get recurrenceEditMode(): RecurrenceEditMode;
    set recurrenceEditMode(value: RecurrenceEditMode);
    /**
     * [descr:dxSchedulerOptions.recurrenceExceptionExpr]
    
     */
    get recurrenceExceptionExpr(): string;
    set recurrenceExceptionExpr(value: string);
    /**
     * [descr:dxSchedulerOptions.recurrenceRuleExpr]
    
     */
    get recurrenceRuleExpr(): string;
    set recurrenceRuleExpr(value: string);
    /**
     * [descr:dxSchedulerOptions.remoteFiltering]
    
     */
    get remoteFiltering(): boolean;
    set remoteFiltering(value: boolean);
    /**
     * [descr:dxSchedulerOptions.resourceCellTemplate]
    
     */
    get resourceCellTemplate(): any;
    set resourceCellTemplate(value: any);
    /**
     * [descr:dxSchedulerOptions.resources]
    
     */
    get resources(): {
        allowMultiple?: boolean;
        colorExpr?: string;
        dataSource?: Array<any> | DataSource | DataSourceOptions | null | Store | string;
        displayExpr?: ((resource: any) => string) | string;
        fieldExpr?: string;
        icon?: string;
        label?: string;
        parentIdExpr?: string;
        useColorAsDefault?: boolean;
        valueExpr?: Function | string;
    }[];
    set resources(value: {
        allowMultiple?: boolean;
        colorExpr?: string;
        dataSource?: Array<any> | DataSource | DataSourceOptions | null | Store | string;
        displayExpr?: ((resource: any) => string) | string;
        fieldExpr?: string;
        icon?: string;
        label?: string;
        parentIdExpr?: string;
        useColorAsDefault?: boolean;
        valueExpr?: Function | string;
    }[]);
    /**
     * [descr:DOMComponentOptions.rtlEnabled]
    
     */
    get rtlEnabled(): boolean;
    set rtlEnabled(value: boolean);
    /**
     * [descr:dxSchedulerOptions.scrolling]
    
     */
    get scrolling(): dxSchedulerScrolling;
    set scrolling(value: dxSchedulerScrolling);
    /**
     * [descr:dxSchedulerOptions.selectedCellData]
    
     */
    get selectedCellData(): Array<any>;
    set selectedCellData(value: Array<any>);
    /**
     * [descr:dxSchedulerOptions.shadeUntilCurrentTime]
    
     */
    get shadeUntilCurrentTime(): boolean;
    set shadeUntilCurrentTime(value: boolean);
    /**
     * [descr:dxSchedulerOptions.showAllDayPanel]
    
     */
    get showAllDayPanel(): boolean;
    set showAllDayPanel(value: boolean);
    /**
     * [descr:dxSchedulerOptions.showCurrentTimeIndicator]
    
     */
    get showCurrentTimeIndicator(): boolean;
    set showCurrentTimeIndicator(value: boolean);
    get snapToCellsMode(): SnapToCellsMode;
    set snapToCellsMode(value: SnapToCellsMode);
    /**
     * [descr:dxSchedulerOptions.startDateExpr]
    
     */
    get startDateExpr(): string;
    set startDateExpr(value: string);
    /**
     * [descr:dxSchedulerOptions.startDateTimeZoneExpr]
    
     */
    get startDateTimeZoneExpr(): string;
    set startDateTimeZoneExpr(value: string);
    /**
     * [descr:dxSchedulerOptions.startDayHour]
    
     */
    get startDayHour(): number;
    set startDayHour(value: number);
    /**
     * [descr:WidgetOptions.tabIndex]
    
     */
    get tabIndex(): number;
    set tabIndex(value: number);
    /**
     * [descr:dxSchedulerOptions.textExpr]
    
     */
    get textExpr(): string;
    set textExpr(value: string);
    /**
     * [descr:dxSchedulerOptions.timeCellTemplate]
    
     */
    get timeCellTemplate(): any;
    set timeCellTemplate(value: any);
    /**
     * [descr:dxSchedulerOptions.timeZone]
    
     */
    get timeZone(): string;
    set timeZone(value: string);
    /**
     * [descr:dxSchedulerOptions.toolbar]
    
     */
    get toolbar(): dxSchedulerToolbar | undefined;
    set toolbar(value: dxSchedulerToolbar | undefined);
    /**
     * [descr:dxSchedulerOptions.useDropDownViewSwitcher]
    
     */
    get useDropDownViewSwitcher(): boolean;
    set useDropDownViewSwitcher(value: boolean);
    /**
     * [descr:dxSchedulerOptions.views]
    
     */
    get views(): Array<Record<string, any> | string> | {
        agendaDuration?: number;
        allDayPanelMode?: AllDayPanelMode;
        appointmentCollectorTemplate?: any;
        appointmentTemplate?: any;
        appointmentTooltipTemplate?: any;
        cellDuration?: number;
        dataCellTemplate?: any;
        dateCellTemplate?: any;
        endDayHour?: number;
        firstDayOfWeek?: DayOfWeek | undefined;
        groupByDate?: boolean;
        groupOrientation?: Orientation;
        groups?: Array<string>;
        hiddenWeekDays?: Array<DayOfWeek> | undefined;
        intervalCount?: number;
        maxAppointmentsPerCell?: CellAppointmentsLimit | number;
        name?: string | undefined;
        offset?: number;
        resourceCellTemplate?: any;
        scrolling?: dxSchedulerScrolling;
        snapToCellsMode?: SnapToCellsMode;
        startDate?: Date | number | string | undefined;
        startDayHour?: number;
        timeCellTemplate?: any;
        type?: undefined | ViewType;
    }[];
    set views(value: Array<Record<string, any> | string> | {
        agendaDuration?: number;
        allDayPanelMode?: AllDayPanelMode;
        appointmentCollectorTemplate?: any;
        appointmentTemplate?: any;
        appointmentTooltipTemplate?: any;
        cellDuration?: number;
        dataCellTemplate?: any;
        dateCellTemplate?: any;
        endDayHour?: number;
        firstDayOfWeek?: DayOfWeek | undefined;
        groupByDate?: boolean;
        groupOrientation?: Orientation;
        groups?: Array<string>;
        hiddenWeekDays?: Array<DayOfWeek> | undefined;
        intervalCount?: number;
        maxAppointmentsPerCell?: CellAppointmentsLimit | number;
        name?: string | undefined;
        offset?: number;
        resourceCellTemplate?: any;
        scrolling?: dxSchedulerScrolling;
        snapToCellsMode?: SnapToCellsMode;
        startDate?: Date | number | string | undefined;
        startDayHour?: number;
        timeCellTemplate?: any;
        type?: undefined | ViewType;
    }[]);
    /**
     * [descr:WidgetOptions.visible]
    
     */
    get visible(): boolean;
    set visible(value: boolean);
    /**
     * [descr:DOMComponentOptions.width]
    
     */
    get width(): number | string | undefined;
    set width(value: number | string | undefined);
    /**
    
     * [descr:dxSchedulerOptions.onAppointmentAdded]
    
    
     */
    onAppointmentAdded: EventEmitter<AppointmentAddedEvent>;
    /**
    
     * [descr:dxSchedulerOptions.onAppointmentAdding]
    
    
     */
    onAppointmentAdding: EventEmitter<AppointmentAddingEvent>;
    /**
    
     * [descr:dxSchedulerOptions.onAppointmentClick]
    
    
     */
    onAppointmentClick: EventEmitter<AppointmentClickEvent>;
    /**
    
     * [descr:dxSchedulerOptions.onAppointmentContextMenu]
    
    
     */
    onAppointmentContextMenu: EventEmitter<AppointmentContextMenuEvent>;
    /**
    
     * [descr:dxSchedulerOptions.onAppointmentDblClick]
    
    
     */
    onAppointmentDblClick: EventEmitter<AppointmentDblClickEvent>;
    /**
    
     * [descr:dxSchedulerOptions.onAppointmentDeleted]
    
    
     */
    onAppointmentDeleted: EventEmitter<AppointmentDeletedEvent>;
    /**
    
     * [descr:dxSchedulerOptions.onAppointmentDeleting]
    
    
     */
    onAppointmentDeleting: EventEmitter<AppointmentDeletingEvent>;
    /**
    
     * [descr:dxSchedulerOptions.onAppointmentFormOpening]
    
    
     */
    onAppointmentFormOpening: EventEmitter<AppointmentFormOpeningEvent>;
    /**
    
     * [descr:dxSchedulerOptions.onAppointmentRendered]
    
    
     */
    onAppointmentRendered: EventEmitter<AppointmentRenderedEvent>;
    /**
    
     * [descr:dxSchedulerOptions.onAppointmentTooltipShowing]
    
    
     */
    onAppointmentTooltipShowing: EventEmitter<AppointmentTooltipShowingEvent>;
    /**
    
     * [descr:dxSchedulerOptions.onAppointmentUpdated]
    
    
     */
    onAppointmentUpdated: EventEmitter<AppointmentUpdatedEvent>;
    /**
    
     * [descr:dxSchedulerOptions.onAppointmentUpdating]
    
    
     */
    onAppointmentUpdating: EventEmitter<AppointmentUpdatingEvent>;
    /**
    
     * [descr:dxSchedulerOptions.onCellClick]
    
    
     */
    onCellClick: EventEmitter<CellClickEvent>;
    /**
    
     * [descr:dxSchedulerOptions.onCellContextMenu]
    
    
     */
    onCellContextMenu: EventEmitter<CellContextMenuEvent>;
    /**
    
     * [descr:dxSchedulerOptions.onContentReady]
    
    
     */
    onContentReady: EventEmitter<ContentReadyEvent>;
    /**
    
     * [descr:dxSchedulerOptions.onDisposing]
    
    
     */
    onDisposing: EventEmitter<DisposingEvent>;
    /**
    
     * [descr:dxSchedulerOptions.onInitialized]
    
    
     */
    onInitialized: EventEmitter<InitializedEvent>;
    /**
    
     * [descr:dxSchedulerOptions.onOptionChanged]
    
    
     */
    onOptionChanged: EventEmitter<OptionChangedEvent>;
    /**
    
     * [descr:dxSchedulerOptions.onSelectionEnd]
    
    
     */
    onSelectionEnd: EventEmitter<SelectionEndEvent>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    accessKeyChange: EventEmitter<string | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    adaptivityEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    allDayExprChange: EventEmitter<string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    allDayPanelModeChange: EventEmitter<AllDayPanelMode>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    appointmentCollectorTemplateChange: EventEmitter<any>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    appointmentDraggingChange: EventEmitter<{
        autoScroll?: boolean;
        data?: any | undefined;
        group?: string | undefined;
        onAdd?: ((e: {
            component: dxScheduler;
            event: event;
            fromComponent: dxSortable | dxDraggable;
            fromData: any;
            itemData: any;
            itemElement: any;
            toComponent: dxSortable | dxDraggable;
            toData: any;
        }) => void);
        onDragEnd?: ((e: {
            cancel: boolean;
            component: dxScheduler;
            event: event;
            fromComponent: dxSortable | dxDraggable;
            fromData: any;
            itemData: any;
            itemElement: any;
            toComponent: dxSortable | dxDraggable;
            toData: any;
            toItemData: any;
        }) => void);
        onDragMove?: ((e: {
            cancel: boolean;
            component: dxScheduler;
            event: event;
            fromComponent: dxSortable | dxDraggable;
            fromData: any;
            itemData: any;
            itemElement: any;
            toComponent: dxSortable | dxDraggable;
            toData: any;
        }) => void);
        onDragStart?: ((e: {
            cancel: boolean;
            component: dxScheduler;
            event: event;
            fromData: any;
            itemData: any;
            itemElement: any;
        }) => void);
        onRemove?: ((e: {
            component: dxScheduler;
            event: event;
            fromComponent: dxSortable | dxDraggable;
            fromData: any;
            itemData: any;
            itemElement: any;
            toComponent: dxSortable | dxDraggable;
        }) => void);
        scrollSensitivity?: number;
        scrollSpeed?: number;
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    appointmentTemplateChange: EventEmitter<any>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    appointmentTooltipTemplateChange: EventEmitter<any>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    cellDurationChange: EventEmitter<number>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    crossScrollingEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    currentDateChange: EventEmitter<Date | number | string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    currentViewChange: EventEmitter<string | ViewType>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    customizeDateNavigatorTextChange: EventEmitter<((info: {
        endDate: Date;
        startDate: Date;
        text: string;
    }) => string) | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    dataCellTemplateChange: EventEmitter<any>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    dataSourceChange: EventEmitter<Array<dxSchedulerAppointment> | DataSource | DataSourceOptions | null | Store | string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    dateCellTemplateChange: EventEmitter<any>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    dateSerializationFormatChange: EventEmitter<string | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    descriptionExprChange: EventEmitter<string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    disabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    editingChange: EventEmitter<boolean | {
        allowAdding?: boolean;
        allowDeleting?: boolean;
        allowDragging?: boolean;
        allowResizing?: boolean;
        allowTimeZoneEditing?: boolean;
        allowUpdating?: boolean;
        form?: AppointmentFormProperties;
        popup?: Record<string, any>;
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    elementAttrChange: EventEmitter<Record<string, any>>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    endDateExprChange: EventEmitter<string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    endDateTimeZoneExprChange: EventEmitter<string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    endDayHourChange: EventEmitter<number>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    firstDayOfWeekChange: EventEmitter<DayOfWeek | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    focusStateEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    groupByDateChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    groupsChange: EventEmitter<Array<string>>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    heightChange: EventEmitter<number | string | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    hiddenWeekDaysChange: EventEmitter<Array<DayOfWeek> | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    hintChange: EventEmitter<string | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    indicatorUpdateIntervalChange: EventEmitter<number>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    maxChange: EventEmitter<Date | number | string | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    maxAppointmentsPerCellChange: EventEmitter<CellAppointmentsLimit | number>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    minChange: EventEmitter<Date | number | string | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    noDataTextChange: EventEmitter<string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    offsetChange: EventEmitter<number>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    recurrenceEditModeChange: EventEmitter<RecurrenceEditMode>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    recurrenceExceptionExprChange: EventEmitter<string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    recurrenceRuleExprChange: EventEmitter<string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    remoteFilteringChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    resourceCellTemplateChange: EventEmitter<any>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    resourcesChange: EventEmitter<{
        allowMultiple?: boolean;
        colorExpr?: string;
        dataSource?: Array<any> | DataSource | DataSourceOptions | null | Store | string;
        displayExpr?: ((resource: any) => string) | string;
        fieldExpr?: string;
        icon?: string;
        label?: string;
        parentIdExpr?: string;
        useColorAsDefault?: boolean;
        valueExpr?: Function | string;
    }[]>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    rtlEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    scrollingChange: EventEmitter<dxSchedulerScrolling>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    selectedCellDataChange: EventEmitter<Array<any>>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    shadeUntilCurrentTimeChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    showAllDayPanelChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    showCurrentTimeIndicatorChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    snapToCellsModeChange: EventEmitter<SnapToCellsMode>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    startDateExprChange: EventEmitter<string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    startDateTimeZoneExprChange: EventEmitter<string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    startDayHourChange: EventEmitter<number>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    tabIndexChange: EventEmitter<number>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    textExprChange: EventEmitter<string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    timeCellTemplateChange: EventEmitter<any>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    timeZoneChange: EventEmitter<string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    toolbarChange: EventEmitter<dxSchedulerToolbar | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    useDropDownViewSwitcherChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    viewsChange: EventEmitter<Array<Record<string, any> | string> | {
        agendaDuration?: number;
        allDayPanelMode?: AllDayPanelMode;
        appointmentCollectorTemplate?: any;
        appointmentTemplate?: any;
        appointmentTooltipTemplate?: any;
        cellDuration?: number;
        dataCellTemplate?: any;
        dateCellTemplate?: any;
        endDayHour?: number;
        firstDayOfWeek?: DayOfWeek | undefined;
        groupByDate?: boolean;
        groupOrientation?: Orientation;
        groups?: Array<string>;
        hiddenWeekDays?: Array<DayOfWeek> | undefined;
        intervalCount?: number;
        maxAppointmentsPerCell?: CellAppointmentsLimit | number;
        name?: string | undefined;
        offset?: number;
        resourceCellTemplate?: any;
        scrolling?: dxSchedulerScrolling;
        snapToCellsMode?: SnapToCellsMode;
        startDate?: Date | number | string | undefined;
        startDayHour?: number;
        timeCellTemplate?: any;
        type?: undefined | ViewType;
    }[]>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    visibleChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    widthChange: EventEmitter<number | string | undefined>;
    constructor(elementRef: ElementRef, ngZone: NgZone, templateHost: DxTemplateHost, _watcherHelper: WatcherHelper, _idh: IterableDifferHelper, optionHost: NestedOptionHost, transferState: TransferState, platformId: any);
    protected _createInstance(element: any, options: any): dxScheduler;
    ngOnDestroy(): void;
    ngOnChanges(changes: SimpleChanges): void;
    setupChanges(prop: string, changes: SimpleChanges): void;
    ngDoCheck(): void;
    _setOption(name: string, value: any): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxSchedulerComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxSchedulerComponent, "dx-scheduler", never, { "accessKey": { "alias": "accessKey"; "required": false; }; "adaptivityEnabled": { "alias": "adaptivityEnabled"; "required": false; }; "allDayExpr": { "alias": "allDayExpr"; "required": false; }; "allDayPanelMode": { "alias": "allDayPanelMode"; "required": false; }; "appointmentCollectorTemplate": { "alias": "appointmentCollectorTemplate"; "required": false; }; "appointmentDragging": { "alias": "appointmentDragging"; "required": false; }; "appointmentTemplate": { "alias": "appointmentTemplate"; "required": false; }; "appointmentTooltipTemplate": { "alias": "appointmentTooltipTemplate"; "required": false; }; "cellDuration": { "alias": "cellDuration"; "required": false; }; "crossScrollingEnabled": { "alias": "crossScrollingEnabled"; "required": false; }; "currentDate": { "alias": "currentDate"; "required": false; }; "currentView": { "alias": "currentView"; "required": false; }; "customizeDateNavigatorText": { "alias": "customizeDateNavigatorText"; "required": false; }; "dataCellTemplate": { "alias": "dataCellTemplate"; "required": false; }; "dataSource": { "alias": "dataSource"; "required": false; }; "dateCellTemplate": { "alias": "dateCellTemplate"; "required": false; }; "dateSerializationFormat": { "alias": "dateSerializationFormat"; "required": false; }; "descriptionExpr": { "alias": "descriptionExpr"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "editing": { "alias": "editing"; "required": false; }; "elementAttr": { "alias": "elementAttr"; "required": false; }; "endDateExpr": { "alias": "endDateExpr"; "required": false; }; "endDateTimeZoneExpr": { "alias": "endDateTimeZoneExpr"; "required": false; }; "endDayHour": { "alias": "endDayHour"; "required": false; }; "firstDayOfWeek": { "alias": "firstDayOfWeek"; "required": false; }; "focusStateEnabled": { "alias": "focusStateEnabled"; "required": false; }; "groupByDate": { "alias": "groupByDate"; "required": false; }; "groups": { "alias": "groups"; "required": false; }; "height": { "alias": "height"; "required": false; }; "hiddenWeekDays": { "alias": "hiddenWeekDays"; "required": false; }; "hint": { "alias": "hint"; "required": false; }; "indicatorUpdateInterval": { "alias": "indicatorUpdateInterval"; "required": false; }; "max": { "alias": "max"; "required": false; }; "maxAppointmentsPerCell": { "alias": "maxAppointmentsPerCell"; "required": false; }; "min": { "alias": "min"; "required": false; }; "noDataText": { "alias": "noDataText"; "required": false; }; "offset": { "alias": "offset"; "required": false; }; "recurrenceEditMode": { "alias": "recurrenceEditMode"; "required": false; }; "recurrenceExceptionExpr": { "alias": "recurrenceExceptionExpr"; "required": false; }; "recurrenceRuleExpr": { "alias": "recurrenceRuleExpr"; "required": false; }; "remoteFiltering": { "alias": "remoteFiltering"; "required": false; }; "resourceCellTemplate": { "alias": "resourceCellTemplate"; "required": false; }; "resources": { "alias": "resources"; "required": false; }; "rtlEnabled": { "alias": "rtlEnabled"; "required": false; }; "scrolling": { "alias": "scrolling"; "required": false; }; "selectedCellData": { "alias": "selectedCellData"; "required": false; }; "shadeUntilCurrentTime": { "alias": "shadeUntilCurrentTime"; "required": false; }; "showAllDayPanel": { "alias": "showAllDayPanel"; "required": false; }; "showCurrentTimeIndicator": { "alias": "showCurrentTimeIndicator"; "required": false; }; "snapToCellsMode": { "alias": "snapToCellsMode"; "required": false; }; "startDateExpr": { "alias": "startDateExpr"; "required": false; }; "startDateTimeZoneExpr": { "alias": "startDateTimeZoneExpr"; "required": false; }; "startDayHour": { "alias": "startDayHour"; "required": false; }; "tabIndex": { "alias": "tabIndex"; "required": false; }; "textExpr": { "alias": "textExpr"; "required": false; }; "timeCellTemplate": { "alias": "timeCellTemplate"; "required": false; }; "timeZone": { "alias": "timeZone"; "required": false; }; "toolbar": { "alias": "toolbar"; "required": false; }; "useDropDownViewSwitcher": { "alias": "useDropDownViewSwitcher"; "required": false; }; "views": { "alias": "views"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, { "onAppointmentAdded": "onAppointmentAdded"; "onAppointmentAdding": "onAppointmentAdding"; "onAppointmentClick": "onAppointmentClick"; "onAppointmentContextMenu": "onAppointmentContextMenu"; "onAppointmentDblClick": "onAppointmentDblClick"; "onAppointmentDeleted": "onAppointmentDeleted"; "onAppointmentDeleting": "onAppointmentDeleting"; "onAppointmentFormOpening": "onAppointmentFormOpening"; "onAppointmentRendered": "onAppointmentRendered"; "onAppointmentTooltipShowing": "onAppointmentTooltipShowing"; "onAppointmentUpdated": "onAppointmentUpdated"; "onAppointmentUpdating": "onAppointmentUpdating"; "onCellClick": "onCellClick"; "onCellContextMenu": "onCellContextMenu"; "onContentReady": "onContentReady"; "onDisposing": "onDisposing"; "onInitialized": "onInitialized"; "onOptionChanged": "onOptionChanged"; "onSelectionEnd": "onSelectionEnd"; "accessKeyChange": "accessKeyChange"; "adaptivityEnabledChange": "adaptivityEnabledChange"; "allDayExprChange": "allDayExprChange"; "allDayPanelModeChange": "allDayPanelModeChange"; "appointmentCollectorTemplateChange": "appointmentCollectorTemplateChange"; "appointmentDraggingChange": "appointmentDraggingChange"; "appointmentTemplateChange": "appointmentTemplateChange"; "appointmentTooltipTemplateChange": "appointmentTooltipTemplateChange"; "cellDurationChange": "cellDurationChange"; "crossScrollingEnabledChange": "crossScrollingEnabledChange"; "currentDateChange": "currentDateChange"; "currentViewChange": "currentViewChange"; "customizeDateNavigatorTextChange": "customizeDateNavigatorTextChange"; "dataCellTemplateChange": "dataCellTemplateChange"; "dataSourceChange": "dataSourceChange"; "dateCellTemplateChange": "dateCellTemplateChange"; "dateSerializationFormatChange": "dateSerializationFormatChange"; "descriptionExprChange": "descriptionExprChange"; "disabledChange": "disabledChange"; "editingChange": "editingChange"; "elementAttrChange": "elementAttrChange"; "endDateExprChange": "endDateExprChange"; "endDateTimeZoneExprChange": "endDateTimeZoneExprChange"; "endDayHourChange": "endDayHourChange"; "firstDayOfWeekChange": "firstDayOfWeekChange"; "focusStateEnabledChange": "focusStateEnabledChange"; "groupByDateChange": "groupByDateChange"; "groupsChange": "groupsChange"; "heightChange": "heightChange"; "hiddenWeekDaysChange": "hiddenWeekDaysChange"; "hintChange": "hintChange"; "indicatorUpdateIntervalChange": "indicatorUpdateIntervalChange"; "maxChange": "maxChange"; "maxAppointmentsPerCellChange": "maxAppointmentsPerCellChange"; "minChange": "minChange"; "noDataTextChange": "noDataTextChange"; "offsetChange": "offsetChange"; "recurrenceEditModeChange": "recurrenceEditModeChange"; "recurrenceExceptionExprChange": "recurrenceExceptionExprChange"; "recurrenceRuleExprChange": "recurrenceRuleExprChange"; "remoteFilteringChange": "remoteFilteringChange"; "resourceCellTemplateChange": "resourceCellTemplateChange"; "resourcesChange": "resourcesChange"; "rtlEnabledChange": "rtlEnabledChange"; "scrollingChange": "scrollingChange"; "selectedCellDataChange": "selectedCellDataChange"; "shadeUntilCurrentTimeChange": "shadeUntilCurrentTimeChange"; "showAllDayPanelChange": "showAllDayPanelChange"; "showCurrentTimeIndicatorChange": "showCurrentTimeIndicatorChange"; "snapToCellsModeChange": "snapToCellsModeChange"; "startDateExprChange": "startDateExprChange"; "startDateTimeZoneExprChange": "startDateTimeZoneExprChange"; "startDayHourChange": "startDayHourChange"; "tabIndexChange": "tabIndexChange"; "textExprChange": "textExprChange"; "timeCellTemplateChange": "timeCellTemplateChange"; "timeZoneChange": "timeZoneChange"; "toolbarChange": "toolbarChange"; "useDropDownViewSwitcherChange": "useDropDownViewSwitcherChange"; "viewsChange": "viewsChange"; "visibleChange": "visibleChange"; "widthChange": "widthChange"; }, ["_validationRulesContentChildren", "_itemsContentChildren", "_resourcesContentChildren", "_tabsContentChildren", "_viewsContentChildren"], never, true, never>;
}
declare class DxSchedulerModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxSchedulerModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxSchedulerModule, never, [typeof DxSchedulerComponent, typeof i1.DxoAppointmentDraggingModule, typeof i1.DxoEditingModule, typeof i1.DxiResourceModule, typeof i1.DxoScrollingModule, typeof i1.DxiViewModule, typeof i2.DxoSchedulerAIOptionsModule, typeof i2.DxoSchedulerAppointmentDraggingModule, typeof i2.DxiSchedulerAsyncRuleModule, typeof i2.DxiSchedulerButtonItemModule, typeof i2.DxoSchedulerButtonOptionsModule, typeof i2.DxoSchedulerColCountByScreenModule, typeof i2.DxiSchedulerCompareRuleModule, typeof i2.DxiSchedulerCustomRuleModule, typeof i2.DxoSchedulerEditingModule, typeof i2.DxiSchedulerEmailRuleModule, typeof i2.DxiSchedulerEmptyItemModule, typeof i2.DxoSchedulerFormModule, typeof i2.DxiSchedulerGroupItemModule, typeof i2.DxiSchedulerItemModule, typeof i2.DxoSchedulerLabelModule, typeof i2.DxiSchedulerNumericRuleModule, typeof i2.DxoSchedulerOptionsModule, typeof i2.DxiSchedulerOptionsItemModule, typeof i2.DxiSchedulerPatternRuleModule, typeof i2.DxiSchedulerRangeRuleModule, typeof i2.DxiSchedulerRequiredRuleModule, typeof i2.DxiSchedulerResourceModule, typeof i2.DxoSchedulerScrollingModule, typeof i2.DxiSchedulerSimpleItemModule, typeof i2.DxiSchedulerStringLengthRuleModule, typeof i2.DxiSchedulerTabModule, typeof i2.DxiSchedulerTabbedItemModule, typeof i2.DxoSchedulerTabPanelOptionsModule, typeof i2.DxiSchedulerTabPanelOptionsItemModule, typeof i2.DxoSchedulerToolbarModule, typeof i2.DxiSchedulerToolbarItemModule, typeof i2.DxiSchedulerValidationRuleModule, typeof i2.DxiSchedulerViewModule, typeof i3.DxIntegrationModule, typeof i3.DxTemplateModule], [typeof DxSchedulerComponent, typeof i1.DxoAppointmentDraggingModule, typeof i1.DxoEditingModule, typeof i1.DxiResourceModule, typeof i1.DxoScrollingModule, typeof i1.DxiViewModule, typeof i2.DxoSchedulerAIOptionsModule, typeof i2.DxoSchedulerAppointmentDraggingModule, typeof i2.DxiSchedulerAsyncRuleModule, typeof i2.DxiSchedulerButtonItemModule, typeof i2.DxoSchedulerButtonOptionsModule, typeof i2.DxoSchedulerColCountByScreenModule, typeof i2.DxiSchedulerCompareRuleModule, typeof i2.DxiSchedulerCustomRuleModule, typeof i2.DxoSchedulerEditingModule, typeof i2.DxiSchedulerEmailRuleModule, typeof i2.DxiSchedulerEmptyItemModule, typeof i2.DxoSchedulerFormModule, typeof i2.DxiSchedulerGroupItemModule, typeof i2.DxiSchedulerItemModule, typeof i2.DxoSchedulerLabelModule, typeof i2.DxiSchedulerNumericRuleModule, typeof i2.DxoSchedulerOptionsModule, typeof i2.DxiSchedulerOptionsItemModule, typeof i2.DxiSchedulerPatternRuleModule, typeof i2.DxiSchedulerRangeRuleModule, typeof i2.DxiSchedulerRequiredRuleModule, typeof i2.DxiSchedulerResourceModule, typeof i2.DxoSchedulerScrollingModule, typeof i2.DxiSchedulerSimpleItemModule, typeof i2.DxiSchedulerStringLengthRuleModule, typeof i2.DxiSchedulerTabModule, typeof i2.DxiSchedulerTabbedItemModule, typeof i2.DxoSchedulerTabPanelOptionsModule, typeof i2.DxiSchedulerTabPanelOptionsItemModule, typeof i2.DxoSchedulerToolbarModule, typeof i2.DxiSchedulerToolbarItemModule, typeof i2.DxiSchedulerValidationRuleModule, typeof i2.DxiSchedulerViewModule, typeof i3.DxTemplateModule]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxSchedulerModule>;
}

export { DxSchedulerComponent, DxSchedulerModule };
//# sourceMappingURL=index.d.ts.map
