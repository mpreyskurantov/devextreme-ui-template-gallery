import * as i0 from '@angular/core';
import { OnDestroy, EventEmitter, ElementRef, NgZone, TransferState } from '@angular/core';
import { AnimationConfig, PositionConfig } from 'devextreme/common/core/animation';
import { event } from 'devextreme/events/events.types';
import DxToast, { ToastType, ContentReadyEvent, DisposingEvent, HiddenEvent, HidingEvent, InitializedEvent, OptionChangedEvent, ShowingEvent, ShownEvent } from 'devextreme/ui/toast';
import * as i3 from 'devextreme-angular/core';
import { DxComponent, DxTemplateHost, WatcherHelper, NestedOptionHost } from 'devextreme-angular/core';
import * as i1 from 'devextreme-angular/ui/nested';
import * as i2 from 'devextreme-angular/ui/toast/nested';
export * from 'devextreme-angular/ui/toast/nested';
import * as toast_types from 'devextreme/ui/toast_types';
export { toast_types as DxToastTypes };

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

/**
 * [descr:dxToast]

 */
declare class DxToastComponent extends DxComponent implements OnDestroy {
    instance: DxToast;
    /**
     * [descr:WidgetOptions.accessKey]
    
     */
    get accessKey(): string | undefined;
    set accessKey(value: string | undefined);
    /**
     * [descr:dxToastOptions.animation]
    
     */
    get animation(): {
        hide?: AnimationConfig;
        show?: AnimationConfig;
    };
    set animation(value: {
        hide?: AnimationConfig;
        show?: AnimationConfig;
    });
    /**
     * [descr:dxToastOptions.closeOnClick]
    
     */
    get closeOnClick(): boolean;
    set closeOnClick(value: boolean);
    /**
     * [descr:dxToastOptions.closeOnSwipe]
    
     */
    get closeOnSwipe(): boolean;
    set closeOnSwipe(value: boolean);
    /**
     * [descr:dxOverlayOptions.contentTemplate]
    
     */
    get contentTemplate(): any;
    set contentTemplate(value: any);
    /**
     * [descr:dxOverlayOptions.deferRendering]
    
     */
    get deferRendering(): boolean;
    set deferRendering(value: boolean);
    /**
     * [descr:dxToastOptions.displayTime]
    
     */
    get displayTime(): number;
    set displayTime(value: number);
    /**
     * [descr:WidgetOptions.focusStateEnabled]
    
     */
    get focusStateEnabled(): boolean;
    set focusStateEnabled(value: boolean);
    /**
     * [descr:dxToastOptions.height]
    
     */
    get height(): number | string;
    set height(value: number | string);
    /**
     * [descr:dxToastOptions.hideOnOutsideClick]
    
     */
    get hideOnOutsideClick(): boolean | ((event: event) => boolean);
    set hideOnOutsideClick(value: boolean | ((event: event) => boolean));
    /**
     * [descr:dxOverlayOptions.hideOnParentScroll]
    
     */
    get hideOnParentScroll(): boolean;
    set hideOnParentScroll(value: boolean);
    /**
     * [descr:WidgetOptions.hint]
    
     */
    get hint(): string | undefined;
    set hint(value: string | undefined);
    /**
     * [descr:WidgetOptions.hoverStateEnabled]
    
     */
    get hoverStateEnabled(): boolean;
    set hoverStateEnabled(value: boolean);
    /**
     * [descr:dxOverlayOptions.maxHeight]
    
     */
    get maxHeight(): number | string;
    set maxHeight(value: number | string);
    /**
     * [descr:dxToastOptions.maxWidth]
    
     */
    get maxWidth(): number | string;
    set maxWidth(value: number | string);
    /**
     * [descr:dxToastOptions.message]
    
     */
    get message(): string;
    set message(value: string);
    /**
     * [descr:dxOverlayOptions.minHeight]
    
     */
    get minHeight(): number | string;
    set minHeight(value: number | string);
    /**
     * [descr:dxToastOptions.minWidth]
    
     */
    get minWidth(): number | string;
    set minWidth(value: number | string);
    /**
     * [descr:dxToastOptions.position]
    
     */
    get position(): PositionConfig | string;
    set position(value: PositionConfig | string);
    /**
     * [descr:DOMComponentOptions.rtlEnabled]
    
     */
    get rtlEnabled(): boolean;
    set rtlEnabled(value: boolean);
    /**
     * [descr:dxToastOptions.shading]
    
     */
    get shading(): boolean;
    set shading(value: boolean);
    /**
     * [descr:dxOverlayOptions.shadingColor]
    
     */
    get shadingColor(): string;
    set shadingColor(value: string);
    /**
     * [descr:WidgetOptions.tabIndex]
    
     */
    get tabIndex(): number;
    set tabIndex(value: number);
    /**
     * [descr:dxToastOptions.type]
    
     */
    get type(): ToastType;
    set type(value: ToastType);
    /**
     * [descr:dxOverlayOptions.visible]
    
     */
    get visible(): boolean;
    set visible(value: boolean);
    /**
     * [descr:dxToastOptions.width]
    
     */
    get width(): number | string;
    set width(value: number | string);
    /**
     * [descr:dxOverlayOptions.wrapperAttr]
    
     */
    get wrapperAttr(): any;
    set wrapperAttr(value: any);
    /**
    
     * [descr:dxToastOptions.onContentReady]
    
    
     */
    onContentReady: EventEmitter<ContentReadyEvent>;
    /**
    
     * [descr:dxToastOptions.onDisposing]
    
    
     */
    onDisposing: EventEmitter<DisposingEvent>;
    /**
    
     * [descr:dxToastOptions.onHidden]
    
    
     */
    onHidden: EventEmitter<HiddenEvent>;
    /**
    
     * [descr:dxToastOptions.onHiding]
    
    
     */
    onHiding: EventEmitter<HidingEvent>;
    /**
    
     * [descr:dxToastOptions.onInitialized]
    
    
     */
    onInitialized: EventEmitter<InitializedEvent>;
    /**
    
     * [descr:dxToastOptions.onOptionChanged]
    
    
     */
    onOptionChanged: EventEmitter<OptionChangedEvent>;
    /**
    
     * [descr:dxToastOptions.onShowing]
    
    
     */
    onShowing: EventEmitter<ShowingEvent>;
    /**
    
     * [descr:dxToastOptions.onShown]
    
    
     */
    onShown: EventEmitter<ShownEvent>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    accessKeyChange: EventEmitter<string | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    animationChange: EventEmitter<{
        hide?: AnimationConfig;
        show?: AnimationConfig;
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    closeOnClickChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    closeOnSwipeChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    contentTemplateChange: EventEmitter<any>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    deferRenderingChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    displayTimeChange: EventEmitter<number>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    focusStateEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    heightChange: EventEmitter<number | string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    hideOnOutsideClickChange: EventEmitter<boolean | ((event: event) => boolean)>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    hideOnParentScrollChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    hintChange: EventEmitter<string | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    hoverStateEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    maxHeightChange: EventEmitter<number | string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    maxWidthChange: EventEmitter<number | string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    messageChange: EventEmitter<string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    minHeightChange: EventEmitter<number | string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    minWidthChange: EventEmitter<number | string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    positionChange: EventEmitter<PositionConfig | string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    rtlEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    shadingChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    shadingColorChange: EventEmitter<string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    tabIndexChange: EventEmitter<number>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    typeChange: EventEmitter<ToastType>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    visibleChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    widthChange: EventEmitter<number | string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    wrapperAttrChange: EventEmitter<any>;
    constructor(elementRef: ElementRef, ngZone: NgZone, templateHost: DxTemplateHost, _watcherHelper: WatcherHelper, optionHost: NestedOptionHost, transferState: TransferState, platformId: any);
    protected _createInstance(element: any, options: any): DxToast;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxToastComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxToastComponent, "dx-toast", never, { "accessKey": { "alias": "accessKey"; "required": false; }; "animation": { "alias": "animation"; "required": false; }; "closeOnClick": { "alias": "closeOnClick"; "required": false; }; "closeOnSwipe": { "alias": "closeOnSwipe"; "required": false; }; "contentTemplate": { "alias": "contentTemplate"; "required": false; }; "deferRendering": { "alias": "deferRendering"; "required": false; }; "displayTime": { "alias": "displayTime"; "required": false; }; "focusStateEnabled": { "alias": "focusStateEnabled"; "required": false; }; "height": { "alias": "height"; "required": false; }; "hideOnOutsideClick": { "alias": "hideOnOutsideClick"; "required": false; }; "hideOnParentScroll": { "alias": "hideOnParentScroll"; "required": false; }; "hint": { "alias": "hint"; "required": false; }; "hoverStateEnabled": { "alias": "hoverStateEnabled"; "required": false; }; "maxHeight": { "alias": "maxHeight"; "required": false; }; "maxWidth": { "alias": "maxWidth"; "required": false; }; "message": { "alias": "message"; "required": false; }; "minHeight": { "alias": "minHeight"; "required": false; }; "minWidth": { "alias": "minWidth"; "required": false; }; "position": { "alias": "position"; "required": false; }; "rtlEnabled": { "alias": "rtlEnabled"; "required": false; }; "shading": { "alias": "shading"; "required": false; }; "shadingColor": { "alias": "shadingColor"; "required": false; }; "tabIndex": { "alias": "tabIndex"; "required": false; }; "type": { "alias": "type"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; "wrapperAttr": { "alias": "wrapperAttr"; "required": false; }; }, { "onContentReady": "onContentReady"; "onDisposing": "onDisposing"; "onHidden": "onHidden"; "onHiding": "onHiding"; "onInitialized": "onInitialized"; "onOptionChanged": "onOptionChanged"; "onShowing": "onShowing"; "onShown": "onShown"; "accessKeyChange": "accessKeyChange"; "animationChange": "animationChange"; "closeOnClickChange": "closeOnClickChange"; "closeOnSwipeChange": "closeOnSwipeChange"; "contentTemplateChange": "contentTemplateChange"; "deferRenderingChange": "deferRenderingChange"; "displayTimeChange": "displayTimeChange"; "focusStateEnabledChange": "focusStateEnabledChange"; "heightChange": "heightChange"; "hideOnOutsideClickChange": "hideOnOutsideClickChange"; "hideOnParentScrollChange": "hideOnParentScrollChange"; "hintChange": "hintChange"; "hoverStateEnabledChange": "hoverStateEnabledChange"; "maxHeightChange": "maxHeightChange"; "maxWidthChange": "maxWidthChange"; "messageChange": "messageChange"; "minHeightChange": "minHeightChange"; "minWidthChange": "minWidthChange"; "positionChange": "positionChange"; "rtlEnabledChange": "rtlEnabledChange"; "shadingChange": "shadingChange"; "shadingColorChange": "shadingColorChange"; "tabIndexChange": "tabIndexChange"; "typeChange": "typeChange"; "visibleChange": "visibleChange"; "widthChange": "widthChange"; "wrapperAttrChange": "wrapperAttrChange"; }, never, never, true, never>;
}
declare class DxToastModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxToastModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxToastModule, never, [typeof DxToastComponent, typeof i1.DxoAnimationModule, typeof i1.DxoHideModule, typeof i1.DxoFromModule, typeof i1.DxoPositionModule, typeof i1.DxoAtModule, typeof i1.DxoBoundaryOffsetModule, typeof i1.DxoCollisionModule, typeof i1.DxoMyModule, typeof i1.DxoOffsetModule, typeof i1.DxoToModule, typeof i1.DxoShowModule, typeof i2.DxoToastAnimationModule, typeof i2.DxoToastAtModule, typeof i2.DxoToastBoundaryOffsetModule, typeof i2.DxoToastCollisionModule, typeof i2.DxoToastFromModule, typeof i2.DxoToastHideModule, typeof i2.DxoToastMyModule, typeof i2.DxoToastOffsetModule, typeof i2.DxoToastPositionModule, typeof i2.DxoToastShowModule, typeof i2.DxoToastToModule, typeof i3.DxIntegrationModule, typeof i3.DxTemplateModule], [typeof DxToastComponent, typeof i1.DxoAnimationModule, typeof i1.DxoHideModule, typeof i1.DxoFromModule, typeof i1.DxoPositionModule, typeof i1.DxoAtModule, typeof i1.DxoBoundaryOffsetModule, typeof i1.DxoCollisionModule, typeof i1.DxoMyModule, typeof i1.DxoOffsetModule, typeof i1.DxoToModule, typeof i1.DxoShowModule, typeof i2.DxoToastAnimationModule, typeof i2.DxoToastAtModule, typeof i2.DxoToastBoundaryOffsetModule, typeof i2.DxoToastCollisionModule, typeof i2.DxoToastFromModule, typeof i2.DxoToastHideModule, typeof i2.DxoToastMyModule, typeof i2.DxoToastOffsetModule, typeof i2.DxoToastPositionModule, typeof i2.DxoToastShowModule, typeof i2.DxoToastToModule, typeof i3.DxTemplateModule]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxToastModule>;
}

export { DxToastComponent, DxToastModule };
//# sourceMappingURL=index.d.ts.map
