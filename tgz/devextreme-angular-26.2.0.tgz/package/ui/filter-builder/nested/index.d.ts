import { dxFilterBuilderField, FieldInfo, FilterBuilderOperation } from 'devextreme/ui/filter_builder';
import { DataType, Format as Format$1 } from 'devextreme/common';
import { CollectionNestedOption, NestedOptionHost, NestedOption } from 'devextreme-angular/core';
import * as i0 from '@angular/core';
import { OnDestroy, OnInit } from '@angular/core';
import { Format } from 'devextreme/common/core/localization';
import { DataSourceOptions } from 'devextreme/data/data_source';
import { Store } from 'devextreme/data/store';

declare class DxiFilterBuilderCustomOperationComponent extends CollectionNestedOption {
    get calculateFilterExpression(): ((filterValue: any, field: dxFilterBuilderField) => string | Function | Array<any>);
    set calculateFilterExpression(value: ((filterValue: any, field: dxFilterBuilderField) => string | Function | Array<any>));
    get caption(): string | undefined;
    set caption(value: string | undefined);
    get customizeText(): ((fieldInfo: FieldInfo) => string);
    set customizeText(value: ((fieldInfo: FieldInfo) => string));
    get dataTypes(): Array<DataType> | undefined;
    set dataTypes(value: Array<DataType> | undefined);
    get editorTemplate(): any;
    set editorTemplate(value: any);
    get hasValue(): boolean;
    set hasValue(value: boolean);
    get icon(): string | undefined;
    set icon(value: string | undefined);
    get name(): string | undefined;
    set name(value: string | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiFilterBuilderCustomOperationComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiFilterBuilderCustomOperationComponent, "dxi-filter-builder-custom-operation", never, { "calculateFilterExpression": { "alias": "calculateFilterExpression"; "required": false; }; "caption": { "alias": "caption"; "required": false; }; "customizeText": { "alias": "customizeText"; "required": false; }; "dataTypes": { "alias": "dataTypes"; "required": false; }; "editorTemplate": { "alias": "editorTemplate"; "required": false; }; "hasValue": { "alias": "hasValue"; "required": false; }; "icon": { "alias": "icon"; "required": false; }; "name": { "alias": "name"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxiFilterBuilderCustomOperationModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiFilterBuilderCustomOperationModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiFilterBuilderCustomOperationModule, never, [typeof DxiFilterBuilderCustomOperationComponent], [typeof DxiFilterBuilderCustomOperationComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiFilterBuilderCustomOperationModule>;
}

declare class DxiFilterBuilderFieldComponent extends CollectionNestedOption {
    get calculateFilterExpression(): ((filterValue: any, selectedFilterOperation: string) => string | Function | Array<any>);
    set calculateFilterExpression(value: ((filterValue: any, selectedFilterOperation: string) => string | Function | Array<any>));
    get caption(): string | undefined;
    set caption(value: string | undefined);
    get customizeText(): ((fieldInfo: FieldInfo) => string);
    set customizeText(value: ((fieldInfo: FieldInfo) => string));
    get dataField(): string | undefined;
    set dataField(value: string | undefined);
    get dataType(): DataType;
    set dataType(value: DataType);
    get editorOptions(): any;
    set editorOptions(value: any);
    get editorTemplate(): any;
    set editorTemplate(value: any);
    get falseText(): string;
    set falseText(value: string);
    get filterOperations(): Array<FilterBuilderOperation | string>;
    set filterOperations(value: Array<FilterBuilderOperation | string>);
    get format(): Format;
    set format(value: Format);
    get lookup(): {
        allowClearing?: boolean;
        dataSource?: Array<any> | DataSourceOptions | Store | undefined;
        displayExpr?: ((data: any) => string) | string | undefined;
        valueExpr?: ((data: any) => string | number | boolean) | string | undefined;
    };
    set lookup(value: {
        allowClearing?: boolean;
        dataSource?: Array<any> | DataSourceOptions | Store | undefined;
        displayExpr?: ((data: any) => string) | string | undefined;
        valueExpr?: ((data: any) => string | number | boolean) | string | undefined;
    });
    get name(): string | undefined;
    set name(value: string | undefined);
    get trueText(): string;
    set trueText(value: string);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiFilterBuilderFieldComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiFilterBuilderFieldComponent, "dxi-filter-builder-field", never, { "calculateFilterExpression": { "alias": "calculateFilterExpression"; "required": false; }; "caption": { "alias": "caption"; "required": false; }; "customizeText": { "alias": "customizeText"; "required": false; }; "dataField": { "alias": "dataField"; "required": false; }; "dataType": { "alias": "dataType"; "required": false; }; "editorOptions": { "alias": "editorOptions"; "required": false; }; "editorTemplate": { "alias": "editorTemplate"; "required": false; }; "falseText": { "alias": "falseText"; "required": false; }; "filterOperations": { "alias": "filterOperations"; "required": false; }; "format": { "alias": "format"; "required": false; }; "lookup": { "alias": "lookup"; "required": false; }; "name": { "alias": "name"; "required": false; }; "trueText": { "alias": "trueText"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxiFilterBuilderFieldModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiFilterBuilderFieldModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiFilterBuilderFieldModule, never, [typeof DxiFilterBuilderFieldComponent], [typeof DxiFilterBuilderFieldComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiFilterBuilderFieldModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoFilterBuilderFilterOperationDescriptionsComponent extends NestedOption implements OnDestroy, OnInit {
    get between(): string;
    set between(value: string);
    get contains(): string;
    set contains(value: string);
    get endsWith(): string;
    set endsWith(value: string);
    get equal(): string;
    set equal(value: string);
    get greaterThan(): string;
    set greaterThan(value: string);
    get greaterThanOrEqual(): string;
    set greaterThanOrEqual(value: string);
    get isBlank(): string;
    set isBlank(value: string);
    get isNotBlank(): string;
    set isNotBlank(value: string);
    get lessThan(): string;
    set lessThan(value: string);
    get lessThanOrEqual(): string;
    set lessThanOrEqual(value: string);
    get notContains(): string;
    set notContains(value: string);
    get notEqual(): string;
    set notEqual(value: string);
    get startsWith(): string;
    set startsWith(value: string);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoFilterBuilderFilterOperationDescriptionsComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoFilterBuilderFilterOperationDescriptionsComponent, "dxo-filter-builder-filter-operation-descriptions", never, { "between": { "alias": "between"; "required": false; }; "contains": { "alias": "contains"; "required": false; }; "endsWith": { "alias": "endsWith"; "required": false; }; "equal": { "alias": "equal"; "required": false; }; "greaterThan": { "alias": "greaterThan"; "required": false; }; "greaterThanOrEqual": { "alias": "greaterThanOrEqual"; "required": false; }; "isBlank": { "alias": "isBlank"; "required": false; }; "isNotBlank": { "alias": "isNotBlank"; "required": false; }; "lessThan": { "alias": "lessThan"; "required": false; }; "lessThanOrEqual": { "alias": "lessThanOrEqual"; "required": false; }; "notContains": { "alias": "notContains"; "required": false; }; "notEqual": { "alias": "notEqual"; "required": false; }; "startsWith": { "alias": "startsWith"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoFilterBuilderFilterOperationDescriptionsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoFilterBuilderFilterOperationDescriptionsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoFilterBuilderFilterOperationDescriptionsModule, never, [typeof DxoFilterBuilderFilterOperationDescriptionsComponent], [typeof DxoFilterBuilderFilterOperationDescriptionsComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoFilterBuilderFilterOperationDescriptionsModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoFilterBuilderFormatComponent extends NestedOption implements OnDestroy, OnInit {
    get currency(): string;
    set currency(value: string);
    get formatter(): ((value: number | Date) => string);
    set formatter(value: ((value: number | Date) => string));
    get parser(): ((value: string) => number | Date);
    set parser(value: ((value: string) => number | Date));
    get precision(): number;
    set precision(value: number);
    get type(): Format$1 | string;
    set type(value: Format$1 | string);
    get useCurrencyAccountingStyle(): boolean;
    set useCurrencyAccountingStyle(value: boolean);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoFilterBuilderFormatComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoFilterBuilderFormatComponent, "dxo-filter-builder-format", never, { "currency": { "alias": "currency"; "required": false; }; "formatter": { "alias": "formatter"; "required": false; }; "parser": { "alias": "parser"; "required": false; }; "precision": { "alias": "precision"; "required": false; }; "type": { "alias": "type"; "required": false; }; "useCurrencyAccountingStyle": { "alias": "useCurrencyAccountingStyle"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoFilterBuilderFormatModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoFilterBuilderFormatModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoFilterBuilderFormatModule, never, [typeof DxoFilterBuilderFormatComponent], [typeof DxoFilterBuilderFormatComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoFilterBuilderFormatModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoFilterBuilderGroupOperationDescriptionsComponent extends NestedOption implements OnDestroy, OnInit {
    get and(): string;
    set and(value: string);
    get notAnd(): string;
    set notAnd(value: string);
    get notOr(): string;
    set notOr(value: string);
    get or(): string;
    set or(value: string);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoFilterBuilderGroupOperationDescriptionsComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoFilterBuilderGroupOperationDescriptionsComponent, "dxo-filter-builder-group-operation-descriptions", never, { "and": { "alias": "and"; "required": false; }; "notAnd": { "alias": "notAnd"; "required": false; }; "notOr": { "alias": "notOr"; "required": false; }; "or": { "alias": "or"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoFilterBuilderGroupOperationDescriptionsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoFilterBuilderGroupOperationDescriptionsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoFilterBuilderGroupOperationDescriptionsModule, never, [typeof DxoFilterBuilderGroupOperationDescriptionsComponent], [typeof DxoFilterBuilderGroupOperationDescriptionsComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoFilterBuilderGroupOperationDescriptionsModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoFilterBuilderLookupComponent extends NestedOption implements OnDestroy, OnInit {
    get allowClearing(): boolean;
    set allowClearing(value: boolean);
    get dataSource(): Array<any> | DataSourceOptions | Store | undefined;
    set dataSource(value: Array<any> | DataSourceOptions | Store | undefined);
    get displayExpr(): ((data: any) => string) | string | undefined;
    set displayExpr(value: ((data: any) => string) | string | undefined);
    get valueExpr(): ((data: any) => string | number | boolean) | string | undefined;
    set valueExpr(value: ((data: any) => string | number | boolean) | string | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoFilterBuilderLookupComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoFilterBuilderLookupComponent, "dxo-filter-builder-lookup", never, { "allowClearing": { "alias": "allowClearing"; "required": false; }; "dataSource": { "alias": "dataSource"; "required": false; }; "displayExpr": { "alias": "displayExpr"; "required": false; }; "valueExpr": { "alias": "valueExpr"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoFilterBuilderLookupModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoFilterBuilderLookupModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoFilterBuilderLookupModule, never, [typeof DxoFilterBuilderLookupComponent], [typeof DxoFilterBuilderLookupComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoFilterBuilderLookupModule>;
}

export { DxiFilterBuilderCustomOperationComponent, DxiFilterBuilderCustomOperationModule, DxiFilterBuilderFieldComponent, DxiFilterBuilderFieldModule, DxoFilterBuilderFilterOperationDescriptionsComponent, DxoFilterBuilderFilterOperationDescriptionsModule, DxoFilterBuilderFormatComponent, DxoFilterBuilderFormatModule, DxoFilterBuilderGroupOperationDescriptionsComponent, DxoFilterBuilderGroupOperationDescriptionsModule, DxoFilterBuilderLookupComponent, DxoFilterBuilderLookupModule };
//# sourceMappingURL=index.d.ts.map
