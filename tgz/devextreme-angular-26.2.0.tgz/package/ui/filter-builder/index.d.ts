import * as i0 from '@angular/core';
import { OnDestroy, OnChanges, DoCheck, QueryList, EventEmitter, ElementRef, NgZone, TransferState, SimpleChanges } from '@angular/core';
import DxFilterBuilder, { dxFilterBuilderCustomOperation, dxFilterBuilderField, GroupOperation, ContentReadyEvent, DisposingEvent, EditorPreparedEvent, EditorPreparingEvent, InitializedEvent, OptionChangedEvent, ValueChangedEvent } from 'devextreme/ui/filter_builder';
import { ControlValueAccessor } from '@angular/forms';
import * as i3 from 'devextreme-angular/core';
import { DxComponent, CollectionNestedOption, DxTemplateHost, WatcherHelper, IterableDifferHelper, NestedOptionHost } from 'devextreme-angular/core';
import * as i1 from 'devextreme-angular/ui/nested';
import * as i2 from 'devextreme-angular/ui/filter-builder/nested';
export * from 'devextreme-angular/ui/filter-builder/nested';
import * as filter_builder_types from 'devextreme/ui/filter_builder_types';
export { filter_builder_types as DxFilterBuilderTypes };

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

/**
 * [descr:dxFilterBuilder]

 */
declare class DxFilterBuilderComponent extends DxComponent implements OnDestroy, ControlValueAccessor, OnChanges, DoCheck {
    private _watcherHelper;
    private _idh;
    set _customOperationsContentChildren(value: QueryList<CollectionNestedOption>);
    set _fieldsContentChildren(value: QueryList<CollectionNestedOption>);
    instance: DxFilterBuilder;
    /**
     * [descr:WidgetOptions.accessKey]
    
     */
    get accessKey(): string | undefined;
    set accessKey(value: string | undefined);
    /**
     * [descr:WidgetOptions.activeStateEnabled]
    
     */
    get activeStateEnabled(): boolean;
    set activeStateEnabled(value: boolean);
    /**
     * [descr:dxFilterBuilderOptions.allowHierarchicalFields]
    
     */
    get allowHierarchicalFields(): boolean;
    set allowHierarchicalFields(value: boolean);
    /**
     * [descr:dxFilterBuilderOptions.customOperations]
    
     */
    get customOperations(): Array<dxFilterBuilderCustomOperation>;
    set customOperations(value: Array<dxFilterBuilderCustomOperation>);
    /**
     * [descr:WidgetOptions.disabled]
    
     */
    get disabled(): boolean;
    set disabled(value: boolean);
    /**
     * [descr:DOMComponentOptions.elementAttr]
    
     */
    get elementAttr(): Record<string, any>;
    set elementAttr(value: Record<string, any>);
    /**
     * [descr:dxFilterBuilderOptions.fields]
    
     */
    get fields(): Array<dxFilterBuilderField>;
    set fields(value: Array<dxFilterBuilderField>);
    /**
     * [descr:dxFilterBuilderOptions.filterOperationDescriptions]
    
     */
    get filterOperationDescriptions(): {
        between?: string;
        contains?: string;
        endsWith?: string;
        equal?: string;
        greaterThan?: string;
        greaterThanOrEqual?: string;
        isBlank?: string;
        isNotBlank?: string;
        lessThan?: string;
        lessThanOrEqual?: string;
        notContains?: string;
        notEqual?: string;
        startsWith?: string;
    };
    set filterOperationDescriptions(value: {
        between?: string;
        contains?: string;
        endsWith?: string;
        equal?: string;
        greaterThan?: string;
        greaterThanOrEqual?: string;
        isBlank?: string;
        isNotBlank?: string;
        lessThan?: string;
        lessThanOrEqual?: string;
        notContains?: string;
        notEqual?: string;
        startsWith?: string;
    });
    /**
     * [descr:WidgetOptions.focusStateEnabled]
    
     */
    get focusStateEnabled(): boolean;
    set focusStateEnabled(value: boolean);
    /**
     * [descr:dxFilterBuilderOptions.groupOperationDescriptions]
    
     */
    get groupOperationDescriptions(): {
        and?: string;
        notAnd?: string;
        notOr?: string;
        or?: string;
    };
    set groupOperationDescriptions(value: {
        and?: string;
        notAnd?: string;
        notOr?: string;
        or?: string;
    });
    /**
     * [descr:dxFilterBuilderOptions.groupOperations]
    
     */
    get groupOperations(): Array<GroupOperation>;
    set groupOperations(value: Array<GroupOperation>);
    /**
     * [descr:DOMComponentOptions.height]
    
     */
    get height(): number | string | undefined;
    set height(value: number | string | undefined);
    /**
     * [descr:WidgetOptions.hint]
    
     */
    get hint(): string | undefined;
    set hint(value: string | undefined);
    /**
     * [descr:WidgetOptions.hoverStateEnabled]
    
     */
    get hoverStateEnabled(): boolean;
    set hoverStateEnabled(value: boolean);
    /**
     * [descr:dxFilterBuilderOptions.maxGroupLevel]
    
     */
    get maxGroupLevel(): number | undefined;
    set maxGroupLevel(value: number | undefined);
    /**
     * [descr:DOMComponentOptions.rtlEnabled]
    
     */
    get rtlEnabled(): boolean;
    set rtlEnabled(value: boolean);
    /**
     * [descr:WidgetOptions.tabIndex]
    
     */
    get tabIndex(): number;
    set tabIndex(value: number);
    /**
     * [descr:dxFilterBuilderOptions.value]
    
     */
    get value(): Array<any> | Function | string;
    set value(value: Array<any> | Function | string);
    /**
     * [descr:WidgetOptions.visible]
    
     */
    get visible(): boolean;
    set visible(value: boolean);
    /**
     * [descr:DOMComponentOptions.width]
    
     */
    get width(): number | string | undefined;
    set width(value: number | string | undefined);
    /**
    
     * [descr:dxFilterBuilderOptions.onContentReady]
    
    
     */
    onContentReady: EventEmitter<ContentReadyEvent>;
    /**
    
     * [descr:dxFilterBuilderOptions.onDisposing]
    
    
     */
    onDisposing: EventEmitter<DisposingEvent>;
    /**
    
     * [descr:dxFilterBuilderOptions.onEditorPrepared]
    
    
     */
    onEditorPrepared: EventEmitter<EditorPreparedEvent>;
    /**
    
     * [descr:dxFilterBuilderOptions.onEditorPreparing]
    
    
     */
    onEditorPreparing: EventEmitter<EditorPreparingEvent>;
    /**
    
     * [descr:dxFilterBuilderOptions.onInitialized]
    
    
     */
    onInitialized: EventEmitter<InitializedEvent>;
    /**
    
     * [descr:dxFilterBuilderOptions.onOptionChanged]
    
    
     */
    onOptionChanged: EventEmitter<OptionChangedEvent>;
    /**
    
     * [descr:dxFilterBuilderOptions.onValueChanged]
    
    
     */
    onValueChanged: EventEmitter<ValueChangedEvent>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    accessKeyChange: EventEmitter<string | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    activeStateEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    allowHierarchicalFieldsChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    customOperationsChange: EventEmitter<Array<dxFilterBuilderCustomOperation>>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    disabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    elementAttrChange: EventEmitter<Record<string, any>>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    fieldsChange: EventEmitter<Array<dxFilterBuilderField>>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    filterOperationDescriptionsChange: EventEmitter<{
        between?: string;
        contains?: string;
        endsWith?: string;
        equal?: string;
        greaterThan?: string;
        greaterThanOrEqual?: string;
        isBlank?: string;
        isNotBlank?: string;
        lessThan?: string;
        lessThanOrEqual?: string;
        notContains?: string;
        notEqual?: string;
        startsWith?: string;
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    focusStateEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    groupOperationDescriptionsChange: EventEmitter<{
        and?: string;
        notAnd?: string;
        notOr?: string;
        or?: string;
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    groupOperationsChange: EventEmitter<Array<GroupOperation>>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    heightChange: EventEmitter<number | string | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    hintChange: EventEmitter<string | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    hoverStateEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    maxGroupLevelChange: EventEmitter<number | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    rtlEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    tabIndexChange: EventEmitter<number>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    valueChange: EventEmitter<Array<any> | Function | string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    visibleChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    widthChange: EventEmitter<number | string | undefined>;
    /**
    
     * [descr:undefined]
    
    
     */
    onBlur: EventEmitter<any>;
    change(_: any): void;
    touched: (_: any) => void;
    constructor(elementRef: ElementRef, ngZone: NgZone, templateHost: DxTemplateHost, _watcherHelper: WatcherHelper, _idh: IterableDifferHelper, optionHost: NestedOptionHost, transferState: TransferState, platformId: any);
    protected _createInstance(element: any, options: any): DxFilterBuilder;
    writeValue(value: any): void;
    setDisabledState(isDisabled: boolean): void;
    registerOnChange(fn: (_: any) => void): void;
    registerOnTouched(fn: () => void): void;
    _createWidget(element: any): void;
    ngOnDestroy(): void;
    ngOnChanges(changes: SimpleChanges): void;
    setupChanges(prop: string, changes: SimpleChanges): void;
    ngDoCheck(): void;
    _setOption(name: string, value: any): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxFilterBuilderComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxFilterBuilderComponent, "dx-filter-builder", never, { "accessKey": { "alias": "accessKey"; "required": false; }; "activeStateEnabled": { "alias": "activeStateEnabled"; "required": false; }; "allowHierarchicalFields": { "alias": "allowHierarchicalFields"; "required": false; }; "customOperations": { "alias": "customOperations"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "elementAttr": { "alias": "elementAttr"; "required": false; }; "fields": { "alias": "fields"; "required": false; }; "filterOperationDescriptions": { "alias": "filterOperationDescriptions"; "required": false; }; "focusStateEnabled": { "alias": "focusStateEnabled"; "required": false; }; "groupOperationDescriptions": { "alias": "groupOperationDescriptions"; "required": false; }; "groupOperations": { "alias": "groupOperations"; "required": false; }; "height": { "alias": "height"; "required": false; }; "hint": { "alias": "hint"; "required": false; }; "hoverStateEnabled": { "alias": "hoverStateEnabled"; "required": false; }; "maxGroupLevel": { "alias": "maxGroupLevel"; "required": false; }; "rtlEnabled": { "alias": "rtlEnabled"; "required": false; }; "tabIndex": { "alias": "tabIndex"; "required": false; }; "value": { "alias": "value"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, { "onContentReady": "onContentReady"; "onDisposing": "onDisposing"; "onEditorPrepared": "onEditorPrepared"; "onEditorPreparing": "onEditorPreparing"; "onInitialized": "onInitialized"; "onOptionChanged": "onOptionChanged"; "onValueChanged": "onValueChanged"; "accessKeyChange": "accessKeyChange"; "activeStateEnabledChange": "activeStateEnabledChange"; "allowHierarchicalFieldsChange": "allowHierarchicalFieldsChange"; "customOperationsChange": "customOperationsChange"; "disabledChange": "disabledChange"; "elementAttrChange": "elementAttrChange"; "fieldsChange": "fieldsChange"; "filterOperationDescriptionsChange": "filterOperationDescriptionsChange"; "focusStateEnabledChange": "focusStateEnabledChange"; "groupOperationDescriptionsChange": "groupOperationDescriptionsChange"; "groupOperationsChange": "groupOperationsChange"; "heightChange": "heightChange"; "hintChange": "hintChange"; "hoverStateEnabledChange": "hoverStateEnabledChange"; "maxGroupLevelChange": "maxGroupLevelChange"; "rtlEnabledChange": "rtlEnabledChange"; "tabIndexChange": "tabIndexChange"; "valueChange": "valueChange"; "visibleChange": "visibleChange"; "widthChange": "widthChange"; "onBlur": "onBlur"; }, ["_customOperationsContentChildren", "_fieldsContentChildren"], never, true, never>;
}
declare class DxFilterBuilderModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxFilterBuilderModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxFilterBuilderModule, never, [typeof DxFilterBuilderComponent, typeof i1.DxiCustomOperationModule, typeof i1.DxiFieldModule, typeof i1.DxoFormatModule, typeof i1.DxoLookupModule, typeof i1.DxoFilterOperationDescriptionsModule, typeof i1.DxoGroupOperationDescriptionsModule, typeof i2.DxiFilterBuilderCustomOperationModule, typeof i2.DxiFilterBuilderFieldModule, typeof i2.DxoFilterBuilderFilterOperationDescriptionsModule, typeof i2.DxoFilterBuilderFormatModule, typeof i2.DxoFilterBuilderGroupOperationDescriptionsModule, typeof i2.DxoFilterBuilderLookupModule, typeof i3.DxIntegrationModule, typeof i3.DxTemplateModule], [typeof DxFilterBuilderComponent, typeof i1.DxiCustomOperationModule, typeof i1.DxiFieldModule, typeof i1.DxoFormatModule, typeof i1.DxoLookupModule, typeof i1.DxoFilterOperationDescriptionsModule, typeof i1.DxoGroupOperationDescriptionsModule, typeof i2.DxiFilterBuilderCustomOperationModule, typeof i2.DxiFilterBuilderFieldModule, typeof i2.DxoFilterBuilderFilterOperationDescriptionsModule, typeof i2.DxoFilterBuilderFormatModule, typeof i2.DxoFilterBuilderGroupOperationDescriptionsModule, typeof i2.DxoFilterBuilderLookupModule, typeof i3.DxTemplateModule]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxFilterBuilderModule>;
}

export { DxFilterBuilderComponent, DxFilterBuilderModule };
//# sourceMappingURL=index.d.ts.map
