import * as i0 from '@angular/core';
import { OnDestroy, OnChanges, DoCheck, QueryList, EventEmitter, ElementRef, NgZone, TransferState, SimpleChanges } from '@angular/core';
import DxDiagram, { AutoZoomMode, Command, CustomCommand, ShapeCategory, ToolboxDisplayMode, ShapeType, ConnectorLineEnd, ConnectorLineType, DataLayoutType, PanelVisibility, Units, ContentReadyEvent, CustomCommandEvent, DisposingEvent, InitializedEvent, ItemClickEvent, ItemDblClickEvent, OptionChangedEvent, RequestEditOperationEvent, RequestLayoutUpdateEvent, SelectionChangedEvent } from 'devextreme/ui/diagram';
import DataSource, { DataSourceOptions } from 'devextreme/data/data_source';
import { Store } from 'devextreme/data/store';
import { Orientation, PageOrientation } from 'devextreme/common';
import * as i3 from 'devextreme-angular/core';
import { DxComponent, CollectionNestedOption, DxTemplateHost, WatcherHelper, IterableDifferHelper, NestedOptionHost } from 'devextreme-angular/core';
import * as i1 from 'devextreme-angular/ui/nested';
import * as i2 from 'devextreme-angular/ui/diagram/nested';
export * from 'devextreme-angular/ui/diagram/nested';
import * as diagram_types from 'devextreme/ui/diagram_types';
export { diagram_types as DxDiagramTypes };

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

/**
 * [descr:dxDiagram]

 */
declare class DxDiagramComponent extends DxComponent implements OnDestroy, OnChanges, DoCheck {
    private _watcherHelper;
    private _idh;
    set _commandsContentChildren(value: QueryList<CollectionNestedOption>);
    set _itemsContentChildren(value: QueryList<CollectionNestedOption>);
    set _connectionPointsContentChildren(value: QueryList<CollectionNestedOption>);
    set _customShapesContentChildren(value: QueryList<CollectionNestedOption>);
    set _groupsContentChildren(value: QueryList<CollectionNestedOption>);
    set _tabsContentChildren(value: QueryList<CollectionNestedOption>);
    instance: DxDiagram;
    /**
     * [descr:dxDiagramOptions.autoZoomMode]
    
     */
    get autoZoomMode(): AutoZoomMode;
    set autoZoomMode(value: AutoZoomMode);
    /**
     * [descr:dxDiagramOptions.contextMenu]
    
     */
    get contextMenu(): {
        commands?: Array<Command | CustomCommand>;
        enabled?: boolean;
    };
    set contextMenu(value: {
        commands?: Array<Command | CustomCommand>;
        enabled?: boolean;
    });
    /**
     * [descr:dxDiagramOptions.contextToolbox]
    
     */
    get contextToolbox(): {
        category?: ShapeCategory | string;
        displayMode?: ToolboxDisplayMode;
        enabled?: boolean;
        shapeIconsPerRow?: number;
        shapes?: Array<ShapeType | string>;
        width?: number;
    };
    set contextToolbox(value: {
        category?: ShapeCategory | string;
        displayMode?: ToolboxDisplayMode;
        enabled?: boolean;
        shapeIconsPerRow?: number;
        shapes?: Array<ShapeType | string>;
        width?: number;
    });
    /**
     * [descr:dxDiagramOptions.customShapes]
    
     */
    get customShapes(): {
        allowEditImage?: boolean;
        allowEditText?: boolean;
        allowResize?: boolean;
        backgroundImageHeight?: number;
        backgroundImageLeft?: number;
        backgroundImageToolboxUrl?: string;
        backgroundImageTop?: number;
        backgroundImageUrl?: string;
        backgroundImageWidth?: number;
        baseType?: ShapeType | string;
        category?: string;
        connectionPoints?: {
            x?: number;
            y?: number;
        }[];
        defaultHeight?: number;
        defaultImageUrl?: string;
        defaultText?: string;
        defaultWidth?: number;
        imageHeight?: number;
        imageLeft?: number;
        imageTop?: number;
        imageWidth?: number;
        keepRatioOnAutoSize?: boolean;
        maxHeight?: number;
        maxWidth?: number;
        minHeight?: number;
        minWidth?: number;
        template?: any;
        templateHeight?: any;
        templateLeft?: any;
        templateTop?: any;
        templateWidth?: any;
        textHeight?: number;
        textLeft?: number;
        textTop?: number;
        textWidth?: number;
        title?: string;
        toolboxTemplate?: any;
        toolboxWidthToHeightRatio?: number;
        type?: string;
    }[];
    set customShapes(value: {
        allowEditImage?: boolean;
        allowEditText?: boolean;
        allowResize?: boolean;
        backgroundImageHeight?: number;
        backgroundImageLeft?: number;
        backgroundImageToolboxUrl?: string;
        backgroundImageTop?: number;
        backgroundImageUrl?: string;
        backgroundImageWidth?: number;
        baseType?: ShapeType | string;
        category?: string;
        connectionPoints?: {
            x?: number;
            y?: number;
        }[];
        defaultHeight?: number;
        defaultImageUrl?: string;
        defaultText?: string;
        defaultWidth?: number;
        imageHeight?: number;
        imageLeft?: number;
        imageTop?: number;
        imageWidth?: number;
        keepRatioOnAutoSize?: boolean;
        maxHeight?: number;
        maxWidth?: number;
        minHeight?: number;
        minWidth?: number;
        template?: any;
        templateHeight?: any;
        templateLeft?: any;
        templateTop?: any;
        templateWidth?: any;
        textHeight?: number;
        textLeft?: number;
        textTop?: number;
        textWidth?: number;
        title?: string;
        toolboxTemplate?: any;
        toolboxWidthToHeightRatio?: number;
        type?: string;
    }[]);
    /**
     * [descr:dxDiagramOptions.customShapeTemplate]
    
     */
    get customShapeTemplate(): any;
    set customShapeTemplate(value: any);
    /**
     * [descr:dxDiagramOptions.customShapeToolboxTemplate]
    
     */
    get customShapeToolboxTemplate(): any;
    set customShapeToolboxTemplate(value: any);
    /**
     * [descr:dxDiagramOptions.defaultItemProperties]
    
     */
    get defaultItemProperties(): {
        connectorLineEnd?: ConnectorLineEnd;
        connectorLineStart?: ConnectorLineEnd;
        connectorLineType?: ConnectorLineType;
        shapeMaxHeight?: number | undefined;
        shapeMaxWidth?: number | undefined;
        shapeMinHeight?: number | undefined;
        shapeMinWidth?: number | undefined;
        style?: Record<string, any>;
        textStyle?: Record<string, any>;
    };
    set defaultItemProperties(value: {
        connectorLineEnd?: ConnectorLineEnd;
        connectorLineStart?: ConnectorLineEnd;
        connectorLineType?: ConnectorLineType;
        shapeMaxHeight?: number | undefined;
        shapeMaxWidth?: number | undefined;
        shapeMinHeight?: number | undefined;
        shapeMinWidth?: number | undefined;
        style?: Record<string, any>;
        textStyle?: Record<string, any>;
    });
    /**
     * [descr:WidgetOptions.disabled]
    
     */
    get disabled(): boolean;
    set disabled(value: boolean);
    /**
     * [descr:dxDiagramOptions.edges]
    
     */
    get edges(): {
        customDataExpr?: ((data: any, value: any) => any) | string | undefined;
        dataSource?: Array<any> | DataSource | DataSourceOptions | null | Store | string;
        fromExpr?: ((data: any, value: any) => any) | string;
        fromLineEndExpr?: ((data: any, value: any) => any) | string | undefined;
        fromPointIndexExpr?: ((data: any, value: any) => any) | string | undefined;
        keyExpr?: ((data: any, value: any) => any) | string;
        lineTypeExpr?: ((data: any, value: any) => any) | string | undefined;
        lockedExpr?: ((data: any, value: any) => any) | string | undefined;
        pointsExpr?: ((data: any, value: any) => any) | string | undefined;
        styleExpr?: ((data: any, value: any) => any) | string | undefined;
        textExpr?: ((data: any, value: any) => any) | string | undefined;
        textStyleExpr?: ((data: any, value: any) => any) | string | undefined;
        toExpr?: ((data: any, value: any) => any) | string;
        toLineEndExpr?: ((data: any, value: any) => any) | string | undefined;
        toPointIndexExpr?: ((data: any, value: any) => any) | string | undefined;
        zIndexExpr?: ((data: any, value: any) => any) | string | undefined;
    };
    set edges(value: {
        customDataExpr?: ((data: any, value: any) => any) | string | undefined;
        dataSource?: Array<any> | DataSource | DataSourceOptions | null | Store | string;
        fromExpr?: ((data: any, value: any) => any) | string;
        fromLineEndExpr?: ((data: any, value: any) => any) | string | undefined;
        fromPointIndexExpr?: ((data: any, value: any) => any) | string | undefined;
        keyExpr?: ((data: any, value: any) => any) | string;
        lineTypeExpr?: ((data: any, value: any) => any) | string | undefined;
        lockedExpr?: ((data: any, value: any) => any) | string | undefined;
        pointsExpr?: ((data: any, value: any) => any) | string | undefined;
        styleExpr?: ((data: any, value: any) => any) | string | undefined;
        textExpr?: ((data: any, value: any) => any) | string | undefined;
        textStyleExpr?: ((data: any, value: any) => any) | string | undefined;
        toExpr?: ((data: any, value: any) => any) | string;
        toLineEndExpr?: ((data: any, value: any) => any) | string | undefined;
        toPointIndexExpr?: ((data: any, value: any) => any) | string | undefined;
        zIndexExpr?: ((data: any, value: any) => any) | string | undefined;
    });
    /**
     * [descr:dxDiagramOptions.editing]
    
     */
    get editing(): {
        allowAddShape?: boolean;
        allowChangeConnection?: boolean;
        allowChangeConnectorPoints?: boolean;
        allowChangeConnectorText?: boolean;
        allowChangeShapeText?: boolean;
        allowDeleteConnector?: boolean;
        allowDeleteShape?: boolean;
        allowMoveShape?: boolean;
        allowResizeShape?: boolean;
    };
    set editing(value: {
        allowAddShape?: boolean;
        allowChangeConnection?: boolean;
        allowChangeConnectorPoints?: boolean;
        allowChangeConnectorText?: boolean;
        allowChangeShapeText?: boolean;
        allowDeleteConnector?: boolean;
        allowDeleteShape?: boolean;
        allowMoveShape?: boolean;
        allowResizeShape?: boolean;
    });
    /**
     * [descr:DOMComponentOptions.elementAttr]
    
     */
    get elementAttr(): Record<string, any>;
    set elementAttr(value: Record<string, any>);
    /**
     * [descr:dxDiagramOptions.export]
    
     */
    get export(): {
        fileName?: string;
    };
    set export(value: {
        fileName?: string;
    });
    /**
     * [descr:dxDiagramOptions.fullScreen]
    
     */
    get fullScreen(): boolean;
    set fullScreen(value: boolean);
    /**
     * [descr:dxDiagramOptions.gridSize]
    
     */
    get gridSize(): number | {
        items?: Array<number>;
        value?: number;
    };
    set gridSize(value: number | {
        items?: Array<number>;
        value?: number;
    });
    /**
     * [descr:dxDiagramOptions.hasChanges]
    
     */
    get hasChanges(): boolean;
    set hasChanges(value: boolean);
    /**
     * [descr:DOMComponentOptions.height]
    
     */
    get height(): number | string | undefined;
    set height(value: number | string | undefined);
    /**
     * [descr:dxDiagramOptions.historyToolbar]
    
     */
    get historyToolbar(): {
        commands?: Array<Command | CustomCommand>;
        visible?: boolean;
    };
    set historyToolbar(value: {
        commands?: Array<Command | CustomCommand>;
        visible?: boolean;
    });
    /**
     * [descr:dxDiagramOptions.mainToolbar]
    
     */
    get mainToolbar(): {
        commands?: Array<Command | CustomCommand>;
        visible?: boolean;
    };
    set mainToolbar(value: {
        commands?: Array<Command | CustomCommand>;
        visible?: boolean;
    });
    /**
     * [descr:dxDiagramOptions.nodes]
    
     */
    get nodes(): {
        autoLayout?: DataLayoutType | {
            orientation?: Orientation;
            type?: DataLayoutType;
        };
        autoSizeEnabled?: boolean;
        containerChildrenExpr?: ((data: any, value: any) => any) | string | undefined;
        containerKeyExpr?: ((data: any, value: any) => any) | string;
        customDataExpr?: ((data: any, value: any) => any) | string | undefined;
        dataSource?: Array<any> | DataSource | DataSourceOptions | null | Store | string;
        heightExpr?: ((data: any, value: any) => any) | string | undefined;
        imageUrlExpr?: ((data: any, value: any) => any) | string | undefined;
        itemsExpr?: ((data: any, value: any) => any) | string | undefined;
        keyExpr?: ((data: any, value: any) => any) | string;
        leftExpr?: ((data: any, value: any) => any) | string | undefined;
        lockedExpr?: ((data: any, value: any) => any) | string | undefined;
        parentKeyExpr?: ((data: any, value: any) => any) | string | undefined;
        styleExpr?: ((data: any, value: any) => any) | string | undefined;
        textExpr?: ((data: any, value: any) => any) | string;
        textStyleExpr?: ((data: any, value: any) => any) | string | undefined;
        topExpr?: ((data: any, value: any) => any) | string | undefined;
        typeExpr?: ((data: any, value: any) => any) | string;
        widthExpr?: ((data: any, value: any) => any) | string | undefined;
        zIndexExpr?: ((data: any, value: any) => any) | string | undefined;
    };
    set nodes(value: {
        autoLayout?: DataLayoutType | {
            orientation?: Orientation;
            type?: DataLayoutType;
        };
        autoSizeEnabled?: boolean;
        containerChildrenExpr?: ((data: any, value: any) => any) | string | undefined;
        containerKeyExpr?: ((data: any, value: any) => any) | string;
        customDataExpr?: ((data: any, value: any) => any) | string | undefined;
        dataSource?: Array<any> | DataSource | DataSourceOptions | null | Store | string;
        heightExpr?: ((data: any, value: any) => any) | string | undefined;
        imageUrlExpr?: ((data: any, value: any) => any) | string | undefined;
        itemsExpr?: ((data: any, value: any) => any) | string | undefined;
        keyExpr?: ((data: any, value: any) => any) | string;
        leftExpr?: ((data: any, value: any) => any) | string | undefined;
        lockedExpr?: ((data: any, value: any) => any) | string | undefined;
        parentKeyExpr?: ((data: any, value: any) => any) | string | undefined;
        styleExpr?: ((data: any, value: any) => any) | string | undefined;
        textExpr?: ((data: any, value: any) => any) | string;
        textStyleExpr?: ((data: any, value: any) => any) | string | undefined;
        topExpr?: ((data: any, value: any) => any) | string | undefined;
        typeExpr?: ((data: any, value: any) => any) | string;
        widthExpr?: ((data: any, value: any) => any) | string | undefined;
        zIndexExpr?: ((data: any, value: any) => any) | string | undefined;
    });
    /**
     * [descr:dxDiagramOptions.pageColor]
    
     */
    get pageColor(): string;
    set pageColor(value: string);
    /**
     * [descr:dxDiagramOptions.pageOrientation]
    
     */
    get pageOrientation(): PageOrientation;
    set pageOrientation(value: PageOrientation);
    /**
     * [descr:dxDiagramOptions.pageSize]
    
     */
    get pageSize(): {
        height?: number;
        items?: {
            height?: number;
            text?: string;
            width?: number;
        }[];
        width?: number;
    };
    set pageSize(value: {
        height?: number;
        items?: {
            height?: number;
            text?: string;
            width?: number;
        }[];
        width?: number;
    });
    /**
     * [descr:dxDiagramOptions.propertiesPanel]
    
     */
    get propertiesPanel(): {
        tabs?: {
            commands?: Array<Command | CustomCommand>;
            groups?: {
                commands?: Array<Command | CustomCommand>;
                title?: string;
            }[];
            title?: string;
        }[];
        visibility?: PanelVisibility;
    };
    set propertiesPanel(value: {
        tabs?: {
            commands?: Array<Command | CustomCommand>;
            groups?: {
                commands?: Array<Command | CustomCommand>;
                title?: string;
            }[];
            title?: string;
        }[];
        visibility?: PanelVisibility;
    });
    /**
     * [descr:dxDiagramOptions.readOnly]
    
     */
    get readOnly(): boolean;
    set readOnly(value: boolean);
    /**
     * [descr:DOMComponentOptions.rtlEnabled]
    
     */
    get rtlEnabled(): boolean;
    set rtlEnabled(value: boolean);
    /**
     * [descr:dxDiagramOptions.showGrid]
    
     */
    get showGrid(): boolean;
    set showGrid(value: boolean);
    /**
     * [descr:dxDiagramOptions.simpleView]
    
     */
    get simpleView(): boolean;
    set simpleView(value: boolean);
    /**
     * [descr:dxDiagramOptions.snapToGrid]
    
     */
    get snapToGrid(): boolean;
    set snapToGrid(value: boolean);
    /**
     * [descr:dxDiagramOptions.toolbox]
    
     */
    get toolbox(): {
        groups?: {
            category?: ShapeCategory | string;
            displayMode?: ToolboxDisplayMode;
            expanded?: boolean;
            shapes?: Array<ShapeType | string>;
            title?: string;
        }[];
        shapeIconsPerRow?: number;
        showSearch?: boolean;
        visibility?: PanelVisibility;
        width?: number | undefined;
    };
    set toolbox(value: {
        groups?: {
            category?: ShapeCategory | string;
            displayMode?: ToolboxDisplayMode;
            expanded?: boolean;
            shapes?: Array<ShapeType | string>;
            title?: string;
        }[];
        shapeIconsPerRow?: number;
        showSearch?: boolean;
        visibility?: PanelVisibility;
        width?: number | undefined;
    });
    /**
     * [descr:dxDiagramOptions.units]
    
     */
    get units(): Units;
    set units(value: Units);
    /**
     * [descr:dxDiagramOptions.useNativeScrolling]
    
     */
    get useNativeScrolling(): boolean;
    set useNativeScrolling(value: boolean);
    /**
     * [descr:dxDiagramOptions.viewToolbar]
    
     */
    get viewToolbar(): {
        commands?: Array<Command | CustomCommand>;
        visible?: boolean;
    };
    set viewToolbar(value: {
        commands?: Array<Command | CustomCommand>;
        visible?: boolean;
    });
    /**
     * [descr:dxDiagramOptions.viewUnits]
    
     */
    get viewUnits(): Units;
    set viewUnits(value: Units);
    /**
     * [descr:WidgetOptions.visible]
    
     */
    get visible(): boolean;
    set visible(value: boolean);
    /**
     * [descr:DOMComponentOptions.width]
    
     */
    get width(): number | string | undefined;
    set width(value: number | string | undefined);
    /**
     * [descr:dxDiagramOptions.zoomLevel]
    
     */
    get zoomLevel(): number | {
        items?: Array<number>;
        value?: number | undefined;
    };
    set zoomLevel(value: number | {
        items?: Array<number>;
        value?: number | undefined;
    });
    /**
    
     * [descr:dxDiagramOptions.onContentReady]
    
    
     */
    onContentReady: EventEmitter<ContentReadyEvent>;
    /**
    
     * [descr:dxDiagramOptions.onCustomCommand]
    
    
     */
    onCustomCommand: EventEmitter<CustomCommandEvent>;
    /**
    
     * [descr:dxDiagramOptions.onDisposing]
    
    
     */
    onDisposing: EventEmitter<DisposingEvent>;
    /**
    
     * [descr:dxDiagramOptions.onInitialized]
    
    
     */
    onInitialized: EventEmitter<InitializedEvent>;
    /**
    
     * [descr:dxDiagramOptions.onItemClick]
    
    
     */
    onItemClick: EventEmitter<ItemClickEvent>;
    /**
    
     * [descr:dxDiagramOptions.onItemDblClick]
    
    
     */
    onItemDblClick: EventEmitter<ItemDblClickEvent>;
    /**
    
     * [descr:dxDiagramOptions.onOptionChanged]
    
    
     */
    onOptionChanged: EventEmitter<OptionChangedEvent>;
    /**
    
     * [descr:dxDiagramOptions.onRequestEditOperation]
    
    
     */
    onRequestEditOperation: EventEmitter<RequestEditOperationEvent>;
    /**
    
     * [descr:dxDiagramOptions.onRequestLayoutUpdate]
    
    
     */
    onRequestLayoutUpdate: EventEmitter<RequestLayoutUpdateEvent>;
    /**
    
     * [descr:dxDiagramOptions.onSelectionChanged]
    
    
     */
    onSelectionChanged: EventEmitter<SelectionChangedEvent>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    autoZoomModeChange: EventEmitter<AutoZoomMode>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    contextMenuChange: EventEmitter<{
        commands?: Array<Command | CustomCommand>;
        enabled?: boolean;
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    contextToolboxChange: EventEmitter<{
        category?: ShapeCategory | string;
        displayMode?: ToolboxDisplayMode;
        enabled?: boolean;
        shapeIconsPerRow?: number;
        shapes?: Array<ShapeType | string>;
        width?: number;
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    customShapesChange: EventEmitter<{
        allowEditImage?: boolean;
        allowEditText?: boolean;
        allowResize?: boolean;
        backgroundImageHeight?: number;
        backgroundImageLeft?: number;
        backgroundImageToolboxUrl?: string;
        backgroundImageTop?: number;
        backgroundImageUrl?: string;
        backgroundImageWidth?: number;
        baseType?: ShapeType | string;
        category?: string;
        connectionPoints?: {
            x?: number;
            y?: number;
        }[];
        defaultHeight?: number;
        defaultImageUrl?: string;
        defaultText?: string;
        defaultWidth?: number;
        imageHeight?: number;
        imageLeft?: number;
        imageTop?: number;
        imageWidth?: number;
        keepRatioOnAutoSize?: boolean;
        maxHeight?: number;
        maxWidth?: number;
        minHeight?: number;
        minWidth?: number;
        template?: any;
        templateHeight?: any;
        templateLeft?: any;
        templateTop?: any;
        templateWidth?: any;
        textHeight?: number;
        textLeft?: number;
        textTop?: number;
        textWidth?: number;
        title?: string;
        toolboxTemplate?: any;
        toolboxWidthToHeightRatio?: number;
        type?: string;
    }[]>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    customShapeTemplateChange: EventEmitter<any>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    customShapeToolboxTemplateChange: EventEmitter<any>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    defaultItemPropertiesChange: EventEmitter<{
        connectorLineEnd?: ConnectorLineEnd;
        connectorLineStart?: ConnectorLineEnd;
        connectorLineType?: ConnectorLineType;
        shapeMaxHeight?: number | undefined;
        shapeMaxWidth?: number | undefined;
        shapeMinHeight?: number | undefined;
        shapeMinWidth?: number | undefined;
        style?: Record<string, any>;
        textStyle?: Record<string, any>;
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    disabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    edgesChange: EventEmitter<{
        customDataExpr?: ((data: any, value: any) => any) | string | undefined;
        dataSource?: Array<any> | DataSource | DataSourceOptions | null | Store | string;
        fromExpr?: ((data: any, value: any) => any) | string;
        fromLineEndExpr?: ((data: any, value: any) => any) | string | undefined;
        fromPointIndexExpr?: ((data: any, value: any) => any) | string | undefined;
        keyExpr?: ((data: any, value: any) => any) | string;
        lineTypeExpr?: ((data: any, value: any) => any) | string | undefined;
        lockedExpr?: ((data: any, value: any) => any) | string | undefined;
        pointsExpr?: ((data: any, value: any) => any) | string | undefined;
        styleExpr?: ((data: any, value: any) => any) | string | undefined;
        textExpr?: ((data: any, value: any) => any) | string | undefined;
        textStyleExpr?: ((data: any, value: any) => any) | string | undefined;
        toExpr?: ((data: any, value: any) => any) | string;
        toLineEndExpr?: ((data: any, value: any) => any) | string | undefined;
        toPointIndexExpr?: ((data: any, value: any) => any) | string | undefined;
        zIndexExpr?: ((data: any, value: any) => any) | string | undefined;
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    editingChange: EventEmitter<{
        allowAddShape?: boolean;
        allowChangeConnection?: boolean;
        allowChangeConnectorPoints?: boolean;
        allowChangeConnectorText?: boolean;
        allowChangeShapeText?: boolean;
        allowDeleteConnector?: boolean;
        allowDeleteShape?: boolean;
        allowMoveShape?: boolean;
        allowResizeShape?: boolean;
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    elementAttrChange: EventEmitter<Record<string, any>>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    exportChange: EventEmitter<{
        fileName?: string;
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    fullScreenChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    gridSizeChange: EventEmitter<number | {
        items?: Array<number>;
        value?: number;
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    hasChangesChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    heightChange: EventEmitter<number | string | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    historyToolbarChange: EventEmitter<{
        commands?: Array<Command | CustomCommand>;
        visible?: boolean;
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    mainToolbarChange: EventEmitter<{
        commands?: Array<Command | CustomCommand>;
        visible?: boolean;
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    nodesChange: EventEmitter<{
        autoLayout?: DataLayoutType | {
            orientation?: Orientation;
            type?: DataLayoutType;
        };
        autoSizeEnabled?: boolean;
        containerChildrenExpr?: ((data: any, value: any) => any) | string | undefined;
        containerKeyExpr?: ((data: any, value: any) => any) | string;
        customDataExpr?: ((data: any, value: any) => any) | string | undefined;
        dataSource?: Array<any> | DataSource | DataSourceOptions | null | Store | string;
        heightExpr?: ((data: any, value: any) => any) | string | undefined;
        imageUrlExpr?: ((data: any, value: any) => any) | string | undefined;
        itemsExpr?: ((data: any, value: any) => any) | string | undefined;
        keyExpr?: ((data: any, value: any) => any) | string;
        leftExpr?: ((data: any, value: any) => any) | string | undefined;
        lockedExpr?: ((data: any, value: any) => any) | string | undefined;
        parentKeyExpr?: ((data: any, value: any) => any) | string | undefined;
        styleExpr?: ((data: any, value: any) => any) | string | undefined;
        textExpr?: ((data: any, value: any) => any) | string;
        textStyleExpr?: ((data: any, value: any) => any) | string | undefined;
        topExpr?: ((data: any, value: any) => any) | string | undefined;
        typeExpr?: ((data: any, value: any) => any) | string;
        widthExpr?: ((data: any, value: any) => any) | string | undefined;
        zIndexExpr?: ((data: any, value: any) => any) | string | undefined;
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    pageColorChange: EventEmitter<string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    pageOrientationChange: EventEmitter<PageOrientation>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    pageSizeChange: EventEmitter<{
        height?: number;
        items?: {
            height?: number;
            text?: string;
            width?: number;
        }[];
        width?: number;
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    propertiesPanelChange: EventEmitter<{
        tabs?: {
            commands?: Array<Command | CustomCommand>;
            groups?: {
                commands?: Array<Command | CustomCommand>;
                title?: string;
            }[];
            title?: string;
        }[];
        visibility?: PanelVisibility;
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    readOnlyChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    rtlEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    showGridChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    simpleViewChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    snapToGridChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    toolboxChange: EventEmitter<{
        groups?: {
            category?: ShapeCategory | string;
            displayMode?: ToolboxDisplayMode;
            expanded?: boolean;
            shapes?: Array<ShapeType | string>;
            title?: string;
        }[];
        shapeIconsPerRow?: number;
        showSearch?: boolean;
        visibility?: PanelVisibility;
        width?: number | undefined;
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    unitsChange: EventEmitter<Units>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    useNativeScrollingChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    viewToolbarChange: EventEmitter<{
        commands?: Array<Command | CustomCommand>;
        visible?: boolean;
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    viewUnitsChange: EventEmitter<Units>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    visibleChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    widthChange: EventEmitter<number | string | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    zoomLevelChange: EventEmitter<number | {
        items?: Array<number>;
        value?: number | undefined;
    }>;
    constructor(elementRef: ElementRef, ngZone: NgZone, templateHost: DxTemplateHost, _watcherHelper: WatcherHelper, _idh: IterableDifferHelper, optionHost: NestedOptionHost, transferState: TransferState, platformId: any);
    protected _createInstance(element: any, options: any): DxDiagram;
    ngOnDestroy(): void;
    ngOnChanges(changes: SimpleChanges): void;
    setupChanges(prop: string, changes: SimpleChanges): void;
    ngDoCheck(): void;
    _setOption(name: string, value: any): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxDiagramComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxDiagramComponent, "dx-diagram", never, { "autoZoomMode": { "alias": "autoZoomMode"; "required": false; }; "contextMenu": { "alias": "contextMenu"; "required": false; }; "contextToolbox": { "alias": "contextToolbox"; "required": false; }; "customShapes": { "alias": "customShapes"; "required": false; }; "customShapeTemplate": { "alias": "customShapeTemplate"; "required": false; }; "customShapeToolboxTemplate": { "alias": "customShapeToolboxTemplate"; "required": false; }; "defaultItemProperties": { "alias": "defaultItemProperties"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "edges": { "alias": "edges"; "required": false; }; "editing": { "alias": "editing"; "required": false; }; "elementAttr": { "alias": "elementAttr"; "required": false; }; "export": { "alias": "export"; "required": false; }; "fullScreen": { "alias": "fullScreen"; "required": false; }; "gridSize": { "alias": "gridSize"; "required": false; }; "hasChanges": { "alias": "hasChanges"; "required": false; }; "height": { "alias": "height"; "required": false; }; "historyToolbar": { "alias": "historyToolbar"; "required": false; }; "mainToolbar": { "alias": "mainToolbar"; "required": false; }; "nodes": { "alias": "nodes"; "required": false; }; "pageColor": { "alias": "pageColor"; "required": false; }; "pageOrientation": { "alias": "pageOrientation"; "required": false; }; "pageSize": { "alias": "pageSize"; "required": false; }; "propertiesPanel": { "alias": "propertiesPanel"; "required": false; }; "readOnly": { "alias": "readOnly"; "required": false; }; "rtlEnabled": { "alias": "rtlEnabled"; "required": false; }; "showGrid": { "alias": "showGrid"; "required": false; }; "simpleView": { "alias": "simpleView"; "required": false; }; "snapToGrid": { "alias": "snapToGrid"; "required": false; }; "toolbox": { "alias": "toolbox"; "required": false; }; "units": { "alias": "units"; "required": false; }; "useNativeScrolling": { "alias": "useNativeScrolling"; "required": false; }; "viewToolbar": { "alias": "viewToolbar"; "required": false; }; "viewUnits": { "alias": "viewUnits"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; "zoomLevel": { "alias": "zoomLevel"; "required": false; }; }, { "onContentReady": "onContentReady"; "onCustomCommand": "onCustomCommand"; "onDisposing": "onDisposing"; "onInitialized": "onInitialized"; "onItemClick": "onItemClick"; "onItemDblClick": "onItemDblClick"; "onOptionChanged": "onOptionChanged"; "onRequestEditOperation": "onRequestEditOperation"; "onRequestLayoutUpdate": "onRequestLayoutUpdate"; "onSelectionChanged": "onSelectionChanged"; "autoZoomModeChange": "autoZoomModeChange"; "contextMenuChange": "contextMenuChange"; "contextToolboxChange": "contextToolboxChange"; "customShapesChange": "customShapesChange"; "customShapeTemplateChange": "customShapeTemplateChange"; "customShapeToolboxTemplateChange": "customShapeToolboxTemplateChange"; "defaultItemPropertiesChange": "defaultItemPropertiesChange"; "disabledChange": "disabledChange"; "edgesChange": "edgesChange"; "editingChange": "editingChange"; "elementAttrChange": "elementAttrChange"; "exportChange": "exportChange"; "fullScreenChange": "fullScreenChange"; "gridSizeChange": "gridSizeChange"; "hasChangesChange": "hasChangesChange"; "heightChange": "heightChange"; "historyToolbarChange": "historyToolbarChange"; "mainToolbarChange": "mainToolbarChange"; "nodesChange": "nodesChange"; "pageColorChange": "pageColorChange"; "pageOrientationChange": "pageOrientationChange"; "pageSizeChange": "pageSizeChange"; "propertiesPanelChange": "propertiesPanelChange"; "readOnlyChange": "readOnlyChange"; "rtlEnabledChange": "rtlEnabledChange"; "showGridChange": "showGridChange"; "simpleViewChange": "simpleViewChange"; "snapToGridChange": "snapToGridChange"; "toolboxChange": "toolboxChange"; "unitsChange": "unitsChange"; "useNativeScrollingChange": "useNativeScrollingChange"; "viewToolbarChange": "viewToolbarChange"; "viewUnitsChange": "viewUnitsChange"; "visibleChange": "visibleChange"; "widthChange": "widthChange"; "zoomLevelChange": "zoomLevelChange"; }, ["_commandsContentChildren", "_itemsContentChildren", "_connectionPointsContentChildren", "_customShapesContentChildren", "_groupsContentChildren", "_tabsContentChildren"], never, true, never>;
}
declare class DxDiagramModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxDiagramModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxDiagramModule, never, [typeof DxDiagramComponent, typeof i1.DxoContextMenuModule, typeof i1.DxiCommandModule, typeof i1.DxiItemModule, typeof i1.DxoContextToolboxModule, typeof i1.DxiCustomShapeModule, typeof i1.DxiConnectionPointModule, typeof i1.DxoDefaultItemPropertiesModule, typeof i1.DxoEdgesModule, typeof i1.DxoEditingModule, typeof i1.DxoExportModule, typeof i1.DxoGridSizeModule, typeof i1.DxoHistoryToolbarModule, typeof i1.DxoMainToolbarModule, typeof i1.DxoNodesModule, typeof i1.DxoAutoLayoutModule, typeof i1.DxoPageSizeModule, typeof i1.DxoPropertiesPanelModule, typeof i1.DxiTabModule, typeof i1.DxiGroupModule, typeof i1.DxoToolboxModule, typeof i1.DxoViewToolbarModule, typeof i1.DxoZoomLevelModule, typeof i2.DxoDiagramAutoLayoutModule, typeof i2.DxiDiagramCommandModule, typeof i2.DxiDiagramCommandItemModule, typeof i2.DxiDiagramConnectionPointModule, typeof i2.DxoDiagramContextMenuModule, typeof i2.DxoDiagramContextToolboxModule, typeof i2.DxiDiagramCustomShapeModule, typeof i2.DxoDiagramDefaultItemPropertiesModule, typeof i2.DxoDiagramEdgesModule, typeof i2.DxoDiagramEditingModule, typeof i2.DxoDiagramExportModule, typeof i2.DxoDiagramGridSizeModule, typeof i2.DxiDiagramGroupModule, typeof i2.DxoDiagramHistoryToolbarModule, typeof i2.DxiDiagramItemModule, typeof i2.DxoDiagramMainToolbarModule, typeof i2.DxoDiagramNodesModule, typeof i2.DxoDiagramPageSizeModule, typeof i2.DxiDiagramPageSizeItemModule, typeof i2.DxoDiagramPropertiesPanelModule, typeof i2.DxiDiagramTabModule, typeof i2.DxiDiagramTabGroupModule, typeof i2.DxoDiagramToolboxModule, typeof i2.DxiDiagramToolboxGroupModule, typeof i2.DxoDiagramViewToolbarModule, typeof i2.DxoDiagramZoomLevelModule, typeof i3.DxIntegrationModule, typeof i3.DxTemplateModule], [typeof DxDiagramComponent, typeof i1.DxoContextMenuModule, typeof i1.DxiCommandModule, typeof i1.DxiItemModule, typeof i1.DxoContextToolboxModule, typeof i1.DxiCustomShapeModule, typeof i1.DxiConnectionPointModule, typeof i1.DxoDefaultItemPropertiesModule, typeof i1.DxoEdgesModule, typeof i1.DxoEditingModule, typeof i1.DxoExportModule, typeof i1.DxoGridSizeModule, typeof i1.DxoHistoryToolbarModule, typeof i1.DxoMainToolbarModule, typeof i1.DxoNodesModule, typeof i1.DxoAutoLayoutModule, typeof i1.DxoPageSizeModule, typeof i1.DxoPropertiesPanelModule, typeof i1.DxiTabModule, typeof i1.DxiGroupModule, typeof i1.DxoToolboxModule, typeof i1.DxoViewToolbarModule, typeof i1.DxoZoomLevelModule, typeof i2.DxoDiagramAutoLayoutModule, typeof i2.DxiDiagramCommandModule, typeof i2.DxiDiagramCommandItemModule, typeof i2.DxiDiagramConnectionPointModule, typeof i2.DxoDiagramContextMenuModule, typeof i2.DxoDiagramContextToolboxModule, typeof i2.DxiDiagramCustomShapeModule, typeof i2.DxoDiagramDefaultItemPropertiesModule, typeof i2.DxoDiagramEdgesModule, typeof i2.DxoDiagramEditingModule, typeof i2.DxoDiagramExportModule, typeof i2.DxoDiagramGridSizeModule, typeof i2.DxiDiagramGroupModule, typeof i2.DxoDiagramHistoryToolbarModule, typeof i2.DxiDiagramItemModule, typeof i2.DxoDiagramMainToolbarModule, typeof i2.DxoDiagramNodesModule, typeof i2.DxoDiagramPageSizeModule, typeof i2.DxiDiagramPageSizeItemModule, typeof i2.DxoDiagramPropertiesPanelModule, typeof i2.DxiDiagramTabModule, typeof i2.DxiDiagramTabGroupModule, typeof i2.DxoDiagramToolboxModule, typeof i2.DxiDiagramToolboxGroupModule, typeof i2.DxoDiagramViewToolbarModule, typeof i2.DxoDiagramZoomLevelModule, typeof i3.DxTemplateModule]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxDiagramModule>;
}

export { DxDiagramComponent, DxDiagramModule };
//# sourceMappingURL=index.d.ts.map
