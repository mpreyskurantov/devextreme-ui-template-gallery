import * as i0 from '@angular/core';
import { OnDestroy, OnInit, QueryList, AfterViewInit, Renderer2, ElementRef, EventEmitter } from '@angular/core';
import { Orientation, ToolbarItemLocation } from 'devextreme/common';
import { DataLayoutType, Command, CustomCommand, ShapeCategory, ToolboxDisplayMode, ShapeType, ConnectorLineEnd, ConnectorLineType, PanelVisibility } from 'devextreme/ui/diagram';
import { NestedOption, NestedOptionHost, CollectionNestedOption, IDxTemplateHost, DxTemplateHost, DxTemplateDirective } from 'devextreme-angular/core';
import DataSource, { DataSourceOptions } from 'devextreme/data/data_source';
import { Store } from 'devextreme/data/store';

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoDiagramAutoLayoutComponent extends NestedOption implements OnDestroy, OnInit {
    get orientation(): Orientation;
    set orientation(value: Orientation);
    get type(): DataLayoutType;
    set type(value: DataLayoutType);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDiagramAutoLayoutComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoDiagramAutoLayoutComponent, "dxo-diagram-auto-layout", never, { "orientation": { "alias": "orientation"; "required": false; }; "type": { "alias": "type"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoDiagramAutoLayoutModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDiagramAutoLayoutModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoDiagramAutoLayoutModule, never, [typeof DxoDiagramAutoLayoutComponent], [typeof DxoDiagramAutoLayoutComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoDiagramAutoLayoutModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxiDiagramCommandComponent extends CollectionNestedOption {
    set _itemsContentChildren(value: QueryList<CollectionNestedOption>);
    get icon(): string;
    set icon(value: string);
    get items(): Array<Command | CustomCommand>;
    set items(value: Array<Command | CustomCommand>);
    get location(): ToolbarItemLocation;
    set location(value: ToolbarItemLocation);
    get name(): Command | string;
    set name(value: Command | string);
    get text(): string;
    set text(value: string);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiDiagramCommandComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiDiagramCommandComponent, "dxi-diagram-command", never, { "icon": { "alias": "icon"; "required": false; }; "items": { "alias": "items"; "required": false; }; "location": { "alias": "location"; "required": false; }; "name": { "alias": "name"; "required": false; }; "text": { "alias": "text"; "required": false; }; }, {}, ["_itemsContentChildren"], never, true, never>;
}
declare class DxiDiagramCommandModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiDiagramCommandModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiDiagramCommandModule, never, [typeof DxiDiagramCommandComponent], [typeof DxiDiagramCommandComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiDiagramCommandModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxiDiagramCommandItemComponent extends CollectionNestedOption {
    set _itemsContentChildren(value: QueryList<CollectionNestedOption>);
    get icon(): string;
    set icon(value: string);
    get items(): Array<Command | CustomCommand>;
    set items(value: Array<Command | CustomCommand>);
    get location(): ToolbarItemLocation;
    set location(value: ToolbarItemLocation);
    get name(): Command | string;
    set name(value: Command | string);
    get text(): string;
    set text(value: string);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiDiagramCommandItemComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiDiagramCommandItemComponent, "dxi-diagram-command-item", never, { "icon": { "alias": "icon"; "required": false; }; "items": { "alias": "items"; "required": false; }; "location": { "alias": "location"; "required": false; }; "name": { "alias": "name"; "required": false; }; "text": { "alias": "text"; "required": false; }; }, {}, ["_itemsContentChildren"], never, true, never>;
}
declare class DxiDiagramCommandItemModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiDiagramCommandItemModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiDiagramCommandItemModule, never, [typeof DxiDiagramCommandItemComponent], [typeof DxiDiagramCommandItemComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiDiagramCommandItemModule>;
}

declare class DxiDiagramConnectionPointComponent extends CollectionNestedOption {
    get x(): number;
    set x(value: number);
    get y(): number;
    set y(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiDiagramConnectionPointComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiDiagramConnectionPointComponent, "dxi-diagram-connection-point", never, { "x": { "alias": "x"; "required": false; }; "y": { "alias": "y"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxiDiagramConnectionPointModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiDiagramConnectionPointModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiDiagramConnectionPointModule, never, [typeof DxiDiagramConnectionPointComponent], [typeof DxiDiagramConnectionPointComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiDiagramConnectionPointModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoDiagramContextMenuComponent extends NestedOption implements OnDestroy, OnInit {
    set _commandsContentChildren(value: QueryList<CollectionNestedOption>);
    get commands(): Array<Command | CustomCommand>;
    set commands(value: Array<Command | CustomCommand>);
    get enabled(): boolean;
    set enabled(value: boolean);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDiagramContextMenuComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoDiagramContextMenuComponent, "dxo-diagram-context-menu", never, { "commands": { "alias": "commands"; "required": false; }; "enabled": { "alias": "enabled"; "required": false; }; }, {}, ["_commandsContentChildren"], never, true, never>;
}
declare class DxoDiagramContextMenuModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDiagramContextMenuModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoDiagramContextMenuModule, never, [typeof DxoDiagramContextMenuComponent], [typeof DxoDiagramContextMenuComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoDiagramContextMenuModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoDiagramContextToolboxComponent extends NestedOption implements OnDestroy, OnInit {
    get category(): ShapeCategory | string;
    set category(value: ShapeCategory | string);
    get displayMode(): ToolboxDisplayMode;
    set displayMode(value: ToolboxDisplayMode);
    get enabled(): boolean;
    set enabled(value: boolean);
    get shapeIconsPerRow(): number;
    set shapeIconsPerRow(value: number);
    get shapes(): Array<ShapeType | string>;
    set shapes(value: Array<ShapeType | string>);
    get width(): number;
    set width(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDiagramContextToolboxComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoDiagramContextToolboxComponent, "dxo-diagram-context-toolbox", never, { "category": { "alias": "category"; "required": false; }; "displayMode": { "alias": "displayMode"; "required": false; }; "enabled": { "alias": "enabled"; "required": false; }; "shapeIconsPerRow": { "alias": "shapeIconsPerRow"; "required": false; }; "shapes": { "alias": "shapes"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoDiagramContextToolboxModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDiagramContextToolboxModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoDiagramContextToolboxModule, never, [typeof DxoDiagramContextToolboxComponent], [typeof DxoDiagramContextToolboxComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoDiagramContextToolboxModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxiDiagramCustomShapeComponent extends CollectionNestedOption implements AfterViewInit, IDxTemplateHost {
    private renderer;
    private document;
    private element;
    set _connectionPointsContentChildren(value: QueryList<CollectionNestedOption>);
    get allowEditImage(): boolean;
    set allowEditImage(value: boolean);
    get allowEditText(): boolean;
    set allowEditText(value: boolean);
    get allowResize(): boolean;
    set allowResize(value: boolean);
    get backgroundImageHeight(): number;
    set backgroundImageHeight(value: number);
    get backgroundImageLeft(): number;
    set backgroundImageLeft(value: number);
    get backgroundImageToolboxUrl(): string;
    set backgroundImageToolboxUrl(value: string);
    get backgroundImageTop(): number;
    set backgroundImageTop(value: number);
    get backgroundImageUrl(): string;
    set backgroundImageUrl(value: string);
    get backgroundImageWidth(): number;
    set backgroundImageWidth(value: number);
    get baseType(): ShapeType | string;
    set baseType(value: ShapeType | string);
    get category(): string;
    set category(value: string);
    get connectionPoints(): {
        x?: number;
        y?: number;
    }[];
    set connectionPoints(value: {
        x?: number;
        y?: number;
    }[]);
    get defaultHeight(): number;
    set defaultHeight(value: number);
    get defaultImageUrl(): string;
    set defaultImageUrl(value: string);
    get defaultText(): string;
    set defaultText(value: string);
    get defaultWidth(): number;
    set defaultWidth(value: number);
    get imageHeight(): number;
    set imageHeight(value: number);
    get imageLeft(): number;
    set imageLeft(value: number);
    get imageTop(): number;
    set imageTop(value: number);
    get imageWidth(): number;
    set imageWidth(value: number);
    get keepRatioOnAutoSize(): boolean;
    set keepRatioOnAutoSize(value: boolean);
    get maxHeight(): number;
    set maxHeight(value: number);
    get maxWidth(): number;
    set maxWidth(value: number);
    get minHeight(): number;
    set minHeight(value: number);
    get minWidth(): number;
    set minWidth(value: number);
    get template(): any;
    set template(value: any);
    get templateHeight(): any;
    set templateHeight(value: any);
    get templateLeft(): any;
    set templateLeft(value: any);
    get templateTop(): any;
    set templateTop(value: any);
    get templateWidth(): any;
    set templateWidth(value: any);
    get textHeight(): number;
    set textHeight(value: number);
    get textLeft(): number;
    set textLeft(value: number);
    get textTop(): number;
    set textTop(value: number);
    get textWidth(): number;
    set textWidth(value: number);
    get title(): string;
    set title(value: string);
    get toolboxTemplate(): any;
    set toolboxTemplate(value: any);
    get toolboxWidthToHeightRatio(): number;
    set toolboxWidthToHeightRatio(value: number);
    get type(): string;
    set type(value: string);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost, renderer: Renderer2, document: any, templateHost: DxTemplateHost, element: ElementRef);
    setTemplate(template: DxTemplateDirective): void;
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiDiagramCustomShapeComponent, [{ host: true; skipSelf: true; }, { host: true; }, null, null, { host: true; }, null]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiDiagramCustomShapeComponent, "dxi-diagram-custom-shape", never, { "allowEditImage": { "alias": "allowEditImage"; "required": false; }; "allowEditText": { "alias": "allowEditText"; "required": false; }; "allowResize": { "alias": "allowResize"; "required": false; }; "backgroundImageHeight": { "alias": "backgroundImageHeight"; "required": false; }; "backgroundImageLeft": { "alias": "backgroundImageLeft"; "required": false; }; "backgroundImageToolboxUrl": { "alias": "backgroundImageToolboxUrl"; "required": false; }; "backgroundImageTop": { "alias": "backgroundImageTop"; "required": false; }; "backgroundImageUrl": { "alias": "backgroundImageUrl"; "required": false; }; "backgroundImageWidth": { "alias": "backgroundImageWidth"; "required": false; }; "baseType": { "alias": "baseType"; "required": false; }; "category": { "alias": "category"; "required": false; }; "connectionPoints": { "alias": "connectionPoints"; "required": false; }; "defaultHeight": { "alias": "defaultHeight"; "required": false; }; "defaultImageUrl": { "alias": "defaultImageUrl"; "required": false; }; "defaultText": { "alias": "defaultText"; "required": false; }; "defaultWidth": { "alias": "defaultWidth"; "required": false; }; "imageHeight": { "alias": "imageHeight"; "required": false; }; "imageLeft": { "alias": "imageLeft"; "required": false; }; "imageTop": { "alias": "imageTop"; "required": false; }; "imageWidth": { "alias": "imageWidth"; "required": false; }; "keepRatioOnAutoSize": { "alias": "keepRatioOnAutoSize"; "required": false; }; "maxHeight": { "alias": "maxHeight"; "required": false; }; "maxWidth": { "alias": "maxWidth"; "required": false; }; "minHeight": { "alias": "minHeight"; "required": false; }; "minWidth": { "alias": "minWidth"; "required": false; }; "template": { "alias": "template"; "required": false; }; "templateHeight": { "alias": "templateHeight"; "required": false; }; "templateLeft": { "alias": "templateLeft"; "required": false; }; "templateTop": { "alias": "templateTop"; "required": false; }; "templateWidth": { "alias": "templateWidth"; "required": false; }; "textHeight": { "alias": "textHeight"; "required": false; }; "textLeft": { "alias": "textLeft"; "required": false; }; "textTop": { "alias": "textTop"; "required": false; }; "textWidth": { "alias": "textWidth"; "required": false; }; "title": { "alias": "title"; "required": false; }; "toolboxTemplate": { "alias": "toolboxTemplate"; "required": false; }; "toolboxWidthToHeightRatio": { "alias": "toolboxWidthToHeightRatio"; "required": false; }; "type": { "alias": "type"; "required": false; }; }, {}, ["_connectionPointsContentChildren"], ["*"], true, never>;
}
declare class DxiDiagramCustomShapeModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiDiagramCustomShapeModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiDiagramCustomShapeModule, never, [typeof DxiDiagramCustomShapeComponent], [typeof DxiDiagramCustomShapeComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiDiagramCustomShapeModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoDiagramDefaultItemPropertiesComponent extends NestedOption implements OnDestroy, OnInit {
    get connectorLineEnd(): ConnectorLineEnd;
    set connectorLineEnd(value: ConnectorLineEnd);
    get connectorLineStart(): ConnectorLineEnd;
    set connectorLineStart(value: ConnectorLineEnd);
    get connectorLineType(): ConnectorLineType;
    set connectorLineType(value: ConnectorLineType);
    get shapeMaxHeight(): number | undefined;
    set shapeMaxHeight(value: number | undefined);
    get shapeMaxWidth(): number | undefined;
    set shapeMaxWidth(value: number | undefined);
    get shapeMinHeight(): number | undefined;
    set shapeMinHeight(value: number | undefined);
    get shapeMinWidth(): number | undefined;
    set shapeMinWidth(value: number | undefined);
    get style(): Record<string, any>;
    set style(value: Record<string, any>);
    get textStyle(): Record<string, any>;
    set textStyle(value: Record<string, any>);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDiagramDefaultItemPropertiesComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoDiagramDefaultItemPropertiesComponent, "dxo-diagram-default-item-properties", never, { "connectorLineEnd": { "alias": "connectorLineEnd"; "required": false; }; "connectorLineStart": { "alias": "connectorLineStart"; "required": false; }; "connectorLineType": { "alias": "connectorLineType"; "required": false; }; "shapeMaxHeight": { "alias": "shapeMaxHeight"; "required": false; }; "shapeMaxWidth": { "alias": "shapeMaxWidth"; "required": false; }; "shapeMinHeight": { "alias": "shapeMinHeight"; "required": false; }; "shapeMinWidth": { "alias": "shapeMinWidth"; "required": false; }; "style": { "alias": "style"; "required": false; }; "textStyle": { "alias": "textStyle"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoDiagramDefaultItemPropertiesModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDiagramDefaultItemPropertiesModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoDiagramDefaultItemPropertiesModule, never, [typeof DxoDiagramDefaultItemPropertiesComponent], [typeof DxoDiagramDefaultItemPropertiesComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoDiagramDefaultItemPropertiesModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoDiagramEdgesComponent extends NestedOption implements OnDestroy, OnInit {
    get customDataExpr(): ((data: any, value: any) => any) | string | undefined;
    set customDataExpr(value: ((data: any, value: any) => any) | string | undefined);
    get dataSource(): Array<any> | DataSource | DataSourceOptions | null | Store | string;
    set dataSource(value: Array<any> | DataSource | DataSourceOptions | null | Store | string);
    get fromExpr(): ((data: any, value: any) => any) | string;
    set fromExpr(value: ((data: any, value: any) => any) | string);
    get fromLineEndExpr(): ((data: any, value: any) => any) | string | undefined;
    set fromLineEndExpr(value: ((data: any, value: any) => any) | string | undefined);
    get fromPointIndexExpr(): ((data: any, value: any) => any) | string | undefined;
    set fromPointIndexExpr(value: ((data: any, value: any) => any) | string | undefined);
    get keyExpr(): ((data: any, value: any) => any) | string;
    set keyExpr(value: ((data: any, value: any) => any) | string);
    get lineTypeExpr(): ((data: any, value: any) => any) | string | undefined;
    set lineTypeExpr(value: ((data: any, value: any) => any) | string | undefined);
    get lockedExpr(): ((data: any, value: any) => any) | string | undefined;
    set lockedExpr(value: ((data: any, value: any) => any) | string | undefined);
    get pointsExpr(): ((data: any, value: any) => any) | string | undefined;
    set pointsExpr(value: ((data: any, value: any) => any) | string | undefined);
    get styleExpr(): ((data: any, value: any) => any) | string | undefined;
    set styleExpr(value: ((data: any, value: any) => any) | string | undefined);
    get textExpr(): ((data: any, value: any) => any) | string | undefined;
    set textExpr(value: ((data: any, value: any) => any) | string | undefined);
    get textStyleExpr(): ((data: any, value: any) => any) | string | undefined;
    set textStyleExpr(value: ((data: any, value: any) => any) | string | undefined);
    get toExpr(): ((data: any, value: any) => any) | string;
    set toExpr(value: ((data: any, value: any) => any) | string);
    get toLineEndExpr(): ((data: any, value: any) => any) | string | undefined;
    set toLineEndExpr(value: ((data: any, value: any) => any) | string | undefined);
    get toPointIndexExpr(): ((data: any, value: any) => any) | string | undefined;
    set toPointIndexExpr(value: ((data: any, value: any) => any) | string | undefined);
    get zIndexExpr(): ((data: any, value: any) => any) | string | undefined;
    set zIndexExpr(value: ((data: any, value: any) => any) | string | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDiagramEdgesComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoDiagramEdgesComponent, "dxo-diagram-edges", never, { "customDataExpr": { "alias": "customDataExpr"; "required": false; }; "dataSource": { "alias": "dataSource"; "required": false; }; "fromExpr": { "alias": "fromExpr"; "required": false; }; "fromLineEndExpr": { "alias": "fromLineEndExpr"; "required": false; }; "fromPointIndexExpr": { "alias": "fromPointIndexExpr"; "required": false; }; "keyExpr": { "alias": "keyExpr"; "required": false; }; "lineTypeExpr": { "alias": "lineTypeExpr"; "required": false; }; "lockedExpr": { "alias": "lockedExpr"; "required": false; }; "pointsExpr": { "alias": "pointsExpr"; "required": false; }; "styleExpr": { "alias": "styleExpr"; "required": false; }; "textExpr": { "alias": "textExpr"; "required": false; }; "textStyleExpr": { "alias": "textStyleExpr"; "required": false; }; "toExpr": { "alias": "toExpr"; "required": false; }; "toLineEndExpr": { "alias": "toLineEndExpr"; "required": false; }; "toPointIndexExpr": { "alias": "toPointIndexExpr"; "required": false; }; "zIndexExpr": { "alias": "zIndexExpr"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoDiagramEdgesModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDiagramEdgesModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoDiagramEdgesModule, never, [typeof DxoDiagramEdgesComponent], [typeof DxoDiagramEdgesComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoDiagramEdgesModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoDiagramEditingComponent extends NestedOption implements OnDestroy, OnInit {
    get allowAddShape(): boolean;
    set allowAddShape(value: boolean);
    get allowChangeConnection(): boolean;
    set allowChangeConnection(value: boolean);
    get allowChangeConnectorPoints(): boolean;
    set allowChangeConnectorPoints(value: boolean);
    get allowChangeConnectorText(): boolean;
    set allowChangeConnectorText(value: boolean);
    get allowChangeShapeText(): boolean;
    set allowChangeShapeText(value: boolean);
    get allowDeleteConnector(): boolean;
    set allowDeleteConnector(value: boolean);
    get allowDeleteShape(): boolean;
    set allowDeleteShape(value: boolean);
    get allowMoveShape(): boolean;
    set allowMoveShape(value: boolean);
    get allowResizeShape(): boolean;
    set allowResizeShape(value: boolean);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDiagramEditingComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoDiagramEditingComponent, "dxo-diagram-editing", never, { "allowAddShape": { "alias": "allowAddShape"; "required": false; }; "allowChangeConnection": { "alias": "allowChangeConnection"; "required": false; }; "allowChangeConnectorPoints": { "alias": "allowChangeConnectorPoints"; "required": false; }; "allowChangeConnectorText": { "alias": "allowChangeConnectorText"; "required": false; }; "allowChangeShapeText": { "alias": "allowChangeShapeText"; "required": false; }; "allowDeleteConnector": { "alias": "allowDeleteConnector"; "required": false; }; "allowDeleteShape": { "alias": "allowDeleteShape"; "required": false; }; "allowMoveShape": { "alias": "allowMoveShape"; "required": false; }; "allowResizeShape": { "alias": "allowResizeShape"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoDiagramEditingModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDiagramEditingModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoDiagramEditingModule, never, [typeof DxoDiagramEditingComponent], [typeof DxoDiagramEditingComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoDiagramEditingModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoDiagramExportComponent extends NestedOption implements OnDestroy, OnInit {
    get fileName(): string;
    set fileName(value: string);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDiagramExportComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoDiagramExportComponent, "dxo-diagram-export", never, { "fileName": { "alias": "fileName"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoDiagramExportModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDiagramExportModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoDiagramExportModule, never, [typeof DxoDiagramExportComponent], [typeof DxoDiagramExportComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoDiagramExportModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoDiagramGridSizeComponent extends NestedOption implements OnDestroy, OnInit {
    get items(): Array<number>;
    set items(value: Array<number>);
    get value(): number;
    set value(value: number);
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    valueChange: EventEmitter<number>;
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDiagramGridSizeComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoDiagramGridSizeComponent, "dxo-diagram-grid-size", never, { "items": { "alias": "items"; "required": false; }; "value": { "alias": "value"; "required": false; }; }, { "valueChange": "valueChange"; }, never, never, true, never>;
}
declare class DxoDiagramGridSizeModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDiagramGridSizeModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoDiagramGridSizeModule, never, [typeof DxoDiagramGridSizeComponent], [typeof DxoDiagramGridSizeComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoDiagramGridSizeModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxiDiagramGroupComponent extends CollectionNestedOption {
    set _commandsContentChildren(value: QueryList<CollectionNestedOption>);
    get commands(): Array<Command | CustomCommand>;
    set commands(value: Array<Command | CustomCommand>);
    get title(): string;
    set title(value: string);
    get category(): ShapeCategory | string;
    set category(value: ShapeCategory | string);
    get displayMode(): ToolboxDisplayMode;
    set displayMode(value: ToolboxDisplayMode);
    get expanded(): boolean;
    set expanded(value: boolean);
    get shapes(): Array<ShapeType | string>;
    set shapes(value: Array<ShapeType | string>);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiDiagramGroupComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiDiagramGroupComponent, "dxi-diagram-group", never, { "commands": { "alias": "commands"; "required": false; }; "title": { "alias": "title"; "required": false; }; "category": { "alias": "category"; "required": false; }; "displayMode": { "alias": "displayMode"; "required": false; }; "expanded": { "alias": "expanded"; "required": false; }; "shapes": { "alias": "shapes"; "required": false; }; }, {}, ["_commandsContentChildren"], never, true, never>;
}
declare class DxiDiagramGroupModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiDiagramGroupModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiDiagramGroupModule, never, [typeof DxiDiagramGroupComponent], [typeof DxiDiagramGroupComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiDiagramGroupModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoDiagramHistoryToolbarComponent extends NestedOption implements OnDestroy, OnInit {
    set _commandsContentChildren(value: QueryList<CollectionNestedOption>);
    get commands(): Array<Command | CustomCommand>;
    set commands(value: Array<Command | CustomCommand>);
    get visible(): boolean;
    set visible(value: boolean);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDiagramHistoryToolbarComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoDiagramHistoryToolbarComponent, "dxo-diagram-history-toolbar", never, { "commands": { "alias": "commands"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; }, {}, ["_commandsContentChildren"], never, true, never>;
}
declare class DxoDiagramHistoryToolbarModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDiagramHistoryToolbarModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoDiagramHistoryToolbarModule, never, [typeof DxoDiagramHistoryToolbarComponent], [typeof DxoDiagramHistoryToolbarComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoDiagramHistoryToolbarModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxiDiagramItemComponent extends CollectionNestedOption {
    set _itemsContentChildren(value: QueryList<CollectionNestedOption>);
    get icon(): string;
    set icon(value: string);
    get items(): Array<Command | CustomCommand>;
    set items(value: Array<Command | CustomCommand>);
    get location(): ToolbarItemLocation;
    set location(value: ToolbarItemLocation);
    get name(): Command | string;
    set name(value: Command | string);
    get text(): string;
    set text(value: string);
    get height(): number;
    set height(value: number);
    get width(): number;
    set width(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiDiagramItemComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiDiagramItemComponent, "dxi-diagram-item", never, { "icon": { "alias": "icon"; "required": false; }; "items": { "alias": "items"; "required": false; }; "location": { "alias": "location"; "required": false; }; "name": { "alias": "name"; "required": false; }; "text": { "alias": "text"; "required": false; }; "height": { "alias": "height"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, ["_itemsContentChildren"], never, true, never>;
}
declare class DxiDiagramItemModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiDiagramItemModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiDiagramItemModule, never, [typeof DxiDiagramItemComponent], [typeof DxiDiagramItemComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiDiagramItemModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoDiagramMainToolbarComponent extends NestedOption implements OnDestroy, OnInit {
    set _commandsContentChildren(value: QueryList<CollectionNestedOption>);
    get commands(): Array<Command | CustomCommand>;
    set commands(value: Array<Command | CustomCommand>);
    get visible(): boolean;
    set visible(value: boolean);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDiagramMainToolbarComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoDiagramMainToolbarComponent, "dxo-diagram-main-toolbar", never, { "commands": { "alias": "commands"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; }, {}, ["_commandsContentChildren"], never, true, never>;
}
declare class DxoDiagramMainToolbarModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDiagramMainToolbarModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoDiagramMainToolbarModule, never, [typeof DxoDiagramMainToolbarComponent], [typeof DxoDiagramMainToolbarComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoDiagramMainToolbarModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoDiagramNodesComponent extends NestedOption implements OnDestroy, OnInit {
    get autoLayout(): DataLayoutType | {
        orientation?: Orientation;
        type?: DataLayoutType;
    };
    set autoLayout(value: DataLayoutType | {
        orientation?: Orientation;
        type?: DataLayoutType;
    });
    get autoSizeEnabled(): boolean;
    set autoSizeEnabled(value: boolean);
    get containerChildrenExpr(): ((data: any, value: any) => any) | string | undefined;
    set containerChildrenExpr(value: ((data: any, value: any) => any) | string | undefined);
    get containerKeyExpr(): ((data: any, value: any) => any) | string;
    set containerKeyExpr(value: ((data: any, value: any) => any) | string);
    get customDataExpr(): ((data: any, value: any) => any) | string | undefined;
    set customDataExpr(value: ((data: any, value: any) => any) | string | undefined);
    get dataSource(): Array<any> | DataSource | DataSourceOptions | null | Store | string;
    set dataSource(value: Array<any> | DataSource | DataSourceOptions | null | Store | string);
    get heightExpr(): ((data: any, value: any) => any) | string | undefined;
    set heightExpr(value: ((data: any, value: any) => any) | string | undefined);
    get imageUrlExpr(): ((data: any, value: any) => any) | string | undefined;
    set imageUrlExpr(value: ((data: any, value: any) => any) | string | undefined);
    get itemsExpr(): ((data: any, value: any) => any) | string | undefined;
    set itemsExpr(value: ((data: any, value: any) => any) | string | undefined);
    get keyExpr(): ((data: any, value: any) => any) | string;
    set keyExpr(value: ((data: any, value: any) => any) | string);
    get leftExpr(): ((data: any, value: any) => any) | string | undefined;
    set leftExpr(value: ((data: any, value: any) => any) | string | undefined);
    get lockedExpr(): ((data: any, value: any) => any) | string | undefined;
    set lockedExpr(value: ((data: any, value: any) => any) | string | undefined);
    get parentKeyExpr(): ((data: any, value: any) => any) | string | undefined;
    set parentKeyExpr(value: ((data: any, value: any) => any) | string | undefined);
    get styleExpr(): ((data: any, value: any) => any) | string | undefined;
    set styleExpr(value: ((data: any, value: any) => any) | string | undefined);
    get textExpr(): ((data: any, value: any) => any) | string;
    set textExpr(value: ((data: any, value: any) => any) | string);
    get textStyleExpr(): ((data: any, value: any) => any) | string | undefined;
    set textStyleExpr(value: ((data: any, value: any) => any) | string | undefined);
    get topExpr(): ((data: any, value: any) => any) | string | undefined;
    set topExpr(value: ((data: any, value: any) => any) | string | undefined);
    get typeExpr(): ((data: any, value: any) => any) | string;
    set typeExpr(value: ((data: any, value: any) => any) | string);
    get widthExpr(): ((data: any, value: any) => any) | string | undefined;
    set widthExpr(value: ((data: any, value: any) => any) | string | undefined);
    get zIndexExpr(): ((data: any, value: any) => any) | string | undefined;
    set zIndexExpr(value: ((data: any, value: any) => any) | string | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDiagramNodesComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoDiagramNodesComponent, "dxo-diagram-nodes", never, { "autoLayout": { "alias": "autoLayout"; "required": false; }; "autoSizeEnabled": { "alias": "autoSizeEnabled"; "required": false; }; "containerChildrenExpr": { "alias": "containerChildrenExpr"; "required": false; }; "containerKeyExpr": { "alias": "containerKeyExpr"; "required": false; }; "customDataExpr": { "alias": "customDataExpr"; "required": false; }; "dataSource": { "alias": "dataSource"; "required": false; }; "heightExpr": { "alias": "heightExpr"; "required": false; }; "imageUrlExpr": { "alias": "imageUrlExpr"; "required": false; }; "itemsExpr": { "alias": "itemsExpr"; "required": false; }; "keyExpr": { "alias": "keyExpr"; "required": false; }; "leftExpr": { "alias": "leftExpr"; "required": false; }; "lockedExpr": { "alias": "lockedExpr"; "required": false; }; "parentKeyExpr": { "alias": "parentKeyExpr"; "required": false; }; "styleExpr": { "alias": "styleExpr"; "required": false; }; "textExpr": { "alias": "textExpr"; "required": false; }; "textStyleExpr": { "alias": "textStyleExpr"; "required": false; }; "topExpr": { "alias": "topExpr"; "required": false; }; "typeExpr": { "alias": "typeExpr"; "required": false; }; "widthExpr": { "alias": "widthExpr"; "required": false; }; "zIndexExpr": { "alias": "zIndexExpr"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoDiagramNodesModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDiagramNodesModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoDiagramNodesModule, never, [typeof DxoDiagramNodesComponent], [typeof DxoDiagramNodesComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoDiagramNodesModule>;
}

declare class DxiDiagramPageSizeItemComponent extends CollectionNestedOption {
    get height(): number;
    set height(value: number);
    get text(): string;
    set text(value: string);
    get width(): number;
    set width(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiDiagramPageSizeItemComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiDiagramPageSizeItemComponent, "dxi-diagram-page-size-item", never, { "height": { "alias": "height"; "required": false; }; "text": { "alias": "text"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxiDiagramPageSizeItemModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiDiagramPageSizeItemModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiDiagramPageSizeItemModule, never, [typeof DxiDiagramPageSizeItemComponent], [typeof DxiDiagramPageSizeItemComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiDiagramPageSizeItemModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoDiagramPageSizeComponent extends NestedOption implements OnDestroy, OnInit {
    set _itemsContentChildren(value: QueryList<CollectionNestedOption>);
    get height(): number;
    set height(value: number);
    get items(): {
        height?: number;
        text?: string;
        width?: number;
    }[];
    set items(value: {
        height?: number;
        text?: string;
        width?: number;
    }[]);
    get width(): number;
    set width(value: number);
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    heightChange: EventEmitter<number>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    widthChange: EventEmitter<number>;
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDiagramPageSizeComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoDiagramPageSizeComponent, "dxo-diagram-page-size", never, { "height": { "alias": "height"; "required": false; }; "items": { "alias": "items"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, { "heightChange": "heightChange"; "widthChange": "widthChange"; }, ["_itemsContentChildren"], never, true, never>;
}
declare class DxoDiagramPageSizeModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDiagramPageSizeModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoDiagramPageSizeModule, never, [typeof DxoDiagramPageSizeComponent], [typeof DxoDiagramPageSizeComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoDiagramPageSizeModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoDiagramPropertiesPanelComponent extends NestedOption implements OnDestroy, OnInit {
    set _tabsContentChildren(value: QueryList<CollectionNestedOption>);
    get tabs(): {
        commands?: Array<Command | CustomCommand>;
        groups?: {
            commands?: Array<Command | CustomCommand>;
            title?: string;
        }[];
        title?: string;
    }[];
    set tabs(value: {
        commands?: Array<Command | CustomCommand>;
        groups?: {
            commands?: Array<Command | CustomCommand>;
            title?: string;
        }[];
        title?: string;
    }[]);
    get visibility(): PanelVisibility;
    set visibility(value: PanelVisibility);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDiagramPropertiesPanelComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoDiagramPropertiesPanelComponent, "dxo-diagram-properties-panel", never, { "tabs": { "alias": "tabs"; "required": false; }; "visibility": { "alias": "visibility"; "required": false; }; }, {}, ["_tabsContentChildren"], never, true, never>;
}
declare class DxoDiagramPropertiesPanelModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDiagramPropertiesPanelModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoDiagramPropertiesPanelModule, never, [typeof DxoDiagramPropertiesPanelComponent], [typeof DxoDiagramPropertiesPanelComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoDiagramPropertiesPanelModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxiDiagramTabComponent extends CollectionNestedOption {
    set _commandsContentChildren(value: QueryList<CollectionNestedOption>);
    set _groupsContentChildren(value: QueryList<CollectionNestedOption>);
    get commands(): Array<Command | CustomCommand>;
    set commands(value: Array<Command | CustomCommand>);
    get groups(): {
        commands?: Array<Command | CustomCommand>;
        title?: string;
    }[];
    set groups(value: {
        commands?: Array<Command | CustomCommand>;
        title?: string;
    }[]);
    get title(): string;
    set title(value: string);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiDiagramTabComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiDiagramTabComponent, "dxi-diagram-tab", never, { "commands": { "alias": "commands"; "required": false; }; "groups": { "alias": "groups"; "required": false; }; "title": { "alias": "title"; "required": false; }; }, {}, ["_commandsContentChildren", "_groupsContentChildren"], never, true, never>;
}
declare class DxiDiagramTabModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiDiagramTabModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiDiagramTabModule, never, [typeof DxiDiagramTabComponent], [typeof DxiDiagramTabComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiDiagramTabModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxiDiagramTabGroupComponent extends CollectionNestedOption {
    set _commandsContentChildren(value: QueryList<CollectionNestedOption>);
    get commands(): Array<Command | CustomCommand>;
    set commands(value: Array<Command | CustomCommand>);
    get title(): string;
    set title(value: string);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiDiagramTabGroupComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiDiagramTabGroupComponent, "dxi-diagram-tab-group", never, { "commands": { "alias": "commands"; "required": false; }; "title": { "alias": "title"; "required": false; }; }, {}, ["_commandsContentChildren"], never, true, never>;
}
declare class DxiDiagramTabGroupModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiDiagramTabGroupModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiDiagramTabGroupModule, never, [typeof DxiDiagramTabGroupComponent], [typeof DxiDiagramTabGroupComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiDiagramTabGroupModule>;
}

declare class DxiDiagramToolboxGroupComponent extends CollectionNestedOption {
    get category(): ShapeCategory | string;
    set category(value: ShapeCategory | string);
    get displayMode(): ToolboxDisplayMode;
    set displayMode(value: ToolboxDisplayMode);
    get expanded(): boolean;
    set expanded(value: boolean);
    get shapes(): Array<ShapeType | string>;
    set shapes(value: Array<ShapeType | string>);
    get title(): string;
    set title(value: string);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiDiagramToolboxGroupComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiDiagramToolboxGroupComponent, "dxi-diagram-toolbox-group", never, { "category": { "alias": "category"; "required": false; }; "displayMode": { "alias": "displayMode"; "required": false; }; "expanded": { "alias": "expanded"; "required": false; }; "shapes": { "alias": "shapes"; "required": false; }; "title": { "alias": "title"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxiDiagramToolboxGroupModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiDiagramToolboxGroupModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiDiagramToolboxGroupModule, never, [typeof DxiDiagramToolboxGroupComponent], [typeof DxiDiagramToolboxGroupComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiDiagramToolboxGroupModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoDiagramToolboxComponent extends NestedOption implements OnDestroy, OnInit {
    set _groupsContentChildren(value: QueryList<CollectionNestedOption>);
    get groups(): {
        category?: ShapeCategory | string;
        displayMode?: ToolboxDisplayMode;
        expanded?: boolean;
        shapes?: Array<ShapeType | string>;
        title?: string;
    }[];
    set groups(value: {
        category?: ShapeCategory | string;
        displayMode?: ToolboxDisplayMode;
        expanded?: boolean;
        shapes?: Array<ShapeType | string>;
        title?: string;
    }[]);
    get shapeIconsPerRow(): number;
    set shapeIconsPerRow(value: number);
    get showSearch(): boolean;
    set showSearch(value: boolean);
    get visibility(): PanelVisibility;
    set visibility(value: PanelVisibility);
    get width(): number | undefined;
    set width(value: number | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDiagramToolboxComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoDiagramToolboxComponent, "dxo-diagram-toolbox", never, { "groups": { "alias": "groups"; "required": false; }; "shapeIconsPerRow": { "alias": "shapeIconsPerRow"; "required": false; }; "showSearch": { "alias": "showSearch"; "required": false; }; "visibility": { "alias": "visibility"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, ["_groupsContentChildren"], never, true, never>;
}
declare class DxoDiagramToolboxModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDiagramToolboxModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoDiagramToolboxModule, never, [typeof DxoDiagramToolboxComponent], [typeof DxoDiagramToolboxComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoDiagramToolboxModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoDiagramViewToolbarComponent extends NestedOption implements OnDestroy, OnInit {
    set _commandsContentChildren(value: QueryList<CollectionNestedOption>);
    get commands(): Array<Command | CustomCommand>;
    set commands(value: Array<Command | CustomCommand>);
    get visible(): boolean;
    set visible(value: boolean);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDiagramViewToolbarComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoDiagramViewToolbarComponent, "dxo-diagram-view-toolbar", never, { "commands": { "alias": "commands"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; }, {}, ["_commandsContentChildren"], never, true, never>;
}
declare class DxoDiagramViewToolbarModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDiagramViewToolbarModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoDiagramViewToolbarModule, never, [typeof DxoDiagramViewToolbarComponent], [typeof DxoDiagramViewToolbarComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoDiagramViewToolbarModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoDiagramZoomLevelComponent extends NestedOption implements OnDestroy, OnInit {
    get items(): Array<number>;
    set items(value: Array<number>);
    get value(): number | undefined;
    set value(value: number | undefined);
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    valueChange: EventEmitter<number | undefined>;
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDiagramZoomLevelComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoDiagramZoomLevelComponent, "dxo-diagram-zoom-level", never, { "items": { "alias": "items"; "required": false; }; "value": { "alias": "value"; "required": false; }; }, { "valueChange": "valueChange"; }, never, never, true, never>;
}
declare class DxoDiagramZoomLevelModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDiagramZoomLevelModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoDiagramZoomLevelModule, never, [typeof DxoDiagramZoomLevelComponent], [typeof DxoDiagramZoomLevelComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoDiagramZoomLevelModule>;
}

export { DxiDiagramCommandComponent, DxiDiagramCommandItemComponent, DxiDiagramCommandItemModule, DxiDiagramCommandModule, DxiDiagramConnectionPointComponent, DxiDiagramConnectionPointModule, DxiDiagramCustomShapeComponent, DxiDiagramCustomShapeModule, DxiDiagramGroupComponent, DxiDiagramGroupModule, DxiDiagramItemComponent, DxiDiagramItemModule, DxiDiagramPageSizeItemComponent, DxiDiagramPageSizeItemModule, DxiDiagramTabComponent, DxiDiagramTabGroupComponent, DxiDiagramTabGroupModule, DxiDiagramTabModule, DxiDiagramToolboxGroupComponent, DxiDiagramToolboxGroupModule, DxoDiagramAutoLayoutComponent, DxoDiagramAutoLayoutModule, DxoDiagramContextMenuComponent, DxoDiagramContextMenuModule, DxoDiagramContextToolboxComponent, DxoDiagramContextToolboxModule, DxoDiagramDefaultItemPropertiesComponent, DxoDiagramDefaultItemPropertiesModule, DxoDiagramEdgesComponent, DxoDiagramEdgesModule, DxoDiagramEditingComponent, DxoDiagramEditingModule, DxoDiagramExportComponent, DxoDiagramExportModule, DxoDiagramGridSizeComponent, DxoDiagramGridSizeModule, DxoDiagramHistoryToolbarComponent, DxoDiagramHistoryToolbarModule, DxoDiagramMainToolbarComponent, DxoDiagramMainToolbarModule, DxoDiagramNodesComponent, DxoDiagramNodesModule, DxoDiagramPageSizeComponent, DxoDiagramPageSizeModule, DxoDiagramPropertiesPanelComponent, DxoDiagramPropertiesPanelModule, DxoDiagramToolboxComponent, DxoDiagramToolboxModule, DxoDiagramViewToolbarComponent, DxoDiagramViewToolbarModule, DxoDiagramZoomLevelComponent, DxoDiagramZoomLevelModule };
//# sourceMappingURL=index.d.ts.map
