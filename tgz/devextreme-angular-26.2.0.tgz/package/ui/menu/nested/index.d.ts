import * as i0 from '@angular/core';
import { OnDestroy, OnInit, AfterViewInit, QueryList, Renderer2, ElementRef } from '@angular/core';
import { AnimationConfig, CollisionResolution, PositionConfig, AnimationState, AnimationType, CollisionResolutionCombination } from 'devextreme/common/core/animation';
import { NestedOption, NestedOptionHost, CollectionNestedOption, IDxTemplateHost, DxTemplateHost, DxTemplateDirective } from 'devextreme-angular/core';
import { HorizontalAlignment, VerticalAlignment, Direction, PositionAlignment, SubmenuShowMode } from 'devextreme/common';
import { dxMenuItem } from 'devextreme/ui/menu';

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoMenuAnimationComponent extends NestedOption implements OnDestroy, OnInit {
    get hide(): AnimationConfig;
    set hide(value: AnimationConfig);
    get show(): AnimationConfig;
    set show(value: AnimationConfig);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoMenuAnimationComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoMenuAnimationComponent, "dxo-menu-animation", never, { "hide": { "alias": "hide"; "required": false; }; "show": { "alias": "show"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoMenuAnimationModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoMenuAnimationModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoMenuAnimationModule, never, [typeof DxoMenuAnimationComponent], [typeof DxoMenuAnimationComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoMenuAnimationModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoMenuAtComponent extends NestedOption implements OnDestroy, OnInit {
    get x(): HorizontalAlignment;
    set x(value: HorizontalAlignment);
    get y(): VerticalAlignment;
    set y(value: VerticalAlignment);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoMenuAtComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoMenuAtComponent, "dxo-menu-at", never, { "x": { "alias": "x"; "required": false; }; "y": { "alias": "y"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoMenuAtModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoMenuAtModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoMenuAtModule, never, [typeof DxoMenuAtComponent], [typeof DxoMenuAtComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoMenuAtModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoMenuBoundaryOffsetComponent extends NestedOption implements OnDestroy, OnInit {
    get x(): number;
    set x(value: number);
    get y(): number;
    set y(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoMenuBoundaryOffsetComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoMenuBoundaryOffsetComponent, "dxo-menu-boundary-offset", never, { "x": { "alias": "x"; "required": false; }; "y": { "alias": "y"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoMenuBoundaryOffsetModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoMenuBoundaryOffsetModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoMenuBoundaryOffsetModule, never, [typeof DxoMenuBoundaryOffsetComponent], [typeof DxoMenuBoundaryOffsetComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoMenuBoundaryOffsetModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoMenuCollisionComponent extends NestedOption implements OnDestroy, OnInit {
    get x(): CollisionResolution;
    set x(value: CollisionResolution);
    get y(): CollisionResolution;
    set y(value: CollisionResolution);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoMenuCollisionComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoMenuCollisionComponent, "dxo-menu-collision", never, { "x": { "alias": "x"; "required": false; }; "y": { "alias": "y"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoMenuCollisionModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoMenuCollisionModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoMenuCollisionModule, never, [typeof DxoMenuCollisionComponent], [typeof DxoMenuCollisionComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoMenuCollisionModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoMenuDelayComponent extends NestedOption implements OnDestroy, OnInit {
    get hide(): number;
    set hide(value: number);
    get show(): number;
    set show(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoMenuDelayComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoMenuDelayComponent, "dxo-menu-delay", never, { "hide": { "alias": "hide"; "required": false; }; "show": { "alias": "show"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoMenuDelayModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoMenuDelayModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoMenuDelayModule, never, [typeof DxoMenuDelayComponent], [typeof DxoMenuDelayComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoMenuDelayModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoMenuFromComponent extends NestedOption implements OnDestroy, OnInit {
    get left(): number;
    set left(value: number);
    get opacity(): number;
    set opacity(value: number);
    get position(): PositionConfig;
    set position(value: PositionConfig);
    get scale(): number;
    set scale(value: number);
    get top(): number;
    set top(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoMenuFromComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoMenuFromComponent, "dxo-menu-from", never, { "left": { "alias": "left"; "required": false; }; "opacity": { "alias": "opacity"; "required": false; }; "position": { "alias": "position"; "required": false; }; "scale": { "alias": "scale"; "required": false; }; "top": { "alias": "top"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoMenuFromModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoMenuFromModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoMenuFromModule, never, [typeof DxoMenuFromComponent], [typeof DxoMenuFromComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoMenuFromModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoMenuHideComponent extends NestedOption implements OnDestroy, OnInit {
    get complete(): (($element: any, config: AnimationConfig) => void);
    set complete(value: (($element: any, config: AnimationConfig) => void));
    get delay(): number;
    set delay(value: number);
    get direction(): Direction | undefined;
    set direction(value: Direction | undefined);
    get duration(): number;
    set duration(value: number);
    get easing(): string;
    set easing(value: string);
    get from(): AnimationState;
    set from(value: AnimationState);
    get staggerDelay(): number | undefined;
    set staggerDelay(value: number | undefined);
    get start(): (($element: any, config: AnimationConfig) => void);
    set start(value: (($element: any, config: AnimationConfig) => void));
    get to(): AnimationState;
    set to(value: AnimationState);
    get type(): AnimationType;
    set type(value: AnimationType);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoMenuHideComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoMenuHideComponent, "dxo-menu-hide", never, { "complete": { "alias": "complete"; "required": false; }; "delay": { "alias": "delay"; "required": false; }; "direction": { "alias": "direction"; "required": false; }; "duration": { "alias": "duration"; "required": false; }; "easing": { "alias": "easing"; "required": false; }; "from": { "alias": "from"; "required": false; }; "staggerDelay": { "alias": "staggerDelay"; "required": false; }; "start": { "alias": "start"; "required": false; }; "to": { "alias": "to"; "required": false; }; "type": { "alias": "type"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoMenuHideModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoMenuHideModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoMenuHideModule, never, [typeof DxoMenuHideComponent], [typeof DxoMenuHideComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoMenuHideModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxiMenuItemComponent extends CollectionNestedOption implements AfterViewInit, IDxTemplateHost {
    private renderer;
    private document;
    private element;
    set _itemsContentChildren(value: QueryList<CollectionNestedOption>);
    get beginGroup(): boolean;
    set beginGroup(value: boolean);
    get closeMenuOnClick(): boolean;
    set closeMenuOnClick(value: boolean);
    get disabled(): boolean;
    set disabled(value: boolean);
    get icon(): string;
    set icon(value: string);
    get items(): Array<dxMenuItem>;
    set items(value: Array<dxMenuItem>);
    get linkAttr(): Record<string, any>;
    set linkAttr(value: Record<string, any>);
    get selectable(): boolean;
    set selectable(value: boolean);
    get selected(): boolean;
    set selected(value: boolean);
    get template(): any;
    set template(value: any);
    get text(): string;
    set text(value: string);
    get url(): string;
    set url(value: string);
    get visible(): boolean;
    set visible(value: boolean);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost, renderer: Renderer2, document: any, templateHost: DxTemplateHost, element: ElementRef);
    setTemplate(template: DxTemplateDirective): void;
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiMenuItemComponent, [{ host: true; skipSelf: true; }, { host: true; }, null, null, { host: true; }, null]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiMenuItemComponent, "dxi-menu-item", never, { "beginGroup": { "alias": "beginGroup"; "required": false; }; "closeMenuOnClick": { "alias": "closeMenuOnClick"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "icon": { "alias": "icon"; "required": false; }; "items": { "alias": "items"; "required": false; }; "linkAttr": { "alias": "linkAttr"; "required": false; }; "selectable": { "alias": "selectable"; "required": false; }; "selected": { "alias": "selected"; "required": false; }; "template": { "alias": "template"; "required": false; }; "text": { "alias": "text"; "required": false; }; "url": { "alias": "url"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; }, {}, ["_itemsContentChildren"], ["*"], true, never>;
}
declare class DxiMenuItemModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiMenuItemModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiMenuItemModule, never, [typeof DxiMenuItemComponent], [typeof DxiMenuItemComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiMenuItemModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoMenuMyComponent extends NestedOption implements OnDestroy, OnInit {
    get x(): HorizontalAlignment;
    set x(value: HorizontalAlignment);
    get y(): VerticalAlignment;
    set y(value: VerticalAlignment);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoMenuMyComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoMenuMyComponent, "dxo-menu-my", never, { "x": { "alias": "x"; "required": false; }; "y": { "alias": "y"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoMenuMyModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoMenuMyModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoMenuMyModule, never, [typeof DxoMenuMyComponent], [typeof DxoMenuMyComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoMenuMyModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoMenuOffsetComponent extends NestedOption implements OnDestroy, OnInit {
    get x(): number;
    set x(value: number);
    get y(): number;
    set y(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoMenuOffsetComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoMenuOffsetComponent, "dxo-menu-offset", never, { "x": { "alias": "x"; "required": false; }; "y": { "alias": "y"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoMenuOffsetModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoMenuOffsetModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoMenuOffsetModule, never, [typeof DxoMenuOffsetComponent], [typeof DxoMenuOffsetComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoMenuOffsetModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoMenuPositionComponent extends NestedOption implements OnDestroy, OnInit {
    get at(): PositionAlignment | {
        x?: HorizontalAlignment;
        y?: VerticalAlignment;
    };
    set at(value: PositionAlignment | {
        x?: HorizontalAlignment;
        y?: VerticalAlignment;
    });
    get boundary(): any | string;
    set boundary(value: any | string);
    get boundaryOffset(): string | {
        x?: number;
        y?: number;
    };
    set boundaryOffset(value: string | {
        x?: number;
        y?: number;
    });
    get collision(): CollisionResolutionCombination | {
        x?: CollisionResolution;
        y?: CollisionResolution;
    };
    set collision(value: CollisionResolutionCombination | {
        x?: CollisionResolution;
        y?: CollisionResolution;
    });
    get my(): PositionAlignment | {
        x?: HorizontalAlignment;
        y?: VerticalAlignment;
    };
    set my(value: PositionAlignment | {
        x?: HorizontalAlignment;
        y?: VerticalAlignment;
    });
    get of(): any | string;
    set of(value: any | string);
    get offset(): string | {
        x?: number;
        y?: number;
    };
    set offset(value: string | {
        x?: number;
        y?: number;
    });
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoMenuPositionComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoMenuPositionComponent, "dxo-menu-position", never, { "at": { "alias": "at"; "required": false; }; "boundary": { "alias": "boundary"; "required": false; }; "boundaryOffset": { "alias": "boundaryOffset"; "required": false; }; "collision": { "alias": "collision"; "required": false; }; "my": { "alias": "my"; "required": false; }; "of": { "alias": "of"; "required": false; }; "offset": { "alias": "offset"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoMenuPositionModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoMenuPositionModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoMenuPositionModule, never, [typeof DxoMenuPositionComponent], [typeof DxoMenuPositionComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoMenuPositionModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoMenuShowFirstSubmenuModeComponent extends NestedOption implements OnDestroy, OnInit {
    get delay(): number | {
        hide?: number;
        show?: number;
    };
    set delay(value: number | {
        hide?: number;
        show?: number;
    });
    get name(): SubmenuShowMode;
    set name(value: SubmenuShowMode);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoMenuShowFirstSubmenuModeComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoMenuShowFirstSubmenuModeComponent, "dxo-menu-show-first-submenu-mode", never, { "delay": { "alias": "delay"; "required": false; }; "name": { "alias": "name"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoMenuShowFirstSubmenuModeModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoMenuShowFirstSubmenuModeModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoMenuShowFirstSubmenuModeModule, never, [typeof DxoMenuShowFirstSubmenuModeComponent], [typeof DxoMenuShowFirstSubmenuModeComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoMenuShowFirstSubmenuModeModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoMenuShowSubmenuModeComponent extends NestedOption implements OnDestroy, OnInit {
    get delay(): number | {
        hide?: number;
        show?: number;
    };
    set delay(value: number | {
        hide?: number;
        show?: number;
    });
    get name(): SubmenuShowMode;
    set name(value: SubmenuShowMode);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoMenuShowSubmenuModeComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoMenuShowSubmenuModeComponent, "dxo-menu-show-submenu-mode", never, { "delay": { "alias": "delay"; "required": false; }; "name": { "alias": "name"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoMenuShowSubmenuModeModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoMenuShowSubmenuModeModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoMenuShowSubmenuModeModule, never, [typeof DxoMenuShowSubmenuModeComponent], [typeof DxoMenuShowSubmenuModeComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoMenuShowSubmenuModeModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoMenuShowComponent extends NestedOption implements OnDestroy, OnInit {
    get complete(): (($element: any, config: AnimationConfig) => void);
    set complete(value: (($element: any, config: AnimationConfig) => void));
    get delay(): number;
    set delay(value: number);
    get direction(): Direction | undefined;
    set direction(value: Direction | undefined);
    get duration(): number;
    set duration(value: number);
    get easing(): string;
    set easing(value: string);
    get from(): AnimationState;
    set from(value: AnimationState);
    get staggerDelay(): number | undefined;
    set staggerDelay(value: number | undefined);
    get start(): (($element: any, config: AnimationConfig) => void);
    set start(value: (($element: any, config: AnimationConfig) => void));
    get to(): AnimationState;
    set to(value: AnimationState);
    get type(): AnimationType;
    set type(value: AnimationType);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoMenuShowComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoMenuShowComponent, "dxo-menu-show", never, { "complete": { "alias": "complete"; "required": false; }; "delay": { "alias": "delay"; "required": false; }; "direction": { "alias": "direction"; "required": false; }; "duration": { "alias": "duration"; "required": false; }; "easing": { "alias": "easing"; "required": false; }; "from": { "alias": "from"; "required": false; }; "staggerDelay": { "alias": "staggerDelay"; "required": false; }; "start": { "alias": "start"; "required": false; }; "to": { "alias": "to"; "required": false; }; "type": { "alias": "type"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoMenuShowModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoMenuShowModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoMenuShowModule, never, [typeof DxoMenuShowComponent], [typeof DxoMenuShowComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoMenuShowModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoMenuToComponent extends NestedOption implements OnDestroy, OnInit {
    get left(): number;
    set left(value: number);
    get opacity(): number;
    set opacity(value: number);
    get position(): PositionConfig;
    set position(value: PositionConfig);
    get scale(): number;
    set scale(value: number);
    get top(): number;
    set top(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoMenuToComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoMenuToComponent, "dxo-menu-to", never, { "left": { "alias": "left"; "required": false; }; "opacity": { "alias": "opacity"; "required": false; }; "position": { "alias": "position"; "required": false; }; "scale": { "alias": "scale"; "required": false; }; "top": { "alias": "top"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoMenuToModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoMenuToModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoMenuToModule, never, [typeof DxoMenuToComponent], [typeof DxoMenuToComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoMenuToModule>;
}

export { DxiMenuItemComponent, DxiMenuItemModule, DxoMenuAnimationComponent, DxoMenuAnimationModule, DxoMenuAtComponent, DxoMenuAtModule, DxoMenuBoundaryOffsetComponent, DxoMenuBoundaryOffsetModule, DxoMenuCollisionComponent, DxoMenuCollisionModule, DxoMenuDelayComponent, DxoMenuDelayModule, DxoMenuFromComponent, DxoMenuFromModule, DxoMenuHideComponent, DxoMenuHideModule, DxoMenuMyComponent, DxoMenuMyModule, DxoMenuOffsetComponent, DxoMenuOffsetModule, DxoMenuPositionComponent, DxoMenuPositionModule, DxoMenuShowComponent, DxoMenuShowFirstSubmenuModeComponent, DxoMenuShowFirstSubmenuModeModule, DxoMenuShowModule, DxoMenuShowSubmenuModeComponent, DxoMenuShowSubmenuModeModule, DxoMenuToComponent, DxoMenuToModule };
//# sourceMappingURL=index.d.ts.map
