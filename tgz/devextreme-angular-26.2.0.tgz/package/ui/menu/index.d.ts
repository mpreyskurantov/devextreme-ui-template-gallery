import * as i0 from '@angular/core';
import { OnDestroy, OnChanges, DoCheck, QueryList, EventEmitter, ElementRef, NgZone, TransferState, SimpleChanges } from '@angular/core';
import { AnimationConfig } from 'devextreme/common/core/animation';
import DxMenu, { dxMenuItem, SubmenuDirection, ContentReadyEvent, DisposingEvent, InitializedEvent, ItemClickEvent, ItemContextMenuEvent, ItemRenderedEvent, OptionChangedEvent, SelectionChangedEvent, SubmenuHiddenEvent, SubmenuHidingEvent, SubmenuShowingEvent, SubmenuShownEvent } from 'devextreme/ui/menu';
export { ExplicitTypes } from 'devextreme/ui/menu';
import DataSource, { DataSourceOptions } from 'devextreme/data/data_source';
import { Store } from 'devextreme/data/store';
import { Orientation, SingleOrNone, SubmenuShowMode } from 'devextreme/common';
import * as i3 from 'devextreme-angular/core';
import { DxComponent, CollectionNestedOption, DxTemplateHost, WatcherHelper, IterableDifferHelper, NestedOptionHost } from 'devextreme-angular/core';
import * as i1 from 'devextreme-angular/ui/nested';
import * as i2 from 'devextreme-angular/ui/menu/nested';
export * from 'devextreme-angular/ui/menu/nested';
import * as menu_types from 'devextreme/ui/menu_types';
export { menu_types as DxMenuTypes };

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

/**
 * [descr:dxMenu]

 */
declare class DxMenuComponent<TItem = any, TKey = any> extends DxComponent implements OnDestroy, OnChanges, DoCheck {
    private _watcherHelper;
    private _idh;
    set _itemsContentChildren(value: QueryList<CollectionNestedOption>);
    instance: DxMenu<TItem, TKey>;
    /**
     * [descr:WidgetOptions.accessKey]
    
     */
    get accessKey(): string | undefined;
    set accessKey(value: string | undefined);
    /**
     * [descr:dxMenuBaseOptions.activeStateEnabled]
    
     */
    get activeStateEnabled(): boolean;
    set activeStateEnabled(value: boolean);
    /**
     * [descr:dxMenuOptions.adaptivityEnabled]
    
     */
    get adaptivityEnabled(): boolean;
    set adaptivityEnabled(value: boolean);
    /**
     * [descr:dxMenuBaseOptions.animation]
    
     */
    get animation(): {
        hide?: AnimationConfig;
        show?: AnimationConfig;
    };
    set animation(value: {
        hide?: AnimationConfig;
        show?: AnimationConfig;
    });
    /**
     * [descr:dxMenuBaseOptions.cssClass]
    
     */
    get cssClass(): string;
    set cssClass(value: string);
    /**
     * [descr:dxMenuOptions.dataSource]
    
     */
    get dataSource(): Array<dxMenuItem> | DataSource | DataSourceOptions | null | Store | string;
    set dataSource(value: Array<dxMenuItem> | DataSource | DataSourceOptions | null | Store | string);
    /**
     * [descr:WidgetOptions.disabled]
    
     */
    get disabled(): boolean;
    set disabled(value: boolean);
    /**
     * [descr:HierarchicalCollectionWidgetOptions.disabledExpr]
    
     */
    get disabledExpr(): ((item: any) => boolean | undefined) | string;
    set disabledExpr(value: ((item: any) => boolean | undefined) | string);
    /**
     * [descr:HierarchicalCollectionWidgetOptions.displayExpr]
    
     */
    get displayExpr(): ((item: any) => string) | string;
    set displayExpr(value: ((item: any) => string) | string);
    /**
     * [descr:DOMComponentOptions.elementAttr]
    
     */
    get elementAttr(): Record<string, any>;
    set elementAttr(value: Record<string, any>);
    /**
     * [descr:HierarchicalCollectionWidgetOptions.focusStateEnabled]
    
     */
    get focusStateEnabled(): boolean;
    set focusStateEnabled(value: boolean);
    /**
     * [descr:DOMComponentOptions.height]
    
     */
    get height(): number | string | undefined;
    set height(value: number | string | undefined);
    /**
     * [descr:dxMenuOptions.hideSubmenuOnMouseLeave]
    
     */
    get hideSubmenuOnMouseLeave(): boolean;
    set hideSubmenuOnMouseLeave(value: boolean);
    /**
     * [descr:WidgetOptions.hint]
    
     */
    get hint(): string | undefined;
    set hint(value: string | undefined);
    /**
     * [descr:HierarchicalCollectionWidgetOptions.hoverStateEnabled]
    
     */
    get hoverStateEnabled(): boolean;
    set hoverStateEnabled(value: boolean);
    /**
     * [descr:dxMenuOptions.items]
    
     */
    get items(): Array<any | dxMenuItem>;
    set items(value: Array<any | dxMenuItem>);
    /**
     * [descr:HierarchicalCollectionWidgetOptions.itemsExpr]
    
     */
    get itemsExpr(): ((item: any) => Array<any> | undefined) | string;
    set itemsExpr(value: ((item: any) => Array<any> | undefined) | string);
    /**
     * [descr:CollectionWidgetOptions.itemTemplate]
    
     */
    get itemTemplate(): any;
    set itemTemplate(value: any);
    /**
     * [descr:dxMenuOptions.orientation]
    
     */
    get orientation(): Orientation;
    set orientation(value: Orientation);
    /**
     * [descr:DOMComponentOptions.rtlEnabled]
    
     */
    get rtlEnabled(): boolean;
    set rtlEnabled(value: boolean);
    /**
     * [descr:dxMenuBaseOptions.selectByClick]
    
     */
    get selectByClick(): boolean;
    set selectByClick(value: boolean);
    /**
     * [descr:HierarchicalCollectionWidgetOptions.selectedExpr]
    
     */
    get selectedExpr(): ((item: any, value: boolean | undefined) => boolean | undefined) | string;
    set selectedExpr(value: ((item: any, value: boolean | undefined) => boolean | undefined) | string);
    /**
     * [descr:CollectionWidgetOptions.selectedItem]
    
     */
    get selectedItem(): any | null;
    set selectedItem(value: any | null);
    /**
     * [descr:dxMenuBaseOptions.selectionMode]
    
     */
    get selectionMode(): SingleOrNone;
    set selectionMode(value: SingleOrNone);
    /**
     * [descr:dxMenuOptions.showFirstSubmenuMode]
    
     */
    get showFirstSubmenuMode(): SubmenuShowMode | {
        delay?: number | {
            hide?: number;
            show?: number;
        };
        name?: SubmenuShowMode;
    };
    set showFirstSubmenuMode(value: SubmenuShowMode | {
        delay?: number | {
            hide?: number;
            show?: number;
        };
        name?: SubmenuShowMode;
    });
    /**
     * [descr:dxMenuBaseOptions.showSubmenuMode]
    
     */
    get showSubmenuMode(): SubmenuShowMode | {
        delay?: number | {
            hide?: number;
            show?: number;
        };
        name?: SubmenuShowMode;
    };
    set showSubmenuMode(value: SubmenuShowMode | {
        delay?: number | {
            hide?: number;
            show?: number;
        };
        name?: SubmenuShowMode;
    });
    /**
     * [descr:dxMenuOptions.submenuDirection]
    
     */
    get submenuDirection(): SubmenuDirection;
    set submenuDirection(value: SubmenuDirection);
    /**
     * [descr:WidgetOptions.tabIndex]
    
     */
    get tabIndex(): number;
    set tabIndex(value: number);
    /**
     * [descr:WidgetOptions.visible]
    
     */
    get visible(): boolean;
    set visible(value: boolean);
    /**
     * [descr:DOMComponentOptions.width]
    
     */
    get width(): number | string | undefined;
    set width(value: number | string | undefined);
    /**
    
     * [descr:dxMenuOptions.onContentReady]
    
    
     */
    onContentReady: EventEmitter<ContentReadyEvent>;
    /**
    
     * [descr:dxMenuOptions.onDisposing]
    
    
     */
    onDisposing: EventEmitter<DisposingEvent>;
    /**
    
     * [descr:dxMenuOptions.onInitialized]
    
    
     */
    onInitialized: EventEmitter<InitializedEvent>;
    /**
    
     * [descr:dxMenuOptions.onItemClick]
    
    
     */
    onItemClick: EventEmitter<ItemClickEvent>;
    /**
    
     * [descr:dxMenuOptions.onItemContextMenu]
    
    
     */
    onItemContextMenu: EventEmitter<ItemContextMenuEvent>;
    /**
    
     * [descr:dxMenuOptions.onItemRendered]
    
    
     */
    onItemRendered: EventEmitter<ItemRenderedEvent>;
    /**
    
     * [descr:dxMenuOptions.onOptionChanged]
    
    
     */
    onOptionChanged: EventEmitter<OptionChangedEvent>;
    /**
    
     * [descr:dxMenuOptions.onSelectionChanged]
    
    
     */
    onSelectionChanged: EventEmitter<SelectionChangedEvent>;
    /**
    
     * [descr:dxMenuOptions.onSubmenuHidden]
    
    
     */
    onSubmenuHidden: EventEmitter<SubmenuHiddenEvent>;
    /**
    
     * [descr:dxMenuOptions.onSubmenuHiding]
    
    
     */
    onSubmenuHiding: EventEmitter<SubmenuHidingEvent>;
    /**
    
     * [descr:dxMenuOptions.onSubmenuShowing]
    
    
     */
    onSubmenuShowing: EventEmitter<SubmenuShowingEvent>;
    /**
    
     * [descr:dxMenuOptions.onSubmenuShown]
    
    
     */
    onSubmenuShown: EventEmitter<SubmenuShownEvent>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    accessKeyChange: EventEmitter<string | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    activeStateEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    adaptivityEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    animationChange: EventEmitter<{
        hide?: AnimationConfig;
        show?: AnimationConfig;
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    cssClassChange: EventEmitter<string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    dataSourceChange: EventEmitter<Array<dxMenuItem> | DataSource | DataSourceOptions | null | Store | string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    disabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    disabledExprChange: EventEmitter<((item: any) => boolean | undefined) | string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    displayExprChange: EventEmitter<((item: any) => string) | string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    elementAttrChange: EventEmitter<Record<string, any>>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    focusStateEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    heightChange: EventEmitter<number | string | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    hideSubmenuOnMouseLeaveChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    hintChange: EventEmitter<string | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    hoverStateEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    itemsChange: EventEmitter<Array<any | dxMenuItem>>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    itemsExprChange: EventEmitter<((item: any) => Array<any> | undefined) | string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    itemTemplateChange: EventEmitter<any>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    orientationChange: EventEmitter<Orientation>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    rtlEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    selectByClickChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    selectedExprChange: EventEmitter<((item: any, value: boolean | undefined) => boolean | undefined) | string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    selectedItemChange: EventEmitter<any | null>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    selectionModeChange: EventEmitter<SingleOrNone>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    showFirstSubmenuModeChange: EventEmitter<SubmenuShowMode | {
        delay?: number | {
            hide?: number;
            show?: number;
        };
        name?: SubmenuShowMode;
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    showSubmenuModeChange: EventEmitter<SubmenuShowMode | {
        delay?: number | {
            hide?: number;
            show?: number;
        };
        name?: SubmenuShowMode;
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    submenuDirectionChange: EventEmitter<SubmenuDirection>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    tabIndexChange: EventEmitter<number>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    visibleChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    widthChange: EventEmitter<number | string | undefined>;
    constructor(elementRef: ElementRef, ngZone: NgZone, templateHost: DxTemplateHost, _watcherHelper: WatcherHelper, _idh: IterableDifferHelper, optionHost: NestedOptionHost, transferState: TransferState, platformId: any);
    protected _createInstance(element: any, options: any): DxMenu<any, any>;
    ngOnDestroy(): void;
    ngOnChanges(changes: SimpleChanges): void;
    setupChanges(prop: string, changes: SimpleChanges): void;
    ngDoCheck(): void;
    _setOption(name: string, value: any): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxMenuComponent<any, any>, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxMenuComponent<any, any>, "dx-menu", never, { "accessKey": { "alias": "accessKey"; "required": false; }; "activeStateEnabled": { "alias": "activeStateEnabled"; "required": false; }; "adaptivityEnabled": { "alias": "adaptivityEnabled"; "required": false; }; "animation": { "alias": "animation"; "required": false; }; "cssClass": { "alias": "cssClass"; "required": false; }; "dataSource": { "alias": "dataSource"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "disabledExpr": { "alias": "disabledExpr"; "required": false; }; "displayExpr": { "alias": "displayExpr"; "required": false; }; "elementAttr": { "alias": "elementAttr"; "required": false; }; "focusStateEnabled": { "alias": "focusStateEnabled"; "required": false; }; "height": { "alias": "height"; "required": false; }; "hideSubmenuOnMouseLeave": { "alias": "hideSubmenuOnMouseLeave"; "required": false; }; "hint": { "alias": "hint"; "required": false; }; "hoverStateEnabled": { "alias": "hoverStateEnabled"; "required": false; }; "items": { "alias": "items"; "required": false; }; "itemsExpr": { "alias": "itemsExpr"; "required": false; }; "itemTemplate": { "alias": "itemTemplate"; "required": false; }; "orientation": { "alias": "orientation"; "required": false; }; "rtlEnabled": { "alias": "rtlEnabled"; "required": false; }; "selectByClick": { "alias": "selectByClick"; "required": false; }; "selectedExpr": { "alias": "selectedExpr"; "required": false; }; "selectedItem": { "alias": "selectedItem"; "required": false; }; "selectionMode": { "alias": "selectionMode"; "required": false; }; "showFirstSubmenuMode": { "alias": "showFirstSubmenuMode"; "required": false; }; "showSubmenuMode": { "alias": "showSubmenuMode"; "required": false; }; "submenuDirection": { "alias": "submenuDirection"; "required": false; }; "tabIndex": { "alias": "tabIndex"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, { "onContentReady": "onContentReady"; "onDisposing": "onDisposing"; "onInitialized": "onInitialized"; "onItemClick": "onItemClick"; "onItemContextMenu": "onItemContextMenu"; "onItemRendered": "onItemRendered"; "onOptionChanged": "onOptionChanged"; "onSelectionChanged": "onSelectionChanged"; "onSubmenuHidden": "onSubmenuHidden"; "onSubmenuHiding": "onSubmenuHiding"; "onSubmenuShowing": "onSubmenuShowing"; "onSubmenuShown": "onSubmenuShown"; "accessKeyChange": "accessKeyChange"; "activeStateEnabledChange": "activeStateEnabledChange"; "adaptivityEnabledChange": "adaptivityEnabledChange"; "animationChange": "animationChange"; "cssClassChange": "cssClassChange"; "dataSourceChange": "dataSourceChange"; "disabledChange": "disabledChange"; "disabledExprChange": "disabledExprChange"; "displayExprChange": "displayExprChange"; "elementAttrChange": "elementAttrChange"; "focusStateEnabledChange": "focusStateEnabledChange"; "heightChange": "heightChange"; "hideSubmenuOnMouseLeaveChange": "hideSubmenuOnMouseLeaveChange"; "hintChange": "hintChange"; "hoverStateEnabledChange": "hoverStateEnabledChange"; "itemsChange": "itemsChange"; "itemsExprChange": "itemsExprChange"; "itemTemplateChange": "itemTemplateChange"; "orientationChange": "orientationChange"; "rtlEnabledChange": "rtlEnabledChange"; "selectByClickChange": "selectByClickChange"; "selectedExprChange": "selectedExprChange"; "selectedItemChange": "selectedItemChange"; "selectionModeChange": "selectionModeChange"; "showFirstSubmenuModeChange": "showFirstSubmenuModeChange"; "showSubmenuModeChange": "showSubmenuModeChange"; "submenuDirectionChange": "submenuDirectionChange"; "tabIndexChange": "tabIndexChange"; "visibleChange": "visibleChange"; "widthChange": "widthChange"; }, ["_itemsContentChildren"], never, true, never>;
}
declare class DxMenuModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxMenuModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxMenuModule, never, [typeof DxMenuComponent, typeof i1.DxoAnimationModule, typeof i1.DxoHideModule, typeof i1.DxoFromModule, typeof i1.DxoPositionModule, typeof i1.DxoAtModule, typeof i1.DxoBoundaryOffsetModule, typeof i1.DxoCollisionModule, typeof i1.DxoMyModule, typeof i1.DxoOffsetModule, typeof i1.DxoToModule, typeof i1.DxoShowModule, typeof i1.DxiItemModule, typeof i1.DxoShowFirstSubmenuModeModule, typeof i1.DxoDelayModule, typeof i1.DxoShowSubmenuModeModule, typeof i2.DxoMenuAnimationModule, typeof i2.DxoMenuAtModule, typeof i2.DxoMenuBoundaryOffsetModule, typeof i2.DxoMenuCollisionModule, typeof i2.DxoMenuDelayModule, typeof i2.DxoMenuFromModule, typeof i2.DxoMenuHideModule, typeof i2.DxiMenuItemModule, typeof i2.DxoMenuMyModule, typeof i2.DxoMenuOffsetModule, typeof i2.DxoMenuPositionModule, typeof i2.DxoMenuShowModule, typeof i2.DxoMenuShowFirstSubmenuModeModule, typeof i2.DxoMenuShowSubmenuModeModule, typeof i2.DxoMenuToModule, typeof i3.DxIntegrationModule, typeof i3.DxTemplateModule], [typeof DxMenuComponent, typeof i1.DxoAnimationModule, typeof i1.DxoHideModule, typeof i1.DxoFromModule, typeof i1.DxoPositionModule, typeof i1.DxoAtModule, typeof i1.DxoBoundaryOffsetModule, typeof i1.DxoCollisionModule, typeof i1.DxoMyModule, typeof i1.DxoOffsetModule, typeof i1.DxoToModule, typeof i1.DxoShowModule, typeof i1.DxiItemModule, typeof i1.DxoShowFirstSubmenuModeModule, typeof i1.DxoDelayModule, typeof i1.DxoShowSubmenuModeModule, typeof i2.DxoMenuAnimationModule, typeof i2.DxoMenuAtModule, typeof i2.DxoMenuBoundaryOffsetModule, typeof i2.DxoMenuCollisionModule, typeof i2.DxoMenuDelayModule, typeof i2.DxoMenuFromModule, typeof i2.DxoMenuHideModule, typeof i2.DxiMenuItemModule, typeof i2.DxoMenuMyModule, typeof i2.DxoMenuOffsetModule, typeof i2.DxoMenuPositionModule, typeof i2.DxoMenuShowModule, typeof i2.DxoMenuShowFirstSubmenuModeModule, typeof i2.DxoMenuShowSubmenuModeModule, typeof i2.DxoMenuToModule, typeof i3.DxTemplateModule]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxMenuModule>;
}

export { DxMenuComponent, DxMenuModule };
//# sourceMappingURL=index.d.ts.map
