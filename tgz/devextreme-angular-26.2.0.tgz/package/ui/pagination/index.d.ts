import * as i0 from '@angular/core';
import { OnDestroy, OnChanges, DoCheck, EventEmitter, ElementRef, NgZone, TransferState, SimpleChanges } from '@angular/core';
import { DisplayMode, Mode } from 'devextreme/common';
import { EventInfo } from 'devextreme/common/core/events';
import DxPagination from 'devextreme/ui/pagination';
import * as i1 from 'devextreme-angular/core';
import { DxComponent, DxTemplateHost, WatcherHelper, IterableDifferHelper, NestedOptionHost } from 'devextreme-angular/core';
import * as pagination_types from 'devextreme/ui/pagination_types';
export { pagination_types as DxPaginationTypes };

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

/**
 * [descr:dxPagination]

 */
declare class DxPaginationComponent extends DxComponent implements OnDestroy, OnChanges, DoCheck {
    private _watcherHelper;
    private _idh;
    instance: DxPagination;
    /**
     * [descr:WidgetOptions.accessKey]
    
     */
    get accessKey(): string | undefined;
    set accessKey(value: string | undefined);
    /**
     * [descr:WidgetOptions.activeStateEnabled]
    
     */
    get activeStateEnabled(): boolean;
    set activeStateEnabled(value: boolean);
    /**
     * [descr:dxPaginationOptions.allowedPageSizes]
    
     */
    get allowedPageSizes(): Array<number | string>;
    set allowedPageSizes(value: Array<number | string>);
    /**
     * [descr:WidgetOptions.disabled]
    
     */
    get disabled(): boolean;
    set disabled(value: boolean);
    /**
     * [descr:PagerBase.displayMode]
    
     */
    get displayMode(): DisplayMode;
    set displayMode(value: DisplayMode);
    /**
     * [descr:DOMComponentOptions.elementAttr]
    
     */
    get elementAttr(): Record<string, any>;
    set elementAttr(value: Record<string, any>);
    /**
     * [descr:WidgetOptions.focusStateEnabled]
    
     */
    get focusStateEnabled(): boolean;
    set focusStateEnabled(value: boolean);
    /**
     * [descr:DOMComponentOptions.height]
    
     */
    get height(): number | string | undefined;
    set height(value: number | string | undefined);
    /**
     * [descr:WidgetOptions.hint]
    
     */
    get hint(): string | undefined;
    set hint(value: string | undefined);
    /**
     * [descr:WidgetOptions.hoverStateEnabled]
    
     */
    get hoverStateEnabled(): boolean;
    set hoverStateEnabled(value: boolean);
    /**
     * [descr:PagerBase.infoText]
    
     */
    get infoText(): string;
    set infoText(value: string);
    /**
     * [descr:dxPaginationOptions.itemCount]
    
     */
    get itemCount(): number;
    set itemCount(value: number);
    /**
     * [descr:PagerBase.label]
    
     */
    get label(): string;
    set label(value: string);
    /**
     * [descr:dxPaginationOptions.pageIndex]
    
     */
    get pageIndex(): number;
    set pageIndex(value: number);
    /**
     * [descr:dxPaginationOptions.pageSize]
    
     */
    get pageSize(): number;
    set pageSize(value: number);
    /**
     * [descr:DOMComponentOptions.rtlEnabled]
    
     */
    get rtlEnabled(): boolean;
    set rtlEnabled(value: boolean);
    /**
     * [descr:PagerBase.showInfo]
    
     */
    get showInfo(): boolean;
    set showInfo(value: boolean);
    /**
     * [descr:PagerBase.showNavigationButtons]
    
     */
    get showNavigationButtons(): boolean;
    set showNavigationButtons(value: boolean);
    /**
     * [descr:PagerBase.showPageSizeSelector]
    
     */
    get showPageSizeSelector(): boolean | Mode;
    set showPageSizeSelector(value: boolean | Mode);
    /**
     * [descr:WidgetOptions.tabIndex]
    
     */
    get tabIndex(): number;
    set tabIndex(value: number);
    /**
     * [descr:WidgetOptions.visible]
    
     */
    get visible(): boolean;
    set visible(value: boolean);
    /**
     * [descr:DOMComponentOptions.width]
    
     */
    get width(): number | string | undefined;
    set width(value: number | string | undefined);
    /**
    
     * [descr:WidgetOptions.onContentReady]
    
    
     */
    onContentReady: EventEmitter<EventInfo<any>>;
    /**
    
     * [descr:DOMComponentOptions.onDisposing]
    
    
     */
    onDisposing: EventEmitter<EventInfo<any>>;
    /**
    
     * [descr:ComponentOptions.onInitialized]
    
    
     */
    onInitialized: EventEmitter<Object>;
    /**
    
     * [descr:DOMComponentOptions.onOptionChanged]
    
    
     */
    onOptionChanged: EventEmitter<Object>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    accessKeyChange: EventEmitter<string | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    activeStateEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    allowedPageSizesChange: EventEmitter<Array<number | string>>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    disabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    displayModeChange: EventEmitter<DisplayMode>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    elementAttrChange: EventEmitter<Record<string, any>>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    focusStateEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    heightChange: EventEmitter<number | string | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    hintChange: EventEmitter<string | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    hoverStateEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    infoTextChange: EventEmitter<string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    itemCountChange: EventEmitter<number>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    labelChange: EventEmitter<string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    pageIndexChange: EventEmitter<number>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    pageSizeChange: EventEmitter<number>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    rtlEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    showInfoChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    showNavigationButtonsChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    showPageSizeSelectorChange: EventEmitter<boolean | Mode>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    tabIndexChange: EventEmitter<number>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    visibleChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    widthChange: EventEmitter<number | string | undefined>;
    constructor(elementRef: ElementRef, ngZone: NgZone, templateHost: DxTemplateHost, _watcherHelper: WatcherHelper, _idh: IterableDifferHelper, optionHost: NestedOptionHost, transferState: TransferState, platformId: any);
    protected _createInstance(element: any, options: any): DxPagination;
    ngOnDestroy(): void;
    ngOnChanges(changes: SimpleChanges): void;
    setupChanges(prop: string, changes: SimpleChanges): void;
    ngDoCheck(): void;
    _setOption(name: string, value: any): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxPaginationComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxPaginationComponent, "dx-pagination", never, { "accessKey": { "alias": "accessKey"; "required": false; }; "activeStateEnabled": { "alias": "activeStateEnabled"; "required": false; }; "allowedPageSizes": { "alias": "allowedPageSizes"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "displayMode": { "alias": "displayMode"; "required": false; }; "elementAttr": { "alias": "elementAttr"; "required": false; }; "focusStateEnabled": { "alias": "focusStateEnabled"; "required": false; }; "height": { "alias": "height"; "required": false; }; "hint": { "alias": "hint"; "required": false; }; "hoverStateEnabled": { "alias": "hoverStateEnabled"; "required": false; }; "infoText": { "alias": "infoText"; "required": false; }; "itemCount": { "alias": "itemCount"; "required": false; }; "label": { "alias": "label"; "required": false; }; "pageIndex": { "alias": "pageIndex"; "required": false; }; "pageSize": { "alias": "pageSize"; "required": false; }; "rtlEnabled": { "alias": "rtlEnabled"; "required": false; }; "showInfo": { "alias": "showInfo"; "required": false; }; "showNavigationButtons": { "alias": "showNavigationButtons"; "required": false; }; "showPageSizeSelector": { "alias": "showPageSizeSelector"; "required": false; }; "tabIndex": { "alias": "tabIndex"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, { "onContentReady": "onContentReady"; "onDisposing": "onDisposing"; "onInitialized": "onInitialized"; "onOptionChanged": "onOptionChanged"; "accessKeyChange": "accessKeyChange"; "activeStateEnabledChange": "activeStateEnabledChange"; "allowedPageSizesChange": "allowedPageSizesChange"; "disabledChange": "disabledChange"; "displayModeChange": "displayModeChange"; "elementAttrChange": "elementAttrChange"; "focusStateEnabledChange": "focusStateEnabledChange"; "heightChange": "heightChange"; "hintChange": "hintChange"; "hoverStateEnabledChange": "hoverStateEnabledChange"; "infoTextChange": "infoTextChange"; "itemCountChange": "itemCountChange"; "labelChange": "labelChange"; "pageIndexChange": "pageIndexChange"; "pageSizeChange": "pageSizeChange"; "rtlEnabledChange": "rtlEnabledChange"; "showInfoChange": "showInfoChange"; "showNavigationButtonsChange": "showNavigationButtonsChange"; "showPageSizeSelectorChange": "showPageSizeSelectorChange"; "tabIndexChange": "tabIndexChange"; "visibleChange": "visibleChange"; "widthChange": "widthChange"; }, never, never, true, never>;
}
declare class DxPaginationModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxPaginationModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxPaginationModule, never, [typeof DxPaginationComponent, typeof i1.DxIntegrationModule, typeof i1.DxTemplateModule], [typeof DxPaginationComponent, typeof i1.DxTemplateModule]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxPaginationModule>;
}

export { DxPaginationComponent, DxPaginationModule };
//# sourceMappingURL=index.d.ts.map
