import * as i0 from '@angular/core';
import { OnDestroy, OnChanges, DoCheck, QueryList, EventEmitter, ElementRef, NgZone, TransferState, SimpleChanges } from '@angular/core';
import { AnimationConfig, PositionConfig } from 'devextreme/common/core/animation';
import { event } from 'devextreme/events/events.types';
import DxPopover, { ContentReadyEvent, DisposingEvent, HiddenEvent, HidingEvent, InitializedEvent, OptionChangedEvent, ShowingEvent, ShownEvent, TitleRenderedEvent } from 'devextreme/ui/popover';
import { Position } from 'devextreme/common';
import { dxPopupToolbarItem } from 'devextreme/ui/popup';
import * as i3 from 'devextreme-angular/core';
import { DxComponent, CollectionNestedOption, DxTemplateHost, WatcherHelper, IterableDifferHelper, NestedOptionHost } from 'devextreme-angular/core';
import * as i1 from 'devextreme-angular/ui/nested';
import * as i2 from 'devextreme-angular/ui/popover/nested';
export * from 'devextreme-angular/ui/popover/nested';
import * as popover_types from 'devextreme/ui/popover_types';
export { popover_types as DxPopoverTypes };

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

/**
 * [descr:dxPopover]

 */
declare class DxPopoverComponent extends DxComponent implements OnDestroy, OnChanges, DoCheck {
    private _watcherHelper;
    private _idh;
    set _toolbarItemsContentChildren(value: QueryList<CollectionNestedOption>);
    instance: DxPopover;
    /**
     * [descr:dxPopoverOptions.animation]
    
     */
    get animation(): {
        hide?: AnimationConfig;
        show?: AnimationConfig;
    };
    set animation(value: {
        hide?: AnimationConfig;
        show?: AnimationConfig;
    });
    /**
     * [descr:dxPopupOptions.container]
    
     */
    get container(): any | string | undefined;
    set container(value: any | string | undefined);
    /**
     * [descr:dxOverlayOptions.contentTemplate]
    
     */
    get contentTemplate(): any;
    set contentTemplate(value: any);
    /**
     * [descr:dxOverlayOptions.deferRendering]
    
     */
    get deferRendering(): boolean;
    set deferRendering(value: boolean);
    /**
     * [descr:WidgetOptions.disabled]
    
     */
    get disabled(): boolean;
    set disabled(value: boolean);
    /**
     * [descr:dxPopupOptions.enableBodyScroll]
    
     */
    get enableBodyScroll(): boolean;
    set enableBodyScroll(value: boolean);
    /**
     * [descr:dxPopoverOptions.height]
    
     */
    get height(): number | string;
    set height(value: number | string);
    /**
     * [descr:dxPopoverOptions.hideEvent]
    
     */
    get hideEvent(): string | undefined | {
        delay?: number | undefined;
        name?: string | undefined;
    };
    set hideEvent(value: string | undefined | {
        delay?: number | undefined;
        name?: string | undefined;
    });
    /**
     * [descr:dxPopoverOptions.hideOnOutsideClick]
    
     */
    get hideOnOutsideClick(): boolean | ((event: event) => boolean);
    set hideOnOutsideClick(value: boolean | ((event: event) => boolean));
    /**
     * [descr:dxPopoverOptions.hideOnParentScroll]
    
     */
    get hideOnParentScroll(): boolean;
    set hideOnParentScroll(value: boolean);
    /**
     * [descr:WidgetOptions.hint]
    
     */
    get hint(): string | undefined;
    set hint(value: string | undefined);
    /**
     * [descr:WidgetOptions.hoverStateEnabled]
    
     */
    get hoverStateEnabled(): boolean;
    set hoverStateEnabled(value: boolean);
    /**
     * [descr:dxOverlayOptions.maxHeight]
    
     */
    get maxHeight(): number | string;
    set maxHeight(value: number | string);
    /**
     * [descr:dxOverlayOptions.maxWidth]
    
     */
    get maxWidth(): number | string;
    set maxWidth(value: number | string);
    /**
     * [descr:dxOverlayOptions.minHeight]
    
     */
    get minHeight(): number | string;
    set minHeight(value: number | string);
    /**
     * [descr:dxOverlayOptions.minWidth]
    
     */
    get minWidth(): number | string;
    set minWidth(value: number | string);
    /**
     * [descr:dxPopoverOptions.position]
    
     */
    get position(): Position | PositionConfig;
    set position(value: Position | PositionConfig);
    /**
     * [descr:DOMComponentOptions.rtlEnabled]
    
     */
    get rtlEnabled(): boolean;
    set rtlEnabled(value: boolean);
    /**
     * [descr:dxPopoverOptions.shading]
    
     */
    get shading(): boolean;
    set shading(value: boolean);
    /**
     * [descr:dxOverlayOptions.shadingColor]
    
     */
    get shadingColor(): string;
    set shadingColor(value: string);
    /**
     * [descr:dxPopupOptions.showCloseButton]
    
     */
    get showCloseButton(): boolean;
    set showCloseButton(value: boolean);
    /**
     * [descr:dxPopoverOptions.showEvent]
    
     */
    get showEvent(): string | undefined | {
        delay?: number | undefined;
        name?: string | undefined;
    };
    set showEvent(value: string | undefined | {
        delay?: number | undefined;
        name?: string | undefined;
    });
    /**
     * [descr:dxPopoverOptions.showTitle]
    
     */
    get showTitle(): boolean;
    set showTitle(value: boolean);
    get tabFocusLoopEnabled(): boolean;
    set tabFocusLoopEnabled(value: boolean);
    /**
     * [descr:dxPopoverOptions.target]
    
     */
    get target(): any | string | undefined;
    set target(value: any | string | undefined);
    /**
     * [descr:dxPopupOptions.title]
    
     */
    get title(): string;
    set title(value: string);
    /**
     * [descr:dxPopupOptions.titleTemplate]
    
     */
    get titleTemplate(): any;
    set titleTemplate(value: any);
    /**
     * [descr:dxPopupOptions.toolbarItems]
    
     */
    get toolbarItems(): Array<dxPopupToolbarItem>;
    set toolbarItems(value: Array<dxPopupToolbarItem>);
    /**
     * [descr:dxOverlayOptions.visible]
    
     */
    get visible(): boolean;
    set visible(value: boolean);
    /**
     * [descr:dxPopoverOptions.width]
    
     */
    get width(): number | string;
    set width(value: number | string);
    /**
     * [descr:dxOverlayOptions.wrapperAttr]
    
     */
    get wrapperAttr(): any;
    set wrapperAttr(value: any);
    /**
    
     * [descr:dxPopoverOptions.onContentReady]
    
    
     */
    onContentReady: EventEmitter<ContentReadyEvent>;
    /**
    
     * [descr:dxPopoverOptions.onDisposing]
    
    
     */
    onDisposing: EventEmitter<DisposingEvent>;
    /**
    
     * [descr:dxPopoverOptions.onHidden]
    
    
     */
    onHidden: EventEmitter<HiddenEvent>;
    /**
    
     * [descr:dxPopoverOptions.onHiding]
    
    
     */
    onHiding: EventEmitter<HidingEvent>;
    /**
    
     * [descr:dxPopoverOptions.onInitialized]
    
    
     */
    onInitialized: EventEmitter<InitializedEvent>;
    /**
    
     * [descr:dxPopoverOptions.onOptionChanged]
    
    
     */
    onOptionChanged: EventEmitter<OptionChangedEvent>;
    /**
    
     * [descr:dxPopoverOptions.onShowing]
    
    
     */
    onShowing: EventEmitter<ShowingEvent>;
    /**
    
     * [descr:dxPopoverOptions.onShown]
    
    
     */
    onShown: EventEmitter<ShownEvent>;
    /**
    
     * [descr:dxPopoverOptions.onTitleRendered]
    
    
     */
    onTitleRendered: EventEmitter<TitleRenderedEvent>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    animationChange: EventEmitter<{
        hide?: AnimationConfig;
        show?: AnimationConfig;
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    containerChange: EventEmitter<any | string | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    contentTemplateChange: EventEmitter<any>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    deferRenderingChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    disabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    enableBodyScrollChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    heightChange: EventEmitter<number | string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    hideEventChange: EventEmitter<string | undefined | {
        delay?: number | undefined;
        name?: string | undefined;
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    hideOnOutsideClickChange: EventEmitter<boolean | ((event: event) => boolean)>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    hideOnParentScrollChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    hintChange: EventEmitter<string | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    hoverStateEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    maxHeightChange: EventEmitter<number | string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    maxWidthChange: EventEmitter<number | string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    minHeightChange: EventEmitter<number | string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    minWidthChange: EventEmitter<number | string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    positionChange: EventEmitter<Position | PositionConfig>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    rtlEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    shadingChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    shadingColorChange: EventEmitter<string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    showCloseButtonChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    showEventChange: EventEmitter<string | undefined | {
        delay?: number | undefined;
        name?: string | undefined;
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    showTitleChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    tabFocusLoopEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    targetChange: EventEmitter<any | string | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    titleChange: EventEmitter<string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    titleTemplateChange: EventEmitter<any>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    toolbarItemsChange: EventEmitter<Array<dxPopupToolbarItem>>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    visibleChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    widthChange: EventEmitter<number | string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    wrapperAttrChange: EventEmitter<any>;
    constructor(elementRef: ElementRef, ngZone: NgZone, templateHost: DxTemplateHost, _watcherHelper: WatcherHelper, _idh: IterableDifferHelper, optionHost: NestedOptionHost, transferState: TransferState, platformId: any);
    protected _createInstance(element: any, options: any): DxPopover<any>;
    ngOnDestroy(): void;
    ngOnChanges(changes: SimpleChanges): void;
    setupChanges(prop: string, changes: SimpleChanges): void;
    ngDoCheck(): void;
    _setOption(name: string, value: any): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxPopoverComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxPopoverComponent, "dx-popover", never, { "animation": { "alias": "animation"; "required": false; }; "container": { "alias": "container"; "required": false; }; "contentTemplate": { "alias": "contentTemplate"; "required": false; }; "deferRendering": { "alias": "deferRendering"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "enableBodyScroll": { "alias": "enableBodyScroll"; "required": false; }; "height": { "alias": "height"; "required": false; }; "hideEvent": { "alias": "hideEvent"; "required": false; }; "hideOnOutsideClick": { "alias": "hideOnOutsideClick"; "required": false; }; "hideOnParentScroll": { "alias": "hideOnParentScroll"; "required": false; }; "hint": { "alias": "hint"; "required": false; }; "hoverStateEnabled": { "alias": "hoverStateEnabled"; "required": false; }; "maxHeight": { "alias": "maxHeight"; "required": false; }; "maxWidth": { "alias": "maxWidth"; "required": false; }; "minHeight": { "alias": "minHeight"; "required": false; }; "minWidth": { "alias": "minWidth"; "required": false; }; "position": { "alias": "position"; "required": false; }; "rtlEnabled": { "alias": "rtlEnabled"; "required": false; }; "shading": { "alias": "shading"; "required": false; }; "shadingColor": { "alias": "shadingColor"; "required": false; }; "showCloseButton": { "alias": "showCloseButton"; "required": false; }; "showEvent": { "alias": "showEvent"; "required": false; }; "showTitle": { "alias": "showTitle"; "required": false; }; "tabFocusLoopEnabled": { "alias": "tabFocusLoopEnabled"; "required": false; }; "target": { "alias": "target"; "required": false; }; "title": { "alias": "title"; "required": false; }; "titleTemplate": { "alias": "titleTemplate"; "required": false; }; "toolbarItems": { "alias": "toolbarItems"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; "wrapperAttr": { "alias": "wrapperAttr"; "required": false; }; }, { "onContentReady": "onContentReady"; "onDisposing": "onDisposing"; "onHidden": "onHidden"; "onHiding": "onHiding"; "onInitialized": "onInitialized"; "onOptionChanged": "onOptionChanged"; "onShowing": "onShowing"; "onShown": "onShown"; "onTitleRendered": "onTitleRendered"; "animationChange": "animationChange"; "containerChange": "containerChange"; "contentTemplateChange": "contentTemplateChange"; "deferRenderingChange": "deferRenderingChange"; "disabledChange": "disabledChange"; "enableBodyScrollChange": "enableBodyScrollChange"; "heightChange": "heightChange"; "hideEventChange": "hideEventChange"; "hideOnOutsideClickChange": "hideOnOutsideClickChange"; "hideOnParentScrollChange": "hideOnParentScrollChange"; "hintChange": "hintChange"; "hoverStateEnabledChange": "hoverStateEnabledChange"; "maxHeightChange": "maxHeightChange"; "maxWidthChange": "maxWidthChange"; "minHeightChange": "minHeightChange"; "minWidthChange": "minWidthChange"; "positionChange": "positionChange"; "rtlEnabledChange": "rtlEnabledChange"; "shadingChange": "shadingChange"; "shadingColorChange": "shadingColorChange"; "showCloseButtonChange": "showCloseButtonChange"; "showEventChange": "showEventChange"; "showTitleChange": "showTitleChange"; "tabFocusLoopEnabledChange": "tabFocusLoopEnabledChange"; "targetChange": "targetChange"; "titleChange": "titleChange"; "titleTemplateChange": "titleTemplateChange"; "toolbarItemsChange": "toolbarItemsChange"; "visibleChange": "visibleChange"; "widthChange": "widthChange"; "wrapperAttrChange": "wrapperAttrChange"; }, ["_toolbarItemsContentChildren"], ["*"], true, never>;
}
declare class DxPopoverModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxPopoverModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxPopoverModule, never, [typeof DxPopoverComponent, typeof i1.DxoAnimationModule, typeof i1.DxoHideModule, typeof i1.DxoFromModule, typeof i1.DxoPositionModule, typeof i1.DxoAtModule, typeof i1.DxoBoundaryOffsetModule, typeof i1.DxoCollisionModule, typeof i1.DxoMyModule, typeof i1.DxoOffsetModule, typeof i1.DxoToModule, typeof i1.DxoShowModule, typeof i1.DxoHideEventModule, typeof i1.DxoShowEventModule, typeof i2.DxoPopoverAnimationModule, typeof i2.DxoPopoverAtModule, typeof i2.DxoPopoverBoundaryOffsetModule, typeof i2.DxoPopoverCollisionModule, typeof i2.DxoPopoverFromModule, typeof i2.DxoPopoverHideModule, typeof i2.DxoPopoverHideEventModule, typeof i2.DxoPopoverMyModule, typeof i2.DxoPopoverOffsetModule, typeof i2.DxoPopoverPositionModule, typeof i2.DxoPopoverShowModule, typeof i2.DxoPopoverShowEventModule, typeof i2.DxoPopoverToModule, typeof i2.DxiPopoverToolbarItemModule, typeof i3.DxIntegrationModule, typeof i3.DxTemplateModule], [typeof DxPopoverComponent, typeof i1.DxoAnimationModule, typeof i1.DxoHideModule, typeof i1.DxoFromModule, typeof i1.DxoPositionModule, typeof i1.DxoAtModule, typeof i1.DxoBoundaryOffsetModule, typeof i1.DxoCollisionModule, typeof i1.DxoMyModule, typeof i1.DxoOffsetModule, typeof i1.DxoToModule, typeof i1.DxoShowModule, typeof i1.DxoHideEventModule, typeof i1.DxoShowEventModule, typeof i2.DxoPopoverAnimationModule, typeof i2.DxoPopoverAtModule, typeof i2.DxoPopoverBoundaryOffsetModule, typeof i2.DxoPopoverCollisionModule, typeof i2.DxoPopoverFromModule, typeof i2.DxoPopoverHideModule, typeof i2.DxoPopoverHideEventModule, typeof i2.DxoPopoverMyModule, typeof i2.DxoPopoverOffsetModule, typeof i2.DxoPopoverPositionModule, typeof i2.DxoPopoverShowModule, typeof i2.DxoPopoverShowEventModule, typeof i2.DxoPopoverToModule, typeof i2.DxiPopoverToolbarItemModule, typeof i3.DxTemplateModule]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxPopoverModule>;
}

export { DxPopoverComponent, DxPopoverModule };
//# sourceMappingURL=index.d.ts.map
