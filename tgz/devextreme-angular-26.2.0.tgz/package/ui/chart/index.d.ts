import * as i0 from '@angular/core';
import { OnDestroy, OnChanges, DoCheck, QueryList, EventEmitter, ElementRef, NgZone, TransferState, SimpleChanges } from '@angular/core';
import * as CommonChartTypes from 'devextreme/common/charts';
import { AnimationEaseMode, TimeInterval, ChartsDataType, ScaleBreak, ScaleBreakLineStyle, DashStyle, Font, RelativePosition, DiscreteAxisDivisionMode, ArgumentAxisHoverMode, ChartsAxisLabelOverlap, TextOverflow, WordWrap, AxisScaleType, VisualRangeUpdateMode, ChartsColor, SeriesHoverMode, HatchDirection, PointInteractionMode, PointSymbol, SeriesSelectionMode, SeriesType, ValueErrorBarDisplayMode, ValueErrorBarType, SeriesLabel, SeriesPoint, LegendItem, LegendHoverMode, Palette, PaletteExtensionMode, ChartsLabelOverlap, Theme, ValueAxisVisualRangeUpdateMode } from 'devextreme/common/charts';
import DxChart, { dxChartAnnotationConfig, AggregatedPointsPosition, ChartLabelDisplayMode, dxChartCommonAnnotationConfig, chartPointAggregationInfoObject, chartSeriesObject, ChartSeriesAggregationMethod, FinancialChartReductionLevel, chartPointObject, dxChartPointInfo, ChartTooltipLocation, ChartZoomAndPanMode, EventKeyModifier, ArgumentAxisClickEvent, DisposingEvent, DoneEvent, DrawnEvent, ExportedEvent, ExportingEvent, FileSavingEvent, IncidentOccurredEvent, InitializedEvent, LegendClickEvent, OptionChangedEvent, PointClickEvent, PointHoverChangedEvent, PointSelectionChangedEvent, SeriesClickEvent, SeriesHoverChangedEvent, SeriesSelectionChangedEvent, TooltipHiddenEvent, TooltipShownEvent, ZoomEndEvent, ZoomStartEvent } from 'devextreme/viz/chart';
import { HorizontalAlignment, VerticalAlignment, Position, ExportFormat, Orientation, VerticalEdge, SingleOrMultiple } from 'devextreme/common';
import { Format } from 'devextreme/common/core/localization';
import DataSource, { DataSourceOptions } from 'devextreme/data/data_source';
import { Store } from 'devextreme/data/store';
import { ChartSeries } from 'devextreme/viz/common';
import * as i3 from 'devextreme-angular/core';
import { DxComponent, CollectionNestedOption, DxTemplateHost, WatcherHelper, IterableDifferHelper, NestedOptionHost } from 'devextreme-angular/core';
import * as i1 from 'devextreme-angular/ui/nested';
import * as i2 from 'devextreme-angular/ui/chart/nested';
export * from 'devextreme-angular/ui/chart/nested';
import * as chart_types from 'devextreme/viz/chart_types';
export { chart_types as DxChartTypes };

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

/**
 * [descr:dxChart]

 */
declare class DxChartComponent extends DxComponent implements OnDestroy, OnChanges, DoCheck {
    private _watcherHelper;
    private _idh;
    set _annotationsContentChildren(value: QueryList<CollectionNestedOption>);
    set _breaksContentChildren(value: QueryList<CollectionNestedOption>);
    set _constantLinesContentChildren(value: QueryList<CollectionNestedOption>);
    set _panesContentChildren(value: QueryList<CollectionNestedOption>);
    set _seriesContentChildren(value: QueryList<CollectionNestedOption>);
    set _stripsContentChildren(value: QueryList<CollectionNestedOption>);
    set _valueAxisContentChildren(value: QueryList<CollectionNestedOption>);
    instance: DxChart;
    /**
     * [descr:BaseChartOptions.adaptiveLayout]
    
     */
    get adaptiveLayout(): {
        height?: number;
        keepLabels?: boolean;
        width?: number;
    };
    set adaptiveLayout(value: {
        height?: number;
        keepLabels?: boolean;
        width?: number;
    });
    /**
     * [descr:dxChartOptions.adjustOnZoom]
    
     */
    get adjustOnZoom(): boolean;
    set adjustOnZoom(value: boolean);
    /**
     * [descr:BaseChartOptions.animation]
    
     */
    get animation(): boolean | {
        duration?: number;
        easing?: AnimationEaseMode;
        enabled?: boolean;
        maxPointCountSupported?: number;
    };
    set animation(value: boolean | {
        duration?: number;
        easing?: AnimationEaseMode;
        enabled?: boolean;
        maxPointCountSupported?: number;
    });
    /**
     * [descr:dxChartOptions.annotations]
    
     */
    get annotations(): Array<any | dxChartAnnotationConfig>;
    set annotations(value: Array<any | dxChartAnnotationConfig>);
    /**
     * [descr:dxChartOptions.argumentAxis]
    
     */
    get argumentAxis(): {
        aggregatedPointsPosition?: AggregatedPointsPosition;
        aggregationGroupWidth?: number | undefined;
        aggregationInterval?: number | TimeInterval | {
            days?: number;
            hours?: number;
            milliseconds?: number;
            minutes?: number;
            months?: number;
            quarters?: number;
            seconds?: number;
            weeks?: number;
            years?: number;
        };
        allowDecimals?: boolean | undefined;
        argumentType?: ChartsDataType | undefined;
        axisDivisionFactor?: number;
        breaks?: Array<ScaleBreak> | undefined | {
            endValue?: Date | number | string | undefined;
            startValue?: Date | number | string | undefined;
        }[];
        breakStyle?: {
            color?: string;
            line?: ScaleBreakLineStyle;
            width?: number;
        };
        categories?: Array<Date | number | string>;
        color?: string;
        constantLines?: {
            color?: string;
            dashStyle?: DashStyle;
            displayBehindSeries?: boolean;
            extendAxis?: boolean;
            label?: {
                font?: Font;
                horizontalAlignment?: HorizontalAlignment;
                position?: RelativePosition;
                text?: string | undefined;
                verticalAlignment?: VerticalAlignment;
                visible?: boolean;
            };
            paddingLeftRight?: number;
            paddingTopBottom?: number;
            value?: Date | number | string | undefined;
            width?: number;
        }[];
        constantLineStyle?: {
            color?: string;
            dashStyle?: DashStyle;
            label?: {
                font?: Font;
                horizontalAlignment?: HorizontalAlignment;
                position?: RelativePosition;
                verticalAlignment?: VerticalAlignment;
                visible?: boolean;
            };
            paddingLeftRight?: number;
            paddingTopBottom?: number;
            width?: number;
        };
        customPosition?: Date | number | string | undefined;
        customPositionAxis?: string | undefined;
        discreteAxisDivisionMode?: DiscreteAxisDivisionMode;
        endOnTick?: boolean;
        grid?: {
            color?: string;
            opacity?: number | undefined;
            visible?: boolean;
            width?: number;
        };
        holidays?: Array<Date | string> | Array<number> | undefined;
        hoverMode?: ArgumentAxisHoverMode;
        inverted?: boolean;
        label?: {
            alignment?: HorizontalAlignment | undefined;
            customizeHint?: ((argument: {
                value: Date | number | string;
                valueText: string;
            }) => string);
            customizeText?: ((argument: {
                value: Date | number | string;
                valueText: string;
            }) => string);
            displayMode?: ChartLabelDisplayMode;
            font?: Font;
            format?: Format | undefined;
            indentFromAxis?: number;
            overlappingBehavior?: ChartsAxisLabelOverlap;
            position?: Position | RelativePosition;
            rotationAngle?: number;
            staggeringSpacing?: number;
            template?: any;
            textOverflow?: TextOverflow;
            visible?: boolean;
            wordWrap?: WordWrap;
        };
        linearThreshold?: number | undefined;
        logarithmBase?: number;
        maxValueMargin?: number | undefined;
        minorGrid?: {
            color?: string;
            opacity?: number | undefined;
            visible?: boolean;
            width?: number;
        };
        minorTick?: {
            color?: string;
            length?: number;
            opacity?: number;
            shift?: number;
            visible?: boolean;
            width?: number;
        };
        minorTickCount?: number | undefined;
        minorTickInterval?: number | TimeInterval | {
            days?: number;
            hours?: number;
            milliseconds?: number;
            minutes?: number;
            months?: number;
            quarters?: number;
            seconds?: number;
            weeks?: number;
            years?: number;
        };
        minValueMargin?: number | undefined;
        minVisualRangeLength?: number | TimeInterval | undefined | {
            days?: number;
            hours?: number;
            milliseconds?: number;
            minutes?: number;
            months?: number;
            quarters?: number;
            seconds?: number;
            weeks?: number;
            years?: number;
        };
        offset?: number | undefined;
        opacity?: number | undefined;
        placeholderSize?: null | number;
        position?: Position;
        singleWorkdays?: Array<Date | string> | Array<number> | undefined;
        strips?: {
            color?: string | undefined;
            endValue?: Date | number | string | undefined;
            label?: {
                font?: Font;
                horizontalAlignment?: HorizontalAlignment;
                text?: string | undefined;
                verticalAlignment?: VerticalAlignment;
            };
            paddingLeftRight?: number;
            paddingTopBottom?: number;
            startValue?: Date | number | string | undefined;
        }[];
        stripStyle?: {
            label?: {
                font?: Font;
                horizontalAlignment?: HorizontalAlignment;
                verticalAlignment?: VerticalAlignment;
            };
            paddingLeftRight?: number;
            paddingTopBottom?: number;
        };
        tick?: {
            color?: string;
            length?: number;
            opacity?: number | undefined;
            shift?: number;
            visible?: boolean;
            width?: number;
        };
        tickInterval?: number | TimeInterval | {
            days?: number;
            hours?: number;
            milliseconds?: number;
            minutes?: number;
            months?: number;
            quarters?: number;
            seconds?: number;
            weeks?: number;
            years?: number;
        };
        title?: string | {
            alignment?: HorizontalAlignment;
            font?: Font;
            margin?: number;
            text?: string | undefined;
            textOverflow?: TextOverflow;
            wordWrap?: WordWrap;
        };
        type?: AxisScaleType | undefined;
        valueMarginsEnabled?: boolean;
        visible?: boolean;
        visualRange?: Array<Date | number | string> | CommonChartTypes.VisualRange;
        visualRangeUpdateMode?: VisualRangeUpdateMode;
        wholeRange?: Array<Date | number | string> | undefined | CommonChartTypes.VisualRange;
        width?: number;
        workdaysOnly?: boolean;
        workWeek?: Array<number>;
    };
    set argumentAxis(value: {
        aggregatedPointsPosition?: AggregatedPointsPosition;
        aggregationGroupWidth?: number | undefined;
        aggregationInterval?: number | TimeInterval | {
            days?: number;
            hours?: number;
            milliseconds?: number;
            minutes?: number;
            months?: number;
            quarters?: number;
            seconds?: number;
            weeks?: number;
            years?: number;
        };
        allowDecimals?: boolean | undefined;
        argumentType?: ChartsDataType | undefined;
        axisDivisionFactor?: number;
        breaks?: Array<ScaleBreak> | undefined | {
            endValue?: Date | number | string | undefined;
            startValue?: Date | number | string | undefined;
        }[];
        breakStyle?: {
            color?: string;
            line?: ScaleBreakLineStyle;
            width?: number;
        };
        categories?: Array<Date | number | string>;
        color?: string;
        constantLines?: {
            color?: string;
            dashStyle?: DashStyle;
            displayBehindSeries?: boolean;
            extendAxis?: boolean;
            label?: {
                font?: Font;
                horizontalAlignment?: HorizontalAlignment;
                position?: RelativePosition;
                text?: string | undefined;
                verticalAlignment?: VerticalAlignment;
                visible?: boolean;
            };
            paddingLeftRight?: number;
            paddingTopBottom?: number;
            value?: Date | number | string | undefined;
            width?: number;
        }[];
        constantLineStyle?: {
            color?: string;
            dashStyle?: DashStyle;
            label?: {
                font?: Font;
                horizontalAlignment?: HorizontalAlignment;
                position?: RelativePosition;
                verticalAlignment?: VerticalAlignment;
                visible?: boolean;
            };
            paddingLeftRight?: number;
            paddingTopBottom?: number;
            width?: number;
        };
        customPosition?: Date | number | string | undefined;
        customPositionAxis?: string | undefined;
        discreteAxisDivisionMode?: DiscreteAxisDivisionMode;
        endOnTick?: boolean;
        grid?: {
            color?: string;
            opacity?: number | undefined;
            visible?: boolean;
            width?: number;
        };
        holidays?: Array<Date | string> | Array<number> | undefined;
        hoverMode?: ArgumentAxisHoverMode;
        inverted?: boolean;
        label?: {
            alignment?: HorizontalAlignment | undefined;
            customizeHint?: ((argument: {
                value: Date | number | string;
                valueText: string;
            }) => string);
            customizeText?: ((argument: {
                value: Date | number | string;
                valueText: string;
            }) => string);
            displayMode?: ChartLabelDisplayMode;
            font?: Font;
            format?: Format | undefined;
            indentFromAxis?: number;
            overlappingBehavior?: ChartsAxisLabelOverlap;
            position?: Position | RelativePosition;
            rotationAngle?: number;
            staggeringSpacing?: number;
            template?: any;
            textOverflow?: TextOverflow;
            visible?: boolean;
            wordWrap?: WordWrap;
        };
        linearThreshold?: number | undefined;
        logarithmBase?: number;
        maxValueMargin?: number | undefined;
        minorGrid?: {
            color?: string;
            opacity?: number | undefined;
            visible?: boolean;
            width?: number;
        };
        minorTick?: {
            color?: string;
            length?: number;
            opacity?: number;
            shift?: number;
            visible?: boolean;
            width?: number;
        };
        minorTickCount?: number | undefined;
        minorTickInterval?: number | TimeInterval | {
            days?: number;
            hours?: number;
            milliseconds?: number;
            minutes?: number;
            months?: number;
            quarters?: number;
            seconds?: number;
            weeks?: number;
            years?: number;
        };
        minValueMargin?: number | undefined;
        minVisualRangeLength?: number | TimeInterval | undefined | {
            days?: number;
            hours?: number;
            milliseconds?: number;
            minutes?: number;
            months?: number;
            quarters?: number;
            seconds?: number;
            weeks?: number;
            years?: number;
        };
        offset?: number | undefined;
        opacity?: number | undefined;
        placeholderSize?: null | number;
        position?: Position;
        singleWorkdays?: Array<Date | string> | Array<number> | undefined;
        strips?: {
            color?: string | undefined;
            endValue?: Date | number | string | undefined;
            label?: {
                font?: Font;
                horizontalAlignment?: HorizontalAlignment;
                text?: string | undefined;
                verticalAlignment?: VerticalAlignment;
            };
            paddingLeftRight?: number;
            paddingTopBottom?: number;
            startValue?: Date | number | string | undefined;
        }[];
        stripStyle?: {
            label?: {
                font?: Font;
                horizontalAlignment?: HorizontalAlignment;
                verticalAlignment?: VerticalAlignment;
            };
            paddingLeftRight?: number;
            paddingTopBottom?: number;
        };
        tick?: {
            color?: string;
            length?: number;
            opacity?: number | undefined;
            shift?: number;
            visible?: boolean;
            width?: number;
        };
        tickInterval?: number | TimeInterval | {
            days?: number;
            hours?: number;
            milliseconds?: number;
            minutes?: number;
            months?: number;
            quarters?: number;
            seconds?: number;
            weeks?: number;
            years?: number;
        };
        title?: string | {
            alignment?: HorizontalAlignment;
            font?: Font;
            margin?: number;
            text?: string | undefined;
            textOverflow?: TextOverflow;
            wordWrap?: WordWrap;
        };
        type?: AxisScaleType | undefined;
        valueMarginsEnabled?: boolean;
        visible?: boolean;
        visualRange?: Array<Date | number | string> | CommonChartTypes.VisualRange;
        visualRangeUpdateMode?: VisualRangeUpdateMode;
        wholeRange?: Array<Date | number | string> | undefined | CommonChartTypes.VisualRange;
        width?: number;
        workdaysOnly?: boolean;
        workWeek?: Array<number>;
    });
    /**
     * [descr:dxChartOptions.autoHidePointMarkers]
    
     */
    get autoHidePointMarkers(): boolean;
    set autoHidePointMarkers(value: boolean);
    /**
     * [descr:dxChartOptions.barGroupPadding]
    
     */
    get barGroupPadding(): number;
    set barGroupPadding(value: number);
    /**
     * [descr:dxChartOptions.barGroupWidth]
    
     */
    get barGroupWidth(): number | undefined;
    set barGroupWidth(value: number | undefined);
    /**
     * [descr:dxChartOptions.commonAnnotationSettings]
    
     */
    get commonAnnotationSettings(): dxChartCommonAnnotationConfig;
    set commonAnnotationSettings(value: dxChartCommonAnnotationConfig);
    /**
     * [descr:dxChartOptions.commonAxisSettings]
    
     */
    get commonAxisSettings(): {
        aggregatedPointsPosition?: AggregatedPointsPosition;
        allowDecimals?: boolean | undefined;
        breakStyle?: {
            color?: string;
            line?: ScaleBreakLineStyle;
            width?: number;
        };
        color?: string;
        constantLineStyle?: {
            color?: string;
            dashStyle?: DashStyle;
            label?: {
                font?: Font;
                position?: RelativePosition;
                visible?: boolean;
            };
            paddingLeftRight?: number;
            paddingTopBottom?: number;
            width?: number;
        };
        discreteAxisDivisionMode?: DiscreteAxisDivisionMode;
        endOnTick?: boolean | undefined;
        grid?: {
            color?: string;
            opacity?: number | undefined;
            visible?: boolean;
            width?: number;
        };
        inverted?: boolean;
        label?: {
            alignment?: HorizontalAlignment | undefined;
            displayMode?: ChartLabelDisplayMode;
            font?: Font;
            indentFromAxis?: number;
            overlappingBehavior?: ChartsAxisLabelOverlap;
            position?: Position | RelativePosition;
            rotationAngle?: number;
            staggeringSpacing?: number;
            template?: any;
            textOverflow?: TextOverflow;
            visible?: boolean;
            wordWrap?: WordWrap;
        };
        maxValueMargin?: number | undefined;
        minorGrid?: {
            color?: string;
            opacity?: number | undefined;
            visible?: boolean;
            width?: number;
        };
        minorTick?: {
            color?: string;
            length?: number;
            opacity?: number;
            shift?: number;
            visible?: boolean;
            width?: number;
        };
        minValueMargin?: number | undefined;
        opacity?: number | undefined;
        placeholderSize?: null | number;
        stripStyle?: {
            label?: {
                font?: Font;
                horizontalAlignment?: HorizontalAlignment;
                verticalAlignment?: VerticalAlignment;
            };
            paddingLeftRight?: number;
            paddingTopBottom?: number;
        };
        tick?: {
            color?: string;
            length?: number;
            opacity?: number | undefined;
            shift?: number;
            visible?: boolean;
            width?: number;
        };
        title?: {
            alignment?: HorizontalAlignment;
            font?: Font;
            margin?: number;
            textOverflow?: TextOverflow;
            wordWrap?: WordWrap;
        };
        valueMarginsEnabled?: boolean;
        visible?: boolean;
        width?: number;
    };
    set commonAxisSettings(value: {
        aggregatedPointsPosition?: AggregatedPointsPosition;
        allowDecimals?: boolean | undefined;
        breakStyle?: {
            color?: string;
            line?: ScaleBreakLineStyle;
            width?: number;
        };
        color?: string;
        constantLineStyle?: {
            color?: string;
            dashStyle?: DashStyle;
            label?: {
                font?: Font;
                position?: RelativePosition;
                visible?: boolean;
            };
            paddingLeftRight?: number;
            paddingTopBottom?: number;
            width?: number;
        };
        discreteAxisDivisionMode?: DiscreteAxisDivisionMode;
        endOnTick?: boolean | undefined;
        grid?: {
            color?: string;
            opacity?: number | undefined;
            visible?: boolean;
            width?: number;
        };
        inverted?: boolean;
        label?: {
            alignment?: HorizontalAlignment | undefined;
            displayMode?: ChartLabelDisplayMode;
            font?: Font;
            indentFromAxis?: number;
            overlappingBehavior?: ChartsAxisLabelOverlap;
            position?: Position | RelativePosition;
            rotationAngle?: number;
            staggeringSpacing?: number;
            template?: any;
            textOverflow?: TextOverflow;
            visible?: boolean;
            wordWrap?: WordWrap;
        };
        maxValueMargin?: number | undefined;
        minorGrid?: {
            color?: string;
            opacity?: number | undefined;
            visible?: boolean;
            width?: number;
        };
        minorTick?: {
            color?: string;
            length?: number;
            opacity?: number;
            shift?: number;
            visible?: boolean;
            width?: number;
        };
        minValueMargin?: number | undefined;
        opacity?: number | undefined;
        placeholderSize?: null | number;
        stripStyle?: {
            label?: {
                font?: Font;
                horizontalAlignment?: HorizontalAlignment;
                verticalAlignment?: VerticalAlignment;
            };
            paddingLeftRight?: number;
            paddingTopBottom?: number;
        };
        tick?: {
            color?: string;
            length?: number;
            opacity?: number | undefined;
            shift?: number;
            visible?: boolean;
            width?: number;
        };
        title?: {
            alignment?: HorizontalAlignment;
            font?: Font;
            margin?: number;
            textOverflow?: TextOverflow;
            wordWrap?: WordWrap;
        };
        valueMarginsEnabled?: boolean;
        visible?: boolean;
        width?: number;
    });
    /**
     * [descr:dxChartOptions.commonPaneSettings]
    
     */
    get commonPaneSettings(): {
        backgroundColor?: ChartsColor | string;
        border?: {
            bottom?: boolean;
            color?: string;
            dashStyle?: DashStyle;
            left?: boolean;
            opacity?: number | undefined;
            right?: boolean;
            top?: boolean;
            visible?: boolean;
            width?: number;
        };
    };
    set commonPaneSettings(value: {
        backgroundColor?: ChartsColor | string;
        border?: {
            bottom?: boolean;
            color?: string;
            dashStyle?: DashStyle;
            left?: boolean;
            opacity?: number | undefined;
            right?: boolean;
            top?: boolean;
            visible?: boolean;
            width?: number;
        };
    });
    /**
     * [descr:dxChartOptions.commonSeriesSettings]
    
     */
    get commonSeriesSettings(): {
        aggregation?: {
            calculate?: ((aggregationInfo: chartPointAggregationInfoObject, series: chartSeriesObject) => Record<string, any> | Array<Record<string, any>>) | undefined;
            enabled?: boolean;
            method?: ChartSeriesAggregationMethod;
        };
        area?: any;
        argumentField?: string;
        axis?: string | undefined;
        bar?: any;
        barOverlapGroup?: string | undefined;
        barPadding?: number | undefined;
        barWidth?: number | undefined;
        border?: {
            color?: string | undefined;
            dashStyle?: DashStyle | undefined;
            visible?: boolean;
            width?: number;
        };
        bubble?: any;
        candlestick?: any;
        closeValueField?: string;
        color?: ChartsColor | string | undefined;
        cornerRadius?: number;
        dashStyle?: DashStyle;
        fullstackedarea?: any;
        fullstackedbar?: any;
        fullstackedline?: any;
        fullstackedspline?: any;
        fullstackedsplinearea?: any;
        highValueField?: string;
        hoverMode?: SeriesHoverMode;
        hoverStyle?: {
            border?: {
                color?: string | undefined;
                dashStyle?: DashStyle | undefined;
                visible?: boolean;
                width?: number;
            };
            color?: ChartsColor | string | undefined;
            dashStyle?: DashStyle;
            hatching?: {
                direction?: HatchDirection;
                opacity?: number;
                step?: number;
                width?: number;
            };
            highlight?: boolean;
            width?: number;
        };
        ignoreEmptyPoints?: boolean;
        innerColor?: string;
        label?: {
            alignment?: HorizontalAlignment;
            argumentFormat?: Format | undefined;
            backgroundColor?: string | undefined;
            border?: {
                color?: string | undefined;
                dashStyle?: DashStyle | undefined;
                visible?: boolean;
                width?: number;
            };
            connector?: {
                color?: string | undefined;
                visible?: boolean;
                width?: number;
            };
            customizeText?: ((pointInfo: any) => string);
            displayFormat?: string | undefined;
            font?: Font;
            format?: Format | undefined;
            horizontalOffset?: number;
            position?: RelativePosition;
            rotationAngle?: number;
            showForZeroValues?: boolean;
            verticalOffset?: number;
            visible?: boolean;
        };
        line?: any;
        lowValueField?: string;
        maxLabelCount?: number | undefined;
        minBarSize?: number | undefined;
        opacity?: number;
        openValueField?: string;
        pane?: string;
        point?: {
            border?: {
                color?: string | undefined;
                visible?: boolean;
                width?: number;
            };
            color?: ChartsColor | string | undefined;
            hoverMode?: PointInteractionMode;
            hoverStyle?: {
                border?: {
                    color?: string | undefined;
                    visible?: boolean;
                    width?: number;
                };
                color?: ChartsColor | string | undefined;
                size?: number | undefined;
            };
            image?: string | undefined | {
                height?: number | {
                    rangeMaxPoint?: number | undefined;
                    rangeMinPoint?: number | undefined;
                };
                url?: string | undefined | {
                    rangeMaxPoint?: string | undefined;
                    rangeMinPoint?: string | undefined;
                };
                width?: number | {
                    rangeMaxPoint?: number | undefined;
                    rangeMinPoint?: number | undefined;
                };
            };
            selectionMode?: PointInteractionMode;
            selectionStyle?: {
                border?: {
                    color?: string | undefined;
                    visible?: boolean;
                    width?: number;
                };
                color?: ChartsColor | string | undefined;
                size?: number | undefined;
            };
            size?: number;
            symbol?: PointSymbol;
            visible?: boolean;
        };
        rangearea?: any;
        rangebar?: any;
        rangeValue1Field?: string;
        rangeValue2Field?: string;
        reduction?: {
            color?: string;
            level?: FinancialChartReductionLevel;
        };
        scatter?: any;
        selectionMode?: SeriesSelectionMode;
        selectionStyle?: {
            border?: {
                color?: string | undefined;
                dashStyle?: DashStyle | undefined;
                visible?: boolean;
                width?: number;
            };
            color?: ChartsColor | string | undefined;
            dashStyle?: DashStyle;
            hatching?: {
                direction?: HatchDirection;
                opacity?: number;
                step?: number;
                width?: number;
            };
            highlight?: boolean;
            width?: number;
        };
        showInLegend?: boolean;
        sizeField?: string;
        spline?: any;
        splinearea?: any;
        stack?: string;
        stackedarea?: any;
        stackedbar?: any;
        stackedline?: any;
        stackedspline?: any;
        stackedsplinearea?: any;
        steparea?: any;
        stepline?: any;
        stock?: any;
        tagField?: string;
        type?: SeriesType;
        valueErrorBar?: {
            color?: string;
            displayMode?: ValueErrorBarDisplayMode;
            edgeLength?: number;
            highValueField?: string | undefined;
            lineWidth?: number;
            lowValueField?: string | undefined;
            opacity?: number | undefined;
            type?: undefined | ValueErrorBarType;
            value?: number;
        };
        valueField?: string;
        visible?: boolean;
        width?: number;
    };
    set commonSeriesSettings(value: {
        aggregation?: {
            calculate?: ((aggregationInfo: chartPointAggregationInfoObject, series: chartSeriesObject) => Record<string, any> | Array<Record<string, any>>) | undefined;
            enabled?: boolean;
            method?: ChartSeriesAggregationMethod;
        };
        area?: any;
        argumentField?: string;
        axis?: string | undefined;
        bar?: any;
        barOverlapGroup?: string | undefined;
        barPadding?: number | undefined;
        barWidth?: number | undefined;
        border?: {
            color?: string | undefined;
            dashStyle?: DashStyle | undefined;
            visible?: boolean;
            width?: number;
        };
        bubble?: any;
        candlestick?: any;
        closeValueField?: string;
        color?: ChartsColor | string | undefined;
        cornerRadius?: number;
        dashStyle?: DashStyle;
        fullstackedarea?: any;
        fullstackedbar?: any;
        fullstackedline?: any;
        fullstackedspline?: any;
        fullstackedsplinearea?: any;
        highValueField?: string;
        hoverMode?: SeriesHoverMode;
        hoverStyle?: {
            border?: {
                color?: string | undefined;
                dashStyle?: DashStyle | undefined;
                visible?: boolean;
                width?: number;
            };
            color?: ChartsColor | string | undefined;
            dashStyle?: DashStyle;
            hatching?: {
                direction?: HatchDirection;
                opacity?: number;
                step?: number;
                width?: number;
            };
            highlight?: boolean;
            width?: number;
        };
        ignoreEmptyPoints?: boolean;
        innerColor?: string;
        label?: {
            alignment?: HorizontalAlignment;
            argumentFormat?: Format | undefined;
            backgroundColor?: string | undefined;
            border?: {
                color?: string | undefined;
                dashStyle?: DashStyle | undefined;
                visible?: boolean;
                width?: number;
            };
            connector?: {
                color?: string | undefined;
                visible?: boolean;
                width?: number;
            };
            customizeText?: ((pointInfo: any) => string);
            displayFormat?: string | undefined;
            font?: Font;
            format?: Format | undefined;
            horizontalOffset?: number;
            position?: RelativePosition;
            rotationAngle?: number;
            showForZeroValues?: boolean;
            verticalOffset?: number;
            visible?: boolean;
        };
        line?: any;
        lowValueField?: string;
        maxLabelCount?: number | undefined;
        minBarSize?: number | undefined;
        opacity?: number;
        openValueField?: string;
        pane?: string;
        point?: {
            border?: {
                color?: string | undefined;
                visible?: boolean;
                width?: number;
            };
            color?: ChartsColor | string | undefined;
            hoverMode?: PointInteractionMode;
            hoverStyle?: {
                border?: {
                    color?: string | undefined;
                    visible?: boolean;
                    width?: number;
                };
                color?: ChartsColor | string | undefined;
                size?: number | undefined;
            };
            image?: string | undefined | {
                height?: number | {
                    rangeMaxPoint?: number | undefined;
                    rangeMinPoint?: number | undefined;
                };
                url?: string | undefined | {
                    rangeMaxPoint?: string | undefined;
                    rangeMinPoint?: string | undefined;
                };
                width?: number | {
                    rangeMaxPoint?: number | undefined;
                    rangeMinPoint?: number | undefined;
                };
            };
            selectionMode?: PointInteractionMode;
            selectionStyle?: {
                border?: {
                    color?: string | undefined;
                    visible?: boolean;
                    width?: number;
                };
                color?: ChartsColor | string | undefined;
                size?: number | undefined;
            };
            size?: number;
            symbol?: PointSymbol;
            visible?: boolean;
        };
        rangearea?: any;
        rangebar?: any;
        rangeValue1Field?: string;
        rangeValue2Field?: string;
        reduction?: {
            color?: string;
            level?: FinancialChartReductionLevel;
        };
        scatter?: any;
        selectionMode?: SeriesSelectionMode;
        selectionStyle?: {
            border?: {
                color?: string | undefined;
                dashStyle?: DashStyle | undefined;
                visible?: boolean;
                width?: number;
            };
            color?: ChartsColor | string | undefined;
            dashStyle?: DashStyle;
            hatching?: {
                direction?: HatchDirection;
                opacity?: number;
                step?: number;
                width?: number;
            };
            highlight?: boolean;
            width?: number;
        };
        showInLegend?: boolean;
        sizeField?: string;
        spline?: any;
        splinearea?: any;
        stack?: string;
        stackedarea?: any;
        stackedbar?: any;
        stackedline?: any;
        stackedspline?: any;
        stackedsplinearea?: any;
        steparea?: any;
        stepline?: any;
        stock?: any;
        tagField?: string;
        type?: SeriesType;
        valueErrorBar?: {
            color?: string;
            displayMode?: ValueErrorBarDisplayMode;
            edgeLength?: number;
            highValueField?: string | undefined;
            lineWidth?: number;
            lowValueField?: string | undefined;
            opacity?: number | undefined;
            type?: undefined | ValueErrorBarType;
            value?: number;
        };
        valueField?: string;
        visible?: boolean;
        width?: number;
    });
    /**
     * [descr:dxChartOptions.containerBackgroundColor]
    
     */
    get containerBackgroundColor(): string;
    set containerBackgroundColor(value: string);
    /**
     * [descr:dxChartOptions.crosshair]
    
     */
    get crosshair(): {
        color?: string;
        dashStyle?: DashStyle;
        enabled?: boolean;
        horizontalLine?: boolean | {
            color?: string;
            dashStyle?: DashStyle;
            label?: {
                backgroundColor?: string;
                customizeText?: ((info: {
                    point: chartPointObject;
                    value: Date | number | string;
                    valueText: string;
                }) => string);
                font?: Font;
                format?: Format | undefined;
                visible?: boolean;
            };
            opacity?: number | undefined;
            visible?: boolean;
            width?: number;
        };
        label?: {
            backgroundColor?: string;
            customizeText?: ((info: {
                point: chartPointObject;
                value: Date | number | string;
                valueText: string;
            }) => string);
            font?: Font;
            format?: Format | undefined;
            visible?: boolean;
        };
        opacity?: number | undefined;
        verticalLine?: boolean | {
            color?: string;
            dashStyle?: DashStyle;
            label?: {
                backgroundColor?: string;
                customizeText?: ((info: {
                    point: chartPointObject;
                    value: Date | number | string;
                    valueText: string;
                }) => string);
                font?: Font;
                format?: Format | undefined;
                visible?: boolean;
            };
            opacity?: number | undefined;
            visible?: boolean;
            width?: number;
        };
        width?: number;
    };
    set crosshair(value: {
        color?: string;
        dashStyle?: DashStyle;
        enabled?: boolean;
        horizontalLine?: boolean | {
            color?: string;
            dashStyle?: DashStyle;
            label?: {
                backgroundColor?: string;
                customizeText?: ((info: {
                    point: chartPointObject;
                    value: Date | number | string;
                    valueText: string;
                }) => string);
                font?: Font;
                format?: Format | undefined;
                visible?: boolean;
            };
            opacity?: number | undefined;
            visible?: boolean;
            width?: number;
        };
        label?: {
            backgroundColor?: string;
            customizeText?: ((info: {
                point: chartPointObject;
                value: Date | number | string;
                valueText: string;
            }) => string);
            font?: Font;
            format?: Format | undefined;
            visible?: boolean;
        };
        opacity?: number | undefined;
        verticalLine?: boolean | {
            color?: string;
            dashStyle?: DashStyle;
            label?: {
                backgroundColor?: string;
                customizeText?: ((info: {
                    point: chartPointObject;
                    value: Date | number | string;
                    valueText: string;
                }) => string);
                font?: Font;
                format?: Format | undefined;
                visible?: boolean;
            };
            opacity?: number | undefined;
            visible?: boolean;
            width?: number;
        };
        width?: number;
    });
    /**
     * [descr:dxChartOptions.customizeAnnotation]
    
     */
    get customizeAnnotation(): ((annotation: dxChartAnnotationConfig | any) => dxChartAnnotationConfig) | undefined;
    set customizeAnnotation(value: ((annotation: dxChartAnnotationConfig | any) => dxChartAnnotationConfig) | undefined);
    /**
     * [descr:BaseChartOptions.customizeLabel]
    
     */
    get customizeLabel(): ((pointInfo: any) => SeriesLabel);
    set customizeLabel(value: ((pointInfo: any) => SeriesLabel));
    /**
     * [descr:BaseChartOptions.customizePoint]
    
     */
    get customizePoint(): ((pointInfo: any) => SeriesPoint);
    set customizePoint(value: ((pointInfo: any) => SeriesPoint));
    /**
     * [descr:dxChartOptions.dataPrepareSettings]
    
     */
    get dataPrepareSettings(): {
        checkTypeForAllData?: boolean;
        convertToAxisDataType?: boolean;
        sortingMethod?: boolean | ((a: any, b: any) => number);
    };
    set dataPrepareSettings(value: {
        checkTypeForAllData?: boolean;
        convertToAxisDataType?: boolean;
        sortingMethod?: boolean | ((a: any, b: any) => number);
    });
    /**
     * [descr:BaseChartOptions.dataSource]
    
     */
    get dataSource(): Array<any> | DataSource | DataSourceOptions | null | Store | string;
    set dataSource(value: Array<any> | DataSource | DataSourceOptions | null | Store | string);
    /**
     * [descr:dxChartOptions.defaultPane]
    
     */
    get defaultPane(): string | undefined;
    set defaultPane(value: string | undefined);
    /**
     * [descr:BaseWidgetOptions.disabled]
    
     */
    get disabled(): boolean;
    set disabled(value: boolean);
    /**
     * [descr:DOMComponentOptions.elementAttr]
    
     */
    get elementAttr(): Record<string, any>;
    set elementAttr(value: Record<string, any>);
    /**
     * [descr:BaseWidgetOptions.encodeHtml]
    
     */
    get encodeHtml(): boolean;
    set encodeHtml(value: boolean);
    /**
     * [descr:BaseWidgetOptions.export]
    
     */
    get export(): {
        backgroundColor?: string;
        enabled?: boolean;
        fileName?: string;
        formats?: Array<ExportFormat>;
        margin?: number;
        printingEnabled?: boolean;
        svgToCanvas?: ((svg: any, canvas: any) => any) | undefined;
    };
    set export(value: {
        backgroundColor?: string;
        enabled?: boolean;
        fileName?: string;
        formats?: Array<ExportFormat>;
        margin?: number;
        printingEnabled?: boolean;
        svgToCanvas?: ((svg: any, canvas: any) => any) | undefined;
    });
    /**
     * [descr:dxChartOptions.legend]
    
     */
    get legend(): {
        backgroundColor?: string | undefined;
        border?: {
            color?: string;
            cornerRadius?: number;
            dashStyle?: DashStyle;
            opacity?: number | undefined;
            visible?: boolean;
            width?: number;
        };
        columnCount?: number;
        columnItemSpacing?: number;
        customizeHint?: ((seriesInfo: {
            seriesColor: string;
            seriesIndex: number;
            seriesName: any;
        }) => string);
        customizeItems?: ((items: Array<LegendItem>) => Array<LegendItem>);
        customizeText?: ((seriesInfo: {
            seriesColor: string;
            seriesIndex: number;
            seriesName: any;
        }) => string);
        font?: Font;
        horizontalAlignment?: HorizontalAlignment;
        hoverMode?: LegendHoverMode;
        itemsAlignment?: HorizontalAlignment | undefined;
        itemTextPosition?: Position | undefined;
        margin?: number | {
            bottom?: number;
            left?: number;
            right?: number;
            top?: number;
        };
        markerSize?: number;
        markerTemplate?: any;
        orientation?: Orientation | undefined;
        paddingLeftRight?: number;
        paddingTopBottom?: number;
        position?: RelativePosition;
        rowCount?: number;
        rowItemSpacing?: number;
        title?: string | {
            font?: Font;
            horizontalAlignment?: HorizontalAlignment | undefined;
            margin?: {
                bottom?: number;
                left?: number;
                right?: number;
                top?: number;
            };
            placeholderSize?: number | undefined;
            subtitle?: string | {
                font?: Font;
                offset?: number;
                text?: string | undefined;
            };
            text?: string | undefined;
            verticalAlignment?: VerticalEdge;
        };
        verticalAlignment?: VerticalEdge;
        visible?: boolean;
    };
    set legend(value: {
        backgroundColor?: string | undefined;
        border?: {
            color?: string;
            cornerRadius?: number;
            dashStyle?: DashStyle;
            opacity?: number | undefined;
            visible?: boolean;
            width?: number;
        };
        columnCount?: number;
        columnItemSpacing?: number;
        customizeHint?: ((seriesInfo: {
            seriesColor: string;
            seriesIndex: number;
            seriesName: any;
        }) => string);
        customizeItems?: ((items: Array<LegendItem>) => Array<LegendItem>);
        customizeText?: ((seriesInfo: {
            seriesColor: string;
            seriesIndex: number;
            seriesName: any;
        }) => string);
        font?: Font;
        horizontalAlignment?: HorizontalAlignment;
        hoverMode?: LegendHoverMode;
        itemsAlignment?: HorizontalAlignment | undefined;
        itemTextPosition?: Position | undefined;
        margin?: number | {
            bottom?: number;
            left?: number;
            right?: number;
            top?: number;
        };
        markerSize?: number;
        markerTemplate?: any;
        orientation?: Orientation | undefined;
        paddingLeftRight?: number;
        paddingTopBottom?: number;
        position?: RelativePosition;
        rowCount?: number;
        rowItemSpacing?: number;
        title?: string | {
            font?: Font;
            horizontalAlignment?: HorizontalAlignment | undefined;
            margin?: {
                bottom?: number;
                left?: number;
                right?: number;
                top?: number;
            };
            placeholderSize?: number | undefined;
            subtitle?: string | {
                font?: Font;
                offset?: number;
                text?: string | undefined;
            };
            text?: string | undefined;
            verticalAlignment?: VerticalEdge;
        };
        verticalAlignment?: VerticalEdge;
        visible?: boolean;
    });
    /**
     * [descr:BaseWidgetOptions.loadingIndicator]
    
     */
    get loadingIndicator(): {
        backgroundColor?: string;
        enabled?: boolean;
        font?: Font;
        show?: boolean;
        text?: string;
    };
    set loadingIndicator(value: {
        backgroundColor?: string;
        enabled?: boolean;
        font?: Font;
        show?: boolean;
        text?: string;
    });
    /**
     * [descr:BaseWidgetOptions.margin]
    
     */
    get margin(): {
        bottom?: number;
        left?: number;
        right?: number;
        top?: number;
    };
    set margin(value: {
        bottom?: number;
        left?: number;
        right?: number;
        top?: number;
    });
    /**
     * [descr:dxChartOptions.maxBubbleSize]
    
     */
    get maxBubbleSize(): number;
    set maxBubbleSize(value: number);
    /**
     * [descr:dxChartOptions.minBubbleSize]
    
     */
    get minBubbleSize(): number;
    set minBubbleSize(value: number);
    /**
     * [descr:dxChartOptions.negativesAsZeroes]
    
     */
    get negativesAsZeroes(): boolean;
    set negativesAsZeroes(value: boolean);
    /**
     * [descr:BaseChartOptions.palette]
    
     */
    get palette(): Array<string> | Palette;
    set palette(value: Array<string> | Palette);
    /**
     * [descr:BaseChartOptions.paletteExtensionMode]
    
     */
    get paletteExtensionMode(): PaletteExtensionMode;
    set paletteExtensionMode(value: PaletteExtensionMode);
    /**
     * [descr:dxChartOptions.panes]
    
     */
    get panes(): {
        backgroundColor?: ChartsColor | string;
        border?: {
            bottom?: boolean;
            color?: string;
            dashStyle?: DashStyle;
            left?: boolean;
            opacity?: number | undefined;
            right?: boolean;
            top?: boolean;
            visible?: boolean;
            width?: number;
        };
        height?: number | string | undefined;
        name?: string | undefined;
    }[];
    set panes(value: {
        backgroundColor?: ChartsColor | string;
        border?: {
            bottom?: boolean;
            color?: string;
            dashStyle?: DashStyle;
            left?: boolean;
            opacity?: number | undefined;
            right?: boolean;
            top?: boolean;
            visible?: boolean;
            width?: number;
        };
        height?: number | string | undefined;
        name?: string | undefined;
    }[]);
    /**
     * [descr:BaseWidgetOptions.pathModified]
    
     */
    get pathModified(): boolean;
    set pathModified(value: boolean);
    /**
     * [descr:BaseChartOptions.pointSelectionMode]
    
     */
    get pointSelectionMode(): SingleOrMultiple;
    set pointSelectionMode(value: SingleOrMultiple);
    /**
     * [descr:BaseWidgetOptions.redrawOnResize]
    
     */
    get redrawOnResize(): boolean;
    set redrawOnResize(value: boolean);
    /**
     * [descr:dxChartOptions.resizePanesOnZoom]
    
     */
    get resizePanesOnZoom(): boolean;
    set resizePanesOnZoom(value: boolean);
    /**
     * [descr:dxChartOptions.resolveLabelOverlapping]
    
     */
    get resolveLabelOverlapping(): ChartsLabelOverlap;
    set resolveLabelOverlapping(value: ChartsLabelOverlap);
    /**
     * [descr:dxChartOptions.rotated]
    
     */
    get rotated(): boolean;
    set rotated(value: boolean);
    /**
     * [descr:BaseWidgetOptions.rtlEnabled]
    
     */
    get rtlEnabled(): boolean;
    set rtlEnabled(value: boolean);
    /**
     * [descr:dxChartOptions.scrollBar]
    
     */
    get scrollBar(): {
        color?: string;
        offset?: number;
        opacity?: number | undefined;
        position?: Position;
        visible?: boolean;
        width?: number;
    };
    set scrollBar(value: {
        color?: string;
        offset?: number;
        opacity?: number | undefined;
        position?: Position;
        visible?: boolean;
        width?: number;
    });
    /**
     * [descr:dxChartOptions.series]
    
     */
    get series(): Array<ChartSeries> | ChartSeries | undefined;
    set series(value: Array<ChartSeries> | ChartSeries | undefined);
    /**
     * [descr:dxChartOptions.seriesSelectionMode]
    
     */
    get seriesSelectionMode(): SingleOrMultiple;
    set seriesSelectionMode(value: SingleOrMultiple);
    /**
     * [descr:dxChartOptions.seriesTemplate]
    
     */
    get seriesTemplate(): any;
    set seriesTemplate(value: any);
    /**
     * [descr:BaseWidgetOptions.size]
    
     */
    get size(): {
        height?: number | undefined;
        width?: number | undefined;
    };
    set size(value: {
        height?: number | undefined;
        width?: number | undefined;
    });
    /**
     * [descr:dxChartOptions.stickyHovering]
    
     */
    get stickyHovering(): boolean;
    set stickyHovering(value: boolean);
    /**
     * [descr:dxChartOptions.synchronizeMultiAxes]
    
     */
    get synchronizeMultiAxes(): boolean;
    set synchronizeMultiAxes(value: boolean);
    /**
     * [descr:BaseWidgetOptions.theme]
    
     */
    get theme(): Theme;
    set theme(value: Theme);
    /**
     * [descr:BaseWidgetOptions.title]
    
     */
    get title(): string | {
        font?: Font;
        horizontalAlignment?: HorizontalAlignment;
        margin?: number | {
            bottom?: number;
            left?: number;
            right?: number;
            top?: number;
        };
        placeholderSize?: number | undefined;
        subtitle?: string | {
            font?: Font;
            offset?: number;
            text?: string | undefined;
            textOverflow?: TextOverflow;
            wordWrap?: WordWrap;
        };
        text?: string | undefined;
        textOverflow?: TextOverflow;
        verticalAlignment?: VerticalEdge;
        wordWrap?: WordWrap;
    };
    set title(value: string | {
        font?: Font;
        horizontalAlignment?: HorizontalAlignment;
        margin?: number | {
            bottom?: number;
            left?: number;
            right?: number;
            top?: number;
        };
        placeholderSize?: number | undefined;
        subtitle?: string | {
            font?: Font;
            offset?: number;
            text?: string | undefined;
            textOverflow?: TextOverflow;
            wordWrap?: WordWrap;
        };
        text?: string | undefined;
        textOverflow?: TextOverflow;
        verticalAlignment?: VerticalEdge;
        wordWrap?: WordWrap;
    });
    /**
     * [descr:dxChartOptions.tooltip]
    
     */
    get tooltip(): {
        argumentFormat?: Format | undefined;
        arrowLength?: number;
        border?: {
            color?: string;
            dashStyle?: DashStyle;
            opacity?: number | undefined;
            visible?: boolean;
            width?: number;
        };
        color?: string;
        container?: any | string | undefined;
        contentTemplate?: any;
        cornerRadius?: number;
        customizeTooltip?: ((pointInfo: dxChartPointInfo) => Record<string, any>) | undefined;
        enabled?: boolean;
        font?: Font;
        format?: Format | undefined;
        interactive?: boolean;
        location?: ChartTooltipLocation;
        opacity?: number | undefined;
        paddingLeftRight?: number;
        paddingTopBottom?: number;
        shadow?: {
            blur?: number;
            color?: string;
            offsetX?: number;
            offsetY?: number;
            opacity?: number;
        };
        shared?: boolean;
        zIndex?: number | undefined;
    };
    set tooltip(value: {
        argumentFormat?: Format | undefined;
        arrowLength?: number;
        border?: {
            color?: string;
            dashStyle?: DashStyle;
            opacity?: number | undefined;
            visible?: boolean;
            width?: number;
        };
        color?: string;
        container?: any | string | undefined;
        contentTemplate?: any;
        cornerRadius?: number;
        customizeTooltip?: ((pointInfo: dxChartPointInfo) => Record<string, any>) | undefined;
        enabled?: boolean;
        font?: Font;
        format?: Format | undefined;
        interactive?: boolean;
        location?: ChartTooltipLocation;
        opacity?: number | undefined;
        paddingLeftRight?: number;
        paddingTopBottom?: number;
        shadow?: {
            blur?: number;
            color?: string;
            offsetX?: number;
            offsetY?: number;
            opacity?: number;
        };
        shared?: boolean;
        zIndex?: number | undefined;
    });
    /**
     * [descr:dxChartOptions.valueAxis]
    
     */
    get valueAxis(): {
        aggregatedPointsPosition?: AggregatedPointsPosition;
        allowDecimals?: boolean | undefined;
        autoBreaksEnabled?: boolean;
        axisDivisionFactor?: number;
        breaks?: Array<ScaleBreak> | undefined | {
            endValue?: Date | number | string | undefined;
            startValue?: Date | number | string | undefined;
        }[];
        breakStyle?: {
            color?: string;
            line?: ScaleBreakLineStyle;
            width?: number;
        };
        categories?: Array<Date | number | string>;
        color?: string;
        constantLines?: {
            color?: string;
            dashStyle?: DashStyle;
            displayBehindSeries?: boolean;
            extendAxis?: boolean;
            label?: {
                font?: Font;
                horizontalAlignment?: HorizontalAlignment;
                position?: RelativePosition;
                text?: string | undefined;
                verticalAlignment?: VerticalAlignment;
                visible?: boolean;
            };
            paddingLeftRight?: number;
            paddingTopBottom?: number;
            value?: Date | number | string | undefined;
            width?: number;
        }[];
        constantLineStyle?: {
            color?: string;
            dashStyle?: DashStyle;
            label?: {
                font?: Font;
                horizontalAlignment?: HorizontalAlignment;
                position?: RelativePosition;
                verticalAlignment?: VerticalAlignment;
                visible?: boolean;
            };
            paddingLeftRight?: number;
            paddingTopBottom?: number;
            width?: number;
        };
        customPosition?: Date | number | string | undefined;
        discreteAxisDivisionMode?: DiscreteAxisDivisionMode;
        endOnTick?: boolean | undefined;
        grid?: {
            color?: string;
            opacity?: number | undefined;
            visible?: boolean;
            width?: number;
        };
        inverted?: boolean;
        label?: {
            alignment?: HorizontalAlignment | undefined;
            customizeHint?: ((axisValue: {
                value: Date | number | string;
                valueText: string;
            }) => string);
            customizeText?: ((axisValue: {
                value: Date | number | string;
                valueText: string;
            }) => string);
            displayMode?: ChartLabelDisplayMode;
            font?: Font;
            format?: Format | undefined;
            indentFromAxis?: number;
            overlappingBehavior?: ChartsAxisLabelOverlap;
            position?: Position | RelativePosition;
            rotationAngle?: number;
            staggeringSpacing?: number;
            template?: any;
            textOverflow?: TextOverflow;
            visible?: boolean;
            wordWrap?: WordWrap;
        };
        linearThreshold?: number | undefined;
        logarithmBase?: number;
        maxAutoBreakCount?: number;
        maxValueMargin?: number | undefined;
        minorGrid?: {
            color?: string;
            opacity?: number | undefined;
            visible?: boolean;
            width?: number;
        };
        minorTick?: {
            color?: string;
            length?: number;
            opacity?: number;
            shift?: number;
            visible?: boolean;
            width?: number;
        };
        minorTickCount?: number | undefined;
        minorTickInterval?: number | TimeInterval | {
            days?: number;
            hours?: number;
            milliseconds?: number;
            minutes?: number;
            months?: number;
            quarters?: number;
            seconds?: number;
            weeks?: number;
            years?: number;
        };
        minValueMargin?: number | undefined;
        minVisualRangeLength?: number | TimeInterval | undefined | {
            days?: number;
            hours?: number;
            milliseconds?: number;
            minutes?: number;
            months?: number;
            quarters?: number;
            seconds?: number;
            weeks?: number;
            years?: number;
        };
        multipleAxesSpacing?: number;
        name?: string | undefined;
        offset?: number | undefined;
        opacity?: number | undefined;
        pane?: string | undefined;
        placeholderSize?: null | number;
        position?: Position;
        showZero?: boolean | undefined;
        strips?: {
            color?: string | undefined;
            endValue?: Date | number | string | undefined;
            label?: {
                font?: Font;
                horizontalAlignment?: HorizontalAlignment;
                text?: string | undefined;
                verticalAlignment?: VerticalAlignment;
            };
            paddingLeftRight?: number;
            paddingTopBottom?: number;
            startValue?: Date | number | string | undefined;
        }[];
        stripStyle?: {
            label?: {
                font?: Font;
                horizontalAlignment?: HorizontalAlignment;
                verticalAlignment?: VerticalAlignment;
            };
            paddingLeftRight?: number;
            paddingTopBottom?: number;
        };
        synchronizedValue?: number | undefined;
        tick?: {
            color?: string;
            length?: number;
            opacity?: number | undefined;
            shift?: number;
            visible?: boolean;
            width?: number;
        };
        tickInterval?: number | TimeInterval | {
            days?: number;
            hours?: number;
            milliseconds?: number;
            minutes?: number;
            months?: number;
            quarters?: number;
            seconds?: number;
            weeks?: number;
            years?: number;
        };
        title?: string | {
            alignment?: HorizontalAlignment;
            font?: Font;
            margin?: number;
            text?: string | undefined;
            textOverflow?: TextOverflow;
            wordWrap?: WordWrap;
        };
        type?: AxisScaleType | undefined;
        valueMarginsEnabled?: boolean;
        valueType?: ChartsDataType | undefined;
        visible?: boolean;
        visualRange?: Array<Date | number | string> | CommonChartTypes.VisualRange;
        visualRangeUpdateMode?: ValueAxisVisualRangeUpdateMode;
        wholeRange?: Array<Date | number | string> | undefined | CommonChartTypes.VisualRange;
        width?: number;
    }[];
    set valueAxis(value: {
        aggregatedPointsPosition?: AggregatedPointsPosition;
        allowDecimals?: boolean | undefined;
        autoBreaksEnabled?: boolean;
        axisDivisionFactor?: number;
        breaks?: Array<ScaleBreak> | undefined | {
            endValue?: Date | number | string | undefined;
            startValue?: Date | number | string | undefined;
        }[];
        breakStyle?: {
            color?: string;
            line?: ScaleBreakLineStyle;
            width?: number;
        };
        categories?: Array<Date | number | string>;
        color?: string;
        constantLines?: {
            color?: string;
            dashStyle?: DashStyle;
            displayBehindSeries?: boolean;
            extendAxis?: boolean;
            label?: {
                font?: Font;
                horizontalAlignment?: HorizontalAlignment;
                position?: RelativePosition;
                text?: string | undefined;
                verticalAlignment?: VerticalAlignment;
                visible?: boolean;
            };
            paddingLeftRight?: number;
            paddingTopBottom?: number;
            value?: Date | number | string | undefined;
            width?: number;
        }[];
        constantLineStyle?: {
            color?: string;
            dashStyle?: DashStyle;
            label?: {
                font?: Font;
                horizontalAlignment?: HorizontalAlignment;
                position?: RelativePosition;
                verticalAlignment?: VerticalAlignment;
                visible?: boolean;
            };
            paddingLeftRight?: number;
            paddingTopBottom?: number;
            width?: number;
        };
        customPosition?: Date | number | string | undefined;
        discreteAxisDivisionMode?: DiscreteAxisDivisionMode;
        endOnTick?: boolean | undefined;
        grid?: {
            color?: string;
            opacity?: number | undefined;
            visible?: boolean;
            width?: number;
        };
        inverted?: boolean;
        label?: {
            alignment?: HorizontalAlignment | undefined;
            customizeHint?: ((axisValue: {
                value: Date | number | string;
                valueText: string;
            }) => string);
            customizeText?: ((axisValue: {
                value: Date | number | string;
                valueText: string;
            }) => string);
            displayMode?: ChartLabelDisplayMode;
            font?: Font;
            format?: Format | undefined;
            indentFromAxis?: number;
            overlappingBehavior?: ChartsAxisLabelOverlap;
            position?: Position | RelativePosition;
            rotationAngle?: number;
            staggeringSpacing?: number;
            template?: any;
            textOverflow?: TextOverflow;
            visible?: boolean;
            wordWrap?: WordWrap;
        };
        linearThreshold?: number | undefined;
        logarithmBase?: number;
        maxAutoBreakCount?: number;
        maxValueMargin?: number | undefined;
        minorGrid?: {
            color?: string;
            opacity?: number | undefined;
            visible?: boolean;
            width?: number;
        };
        minorTick?: {
            color?: string;
            length?: number;
            opacity?: number;
            shift?: number;
            visible?: boolean;
            width?: number;
        };
        minorTickCount?: number | undefined;
        minorTickInterval?: number | TimeInterval | {
            days?: number;
            hours?: number;
            milliseconds?: number;
            minutes?: number;
            months?: number;
            quarters?: number;
            seconds?: number;
            weeks?: number;
            years?: number;
        };
        minValueMargin?: number | undefined;
        minVisualRangeLength?: number | TimeInterval | undefined | {
            days?: number;
            hours?: number;
            milliseconds?: number;
            minutes?: number;
            months?: number;
            quarters?: number;
            seconds?: number;
            weeks?: number;
            years?: number;
        };
        multipleAxesSpacing?: number;
        name?: string | undefined;
        offset?: number | undefined;
        opacity?: number | undefined;
        pane?: string | undefined;
        placeholderSize?: null | number;
        position?: Position;
        showZero?: boolean | undefined;
        strips?: {
            color?: string | undefined;
            endValue?: Date | number | string | undefined;
            label?: {
                font?: Font;
                horizontalAlignment?: HorizontalAlignment;
                text?: string | undefined;
                verticalAlignment?: VerticalAlignment;
            };
            paddingLeftRight?: number;
            paddingTopBottom?: number;
            startValue?: Date | number | string | undefined;
        }[];
        stripStyle?: {
            label?: {
                font?: Font;
                horizontalAlignment?: HorizontalAlignment;
                verticalAlignment?: VerticalAlignment;
            };
            paddingLeftRight?: number;
            paddingTopBottom?: number;
        };
        synchronizedValue?: number | undefined;
        tick?: {
            color?: string;
            length?: number;
            opacity?: number | undefined;
            shift?: number;
            visible?: boolean;
            width?: number;
        };
        tickInterval?: number | TimeInterval | {
            days?: number;
            hours?: number;
            milliseconds?: number;
            minutes?: number;
            months?: number;
            quarters?: number;
            seconds?: number;
            weeks?: number;
            years?: number;
        };
        title?: string | {
            alignment?: HorizontalAlignment;
            font?: Font;
            margin?: number;
            text?: string | undefined;
            textOverflow?: TextOverflow;
            wordWrap?: WordWrap;
        };
        type?: AxisScaleType | undefined;
        valueMarginsEnabled?: boolean;
        valueType?: ChartsDataType | undefined;
        visible?: boolean;
        visualRange?: Array<Date | number | string> | CommonChartTypes.VisualRange;
        visualRangeUpdateMode?: ValueAxisVisualRangeUpdateMode;
        wholeRange?: Array<Date | number | string> | undefined | CommonChartTypes.VisualRange;
        width?: number;
    }[]);
    /**
     * [descr:dxChartOptions.zoomAndPan]
    
     */
    get zoomAndPan(): {
        allowMouseWheel?: boolean;
        allowTouchGestures?: boolean;
        argumentAxis?: ChartZoomAndPanMode;
        dragBoxStyle?: {
            color?: string | undefined;
            opacity?: number | undefined;
        };
        dragToZoom?: boolean;
        panKey?: EventKeyModifier;
        valueAxis?: ChartZoomAndPanMode;
    };
    set zoomAndPan(value: {
        allowMouseWheel?: boolean;
        allowTouchGestures?: boolean;
        argumentAxis?: ChartZoomAndPanMode;
        dragBoxStyle?: {
            color?: string | undefined;
            opacity?: number | undefined;
        };
        dragToZoom?: boolean;
        panKey?: EventKeyModifier;
        valueAxis?: ChartZoomAndPanMode;
    });
    /**
    
     * [descr:dxChartOptions.onArgumentAxisClick]
    
    
     */
    onArgumentAxisClick: EventEmitter<ArgumentAxisClickEvent>;
    /**
    
     * [descr:dxChartOptions.onDisposing]
    
    
     */
    onDisposing: EventEmitter<DisposingEvent>;
    /**
    
     * [descr:dxChartOptions.onDone]
    
    
     */
    onDone: EventEmitter<DoneEvent>;
    /**
    
     * [descr:dxChartOptions.onDrawn]
    
    
     */
    onDrawn: EventEmitter<DrawnEvent>;
    /**
    
     * [descr:dxChartOptions.onExported]
    
    
     */
    onExported: EventEmitter<ExportedEvent>;
    /**
    
     * [descr:dxChartOptions.onExporting]
    
    
     */
    onExporting: EventEmitter<ExportingEvent>;
    /**
    
     * [descr:dxChartOptions.onFileSaving]
    
    
     */
    onFileSaving: EventEmitter<FileSavingEvent>;
    /**
    
     * [descr:dxChartOptions.onIncidentOccurred]
    
    
     */
    onIncidentOccurred: EventEmitter<IncidentOccurredEvent>;
    /**
    
     * [descr:dxChartOptions.onInitialized]
    
    
     */
    onInitialized: EventEmitter<InitializedEvent>;
    /**
    
     * [descr:dxChartOptions.onLegendClick]
    
    
     */
    onLegendClick: EventEmitter<LegendClickEvent>;
    /**
    
     * [descr:dxChartOptions.onOptionChanged]
    
    
     */
    onOptionChanged: EventEmitter<OptionChangedEvent>;
    /**
    
     * [descr:dxChartOptions.onPointClick]
    
    
     */
    onPointClick: EventEmitter<PointClickEvent>;
    /**
    
     * [descr:dxChartOptions.onPointHoverChanged]
    
    
     */
    onPointHoverChanged: EventEmitter<PointHoverChangedEvent>;
    /**
    
     * [descr:dxChartOptions.onPointSelectionChanged]
    
    
     */
    onPointSelectionChanged: EventEmitter<PointSelectionChangedEvent>;
    /**
    
     * [descr:dxChartOptions.onSeriesClick]
    
    
     */
    onSeriesClick: EventEmitter<SeriesClickEvent>;
    /**
    
     * [descr:dxChartOptions.onSeriesHoverChanged]
    
    
     */
    onSeriesHoverChanged: EventEmitter<SeriesHoverChangedEvent>;
    /**
    
     * [descr:dxChartOptions.onSeriesSelectionChanged]
    
    
     */
    onSeriesSelectionChanged: EventEmitter<SeriesSelectionChangedEvent>;
    /**
    
     * [descr:dxChartOptions.onTooltipHidden]
    
    
     */
    onTooltipHidden: EventEmitter<TooltipHiddenEvent>;
    /**
    
     * [descr:dxChartOptions.onTooltipShown]
    
    
     */
    onTooltipShown: EventEmitter<TooltipShownEvent>;
    /**
    
     * [descr:dxChartOptions.onZoomEnd]
    
    
     */
    onZoomEnd: EventEmitter<ZoomEndEvent>;
    /**
    
     * [descr:dxChartOptions.onZoomStart]
    
    
     */
    onZoomStart: EventEmitter<ZoomStartEvent>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    adaptiveLayoutChange: EventEmitter<{
        height?: number;
        keepLabels?: boolean;
        width?: number;
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    adjustOnZoomChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    animationChange: EventEmitter<boolean | {
        duration?: number;
        easing?: AnimationEaseMode;
        enabled?: boolean;
        maxPointCountSupported?: number;
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    annotationsChange: EventEmitter<Array<any | dxChartAnnotationConfig>>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    argumentAxisChange: EventEmitter<{
        aggregatedPointsPosition?: AggregatedPointsPosition;
        aggregationGroupWidth?: number | undefined;
        aggregationInterval?: number | TimeInterval | {
            days?: number;
            hours?: number;
            milliseconds?: number;
            minutes?: number;
            months?: number;
            quarters?: number;
            seconds?: number;
            weeks?: number;
            years?: number;
        };
        allowDecimals?: boolean | undefined;
        argumentType?: ChartsDataType | undefined;
        axisDivisionFactor?: number;
        breaks?: Array<ScaleBreak> | undefined | {
            endValue?: Date | number | string | undefined;
            startValue?: Date | number | string | undefined;
        }[];
        breakStyle?: {
            color?: string;
            line?: ScaleBreakLineStyle;
            width?: number;
        };
        categories?: Array<Date | number | string>;
        color?: string;
        constantLines?: {
            color?: string;
            dashStyle?: DashStyle;
            displayBehindSeries?: boolean;
            extendAxis?: boolean;
            label?: {
                font?: Font;
                horizontalAlignment?: HorizontalAlignment;
                position?: RelativePosition;
                text?: string | undefined;
                verticalAlignment?: VerticalAlignment;
                visible?: boolean;
            };
            paddingLeftRight?: number;
            paddingTopBottom?: number;
            value?: Date | number | string | undefined;
            width?: number;
        }[];
        constantLineStyle?: {
            color?: string;
            dashStyle?: DashStyle;
            label?: {
                font?: Font;
                horizontalAlignment?: HorizontalAlignment;
                position?: RelativePosition;
                verticalAlignment?: VerticalAlignment;
                visible?: boolean;
            };
            paddingLeftRight?: number;
            paddingTopBottom?: number;
            width?: number;
        };
        customPosition?: Date | number | string | undefined;
        customPositionAxis?: string | undefined;
        discreteAxisDivisionMode?: DiscreteAxisDivisionMode;
        endOnTick?: boolean;
        grid?: {
            color?: string;
            opacity?: number | undefined;
            visible?: boolean;
            width?: number;
        };
        holidays?: Array<Date | string> | Array<number> | undefined;
        hoverMode?: ArgumentAxisHoverMode;
        inverted?: boolean;
        label?: {
            alignment?: HorizontalAlignment | undefined;
            customizeHint?: ((argument: {
                value: Date | number | string;
                valueText: string;
            }) => string);
            customizeText?: ((argument: {
                value: Date | number | string;
                valueText: string;
            }) => string);
            displayMode?: ChartLabelDisplayMode;
            font?: Font;
            format?: Format | undefined;
            indentFromAxis?: number;
            overlappingBehavior?: ChartsAxisLabelOverlap;
            position?: Position | RelativePosition;
            rotationAngle?: number;
            staggeringSpacing?: number;
            template?: any;
            textOverflow?: TextOverflow;
            visible?: boolean;
            wordWrap?: WordWrap;
        };
        linearThreshold?: number | undefined;
        logarithmBase?: number;
        maxValueMargin?: number | undefined;
        minorGrid?: {
            color?: string;
            opacity?: number | undefined;
            visible?: boolean;
            width?: number;
        };
        minorTick?: {
            color?: string;
            length?: number;
            opacity?: number;
            shift?: number;
            visible?: boolean;
            width?: number;
        };
        minorTickCount?: number | undefined;
        minorTickInterval?: number | TimeInterval | {
            days?: number;
            hours?: number;
            milliseconds?: number;
            minutes?: number;
            months?: number;
            quarters?: number;
            seconds?: number;
            weeks?: number;
            years?: number;
        };
        minValueMargin?: number | undefined;
        minVisualRangeLength?: number | TimeInterval | undefined | {
            days?: number;
            hours?: number;
            milliseconds?: number;
            minutes?: number;
            months?: number;
            quarters?: number;
            seconds?: number;
            weeks?: number;
            years?: number;
        };
        offset?: number | undefined;
        opacity?: number | undefined;
        placeholderSize?: null | number;
        position?: Position;
        singleWorkdays?: Array<Date | string> | Array<number> | undefined;
        strips?: {
            color?: string | undefined;
            endValue?: Date | number | string | undefined;
            label?: {
                font?: Font;
                horizontalAlignment?: HorizontalAlignment;
                text?: string | undefined;
                verticalAlignment?: VerticalAlignment;
            };
            paddingLeftRight?: number;
            paddingTopBottom?: number;
            startValue?: Date | number | string | undefined;
        }[];
        stripStyle?: {
            label?: {
                font?: Font;
                horizontalAlignment?: HorizontalAlignment;
                verticalAlignment?: VerticalAlignment;
            };
            paddingLeftRight?: number;
            paddingTopBottom?: number;
        };
        tick?: {
            color?: string;
            length?: number;
            opacity?: number | undefined;
            shift?: number;
            visible?: boolean;
            width?: number;
        };
        tickInterval?: number | TimeInterval | {
            days?: number;
            hours?: number;
            milliseconds?: number;
            minutes?: number;
            months?: number;
            quarters?: number;
            seconds?: number;
            weeks?: number;
            years?: number;
        };
        title?: string | {
            alignment?: HorizontalAlignment;
            font?: Font;
            margin?: number;
            text?: string | undefined;
            textOverflow?: TextOverflow;
            wordWrap?: WordWrap;
        };
        type?: AxisScaleType | undefined;
        valueMarginsEnabled?: boolean;
        visible?: boolean;
        visualRange?: Array<Date | number | string> | CommonChartTypes.VisualRange;
        visualRangeUpdateMode?: VisualRangeUpdateMode;
        wholeRange?: Array<Date | number | string> | undefined | CommonChartTypes.VisualRange;
        width?: number;
        workdaysOnly?: boolean;
        workWeek?: Array<number>;
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    autoHidePointMarkersChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    barGroupPaddingChange: EventEmitter<number>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    barGroupWidthChange: EventEmitter<number | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    commonAnnotationSettingsChange: EventEmitter<dxChartCommonAnnotationConfig>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    commonAxisSettingsChange: EventEmitter<{
        aggregatedPointsPosition?: AggregatedPointsPosition;
        allowDecimals?: boolean | undefined;
        breakStyle?: {
            color?: string;
            line?: ScaleBreakLineStyle;
            width?: number;
        };
        color?: string;
        constantLineStyle?: {
            color?: string;
            dashStyle?: DashStyle;
            label?: {
                font?: Font;
                position?: RelativePosition;
                visible?: boolean;
            };
            paddingLeftRight?: number;
            paddingTopBottom?: number;
            width?: number;
        };
        discreteAxisDivisionMode?: DiscreteAxisDivisionMode;
        endOnTick?: boolean | undefined;
        grid?: {
            color?: string;
            opacity?: number | undefined;
            visible?: boolean;
            width?: number;
        };
        inverted?: boolean;
        label?: {
            alignment?: HorizontalAlignment | undefined;
            displayMode?: ChartLabelDisplayMode;
            font?: Font;
            indentFromAxis?: number;
            overlappingBehavior?: ChartsAxisLabelOverlap;
            position?: Position | RelativePosition;
            rotationAngle?: number;
            staggeringSpacing?: number;
            template?: any;
            textOverflow?: TextOverflow;
            visible?: boolean;
            wordWrap?: WordWrap;
        };
        maxValueMargin?: number | undefined;
        minorGrid?: {
            color?: string;
            opacity?: number | undefined;
            visible?: boolean;
            width?: number;
        };
        minorTick?: {
            color?: string;
            length?: number;
            opacity?: number;
            shift?: number;
            visible?: boolean;
            width?: number;
        };
        minValueMargin?: number | undefined;
        opacity?: number | undefined;
        placeholderSize?: null | number;
        stripStyle?: {
            label?: {
                font?: Font;
                horizontalAlignment?: HorizontalAlignment;
                verticalAlignment?: VerticalAlignment;
            };
            paddingLeftRight?: number;
            paddingTopBottom?: number;
        };
        tick?: {
            color?: string;
            length?: number;
            opacity?: number | undefined;
            shift?: number;
            visible?: boolean;
            width?: number;
        };
        title?: {
            alignment?: HorizontalAlignment;
            font?: Font;
            margin?: number;
            textOverflow?: TextOverflow;
            wordWrap?: WordWrap;
        };
        valueMarginsEnabled?: boolean;
        visible?: boolean;
        width?: number;
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    commonPaneSettingsChange: EventEmitter<{
        backgroundColor?: ChartsColor | string;
        border?: {
            bottom?: boolean;
            color?: string;
            dashStyle?: DashStyle;
            left?: boolean;
            opacity?: number | undefined;
            right?: boolean;
            top?: boolean;
            visible?: boolean;
            width?: number;
        };
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    commonSeriesSettingsChange: EventEmitter<{
        aggregation?: {
            calculate?: ((aggregationInfo: chartPointAggregationInfoObject, series: chartSeriesObject) => Record<string, any> | Array<Record<string, any>>) | undefined;
            enabled?: boolean;
            method?: ChartSeriesAggregationMethod;
        };
        area?: any;
        argumentField?: string;
        axis?: string | undefined;
        bar?: any;
        barOverlapGroup?: string | undefined;
        barPadding?: number | undefined;
        barWidth?: number | undefined;
        border?: {
            color?: string | undefined;
            dashStyle?: DashStyle | undefined;
            visible?: boolean;
            width?: number;
        };
        bubble?: any;
        candlestick?: any;
        closeValueField?: string;
        color?: ChartsColor | string | undefined;
        cornerRadius?: number;
        dashStyle?: DashStyle;
        fullstackedarea?: any;
        fullstackedbar?: any;
        fullstackedline?: any;
        fullstackedspline?: any;
        fullstackedsplinearea?: any;
        highValueField?: string;
        hoverMode?: SeriesHoverMode;
        hoverStyle?: {
            border?: {
                color?: string | undefined;
                dashStyle?: DashStyle | undefined;
                visible?: boolean;
                width?: number;
            };
            color?: ChartsColor | string | undefined;
            dashStyle?: DashStyle;
            hatching?: {
                direction?: HatchDirection;
                opacity?: number;
                step?: number;
                width?: number;
            };
            highlight?: boolean;
            width?: number;
        };
        ignoreEmptyPoints?: boolean;
        innerColor?: string;
        label?: {
            alignment?: HorizontalAlignment;
            argumentFormat?: Format | undefined;
            backgroundColor?: string | undefined;
            border?: {
                color?: string | undefined;
                dashStyle?: DashStyle | undefined;
                visible?: boolean;
                width?: number;
            };
            connector?: {
                color?: string | undefined;
                visible?: boolean;
                width?: number;
            };
            customizeText?: ((pointInfo: any) => string);
            displayFormat?: string | undefined;
            font?: Font;
            format?: Format | undefined;
            horizontalOffset?: number;
            position?: RelativePosition;
            rotationAngle?: number;
            showForZeroValues?: boolean;
            verticalOffset?: number;
            visible?: boolean;
        };
        line?: any;
        lowValueField?: string;
        maxLabelCount?: number | undefined;
        minBarSize?: number | undefined;
        opacity?: number;
        openValueField?: string;
        pane?: string;
        point?: {
            border?: {
                color?: string | undefined;
                visible?: boolean;
                width?: number;
            };
            color?: ChartsColor | string | undefined;
            hoverMode?: PointInteractionMode;
            hoverStyle?: {
                border?: {
                    color?: string | undefined;
                    visible?: boolean;
                    width?: number;
                };
                color?: ChartsColor | string | undefined;
                size?: number | undefined;
            };
            image?: string | undefined | {
                height?: number | {
                    rangeMaxPoint?: number | undefined;
                    rangeMinPoint?: number | undefined;
                };
                url?: string | undefined | {
                    rangeMaxPoint?: string | undefined;
                    rangeMinPoint?: string | undefined;
                };
                width?: number | {
                    rangeMaxPoint?: number | undefined;
                    rangeMinPoint?: number | undefined;
                };
            };
            selectionMode?: PointInteractionMode;
            selectionStyle?: {
                border?: {
                    color?: string | undefined;
                    visible?: boolean;
                    width?: number;
                };
                color?: ChartsColor | string | undefined;
                size?: number | undefined;
            };
            size?: number;
            symbol?: PointSymbol;
            visible?: boolean;
        };
        rangearea?: any;
        rangebar?: any;
        rangeValue1Field?: string;
        rangeValue2Field?: string;
        reduction?: {
            color?: string;
            level?: FinancialChartReductionLevel;
        };
        scatter?: any;
        selectionMode?: SeriesSelectionMode;
        selectionStyle?: {
            border?: {
                color?: string | undefined;
                dashStyle?: DashStyle | undefined;
                visible?: boolean;
                width?: number;
            };
            color?: ChartsColor | string | undefined;
            dashStyle?: DashStyle;
            hatching?: {
                direction?: HatchDirection;
                opacity?: number;
                step?: number;
                width?: number;
            };
            highlight?: boolean;
            width?: number;
        };
        showInLegend?: boolean;
        sizeField?: string;
        spline?: any;
        splinearea?: any;
        stack?: string;
        stackedarea?: any;
        stackedbar?: any;
        stackedline?: any;
        stackedspline?: any;
        stackedsplinearea?: any;
        steparea?: any;
        stepline?: any;
        stock?: any;
        tagField?: string;
        type?: SeriesType;
        valueErrorBar?: {
            color?: string;
            displayMode?: ValueErrorBarDisplayMode;
            edgeLength?: number;
            highValueField?: string | undefined;
            lineWidth?: number;
            lowValueField?: string | undefined;
            opacity?: number | undefined;
            type?: undefined | ValueErrorBarType;
            value?: number;
        };
        valueField?: string;
        visible?: boolean;
        width?: number;
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    containerBackgroundColorChange: EventEmitter<string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    crosshairChange: EventEmitter<{
        color?: string;
        dashStyle?: DashStyle;
        enabled?: boolean;
        horizontalLine?: boolean | {
            color?: string;
            dashStyle?: DashStyle;
            label?: {
                backgroundColor?: string;
                customizeText?: ((info: {
                    point: chartPointObject;
                    value: Date | number | string;
                    valueText: string;
                }) => string);
                font?: Font;
                format?: Format | undefined;
                visible?: boolean;
            };
            opacity?: number | undefined;
            visible?: boolean;
            width?: number;
        };
        label?: {
            backgroundColor?: string;
            customizeText?: ((info: {
                point: chartPointObject;
                value: Date | number | string;
                valueText: string;
            }) => string);
            font?: Font;
            format?: Format | undefined;
            visible?: boolean;
        };
        opacity?: number | undefined;
        verticalLine?: boolean | {
            color?: string;
            dashStyle?: DashStyle;
            label?: {
                backgroundColor?: string;
                customizeText?: ((info: {
                    point: chartPointObject;
                    value: Date | number | string;
                    valueText: string;
                }) => string);
                font?: Font;
                format?: Format | undefined;
                visible?: boolean;
            };
            opacity?: number | undefined;
            visible?: boolean;
            width?: number;
        };
        width?: number;
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    customizeAnnotationChange: EventEmitter<((annotation: dxChartAnnotationConfig | any) => dxChartAnnotationConfig) | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    customizeLabelChange: EventEmitter<((pointInfo: any) => SeriesLabel)>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    customizePointChange: EventEmitter<((pointInfo: any) => SeriesPoint)>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    dataPrepareSettingsChange: EventEmitter<{
        checkTypeForAllData?: boolean;
        convertToAxisDataType?: boolean;
        sortingMethod?: boolean | ((a: any, b: any) => number);
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    dataSourceChange: EventEmitter<Array<any> | DataSource | DataSourceOptions | null | Store | string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    defaultPaneChange: EventEmitter<string | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    disabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    elementAttrChange: EventEmitter<Record<string, any>>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    encodeHtmlChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    exportChange: EventEmitter<{
        backgroundColor?: string;
        enabled?: boolean;
        fileName?: string;
        formats?: Array<ExportFormat>;
        margin?: number;
        printingEnabled?: boolean;
        svgToCanvas?: ((svg: any, canvas: any) => any) | undefined;
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    legendChange: EventEmitter<{
        backgroundColor?: string | undefined;
        border?: {
            color?: string;
            cornerRadius?: number;
            dashStyle?: DashStyle;
            opacity?: number | undefined;
            visible?: boolean;
            width?: number;
        };
        columnCount?: number;
        columnItemSpacing?: number;
        customizeHint?: ((seriesInfo: {
            seriesColor: string;
            seriesIndex: number;
            seriesName: any;
        }) => string);
        customizeItems?: ((items: Array<LegendItem>) => Array<LegendItem>);
        customizeText?: ((seriesInfo: {
            seriesColor: string;
            seriesIndex: number;
            seriesName: any;
        }) => string);
        font?: Font;
        horizontalAlignment?: HorizontalAlignment;
        hoverMode?: LegendHoverMode;
        itemsAlignment?: HorizontalAlignment | undefined;
        itemTextPosition?: Position | undefined;
        margin?: number | {
            bottom?: number;
            left?: number;
            right?: number;
            top?: number;
        };
        markerSize?: number;
        markerTemplate?: any;
        orientation?: Orientation | undefined;
        paddingLeftRight?: number;
        paddingTopBottom?: number;
        position?: RelativePosition;
        rowCount?: number;
        rowItemSpacing?: number;
        title?: string | {
            font?: Font;
            horizontalAlignment?: HorizontalAlignment | undefined;
            margin?: {
                bottom?: number;
                left?: number;
                right?: number;
                top?: number;
            };
            placeholderSize?: number | undefined;
            subtitle?: string | {
                font?: Font;
                offset?: number;
                text?: string | undefined;
            };
            text?: string | undefined;
            verticalAlignment?: VerticalEdge;
        };
        verticalAlignment?: VerticalEdge;
        visible?: boolean;
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    loadingIndicatorChange: EventEmitter<{
        backgroundColor?: string;
        enabled?: boolean;
        font?: Font;
        show?: boolean;
        text?: string;
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    marginChange: EventEmitter<{
        bottom?: number;
        left?: number;
        right?: number;
        top?: number;
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    maxBubbleSizeChange: EventEmitter<number>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    minBubbleSizeChange: EventEmitter<number>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    negativesAsZeroesChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    paletteChange: EventEmitter<Array<string> | Palette>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    paletteExtensionModeChange: EventEmitter<PaletteExtensionMode>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    panesChange: EventEmitter<{
        backgroundColor?: ChartsColor | string;
        border?: {
            bottom?: boolean;
            color?: string;
            dashStyle?: DashStyle;
            left?: boolean;
            opacity?: number | undefined;
            right?: boolean;
            top?: boolean;
            visible?: boolean;
            width?: number;
        };
        height?: number | string | undefined;
        name?: string | undefined;
    }[]>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    pathModifiedChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    pointSelectionModeChange: EventEmitter<SingleOrMultiple>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    redrawOnResizeChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    resizePanesOnZoomChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    resolveLabelOverlappingChange: EventEmitter<ChartsLabelOverlap>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    rotatedChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    rtlEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    scrollBarChange: EventEmitter<{
        color?: string;
        offset?: number;
        opacity?: number | undefined;
        position?: Position;
        visible?: boolean;
        width?: number;
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    seriesChange: EventEmitter<Array<ChartSeries> | ChartSeries | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    seriesSelectionModeChange: EventEmitter<SingleOrMultiple>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    seriesTemplateChange: EventEmitter<any>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    sizeChange: EventEmitter<{
        height?: number | undefined;
        width?: number | undefined;
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    stickyHoveringChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    synchronizeMultiAxesChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    themeChange: EventEmitter<Theme>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    titleChange: EventEmitter<string | {
        font?: Font;
        horizontalAlignment?: HorizontalAlignment;
        margin?: number | {
            bottom?: number;
            left?: number;
            right?: number;
            top?: number;
        };
        placeholderSize?: number | undefined;
        subtitle?: string | {
            font?: Font;
            offset?: number;
            text?: string | undefined;
            textOverflow?: TextOverflow;
            wordWrap?: WordWrap;
        };
        text?: string | undefined;
        textOverflow?: TextOverflow;
        verticalAlignment?: VerticalEdge;
        wordWrap?: WordWrap;
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    tooltipChange: EventEmitter<{
        argumentFormat?: Format | undefined;
        arrowLength?: number;
        border?: {
            color?: string;
            dashStyle?: DashStyle;
            opacity?: number | undefined;
            visible?: boolean;
            width?: number;
        };
        color?: string;
        container?: any | string | undefined;
        contentTemplate?: any;
        cornerRadius?: number;
        customizeTooltip?: ((pointInfo: dxChartPointInfo) => Record<string, any>) | undefined;
        enabled?: boolean;
        font?: Font;
        format?: Format | undefined;
        interactive?: boolean;
        location?: ChartTooltipLocation;
        opacity?: number | undefined;
        paddingLeftRight?: number;
        paddingTopBottom?: number;
        shadow?: {
            blur?: number;
            color?: string;
            offsetX?: number;
            offsetY?: number;
            opacity?: number;
        };
        shared?: boolean;
        zIndex?: number | undefined;
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    valueAxisChange: EventEmitter<{
        aggregatedPointsPosition?: AggregatedPointsPosition;
        allowDecimals?: boolean | undefined;
        autoBreaksEnabled?: boolean;
        axisDivisionFactor?: number;
        breaks?: Array<ScaleBreak> | undefined | {
            endValue?: Date | number | string | undefined;
            startValue?: Date | number | string | undefined;
        }[];
        breakStyle?: {
            color?: string;
            line?: ScaleBreakLineStyle;
            width?: number;
        };
        categories?: Array<Date | number | string>;
        color?: string;
        constantLines?: {
            color?: string;
            dashStyle?: DashStyle;
            displayBehindSeries?: boolean;
            extendAxis?: boolean;
            label?: {
                font?: Font;
                horizontalAlignment?: HorizontalAlignment;
                position?: RelativePosition;
                text?: string | undefined;
                verticalAlignment?: VerticalAlignment;
                visible?: boolean;
            };
            paddingLeftRight?: number;
            paddingTopBottom?: number;
            value?: Date | number | string | undefined;
            width?: number;
        }[];
        constantLineStyle?: {
            color?: string;
            dashStyle?: DashStyle;
            label?: {
                font?: Font;
                horizontalAlignment?: HorizontalAlignment;
                position?: RelativePosition;
                verticalAlignment?: VerticalAlignment;
                visible?: boolean;
            };
            paddingLeftRight?: number;
            paddingTopBottom?: number;
            width?: number;
        };
        customPosition?: Date | number | string | undefined;
        discreteAxisDivisionMode?: DiscreteAxisDivisionMode;
        endOnTick?: boolean | undefined;
        grid?: {
            color?: string;
            opacity?: number | undefined;
            visible?: boolean;
            width?: number;
        };
        inverted?: boolean;
        label?: {
            alignment?: HorizontalAlignment | undefined;
            customizeHint?: ((axisValue: {
                value: Date | number | string;
                valueText: string;
            }) => string);
            customizeText?: ((axisValue: {
                value: Date | number | string;
                valueText: string;
            }) => string);
            displayMode?: ChartLabelDisplayMode;
            font?: Font;
            format?: Format | undefined;
            indentFromAxis?: number;
            overlappingBehavior?: ChartsAxisLabelOverlap;
            position?: Position | RelativePosition;
            rotationAngle?: number;
            staggeringSpacing?: number;
            template?: any;
            textOverflow?: TextOverflow;
            visible?: boolean;
            wordWrap?: WordWrap;
        };
        linearThreshold?: number | undefined;
        logarithmBase?: number;
        maxAutoBreakCount?: number;
        maxValueMargin?: number | undefined;
        minorGrid?: {
            color?: string;
            opacity?: number | undefined;
            visible?: boolean;
            width?: number;
        };
        minorTick?: {
            color?: string;
            length?: number;
            opacity?: number;
            shift?: number;
            visible?: boolean;
            width?: number;
        };
        minorTickCount?: number | undefined;
        minorTickInterval?: number | TimeInterval | {
            days?: number;
            hours?: number;
            milliseconds?: number;
            minutes?: number;
            months?: number;
            quarters?: number;
            seconds?: number;
            weeks?: number;
            years?: number;
        };
        minValueMargin?: number | undefined;
        minVisualRangeLength?: number | TimeInterval | undefined | {
            days?: number;
            hours?: number;
            milliseconds?: number;
            minutes?: number;
            months?: number;
            quarters?: number;
            seconds?: number;
            weeks?: number;
            years?: number;
        };
        multipleAxesSpacing?: number;
        name?: string | undefined;
        offset?: number | undefined;
        opacity?: number | undefined;
        pane?: string | undefined;
        placeholderSize?: null | number;
        position?: Position;
        showZero?: boolean | undefined;
        strips?: {
            color?: string | undefined;
            endValue?: Date | number | string | undefined;
            label?: {
                font?: Font;
                horizontalAlignment?: HorizontalAlignment;
                text?: string | undefined;
                verticalAlignment?: VerticalAlignment;
            };
            paddingLeftRight?: number;
            paddingTopBottom?: number;
            startValue?: Date | number | string | undefined;
        }[];
        stripStyle?: {
            label?: {
                font?: Font;
                horizontalAlignment?: HorizontalAlignment;
                verticalAlignment?: VerticalAlignment;
            };
            paddingLeftRight?: number;
            paddingTopBottom?: number;
        };
        synchronizedValue?: number | undefined;
        tick?: {
            color?: string;
            length?: number;
            opacity?: number | undefined;
            shift?: number;
            visible?: boolean;
            width?: number;
        };
        tickInterval?: number | TimeInterval | {
            days?: number;
            hours?: number;
            milliseconds?: number;
            minutes?: number;
            months?: number;
            quarters?: number;
            seconds?: number;
            weeks?: number;
            years?: number;
        };
        title?: string | {
            alignment?: HorizontalAlignment;
            font?: Font;
            margin?: number;
            text?: string | undefined;
            textOverflow?: TextOverflow;
            wordWrap?: WordWrap;
        };
        type?: AxisScaleType | undefined;
        valueMarginsEnabled?: boolean;
        valueType?: ChartsDataType | undefined;
        visible?: boolean;
        visualRange?: Array<Date | number | string> | CommonChartTypes.VisualRange;
        visualRangeUpdateMode?: ValueAxisVisualRangeUpdateMode;
        wholeRange?: Array<Date | number | string> | undefined | CommonChartTypes.VisualRange;
        width?: number;
    }[]>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    zoomAndPanChange: EventEmitter<{
        allowMouseWheel?: boolean;
        allowTouchGestures?: boolean;
        argumentAxis?: ChartZoomAndPanMode;
        dragBoxStyle?: {
            color?: string | undefined;
            opacity?: number | undefined;
        };
        dragToZoom?: boolean;
        panKey?: EventKeyModifier;
        valueAxis?: ChartZoomAndPanMode;
    }>;
    constructor(elementRef: ElementRef, ngZone: NgZone, templateHost: DxTemplateHost, _watcherHelper: WatcherHelper, _idh: IterableDifferHelper, optionHost: NestedOptionHost, transferState: TransferState, platformId: any);
    protected _createInstance(element: any, options: any): DxChart;
    ngOnDestroy(): void;
    ngOnChanges(changes: SimpleChanges): void;
    setupChanges(prop: string, changes: SimpleChanges): void;
    ngDoCheck(): void;
    _setOption(name: string, value: any): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxChartComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxChartComponent, "dx-chart", never, { "adaptiveLayout": { "alias": "adaptiveLayout"; "required": false; }; "adjustOnZoom": { "alias": "adjustOnZoom"; "required": false; }; "animation": { "alias": "animation"; "required": false; }; "annotations": { "alias": "annotations"; "required": false; }; "argumentAxis": { "alias": "argumentAxis"; "required": false; }; "autoHidePointMarkers": { "alias": "autoHidePointMarkers"; "required": false; }; "barGroupPadding": { "alias": "barGroupPadding"; "required": false; }; "barGroupWidth": { "alias": "barGroupWidth"; "required": false; }; "commonAnnotationSettings": { "alias": "commonAnnotationSettings"; "required": false; }; "commonAxisSettings": { "alias": "commonAxisSettings"; "required": false; }; "commonPaneSettings": { "alias": "commonPaneSettings"; "required": false; }; "commonSeriesSettings": { "alias": "commonSeriesSettings"; "required": false; }; "containerBackgroundColor": { "alias": "containerBackgroundColor"; "required": false; }; "crosshair": { "alias": "crosshair"; "required": false; }; "customizeAnnotation": { "alias": "customizeAnnotation"; "required": false; }; "customizeLabel": { "alias": "customizeLabel"; "required": false; }; "customizePoint": { "alias": "customizePoint"; "required": false; }; "dataPrepareSettings": { "alias": "dataPrepareSettings"; "required": false; }; "dataSource": { "alias": "dataSource"; "required": false; }; "defaultPane": { "alias": "defaultPane"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "elementAttr": { "alias": "elementAttr"; "required": false; }; "encodeHtml": { "alias": "encodeHtml"; "required": false; }; "export": { "alias": "export"; "required": false; }; "legend": { "alias": "legend"; "required": false; }; "loadingIndicator": { "alias": "loadingIndicator"; "required": false; }; "margin": { "alias": "margin"; "required": false; }; "maxBubbleSize": { "alias": "maxBubbleSize"; "required": false; }; "minBubbleSize": { "alias": "minBubbleSize"; "required": false; }; "negativesAsZeroes": { "alias": "negativesAsZeroes"; "required": false; }; "palette": { "alias": "palette"; "required": false; }; "paletteExtensionMode": { "alias": "paletteExtensionMode"; "required": false; }; "panes": { "alias": "panes"; "required": false; }; "pathModified": { "alias": "pathModified"; "required": false; }; "pointSelectionMode": { "alias": "pointSelectionMode"; "required": false; }; "redrawOnResize": { "alias": "redrawOnResize"; "required": false; }; "resizePanesOnZoom": { "alias": "resizePanesOnZoom"; "required": false; }; "resolveLabelOverlapping": { "alias": "resolveLabelOverlapping"; "required": false; }; "rotated": { "alias": "rotated"; "required": false; }; "rtlEnabled": { "alias": "rtlEnabled"; "required": false; }; "scrollBar": { "alias": "scrollBar"; "required": false; }; "series": { "alias": "series"; "required": false; }; "seriesSelectionMode": { "alias": "seriesSelectionMode"; "required": false; }; "seriesTemplate": { "alias": "seriesTemplate"; "required": false; }; "size": { "alias": "size"; "required": false; }; "stickyHovering": { "alias": "stickyHovering"; "required": false; }; "synchronizeMultiAxes": { "alias": "synchronizeMultiAxes"; "required": false; }; "theme": { "alias": "theme"; "required": false; }; "title": { "alias": "title"; "required": false; }; "tooltip": { "alias": "tooltip"; "required": false; }; "valueAxis": { "alias": "valueAxis"; "required": false; }; "zoomAndPan": { "alias": "zoomAndPan"; "required": false; }; }, { "onArgumentAxisClick": "onArgumentAxisClick"; "onDisposing": "onDisposing"; "onDone": "onDone"; "onDrawn": "onDrawn"; "onExported": "onExported"; "onExporting": "onExporting"; "onFileSaving": "onFileSaving"; "onIncidentOccurred": "onIncidentOccurred"; "onInitialized": "onInitialized"; "onLegendClick": "onLegendClick"; "onOptionChanged": "onOptionChanged"; "onPointClick": "onPointClick"; "onPointHoverChanged": "onPointHoverChanged"; "onPointSelectionChanged": "onPointSelectionChanged"; "onSeriesClick": "onSeriesClick"; "onSeriesHoverChanged": "onSeriesHoverChanged"; "onSeriesSelectionChanged": "onSeriesSelectionChanged"; "onTooltipHidden": "onTooltipHidden"; "onTooltipShown": "onTooltipShown"; "onZoomEnd": "onZoomEnd"; "onZoomStart": "onZoomStart"; "adaptiveLayoutChange": "adaptiveLayoutChange"; "adjustOnZoomChange": "adjustOnZoomChange"; "animationChange": "animationChange"; "annotationsChange": "annotationsChange"; "argumentAxisChange": "argumentAxisChange"; "autoHidePointMarkersChange": "autoHidePointMarkersChange"; "barGroupPaddingChange": "barGroupPaddingChange"; "barGroupWidthChange": "barGroupWidthChange"; "commonAnnotationSettingsChange": "commonAnnotationSettingsChange"; "commonAxisSettingsChange": "commonAxisSettingsChange"; "commonPaneSettingsChange": "commonPaneSettingsChange"; "commonSeriesSettingsChange": "commonSeriesSettingsChange"; "containerBackgroundColorChange": "containerBackgroundColorChange"; "crosshairChange": "crosshairChange"; "customizeAnnotationChange": "customizeAnnotationChange"; "customizeLabelChange": "customizeLabelChange"; "customizePointChange": "customizePointChange"; "dataPrepareSettingsChange": "dataPrepareSettingsChange"; "dataSourceChange": "dataSourceChange"; "defaultPaneChange": "defaultPaneChange"; "disabledChange": "disabledChange"; "elementAttrChange": "elementAttrChange"; "encodeHtmlChange": "encodeHtmlChange"; "exportChange": "exportChange"; "legendChange": "legendChange"; "loadingIndicatorChange": "loadingIndicatorChange"; "marginChange": "marginChange"; "maxBubbleSizeChange": "maxBubbleSizeChange"; "minBubbleSizeChange": "minBubbleSizeChange"; "negativesAsZeroesChange": "negativesAsZeroesChange"; "paletteChange": "paletteChange"; "paletteExtensionModeChange": "paletteExtensionModeChange"; "panesChange": "panesChange"; "pathModifiedChange": "pathModifiedChange"; "pointSelectionModeChange": "pointSelectionModeChange"; "redrawOnResizeChange": "redrawOnResizeChange"; "resizePanesOnZoomChange": "resizePanesOnZoomChange"; "resolveLabelOverlappingChange": "resolveLabelOverlappingChange"; "rotatedChange": "rotatedChange"; "rtlEnabledChange": "rtlEnabledChange"; "scrollBarChange": "scrollBarChange"; "seriesChange": "seriesChange"; "seriesSelectionModeChange": "seriesSelectionModeChange"; "seriesTemplateChange": "seriesTemplateChange"; "sizeChange": "sizeChange"; "stickyHoveringChange": "stickyHoveringChange"; "synchronizeMultiAxesChange": "synchronizeMultiAxesChange"; "themeChange": "themeChange"; "titleChange": "titleChange"; "tooltipChange": "tooltipChange"; "valueAxisChange": "valueAxisChange"; "zoomAndPanChange": "zoomAndPanChange"; }, ["_annotationsContentChildren", "_breaksContentChildren", "_constantLinesContentChildren", "_panesContentChildren", "_seriesContentChildren", "_stripsContentChildren", "_valueAxisContentChildren"], never, true, never>;
}
declare class DxChartModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxChartModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxChartModule, never, [typeof DxChartComponent, typeof i1.DxoAdaptiveLayoutModule, typeof i1.DxoAnimationModule, typeof i1.DxiAnnotationModule, typeof i1.DxoBorderModule, typeof i1.DxoFontModule, typeof i1.DxoImageModule, typeof i1.DxoShadowModule, typeof i1.DxoArgumentAxisModule, typeof i1.DxoAggregationIntervalModule, typeof i1.DxiBreakModule, typeof i1.DxoBreakStyleModule, typeof i1.DxiConstantLineModule, typeof i1.DxoLabelModule, typeof i1.DxoConstantLineStyleModule, typeof i1.DxoGridModule, typeof i1.DxoFormatModule, typeof i1.DxoMinorGridModule, typeof i1.DxoMinorTickModule, typeof i1.DxoMinorTickIntervalModule, typeof i1.DxoMinVisualRangeLengthModule, typeof i1.DxiStripModule, typeof i1.DxoStripStyleModule, typeof i1.DxoTickModule, typeof i1.DxoTickIntervalModule, typeof i1.DxoTitleModule, typeof i1.DxoCommonAnnotationSettingsModule, typeof i1.DxoCommonAxisSettingsModule, typeof i1.DxoCommonPaneSettingsModule, typeof i1.DxoBackgroundColorModule, typeof i1.DxoCommonSeriesSettingsModule, typeof i1.DxoAggregationModule, typeof i1.DxoAreaModule, typeof i1.DxoHoverStyleModule, typeof i1.DxoHatchingModule, typeof i1.DxoConnectorModule, typeof i1.DxoPointModule, typeof i1.DxoHeightModule, typeof i1.DxoUrlModule, typeof i1.DxoWidthModule, typeof i1.DxoSelectionStyleModule, typeof i1.DxoReductionModule, typeof i1.DxoValueErrorBarModule, typeof i1.DxoBarModule, typeof i1.DxoBubbleModule, typeof i1.DxoCandlestickModule, typeof i1.DxoColorModule, typeof i1.DxoFullstackedareaModule, typeof i1.DxoFullstackedbarModule, typeof i1.DxoFullstackedlineModule, typeof i1.DxoFullstackedsplineModule, typeof i1.DxoFullstackedsplineareaModule, typeof i1.DxoArgumentFormatModule, typeof i1.DxoLineModule, typeof i1.DxoRangeareaModule, typeof i1.DxoRangebarModule, typeof i1.DxoScatterModule, typeof i1.DxoSplineModule, typeof i1.DxoSplineareaModule, typeof i1.DxoStackedareaModule, typeof i1.DxoStackedbarModule, typeof i1.DxoStackedlineModule, typeof i1.DxoStackedsplineModule, typeof i1.DxoStackedsplineareaModule, typeof i1.DxoStepareaModule, typeof i1.DxoSteplineModule, typeof i1.DxoStockModule, typeof i1.DxoCrosshairModule, typeof i1.DxoHorizontalLineModule, typeof i1.DxoVerticalLineModule, typeof i1.DxoDataPrepareSettingsModule, typeof i1.DxoExportModule, typeof i1.DxoLegendModule, typeof i1.DxoMarginModule, typeof i1.DxoSubtitleModule, typeof i1.DxoLoadingIndicatorModule, typeof i1.DxiPaneModule, typeof i1.DxoScrollBarModule, typeof i1.DxiSeriesModule, typeof i1.DxoSeriesTemplateModule, typeof i1.DxoSizeModule, typeof i1.DxoTooltipModule, typeof i1.DxiValueAxisModule, typeof i1.DxoZoomAndPanModule, typeof i1.DxoDragBoxStyleModule, typeof i2.DxoChartAdaptiveLayoutModule, typeof i2.DxoChartAggregationModule, typeof i2.DxoChartAggregationIntervalModule, typeof i2.DxoChartAnimationModule, typeof i2.DxiChartAnnotationModule, typeof i2.DxoChartAnnotationBorderModule, typeof i2.DxoChartAnnotationImageModule, typeof i2.DxoChartArgumentAxisModule, typeof i2.DxoChartArgumentFormatModule, typeof i2.DxoChartAxisConstantLineStyleModule, typeof i2.DxoChartAxisConstantLineStyleLabelModule, typeof i2.DxoChartAxisLabelModule, typeof i2.DxoChartAxisTitleModule, typeof i2.DxoChartBackgroundColorModule, typeof i2.DxoChartBorderModule, typeof i2.DxiChartBreakModule, typeof i2.DxoChartBreakStyleModule, typeof i2.DxoChartChartTitleModule, typeof i2.DxoChartChartTitleSubtitleModule, typeof i2.DxoChartColorModule, typeof i2.DxoChartCommonAnnotationSettingsModule, typeof i2.DxoChartCommonAxisSettingsModule, typeof i2.DxoChartCommonAxisSettingsConstantLineStyleModule, typeof i2.DxoChartCommonAxisSettingsConstantLineStyleLabelModule, typeof i2.DxoChartCommonAxisSettingsLabelModule, typeof i2.DxoChartCommonAxisSettingsTitleModule, typeof i2.DxoChartCommonPaneSettingsModule, typeof i2.DxoChartCommonSeriesSettingsModule, typeof i2.DxoChartCommonSeriesSettingsHoverStyleModule, typeof i2.DxoChartCommonSeriesSettingsLabelModule, typeof i2.DxoChartCommonSeriesSettingsSelectionStyleModule, typeof i2.DxoChartConnectorModule, typeof i2.DxiChartConstantLineModule, typeof i2.DxoChartConstantLineLabelModule, typeof i2.DxoChartConstantLineStyleModule, typeof i2.DxoChartCrosshairModule, typeof i2.DxoChartDataPrepareSettingsModule, typeof i2.DxoChartDragBoxStyleModule, typeof i2.DxoChartExportModule, typeof i2.DxoChartFontModule, typeof i2.DxoChartFormatModule, typeof i2.DxoChartGridModule, typeof i2.DxoChartHatchingModule, typeof i2.DxoChartHeightModule, typeof i2.DxoChartHorizontalLineModule, typeof i2.DxoChartHorizontalLineLabelModule, typeof i2.DxoChartHoverStyleModule, typeof i2.DxoChartImageModule, typeof i2.DxoChartLabelModule, typeof i2.DxoChartLegendModule, typeof i2.DxoChartLegendTitleModule, typeof i2.DxoChartLegendTitleSubtitleModule, typeof i2.DxoChartLengthModule, typeof i2.DxoChartLoadingIndicatorModule, typeof i2.DxoChartMarginModule, typeof i2.DxoChartMinorGridModule, typeof i2.DxoChartMinorTickModule, typeof i2.DxoChartMinorTickIntervalModule, typeof i2.DxoChartMinVisualRangeLengthModule, typeof i2.DxiChartPaneModule, typeof i2.DxoChartPaneBorderModule, typeof i2.DxoChartPointModule, typeof i2.DxoChartPointBorderModule, typeof i2.DxoChartPointHoverStyleModule, typeof i2.DxoChartPointImageModule, typeof i2.DxoChartPointSelectionStyleModule, typeof i2.DxoChartReductionModule, typeof i2.DxoChartScrollBarModule, typeof i2.DxoChartSelectionStyleModule, typeof i2.DxiChartSeriesModule, typeof i2.DxoChartSeriesBorderModule, typeof i2.DxoChartSeriesTemplateModule, typeof i2.DxoChartShadowModule, typeof i2.DxoChartSizeModule, typeof i2.DxiChartStripModule, typeof i2.DxoChartStripLabelModule, typeof i2.DxoChartStripStyleModule, typeof i2.DxoChartStripStyleLabelModule, typeof i2.DxoChartSubtitleModule, typeof i2.DxoChartTickModule, typeof i2.DxoChartTickIntervalModule, typeof i2.DxoChartTitleModule, typeof i2.DxoChartTooltipModule, typeof i2.DxoChartTooltipBorderModule, typeof i2.DxoChartUrlModule, typeof i2.DxiChartValueAxisModule, typeof i2.DxoChartValueErrorBarModule, typeof i2.DxoChartVerticalLineModule, typeof i2.DxoChartVisualRangeModule, typeof i2.DxoChartWholeRangeModule, typeof i2.DxoChartWidthModule, typeof i2.DxoChartZoomAndPanModule, typeof i3.DxIntegrationModule, typeof i3.DxTemplateModule], [typeof DxChartComponent, typeof i1.DxoAdaptiveLayoutModule, typeof i1.DxoAnimationModule, typeof i1.DxiAnnotationModule, typeof i1.DxoBorderModule, typeof i1.DxoFontModule, typeof i1.DxoImageModule, typeof i1.DxoShadowModule, typeof i1.DxoArgumentAxisModule, typeof i1.DxoAggregationIntervalModule, typeof i1.DxiBreakModule, typeof i1.DxoBreakStyleModule, typeof i1.DxiConstantLineModule, typeof i1.DxoLabelModule, typeof i1.DxoConstantLineStyleModule, typeof i1.DxoGridModule, typeof i1.DxoFormatModule, typeof i1.DxoMinorGridModule, typeof i1.DxoMinorTickModule, typeof i1.DxoMinorTickIntervalModule, typeof i1.DxoMinVisualRangeLengthModule, typeof i1.DxiStripModule, typeof i1.DxoStripStyleModule, typeof i1.DxoTickModule, typeof i1.DxoTickIntervalModule, typeof i1.DxoTitleModule, typeof i1.DxoCommonAnnotationSettingsModule, typeof i1.DxoCommonAxisSettingsModule, typeof i1.DxoCommonPaneSettingsModule, typeof i1.DxoBackgroundColorModule, typeof i1.DxoCommonSeriesSettingsModule, typeof i1.DxoAggregationModule, typeof i1.DxoAreaModule, typeof i1.DxoHoverStyleModule, typeof i1.DxoHatchingModule, typeof i1.DxoConnectorModule, typeof i1.DxoPointModule, typeof i1.DxoHeightModule, typeof i1.DxoUrlModule, typeof i1.DxoWidthModule, typeof i1.DxoSelectionStyleModule, typeof i1.DxoReductionModule, typeof i1.DxoValueErrorBarModule, typeof i1.DxoBarModule, typeof i1.DxoBubbleModule, typeof i1.DxoCandlestickModule, typeof i1.DxoColorModule, typeof i1.DxoFullstackedareaModule, typeof i1.DxoFullstackedbarModule, typeof i1.DxoFullstackedlineModule, typeof i1.DxoFullstackedsplineModule, typeof i1.DxoFullstackedsplineareaModule, typeof i1.DxoArgumentFormatModule, typeof i1.DxoLineModule, typeof i1.DxoRangeareaModule, typeof i1.DxoRangebarModule, typeof i1.DxoScatterModule, typeof i1.DxoSplineModule, typeof i1.DxoSplineareaModule, typeof i1.DxoStackedareaModule, typeof i1.DxoStackedbarModule, typeof i1.DxoStackedlineModule, typeof i1.DxoStackedsplineModule, typeof i1.DxoStackedsplineareaModule, typeof i1.DxoStepareaModule, typeof i1.DxoSteplineModule, typeof i1.DxoStockModule, typeof i1.DxoCrosshairModule, typeof i1.DxoHorizontalLineModule, typeof i1.DxoVerticalLineModule, typeof i1.DxoDataPrepareSettingsModule, typeof i1.DxoExportModule, typeof i1.DxoLegendModule, typeof i1.DxoMarginModule, typeof i1.DxoSubtitleModule, typeof i1.DxoLoadingIndicatorModule, typeof i1.DxiPaneModule, typeof i1.DxoScrollBarModule, typeof i1.DxiSeriesModule, typeof i1.DxoSeriesTemplateModule, typeof i1.DxoSizeModule, typeof i1.DxoTooltipModule, typeof i1.DxiValueAxisModule, typeof i1.DxoZoomAndPanModule, typeof i1.DxoDragBoxStyleModule, typeof i2.DxoChartAdaptiveLayoutModule, typeof i2.DxoChartAggregationModule, typeof i2.DxoChartAggregationIntervalModule, typeof i2.DxoChartAnimationModule, typeof i2.DxiChartAnnotationModule, typeof i2.DxoChartAnnotationBorderModule, typeof i2.DxoChartAnnotationImageModule, typeof i2.DxoChartArgumentAxisModule, typeof i2.DxoChartArgumentFormatModule, typeof i2.DxoChartAxisConstantLineStyleModule, typeof i2.DxoChartAxisConstantLineStyleLabelModule, typeof i2.DxoChartAxisLabelModule, typeof i2.DxoChartAxisTitleModule, typeof i2.DxoChartBackgroundColorModule, typeof i2.DxoChartBorderModule, typeof i2.DxiChartBreakModule, typeof i2.DxoChartBreakStyleModule, typeof i2.DxoChartChartTitleModule, typeof i2.DxoChartChartTitleSubtitleModule, typeof i2.DxoChartColorModule, typeof i2.DxoChartCommonAnnotationSettingsModule, typeof i2.DxoChartCommonAxisSettingsModule, typeof i2.DxoChartCommonAxisSettingsConstantLineStyleModule, typeof i2.DxoChartCommonAxisSettingsConstantLineStyleLabelModule, typeof i2.DxoChartCommonAxisSettingsLabelModule, typeof i2.DxoChartCommonAxisSettingsTitleModule, typeof i2.DxoChartCommonPaneSettingsModule, typeof i2.DxoChartCommonSeriesSettingsModule, typeof i2.DxoChartCommonSeriesSettingsHoverStyleModule, typeof i2.DxoChartCommonSeriesSettingsLabelModule, typeof i2.DxoChartCommonSeriesSettingsSelectionStyleModule, typeof i2.DxoChartConnectorModule, typeof i2.DxiChartConstantLineModule, typeof i2.DxoChartConstantLineLabelModule, typeof i2.DxoChartConstantLineStyleModule, typeof i2.DxoChartCrosshairModule, typeof i2.DxoChartDataPrepareSettingsModule, typeof i2.DxoChartDragBoxStyleModule, typeof i2.DxoChartExportModule, typeof i2.DxoChartFontModule, typeof i2.DxoChartFormatModule, typeof i2.DxoChartGridModule, typeof i2.DxoChartHatchingModule, typeof i2.DxoChartHeightModule, typeof i2.DxoChartHorizontalLineModule, typeof i2.DxoChartHorizontalLineLabelModule, typeof i2.DxoChartHoverStyleModule, typeof i2.DxoChartImageModule, typeof i2.DxoChartLabelModule, typeof i2.DxoChartLegendModule, typeof i2.DxoChartLegendTitleModule, typeof i2.DxoChartLegendTitleSubtitleModule, typeof i2.DxoChartLengthModule, typeof i2.DxoChartLoadingIndicatorModule, typeof i2.DxoChartMarginModule, typeof i2.DxoChartMinorGridModule, typeof i2.DxoChartMinorTickModule, typeof i2.DxoChartMinorTickIntervalModule, typeof i2.DxoChartMinVisualRangeLengthModule, typeof i2.DxiChartPaneModule, typeof i2.DxoChartPaneBorderModule, typeof i2.DxoChartPointModule, typeof i2.DxoChartPointBorderModule, typeof i2.DxoChartPointHoverStyleModule, typeof i2.DxoChartPointImageModule, typeof i2.DxoChartPointSelectionStyleModule, typeof i2.DxoChartReductionModule, typeof i2.DxoChartScrollBarModule, typeof i2.DxoChartSelectionStyleModule, typeof i2.DxiChartSeriesModule, typeof i2.DxoChartSeriesBorderModule, typeof i2.DxoChartSeriesTemplateModule, typeof i2.DxoChartShadowModule, typeof i2.DxoChartSizeModule, typeof i2.DxiChartStripModule, typeof i2.DxoChartStripLabelModule, typeof i2.DxoChartStripStyleModule, typeof i2.DxoChartStripStyleLabelModule, typeof i2.DxoChartSubtitleModule, typeof i2.DxoChartTickModule, typeof i2.DxoChartTickIntervalModule, typeof i2.DxoChartTitleModule, typeof i2.DxoChartTooltipModule, typeof i2.DxoChartTooltipBorderModule, typeof i2.DxoChartUrlModule, typeof i2.DxiChartValueAxisModule, typeof i2.DxoChartValueErrorBarModule, typeof i2.DxoChartVerticalLineModule, typeof i2.DxoChartVisualRangeModule, typeof i2.DxoChartWholeRangeModule, typeof i2.DxoChartWidthModule, typeof i2.DxoChartZoomAndPanModule, typeof i3.DxTemplateModule]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxChartModule>;
}

export { DxChartComponent, DxChartModule };
//# sourceMappingURL=index.d.ts.map
