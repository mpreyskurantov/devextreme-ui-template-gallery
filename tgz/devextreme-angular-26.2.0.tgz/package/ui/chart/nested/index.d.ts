import * as i0 from '@angular/core';
import { OnDestroy, OnInit, AfterViewInit, Renderer2, ElementRef, QueryList, EventEmitter } from '@angular/core';
import { NestedOption, NestedOptionHost, CollectionNestedOption, IDxTemplateHost, DxTemplateHost, DxTemplateDirective } from 'devextreme-angular/core';
import { chartPointAggregationInfoObject, chartSeriesObject, ChartSeriesAggregationMethod, dxChartAnnotationConfig, AggregatedPointsPosition, ChartLabelDisplayMode, FinancialChartReductionLevel, chartPointObject, dxChartPointInfo, ChartTooltipLocation, ChartZoomAndPanMode, EventKeyModifier } from 'devextreme/viz/chart';
import * as CommonChartTypes from 'devextreme/common/charts';
import { AnimationEaseMode, DashStyle, Font, TextOverflow, AnnotationType, WordWrap, TimeInterval, ChartsDataType, ScaleBreak, ScaleBreakLineStyle, RelativePosition, DiscreteAxisDivisionMode, ArgumentAxisHoverMode, ChartsAxisLabelOverlap, AxisScaleType, VisualRangeUpdateMode, ChartsColor, HatchDirection, SeriesHoverMode, PointInteractionMode, PointSymbol, SeriesSelectionMode, SeriesType, ValueErrorBarDisplayMode, ValueErrorBarType, LegendItem, LegendHoverMode, ValueAxisVisualRangeUpdateMode } from 'devextreme/common/charts';
import { HorizontalAlignment, VerticalAlignment, Position, Format as Format$1, VerticalEdge, ExportFormat, Orientation } from 'devextreme/common';
import { Format } from 'devextreme/common/core/localization';
import { ChartSeries } from 'devextreme/viz/common';

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoChartAdaptiveLayoutComponent extends NestedOption implements OnDestroy, OnInit {
    get height(): number;
    set height(value: number);
    get keepLabels(): boolean;
    set keepLabels(value: boolean);
    get width(): number;
    set width(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChartAdaptiveLayoutComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoChartAdaptiveLayoutComponent, "dxo-chart-adaptive-layout", never, { "height": { "alias": "height"; "required": false; }; "keepLabels": { "alias": "keepLabels"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoChartAdaptiveLayoutModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChartAdaptiveLayoutModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoChartAdaptiveLayoutModule, never, [typeof DxoChartAdaptiveLayoutComponent], [typeof DxoChartAdaptiveLayoutComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoChartAdaptiveLayoutModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoChartAggregationIntervalComponent extends NestedOption implements OnDestroy, OnInit {
    get days(): number;
    set days(value: number);
    get hours(): number;
    set hours(value: number);
    get milliseconds(): number;
    set milliseconds(value: number);
    get minutes(): number;
    set minutes(value: number);
    get months(): number;
    set months(value: number);
    get quarters(): number;
    set quarters(value: number);
    get seconds(): number;
    set seconds(value: number);
    get weeks(): number;
    set weeks(value: number);
    get years(): number;
    set years(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChartAggregationIntervalComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoChartAggregationIntervalComponent, "dxo-chart-aggregation-interval", never, { "days": { "alias": "days"; "required": false; }; "hours": { "alias": "hours"; "required": false; }; "milliseconds": { "alias": "milliseconds"; "required": false; }; "minutes": { "alias": "minutes"; "required": false; }; "months": { "alias": "months"; "required": false; }; "quarters": { "alias": "quarters"; "required": false; }; "seconds": { "alias": "seconds"; "required": false; }; "weeks": { "alias": "weeks"; "required": false; }; "years": { "alias": "years"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoChartAggregationIntervalModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChartAggregationIntervalModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoChartAggregationIntervalModule, never, [typeof DxoChartAggregationIntervalComponent], [typeof DxoChartAggregationIntervalComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoChartAggregationIntervalModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoChartAggregationComponent extends NestedOption implements OnDestroy, OnInit {
    get calculate(): ((aggregationInfo: chartPointAggregationInfoObject, series: chartSeriesObject) => Record<string, any> | Array<Record<string, any>>) | undefined;
    set calculate(value: ((aggregationInfo: chartPointAggregationInfoObject, series: chartSeriesObject) => Record<string, any> | Array<Record<string, any>>) | undefined);
    get enabled(): boolean;
    set enabled(value: boolean);
    get method(): ChartSeriesAggregationMethod;
    set method(value: ChartSeriesAggregationMethod);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChartAggregationComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoChartAggregationComponent, "dxo-chart-aggregation", never, { "calculate": { "alias": "calculate"; "required": false; }; "enabled": { "alias": "enabled"; "required": false; }; "method": { "alias": "method"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoChartAggregationModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChartAggregationModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoChartAggregationModule, never, [typeof DxoChartAggregationComponent], [typeof DxoChartAggregationComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoChartAggregationModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoChartAnimationComponent extends NestedOption implements OnDestroy, OnInit {
    get duration(): number;
    set duration(value: number);
    get easing(): AnimationEaseMode;
    set easing(value: AnimationEaseMode);
    get enabled(): boolean;
    set enabled(value: boolean);
    get maxPointCountSupported(): number;
    set maxPointCountSupported(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChartAnimationComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoChartAnimationComponent, "dxo-chart-animation", never, { "duration": { "alias": "duration"; "required": false; }; "easing": { "alias": "easing"; "required": false; }; "enabled": { "alias": "enabled"; "required": false; }; "maxPointCountSupported": { "alias": "maxPointCountSupported"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoChartAnimationModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChartAnimationModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoChartAnimationModule, never, [typeof DxoChartAnimationComponent], [typeof DxoChartAnimationComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoChartAnimationModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoChartAnnotationBorderComponent extends NestedOption implements OnDestroy, OnInit {
    get color(): string;
    set color(value: string);
    get cornerRadius(): number;
    set cornerRadius(value: number);
    get dashStyle(): DashStyle;
    set dashStyle(value: DashStyle);
    get opacity(): number | undefined;
    set opacity(value: number | undefined);
    get visible(): boolean;
    set visible(value: boolean);
    get width(): number;
    set width(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChartAnnotationBorderComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoChartAnnotationBorderComponent, "dxo-chart-annotation-border", never, { "color": { "alias": "color"; "required": false; }; "cornerRadius": { "alias": "cornerRadius"; "required": false; }; "dashStyle": { "alias": "dashStyle"; "required": false; }; "opacity": { "alias": "opacity"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoChartAnnotationBorderModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChartAnnotationBorderModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoChartAnnotationBorderModule, never, [typeof DxoChartAnnotationBorderComponent], [typeof DxoChartAnnotationBorderComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoChartAnnotationBorderModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxiChartAnnotationComponent extends CollectionNestedOption implements AfterViewInit, IDxTemplateHost {
    private renderer;
    private document;
    private element;
    get allowDragging(): boolean;
    set allowDragging(value: boolean);
    get argument(): Date | number | string | undefined;
    set argument(value: Date | number | string | undefined);
    get arrowLength(): number;
    set arrowLength(value: number);
    get arrowWidth(): number;
    set arrowWidth(value: number);
    get axis(): string | undefined;
    set axis(value: string | undefined);
    get border(): {
        color?: string;
        cornerRadius?: number;
        dashStyle?: DashStyle;
        opacity?: number | undefined;
        visible?: boolean;
        width?: number;
    };
    set border(value: {
        color?: string;
        cornerRadius?: number;
        dashStyle?: DashStyle;
        opacity?: number | undefined;
        visible?: boolean;
        width?: number;
    });
    get color(): string;
    set color(value: string);
    get customizeTooltip(): ((annotation: dxChartAnnotationConfig | any) => Record<string, any>) | undefined;
    set customizeTooltip(value: ((annotation: dxChartAnnotationConfig | any) => Record<string, any>) | undefined);
    get data(): any;
    set data(value: any);
    get description(): string | undefined;
    set description(value: string | undefined);
    get font(): Font;
    set font(value: Font);
    get height(): number | undefined;
    set height(value: number | undefined);
    get image(): string | {
        height?: number;
        url?: string | undefined;
        width?: number;
    };
    set image(value: string | {
        height?: number;
        url?: string | undefined;
        width?: number;
    });
    get name(): string | undefined;
    set name(value: string | undefined);
    get offsetX(): number | undefined;
    set offsetX(value: number | undefined);
    get offsetY(): number | undefined;
    set offsetY(value: number | undefined);
    get opacity(): number;
    set opacity(value: number);
    get paddingLeftRight(): number;
    set paddingLeftRight(value: number);
    get paddingTopBottom(): number;
    set paddingTopBottom(value: number);
    get series(): string | undefined;
    set series(value: string | undefined);
    get shadow(): {
        blur?: number;
        color?: string;
        offsetX?: number;
        offsetY?: number;
        opacity?: number;
    };
    set shadow(value: {
        blur?: number;
        color?: string;
        offsetX?: number;
        offsetY?: number;
        opacity?: number;
    });
    get template(): any;
    set template(value: any);
    get text(): string | undefined;
    set text(value: string | undefined);
    get textOverflow(): TextOverflow;
    set textOverflow(value: TextOverflow);
    get tooltipEnabled(): boolean;
    set tooltipEnabled(value: boolean);
    get tooltipTemplate(): any;
    set tooltipTemplate(value: any);
    get type(): AnnotationType | undefined;
    set type(value: AnnotationType | undefined);
    get value(): Date | number | string | undefined;
    set value(value: Date | number | string | undefined);
    get width(): number | undefined;
    set width(value: number | undefined);
    get wordWrap(): WordWrap;
    set wordWrap(value: WordWrap);
    get x(): number | undefined;
    set x(value: number | undefined);
    get y(): number | undefined;
    set y(value: number | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost, renderer: Renderer2, document: any, templateHost: DxTemplateHost, element: ElementRef);
    setTemplate(template: DxTemplateDirective): void;
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiChartAnnotationComponent, [{ host: true; skipSelf: true; }, { host: true; }, null, null, { host: true; }, null]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiChartAnnotationComponent, "dxi-chart-annotation", never, { "allowDragging": { "alias": "allowDragging"; "required": false; }; "argument": { "alias": "argument"; "required": false; }; "arrowLength": { "alias": "arrowLength"; "required": false; }; "arrowWidth": { "alias": "arrowWidth"; "required": false; }; "axis": { "alias": "axis"; "required": false; }; "border": { "alias": "border"; "required": false; }; "color": { "alias": "color"; "required": false; }; "customizeTooltip": { "alias": "customizeTooltip"; "required": false; }; "data": { "alias": "data"; "required": false; }; "description": { "alias": "description"; "required": false; }; "font": { "alias": "font"; "required": false; }; "height": { "alias": "height"; "required": false; }; "image": { "alias": "image"; "required": false; }; "name": { "alias": "name"; "required": false; }; "offsetX": { "alias": "offsetX"; "required": false; }; "offsetY": { "alias": "offsetY"; "required": false; }; "opacity": { "alias": "opacity"; "required": false; }; "paddingLeftRight": { "alias": "paddingLeftRight"; "required": false; }; "paddingTopBottom": { "alias": "paddingTopBottom"; "required": false; }; "series": { "alias": "series"; "required": false; }; "shadow": { "alias": "shadow"; "required": false; }; "template": { "alias": "template"; "required": false; }; "text": { "alias": "text"; "required": false; }; "textOverflow": { "alias": "textOverflow"; "required": false; }; "tooltipEnabled": { "alias": "tooltipEnabled"; "required": false; }; "tooltipTemplate": { "alias": "tooltipTemplate"; "required": false; }; "type": { "alias": "type"; "required": false; }; "value": { "alias": "value"; "required": false; }; "width": { "alias": "width"; "required": false; }; "wordWrap": { "alias": "wordWrap"; "required": false; }; "x": { "alias": "x"; "required": false; }; "y": { "alias": "y"; "required": false; }; }, {}, never, ["*"], true, never>;
}
declare class DxiChartAnnotationModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiChartAnnotationModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiChartAnnotationModule, never, [typeof DxiChartAnnotationComponent], [typeof DxiChartAnnotationComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiChartAnnotationModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoChartAnnotationImageComponent extends NestedOption implements OnDestroy, OnInit {
    get height(): number;
    set height(value: number);
    get url(): string | undefined;
    set url(value: string | undefined);
    get width(): number;
    set width(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChartAnnotationImageComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoChartAnnotationImageComponent, "dxo-chart-annotation-image", never, { "height": { "alias": "height"; "required": false; }; "url": { "alias": "url"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoChartAnnotationImageModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChartAnnotationImageModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoChartAnnotationImageModule, never, [typeof DxoChartAnnotationImageComponent], [typeof DxoChartAnnotationImageComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoChartAnnotationImageModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoChartArgumentAxisComponent extends NestedOption implements OnDestroy, OnInit {
    set _breaksContentChildren(value: QueryList<CollectionNestedOption>);
    set _constantLinesContentChildren(value: QueryList<CollectionNestedOption>);
    set _stripsContentChildren(value: QueryList<CollectionNestedOption>);
    get aggregatedPointsPosition(): AggregatedPointsPosition;
    set aggregatedPointsPosition(value: AggregatedPointsPosition);
    get aggregationGroupWidth(): number | undefined;
    set aggregationGroupWidth(value: number | undefined);
    get aggregationInterval(): number | TimeInterval | {
        days?: number;
        hours?: number;
        milliseconds?: number;
        minutes?: number;
        months?: number;
        quarters?: number;
        seconds?: number;
        weeks?: number;
        years?: number;
    };
    set aggregationInterval(value: number | TimeInterval | {
        days?: number;
        hours?: number;
        milliseconds?: number;
        minutes?: number;
        months?: number;
        quarters?: number;
        seconds?: number;
        weeks?: number;
        years?: number;
    });
    get allowDecimals(): boolean | undefined;
    set allowDecimals(value: boolean | undefined);
    get argumentType(): ChartsDataType | undefined;
    set argumentType(value: ChartsDataType | undefined);
    get axisDivisionFactor(): number;
    set axisDivisionFactor(value: number);
    get breaks(): Array<ScaleBreak> | undefined | {
        endValue?: Date | number | string | undefined;
        startValue?: Date | number | string | undefined;
    }[];
    set breaks(value: Array<ScaleBreak> | undefined | {
        endValue?: Date | number | string | undefined;
        startValue?: Date | number | string | undefined;
    }[]);
    get breakStyle(): {
        color?: string;
        line?: ScaleBreakLineStyle;
        width?: number;
    };
    set breakStyle(value: {
        color?: string;
        line?: ScaleBreakLineStyle;
        width?: number;
    });
    get categories(): Array<Date | number | string>;
    set categories(value: Array<Date | number | string>);
    get color(): string;
    set color(value: string);
    get constantLines(): {
        color?: string;
        dashStyle?: DashStyle;
        displayBehindSeries?: boolean;
        extendAxis?: boolean;
        label?: {
            font?: Font;
            horizontalAlignment?: HorizontalAlignment;
            position?: RelativePosition;
            text?: string | undefined;
            verticalAlignment?: VerticalAlignment;
            visible?: boolean;
        };
        paddingLeftRight?: number;
        paddingTopBottom?: number;
        value?: Date | number | string | undefined;
        width?: number;
    }[];
    set constantLines(value: {
        color?: string;
        dashStyle?: DashStyle;
        displayBehindSeries?: boolean;
        extendAxis?: boolean;
        label?: {
            font?: Font;
            horizontalAlignment?: HorizontalAlignment;
            position?: RelativePosition;
            text?: string | undefined;
            verticalAlignment?: VerticalAlignment;
            visible?: boolean;
        };
        paddingLeftRight?: number;
        paddingTopBottom?: number;
        value?: Date | number | string | undefined;
        width?: number;
    }[]);
    get constantLineStyle(): {
        color?: string;
        dashStyle?: DashStyle;
        label?: {
            font?: Font;
            horizontalAlignment?: HorizontalAlignment;
            position?: RelativePosition;
            verticalAlignment?: VerticalAlignment;
            visible?: boolean;
        };
        paddingLeftRight?: number;
        paddingTopBottom?: number;
        width?: number;
    };
    set constantLineStyle(value: {
        color?: string;
        dashStyle?: DashStyle;
        label?: {
            font?: Font;
            horizontalAlignment?: HorizontalAlignment;
            position?: RelativePosition;
            verticalAlignment?: VerticalAlignment;
            visible?: boolean;
        };
        paddingLeftRight?: number;
        paddingTopBottom?: number;
        width?: number;
    });
    get customPosition(): Date | number | string | undefined;
    set customPosition(value: Date | number | string | undefined);
    get customPositionAxis(): string | undefined;
    set customPositionAxis(value: string | undefined);
    get discreteAxisDivisionMode(): DiscreteAxisDivisionMode;
    set discreteAxisDivisionMode(value: DiscreteAxisDivisionMode);
    get endOnTick(): boolean;
    set endOnTick(value: boolean);
    get grid(): {
        color?: string;
        opacity?: number | undefined;
        visible?: boolean;
        width?: number;
    };
    set grid(value: {
        color?: string;
        opacity?: number | undefined;
        visible?: boolean;
        width?: number;
    });
    get holidays(): Array<Date | string> | Array<number> | undefined;
    set holidays(value: Array<Date | string> | Array<number> | undefined);
    get hoverMode(): ArgumentAxisHoverMode;
    set hoverMode(value: ArgumentAxisHoverMode);
    get inverted(): boolean;
    set inverted(value: boolean);
    get label(): {
        alignment?: HorizontalAlignment | undefined;
        customizeHint?: ((argument: {
            value: Date | number | string;
            valueText: string;
        }) => string);
        customizeText?: ((argument: {
            value: Date | number | string;
            valueText: string;
        }) => string);
        displayMode?: ChartLabelDisplayMode;
        font?: Font;
        format?: Format | undefined;
        indentFromAxis?: number;
        overlappingBehavior?: ChartsAxisLabelOverlap;
        position?: Position | RelativePosition;
        rotationAngle?: number;
        staggeringSpacing?: number;
        template?: any;
        textOverflow?: TextOverflow;
        visible?: boolean;
        wordWrap?: WordWrap;
    };
    set label(value: {
        alignment?: HorizontalAlignment | undefined;
        customizeHint?: ((argument: {
            value: Date | number | string;
            valueText: string;
        }) => string);
        customizeText?: ((argument: {
            value: Date | number | string;
            valueText: string;
        }) => string);
        displayMode?: ChartLabelDisplayMode;
        font?: Font;
        format?: Format | undefined;
        indentFromAxis?: number;
        overlappingBehavior?: ChartsAxisLabelOverlap;
        position?: Position | RelativePosition;
        rotationAngle?: number;
        staggeringSpacing?: number;
        template?: any;
        textOverflow?: TextOverflow;
        visible?: boolean;
        wordWrap?: WordWrap;
    });
    get linearThreshold(): number | undefined;
    set linearThreshold(value: number | undefined);
    get logarithmBase(): number;
    set logarithmBase(value: number);
    get maxValueMargin(): number | undefined;
    set maxValueMargin(value: number | undefined);
    get minorGrid(): {
        color?: string;
        opacity?: number | undefined;
        visible?: boolean;
        width?: number;
    };
    set minorGrid(value: {
        color?: string;
        opacity?: number | undefined;
        visible?: boolean;
        width?: number;
    });
    get minorTick(): {
        color?: string;
        length?: number;
        opacity?: number;
        shift?: number;
        visible?: boolean;
        width?: number;
    };
    set minorTick(value: {
        color?: string;
        length?: number;
        opacity?: number;
        shift?: number;
        visible?: boolean;
        width?: number;
    });
    get minorTickCount(): number | undefined;
    set minorTickCount(value: number | undefined);
    get minorTickInterval(): number | TimeInterval | {
        days?: number;
        hours?: number;
        milliseconds?: number;
        minutes?: number;
        months?: number;
        quarters?: number;
        seconds?: number;
        weeks?: number;
        years?: number;
    };
    set minorTickInterval(value: number | TimeInterval | {
        days?: number;
        hours?: number;
        milliseconds?: number;
        minutes?: number;
        months?: number;
        quarters?: number;
        seconds?: number;
        weeks?: number;
        years?: number;
    });
    get minValueMargin(): number | undefined;
    set minValueMargin(value: number | undefined);
    get minVisualRangeLength(): number | TimeInterval | undefined | {
        days?: number;
        hours?: number;
        milliseconds?: number;
        minutes?: number;
        months?: number;
        quarters?: number;
        seconds?: number;
        weeks?: number;
        years?: number;
    };
    set minVisualRangeLength(value: number | TimeInterval | undefined | {
        days?: number;
        hours?: number;
        milliseconds?: number;
        minutes?: number;
        months?: number;
        quarters?: number;
        seconds?: number;
        weeks?: number;
        years?: number;
    });
    get offset(): number | undefined;
    set offset(value: number | undefined);
    get opacity(): number | undefined;
    set opacity(value: number | undefined);
    get placeholderSize(): null | number;
    set placeholderSize(value: null | number);
    get position(): Position;
    set position(value: Position);
    get singleWorkdays(): Array<Date | string> | Array<number> | undefined;
    set singleWorkdays(value: Array<Date | string> | Array<number> | undefined);
    get strips(): {
        color?: string | undefined;
        endValue?: Date | number | string | undefined;
        label?: {
            font?: Font;
            horizontalAlignment?: HorizontalAlignment;
            text?: string | undefined;
            verticalAlignment?: VerticalAlignment;
        };
        paddingLeftRight?: number;
        paddingTopBottom?: number;
        startValue?: Date | number | string | undefined;
    }[];
    set strips(value: {
        color?: string | undefined;
        endValue?: Date | number | string | undefined;
        label?: {
            font?: Font;
            horizontalAlignment?: HorizontalAlignment;
            text?: string | undefined;
            verticalAlignment?: VerticalAlignment;
        };
        paddingLeftRight?: number;
        paddingTopBottom?: number;
        startValue?: Date | number | string | undefined;
    }[]);
    get stripStyle(): {
        label?: {
            font?: Font;
            horizontalAlignment?: HorizontalAlignment;
            verticalAlignment?: VerticalAlignment;
        };
        paddingLeftRight?: number;
        paddingTopBottom?: number;
    };
    set stripStyle(value: {
        label?: {
            font?: Font;
            horizontalAlignment?: HorizontalAlignment;
            verticalAlignment?: VerticalAlignment;
        };
        paddingLeftRight?: number;
        paddingTopBottom?: number;
    });
    get tick(): {
        color?: string;
        length?: number;
        opacity?: number | undefined;
        shift?: number;
        visible?: boolean;
        width?: number;
    };
    set tick(value: {
        color?: string;
        length?: number;
        opacity?: number | undefined;
        shift?: number;
        visible?: boolean;
        width?: number;
    });
    get tickInterval(): number | TimeInterval | {
        days?: number;
        hours?: number;
        milliseconds?: number;
        minutes?: number;
        months?: number;
        quarters?: number;
        seconds?: number;
        weeks?: number;
        years?: number;
    };
    set tickInterval(value: number | TimeInterval | {
        days?: number;
        hours?: number;
        milliseconds?: number;
        minutes?: number;
        months?: number;
        quarters?: number;
        seconds?: number;
        weeks?: number;
        years?: number;
    });
    get title(): string | {
        alignment?: HorizontalAlignment;
        font?: Font;
        margin?: number;
        text?: string | undefined;
        textOverflow?: TextOverflow;
        wordWrap?: WordWrap;
    };
    set title(value: string | {
        alignment?: HorizontalAlignment;
        font?: Font;
        margin?: number;
        text?: string | undefined;
        textOverflow?: TextOverflow;
        wordWrap?: WordWrap;
    });
    get type(): AxisScaleType | undefined;
    set type(value: AxisScaleType | undefined);
    get valueMarginsEnabled(): boolean;
    set valueMarginsEnabled(value: boolean);
    get visible(): boolean;
    set visible(value: boolean);
    get visualRange(): Array<Date | number | string> | CommonChartTypes.VisualRange;
    set visualRange(value: Array<Date | number | string> | CommonChartTypes.VisualRange);
    get visualRangeUpdateMode(): VisualRangeUpdateMode;
    set visualRangeUpdateMode(value: VisualRangeUpdateMode);
    get wholeRange(): Array<Date | number | string> | undefined | CommonChartTypes.VisualRange;
    set wholeRange(value: Array<Date | number | string> | undefined | CommonChartTypes.VisualRange);
    get width(): number;
    set width(value: number);
    get workdaysOnly(): boolean;
    set workdaysOnly(value: boolean);
    get workWeek(): Array<number>;
    set workWeek(value: Array<number>);
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    categoriesChange: EventEmitter<Array<Date | number | string>>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    visualRangeChange: EventEmitter<Array<Date | number | string> | CommonChartTypes.VisualRange>;
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChartArgumentAxisComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoChartArgumentAxisComponent, "dxo-chart-argument-axis", never, { "aggregatedPointsPosition": { "alias": "aggregatedPointsPosition"; "required": false; }; "aggregationGroupWidth": { "alias": "aggregationGroupWidth"; "required": false; }; "aggregationInterval": { "alias": "aggregationInterval"; "required": false; }; "allowDecimals": { "alias": "allowDecimals"; "required": false; }; "argumentType": { "alias": "argumentType"; "required": false; }; "axisDivisionFactor": { "alias": "axisDivisionFactor"; "required": false; }; "breaks": { "alias": "breaks"; "required": false; }; "breakStyle": { "alias": "breakStyle"; "required": false; }; "categories": { "alias": "categories"; "required": false; }; "color": { "alias": "color"; "required": false; }; "constantLines": { "alias": "constantLines"; "required": false; }; "constantLineStyle": { "alias": "constantLineStyle"; "required": false; }; "customPosition": { "alias": "customPosition"; "required": false; }; "customPositionAxis": { "alias": "customPositionAxis"; "required": false; }; "discreteAxisDivisionMode": { "alias": "discreteAxisDivisionMode"; "required": false; }; "endOnTick": { "alias": "endOnTick"; "required": false; }; "grid": { "alias": "grid"; "required": false; }; "holidays": { "alias": "holidays"; "required": false; }; "hoverMode": { "alias": "hoverMode"; "required": false; }; "inverted": { "alias": "inverted"; "required": false; }; "label": { "alias": "label"; "required": false; }; "linearThreshold": { "alias": "linearThreshold"; "required": false; }; "logarithmBase": { "alias": "logarithmBase"; "required": false; }; "maxValueMargin": { "alias": "maxValueMargin"; "required": false; }; "minorGrid": { "alias": "minorGrid"; "required": false; }; "minorTick": { "alias": "minorTick"; "required": false; }; "minorTickCount": { "alias": "minorTickCount"; "required": false; }; "minorTickInterval": { "alias": "minorTickInterval"; "required": false; }; "minValueMargin": { "alias": "minValueMargin"; "required": false; }; "minVisualRangeLength": { "alias": "minVisualRangeLength"; "required": false; }; "offset": { "alias": "offset"; "required": false; }; "opacity": { "alias": "opacity"; "required": false; }; "placeholderSize": { "alias": "placeholderSize"; "required": false; }; "position": { "alias": "position"; "required": false; }; "singleWorkdays": { "alias": "singleWorkdays"; "required": false; }; "strips": { "alias": "strips"; "required": false; }; "stripStyle": { "alias": "stripStyle"; "required": false; }; "tick": { "alias": "tick"; "required": false; }; "tickInterval": { "alias": "tickInterval"; "required": false; }; "title": { "alias": "title"; "required": false; }; "type": { "alias": "type"; "required": false; }; "valueMarginsEnabled": { "alias": "valueMarginsEnabled"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "visualRange": { "alias": "visualRange"; "required": false; }; "visualRangeUpdateMode": { "alias": "visualRangeUpdateMode"; "required": false; }; "wholeRange": { "alias": "wholeRange"; "required": false; }; "width": { "alias": "width"; "required": false; }; "workdaysOnly": { "alias": "workdaysOnly"; "required": false; }; "workWeek": { "alias": "workWeek"; "required": false; }; }, { "categoriesChange": "categoriesChange"; "visualRangeChange": "visualRangeChange"; }, ["_breaksContentChildren", "_constantLinesContentChildren", "_stripsContentChildren"], never, true, never>;
}
declare class DxoChartArgumentAxisModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChartArgumentAxisModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoChartArgumentAxisModule, never, [typeof DxoChartArgumentAxisComponent], [typeof DxoChartArgumentAxisComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoChartArgumentAxisModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoChartArgumentFormatComponent extends NestedOption implements OnDestroy, OnInit {
    get currency(): string;
    set currency(value: string);
    get formatter(): ((value: number | Date) => string);
    set formatter(value: ((value: number | Date) => string));
    get parser(): ((value: string) => number | Date);
    set parser(value: ((value: string) => number | Date));
    get precision(): number;
    set precision(value: number);
    get type(): Format$1 | string;
    set type(value: Format$1 | string);
    get useCurrencyAccountingStyle(): boolean;
    set useCurrencyAccountingStyle(value: boolean);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChartArgumentFormatComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoChartArgumentFormatComponent, "dxo-chart-argument-format", never, { "currency": { "alias": "currency"; "required": false; }; "formatter": { "alias": "formatter"; "required": false; }; "parser": { "alias": "parser"; "required": false; }; "precision": { "alias": "precision"; "required": false; }; "type": { "alias": "type"; "required": false; }; "useCurrencyAccountingStyle": { "alias": "useCurrencyAccountingStyle"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoChartArgumentFormatModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChartArgumentFormatModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoChartArgumentFormatModule, never, [typeof DxoChartArgumentFormatComponent], [typeof DxoChartArgumentFormatComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoChartArgumentFormatModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoChartAxisConstantLineStyleLabelComponent extends NestedOption implements OnDestroy, OnInit {
    get font(): Font;
    set font(value: Font);
    get horizontalAlignment(): HorizontalAlignment;
    set horizontalAlignment(value: HorizontalAlignment);
    get position(): RelativePosition;
    set position(value: RelativePosition);
    get verticalAlignment(): VerticalAlignment;
    set verticalAlignment(value: VerticalAlignment);
    get visible(): boolean;
    set visible(value: boolean);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChartAxisConstantLineStyleLabelComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoChartAxisConstantLineStyleLabelComponent, "dxo-chart-axis-constant-line-style-label", never, { "font": { "alias": "font"; "required": false; }; "horizontalAlignment": { "alias": "horizontalAlignment"; "required": false; }; "position": { "alias": "position"; "required": false; }; "verticalAlignment": { "alias": "verticalAlignment"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoChartAxisConstantLineStyleLabelModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChartAxisConstantLineStyleLabelModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoChartAxisConstantLineStyleLabelModule, never, [typeof DxoChartAxisConstantLineStyleLabelComponent], [typeof DxoChartAxisConstantLineStyleLabelComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoChartAxisConstantLineStyleLabelModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoChartAxisConstantLineStyleComponent extends NestedOption implements OnDestroy, OnInit {
    get color(): string;
    set color(value: string);
    get dashStyle(): DashStyle;
    set dashStyle(value: DashStyle);
    get label(): {
        font?: Font;
        horizontalAlignment?: HorizontalAlignment;
        position?: RelativePosition;
        verticalAlignment?: VerticalAlignment;
        visible?: boolean;
    };
    set label(value: {
        font?: Font;
        horizontalAlignment?: HorizontalAlignment;
        position?: RelativePosition;
        verticalAlignment?: VerticalAlignment;
        visible?: boolean;
    });
    get paddingLeftRight(): number;
    set paddingLeftRight(value: number);
    get paddingTopBottom(): number;
    set paddingTopBottom(value: number);
    get width(): number;
    set width(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChartAxisConstantLineStyleComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoChartAxisConstantLineStyleComponent, "dxo-chart-axis-constant-line-style", never, { "color": { "alias": "color"; "required": false; }; "dashStyle": { "alias": "dashStyle"; "required": false; }; "label": { "alias": "label"; "required": false; }; "paddingLeftRight": { "alias": "paddingLeftRight"; "required": false; }; "paddingTopBottom": { "alias": "paddingTopBottom"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoChartAxisConstantLineStyleModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChartAxisConstantLineStyleModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoChartAxisConstantLineStyleModule, never, [typeof DxoChartAxisConstantLineStyleComponent], [typeof DxoChartAxisConstantLineStyleComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoChartAxisConstantLineStyleModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoChartAxisLabelComponent extends NestedOption implements AfterViewInit, OnDestroy, OnInit, IDxTemplateHost {
    private renderer;
    private document;
    private element;
    get alignment(): HorizontalAlignment | undefined;
    set alignment(value: HorizontalAlignment | undefined);
    get customizeHint(): ((argument: {
        value: Date | number | string;
        valueText: string;
    }) => string);
    set customizeHint(value: ((argument: {
        value: Date | number | string;
        valueText: string;
    }) => string));
    get customizeText(): ((argument: {
        value: Date | number | string;
        valueText: string;
    }) => string);
    set customizeText(value: ((argument: {
        value: Date | number | string;
        valueText: string;
    }) => string));
    get displayMode(): ChartLabelDisplayMode;
    set displayMode(value: ChartLabelDisplayMode);
    get font(): Font;
    set font(value: Font);
    get format(): Format | undefined;
    set format(value: Format | undefined);
    get indentFromAxis(): number;
    set indentFromAxis(value: number);
    get overlappingBehavior(): ChartsAxisLabelOverlap;
    set overlappingBehavior(value: ChartsAxisLabelOverlap);
    get position(): Position | RelativePosition;
    set position(value: Position | RelativePosition);
    get rotationAngle(): number;
    set rotationAngle(value: number);
    get staggeringSpacing(): number;
    set staggeringSpacing(value: number);
    get template(): any;
    set template(value: any);
    get textOverflow(): TextOverflow;
    set textOverflow(value: TextOverflow);
    get visible(): boolean;
    set visible(value: boolean);
    get wordWrap(): WordWrap;
    set wordWrap(value: WordWrap);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost, renderer: Renderer2, document: any, templateHost: DxTemplateHost, element: ElementRef);
    setTemplate(template: DxTemplateDirective): void;
    ngAfterViewInit(): void;
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChartAxisLabelComponent, [{ host: true; skipSelf: true; }, { host: true; }, null, null, { host: true; }, null]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoChartAxisLabelComponent, "dxo-chart-axis-label", never, { "alignment": { "alias": "alignment"; "required": false; }; "customizeHint": { "alias": "customizeHint"; "required": false; }; "customizeText": { "alias": "customizeText"; "required": false; }; "displayMode": { "alias": "displayMode"; "required": false; }; "font": { "alias": "font"; "required": false; }; "format": { "alias": "format"; "required": false; }; "indentFromAxis": { "alias": "indentFromAxis"; "required": false; }; "overlappingBehavior": { "alias": "overlappingBehavior"; "required": false; }; "position": { "alias": "position"; "required": false; }; "rotationAngle": { "alias": "rotationAngle"; "required": false; }; "staggeringSpacing": { "alias": "staggeringSpacing"; "required": false; }; "template": { "alias": "template"; "required": false; }; "textOverflow": { "alias": "textOverflow"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "wordWrap": { "alias": "wordWrap"; "required": false; }; }, {}, never, ["*"], true, never>;
}
declare class DxoChartAxisLabelModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChartAxisLabelModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoChartAxisLabelModule, never, [typeof DxoChartAxisLabelComponent], [typeof DxoChartAxisLabelComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoChartAxisLabelModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoChartAxisTitleComponent extends NestedOption implements OnDestroy, OnInit {
    get alignment(): HorizontalAlignment;
    set alignment(value: HorizontalAlignment);
    get font(): Font;
    set font(value: Font);
    get margin(): number;
    set margin(value: number);
    get text(): string | undefined;
    set text(value: string | undefined);
    get textOverflow(): TextOverflow;
    set textOverflow(value: TextOverflow);
    get wordWrap(): WordWrap;
    set wordWrap(value: WordWrap);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChartAxisTitleComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoChartAxisTitleComponent, "dxo-chart-axis-title", never, { "alignment": { "alias": "alignment"; "required": false; }; "font": { "alias": "font"; "required": false; }; "margin": { "alias": "margin"; "required": false; }; "text": { "alias": "text"; "required": false; }; "textOverflow": { "alias": "textOverflow"; "required": false; }; "wordWrap": { "alias": "wordWrap"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoChartAxisTitleModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChartAxisTitleModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoChartAxisTitleModule, never, [typeof DxoChartAxisTitleComponent], [typeof DxoChartAxisTitleComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoChartAxisTitleModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoChartBackgroundColorComponent extends NestedOption implements OnDestroy, OnInit {
    get base(): string | undefined;
    set base(value: string | undefined);
    get fillId(): string | undefined;
    set fillId(value: string | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChartBackgroundColorComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoChartBackgroundColorComponent, "dxo-chart-background-color", never, { "base": { "alias": "base"; "required": false; }; "fillId": { "alias": "fillId"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoChartBackgroundColorModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChartBackgroundColorModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoChartBackgroundColorModule, never, [typeof DxoChartBackgroundColorComponent], [typeof DxoChartBackgroundColorComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoChartBackgroundColorModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoChartBorderComponent extends NestedOption implements OnDestroy, OnInit {
    get color(): string | undefined;
    set color(value: string | undefined);
    get cornerRadius(): number;
    set cornerRadius(value: number);
    get dashStyle(): DashStyle | undefined;
    set dashStyle(value: DashStyle | undefined);
    get opacity(): number | undefined;
    set opacity(value: number | undefined);
    get visible(): boolean;
    set visible(value: boolean);
    get width(): number;
    set width(value: number);
    get bottom(): boolean;
    set bottom(value: boolean);
    get left(): boolean;
    set left(value: boolean);
    get right(): boolean;
    set right(value: boolean);
    get top(): boolean;
    set top(value: boolean);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChartBorderComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoChartBorderComponent, "dxo-chart-border", never, { "color": { "alias": "color"; "required": false; }; "cornerRadius": { "alias": "cornerRadius"; "required": false; }; "dashStyle": { "alias": "dashStyle"; "required": false; }; "opacity": { "alias": "opacity"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; "bottom": { "alias": "bottom"; "required": false; }; "left": { "alias": "left"; "required": false; }; "right": { "alias": "right"; "required": false; }; "top": { "alias": "top"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoChartBorderModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChartBorderModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoChartBorderModule, never, [typeof DxoChartBorderComponent], [typeof DxoChartBorderComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoChartBorderModule>;
}

declare class DxiChartBreakComponent extends CollectionNestedOption {
    get endValue(): Date | number | string | undefined;
    set endValue(value: Date | number | string | undefined);
    get startValue(): Date | number | string | undefined;
    set startValue(value: Date | number | string | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiChartBreakComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiChartBreakComponent, "dxi-chart-break", never, { "endValue": { "alias": "endValue"; "required": false; }; "startValue": { "alias": "startValue"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxiChartBreakModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiChartBreakModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiChartBreakModule, never, [typeof DxiChartBreakComponent], [typeof DxiChartBreakComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiChartBreakModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoChartBreakStyleComponent extends NestedOption implements OnDestroy, OnInit {
    get color(): string;
    set color(value: string);
    get line(): ScaleBreakLineStyle;
    set line(value: ScaleBreakLineStyle);
    get width(): number;
    set width(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChartBreakStyleComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoChartBreakStyleComponent, "dxo-chart-break-style", never, { "color": { "alias": "color"; "required": false; }; "line": { "alias": "line"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoChartBreakStyleModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChartBreakStyleModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoChartBreakStyleModule, never, [typeof DxoChartBreakStyleComponent], [typeof DxoChartBreakStyleComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoChartBreakStyleModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoChartChartTitleSubtitleComponent extends NestedOption implements OnDestroy, OnInit {
    get font(): Font;
    set font(value: Font);
    get offset(): number;
    set offset(value: number);
    get text(): string | undefined;
    set text(value: string | undefined);
    get textOverflow(): TextOverflow;
    set textOverflow(value: TextOverflow);
    get wordWrap(): WordWrap;
    set wordWrap(value: WordWrap);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChartChartTitleSubtitleComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoChartChartTitleSubtitleComponent, "dxo-chart-chart-title-subtitle", never, { "font": { "alias": "font"; "required": false; }; "offset": { "alias": "offset"; "required": false; }; "text": { "alias": "text"; "required": false; }; "textOverflow": { "alias": "textOverflow"; "required": false; }; "wordWrap": { "alias": "wordWrap"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoChartChartTitleSubtitleModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChartChartTitleSubtitleModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoChartChartTitleSubtitleModule, never, [typeof DxoChartChartTitleSubtitleComponent], [typeof DxoChartChartTitleSubtitleComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoChartChartTitleSubtitleModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoChartChartTitleComponent extends NestedOption implements OnDestroy, OnInit {
    get font(): Font;
    set font(value: Font);
    get horizontalAlignment(): HorizontalAlignment;
    set horizontalAlignment(value: HorizontalAlignment);
    get margin(): number | {
        bottom?: number;
        left?: number;
        right?: number;
        top?: number;
    };
    set margin(value: number | {
        bottom?: number;
        left?: number;
        right?: number;
        top?: number;
    });
    get placeholderSize(): number | undefined;
    set placeholderSize(value: number | undefined);
    get subtitle(): string | {
        font?: Font;
        offset?: number;
        text?: string | undefined;
        textOverflow?: TextOverflow;
        wordWrap?: WordWrap;
    };
    set subtitle(value: string | {
        font?: Font;
        offset?: number;
        text?: string | undefined;
        textOverflow?: TextOverflow;
        wordWrap?: WordWrap;
    });
    get text(): string | undefined;
    set text(value: string | undefined);
    get textOverflow(): TextOverflow;
    set textOverflow(value: TextOverflow);
    get verticalAlignment(): VerticalEdge;
    set verticalAlignment(value: VerticalEdge);
    get wordWrap(): WordWrap;
    set wordWrap(value: WordWrap);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChartChartTitleComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoChartChartTitleComponent, "dxo-chart-chart-title", never, { "font": { "alias": "font"; "required": false; }; "horizontalAlignment": { "alias": "horizontalAlignment"; "required": false; }; "margin": { "alias": "margin"; "required": false; }; "placeholderSize": { "alias": "placeholderSize"; "required": false; }; "subtitle": { "alias": "subtitle"; "required": false; }; "text": { "alias": "text"; "required": false; }; "textOverflow": { "alias": "textOverflow"; "required": false; }; "verticalAlignment": { "alias": "verticalAlignment"; "required": false; }; "wordWrap": { "alias": "wordWrap"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoChartChartTitleModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChartChartTitleModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoChartChartTitleModule, never, [typeof DxoChartChartTitleComponent], [typeof DxoChartChartTitleComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoChartChartTitleModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoChartColorComponent extends NestedOption implements OnDestroy, OnInit {
    get base(): string | undefined;
    set base(value: string | undefined);
    get fillId(): string | undefined;
    set fillId(value: string | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChartColorComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoChartColorComponent, "dxo-chart-color", never, { "base": { "alias": "base"; "required": false; }; "fillId": { "alias": "fillId"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoChartColorModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChartColorModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoChartColorModule, never, [typeof DxoChartColorComponent], [typeof DxoChartColorComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoChartColorModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoChartCommonAnnotationSettingsComponent extends NestedOption implements AfterViewInit, OnDestroy, OnInit, IDxTemplateHost {
    private renderer;
    private document;
    private element;
    get allowDragging(): boolean;
    set allowDragging(value: boolean);
    get argument(): Date | number | string | undefined;
    set argument(value: Date | number | string | undefined);
    get arrowLength(): number;
    set arrowLength(value: number);
    get arrowWidth(): number;
    set arrowWidth(value: number);
    get axis(): string | undefined;
    set axis(value: string | undefined);
    get border(): {
        color?: string;
        cornerRadius?: number;
        dashStyle?: DashStyle;
        opacity?: number | undefined;
        visible?: boolean;
        width?: number;
    };
    set border(value: {
        color?: string;
        cornerRadius?: number;
        dashStyle?: DashStyle;
        opacity?: number | undefined;
        visible?: boolean;
        width?: number;
    });
    get color(): string;
    set color(value: string);
    get customizeTooltip(): ((annotation: dxChartAnnotationConfig | any) => Record<string, any>) | undefined;
    set customizeTooltip(value: ((annotation: dxChartAnnotationConfig | any) => Record<string, any>) | undefined);
    get data(): any;
    set data(value: any);
    get description(): string | undefined;
    set description(value: string | undefined);
    get font(): Font;
    set font(value: Font);
    get height(): number | undefined;
    set height(value: number | undefined);
    get image(): string | {
        height?: number;
        url?: string | undefined;
        width?: number;
    };
    set image(value: string | {
        height?: number;
        url?: string | undefined;
        width?: number;
    });
    get offsetX(): number | undefined;
    set offsetX(value: number | undefined);
    get offsetY(): number | undefined;
    set offsetY(value: number | undefined);
    get opacity(): number;
    set opacity(value: number);
    get paddingLeftRight(): number;
    set paddingLeftRight(value: number);
    get paddingTopBottom(): number;
    set paddingTopBottom(value: number);
    get series(): string | undefined;
    set series(value: string | undefined);
    get shadow(): {
        blur?: number;
        color?: string;
        offsetX?: number;
        offsetY?: number;
        opacity?: number;
    };
    set shadow(value: {
        blur?: number;
        color?: string;
        offsetX?: number;
        offsetY?: number;
        opacity?: number;
    });
    get template(): any;
    set template(value: any);
    get text(): string | undefined;
    set text(value: string | undefined);
    get textOverflow(): TextOverflow;
    set textOverflow(value: TextOverflow);
    get tooltipEnabled(): boolean;
    set tooltipEnabled(value: boolean);
    get tooltipTemplate(): any;
    set tooltipTemplate(value: any);
    get type(): AnnotationType | undefined;
    set type(value: AnnotationType | undefined);
    get value(): Date | number | string | undefined;
    set value(value: Date | number | string | undefined);
    get width(): number | undefined;
    set width(value: number | undefined);
    get wordWrap(): WordWrap;
    set wordWrap(value: WordWrap);
    get x(): number | undefined;
    set x(value: number | undefined);
    get y(): number | undefined;
    set y(value: number | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost, renderer: Renderer2, document: any, templateHost: DxTemplateHost, element: ElementRef);
    setTemplate(template: DxTemplateDirective): void;
    ngAfterViewInit(): void;
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChartCommonAnnotationSettingsComponent, [{ host: true; skipSelf: true; }, { host: true; }, null, null, { host: true; }, null]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoChartCommonAnnotationSettingsComponent, "dxo-chart-common-annotation-settings", never, { "allowDragging": { "alias": "allowDragging"; "required": false; }; "argument": { "alias": "argument"; "required": false; }; "arrowLength": { "alias": "arrowLength"; "required": false; }; "arrowWidth": { "alias": "arrowWidth"; "required": false; }; "axis": { "alias": "axis"; "required": false; }; "border": { "alias": "border"; "required": false; }; "color": { "alias": "color"; "required": false; }; "customizeTooltip": { "alias": "customizeTooltip"; "required": false; }; "data": { "alias": "data"; "required": false; }; "description": { "alias": "description"; "required": false; }; "font": { "alias": "font"; "required": false; }; "height": { "alias": "height"; "required": false; }; "image": { "alias": "image"; "required": false; }; "offsetX": { "alias": "offsetX"; "required": false; }; "offsetY": { "alias": "offsetY"; "required": false; }; "opacity": { "alias": "opacity"; "required": false; }; "paddingLeftRight": { "alias": "paddingLeftRight"; "required": false; }; "paddingTopBottom": { "alias": "paddingTopBottom"; "required": false; }; "series": { "alias": "series"; "required": false; }; "shadow": { "alias": "shadow"; "required": false; }; "template": { "alias": "template"; "required": false; }; "text": { "alias": "text"; "required": false; }; "textOverflow": { "alias": "textOverflow"; "required": false; }; "tooltipEnabled": { "alias": "tooltipEnabled"; "required": false; }; "tooltipTemplate": { "alias": "tooltipTemplate"; "required": false; }; "type": { "alias": "type"; "required": false; }; "value": { "alias": "value"; "required": false; }; "width": { "alias": "width"; "required": false; }; "wordWrap": { "alias": "wordWrap"; "required": false; }; "x": { "alias": "x"; "required": false; }; "y": { "alias": "y"; "required": false; }; }, {}, never, ["*"], true, never>;
}
declare class DxoChartCommonAnnotationSettingsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChartCommonAnnotationSettingsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoChartCommonAnnotationSettingsModule, never, [typeof DxoChartCommonAnnotationSettingsComponent], [typeof DxoChartCommonAnnotationSettingsComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoChartCommonAnnotationSettingsModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoChartCommonAxisSettingsConstantLineStyleLabelComponent extends NestedOption implements OnDestroy, OnInit {
    get font(): Font;
    set font(value: Font);
    get position(): RelativePosition;
    set position(value: RelativePosition);
    get visible(): boolean;
    set visible(value: boolean);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChartCommonAxisSettingsConstantLineStyleLabelComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoChartCommonAxisSettingsConstantLineStyleLabelComponent, "dxo-chart-common-axis-settings-constant-line-style-label", never, { "font": { "alias": "font"; "required": false; }; "position": { "alias": "position"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoChartCommonAxisSettingsConstantLineStyleLabelModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChartCommonAxisSettingsConstantLineStyleLabelModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoChartCommonAxisSettingsConstantLineStyleLabelModule, never, [typeof DxoChartCommonAxisSettingsConstantLineStyleLabelComponent], [typeof DxoChartCommonAxisSettingsConstantLineStyleLabelComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoChartCommonAxisSettingsConstantLineStyleLabelModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoChartCommonAxisSettingsConstantLineStyleComponent extends NestedOption implements OnDestroy, OnInit {
    get color(): string;
    set color(value: string);
    get dashStyle(): DashStyle;
    set dashStyle(value: DashStyle);
    get label(): {
        font?: Font;
        position?: RelativePosition;
        visible?: boolean;
    };
    set label(value: {
        font?: Font;
        position?: RelativePosition;
        visible?: boolean;
    });
    get paddingLeftRight(): number;
    set paddingLeftRight(value: number);
    get paddingTopBottom(): number;
    set paddingTopBottom(value: number);
    get width(): number;
    set width(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChartCommonAxisSettingsConstantLineStyleComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoChartCommonAxisSettingsConstantLineStyleComponent, "dxo-chart-common-axis-settings-constant-line-style", never, { "color": { "alias": "color"; "required": false; }; "dashStyle": { "alias": "dashStyle"; "required": false; }; "label": { "alias": "label"; "required": false; }; "paddingLeftRight": { "alias": "paddingLeftRight"; "required": false; }; "paddingTopBottom": { "alias": "paddingTopBottom"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoChartCommonAxisSettingsConstantLineStyleModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChartCommonAxisSettingsConstantLineStyleModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoChartCommonAxisSettingsConstantLineStyleModule, never, [typeof DxoChartCommonAxisSettingsConstantLineStyleComponent], [typeof DxoChartCommonAxisSettingsConstantLineStyleComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoChartCommonAxisSettingsConstantLineStyleModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoChartCommonAxisSettingsLabelComponent extends NestedOption implements AfterViewInit, OnDestroy, OnInit, IDxTemplateHost {
    private renderer;
    private document;
    private element;
    get alignment(): HorizontalAlignment | undefined;
    set alignment(value: HorizontalAlignment | undefined);
    get displayMode(): ChartLabelDisplayMode;
    set displayMode(value: ChartLabelDisplayMode);
    get font(): Font;
    set font(value: Font);
    get indentFromAxis(): number;
    set indentFromAxis(value: number);
    get overlappingBehavior(): ChartsAxisLabelOverlap;
    set overlappingBehavior(value: ChartsAxisLabelOverlap);
    get position(): Position | RelativePosition;
    set position(value: Position | RelativePosition);
    get rotationAngle(): number;
    set rotationAngle(value: number);
    get staggeringSpacing(): number;
    set staggeringSpacing(value: number);
    get template(): any;
    set template(value: any);
    get textOverflow(): TextOverflow;
    set textOverflow(value: TextOverflow);
    get visible(): boolean;
    set visible(value: boolean);
    get wordWrap(): WordWrap;
    set wordWrap(value: WordWrap);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost, renderer: Renderer2, document: any, templateHost: DxTemplateHost, element: ElementRef);
    setTemplate(template: DxTemplateDirective): void;
    ngAfterViewInit(): void;
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChartCommonAxisSettingsLabelComponent, [{ host: true; skipSelf: true; }, { host: true; }, null, null, { host: true; }, null]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoChartCommonAxisSettingsLabelComponent, "dxo-chart-common-axis-settings-label", never, { "alignment": { "alias": "alignment"; "required": false; }; "displayMode": { "alias": "displayMode"; "required": false; }; "font": { "alias": "font"; "required": false; }; "indentFromAxis": { "alias": "indentFromAxis"; "required": false; }; "overlappingBehavior": { "alias": "overlappingBehavior"; "required": false; }; "position": { "alias": "position"; "required": false; }; "rotationAngle": { "alias": "rotationAngle"; "required": false; }; "staggeringSpacing": { "alias": "staggeringSpacing"; "required": false; }; "template": { "alias": "template"; "required": false; }; "textOverflow": { "alias": "textOverflow"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "wordWrap": { "alias": "wordWrap"; "required": false; }; }, {}, never, ["*"], true, never>;
}
declare class DxoChartCommonAxisSettingsLabelModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChartCommonAxisSettingsLabelModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoChartCommonAxisSettingsLabelModule, never, [typeof DxoChartCommonAxisSettingsLabelComponent], [typeof DxoChartCommonAxisSettingsLabelComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoChartCommonAxisSettingsLabelModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoChartCommonAxisSettingsTitleComponent extends NestedOption implements OnDestroy, OnInit {
    get alignment(): HorizontalAlignment;
    set alignment(value: HorizontalAlignment);
    get font(): Font;
    set font(value: Font);
    get margin(): number;
    set margin(value: number);
    get textOverflow(): TextOverflow;
    set textOverflow(value: TextOverflow);
    get wordWrap(): WordWrap;
    set wordWrap(value: WordWrap);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChartCommonAxisSettingsTitleComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoChartCommonAxisSettingsTitleComponent, "dxo-chart-common-axis-settings-title", never, { "alignment": { "alias": "alignment"; "required": false; }; "font": { "alias": "font"; "required": false; }; "margin": { "alias": "margin"; "required": false; }; "textOverflow": { "alias": "textOverflow"; "required": false; }; "wordWrap": { "alias": "wordWrap"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoChartCommonAxisSettingsTitleModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChartCommonAxisSettingsTitleModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoChartCommonAxisSettingsTitleModule, never, [typeof DxoChartCommonAxisSettingsTitleComponent], [typeof DxoChartCommonAxisSettingsTitleComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoChartCommonAxisSettingsTitleModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoChartCommonAxisSettingsComponent extends NestedOption implements OnDestroy, OnInit {
    get aggregatedPointsPosition(): AggregatedPointsPosition;
    set aggregatedPointsPosition(value: AggregatedPointsPosition);
    get allowDecimals(): boolean | undefined;
    set allowDecimals(value: boolean | undefined);
    get breakStyle(): {
        color?: string;
        line?: ScaleBreakLineStyle;
        width?: number;
    };
    set breakStyle(value: {
        color?: string;
        line?: ScaleBreakLineStyle;
        width?: number;
    });
    get color(): string;
    set color(value: string);
    get constantLineStyle(): {
        color?: string;
        dashStyle?: DashStyle;
        label?: {
            font?: Font;
            position?: RelativePosition;
            visible?: boolean;
        };
        paddingLeftRight?: number;
        paddingTopBottom?: number;
        width?: number;
    };
    set constantLineStyle(value: {
        color?: string;
        dashStyle?: DashStyle;
        label?: {
            font?: Font;
            position?: RelativePosition;
            visible?: boolean;
        };
        paddingLeftRight?: number;
        paddingTopBottom?: number;
        width?: number;
    });
    get discreteAxisDivisionMode(): DiscreteAxisDivisionMode;
    set discreteAxisDivisionMode(value: DiscreteAxisDivisionMode);
    get endOnTick(): boolean | undefined;
    set endOnTick(value: boolean | undefined);
    get grid(): {
        color?: string;
        opacity?: number | undefined;
        visible?: boolean;
        width?: number;
    };
    set grid(value: {
        color?: string;
        opacity?: number | undefined;
        visible?: boolean;
        width?: number;
    });
    get inverted(): boolean;
    set inverted(value: boolean);
    get label(): {
        alignment?: HorizontalAlignment | undefined;
        displayMode?: ChartLabelDisplayMode;
        font?: Font;
        indentFromAxis?: number;
        overlappingBehavior?: ChartsAxisLabelOverlap;
        position?: Position | RelativePosition;
        rotationAngle?: number;
        staggeringSpacing?: number;
        template?: any;
        textOverflow?: TextOverflow;
        visible?: boolean;
        wordWrap?: WordWrap;
    };
    set label(value: {
        alignment?: HorizontalAlignment | undefined;
        displayMode?: ChartLabelDisplayMode;
        font?: Font;
        indentFromAxis?: number;
        overlappingBehavior?: ChartsAxisLabelOverlap;
        position?: Position | RelativePosition;
        rotationAngle?: number;
        staggeringSpacing?: number;
        template?: any;
        textOverflow?: TextOverflow;
        visible?: boolean;
        wordWrap?: WordWrap;
    });
    get maxValueMargin(): number | undefined;
    set maxValueMargin(value: number | undefined);
    get minorGrid(): {
        color?: string;
        opacity?: number | undefined;
        visible?: boolean;
        width?: number;
    };
    set minorGrid(value: {
        color?: string;
        opacity?: number | undefined;
        visible?: boolean;
        width?: number;
    });
    get minorTick(): {
        color?: string;
        length?: number;
        opacity?: number;
        shift?: number;
        visible?: boolean;
        width?: number;
    };
    set minorTick(value: {
        color?: string;
        length?: number;
        opacity?: number;
        shift?: number;
        visible?: boolean;
        width?: number;
    });
    get minValueMargin(): number | undefined;
    set minValueMargin(value: number | undefined);
    get opacity(): number | undefined;
    set opacity(value: number | undefined);
    get placeholderSize(): null | number;
    set placeholderSize(value: null | number);
    get stripStyle(): {
        label?: {
            font?: Font;
            horizontalAlignment?: HorizontalAlignment;
            verticalAlignment?: VerticalAlignment;
        };
        paddingLeftRight?: number;
        paddingTopBottom?: number;
    };
    set stripStyle(value: {
        label?: {
            font?: Font;
            horizontalAlignment?: HorizontalAlignment;
            verticalAlignment?: VerticalAlignment;
        };
        paddingLeftRight?: number;
        paddingTopBottom?: number;
    });
    get tick(): {
        color?: string;
        length?: number;
        opacity?: number | undefined;
        shift?: number;
        visible?: boolean;
        width?: number;
    };
    set tick(value: {
        color?: string;
        length?: number;
        opacity?: number | undefined;
        shift?: number;
        visible?: boolean;
        width?: number;
    });
    get title(): {
        alignment?: HorizontalAlignment;
        font?: Font;
        margin?: number;
        textOverflow?: TextOverflow;
        wordWrap?: WordWrap;
    };
    set title(value: {
        alignment?: HorizontalAlignment;
        font?: Font;
        margin?: number;
        textOverflow?: TextOverflow;
        wordWrap?: WordWrap;
    });
    get valueMarginsEnabled(): boolean;
    set valueMarginsEnabled(value: boolean);
    get visible(): boolean;
    set visible(value: boolean);
    get width(): number;
    set width(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChartCommonAxisSettingsComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoChartCommonAxisSettingsComponent, "dxo-chart-common-axis-settings", never, { "aggregatedPointsPosition": { "alias": "aggregatedPointsPosition"; "required": false; }; "allowDecimals": { "alias": "allowDecimals"; "required": false; }; "breakStyle": { "alias": "breakStyle"; "required": false; }; "color": { "alias": "color"; "required": false; }; "constantLineStyle": { "alias": "constantLineStyle"; "required": false; }; "discreteAxisDivisionMode": { "alias": "discreteAxisDivisionMode"; "required": false; }; "endOnTick": { "alias": "endOnTick"; "required": false; }; "grid": { "alias": "grid"; "required": false; }; "inverted": { "alias": "inverted"; "required": false; }; "label": { "alias": "label"; "required": false; }; "maxValueMargin": { "alias": "maxValueMargin"; "required": false; }; "minorGrid": { "alias": "minorGrid"; "required": false; }; "minorTick": { "alias": "minorTick"; "required": false; }; "minValueMargin": { "alias": "minValueMargin"; "required": false; }; "opacity": { "alias": "opacity"; "required": false; }; "placeholderSize": { "alias": "placeholderSize"; "required": false; }; "stripStyle": { "alias": "stripStyle"; "required": false; }; "tick": { "alias": "tick"; "required": false; }; "title": { "alias": "title"; "required": false; }; "valueMarginsEnabled": { "alias": "valueMarginsEnabled"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoChartCommonAxisSettingsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChartCommonAxisSettingsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoChartCommonAxisSettingsModule, never, [typeof DxoChartCommonAxisSettingsComponent], [typeof DxoChartCommonAxisSettingsComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoChartCommonAxisSettingsModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoChartCommonPaneSettingsComponent extends NestedOption implements OnDestroy, OnInit {
    get backgroundColor(): ChartsColor | string;
    set backgroundColor(value: ChartsColor | string);
    get border(): {
        bottom?: boolean;
        color?: string;
        dashStyle?: DashStyle;
        left?: boolean;
        opacity?: number | undefined;
        right?: boolean;
        top?: boolean;
        visible?: boolean;
        width?: number;
    };
    set border(value: {
        bottom?: boolean;
        color?: string;
        dashStyle?: DashStyle;
        left?: boolean;
        opacity?: number | undefined;
        right?: boolean;
        top?: boolean;
        visible?: boolean;
        width?: number;
    });
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChartCommonPaneSettingsComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoChartCommonPaneSettingsComponent, "dxo-chart-common-pane-settings", never, { "backgroundColor": { "alias": "backgroundColor"; "required": false; }; "border": { "alias": "border"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoChartCommonPaneSettingsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChartCommonPaneSettingsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoChartCommonPaneSettingsModule, never, [typeof DxoChartCommonPaneSettingsComponent], [typeof DxoChartCommonPaneSettingsComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoChartCommonPaneSettingsModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoChartCommonSeriesSettingsHoverStyleComponent extends NestedOption implements OnDestroy, OnInit {
    get border(): {
        color?: string | undefined;
        dashStyle?: DashStyle | undefined;
        visible?: boolean;
        width?: number;
    };
    set border(value: {
        color?: string | undefined;
        dashStyle?: DashStyle | undefined;
        visible?: boolean;
        width?: number;
    });
    get color(): ChartsColor | string | undefined;
    set color(value: ChartsColor | string | undefined);
    get dashStyle(): DashStyle;
    set dashStyle(value: DashStyle);
    get hatching(): {
        direction?: HatchDirection;
        opacity?: number;
        step?: number;
        width?: number;
    };
    set hatching(value: {
        direction?: HatchDirection;
        opacity?: number;
        step?: number;
        width?: number;
    });
    get highlight(): boolean;
    set highlight(value: boolean);
    get width(): number;
    set width(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChartCommonSeriesSettingsHoverStyleComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoChartCommonSeriesSettingsHoverStyleComponent, "dxo-chart-common-series-settings-hover-style", never, { "border": { "alias": "border"; "required": false; }; "color": { "alias": "color"; "required": false; }; "dashStyle": { "alias": "dashStyle"; "required": false; }; "hatching": { "alias": "hatching"; "required": false; }; "highlight": { "alias": "highlight"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoChartCommonSeriesSettingsHoverStyleModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChartCommonSeriesSettingsHoverStyleModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoChartCommonSeriesSettingsHoverStyleModule, never, [typeof DxoChartCommonSeriesSettingsHoverStyleComponent], [typeof DxoChartCommonSeriesSettingsHoverStyleComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoChartCommonSeriesSettingsHoverStyleModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoChartCommonSeriesSettingsLabelComponent extends NestedOption implements OnDestroy, OnInit {
    get alignment(): HorizontalAlignment;
    set alignment(value: HorizontalAlignment);
    get argumentFormat(): Format | undefined;
    set argumentFormat(value: Format | undefined);
    get backgroundColor(): string | undefined;
    set backgroundColor(value: string | undefined);
    get border(): {
        color?: string | undefined;
        dashStyle?: DashStyle | undefined;
        visible?: boolean;
        width?: number;
    };
    set border(value: {
        color?: string | undefined;
        dashStyle?: DashStyle | undefined;
        visible?: boolean;
        width?: number;
    });
    get connector(): {
        color?: string | undefined;
        visible?: boolean;
        width?: number;
    };
    set connector(value: {
        color?: string | undefined;
        visible?: boolean;
        width?: number;
    });
    get customizeText(): ((pointInfo: any) => string);
    set customizeText(value: ((pointInfo: any) => string));
    get displayFormat(): string | undefined;
    set displayFormat(value: string | undefined);
    get font(): Font;
    set font(value: Font);
    get format(): Format | undefined;
    set format(value: Format | undefined);
    get horizontalOffset(): number;
    set horizontalOffset(value: number);
    get position(): RelativePosition;
    set position(value: RelativePosition);
    get rotationAngle(): number;
    set rotationAngle(value: number);
    get showForZeroValues(): boolean;
    set showForZeroValues(value: boolean);
    get verticalOffset(): number;
    set verticalOffset(value: number);
    get visible(): boolean;
    set visible(value: boolean);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChartCommonSeriesSettingsLabelComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoChartCommonSeriesSettingsLabelComponent, "dxo-chart-common-series-settings-label", never, { "alignment": { "alias": "alignment"; "required": false; }; "argumentFormat": { "alias": "argumentFormat"; "required": false; }; "backgroundColor": { "alias": "backgroundColor"; "required": false; }; "border": { "alias": "border"; "required": false; }; "connector": { "alias": "connector"; "required": false; }; "customizeText": { "alias": "customizeText"; "required": false; }; "displayFormat": { "alias": "displayFormat"; "required": false; }; "font": { "alias": "font"; "required": false; }; "format": { "alias": "format"; "required": false; }; "horizontalOffset": { "alias": "horizontalOffset"; "required": false; }; "position": { "alias": "position"; "required": false; }; "rotationAngle": { "alias": "rotationAngle"; "required": false; }; "showForZeroValues": { "alias": "showForZeroValues"; "required": false; }; "verticalOffset": { "alias": "verticalOffset"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoChartCommonSeriesSettingsLabelModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChartCommonSeriesSettingsLabelModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoChartCommonSeriesSettingsLabelModule, never, [typeof DxoChartCommonSeriesSettingsLabelComponent], [typeof DxoChartCommonSeriesSettingsLabelComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoChartCommonSeriesSettingsLabelModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoChartCommonSeriesSettingsSelectionStyleComponent extends NestedOption implements OnDestroy, OnInit {
    get border(): {
        color?: string | undefined;
        dashStyle?: DashStyle | undefined;
        visible?: boolean;
        width?: number;
    };
    set border(value: {
        color?: string | undefined;
        dashStyle?: DashStyle | undefined;
        visible?: boolean;
        width?: number;
    });
    get color(): ChartsColor | string | undefined;
    set color(value: ChartsColor | string | undefined);
    get dashStyle(): DashStyle;
    set dashStyle(value: DashStyle);
    get hatching(): {
        direction?: HatchDirection;
        opacity?: number;
        step?: number;
        width?: number;
    };
    set hatching(value: {
        direction?: HatchDirection;
        opacity?: number;
        step?: number;
        width?: number;
    });
    get highlight(): boolean;
    set highlight(value: boolean);
    get width(): number;
    set width(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChartCommonSeriesSettingsSelectionStyleComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoChartCommonSeriesSettingsSelectionStyleComponent, "dxo-chart-common-series-settings-selection-style", never, { "border": { "alias": "border"; "required": false; }; "color": { "alias": "color"; "required": false; }; "dashStyle": { "alias": "dashStyle"; "required": false; }; "hatching": { "alias": "hatching"; "required": false; }; "highlight": { "alias": "highlight"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoChartCommonSeriesSettingsSelectionStyleModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChartCommonSeriesSettingsSelectionStyleModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoChartCommonSeriesSettingsSelectionStyleModule, never, [typeof DxoChartCommonSeriesSettingsSelectionStyleComponent], [typeof DxoChartCommonSeriesSettingsSelectionStyleComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoChartCommonSeriesSettingsSelectionStyleModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoChartCommonSeriesSettingsComponent extends NestedOption implements OnDestroy, OnInit {
    get aggregation(): {
        calculate?: ((aggregationInfo: chartPointAggregationInfoObject, series: chartSeriesObject) => Record<string, any> | Array<Record<string, any>>) | undefined;
        enabled?: boolean;
        method?: ChartSeriesAggregationMethod;
    };
    set aggregation(value: {
        calculate?: ((aggregationInfo: chartPointAggregationInfoObject, series: chartSeriesObject) => Record<string, any> | Array<Record<string, any>>) | undefined;
        enabled?: boolean;
        method?: ChartSeriesAggregationMethod;
    });
    get area(): any;
    set area(value: any);
    get argumentField(): string;
    set argumentField(value: string);
    get axis(): string | undefined;
    set axis(value: string | undefined);
    get bar(): any;
    set bar(value: any);
    get barOverlapGroup(): string | undefined;
    set barOverlapGroup(value: string | undefined);
    get barPadding(): number | undefined;
    set barPadding(value: number | undefined);
    get barWidth(): number | undefined;
    set barWidth(value: number | undefined);
    get border(): {
        color?: string | undefined;
        dashStyle?: DashStyle | undefined;
        visible?: boolean;
        width?: number;
    };
    set border(value: {
        color?: string | undefined;
        dashStyle?: DashStyle | undefined;
        visible?: boolean;
        width?: number;
    });
    get bubble(): any;
    set bubble(value: any);
    get candlestick(): any;
    set candlestick(value: any);
    get closeValueField(): string;
    set closeValueField(value: string);
    get color(): ChartsColor | string | undefined;
    set color(value: ChartsColor | string | undefined);
    get cornerRadius(): number;
    set cornerRadius(value: number);
    get dashStyle(): DashStyle;
    set dashStyle(value: DashStyle);
    get fullstackedarea(): any;
    set fullstackedarea(value: any);
    get fullstackedbar(): any;
    set fullstackedbar(value: any);
    get fullstackedline(): any;
    set fullstackedline(value: any);
    get fullstackedspline(): any;
    set fullstackedspline(value: any);
    get fullstackedsplinearea(): any;
    set fullstackedsplinearea(value: any);
    get highValueField(): string;
    set highValueField(value: string);
    get hoverMode(): SeriesHoverMode;
    set hoverMode(value: SeriesHoverMode);
    get hoverStyle(): {
        border?: {
            color?: string | undefined;
            dashStyle?: DashStyle | undefined;
            visible?: boolean;
            width?: number;
        };
        color?: ChartsColor | string | undefined;
        dashStyle?: DashStyle;
        hatching?: {
            direction?: HatchDirection;
            opacity?: number;
            step?: number;
            width?: number;
        };
        highlight?: boolean;
        width?: number;
    };
    set hoverStyle(value: {
        border?: {
            color?: string | undefined;
            dashStyle?: DashStyle | undefined;
            visible?: boolean;
            width?: number;
        };
        color?: ChartsColor | string | undefined;
        dashStyle?: DashStyle;
        hatching?: {
            direction?: HatchDirection;
            opacity?: number;
            step?: number;
            width?: number;
        };
        highlight?: boolean;
        width?: number;
    });
    get ignoreEmptyPoints(): boolean;
    set ignoreEmptyPoints(value: boolean);
    get innerColor(): string;
    set innerColor(value: string);
    get label(): {
        alignment?: HorizontalAlignment;
        argumentFormat?: Format | undefined;
        backgroundColor?: string | undefined;
        border?: {
            color?: string | undefined;
            dashStyle?: DashStyle | undefined;
            visible?: boolean;
            width?: number;
        };
        connector?: {
            color?: string | undefined;
            visible?: boolean;
            width?: number;
        };
        customizeText?: ((pointInfo: any) => string);
        displayFormat?: string | undefined;
        font?: Font;
        format?: Format | undefined;
        horizontalOffset?: number;
        position?: RelativePosition;
        rotationAngle?: number;
        showForZeroValues?: boolean;
        verticalOffset?: number;
        visible?: boolean;
    };
    set label(value: {
        alignment?: HorizontalAlignment;
        argumentFormat?: Format | undefined;
        backgroundColor?: string | undefined;
        border?: {
            color?: string | undefined;
            dashStyle?: DashStyle | undefined;
            visible?: boolean;
            width?: number;
        };
        connector?: {
            color?: string | undefined;
            visible?: boolean;
            width?: number;
        };
        customizeText?: ((pointInfo: any) => string);
        displayFormat?: string | undefined;
        font?: Font;
        format?: Format | undefined;
        horizontalOffset?: number;
        position?: RelativePosition;
        rotationAngle?: number;
        showForZeroValues?: boolean;
        verticalOffset?: number;
        visible?: boolean;
    });
    get line(): any;
    set line(value: any);
    get lowValueField(): string;
    set lowValueField(value: string);
    get maxLabelCount(): number | undefined;
    set maxLabelCount(value: number | undefined);
    get minBarSize(): number | undefined;
    set minBarSize(value: number | undefined);
    get opacity(): number;
    set opacity(value: number);
    get openValueField(): string;
    set openValueField(value: string);
    get pane(): string;
    set pane(value: string);
    get point(): {
        border?: {
            color?: string | undefined;
            visible?: boolean;
            width?: number;
        };
        color?: ChartsColor | string | undefined;
        hoverMode?: PointInteractionMode;
        hoverStyle?: {
            border?: {
                color?: string | undefined;
                visible?: boolean;
                width?: number;
            };
            color?: ChartsColor | string | undefined;
            size?: number | undefined;
        };
        image?: string | undefined | {
            height?: number | {
                rangeMaxPoint?: number | undefined;
                rangeMinPoint?: number | undefined;
            };
            url?: string | undefined | {
                rangeMaxPoint?: string | undefined;
                rangeMinPoint?: string | undefined;
            };
            width?: number | {
                rangeMaxPoint?: number | undefined;
                rangeMinPoint?: number | undefined;
            };
        };
        selectionMode?: PointInteractionMode;
        selectionStyle?: {
            border?: {
                color?: string | undefined;
                visible?: boolean;
                width?: number;
            };
            color?: ChartsColor | string | undefined;
            size?: number | undefined;
        };
        size?: number;
        symbol?: PointSymbol;
        visible?: boolean;
    };
    set point(value: {
        border?: {
            color?: string | undefined;
            visible?: boolean;
            width?: number;
        };
        color?: ChartsColor | string | undefined;
        hoverMode?: PointInteractionMode;
        hoverStyle?: {
            border?: {
                color?: string | undefined;
                visible?: boolean;
                width?: number;
            };
            color?: ChartsColor | string | undefined;
            size?: number | undefined;
        };
        image?: string | undefined | {
            height?: number | {
                rangeMaxPoint?: number | undefined;
                rangeMinPoint?: number | undefined;
            };
            url?: string | undefined | {
                rangeMaxPoint?: string | undefined;
                rangeMinPoint?: string | undefined;
            };
            width?: number | {
                rangeMaxPoint?: number | undefined;
                rangeMinPoint?: number | undefined;
            };
        };
        selectionMode?: PointInteractionMode;
        selectionStyle?: {
            border?: {
                color?: string | undefined;
                visible?: boolean;
                width?: number;
            };
            color?: ChartsColor | string | undefined;
            size?: number | undefined;
        };
        size?: number;
        symbol?: PointSymbol;
        visible?: boolean;
    });
    get rangearea(): any;
    set rangearea(value: any);
    get rangebar(): any;
    set rangebar(value: any);
    get rangeValue1Field(): string;
    set rangeValue1Field(value: string);
    get rangeValue2Field(): string;
    set rangeValue2Field(value: string);
    get reduction(): {
        color?: string;
        level?: FinancialChartReductionLevel;
    };
    set reduction(value: {
        color?: string;
        level?: FinancialChartReductionLevel;
    });
    get scatter(): any;
    set scatter(value: any);
    get selectionMode(): SeriesSelectionMode;
    set selectionMode(value: SeriesSelectionMode);
    get selectionStyle(): {
        border?: {
            color?: string | undefined;
            dashStyle?: DashStyle | undefined;
            visible?: boolean;
            width?: number;
        };
        color?: ChartsColor | string | undefined;
        dashStyle?: DashStyle;
        hatching?: {
            direction?: HatchDirection;
            opacity?: number;
            step?: number;
            width?: number;
        };
        highlight?: boolean;
        width?: number;
    };
    set selectionStyle(value: {
        border?: {
            color?: string | undefined;
            dashStyle?: DashStyle | undefined;
            visible?: boolean;
            width?: number;
        };
        color?: ChartsColor | string | undefined;
        dashStyle?: DashStyle;
        hatching?: {
            direction?: HatchDirection;
            opacity?: number;
            step?: number;
            width?: number;
        };
        highlight?: boolean;
        width?: number;
    });
    get showInLegend(): boolean;
    set showInLegend(value: boolean);
    get sizeField(): string;
    set sizeField(value: string);
    get spline(): any;
    set spline(value: any);
    get splinearea(): any;
    set splinearea(value: any);
    get stack(): string;
    set stack(value: string);
    get stackedarea(): any;
    set stackedarea(value: any);
    get stackedbar(): any;
    set stackedbar(value: any);
    get stackedline(): any;
    set stackedline(value: any);
    get stackedspline(): any;
    set stackedspline(value: any);
    get stackedsplinearea(): any;
    set stackedsplinearea(value: any);
    get steparea(): any;
    set steparea(value: any);
    get stepline(): any;
    set stepline(value: any);
    get stock(): any;
    set stock(value: any);
    get tagField(): string;
    set tagField(value: string);
    get type(): SeriesType;
    set type(value: SeriesType);
    get valueErrorBar(): {
        color?: string;
        displayMode?: ValueErrorBarDisplayMode;
        edgeLength?: number;
        highValueField?: string | undefined;
        lineWidth?: number;
        lowValueField?: string | undefined;
        opacity?: number | undefined;
        type?: undefined | ValueErrorBarType;
        value?: number;
    };
    set valueErrorBar(value: {
        color?: string;
        displayMode?: ValueErrorBarDisplayMode;
        edgeLength?: number;
        highValueField?: string | undefined;
        lineWidth?: number;
        lowValueField?: string | undefined;
        opacity?: number | undefined;
        type?: undefined | ValueErrorBarType;
        value?: number;
    });
    get valueField(): string;
    set valueField(value: string);
    get visible(): boolean;
    set visible(value: boolean);
    get width(): number;
    set width(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChartCommonSeriesSettingsComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoChartCommonSeriesSettingsComponent, "dxo-chart-common-series-settings", never, { "aggregation": { "alias": "aggregation"; "required": false; }; "area": { "alias": "area"; "required": false; }; "argumentField": { "alias": "argumentField"; "required": false; }; "axis": { "alias": "axis"; "required": false; }; "bar": { "alias": "bar"; "required": false; }; "barOverlapGroup": { "alias": "barOverlapGroup"; "required": false; }; "barPadding": { "alias": "barPadding"; "required": false; }; "barWidth": { "alias": "barWidth"; "required": false; }; "border": { "alias": "border"; "required": false; }; "bubble": { "alias": "bubble"; "required": false; }; "candlestick": { "alias": "candlestick"; "required": false; }; "closeValueField": { "alias": "closeValueField"; "required": false; }; "color": { "alias": "color"; "required": false; }; "cornerRadius": { "alias": "cornerRadius"; "required": false; }; "dashStyle": { "alias": "dashStyle"; "required": false; }; "fullstackedarea": { "alias": "fullstackedarea"; "required": false; }; "fullstackedbar": { "alias": "fullstackedbar"; "required": false; }; "fullstackedline": { "alias": "fullstackedline"; "required": false; }; "fullstackedspline": { "alias": "fullstackedspline"; "required": false; }; "fullstackedsplinearea": { "alias": "fullstackedsplinearea"; "required": false; }; "highValueField": { "alias": "highValueField"; "required": false; }; "hoverMode": { "alias": "hoverMode"; "required": false; }; "hoverStyle": { "alias": "hoverStyle"; "required": false; }; "ignoreEmptyPoints": { "alias": "ignoreEmptyPoints"; "required": false; }; "innerColor": { "alias": "innerColor"; "required": false; }; "label": { "alias": "label"; "required": false; }; "line": { "alias": "line"; "required": false; }; "lowValueField": { "alias": "lowValueField"; "required": false; }; "maxLabelCount": { "alias": "maxLabelCount"; "required": false; }; "minBarSize": { "alias": "minBarSize"; "required": false; }; "opacity": { "alias": "opacity"; "required": false; }; "openValueField": { "alias": "openValueField"; "required": false; }; "pane": { "alias": "pane"; "required": false; }; "point": { "alias": "point"; "required": false; }; "rangearea": { "alias": "rangearea"; "required": false; }; "rangebar": { "alias": "rangebar"; "required": false; }; "rangeValue1Field": { "alias": "rangeValue1Field"; "required": false; }; "rangeValue2Field": { "alias": "rangeValue2Field"; "required": false; }; "reduction": { "alias": "reduction"; "required": false; }; "scatter": { "alias": "scatter"; "required": false; }; "selectionMode": { "alias": "selectionMode"; "required": false; }; "selectionStyle": { "alias": "selectionStyle"; "required": false; }; "showInLegend": { "alias": "showInLegend"; "required": false; }; "sizeField": { "alias": "sizeField"; "required": false; }; "spline": { "alias": "spline"; "required": false; }; "splinearea": { "alias": "splinearea"; "required": false; }; "stack": { "alias": "stack"; "required": false; }; "stackedarea": { "alias": "stackedarea"; "required": false; }; "stackedbar": { "alias": "stackedbar"; "required": false; }; "stackedline": { "alias": "stackedline"; "required": false; }; "stackedspline": { "alias": "stackedspline"; "required": false; }; "stackedsplinearea": { "alias": "stackedsplinearea"; "required": false; }; "steparea": { "alias": "steparea"; "required": false; }; "stepline": { "alias": "stepline"; "required": false; }; "stock": { "alias": "stock"; "required": false; }; "tagField": { "alias": "tagField"; "required": false; }; "type": { "alias": "type"; "required": false; }; "valueErrorBar": { "alias": "valueErrorBar"; "required": false; }; "valueField": { "alias": "valueField"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoChartCommonSeriesSettingsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChartCommonSeriesSettingsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoChartCommonSeriesSettingsModule, never, [typeof DxoChartCommonSeriesSettingsComponent], [typeof DxoChartCommonSeriesSettingsComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoChartCommonSeriesSettingsModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoChartConnectorComponent extends NestedOption implements OnDestroy, OnInit {
    get color(): string | undefined;
    set color(value: string | undefined);
    get visible(): boolean;
    set visible(value: boolean);
    get width(): number;
    set width(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChartConnectorComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoChartConnectorComponent, "dxo-chart-connector", never, { "color": { "alias": "color"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoChartConnectorModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChartConnectorModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoChartConnectorModule, never, [typeof DxoChartConnectorComponent], [typeof DxoChartConnectorComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoChartConnectorModule>;
}

declare class DxiChartConstantLineComponent extends CollectionNestedOption {
    get color(): string;
    set color(value: string);
    get dashStyle(): DashStyle;
    set dashStyle(value: DashStyle);
    get displayBehindSeries(): boolean;
    set displayBehindSeries(value: boolean);
    get extendAxis(): boolean;
    set extendAxis(value: boolean);
    get label(): {
        font?: Font;
        horizontalAlignment?: HorizontalAlignment;
        position?: RelativePosition;
        text?: string | undefined;
        verticalAlignment?: VerticalAlignment;
        visible?: boolean;
    };
    set label(value: {
        font?: Font;
        horizontalAlignment?: HorizontalAlignment;
        position?: RelativePosition;
        text?: string | undefined;
        verticalAlignment?: VerticalAlignment;
        visible?: boolean;
    });
    get paddingLeftRight(): number;
    set paddingLeftRight(value: number);
    get paddingTopBottom(): number;
    set paddingTopBottom(value: number);
    get value(): Date | number | string | undefined;
    set value(value: Date | number | string | undefined);
    get width(): number;
    set width(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiChartConstantLineComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiChartConstantLineComponent, "dxi-chart-constant-line", never, { "color": { "alias": "color"; "required": false; }; "dashStyle": { "alias": "dashStyle"; "required": false; }; "displayBehindSeries": { "alias": "displayBehindSeries"; "required": false; }; "extendAxis": { "alias": "extendAxis"; "required": false; }; "label": { "alias": "label"; "required": false; }; "paddingLeftRight": { "alias": "paddingLeftRight"; "required": false; }; "paddingTopBottom": { "alias": "paddingTopBottom"; "required": false; }; "value": { "alias": "value"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxiChartConstantLineModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiChartConstantLineModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiChartConstantLineModule, never, [typeof DxiChartConstantLineComponent], [typeof DxiChartConstantLineComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiChartConstantLineModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoChartConstantLineLabelComponent extends NestedOption implements OnDestroy, OnInit {
    get font(): Font;
    set font(value: Font);
    get horizontalAlignment(): HorizontalAlignment;
    set horizontalAlignment(value: HorizontalAlignment);
    get position(): RelativePosition;
    set position(value: RelativePosition);
    get text(): string | undefined;
    set text(value: string | undefined);
    get verticalAlignment(): VerticalAlignment;
    set verticalAlignment(value: VerticalAlignment);
    get visible(): boolean;
    set visible(value: boolean);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChartConstantLineLabelComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoChartConstantLineLabelComponent, "dxo-chart-constant-line-label", never, { "font": { "alias": "font"; "required": false; }; "horizontalAlignment": { "alias": "horizontalAlignment"; "required": false; }; "position": { "alias": "position"; "required": false; }; "text": { "alias": "text"; "required": false; }; "verticalAlignment": { "alias": "verticalAlignment"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoChartConstantLineLabelModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChartConstantLineLabelModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoChartConstantLineLabelModule, never, [typeof DxoChartConstantLineLabelComponent], [typeof DxoChartConstantLineLabelComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoChartConstantLineLabelModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoChartConstantLineStyleComponent extends NestedOption implements OnDestroy, OnInit {
    get color(): string;
    set color(value: string);
    get dashStyle(): DashStyle;
    set dashStyle(value: DashStyle);
    get label(): {
        font?: Font;
        horizontalAlignment?: HorizontalAlignment;
        position?: RelativePosition;
        verticalAlignment?: VerticalAlignment;
        visible?: boolean;
    };
    set label(value: {
        font?: Font;
        horizontalAlignment?: HorizontalAlignment;
        position?: RelativePosition;
        verticalAlignment?: VerticalAlignment;
        visible?: boolean;
    });
    get paddingLeftRight(): number;
    set paddingLeftRight(value: number);
    get paddingTopBottom(): number;
    set paddingTopBottom(value: number);
    get width(): number;
    set width(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChartConstantLineStyleComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoChartConstantLineStyleComponent, "dxo-chart-constant-line-style", never, { "color": { "alias": "color"; "required": false; }; "dashStyle": { "alias": "dashStyle"; "required": false; }; "label": { "alias": "label"; "required": false; }; "paddingLeftRight": { "alias": "paddingLeftRight"; "required": false; }; "paddingTopBottom": { "alias": "paddingTopBottom"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoChartConstantLineStyleModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChartConstantLineStyleModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoChartConstantLineStyleModule, never, [typeof DxoChartConstantLineStyleComponent], [typeof DxoChartConstantLineStyleComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoChartConstantLineStyleModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoChartCrosshairComponent extends NestedOption implements OnDestroy, OnInit {
    get color(): string;
    set color(value: string);
    get dashStyle(): DashStyle;
    set dashStyle(value: DashStyle);
    get enabled(): boolean;
    set enabled(value: boolean);
    get horizontalLine(): boolean | {
        color?: string;
        dashStyle?: DashStyle;
        label?: {
            backgroundColor?: string;
            customizeText?: ((info: {
                point: chartPointObject;
                value: Date | number | string;
                valueText: string;
            }) => string);
            font?: Font;
            format?: Format | undefined;
            visible?: boolean;
        };
        opacity?: number | undefined;
        visible?: boolean;
        width?: number;
    };
    set horizontalLine(value: boolean | {
        color?: string;
        dashStyle?: DashStyle;
        label?: {
            backgroundColor?: string;
            customizeText?: ((info: {
                point: chartPointObject;
                value: Date | number | string;
                valueText: string;
            }) => string);
            font?: Font;
            format?: Format | undefined;
            visible?: boolean;
        };
        opacity?: number | undefined;
        visible?: boolean;
        width?: number;
    });
    get label(): {
        backgroundColor?: string;
        customizeText?: ((info: {
            point: chartPointObject;
            value: Date | number | string;
            valueText: string;
        }) => string);
        font?: Font;
        format?: Format | undefined;
        visible?: boolean;
    };
    set label(value: {
        backgroundColor?: string;
        customizeText?: ((info: {
            point: chartPointObject;
            value: Date | number | string;
            valueText: string;
        }) => string);
        font?: Font;
        format?: Format | undefined;
        visible?: boolean;
    });
    get opacity(): number | undefined;
    set opacity(value: number | undefined);
    get verticalLine(): boolean | {
        color?: string;
        dashStyle?: DashStyle;
        label?: {
            backgroundColor?: string;
            customizeText?: ((info: {
                point: chartPointObject;
                value: Date | number | string;
                valueText: string;
            }) => string);
            font?: Font;
            format?: Format | undefined;
            visible?: boolean;
        };
        opacity?: number | undefined;
        visible?: boolean;
        width?: number;
    };
    set verticalLine(value: boolean | {
        color?: string;
        dashStyle?: DashStyle;
        label?: {
            backgroundColor?: string;
            customizeText?: ((info: {
                point: chartPointObject;
                value: Date | number | string;
                valueText: string;
            }) => string);
            font?: Font;
            format?: Format | undefined;
            visible?: boolean;
        };
        opacity?: number | undefined;
        visible?: boolean;
        width?: number;
    });
    get width(): number;
    set width(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChartCrosshairComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoChartCrosshairComponent, "dxo-chart-crosshair", never, { "color": { "alias": "color"; "required": false; }; "dashStyle": { "alias": "dashStyle"; "required": false; }; "enabled": { "alias": "enabled"; "required": false; }; "horizontalLine": { "alias": "horizontalLine"; "required": false; }; "label": { "alias": "label"; "required": false; }; "opacity": { "alias": "opacity"; "required": false; }; "verticalLine": { "alias": "verticalLine"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoChartCrosshairModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChartCrosshairModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoChartCrosshairModule, never, [typeof DxoChartCrosshairComponent], [typeof DxoChartCrosshairComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoChartCrosshairModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoChartDataPrepareSettingsComponent extends NestedOption implements OnDestroy, OnInit {
    get checkTypeForAllData(): boolean;
    set checkTypeForAllData(value: boolean);
    get convertToAxisDataType(): boolean;
    set convertToAxisDataType(value: boolean);
    get sortingMethod(): boolean | ((a: any, b: any) => number);
    set sortingMethod(value: boolean | ((a: any, b: any) => number));
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChartDataPrepareSettingsComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoChartDataPrepareSettingsComponent, "dxo-chart-data-prepare-settings", never, { "checkTypeForAllData": { "alias": "checkTypeForAllData"; "required": false; }; "convertToAxisDataType": { "alias": "convertToAxisDataType"; "required": false; }; "sortingMethod": { "alias": "sortingMethod"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoChartDataPrepareSettingsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChartDataPrepareSettingsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoChartDataPrepareSettingsModule, never, [typeof DxoChartDataPrepareSettingsComponent], [typeof DxoChartDataPrepareSettingsComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoChartDataPrepareSettingsModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoChartDragBoxStyleComponent extends NestedOption implements OnDestroy, OnInit {
    get color(): string | undefined;
    set color(value: string | undefined);
    get opacity(): number | undefined;
    set opacity(value: number | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChartDragBoxStyleComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoChartDragBoxStyleComponent, "dxo-chart-drag-box-style", never, { "color": { "alias": "color"; "required": false; }; "opacity": { "alias": "opacity"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoChartDragBoxStyleModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChartDragBoxStyleModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoChartDragBoxStyleModule, never, [typeof DxoChartDragBoxStyleComponent], [typeof DxoChartDragBoxStyleComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoChartDragBoxStyleModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoChartExportComponent extends NestedOption implements OnDestroy, OnInit {
    get backgroundColor(): string;
    set backgroundColor(value: string);
    get enabled(): boolean;
    set enabled(value: boolean);
    get fileName(): string;
    set fileName(value: string);
    get formats(): Array<ExportFormat>;
    set formats(value: Array<ExportFormat>);
    get margin(): number;
    set margin(value: number);
    get printingEnabled(): boolean;
    set printingEnabled(value: boolean);
    get svgToCanvas(): ((svg: any, canvas: any) => any) | undefined;
    set svgToCanvas(value: ((svg: any, canvas: any) => any) | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChartExportComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoChartExportComponent, "dxo-chart-export", never, { "backgroundColor": { "alias": "backgroundColor"; "required": false; }; "enabled": { "alias": "enabled"; "required": false; }; "fileName": { "alias": "fileName"; "required": false; }; "formats": { "alias": "formats"; "required": false; }; "margin": { "alias": "margin"; "required": false; }; "printingEnabled": { "alias": "printingEnabled"; "required": false; }; "svgToCanvas": { "alias": "svgToCanvas"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoChartExportModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChartExportModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoChartExportModule, never, [typeof DxoChartExportComponent], [typeof DxoChartExportComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoChartExportModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoChartFontComponent extends NestedOption implements OnDestroy, OnInit {
    get color(): string;
    set color(value: string);
    get family(): string;
    set family(value: string);
    get opacity(): number;
    set opacity(value: number);
    get size(): number | string;
    set size(value: number | string);
    get weight(): number;
    set weight(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChartFontComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoChartFontComponent, "dxo-chart-font", never, { "color": { "alias": "color"; "required": false; }; "family": { "alias": "family"; "required": false; }; "opacity": { "alias": "opacity"; "required": false; }; "size": { "alias": "size"; "required": false; }; "weight": { "alias": "weight"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoChartFontModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChartFontModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoChartFontModule, never, [typeof DxoChartFontComponent], [typeof DxoChartFontComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoChartFontModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoChartFormatComponent extends NestedOption implements OnDestroy, OnInit {
    get currency(): string;
    set currency(value: string);
    get formatter(): ((value: number | Date) => string);
    set formatter(value: ((value: number | Date) => string));
    get parser(): ((value: string) => number | Date);
    set parser(value: ((value: string) => number | Date));
    get precision(): number;
    set precision(value: number);
    get type(): Format$1 | string;
    set type(value: Format$1 | string);
    get useCurrencyAccountingStyle(): boolean;
    set useCurrencyAccountingStyle(value: boolean);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChartFormatComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoChartFormatComponent, "dxo-chart-format", never, { "currency": { "alias": "currency"; "required": false; }; "formatter": { "alias": "formatter"; "required": false; }; "parser": { "alias": "parser"; "required": false; }; "precision": { "alias": "precision"; "required": false; }; "type": { "alias": "type"; "required": false; }; "useCurrencyAccountingStyle": { "alias": "useCurrencyAccountingStyle"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoChartFormatModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChartFormatModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoChartFormatModule, never, [typeof DxoChartFormatComponent], [typeof DxoChartFormatComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoChartFormatModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoChartGridComponent extends NestedOption implements OnDestroy, OnInit {
    get color(): string;
    set color(value: string);
    get opacity(): number | undefined;
    set opacity(value: number | undefined);
    get visible(): boolean;
    set visible(value: boolean);
    get width(): number;
    set width(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChartGridComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoChartGridComponent, "dxo-chart-grid", never, { "color": { "alias": "color"; "required": false; }; "opacity": { "alias": "opacity"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoChartGridModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChartGridModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoChartGridModule, never, [typeof DxoChartGridComponent], [typeof DxoChartGridComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoChartGridModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoChartHatchingComponent extends NestedOption implements OnDestroy, OnInit {
    get direction(): HatchDirection;
    set direction(value: HatchDirection);
    get opacity(): number;
    set opacity(value: number);
    get step(): number;
    set step(value: number);
    get width(): number;
    set width(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChartHatchingComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoChartHatchingComponent, "dxo-chart-hatching", never, { "direction": { "alias": "direction"; "required": false; }; "opacity": { "alias": "opacity"; "required": false; }; "step": { "alias": "step"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoChartHatchingModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChartHatchingModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoChartHatchingModule, never, [typeof DxoChartHatchingComponent], [typeof DxoChartHatchingComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoChartHatchingModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoChartHeightComponent extends NestedOption implements OnDestroy, OnInit {
    get rangeMaxPoint(): number | undefined;
    set rangeMaxPoint(value: number | undefined);
    get rangeMinPoint(): number | undefined;
    set rangeMinPoint(value: number | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChartHeightComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoChartHeightComponent, "dxo-chart-height", never, { "rangeMaxPoint": { "alias": "rangeMaxPoint"; "required": false; }; "rangeMinPoint": { "alias": "rangeMinPoint"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoChartHeightModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChartHeightModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoChartHeightModule, never, [typeof DxoChartHeightComponent], [typeof DxoChartHeightComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoChartHeightModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoChartHorizontalLineLabelComponent extends NestedOption implements OnDestroy, OnInit {
    get backgroundColor(): string;
    set backgroundColor(value: string);
    get customizeText(): ((info: {
        point: chartPointObject;
        value: Date | number | string;
        valueText: string;
    }) => string);
    set customizeText(value: ((info: {
        point: chartPointObject;
        value: Date | number | string;
        valueText: string;
    }) => string));
    get font(): Font;
    set font(value: Font);
    get format(): Format | undefined;
    set format(value: Format | undefined);
    get visible(): boolean;
    set visible(value: boolean);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChartHorizontalLineLabelComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoChartHorizontalLineLabelComponent, "dxo-chart-horizontal-line-label", never, { "backgroundColor": { "alias": "backgroundColor"; "required": false; }; "customizeText": { "alias": "customizeText"; "required": false; }; "font": { "alias": "font"; "required": false; }; "format": { "alias": "format"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoChartHorizontalLineLabelModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChartHorizontalLineLabelModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoChartHorizontalLineLabelModule, never, [typeof DxoChartHorizontalLineLabelComponent], [typeof DxoChartHorizontalLineLabelComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoChartHorizontalLineLabelModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoChartHorizontalLineComponent extends NestedOption implements OnDestroy, OnInit {
    get color(): string;
    set color(value: string);
    get dashStyle(): DashStyle;
    set dashStyle(value: DashStyle);
    get label(): {
        backgroundColor?: string;
        customizeText?: ((info: {
            point: chartPointObject;
            value: Date | number | string;
            valueText: string;
        }) => string);
        font?: Font;
        format?: Format | undefined;
        visible?: boolean;
    };
    set label(value: {
        backgroundColor?: string;
        customizeText?: ((info: {
            point: chartPointObject;
            value: Date | number | string;
            valueText: string;
        }) => string);
        font?: Font;
        format?: Format | undefined;
        visible?: boolean;
    });
    get opacity(): number | undefined;
    set opacity(value: number | undefined);
    get visible(): boolean;
    set visible(value: boolean);
    get width(): number;
    set width(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChartHorizontalLineComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoChartHorizontalLineComponent, "dxo-chart-horizontal-line", never, { "color": { "alias": "color"; "required": false; }; "dashStyle": { "alias": "dashStyle"; "required": false; }; "label": { "alias": "label"; "required": false; }; "opacity": { "alias": "opacity"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoChartHorizontalLineModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChartHorizontalLineModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoChartHorizontalLineModule, never, [typeof DxoChartHorizontalLineComponent], [typeof DxoChartHorizontalLineComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoChartHorizontalLineModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoChartHoverStyleComponent extends NestedOption implements OnDestroy, OnInit {
    get border(): {
        color?: string | undefined;
        dashStyle?: DashStyle | undefined;
        visible?: boolean;
        width?: number;
    };
    set border(value: {
        color?: string | undefined;
        dashStyle?: DashStyle | undefined;
        visible?: boolean;
        width?: number;
    });
    get color(): ChartsColor | string | undefined;
    set color(value: ChartsColor | string | undefined);
    get dashStyle(): DashStyle;
    set dashStyle(value: DashStyle);
    get hatching(): {
        direction?: HatchDirection;
        opacity?: number;
        step?: number;
        width?: number;
    };
    set hatching(value: {
        direction?: HatchDirection;
        opacity?: number;
        step?: number;
        width?: number;
    });
    get highlight(): boolean;
    set highlight(value: boolean);
    get width(): number;
    set width(value: number);
    get size(): number | undefined;
    set size(value: number | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChartHoverStyleComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoChartHoverStyleComponent, "dxo-chart-hover-style", never, { "border": { "alias": "border"; "required": false; }; "color": { "alias": "color"; "required": false; }; "dashStyle": { "alias": "dashStyle"; "required": false; }; "hatching": { "alias": "hatching"; "required": false; }; "highlight": { "alias": "highlight"; "required": false; }; "width": { "alias": "width"; "required": false; }; "size": { "alias": "size"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoChartHoverStyleModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChartHoverStyleModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoChartHoverStyleModule, never, [typeof DxoChartHoverStyleComponent], [typeof DxoChartHoverStyleComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoChartHoverStyleModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoChartImageComponent extends NestedOption implements OnDestroy, OnInit {
    get height(): number | {
        rangeMaxPoint?: number | undefined;
        rangeMinPoint?: number | undefined;
    };
    set height(value: number | {
        rangeMaxPoint?: number | undefined;
        rangeMinPoint?: number | undefined;
    });
    get url(): string | undefined | {
        rangeMaxPoint?: string | undefined;
        rangeMinPoint?: string | undefined;
    };
    set url(value: string | undefined | {
        rangeMaxPoint?: string | undefined;
        rangeMinPoint?: string | undefined;
    });
    get width(): number | {
        rangeMaxPoint?: number | undefined;
        rangeMinPoint?: number | undefined;
    };
    set width(value: number | {
        rangeMaxPoint?: number | undefined;
        rangeMinPoint?: number | undefined;
    });
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChartImageComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoChartImageComponent, "dxo-chart-image", never, { "height": { "alias": "height"; "required": false; }; "url": { "alias": "url"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoChartImageModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChartImageModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoChartImageModule, never, [typeof DxoChartImageComponent], [typeof DxoChartImageComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoChartImageModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoChartLabelComponent extends NestedOption implements AfterViewInit, OnDestroy, OnInit, IDxTemplateHost {
    private renderer;
    private document;
    private element;
    get font(): Font;
    set font(value: Font);
    get horizontalAlignment(): HorizontalAlignment;
    set horizontalAlignment(value: HorizontalAlignment);
    get position(): RelativePosition | Position;
    set position(value: RelativePosition | Position);
    get verticalAlignment(): VerticalAlignment;
    set verticalAlignment(value: VerticalAlignment);
    get visible(): boolean;
    set visible(value: boolean);
    get text(): string | undefined;
    set text(value: string | undefined);
    get alignment(): HorizontalAlignment | undefined;
    set alignment(value: HorizontalAlignment | undefined);
    get customizeHint(): ((argument: {
        value: Date | number | string;
        valueText: string;
    }) => string);
    set customizeHint(value: ((argument: {
        value: Date | number | string;
        valueText: string;
    }) => string));
    get customizeText(): ((argument: {
        value: Date | number | string;
        valueText: string;
    }) => string);
    set customizeText(value: ((argument: {
        value: Date | number | string;
        valueText: string;
    }) => string));
    get displayMode(): ChartLabelDisplayMode;
    set displayMode(value: ChartLabelDisplayMode);
    get format(): Format | undefined;
    set format(value: Format | undefined);
    get indentFromAxis(): number;
    set indentFromAxis(value: number);
    get overlappingBehavior(): ChartsAxisLabelOverlap;
    set overlappingBehavior(value: ChartsAxisLabelOverlap);
    get rotationAngle(): number;
    set rotationAngle(value: number);
    get staggeringSpacing(): number;
    set staggeringSpacing(value: number);
    get template(): any;
    set template(value: any);
    get textOverflow(): TextOverflow;
    set textOverflow(value: TextOverflow);
    get wordWrap(): WordWrap;
    set wordWrap(value: WordWrap);
    get argumentFormat(): Format | undefined;
    set argumentFormat(value: Format | undefined);
    get backgroundColor(): string | undefined;
    set backgroundColor(value: string | undefined);
    get border(): {
        color?: string | undefined;
        dashStyle?: DashStyle | undefined;
        visible?: boolean;
        width?: number;
    };
    set border(value: {
        color?: string | undefined;
        dashStyle?: DashStyle | undefined;
        visible?: boolean;
        width?: number;
    });
    get connector(): {
        color?: string | undefined;
        visible?: boolean;
        width?: number;
    };
    set connector(value: {
        color?: string | undefined;
        visible?: boolean;
        width?: number;
    });
    get displayFormat(): string | undefined;
    set displayFormat(value: string | undefined);
    get horizontalOffset(): number;
    set horizontalOffset(value: number);
    get showForZeroValues(): boolean;
    set showForZeroValues(value: boolean);
    get verticalOffset(): number;
    set verticalOffset(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost, renderer: Renderer2, document: any, templateHost: DxTemplateHost, element: ElementRef);
    setTemplate(template: DxTemplateDirective): void;
    ngAfterViewInit(): void;
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChartLabelComponent, [{ host: true; skipSelf: true; }, { host: true; }, null, null, { host: true; }, null]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoChartLabelComponent, "dxo-chart-label", never, { "font": { "alias": "font"; "required": false; }; "horizontalAlignment": { "alias": "horizontalAlignment"; "required": false; }; "position": { "alias": "position"; "required": false; }; "verticalAlignment": { "alias": "verticalAlignment"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "text": { "alias": "text"; "required": false; }; "alignment": { "alias": "alignment"; "required": false; }; "customizeHint": { "alias": "customizeHint"; "required": false; }; "customizeText": { "alias": "customizeText"; "required": false; }; "displayMode": { "alias": "displayMode"; "required": false; }; "format": { "alias": "format"; "required": false; }; "indentFromAxis": { "alias": "indentFromAxis"; "required": false; }; "overlappingBehavior": { "alias": "overlappingBehavior"; "required": false; }; "rotationAngle": { "alias": "rotationAngle"; "required": false; }; "staggeringSpacing": { "alias": "staggeringSpacing"; "required": false; }; "template": { "alias": "template"; "required": false; }; "textOverflow": { "alias": "textOverflow"; "required": false; }; "wordWrap": { "alias": "wordWrap"; "required": false; }; "argumentFormat": { "alias": "argumentFormat"; "required": false; }; "backgroundColor": { "alias": "backgroundColor"; "required": false; }; "border": { "alias": "border"; "required": false; }; "connector": { "alias": "connector"; "required": false; }; "displayFormat": { "alias": "displayFormat"; "required": false; }; "horizontalOffset": { "alias": "horizontalOffset"; "required": false; }; "showForZeroValues": { "alias": "showForZeroValues"; "required": false; }; "verticalOffset": { "alias": "verticalOffset"; "required": false; }; }, {}, never, ["*"], true, never>;
}
declare class DxoChartLabelModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChartLabelModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoChartLabelModule, never, [typeof DxoChartLabelComponent], [typeof DxoChartLabelComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoChartLabelModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoChartLegendTitleSubtitleComponent extends NestedOption implements OnDestroy, OnInit {
    get font(): Font;
    set font(value: Font);
    get offset(): number;
    set offset(value: number);
    get text(): string | undefined;
    set text(value: string | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChartLegendTitleSubtitleComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoChartLegendTitleSubtitleComponent, "dxo-chart-legend-title-subtitle", never, { "font": { "alias": "font"; "required": false; }; "offset": { "alias": "offset"; "required": false; }; "text": { "alias": "text"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoChartLegendTitleSubtitleModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChartLegendTitleSubtitleModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoChartLegendTitleSubtitleModule, never, [typeof DxoChartLegendTitleSubtitleComponent], [typeof DxoChartLegendTitleSubtitleComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoChartLegendTitleSubtitleModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoChartLegendTitleComponent extends NestedOption implements OnDestroy, OnInit {
    get font(): Font;
    set font(value: Font);
    get horizontalAlignment(): HorizontalAlignment | undefined;
    set horizontalAlignment(value: HorizontalAlignment | undefined);
    get margin(): {
        bottom?: number;
        left?: number;
        right?: number;
        top?: number;
    };
    set margin(value: {
        bottom?: number;
        left?: number;
        right?: number;
        top?: number;
    });
    get placeholderSize(): number | undefined;
    set placeholderSize(value: number | undefined);
    get subtitle(): string | {
        font?: Font;
        offset?: number;
        text?: string | undefined;
    };
    set subtitle(value: string | {
        font?: Font;
        offset?: number;
        text?: string | undefined;
    });
    get text(): string | undefined;
    set text(value: string | undefined);
    get verticalAlignment(): VerticalEdge;
    set verticalAlignment(value: VerticalEdge);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChartLegendTitleComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoChartLegendTitleComponent, "dxo-chart-legend-title", never, { "font": { "alias": "font"; "required": false; }; "horizontalAlignment": { "alias": "horizontalAlignment"; "required": false; }; "margin": { "alias": "margin"; "required": false; }; "placeholderSize": { "alias": "placeholderSize"; "required": false; }; "subtitle": { "alias": "subtitle"; "required": false; }; "text": { "alias": "text"; "required": false; }; "verticalAlignment": { "alias": "verticalAlignment"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoChartLegendTitleModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChartLegendTitleModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoChartLegendTitleModule, never, [typeof DxoChartLegendTitleComponent], [typeof DxoChartLegendTitleComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoChartLegendTitleModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoChartLegendComponent extends NestedOption implements OnDestroy, OnInit {
    get backgroundColor(): string | undefined;
    set backgroundColor(value: string | undefined);
    get border(): {
        color?: string;
        cornerRadius?: number;
        dashStyle?: DashStyle;
        opacity?: number | undefined;
        visible?: boolean;
        width?: number;
    };
    set border(value: {
        color?: string;
        cornerRadius?: number;
        dashStyle?: DashStyle;
        opacity?: number | undefined;
        visible?: boolean;
        width?: number;
    });
    get columnCount(): number;
    set columnCount(value: number);
    get columnItemSpacing(): number;
    set columnItemSpacing(value: number);
    get customizeHint(): ((seriesInfo: {
        seriesColor: string;
        seriesIndex: number;
        seriesName: any;
    }) => string);
    set customizeHint(value: ((seriesInfo: {
        seriesColor: string;
        seriesIndex: number;
        seriesName: any;
    }) => string));
    get customizeItems(): ((items: Array<LegendItem>) => Array<LegendItem>);
    set customizeItems(value: ((items: Array<LegendItem>) => Array<LegendItem>));
    get customizeText(): ((seriesInfo: {
        seriesColor: string;
        seriesIndex: number;
        seriesName: any;
    }) => string);
    set customizeText(value: ((seriesInfo: {
        seriesColor: string;
        seriesIndex: number;
        seriesName: any;
    }) => string));
    get font(): Font;
    set font(value: Font);
    get horizontalAlignment(): HorizontalAlignment;
    set horizontalAlignment(value: HorizontalAlignment);
    get hoverMode(): LegendHoverMode;
    set hoverMode(value: LegendHoverMode);
    get itemsAlignment(): HorizontalAlignment | undefined;
    set itemsAlignment(value: HorizontalAlignment | undefined);
    get itemTextPosition(): Position | undefined;
    set itemTextPosition(value: Position | undefined);
    get margin(): number | {
        bottom?: number;
        left?: number;
        right?: number;
        top?: number;
    };
    set margin(value: number | {
        bottom?: number;
        left?: number;
        right?: number;
        top?: number;
    });
    get markerSize(): number;
    set markerSize(value: number);
    get markerTemplate(): any;
    set markerTemplate(value: any);
    get orientation(): Orientation | undefined;
    set orientation(value: Orientation | undefined);
    get paddingLeftRight(): number;
    set paddingLeftRight(value: number);
    get paddingTopBottom(): number;
    set paddingTopBottom(value: number);
    get position(): RelativePosition;
    set position(value: RelativePosition);
    get rowCount(): number;
    set rowCount(value: number);
    get rowItemSpacing(): number;
    set rowItemSpacing(value: number);
    get title(): string | {
        font?: Font;
        horizontalAlignment?: HorizontalAlignment | undefined;
        margin?: {
            bottom?: number;
            left?: number;
            right?: number;
            top?: number;
        };
        placeholderSize?: number | undefined;
        subtitle?: string | {
            font?: Font;
            offset?: number;
            text?: string | undefined;
        };
        text?: string | undefined;
        verticalAlignment?: VerticalEdge;
    };
    set title(value: string | {
        font?: Font;
        horizontalAlignment?: HorizontalAlignment | undefined;
        margin?: {
            bottom?: number;
            left?: number;
            right?: number;
            top?: number;
        };
        placeholderSize?: number | undefined;
        subtitle?: string | {
            font?: Font;
            offset?: number;
            text?: string | undefined;
        };
        text?: string | undefined;
        verticalAlignment?: VerticalEdge;
    });
    get verticalAlignment(): VerticalEdge;
    set verticalAlignment(value: VerticalEdge);
    get visible(): boolean;
    set visible(value: boolean);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChartLegendComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoChartLegendComponent, "dxo-chart-legend", never, { "backgroundColor": { "alias": "backgroundColor"; "required": false; }; "border": { "alias": "border"; "required": false; }; "columnCount": { "alias": "columnCount"; "required": false; }; "columnItemSpacing": { "alias": "columnItemSpacing"; "required": false; }; "customizeHint": { "alias": "customizeHint"; "required": false; }; "customizeItems": { "alias": "customizeItems"; "required": false; }; "customizeText": { "alias": "customizeText"; "required": false; }; "font": { "alias": "font"; "required": false; }; "horizontalAlignment": { "alias": "horizontalAlignment"; "required": false; }; "hoverMode": { "alias": "hoverMode"; "required": false; }; "itemsAlignment": { "alias": "itemsAlignment"; "required": false; }; "itemTextPosition": { "alias": "itemTextPosition"; "required": false; }; "margin": { "alias": "margin"; "required": false; }; "markerSize": { "alias": "markerSize"; "required": false; }; "markerTemplate": { "alias": "markerTemplate"; "required": false; }; "orientation": { "alias": "orientation"; "required": false; }; "paddingLeftRight": { "alias": "paddingLeftRight"; "required": false; }; "paddingTopBottom": { "alias": "paddingTopBottom"; "required": false; }; "position": { "alias": "position"; "required": false; }; "rowCount": { "alias": "rowCount"; "required": false; }; "rowItemSpacing": { "alias": "rowItemSpacing"; "required": false; }; "title": { "alias": "title"; "required": false; }; "verticalAlignment": { "alias": "verticalAlignment"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoChartLegendModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChartLegendModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoChartLegendModule, never, [typeof DxoChartLegendComponent], [typeof DxoChartLegendComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoChartLegendModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoChartLengthComponent extends NestedOption implements OnDestroy, OnInit {
    get days(): number;
    set days(value: number);
    get hours(): number;
    set hours(value: number);
    get milliseconds(): number;
    set milliseconds(value: number);
    get minutes(): number;
    set minutes(value: number);
    get months(): number;
    set months(value: number);
    get quarters(): number;
    set quarters(value: number);
    get seconds(): number;
    set seconds(value: number);
    get weeks(): number;
    set weeks(value: number);
    get years(): number;
    set years(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChartLengthComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoChartLengthComponent, "dxo-chart-length", never, { "days": { "alias": "days"; "required": false; }; "hours": { "alias": "hours"; "required": false; }; "milliseconds": { "alias": "milliseconds"; "required": false; }; "minutes": { "alias": "minutes"; "required": false; }; "months": { "alias": "months"; "required": false; }; "quarters": { "alias": "quarters"; "required": false; }; "seconds": { "alias": "seconds"; "required": false; }; "weeks": { "alias": "weeks"; "required": false; }; "years": { "alias": "years"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoChartLengthModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChartLengthModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoChartLengthModule, never, [typeof DxoChartLengthComponent], [typeof DxoChartLengthComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoChartLengthModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoChartLoadingIndicatorComponent extends NestedOption implements OnDestroy, OnInit {
    get backgroundColor(): string;
    set backgroundColor(value: string);
    get enabled(): boolean;
    set enabled(value: boolean);
    get font(): Font;
    set font(value: Font);
    get show(): boolean;
    set show(value: boolean);
    get text(): string;
    set text(value: string);
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    showChange: EventEmitter<boolean>;
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChartLoadingIndicatorComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoChartLoadingIndicatorComponent, "dxo-chart-loading-indicator", never, { "backgroundColor": { "alias": "backgroundColor"; "required": false; }; "enabled": { "alias": "enabled"; "required": false; }; "font": { "alias": "font"; "required": false; }; "show": { "alias": "show"; "required": false; }; "text": { "alias": "text"; "required": false; }; }, { "showChange": "showChange"; }, never, never, true, never>;
}
declare class DxoChartLoadingIndicatorModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChartLoadingIndicatorModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoChartLoadingIndicatorModule, never, [typeof DxoChartLoadingIndicatorComponent], [typeof DxoChartLoadingIndicatorComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoChartLoadingIndicatorModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoChartMarginComponent extends NestedOption implements OnDestroy, OnInit {
    get bottom(): number;
    set bottom(value: number);
    get left(): number;
    set left(value: number);
    get right(): number;
    set right(value: number);
    get top(): number;
    set top(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChartMarginComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoChartMarginComponent, "dxo-chart-margin", never, { "bottom": { "alias": "bottom"; "required": false; }; "left": { "alias": "left"; "required": false; }; "right": { "alias": "right"; "required": false; }; "top": { "alias": "top"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoChartMarginModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChartMarginModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoChartMarginModule, never, [typeof DxoChartMarginComponent], [typeof DxoChartMarginComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoChartMarginModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoChartMinVisualRangeLengthComponent extends NestedOption implements OnDestroy, OnInit {
    get days(): number;
    set days(value: number);
    get hours(): number;
    set hours(value: number);
    get milliseconds(): number;
    set milliseconds(value: number);
    get minutes(): number;
    set minutes(value: number);
    get months(): number;
    set months(value: number);
    get quarters(): number;
    set quarters(value: number);
    get seconds(): number;
    set seconds(value: number);
    get weeks(): number;
    set weeks(value: number);
    get years(): number;
    set years(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChartMinVisualRangeLengthComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoChartMinVisualRangeLengthComponent, "dxo-chart-min-visual-range-length", never, { "days": { "alias": "days"; "required": false; }; "hours": { "alias": "hours"; "required": false; }; "milliseconds": { "alias": "milliseconds"; "required": false; }; "minutes": { "alias": "minutes"; "required": false; }; "months": { "alias": "months"; "required": false; }; "quarters": { "alias": "quarters"; "required": false; }; "seconds": { "alias": "seconds"; "required": false; }; "weeks": { "alias": "weeks"; "required": false; }; "years": { "alias": "years"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoChartMinVisualRangeLengthModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChartMinVisualRangeLengthModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoChartMinVisualRangeLengthModule, never, [typeof DxoChartMinVisualRangeLengthComponent], [typeof DxoChartMinVisualRangeLengthComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoChartMinVisualRangeLengthModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoChartMinorGridComponent extends NestedOption implements OnDestroy, OnInit {
    get color(): string;
    set color(value: string);
    get opacity(): number | undefined;
    set opacity(value: number | undefined);
    get visible(): boolean;
    set visible(value: boolean);
    get width(): number;
    set width(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChartMinorGridComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoChartMinorGridComponent, "dxo-chart-minor-grid", never, { "color": { "alias": "color"; "required": false; }; "opacity": { "alias": "opacity"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoChartMinorGridModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChartMinorGridModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoChartMinorGridModule, never, [typeof DxoChartMinorGridComponent], [typeof DxoChartMinorGridComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoChartMinorGridModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoChartMinorTickIntervalComponent extends NestedOption implements OnDestroy, OnInit {
    get days(): number;
    set days(value: number);
    get hours(): number;
    set hours(value: number);
    get milliseconds(): number;
    set milliseconds(value: number);
    get minutes(): number;
    set minutes(value: number);
    get months(): number;
    set months(value: number);
    get quarters(): number;
    set quarters(value: number);
    get seconds(): number;
    set seconds(value: number);
    get weeks(): number;
    set weeks(value: number);
    get years(): number;
    set years(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChartMinorTickIntervalComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoChartMinorTickIntervalComponent, "dxo-chart-minor-tick-interval", never, { "days": { "alias": "days"; "required": false; }; "hours": { "alias": "hours"; "required": false; }; "milliseconds": { "alias": "milliseconds"; "required": false; }; "minutes": { "alias": "minutes"; "required": false; }; "months": { "alias": "months"; "required": false; }; "quarters": { "alias": "quarters"; "required": false; }; "seconds": { "alias": "seconds"; "required": false; }; "weeks": { "alias": "weeks"; "required": false; }; "years": { "alias": "years"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoChartMinorTickIntervalModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChartMinorTickIntervalModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoChartMinorTickIntervalModule, never, [typeof DxoChartMinorTickIntervalComponent], [typeof DxoChartMinorTickIntervalComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoChartMinorTickIntervalModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoChartMinorTickComponent extends NestedOption implements OnDestroy, OnInit {
    get color(): string;
    set color(value: string);
    get length(): number;
    set length(value: number);
    get opacity(): number;
    set opacity(value: number);
    get shift(): number;
    set shift(value: number);
    get visible(): boolean;
    set visible(value: boolean);
    get width(): number;
    set width(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChartMinorTickComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoChartMinorTickComponent, "dxo-chart-minor-tick", never, { "color": { "alias": "color"; "required": false; }; "length": { "alias": "length"; "required": false; }; "opacity": { "alias": "opacity"; "required": false; }; "shift": { "alias": "shift"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoChartMinorTickModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChartMinorTickModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoChartMinorTickModule, never, [typeof DxoChartMinorTickComponent], [typeof DxoChartMinorTickComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoChartMinorTickModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoChartPaneBorderComponent extends NestedOption implements OnDestroy, OnInit {
    get bottom(): boolean;
    set bottom(value: boolean);
    get color(): string;
    set color(value: string);
    get dashStyle(): DashStyle;
    set dashStyle(value: DashStyle);
    get left(): boolean;
    set left(value: boolean);
    get opacity(): number | undefined;
    set opacity(value: number | undefined);
    get right(): boolean;
    set right(value: boolean);
    get top(): boolean;
    set top(value: boolean);
    get visible(): boolean;
    set visible(value: boolean);
    get width(): number;
    set width(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChartPaneBorderComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoChartPaneBorderComponent, "dxo-chart-pane-border", never, { "bottom": { "alias": "bottom"; "required": false; }; "color": { "alias": "color"; "required": false; }; "dashStyle": { "alias": "dashStyle"; "required": false; }; "left": { "alias": "left"; "required": false; }; "opacity": { "alias": "opacity"; "required": false; }; "right": { "alias": "right"; "required": false; }; "top": { "alias": "top"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoChartPaneBorderModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChartPaneBorderModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoChartPaneBorderModule, never, [typeof DxoChartPaneBorderComponent], [typeof DxoChartPaneBorderComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoChartPaneBorderModule>;
}

declare class DxiChartPaneComponent extends CollectionNestedOption {
    get backgroundColor(): ChartsColor | string;
    set backgroundColor(value: ChartsColor | string);
    get border(): {
        bottom?: boolean;
        color?: string;
        dashStyle?: DashStyle;
        left?: boolean;
        opacity?: number | undefined;
        right?: boolean;
        top?: boolean;
        visible?: boolean;
        width?: number;
    };
    set border(value: {
        bottom?: boolean;
        color?: string;
        dashStyle?: DashStyle;
        left?: boolean;
        opacity?: number | undefined;
        right?: boolean;
        top?: boolean;
        visible?: boolean;
        width?: number;
    });
    get height(): number | string | undefined;
    set height(value: number | string | undefined);
    get name(): string | undefined;
    set name(value: string | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiChartPaneComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiChartPaneComponent, "dxi-chart-pane", never, { "backgroundColor": { "alias": "backgroundColor"; "required": false; }; "border": { "alias": "border"; "required": false; }; "height": { "alias": "height"; "required": false; }; "name": { "alias": "name"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxiChartPaneModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiChartPaneModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiChartPaneModule, never, [typeof DxiChartPaneComponent], [typeof DxiChartPaneComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiChartPaneModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoChartPointBorderComponent extends NestedOption implements OnDestroy, OnInit {
    get color(): string | undefined;
    set color(value: string | undefined);
    get visible(): boolean;
    set visible(value: boolean);
    get width(): number;
    set width(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChartPointBorderComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoChartPointBorderComponent, "dxo-chart-point-border", never, { "color": { "alias": "color"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoChartPointBorderModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChartPointBorderModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoChartPointBorderModule, never, [typeof DxoChartPointBorderComponent], [typeof DxoChartPointBorderComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoChartPointBorderModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoChartPointHoverStyleComponent extends NestedOption implements OnDestroy, OnInit {
    get border(): {
        color?: string | undefined;
        visible?: boolean;
        width?: number;
    };
    set border(value: {
        color?: string | undefined;
        visible?: boolean;
        width?: number;
    });
    get color(): ChartsColor | string | undefined;
    set color(value: ChartsColor | string | undefined);
    get size(): number | undefined;
    set size(value: number | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChartPointHoverStyleComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoChartPointHoverStyleComponent, "dxo-chart-point-hover-style", never, { "border": { "alias": "border"; "required": false; }; "color": { "alias": "color"; "required": false; }; "size": { "alias": "size"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoChartPointHoverStyleModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChartPointHoverStyleModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoChartPointHoverStyleModule, never, [typeof DxoChartPointHoverStyleComponent], [typeof DxoChartPointHoverStyleComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoChartPointHoverStyleModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoChartPointImageComponent extends NestedOption implements OnDestroy, OnInit {
    get height(): number | {
        rangeMaxPoint?: number | undefined;
        rangeMinPoint?: number | undefined;
    };
    set height(value: number | {
        rangeMaxPoint?: number | undefined;
        rangeMinPoint?: number | undefined;
    });
    get url(): string | undefined | {
        rangeMaxPoint?: string | undefined;
        rangeMinPoint?: string | undefined;
    };
    set url(value: string | undefined | {
        rangeMaxPoint?: string | undefined;
        rangeMinPoint?: string | undefined;
    });
    get width(): number | {
        rangeMaxPoint?: number | undefined;
        rangeMinPoint?: number | undefined;
    };
    set width(value: number | {
        rangeMaxPoint?: number | undefined;
        rangeMinPoint?: number | undefined;
    });
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChartPointImageComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoChartPointImageComponent, "dxo-chart-point-image", never, { "height": { "alias": "height"; "required": false; }; "url": { "alias": "url"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoChartPointImageModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChartPointImageModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoChartPointImageModule, never, [typeof DxoChartPointImageComponent], [typeof DxoChartPointImageComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoChartPointImageModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoChartPointSelectionStyleComponent extends NestedOption implements OnDestroy, OnInit {
    get border(): {
        color?: string | undefined;
        visible?: boolean;
        width?: number;
    };
    set border(value: {
        color?: string | undefined;
        visible?: boolean;
        width?: number;
    });
    get color(): ChartsColor | string | undefined;
    set color(value: ChartsColor | string | undefined);
    get size(): number | undefined;
    set size(value: number | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChartPointSelectionStyleComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoChartPointSelectionStyleComponent, "dxo-chart-point-selection-style", never, { "border": { "alias": "border"; "required": false; }; "color": { "alias": "color"; "required": false; }; "size": { "alias": "size"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoChartPointSelectionStyleModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChartPointSelectionStyleModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoChartPointSelectionStyleModule, never, [typeof DxoChartPointSelectionStyleComponent], [typeof DxoChartPointSelectionStyleComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoChartPointSelectionStyleModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoChartPointComponent extends NestedOption implements OnDestroy, OnInit {
    get border(): {
        color?: string | undefined;
        visible?: boolean;
        width?: number;
    };
    set border(value: {
        color?: string | undefined;
        visible?: boolean;
        width?: number;
    });
    get color(): ChartsColor | string | undefined;
    set color(value: ChartsColor | string | undefined);
    get hoverMode(): PointInteractionMode;
    set hoverMode(value: PointInteractionMode);
    get hoverStyle(): {
        border?: {
            color?: string | undefined;
            visible?: boolean;
            width?: number;
        };
        color?: ChartsColor | string | undefined;
        size?: number | undefined;
    };
    set hoverStyle(value: {
        border?: {
            color?: string | undefined;
            visible?: boolean;
            width?: number;
        };
        color?: ChartsColor | string | undefined;
        size?: number | undefined;
    });
    get image(): string | undefined | {
        height?: number | {
            rangeMaxPoint?: number | undefined;
            rangeMinPoint?: number | undefined;
        };
        url?: string | undefined | {
            rangeMaxPoint?: string | undefined;
            rangeMinPoint?: string | undefined;
        };
        width?: number | {
            rangeMaxPoint?: number | undefined;
            rangeMinPoint?: number | undefined;
        };
    };
    set image(value: string | undefined | {
        height?: number | {
            rangeMaxPoint?: number | undefined;
            rangeMinPoint?: number | undefined;
        };
        url?: string | undefined | {
            rangeMaxPoint?: string | undefined;
            rangeMinPoint?: string | undefined;
        };
        width?: number | {
            rangeMaxPoint?: number | undefined;
            rangeMinPoint?: number | undefined;
        };
    });
    get selectionMode(): PointInteractionMode;
    set selectionMode(value: PointInteractionMode);
    get selectionStyle(): {
        border?: {
            color?: string | undefined;
            visible?: boolean;
            width?: number;
        };
        color?: ChartsColor | string | undefined;
        size?: number | undefined;
    };
    set selectionStyle(value: {
        border?: {
            color?: string | undefined;
            visible?: boolean;
            width?: number;
        };
        color?: ChartsColor | string | undefined;
        size?: number | undefined;
    });
    get size(): number;
    set size(value: number);
    get symbol(): PointSymbol;
    set symbol(value: PointSymbol);
    get visible(): boolean;
    set visible(value: boolean);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChartPointComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoChartPointComponent, "dxo-chart-point", never, { "border": { "alias": "border"; "required": false; }; "color": { "alias": "color"; "required": false; }; "hoverMode": { "alias": "hoverMode"; "required": false; }; "hoverStyle": { "alias": "hoverStyle"; "required": false; }; "image": { "alias": "image"; "required": false; }; "selectionMode": { "alias": "selectionMode"; "required": false; }; "selectionStyle": { "alias": "selectionStyle"; "required": false; }; "size": { "alias": "size"; "required": false; }; "symbol": { "alias": "symbol"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoChartPointModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChartPointModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoChartPointModule, never, [typeof DxoChartPointComponent], [typeof DxoChartPointComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoChartPointModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoChartReductionComponent extends NestedOption implements OnDestroy, OnInit {
    get color(): string;
    set color(value: string);
    get level(): FinancialChartReductionLevel;
    set level(value: FinancialChartReductionLevel);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChartReductionComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoChartReductionComponent, "dxo-chart-reduction", never, { "color": { "alias": "color"; "required": false; }; "level": { "alias": "level"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoChartReductionModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChartReductionModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoChartReductionModule, never, [typeof DxoChartReductionComponent], [typeof DxoChartReductionComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoChartReductionModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoChartScrollBarComponent extends NestedOption implements OnDestroy, OnInit {
    get color(): string;
    set color(value: string);
    get offset(): number;
    set offset(value: number);
    get opacity(): number | undefined;
    set opacity(value: number | undefined);
    get position(): Position;
    set position(value: Position);
    get visible(): boolean;
    set visible(value: boolean);
    get width(): number;
    set width(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChartScrollBarComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoChartScrollBarComponent, "dxo-chart-scroll-bar", never, { "color": { "alias": "color"; "required": false; }; "offset": { "alias": "offset"; "required": false; }; "opacity": { "alias": "opacity"; "required": false; }; "position": { "alias": "position"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoChartScrollBarModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChartScrollBarModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoChartScrollBarModule, never, [typeof DxoChartScrollBarComponent], [typeof DxoChartScrollBarComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoChartScrollBarModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoChartSelectionStyleComponent extends NestedOption implements OnDestroy, OnInit {
    get border(): {
        color?: string | undefined;
        visible?: boolean;
        width?: number;
        dashStyle?: DashStyle | undefined;
    };
    set border(value: {
        color?: string | undefined;
        visible?: boolean;
        width?: number;
        dashStyle?: DashStyle | undefined;
    });
    get color(): ChartsColor | string | undefined;
    set color(value: ChartsColor | string | undefined);
    get size(): number | undefined;
    set size(value: number | undefined);
    get dashStyle(): DashStyle;
    set dashStyle(value: DashStyle);
    get hatching(): {
        direction?: HatchDirection;
        opacity?: number;
        step?: number;
        width?: number;
    };
    set hatching(value: {
        direction?: HatchDirection;
        opacity?: number;
        step?: number;
        width?: number;
    });
    get highlight(): boolean;
    set highlight(value: boolean);
    get width(): number;
    set width(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChartSelectionStyleComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoChartSelectionStyleComponent, "dxo-chart-selection-style", never, { "border": { "alias": "border"; "required": false; }; "color": { "alias": "color"; "required": false; }; "size": { "alias": "size"; "required": false; }; "dashStyle": { "alias": "dashStyle"; "required": false; }; "hatching": { "alias": "hatching"; "required": false; }; "highlight": { "alias": "highlight"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoChartSelectionStyleModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChartSelectionStyleModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoChartSelectionStyleModule, never, [typeof DxoChartSelectionStyleComponent], [typeof DxoChartSelectionStyleComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoChartSelectionStyleModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoChartSeriesBorderComponent extends NestedOption implements OnDestroy, OnInit {
    get color(): string | undefined;
    set color(value: string | undefined);
    get dashStyle(): DashStyle | undefined;
    set dashStyle(value: DashStyle | undefined);
    get visible(): boolean;
    set visible(value: boolean);
    get width(): number;
    set width(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChartSeriesBorderComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoChartSeriesBorderComponent, "dxo-chart-series-border", never, { "color": { "alias": "color"; "required": false; }; "dashStyle": { "alias": "dashStyle"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoChartSeriesBorderModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChartSeriesBorderModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoChartSeriesBorderModule, never, [typeof DxoChartSeriesBorderComponent], [typeof DxoChartSeriesBorderComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoChartSeriesBorderModule>;
}

declare class DxiChartSeriesComponent extends CollectionNestedOption {
    get aggregation(): {
        calculate?: ((aggregationInfo: chartPointAggregationInfoObject, series: chartSeriesObject) => Record<string, any> | Array<Record<string, any>>) | undefined;
        enabled?: boolean;
        method?: ChartSeriesAggregationMethod;
    };
    set aggregation(value: {
        calculate?: ((aggregationInfo: chartPointAggregationInfoObject, series: chartSeriesObject) => Record<string, any> | Array<Record<string, any>>) | undefined;
        enabled?: boolean;
        method?: ChartSeriesAggregationMethod;
    });
    get argumentField(): string;
    set argumentField(value: string);
    get axis(): string | undefined;
    set axis(value: string | undefined);
    get barOverlapGroup(): string | undefined;
    set barOverlapGroup(value: string | undefined);
    get barPadding(): number | undefined;
    set barPadding(value: number | undefined);
    get barWidth(): number | undefined;
    set barWidth(value: number | undefined);
    get border(): {
        color?: string | undefined;
        dashStyle?: DashStyle | undefined;
        visible?: boolean;
        width?: number;
    };
    set border(value: {
        color?: string | undefined;
        dashStyle?: DashStyle | undefined;
        visible?: boolean;
        width?: number;
    });
    get closeValueField(): string;
    set closeValueField(value: string);
    get color(): ChartsColor | string | undefined;
    set color(value: ChartsColor | string | undefined);
    get cornerRadius(): number;
    set cornerRadius(value: number);
    get dashStyle(): DashStyle;
    set dashStyle(value: DashStyle);
    get highValueField(): string;
    set highValueField(value: string);
    get hoverMode(): SeriesHoverMode;
    set hoverMode(value: SeriesHoverMode);
    get hoverStyle(): {
        border?: {
            color?: string | undefined;
            dashStyle?: DashStyle | undefined;
            visible?: boolean;
            width?: number;
        };
        color?: ChartsColor | string | undefined;
        dashStyle?: DashStyle;
        hatching?: {
            direction?: HatchDirection;
            opacity?: number;
            step?: number;
            width?: number;
        };
        highlight?: boolean;
        width?: number;
    };
    set hoverStyle(value: {
        border?: {
            color?: string | undefined;
            dashStyle?: DashStyle | undefined;
            visible?: boolean;
            width?: number;
        };
        color?: ChartsColor | string | undefined;
        dashStyle?: DashStyle;
        hatching?: {
            direction?: HatchDirection;
            opacity?: number;
            step?: number;
            width?: number;
        };
        highlight?: boolean;
        width?: number;
    });
    get ignoreEmptyPoints(): boolean;
    set ignoreEmptyPoints(value: boolean);
    get innerColor(): string;
    set innerColor(value: string);
    get label(): {
        alignment?: HorizontalAlignment;
        argumentFormat?: Format | undefined;
        backgroundColor?: string | undefined;
        border?: {
            color?: string | undefined;
            dashStyle?: DashStyle | undefined;
            visible?: boolean;
            width?: number;
        };
        connector?: {
            color?: string | undefined;
            visible?: boolean;
            width?: number;
        };
        customizeText?: ((pointInfo: any) => string);
        displayFormat?: string | undefined;
        font?: Font;
        format?: Format | undefined;
        horizontalOffset?: number;
        position?: RelativePosition;
        rotationAngle?: number;
        showForZeroValues?: boolean;
        verticalOffset?: number;
        visible?: boolean;
    };
    set label(value: {
        alignment?: HorizontalAlignment;
        argumentFormat?: Format | undefined;
        backgroundColor?: string | undefined;
        border?: {
            color?: string | undefined;
            dashStyle?: DashStyle | undefined;
            visible?: boolean;
            width?: number;
        };
        connector?: {
            color?: string | undefined;
            visible?: boolean;
            width?: number;
        };
        customizeText?: ((pointInfo: any) => string);
        displayFormat?: string | undefined;
        font?: Font;
        format?: Format | undefined;
        horizontalOffset?: number;
        position?: RelativePosition;
        rotationAngle?: number;
        showForZeroValues?: boolean;
        verticalOffset?: number;
        visible?: boolean;
    });
    get lowValueField(): string;
    set lowValueField(value: string);
    get maxLabelCount(): number | undefined;
    set maxLabelCount(value: number | undefined);
    get minBarSize(): number | undefined;
    set minBarSize(value: number | undefined);
    get name(): string | undefined;
    set name(value: string | undefined);
    get opacity(): number;
    set opacity(value: number);
    get openValueField(): string;
    set openValueField(value: string);
    get pane(): string;
    set pane(value: string);
    get point(): {
        border?: {
            color?: string | undefined;
            visible?: boolean;
            width?: number;
        };
        color?: ChartsColor | string | undefined;
        hoverMode?: PointInteractionMode;
        hoverStyle?: {
            border?: {
                color?: string | undefined;
                visible?: boolean;
                width?: number;
            };
            color?: ChartsColor | string | undefined;
            size?: number | undefined;
        };
        image?: string | undefined | {
            height?: number | {
                rangeMaxPoint?: number | undefined;
                rangeMinPoint?: number | undefined;
            };
            url?: string | undefined | {
                rangeMaxPoint?: string | undefined;
                rangeMinPoint?: string | undefined;
            };
            width?: number | {
                rangeMaxPoint?: number | undefined;
                rangeMinPoint?: number | undefined;
            };
        };
        selectionMode?: PointInteractionMode;
        selectionStyle?: {
            border?: {
                color?: string | undefined;
                visible?: boolean;
                width?: number;
            };
            color?: ChartsColor | string | undefined;
            size?: number | undefined;
        };
        size?: number;
        symbol?: PointSymbol;
        visible?: boolean;
    };
    set point(value: {
        border?: {
            color?: string | undefined;
            visible?: boolean;
            width?: number;
        };
        color?: ChartsColor | string | undefined;
        hoverMode?: PointInteractionMode;
        hoverStyle?: {
            border?: {
                color?: string | undefined;
                visible?: boolean;
                width?: number;
            };
            color?: ChartsColor | string | undefined;
            size?: number | undefined;
        };
        image?: string | undefined | {
            height?: number | {
                rangeMaxPoint?: number | undefined;
                rangeMinPoint?: number | undefined;
            };
            url?: string | undefined | {
                rangeMaxPoint?: string | undefined;
                rangeMinPoint?: string | undefined;
            };
            width?: number | {
                rangeMaxPoint?: number | undefined;
                rangeMinPoint?: number | undefined;
            };
        };
        selectionMode?: PointInteractionMode;
        selectionStyle?: {
            border?: {
                color?: string | undefined;
                visible?: boolean;
                width?: number;
            };
            color?: ChartsColor | string | undefined;
            size?: number | undefined;
        };
        size?: number;
        symbol?: PointSymbol;
        visible?: boolean;
    });
    get rangeValue1Field(): string;
    set rangeValue1Field(value: string);
    get rangeValue2Field(): string;
    set rangeValue2Field(value: string);
    get reduction(): {
        color?: string;
        level?: FinancialChartReductionLevel;
    };
    set reduction(value: {
        color?: string;
        level?: FinancialChartReductionLevel;
    });
    get selectionMode(): SeriesSelectionMode;
    set selectionMode(value: SeriesSelectionMode);
    get selectionStyle(): {
        border?: {
            color?: string | undefined;
            dashStyle?: DashStyle | undefined;
            visible?: boolean;
            width?: number;
        };
        color?: ChartsColor | string | undefined;
        dashStyle?: DashStyle;
        hatching?: {
            direction?: HatchDirection;
            opacity?: number;
            step?: number;
            width?: number;
        };
        highlight?: boolean;
        width?: number;
    };
    set selectionStyle(value: {
        border?: {
            color?: string | undefined;
            dashStyle?: DashStyle | undefined;
            visible?: boolean;
            width?: number;
        };
        color?: ChartsColor | string | undefined;
        dashStyle?: DashStyle;
        hatching?: {
            direction?: HatchDirection;
            opacity?: number;
            step?: number;
            width?: number;
        };
        highlight?: boolean;
        width?: number;
    });
    get showInLegend(): boolean;
    set showInLegend(value: boolean);
    get sizeField(): string;
    set sizeField(value: string);
    get stack(): string;
    set stack(value: string);
    get tag(): any | undefined;
    set tag(value: any | undefined);
    get tagField(): string;
    set tagField(value: string);
    get type(): SeriesType;
    set type(value: SeriesType);
    get valueErrorBar(): {
        color?: string;
        displayMode?: ValueErrorBarDisplayMode;
        edgeLength?: number;
        highValueField?: string | undefined;
        lineWidth?: number;
        lowValueField?: string | undefined;
        opacity?: number | undefined;
        type?: undefined | ValueErrorBarType;
        value?: number;
    };
    set valueErrorBar(value: {
        color?: string;
        displayMode?: ValueErrorBarDisplayMode;
        edgeLength?: number;
        highValueField?: string | undefined;
        lineWidth?: number;
        lowValueField?: string | undefined;
        opacity?: number | undefined;
        type?: undefined | ValueErrorBarType;
        value?: number;
    });
    get valueField(): string;
    set valueField(value: string);
    get visible(): boolean;
    set visible(value: boolean);
    get width(): number;
    set width(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiChartSeriesComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiChartSeriesComponent, "dxi-chart-series", never, { "aggregation": { "alias": "aggregation"; "required": false; }; "argumentField": { "alias": "argumentField"; "required": false; }; "axis": { "alias": "axis"; "required": false; }; "barOverlapGroup": { "alias": "barOverlapGroup"; "required": false; }; "barPadding": { "alias": "barPadding"; "required": false; }; "barWidth": { "alias": "barWidth"; "required": false; }; "border": { "alias": "border"; "required": false; }; "closeValueField": { "alias": "closeValueField"; "required": false; }; "color": { "alias": "color"; "required": false; }; "cornerRadius": { "alias": "cornerRadius"; "required": false; }; "dashStyle": { "alias": "dashStyle"; "required": false; }; "highValueField": { "alias": "highValueField"; "required": false; }; "hoverMode": { "alias": "hoverMode"; "required": false; }; "hoverStyle": { "alias": "hoverStyle"; "required": false; }; "ignoreEmptyPoints": { "alias": "ignoreEmptyPoints"; "required": false; }; "innerColor": { "alias": "innerColor"; "required": false; }; "label": { "alias": "label"; "required": false; }; "lowValueField": { "alias": "lowValueField"; "required": false; }; "maxLabelCount": { "alias": "maxLabelCount"; "required": false; }; "minBarSize": { "alias": "minBarSize"; "required": false; }; "name": { "alias": "name"; "required": false; }; "opacity": { "alias": "opacity"; "required": false; }; "openValueField": { "alias": "openValueField"; "required": false; }; "pane": { "alias": "pane"; "required": false; }; "point": { "alias": "point"; "required": false; }; "rangeValue1Field": { "alias": "rangeValue1Field"; "required": false; }; "rangeValue2Field": { "alias": "rangeValue2Field"; "required": false; }; "reduction": { "alias": "reduction"; "required": false; }; "selectionMode": { "alias": "selectionMode"; "required": false; }; "selectionStyle": { "alias": "selectionStyle"; "required": false; }; "showInLegend": { "alias": "showInLegend"; "required": false; }; "sizeField": { "alias": "sizeField"; "required": false; }; "stack": { "alias": "stack"; "required": false; }; "tag": { "alias": "tag"; "required": false; }; "tagField": { "alias": "tagField"; "required": false; }; "type": { "alias": "type"; "required": false; }; "valueErrorBar": { "alias": "valueErrorBar"; "required": false; }; "valueField": { "alias": "valueField"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxiChartSeriesModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiChartSeriesModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiChartSeriesModule, never, [typeof DxiChartSeriesComponent], [typeof DxiChartSeriesComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiChartSeriesModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoChartSeriesTemplateComponent extends NestedOption implements OnDestroy, OnInit {
    get customizeSeries(): ((seriesName: any) => ChartSeries);
    set customizeSeries(value: ((seriesName: any) => ChartSeries));
    get nameField(): string;
    set nameField(value: string);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChartSeriesTemplateComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoChartSeriesTemplateComponent, "dxo-chart-series-template", never, { "customizeSeries": { "alias": "customizeSeries"; "required": false; }; "nameField": { "alias": "nameField"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoChartSeriesTemplateModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChartSeriesTemplateModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoChartSeriesTemplateModule, never, [typeof DxoChartSeriesTemplateComponent], [typeof DxoChartSeriesTemplateComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoChartSeriesTemplateModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoChartShadowComponent extends NestedOption implements OnDestroy, OnInit {
    get blur(): number;
    set blur(value: number);
    get color(): string;
    set color(value: string);
    get offsetX(): number;
    set offsetX(value: number);
    get offsetY(): number;
    set offsetY(value: number);
    get opacity(): number;
    set opacity(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChartShadowComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoChartShadowComponent, "dxo-chart-shadow", never, { "blur": { "alias": "blur"; "required": false; }; "color": { "alias": "color"; "required": false; }; "offsetX": { "alias": "offsetX"; "required": false; }; "offsetY": { "alias": "offsetY"; "required": false; }; "opacity": { "alias": "opacity"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoChartShadowModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChartShadowModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoChartShadowModule, never, [typeof DxoChartShadowComponent], [typeof DxoChartShadowComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoChartShadowModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoChartSizeComponent extends NestedOption implements OnDestroy, OnInit {
    get height(): number | undefined;
    set height(value: number | undefined);
    get width(): number | undefined;
    set width(value: number | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChartSizeComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoChartSizeComponent, "dxo-chart-size", never, { "height": { "alias": "height"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoChartSizeModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChartSizeModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoChartSizeModule, never, [typeof DxoChartSizeComponent], [typeof DxoChartSizeComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoChartSizeModule>;
}

declare class DxiChartStripComponent extends CollectionNestedOption {
    get color(): string | undefined;
    set color(value: string | undefined);
    get endValue(): Date | number | string | undefined;
    set endValue(value: Date | number | string | undefined);
    get label(): {
        font?: Font;
        horizontalAlignment?: HorizontalAlignment;
        text?: string | undefined;
        verticalAlignment?: VerticalAlignment;
    };
    set label(value: {
        font?: Font;
        horizontalAlignment?: HorizontalAlignment;
        text?: string | undefined;
        verticalAlignment?: VerticalAlignment;
    });
    get paddingLeftRight(): number;
    set paddingLeftRight(value: number);
    get paddingTopBottom(): number;
    set paddingTopBottom(value: number);
    get startValue(): Date | number | string | undefined;
    set startValue(value: Date | number | string | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiChartStripComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiChartStripComponent, "dxi-chart-strip", never, { "color": { "alias": "color"; "required": false; }; "endValue": { "alias": "endValue"; "required": false; }; "label": { "alias": "label"; "required": false; }; "paddingLeftRight": { "alias": "paddingLeftRight"; "required": false; }; "paddingTopBottom": { "alias": "paddingTopBottom"; "required": false; }; "startValue": { "alias": "startValue"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxiChartStripModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiChartStripModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiChartStripModule, never, [typeof DxiChartStripComponent], [typeof DxiChartStripComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiChartStripModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoChartStripLabelComponent extends NestedOption implements OnDestroy, OnInit {
    get font(): Font;
    set font(value: Font);
    get horizontalAlignment(): HorizontalAlignment;
    set horizontalAlignment(value: HorizontalAlignment);
    get text(): string | undefined;
    set text(value: string | undefined);
    get verticalAlignment(): VerticalAlignment;
    set verticalAlignment(value: VerticalAlignment);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChartStripLabelComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoChartStripLabelComponent, "dxo-chart-strip-label", never, { "font": { "alias": "font"; "required": false; }; "horizontalAlignment": { "alias": "horizontalAlignment"; "required": false; }; "text": { "alias": "text"; "required": false; }; "verticalAlignment": { "alias": "verticalAlignment"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoChartStripLabelModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChartStripLabelModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoChartStripLabelModule, never, [typeof DxoChartStripLabelComponent], [typeof DxoChartStripLabelComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoChartStripLabelModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoChartStripStyleLabelComponent extends NestedOption implements OnDestroy, OnInit {
    get font(): Font;
    set font(value: Font);
    get horizontalAlignment(): HorizontalAlignment;
    set horizontalAlignment(value: HorizontalAlignment);
    get verticalAlignment(): VerticalAlignment;
    set verticalAlignment(value: VerticalAlignment);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChartStripStyleLabelComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoChartStripStyleLabelComponent, "dxo-chart-strip-style-label", never, { "font": { "alias": "font"; "required": false; }; "horizontalAlignment": { "alias": "horizontalAlignment"; "required": false; }; "verticalAlignment": { "alias": "verticalAlignment"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoChartStripStyleLabelModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChartStripStyleLabelModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoChartStripStyleLabelModule, never, [typeof DxoChartStripStyleLabelComponent], [typeof DxoChartStripStyleLabelComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoChartStripStyleLabelModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoChartStripStyleComponent extends NestedOption implements OnDestroy, OnInit {
    get label(): {
        font?: Font;
        horizontalAlignment?: HorizontalAlignment;
        verticalAlignment?: VerticalAlignment;
    };
    set label(value: {
        font?: Font;
        horizontalAlignment?: HorizontalAlignment;
        verticalAlignment?: VerticalAlignment;
    });
    get paddingLeftRight(): number;
    set paddingLeftRight(value: number);
    get paddingTopBottom(): number;
    set paddingTopBottom(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChartStripStyleComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoChartStripStyleComponent, "dxo-chart-strip-style", never, { "label": { "alias": "label"; "required": false; }; "paddingLeftRight": { "alias": "paddingLeftRight"; "required": false; }; "paddingTopBottom": { "alias": "paddingTopBottom"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoChartStripStyleModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChartStripStyleModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoChartStripStyleModule, never, [typeof DxoChartStripStyleComponent], [typeof DxoChartStripStyleComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoChartStripStyleModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoChartSubtitleComponent extends NestedOption implements OnDestroy, OnInit {
    get font(): Font;
    set font(value: Font);
    get offset(): number;
    set offset(value: number);
    get text(): string | undefined;
    set text(value: string | undefined);
    get textOverflow(): TextOverflow;
    set textOverflow(value: TextOverflow);
    get wordWrap(): WordWrap;
    set wordWrap(value: WordWrap);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChartSubtitleComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoChartSubtitleComponent, "dxo-chart-subtitle", never, { "font": { "alias": "font"; "required": false; }; "offset": { "alias": "offset"; "required": false; }; "text": { "alias": "text"; "required": false; }; "textOverflow": { "alias": "textOverflow"; "required": false; }; "wordWrap": { "alias": "wordWrap"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoChartSubtitleModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChartSubtitleModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoChartSubtitleModule, never, [typeof DxoChartSubtitleComponent], [typeof DxoChartSubtitleComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoChartSubtitleModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoChartTickIntervalComponent extends NestedOption implements OnDestroy, OnInit {
    get days(): number;
    set days(value: number);
    get hours(): number;
    set hours(value: number);
    get milliseconds(): number;
    set milliseconds(value: number);
    get minutes(): number;
    set minutes(value: number);
    get months(): number;
    set months(value: number);
    get quarters(): number;
    set quarters(value: number);
    get seconds(): number;
    set seconds(value: number);
    get weeks(): number;
    set weeks(value: number);
    get years(): number;
    set years(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChartTickIntervalComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoChartTickIntervalComponent, "dxo-chart-tick-interval", never, { "days": { "alias": "days"; "required": false; }; "hours": { "alias": "hours"; "required": false; }; "milliseconds": { "alias": "milliseconds"; "required": false; }; "minutes": { "alias": "minutes"; "required": false; }; "months": { "alias": "months"; "required": false; }; "quarters": { "alias": "quarters"; "required": false; }; "seconds": { "alias": "seconds"; "required": false; }; "weeks": { "alias": "weeks"; "required": false; }; "years": { "alias": "years"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoChartTickIntervalModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChartTickIntervalModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoChartTickIntervalModule, never, [typeof DxoChartTickIntervalComponent], [typeof DxoChartTickIntervalComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoChartTickIntervalModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoChartTickComponent extends NestedOption implements OnDestroy, OnInit {
    get color(): string;
    set color(value: string);
    get length(): number;
    set length(value: number);
    get opacity(): number | undefined;
    set opacity(value: number | undefined);
    get shift(): number;
    set shift(value: number);
    get visible(): boolean;
    set visible(value: boolean);
    get width(): number;
    set width(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChartTickComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoChartTickComponent, "dxo-chart-tick", never, { "color": { "alias": "color"; "required": false; }; "length": { "alias": "length"; "required": false; }; "opacity": { "alias": "opacity"; "required": false; }; "shift": { "alias": "shift"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoChartTickModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChartTickModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoChartTickModule, never, [typeof DxoChartTickComponent], [typeof DxoChartTickComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoChartTickModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoChartTitleComponent extends NestedOption implements OnDestroy, OnInit {
    get alignment(): HorizontalAlignment;
    set alignment(value: HorizontalAlignment);
    get font(): Font;
    set font(value: Font);
    get margin(): number | {
        bottom?: number;
        left?: number;
        right?: number;
        top?: number;
    };
    set margin(value: number | {
        bottom?: number;
        left?: number;
        right?: number;
        top?: number;
    });
    get text(): string | undefined;
    set text(value: string | undefined);
    get textOverflow(): TextOverflow;
    set textOverflow(value: TextOverflow);
    get wordWrap(): WordWrap;
    set wordWrap(value: WordWrap);
    get horizontalAlignment(): HorizontalAlignment | undefined;
    set horizontalAlignment(value: HorizontalAlignment | undefined);
    get placeholderSize(): number | undefined;
    set placeholderSize(value: number | undefined);
    get subtitle(): string | {
        font?: Font;
        offset?: number;
        text?: string | undefined;
        textOverflow?: TextOverflow;
        wordWrap?: WordWrap;
    };
    set subtitle(value: string | {
        font?: Font;
        offset?: number;
        text?: string | undefined;
        textOverflow?: TextOverflow;
        wordWrap?: WordWrap;
    });
    get verticalAlignment(): VerticalEdge;
    set verticalAlignment(value: VerticalEdge);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChartTitleComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoChartTitleComponent, "dxo-chart-title", never, { "alignment": { "alias": "alignment"; "required": false; }; "font": { "alias": "font"; "required": false; }; "margin": { "alias": "margin"; "required": false; }; "text": { "alias": "text"; "required": false; }; "textOverflow": { "alias": "textOverflow"; "required": false; }; "wordWrap": { "alias": "wordWrap"; "required": false; }; "horizontalAlignment": { "alias": "horizontalAlignment"; "required": false; }; "placeholderSize": { "alias": "placeholderSize"; "required": false; }; "subtitle": { "alias": "subtitle"; "required": false; }; "verticalAlignment": { "alias": "verticalAlignment"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoChartTitleModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChartTitleModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoChartTitleModule, never, [typeof DxoChartTitleComponent], [typeof DxoChartTitleComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoChartTitleModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoChartTooltipBorderComponent extends NestedOption implements OnDestroy, OnInit {
    get color(): string;
    set color(value: string);
    get dashStyle(): DashStyle;
    set dashStyle(value: DashStyle);
    get opacity(): number | undefined;
    set opacity(value: number | undefined);
    get visible(): boolean;
    set visible(value: boolean);
    get width(): number;
    set width(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChartTooltipBorderComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoChartTooltipBorderComponent, "dxo-chart-tooltip-border", never, { "color": { "alias": "color"; "required": false; }; "dashStyle": { "alias": "dashStyle"; "required": false; }; "opacity": { "alias": "opacity"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoChartTooltipBorderModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChartTooltipBorderModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoChartTooltipBorderModule, never, [typeof DxoChartTooltipBorderComponent], [typeof DxoChartTooltipBorderComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoChartTooltipBorderModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoChartTooltipComponent extends NestedOption implements OnDestroy, OnInit {
    get argumentFormat(): Format | undefined;
    set argumentFormat(value: Format | undefined);
    get arrowLength(): number;
    set arrowLength(value: number);
    get border(): {
        color?: string;
        dashStyle?: DashStyle;
        opacity?: number | undefined;
        visible?: boolean;
        width?: number;
    };
    set border(value: {
        color?: string;
        dashStyle?: DashStyle;
        opacity?: number | undefined;
        visible?: boolean;
        width?: number;
    });
    get color(): string;
    set color(value: string);
    get container(): any | string | undefined;
    set container(value: any | string | undefined);
    get contentTemplate(): any;
    set contentTemplate(value: any);
    get cornerRadius(): number;
    set cornerRadius(value: number);
    get customizeTooltip(): ((pointInfo: dxChartPointInfo) => Record<string, any>) | undefined;
    set customizeTooltip(value: ((pointInfo: dxChartPointInfo) => Record<string, any>) | undefined);
    get enabled(): boolean;
    set enabled(value: boolean);
    get font(): Font;
    set font(value: Font);
    get format(): Format | undefined;
    set format(value: Format | undefined);
    get interactive(): boolean;
    set interactive(value: boolean);
    get location(): ChartTooltipLocation;
    set location(value: ChartTooltipLocation);
    get opacity(): number | undefined;
    set opacity(value: number | undefined);
    get paddingLeftRight(): number;
    set paddingLeftRight(value: number);
    get paddingTopBottom(): number;
    set paddingTopBottom(value: number);
    get shadow(): {
        blur?: number;
        color?: string;
        offsetX?: number;
        offsetY?: number;
        opacity?: number;
    };
    set shadow(value: {
        blur?: number;
        color?: string;
        offsetX?: number;
        offsetY?: number;
        opacity?: number;
    });
    get shared(): boolean;
    set shared(value: boolean);
    get zIndex(): number | undefined;
    set zIndex(value: number | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChartTooltipComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoChartTooltipComponent, "dxo-chart-tooltip", never, { "argumentFormat": { "alias": "argumentFormat"; "required": false; }; "arrowLength": { "alias": "arrowLength"; "required": false; }; "border": { "alias": "border"; "required": false; }; "color": { "alias": "color"; "required": false; }; "container": { "alias": "container"; "required": false; }; "contentTemplate": { "alias": "contentTemplate"; "required": false; }; "cornerRadius": { "alias": "cornerRadius"; "required": false; }; "customizeTooltip": { "alias": "customizeTooltip"; "required": false; }; "enabled": { "alias": "enabled"; "required": false; }; "font": { "alias": "font"; "required": false; }; "format": { "alias": "format"; "required": false; }; "interactive": { "alias": "interactive"; "required": false; }; "location": { "alias": "location"; "required": false; }; "opacity": { "alias": "opacity"; "required": false; }; "paddingLeftRight": { "alias": "paddingLeftRight"; "required": false; }; "paddingTopBottom": { "alias": "paddingTopBottom"; "required": false; }; "shadow": { "alias": "shadow"; "required": false; }; "shared": { "alias": "shared"; "required": false; }; "zIndex": { "alias": "zIndex"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoChartTooltipModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChartTooltipModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoChartTooltipModule, never, [typeof DxoChartTooltipComponent], [typeof DxoChartTooltipComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoChartTooltipModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoChartUrlComponent extends NestedOption implements OnDestroy, OnInit {
    get rangeMaxPoint(): string | undefined;
    set rangeMaxPoint(value: string | undefined);
    get rangeMinPoint(): string | undefined;
    set rangeMinPoint(value: string | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChartUrlComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoChartUrlComponent, "dxo-chart-url", never, { "rangeMaxPoint": { "alias": "rangeMaxPoint"; "required": false; }; "rangeMinPoint": { "alias": "rangeMinPoint"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoChartUrlModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChartUrlModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoChartUrlModule, never, [typeof DxoChartUrlComponent], [typeof DxoChartUrlComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoChartUrlModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxiChartValueAxisComponent extends CollectionNestedOption {
    set _breaksContentChildren(value: QueryList<CollectionNestedOption>);
    set _constantLinesContentChildren(value: QueryList<CollectionNestedOption>);
    set _stripsContentChildren(value: QueryList<CollectionNestedOption>);
    get aggregatedPointsPosition(): AggregatedPointsPosition;
    set aggregatedPointsPosition(value: AggregatedPointsPosition);
    get allowDecimals(): boolean | undefined;
    set allowDecimals(value: boolean | undefined);
    get autoBreaksEnabled(): boolean;
    set autoBreaksEnabled(value: boolean);
    get axisDivisionFactor(): number;
    set axisDivisionFactor(value: number);
    get breaks(): Array<ScaleBreak> | undefined | {
        endValue?: Date | number | string | undefined;
        startValue?: Date | number | string | undefined;
    }[];
    set breaks(value: Array<ScaleBreak> | undefined | {
        endValue?: Date | number | string | undefined;
        startValue?: Date | number | string | undefined;
    }[]);
    get breakStyle(): {
        color?: string;
        line?: ScaleBreakLineStyle;
        width?: number;
    };
    set breakStyle(value: {
        color?: string;
        line?: ScaleBreakLineStyle;
        width?: number;
    });
    get categories(): Array<Date | number | string>;
    set categories(value: Array<Date | number | string>);
    get color(): string;
    set color(value: string);
    get constantLines(): {
        color?: string;
        dashStyle?: DashStyle;
        displayBehindSeries?: boolean;
        extendAxis?: boolean;
        label?: {
            font?: Font;
            horizontalAlignment?: HorizontalAlignment;
            position?: RelativePosition;
            text?: string | undefined;
            verticalAlignment?: VerticalAlignment;
            visible?: boolean;
        };
        paddingLeftRight?: number;
        paddingTopBottom?: number;
        value?: Date | number | string | undefined;
        width?: number;
    }[];
    set constantLines(value: {
        color?: string;
        dashStyle?: DashStyle;
        displayBehindSeries?: boolean;
        extendAxis?: boolean;
        label?: {
            font?: Font;
            horizontalAlignment?: HorizontalAlignment;
            position?: RelativePosition;
            text?: string | undefined;
            verticalAlignment?: VerticalAlignment;
            visible?: boolean;
        };
        paddingLeftRight?: number;
        paddingTopBottom?: number;
        value?: Date | number | string | undefined;
        width?: number;
    }[]);
    get constantLineStyle(): {
        color?: string;
        dashStyle?: DashStyle;
        label?: {
            font?: Font;
            horizontalAlignment?: HorizontalAlignment;
            position?: RelativePosition;
            verticalAlignment?: VerticalAlignment;
            visible?: boolean;
        };
        paddingLeftRight?: number;
        paddingTopBottom?: number;
        width?: number;
    };
    set constantLineStyle(value: {
        color?: string;
        dashStyle?: DashStyle;
        label?: {
            font?: Font;
            horizontalAlignment?: HorizontalAlignment;
            position?: RelativePosition;
            verticalAlignment?: VerticalAlignment;
            visible?: boolean;
        };
        paddingLeftRight?: number;
        paddingTopBottom?: number;
        width?: number;
    });
    get customPosition(): Date | number | string | undefined;
    set customPosition(value: Date | number | string | undefined);
    get discreteAxisDivisionMode(): DiscreteAxisDivisionMode;
    set discreteAxisDivisionMode(value: DiscreteAxisDivisionMode);
    get endOnTick(): boolean | undefined;
    set endOnTick(value: boolean | undefined);
    get grid(): {
        color?: string;
        opacity?: number | undefined;
        visible?: boolean;
        width?: number;
    };
    set grid(value: {
        color?: string;
        opacity?: number | undefined;
        visible?: boolean;
        width?: number;
    });
    get inverted(): boolean;
    set inverted(value: boolean);
    get label(): {
        alignment?: HorizontalAlignment | undefined;
        customizeHint?: ((axisValue: {
            value: Date | number | string;
            valueText: string;
        }) => string);
        customizeText?: ((axisValue: {
            value: Date | number | string;
            valueText: string;
        }) => string);
        displayMode?: ChartLabelDisplayMode;
        font?: Font;
        format?: Format | undefined;
        indentFromAxis?: number;
        overlappingBehavior?: ChartsAxisLabelOverlap;
        position?: Position | RelativePosition;
        rotationAngle?: number;
        staggeringSpacing?: number;
        template?: any;
        textOverflow?: TextOverflow;
        visible?: boolean;
        wordWrap?: WordWrap;
    };
    set label(value: {
        alignment?: HorizontalAlignment | undefined;
        customizeHint?: ((axisValue: {
            value: Date | number | string;
            valueText: string;
        }) => string);
        customizeText?: ((axisValue: {
            value: Date | number | string;
            valueText: string;
        }) => string);
        displayMode?: ChartLabelDisplayMode;
        font?: Font;
        format?: Format | undefined;
        indentFromAxis?: number;
        overlappingBehavior?: ChartsAxisLabelOverlap;
        position?: Position | RelativePosition;
        rotationAngle?: number;
        staggeringSpacing?: number;
        template?: any;
        textOverflow?: TextOverflow;
        visible?: boolean;
        wordWrap?: WordWrap;
    });
    get linearThreshold(): number | undefined;
    set linearThreshold(value: number | undefined);
    get logarithmBase(): number;
    set logarithmBase(value: number);
    get maxAutoBreakCount(): number;
    set maxAutoBreakCount(value: number);
    get maxValueMargin(): number | undefined;
    set maxValueMargin(value: number | undefined);
    get minorGrid(): {
        color?: string;
        opacity?: number | undefined;
        visible?: boolean;
        width?: number;
    };
    set minorGrid(value: {
        color?: string;
        opacity?: number | undefined;
        visible?: boolean;
        width?: number;
    });
    get minorTick(): {
        color?: string;
        length?: number;
        opacity?: number;
        shift?: number;
        visible?: boolean;
        width?: number;
    };
    set minorTick(value: {
        color?: string;
        length?: number;
        opacity?: number;
        shift?: number;
        visible?: boolean;
        width?: number;
    });
    get minorTickCount(): number | undefined;
    set minorTickCount(value: number | undefined);
    get minorTickInterval(): number | TimeInterval | {
        days?: number;
        hours?: number;
        milliseconds?: number;
        minutes?: number;
        months?: number;
        quarters?: number;
        seconds?: number;
        weeks?: number;
        years?: number;
    };
    set minorTickInterval(value: number | TimeInterval | {
        days?: number;
        hours?: number;
        milliseconds?: number;
        minutes?: number;
        months?: number;
        quarters?: number;
        seconds?: number;
        weeks?: number;
        years?: number;
    });
    get minValueMargin(): number | undefined;
    set minValueMargin(value: number | undefined);
    get minVisualRangeLength(): number | TimeInterval | undefined | {
        days?: number;
        hours?: number;
        milliseconds?: number;
        minutes?: number;
        months?: number;
        quarters?: number;
        seconds?: number;
        weeks?: number;
        years?: number;
    };
    set minVisualRangeLength(value: number | TimeInterval | undefined | {
        days?: number;
        hours?: number;
        milliseconds?: number;
        minutes?: number;
        months?: number;
        quarters?: number;
        seconds?: number;
        weeks?: number;
        years?: number;
    });
    get multipleAxesSpacing(): number;
    set multipleAxesSpacing(value: number);
    get name(): string | undefined;
    set name(value: string | undefined);
    get offset(): number | undefined;
    set offset(value: number | undefined);
    get opacity(): number | undefined;
    set opacity(value: number | undefined);
    get pane(): string | undefined;
    set pane(value: string | undefined);
    get placeholderSize(): null | number;
    set placeholderSize(value: null | number);
    get position(): Position;
    set position(value: Position);
    get showZero(): boolean | undefined;
    set showZero(value: boolean | undefined);
    get strips(): {
        color?: string | undefined;
        endValue?: Date | number | string | undefined;
        label?: {
            font?: Font;
            horizontalAlignment?: HorizontalAlignment;
            text?: string | undefined;
            verticalAlignment?: VerticalAlignment;
        };
        paddingLeftRight?: number;
        paddingTopBottom?: number;
        startValue?: Date | number | string | undefined;
    }[];
    set strips(value: {
        color?: string | undefined;
        endValue?: Date | number | string | undefined;
        label?: {
            font?: Font;
            horizontalAlignment?: HorizontalAlignment;
            text?: string | undefined;
            verticalAlignment?: VerticalAlignment;
        };
        paddingLeftRight?: number;
        paddingTopBottom?: number;
        startValue?: Date | number | string | undefined;
    }[]);
    get stripStyle(): {
        label?: {
            font?: Font;
            horizontalAlignment?: HorizontalAlignment;
            verticalAlignment?: VerticalAlignment;
        };
        paddingLeftRight?: number;
        paddingTopBottom?: number;
    };
    set stripStyle(value: {
        label?: {
            font?: Font;
            horizontalAlignment?: HorizontalAlignment;
            verticalAlignment?: VerticalAlignment;
        };
        paddingLeftRight?: number;
        paddingTopBottom?: number;
    });
    get synchronizedValue(): number | undefined;
    set synchronizedValue(value: number | undefined);
    get tick(): {
        color?: string;
        length?: number;
        opacity?: number | undefined;
        shift?: number;
        visible?: boolean;
        width?: number;
    };
    set tick(value: {
        color?: string;
        length?: number;
        opacity?: number | undefined;
        shift?: number;
        visible?: boolean;
        width?: number;
    });
    get tickInterval(): number | TimeInterval | {
        days?: number;
        hours?: number;
        milliseconds?: number;
        minutes?: number;
        months?: number;
        quarters?: number;
        seconds?: number;
        weeks?: number;
        years?: number;
    };
    set tickInterval(value: number | TimeInterval | {
        days?: number;
        hours?: number;
        milliseconds?: number;
        minutes?: number;
        months?: number;
        quarters?: number;
        seconds?: number;
        weeks?: number;
        years?: number;
    });
    get title(): string | {
        alignment?: HorizontalAlignment;
        font?: Font;
        margin?: number;
        text?: string | undefined;
        textOverflow?: TextOverflow;
        wordWrap?: WordWrap;
    };
    set title(value: string | {
        alignment?: HorizontalAlignment;
        font?: Font;
        margin?: number;
        text?: string | undefined;
        textOverflow?: TextOverflow;
        wordWrap?: WordWrap;
    });
    get type(): AxisScaleType | undefined;
    set type(value: AxisScaleType | undefined);
    get valueMarginsEnabled(): boolean;
    set valueMarginsEnabled(value: boolean);
    get valueType(): ChartsDataType | undefined;
    set valueType(value: ChartsDataType | undefined);
    get visible(): boolean;
    set visible(value: boolean);
    get visualRange(): Array<Date | number | string> | CommonChartTypes.VisualRange;
    set visualRange(value: Array<Date | number | string> | CommonChartTypes.VisualRange);
    get visualRangeUpdateMode(): ValueAxisVisualRangeUpdateMode;
    set visualRangeUpdateMode(value: ValueAxisVisualRangeUpdateMode);
    get wholeRange(): Array<Date | number | string> | undefined | CommonChartTypes.VisualRange;
    set wholeRange(value: Array<Date | number | string> | undefined | CommonChartTypes.VisualRange);
    get width(): number;
    set width(value: number);
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    categoriesChange: EventEmitter<Array<Date | number | string>>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    visualRangeChange: EventEmitter<Array<Date | number | string> | CommonChartTypes.VisualRange>;
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiChartValueAxisComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiChartValueAxisComponent, "dxi-chart-value-axis", never, { "aggregatedPointsPosition": { "alias": "aggregatedPointsPosition"; "required": false; }; "allowDecimals": { "alias": "allowDecimals"; "required": false; }; "autoBreaksEnabled": { "alias": "autoBreaksEnabled"; "required": false; }; "axisDivisionFactor": { "alias": "axisDivisionFactor"; "required": false; }; "breaks": { "alias": "breaks"; "required": false; }; "breakStyle": { "alias": "breakStyle"; "required": false; }; "categories": { "alias": "categories"; "required": false; }; "color": { "alias": "color"; "required": false; }; "constantLines": { "alias": "constantLines"; "required": false; }; "constantLineStyle": { "alias": "constantLineStyle"; "required": false; }; "customPosition": { "alias": "customPosition"; "required": false; }; "discreteAxisDivisionMode": { "alias": "discreteAxisDivisionMode"; "required": false; }; "endOnTick": { "alias": "endOnTick"; "required": false; }; "grid": { "alias": "grid"; "required": false; }; "inverted": { "alias": "inverted"; "required": false; }; "label": { "alias": "label"; "required": false; }; "linearThreshold": { "alias": "linearThreshold"; "required": false; }; "logarithmBase": { "alias": "logarithmBase"; "required": false; }; "maxAutoBreakCount": { "alias": "maxAutoBreakCount"; "required": false; }; "maxValueMargin": { "alias": "maxValueMargin"; "required": false; }; "minorGrid": { "alias": "minorGrid"; "required": false; }; "minorTick": { "alias": "minorTick"; "required": false; }; "minorTickCount": { "alias": "minorTickCount"; "required": false; }; "minorTickInterval": { "alias": "minorTickInterval"; "required": false; }; "minValueMargin": { "alias": "minValueMargin"; "required": false; }; "minVisualRangeLength": { "alias": "minVisualRangeLength"; "required": false; }; "multipleAxesSpacing": { "alias": "multipleAxesSpacing"; "required": false; }; "name": { "alias": "name"; "required": false; }; "offset": { "alias": "offset"; "required": false; }; "opacity": { "alias": "opacity"; "required": false; }; "pane": { "alias": "pane"; "required": false; }; "placeholderSize": { "alias": "placeholderSize"; "required": false; }; "position": { "alias": "position"; "required": false; }; "showZero": { "alias": "showZero"; "required": false; }; "strips": { "alias": "strips"; "required": false; }; "stripStyle": { "alias": "stripStyle"; "required": false; }; "synchronizedValue": { "alias": "synchronizedValue"; "required": false; }; "tick": { "alias": "tick"; "required": false; }; "tickInterval": { "alias": "tickInterval"; "required": false; }; "title": { "alias": "title"; "required": false; }; "type": { "alias": "type"; "required": false; }; "valueMarginsEnabled": { "alias": "valueMarginsEnabled"; "required": false; }; "valueType": { "alias": "valueType"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "visualRange": { "alias": "visualRange"; "required": false; }; "visualRangeUpdateMode": { "alias": "visualRangeUpdateMode"; "required": false; }; "wholeRange": { "alias": "wholeRange"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, { "categoriesChange": "categoriesChange"; "visualRangeChange": "visualRangeChange"; }, ["_breaksContentChildren", "_constantLinesContentChildren", "_stripsContentChildren"], never, true, never>;
}
declare class DxiChartValueAxisModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiChartValueAxisModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiChartValueAxisModule, never, [typeof DxiChartValueAxisComponent], [typeof DxiChartValueAxisComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiChartValueAxisModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoChartValueErrorBarComponent extends NestedOption implements OnDestroy, OnInit {
    get color(): string;
    set color(value: string);
    get displayMode(): ValueErrorBarDisplayMode;
    set displayMode(value: ValueErrorBarDisplayMode);
    get edgeLength(): number;
    set edgeLength(value: number);
    get highValueField(): string | undefined;
    set highValueField(value: string | undefined);
    get lineWidth(): number;
    set lineWidth(value: number);
    get lowValueField(): string | undefined;
    set lowValueField(value: string | undefined);
    get opacity(): number | undefined;
    set opacity(value: number | undefined);
    get type(): undefined | ValueErrorBarType;
    set type(value: undefined | ValueErrorBarType);
    get value(): number;
    set value(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChartValueErrorBarComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoChartValueErrorBarComponent, "dxo-chart-value-error-bar", never, { "color": { "alias": "color"; "required": false; }; "displayMode": { "alias": "displayMode"; "required": false; }; "edgeLength": { "alias": "edgeLength"; "required": false; }; "highValueField": { "alias": "highValueField"; "required": false; }; "lineWidth": { "alias": "lineWidth"; "required": false; }; "lowValueField": { "alias": "lowValueField"; "required": false; }; "opacity": { "alias": "opacity"; "required": false; }; "type": { "alias": "type"; "required": false; }; "value": { "alias": "value"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoChartValueErrorBarModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChartValueErrorBarModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoChartValueErrorBarModule, never, [typeof DxoChartValueErrorBarComponent], [typeof DxoChartValueErrorBarComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoChartValueErrorBarModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoChartVerticalLineComponent extends NestedOption implements OnDestroy, OnInit {
    get color(): string;
    set color(value: string);
    get dashStyle(): DashStyle;
    set dashStyle(value: DashStyle);
    get label(): {
        backgroundColor?: string;
        customizeText?: ((info: {
            point: chartPointObject;
            value: Date | number | string;
            valueText: string;
        }) => string);
        font?: Font;
        format?: Format | undefined;
        visible?: boolean;
    };
    set label(value: {
        backgroundColor?: string;
        customizeText?: ((info: {
            point: chartPointObject;
            value: Date | number | string;
            valueText: string;
        }) => string);
        font?: Font;
        format?: Format | undefined;
        visible?: boolean;
    });
    get opacity(): number | undefined;
    set opacity(value: number | undefined);
    get visible(): boolean;
    set visible(value: boolean);
    get width(): number;
    set width(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChartVerticalLineComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoChartVerticalLineComponent, "dxo-chart-vertical-line", never, { "color": { "alias": "color"; "required": false; }; "dashStyle": { "alias": "dashStyle"; "required": false; }; "label": { "alias": "label"; "required": false; }; "opacity": { "alias": "opacity"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoChartVerticalLineModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChartVerticalLineModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoChartVerticalLineModule, never, [typeof DxoChartVerticalLineComponent], [typeof DxoChartVerticalLineComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoChartVerticalLineModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoChartVisualRangeComponent extends NestedOption implements OnDestroy, OnInit {
    get endValue(): Date | number | string | undefined;
    set endValue(value: Date | number | string | undefined);
    get length(): number | TimeInterval | undefined | {
        days?: number;
        hours?: number;
        milliseconds?: number;
        minutes?: number;
        months?: number;
        quarters?: number;
        seconds?: number;
        weeks?: number;
        years?: number;
    };
    set length(value: number | TimeInterval | undefined | {
        days?: number;
        hours?: number;
        milliseconds?: number;
        minutes?: number;
        months?: number;
        quarters?: number;
        seconds?: number;
        weeks?: number;
        years?: number;
    });
    get startValue(): Date | number | string | undefined;
    set startValue(value: Date | number | string | undefined);
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    endValueChange: EventEmitter<Date | number | string | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    startValueChange: EventEmitter<Date | number | string | undefined>;
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChartVisualRangeComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoChartVisualRangeComponent, "dxo-chart-visual-range", never, { "endValue": { "alias": "endValue"; "required": false; }; "length": { "alias": "length"; "required": false; }; "startValue": { "alias": "startValue"; "required": false; }; }, { "endValueChange": "endValueChange"; "startValueChange": "startValueChange"; }, never, never, true, never>;
}
declare class DxoChartVisualRangeModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChartVisualRangeModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoChartVisualRangeModule, never, [typeof DxoChartVisualRangeComponent], [typeof DxoChartVisualRangeComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoChartVisualRangeModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoChartWholeRangeComponent extends NestedOption implements OnDestroy, OnInit {
    get endValue(): Date | number | string | undefined;
    set endValue(value: Date | number | string | undefined);
    get length(): number | TimeInterval | undefined | {
        days?: number;
        hours?: number;
        milliseconds?: number;
        minutes?: number;
        months?: number;
        quarters?: number;
        seconds?: number;
        weeks?: number;
        years?: number;
    };
    set length(value: number | TimeInterval | undefined | {
        days?: number;
        hours?: number;
        milliseconds?: number;
        minutes?: number;
        months?: number;
        quarters?: number;
        seconds?: number;
        weeks?: number;
        years?: number;
    });
    get startValue(): Date | number | string | undefined;
    set startValue(value: Date | number | string | undefined);
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    endValueChange: EventEmitter<Date | number | string | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    startValueChange: EventEmitter<Date | number | string | undefined>;
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChartWholeRangeComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoChartWholeRangeComponent, "dxo-chart-whole-range", never, { "endValue": { "alias": "endValue"; "required": false; }; "length": { "alias": "length"; "required": false; }; "startValue": { "alias": "startValue"; "required": false; }; }, { "endValueChange": "endValueChange"; "startValueChange": "startValueChange"; }, never, never, true, never>;
}
declare class DxoChartWholeRangeModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChartWholeRangeModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoChartWholeRangeModule, never, [typeof DxoChartWholeRangeComponent], [typeof DxoChartWholeRangeComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoChartWholeRangeModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoChartWidthComponent extends NestedOption implements OnDestroy, OnInit {
    get rangeMaxPoint(): number | undefined;
    set rangeMaxPoint(value: number | undefined);
    get rangeMinPoint(): number | undefined;
    set rangeMinPoint(value: number | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChartWidthComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoChartWidthComponent, "dxo-chart-width", never, { "rangeMaxPoint": { "alias": "rangeMaxPoint"; "required": false; }; "rangeMinPoint": { "alias": "rangeMinPoint"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoChartWidthModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChartWidthModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoChartWidthModule, never, [typeof DxoChartWidthComponent], [typeof DxoChartWidthComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoChartWidthModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoChartZoomAndPanComponent extends NestedOption implements OnDestroy, OnInit {
    get allowMouseWheel(): boolean;
    set allowMouseWheel(value: boolean);
    get allowTouchGestures(): boolean;
    set allowTouchGestures(value: boolean);
    get argumentAxis(): ChartZoomAndPanMode;
    set argumentAxis(value: ChartZoomAndPanMode);
    get dragBoxStyle(): {
        color?: string | undefined;
        opacity?: number | undefined;
    };
    set dragBoxStyle(value: {
        color?: string | undefined;
        opacity?: number | undefined;
    });
    get dragToZoom(): boolean;
    set dragToZoom(value: boolean);
    get panKey(): EventKeyModifier;
    set panKey(value: EventKeyModifier);
    get valueAxis(): ChartZoomAndPanMode;
    set valueAxis(value: ChartZoomAndPanMode);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChartZoomAndPanComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoChartZoomAndPanComponent, "dxo-chart-zoom-and-pan", never, { "allowMouseWheel": { "alias": "allowMouseWheel"; "required": false; }; "allowTouchGestures": { "alias": "allowTouchGestures"; "required": false; }; "argumentAxis": { "alias": "argumentAxis"; "required": false; }; "dragBoxStyle": { "alias": "dragBoxStyle"; "required": false; }; "dragToZoom": { "alias": "dragToZoom"; "required": false; }; "panKey": { "alias": "panKey"; "required": false; }; "valueAxis": { "alias": "valueAxis"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoChartZoomAndPanModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChartZoomAndPanModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoChartZoomAndPanModule, never, [typeof DxoChartZoomAndPanComponent], [typeof DxoChartZoomAndPanComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoChartZoomAndPanModule>;
}

export { DxiChartAnnotationComponent, DxiChartAnnotationModule, DxiChartBreakComponent, DxiChartBreakModule, DxiChartConstantLineComponent, DxiChartConstantLineModule, DxiChartPaneComponent, DxiChartPaneModule, DxiChartSeriesComponent, DxiChartSeriesModule, DxiChartStripComponent, DxiChartStripModule, DxiChartValueAxisComponent, DxiChartValueAxisModule, DxoChartAdaptiveLayoutComponent, DxoChartAdaptiveLayoutModule, DxoChartAggregationComponent, DxoChartAggregationIntervalComponent, DxoChartAggregationIntervalModule, DxoChartAggregationModule, DxoChartAnimationComponent, DxoChartAnimationModule, DxoChartAnnotationBorderComponent, DxoChartAnnotationBorderModule, DxoChartAnnotationImageComponent, DxoChartAnnotationImageModule, DxoChartArgumentAxisComponent, DxoChartArgumentAxisModule, DxoChartArgumentFormatComponent, DxoChartArgumentFormatModule, DxoChartAxisConstantLineStyleComponent, DxoChartAxisConstantLineStyleLabelComponent, DxoChartAxisConstantLineStyleLabelModule, DxoChartAxisConstantLineStyleModule, DxoChartAxisLabelComponent, DxoChartAxisLabelModule, DxoChartAxisTitleComponent, DxoChartAxisTitleModule, DxoChartBackgroundColorComponent, DxoChartBackgroundColorModule, DxoChartBorderComponent, DxoChartBorderModule, DxoChartBreakStyleComponent, DxoChartBreakStyleModule, DxoChartChartTitleComponent, DxoChartChartTitleModule, DxoChartChartTitleSubtitleComponent, DxoChartChartTitleSubtitleModule, DxoChartColorComponent, DxoChartColorModule, DxoChartCommonAnnotationSettingsComponent, DxoChartCommonAnnotationSettingsModule, DxoChartCommonAxisSettingsComponent, DxoChartCommonAxisSettingsConstantLineStyleComponent, DxoChartCommonAxisSettingsConstantLineStyleLabelComponent, DxoChartCommonAxisSettingsConstantLineStyleLabelModule, DxoChartCommonAxisSettingsConstantLineStyleModule, DxoChartCommonAxisSettingsLabelComponent, DxoChartCommonAxisSettingsLabelModule, DxoChartCommonAxisSettingsModule, DxoChartCommonAxisSettingsTitleComponent, DxoChartCommonAxisSettingsTitleModule, DxoChartCommonPaneSettingsComponent, DxoChartCommonPaneSettingsModule, DxoChartCommonSeriesSettingsComponent, DxoChartCommonSeriesSettingsHoverStyleComponent, DxoChartCommonSeriesSettingsHoverStyleModule, DxoChartCommonSeriesSettingsLabelComponent, DxoChartCommonSeriesSettingsLabelModule, DxoChartCommonSeriesSettingsModule, DxoChartCommonSeriesSettingsSelectionStyleComponent, DxoChartCommonSeriesSettingsSelectionStyleModule, DxoChartConnectorComponent, DxoChartConnectorModule, DxoChartConstantLineLabelComponent, DxoChartConstantLineLabelModule, DxoChartConstantLineStyleComponent, DxoChartConstantLineStyleModule, DxoChartCrosshairComponent, DxoChartCrosshairModule, DxoChartDataPrepareSettingsComponent, DxoChartDataPrepareSettingsModule, DxoChartDragBoxStyleComponent, DxoChartDragBoxStyleModule, DxoChartExportComponent, DxoChartExportModule, DxoChartFontComponent, DxoChartFontModule, DxoChartFormatComponent, DxoChartFormatModule, DxoChartGridComponent, DxoChartGridModule, DxoChartHatchingComponent, DxoChartHatchingModule, DxoChartHeightComponent, DxoChartHeightModule, DxoChartHorizontalLineComponent, DxoChartHorizontalLineLabelComponent, DxoChartHorizontalLineLabelModule, DxoChartHorizontalLineModule, DxoChartHoverStyleComponent, DxoChartHoverStyleModule, DxoChartImageComponent, DxoChartImageModule, DxoChartLabelComponent, DxoChartLabelModule, DxoChartLegendComponent, DxoChartLegendModule, DxoChartLegendTitleComponent, DxoChartLegendTitleModule, DxoChartLegendTitleSubtitleComponent, DxoChartLegendTitleSubtitleModule, DxoChartLengthComponent, DxoChartLengthModule, DxoChartLoadingIndicatorComponent, DxoChartLoadingIndicatorModule, DxoChartMarginComponent, DxoChartMarginModule, DxoChartMinVisualRangeLengthComponent, DxoChartMinVisualRangeLengthModule, DxoChartMinorGridComponent, DxoChartMinorGridModule, DxoChartMinorTickComponent, DxoChartMinorTickIntervalComponent, DxoChartMinorTickIntervalModule, DxoChartMinorTickModule, DxoChartPaneBorderComponent, DxoChartPaneBorderModule, DxoChartPointBorderComponent, DxoChartPointBorderModule, DxoChartPointComponent, DxoChartPointHoverStyleComponent, DxoChartPointHoverStyleModule, DxoChartPointImageComponent, DxoChartPointImageModule, DxoChartPointModule, DxoChartPointSelectionStyleComponent, DxoChartPointSelectionStyleModule, DxoChartReductionComponent, DxoChartReductionModule, DxoChartScrollBarComponent, DxoChartScrollBarModule, DxoChartSelectionStyleComponent, DxoChartSelectionStyleModule, DxoChartSeriesBorderComponent, DxoChartSeriesBorderModule, DxoChartSeriesTemplateComponent, DxoChartSeriesTemplateModule, DxoChartShadowComponent, DxoChartShadowModule, DxoChartSizeComponent, DxoChartSizeModule, DxoChartStripLabelComponent, DxoChartStripLabelModule, DxoChartStripStyleComponent, DxoChartStripStyleLabelComponent, DxoChartStripStyleLabelModule, DxoChartStripStyleModule, DxoChartSubtitleComponent, DxoChartSubtitleModule, DxoChartTickComponent, DxoChartTickIntervalComponent, DxoChartTickIntervalModule, DxoChartTickModule, DxoChartTitleComponent, DxoChartTitleModule, DxoChartTooltipBorderComponent, DxoChartTooltipBorderModule, DxoChartTooltipComponent, DxoChartTooltipModule, DxoChartUrlComponent, DxoChartUrlModule, DxoChartValueErrorBarComponent, DxoChartValueErrorBarModule, DxoChartVerticalLineComponent, DxoChartVerticalLineModule, DxoChartVisualRangeComponent, DxoChartVisualRangeModule, DxoChartWholeRangeComponent, DxoChartWholeRangeModule, DxoChartWidthComponent, DxoChartWidthModule, DxoChartZoomAndPanComponent, DxoChartZoomAndPanModule };
//# sourceMappingURL=index.d.ts.map
