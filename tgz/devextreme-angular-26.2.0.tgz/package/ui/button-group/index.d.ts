import * as i0 from '@angular/core';
import { OnDestroy, OnChanges, DoCheck, QueryList, EventEmitter, ElementRef, NgZone, TransferState, SimpleChanges } from '@angular/core';
import DxButtonGroup, { dxButtonGroupItem, ContentReadyEvent, DisposingEvent, InitializedEvent, ItemClickEvent, OptionChangedEvent, SelectionChangedEvent } from 'devextreme/ui/button_group';
import { SingleMultipleOrNone, ButtonStyle } from 'devextreme/common';
import * as i3 from 'devextreme-angular/core';
import { DxComponent, CollectionNestedOption, DxTemplateHost, WatcherHelper, IterableDifferHelper, NestedOptionHost } from 'devextreme-angular/core';
import * as i1 from 'devextreme-angular/ui/nested';
import * as i2 from 'devextreme-angular/ui/button-group/nested';
export * from 'devextreme-angular/ui/button-group/nested';
import * as button_group_types from 'devextreme/ui/button_group_types';
export { button_group_types as DxButtonGroupTypes };

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

/**
 * [descr:dxButtonGroup]

 */
declare class DxButtonGroupComponent extends DxComponent implements OnDestroy, OnChanges, DoCheck {
    private _watcherHelper;
    private _idh;
    set _itemsContentChildren(value: QueryList<CollectionNestedOption>);
    instance: DxButtonGroup;
    /**
     * [descr:WidgetOptions.accessKey]
    
     */
    get accessKey(): string | undefined;
    set accessKey(value: string | undefined);
    /**
     * [descr:WidgetOptions.activeStateEnabled]
    
     */
    get activeStateEnabled(): boolean;
    set activeStateEnabled(value: boolean);
    /**
     * [descr:dxButtonGroupOptions.buttonTemplate]
    
     */
    get buttonTemplate(): any;
    set buttonTemplate(value: any);
    /**
     * [descr:WidgetOptions.disabled]
    
     */
    get disabled(): boolean;
    set disabled(value: boolean);
    /**
     * [descr:DOMComponentOptions.elementAttr]
    
     */
    get elementAttr(): Record<string, any>;
    set elementAttr(value: Record<string, any>);
    /**
     * [descr:dxButtonGroupOptions.focusStateEnabled]
    
     */
    get focusStateEnabled(): boolean;
    set focusStateEnabled(value: boolean);
    /**
     * [descr:DOMComponentOptions.height]
    
     */
    get height(): number | string | undefined;
    set height(value: number | string | undefined);
    /**
     * [descr:WidgetOptions.hint]
    
     */
    get hint(): string | undefined;
    set hint(value: string | undefined);
    /**
     * [descr:dxButtonGroupOptions.hoverStateEnabled]
    
     */
    get hoverStateEnabled(): boolean;
    set hoverStateEnabled(value: boolean);
    /**
     * [descr:dxButtonGroupOptions.items]
    
     */
    get items(): Array<dxButtonGroupItem>;
    set items(value: Array<dxButtonGroupItem>);
    /**
     * [descr:dxButtonGroupOptions.keyExpr]
    
     */
    get keyExpr(): ((item: any) => any) | string;
    set keyExpr(value: ((item: any) => any) | string);
    /**
     * [descr:DOMComponentOptions.rtlEnabled]
    
     */
    get rtlEnabled(): boolean;
    set rtlEnabled(value: boolean);
    /**
     * [descr:dxButtonGroupOptions.selectedItemKeys]
    
     */
    get selectedItemKeys(): Array<any>;
    set selectedItemKeys(value: Array<any>);
    /**
     * [descr:dxButtonGroupOptions.selectedItems]
    
     */
    get selectedItems(): Array<any>;
    set selectedItems(value: Array<any>);
    /**
     * [descr:dxButtonGroupOptions.selectionMode]
    
     */
    get selectionMode(): SingleMultipleOrNone;
    set selectionMode(value: SingleMultipleOrNone);
    /**
     * [descr:dxButtonGroupOptions.stylingMode]
    
     */
    get stylingMode(): ButtonStyle;
    set stylingMode(value: ButtonStyle);
    /**
     * [descr:WidgetOptions.tabIndex]
    
     */
    get tabIndex(): number;
    set tabIndex(value: number);
    /**
     * [descr:WidgetOptions.visible]
    
     */
    get visible(): boolean;
    set visible(value: boolean);
    /**
     * [descr:DOMComponentOptions.width]
    
     */
    get width(): number | string | undefined;
    set width(value: number | string | undefined);
    /**
    
     * [descr:dxButtonGroupOptions.onContentReady]
    
    
     */
    onContentReady: EventEmitter<ContentReadyEvent>;
    /**
    
     * [descr:dxButtonGroupOptions.onDisposing]
    
    
     */
    onDisposing: EventEmitter<DisposingEvent>;
    /**
    
     * [descr:dxButtonGroupOptions.onInitialized]
    
    
     */
    onInitialized: EventEmitter<InitializedEvent>;
    /**
    
     * [descr:dxButtonGroupOptions.onItemClick]
    
    
     */
    onItemClick: EventEmitter<ItemClickEvent>;
    /**
    
     * [descr:dxButtonGroupOptions.onOptionChanged]
    
    
     */
    onOptionChanged: EventEmitter<OptionChangedEvent>;
    /**
    
     * [descr:dxButtonGroupOptions.onSelectionChanged]
    
    
     */
    onSelectionChanged: EventEmitter<SelectionChangedEvent>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    accessKeyChange: EventEmitter<string | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    activeStateEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    buttonTemplateChange: EventEmitter<any>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    disabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    elementAttrChange: EventEmitter<Record<string, any>>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    focusStateEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    heightChange: EventEmitter<number | string | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    hintChange: EventEmitter<string | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    hoverStateEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    itemsChange: EventEmitter<Array<dxButtonGroupItem>>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    keyExprChange: EventEmitter<((item: any) => any) | string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    rtlEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    selectedItemKeysChange: EventEmitter<Array<any>>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    selectedItemsChange: EventEmitter<Array<any>>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    selectionModeChange: EventEmitter<SingleMultipleOrNone>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    stylingModeChange: EventEmitter<ButtonStyle>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    tabIndexChange: EventEmitter<number>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    visibleChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    widthChange: EventEmitter<number | string | undefined>;
    constructor(elementRef: ElementRef, ngZone: NgZone, templateHost: DxTemplateHost, _watcherHelper: WatcherHelper, _idh: IterableDifferHelper, optionHost: NestedOptionHost, transferState: TransferState, platformId: any);
    protected _createInstance(element: any, options: any): DxButtonGroup;
    ngOnDestroy(): void;
    ngOnChanges(changes: SimpleChanges): void;
    setupChanges(prop: string, changes: SimpleChanges): void;
    ngDoCheck(): void;
    _setOption(name: string, value: any): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxButtonGroupComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxButtonGroupComponent, "dx-button-group", never, { "accessKey": { "alias": "accessKey"; "required": false; }; "activeStateEnabled": { "alias": "activeStateEnabled"; "required": false; }; "buttonTemplate": { "alias": "buttonTemplate"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "elementAttr": { "alias": "elementAttr"; "required": false; }; "focusStateEnabled": { "alias": "focusStateEnabled"; "required": false; }; "height": { "alias": "height"; "required": false; }; "hint": { "alias": "hint"; "required": false; }; "hoverStateEnabled": { "alias": "hoverStateEnabled"; "required": false; }; "items": { "alias": "items"; "required": false; }; "keyExpr": { "alias": "keyExpr"; "required": false; }; "rtlEnabled": { "alias": "rtlEnabled"; "required": false; }; "selectedItemKeys": { "alias": "selectedItemKeys"; "required": false; }; "selectedItems": { "alias": "selectedItems"; "required": false; }; "selectionMode": { "alias": "selectionMode"; "required": false; }; "stylingMode": { "alias": "stylingMode"; "required": false; }; "tabIndex": { "alias": "tabIndex"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, { "onContentReady": "onContentReady"; "onDisposing": "onDisposing"; "onInitialized": "onInitialized"; "onItemClick": "onItemClick"; "onOptionChanged": "onOptionChanged"; "onSelectionChanged": "onSelectionChanged"; "accessKeyChange": "accessKeyChange"; "activeStateEnabledChange": "activeStateEnabledChange"; "buttonTemplateChange": "buttonTemplateChange"; "disabledChange": "disabledChange"; "elementAttrChange": "elementAttrChange"; "focusStateEnabledChange": "focusStateEnabledChange"; "heightChange": "heightChange"; "hintChange": "hintChange"; "hoverStateEnabledChange": "hoverStateEnabledChange"; "itemsChange": "itemsChange"; "keyExprChange": "keyExprChange"; "rtlEnabledChange": "rtlEnabledChange"; "selectedItemKeysChange": "selectedItemKeysChange"; "selectedItemsChange": "selectedItemsChange"; "selectionModeChange": "selectionModeChange"; "stylingModeChange": "stylingModeChange"; "tabIndexChange": "tabIndexChange"; "visibleChange": "visibleChange"; "widthChange": "widthChange"; }, ["_itemsContentChildren"], never, true, never>;
}
declare class DxButtonGroupModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxButtonGroupModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxButtonGroupModule, never, [typeof DxButtonGroupComponent, typeof i1.DxiItemModule, typeof i2.DxiButtonGroupItemModule, typeof i3.DxIntegrationModule, typeof i3.DxTemplateModule], [typeof DxButtonGroupComponent, typeof i1.DxiItemModule, typeof i2.DxiButtonGroupItemModule, typeof i3.DxTemplateModule]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxButtonGroupModule>;
}

export { DxButtonGroupComponent, DxButtonGroupModule };
//# sourceMappingURL=index.d.ts.map
