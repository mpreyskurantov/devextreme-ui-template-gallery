import * as i0 from '@angular/core';
import { OnDestroy, OnChanges, DoCheck, EventEmitter, ElementRef, NgZone, TransferState, SimpleChanges } from '@angular/core';
import DxFunnel, { FunnelAlgorithm, dxFunnelItem, FunnelLegendItem, DisposingEvent, DrawnEvent, ExportedEvent, ExportingEvent, FileSavingEvent, HoverChangedEvent, IncidentOccurredEvent, InitializedEvent, ItemClickEvent, LegendClickEvent, OptionChangedEvent, SelectionChangedEvent } from 'devextreme/viz/funnel';
import DataSource, { DataSourceOptions } from 'devextreme/data/data_source';
import { Store } from 'devextreme/data/store';
import { ExportFormat, HorizontalEdge, HorizontalAlignment, Position, Orientation, VerticalEdge, SingleMultipleOrNone } from 'devextreme/common';
import { HatchDirection, DashStyle, Font, LabelPosition, TextOverflow, WordWrap, Palette, PaletteExtensionMode, ShiftLabelOverlap, Theme } from 'devextreme/common/charts';
import { Format } from 'devextreme/common/core/localization';
import * as i3 from 'devextreme-angular/core';
import { DxComponent, DxTemplateHost, WatcherHelper, IterableDifferHelper, NestedOptionHost } from 'devextreme-angular/core';
import * as i1 from 'devextreme-angular/ui/nested';
import * as i2 from 'devextreme-angular/ui/funnel/nested';
export * from 'devextreme-angular/ui/funnel/nested';
import * as funnel_types from 'devextreme/viz/funnel_types';
export { funnel_types as DxFunnelTypes };

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

/**
 * [descr:dxFunnel]

 */
declare class DxFunnelComponent extends DxComponent implements OnDestroy, OnChanges, DoCheck {
    private _watcherHelper;
    private _idh;
    instance: DxFunnel;
    /**
     * [descr:dxFunnelOptions.adaptiveLayout]
    
     */
    get adaptiveLayout(): {
        height?: number;
        keepLabels?: boolean;
        width?: number;
    };
    set adaptiveLayout(value: {
        height?: number;
        keepLabels?: boolean;
        width?: number;
    });
    /**
     * [descr:dxFunnelOptions.algorithm]
    
     */
    get algorithm(): FunnelAlgorithm;
    set algorithm(value: FunnelAlgorithm);
    /**
     * [descr:dxFunnelOptions.argumentField]
    
     */
    get argumentField(): string;
    set argumentField(value: string);
    /**
     * [descr:dxFunnelOptions.colorField]
    
     */
    get colorField(): string;
    set colorField(value: string);
    /**
     * [descr:dxFunnelOptions.dataSource]
    
     */
    get dataSource(): Array<any> | DataSource | DataSourceOptions | null | Store | string;
    set dataSource(value: Array<any> | DataSource | DataSourceOptions | null | Store | string);
    /**
     * [descr:BaseWidgetOptions.disabled]
    
     */
    get disabled(): boolean;
    set disabled(value: boolean);
    /**
     * [descr:DOMComponentOptions.elementAttr]
    
     */
    get elementAttr(): Record<string, any>;
    set elementAttr(value: Record<string, any>);
    /**
     * [descr:BaseWidgetOptions.encodeHtml]
    
     */
    get encodeHtml(): boolean;
    set encodeHtml(value: boolean);
    /**
     * [descr:BaseWidgetOptions.export]
    
     */
    get export(): {
        backgroundColor?: string;
        enabled?: boolean;
        fileName?: string;
        formats?: Array<ExportFormat>;
        margin?: number;
        printingEnabled?: boolean;
        svgToCanvas?: ((svg: any, canvas: any) => any) | undefined;
    };
    set export(value: {
        backgroundColor?: string;
        enabled?: boolean;
        fileName?: string;
        formats?: Array<ExportFormat>;
        margin?: number;
        printingEnabled?: boolean;
        svgToCanvas?: ((svg: any, canvas: any) => any) | undefined;
    });
    /**
     * [descr:dxFunnelOptions.hoverEnabled]
    
     */
    get hoverEnabled(): boolean;
    set hoverEnabled(value: boolean);
    /**
     * [descr:dxFunnelOptions.inverted]
    
     */
    get inverted(): boolean;
    set inverted(value: boolean);
    /**
     * [descr:dxFunnelOptions.item]
    
     */
    get item(): {
        border?: {
            color?: string | undefined;
            visible?: boolean | undefined;
            width?: number | undefined;
        };
        hoverStyle?: {
            border?: {
                color?: string | undefined;
                visible?: boolean | undefined;
                width?: number | undefined;
            };
            hatching?: {
                direction?: HatchDirection;
                opacity?: number;
                step?: number;
                width?: number;
            };
        };
        selectionStyle?: {
            border?: {
                color?: string | undefined;
                visible?: boolean | undefined;
                width?: number | undefined;
            };
            hatching?: {
                direction?: HatchDirection;
                opacity?: number;
                step?: number;
                width?: number;
            };
        };
    };
    set item(value: {
        border?: {
            color?: string | undefined;
            visible?: boolean | undefined;
            width?: number | undefined;
        };
        hoverStyle?: {
            border?: {
                color?: string | undefined;
                visible?: boolean | undefined;
                width?: number | undefined;
            };
            hatching?: {
                direction?: HatchDirection;
                opacity?: number;
                step?: number;
                width?: number;
            };
        };
        selectionStyle?: {
            border?: {
                color?: string | undefined;
                visible?: boolean | undefined;
                width?: number | undefined;
            };
            hatching?: {
                direction?: HatchDirection;
                opacity?: number;
                step?: number;
                width?: number;
            };
        };
    });
    /**
     * [descr:dxFunnelOptions.label]
    
     */
    get label(): {
        backgroundColor?: string;
        border?: {
            color?: string;
            dashStyle?: DashStyle;
            visible?: boolean;
            width?: number;
        };
        connector?: {
            color?: string | undefined;
            opacity?: number;
            visible?: boolean;
            width?: number;
        };
        customizeText?: ((itemInfo: {
            item: dxFunnelItem;
            percent: number;
            percentText: string;
            value: number;
            valueText: string;
        }) => string);
        font?: Font;
        format?: Format | undefined;
        horizontalAlignment?: HorizontalEdge;
        horizontalOffset?: number;
        position?: LabelPosition;
        showForZeroValues?: boolean;
        textOverflow?: TextOverflow;
        visible?: boolean;
        wordWrap?: WordWrap;
    };
    set label(value: {
        backgroundColor?: string;
        border?: {
            color?: string;
            dashStyle?: DashStyle;
            visible?: boolean;
            width?: number;
        };
        connector?: {
            color?: string | undefined;
            opacity?: number;
            visible?: boolean;
            width?: number;
        };
        customizeText?: ((itemInfo: {
            item: dxFunnelItem;
            percent: number;
            percentText: string;
            value: number;
            valueText: string;
        }) => string);
        font?: Font;
        format?: Format | undefined;
        horizontalAlignment?: HorizontalEdge;
        horizontalOffset?: number;
        position?: LabelPosition;
        showForZeroValues?: boolean;
        textOverflow?: TextOverflow;
        visible?: boolean;
        wordWrap?: WordWrap;
    });
    /**
     * [descr:dxFunnelOptions.legend]
    
     */
    get legend(): {
        backgroundColor?: string | undefined;
        border?: {
            color?: string;
            cornerRadius?: number;
            dashStyle?: DashStyle;
            opacity?: number | undefined;
            visible?: boolean;
            width?: number;
        };
        columnCount?: number;
        columnItemSpacing?: number;
        customizeHint?: ((itemInfo: {
            item: dxFunnelItem;
            text: string;
        }) => string);
        customizeItems?: ((items: Array<FunnelLegendItem>) => Array<FunnelLegendItem>);
        customizeText?: ((itemInfo: {
            item: dxFunnelItem;
            text: string;
        }) => string);
        font?: Font;
        horizontalAlignment?: HorizontalAlignment;
        itemsAlignment?: HorizontalAlignment | undefined;
        itemTextPosition?: Position | undefined;
        margin?: number | {
            bottom?: number;
            left?: number;
            right?: number;
            top?: number;
        };
        markerSize?: number;
        markerTemplate?: any;
        orientation?: Orientation | undefined;
        paddingLeftRight?: number;
        paddingTopBottom?: number;
        rowCount?: number;
        rowItemSpacing?: number;
        title?: string | {
            font?: Font;
            horizontalAlignment?: HorizontalAlignment | undefined;
            margin?: {
                bottom?: number;
                left?: number;
                right?: number;
                top?: number;
            };
            placeholderSize?: number | undefined;
            subtitle?: string | {
                font?: Font;
                offset?: number;
                text?: string | undefined;
            };
            text?: string | undefined;
            verticalAlignment?: VerticalEdge;
        };
        verticalAlignment?: VerticalEdge;
        visible?: boolean;
    };
    set legend(value: {
        backgroundColor?: string | undefined;
        border?: {
            color?: string;
            cornerRadius?: number;
            dashStyle?: DashStyle;
            opacity?: number | undefined;
            visible?: boolean;
            width?: number;
        };
        columnCount?: number;
        columnItemSpacing?: number;
        customizeHint?: ((itemInfo: {
            item: dxFunnelItem;
            text: string;
        }) => string);
        customizeItems?: ((items: Array<FunnelLegendItem>) => Array<FunnelLegendItem>);
        customizeText?: ((itemInfo: {
            item: dxFunnelItem;
            text: string;
        }) => string);
        font?: Font;
        horizontalAlignment?: HorizontalAlignment;
        itemsAlignment?: HorizontalAlignment | undefined;
        itemTextPosition?: Position | undefined;
        margin?: number | {
            bottom?: number;
            left?: number;
            right?: number;
            top?: number;
        };
        markerSize?: number;
        markerTemplate?: any;
        orientation?: Orientation | undefined;
        paddingLeftRight?: number;
        paddingTopBottom?: number;
        rowCount?: number;
        rowItemSpacing?: number;
        title?: string | {
            font?: Font;
            horizontalAlignment?: HorizontalAlignment | undefined;
            margin?: {
                bottom?: number;
                left?: number;
                right?: number;
                top?: number;
            };
            placeholderSize?: number | undefined;
            subtitle?: string | {
                font?: Font;
                offset?: number;
                text?: string | undefined;
            };
            text?: string | undefined;
            verticalAlignment?: VerticalEdge;
        };
        verticalAlignment?: VerticalEdge;
        visible?: boolean;
    });
    /**
     * [descr:BaseWidgetOptions.loadingIndicator]
    
     */
    get loadingIndicator(): {
        backgroundColor?: string;
        enabled?: boolean;
        font?: Font;
        show?: boolean;
        text?: string;
    };
    set loadingIndicator(value: {
        backgroundColor?: string;
        enabled?: boolean;
        font?: Font;
        show?: boolean;
        text?: string;
    });
    /**
     * [descr:BaseWidgetOptions.margin]
    
     */
    get margin(): {
        bottom?: number;
        left?: number;
        right?: number;
        top?: number;
    };
    set margin(value: {
        bottom?: number;
        left?: number;
        right?: number;
        top?: number;
    });
    /**
     * [descr:dxFunnelOptions.neckHeight]
    
     */
    get neckHeight(): number;
    set neckHeight(value: number);
    /**
     * [descr:dxFunnelOptions.neckWidth]
    
     */
    get neckWidth(): number;
    set neckWidth(value: number);
    /**
     * [descr:dxFunnelOptions.palette]
    
     */
    get palette(): Array<string> | Palette;
    set palette(value: Array<string> | Palette);
    /**
     * [descr:dxFunnelOptions.paletteExtensionMode]
    
     */
    get paletteExtensionMode(): PaletteExtensionMode;
    set paletteExtensionMode(value: PaletteExtensionMode);
    /**
     * [descr:BaseWidgetOptions.pathModified]
    
     */
    get pathModified(): boolean;
    set pathModified(value: boolean);
    /**
     * [descr:BaseWidgetOptions.redrawOnResize]
    
     */
    get redrawOnResize(): boolean;
    set redrawOnResize(value: boolean);
    /**
     * [descr:dxFunnelOptions.resolveLabelOverlapping]
    
     */
    get resolveLabelOverlapping(): ShiftLabelOverlap;
    set resolveLabelOverlapping(value: ShiftLabelOverlap);
    /**
     * [descr:BaseWidgetOptions.rtlEnabled]
    
     */
    get rtlEnabled(): boolean;
    set rtlEnabled(value: boolean);
    /**
     * [descr:dxFunnelOptions.selectionMode]
    
     */
    get selectionMode(): SingleMultipleOrNone;
    set selectionMode(value: SingleMultipleOrNone);
    /**
     * [descr:BaseWidgetOptions.size]
    
     */
    get size(): {
        height?: number | undefined;
        width?: number | undefined;
    };
    set size(value: {
        height?: number | undefined;
        width?: number | undefined;
    });
    /**
     * [descr:dxFunnelOptions.sortData]
    
     */
    get sortData(): boolean;
    set sortData(value: boolean);
    /**
     * [descr:BaseWidgetOptions.theme]
    
     */
    get theme(): Theme;
    set theme(value: Theme);
    /**
     * [descr:BaseWidgetOptions.title]
    
     */
    get title(): string | {
        font?: Font;
        horizontalAlignment?: HorizontalAlignment;
        margin?: number | {
            bottom?: number;
            left?: number;
            right?: number;
            top?: number;
        };
        placeholderSize?: number | undefined;
        subtitle?: string | {
            font?: Font;
            offset?: number;
            text?: string | undefined;
            textOverflow?: TextOverflow;
            wordWrap?: WordWrap;
        };
        text?: string | undefined;
        textOverflow?: TextOverflow;
        verticalAlignment?: VerticalEdge;
        wordWrap?: WordWrap;
    };
    set title(value: string | {
        font?: Font;
        horizontalAlignment?: HorizontalAlignment;
        margin?: number | {
            bottom?: number;
            left?: number;
            right?: number;
            top?: number;
        };
        placeholderSize?: number | undefined;
        subtitle?: string | {
            font?: Font;
            offset?: number;
            text?: string | undefined;
            textOverflow?: TextOverflow;
            wordWrap?: WordWrap;
        };
        text?: string | undefined;
        textOverflow?: TextOverflow;
        verticalAlignment?: VerticalEdge;
        wordWrap?: WordWrap;
    });
    /**
     * [descr:dxFunnelOptions.tooltip]
    
     */
    get tooltip(): {
        arrowLength?: number;
        border?: {
            color?: string;
            dashStyle?: DashStyle;
            opacity?: number | undefined;
            visible?: boolean;
            width?: number;
        };
        color?: string;
        container?: any | string | undefined;
        contentTemplate?: any;
        cornerRadius?: number;
        customizeTooltip?: ((info: {
            item: dxFunnelItem;
            percent: number;
            percentText: string;
            value: number;
            valueText: string;
        }) => Record<string, any>) | undefined;
        enabled?: boolean;
        font?: Font;
        format?: Format | undefined;
        opacity?: number | undefined;
        paddingLeftRight?: number;
        paddingTopBottom?: number;
        shadow?: {
            blur?: number;
            color?: string;
            offsetX?: number;
            offsetY?: number;
            opacity?: number;
        };
        zIndex?: number | undefined;
    };
    set tooltip(value: {
        arrowLength?: number;
        border?: {
            color?: string;
            dashStyle?: DashStyle;
            opacity?: number | undefined;
            visible?: boolean;
            width?: number;
        };
        color?: string;
        container?: any | string | undefined;
        contentTemplate?: any;
        cornerRadius?: number;
        customizeTooltip?: ((info: {
            item: dxFunnelItem;
            percent: number;
            percentText: string;
            value: number;
            valueText: string;
        }) => Record<string, any>) | undefined;
        enabled?: boolean;
        font?: Font;
        format?: Format | undefined;
        opacity?: number | undefined;
        paddingLeftRight?: number;
        paddingTopBottom?: number;
        shadow?: {
            blur?: number;
            color?: string;
            offsetX?: number;
            offsetY?: number;
            opacity?: number;
        };
        zIndex?: number | undefined;
    });
    /**
     * [descr:dxFunnelOptions.valueField]
    
     */
    get valueField(): string;
    set valueField(value: string);
    /**
    
     * [descr:dxFunnelOptions.onDisposing]
    
    
     */
    onDisposing: EventEmitter<DisposingEvent>;
    /**
    
     * [descr:dxFunnelOptions.onDrawn]
    
    
     */
    onDrawn: EventEmitter<DrawnEvent>;
    /**
    
     * [descr:dxFunnelOptions.onExported]
    
    
     */
    onExported: EventEmitter<ExportedEvent>;
    /**
    
     * [descr:dxFunnelOptions.onExporting]
    
    
     */
    onExporting: EventEmitter<ExportingEvent>;
    /**
    
     * [descr:dxFunnelOptions.onFileSaving]
    
    
     */
    onFileSaving: EventEmitter<FileSavingEvent>;
    /**
    
     * [descr:dxFunnelOptions.onHoverChanged]
    
    
     */
    onHoverChanged: EventEmitter<HoverChangedEvent>;
    /**
    
     * [descr:dxFunnelOptions.onIncidentOccurred]
    
    
     */
    onIncidentOccurred: EventEmitter<IncidentOccurredEvent>;
    /**
    
     * [descr:dxFunnelOptions.onInitialized]
    
    
     */
    onInitialized: EventEmitter<InitializedEvent>;
    /**
    
     * [descr:dxFunnelOptions.onItemClick]
    
    
     */
    onItemClick: EventEmitter<ItemClickEvent>;
    /**
    
     * [descr:dxFunnelOptions.onLegendClick]
    
    
     */
    onLegendClick: EventEmitter<LegendClickEvent>;
    /**
    
     * [descr:dxFunnelOptions.onOptionChanged]
    
    
     */
    onOptionChanged: EventEmitter<OptionChangedEvent>;
    /**
    
     * [descr:dxFunnelOptions.onSelectionChanged]
    
    
     */
    onSelectionChanged: EventEmitter<SelectionChangedEvent>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    adaptiveLayoutChange: EventEmitter<{
        height?: number;
        keepLabels?: boolean;
        width?: number;
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    algorithmChange: EventEmitter<FunnelAlgorithm>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    argumentFieldChange: EventEmitter<string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    colorFieldChange: EventEmitter<string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    dataSourceChange: EventEmitter<Array<any> | DataSource | DataSourceOptions | null | Store | string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    disabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    elementAttrChange: EventEmitter<Record<string, any>>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    encodeHtmlChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    exportChange: EventEmitter<{
        backgroundColor?: string;
        enabled?: boolean;
        fileName?: string;
        formats?: Array<ExportFormat>;
        margin?: number;
        printingEnabled?: boolean;
        svgToCanvas?: ((svg: any, canvas: any) => any) | undefined;
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    hoverEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    invertedChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    itemChange: EventEmitter<{
        border?: {
            color?: string | undefined;
            visible?: boolean | undefined;
            width?: number | undefined;
        };
        hoverStyle?: {
            border?: {
                color?: string | undefined;
                visible?: boolean | undefined;
                width?: number | undefined;
            };
            hatching?: {
                direction?: HatchDirection;
                opacity?: number;
                step?: number;
                width?: number;
            };
        };
        selectionStyle?: {
            border?: {
                color?: string | undefined;
                visible?: boolean | undefined;
                width?: number | undefined;
            };
            hatching?: {
                direction?: HatchDirection;
                opacity?: number;
                step?: number;
                width?: number;
            };
        };
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    labelChange: EventEmitter<{
        backgroundColor?: string;
        border?: {
            color?: string;
            dashStyle?: DashStyle;
            visible?: boolean;
            width?: number;
        };
        connector?: {
            color?: string | undefined;
            opacity?: number;
            visible?: boolean;
            width?: number;
        };
        customizeText?: ((itemInfo: {
            item: dxFunnelItem;
            percent: number;
            percentText: string;
            value: number;
            valueText: string;
        }) => string);
        font?: Font;
        format?: Format | undefined;
        horizontalAlignment?: HorizontalEdge;
        horizontalOffset?: number;
        position?: LabelPosition;
        showForZeroValues?: boolean;
        textOverflow?: TextOverflow;
        visible?: boolean;
        wordWrap?: WordWrap;
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    legendChange: EventEmitter<{
        backgroundColor?: string | undefined;
        border?: {
            color?: string;
            cornerRadius?: number;
            dashStyle?: DashStyle;
            opacity?: number | undefined;
            visible?: boolean;
            width?: number;
        };
        columnCount?: number;
        columnItemSpacing?: number;
        customizeHint?: ((itemInfo: {
            item: dxFunnelItem;
            text: string;
        }) => string);
        customizeItems?: ((items: Array<FunnelLegendItem>) => Array<FunnelLegendItem>);
        customizeText?: ((itemInfo: {
            item: dxFunnelItem;
            text: string;
        }) => string);
        font?: Font;
        horizontalAlignment?: HorizontalAlignment;
        itemsAlignment?: HorizontalAlignment | undefined;
        itemTextPosition?: Position | undefined;
        margin?: number | {
            bottom?: number;
            left?: number;
            right?: number;
            top?: number;
        };
        markerSize?: number;
        markerTemplate?: any;
        orientation?: Orientation | undefined;
        paddingLeftRight?: number;
        paddingTopBottom?: number;
        rowCount?: number;
        rowItemSpacing?: number;
        title?: string | {
            font?: Font;
            horizontalAlignment?: HorizontalAlignment | undefined;
            margin?: {
                bottom?: number;
                left?: number;
                right?: number;
                top?: number;
            };
            placeholderSize?: number | undefined;
            subtitle?: string | {
                font?: Font;
                offset?: number;
                text?: string | undefined;
            };
            text?: string | undefined;
            verticalAlignment?: VerticalEdge;
        };
        verticalAlignment?: VerticalEdge;
        visible?: boolean;
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    loadingIndicatorChange: EventEmitter<{
        backgroundColor?: string;
        enabled?: boolean;
        font?: Font;
        show?: boolean;
        text?: string;
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    marginChange: EventEmitter<{
        bottom?: number;
        left?: number;
        right?: number;
        top?: number;
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    neckHeightChange: EventEmitter<number>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    neckWidthChange: EventEmitter<number>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    paletteChange: EventEmitter<Array<string> | Palette>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    paletteExtensionModeChange: EventEmitter<PaletteExtensionMode>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    pathModifiedChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    redrawOnResizeChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    resolveLabelOverlappingChange: EventEmitter<ShiftLabelOverlap>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    rtlEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    selectionModeChange: EventEmitter<SingleMultipleOrNone>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    sizeChange: EventEmitter<{
        height?: number | undefined;
        width?: number | undefined;
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    sortDataChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    themeChange: EventEmitter<Theme>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    titleChange: EventEmitter<string | {
        font?: Font;
        horizontalAlignment?: HorizontalAlignment;
        margin?: number | {
            bottom?: number;
            left?: number;
            right?: number;
            top?: number;
        };
        placeholderSize?: number | undefined;
        subtitle?: string | {
            font?: Font;
            offset?: number;
            text?: string | undefined;
            textOverflow?: TextOverflow;
            wordWrap?: WordWrap;
        };
        text?: string | undefined;
        textOverflow?: TextOverflow;
        verticalAlignment?: VerticalEdge;
        wordWrap?: WordWrap;
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    tooltipChange: EventEmitter<{
        arrowLength?: number;
        border?: {
            color?: string;
            dashStyle?: DashStyle;
            opacity?: number | undefined;
            visible?: boolean;
            width?: number;
        };
        color?: string;
        container?: any | string | undefined;
        contentTemplate?: any;
        cornerRadius?: number;
        customizeTooltip?: ((info: {
            item: dxFunnelItem;
            percent: number;
            percentText: string;
            value: number;
            valueText: string;
        }) => Record<string, any>) | undefined;
        enabled?: boolean;
        font?: Font;
        format?: Format | undefined;
        opacity?: number | undefined;
        paddingLeftRight?: number;
        paddingTopBottom?: number;
        shadow?: {
            blur?: number;
            color?: string;
            offsetX?: number;
            offsetY?: number;
            opacity?: number;
        };
        zIndex?: number | undefined;
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    valueFieldChange: EventEmitter<string>;
    constructor(elementRef: ElementRef, ngZone: NgZone, templateHost: DxTemplateHost, _watcherHelper: WatcherHelper, _idh: IterableDifferHelper, optionHost: NestedOptionHost, transferState: TransferState, platformId: any);
    protected _createInstance(element: any, options: any): DxFunnel;
    ngOnDestroy(): void;
    ngOnChanges(changes: SimpleChanges): void;
    setupChanges(prop: string, changes: SimpleChanges): void;
    ngDoCheck(): void;
    _setOption(name: string, value: any): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxFunnelComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxFunnelComponent, "dx-funnel", never, { "adaptiveLayout": { "alias": "adaptiveLayout"; "required": false; }; "algorithm": { "alias": "algorithm"; "required": false; }; "argumentField": { "alias": "argumentField"; "required": false; }; "colorField": { "alias": "colorField"; "required": false; }; "dataSource": { "alias": "dataSource"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "elementAttr": { "alias": "elementAttr"; "required": false; }; "encodeHtml": { "alias": "encodeHtml"; "required": false; }; "export": { "alias": "export"; "required": false; }; "hoverEnabled": { "alias": "hoverEnabled"; "required": false; }; "inverted": { "alias": "inverted"; "required": false; }; "item": { "alias": "item"; "required": false; }; "label": { "alias": "label"; "required": false; }; "legend": { "alias": "legend"; "required": false; }; "loadingIndicator": { "alias": "loadingIndicator"; "required": false; }; "margin": { "alias": "margin"; "required": false; }; "neckHeight": { "alias": "neckHeight"; "required": false; }; "neckWidth": { "alias": "neckWidth"; "required": false; }; "palette": { "alias": "palette"; "required": false; }; "paletteExtensionMode": { "alias": "paletteExtensionMode"; "required": false; }; "pathModified": { "alias": "pathModified"; "required": false; }; "redrawOnResize": { "alias": "redrawOnResize"; "required": false; }; "resolveLabelOverlapping": { "alias": "resolveLabelOverlapping"; "required": false; }; "rtlEnabled": { "alias": "rtlEnabled"; "required": false; }; "selectionMode": { "alias": "selectionMode"; "required": false; }; "size": { "alias": "size"; "required": false; }; "sortData": { "alias": "sortData"; "required": false; }; "theme": { "alias": "theme"; "required": false; }; "title": { "alias": "title"; "required": false; }; "tooltip": { "alias": "tooltip"; "required": false; }; "valueField": { "alias": "valueField"; "required": false; }; }, { "onDisposing": "onDisposing"; "onDrawn": "onDrawn"; "onExported": "onExported"; "onExporting": "onExporting"; "onFileSaving": "onFileSaving"; "onHoverChanged": "onHoverChanged"; "onIncidentOccurred": "onIncidentOccurred"; "onInitialized": "onInitialized"; "onItemClick": "onItemClick"; "onLegendClick": "onLegendClick"; "onOptionChanged": "onOptionChanged"; "onSelectionChanged": "onSelectionChanged"; "adaptiveLayoutChange": "adaptiveLayoutChange"; "algorithmChange": "algorithmChange"; "argumentFieldChange": "argumentFieldChange"; "colorFieldChange": "colorFieldChange"; "dataSourceChange": "dataSourceChange"; "disabledChange": "disabledChange"; "elementAttrChange": "elementAttrChange"; "encodeHtmlChange": "encodeHtmlChange"; "exportChange": "exportChange"; "hoverEnabledChange": "hoverEnabledChange"; "invertedChange": "invertedChange"; "itemChange": "itemChange"; "labelChange": "labelChange"; "legendChange": "legendChange"; "loadingIndicatorChange": "loadingIndicatorChange"; "marginChange": "marginChange"; "neckHeightChange": "neckHeightChange"; "neckWidthChange": "neckWidthChange"; "paletteChange": "paletteChange"; "paletteExtensionModeChange": "paletteExtensionModeChange"; "pathModifiedChange": "pathModifiedChange"; "redrawOnResizeChange": "redrawOnResizeChange"; "resolveLabelOverlappingChange": "resolveLabelOverlappingChange"; "rtlEnabledChange": "rtlEnabledChange"; "selectionModeChange": "selectionModeChange"; "sizeChange": "sizeChange"; "sortDataChange": "sortDataChange"; "themeChange": "themeChange"; "titleChange": "titleChange"; "tooltipChange": "tooltipChange"; "valueFieldChange": "valueFieldChange"; }, never, never, true, never>;
}
declare class DxFunnelModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxFunnelModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxFunnelModule, never, [typeof DxFunnelComponent, typeof i1.DxoAdaptiveLayoutModule, typeof i1.DxoExportModule, typeof i1.DxoItemModule, typeof i1.DxoBorderModule, typeof i1.DxoHoverStyleModule, typeof i1.DxoHatchingModule, typeof i1.DxoSelectionStyleModule, typeof i1.DxoLabelModule, typeof i1.DxoConnectorModule, typeof i1.DxoFontModule, typeof i1.DxoFormatModule, typeof i1.DxoLegendModule, typeof i1.DxoMarginModule, typeof i1.DxoTitleModule, typeof i1.DxoSubtitleModule, typeof i1.DxoLoadingIndicatorModule, typeof i1.DxoSizeModule, typeof i1.DxoTooltipModule, typeof i1.DxoShadowModule, typeof i2.DxoFunnelAdaptiveLayoutModule, typeof i2.DxoFunnelBorderModule, typeof i2.DxoFunnelConnectorModule, typeof i2.DxoFunnelExportModule, typeof i2.DxoFunnelFontModule, typeof i2.DxoFunnelFormatModule, typeof i2.DxoFunnelFunnelTitleModule, typeof i2.DxoFunnelFunnelTitleSubtitleModule, typeof i2.DxoFunnelHatchingModule, typeof i2.DxoFunnelHoverStyleModule, typeof i2.DxoFunnelItemModule, typeof i2.DxoFunnelItemBorderModule, typeof i2.DxoFunnelLabelModule, typeof i2.DxoFunnelLabelBorderModule, typeof i2.DxoFunnelLegendModule, typeof i2.DxoFunnelLegendBorderModule, typeof i2.DxoFunnelLegendTitleModule, typeof i2.DxoFunnelLegendTitleSubtitleModule, typeof i2.DxoFunnelLoadingIndicatorModule, typeof i2.DxoFunnelMarginModule, typeof i2.DxoFunnelSelectionStyleModule, typeof i2.DxoFunnelShadowModule, typeof i2.DxoFunnelSizeModule, typeof i2.DxoFunnelSubtitleModule, typeof i2.DxoFunnelTitleModule, typeof i2.DxoFunnelTooltipModule, typeof i2.DxoFunnelTooltipBorderModule, typeof i3.DxIntegrationModule, typeof i3.DxTemplateModule], [typeof DxFunnelComponent, typeof i1.DxoAdaptiveLayoutModule, typeof i1.DxoExportModule, typeof i1.DxoItemModule, typeof i1.DxoBorderModule, typeof i1.DxoHoverStyleModule, typeof i1.DxoHatchingModule, typeof i1.DxoSelectionStyleModule, typeof i1.DxoLabelModule, typeof i1.DxoConnectorModule, typeof i1.DxoFontModule, typeof i1.DxoFormatModule, typeof i1.DxoLegendModule, typeof i1.DxoMarginModule, typeof i1.DxoTitleModule, typeof i1.DxoSubtitleModule, typeof i1.DxoLoadingIndicatorModule, typeof i1.DxoSizeModule, typeof i1.DxoTooltipModule, typeof i1.DxoShadowModule, typeof i2.DxoFunnelAdaptiveLayoutModule, typeof i2.DxoFunnelBorderModule, typeof i2.DxoFunnelConnectorModule, typeof i2.DxoFunnelExportModule, typeof i2.DxoFunnelFontModule, typeof i2.DxoFunnelFormatModule, typeof i2.DxoFunnelFunnelTitleModule, typeof i2.DxoFunnelFunnelTitleSubtitleModule, typeof i2.DxoFunnelHatchingModule, typeof i2.DxoFunnelHoverStyleModule, typeof i2.DxoFunnelItemModule, typeof i2.DxoFunnelItemBorderModule, typeof i2.DxoFunnelLabelModule, typeof i2.DxoFunnelLabelBorderModule, typeof i2.DxoFunnelLegendModule, typeof i2.DxoFunnelLegendBorderModule, typeof i2.DxoFunnelLegendTitleModule, typeof i2.DxoFunnelLegendTitleSubtitleModule, typeof i2.DxoFunnelLoadingIndicatorModule, typeof i2.DxoFunnelMarginModule, typeof i2.DxoFunnelSelectionStyleModule, typeof i2.DxoFunnelShadowModule, typeof i2.DxoFunnelSizeModule, typeof i2.DxoFunnelSubtitleModule, typeof i2.DxoFunnelTitleModule, typeof i2.DxoFunnelTooltipModule, typeof i2.DxoFunnelTooltipBorderModule, typeof i3.DxTemplateModule]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxFunnelModule>;
}

export { DxFunnelComponent, DxFunnelModule };
//# sourceMappingURL=index.d.ts.map
