import * as i0 from '@angular/core';
import { OnDestroy, OnInit, EventEmitter } from '@angular/core';
import { NestedOption, NestedOptionHost } from 'devextreme-angular/core';
import { DashStyle, Font, TextOverflow, WordWrap, HatchDirection, LabelPosition } from 'devextreme/common/charts';
import { ExportFormat, Format, HorizontalAlignment, VerticalEdge, HorizontalEdge, Position, Orientation } from 'devextreme/common';
import { dxFunnelItem, FunnelLegendItem } from 'devextreme/viz/funnel';
import { Format as Format$1 } from 'devextreme/common/core/localization';

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoFunnelAdaptiveLayoutComponent extends NestedOption implements OnDestroy, OnInit {
    get height(): number;
    set height(value: number);
    get keepLabels(): boolean;
    set keepLabels(value: boolean);
    get width(): number;
    set width(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoFunnelAdaptiveLayoutComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoFunnelAdaptiveLayoutComponent, "dxo-funnel-adaptive-layout", never, { "height": { "alias": "height"; "required": false; }; "keepLabels": { "alias": "keepLabels"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoFunnelAdaptiveLayoutModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoFunnelAdaptiveLayoutModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoFunnelAdaptiveLayoutModule, never, [typeof DxoFunnelAdaptiveLayoutComponent], [typeof DxoFunnelAdaptiveLayoutComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoFunnelAdaptiveLayoutModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoFunnelBorderComponent extends NestedOption implements OnDestroy, OnInit {
    get color(): string | undefined;
    set color(value: string | undefined);
    get visible(): boolean | undefined;
    set visible(value: boolean | undefined);
    get width(): number | undefined;
    set width(value: number | undefined);
    get dashStyle(): DashStyle;
    set dashStyle(value: DashStyle);
    get cornerRadius(): number;
    set cornerRadius(value: number);
    get opacity(): number | undefined;
    set opacity(value: number | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoFunnelBorderComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoFunnelBorderComponent, "dxo-funnel-border", never, { "color": { "alias": "color"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; "dashStyle": { "alias": "dashStyle"; "required": false; }; "cornerRadius": { "alias": "cornerRadius"; "required": false; }; "opacity": { "alias": "opacity"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoFunnelBorderModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoFunnelBorderModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoFunnelBorderModule, never, [typeof DxoFunnelBorderComponent], [typeof DxoFunnelBorderComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoFunnelBorderModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoFunnelConnectorComponent extends NestedOption implements OnDestroy, OnInit {
    get color(): string | undefined;
    set color(value: string | undefined);
    get opacity(): number;
    set opacity(value: number);
    get visible(): boolean;
    set visible(value: boolean);
    get width(): number;
    set width(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoFunnelConnectorComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoFunnelConnectorComponent, "dxo-funnel-connector", never, { "color": { "alias": "color"; "required": false; }; "opacity": { "alias": "opacity"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoFunnelConnectorModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoFunnelConnectorModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoFunnelConnectorModule, never, [typeof DxoFunnelConnectorComponent], [typeof DxoFunnelConnectorComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoFunnelConnectorModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoFunnelExportComponent extends NestedOption implements OnDestroy, OnInit {
    get backgroundColor(): string;
    set backgroundColor(value: string);
    get enabled(): boolean;
    set enabled(value: boolean);
    get fileName(): string;
    set fileName(value: string);
    get formats(): Array<ExportFormat>;
    set formats(value: Array<ExportFormat>);
    get margin(): number;
    set margin(value: number);
    get printingEnabled(): boolean;
    set printingEnabled(value: boolean);
    get svgToCanvas(): ((svg: any, canvas: any) => any) | undefined;
    set svgToCanvas(value: ((svg: any, canvas: any) => any) | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoFunnelExportComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoFunnelExportComponent, "dxo-funnel-export", never, { "backgroundColor": { "alias": "backgroundColor"; "required": false; }; "enabled": { "alias": "enabled"; "required": false; }; "fileName": { "alias": "fileName"; "required": false; }; "formats": { "alias": "formats"; "required": false; }; "margin": { "alias": "margin"; "required": false; }; "printingEnabled": { "alias": "printingEnabled"; "required": false; }; "svgToCanvas": { "alias": "svgToCanvas"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoFunnelExportModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoFunnelExportModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoFunnelExportModule, never, [typeof DxoFunnelExportComponent], [typeof DxoFunnelExportComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoFunnelExportModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoFunnelFontComponent extends NestedOption implements OnDestroy, OnInit {
    get color(): string;
    set color(value: string);
    get family(): string;
    set family(value: string);
    get opacity(): number;
    set opacity(value: number);
    get size(): number | string;
    set size(value: number | string);
    get weight(): number;
    set weight(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoFunnelFontComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoFunnelFontComponent, "dxo-funnel-font", never, { "color": { "alias": "color"; "required": false; }; "family": { "alias": "family"; "required": false; }; "opacity": { "alias": "opacity"; "required": false; }; "size": { "alias": "size"; "required": false; }; "weight": { "alias": "weight"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoFunnelFontModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoFunnelFontModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoFunnelFontModule, never, [typeof DxoFunnelFontComponent], [typeof DxoFunnelFontComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoFunnelFontModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoFunnelFormatComponent extends NestedOption implements OnDestroy, OnInit {
    get currency(): string;
    set currency(value: string);
    get formatter(): ((value: number | Date) => string);
    set formatter(value: ((value: number | Date) => string));
    get parser(): ((value: string) => number | Date);
    set parser(value: ((value: string) => number | Date));
    get precision(): number;
    set precision(value: number);
    get type(): Format | string;
    set type(value: Format | string);
    get useCurrencyAccountingStyle(): boolean;
    set useCurrencyAccountingStyle(value: boolean);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoFunnelFormatComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoFunnelFormatComponent, "dxo-funnel-format", never, { "currency": { "alias": "currency"; "required": false; }; "formatter": { "alias": "formatter"; "required": false; }; "parser": { "alias": "parser"; "required": false; }; "precision": { "alias": "precision"; "required": false; }; "type": { "alias": "type"; "required": false; }; "useCurrencyAccountingStyle": { "alias": "useCurrencyAccountingStyle"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoFunnelFormatModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoFunnelFormatModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoFunnelFormatModule, never, [typeof DxoFunnelFormatComponent], [typeof DxoFunnelFormatComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoFunnelFormatModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoFunnelFunnelTitleSubtitleComponent extends NestedOption implements OnDestroy, OnInit {
    get font(): Font;
    set font(value: Font);
    get offset(): number;
    set offset(value: number);
    get text(): string | undefined;
    set text(value: string | undefined);
    get textOverflow(): TextOverflow;
    set textOverflow(value: TextOverflow);
    get wordWrap(): WordWrap;
    set wordWrap(value: WordWrap);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoFunnelFunnelTitleSubtitleComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoFunnelFunnelTitleSubtitleComponent, "dxo-funnel-funnel-title-subtitle", never, { "font": { "alias": "font"; "required": false; }; "offset": { "alias": "offset"; "required": false; }; "text": { "alias": "text"; "required": false; }; "textOverflow": { "alias": "textOverflow"; "required": false; }; "wordWrap": { "alias": "wordWrap"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoFunnelFunnelTitleSubtitleModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoFunnelFunnelTitleSubtitleModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoFunnelFunnelTitleSubtitleModule, never, [typeof DxoFunnelFunnelTitleSubtitleComponent], [typeof DxoFunnelFunnelTitleSubtitleComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoFunnelFunnelTitleSubtitleModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoFunnelFunnelTitleComponent extends NestedOption implements OnDestroy, OnInit {
    get font(): Font;
    set font(value: Font);
    get horizontalAlignment(): HorizontalAlignment;
    set horizontalAlignment(value: HorizontalAlignment);
    get margin(): number | {
        bottom?: number;
        left?: number;
        right?: number;
        top?: number;
    };
    set margin(value: number | {
        bottom?: number;
        left?: number;
        right?: number;
        top?: number;
    });
    get placeholderSize(): number | undefined;
    set placeholderSize(value: number | undefined);
    get subtitle(): string | {
        font?: Font;
        offset?: number;
        text?: string | undefined;
        textOverflow?: TextOverflow;
        wordWrap?: WordWrap;
    };
    set subtitle(value: string | {
        font?: Font;
        offset?: number;
        text?: string | undefined;
        textOverflow?: TextOverflow;
        wordWrap?: WordWrap;
    });
    get text(): string | undefined;
    set text(value: string | undefined);
    get textOverflow(): TextOverflow;
    set textOverflow(value: TextOverflow);
    get verticalAlignment(): VerticalEdge;
    set verticalAlignment(value: VerticalEdge);
    get wordWrap(): WordWrap;
    set wordWrap(value: WordWrap);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoFunnelFunnelTitleComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoFunnelFunnelTitleComponent, "dxo-funnel-funnel-title", never, { "font": { "alias": "font"; "required": false; }; "horizontalAlignment": { "alias": "horizontalAlignment"; "required": false; }; "margin": { "alias": "margin"; "required": false; }; "placeholderSize": { "alias": "placeholderSize"; "required": false; }; "subtitle": { "alias": "subtitle"; "required": false; }; "text": { "alias": "text"; "required": false; }; "textOverflow": { "alias": "textOverflow"; "required": false; }; "verticalAlignment": { "alias": "verticalAlignment"; "required": false; }; "wordWrap": { "alias": "wordWrap"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoFunnelFunnelTitleModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoFunnelFunnelTitleModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoFunnelFunnelTitleModule, never, [typeof DxoFunnelFunnelTitleComponent], [typeof DxoFunnelFunnelTitleComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoFunnelFunnelTitleModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoFunnelHatchingComponent extends NestedOption implements OnDestroy, OnInit {
    get direction(): HatchDirection;
    set direction(value: HatchDirection);
    get opacity(): number;
    set opacity(value: number);
    get step(): number;
    set step(value: number);
    get width(): number;
    set width(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoFunnelHatchingComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoFunnelHatchingComponent, "dxo-funnel-hatching", never, { "direction": { "alias": "direction"; "required": false; }; "opacity": { "alias": "opacity"; "required": false; }; "step": { "alias": "step"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoFunnelHatchingModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoFunnelHatchingModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoFunnelHatchingModule, never, [typeof DxoFunnelHatchingComponent], [typeof DxoFunnelHatchingComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoFunnelHatchingModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoFunnelHoverStyleComponent extends NestedOption implements OnDestroy, OnInit {
    get border(): {
        color?: string | undefined;
        visible?: boolean | undefined;
        width?: number | undefined;
    };
    set border(value: {
        color?: string | undefined;
        visible?: boolean | undefined;
        width?: number | undefined;
    });
    get hatching(): {
        direction?: HatchDirection;
        opacity?: number;
        step?: number;
        width?: number;
    };
    set hatching(value: {
        direction?: HatchDirection;
        opacity?: number;
        step?: number;
        width?: number;
    });
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoFunnelHoverStyleComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoFunnelHoverStyleComponent, "dxo-funnel-hover-style", never, { "border": { "alias": "border"; "required": false; }; "hatching": { "alias": "hatching"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoFunnelHoverStyleModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoFunnelHoverStyleModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoFunnelHoverStyleModule, never, [typeof DxoFunnelHoverStyleComponent], [typeof DxoFunnelHoverStyleComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoFunnelHoverStyleModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoFunnelItemBorderComponent extends NestedOption implements OnDestroy, OnInit {
    get color(): string | undefined;
    set color(value: string | undefined);
    get visible(): boolean | undefined;
    set visible(value: boolean | undefined);
    get width(): number | undefined;
    set width(value: number | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoFunnelItemBorderComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoFunnelItemBorderComponent, "dxo-funnel-item-border", never, { "color": { "alias": "color"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoFunnelItemBorderModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoFunnelItemBorderModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoFunnelItemBorderModule, never, [typeof DxoFunnelItemBorderComponent], [typeof DxoFunnelItemBorderComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoFunnelItemBorderModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoFunnelItemComponent extends NestedOption implements OnDestroy, OnInit {
    get border(): {
        color?: string | undefined;
        visible?: boolean | undefined;
        width?: number | undefined;
    };
    set border(value: {
        color?: string | undefined;
        visible?: boolean | undefined;
        width?: number | undefined;
    });
    get hoverStyle(): {
        border?: {
            color?: string | undefined;
            visible?: boolean | undefined;
            width?: number | undefined;
        };
        hatching?: {
            direction?: HatchDirection;
            opacity?: number;
            step?: number;
            width?: number;
        };
    };
    set hoverStyle(value: {
        border?: {
            color?: string | undefined;
            visible?: boolean | undefined;
            width?: number | undefined;
        };
        hatching?: {
            direction?: HatchDirection;
            opacity?: number;
            step?: number;
            width?: number;
        };
    });
    get selectionStyle(): {
        border?: {
            color?: string | undefined;
            visible?: boolean | undefined;
            width?: number | undefined;
        };
        hatching?: {
            direction?: HatchDirection;
            opacity?: number;
            step?: number;
            width?: number;
        };
    };
    set selectionStyle(value: {
        border?: {
            color?: string | undefined;
            visible?: boolean | undefined;
            width?: number | undefined;
        };
        hatching?: {
            direction?: HatchDirection;
            opacity?: number;
            step?: number;
            width?: number;
        };
    });
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoFunnelItemComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoFunnelItemComponent, "dxo-funnel-item", never, { "border": { "alias": "border"; "required": false; }; "hoverStyle": { "alias": "hoverStyle"; "required": false; }; "selectionStyle": { "alias": "selectionStyle"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoFunnelItemModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoFunnelItemModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoFunnelItemModule, never, [typeof DxoFunnelItemComponent], [typeof DxoFunnelItemComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoFunnelItemModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoFunnelLabelBorderComponent extends NestedOption implements OnDestroy, OnInit {
    get color(): string;
    set color(value: string);
    get dashStyle(): DashStyle;
    set dashStyle(value: DashStyle);
    get visible(): boolean;
    set visible(value: boolean);
    get width(): number;
    set width(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoFunnelLabelBorderComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoFunnelLabelBorderComponent, "dxo-funnel-label-border", never, { "color": { "alias": "color"; "required": false; }; "dashStyle": { "alias": "dashStyle"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoFunnelLabelBorderModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoFunnelLabelBorderModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoFunnelLabelBorderModule, never, [typeof DxoFunnelLabelBorderComponent], [typeof DxoFunnelLabelBorderComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoFunnelLabelBorderModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoFunnelLabelComponent extends NestedOption implements OnDestroy, OnInit {
    get backgroundColor(): string;
    set backgroundColor(value: string);
    get border(): {
        color?: string;
        dashStyle?: DashStyle;
        visible?: boolean;
        width?: number;
    };
    set border(value: {
        color?: string;
        dashStyle?: DashStyle;
        visible?: boolean;
        width?: number;
    });
    get connector(): {
        color?: string | undefined;
        opacity?: number;
        visible?: boolean;
        width?: number;
    };
    set connector(value: {
        color?: string | undefined;
        opacity?: number;
        visible?: boolean;
        width?: number;
    });
    get customizeText(): ((itemInfo: {
        item: dxFunnelItem;
        percent: number;
        percentText: string;
        value: number;
        valueText: string;
    }) => string);
    set customizeText(value: ((itemInfo: {
        item: dxFunnelItem;
        percent: number;
        percentText: string;
        value: number;
        valueText: string;
    }) => string));
    get font(): Font;
    set font(value: Font);
    get format(): Format$1 | undefined;
    set format(value: Format$1 | undefined);
    get horizontalAlignment(): HorizontalEdge;
    set horizontalAlignment(value: HorizontalEdge);
    get horizontalOffset(): number;
    set horizontalOffset(value: number);
    get position(): LabelPosition;
    set position(value: LabelPosition);
    get showForZeroValues(): boolean;
    set showForZeroValues(value: boolean);
    get textOverflow(): TextOverflow;
    set textOverflow(value: TextOverflow);
    get visible(): boolean;
    set visible(value: boolean);
    get wordWrap(): WordWrap;
    set wordWrap(value: WordWrap);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoFunnelLabelComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoFunnelLabelComponent, "dxo-funnel-label", never, { "backgroundColor": { "alias": "backgroundColor"; "required": false; }; "border": { "alias": "border"; "required": false; }; "connector": { "alias": "connector"; "required": false; }; "customizeText": { "alias": "customizeText"; "required": false; }; "font": { "alias": "font"; "required": false; }; "format": { "alias": "format"; "required": false; }; "horizontalAlignment": { "alias": "horizontalAlignment"; "required": false; }; "horizontalOffset": { "alias": "horizontalOffset"; "required": false; }; "position": { "alias": "position"; "required": false; }; "showForZeroValues": { "alias": "showForZeroValues"; "required": false; }; "textOverflow": { "alias": "textOverflow"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "wordWrap": { "alias": "wordWrap"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoFunnelLabelModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoFunnelLabelModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoFunnelLabelModule, never, [typeof DxoFunnelLabelComponent], [typeof DxoFunnelLabelComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoFunnelLabelModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoFunnelLegendBorderComponent extends NestedOption implements OnDestroy, OnInit {
    get color(): string;
    set color(value: string);
    get cornerRadius(): number;
    set cornerRadius(value: number);
    get dashStyle(): DashStyle;
    set dashStyle(value: DashStyle);
    get opacity(): number | undefined;
    set opacity(value: number | undefined);
    get visible(): boolean;
    set visible(value: boolean);
    get width(): number;
    set width(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoFunnelLegendBorderComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoFunnelLegendBorderComponent, "dxo-funnel-legend-border", never, { "color": { "alias": "color"; "required": false; }; "cornerRadius": { "alias": "cornerRadius"; "required": false; }; "dashStyle": { "alias": "dashStyle"; "required": false; }; "opacity": { "alias": "opacity"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoFunnelLegendBorderModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoFunnelLegendBorderModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoFunnelLegendBorderModule, never, [typeof DxoFunnelLegendBorderComponent], [typeof DxoFunnelLegendBorderComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoFunnelLegendBorderModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoFunnelLegendTitleSubtitleComponent extends NestedOption implements OnDestroy, OnInit {
    get font(): Font;
    set font(value: Font);
    get offset(): number;
    set offset(value: number);
    get text(): string | undefined;
    set text(value: string | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoFunnelLegendTitleSubtitleComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoFunnelLegendTitleSubtitleComponent, "dxo-funnel-legend-title-subtitle", never, { "font": { "alias": "font"; "required": false; }; "offset": { "alias": "offset"; "required": false; }; "text": { "alias": "text"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoFunnelLegendTitleSubtitleModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoFunnelLegendTitleSubtitleModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoFunnelLegendTitleSubtitleModule, never, [typeof DxoFunnelLegendTitleSubtitleComponent], [typeof DxoFunnelLegendTitleSubtitleComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoFunnelLegendTitleSubtitleModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoFunnelLegendTitleComponent extends NestedOption implements OnDestroy, OnInit {
    get font(): Font;
    set font(value: Font);
    get horizontalAlignment(): HorizontalAlignment | undefined;
    set horizontalAlignment(value: HorizontalAlignment | undefined);
    get margin(): {
        bottom?: number;
        left?: number;
        right?: number;
        top?: number;
    };
    set margin(value: {
        bottom?: number;
        left?: number;
        right?: number;
        top?: number;
    });
    get placeholderSize(): number | undefined;
    set placeholderSize(value: number | undefined);
    get subtitle(): string | {
        font?: Font;
        offset?: number;
        text?: string | undefined;
    };
    set subtitle(value: string | {
        font?: Font;
        offset?: number;
        text?: string | undefined;
    });
    get text(): string | undefined;
    set text(value: string | undefined);
    get verticalAlignment(): VerticalEdge;
    set verticalAlignment(value: VerticalEdge);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoFunnelLegendTitleComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoFunnelLegendTitleComponent, "dxo-funnel-legend-title", never, { "font": { "alias": "font"; "required": false; }; "horizontalAlignment": { "alias": "horizontalAlignment"; "required": false; }; "margin": { "alias": "margin"; "required": false; }; "placeholderSize": { "alias": "placeholderSize"; "required": false; }; "subtitle": { "alias": "subtitle"; "required": false; }; "text": { "alias": "text"; "required": false; }; "verticalAlignment": { "alias": "verticalAlignment"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoFunnelLegendTitleModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoFunnelLegendTitleModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoFunnelLegendTitleModule, never, [typeof DxoFunnelLegendTitleComponent], [typeof DxoFunnelLegendTitleComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoFunnelLegendTitleModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoFunnelLegendComponent extends NestedOption implements OnDestroy, OnInit {
    get backgroundColor(): string | undefined;
    set backgroundColor(value: string | undefined);
    get border(): {
        color?: string;
        cornerRadius?: number;
        dashStyle?: DashStyle;
        opacity?: number | undefined;
        visible?: boolean;
        width?: number;
    };
    set border(value: {
        color?: string;
        cornerRadius?: number;
        dashStyle?: DashStyle;
        opacity?: number | undefined;
        visible?: boolean;
        width?: number;
    });
    get columnCount(): number;
    set columnCount(value: number);
    get columnItemSpacing(): number;
    set columnItemSpacing(value: number);
    get customizeHint(): ((itemInfo: {
        item: dxFunnelItem;
        text: string;
    }) => string);
    set customizeHint(value: ((itemInfo: {
        item: dxFunnelItem;
        text: string;
    }) => string));
    get customizeItems(): ((items: Array<FunnelLegendItem>) => Array<FunnelLegendItem>);
    set customizeItems(value: ((items: Array<FunnelLegendItem>) => Array<FunnelLegendItem>));
    get customizeText(): ((itemInfo: {
        item: dxFunnelItem;
        text: string;
    }) => string);
    set customizeText(value: ((itemInfo: {
        item: dxFunnelItem;
        text: string;
    }) => string));
    get font(): Font;
    set font(value: Font);
    get horizontalAlignment(): HorizontalAlignment;
    set horizontalAlignment(value: HorizontalAlignment);
    get itemsAlignment(): HorizontalAlignment | undefined;
    set itemsAlignment(value: HorizontalAlignment | undefined);
    get itemTextPosition(): Position | undefined;
    set itemTextPosition(value: Position | undefined);
    get margin(): number | {
        bottom?: number;
        left?: number;
        right?: number;
        top?: number;
    };
    set margin(value: number | {
        bottom?: number;
        left?: number;
        right?: number;
        top?: number;
    });
    get markerSize(): number;
    set markerSize(value: number);
    get markerTemplate(): any;
    set markerTemplate(value: any);
    get orientation(): Orientation | undefined;
    set orientation(value: Orientation | undefined);
    get paddingLeftRight(): number;
    set paddingLeftRight(value: number);
    get paddingTopBottom(): number;
    set paddingTopBottom(value: number);
    get rowCount(): number;
    set rowCount(value: number);
    get rowItemSpacing(): number;
    set rowItemSpacing(value: number);
    get title(): string | {
        font?: Font;
        horizontalAlignment?: HorizontalAlignment | undefined;
        margin?: {
            bottom?: number;
            left?: number;
            right?: number;
            top?: number;
        };
        placeholderSize?: number | undefined;
        subtitle?: string | {
            font?: Font;
            offset?: number;
            text?: string | undefined;
        };
        text?: string | undefined;
        verticalAlignment?: VerticalEdge;
    };
    set title(value: string | {
        font?: Font;
        horizontalAlignment?: HorizontalAlignment | undefined;
        margin?: {
            bottom?: number;
            left?: number;
            right?: number;
            top?: number;
        };
        placeholderSize?: number | undefined;
        subtitle?: string | {
            font?: Font;
            offset?: number;
            text?: string | undefined;
        };
        text?: string | undefined;
        verticalAlignment?: VerticalEdge;
    });
    get verticalAlignment(): VerticalEdge;
    set verticalAlignment(value: VerticalEdge);
    get visible(): boolean;
    set visible(value: boolean);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoFunnelLegendComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoFunnelLegendComponent, "dxo-funnel-legend", never, { "backgroundColor": { "alias": "backgroundColor"; "required": false; }; "border": { "alias": "border"; "required": false; }; "columnCount": { "alias": "columnCount"; "required": false; }; "columnItemSpacing": { "alias": "columnItemSpacing"; "required": false; }; "customizeHint": { "alias": "customizeHint"; "required": false; }; "customizeItems": { "alias": "customizeItems"; "required": false; }; "customizeText": { "alias": "customizeText"; "required": false; }; "font": { "alias": "font"; "required": false; }; "horizontalAlignment": { "alias": "horizontalAlignment"; "required": false; }; "itemsAlignment": { "alias": "itemsAlignment"; "required": false; }; "itemTextPosition": { "alias": "itemTextPosition"; "required": false; }; "margin": { "alias": "margin"; "required": false; }; "markerSize": { "alias": "markerSize"; "required": false; }; "markerTemplate": { "alias": "markerTemplate"; "required": false; }; "orientation": { "alias": "orientation"; "required": false; }; "paddingLeftRight": { "alias": "paddingLeftRight"; "required": false; }; "paddingTopBottom": { "alias": "paddingTopBottom"; "required": false; }; "rowCount": { "alias": "rowCount"; "required": false; }; "rowItemSpacing": { "alias": "rowItemSpacing"; "required": false; }; "title": { "alias": "title"; "required": false; }; "verticalAlignment": { "alias": "verticalAlignment"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoFunnelLegendModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoFunnelLegendModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoFunnelLegendModule, never, [typeof DxoFunnelLegendComponent], [typeof DxoFunnelLegendComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoFunnelLegendModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoFunnelLoadingIndicatorComponent extends NestedOption implements OnDestroy, OnInit {
    get backgroundColor(): string;
    set backgroundColor(value: string);
    get enabled(): boolean;
    set enabled(value: boolean);
    get font(): Font;
    set font(value: Font);
    get show(): boolean;
    set show(value: boolean);
    get text(): string;
    set text(value: string);
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    showChange: EventEmitter<boolean>;
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoFunnelLoadingIndicatorComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoFunnelLoadingIndicatorComponent, "dxo-funnel-loading-indicator", never, { "backgroundColor": { "alias": "backgroundColor"; "required": false; }; "enabled": { "alias": "enabled"; "required": false; }; "font": { "alias": "font"; "required": false; }; "show": { "alias": "show"; "required": false; }; "text": { "alias": "text"; "required": false; }; }, { "showChange": "showChange"; }, never, never, true, never>;
}
declare class DxoFunnelLoadingIndicatorModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoFunnelLoadingIndicatorModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoFunnelLoadingIndicatorModule, never, [typeof DxoFunnelLoadingIndicatorComponent], [typeof DxoFunnelLoadingIndicatorComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoFunnelLoadingIndicatorModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoFunnelMarginComponent extends NestedOption implements OnDestroy, OnInit {
    get bottom(): number;
    set bottom(value: number);
    get left(): number;
    set left(value: number);
    get right(): number;
    set right(value: number);
    get top(): number;
    set top(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoFunnelMarginComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoFunnelMarginComponent, "dxo-funnel-margin", never, { "bottom": { "alias": "bottom"; "required": false; }; "left": { "alias": "left"; "required": false; }; "right": { "alias": "right"; "required": false; }; "top": { "alias": "top"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoFunnelMarginModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoFunnelMarginModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoFunnelMarginModule, never, [typeof DxoFunnelMarginComponent], [typeof DxoFunnelMarginComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoFunnelMarginModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoFunnelSelectionStyleComponent extends NestedOption implements OnDestroy, OnInit {
    get border(): {
        color?: string | undefined;
        visible?: boolean | undefined;
        width?: number | undefined;
    };
    set border(value: {
        color?: string | undefined;
        visible?: boolean | undefined;
        width?: number | undefined;
    });
    get hatching(): {
        direction?: HatchDirection;
        opacity?: number;
        step?: number;
        width?: number;
    };
    set hatching(value: {
        direction?: HatchDirection;
        opacity?: number;
        step?: number;
        width?: number;
    });
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoFunnelSelectionStyleComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoFunnelSelectionStyleComponent, "dxo-funnel-selection-style", never, { "border": { "alias": "border"; "required": false; }; "hatching": { "alias": "hatching"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoFunnelSelectionStyleModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoFunnelSelectionStyleModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoFunnelSelectionStyleModule, never, [typeof DxoFunnelSelectionStyleComponent], [typeof DxoFunnelSelectionStyleComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoFunnelSelectionStyleModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoFunnelShadowComponent extends NestedOption implements OnDestroy, OnInit {
    get blur(): number;
    set blur(value: number);
    get color(): string;
    set color(value: string);
    get offsetX(): number;
    set offsetX(value: number);
    get offsetY(): number;
    set offsetY(value: number);
    get opacity(): number;
    set opacity(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoFunnelShadowComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoFunnelShadowComponent, "dxo-funnel-shadow", never, { "blur": { "alias": "blur"; "required": false; }; "color": { "alias": "color"; "required": false; }; "offsetX": { "alias": "offsetX"; "required": false; }; "offsetY": { "alias": "offsetY"; "required": false; }; "opacity": { "alias": "opacity"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoFunnelShadowModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoFunnelShadowModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoFunnelShadowModule, never, [typeof DxoFunnelShadowComponent], [typeof DxoFunnelShadowComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoFunnelShadowModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoFunnelSizeComponent extends NestedOption implements OnDestroy, OnInit {
    get height(): number | undefined;
    set height(value: number | undefined);
    get width(): number | undefined;
    set width(value: number | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoFunnelSizeComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoFunnelSizeComponent, "dxo-funnel-size", never, { "height": { "alias": "height"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoFunnelSizeModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoFunnelSizeModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoFunnelSizeModule, never, [typeof DxoFunnelSizeComponent], [typeof DxoFunnelSizeComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoFunnelSizeModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoFunnelSubtitleComponent extends NestedOption implements OnDestroy, OnInit {
    get font(): Font;
    set font(value: Font);
    get offset(): number;
    set offset(value: number);
    get text(): string | undefined;
    set text(value: string | undefined);
    get textOverflow(): TextOverflow;
    set textOverflow(value: TextOverflow);
    get wordWrap(): WordWrap;
    set wordWrap(value: WordWrap);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoFunnelSubtitleComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoFunnelSubtitleComponent, "dxo-funnel-subtitle", never, { "font": { "alias": "font"; "required": false; }; "offset": { "alias": "offset"; "required": false; }; "text": { "alias": "text"; "required": false; }; "textOverflow": { "alias": "textOverflow"; "required": false; }; "wordWrap": { "alias": "wordWrap"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoFunnelSubtitleModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoFunnelSubtitleModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoFunnelSubtitleModule, never, [typeof DxoFunnelSubtitleComponent], [typeof DxoFunnelSubtitleComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoFunnelSubtitleModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoFunnelTitleComponent extends NestedOption implements OnDestroy, OnInit {
    get font(): Font;
    set font(value: Font);
    get horizontalAlignment(): HorizontalAlignment | undefined;
    set horizontalAlignment(value: HorizontalAlignment | undefined);
    get margin(): number | {
        bottom?: number;
        left?: number;
        right?: number;
        top?: number;
    };
    set margin(value: number | {
        bottom?: number;
        left?: number;
        right?: number;
        top?: number;
    });
    get placeholderSize(): number | undefined;
    set placeholderSize(value: number | undefined);
    get subtitle(): string | {
        font?: Font;
        offset?: number;
        text?: string | undefined;
        textOverflow?: TextOverflow;
        wordWrap?: WordWrap;
    };
    set subtitle(value: string | {
        font?: Font;
        offset?: number;
        text?: string | undefined;
        textOverflow?: TextOverflow;
        wordWrap?: WordWrap;
    });
    get text(): string | undefined;
    set text(value: string | undefined);
    get verticalAlignment(): VerticalEdge;
    set verticalAlignment(value: VerticalEdge);
    get textOverflow(): TextOverflow;
    set textOverflow(value: TextOverflow);
    get wordWrap(): WordWrap;
    set wordWrap(value: WordWrap);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoFunnelTitleComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoFunnelTitleComponent, "dxo-funnel-title", never, { "font": { "alias": "font"; "required": false; }; "horizontalAlignment": { "alias": "horizontalAlignment"; "required": false; }; "margin": { "alias": "margin"; "required": false; }; "placeholderSize": { "alias": "placeholderSize"; "required": false; }; "subtitle": { "alias": "subtitle"; "required": false; }; "text": { "alias": "text"; "required": false; }; "verticalAlignment": { "alias": "verticalAlignment"; "required": false; }; "textOverflow": { "alias": "textOverflow"; "required": false; }; "wordWrap": { "alias": "wordWrap"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoFunnelTitleModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoFunnelTitleModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoFunnelTitleModule, never, [typeof DxoFunnelTitleComponent], [typeof DxoFunnelTitleComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoFunnelTitleModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoFunnelTooltipBorderComponent extends NestedOption implements OnDestroy, OnInit {
    get color(): string;
    set color(value: string);
    get dashStyle(): DashStyle;
    set dashStyle(value: DashStyle);
    get opacity(): number | undefined;
    set opacity(value: number | undefined);
    get visible(): boolean;
    set visible(value: boolean);
    get width(): number;
    set width(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoFunnelTooltipBorderComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoFunnelTooltipBorderComponent, "dxo-funnel-tooltip-border", never, { "color": { "alias": "color"; "required": false; }; "dashStyle": { "alias": "dashStyle"; "required": false; }; "opacity": { "alias": "opacity"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoFunnelTooltipBorderModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoFunnelTooltipBorderModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoFunnelTooltipBorderModule, never, [typeof DxoFunnelTooltipBorderComponent], [typeof DxoFunnelTooltipBorderComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoFunnelTooltipBorderModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoFunnelTooltipComponent extends NestedOption implements OnDestroy, OnInit {
    get arrowLength(): number;
    set arrowLength(value: number);
    get border(): {
        color?: string;
        dashStyle?: DashStyle;
        opacity?: number | undefined;
        visible?: boolean;
        width?: number;
    };
    set border(value: {
        color?: string;
        dashStyle?: DashStyle;
        opacity?: number | undefined;
        visible?: boolean;
        width?: number;
    });
    get color(): string;
    set color(value: string);
    get container(): any | string | undefined;
    set container(value: any | string | undefined);
    get contentTemplate(): any;
    set contentTemplate(value: any);
    get cornerRadius(): number;
    set cornerRadius(value: number);
    get customizeTooltip(): ((info: {
        item: dxFunnelItem;
        percent: number;
        percentText: string;
        value: number;
        valueText: string;
    }) => Record<string, any>) | undefined;
    set customizeTooltip(value: ((info: {
        item: dxFunnelItem;
        percent: number;
        percentText: string;
        value: number;
        valueText: string;
    }) => Record<string, any>) | undefined);
    get enabled(): boolean;
    set enabled(value: boolean);
    get font(): Font;
    set font(value: Font);
    get format(): Format$1 | undefined;
    set format(value: Format$1 | undefined);
    get opacity(): number | undefined;
    set opacity(value: number | undefined);
    get paddingLeftRight(): number;
    set paddingLeftRight(value: number);
    get paddingTopBottom(): number;
    set paddingTopBottom(value: number);
    get shadow(): {
        blur?: number;
        color?: string;
        offsetX?: number;
        offsetY?: number;
        opacity?: number;
    };
    set shadow(value: {
        blur?: number;
        color?: string;
        offsetX?: number;
        offsetY?: number;
        opacity?: number;
    });
    get zIndex(): number | undefined;
    set zIndex(value: number | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoFunnelTooltipComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoFunnelTooltipComponent, "dxo-funnel-tooltip", never, { "arrowLength": { "alias": "arrowLength"; "required": false; }; "border": { "alias": "border"; "required": false; }; "color": { "alias": "color"; "required": false; }; "container": { "alias": "container"; "required": false; }; "contentTemplate": { "alias": "contentTemplate"; "required": false; }; "cornerRadius": { "alias": "cornerRadius"; "required": false; }; "customizeTooltip": { "alias": "customizeTooltip"; "required": false; }; "enabled": { "alias": "enabled"; "required": false; }; "font": { "alias": "font"; "required": false; }; "format": { "alias": "format"; "required": false; }; "opacity": { "alias": "opacity"; "required": false; }; "paddingLeftRight": { "alias": "paddingLeftRight"; "required": false; }; "paddingTopBottom": { "alias": "paddingTopBottom"; "required": false; }; "shadow": { "alias": "shadow"; "required": false; }; "zIndex": { "alias": "zIndex"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoFunnelTooltipModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoFunnelTooltipModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoFunnelTooltipModule, never, [typeof DxoFunnelTooltipComponent], [typeof DxoFunnelTooltipComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoFunnelTooltipModule>;
}

export { DxoFunnelAdaptiveLayoutComponent, DxoFunnelAdaptiveLayoutModule, DxoFunnelBorderComponent, DxoFunnelBorderModule, DxoFunnelConnectorComponent, DxoFunnelConnectorModule, DxoFunnelExportComponent, DxoFunnelExportModule, DxoFunnelFontComponent, DxoFunnelFontModule, DxoFunnelFormatComponent, DxoFunnelFormatModule, DxoFunnelFunnelTitleComponent, DxoFunnelFunnelTitleModule, DxoFunnelFunnelTitleSubtitleComponent, DxoFunnelFunnelTitleSubtitleModule, DxoFunnelHatchingComponent, DxoFunnelHatchingModule, DxoFunnelHoverStyleComponent, DxoFunnelHoverStyleModule, DxoFunnelItemBorderComponent, DxoFunnelItemBorderModule, DxoFunnelItemComponent, DxoFunnelItemModule, DxoFunnelLabelBorderComponent, DxoFunnelLabelBorderModule, DxoFunnelLabelComponent, DxoFunnelLabelModule, DxoFunnelLegendBorderComponent, DxoFunnelLegendBorderModule, DxoFunnelLegendComponent, DxoFunnelLegendModule, DxoFunnelLegendTitleComponent, DxoFunnelLegendTitleModule, DxoFunnelLegendTitleSubtitleComponent, DxoFunnelLegendTitleSubtitleModule, DxoFunnelLoadingIndicatorComponent, DxoFunnelLoadingIndicatorModule, DxoFunnelMarginComponent, DxoFunnelMarginModule, DxoFunnelSelectionStyleComponent, DxoFunnelSelectionStyleModule, DxoFunnelShadowComponent, DxoFunnelShadowModule, DxoFunnelSizeComponent, DxoFunnelSizeModule, DxoFunnelSubtitleComponent, DxoFunnelSubtitleModule, DxoFunnelTitleComponent, DxoFunnelTitleModule, DxoFunnelTooltipBorderComponent, DxoFunnelTooltipBorderModule, DxoFunnelTooltipComponent, DxoFunnelTooltipModule };
//# sourceMappingURL=index.d.ts.map
