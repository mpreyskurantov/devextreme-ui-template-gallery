import * as i0 from '@angular/core';
import { OnDestroy, EventEmitter, ElementRef, NgZone, TransferState } from '@angular/core';
import { event } from 'devextreme/events/events.types';
import DxDrawer, { OpenedStateMode, PanelLocation, RevealMode, DisposingEvent, InitializedEvent, OptionChangedEvent } from 'devextreme/ui/drawer';
import * as i1 from 'devextreme-angular/core';
import { DxComponent, DxTemplateHost, WatcherHelper, NestedOptionHost } from 'devextreme-angular/core';
import * as drawer_types from 'devextreme/ui/drawer_types';
export { drawer_types as DxDrawerTypes };

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

/**
 * [descr:dxDrawer]

 */
declare class DxDrawerComponent extends DxComponent implements OnDestroy {
    instance: DxDrawer;
    /**
     * [descr:WidgetOptions.activeStateEnabled]
    
     */
    get activeStateEnabled(): boolean;
    set activeStateEnabled(value: boolean);
    /**
     * [descr:dxDrawerOptions.animationDuration]
    
     */
    get animationDuration(): number;
    set animationDuration(value: number);
    /**
     * [descr:dxDrawerOptions.animationEnabled]
    
     */
    get animationEnabled(): boolean;
    set animationEnabled(value: boolean);
    /**
     * [descr:dxDrawerOptions.closeOnOutsideClick]
    
     */
    get closeOnOutsideClick(): boolean | ((event: event) => boolean);
    set closeOnOutsideClick(value: boolean | ((event: event) => boolean));
    /**
     * [descr:WidgetOptions.disabled]
    
     */
    get disabled(): boolean;
    set disabled(value: boolean);
    /**
     * [descr:DOMComponentOptions.elementAttr]
    
     */
    get elementAttr(): Record<string, any>;
    set elementAttr(value: Record<string, any>);
    /**
     * [descr:DOMComponentOptions.height]
    
     */
    get height(): number | string | undefined;
    set height(value: number | string | undefined);
    /**
     * [descr:WidgetOptions.hint]
    
     */
    get hint(): string | undefined;
    set hint(value: string | undefined);
    /**
     * [descr:WidgetOptions.hoverStateEnabled]
    
     */
    get hoverStateEnabled(): boolean;
    set hoverStateEnabled(value: boolean);
    /**
     * [descr:dxDrawerOptions.maxSize]
    
     */
    get maxSize(): null | number;
    set maxSize(value: null | number);
    /**
     * [descr:dxDrawerOptions.minSize]
    
     */
    get minSize(): null | number;
    set minSize(value: null | number);
    /**
     * [descr:dxDrawerOptions.opened]
    
     */
    get opened(): boolean;
    set opened(value: boolean);
    /**
     * [descr:dxDrawerOptions.openedStateMode]
    
     */
    get openedStateMode(): OpenedStateMode;
    set openedStateMode(value: OpenedStateMode);
    /**
     * [descr:dxDrawerOptions.position]
    
     */
    get position(): PanelLocation;
    set position(value: PanelLocation);
    /**
     * [descr:dxDrawerOptions.revealMode]
    
     */
    get revealMode(): RevealMode;
    set revealMode(value: RevealMode);
    /**
     * [descr:DOMComponentOptions.rtlEnabled]
    
     */
    get rtlEnabled(): boolean;
    set rtlEnabled(value: boolean);
    /**
     * [descr:dxDrawerOptions.shading]
    
     */
    get shading(): boolean;
    set shading(value: boolean);
    /**
     * [descr:dxDrawerOptions.template]
    
     */
    get template(): any;
    set template(value: any);
    /**
     * [descr:WidgetOptions.visible]
    
     */
    get visible(): boolean;
    set visible(value: boolean);
    /**
     * [descr:DOMComponentOptions.width]
    
     */
    get width(): number | string | undefined;
    set width(value: number | string | undefined);
    /**
    
     * [descr:dxDrawerOptions.onDisposing]
    
    
     */
    onDisposing: EventEmitter<DisposingEvent>;
    /**
    
     * [descr:dxDrawerOptions.onInitialized]
    
    
     */
    onInitialized: EventEmitter<InitializedEvent>;
    /**
    
     * [descr:dxDrawerOptions.onOptionChanged]
    
    
     */
    onOptionChanged: EventEmitter<OptionChangedEvent>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    activeStateEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    animationDurationChange: EventEmitter<number>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    animationEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    closeOnOutsideClickChange: EventEmitter<boolean | ((event: event) => boolean)>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    disabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    elementAttrChange: EventEmitter<Record<string, any>>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    heightChange: EventEmitter<number | string | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    hintChange: EventEmitter<string | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    hoverStateEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    maxSizeChange: EventEmitter<null | number>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    minSizeChange: EventEmitter<null | number>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    openedChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    openedStateModeChange: EventEmitter<OpenedStateMode>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    positionChange: EventEmitter<PanelLocation>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    revealModeChange: EventEmitter<RevealMode>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    rtlEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    shadingChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    templateChange: EventEmitter<any>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    visibleChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    widthChange: EventEmitter<number | string | undefined>;
    constructor(elementRef: ElementRef, ngZone: NgZone, templateHost: DxTemplateHost, _watcherHelper: WatcherHelper, optionHost: NestedOptionHost, transferState: TransferState, platformId: any);
    protected _createInstance(element: any, options: any): DxDrawer;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxDrawerComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxDrawerComponent, "dx-drawer", never, { "activeStateEnabled": { "alias": "activeStateEnabled"; "required": false; }; "animationDuration": { "alias": "animationDuration"; "required": false; }; "animationEnabled": { "alias": "animationEnabled"; "required": false; }; "closeOnOutsideClick": { "alias": "closeOnOutsideClick"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "elementAttr": { "alias": "elementAttr"; "required": false; }; "height": { "alias": "height"; "required": false; }; "hint": { "alias": "hint"; "required": false; }; "hoverStateEnabled": { "alias": "hoverStateEnabled"; "required": false; }; "maxSize": { "alias": "maxSize"; "required": false; }; "minSize": { "alias": "minSize"; "required": false; }; "opened": { "alias": "opened"; "required": false; }; "openedStateMode": { "alias": "openedStateMode"; "required": false; }; "position": { "alias": "position"; "required": false; }; "revealMode": { "alias": "revealMode"; "required": false; }; "rtlEnabled": { "alias": "rtlEnabled"; "required": false; }; "shading": { "alias": "shading"; "required": false; }; "template": { "alias": "template"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, { "onDisposing": "onDisposing"; "onInitialized": "onInitialized"; "onOptionChanged": "onOptionChanged"; "activeStateEnabledChange": "activeStateEnabledChange"; "animationDurationChange": "animationDurationChange"; "animationEnabledChange": "animationEnabledChange"; "closeOnOutsideClickChange": "closeOnOutsideClickChange"; "disabledChange": "disabledChange"; "elementAttrChange": "elementAttrChange"; "heightChange": "heightChange"; "hintChange": "hintChange"; "hoverStateEnabledChange": "hoverStateEnabledChange"; "maxSizeChange": "maxSizeChange"; "minSizeChange": "minSizeChange"; "openedChange": "openedChange"; "openedStateModeChange": "openedStateModeChange"; "positionChange": "positionChange"; "revealModeChange": "revealModeChange"; "rtlEnabledChange": "rtlEnabledChange"; "shadingChange": "shadingChange"; "templateChange": "templateChange"; "visibleChange": "visibleChange"; "widthChange": "widthChange"; }, never, ["*"], true, never>;
}
declare class DxDrawerModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxDrawerModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxDrawerModule, never, [typeof DxDrawerComponent, typeof i1.DxIntegrationModule, typeof i1.DxTemplateModule], [typeof DxDrawerComponent, typeof i1.DxTemplateModule]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxDrawerModule>;
}

export { DxDrawerComponent, DxDrawerModule };
//# sourceMappingURL=index.d.ts.map
