import * as i0 from '@angular/core';
import { OnDestroy, OnInit, AfterViewInit, QueryList, Renderer2, ElementRef } from '@angular/core';
import { AnimationConfig, CollisionResolution, PositionConfig, AnimationState, AnimationType, CollisionResolutionCombination } from 'devextreme/common/core/animation';
import { NestedOption, NestedOptionHost, CollectionNestedOption, IDxTemplateHost, DxTemplateHost, DxTemplateDirective } from 'devextreme-angular/core';
import { HorizontalAlignment, VerticalAlignment, Direction, PositionAlignment, SubmenuShowMode } from 'devextreme/common';
import { dxContextMenuItem } from 'devextreme/ui/context_menu';

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoContextMenuAnimationComponent extends NestedOption implements OnDestroy, OnInit {
    get hide(): AnimationConfig;
    set hide(value: AnimationConfig);
    get show(): AnimationConfig;
    set show(value: AnimationConfig);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoContextMenuAnimationComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoContextMenuAnimationComponent, "dxo-context-menu-animation", never, { "hide": { "alias": "hide"; "required": false; }; "show": { "alias": "show"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoContextMenuAnimationModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoContextMenuAnimationModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoContextMenuAnimationModule, never, [typeof DxoContextMenuAnimationComponent], [typeof DxoContextMenuAnimationComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoContextMenuAnimationModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoContextMenuAtComponent extends NestedOption implements OnDestroy, OnInit {
    get x(): HorizontalAlignment;
    set x(value: HorizontalAlignment);
    get y(): VerticalAlignment;
    set y(value: VerticalAlignment);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoContextMenuAtComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoContextMenuAtComponent, "dxo-context-menu-at", never, { "x": { "alias": "x"; "required": false; }; "y": { "alias": "y"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoContextMenuAtModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoContextMenuAtModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoContextMenuAtModule, never, [typeof DxoContextMenuAtComponent], [typeof DxoContextMenuAtComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoContextMenuAtModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoContextMenuBoundaryOffsetComponent extends NestedOption implements OnDestroy, OnInit {
    get x(): number;
    set x(value: number);
    get y(): number;
    set y(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoContextMenuBoundaryOffsetComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoContextMenuBoundaryOffsetComponent, "dxo-context-menu-boundary-offset", never, { "x": { "alias": "x"; "required": false; }; "y": { "alias": "y"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoContextMenuBoundaryOffsetModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoContextMenuBoundaryOffsetModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoContextMenuBoundaryOffsetModule, never, [typeof DxoContextMenuBoundaryOffsetComponent], [typeof DxoContextMenuBoundaryOffsetComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoContextMenuBoundaryOffsetModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoContextMenuCollisionComponent extends NestedOption implements OnDestroy, OnInit {
    get x(): CollisionResolution;
    set x(value: CollisionResolution);
    get y(): CollisionResolution;
    set y(value: CollisionResolution);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoContextMenuCollisionComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoContextMenuCollisionComponent, "dxo-context-menu-collision", never, { "x": { "alias": "x"; "required": false; }; "y": { "alias": "y"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoContextMenuCollisionModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoContextMenuCollisionModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoContextMenuCollisionModule, never, [typeof DxoContextMenuCollisionComponent], [typeof DxoContextMenuCollisionComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoContextMenuCollisionModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoContextMenuDelayComponent extends NestedOption implements OnDestroy, OnInit {
    get hide(): number;
    set hide(value: number);
    get show(): number;
    set show(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoContextMenuDelayComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoContextMenuDelayComponent, "dxo-context-menu-delay", never, { "hide": { "alias": "hide"; "required": false; }; "show": { "alias": "show"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoContextMenuDelayModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoContextMenuDelayModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoContextMenuDelayModule, never, [typeof DxoContextMenuDelayComponent], [typeof DxoContextMenuDelayComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoContextMenuDelayModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoContextMenuFromComponent extends NestedOption implements OnDestroy, OnInit {
    get left(): number;
    set left(value: number);
    get opacity(): number;
    set opacity(value: number);
    get position(): PositionConfig;
    set position(value: PositionConfig);
    get scale(): number;
    set scale(value: number);
    get top(): number;
    set top(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoContextMenuFromComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoContextMenuFromComponent, "dxo-context-menu-from", never, { "left": { "alias": "left"; "required": false; }; "opacity": { "alias": "opacity"; "required": false; }; "position": { "alias": "position"; "required": false; }; "scale": { "alias": "scale"; "required": false; }; "top": { "alias": "top"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoContextMenuFromModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoContextMenuFromModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoContextMenuFromModule, never, [typeof DxoContextMenuFromComponent], [typeof DxoContextMenuFromComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoContextMenuFromModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoContextMenuHideComponent extends NestedOption implements OnDestroy, OnInit {
    get complete(): (($element: any, config: AnimationConfig) => void);
    set complete(value: (($element: any, config: AnimationConfig) => void));
    get delay(): number;
    set delay(value: number);
    get direction(): Direction | undefined;
    set direction(value: Direction | undefined);
    get duration(): number;
    set duration(value: number);
    get easing(): string;
    set easing(value: string);
    get from(): AnimationState;
    set from(value: AnimationState);
    get staggerDelay(): number | undefined;
    set staggerDelay(value: number | undefined);
    get start(): (($element: any, config: AnimationConfig) => void);
    set start(value: (($element: any, config: AnimationConfig) => void));
    get to(): AnimationState;
    set to(value: AnimationState);
    get type(): AnimationType;
    set type(value: AnimationType);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoContextMenuHideComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoContextMenuHideComponent, "dxo-context-menu-hide", never, { "complete": { "alias": "complete"; "required": false; }; "delay": { "alias": "delay"; "required": false; }; "direction": { "alias": "direction"; "required": false; }; "duration": { "alias": "duration"; "required": false; }; "easing": { "alias": "easing"; "required": false; }; "from": { "alias": "from"; "required": false; }; "staggerDelay": { "alias": "staggerDelay"; "required": false; }; "start": { "alias": "start"; "required": false; }; "to": { "alias": "to"; "required": false; }; "type": { "alias": "type"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoContextMenuHideModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoContextMenuHideModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoContextMenuHideModule, never, [typeof DxoContextMenuHideComponent], [typeof DxoContextMenuHideComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoContextMenuHideModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxiContextMenuItemComponent extends CollectionNestedOption implements AfterViewInit, IDxTemplateHost {
    private renderer;
    private document;
    private element;
    set _itemsContentChildren(value: QueryList<CollectionNestedOption>);
    get beginGroup(): boolean;
    set beginGroup(value: boolean);
    get closeMenuOnClick(): boolean;
    set closeMenuOnClick(value: boolean);
    get disabled(): boolean;
    set disabled(value: boolean);
    get icon(): string;
    set icon(value: string);
    get items(): Array<dxContextMenuItem>;
    set items(value: Array<dxContextMenuItem>);
    get selectable(): boolean;
    set selectable(value: boolean);
    get selected(): boolean;
    set selected(value: boolean);
    get template(): any;
    set template(value: any);
    get text(): string;
    set text(value: string);
    get visible(): boolean;
    set visible(value: boolean);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost, renderer: Renderer2, document: any, templateHost: DxTemplateHost, element: ElementRef);
    setTemplate(template: DxTemplateDirective): void;
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiContextMenuItemComponent, [{ host: true; skipSelf: true; }, { host: true; }, null, null, { host: true; }, null]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiContextMenuItemComponent, "dxi-context-menu-item", never, { "beginGroup": { "alias": "beginGroup"; "required": false; }; "closeMenuOnClick": { "alias": "closeMenuOnClick"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "icon": { "alias": "icon"; "required": false; }; "items": { "alias": "items"; "required": false; }; "selectable": { "alias": "selectable"; "required": false; }; "selected": { "alias": "selected"; "required": false; }; "template": { "alias": "template"; "required": false; }; "text": { "alias": "text"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; }, {}, ["_itemsContentChildren"], ["*"], true, never>;
}
declare class DxiContextMenuItemModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiContextMenuItemModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiContextMenuItemModule, never, [typeof DxiContextMenuItemComponent], [typeof DxiContextMenuItemComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiContextMenuItemModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoContextMenuMyComponent extends NestedOption implements OnDestroy, OnInit {
    get x(): HorizontalAlignment;
    set x(value: HorizontalAlignment);
    get y(): VerticalAlignment;
    set y(value: VerticalAlignment);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoContextMenuMyComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoContextMenuMyComponent, "dxo-context-menu-my", never, { "x": { "alias": "x"; "required": false; }; "y": { "alias": "y"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoContextMenuMyModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoContextMenuMyModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoContextMenuMyModule, never, [typeof DxoContextMenuMyComponent], [typeof DxoContextMenuMyComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoContextMenuMyModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoContextMenuOffsetComponent extends NestedOption implements OnDestroy, OnInit {
    get x(): number;
    set x(value: number);
    get y(): number;
    set y(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoContextMenuOffsetComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoContextMenuOffsetComponent, "dxo-context-menu-offset", never, { "x": { "alias": "x"; "required": false; }; "y": { "alias": "y"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoContextMenuOffsetModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoContextMenuOffsetModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoContextMenuOffsetModule, never, [typeof DxoContextMenuOffsetComponent], [typeof DxoContextMenuOffsetComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoContextMenuOffsetModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoContextMenuPositionComponent extends NestedOption implements OnDestroy, OnInit {
    get at(): PositionAlignment | {
        x?: HorizontalAlignment;
        y?: VerticalAlignment;
    };
    set at(value: PositionAlignment | {
        x?: HorizontalAlignment;
        y?: VerticalAlignment;
    });
    get boundary(): any | string;
    set boundary(value: any | string);
    get boundaryOffset(): string | {
        x?: number;
        y?: number;
    };
    set boundaryOffset(value: string | {
        x?: number;
        y?: number;
    });
    get collision(): CollisionResolutionCombination | {
        x?: CollisionResolution;
        y?: CollisionResolution;
    };
    set collision(value: CollisionResolutionCombination | {
        x?: CollisionResolution;
        y?: CollisionResolution;
    });
    get my(): PositionAlignment | {
        x?: HorizontalAlignment;
        y?: VerticalAlignment;
    };
    set my(value: PositionAlignment | {
        x?: HorizontalAlignment;
        y?: VerticalAlignment;
    });
    get of(): any | string;
    set of(value: any | string);
    get offset(): string | {
        x?: number;
        y?: number;
    };
    set offset(value: string | {
        x?: number;
        y?: number;
    });
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoContextMenuPositionComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoContextMenuPositionComponent, "dxo-context-menu-position", never, { "at": { "alias": "at"; "required": false; }; "boundary": { "alias": "boundary"; "required": false; }; "boundaryOffset": { "alias": "boundaryOffset"; "required": false; }; "collision": { "alias": "collision"; "required": false; }; "my": { "alias": "my"; "required": false; }; "of": { "alias": "of"; "required": false; }; "offset": { "alias": "offset"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoContextMenuPositionModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoContextMenuPositionModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoContextMenuPositionModule, never, [typeof DxoContextMenuPositionComponent], [typeof DxoContextMenuPositionComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoContextMenuPositionModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoContextMenuShowEventComponent extends NestedOption implements OnDestroy, OnInit {
    get delay(): number | undefined;
    set delay(value: number | undefined);
    get name(): string | undefined;
    set name(value: string | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoContextMenuShowEventComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoContextMenuShowEventComponent, "dxo-context-menu-show-event", never, { "delay": { "alias": "delay"; "required": false; }; "name": { "alias": "name"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoContextMenuShowEventModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoContextMenuShowEventModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoContextMenuShowEventModule, never, [typeof DxoContextMenuShowEventComponent], [typeof DxoContextMenuShowEventComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoContextMenuShowEventModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoContextMenuShowSubmenuModeComponent extends NestedOption implements OnDestroy, OnInit {
    get delay(): number | {
        hide?: number;
        show?: number;
    };
    set delay(value: number | {
        hide?: number;
        show?: number;
    });
    get name(): SubmenuShowMode;
    set name(value: SubmenuShowMode);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoContextMenuShowSubmenuModeComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoContextMenuShowSubmenuModeComponent, "dxo-context-menu-show-submenu-mode", never, { "delay": { "alias": "delay"; "required": false; }; "name": { "alias": "name"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoContextMenuShowSubmenuModeModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoContextMenuShowSubmenuModeModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoContextMenuShowSubmenuModeModule, never, [typeof DxoContextMenuShowSubmenuModeComponent], [typeof DxoContextMenuShowSubmenuModeComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoContextMenuShowSubmenuModeModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoContextMenuShowComponent extends NestedOption implements OnDestroy, OnInit {
    get complete(): (($element: any, config: AnimationConfig) => void);
    set complete(value: (($element: any, config: AnimationConfig) => void));
    get delay(): number;
    set delay(value: number);
    get direction(): Direction | undefined;
    set direction(value: Direction | undefined);
    get duration(): number;
    set duration(value: number);
    get easing(): string;
    set easing(value: string);
    get from(): AnimationState;
    set from(value: AnimationState);
    get staggerDelay(): number | undefined;
    set staggerDelay(value: number | undefined);
    get start(): (($element: any, config: AnimationConfig) => void);
    set start(value: (($element: any, config: AnimationConfig) => void));
    get to(): AnimationState;
    set to(value: AnimationState);
    get type(): AnimationType;
    set type(value: AnimationType);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoContextMenuShowComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoContextMenuShowComponent, "dxo-context-menu-show", never, { "complete": { "alias": "complete"; "required": false; }; "delay": { "alias": "delay"; "required": false; }; "direction": { "alias": "direction"; "required": false; }; "duration": { "alias": "duration"; "required": false; }; "easing": { "alias": "easing"; "required": false; }; "from": { "alias": "from"; "required": false; }; "staggerDelay": { "alias": "staggerDelay"; "required": false; }; "start": { "alias": "start"; "required": false; }; "to": { "alias": "to"; "required": false; }; "type": { "alias": "type"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoContextMenuShowModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoContextMenuShowModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoContextMenuShowModule, never, [typeof DxoContextMenuShowComponent], [typeof DxoContextMenuShowComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoContextMenuShowModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoContextMenuToComponent extends NestedOption implements OnDestroy, OnInit {
    get left(): number;
    set left(value: number);
    get opacity(): number;
    set opacity(value: number);
    get position(): PositionConfig;
    set position(value: PositionConfig);
    get scale(): number;
    set scale(value: number);
    get top(): number;
    set top(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoContextMenuToComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoContextMenuToComponent, "dxo-context-menu-to", never, { "left": { "alias": "left"; "required": false; }; "opacity": { "alias": "opacity"; "required": false; }; "position": { "alias": "position"; "required": false; }; "scale": { "alias": "scale"; "required": false; }; "top": { "alias": "top"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoContextMenuToModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoContextMenuToModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoContextMenuToModule, never, [typeof DxoContextMenuToComponent], [typeof DxoContextMenuToComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoContextMenuToModule>;
}

export { DxiContextMenuItemComponent, DxiContextMenuItemModule, DxoContextMenuAnimationComponent, DxoContextMenuAnimationModule, DxoContextMenuAtComponent, DxoContextMenuAtModule, DxoContextMenuBoundaryOffsetComponent, DxoContextMenuBoundaryOffsetModule, DxoContextMenuCollisionComponent, DxoContextMenuCollisionModule, DxoContextMenuDelayComponent, DxoContextMenuDelayModule, DxoContextMenuFromComponent, DxoContextMenuFromModule, DxoContextMenuHideComponent, DxoContextMenuHideModule, DxoContextMenuMyComponent, DxoContextMenuMyModule, DxoContextMenuOffsetComponent, DxoContextMenuOffsetModule, DxoContextMenuPositionComponent, DxoContextMenuPositionModule, DxoContextMenuShowComponent, DxoContextMenuShowEventComponent, DxoContextMenuShowEventModule, DxoContextMenuShowModule, DxoContextMenuShowSubmenuModeComponent, DxoContextMenuShowSubmenuModeModule, DxoContextMenuToComponent, DxoContextMenuToModule };
//# sourceMappingURL=index.d.ts.map
