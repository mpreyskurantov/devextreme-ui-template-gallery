import * as i0 from '@angular/core';
import { OnDestroy, OnChanges, DoCheck, EventEmitter, ElementRef, NgZone, TransferState, SimpleChanges } from '@angular/core';
import DxCheckBox, { ContentReadyEvent, DisposingEvent, InitializedEvent, OptionChangedEvent, ValueChangedEvent } from 'devextreme/ui/check_box';
import { ValidationMessageMode, Position, ValidationStatus } from 'devextreme/common';
import { ControlValueAccessor } from '@angular/forms';
import * as i1 from 'devextreme-angular/core';
import { DxComponent, DxTemplateHost, WatcherHelper, IterableDifferHelper, NestedOptionHost } from 'devextreme-angular/core';
import * as check_box_types from 'devextreme/ui/check_box_types';
export { check_box_types as DxCheckBoxTypes };

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

/**
 * [descr:dxCheckBox]

 */
declare class DxCheckBoxComponent extends DxComponent implements OnDestroy, ControlValueAccessor, OnChanges, DoCheck {
    private _watcherHelper;
    private _idh;
    instance: DxCheckBox;
    /**
     * [descr:WidgetOptions.accessKey]
    
     */
    get accessKey(): string | undefined;
    set accessKey(value: string | undefined);
    /**
     * [descr:dxCheckBoxOptions.activeStateEnabled]
    
     */
    get activeStateEnabled(): boolean;
    set activeStateEnabled(value: boolean);
    /**
     * [descr:WidgetOptions.disabled]
    
     */
    get disabled(): boolean;
    set disabled(value: boolean);
    /**
     * [descr:DOMComponentOptions.elementAttr]
    
     */
    get elementAttr(): Record<string, any>;
    set elementAttr(value: Record<string, any>);
    /**
     * [descr:dxCheckBoxOptions.enableThreeStateBehavior]
    
     */
    get enableThreeStateBehavior(): boolean;
    set enableThreeStateBehavior(value: boolean);
    /**
     * [descr:dxCheckBoxOptions.focusStateEnabled]
    
     */
    get focusStateEnabled(): boolean;
    set focusStateEnabled(value: boolean);
    /**
     * [descr:DOMComponentOptions.height]
    
     */
    get height(): number | string | undefined;
    set height(value: number | string | undefined);
    /**
     * [descr:WidgetOptions.hint]
    
     */
    get hint(): string | undefined;
    set hint(value: string | undefined);
    /**
     * [descr:dxCheckBoxOptions.hoverStateEnabled]
    
     */
    get hoverStateEnabled(): boolean;
    set hoverStateEnabled(value: boolean);
    /**
     * [descr:dxCheckBoxOptions.iconSize]
    
     */
    get iconSize(): number | string | undefined;
    set iconSize(value: number | string | undefined);
    /**
     * [descr:EditorOptions.isDirty]
    
     */
    get isDirty(): boolean;
    set isDirty(value: boolean);
    /**
     * [descr:EditorOptions.isValid]
    
     */
    get isValid(): boolean;
    set isValid(value: boolean);
    /**
     * [descr:dxCheckBoxOptions.name]
    
     */
    get name(): string;
    set name(value: string);
    /**
     * [descr:EditorOptions.readOnly]
    
     */
    get readOnly(): boolean;
    set readOnly(value: boolean);
    /**
     * [descr:DOMComponentOptions.rtlEnabled]
    
     */
    get rtlEnabled(): boolean;
    set rtlEnabled(value: boolean);
    /**
     * [descr:WidgetOptions.tabIndex]
    
     */
    get tabIndex(): number;
    set tabIndex(value: number);
    /**
     * [descr:dxCheckBoxOptions.text]
    
     */
    get text(): string;
    set text(value: string);
    /**
     * [descr:EditorOptions.validationError]
    
     */
    get validationError(): any | null;
    set validationError(value: any | null);
    /**
     * [descr:EditorOptions.validationErrors]
    
     */
    get validationErrors(): Array<any> | null;
    set validationErrors(value: Array<any> | null);
    /**
     * [descr:EditorOptions.validationMessageMode]
    
     */
    get validationMessageMode(): ValidationMessageMode;
    set validationMessageMode(value: ValidationMessageMode);
    /**
     * [descr:EditorOptions.validationMessagePosition]
    
     */
    get validationMessagePosition(): Position;
    set validationMessagePosition(value: Position);
    /**
     * [descr:EditorOptions.validationStatus]
    
     */
    get validationStatus(): ValidationStatus;
    set validationStatus(value: ValidationStatus);
    /**
     * [descr:dxCheckBoxOptions.value]
    
     */
    get value(): boolean | null;
    set value(value: boolean | null);
    /**
     * [descr:WidgetOptions.visible]
    
     */
    get visible(): boolean;
    set visible(value: boolean);
    /**
     * [descr:DOMComponentOptions.width]
    
     */
    get width(): number | string | undefined;
    set width(value: number | string | undefined);
    /**
    
     * [descr:dxCheckBoxOptions.onContentReady]
    
    
     */
    onContentReady: EventEmitter<ContentReadyEvent>;
    /**
    
     * [descr:dxCheckBoxOptions.onDisposing]
    
    
     */
    onDisposing: EventEmitter<DisposingEvent>;
    /**
    
     * [descr:dxCheckBoxOptions.onInitialized]
    
    
     */
    onInitialized: EventEmitter<InitializedEvent>;
    /**
    
     * [descr:dxCheckBoxOptions.onOptionChanged]
    
    
     */
    onOptionChanged: EventEmitter<OptionChangedEvent>;
    /**
    
     * [descr:dxCheckBoxOptions.onValueChanged]
    
    
     */
    onValueChanged: EventEmitter<ValueChangedEvent>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    accessKeyChange: EventEmitter<string | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    activeStateEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    disabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    elementAttrChange: EventEmitter<Record<string, any>>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    enableThreeStateBehaviorChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    focusStateEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    heightChange: EventEmitter<number | string | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    hintChange: EventEmitter<string | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    hoverStateEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    iconSizeChange: EventEmitter<number | string | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    isDirtyChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    isValidChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    nameChange: EventEmitter<string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    readOnlyChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    rtlEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    tabIndexChange: EventEmitter<number>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    textChange: EventEmitter<string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    validationErrorChange: EventEmitter<any | null>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    validationErrorsChange: EventEmitter<Array<any> | null>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    validationMessageModeChange: EventEmitter<ValidationMessageMode>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    validationMessagePositionChange: EventEmitter<Position>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    validationStatusChange: EventEmitter<ValidationStatus>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    valueChange: EventEmitter<boolean | null>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    visibleChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    widthChange: EventEmitter<number | string | undefined>;
    /**
    
     * [descr:undefined]
    
    
     */
    onBlur: EventEmitter<any>;
    change(_: any): void;
    touched: (_: any) => void;
    constructor(elementRef: ElementRef, ngZone: NgZone, templateHost: DxTemplateHost, _watcherHelper: WatcherHelper, _idh: IterableDifferHelper, optionHost: NestedOptionHost, transferState: TransferState, platformId: any);
    protected _createInstance(element: any, options: any): DxCheckBox;
    writeValue(value: any): void;
    setDisabledState(isDisabled: boolean): void;
    registerOnChange(fn: (_: any) => void): void;
    registerOnTouched(fn: () => void): void;
    _createWidget(element: any): void;
    ngOnDestroy(): void;
    ngOnChanges(changes: SimpleChanges): void;
    setupChanges(prop: string, changes: SimpleChanges): void;
    ngDoCheck(): void;
    _setOption(name: string, value: any): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxCheckBoxComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxCheckBoxComponent, "dx-check-box", never, { "accessKey": { "alias": "accessKey"; "required": false; }; "activeStateEnabled": { "alias": "activeStateEnabled"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "elementAttr": { "alias": "elementAttr"; "required": false; }; "enableThreeStateBehavior": { "alias": "enableThreeStateBehavior"; "required": false; }; "focusStateEnabled": { "alias": "focusStateEnabled"; "required": false; }; "height": { "alias": "height"; "required": false; }; "hint": { "alias": "hint"; "required": false; }; "hoverStateEnabled": { "alias": "hoverStateEnabled"; "required": false; }; "iconSize": { "alias": "iconSize"; "required": false; }; "isDirty": { "alias": "isDirty"; "required": false; }; "isValid": { "alias": "isValid"; "required": false; }; "name": { "alias": "name"; "required": false; }; "readOnly": { "alias": "readOnly"; "required": false; }; "rtlEnabled": { "alias": "rtlEnabled"; "required": false; }; "tabIndex": { "alias": "tabIndex"; "required": false; }; "text": { "alias": "text"; "required": false; }; "validationError": { "alias": "validationError"; "required": false; }; "validationErrors": { "alias": "validationErrors"; "required": false; }; "validationMessageMode": { "alias": "validationMessageMode"; "required": false; }; "validationMessagePosition": { "alias": "validationMessagePosition"; "required": false; }; "validationStatus": { "alias": "validationStatus"; "required": false; }; "value": { "alias": "value"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, { "onContentReady": "onContentReady"; "onDisposing": "onDisposing"; "onInitialized": "onInitialized"; "onOptionChanged": "onOptionChanged"; "onValueChanged": "onValueChanged"; "accessKeyChange": "accessKeyChange"; "activeStateEnabledChange": "activeStateEnabledChange"; "disabledChange": "disabledChange"; "elementAttrChange": "elementAttrChange"; "enableThreeStateBehaviorChange": "enableThreeStateBehaviorChange"; "focusStateEnabledChange": "focusStateEnabledChange"; "heightChange": "heightChange"; "hintChange": "hintChange"; "hoverStateEnabledChange": "hoverStateEnabledChange"; "iconSizeChange": "iconSizeChange"; "isDirtyChange": "isDirtyChange"; "isValidChange": "isValidChange"; "nameChange": "nameChange"; "readOnlyChange": "readOnlyChange"; "rtlEnabledChange": "rtlEnabledChange"; "tabIndexChange": "tabIndexChange"; "textChange": "textChange"; "validationErrorChange": "validationErrorChange"; "validationErrorsChange": "validationErrorsChange"; "validationMessageModeChange": "validationMessageModeChange"; "validationMessagePositionChange": "validationMessagePositionChange"; "validationStatusChange": "validationStatusChange"; "valueChange": "valueChange"; "visibleChange": "visibleChange"; "widthChange": "widthChange"; "onBlur": "onBlur"; }, never, never, true, never>;
}
declare class DxCheckBoxModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxCheckBoxModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxCheckBoxModule, never, [typeof DxCheckBoxComponent, typeof i1.DxIntegrationModule, typeof i1.DxTemplateModule], [typeof DxCheckBoxComponent, typeof i1.DxTemplateModule]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxCheckBoxModule>;
}

export { DxCheckBoxComponent, DxCheckBoxModule };
//# sourceMappingURL=index.d.ts.map
