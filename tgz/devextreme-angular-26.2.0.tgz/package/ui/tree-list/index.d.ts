import * as i0 from '@angular/core';
import { OnDestroy, OnChanges, DoCheck, QueryList, EventEmitter, ElementRef, NgZone, TransferState, SimpleChanges } from '@angular/core';
import { AIAssistant, ColumnChooser, ColumnResizeMode, DataChange, GridsEditMode, GridsEditRefreshMode, StartEditAction, FilterPanel, ApplyFilterMode, HeaderFilter, EnterKeyAction, EnterKeyDirection, Pager, DataRenderMode, SearchPanel, Sorting, StateStoreType } from 'devextreme/common/grids';
import { AIIntegration } from 'devextreme/common/ai-integration';
import dxTreeList, { dxTreeListColumn, dxTreeListRowObject, TreeListFilterMode, RowDraggingAddEvent, RowDraggingChangeEvent, RowDraggingEndEvent, RowDraggingMoveEvent, RowDraggingStartEvent, RowDraggingRemoveEvent, RowDraggingReorderEvent, dxTreeListToolbar, AdaptiveDetailRowPreparingEvent, AIAssistantRequestCreatingEvent, AIColumnRequestCreatingEvent, CellClickEvent, CellDblClickEvent, CellHoverChangedEvent, CellPreparedEvent, ContentReadyEvent, ContextMenuPreparingEvent, DataErrorOccurredEvent, DisposingEvent, EditCanceledEvent, EditCancelingEvent, EditingStartEvent, EditorPreparedEvent, EditorPreparingEvent, FocusedCellChangedEvent, FocusedCellChangingEvent, FocusedRowChangedEvent, FocusedRowChangingEvent, InitializedEvent, InitNewRowEvent, KeyDownEvent, NodesInitializedEvent, OptionChangedEvent, RowClickEvent, RowCollapsedEvent, RowCollapsingEvent, RowDblClickEvent, RowExpandedEvent, RowExpandingEvent, RowInsertedEvent, RowInsertingEvent, RowPreparedEvent, RowRemovedEvent, RowRemovingEvent, RowUpdatedEvent, RowUpdatingEvent, RowValidatingEvent, SavedEvent, SavingEvent, SelectionChangedEvent, ToolbarPreparingEvent } from 'devextreme/ui/tree_list';
export { ExplicitTypes } from 'devextreme/ui/tree_list';
import { Mode, DataStructure, DragDirection, DragHighlight, ScrollMode, ScrollbarMode, SingleMultipleOrNone } from 'devextreme/common';
import DataSource, { DataSourceOptions } from 'devextreme/data/data_source';
import { Store } from 'devextreme/data/store';
import { dxFormOptions } from 'devextreme/ui/form';
import { dxPopupOptions } from 'devextreme/ui/popup';
import { dxFilterBuilderOptions } from 'devextreme/ui/filter_builder';
import { LoadPanelIndicatorProperties } from 'devextreme/ui/load_panel';
import * as i3 from 'devextreme-angular/core';
import { DxComponent, CollectionNestedOption, DxTemplateHost, WatcherHelper, IterableDifferHelper, NestedOptionHost } from 'devextreme-angular/core';
import * as i1 from 'devextreme-angular/ui/nested';
import * as i2 from 'devextreme-angular/ui/tree-list/nested';
export * from 'devextreme-angular/ui/tree-list/nested';
import * as tree_list_types from 'devextreme/ui/tree_list_types';
export { tree_list_types as DxTreeListTypes };

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

/**
 * [descr:dxTreeList]

 */
declare class DxTreeListComponent<TRowData = any, TKey = any> extends DxComponent implements OnDestroy, OnChanges, DoCheck {
    private _watcherHelper;
    private _idh;
    set _validationRulesContentChildren(value: QueryList<CollectionNestedOption>);
    set _buttonsContentChildren(value: QueryList<CollectionNestedOption>);
    set _itemsContentChildren(value: QueryList<CollectionNestedOption>);
    set _changesContentChildren(value: QueryList<CollectionNestedOption>);
    set _columnsContentChildren(value: QueryList<CollectionNestedOption>);
    set _customOperationsContentChildren(value: QueryList<CollectionNestedOption>);
    set _fieldsContentChildren(value: QueryList<CollectionNestedOption>);
    set _tabsContentChildren(value: QueryList<CollectionNestedOption>);
    set _toolbarItemsContentChildren(value: QueryList<CollectionNestedOption>);
    instance: dxTreeList<TRowData, TKey>;
    /**
     * [descr:WidgetOptions.accessKey]
    
     */
    get accessKey(): string | undefined;
    set accessKey(value: string | undefined);
    /**
     * [descr:WidgetOptions.activeStateEnabled]
    
     */
    get activeStateEnabled(): boolean;
    set activeStateEnabled(value: boolean);
    get aiAssistant(): AIAssistant;
    set aiAssistant(value: AIAssistant);
    /**
     * [descr:GridBaseOptions.aiIntegration]
    
     */
    get aiIntegration(): AIIntegration | undefined;
    set aiIntegration(value: AIIntegration | undefined);
    /**
     * [descr:GridBaseOptions.allowColumnReordering]
    
     */
    get allowColumnReordering(): boolean;
    set allowColumnReordering(value: boolean);
    /**
     * [descr:GridBaseOptions.allowColumnResizing]
    
     */
    get allowColumnResizing(): boolean;
    set allowColumnResizing(value: boolean);
    /**
     * [descr:dxTreeListOptions.autoExpandAll]
    
     */
    get autoExpandAll(): boolean;
    set autoExpandAll(value: boolean);
    /**
     * [descr:GridBaseOptions.autoNavigateToFocusedRow]
    
     */
    get autoNavigateToFocusedRow(): boolean;
    set autoNavigateToFocusedRow(value: boolean);
    /**
     * [descr:GridBaseOptions.cacheEnabled]
    
     */
    get cacheEnabled(): boolean;
    set cacheEnabled(value: boolean);
    /**
     * [descr:GridBaseOptions.cellHintEnabled]
    
     */
    get cellHintEnabled(): boolean;
    set cellHintEnabled(value: boolean);
    /**
     * [descr:GridBaseOptions.columnAutoWidth]
    
     */
    get columnAutoWidth(): boolean;
    set columnAutoWidth(value: boolean);
    /**
     * [descr:GridBaseOptions.columnChooser]
    
     */
    get columnChooser(): ColumnChooser;
    set columnChooser(value: ColumnChooser);
    /**
     * [descr:GridBaseOptions.columnFixing]
    
     */
    get columnFixing(): {
        enabled?: boolean;
        icons?: {
            fix?: string;
            leftPosition?: string;
            rightPosition?: string;
            stickyPosition?: string;
            unfix?: string;
        };
        texts?: {
            fix?: string;
            leftPosition?: string;
            rightPosition?: string;
            stickyPosition?: string;
            unfix?: string;
        };
    };
    set columnFixing(value: {
        enabled?: boolean;
        icons?: {
            fix?: string;
            leftPosition?: string;
            rightPosition?: string;
            stickyPosition?: string;
            unfix?: string;
        };
        texts?: {
            fix?: string;
            leftPosition?: string;
            rightPosition?: string;
            stickyPosition?: string;
            unfix?: string;
        };
    });
    /**
     * [descr:GridBaseOptions.columnHidingEnabled]
    
     */
    get columnHidingEnabled(): boolean;
    set columnHidingEnabled(value: boolean);
    /**
     * [descr:GridBaseOptions.columnMinWidth]
    
     */
    get columnMinWidth(): number | undefined;
    set columnMinWidth(value: number | undefined);
    /**
     * [descr:GridBaseOptions.columnResizingMode]
    
     */
    get columnResizingMode(): ColumnResizeMode;
    set columnResizingMode(value: ColumnResizeMode);
    /**
     * [descr:dxTreeListOptions.columns]
    
     */
    get columns(): Array<dxTreeListColumn | string>;
    set columns(value: Array<dxTreeListColumn | string>);
    /**
     * [descr:GridBaseOptions.columnWidth]
    
     */
    get columnWidth(): Mode | number | undefined;
    set columnWidth(value: Mode | number | undefined);
    /**
     * [descr:dxTreeListOptions.customizeColumns]
    
     */
    get customizeColumns(): ((columns: Array<dxTreeListColumn>) => void);
    set customizeColumns(value: ((columns: Array<dxTreeListColumn>) => void));
    /**
     * [descr:GridBaseOptions.dataSource]
    
     */
    get dataSource(): Array<any> | DataSource | DataSourceOptions | Store | string | undefined;
    set dataSource(value: Array<any> | DataSource | DataSourceOptions | Store | string | undefined);
    /**
     * [descr:dxTreeListOptions.dataStructure]
    
     */
    get dataStructure(): DataStructure;
    set dataStructure(value: DataStructure);
    /**
     * [descr:GridBaseOptions.dateSerializationFormat]
    
     */
    get dateSerializationFormat(): string;
    set dateSerializationFormat(value: string);
    /**
     * [descr:WidgetOptions.disabled]
    
     */
    get disabled(): boolean;
    set disabled(value: boolean);
    /**
     * [descr:dxTreeListOptions.editing]
    
     */
    get editing(): {
        allowAdding?: boolean | ((options: {
            component: dxTreeList;
            row: dxTreeListRowObject;
        }) => boolean);
        allowDeleting?: boolean | ((options: {
            component: dxTreeList;
            row: dxTreeListRowObject;
        }) => boolean);
        allowUpdating?: boolean | ((options: {
            component: dxTreeList;
            row: dxTreeListRowObject;
        }) => boolean);
        changes?: Array<DataChange>;
        confirmDelete?: boolean;
        editColumnName?: string | undefined;
        editRowKey?: any | undefined;
        form?: dxFormOptions;
        mode?: GridsEditMode;
        popup?: dxPopupOptions<any>;
        refreshMode?: GridsEditRefreshMode;
        selectTextOnEditStart?: boolean;
        startEditAction?: StartEditAction;
        texts?: {
            addRow?: string;
            addRowToNode?: string;
            cancelAllChanges?: string;
            cancelRowChanges?: string;
            confirmDeleteMessage?: string;
            confirmDeleteTitle?: string;
            deleteRow?: string;
            editRow?: string;
            saveAllChanges?: string;
            saveRowChanges?: string;
            undeleteRow?: string;
            validationCancelChanges?: string;
        };
        useIcons?: boolean;
    };
    set editing(value: {
        allowAdding?: boolean | ((options: {
            component: dxTreeList;
            row: dxTreeListRowObject;
        }) => boolean);
        allowDeleting?: boolean | ((options: {
            component: dxTreeList;
            row: dxTreeListRowObject;
        }) => boolean);
        allowUpdating?: boolean | ((options: {
            component: dxTreeList;
            row: dxTreeListRowObject;
        }) => boolean);
        changes?: Array<DataChange>;
        confirmDelete?: boolean;
        editColumnName?: string | undefined;
        editRowKey?: any | undefined;
        form?: dxFormOptions;
        mode?: GridsEditMode;
        popup?: dxPopupOptions<any>;
        refreshMode?: GridsEditRefreshMode;
        selectTextOnEditStart?: boolean;
        startEditAction?: StartEditAction;
        texts?: {
            addRow?: string;
            addRowToNode?: string;
            cancelAllChanges?: string;
            cancelRowChanges?: string;
            confirmDeleteMessage?: string;
            confirmDeleteTitle?: string;
            deleteRow?: string;
            editRow?: string;
            saveAllChanges?: string;
            saveRowChanges?: string;
            undeleteRow?: string;
            validationCancelChanges?: string;
        };
        useIcons?: boolean;
    });
    /**
     * [descr:DOMComponentOptions.elementAttr]
    
     */
    get elementAttr(): Record<string, any>;
    set elementAttr(value: Record<string, any>);
    /**
     * [descr:GridBaseOptions.errorRowEnabled]
    
     */
    get errorRowEnabled(): boolean;
    set errorRowEnabled(value: boolean);
    /**
     * [descr:dxTreeListOptions.expandedRowKeys]
    
     */
    get expandedRowKeys(): Array<any>;
    set expandedRowKeys(value: Array<any>);
    /**
     * [descr:dxTreeListOptions.expandNodesOnFiltering]
    
     */
    get expandNodesOnFiltering(): boolean;
    set expandNodesOnFiltering(value: boolean);
    /**
     * [descr:GridBaseOptions.filterBuilder]
    
     */
    get filterBuilder(): dxFilterBuilderOptions;
    set filterBuilder(value: dxFilterBuilderOptions);
    /**
     * [descr:GridBaseOptions.filterBuilderPopup]
    
     */
    get filterBuilderPopup(): dxPopupOptions<any>;
    set filterBuilderPopup(value: dxPopupOptions<any>);
    /**
     * [descr:dxTreeListOptions.filterMode]
    
     */
    get filterMode(): TreeListFilterMode;
    set filterMode(value: TreeListFilterMode);
    /**
     * [descr:GridBaseOptions.filterPanel]
    
     */
    get filterPanel(): FilterPanel;
    set filterPanel(value: FilterPanel);
    /**
     * [descr:GridBaseOptions.filterRow]
    
     */
    get filterRow(): {
        applyFilter?: ApplyFilterMode;
        applyFilterText?: string;
        betweenEndText?: string;
        betweenStartText?: string;
        operationDescriptions?: {
            between?: string;
            contains?: string;
            endsWith?: string;
            equal?: string;
            greaterThan?: string;
            greaterThanOrEqual?: string;
            lessThan?: string;
            lessThanOrEqual?: string;
            notContains?: string;
            notEqual?: string;
            startsWith?: string;
        };
        resetOperationText?: string;
        showAllText?: string;
        showOperationChooser?: boolean;
        visible?: boolean;
    };
    set filterRow(value: {
        applyFilter?: ApplyFilterMode;
        applyFilterText?: string;
        betweenEndText?: string;
        betweenStartText?: string;
        operationDescriptions?: {
            between?: string;
            contains?: string;
            endsWith?: string;
            equal?: string;
            greaterThan?: string;
            greaterThanOrEqual?: string;
            lessThan?: string;
            lessThanOrEqual?: string;
            notContains?: string;
            notEqual?: string;
            startsWith?: string;
        };
        resetOperationText?: string;
        showAllText?: string;
        showOperationChooser?: boolean;
        visible?: boolean;
    });
    /**
     * [descr:GridBaseOptions.filterSyncEnabled]
    
     */
    get filterSyncEnabled(): boolean | Mode;
    set filterSyncEnabled(value: boolean | Mode);
    /**
     * [descr:GridBaseOptions.filterValue]
    
     */
    get filterValue(): Array<any> | Function | string;
    set filterValue(value: Array<any> | Function | string);
    /**
     * [descr:GridBaseOptions.focusedColumnIndex]
    
     */
    get focusedColumnIndex(): number;
    set focusedColumnIndex(value: number);
    /**
     * [descr:GridBaseOptions.focusedRowEnabled]
    
     */
    get focusedRowEnabled(): boolean;
    set focusedRowEnabled(value: boolean);
    /**
     * [descr:GridBaseOptions.focusedRowIndex]
    
     */
    get focusedRowIndex(): number;
    set focusedRowIndex(value: number);
    /**
     * [descr:GridBaseOptions.focusedRowKey]
    
     */
    get focusedRowKey(): any | undefined;
    set focusedRowKey(value: any | undefined);
    /**
     * [descr:dxTreeListOptions.hasItemsExpr]
    
     */
    get hasItemsExpr(): ((item: any, value: boolean | undefined) => boolean | undefined) | string;
    set hasItemsExpr(value: ((item: any, value: boolean | undefined) => boolean | undefined) | string);
    /**
     * [descr:GridBaseOptions.headerFilter]
    
     */
    get headerFilter(): HeaderFilter;
    set headerFilter(value: HeaderFilter);
    /**
     * [descr:DOMComponentOptions.height]
    
     */
    get height(): number | string | undefined;
    set height(value: number | string | undefined);
    /**
     * [descr:GridBaseOptions.highlightChanges]
    
     */
    get highlightChanges(): boolean;
    set highlightChanges(value: boolean);
    /**
     * [descr:WidgetOptions.hint]
    
     */
    get hint(): string | undefined;
    set hint(value: string | undefined);
    /**
     * [descr:WidgetOptions.hoverStateEnabled]
    
     */
    get hoverStateEnabled(): boolean;
    set hoverStateEnabled(value: boolean);
    /**
     * [descr:dxTreeListOptions.itemsExpr]
    
     */
    get itemsExpr(): ((item: any, value: Array<any> | undefined) => Array<any> | undefined) | string;
    set itemsExpr(value: ((item: any, value: Array<any> | undefined) => Array<any> | undefined) | string);
    /**
     * [descr:GridBaseOptions.keyboardNavigation]
    
     */
    get keyboardNavigation(): {
        editOnKeyPress?: boolean;
        enabled?: boolean;
        enterKeyAction?: EnterKeyAction;
        enterKeyDirection?: EnterKeyDirection;
    };
    set keyboardNavigation(value: {
        editOnKeyPress?: boolean;
        enabled?: boolean;
        enterKeyAction?: EnterKeyAction;
        enterKeyDirection?: EnterKeyDirection;
    });
    /**
     * [descr:dxTreeListOptions.keyExpr]
    
     */
    get keyExpr(): ((item: any, value: any) => any) | string;
    set keyExpr(value: ((item: any, value: any) => any) | string);
    /**
     * [descr:GridBaseOptions.loadPanel]
    
     */
    get loadPanel(): {
        enabled?: boolean | Mode;
        height?: number | string;
        indicatorOptions?: LoadPanelIndicatorProperties;
        indicatorSrc?: string;
        shading?: boolean;
        shadingColor?: string;
        showIndicator?: boolean;
        showPane?: boolean;
        text?: string;
        width?: number | string;
    };
    set loadPanel(value: {
        enabled?: boolean | Mode;
        height?: number | string;
        indicatorOptions?: LoadPanelIndicatorProperties;
        indicatorSrc?: string;
        shading?: boolean;
        shadingColor?: string;
        showIndicator?: boolean;
        showPane?: boolean;
        text?: string;
        width?: number | string;
    });
    /**
     * [descr:GridBaseOptions.noDataText]
    
     */
    get noDataText(): string;
    set noDataText(value: string);
    /**
     * [descr:GridBaseOptions.pager]
    
     */
    get pager(): Pager;
    set pager(value: Pager);
    /**
     * [descr:dxTreeListOptions.paging]
    
     */
    get paging(): {
        enabled?: boolean;
        pageIndex?: number;
        pageSize?: number;
    };
    set paging(value: {
        enabled?: boolean;
        pageIndex?: number;
        pageSize?: number;
    });
    /**
     * [descr:dxTreeListOptions.parentIdExpr]
    
     */
    get parentIdExpr(): ((item: any, value: any) => any | undefined) | string;
    set parentIdExpr(value: ((item: any, value: any) => any | undefined) | string);
    /**
     * [descr:dxTreeListOptions.remoteOperations]
    
     */
    get remoteOperations(): Mode | {
        filtering?: boolean;
        grouping?: boolean;
        sorting?: boolean;
    };
    set remoteOperations(value: Mode | {
        filtering?: boolean;
        grouping?: boolean;
        sorting?: boolean;
    });
    /**
     * [descr:GridBaseOptions.renderAsync]
    
     */
    get renderAsync(): boolean;
    set renderAsync(value: boolean);
    /**
     * [descr:GridBaseOptions.repaintChangesOnly]
    
     */
    get repaintChangesOnly(): boolean;
    set repaintChangesOnly(value: boolean);
    /**
     * [descr:dxTreeListOptions.rootValue]
    
     */
    get rootValue(): any;
    set rootValue(value: any);
    /**
     * [descr:GridBaseOptions.rowAlternationEnabled]
    
     */
    get rowAlternationEnabled(): boolean;
    set rowAlternationEnabled(value: boolean);
    /**
     * [descr:GridBaseOptions.rowDragging]
    
     */
    get rowDragging(): {
        allowDropInsideItem?: boolean;
        allowReordering?: boolean;
        autoScroll?: boolean;
        boundary?: any | string | undefined;
        container?: any | string | undefined;
        cursorOffset?: string | {
            x?: number;
            y?: number;
        };
        data?: any | undefined;
        dragDirection?: DragDirection;
        dragTemplate?: any;
        dropFeedbackMode?: DragHighlight;
        filter?: string;
        group?: string | undefined;
        handle?: string;
        onAdd?: ((e: RowDraggingAddEvent) => void);
        onDragChange?: ((e: RowDraggingChangeEvent) => void);
        onDragEnd?: ((e: RowDraggingEndEvent) => void);
        onDragMove?: ((e: RowDraggingMoveEvent) => void);
        onDragStart?: ((e: RowDraggingStartEvent) => void);
        onRemove?: ((e: RowDraggingRemoveEvent) => void);
        onReorder?: ((e: RowDraggingReorderEvent) => void);
        scrollSensitivity?: number;
        scrollSpeed?: number;
        showDragIcons?: boolean;
    };
    set rowDragging(value: {
        allowDropInsideItem?: boolean;
        allowReordering?: boolean;
        autoScroll?: boolean;
        boundary?: any | string | undefined;
        container?: any | string | undefined;
        cursorOffset?: string | {
            x?: number;
            y?: number;
        };
        data?: any | undefined;
        dragDirection?: DragDirection;
        dragTemplate?: any;
        dropFeedbackMode?: DragHighlight;
        filter?: string;
        group?: string | undefined;
        handle?: string;
        onAdd?: ((e: RowDraggingAddEvent) => void);
        onDragChange?: ((e: RowDraggingChangeEvent) => void);
        onDragEnd?: ((e: RowDraggingEndEvent) => void);
        onDragMove?: ((e: RowDraggingMoveEvent) => void);
        onDragStart?: ((e: RowDraggingStartEvent) => void);
        onRemove?: ((e: RowDraggingRemoveEvent) => void);
        onReorder?: ((e: RowDraggingReorderEvent) => void);
        scrollSensitivity?: number;
        scrollSpeed?: number;
        showDragIcons?: boolean;
    });
    /**
     * [descr:DOMComponentOptions.rtlEnabled]
    
     */
    get rtlEnabled(): boolean;
    set rtlEnabled(value: boolean);
    /**
     * [descr:dxTreeListOptions.scrolling]
    
     */
    get scrolling(): {
        columnRenderingMode?: DataRenderMode;
        mode?: ScrollMode;
        preloadEnabled?: boolean;
        renderAsync?: boolean | undefined;
        rowRenderingMode?: DataRenderMode;
        scrollByContent?: boolean;
        scrollByThumb?: boolean;
        showScrollbar?: ScrollbarMode;
        useNative?: boolean | Mode;
    };
    set scrolling(value: {
        columnRenderingMode?: DataRenderMode;
        mode?: ScrollMode;
        preloadEnabled?: boolean;
        renderAsync?: boolean | undefined;
        rowRenderingMode?: DataRenderMode;
        scrollByContent?: boolean;
        scrollByThumb?: boolean;
        showScrollbar?: ScrollbarMode;
        useNative?: boolean | Mode;
    });
    /**
     * [descr:GridBaseOptions.searchPanel]
    
     */
    get searchPanel(): SearchPanel;
    set searchPanel(value: SearchPanel);
    /**
     * [descr:GridBaseOptions.selectedRowKeys]
    
     */
    get selectedRowKeys(): Array<any>;
    set selectedRowKeys(value: Array<any>);
    /**
     * [descr:dxTreeListOptions.selection]
    
     */
    get selection(): {
        allowSelectAll?: boolean;
        mode?: SingleMultipleOrNone;
        recursive?: boolean;
    };
    set selection(value: {
        allowSelectAll?: boolean;
        mode?: SingleMultipleOrNone;
        recursive?: boolean;
    });
    /**
     * [descr:GridBaseOptions.showBorders]
    
     */
    get showBorders(): boolean;
    set showBorders(value: boolean);
    /**
     * [descr:GridBaseOptions.showColumnHeaders]
    
     */
    get showColumnHeaders(): boolean;
    set showColumnHeaders(value: boolean);
    /**
     * [descr:GridBaseOptions.showColumnLines]
    
     */
    get showColumnLines(): boolean;
    set showColumnLines(value: boolean);
    /**
     * [descr:GridBaseOptions.showRowLines]
    
     */
    get showRowLines(): boolean;
    set showRowLines(value: boolean);
    /**
     * [descr:GridBaseOptions.sorting]
    
     */
    get sorting(): Sorting;
    set sorting(value: Sorting);
    /**
     * [descr:GridBaseOptions.stateStoring]
    
     */
    get stateStoring(): {
        customLoad?: Function;
        customSave?: ((gridState: any) => void);
        enabled?: boolean;
        savingTimeout?: number;
        storageKey?: string | undefined;
        type?: StateStoreType;
    };
    set stateStoring(value: {
        customLoad?: Function;
        customSave?: ((gridState: any) => void);
        enabled?: boolean;
        savingTimeout?: number;
        storageKey?: string | undefined;
        type?: StateStoreType;
    });
    /**
     * [descr:GridBaseOptions.syncLookupFilterValues]
    
     */
    get syncLookupFilterValues(): boolean;
    set syncLookupFilterValues(value: boolean);
    /**
     * [descr:WidgetOptions.tabIndex]
    
     */
    get tabIndex(): number;
    set tabIndex(value: number);
    /**
     * [descr:dxTreeListOptions.toolbar]
    
     */
    get toolbar(): dxTreeListToolbar | undefined;
    set toolbar(value: dxTreeListToolbar | undefined);
    /**
     * [descr:GridBaseOptions.twoWayBindingEnabled]
    
     */
    get twoWayBindingEnabled(): boolean;
    set twoWayBindingEnabled(value: boolean);
    /**
     * [descr:WidgetOptions.visible]
    
     */
    get visible(): boolean;
    set visible(value: boolean);
    /**
     * [descr:DOMComponentOptions.width]
    
     */
    get width(): number | string | undefined;
    set width(value: number | string | undefined);
    /**
     * [descr:GridBaseOptions.wordWrapEnabled]
    
     */
    get wordWrapEnabled(): boolean;
    set wordWrapEnabled(value: boolean);
    /**
    
     * [descr:dxTreeListOptions.onAdaptiveDetailRowPreparing]
    
    
     */
    onAdaptiveDetailRowPreparing: EventEmitter<AdaptiveDetailRowPreparingEvent>;
    /**
    
     * [descr:dxTreeListOptions.onAIAssistantRequestCreating]
    
    
     */
    onAIAssistantRequestCreating: EventEmitter<AIAssistantRequestCreatingEvent>;
    /**
    
     * [descr:dxTreeListOptions.onAIColumnRequestCreating]
    
    
     */
    onAIColumnRequestCreating: EventEmitter<AIColumnRequestCreatingEvent>;
    /**
    
     * [descr:dxTreeListOptions.onCellClick]
    
    
     */
    onCellClick: EventEmitter<CellClickEvent>;
    /**
    
     * [descr:dxTreeListOptions.onCellDblClick]
    
    
     */
    onCellDblClick: EventEmitter<CellDblClickEvent>;
    /**
    
     * [descr:dxTreeListOptions.onCellHoverChanged]
    
    
     */
    onCellHoverChanged: EventEmitter<CellHoverChangedEvent>;
    /**
    
     * [descr:dxTreeListOptions.onCellPrepared]
    
    
     */
    onCellPrepared: EventEmitter<CellPreparedEvent>;
    /**
    
     * [descr:dxTreeListOptions.onContentReady]
    
    
     */
    onContentReady: EventEmitter<ContentReadyEvent>;
    /**
    
     * [descr:dxTreeListOptions.onContextMenuPreparing]
    
    
     */
    onContextMenuPreparing: EventEmitter<ContextMenuPreparingEvent>;
    /**
    
     * [descr:dxTreeListOptions.onDataErrorOccurred]
    
    
     */
    onDataErrorOccurred: EventEmitter<DataErrorOccurredEvent>;
    /**
    
     * [descr:dxTreeListOptions.onDisposing]
    
    
     */
    onDisposing: EventEmitter<DisposingEvent>;
    /**
    
     * [descr:dxTreeListOptions.onEditCanceled]
    
    
     */
    onEditCanceled: EventEmitter<EditCanceledEvent>;
    /**
    
     * [descr:dxTreeListOptions.onEditCanceling]
    
    
     */
    onEditCanceling: EventEmitter<EditCancelingEvent>;
    /**
    
     * [descr:dxTreeListOptions.onEditingStart]
    
    
     */
    onEditingStart: EventEmitter<EditingStartEvent>;
    /**
    
     * [descr:dxTreeListOptions.onEditorPrepared]
    
    
     */
    onEditorPrepared: EventEmitter<EditorPreparedEvent>;
    /**
    
     * [descr:dxTreeListOptions.onEditorPreparing]
    
    
     */
    onEditorPreparing: EventEmitter<EditorPreparingEvent>;
    /**
    
     * [descr:dxTreeListOptions.onFocusedCellChanged]
    
    
     */
    onFocusedCellChanged: EventEmitter<FocusedCellChangedEvent>;
    /**
    
     * [descr:dxTreeListOptions.onFocusedCellChanging]
    
    
     */
    onFocusedCellChanging: EventEmitter<FocusedCellChangingEvent>;
    /**
    
     * [descr:dxTreeListOptions.onFocusedRowChanged]
    
    
     */
    onFocusedRowChanged: EventEmitter<FocusedRowChangedEvent>;
    /**
    
     * [descr:dxTreeListOptions.onFocusedRowChanging]
    
    
     */
    onFocusedRowChanging: EventEmitter<FocusedRowChangingEvent>;
    /**
    
     * [descr:dxTreeListOptions.onInitialized]
    
    
     */
    onInitialized: EventEmitter<InitializedEvent>;
    /**
    
     * [descr:dxTreeListOptions.onInitNewRow]
    
    
     */
    onInitNewRow: EventEmitter<InitNewRowEvent>;
    /**
    
     * [descr:dxTreeListOptions.onKeyDown]
    
    
     */
    onKeyDown: EventEmitter<KeyDownEvent>;
    /**
    
     * [descr:dxTreeListOptions.onNodesInitialized]
    
    
     */
    onNodesInitialized: EventEmitter<NodesInitializedEvent>;
    /**
    
     * [descr:dxTreeListOptions.onOptionChanged]
    
    
     */
    onOptionChanged: EventEmitter<OptionChangedEvent>;
    /**
    
     * [descr:dxTreeListOptions.onRowClick]
    
    
     */
    onRowClick: EventEmitter<RowClickEvent>;
    /**
    
     * [descr:dxTreeListOptions.onRowCollapsed]
    
    
     */
    onRowCollapsed: EventEmitter<RowCollapsedEvent>;
    /**
    
     * [descr:dxTreeListOptions.onRowCollapsing]
    
    
     */
    onRowCollapsing: EventEmitter<RowCollapsingEvent>;
    /**
    
     * [descr:dxTreeListOptions.onRowDblClick]
    
    
     */
    onRowDblClick: EventEmitter<RowDblClickEvent>;
    /**
    
     * [descr:dxTreeListOptions.onRowExpanded]
    
    
     */
    onRowExpanded: EventEmitter<RowExpandedEvent>;
    /**
    
     * [descr:dxTreeListOptions.onRowExpanding]
    
    
     */
    onRowExpanding: EventEmitter<RowExpandingEvent>;
    /**
    
     * [descr:dxTreeListOptions.onRowInserted]
    
    
     */
    onRowInserted: EventEmitter<RowInsertedEvent>;
    /**
    
     * [descr:dxTreeListOptions.onRowInserting]
    
    
     */
    onRowInserting: EventEmitter<RowInsertingEvent>;
    /**
    
     * [descr:dxTreeListOptions.onRowPrepared]
    
    
     */
    onRowPrepared: EventEmitter<RowPreparedEvent>;
    /**
    
     * [descr:dxTreeListOptions.onRowRemoved]
    
    
     */
    onRowRemoved: EventEmitter<RowRemovedEvent>;
    /**
    
     * [descr:dxTreeListOptions.onRowRemoving]
    
    
     */
    onRowRemoving: EventEmitter<RowRemovingEvent>;
    /**
    
     * [descr:dxTreeListOptions.onRowUpdated]
    
    
     */
    onRowUpdated: EventEmitter<RowUpdatedEvent>;
    /**
    
     * [descr:dxTreeListOptions.onRowUpdating]
    
    
     */
    onRowUpdating: EventEmitter<RowUpdatingEvent>;
    /**
    
     * [descr:dxTreeListOptions.onRowValidating]
    
    
     */
    onRowValidating: EventEmitter<RowValidatingEvent>;
    /**
    
     * [descr:dxTreeListOptions.onSaved]
    
    
     */
    onSaved: EventEmitter<SavedEvent>;
    /**
    
     * [descr:dxTreeListOptions.onSaving]
    
    
     */
    onSaving: EventEmitter<SavingEvent>;
    /**
    
     * [descr:dxTreeListOptions.onSelectionChanged]
    
    
     */
    onSelectionChanged: EventEmitter<SelectionChangedEvent>;
    /**
    
     * [descr:dxTreeListOptions.onToolbarPreparing]
    
    
     */
    onToolbarPreparing: EventEmitter<ToolbarPreparingEvent>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    accessKeyChange: EventEmitter<string | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    activeStateEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    aiAssistantChange: EventEmitter<AIAssistant>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    aiIntegrationChange: EventEmitter<AIIntegration | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    allowColumnReorderingChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    allowColumnResizingChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    autoExpandAllChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    autoNavigateToFocusedRowChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    cacheEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    cellHintEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    columnAutoWidthChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    columnChooserChange: EventEmitter<ColumnChooser>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    columnFixingChange: EventEmitter<{
        enabled?: boolean;
        icons?: {
            fix?: string;
            leftPosition?: string;
            rightPosition?: string;
            stickyPosition?: string;
            unfix?: string;
        };
        texts?: {
            fix?: string;
            leftPosition?: string;
            rightPosition?: string;
            stickyPosition?: string;
            unfix?: string;
        };
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    columnHidingEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    columnMinWidthChange: EventEmitter<number | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    columnResizingModeChange: EventEmitter<ColumnResizeMode>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    columnsChange: EventEmitter<Array<dxTreeListColumn | string>>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    columnWidthChange: EventEmitter<Mode | number | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    customizeColumnsChange: EventEmitter<((columns: Array<dxTreeListColumn>) => void)>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    dataSourceChange: EventEmitter<Array<any> | DataSource | DataSourceOptions | Store | string | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    dataStructureChange: EventEmitter<DataStructure>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    dateSerializationFormatChange: EventEmitter<string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    disabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    editingChange: EventEmitter<{
        allowAdding?: boolean | ((options: {
            component: dxTreeList;
            row: dxTreeListRowObject;
        }) => boolean);
        allowDeleting?: boolean | ((options: {
            component: dxTreeList;
            row: dxTreeListRowObject;
        }) => boolean);
        allowUpdating?: boolean | ((options: {
            component: dxTreeList;
            row: dxTreeListRowObject;
        }) => boolean);
        changes?: Array<DataChange>;
        confirmDelete?: boolean;
        editColumnName?: string | undefined;
        editRowKey?: any | undefined;
        form?: dxFormOptions;
        mode?: GridsEditMode;
        popup?: dxPopupOptions<any>;
        refreshMode?: GridsEditRefreshMode;
        selectTextOnEditStart?: boolean;
        startEditAction?: StartEditAction;
        texts?: {
            addRow?: string;
            addRowToNode?: string;
            cancelAllChanges?: string;
            cancelRowChanges?: string;
            confirmDeleteMessage?: string;
            confirmDeleteTitle?: string;
            deleteRow?: string;
            editRow?: string;
            saveAllChanges?: string;
            saveRowChanges?: string;
            undeleteRow?: string;
            validationCancelChanges?: string;
        };
        useIcons?: boolean;
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    elementAttrChange: EventEmitter<Record<string, any>>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    errorRowEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    expandedRowKeysChange: EventEmitter<Array<any>>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    expandNodesOnFilteringChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    filterBuilderChange: EventEmitter<dxFilterBuilderOptions>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    filterBuilderPopupChange: EventEmitter<dxPopupOptions<any>>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    filterModeChange: EventEmitter<TreeListFilterMode>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    filterPanelChange: EventEmitter<FilterPanel>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    filterRowChange: EventEmitter<{
        applyFilter?: ApplyFilterMode;
        applyFilterText?: string;
        betweenEndText?: string;
        betweenStartText?: string;
        operationDescriptions?: {
            between?: string;
            contains?: string;
            endsWith?: string;
            equal?: string;
            greaterThan?: string;
            greaterThanOrEqual?: string;
            lessThan?: string;
            lessThanOrEqual?: string;
            notContains?: string;
            notEqual?: string;
            startsWith?: string;
        };
        resetOperationText?: string;
        showAllText?: string;
        showOperationChooser?: boolean;
        visible?: boolean;
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    filterSyncEnabledChange: EventEmitter<boolean | Mode>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    filterValueChange: EventEmitter<Array<any> | Function | string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    focusedColumnIndexChange: EventEmitter<number>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    focusedRowEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    focusedRowIndexChange: EventEmitter<number>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    focusedRowKeyChange: EventEmitter<any | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    hasItemsExprChange: EventEmitter<((item: any, value: boolean | undefined) => boolean | undefined) | string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    headerFilterChange: EventEmitter<HeaderFilter>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    heightChange: EventEmitter<number | string | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    highlightChangesChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    hintChange: EventEmitter<string | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    hoverStateEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    itemsExprChange: EventEmitter<((item: any, value: Array<any> | undefined) => Array<any> | undefined) | string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    keyboardNavigationChange: EventEmitter<{
        editOnKeyPress?: boolean;
        enabled?: boolean;
        enterKeyAction?: EnterKeyAction;
        enterKeyDirection?: EnterKeyDirection;
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    keyExprChange: EventEmitter<((item: any, value: any) => any) | string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    loadPanelChange: EventEmitter<{
        enabled?: boolean | Mode;
        height?: number | string;
        indicatorOptions?: LoadPanelIndicatorProperties;
        indicatorSrc?: string;
        shading?: boolean;
        shadingColor?: string;
        showIndicator?: boolean;
        showPane?: boolean;
        text?: string;
        width?: number | string;
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    noDataTextChange: EventEmitter<string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    pagerChange: EventEmitter<Pager>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    pagingChange: EventEmitter<{
        enabled?: boolean;
        pageIndex?: number;
        pageSize?: number;
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    parentIdExprChange: EventEmitter<((item: any, value: any) => any | undefined) | string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    remoteOperationsChange: EventEmitter<Mode | {
        filtering?: boolean;
        grouping?: boolean;
        sorting?: boolean;
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    renderAsyncChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    repaintChangesOnlyChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    rootValueChange: EventEmitter<any>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    rowAlternationEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    rowDraggingChange: EventEmitter<{
        allowDropInsideItem?: boolean;
        allowReordering?: boolean;
        autoScroll?: boolean;
        boundary?: any | string | undefined;
        container?: any | string | undefined;
        cursorOffset?: string | {
            x?: number;
            y?: number;
        };
        data?: any | undefined;
        dragDirection?: DragDirection;
        dragTemplate?: any;
        dropFeedbackMode?: DragHighlight;
        filter?: string;
        group?: string | undefined;
        handle?: string;
        onAdd?: ((e: RowDraggingAddEvent) => void);
        onDragChange?: ((e: RowDraggingChangeEvent) => void);
        onDragEnd?: ((e: RowDraggingEndEvent) => void);
        onDragMove?: ((e: RowDraggingMoveEvent) => void);
        onDragStart?: ((e: RowDraggingStartEvent) => void);
        onRemove?: ((e: RowDraggingRemoveEvent) => void);
        onReorder?: ((e: RowDraggingReorderEvent) => void);
        scrollSensitivity?: number;
        scrollSpeed?: number;
        showDragIcons?: boolean;
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    rtlEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    scrollingChange: EventEmitter<{
        columnRenderingMode?: DataRenderMode;
        mode?: ScrollMode;
        preloadEnabled?: boolean;
        renderAsync?: boolean | undefined;
        rowRenderingMode?: DataRenderMode;
        scrollByContent?: boolean;
        scrollByThumb?: boolean;
        showScrollbar?: ScrollbarMode;
        useNative?: boolean | Mode;
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    searchPanelChange: EventEmitter<SearchPanel>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    selectedRowKeysChange: EventEmitter<Array<any>>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    selectionChange: EventEmitter<{
        allowSelectAll?: boolean;
        mode?: SingleMultipleOrNone;
        recursive?: boolean;
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    showBordersChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    showColumnHeadersChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    showColumnLinesChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    showRowLinesChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    sortingChange: EventEmitter<Sorting>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    stateStoringChange: EventEmitter<{
        customLoad?: Function;
        customSave?: ((gridState: any) => void);
        enabled?: boolean;
        savingTimeout?: number;
        storageKey?: string | undefined;
        type?: StateStoreType;
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    syncLookupFilterValuesChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    tabIndexChange: EventEmitter<number>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    toolbarChange: EventEmitter<dxTreeListToolbar | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    twoWayBindingEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    visibleChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    widthChange: EventEmitter<number | string | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    wordWrapEnabledChange: EventEmitter<boolean>;
    constructor(elementRef: ElementRef, ngZone: NgZone, templateHost: DxTemplateHost, _watcherHelper: WatcherHelper, _idh: IterableDifferHelper, optionHost: NestedOptionHost, transferState: TransferState, platformId: any);
    protected _createInstance(element: any, options: any): dxTreeList<any, any>;
    ngOnDestroy(): void;
    ngOnChanges(changes: SimpleChanges): void;
    setupChanges(prop: string, changes: SimpleChanges): void;
    ngDoCheck(): void;
    _setOption(name: string, value: any): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxTreeListComponent<any, any>, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxTreeListComponent<any, any>, "dx-tree-list", never, { "accessKey": { "alias": "accessKey"; "required": false; }; "activeStateEnabled": { "alias": "activeStateEnabled"; "required": false; }; "aiAssistant": { "alias": "aiAssistant"; "required": false; }; "aiIntegration": { "alias": "aiIntegration"; "required": false; }; "allowColumnReordering": { "alias": "allowColumnReordering"; "required": false; }; "allowColumnResizing": { "alias": "allowColumnResizing"; "required": false; }; "autoExpandAll": { "alias": "autoExpandAll"; "required": false; }; "autoNavigateToFocusedRow": { "alias": "autoNavigateToFocusedRow"; "required": false; }; "cacheEnabled": { "alias": "cacheEnabled"; "required": false; }; "cellHintEnabled": { "alias": "cellHintEnabled"; "required": false; }; "columnAutoWidth": { "alias": "columnAutoWidth"; "required": false; }; "columnChooser": { "alias": "columnChooser"; "required": false; }; "columnFixing": { "alias": "columnFixing"; "required": false; }; "columnHidingEnabled": { "alias": "columnHidingEnabled"; "required": false; }; "columnMinWidth": { "alias": "columnMinWidth"; "required": false; }; "columnResizingMode": { "alias": "columnResizingMode"; "required": false; }; "columns": { "alias": "columns"; "required": false; }; "columnWidth": { "alias": "columnWidth"; "required": false; }; "customizeColumns": { "alias": "customizeColumns"; "required": false; }; "dataSource": { "alias": "dataSource"; "required": false; }; "dataStructure": { "alias": "dataStructure"; "required": false; }; "dateSerializationFormat": { "alias": "dateSerializationFormat"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "editing": { "alias": "editing"; "required": false; }; "elementAttr": { "alias": "elementAttr"; "required": false; }; "errorRowEnabled": { "alias": "errorRowEnabled"; "required": false; }; "expandedRowKeys": { "alias": "expandedRowKeys"; "required": false; }; "expandNodesOnFiltering": { "alias": "expandNodesOnFiltering"; "required": false; }; "filterBuilder": { "alias": "filterBuilder"; "required": false; }; "filterBuilderPopup": { "alias": "filterBuilderPopup"; "required": false; }; "filterMode": { "alias": "filterMode"; "required": false; }; "filterPanel": { "alias": "filterPanel"; "required": false; }; "filterRow": { "alias": "filterRow"; "required": false; }; "filterSyncEnabled": { "alias": "filterSyncEnabled"; "required": false; }; "filterValue": { "alias": "filterValue"; "required": false; }; "focusedColumnIndex": { "alias": "focusedColumnIndex"; "required": false; }; "focusedRowEnabled": { "alias": "focusedRowEnabled"; "required": false; }; "focusedRowIndex": { "alias": "focusedRowIndex"; "required": false; }; "focusedRowKey": { "alias": "focusedRowKey"; "required": false; }; "hasItemsExpr": { "alias": "hasItemsExpr"; "required": false; }; "headerFilter": { "alias": "headerFilter"; "required": false; }; "height": { "alias": "height"; "required": false; }; "highlightChanges": { "alias": "highlightChanges"; "required": false; }; "hint": { "alias": "hint"; "required": false; }; "hoverStateEnabled": { "alias": "hoverStateEnabled"; "required": false; }; "itemsExpr": { "alias": "itemsExpr"; "required": false; }; "keyboardNavigation": { "alias": "keyboardNavigation"; "required": false; }; "keyExpr": { "alias": "keyExpr"; "required": false; }; "loadPanel": { "alias": "loadPanel"; "required": false; }; "noDataText": { "alias": "noDataText"; "required": false; }; "pager": { "alias": "pager"; "required": false; }; "paging": { "alias": "paging"; "required": false; }; "parentIdExpr": { "alias": "parentIdExpr"; "required": false; }; "remoteOperations": { "alias": "remoteOperations"; "required": false; }; "renderAsync": { "alias": "renderAsync"; "required": false; }; "repaintChangesOnly": { "alias": "repaintChangesOnly"; "required": false; }; "rootValue": { "alias": "rootValue"; "required": false; }; "rowAlternationEnabled": { "alias": "rowAlternationEnabled"; "required": false; }; "rowDragging": { "alias": "rowDragging"; "required": false; }; "rtlEnabled": { "alias": "rtlEnabled"; "required": false; }; "scrolling": { "alias": "scrolling"; "required": false; }; "searchPanel": { "alias": "searchPanel"; "required": false; }; "selectedRowKeys": { "alias": "selectedRowKeys"; "required": false; }; "selection": { "alias": "selection"; "required": false; }; "showBorders": { "alias": "showBorders"; "required": false; }; "showColumnHeaders": { "alias": "showColumnHeaders"; "required": false; }; "showColumnLines": { "alias": "showColumnLines"; "required": false; }; "showRowLines": { "alias": "showRowLines"; "required": false; }; "sorting": { "alias": "sorting"; "required": false; }; "stateStoring": { "alias": "stateStoring"; "required": false; }; "syncLookupFilterValues": { "alias": "syncLookupFilterValues"; "required": false; }; "tabIndex": { "alias": "tabIndex"; "required": false; }; "toolbar": { "alias": "toolbar"; "required": false; }; "twoWayBindingEnabled": { "alias": "twoWayBindingEnabled"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; "wordWrapEnabled": { "alias": "wordWrapEnabled"; "required": false; }; }, { "onAdaptiveDetailRowPreparing": "onAdaptiveDetailRowPreparing"; "onAIAssistantRequestCreating": "onAIAssistantRequestCreating"; "onAIColumnRequestCreating": "onAIColumnRequestCreating"; "onCellClick": "onCellClick"; "onCellDblClick": "onCellDblClick"; "onCellHoverChanged": "onCellHoverChanged"; "onCellPrepared": "onCellPrepared"; "onContentReady": "onContentReady"; "onContextMenuPreparing": "onContextMenuPreparing"; "onDataErrorOccurred": "onDataErrorOccurred"; "onDisposing": "onDisposing"; "onEditCanceled": "onEditCanceled"; "onEditCanceling": "onEditCanceling"; "onEditingStart": "onEditingStart"; "onEditorPrepared": "onEditorPrepared"; "onEditorPreparing": "onEditorPreparing"; "onFocusedCellChanged": "onFocusedCellChanged"; "onFocusedCellChanging": "onFocusedCellChanging"; "onFocusedRowChanged": "onFocusedRowChanged"; "onFocusedRowChanging": "onFocusedRowChanging"; "onInitialized": "onInitialized"; "onInitNewRow": "onInitNewRow"; "onKeyDown": "onKeyDown"; "onNodesInitialized": "onNodesInitialized"; "onOptionChanged": "onOptionChanged"; "onRowClick": "onRowClick"; "onRowCollapsed": "onRowCollapsed"; "onRowCollapsing": "onRowCollapsing"; "onRowDblClick": "onRowDblClick"; "onRowExpanded": "onRowExpanded"; "onRowExpanding": "onRowExpanding"; "onRowInserted": "onRowInserted"; "onRowInserting": "onRowInserting"; "onRowPrepared": "onRowPrepared"; "onRowRemoved": "onRowRemoved"; "onRowRemoving": "onRowRemoving"; "onRowUpdated": "onRowUpdated"; "onRowUpdating": "onRowUpdating"; "onRowValidating": "onRowValidating"; "onSaved": "onSaved"; "onSaving": "onSaving"; "onSelectionChanged": "onSelectionChanged"; "onToolbarPreparing": "onToolbarPreparing"; "accessKeyChange": "accessKeyChange"; "activeStateEnabledChange": "activeStateEnabledChange"; "aiAssistantChange": "aiAssistantChange"; "aiIntegrationChange": "aiIntegrationChange"; "allowColumnReorderingChange": "allowColumnReorderingChange"; "allowColumnResizingChange": "allowColumnResizingChange"; "autoExpandAllChange": "autoExpandAllChange"; "autoNavigateToFocusedRowChange": "autoNavigateToFocusedRowChange"; "cacheEnabledChange": "cacheEnabledChange"; "cellHintEnabledChange": "cellHintEnabledChange"; "columnAutoWidthChange": "columnAutoWidthChange"; "columnChooserChange": "columnChooserChange"; "columnFixingChange": "columnFixingChange"; "columnHidingEnabledChange": "columnHidingEnabledChange"; "columnMinWidthChange": "columnMinWidthChange"; "columnResizingModeChange": "columnResizingModeChange"; "columnsChange": "columnsChange"; "columnWidthChange": "columnWidthChange"; "customizeColumnsChange": "customizeColumnsChange"; "dataSourceChange": "dataSourceChange"; "dataStructureChange": "dataStructureChange"; "dateSerializationFormatChange": "dateSerializationFormatChange"; "disabledChange": "disabledChange"; "editingChange": "editingChange"; "elementAttrChange": "elementAttrChange"; "errorRowEnabledChange": "errorRowEnabledChange"; "expandedRowKeysChange": "expandedRowKeysChange"; "expandNodesOnFilteringChange": "expandNodesOnFilteringChange"; "filterBuilderChange": "filterBuilderChange"; "filterBuilderPopupChange": "filterBuilderPopupChange"; "filterModeChange": "filterModeChange"; "filterPanelChange": "filterPanelChange"; "filterRowChange": "filterRowChange"; "filterSyncEnabledChange": "filterSyncEnabledChange"; "filterValueChange": "filterValueChange"; "focusedColumnIndexChange": "focusedColumnIndexChange"; "focusedRowEnabledChange": "focusedRowEnabledChange"; "focusedRowIndexChange": "focusedRowIndexChange"; "focusedRowKeyChange": "focusedRowKeyChange"; "hasItemsExprChange": "hasItemsExprChange"; "headerFilterChange": "headerFilterChange"; "heightChange": "heightChange"; "highlightChangesChange": "highlightChangesChange"; "hintChange": "hintChange"; "hoverStateEnabledChange": "hoverStateEnabledChange"; "itemsExprChange": "itemsExprChange"; "keyboardNavigationChange": "keyboardNavigationChange"; "keyExprChange": "keyExprChange"; "loadPanelChange": "loadPanelChange"; "noDataTextChange": "noDataTextChange"; "pagerChange": "pagerChange"; "pagingChange": "pagingChange"; "parentIdExprChange": "parentIdExprChange"; "remoteOperationsChange": "remoteOperationsChange"; "renderAsyncChange": "renderAsyncChange"; "repaintChangesOnlyChange": "repaintChangesOnlyChange"; "rootValueChange": "rootValueChange"; "rowAlternationEnabledChange": "rowAlternationEnabledChange"; "rowDraggingChange": "rowDraggingChange"; "rtlEnabledChange": "rtlEnabledChange"; "scrollingChange": "scrollingChange"; "searchPanelChange": "searchPanelChange"; "selectedRowKeysChange": "selectedRowKeysChange"; "selectionChange": "selectionChange"; "showBordersChange": "showBordersChange"; "showColumnHeadersChange": "showColumnHeadersChange"; "showColumnLinesChange": "showColumnLinesChange"; "showRowLinesChange": "showRowLinesChange"; "sortingChange": "sortingChange"; "stateStoringChange": "stateStoringChange"; "syncLookupFilterValuesChange": "syncLookupFilterValuesChange"; "tabIndexChange": "tabIndexChange"; "toolbarChange": "toolbarChange"; "twoWayBindingEnabledChange": "twoWayBindingEnabledChange"; "visibleChange": "visibleChange"; "widthChange": "widthChange"; "wordWrapEnabledChange": "wordWrapEnabledChange"; }, ["_validationRulesContentChildren", "_buttonsContentChildren", "_itemsContentChildren", "_changesContentChildren", "_columnsContentChildren", "_customOperationsContentChildren", "_fieldsContentChildren", "_tabsContentChildren", "_toolbarItemsContentChildren"], never, true, never>;
}
declare class DxTreeListModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxTreeListModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxTreeListModule, never, [typeof DxTreeListComponent, typeof i1.DxoColumnChooserModule, typeof i1.DxoPositionModule, typeof i1.DxoAtModule, typeof i1.DxoBoundaryOffsetModule, typeof i1.DxoCollisionModule, typeof i1.DxoMyModule, typeof i1.DxoOffsetModule, typeof i1.DxoSearchModule, typeof i1.DxoSelectionModule, typeof i1.DxoColumnFixingModule, typeof i1.DxoIconsModule, typeof i1.DxoTextsModule, typeof i1.DxiColumnModule, typeof i1.DxiButtonModule, typeof i1.DxoLookupModule, typeof i1.DxoFormatModule, typeof i1.DxoFormItemModule, typeof i1.DxoLabelModule, typeof i1.DxiValidationRuleModule, typeof i1.DxoHeaderFilterModule, typeof i1.DxoEditingModule, typeof i1.DxiChangeModule, typeof i1.DxoFormModule, typeof i1.DxoColCountByScreenModule, typeof i1.DxiItemModule, typeof i1.DxoTabPanelOptionsModule, typeof i1.DxiTabModule, typeof i1.DxoButtonOptionsModule, typeof i1.DxoPopupModule, typeof i1.DxoAnimationModule, typeof i1.DxoHideModule, typeof i1.DxoFromModule, typeof i1.DxoToModule, typeof i1.DxoShowModule, typeof i1.DxoFilterBuilderModule, typeof i1.DxiCustomOperationModule, typeof i1.DxiFieldModule, typeof i1.DxoFilterOperationDescriptionsModule, typeof i1.DxoGroupOperationDescriptionsModule, typeof i1.DxoFilterBuilderPopupModule, typeof i1.DxoFilterPanelModule, typeof i1.DxoFilterRowModule, typeof i1.DxoOperationDescriptionsModule, typeof i1.DxoKeyboardNavigationModule, typeof i1.DxoLoadPanelModule, typeof i1.DxoPagerModule, typeof i1.DxoPagingModule, typeof i1.DxoRemoteOperationsModule, typeof i1.DxoRowDraggingModule, typeof i1.DxoCursorOffsetModule, typeof i1.DxoScrollingModule, typeof i1.DxoSearchPanelModule, typeof i1.DxoSortingModule, typeof i1.DxoStateStoringModule, typeof i1.DxoToolbarModule, typeof i2.DxoTreeListAIModule, typeof i2.DxoTreeListAIAssistantModule, typeof i2.DxoTreeListAIOptionsModule, typeof i2.DxoTreeListAnimationModule, typeof i2.DxiTreeListAsyncRuleModule, typeof i2.DxoTreeListAtModule, typeof i2.DxoTreeListBoundaryOffsetModule, typeof i2.DxiTreeListButtonModule, typeof i2.DxiTreeListButtonItemModule, typeof i2.DxoTreeListButtonOptionsModule, typeof i2.DxiTreeListChangeModule, typeof i2.DxoTreeListColCountByScreenModule, typeof i2.DxoTreeListCollisionModule, typeof i2.DxiTreeListColumnModule, typeof i2.DxiTreeListColumnButtonModule, typeof i2.DxoTreeListColumnChooserModule, typeof i2.DxoTreeListColumnChooserSearchModule, typeof i2.DxoTreeListColumnChooserSelectionModule, typeof i2.DxoTreeListColumnFixingModule, typeof i2.DxoTreeListColumnFixingTextsModule, typeof i2.DxoTreeListColumnHeaderFilterModule, typeof i2.DxoTreeListColumnHeaderFilterSearchModule, typeof i2.DxoTreeListColumnLookupModule, typeof i2.DxiTreeListCompareRuleModule, typeof i2.DxoTreeListCursorOffsetModule, typeof i2.DxiTreeListCustomOperationModule, typeof i2.DxiTreeListCustomRuleModule, typeof i2.DxoTreeListEditingModule, typeof i2.DxoTreeListEditingTextsModule, typeof i2.DxoTreeListEditorOptionsModule, typeof i2.DxiTreeListEditorOptionsButtonModule, typeof i2.DxiTreeListEmailRuleModule, typeof i2.DxiTreeListEmptyItemModule, typeof i2.DxiTreeListFieldModule, typeof i2.DxoTreeListFieldLookupModule, typeof i2.DxoTreeListFilterBuilderModule, typeof i2.DxoTreeListFilterBuilderPopupModule, typeof i2.DxoTreeListFilterOperationDescriptionsModule, typeof i2.DxoTreeListFilterPanelModule, typeof i2.DxoTreeListFilterPanelTextsModule, typeof i2.DxoTreeListFilterRowModule, typeof i2.DxoTreeListFormModule, typeof i2.DxoTreeListFormatModule, typeof i2.DxoTreeListFormItemModule, typeof i2.DxoTreeListFromModule, typeof i2.DxiTreeListGroupItemModule, typeof i2.DxoTreeListGroupOperationDescriptionsModule, typeof i2.DxoTreeListHeaderFilterModule, typeof i2.DxoTreeListHideModule, typeof i2.DxoTreeListIconsModule, typeof i2.DxoTreeListIndicatorOptionsModule, typeof i2.DxiTreeListItemModule, typeof i2.DxoTreeListKeyboardNavigationModule, typeof i2.DxoTreeListLabelModule, typeof i2.DxoTreeListLoadPanelModule, typeof i2.DxoTreeListLookupModule, typeof i2.DxoTreeListMyModule, typeof i2.DxiTreeListNumericRuleModule, typeof i2.DxoTreeListOffsetModule, typeof i2.DxoTreeListOperationDescriptionsModule, typeof i2.DxoTreeListOptionsModule, typeof i2.DxoTreeListPagerModule, typeof i2.DxoTreeListPagingModule, typeof i2.DxiTreeListPatternRuleModule, typeof i2.DxoTreeListPopupModule, typeof i2.DxoTreeListPositionModule, typeof i2.DxiTreeListRangeRuleModule, typeof i2.DxoTreeListRemoteOperationsModule, typeof i2.DxiTreeListRequiredRuleModule, typeof i2.DxoTreeListRowDraggingModule, typeof i2.DxoTreeListScrollingModule, typeof i2.DxoTreeListSearchModule, typeof i2.DxoTreeListSearchPanelModule, typeof i2.DxoTreeListSelectionModule, typeof i2.DxoTreeListShowModule, typeof i2.DxiTreeListSimpleItemModule, typeof i2.DxoTreeListSortingModule, typeof i2.DxoTreeListStateStoringModule, typeof i2.DxiTreeListStringLengthRuleModule, typeof i2.DxiTreeListTabModule, typeof i2.DxiTreeListTabbedItemModule, typeof i2.DxoTreeListTabPanelOptionsModule, typeof i2.DxiTreeListTabPanelOptionsItemModule, typeof i2.DxoTreeListTextsModule, typeof i2.DxoTreeListToModule, typeof i2.DxoTreeListToolbarModule, typeof i2.DxiTreeListToolbarItemModule, typeof i2.DxoTreeListTreeListHeaderFilterModule, typeof i2.DxoTreeListTreeListHeaderFilterSearchModule, typeof i2.DxoTreeListTreeListHeaderFilterTextsModule, typeof i2.DxoTreeListTreeListSelectionModule, typeof i2.DxiTreeListTreeListToolbarItemModule, typeof i2.DxiTreeListValidationRuleModule, typeof i3.DxIntegrationModule, typeof i3.DxTemplateModule], [typeof DxTreeListComponent, typeof i1.DxoColumnChooserModule, typeof i1.DxoPositionModule, typeof i1.DxoAtModule, typeof i1.DxoBoundaryOffsetModule, typeof i1.DxoCollisionModule, typeof i1.DxoMyModule, typeof i1.DxoOffsetModule, typeof i1.DxoSearchModule, typeof i1.DxoSelectionModule, typeof i1.DxoColumnFixingModule, typeof i1.DxoIconsModule, typeof i1.DxoTextsModule, typeof i1.DxiColumnModule, typeof i1.DxiButtonModule, typeof i1.DxoLookupModule, typeof i1.DxoFormatModule, typeof i1.DxoFormItemModule, typeof i1.DxoLabelModule, typeof i1.DxiValidationRuleModule, typeof i1.DxoHeaderFilterModule, typeof i1.DxoEditingModule, typeof i1.DxiChangeModule, typeof i1.DxoFormModule, typeof i1.DxoColCountByScreenModule, typeof i1.DxiItemModule, typeof i1.DxoTabPanelOptionsModule, typeof i1.DxiTabModule, typeof i1.DxoButtonOptionsModule, typeof i1.DxoPopupModule, typeof i1.DxoAnimationModule, typeof i1.DxoHideModule, typeof i1.DxoFromModule, typeof i1.DxoToModule, typeof i1.DxoShowModule, typeof i1.DxoFilterBuilderModule, typeof i1.DxiCustomOperationModule, typeof i1.DxiFieldModule, typeof i1.DxoFilterOperationDescriptionsModule, typeof i1.DxoGroupOperationDescriptionsModule, typeof i1.DxoFilterBuilderPopupModule, typeof i1.DxoFilterPanelModule, typeof i1.DxoFilterRowModule, typeof i1.DxoOperationDescriptionsModule, typeof i1.DxoKeyboardNavigationModule, typeof i1.DxoLoadPanelModule, typeof i1.DxoPagerModule, typeof i1.DxoPagingModule, typeof i1.DxoRemoteOperationsModule, typeof i1.DxoRowDraggingModule, typeof i1.DxoCursorOffsetModule, typeof i1.DxoScrollingModule, typeof i1.DxoSearchPanelModule, typeof i1.DxoSortingModule, typeof i1.DxoStateStoringModule, typeof i1.DxoToolbarModule, typeof i2.DxoTreeListAIModule, typeof i2.DxoTreeListAIAssistantModule, typeof i2.DxoTreeListAIOptionsModule, typeof i2.DxoTreeListAnimationModule, typeof i2.DxiTreeListAsyncRuleModule, typeof i2.DxoTreeListAtModule, typeof i2.DxoTreeListBoundaryOffsetModule, typeof i2.DxiTreeListButtonModule, typeof i2.DxiTreeListButtonItemModule, typeof i2.DxoTreeListButtonOptionsModule, typeof i2.DxiTreeListChangeModule, typeof i2.DxoTreeListColCountByScreenModule, typeof i2.DxoTreeListCollisionModule, typeof i2.DxiTreeListColumnModule, typeof i2.DxiTreeListColumnButtonModule, typeof i2.DxoTreeListColumnChooserModule, typeof i2.DxoTreeListColumnChooserSearchModule, typeof i2.DxoTreeListColumnChooserSelectionModule, typeof i2.DxoTreeListColumnFixingModule, typeof i2.DxoTreeListColumnFixingTextsModule, typeof i2.DxoTreeListColumnHeaderFilterModule, typeof i2.DxoTreeListColumnHeaderFilterSearchModule, typeof i2.DxoTreeListColumnLookupModule, typeof i2.DxiTreeListCompareRuleModule, typeof i2.DxoTreeListCursorOffsetModule, typeof i2.DxiTreeListCustomOperationModule, typeof i2.DxiTreeListCustomRuleModule, typeof i2.DxoTreeListEditingModule, typeof i2.DxoTreeListEditingTextsModule, typeof i2.DxoTreeListEditorOptionsModule, typeof i2.DxiTreeListEditorOptionsButtonModule, typeof i2.DxiTreeListEmailRuleModule, typeof i2.DxiTreeListEmptyItemModule, typeof i2.DxiTreeListFieldModule, typeof i2.DxoTreeListFieldLookupModule, typeof i2.DxoTreeListFilterBuilderModule, typeof i2.DxoTreeListFilterBuilderPopupModule, typeof i2.DxoTreeListFilterOperationDescriptionsModule, typeof i2.DxoTreeListFilterPanelModule, typeof i2.DxoTreeListFilterPanelTextsModule, typeof i2.DxoTreeListFilterRowModule, typeof i2.DxoTreeListFormModule, typeof i2.DxoTreeListFormatModule, typeof i2.DxoTreeListFormItemModule, typeof i2.DxoTreeListFromModule, typeof i2.DxiTreeListGroupItemModule, typeof i2.DxoTreeListGroupOperationDescriptionsModule, typeof i2.DxoTreeListHeaderFilterModule, typeof i2.DxoTreeListHideModule, typeof i2.DxoTreeListIconsModule, typeof i2.DxoTreeListIndicatorOptionsModule, typeof i2.DxiTreeListItemModule, typeof i2.DxoTreeListKeyboardNavigationModule, typeof i2.DxoTreeListLabelModule, typeof i2.DxoTreeListLoadPanelModule, typeof i2.DxoTreeListLookupModule, typeof i2.DxoTreeListMyModule, typeof i2.DxiTreeListNumericRuleModule, typeof i2.DxoTreeListOffsetModule, typeof i2.DxoTreeListOperationDescriptionsModule, typeof i2.DxoTreeListOptionsModule, typeof i2.DxoTreeListPagerModule, typeof i2.DxoTreeListPagingModule, typeof i2.DxiTreeListPatternRuleModule, typeof i2.DxoTreeListPopupModule, typeof i2.DxoTreeListPositionModule, typeof i2.DxiTreeListRangeRuleModule, typeof i2.DxoTreeListRemoteOperationsModule, typeof i2.DxiTreeListRequiredRuleModule, typeof i2.DxoTreeListRowDraggingModule, typeof i2.DxoTreeListScrollingModule, typeof i2.DxoTreeListSearchModule, typeof i2.DxoTreeListSearchPanelModule, typeof i2.DxoTreeListSelectionModule, typeof i2.DxoTreeListShowModule, typeof i2.DxiTreeListSimpleItemModule, typeof i2.DxoTreeListSortingModule, typeof i2.DxoTreeListStateStoringModule, typeof i2.DxiTreeListStringLengthRuleModule, typeof i2.DxiTreeListTabModule, typeof i2.DxiTreeListTabbedItemModule, typeof i2.DxoTreeListTabPanelOptionsModule, typeof i2.DxiTreeListTabPanelOptionsItemModule, typeof i2.DxoTreeListTextsModule, typeof i2.DxoTreeListToModule, typeof i2.DxoTreeListToolbarModule, typeof i2.DxiTreeListToolbarItemModule, typeof i2.DxoTreeListTreeListHeaderFilterModule, typeof i2.DxoTreeListTreeListHeaderFilterSearchModule, typeof i2.DxoTreeListTreeListHeaderFilterTextsModule, typeof i2.DxoTreeListTreeListSelectionModule, typeof i2.DxiTreeListTreeListToolbarItemModule, typeof i2.DxiTreeListValidationRuleModule, typeof i3.DxTemplateModule]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxTreeListModule>;
}

export { DxTreeListComponent, DxTreeListModule };
//# sourceMappingURL=index.d.ts.map
