import * as i0 from '@angular/core';
import { OnDestroy, OnInit, AfterViewInit, Renderer2, ElementRef, QueryList, EventEmitter } from '@angular/core';
import { AIIntegration } from 'devextreme/common/ai-integration';
import { CommandInfo, ResponseStatusTexts, ResponseStatus, AIColumnMode, DataChangeType, ColumnChooserMode, ColumnChooserSearchConfig, ColumnChooserSelectionConfig, ColumnAIOptions, FilterOperation, FilterType, FixedPosition, ColumnHeaderFilter, SelectedFilterOperation, HeaderFilterGroupInterval, ColumnHeaderFilterSearchConfig, DataChange, GridsEditMode, GridsEditRefreshMode, StartEditAction, FilterPanel, FilterPanelTexts, ApplyFilterMode, HeaderFilterSearchConfig, HeaderFilterTexts, EnterKeyAction, EnterKeyDirection, PagerPageSize, DataRenderMode, StateStoreType } from 'devextreme/common/grids';
import dxPopup, { dxPopupOptions, dxPopupToolbarItem, ToolbarLocation } from 'devextreme/ui/popup';
import { NestedOption, NestedOptionHost, CollectionNestedOption, IDxTemplateHost, DxTemplateHost, DxTemplateDirective } from 'devextreme-angular/core';
import { dxTextBoxOptions, TextBoxType, ChangeEvent, ContentReadyEvent as ContentReadyEvent$1, CopyEvent, CutEvent, DisposingEvent as DisposingEvent$1, EnterKeyEvent, FocusInEvent, FocusOutEvent, InitializedEvent as InitializedEvent$1, InputEvent, KeyDownEvent, KeyUpEvent, OptionChangedEvent as OptionChangedEvent$1, PasteEvent, ValueChangedEvent } from 'devextreme/ui/text_box';
import { AnimationConfig, CollisionResolution, PositionConfig, AnimationState, AnimationType, CollisionResolutionCombination } from 'devextreme/common/core/animation';
import * as CommonTypes from 'devextreme/common';
import { ValidationRuleType, HorizontalAlignment, VerticalAlignment, TextEditorButtonLocation, ButtonStyle, ButtonType, SortOrder, DataType, SearchMode, ComparisonOperator, TextBoxPredefinedButton, TextEditorButton, LabelMode, MaskMode, EditorStyle, ValidationMessageMode, Position, ValidationStatus, PositionAlignment, Mode, Format as Format$1, Direction, ToolbarItemLocation, ToolbarItemComponent, DisplayMode, DragDirection, DragHighlight, ScrollMode, ScrollbarMode, SingleMultipleOrNone, TabsIconPosition, TabsStyle } from 'devextreme/common';
import dxTreeList, { dxTreeListColumn, dxTreeListRowObject, TreeListPredefinedColumnButton, ColumnButtonClickEvent, dxTreeListColumnButton, TreeListCommandColumnType, TreeListPredefinedToolbarItem, RowDraggingAddEvent, RowDraggingChangeEvent, RowDraggingEndEvent, RowDraggingMoveEvent, RowDraggingStartEvent, RowDraggingRemoveEvent, RowDraggingReorderEvent, dxTreeListToolbarItem } from 'devextreme/ui/tree_list';
import { dxButtonOptions, ClickEvent, ContentReadyEvent, DisposingEvent, InitializedEvent, OptionChangedEvent } from 'devextreme/ui/button';
import { FormItemType, FormPredefinedButtonItem, dxFormSimpleItem, dxFormOptions, FormItemComponent, LabelLocation, dxFormGroupItem, dxFormTabbedItem, dxFormEmptyItem, dxFormButtonItem, FormLabelMode, ContentReadyEvent as ContentReadyEvent$3, DisposingEvent as DisposingEvent$3, EditorEnterKeyEvent, FieldDataChangedEvent, InitializedEvent as InitializedEvent$3, OptionChangedEvent as OptionChangedEvent$3, SmartPastedEvent, SmartPastingEvent } from 'devextreme/ui/form';
import { Format } from 'devextreme/common/core/localization';
import DataSource, { DataSourceOptions } from 'devextreme/data/data_source';
import { Store } from 'devextreme/data/store';
import { dxFilterBuilderField, FieldInfo, FilterBuilderOperation, dxFilterBuilderCustomOperation, GroupOperation, ContentReadyEvent as ContentReadyEvent$2, DisposingEvent as DisposingEvent$2, EditorPreparedEvent, EditorPreparingEvent, InitializedEvent as InitializedEvent$2, OptionChangedEvent as OptionChangedEvent$2, ValueChangedEvent as ValueChangedEvent$1 } from 'devextreme/ui/filter_builder';
import dxOverlay from 'devextreme/ui/overlay';
import DOMComponent from 'devextreme/core/dom_component';
import { event } from 'devextreme/events/events.types';
import { EventInfo } from 'devextreme/common/core/events';
import { Component } from 'devextreme/core/component';
import { LoadingAnimationType } from 'devextreme/ui/load_indicator';
import { dxTabPanelOptions, dxTabPanelItem, ContentReadyEvent as ContentReadyEvent$4, DisposingEvent as DisposingEvent$4, InitializedEvent as InitializedEvent$4, ItemClickEvent, ItemContextMenuEvent, ItemHoldEvent, ItemRenderedEvent, OptionChangedEvent as OptionChangedEvent$4, SelectionChangedEvent, SelectionChangingEvent, TitleClickEvent, TitleHoldEvent, TitleRenderedEvent } from 'devextreme/ui/tab_panel';
import { LocateInMenuMode, ShowTextMode } from 'devextreme/ui/toolbar';
import { LoadPanelIndicatorProperties } from 'devextreme/ui/load_panel';

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoTreeListAIAssistantComponent extends NestedOption implements OnDestroy, OnInit {
    get aiIntegration(): AIIntegration;
    set aiIntegration(value: AIIntegration);
    get chat(): Record<string, any>;
    set chat(value: Record<string, any>);
    get customizeResponseText(): ((command: CommandInfo) => ResponseStatusTexts);
    set customizeResponseText(value: ((command: CommandInfo) => ResponseStatusTexts));
    get customizeResponseTitle(): ((status: ResponseStatus, commandNames: Array<string>) => string);
    set customizeResponseTitle(value: ((status: ResponseStatus, commandNames: Array<string>) => string));
    get enabled(): boolean;
    set enabled(value: boolean);
    get popup(): dxPopupOptions<any>;
    set popup(value: dxPopupOptions<any>);
    get title(): string;
    set title(value: string);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTreeListAIAssistantComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoTreeListAIAssistantComponent, "dxo-tree-list-ai-assistant", never, { "aiIntegration": { "alias": "aiIntegration"; "required": false; }; "chat": { "alias": "chat"; "required": false; }; "customizeResponseText": { "alias": "customizeResponseText"; "required": false; }; "customizeResponseTitle": { "alias": "customizeResponseTitle"; "required": false; }; "enabled": { "alias": "enabled"; "required": false; }; "popup": { "alias": "popup"; "required": false; }; "title": { "alias": "title"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoTreeListAIAssistantModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTreeListAIAssistantModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoTreeListAIAssistantModule, never, [typeof DxoTreeListAIAssistantComponent], [typeof DxoTreeListAIAssistantComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoTreeListAIAssistantModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoTreeListAIOptionsComponent extends NestedOption implements OnDestroy, OnInit {
    get disabled(): boolean;
    set disabled(value: boolean);
    get instruction(): string | undefined;
    set instruction(value: string | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTreeListAIOptionsComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoTreeListAIOptionsComponent, "dxo-tree-list-ai-options", never, { "disabled": { "alias": "disabled"; "required": false; }; "instruction": { "alias": "instruction"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoTreeListAIOptionsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTreeListAIOptionsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoTreeListAIOptionsModule, never, [typeof DxoTreeListAIOptionsComponent], [typeof DxoTreeListAIOptionsComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoTreeListAIOptionsModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoTreeListAIComponent extends NestedOption implements OnDestroy, OnInit {
    get aiIntegration(): AIIntegration | undefined;
    set aiIntegration(value: AIIntegration | undefined);
    get editorOptions(): dxTextBoxOptions<any>;
    set editorOptions(value: dxTextBoxOptions<any>);
    get emptyText(): string;
    set emptyText(value: string);
    get mode(): AIColumnMode;
    set mode(value: AIColumnMode);
    get noDataText(): string;
    set noDataText(value: string);
    get popup(): Record<string, any>;
    set popup(value: Record<string, any>);
    get prompt(): string;
    set prompt(value: string);
    get showHeaderMenu(): boolean;
    set showHeaderMenu(value: boolean);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTreeListAIComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoTreeListAIComponent, "dxo-tree-list-ai", never, { "aiIntegration": { "alias": "aiIntegration"; "required": false; }; "editorOptions": { "alias": "editorOptions"; "required": false; }; "emptyText": { "alias": "emptyText"; "required": false; }; "mode": { "alias": "mode"; "required": false; }; "noDataText": { "alias": "noDataText"; "required": false; }; "popup": { "alias": "popup"; "required": false; }; "prompt": { "alias": "prompt"; "required": false; }; "showHeaderMenu": { "alias": "showHeaderMenu"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoTreeListAIModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTreeListAIModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoTreeListAIModule, never, [typeof DxoTreeListAIComponent], [typeof DxoTreeListAIComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoTreeListAIModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoTreeListAnimationComponent extends NestedOption implements OnDestroy, OnInit {
    get hide(): AnimationConfig;
    set hide(value: AnimationConfig);
    get show(): AnimationConfig;
    set show(value: AnimationConfig);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTreeListAnimationComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoTreeListAnimationComponent, "dxo-tree-list-animation", never, { "hide": { "alias": "hide"; "required": false; }; "show": { "alias": "show"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoTreeListAnimationModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTreeListAnimationModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoTreeListAnimationModule, never, [typeof DxoTreeListAnimationComponent], [typeof DxoTreeListAnimationComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoTreeListAnimationModule>;
}

declare class DxiTreeListAsyncRuleComponent extends CollectionNestedOption {
    get ignoreEmptyValue(): boolean;
    set ignoreEmptyValue(value: boolean);
    get message(): string;
    set message(value: string);
    get reevaluate(): boolean;
    set reevaluate(value: boolean);
    get type(): ValidationRuleType;
    set type(value: ValidationRuleType);
    get validationCallback(): ((options: {
        column: Record<string, any>;
        data: Record<string, any>;
        formItem: Record<string, any>;
        rule: Record<string, any>;
        validator: Record<string, any>;
        value: any;
    }) => any);
    set validationCallback(value: ((options: {
        column: Record<string, any>;
        data: Record<string, any>;
        formItem: Record<string, any>;
        rule: Record<string, any>;
        validator: Record<string, any>;
        value: any;
    }) => any));
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiTreeListAsyncRuleComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiTreeListAsyncRuleComponent, "dxi-tree-list-async-rule", never, { "ignoreEmptyValue": { "alias": "ignoreEmptyValue"; "required": false; }; "message": { "alias": "message"; "required": false; }; "reevaluate": { "alias": "reevaluate"; "required": false; }; "type": { "alias": "type"; "required": false; }; "validationCallback": { "alias": "validationCallback"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxiTreeListAsyncRuleModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiTreeListAsyncRuleModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiTreeListAsyncRuleModule, never, [typeof DxiTreeListAsyncRuleComponent], [typeof DxiTreeListAsyncRuleComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiTreeListAsyncRuleModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoTreeListAtComponent extends NestedOption implements OnDestroy, OnInit {
    get x(): HorizontalAlignment;
    set x(value: HorizontalAlignment);
    get y(): VerticalAlignment;
    set y(value: VerticalAlignment);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTreeListAtComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoTreeListAtComponent, "dxo-tree-list-at", never, { "x": { "alias": "x"; "required": false; }; "y": { "alias": "y"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoTreeListAtModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTreeListAtModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoTreeListAtModule, never, [typeof DxoTreeListAtComponent], [typeof DxoTreeListAtComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoTreeListAtModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoTreeListBoundaryOffsetComponent extends NestedOption implements OnDestroy, OnInit {
    get x(): number;
    set x(value: number);
    get y(): number;
    set y(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTreeListBoundaryOffsetComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoTreeListBoundaryOffsetComponent, "dxo-tree-list-boundary-offset", never, { "x": { "alias": "x"; "required": false; }; "y": { "alias": "y"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoTreeListBoundaryOffsetModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTreeListBoundaryOffsetModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoTreeListBoundaryOffsetModule, never, [typeof DxoTreeListBoundaryOffsetComponent], [typeof DxoTreeListBoundaryOffsetComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoTreeListBoundaryOffsetModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxiTreeListButtonComponent extends CollectionNestedOption implements AfterViewInit, IDxTemplateHost {
    private renderer;
    private document;
    private element;
    get cssClass(): string;
    set cssClass(value: string);
    get disabled(): boolean | ((options: {
        column: dxTreeListColumn;
        component: dxTreeList;
        row: dxTreeListRowObject;
    }) => boolean);
    set disabled(value: boolean | ((options: {
        column: dxTreeListColumn;
        component: dxTreeList;
        row: dxTreeListRowObject;
    }) => boolean));
    get hint(): string;
    set hint(value: string);
    get icon(): string;
    set icon(value: string);
    get name(): string | TreeListPredefinedColumnButton | undefined;
    set name(value: string | TreeListPredefinedColumnButton | undefined);
    get onClick(): ((e: ColumnButtonClickEvent) => void);
    set onClick(value: ((e: ColumnButtonClickEvent) => void));
    get template(): any;
    set template(value: any);
    get text(): string;
    set text(value: string);
    get visible(): boolean | ((options: {
        column: dxTreeListColumn;
        component: dxTreeList;
        row: dxTreeListRowObject;
    }) => boolean);
    set visible(value: boolean | ((options: {
        column: dxTreeListColumn;
        component: dxTreeList;
        row: dxTreeListRowObject;
    }) => boolean));
    get location(): TextEditorButtonLocation;
    set location(value: TextEditorButtonLocation);
    get options(): dxButtonOptions | undefined;
    set options(value: dxButtonOptions | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost, renderer: Renderer2, document: any, templateHost: DxTemplateHost, element: ElementRef);
    setTemplate(template: DxTemplateDirective): void;
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiTreeListButtonComponent, [{ host: true; skipSelf: true; }, { host: true; }, null, null, { host: true; }, null]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiTreeListButtonComponent, "dxi-tree-list-button", never, { "cssClass": { "alias": "cssClass"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "hint": { "alias": "hint"; "required": false; }; "icon": { "alias": "icon"; "required": false; }; "name": { "alias": "name"; "required": false; }; "onClick": { "alias": "onClick"; "required": false; }; "template": { "alias": "template"; "required": false; }; "text": { "alias": "text"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "location": { "alias": "location"; "required": false; }; "options": { "alias": "options"; "required": false; }; }, {}, never, ["*"], true, never>;
}
declare class DxiTreeListButtonModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiTreeListButtonModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiTreeListButtonModule, never, [typeof DxiTreeListButtonComponent], [typeof DxiTreeListButtonComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiTreeListButtonModule>;
}

declare class DxiTreeListButtonItemComponent extends CollectionNestedOption {
    get buttonOptions(): dxButtonOptions | undefined;
    set buttonOptions(value: dxButtonOptions | undefined);
    get colSpan(): number | undefined;
    set colSpan(value: number | undefined);
    get cssClass(): string | undefined;
    set cssClass(value: string | undefined);
    get horizontalAlignment(): HorizontalAlignment;
    set horizontalAlignment(value: HorizontalAlignment);
    get itemType(): FormItemType;
    set itemType(value: FormItemType);
    get name(): FormPredefinedButtonItem | string | undefined;
    set name(value: FormPredefinedButtonItem | string | undefined);
    get verticalAlignment(): VerticalAlignment;
    set verticalAlignment(value: VerticalAlignment);
    get visible(): boolean;
    set visible(value: boolean);
    get visibleIndex(): number | undefined;
    set visibleIndex(value: number | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiTreeListButtonItemComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiTreeListButtonItemComponent, "dxi-tree-list-button-item", never, { "buttonOptions": { "alias": "buttonOptions"; "required": false; }; "colSpan": { "alias": "colSpan"; "required": false; }; "cssClass": { "alias": "cssClass"; "required": false; }; "horizontalAlignment": { "alias": "horizontalAlignment"; "required": false; }; "itemType": { "alias": "itemType"; "required": false; }; "name": { "alias": "name"; "required": false; }; "verticalAlignment": { "alias": "verticalAlignment"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "visibleIndex": { "alias": "visibleIndex"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxiTreeListButtonItemModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiTreeListButtonItemModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiTreeListButtonItemModule, never, [typeof DxiTreeListButtonItemComponent], [typeof DxiTreeListButtonItemComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiTreeListButtonItemModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoTreeListButtonOptionsComponent extends NestedOption implements AfterViewInit, OnDestroy, OnInit, IDxTemplateHost {
    private renderer;
    private document;
    private element;
    get accessKey(): string | undefined;
    set accessKey(value: string | undefined);
    get activeStateEnabled(): boolean;
    set activeStateEnabled(value: boolean);
    get disabled(): boolean;
    set disabled(value: boolean);
    get elementAttr(): Record<string, any>;
    set elementAttr(value: Record<string, any>);
    get focusStateEnabled(): boolean;
    set focusStateEnabled(value: boolean);
    get height(): number | string | undefined;
    set height(value: number | string | undefined);
    get hint(): string | undefined;
    set hint(value: string | undefined);
    get hoverStateEnabled(): boolean;
    set hoverStateEnabled(value: boolean);
    get icon(): string;
    set icon(value: string);
    get onClick(): ((e: ClickEvent) => void) | undefined;
    set onClick(value: ((e: ClickEvent) => void) | undefined);
    get onContentReady(): ((e: ContentReadyEvent) => void);
    set onContentReady(value: ((e: ContentReadyEvent) => void));
    get onDisposing(): ((e: DisposingEvent) => void);
    set onDisposing(value: ((e: DisposingEvent) => void));
    get onInitialized(): ((e: InitializedEvent) => void);
    set onInitialized(value: ((e: InitializedEvent) => void));
    get onOptionChanged(): ((e: OptionChangedEvent) => void);
    set onOptionChanged(value: ((e: OptionChangedEvent) => void));
    get rtlEnabled(): boolean;
    set rtlEnabled(value: boolean);
    get stylingMode(): ButtonStyle;
    set stylingMode(value: ButtonStyle);
    get tabIndex(): number;
    set tabIndex(value: number);
    get template(): any;
    set template(value: any);
    get text(): string;
    set text(value: string);
    get type(): ButtonType | string;
    set type(value: ButtonType | string);
    get useSubmitBehavior(): boolean;
    set useSubmitBehavior(value: boolean);
    get validationGroup(): string | undefined;
    set validationGroup(value: string | undefined);
    get visible(): boolean;
    set visible(value: boolean);
    get width(): number | string | undefined;
    set width(value: number | string | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost, renderer: Renderer2, document: any, templateHost: DxTemplateHost, element: ElementRef);
    setTemplate(template: DxTemplateDirective): void;
    ngAfterViewInit(): void;
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTreeListButtonOptionsComponent, [{ host: true; skipSelf: true; }, { host: true; }, null, null, { host: true; }, null]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoTreeListButtonOptionsComponent, "dxo-tree-list-button-options", never, { "accessKey": { "alias": "accessKey"; "required": false; }; "activeStateEnabled": { "alias": "activeStateEnabled"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "elementAttr": { "alias": "elementAttr"; "required": false; }; "focusStateEnabled": { "alias": "focusStateEnabled"; "required": false; }; "height": { "alias": "height"; "required": false; }; "hint": { "alias": "hint"; "required": false; }; "hoverStateEnabled": { "alias": "hoverStateEnabled"; "required": false; }; "icon": { "alias": "icon"; "required": false; }; "onClick": { "alias": "onClick"; "required": false; }; "onContentReady": { "alias": "onContentReady"; "required": false; }; "onDisposing": { "alias": "onDisposing"; "required": false; }; "onInitialized": { "alias": "onInitialized"; "required": false; }; "onOptionChanged": { "alias": "onOptionChanged"; "required": false; }; "rtlEnabled": { "alias": "rtlEnabled"; "required": false; }; "stylingMode": { "alias": "stylingMode"; "required": false; }; "tabIndex": { "alias": "tabIndex"; "required": false; }; "template": { "alias": "template"; "required": false; }; "text": { "alias": "text"; "required": false; }; "type": { "alias": "type"; "required": false; }; "useSubmitBehavior": { "alias": "useSubmitBehavior"; "required": false; }; "validationGroup": { "alias": "validationGroup"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, ["*"], true, never>;
}
declare class DxoTreeListButtonOptionsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTreeListButtonOptionsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoTreeListButtonOptionsModule, never, [typeof DxoTreeListButtonOptionsComponent], [typeof DxoTreeListButtonOptionsComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoTreeListButtonOptionsModule>;
}

declare class DxiTreeListChangeComponent extends CollectionNestedOption {
    get data(): any;
    set data(value: any);
    get insertAfterKey(): any;
    set insertAfterKey(value: any);
    get insertBeforeKey(): any;
    set insertBeforeKey(value: any);
    get key(): any;
    set key(value: any);
    get type(): DataChangeType;
    set type(value: DataChangeType);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiTreeListChangeComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiTreeListChangeComponent, "dxi-tree-list-change", never, { "data": { "alias": "data"; "required": false; }; "insertAfterKey": { "alias": "insertAfterKey"; "required": false; }; "insertBeforeKey": { "alias": "insertBeforeKey"; "required": false; }; "key": { "alias": "key"; "required": false; }; "type": { "alias": "type"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxiTreeListChangeModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiTreeListChangeModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiTreeListChangeModule, never, [typeof DxiTreeListChangeComponent], [typeof DxiTreeListChangeComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiTreeListChangeModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoTreeListColCountByScreenComponent extends NestedOption implements OnDestroy, OnInit {
    get lg(): number | undefined;
    set lg(value: number | undefined);
    get md(): number | undefined;
    set md(value: number | undefined);
    get sm(): number | undefined;
    set sm(value: number | undefined);
    get xs(): number | undefined;
    set xs(value: number | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTreeListColCountByScreenComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoTreeListColCountByScreenComponent, "dxo-tree-list-col-count-by-screen", never, { "lg": { "alias": "lg"; "required": false; }; "md": { "alias": "md"; "required": false; }; "sm": { "alias": "sm"; "required": false; }; "xs": { "alias": "xs"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoTreeListColCountByScreenModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTreeListColCountByScreenModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoTreeListColCountByScreenModule, never, [typeof DxoTreeListColCountByScreenComponent], [typeof DxoTreeListColCountByScreenComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoTreeListColCountByScreenModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoTreeListCollisionComponent extends NestedOption implements OnDestroy, OnInit {
    get x(): CollisionResolution;
    set x(value: CollisionResolution);
    get y(): CollisionResolution;
    set y(value: CollisionResolution);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTreeListCollisionComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoTreeListCollisionComponent, "dxo-tree-list-collision", never, { "x": { "alias": "x"; "required": false; }; "y": { "alias": "y"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoTreeListCollisionModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTreeListCollisionModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoTreeListCollisionModule, never, [typeof DxoTreeListCollisionComponent], [typeof DxoTreeListCollisionComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoTreeListCollisionModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxiTreeListColumnButtonComponent extends CollectionNestedOption implements AfterViewInit, IDxTemplateHost {
    private renderer;
    private document;
    private element;
    get cssClass(): string;
    set cssClass(value: string);
    get disabled(): boolean | ((options: {
        column: dxTreeListColumn;
        component: dxTreeList;
        row: dxTreeListRowObject;
    }) => boolean);
    set disabled(value: boolean | ((options: {
        column: dxTreeListColumn;
        component: dxTreeList;
        row: dxTreeListRowObject;
    }) => boolean));
    get hint(): string;
    set hint(value: string);
    get icon(): string;
    set icon(value: string);
    get name(): string | TreeListPredefinedColumnButton;
    set name(value: string | TreeListPredefinedColumnButton);
    get onClick(): ((e: ColumnButtonClickEvent) => void);
    set onClick(value: ((e: ColumnButtonClickEvent) => void));
    get template(): any;
    set template(value: any);
    get text(): string;
    set text(value: string);
    get visible(): boolean | ((options: {
        column: dxTreeListColumn;
        component: dxTreeList;
        row: dxTreeListRowObject;
    }) => boolean);
    set visible(value: boolean | ((options: {
        column: dxTreeListColumn;
        component: dxTreeList;
        row: dxTreeListRowObject;
    }) => boolean));
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost, renderer: Renderer2, document: any, templateHost: DxTemplateHost, element: ElementRef);
    setTemplate(template: DxTemplateDirective): void;
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiTreeListColumnButtonComponent, [{ host: true; skipSelf: true; }, { host: true; }, null, null, { host: true; }, null]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiTreeListColumnButtonComponent, "dxi-tree-list-column-button", never, { "cssClass": { "alias": "cssClass"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "hint": { "alias": "hint"; "required": false; }; "icon": { "alias": "icon"; "required": false; }; "name": { "alias": "name"; "required": false; }; "onClick": { "alias": "onClick"; "required": false; }; "template": { "alias": "template"; "required": false; }; "text": { "alias": "text"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; }, {}, never, ["*"], true, never>;
}
declare class DxiTreeListColumnButtonModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiTreeListColumnButtonModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiTreeListColumnButtonModule, never, [typeof DxiTreeListColumnButtonComponent], [typeof DxiTreeListColumnButtonComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiTreeListColumnButtonModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoTreeListColumnChooserSearchComponent extends NestedOption implements OnDestroy, OnInit {
    get editorOptions(): any;
    set editorOptions(value: any);
    get enabled(): boolean;
    set enabled(value: boolean);
    get timeout(): number;
    set timeout(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTreeListColumnChooserSearchComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoTreeListColumnChooserSearchComponent, "dxo-tree-list-column-chooser-search", never, { "editorOptions": { "alias": "editorOptions"; "required": false; }; "enabled": { "alias": "enabled"; "required": false; }; "timeout": { "alias": "timeout"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoTreeListColumnChooserSearchModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTreeListColumnChooserSearchModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoTreeListColumnChooserSearchModule, never, [typeof DxoTreeListColumnChooserSearchComponent], [typeof DxoTreeListColumnChooserSearchComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoTreeListColumnChooserSearchModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoTreeListColumnChooserSelectionComponent extends NestedOption implements OnDestroy, OnInit {
    get allowSelectAll(): boolean;
    set allowSelectAll(value: boolean);
    get recursive(): boolean;
    set recursive(value: boolean);
    get selectByClick(): boolean;
    set selectByClick(value: boolean);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTreeListColumnChooserSelectionComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoTreeListColumnChooserSelectionComponent, "dxo-tree-list-column-chooser-selection", never, { "allowSelectAll": { "alias": "allowSelectAll"; "required": false; }; "recursive": { "alias": "recursive"; "required": false; }; "selectByClick": { "alias": "selectByClick"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoTreeListColumnChooserSelectionModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTreeListColumnChooserSelectionModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoTreeListColumnChooserSelectionModule, never, [typeof DxoTreeListColumnChooserSelectionComponent], [typeof DxoTreeListColumnChooserSelectionComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoTreeListColumnChooserSelectionModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoTreeListColumnChooserComponent extends NestedOption implements OnDestroy, OnInit {
    get allowSearch(): boolean;
    set allowSearch(value: boolean);
    get container(): any | string | undefined;
    set container(value: any | string | undefined);
    get emptyPanelText(): string;
    set emptyPanelText(value: string);
    get enabled(): boolean;
    set enabled(value: boolean);
    get height(): number | string;
    set height(value: number | string);
    get mode(): ColumnChooserMode;
    set mode(value: ColumnChooserMode);
    get position(): PositionConfig | undefined;
    set position(value: PositionConfig | undefined);
    get search(): ColumnChooserSearchConfig;
    set search(value: ColumnChooserSearchConfig);
    get searchTimeout(): number;
    set searchTimeout(value: number);
    get selection(): ColumnChooserSelectionConfig;
    set selection(value: ColumnChooserSelectionConfig);
    get sortOrder(): SortOrder | undefined;
    set sortOrder(value: SortOrder | undefined);
    get title(): string;
    set title(value: string);
    get width(): number | string;
    set width(value: number | string);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTreeListColumnChooserComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoTreeListColumnChooserComponent, "dxo-tree-list-column-chooser", never, { "allowSearch": { "alias": "allowSearch"; "required": false; }; "container": { "alias": "container"; "required": false; }; "emptyPanelText": { "alias": "emptyPanelText"; "required": false; }; "enabled": { "alias": "enabled"; "required": false; }; "height": { "alias": "height"; "required": false; }; "mode": { "alias": "mode"; "required": false; }; "position": { "alias": "position"; "required": false; }; "search": { "alias": "search"; "required": false; }; "searchTimeout": { "alias": "searchTimeout"; "required": false; }; "selection": { "alias": "selection"; "required": false; }; "sortOrder": { "alias": "sortOrder"; "required": false; }; "title": { "alias": "title"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoTreeListColumnChooserModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTreeListColumnChooserModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoTreeListColumnChooserModule, never, [typeof DxoTreeListColumnChooserComponent], [typeof DxoTreeListColumnChooserComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoTreeListColumnChooserModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxiTreeListColumnComponent extends CollectionNestedOption {
    set _validationRulesContentChildren(value: QueryList<CollectionNestedOption>);
    set _buttonsContentChildren(value: QueryList<CollectionNestedOption>);
    set _columnsContentChildren(value: QueryList<CollectionNestedOption>);
    get ai(): ColumnAIOptions;
    set ai(value: ColumnAIOptions);
    get alignment(): HorizontalAlignment | undefined;
    set alignment(value: HorizontalAlignment | undefined);
    get allowEditing(): boolean;
    set allowEditing(value: boolean);
    get allowFiltering(): boolean;
    set allowFiltering(value: boolean);
    get allowFixing(): boolean;
    set allowFixing(value: boolean);
    get allowHeaderFiltering(): boolean;
    set allowHeaderFiltering(value: boolean);
    get allowHiding(): boolean;
    set allowHiding(value: boolean);
    get allowReordering(): boolean;
    set allowReordering(value: boolean);
    get allowResizing(): boolean;
    set allowResizing(value: boolean);
    get allowSearch(): boolean;
    set allowSearch(value: boolean);
    get allowSorting(): boolean;
    set allowSorting(value: boolean);
    get buttons(): Array<dxTreeListColumnButton | TreeListPredefinedColumnButton>;
    set buttons(value: Array<dxTreeListColumnButton | TreeListPredefinedColumnButton>);
    get calculateCellValue(): ((rowData: any) => any);
    set calculateCellValue(value: ((rowData: any) => any));
    get calculateDisplayValue(): ((rowData: any) => any) | string;
    set calculateDisplayValue(value: ((rowData: any) => any) | string);
    get calculateFilterExpression(): ((filterValue: any, selectedFilterOperation: string | null, target: string) => string | Function | Array<any>);
    set calculateFilterExpression(value: ((filterValue: any, selectedFilterOperation: string | null, target: string) => string | Function | Array<any>));
    get calculateSortValue(): ((rowData: any) => any) | string;
    set calculateSortValue(value: ((rowData: any) => any) | string);
    get caption(): string | undefined;
    set caption(value: string | undefined);
    get cellTemplate(): any;
    set cellTemplate(value: any);
    get columns(): Array<dxTreeListColumn | string>;
    set columns(value: Array<dxTreeListColumn | string>);
    get cssClass(): string | undefined;
    set cssClass(value: string | undefined);
    get customizeText(): ((cellInfo: {
        groupInterval: string | number;
        target: string;
        value: any;
        valueText: string;
    }) => string);
    set customizeText(value: ((cellInfo: {
        groupInterval: string | number;
        target: string;
        value: any;
        valueText: string;
    }) => string));
    get dataField(): string | undefined;
    set dataField(value: string | undefined);
    get dataType(): DataType | undefined;
    set dataType(value: DataType | undefined);
    get editCellTemplate(): any;
    set editCellTemplate(value: any);
    get editorOptions(): any;
    set editorOptions(value: any);
    get encodeHtml(): boolean;
    set encodeHtml(value: boolean);
    get falseText(): string;
    set falseText(value: string);
    get filterOperations(): Array<FilterOperation | string>;
    set filterOperations(value: Array<FilterOperation | string>);
    get filterType(): FilterType;
    set filterType(value: FilterType);
    get filterValue(): any | undefined;
    set filterValue(value: any | undefined);
    get filterValues(): Array<any>;
    set filterValues(value: Array<any>);
    get fixed(): boolean;
    set fixed(value: boolean);
    get fixedPosition(): FixedPosition | undefined;
    set fixedPosition(value: FixedPosition | undefined);
    get format(): Format;
    set format(value: Format);
    get formItem(): dxFormSimpleItem;
    set formItem(value: dxFormSimpleItem);
    get headerCellTemplate(): any;
    set headerCellTemplate(value: any);
    get headerFilter(): ColumnHeaderFilter | undefined;
    set headerFilter(value: ColumnHeaderFilter | undefined);
    get hidingPriority(): number | undefined;
    set hidingPriority(value: number | undefined);
    get isBand(): boolean | undefined;
    set isBand(value: boolean | undefined);
    get lookup(): {
        allowClearing?: boolean;
        calculateCellValue?: ((rowData: any) => any);
        dataSource?: Array<any> | DataSourceOptions | ((options: {
            data: Record<string, any>;
            key: any;
        }) => Array<any> | Store | DataSourceOptions) | null | Store | undefined;
        displayExpr?: ((data: any) => string) | string | undefined;
        valueExpr?: string | undefined;
    };
    set lookup(value: {
        allowClearing?: boolean;
        calculateCellValue?: ((rowData: any) => any);
        dataSource?: Array<any> | DataSourceOptions | ((options: {
            data: Record<string, any>;
            key: any;
        }) => Array<any> | Store | DataSourceOptions) | null | Store | undefined;
        displayExpr?: ((data: any) => string) | string | undefined;
        valueExpr?: string | undefined;
    });
    get minWidth(): number | undefined;
    set minWidth(value: number | undefined);
    get name(): string | undefined;
    set name(value: string | undefined);
    get ownerBand(): number | undefined;
    set ownerBand(value: number | undefined);
    get renderAsync(): boolean;
    set renderAsync(value: boolean);
    get selectedFilterOperation(): SelectedFilterOperation | undefined;
    set selectedFilterOperation(value: SelectedFilterOperation | undefined);
    get setCellValue(): ((newData: any, value: any, currentRowData: any) => any);
    set setCellValue(value: ((newData: any, value: any, currentRowData: any) => any));
    get showEditorAlways(): boolean;
    set showEditorAlways(value: boolean);
    get showInColumnChooser(): boolean;
    set showInColumnChooser(value: boolean);
    get sortIndex(): number | undefined;
    set sortIndex(value: number | undefined);
    get sortingMethod(): ((value1: any, value2: any) => number) | undefined;
    set sortingMethod(value: ((value1: any, value2: any) => number) | undefined);
    get sortOrder(): SortOrder | undefined;
    set sortOrder(value: SortOrder | undefined);
    get trueText(): string;
    set trueText(value: string);
    get type(): TreeListCommandColumnType;
    set type(value: TreeListCommandColumnType);
    get validationRules(): Array<CommonTypes.ValidationRule>;
    set validationRules(value: Array<CommonTypes.ValidationRule>);
    get visible(): boolean;
    set visible(value: boolean);
    get visibleIndex(): number | undefined;
    set visibleIndex(value: number | undefined);
    get width(): number | string | undefined;
    set width(value: number | string | undefined);
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    filterValueChange: EventEmitter<any | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    filterValuesChange: EventEmitter<Array<any>>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    selectedFilterOperationChange: EventEmitter<SelectedFilterOperation | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    sortIndexChange: EventEmitter<number | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    sortOrderChange: EventEmitter<SortOrder | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    visibleChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    visibleIndexChange: EventEmitter<number | undefined>;
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiTreeListColumnComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiTreeListColumnComponent, "dxi-tree-list-column", never, { "ai": { "alias": "ai"; "required": false; }; "alignment": { "alias": "alignment"; "required": false; }; "allowEditing": { "alias": "allowEditing"; "required": false; }; "allowFiltering": { "alias": "allowFiltering"; "required": false; }; "allowFixing": { "alias": "allowFixing"; "required": false; }; "allowHeaderFiltering": { "alias": "allowHeaderFiltering"; "required": false; }; "allowHiding": { "alias": "allowHiding"; "required": false; }; "allowReordering": { "alias": "allowReordering"; "required": false; }; "allowResizing": { "alias": "allowResizing"; "required": false; }; "allowSearch": { "alias": "allowSearch"; "required": false; }; "allowSorting": { "alias": "allowSorting"; "required": false; }; "buttons": { "alias": "buttons"; "required": false; }; "calculateCellValue": { "alias": "calculateCellValue"; "required": false; }; "calculateDisplayValue": { "alias": "calculateDisplayValue"; "required": false; }; "calculateFilterExpression": { "alias": "calculateFilterExpression"; "required": false; }; "calculateSortValue": { "alias": "calculateSortValue"; "required": false; }; "caption": { "alias": "caption"; "required": false; }; "cellTemplate": { "alias": "cellTemplate"; "required": false; }; "columns": { "alias": "columns"; "required": false; }; "cssClass": { "alias": "cssClass"; "required": false; }; "customizeText": { "alias": "customizeText"; "required": false; }; "dataField": { "alias": "dataField"; "required": false; }; "dataType": { "alias": "dataType"; "required": false; }; "editCellTemplate": { "alias": "editCellTemplate"; "required": false; }; "editorOptions": { "alias": "editorOptions"; "required": false; }; "encodeHtml": { "alias": "encodeHtml"; "required": false; }; "falseText": { "alias": "falseText"; "required": false; }; "filterOperations": { "alias": "filterOperations"; "required": false; }; "filterType": { "alias": "filterType"; "required": false; }; "filterValue": { "alias": "filterValue"; "required": false; }; "filterValues": { "alias": "filterValues"; "required": false; }; "fixed": { "alias": "fixed"; "required": false; }; "fixedPosition": { "alias": "fixedPosition"; "required": false; }; "format": { "alias": "format"; "required": false; }; "formItem": { "alias": "formItem"; "required": false; }; "headerCellTemplate": { "alias": "headerCellTemplate"; "required": false; }; "headerFilter": { "alias": "headerFilter"; "required": false; }; "hidingPriority": { "alias": "hidingPriority"; "required": false; }; "isBand": { "alias": "isBand"; "required": false; }; "lookup": { "alias": "lookup"; "required": false; }; "minWidth": { "alias": "minWidth"; "required": false; }; "name": { "alias": "name"; "required": false; }; "ownerBand": { "alias": "ownerBand"; "required": false; }; "renderAsync": { "alias": "renderAsync"; "required": false; }; "selectedFilterOperation": { "alias": "selectedFilterOperation"; "required": false; }; "setCellValue": { "alias": "setCellValue"; "required": false; }; "showEditorAlways": { "alias": "showEditorAlways"; "required": false; }; "showInColumnChooser": { "alias": "showInColumnChooser"; "required": false; }; "sortIndex": { "alias": "sortIndex"; "required": false; }; "sortingMethod": { "alias": "sortingMethod"; "required": false; }; "sortOrder": { "alias": "sortOrder"; "required": false; }; "trueText": { "alias": "trueText"; "required": false; }; "type": { "alias": "type"; "required": false; }; "validationRules": { "alias": "validationRules"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "visibleIndex": { "alias": "visibleIndex"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, { "filterValueChange": "filterValueChange"; "filterValuesChange": "filterValuesChange"; "selectedFilterOperationChange": "selectedFilterOperationChange"; "sortIndexChange": "sortIndexChange"; "sortOrderChange": "sortOrderChange"; "visibleChange": "visibleChange"; "visibleIndexChange": "visibleIndexChange"; }, ["_validationRulesContentChildren", "_buttonsContentChildren", "_columnsContentChildren"], never, true, never>;
}
declare class DxiTreeListColumnModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiTreeListColumnModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiTreeListColumnModule, never, [typeof DxiTreeListColumnComponent], [typeof DxiTreeListColumnComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiTreeListColumnModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoTreeListColumnFixingTextsComponent extends NestedOption implements OnDestroy, OnInit {
    get fix(): string;
    set fix(value: string);
    get leftPosition(): string;
    set leftPosition(value: string);
    get rightPosition(): string;
    set rightPosition(value: string);
    get stickyPosition(): string;
    set stickyPosition(value: string);
    get unfix(): string;
    set unfix(value: string);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTreeListColumnFixingTextsComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoTreeListColumnFixingTextsComponent, "dxo-tree-list-column-fixing-texts", never, { "fix": { "alias": "fix"; "required": false; }; "leftPosition": { "alias": "leftPosition"; "required": false; }; "rightPosition": { "alias": "rightPosition"; "required": false; }; "stickyPosition": { "alias": "stickyPosition"; "required": false; }; "unfix": { "alias": "unfix"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoTreeListColumnFixingTextsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTreeListColumnFixingTextsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoTreeListColumnFixingTextsModule, never, [typeof DxoTreeListColumnFixingTextsComponent], [typeof DxoTreeListColumnFixingTextsComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoTreeListColumnFixingTextsModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoTreeListColumnFixingComponent extends NestedOption implements OnDestroy, OnInit {
    get enabled(): boolean;
    set enabled(value: boolean);
    get icons(): {
        fix?: string;
        leftPosition?: string;
        rightPosition?: string;
        stickyPosition?: string;
        unfix?: string;
    };
    set icons(value: {
        fix?: string;
        leftPosition?: string;
        rightPosition?: string;
        stickyPosition?: string;
        unfix?: string;
    });
    get texts(): {
        fix?: string;
        leftPosition?: string;
        rightPosition?: string;
        stickyPosition?: string;
        unfix?: string;
    };
    set texts(value: {
        fix?: string;
        leftPosition?: string;
        rightPosition?: string;
        stickyPosition?: string;
        unfix?: string;
    });
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTreeListColumnFixingComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoTreeListColumnFixingComponent, "dxo-tree-list-column-fixing", never, { "enabled": { "alias": "enabled"; "required": false; }; "icons": { "alias": "icons"; "required": false; }; "texts": { "alias": "texts"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoTreeListColumnFixingModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTreeListColumnFixingModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoTreeListColumnFixingModule, never, [typeof DxoTreeListColumnFixingComponent], [typeof DxoTreeListColumnFixingComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoTreeListColumnFixingModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoTreeListColumnHeaderFilterSearchComponent extends NestedOption implements OnDestroy, OnInit {
    get editorOptions(): any;
    set editorOptions(value: any);
    get enabled(): boolean;
    set enabled(value: boolean);
    get mode(): SearchMode;
    set mode(value: SearchMode);
    get searchExpr(): Array<Function | string> | Function | string | undefined;
    set searchExpr(value: Array<Function | string> | Function | string | undefined);
    get timeout(): number;
    set timeout(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTreeListColumnHeaderFilterSearchComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoTreeListColumnHeaderFilterSearchComponent, "dxo-tree-list-column-header-filter-search", never, { "editorOptions": { "alias": "editorOptions"; "required": false; }; "enabled": { "alias": "enabled"; "required": false; }; "mode": { "alias": "mode"; "required": false; }; "searchExpr": { "alias": "searchExpr"; "required": false; }; "timeout": { "alias": "timeout"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoTreeListColumnHeaderFilterSearchModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTreeListColumnHeaderFilterSearchModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoTreeListColumnHeaderFilterSearchModule, never, [typeof DxoTreeListColumnHeaderFilterSearchComponent], [typeof DxoTreeListColumnHeaderFilterSearchComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoTreeListColumnHeaderFilterSearchModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoTreeListColumnHeaderFilterComponent extends NestedOption implements OnDestroy, OnInit {
    get allowSearch(): boolean;
    set allowSearch(value: boolean);
    get allowSelectAll(): boolean;
    set allowSelectAll(value: boolean);
    get dataSource(): Array<any> | DataSourceOptions | ((options: {
        component: Record<string, any>;
        dataSource: DataSourceOptions | null;
    }) => void) | null | Store | undefined;
    set dataSource(value: Array<any> | DataSourceOptions | ((options: {
        component: Record<string, any>;
        dataSource: DataSourceOptions | null;
    }) => void) | null | Store | undefined);
    get groupInterval(): Array<number | string> | HeaderFilterGroupInterval | number | undefined;
    set groupInterval(value: Array<number | string> | HeaderFilterGroupInterval | number | undefined);
    get height(): number | string | undefined;
    set height(value: number | string | undefined);
    get search(): ColumnHeaderFilterSearchConfig;
    set search(value: ColumnHeaderFilterSearchConfig);
    get searchMode(): SearchMode;
    set searchMode(value: SearchMode);
    get width(): number | string | undefined;
    set width(value: number | string | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTreeListColumnHeaderFilterComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoTreeListColumnHeaderFilterComponent, "dxo-tree-list-column-header-filter", never, { "allowSearch": { "alias": "allowSearch"; "required": false; }; "allowSelectAll": { "alias": "allowSelectAll"; "required": false; }; "dataSource": { "alias": "dataSource"; "required": false; }; "groupInterval": { "alias": "groupInterval"; "required": false; }; "height": { "alias": "height"; "required": false; }; "search": { "alias": "search"; "required": false; }; "searchMode": { "alias": "searchMode"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoTreeListColumnHeaderFilterModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTreeListColumnHeaderFilterModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoTreeListColumnHeaderFilterModule, never, [typeof DxoTreeListColumnHeaderFilterComponent], [typeof DxoTreeListColumnHeaderFilterComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoTreeListColumnHeaderFilterModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoTreeListColumnLookupComponent extends NestedOption implements OnDestroy, OnInit {
    get allowClearing(): boolean;
    set allowClearing(value: boolean);
    get calculateCellValue(): ((rowData: any) => any);
    set calculateCellValue(value: ((rowData: any) => any));
    get dataSource(): Array<any> | DataSourceOptions | ((options: {
        data: Record<string, any>;
        key: any;
    }) => Array<any> | Store | DataSourceOptions) | null | Store | undefined;
    set dataSource(value: Array<any> | DataSourceOptions | ((options: {
        data: Record<string, any>;
        key: any;
    }) => Array<any> | Store | DataSourceOptions) | null | Store | undefined);
    get displayExpr(): ((data: any) => string) | string | undefined;
    set displayExpr(value: ((data: any) => string) | string | undefined);
    get valueExpr(): string | undefined;
    set valueExpr(value: string | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTreeListColumnLookupComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoTreeListColumnLookupComponent, "dxo-tree-list-column-lookup", never, { "allowClearing": { "alias": "allowClearing"; "required": false; }; "calculateCellValue": { "alias": "calculateCellValue"; "required": false; }; "dataSource": { "alias": "dataSource"; "required": false; }; "displayExpr": { "alias": "displayExpr"; "required": false; }; "valueExpr": { "alias": "valueExpr"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoTreeListColumnLookupModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTreeListColumnLookupModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoTreeListColumnLookupModule, never, [typeof DxoTreeListColumnLookupComponent], [typeof DxoTreeListColumnLookupComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoTreeListColumnLookupModule>;
}

declare class DxiTreeListCompareRuleComponent extends CollectionNestedOption {
    get comparisonTarget(): Function;
    set comparisonTarget(value: Function);
    get comparisonType(): ComparisonOperator;
    set comparisonType(value: ComparisonOperator);
    get ignoreEmptyValue(): boolean;
    set ignoreEmptyValue(value: boolean);
    get message(): string;
    set message(value: string);
    get type(): ValidationRuleType;
    set type(value: ValidationRuleType);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiTreeListCompareRuleComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiTreeListCompareRuleComponent, "dxi-tree-list-compare-rule", never, { "comparisonTarget": { "alias": "comparisonTarget"; "required": false; }; "comparisonType": { "alias": "comparisonType"; "required": false; }; "ignoreEmptyValue": { "alias": "ignoreEmptyValue"; "required": false; }; "message": { "alias": "message"; "required": false; }; "type": { "alias": "type"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxiTreeListCompareRuleModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiTreeListCompareRuleModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiTreeListCompareRuleModule, never, [typeof DxiTreeListCompareRuleComponent], [typeof DxiTreeListCompareRuleComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiTreeListCompareRuleModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoTreeListCursorOffsetComponent extends NestedOption implements OnDestroy, OnInit {
    get x(): number;
    set x(value: number);
    get y(): number;
    set y(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTreeListCursorOffsetComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoTreeListCursorOffsetComponent, "dxo-tree-list-cursor-offset", never, { "x": { "alias": "x"; "required": false; }; "y": { "alias": "y"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoTreeListCursorOffsetModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTreeListCursorOffsetModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoTreeListCursorOffsetModule, never, [typeof DxoTreeListCursorOffsetComponent], [typeof DxoTreeListCursorOffsetComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoTreeListCursorOffsetModule>;
}

declare class DxiTreeListCustomOperationComponent extends CollectionNestedOption {
    get calculateFilterExpression(): ((filterValue: any, field: dxFilterBuilderField) => string | Function | Array<any>);
    set calculateFilterExpression(value: ((filterValue: any, field: dxFilterBuilderField) => string | Function | Array<any>));
    get caption(): string | undefined;
    set caption(value: string | undefined);
    get customizeText(): ((fieldInfo: FieldInfo) => string);
    set customizeText(value: ((fieldInfo: FieldInfo) => string));
    get dataTypes(): Array<DataType> | undefined;
    set dataTypes(value: Array<DataType> | undefined);
    get editorTemplate(): any;
    set editorTemplate(value: any);
    get hasValue(): boolean;
    set hasValue(value: boolean);
    get icon(): string | undefined;
    set icon(value: string | undefined);
    get name(): string | undefined;
    set name(value: string | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiTreeListCustomOperationComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiTreeListCustomOperationComponent, "dxi-tree-list-custom-operation", never, { "calculateFilterExpression": { "alias": "calculateFilterExpression"; "required": false; }; "caption": { "alias": "caption"; "required": false; }; "customizeText": { "alias": "customizeText"; "required": false; }; "dataTypes": { "alias": "dataTypes"; "required": false; }; "editorTemplate": { "alias": "editorTemplate"; "required": false; }; "hasValue": { "alias": "hasValue"; "required": false; }; "icon": { "alias": "icon"; "required": false; }; "name": { "alias": "name"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxiTreeListCustomOperationModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiTreeListCustomOperationModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiTreeListCustomOperationModule, never, [typeof DxiTreeListCustomOperationComponent], [typeof DxiTreeListCustomOperationComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiTreeListCustomOperationModule>;
}

declare class DxiTreeListCustomRuleComponent extends CollectionNestedOption {
    get ignoreEmptyValue(): boolean;
    set ignoreEmptyValue(value: boolean);
    get message(): string;
    set message(value: string);
    get reevaluate(): boolean;
    set reevaluate(value: boolean);
    get type(): ValidationRuleType;
    set type(value: ValidationRuleType);
    get validationCallback(): ((options: {
        column: Record<string, any>;
        data: Record<string, any>;
        formItem: Record<string, any>;
        rule: Record<string, any>;
        validator: Record<string, any>;
        value: any;
    }) => boolean);
    set validationCallback(value: ((options: {
        column: Record<string, any>;
        data: Record<string, any>;
        formItem: Record<string, any>;
        rule: Record<string, any>;
        validator: Record<string, any>;
        value: any;
    }) => boolean));
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiTreeListCustomRuleComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiTreeListCustomRuleComponent, "dxi-tree-list-custom-rule", never, { "ignoreEmptyValue": { "alias": "ignoreEmptyValue"; "required": false; }; "message": { "alias": "message"; "required": false; }; "reevaluate": { "alias": "reevaluate"; "required": false; }; "type": { "alias": "type"; "required": false; }; "validationCallback": { "alias": "validationCallback"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxiTreeListCustomRuleModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiTreeListCustomRuleModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiTreeListCustomRuleModule, never, [typeof DxiTreeListCustomRuleComponent], [typeof DxiTreeListCustomRuleComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiTreeListCustomRuleModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoTreeListEditingTextsComponent extends NestedOption implements OnDestroy, OnInit {
    get addRow(): string;
    set addRow(value: string);
    get addRowToNode(): string;
    set addRowToNode(value: string);
    get cancelAllChanges(): string;
    set cancelAllChanges(value: string);
    get cancelRowChanges(): string;
    set cancelRowChanges(value: string);
    get confirmDeleteMessage(): string;
    set confirmDeleteMessage(value: string);
    get confirmDeleteTitle(): string;
    set confirmDeleteTitle(value: string);
    get deleteRow(): string;
    set deleteRow(value: string);
    get editRow(): string;
    set editRow(value: string);
    get saveAllChanges(): string;
    set saveAllChanges(value: string);
    get saveRowChanges(): string;
    set saveRowChanges(value: string);
    get undeleteRow(): string;
    set undeleteRow(value: string);
    get validationCancelChanges(): string;
    set validationCancelChanges(value: string);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTreeListEditingTextsComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoTreeListEditingTextsComponent, "dxo-tree-list-editing-texts", never, { "addRow": { "alias": "addRow"; "required": false; }; "addRowToNode": { "alias": "addRowToNode"; "required": false; }; "cancelAllChanges": { "alias": "cancelAllChanges"; "required": false; }; "cancelRowChanges": { "alias": "cancelRowChanges"; "required": false; }; "confirmDeleteMessage": { "alias": "confirmDeleteMessage"; "required": false; }; "confirmDeleteTitle": { "alias": "confirmDeleteTitle"; "required": false; }; "deleteRow": { "alias": "deleteRow"; "required": false; }; "editRow": { "alias": "editRow"; "required": false; }; "saveAllChanges": { "alias": "saveAllChanges"; "required": false; }; "saveRowChanges": { "alias": "saveRowChanges"; "required": false; }; "undeleteRow": { "alias": "undeleteRow"; "required": false; }; "validationCancelChanges": { "alias": "validationCancelChanges"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoTreeListEditingTextsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTreeListEditingTextsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoTreeListEditingTextsModule, never, [typeof DxoTreeListEditingTextsComponent], [typeof DxoTreeListEditingTextsComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoTreeListEditingTextsModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoTreeListEditingComponent extends NestedOption implements OnDestroy, OnInit {
    set _changesContentChildren(value: QueryList<CollectionNestedOption>);
    get allowAdding(): boolean | ((options: {
        component: dxTreeList;
        row: dxTreeListRowObject;
    }) => boolean);
    set allowAdding(value: boolean | ((options: {
        component: dxTreeList;
        row: dxTreeListRowObject;
    }) => boolean));
    get allowDeleting(): boolean | ((options: {
        component: dxTreeList;
        row: dxTreeListRowObject;
    }) => boolean);
    set allowDeleting(value: boolean | ((options: {
        component: dxTreeList;
        row: dxTreeListRowObject;
    }) => boolean));
    get allowUpdating(): boolean | ((options: {
        component: dxTreeList;
        row: dxTreeListRowObject;
    }) => boolean);
    set allowUpdating(value: boolean | ((options: {
        component: dxTreeList;
        row: dxTreeListRowObject;
    }) => boolean));
    get changes(): Array<DataChange>;
    set changes(value: Array<DataChange>);
    get confirmDelete(): boolean;
    set confirmDelete(value: boolean);
    get editColumnName(): string | undefined;
    set editColumnName(value: string | undefined);
    get editRowKey(): any | undefined;
    set editRowKey(value: any | undefined);
    get form(): dxFormOptions;
    set form(value: dxFormOptions);
    get mode(): GridsEditMode;
    set mode(value: GridsEditMode);
    get popup(): dxPopupOptions<any>;
    set popup(value: dxPopupOptions<any>);
    get refreshMode(): GridsEditRefreshMode;
    set refreshMode(value: GridsEditRefreshMode);
    get selectTextOnEditStart(): boolean;
    set selectTextOnEditStart(value: boolean);
    get startEditAction(): StartEditAction;
    set startEditAction(value: StartEditAction);
    get texts(): {
        addRow?: string;
        addRowToNode?: string;
        cancelAllChanges?: string;
        cancelRowChanges?: string;
        confirmDeleteMessage?: string;
        confirmDeleteTitle?: string;
        deleteRow?: string;
        editRow?: string;
        saveAllChanges?: string;
        saveRowChanges?: string;
        undeleteRow?: string;
        validationCancelChanges?: string;
    };
    set texts(value: {
        addRow?: string;
        addRowToNode?: string;
        cancelAllChanges?: string;
        cancelRowChanges?: string;
        confirmDeleteMessage?: string;
        confirmDeleteTitle?: string;
        deleteRow?: string;
        editRow?: string;
        saveAllChanges?: string;
        saveRowChanges?: string;
        undeleteRow?: string;
        validationCancelChanges?: string;
    });
    get useIcons(): boolean;
    set useIcons(value: boolean);
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    changesChange: EventEmitter<Array<DataChange>>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    editColumnNameChange: EventEmitter<string | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    editRowKeyChange: EventEmitter<any | undefined>;
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTreeListEditingComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoTreeListEditingComponent, "dxo-tree-list-editing", never, { "allowAdding": { "alias": "allowAdding"; "required": false; }; "allowDeleting": { "alias": "allowDeleting"; "required": false; }; "allowUpdating": { "alias": "allowUpdating"; "required": false; }; "changes": { "alias": "changes"; "required": false; }; "confirmDelete": { "alias": "confirmDelete"; "required": false; }; "editColumnName": { "alias": "editColumnName"; "required": false; }; "editRowKey": { "alias": "editRowKey"; "required": false; }; "form": { "alias": "form"; "required": false; }; "mode": { "alias": "mode"; "required": false; }; "popup": { "alias": "popup"; "required": false; }; "refreshMode": { "alias": "refreshMode"; "required": false; }; "selectTextOnEditStart": { "alias": "selectTextOnEditStart"; "required": false; }; "startEditAction": { "alias": "startEditAction"; "required": false; }; "texts": { "alias": "texts"; "required": false; }; "useIcons": { "alias": "useIcons"; "required": false; }; }, { "changesChange": "changesChange"; "editColumnNameChange": "editColumnNameChange"; "editRowKeyChange": "editRowKeyChange"; }, ["_changesContentChildren"], never, true, never>;
}
declare class DxoTreeListEditingModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTreeListEditingModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoTreeListEditingModule, never, [typeof DxoTreeListEditingComponent], [typeof DxoTreeListEditingComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoTreeListEditingModule>;
}

declare class DxiTreeListEditorOptionsButtonComponent extends CollectionNestedOption {
    get location(): TextEditorButtonLocation;
    set location(value: TextEditorButtonLocation);
    get name(): string | undefined;
    set name(value: string | undefined);
    get options(): dxButtonOptions | undefined;
    set options(value: dxButtonOptions | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiTreeListEditorOptionsButtonComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiTreeListEditorOptionsButtonComponent, "dxi-tree-list-editor-options-button", never, { "location": { "alias": "location"; "required": false; }; "name": { "alias": "name"; "required": false; }; "options": { "alias": "options"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxiTreeListEditorOptionsButtonModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiTreeListEditorOptionsButtonModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiTreeListEditorOptionsButtonModule, never, [typeof DxiTreeListEditorOptionsButtonComponent], [typeof DxiTreeListEditorOptionsButtonComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiTreeListEditorOptionsButtonModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoTreeListEditorOptionsComponent extends NestedOption implements OnDestroy, OnInit {
    set _buttonsContentChildren(value: QueryList<CollectionNestedOption>);
    get accessKey(): string | undefined;
    set accessKey(value: string | undefined);
    get activeStateEnabled(): boolean;
    set activeStateEnabled(value: boolean);
    get buttons(): Array<string | TextBoxPredefinedButton | TextEditorButton> | undefined;
    set buttons(value: Array<string | TextBoxPredefinedButton | TextEditorButton> | undefined);
    get disabled(): boolean;
    set disabled(value: boolean);
    get elementAttr(): Record<string, any>;
    set elementAttr(value: Record<string, any>);
    get focusStateEnabled(): boolean;
    set focusStateEnabled(value: boolean);
    get height(): number | string | undefined;
    set height(value: number | string | undefined);
    get hint(): string | undefined;
    set hint(value: string | undefined);
    get hoverStateEnabled(): boolean;
    set hoverStateEnabled(value: boolean);
    get inputAttr(): any;
    set inputAttr(value: any);
    get isDirty(): boolean;
    set isDirty(value: boolean);
    get isValid(): boolean;
    set isValid(value: boolean);
    get label(): string;
    set label(value: string);
    get labelMode(): LabelMode;
    set labelMode(value: LabelMode);
    get mask(): string;
    set mask(value: string);
    get maskChar(): string;
    set maskChar(value: string);
    get maskInvalidMessage(): string;
    set maskInvalidMessage(value: string);
    get maskRules(): any;
    set maskRules(value: any);
    get maxLength(): null | number | string;
    set maxLength(value: null | number | string);
    get mode(): TextBoxType;
    set mode(value: TextBoxType);
    get name(): string;
    set name(value: string);
    get onChange(): ((e: ChangeEvent) => void);
    set onChange(value: ((e: ChangeEvent) => void));
    get onContentReady(): ((e: ContentReadyEvent$1) => void);
    set onContentReady(value: ((e: ContentReadyEvent$1) => void));
    get onCopy(): ((e: CopyEvent) => void);
    set onCopy(value: ((e: CopyEvent) => void));
    get onCut(): ((e: CutEvent) => void);
    set onCut(value: ((e: CutEvent) => void));
    get onDisposing(): ((e: DisposingEvent$1) => void);
    set onDisposing(value: ((e: DisposingEvent$1) => void));
    get onEnterKey(): ((e: EnterKeyEvent) => void);
    set onEnterKey(value: ((e: EnterKeyEvent) => void));
    get onFocusIn(): ((e: FocusInEvent) => void);
    set onFocusIn(value: ((e: FocusInEvent) => void));
    get onFocusOut(): ((e: FocusOutEvent) => void);
    set onFocusOut(value: ((e: FocusOutEvent) => void));
    get onInitialized(): ((e: InitializedEvent$1) => void);
    set onInitialized(value: ((e: InitializedEvent$1) => void));
    get onInput(): ((e: InputEvent) => void);
    set onInput(value: ((e: InputEvent) => void));
    get onKeyDown(): ((e: KeyDownEvent) => void);
    set onKeyDown(value: ((e: KeyDownEvent) => void));
    get onKeyUp(): ((e: KeyUpEvent) => void);
    set onKeyUp(value: ((e: KeyUpEvent) => void));
    get onOptionChanged(): ((e: OptionChangedEvent$1) => void);
    set onOptionChanged(value: ((e: OptionChangedEvent$1) => void));
    get onPaste(): ((e: PasteEvent) => void);
    set onPaste(value: ((e: PasteEvent) => void));
    get onValueChanged(): ((e: ValueChangedEvent) => void);
    set onValueChanged(value: ((e: ValueChangedEvent) => void));
    get placeholder(): string;
    set placeholder(value: string);
    get readOnly(): boolean;
    set readOnly(value: boolean);
    get rtlEnabled(): boolean;
    set rtlEnabled(value: boolean);
    get showClearButton(): boolean;
    set showClearButton(value: boolean);
    get showMaskMode(): MaskMode;
    set showMaskMode(value: MaskMode);
    get spellcheck(): boolean;
    set spellcheck(value: boolean);
    get stylingMode(): EditorStyle;
    set stylingMode(value: EditorStyle);
    get tabIndex(): number;
    set tabIndex(value: number);
    get text(): string;
    set text(value: string);
    get useMaskedValue(): boolean;
    set useMaskedValue(value: boolean);
    get validationError(): any | null;
    set validationError(value: any | null);
    get validationErrors(): Array<any> | null;
    set validationErrors(value: Array<any> | null);
    get validationMessageMode(): ValidationMessageMode;
    set validationMessageMode(value: ValidationMessageMode);
    get validationMessagePosition(): Position;
    set validationMessagePosition(value: Position);
    get validationStatus(): ValidationStatus;
    set validationStatus(value: ValidationStatus);
    get value(): string;
    set value(value: string);
    get valueChangeEvent(): string;
    set valueChangeEvent(value: string);
    get visible(): boolean;
    set visible(value: boolean);
    get width(): number | string | undefined;
    set width(value: number | string | undefined);
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    valueChange: EventEmitter<string>;
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTreeListEditorOptionsComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoTreeListEditorOptionsComponent, "dxo-tree-list-editor-options", never, { "accessKey": { "alias": "accessKey"; "required": false; }; "activeStateEnabled": { "alias": "activeStateEnabled"; "required": false; }; "buttons": { "alias": "buttons"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "elementAttr": { "alias": "elementAttr"; "required": false; }; "focusStateEnabled": { "alias": "focusStateEnabled"; "required": false; }; "height": { "alias": "height"; "required": false; }; "hint": { "alias": "hint"; "required": false; }; "hoverStateEnabled": { "alias": "hoverStateEnabled"; "required": false; }; "inputAttr": { "alias": "inputAttr"; "required": false; }; "isDirty": { "alias": "isDirty"; "required": false; }; "isValid": { "alias": "isValid"; "required": false; }; "label": { "alias": "label"; "required": false; }; "labelMode": { "alias": "labelMode"; "required": false; }; "mask": { "alias": "mask"; "required": false; }; "maskChar": { "alias": "maskChar"; "required": false; }; "maskInvalidMessage": { "alias": "maskInvalidMessage"; "required": false; }; "maskRules": { "alias": "maskRules"; "required": false; }; "maxLength": { "alias": "maxLength"; "required": false; }; "mode": { "alias": "mode"; "required": false; }; "name": { "alias": "name"; "required": false; }; "onChange": { "alias": "onChange"; "required": false; }; "onContentReady": { "alias": "onContentReady"; "required": false; }; "onCopy": { "alias": "onCopy"; "required": false; }; "onCut": { "alias": "onCut"; "required": false; }; "onDisposing": { "alias": "onDisposing"; "required": false; }; "onEnterKey": { "alias": "onEnterKey"; "required": false; }; "onFocusIn": { "alias": "onFocusIn"; "required": false; }; "onFocusOut": { "alias": "onFocusOut"; "required": false; }; "onInitialized": { "alias": "onInitialized"; "required": false; }; "onInput": { "alias": "onInput"; "required": false; }; "onKeyDown": { "alias": "onKeyDown"; "required": false; }; "onKeyUp": { "alias": "onKeyUp"; "required": false; }; "onOptionChanged": { "alias": "onOptionChanged"; "required": false; }; "onPaste": { "alias": "onPaste"; "required": false; }; "onValueChanged": { "alias": "onValueChanged"; "required": false; }; "placeholder": { "alias": "placeholder"; "required": false; }; "readOnly": { "alias": "readOnly"; "required": false; }; "rtlEnabled": { "alias": "rtlEnabled"; "required": false; }; "showClearButton": { "alias": "showClearButton"; "required": false; }; "showMaskMode": { "alias": "showMaskMode"; "required": false; }; "spellcheck": { "alias": "spellcheck"; "required": false; }; "stylingMode": { "alias": "stylingMode"; "required": false; }; "tabIndex": { "alias": "tabIndex"; "required": false; }; "text": { "alias": "text"; "required": false; }; "useMaskedValue": { "alias": "useMaskedValue"; "required": false; }; "validationError": { "alias": "validationError"; "required": false; }; "validationErrors": { "alias": "validationErrors"; "required": false; }; "validationMessageMode": { "alias": "validationMessageMode"; "required": false; }; "validationMessagePosition": { "alias": "validationMessagePosition"; "required": false; }; "validationStatus": { "alias": "validationStatus"; "required": false; }; "value": { "alias": "value"; "required": false; }; "valueChangeEvent": { "alias": "valueChangeEvent"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, { "valueChange": "valueChange"; }, ["_buttonsContentChildren"], never, true, never>;
}
declare class DxoTreeListEditorOptionsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTreeListEditorOptionsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoTreeListEditorOptionsModule, never, [typeof DxoTreeListEditorOptionsComponent], [typeof DxoTreeListEditorOptionsComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoTreeListEditorOptionsModule>;
}

declare class DxiTreeListEmailRuleComponent extends CollectionNestedOption {
    get ignoreEmptyValue(): boolean;
    set ignoreEmptyValue(value: boolean);
    get message(): string;
    set message(value: string);
    get type(): ValidationRuleType;
    set type(value: ValidationRuleType);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiTreeListEmailRuleComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiTreeListEmailRuleComponent, "dxi-tree-list-email-rule", never, { "ignoreEmptyValue": { "alias": "ignoreEmptyValue"; "required": false; }; "message": { "alias": "message"; "required": false; }; "type": { "alias": "type"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxiTreeListEmailRuleModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiTreeListEmailRuleModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiTreeListEmailRuleModule, never, [typeof DxiTreeListEmailRuleComponent], [typeof DxiTreeListEmailRuleComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiTreeListEmailRuleModule>;
}

declare class DxiTreeListEmptyItemComponent extends CollectionNestedOption {
    get colSpan(): number | undefined;
    set colSpan(value: number | undefined);
    get cssClass(): string | undefined;
    set cssClass(value: string | undefined);
    get itemType(): FormItemType;
    set itemType(value: FormItemType);
    get name(): string | undefined;
    set name(value: string | undefined);
    get visible(): boolean;
    set visible(value: boolean);
    get visibleIndex(): number | undefined;
    set visibleIndex(value: number | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiTreeListEmptyItemComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiTreeListEmptyItemComponent, "dxi-tree-list-empty-item", never, { "colSpan": { "alias": "colSpan"; "required": false; }; "cssClass": { "alias": "cssClass"; "required": false; }; "itemType": { "alias": "itemType"; "required": false; }; "name": { "alias": "name"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "visibleIndex": { "alias": "visibleIndex"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxiTreeListEmptyItemModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiTreeListEmptyItemModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiTreeListEmptyItemModule, never, [typeof DxiTreeListEmptyItemComponent], [typeof DxiTreeListEmptyItemComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiTreeListEmptyItemModule>;
}

declare class DxiTreeListFieldComponent extends CollectionNestedOption {
    get calculateFilterExpression(): ((filterValue: any, selectedFilterOperation: string) => string | Function | Array<any>);
    set calculateFilterExpression(value: ((filterValue: any, selectedFilterOperation: string) => string | Function | Array<any>));
    get caption(): string | undefined;
    set caption(value: string | undefined);
    get customizeText(): ((fieldInfo: FieldInfo) => string);
    set customizeText(value: ((fieldInfo: FieldInfo) => string));
    get dataField(): string | undefined;
    set dataField(value: string | undefined);
    get dataType(): DataType;
    set dataType(value: DataType);
    get editorOptions(): any;
    set editorOptions(value: any);
    get editorTemplate(): any;
    set editorTemplate(value: any);
    get falseText(): string;
    set falseText(value: string);
    get filterOperations(): Array<FilterBuilderOperation | string>;
    set filterOperations(value: Array<FilterBuilderOperation | string>);
    get format(): Format;
    set format(value: Format);
    get lookup(): {
        allowClearing?: boolean;
        dataSource?: Array<any> | DataSourceOptions | Store | undefined;
        displayExpr?: ((data: any) => string) | string | undefined;
        valueExpr?: ((data: any) => string | number | boolean) | string | undefined;
    };
    set lookup(value: {
        allowClearing?: boolean;
        dataSource?: Array<any> | DataSourceOptions | Store | undefined;
        displayExpr?: ((data: any) => string) | string | undefined;
        valueExpr?: ((data: any) => string | number | boolean) | string | undefined;
    });
    get name(): string | undefined;
    set name(value: string | undefined);
    get trueText(): string;
    set trueText(value: string);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiTreeListFieldComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiTreeListFieldComponent, "dxi-tree-list-field", never, { "calculateFilterExpression": { "alias": "calculateFilterExpression"; "required": false; }; "caption": { "alias": "caption"; "required": false; }; "customizeText": { "alias": "customizeText"; "required": false; }; "dataField": { "alias": "dataField"; "required": false; }; "dataType": { "alias": "dataType"; "required": false; }; "editorOptions": { "alias": "editorOptions"; "required": false; }; "editorTemplate": { "alias": "editorTemplate"; "required": false; }; "falseText": { "alias": "falseText"; "required": false; }; "filterOperations": { "alias": "filterOperations"; "required": false; }; "format": { "alias": "format"; "required": false; }; "lookup": { "alias": "lookup"; "required": false; }; "name": { "alias": "name"; "required": false; }; "trueText": { "alias": "trueText"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxiTreeListFieldModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiTreeListFieldModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiTreeListFieldModule, never, [typeof DxiTreeListFieldComponent], [typeof DxiTreeListFieldComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiTreeListFieldModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoTreeListFieldLookupComponent extends NestedOption implements OnDestroy, OnInit {
    get allowClearing(): boolean;
    set allowClearing(value: boolean);
    get dataSource(): Array<any> | DataSourceOptions | Store | undefined;
    set dataSource(value: Array<any> | DataSourceOptions | Store | undefined);
    get displayExpr(): ((data: any) => string) | string | undefined;
    set displayExpr(value: ((data: any) => string) | string | undefined);
    get valueExpr(): ((data: any) => string | number | boolean) | string | undefined;
    set valueExpr(value: ((data: any) => string | number | boolean) | string | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTreeListFieldLookupComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoTreeListFieldLookupComponent, "dxo-tree-list-field-lookup", never, { "allowClearing": { "alias": "allowClearing"; "required": false; }; "dataSource": { "alias": "dataSource"; "required": false; }; "displayExpr": { "alias": "displayExpr"; "required": false; }; "valueExpr": { "alias": "valueExpr"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoTreeListFieldLookupModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTreeListFieldLookupModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoTreeListFieldLookupModule, never, [typeof DxoTreeListFieldLookupComponent], [typeof DxoTreeListFieldLookupComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoTreeListFieldLookupModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoTreeListFilterBuilderPopupComponent extends NestedOption implements OnDestroy, OnInit {
    set _toolbarItemsContentChildren(value: QueryList<CollectionNestedOption>);
    get accessKey(): string | undefined;
    set accessKey(value: string | undefined);
    get animation(): {
        hide?: AnimationConfig;
        show?: AnimationConfig;
    };
    set animation(value: {
        hide?: AnimationConfig;
        show?: AnimationConfig;
    });
    get container(): any | string | undefined;
    set container(value: any | string | undefined);
    get contentTemplate(): any;
    set contentTemplate(value: any);
    get deferRendering(): boolean;
    set deferRendering(value: boolean);
    get disabled(): boolean;
    set disabled(value: boolean);
    get dragAndResizeArea(): any | string | undefined;
    set dragAndResizeArea(value: any | string | undefined);
    get dragEnabled(): boolean;
    set dragEnabled(value: boolean);
    get dragOutsideBoundary(): boolean;
    set dragOutsideBoundary(value: boolean);
    get enableBodyScroll(): boolean;
    set enableBodyScroll(value: boolean);
    get focusStateEnabled(): boolean;
    set focusStateEnabled(value: boolean);
    get fullScreen(): boolean;
    set fullScreen(value: boolean);
    get height(): number | string;
    set height(value: number | string);
    get hideOnOutsideClick(): boolean | ((event: event) => boolean);
    set hideOnOutsideClick(value: boolean | ((event: event) => boolean));
    get hideOnParentScroll(): boolean;
    set hideOnParentScroll(value: boolean);
    get hint(): string | undefined;
    set hint(value: string | undefined);
    get hoverStateEnabled(): boolean;
    set hoverStateEnabled(value: boolean);
    get maxHeight(): number | string;
    set maxHeight(value: number | string);
    get maxWidth(): number | string;
    set maxWidth(value: number | string);
    get minHeight(): number | string;
    set minHeight(value: number | string);
    get minWidth(): number | string;
    set minWidth(value: number | string);
    get onContentReady(): ((e: EventInfo<any>) => void) | undefined;
    set onContentReady(value: ((e: EventInfo<any>) => void) | undefined);
    get onDisposing(): ((e: EventInfo<any>) => void) | undefined;
    set onDisposing(value: ((e: EventInfo<any>) => void) | undefined);
    get onHidden(): ((e: EventInfo<any>) => void);
    set onHidden(value: ((e: EventInfo<any>) => void));
    get onHiding(): ((e: {
        cancel: boolean | any;
        component: dxOverlay<any>;
        element: any;
        model: any;
    }) => void);
    set onHiding(value: ((e: {
        cancel: boolean | any;
        component: dxOverlay<any>;
        element: any;
        model: any;
    }) => void));
    get onInitialized(): ((e: {
        component: Component<any>;
        element: any;
    }) => void) | undefined;
    set onInitialized(value: ((e: {
        component: Component<any>;
        element: any;
    }) => void) | undefined);
    get onOptionChanged(): ((e: {
        component: DOMComponent;
        element: any;
        fullName: string;
        model: any;
        name: string;
        previousValue: any;
        value: any;
    }) => void) | undefined;
    set onOptionChanged(value: ((e: {
        component: DOMComponent;
        element: any;
        fullName: string;
        model: any;
        name: string;
        previousValue: any;
        value: any;
    }) => void) | undefined);
    get onResize(): ((e: {
        component: dxPopup;
        element: any;
        event: event;
        height: number;
        model: any;
        width: number;
    }) => void) | undefined;
    set onResize(value: ((e: {
        component: dxPopup;
        element: any;
        event: event;
        height: number;
        model: any;
        width: number;
    }) => void) | undefined);
    get onResizeEnd(): ((e: {
        component: dxPopup;
        element: any;
        event: event;
        height: number;
        model: any;
        width: number;
    }) => void) | undefined;
    set onResizeEnd(value: ((e: {
        component: dxPopup;
        element: any;
        event: event;
        height: number;
        model: any;
        width: number;
    }) => void) | undefined);
    get onResizeStart(): ((e: {
        component: dxPopup;
        element: any;
        event: event;
        height: number;
        model: any;
        width: number;
    }) => void) | undefined;
    set onResizeStart(value: ((e: {
        component: dxPopup;
        element: any;
        event: event;
        height: number;
        model: any;
        width: number;
    }) => void) | undefined);
    get onShowing(): ((e: {
        cancel: boolean | any;
        component: dxOverlay<any>;
        element: any;
        model: any;
    }) => void);
    set onShowing(value: ((e: {
        cancel: boolean | any;
        component: dxOverlay<any>;
        element: any;
        model: any;
    }) => void));
    get onShown(): ((e: EventInfo<any>) => void);
    set onShown(value: ((e: EventInfo<any>) => void));
    get onTitleRendered(): ((e: {
        component: dxPopup;
        element: any;
        model: any;
        titleElement: any;
    }) => void) | undefined;
    set onTitleRendered(value: ((e: {
        component: dxPopup;
        element: any;
        model: any;
        titleElement: any;
    }) => void) | undefined);
    get position(): Function | PositionAlignment | PositionConfig;
    set position(value: Function | PositionAlignment | PositionConfig);
    get resizeEnabled(): boolean;
    set resizeEnabled(value: boolean);
    get restorePosition(): boolean;
    set restorePosition(value: boolean);
    get rtlEnabled(): boolean;
    set rtlEnabled(value: boolean);
    get shading(): boolean;
    set shading(value: boolean);
    get shadingColor(): string;
    set shadingColor(value: string);
    get showCloseButton(): boolean;
    set showCloseButton(value: boolean);
    get showTitle(): boolean;
    set showTitle(value: boolean);
    get tabFocusLoopEnabled(): boolean;
    set tabFocusLoopEnabled(value: boolean);
    get tabIndex(): number;
    set tabIndex(value: number);
    get title(): string;
    set title(value: string);
    get titleTemplate(): any;
    set titleTemplate(value: any);
    get toolbarItems(): Array<dxPopupToolbarItem>;
    set toolbarItems(value: Array<dxPopupToolbarItem>);
    get visible(): boolean;
    set visible(value: boolean);
    get width(): number | string;
    set width(value: number | string);
    get wrapperAttr(): any;
    set wrapperAttr(value: any);
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    heightChange: EventEmitter<number | string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    positionChange: EventEmitter<Function | PositionAlignment | PositionConfig>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    visibleChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    widthChange: EventEmitter<number | string>;
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTreeListFilterBuilderPopupComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoTreeListFilterBuilderPopupComponent, "dxo-tree-list-filter-builder-popup", never, { "accessKey": { "alias": "accessKey"; "required": false; }; "animation": { "alias": "animation"; "required": false; }; "container": { "alias": "container"; "required": false; }; "contentTemplate": { "alias": "contentTemplate"; "required": false; }; "deferRendering": { "alias": "deferRendering"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "dragAndResizeArea": { "alias": "dragAndResizeArea"; "required": false; }; "dragEnabled": { "alias": "dragEnabled"; "required": false; }; "dragOutsideBoundary": { "alias": "dragOutsideBoundary"; "required": false; }; "enableBodyScroll": { "alias": "enableBodyScroll"; "required": false; }; "focusStateEnabled": { "alias": "focusStateEnabled"; "required": false; }; "fullScreen": { "alias": "fullScreen"; "required": false; }; "height": { "alias": "height"; "required": false; }; "hideOnOutsideClick": { "alias": "hideOnOutsideClick"; "required": false; }; "hideOnParentScroll": { "alias": "hideOnParentScroll"; "required": false; }; "hint": { "alias": "hint"; "required": false; }; "hoverStateEnabled": { "alias": "hoverStateEnabled"; "required": false; }; "maxHeight": { "alias": "maxHeight"; "required": false; }; "maxWidth": { "alias": "maxWidth"; "required": false; }; "minHeight": { "alias": "minHeight"; "required": false; }; "minWidth": { "alias": "minWidth"; "required": false; }; "onContentReady": { "alias": "onContentReady"; "required": false; }; "onDisposing": { "alias": "onDisposing"; "required": false; }; "onHidden": { "alias": "onHidden"; "required": false; }; "onHiding": { "alias": "onHiding"; "required": false; }; "onInitialized": { "alias": "onInitialized"; "required": false; }; "onOptionChanged": { "alias": "onOptionChanged"; "required": false; }; "onResize": { "alias": "onResize"; "required": false; }; "onResizeEnd": { "alias": "onResizeEnd"; "required": false; }; "onResizeStart": { "alias": "onResizeStart"; "required": false; }; "onShowing": { "alias": "onShowing"; "required": false; }; "onShown": { "alias": "onShown"; "required": false; }; "onTitleRendered": { "alias": "onTitleRendered"; "required": false; }; "position": { "alias": "position"; "required": false; }; "resizeEnabled": { "alias": "resizeEnabled"; "required": false; }; "restorePosition": { "alias": "restorePosition"; "required": false; }; "rtlEnabled": { "alias": "rtlEnabled"; "required": false; }; "shading": { "alias": "shading"; "required": false; }; "shadingColor": { "alias": "shadingColor"; "required": false; }; "showCloseButton": { "alias": "showCloseButton"; "required": false; }; "showTitle": { "alias": "showTitle"; "required": false; }; "tabFocusLoopEnabled": { "alias": "tabFocusLoopEnabled"; "required": false; }; "tabIndex": { "alias": "tabIndex"; "required": false; }; "title": { "alias": "title"; "required": false; }; "titleTemplate": { "alias": "titleTemplate"; "required": false; }; "toolbarItems": { "alias": "toolbarItems"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; "wrapperAttr": { "alias": "wrapperAttr"; "required": false; }; }, { "heightChange": "heightChange"; "positionChange": "positionChange"; "visibleChange": "visibleChange"; "widthChange": "widthChange"; }, ["_toolbarItemsContentChildren"], never, true, never>;
}
declare class DxoTreeListFilterBuilderPopupModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTreeListFilterBuilderPopupModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoTreeListFilterBuilderPopupModule, never, [typeof DxoTreeListFilterBuilderPopupComponent], [typeof DxoTreeListFilterBuilderPopupComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoTreeListFilterBuilderPopupModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoTreeListFilterBuilderComponent extends NestedOption implements OnDestroy, OnInit {
    set _customOperationsContentChildren(value: QueryList<CollectionNestedOption>);
    set _fieldsContentChildren(value: QueryList<CollectionNestedOption>);
    get accessKey(): string | undefined;
    set accessKey(value: string | undefined);
    get activeStateEnabled(): boolean;
    set activeStateEnabled(value: boolean);
    get allowHierarchicalFields(): boolean;
    set allowHierarchicalFields(value: boolean);
    get customOperations(): Array<dxFilterBuilderCustomOperation>;
    set customOperations(value: Array<dxFilterBuilderCustomOperation>);
    get disabled(): boolean;
    set disabled(value: boolean);
    get elementAttr(): Record<string, any>;
    set elementAttr(value: Record<string, any>);
    get fields(): Array<dxFilterBuilderField>;
    set fields(value: Array<dxFilterBuilderField>);
    get filterOperationDescriptions(): {
        between?: string;
        contains?: string;
        endsWith?: string;
        equal?: string;
        greaterThan?: string;
        greaterThanOrEqual?: string;
        isBlank?: string;
        isNotBlank?: string;
        lessThan?: string;
        lessThanOrEqual?: string;
        notContains?: string;
        notEqual?: string;
        startsWith?: string;
    };
    set filterOperationDescriptions(value: {
        between?: string;
        contains?: string;
        endsWith?: string;
        equal?: string;
        greaterThan?: string;
        greaterThanOrEqual?: string;
        isBlank?: string;
        isNotBlank?: string;
        lessThan?: string;
        lessThanOrEqual?: string;
        notContains?: string;
        notEqual?: string;
        startsWith?: string;
    });
    get focusStateEnabled(): boolean;
    set focusStateEnabled(value: boolean);
    get groupOperationDescriptions(): {
        and?: string;
        notAnd?: string;
        notOr?: string;
        or?: string;
    };
    set groupOperationDescriptions(value: {
        and?: string;
        notAnd?: string;
        notOr?: string;
        or?: string;
    });
    get groupOperations(): Array<GroupOperation>;
    set groupOperations(value: Array<GroupOperation>);
    get height(): number | string | undefined;
    set height(value: number | string | undefined);
    get hint(): string | undefined;
    set hint(value: string | undefined);
    get hoverStateEnabled(): boolean;
    set hoverStateEnabled(value: boolean);
    get maxGroupLevel(): number | undefined;
    set maxGroupLevel(value: number | undefined);
    get onContentReady(): ((e: ContentReadyEvent$2) => void);
    set onContentReady(value: ((e: ContentReadyEvent$2) => void));
    get onDisposing(): ((e: DisposingEvent$2) => void);
    set onDisposing(value: ((e: DisposingEvent$2) => void));
    get onEditorPrepared(): ((e: EditorPreparedEvent) => void) | undefined;
    set onEditorPrepared(value: ((e: EditorPreparedEvent) => void) | undefined);
    get onEditorPreparing(): ((e: EditorPreparingEvent) => void) | undefined;
    set onEditorPreparing(value: ((e: EditorPreparingEvent) => void) | undefined);
    get onInitialized(): ((e: InitializedEvent$2) => void);
    set onInitialized(value: ((e: InitializedEvent$2) => void));
    get onOptionChanged(): ((e: OptionChangedEvent$2) => void);
    set onOptionChanged(value: ((e: OptionChangedEvent$2) => void));
    get onValueChanged(): ((e: ValueChangedEvent$1) => void) | undefined;
    set onValueChanged(value: ((e: ValueChangedEvent$1) => void) | undefined);
    get rtlEnabled(): boolean;
    set rtlEnabled(value: boolean);
    get tabIndex(): number;
    set tabIndex(value: number);
    get value(): Array<any> | Function | string;
    set value(value: Array<any> | Function | string);
    get visible(): boolean;
    set visible(value: boolean);
    get width(): number | string | undefined;
    set width(value: number | string | undefined);
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    valueChange: EventEmitter<Array<any> | Function | string>;
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTreeListFilterBuilderComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoTreeListFilterBuilderComponent, "dxo-tree-list-filter-builder", never, { "accessKey": { "alias": "accessKey"; "required": false; }; "activeStateEnabled": { "alias": "activeStateEnabled"; "required": false; }; "allowHierarchicalFields": { "alias": "allowHierarchicalFields"; "required": false; }; "customOperations": { "alias": "customOperations"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "elementAttr": { "alias": "elementAttr"; "required": false; }; "fields": { "alias": "fields"; "required": false; }; "filterOperationDescriptions": { "alias": "filterOperationDescriptions"; "required": false; }; "focusStateEnabled": { "alias": "focusStateEnabled"; "required": false; }; "groupOperationDescriptions": { "alias": "groupOperationDescriptions"; "required": false; }; "groupOperations": { "alias": "groupOperations"; "required": false; }; "height": { "alias": "height"; "required": false; }; "hint": { "alias": "hint"; "required": false; }; "hoverStateEnabled": { "alias": "hoverStateEnabled"; "required": false; }; "maxGroupLevel": { "alias": "maxGroupLevel"; "required": false; }; "onContentReady": { "alias": "onContentReady"; "required": false; }; "onDisposing": { "alias": "onDisposing"; "required": false; }; "onEditorPrepared": { "alias": "onEditorPrepared"; "required": false; }; "onEditorPreparing": { "alias": "onEditorPreparing"; "required": false; }; "onInitialized": { "alias": "onInitialized"; "required": false; }; "onOptionChanged": { "alias": "onOptionChanged"; "required": false; }; "onValueChanged": { "alias": "onValueChanged"; "required": false; }; "rtlEnabled": { "alias": "rtlEnabled"; "required": false; }; "tabIndex": { "alias": "tabIndex"; "required": false; }; "value": { "alias": "value"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, { "valueChange": "valueChange"; }, ["_customOperationsContentChildren", "_fieldsContentChildren"], never, true, never>;
}
declare class DxoTreeListFilterBuilderModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTreeListFilterBuilderModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoTreeListFilterBuilderModule, never, [typeof DxoTreeListFilterBuilderComponent], [typeof DxoTreeListFilterBuilderComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoTreeListFilterBuilderModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoTreeListFilterOperationDescriptionsComponent extends NestedOption implements OnDestroy, OnInit {
    get between(): string;
    set between(value: string);
    get contains(): string;
    set contains(value: string);
    get endsWith(): string;
    set endsWith(value: string);
    get equal(): string;
    set equal(value: string);
    get greaterThan(): string;
    set greaterThan(value: string);
    get greaterThanOrEqual(): string;
    set greaterThanOrEqual(value: string);
    get isBlank(): string;
    set isBlank(value: string);
    get isNotBlank(): string;
    set isNotBlank(value: string);
    get lessThan(): string;
    set lessThan(value: string);
    get lessThanOrEqual(): string;
    set lessThanOrEqual(value: string);
    get notContains(): string;
    set notContains(value: string);
    get notEqual(): string;
    set notEqual(value: string);
    get startsWith(): string;
    set startsWith(value: string);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTreeListFilterOperationDescriptionsComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoTreeListFilterOperationDescriptionsComponent, "dxo-tree-list-filter-operation-descriptions", never, { "between": { "alias": "between"; "required": false; }; "contains": { "alias": "contains"; "required": false; }; "endsWith": { "alias": "endsWith"; "required": false; }; "equal": { "alias": "equal"; "required": false; }; "greaterThan": { "alias": "greaterThan"; "required": false; }; "greaterThanOrEqual": { "alias": "greaterThanOrEqual"; "required": false; }; "isBlank": { "alias": "isBlank"; "required": false; }; "isNotBlank": { "alias": "isNotBlank"; "required": false; }; "lessThan": { "alias": "lessThan"; "required": false; }; "lessThanOrEqual": { "alias": "lessThanOrEqual"; "required": false; }; "notContains": { "alias": "notContains"; "required": false; }; "notEqual": { "alias": "notEqual"; "required": false; }; "startsWith": { "alias": "startsWith"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoTreeListFilterOperationDescriptionsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTreeListFilterOperationDescriptionsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoTreeListFilterOperationDescriptionsModule, never, [typeof DxoTreeListFilterOperationDescriptionsComponent], [typeof DxoTreeListFilterOperationDescriptionsComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoTreeListFilterOperationDescriptionsModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoTreeListFilterPanelTextsComponent extends NestedOption implements OnDestroy, OnInit {
    get clearFilter(): string;
    set clearFilter(value: string);
    get createFilter(): string;
    set createFilter(value: string);
    get filterEnabledHint(): string;
    set filterEnabledHint(value: string);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTreeListFilterPanelTextsComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoTreeListFilterPanelTextsComponent, "dxo-tree-list-filter-panel-texts", never, { "clearFilter": { "alias": "clearFilter"; "required": false; }; "createFilter": { "alias": "createFilter"; "required": false; }; "filterEnabledHint": { "alias": "filterEnabledHint"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoTreeListFilterPanelTextsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTreeListFilterPanelTextsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoTreeListFilterPanelTextsModule, never, [typeof DxoTreeListFilterPanelTextsComponent], [typeof DxoTreeListFilterPanelTextsComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoTreeListFilterPanelTextsModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoTreeListFilterPanelComponent extends NestedOption implements OnDestroy, OnInit {
    get customizeText(): ((e: {
        component: FilterPanel;
        filterValue: Record<string, any>;
        text: string;
    }) => string);
    set customizeText(value: ((e: {
        component: FilterPanel;
        filterValue: Record<string, any>;
        text: string;
    }) => string));
    get filterEnabled(): boolean;
    set filterEnabled(value: boolean);
    get texts(): FilterPanelTexts;
    set texts(value: FilterPanelTexts);
    get visible(): boolean;
    set visible(value: boolean);
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    filterEnabledChange: EventEmitter<boolean>;
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTreeListFilterPanelComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoTreeListFilterPanelComponent, "dxo-tree-list-filter-panel", never, { "customizeText": { "alias": "customizeText"; "required": false; }; "filterEnabled": { "alias": "filterEnabled"; "required": false; }; "texts": { "alias": "texts"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; }, { "filterEnabledChange": "filterEnabledChange"; }, never, never, true, never>;
}
declare class DxoTreeListFilterPanelModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTreeListFilterPanelModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoTreeListFilterPanelModule, never, [typeof DxoTreeListFilterPanelComponent], [typeof DxoTreeListFilterPanelComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoTreeListFilterPanelModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoTreeListFilterRowComponent extends NestedOption implements OnDestroy, OnInit {
    get applyFilter(): ApplyFilterMode;
    set applyFilter(value: ApplyFilterMode);
    get applyFilterText(): string;
    set applyFilterText(value: string);
    get betweenEndText(): string;
    set betweenEndText(value: string);
    get betweenStartText(): string;
    set betweenStartText(value: string);
    get operationDescriptions(): {
        between?: string;
        contains?: string;
        endsWith?: string;
        equal?: string;
        greaterThan?: string;
        greaterThanOrEqual?: string;
        lessThan?: string;
        lessThanOrEqual?: string;
        notContains?: string;
        notEqual?: string;
        startsWith?: string;
    };
    set operationDescriptions(value: {
        between?: string;
        contains?: string;
        endsWith?: string;
        equal?: string;
        greaterThan?: string;
        greaterThanOrEqual?: string;
        lessThan?: string;
        lessThanOrEqual?: string;
        notContains?: string;
        notEqual?: string;
        startsWith?: string;
    });
    get resetOperationText(): string;
    set resetOperationText(value: string);
    get showAllText(): string;
    set showAllText(value: string);
    get showOperationChooser(): boolean;
    set showOperationChooser(value: boolean);
    get visible(): boolean;
    set visible(value: boolean);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTreeListFilterRowComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoTreeListFilterRowComponent, "dxo-tree-list-filter-row", never, { "applyFilter": { "alias": "applyFilter"; "required": false; }; "applyFilterText": { "alias": "applyFilterText"; "required": false; }; "betweenEndText": { "alias": "betweenEndText"; "required": false; }; "betweenStartText": { "alias": "betweenStartText"; "required": false; }; "operationDescriptions": { "alias": "operationDescriptions"; "required": false; }; "resetOperationText": { "alias": "resetOperationText"; "required": false; }; "showAllText": { "alias": "showAllText"; "required": false; }; "showOperationChooser": { "alias": "showOperationChooser"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoTreeListFilterRowModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTreeListFilterRowModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoTreeListFilterRowModule, never, [typeof DxoTreeListFilterRowComponent], [typeof DxoTreeListFilterRowComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoTreeListFilterRowModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoTreeListFormItemComponent extends NestedOption implements AfterViewInit, OnDestroy, OnInit, IDxTemplateHost {
    private renderer;
    private document;
    private element;
    set _validationRulesContentChildren(value: QueryList<CollectionNestedOption>);
    get aiOptions(): {
        disabled?: boolean;
        instruction?: string | undefined;
    };
    set aiOptions(value: {
        disabled?: boolean;
        instruction?: string | undefined;
    });
    get colSpan(): number | undefined;
    set colSpan(value: number | undefined);
    get cssClass(): string | undefined;
    set cssClass(value: string | undefined);
    get dataField(): string | undefined;
    set dataField(value: string | undefined);
    get editorOptions(): any | undefined;
    set editorOptions(value: any | undefined);
    get editorType(): FormItemComponent;
    set editorType(value: FormItemComponent);
    get helpText(): string | undefined;
    set helpText(value: string | undefined);
    get isRequired(): boolean | undefined;
    set isRequired(value: boolean | undefined);
    get itemType(): FormItemType;
    set itemType(value: FormItemType);
    get label(): {
        alignment?: HorizontalAlignment;
        location?: LabelLocation;
        showColon?: boolean;
        template?: any;
        text?: string | undefined;
        visible?: boolean;
    };
    set label(value: {
        alignment?: HorizontalAlignment;
        location?: LabelLocation;
        showColon?: boolean;
        template?: any;
        text?: string | undefined;
        visible?: boolean;
    });
    get name(): string | undefined;
    set name(value: string | undefined);
    get template(): any;
    set template(value: any);
    get validationRules(): Array<CommonTypes.ValidationRule>;
    set validationRules(value: Array<CommonTypes.ValidationRule>);
    get visible(): boolean;
    set visible(value: boolean);
    get visibleIndex(): number | undefined;
    set visibleIndex(value: number | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost, renderer: Renderer2, document: any, templateHost: DxTemplateHost, element: ElementRef);
    setTemplate(template: DxTemplateDirective): void;
    ngAfterViewInit(): void;
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTreeListFormItemComponent, [{ host: true; skipSelf: true; }, { host: true; }, null, null, { host: true; }, null]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoTreeListFormItemComponent, "dxo-tree-list-form-item", never, { "aiOptions": { "alias": "aiOptions"; "required": false; }; "colSpan": { "alias": "colSpan"; "required": false; }; "cssClass": { "alias": "cssClass"; "required": false; }; "dataField": { "alias": "dataField"; "required": false; }; "editorOptions": { "alias": "editorOptions"; "required": false; }; "editorType": { "alias": "editorType"; "required": false; }; "helpText": { "alias": "helpText"; "required": false; }; "isRequired": { "alias": "isRequired"; "required": false; }; "itemType": { "alias": "itemType"; "required": false; }; "label": { "alias": "label"; "required": false; }; "name": { "alias": "name"; "required": false; }; "template": { "alias": "template"; "required": false; }; "validationRules": { "alias": "validationRules"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "visibleIndex": { "alias": "visibleIndex"; "required": false; }; }, {}, ["_validationRulesContentChildren"], ["*"], true, never>;
}
declare class DxoTreeListFormItemModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTreeListFormItemModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoTreeListFormItemModule, never, [typeof DxoTreeListFormItemComponent], [typeof DxoTreeListFormItemComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoTreeListFormItemModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoTreeListFormComponent extends NestedOption implements OnDestroy, OnInit {
    set _itemsContentChildren(value: QueryList<CollectionNestedOption>);
    get accessKey(): string | undefined;
    set accessKey(value: string | undefined);
    get activeStateEnabled(): boolean;
    set activeStateEnabled(value: boolean);
    get aiIntegration(): AIIntegration | undefined;
    set aiIntegration(value: AIIntegration | undefined);
    get alignItemLabels(): boolean;
    set alignItemLabels(value: boolean);
    get alignItemLabelsInAllGroups(): boolean;
    set alignItemLabelsInAllGroups(value: boolean);
    get colCount(): Mode | number;
    set colCount(value: Mode | number);
    get colCountByScreen(): {
        lg?: number | undefined;
        md?: number | undefined;
        sm?: number | undefined;
        xs?: number | undefined;
    };
    set colCountByScreen(value: {
        lg?: number | undefined;
        md?: number | undefined;
        sm?: number | undefined;
        xs?: number | undefined;
    });
    get customizeItem(): ((item: dxFormSimpleItem | dxFormGroupItem | dxFormTabbedItem | dxFormEmptyItem | dxFormButtonItem) => void);
    set customizeItem(value: ((item: dxFormSimpleItem | dxFormGroupItem | dxFormTabbedItem | dxFormEmptyItem | dxFormButtonItem) => void));
    get disabled(): boolean;
    set disabled(value: boolean);
    get elementAttr(): Record<string, any>;
    set elementAttr(value: Record<string, any>);
    get focusStateEnabled(): boolean;
    set focusStateEnabled(value: boolean);
    get formData(): any;
    set formData(value: any);
    get height(): number | string | undefined;
    set height(value: number | string | undefined);
    get hint(): string | undefined;
    set hint(value: string | undefined);
    get hoverStateEnabled(): boolean;
    set hoverStateEnabled(value: boolean);
    get isDirty(): boolean;
    set isDirty(value: boolean);
    get items(): Array<dxFormButtonItem | dxFormEmptyItem | dxFormGroupItem | dxFormSimpleItem | dxFormTabbedItem>;
    set items(value: Array<dxFormButtonItem | dxFormEmptyItem | dxFormGroupItem | dxFormSimpleItem | dxFormTabbedItem>);
    get labelLocation(): LabelLocation;
    set labelLocation(value: LabelLocation);
    get labelMode(): FormLabelMode;
    set labelMode(value: FormLabelMode);
    get minColWidth(): number;
    set minColWidth(value: number);
    get onContentReady(): ((e: ContentReadyEvent$3) => void);
    set onContentReady(value: ((e: ContentReadyEvent$3) => void));
    get onDisposing(): ((e: DisposingEvent$3) => void);
    set onDisposing(value: ((e: DisposingEvent$3) => void));
    get onEditorEnterKey(): ((e: EditorEnterKeyEvent) => void) | undefined;
    set onEditorEnterKey(value: ((e: EditorEnterKeyEvent) => void) | undefined);
    get onFieldDataChanged(): ((e: FieldDataChangedEvent) => void) | undefined;
    set onFieldDataChanged(value: ((e: FieldDataChangedEvent) => void) | undefined);
    get onInitialized(): ((e: InitializedEvent$3) => void);
    set onInitialized(value: ((e: InitializedEvent$3) => void));
    get onOptionChanged(): ((e: OptionChangedEvent$3) => void);
    set onOptionChanged(value: ((e: OptionChangedEvent$3) => void));
    get onSmartPasted(): ((e: SmartPastedEvent) => void) | undefined;
    set onSmartPasted(value: ((e: SmartPastedEvent) => void) | undefined);
    get onSmartPasting(): ((e: SmartPastingEvent) => void) | undefined;
    set onSmartPasting(value: ((e: SmartPastingEvent) => void) | undefined);
    get optionalMark(): string;
    set optionalMark(value: string);
    get readOnly(): boolean;
    set readOnly(value: boolean);
    get requiredMark(): string;
    set requiredMark(value: string);
    get requiredMessage(): string;
    set requiredMessage(value: string);
    get rtlEnabled(): boolean;
    set rtlEnabled(value: boolean);
    get screenByWidth(): Function;
    set screenByWidth(value: Function);
    get scrollingEnabled(): boolean;
    set scrollingEnabled(value: boolean);
    get showColonAfterLabel(): boolean;
    set showColonAfterLabel(value: boolean);
    get showOptionalMark(): boolean;
    set showOptionalMark(value: boolean);
    get showRequiredMark(): boolean;
    set showRequiredMark(value: boolean);
    get showValidationSummary(): boolean;
    set showValidationSummary(value: boolean);
    get tabIndex(): number;
    set tabIndex(value: number);
    get validationGroup(): string | undefined;
    set validationGroup(value: string | undefined);
    get visible(): boolean;
    set visible(value: boolean);
    get width(): number | string | undefined;
    set width(value: number | string | undefined);
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    formDataChange: EventEmitter<any>;
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTreeListFormComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoTreeListFormComponent, "dxo-tree-list-form", never, { "accessKey": { "alias": "accessKey"; "required": false; }; "activeStateEnabled": { "alias": "activeStateEnabled"; "required": false; }; "aiIntegration": { "alias": "aiIntegration"; "required": false; }; "alignItemLabels": { "alias": "alignItemLabels"; "required": false; }; "alignItemLabelsInAllGroups": { "alias": "alignItemLabelsInAllGroups"; "required": false; }; "colCount": { "alias": "colCount"; "required": false; }; "colCountByScreen": { "alias": "colCountByScreen"; "required": false; }; "customizeItem": { "alias": "customizeItem"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "elementAttr": { "alias": "elementAttr"; "required": false; }; "focusStateEnabled": { "alias": "focusStateEnabled"; "required": false; }; "formData": { "alias": "formData"; "required": false; }; "height": { "alias": "height"; "required": false; }; "hint": { "alias": "hint"; "required": false; }; "hoverStateEnabled": { "alias": "hoverStateEnabled"; "required": false; }; "isDirty": { "alias": "isDirty"; "required": false; }; "items": { "alias": "items"; "required": false; }; "labelLocation": { "alias": "labelLocation"; "required": false; }; "labelMode": { "alias": "labelMode"; "required": false; }; "minColWidth": { "alias": "minColWidth"; "required": false; }; "onContentReady": { "alias": "onContentReady"; "required": false; }; "onDisposing": { "alias": "onDisposing"; "required": false; }; "onEditorEnterKey": { "alias": "onEditorEnterKey"; "required": false; }; "onFieldDataChanged": { "alias": "onFieldDataChanged"; "required": false; }; "onInitialized": { "alias": "onInitialized"; "required": false; }; "onOptionChanged": { "alias": "onOptionChanged"; "required": false; }; "onSmartPasted": { "alias": "onSmartPasted"; "required": false; }; "onSmartPasting": { "alias": "onSmartPasting"; "required": false; }; "optionalMark": { "alias": "optionalMark"; "required": false; }; "readOnly": { "alias": "readOnly"; "required": false; }; "requiredMark": { "alias": "requiredMark"; "required": false; }; "requiredMessage": { "alias": "requiredMessage"; "required": false; }; "rtlEnabled": { "alias": "rtlEnabled"; "required": false; }; "screenByWidth": { "alias": "screenByWidth"; "required": false; }; "scrollingEnabled": { "alias": "scrollingEnabled"; "required": false; }; "showColonAfterLabel": { "alias": "showColonAfterLabel"; "required": false; }; "showOptionalMark": { "alias": "showOptionalMark"; "required": false; }; "showRequiredMark": { "alias": "showRequiredMark"; "required": false; }; "showValidationSummary": { "alias": "showValidationSummary"; "required": false; }; "tabIndex": { "alias": "tabIndex"; "required": false; }; "validationGroup": { "alias": "validationGroup"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, { "formDataChange": "formDataChange"; }, ["_itemsContentChildren"], never, true, never>;
}
declare class DxoTreeListFormModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTreeListFormModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoTreeListFormModule, never, [typeof DxoTreeListFormComponent], [typeof DxoTreeListFormComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoTreeListFormModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoTreeListFormatComponent extends NestedOption implements OnDestroy, OnInit {
    get currency(): string;
    set currency(value: string);
    get formatter(): ((value: number | Date) => string);
    set formatter(value: ((value: number | Date) => string));
    get parser(): ((value: string) => number | Date);
    set parser(value: ((value: string) => number | Date));
    get precision(): number;
    set precision(value: number);
    get type(): Format$1 | string;
    set type(value: Format$1 | string);
    get useCurrencyAccountingStyle(): boolean;
    set useCurrencyAccountingStyle(value: boolean);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTreeListFormatComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoTreeListFormatComponent, "dxo-tree-list-format", never, { "currency": { "alias": "currency"; "required": false; }; "formatter": { "alias": "formatter"; "required": false; }; "parser": { "alias": "parser"; "required": false; }; "precision": { "alias": "precision"; "required": false; }; "type": { "alias": "type"; "required": false; }; "useCurrencyAccountingStyle": { "alias": "useCurrencyAccountingStyle"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoTreeListFormatModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTreeListFormatModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoTreeListFormatModule, never, [typeof DxoTreeListFormatComponent], [typeof DxoTreeListFormatComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoTreeListFormatModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoTreeListFromComponent extends NestedOption implements OnDestroy, OnInit {
    get left(): number;
    set left(value: number);
    get opacity(): number;
    set opacity(value: number);
    get position(): PositionConfig;
    set position(value: PositionConfig);
    get scale(): number;
    set scale(value: number);
    get top(): number;
    set top(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTreeListFromComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoTreeListFromComponent, "dxo-tree-list-from", never, { "left": { "alias": "left"; "required": false; }; "opacity": { "alias": "opacity"; "required": false; }; "position": { "alias": "position"; "required": false; }; "scale": { "alias": "scale"; "required": false; }; "top": { "alias": "top"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoTreeListFromModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTreeListFromModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoTreeListFromModule, never, [typeof DxoTreeListFromComponent], [typeof DxoTreeListFromComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoTreeListFromModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxiTreeListGroupItemComponent extends CollectionNestedOption implements AfterViewInit, IDxTemplateHost {
    private renderer;
    private document;
    private element;
    set _itemsContentChildren(value: QueryList<CollectionNestedOption>);
    get alignItemLabels(): boolean;
    set alignItemLabels(value: boolean);
    get caption(): string | undefined;
    set caption(value: string | undefined);
    get captionTemplate(): any;
    set captionTemplate(value: any);
    get colCount(): number;
    set colCount(value: number);
    get colCountByScreen(): {
        lg?: number | undefined;
        md?: number | undefined;
        sm?: number | undefined;
        xs?: number | undefined;
    };
    set colCountByScreen(value: {
        lg?: number | undefined;
        md?: number | undefined;
        sm?: number | undefined;
        xs?: number | undefined;
    });
    get colSpan(): number | undefined;
    set colSpan(value: number | undefined);
    get cssClass(): string | undefined;
    set cssClass(value: string | undefined);
    get items(): Array<dxFormButtonItem | dxFormEmptyItem | dxFormGroupItem | dxFormSimpleItem | dxFormTabbedItem>;
    set items(value: Array<dxFormButtonItem | dxFormEmptyItem | dxFormGroupItem | dxFormSimpleItem | dxFormTabbedItem>);
    get itemType(): FormItemType;
    set itemType(value: FormItemType);
    get name(): string | undefined;
    set name(value: string | undefined);
    get template(): any;
    set template(value: any);
    get visible(): boolean;
    set visible(value: boolean);
    get visibleIndex(): number | undefined;
    set visibleIndex(value: number | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost, renderer: Renderer2, document: any, templateHost: DxTemplateHost, element: ElementRef);
    setTemplate(template: DxTemplateDirective): void;
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiTreeListGroupItemComponent, [{ host: true; skipSelf: true; }, { host: true; }, null, null, { host: true; }, null]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiTreeListGroupItemComponent, "dxi-tree-list-group-item", never, { "alignItemLabels": { "alias": "alignItemLabels"; "required": false; }; "caption": { "alias": "caption"; "required": false; }; "captionTemplate": { "alias": "captionTemplate"; "required": false; }; "colCount": { "alias": "colCount"; "required": false; }; "colCountByScreen": { "alias": "colCountByScreen"; "required": false; }; "colSpan": { "alias": "colSpan"; "required": false; }; "cssClass": { "alias": "cssClass"; "required": false; }; "items": { "alias": "items"; "required": false; }; "itemType": { "alias": "itemType"; "required": false; }; "name": { "alias": "name"; "required": false; }; "template": { "alias": "template"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "visibleIndex": { "alias": "visibleIndex"; "required": false; }; }, {}, ["_itemsContentChildren"], ["*"], true, never>;
}
declare class DxiTreeListGroupItemModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiTreeListGroupItemModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiTreeListGroupItemModule, never, [typeof DxiTreeListGroupItemComponent], [typeof DxiTreeListGroupItemComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiTreeListGroupItemModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoTreeListGroupOperationDescriptionsComponent extends NestedOption implements OnDestroy, OnInit {
    get and(): string;
    set and(value: string);
    get notAnd(): string;
    set notAnd(value: string);
    get notOr(): string;
    set notOr(value: string);
    get or(): string;
    set or(value: string);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTreeListGroupOperationDescriptionsComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoTreeListGroupOperationDescriptionsComponent, "dxo-tree-list-group-operation-descriptions", never, { "and": { "alias": "and"; "required": false; }; "notAnd": { "alias": "notAnd"; "required": false; }; "notOr": { "alias": "notOr"; "required": false; }; "or": { "alias": "or"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoTreeListGroupOperationDescriptionsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTreeListGroupOperationDescriptionsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoTreeListGroupOperationDescriptionsModule, never, [typeof DxoTreeListGroupOperationDescriptionsComponent], [typeof DxoTreeListGroupOperationDescriptionsComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoTreeListGroupOperationDescriptionsModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoTreeListHeaderFilterComponent extends NestedOption implements OnDestroy, OnInit {
    get allowSearch(): boolean;
    set allowSearch(value: boolean);
    get allowSelectAll(): boolean;
    set allowSelectAll(value: boolean);
    get dataSource(): Array<any> | DataSourceOptions | ((options: {
        component: Record<string, any>;
        dataSource: DataSourceOptions | null;
    }) => void) | null | Store | undefined;
    set dataSource(value: Array<any> | DataSourceOptions | ((options: {
        component: Record<string, any>;
        dataSource: DataSourceOptions | null;
    }) => void) | null | Store | undefined);
    get groupInterval(): Array<number | string> | HeaderFilterGroupInterval | number | undefined;
    set groupInterval(value: Array<number | string> | HeaderFilterGroupInterval | number | undefined);
    get height(): number | string | undefined;
    set height(value: number | string | undefined);
    get search(): ColumnHeaderFilterSearchConfig | HeaderFilterSearchConfig;
    set search(value: ColumnHeaderFilterSearchConfig | HeaderFilterSearchConfig);
    get searchMode(): SearchMode;
    set searchMode(value: SearchMode);
    get width(): number | string | undefined;
    set width(value: number | string | undefined);
    get searchTimeout(): number;
    set searchTimeout(value: number);
    get texts(): HeaderFilterTexts;
    set texts(value: HeaderFilterTexts);
    get visible(): boolean;
    set visible(value: boolean);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTreeListHeaderFilterComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoTreeListHeaderFilterComponent, "dxo-tree-list-header-filter", never, { "allowSearch": { "alias": "allowSearch"; "required": false; }; "allowSelectAll": { "alias": "allowSelectAll"; "required": false; }; "dataSource": { "alias": "dataSource"; "required": false; }; "groupInterval": { "alias": "groupInterval"; "required": false; }; "height": { "alias": "height"; "required": false; }; "search": { "alias": "search"; "required": false; }; "searchMode": { "alias": "searchMode"; "required": false; }; "width": { "alias": "width"; "required": false; }; "searchTimeout": { "alias": "searchTimeout"; "required": false; }; "texts": { "alias": "texts"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoTreeListHeaderFilterModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTreeListHeaderFilterModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoTreeListHeaderFilterModule, never, [typeof DxoTreeListHeaderFilterComponent], [typeof DxoTreeListHeaderFilterComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoTreeListHeaderFilterModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoTreeListHideComponent extends NestedOption implements OnDestroy, OnInit {
    get complete(): (($element: any, config: AnimationConfig) => void);
    set complete(value: (($element: any, config: AnimationConfig) => void));
    get delay(): number;
    set delay(value: number);
    get direction(): Direction | undefined;
    set direction(value: Direction | undefined);
    get duration(): number;
    set duration(value: number);
    get easing(): string;
    set easing(value: string);
    get from(): AnimationState;
    set from(value: AnimationState);
    get staggerDelay(): number | undefined;
    set staggerDelay(value: number | undefined);
    get start(): (($element: any, config: AnimationConfig) => void);
    set start(value: (($element: any, config: AnimationConfig) => void));
    get to(): AnimationState;
    set to(value: AnimationState);
    get type(): AnimationType;
    set type(value: AnimationType);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTreeListHideComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoTreeListHideComponent, "dxo-tree-list-hide", never, { "complete": { "alias": "complete"; "required": false; }; "delay": { "alias": "delay"; "required": false; }; "direction": { "alias": "direction"; "required": false; }; "duration": { "alias": "duration"; "required": false; }; "easing": { "alias": "easing"; "required": false; }; "from": { "alias": "from"; "required": false; }; "staggerDelay": { "alias": "staggerDelay"; "required": false; }; "start": { "alias": "start"; "required": false; }; "to": { "alias": "to"; "required": false; }; "type": { "alias": "type"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoTreeListHideModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTreeListHideModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoTreeListHideModule, never, [typeof DxoTreeListHideComponent], [typeof DxoTreeListHideComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoTreeListHideModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoTreeListIconsComponent extends NestedOption implements OnDestroy, OnInit {
    get fix(): string;
    set fix(value: string);
    get leftPosition(): string;
    set leftPosition(value: string);
    get rightPosition(): string;
    set rightPosition(value: string);
    get stickyPosition(): string;
    set stickyPosition(value: string);
    get unfix(): string;
    set unfix(value: string);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTreeListIconsComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoTreeListIconsComponent, "dxo-tree-list-icons", never, { "fix": { "alias": "fix"; "required": false; }; "leftPosition": { "alias": "leftPosition"; "required": false; }; "rightPosition": { "alias": "rightPosition"; "required": false; }; "stickyPosition": { "alias": "stickyPosition"; "required": false; }; "unfix": { "alias": "unfix"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoTreeListIconsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTreeListIconsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoTreeListIconsModule, never, [typeof DxoTreeListIconsComponent], [typeof DxoTreeListIconsComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoTreeListIconsModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoTreeListIndicatorOptionsComponent extends NestedOption implements OnDestroy, OnInit {
    get animationType(): LoadingAnimationType;
    set animationType(value: LoadingAnimationType);
    get height(): number | string | undefined;
    set height(value: number | string | undefined);
    get src(): string;
    set src(value: string);
    get width(): number | string | undefined;
    set width(value: number | string | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTreeListIndicatorOptionsComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoTreeListIndicatorOptionsComponent, "dxo-tree-list-indicator-options", never, { "animationType": { "alias": "animationType"; "required": false; }; "height": { "alias": "height"; "required": false; }; "src": { "alias": "src"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoTreeListIndicatorOptionsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTreeListIndicatorOptionsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoTreeListIndicatorOptionsModule, never, [typeof DxoTreeListIndicatorOptionsComponent], [typeof DxoTreeListIndicatorOptionsComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoTreeListIndicatorOptionsModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxiTreeListItemComponent extends CollectionNestedOption implements AfterViewInit, IDxTemplateHost {
    private renderer;
    private document;
    private element;
    set _validationRulesContentChildren(value: QueryList<CollectionNestedOption>);
    set _tabsContentChildren(value: QueryList<CollectionNestedOption>);
    set _itemsContentChildren(value: QueryList<CollectionNestedOption>);
    get badge(): string;
    set badge(value: string);
    get disabled(): boolean;
    set disabled(value: boolean);
    get html(): string;
    set html(value: string);
    get icon(): string;
    set icon(value: string);
    get tabTemplate(): any;
    set tabTemplate(value: any);
    get template(): any;
    set template(value: any);
    get text(): string;
    set text(value: string);
    get title(): string;
    set title(value: string);
    get visible(): boolean;
    set visible(value: boolean);
    get aiOptions(): {
        disabled?: boolean;
        instruction?: string | undefined;
    };
    set aiOptions(value: {
        disabled?: boolean;
        instruction?: string | undefined;
    });
    get colSpan(): number | undefined;
    set colSpan(value: number | undefined);
    get cssClass(): string | undefined;
    set cssClass(value: string | undefined);
    get dataField(): string | undefined;
    set dataField(value: string | undefined);
    get editorOptions(): any | undefined;
    set editorOptions(value: any | undefined);
    get editorType(): FormItemComponent;
    set editorType(value: FormItemComponent);
    get helpText(): string | undefined;
    set helpText(value: string | undefined);
    get isRequired(): boolean | undefined;
    set isRequired(value: boolean | undefined);
    get itemType(): FormItemType;
    set itemType(value: FormItemType);
    get label(): {
        alignment?: HorizontalAlignment;
        location?: LabelLocation;
        showColon?: boolean;
        template?: any;
        text?: string | undefined;
        visible?: boolean;
    };
    set label(value: {
        alignment?: HorizontalAlignment;
        location?: LabelLocation;
        showColon?: boolean;
        template?: any;
        text?: string | undefined;
        visible?: boolean;
    });
    get name(): string | undefined | FormPredefinedButtonItem | TreeListPredefinedToolbarItem;
    set name(value: string | undefined | FormPredefinedButtonItem | TreeListPredefinedToolbarItem);
    get validationRules(): Array<CommonTypes.ValidationRule>;
    set validationRules(value: Array<CommonTypes.ValidationRule>);
    get visibleIndex(): number | undefined;
    set visibleIndex(value: number | undefined);
    get alignItemLabels(): boolean;
    set alignItemLabels(value: boolean);
    get caption(): string | undefined;
    set caption(value: string | undefined);
    get captionTemplate(): any;
    set captionTemplate(value: any);
    get colCount(): number;
    set colCount(value: number);
    get colCountByScreen(): {
        lg?: number | undefined;
        md?: number | undefined;
        sm?: number | undefined;
        xs?: number | undefined;
    };
    set colCountByScreen(value: {
        lg?: number | undefined;
        md?: number | undefined;
        sm?: number | undefined;
        xs?: number | undefined;
    });
    get items(): Array<dxFormButtonItem | dxFormEmptyItem | dxFormGroupItem | dxFormSimpleItem | dxFormTabbedItem>;
    set items(value: Array<dxFormButtonItem | dxFormEmptyItem | dxFormGroupItem | dxFormSimpleItem | dxFormTabbedItem>);
    get tabPanelOptions(): dxTabPanelOptions | undefined;
    set tabPanelOptions(value: dxTabPanelOptions | undefined);
    get tabs(): {
        alignItemLabels?: boolean;
        badge?: string | undefined;
        colCount?: number;
        colCountByScreen?: {
            lg?: number | undefined;
            md?: number | undefined;
            sm?: number | undefined;
            xs?: number | undefined;
        };
        disabled?: boolean;
        icon?: string | undefined;
        items?: Array<dxFormButtonItem | dxFormEmptyItem | dxFormGroupItem | dxFormSimpleItem | dxFormTabbedItem>;
        tabTemplate?: any;
        template?: any;
        title?: string | undefined;
    }[];
    set tabs(value: {
        alignItemLabels?: boolean;
        badge?: string | undefined;
        colCount?: number;
        colCountByScreen?: {
            lg?: number | undefined;
            md?: number | undefined;
            sm?: number | undefined;
            xs?: number | undefined;
        };
        disabled?: boolean;
        icon?: string | undefined;
        items?: Array<dxFormButtonItem | dxFormEmptyItem | dxFormGroupItem | dxFormSimpleItem | dxFormTabbedItem>;
        tabTemplate?: any;
        template?: any;
        title?: string | undefined;
    }[]);
    get buttonOptions(): dxButtonOptions | undefined;
    set buttonOptions(value: dxButtonOptions | undefined);
    get horizontalAlignment(): HorizontalAlignment;
    set horizontalAlignment(value: HorizontalAlignment);
    get verticalAlignment(): VerticalAlignment;
    set verticalAlignment(value: VerticalAlignment);
    get locateInMenu(): LocateInMenuMode;
    set locateInMenu(value: LocateInMenuMode);
    get location(): ToolbarItemLocation;
    set location(value: ToolbarItemLocation);
    get menuItemTemplate(): any;
    set menuItemTemplate(value: any);
    get options(): any;
    set options(value: any);
    get showText(): ShowTextMode;
    set showText(value: ShowTextMode);
    get widget(): ToolbarItemComponent;
    set widget(value: ToolbarItemComponent);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost, renderer: Renderer2, document: any, templateHost: DxTemplateHost, element: ElementRef);
    setTemplate(template: DxTemplateDirective): void;
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiTreeListItemComponent, [{ host: true; skipSelf: true; }, { host: true; }, null, null, { host: true; }, null]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiTreeListItemComponent, "dxi-tree-list-item", never, { "badge": { "alias": "badge"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "html": { "alias": "html"; "required": false; }; "icon": { "alias": "icon"; "required": false; }; "tabTemplate": { "alias": "tabTemplate"; "required": false; }; "template": { "alias": "template"; "required": false; }; "text": { "alias": "text"; "required": false; }; "title": { "alias": "title"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "aiOptions": { "alias": "aiOptions"; "required": false; }; "colSpan": { "alias": "colSpan"; "required": false; }; "cssClass": { "alias": "cssClass"; "required": false; }; "dataField": { "alias": "dataField"; "required": false; }; "editorOptions": { "alias": "editorOptions"; "required": false; }; "editorType": { "alias": "editorType"; "required": false; }; "helpText": { "alias": "helpText"; "required": false; }; "isRequired": { "alias": "isRequired"; "required": false; }; "itemType": { "alias": "itemType"; "required": false; }; "label": { "alias": "label"; "required": false; }; "name": { "alias": "name"; "required": false; }; "validationRules": { "alias": "validationRules"; "required": false; }; "visibleIndex": { "alias": "visibleIndex"; "required": false; }; "alignItemLabels": { "alias": "alignItemLabels"; "required": false; }; "caption": { "alias": "caption"; "required": false; }; "captionTemplate": { "alias": "captionTemplate"; "required": false; }; "colCount": { "alias": "colCount"; "required": false; }; "colCountByScreen": { "alias": "colCountByScreen"; "required": false; }; "items": { "alias": "items"; "required": false; }; "tabPanelOptions": { "alias": "tabPanelOptions"; "required": false; }; "tabs": { "alias": "tabs"; "required": false; }; "buttonOptions": { "alias": "buttonOptions"; "required": false; }; "horizontalAlignment": { "alias": "horizontalAlignment"; "required": false; }; "verticalAlignment": { "alias": "verticalAlignment"; "required": false; }; "locateInMenu": { "alias": "locateInMenu"; "required": false; }; "location": { "alias": "location"; "required": false; }; "menuItemTemplate": { "alias": "menuItemTemplate"; "required": false; }; "options": { "alias": "options"; "required": false; }; "showText": { "alias": "showText"; "required": false; }; "widget": { "alias": "widget"; "required": false; }; }, {}, ["_validationRulesContentChildren", "_tabsContentChildren", "_itemsContentChildren"], ["*"], true, never>;
}
declare class DxiTreeListItemModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiTreeListItemModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiTreeListItemModule, never, [typeof DxiTreeListItemComponent], [typeof DxiTreeListItemComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiTreeListItemModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoTreeListKeyboardNavigationComponent extends NestedOption implements OnDestroy, OnInit {
    get editOnKeyPress(): boolean;
    set editOnKeyPress(value: boolean);
    get enabled(): boolean;
    set enabled(value: boolean);
    get enterKeyAction(): EnterKeyAction;
    set enterKeyAction(value: EnterKeyAction);
    get enterKeyDirection(): EnterKeyDirection;
    set enterKeyDirection(value: EnterKeyDirection);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTreeListKeyboardNavigationComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoTreeListKeyboardNavigationComponent, "dxo-tree-list-keyboard-navigation", never, { "editOnKeyPress": { "alias": "editOnKeyPress"; "required": false; }; "enabled": { "alias": "enabled"; "required": false; }; "enterKeyAction": { "alias": "enterKeyAction"; "required": false; }; "enterKeyDirection": { "alias": "enterKeyDirection"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoTreeListKeyboardNavigationModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTreeListKeyboardNavigationModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoTreeListKeyboardNavigationModule, never, [typeof DxoTreeListKeyboardNavigationComponent], [typeof DxoTreeListKeyboardNavigationComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoTreeListKeyboardNavigationModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoTreeListLabelComponent extends NestedOption implements AfterViewInit, OnDestroy, OnInit, IDxTemplateHost {
    private renderer;
    private document;
    private element;
    get alignment(): HorizontalAlignment;
    set alignment(value: HorizontalAlignment);
    get location(): LabelLocation;
    set location(value: LabelLocation);
    get showColon(): boolean;
    set showColon(value: boolean);
    get template(): any;
    set template(value: any);
    get text(): string | undefined;
    set text(value: string | undefined);
    get visible(): boolean;
    set visible(value: boolean);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost, renderer: Renderer2, document: any, templateHost: DxTemplateHost, element: ElementRef);
    setTemplate(template: DxTemplateDirective): void;
    ngAfterViewInit(): void;
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTreeListLabelComponent, [{ host: true; skipSelf: true; }, { host: true; }, null, null, { host: true; }, null]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoTreeListLabelComponent, "dxo-tree-list-label", never, { "alignment": { "alias": "alignment"; "required": false; }; "location": { "alias": "location"; "required": false; }; "showColon": { "alias": "showColon"; "required": false; }; "template": { "alias": "template"; "required": false; }; "text": { "alias": "text"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; }, {}, never, ["*"], true, never>;
}
declare class DxoTreeListLabelModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTreeListLabelModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoTreeListLabelModule, never, [typeof DxoTreeListLabelComponent], [typeof DxoTreeListLabelComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoTreeListLabelModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoTreeListLoadPanelComponent extends NestedOption implements OnDestroy, OnInit {
    get enabled(): boolean | Mode;
    set enabled(value: boolean | Mode);
    get height(): number | string;
    set height(value: number | string);
    get indicatorOptions(): LoadPanelIndicatorProperties;
    set indicatorOptions(value: LoadPanelIndicatorProperties);
    get indicatorSrc(): string;
    set indicatorSrc(value: string);
    get shading(): boolean;
    set shading(value: boolean);
    get shadingColor(): string;
    set shadingColor(value: string);
    get showIndicator(): boolean;
    set showIndicator(value: boolean);
    get showPane(): boolean;
    set showPane(value: boolean);
    get text(): string;
    set text(value: string);
    get width(): number | string;
    set width(value: number | string);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTreeListLoadPanelComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoTreeListLoadPanelComponent, "dxo-tree-list-load-panel", never, { "enabled": { "alias": "enabled"; "required": false; }; "height": { "alias": "height"; "required": false; }; "indicatorOptions": { "alias": "indicatorOptions"; "required": false; }; "indicatorSrc": { "alias": "indicatorSrc"; "required": false; }; "shading": { "alias": "shading"; "required": false; }; "shadingColor": { "alias": "shadingColor"; "required": false; }; "showIndicator": { "alias": "showIndicator"; "required": false; }; "showPane": { "alias": "showPane"; "required": false; }; "text": { "alias": "text"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoTreeListLoadPanelModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTreeListLoadPanelModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoTreeListLoadPanelModule, never, [typeof DxoTreeListLoadPanelComponent], [typeof DxoTreeListLoadPanelComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoTreeListLoadPanelModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoTreeListLookupComponent extends NestedOption implements OnDestroy, OnInit {
    get allowClearing(): boolean;
    set allowClearing(value: boolean);
    get calculateCellValue(): ((rowData: any) => any);
    set calculateCellValue(value: ((rowData: any) => any));
    get dataSource(): Array<any> | DataSourceOptions | ((options: {
        data: Record<string, any>;
        key: any;
    }) => Array<any> | Store | DataSourceOptions) | null | Store | undefined;
    set dataSource(value: Array<any> | DataSourceOptions | ((options: {
        data: Record<string, any>;
        key: any;
    }) => Array<any> | Store | DataSourceOptions) | null | Store | undefined);
    get displayExpr(): ((data: any) => string) | string | undefined;
    set displayExpr(value: ((data: any) => string) | string | undefined);
    get valueExpr(): string | undefined | ((data: any) => string | number | boolean);
    set valueExpr(value: string | undefined | ((data: any) => string | number | boolean));
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTreeListLookupComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoTreeListLookupComponent, "dxo-tree-list-lookup", never, { "allowClearing": { "alias": "allowClearing"; "required": false; }; "calculateCellValue": { "alias": "calculateCellValue"; "required": false; }; "dataSource": { "alias": "dataSource"; "required": false; }; "displayExpr": { "alias": "displayExpr"; "required": false; }; "valueExpr": { "alias": "valueExpr"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoTreeListLookupModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTreeListLookupModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoTreeListLookupModule, never, [typeof DxoTreeListLookupComponent], [typeof DxoTreeListLookupComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoTreeListLookupModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoTreeListMyComponent extends NestedOption implements OnDestroy, OnInit {
    get x(): HorizontalAlignment;
    set x(value: HorizontalAlignment);
    get y(): VerticalAlignment;
    set y(value: VerticalAlignment);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTreeListMyComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoTreeListMyComponent, "dxo-tree-list-my", never, { "x": { "alias": "x"; "required": false; }; "y": { "alias": "y"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoTreeListMyModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTreeListMyModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoTreeListMyModule, never, [typeof DxoTreeListMyComponent], [typeof DxoTreeListMyComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoTreeListMyModule>;
}

declare class DxiTreeListNumericRuleComponent extends CollectionNestedOption {
    get ignoreEmptyValue(): boolean;
    set ignoreEmptyValue(value: boolean);
    get message(): string;
    set message(value: string);
    get type(): ValidationRuleType;
    set type(value: ValidationRuleType);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiTreeListNumericRuleComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiTreeListNumericRuleComponent, "dxi-tree-list-numeric-rule", never, { "ignoreEmptyValue": { "alias": "ignoreEmptyValue"; "required": false; }; "message": { "alias": "message"; "required": false; }; "type": { "alias": "type"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxiTreeListNumericRuleModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiTreeListNumericRuleModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiTreeListNumericRuleModule, never, [typeof DxiTreeListNumericRuleComponent], [typeof DxiTreeListNumericRuleComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiTreeListNumericRuleModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoTreeListOffsetComponent extends NestedOption implements OnDestroy, OnInit {
    get x(): number;
    set x(value: number);
    get y(): number;
    set y(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTreeListOffsetComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoTreeListOffsetComponent, "dxo-tree-list-offset", never, { "x": { "alias": "x"; "required": false; }; "y": { "alias": "y"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoTreeListOffsetModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTreeListOffsetModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoTreeListOffsetModule, never, [typeof DxoTreeListOffsetComponent], [typeof DxoTreeListOffsetComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoTreeListOffsetModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoTreeListOperationDescriptionsComponent extends NestedOption implements OnDestroy, OnInit {
    get between(): string;
    set between(value: string);
    get contains(): string;
    set contains(value: string);
    get endsWith(): string;
    set endsWith(value: string);
    get equal(): string;
    set equal(value: string);
    get greaterThan(): string;
    set greaterThan(value: string);
    get greaterThanOrEqual(): string;
    set greaterThanOrEqual(value: string);
    get lessThan(): string;
    set lessThan(value: string);
    get lessThanOrEqual(): string;
    set lessThanOrEqual(value: string);
    get notContains(): string;
    set notContains(value: string);
    get notEqual(): string;
    set notEqual(value: string);
    get startsWith(): string;
    set startsWith(value: string);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTreeListOperationDescriptionsComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoTreeListOperationDescriptionsComponent, "dxo-tree-list-operation-descriptions", never, { "between": { "alias": "between"; "required": false; }; "contains": { "alias": "contains"; "required": false; }; "endsWith": { "alias": "endsWith"; "required": false; }; "equal": { "alias": "equal"; "required": false; }; "greaterThan": { "alias": "greaterThan"; "required": false; }; "greaterThanOrEqual": { "alias": "greaterThanOrEqual"; "required": false; }; "lessThan": { "alias": "lessThan"; "required": false; }; "lessThanOrEqual": { "alias": "lessThanOrEqual"; "required": false; }; "notContains": { "alias": "notContains"; "required": false; }; "notEqual": { "alias": "notEqual"; "required": false; }; "startsWith": { "alias": "startsWith"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoTreeListOperationDescriptionsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTreeListOperationDescriptionsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoTreeListOperationDescriptionsModule, never, [typeof DxoTreeListOperationDescriptionsComponent], [typeof DxoTreeListOperationDescriptionsComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoTreeListOperationDescriptionsModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoTreeListOptionsComponent extends NestedOption implements AfterViewInit, OnDestroy, OnInit, IDxTemplateHost {
    private renderer;
    private document;
    private element;
    get accessKey(): string | undefined;
    set accessKey(value: string | undefined);
    get activeStateEnabled(): boolean;
    set activeStateEnabled(value: boolean);
    get disabled(): boolean;
    set disabled(value: boolean);
    get elementAttr(): Record<string, any>;
    set elementAttr(value: Record<string, any>);
    get focusStateEnabled(): boolean;
    set focusStateEnabled(value: boolean);
    get height(): number | string | undefined;
    set height(value: number | string | undefined);
    get hint(): string | undefined;
    set hint(value: string | undefined);
    get hoverStateEnabled(): boolean;
    set hoverStateEnabled(value: boolean);
    get icon(): string;
    set icon(value: string);
    get onClick(): ((e: ClickEvent) => void) | undefined;
    set onClick(value: ((e: ClickEvent) => void) | undefined);
    get onContentReady(): ((e: ContentReadyEvent) => void);
    set onContentReady(value: ((e: ContentReadyEvent) => void));
    get onDisposing(): ((e: DisposingEvent) => void);
    set onDisposing(value: ((e: DisposingEvent) => void));
    get onInitialized(): ((e: InitializedEvent) => void);
    set onInitialized(value: ((e: InitializedEvent) => void));
    get onOptionChanged(): ((e: OptionChangedEvent) => void);
    set onOptionChanged(value: ((e: OptionChangedEvent) => void));
    get rtlEnabled(): boolean;
    set rtlEnabled(value: boolean);
    get stylingMode(): ButtonStyle;
    set stylingMode(value: ButtonStyle);
    get tabIndex(): number;
    set tabIndex(value: number);
    get template(): any;
    set template(value: any);
    get text(): string;
    set text(value: string);
    get type(): ButtonType | string;
    set type(value: ButtonType | string);
    get useSubmitBehavior(): boolean;
    set useSubmitBehavior(value: boolean);
    get validationGroup(): string | undefined;
    set validationGroup(value: string | undefined);
    get visible(): boolean;
    set visible(value: boolean);
    get width(): number | string | undefined;
    set width(value: number | string | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost, renderer: Renderer2, document: any, templateHost: DxTemplateHost, element: ElementRef);
    setTemplate(template: DxTemplateDirective): void;
    ngAfterViewInit(): void;
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTreeListOptionsComponent, [{ host: true; skipSelf: true; }, { host: true; }, null, null, { host: true; }, null]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoTreeListOptionsComponent, "dxo-tree-list-options", never, { "accessKey": { "alias": "accessKey"; "required": false; }; "activeStateEnabled": { "alias": "activeStateEnabled"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "elementAttr": { "alias": "elementAttr"; "required": false; }; "focusStateEnabled": { "alias": "focusStateEnabled"; "required": false; }; "height": { "alias": "height"; "required": false; }; "hint": { "alias": "hint"; "required": false; }; "hoverStateEnabled": { "alias": "hoverStateEnabled"; "required": false; }; "icon": { "alias": "icon"; "required": false; }; "onClick": { "alias": "onClick"; "required": false; }; "onContentReady": { "alias": "onContentReady"; "required": false; }; "onDisposing": { "alias": "onDisposing"; "required": false; }; "onInitialized": { "alias": "onInitialized"; "required": false; }; "onOptionChanged": { "alias": "onOptionChanged"; "required": false; }; "rtlEnabled": { "alias": "rtlEnabled"; "required": false; }; "stylingMode": { "alias": "stylingMode"; "required": false; }; "tabIndex": { "alias": "tabIndex"; "required": false; }; "template": { "alias": "template"; "required": false; }; "text": { "alias": "text"; "required": false; }; "type": { "alias": "type"; "required": false; }; "useSubmitBehavior": { "alias": "useSubmitBehavior"; "required": false; }; "validationGroup": { "alias": "validationGroup"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, ["*"], true, never>;
}
declare class DxoTreeListOptionsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTreeListOptionsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoTreeListOptionsModule, never, [typeof DxoTreeListOptionsComponent], [typeof DxoTreeListOptionsComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoTreeListOptionsModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoTreeListPagerComponent extends NestedOption implements OnDestroy, OnInit {
    get allowedPageSizes(): Array<number | PagerPageSize> | Mode;
    set allowedPageSizes(value: Array<number | PagerPageSize> | Mode);
    get displayMode(): DisplayMode;
    set displayMode(value: DisplayMode);
    get infoText(): string;
    set infoText(value: string);
    get label(): string;
    set label(value: string);
    get showInfo(): boolean;
    set showInfo(value: boolean);
    get showNavigationButtons(): boolean;
    set showNavigationButtons(value: boolean);
    get showPageSizeSelector(): boolean | Mode;
    set showPageSizeSelector(value: boolean | Mode);
    get visible(): boolean | Mode;
    set visible(value: boolean | Mode);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTreeListPagerComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoTreeListPagerComponent, "dxo-tree-list-pager", never, { "allowedPageSizes": { "alias": "allowedPageSizes"; "required": false; }; "displayMode": { "alias": "displayMode"; "required": false; }; "infoText": { "alias": "infoText"; "required": false; }; "label": { "alias": "label"; "required": false; }; "showInfo": { "alias": "showInfo"; "required": false; }; "showNavigationButtons": { "alias": "showNavigationButtons"; "required": false; }; "showPageSizeSelector": { "alias": "showPageSizeSelector"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoTreeListPagerModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTreeListPagerModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoTreeListPagerModule, never, [typeof DxoTreeListPagerComponent], [typeof DxoTreeListPagerComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoTreeListPagerModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoTreeListPagingComponent extends NestedOption implements OnDestroy, OnInit {
    get enabled(): boolean;
    set enabled(value: boolean);
    get pageIndex(): number;
    set pageIndex(value: number);
    get pageSize(): number;
    set pageSize(value: number);
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    pageIndexChange: EventEmitter<number>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    pageSizeChange: EventEmitter<number>;
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTreeListPagingComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoTreeListPagingComponent, "dxo-tree-list-paging", never, { "enabled": { "alias": "enabled"; "required": false; }; "pageIndex": { "alias": "pageIndex"; "required": false; }; "pageSize": { "alias": "pageSize"; "required": false; }; }, { "pageIndexChange": "pageIndexChange"; "pageSizeChange": "pageSizeChange"; }, never, never, true, never>;
}
declare class DxoTreeListPagingModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTreeListPagingModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoTreeListPagingModule, never, [typeof DxoTreeListPagingComponent], [typeof DxoTreeListPagingComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoTreeListPagingModule>;
}

declare class DxiTreeListPatternRuleComponent extends CollectionNestedOption {
    get ignoreEmptyValue(): boolean;
    set ignoreEmptyValue(value: boolean);
    get message(): string;
    set message(value: string);
    get pattern(): RegExp | string;
    set pattern(value: RegExp | string);
    get type(): ValidationRuleType;
    set type(value: ValidationRuleType);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiTreeListPatternRuleComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiTreeListPatternRuleComponent, "dxi-tree-list-pattern-rule", never, { "ignoreEmptyValue": { "alias": "ignoreEmptyValue"; "required": false; }; "message": { "alias": "message"; "required": false; }; "pattern": { "alias": "pattern"; "required": false; }; "type": { "alias": "type"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxiTreeListPatternRuleModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiTreeListPatternRuleModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiTreeListPatternRuleModule, never, [typeof DxiTreeListPatternRuleComponent], [typeof DxiTreeListPatternRuleComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiTreeListPatternRuleModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoTreeListPopupComponent extends NestedOption implements OnDestroy, OnInit {
    set _toolbarItemsContentChildren(value: QueryList<CollectionNestedOption>);
    get accessKey(): string | undefined;
    set accessKey(value: string | undefined);
    get animation(): {
        hide?: AnimationConfig;
        show?: AnimationConfig;
    };
    set animation(value: {
        hide?: AnimationConfig;
        show?: AnimationConfig;
    });
    get container(): any | string | undefined;
    set container(value: any | string | undefined);
    get contentTemplate(): any;
    set contentTemplate(value: any);
    get deferRendering(): boolean;
    set deferRendering(value: boolean);
    get disabled(): boolean;
    set disabled(value: boolean);
    get dragAndResizeArea(): any | string | undefined;
    set dragAndResizeArea(value: any | string | undefined);
    get dragEnabled(): boolean;
    set dragEnabled(value: boolean);
    get dragOutsideBoundary(): boolean;
    set dragOutsideBoundary(value: boolean);
    get enableBodyScroll(): boolean;
    set enableBodyScroll(value: boolean);
    get focusStateEnabled(): boolean;
    set focusStateEnabled(value: boolean);
    get fullScreen(): boolean;
    set fullScreen(value: boolean);
    get height(): number | string;
    set height(value: number | string);
    get hideOnOutsideClick(): boolean | ((event: event) => boolean);
    set hideOnOutsideClick(value: boolean | ((event: event) => boolean));
    get hideOnParentScroll(): boolean;
    set hideOnParentScroll(value: boolean);
    get hint(): string | undefined;
    set hint(value: string | undefined);
    get hoverStateEnabled(): boolean;
    set hoverStateEnabled(value: boolean);
    get maxHeight(): number | string;
    set maxHeight(value: number | string);
    get maxWidth(): number | string;
    set maxWidth(value: number | string);
    get minHeight(): number | string;
    set minHeight(value: number | string);
    get minWidth(): number | string;
    set minWidth(value: number | string);
    get onContentReady(): ((e: EventInfo<any>) => void) | undefined;
    set onContentReady(value: ((e: EventInfo<any>) => void) | undefined);
    get onDisposing(): ((e: EventInfo<any>) => void) | undefined;
    set onDisposing(value: ((e: EventInfo<any>) => void) | undefined);
    get onHidden(): ((e: EventInfo<any>) => void);
    set onHidden(value: ((e: EventInfo<any>) => void));
    get onHiding(): ((e: {
        cancel: boolean | any;
        component: dxOverlay<any>;
        element: any;
        model: any;
    }) => void);
    set onHiding(value: ((e: {
        cancel: boolean | any;
        component: dxOverlay<any>;
        element: any;
        model: any;
    }) => void));
    get onInitialized(): ((e: {
        component: Component<any>;
        element: any;
    }) => void) | undefined;
    set onInitialized(value: ((e: {
        component: Component<any>;
        element: any;
    }) => void) | undefined);
    get onOptionChanged(): ((e: {
        component: DOMComponent;
        element: any;
        fullName: string;
        model: any;
        name: string;
        previousValue: any;
        value: any;
    }) => void) | undefined;
    set onOptionChanged(value: ((e: {
        component: DOMComponent;
        element: any;
        fullName: string;
        model: any;
        name: string;
        previousValue: any;
        value: any;
    }) => void) | undefined);
    get onResize(): ((e: {
        component: dxPopup;
        element: any;
        event: event;
        height: number;
        model: any;
        width: number;
    }) => void) | undefined;
    set onResize(value: ((e: {
        component: dxPopup;
        element: any;
        event: event;
        height: number;
        model: any;
        width: number;
    }) => void) | undefined);
    get onResizeEnd(): ((e: {
        component: dxPopup;
        element: any;
        event: event;
        height: number;
        model: any;
        width: number;
    }) => void) | undefined;
    set onResizeEnd(value: ((e: {
        component: dxPopup;
        element: any;
        event: event;
        height: number;
        model: any;
        width: number;
    }) => void) | undefined);
    get onResizeStart(): ((e: {
        component: dxPopup;
        element: any;
        event: event;
        height: number;
        model: any;
        width: number;
    }) => void) | undefined;
    set onResizeStart(value: ((e: {
        component: dxPopup;
        element: any;
        event: event;
        height: number;
        model: any;
        width: number;
    }) => void) | undefined);
    get onShowing(): ((e: {
        cancel: boolean | any;
        component: dxOverlay<any>;
        element: any;
        model: any;
    }) => void);
    set onShowing(value: ((e: {
        cancel: boolean | any;
        component: dxOverlay<any>;
        element: any;
        model: any;
    }) => void));
    get onShown(): ((e: EventInfo<any>) => void);
    set onShown(value: ((e: EventInfo<any>) => void));
    get onTitleRendered(): ((e: {
        component: dxPopup;
        element: any;
        model: any;
        titleElement: any;
    }) => void) | undefined;
    set onTitleRendered(value: ((e: {
        component: dxPopup;
        element: any;
        model: any;
        titleElement: any;
    }) => void) | undefined);
    get position(): Function | PositionAlignment | PositionConfig;
    set position(value: Function | PositionAlignment | PositionConfig);
    get resizeEnabled(): boolean;
    set resizeEnabled(value: boolean);
    get restorePosition(): boolean;
    set restorePosition(value: boolean);
    get rtlEnabled(): boolean;
    set rtlEnabled(value: boolean);
    get shading(): boolean;
    set shading(value: boolean);
    get shadingColor(): string;
    set shadingColor(value: string);
    get showCloseButton(): boolean;
    set showCloseButton(value: boolean);
    get showTitle(): boolean;
    set showTitle(value: boolean);
    get tabFocusLoopEnabled(): boolean;
    set tabFocusLoopEnabled(value: boolean);
    get tabIndex(): number;
    set tabIndex(value: number);
    get title(): string;
    set title(value: string);
    get titleTemplate(): any;
    set titleTemplate(value: any);
    get toolbarItems(): Array<dxPopupToolbarItem>;
    set toolbarItems(value: Array<dxPopupToolbarItem>);
    get visible(): boolean;
    set visible(value: boolean);
    get width(): number | string;
    set width(value: number | string);
    get wrapperAttr(): any;
    set wrapperAttr(value: any);
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    heightChange: EventEmitter<number | string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    positionChange: EventEmitter<Function | PositionAlignment | PositionConfig>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    visibleChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    widthChange: EventEmitter<number | string>;
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTreeListPopupComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoTreeListPopupComponent, "dxo-tree-list-popup", never, { "accessKey": { "alias": "accessKey"; "required": false; }; "animation": { "alias": "animation"; "required": false; }; "container": { "alias": "container"; "required": false; }; "contentTemplate": { "alias": "contentTemplate"; "required": false; }; "deferRendering": { "alias": "deferRendering"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "dragAndResizeArea": { "alias": "dragAndResizeArea"; "required": false; }; "dragEnabled": { "alias": "dragEnabled"; "required": false; }; "dragOutsideBoundary": { "alias": "dragOutsideBoundary"; "required": false; }; "enableBodyScroll": { "alias": "enableBodyScroll"; "required": false; }; "focusStateEnabled": { "alias": "focusStateEnabled"; "required": false; }; "fullScreen": { "alias": "fullScreen"; "required": false; }; "height": { "alias": "height"; "required": false; }; "hideOnOutsideClick": { "alias": "hideOnOutsideClick"; "required": false; }; "hideOnParentScroll": { "alias": "hideOnParentScroll"; "required": false; }; "hint": { "alias": "hint"; "required": false; }; "hoverStateEnabled": { "alias": "hoverStateEnabled"; "required": false; }; "maxHeight": { "alias": "maxHeight"; "required": false; }; "maxWidth": { "alias": "maxWidth"; "required": false; }; "minHeight": { "alias": "minHeight"; "required": false; }; "minWidth": { "alias": "minWidth"; "required": false; }; "onContentReady": { "alias": "onContentReady"; "required": false; }; "onDisposing": { "alias": "onDisposing"; "required": false; }; "onHidden": { "alias": "onHidden"; "required": false; }; "onHiding": { "alias": "onHiding"; "required": false; }; "onInitialized": { "alias": "onInitialized"; "required": false; }; "onOptionChanged": { "alias": "onOptionChanged"; "required": false; }; "onResize": { "alias": "onResize"; "required": false; }; "onResizeEnd": { "alias": "onResizeEnd"; "required": false; }; "onResizeStart": { "alias": "onResizeStart"; "required": false; }; "onShowing": { "alias": "onShowing"; "required": false; }; "onShown": { "alias": "onShown"; "required": false; }; "onTitleRendered": { "alias": "onTitleRendered"; "required": false; }; "position": { "alias": "position"; "required": false; }; "resizeEnabled": { "alias": "resizeEnabled"; "required": false; }; "restorePosition": { "alias": "restorePosition"; "required": false; }; "rtlEnabled": { "alias": "rtlEnabled"; "required": false; }; "shading": { "alias": "shading"; "required": false; }; "shadingColor": { "alias": "shadingColor"; "required": false; }; "showCloseButton": { "alias": "showCloseButton"; "required": false; }; "showTitle": { "alias": "showTitle"; "required": false; }; "tabFocusLoopEnabled": { "alias": "tabFocusLoopEnabled"; "required": false; }; "tabIndex": { "alias": "tabIndex"; "required": false; }; "title": { "alias": "title"; "required": false; }; "titleTemplate": { "alias": "titleTemplate"; "required": false; }; "toolbarItems": { "alias": "toolbarItems"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; "wrapperAttr": { "alias": "wrapperAttr"; "required": false; }; }, { "heightChange": "heightChange"; "positionChange": "positionChange"; "visibleChange": "visibleChange"; "widthChange": "widthChange"; }, ["_toolbarItemsContentChildren"], never, true, never>;
}
declare class DxoTreeListPopupModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTreeListPopupModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoTreeListPopupModule, never, [typeof DxoTreeListPopupComponent], [typeof DxoTreeListPopupComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoTreeListPopupModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoTreeListPositionComponent extends NestedOption implements OnDestroy, OnInit {
    get at(): PositionAlignment | {
        x?: HorizontalAlignment;
        y?: VerticalAlignment;
    };
    set at(value: PositionAlignment | {
        x?: HorizontalAlignment;
        y?: VerticalAlignment;
    });
    get boundary(): any | string;
    set boundary(value: any | string);
    get boundaryOffset(): string | {
        x?: number;
        y?: number;
    };
    set boundaryOffset(value: string | {
        x?: number;
        y?: number;
    });
    get collision(): CollisionResolutionCombination | {
        x?: CollisionResolution;
        y?: CollisionResolution;
    };
    set collision(value: CollisionResolutionCombination | {
        x?: CollisionResolution;
        y?: CollisionResolution;
    });
    get my(): PositionAlignment | {
        x?: HorizontalAlignment;
        y?: VerticalAlignment;
    };
    set my(value: PositionAlignment | {
        x?: HorizontalAlignment;
        y?: VerticalAlignment;
    });
    get of(): any | string;
    set of(value: any | string);
    get offset(): string | {
        x?: number;
        y?: number;
    };
    set offset(value: string | {
        x?: number;
        y?: number;
    });
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTreeListPositionComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoTreeListPositionComponent, "dxo-tree-list-position", never, { "at": { "alias": "at"; "required": false; }; "boundary": { "alias": "boundary"; "required": false; }; "boundaryOffset": { "alias": "boundaryOffset"; "required": false; }; "collision": { "alias": "collision"; "required": false; }; "my": { "alias": "my"; "required": false; }; "of": { "alias": "of"; "required": false; }; "offset": { "alias": "offset"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoTreeListPositionModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTreeListPositionModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoTreeListPositionModule, never, [typeof DxoTreeListPositionComponent], [typeof DxoTreeListPositionComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoTreeListPositionModule>;
}

declare class DxiTreeListRangeRuleComponent extends CollectionNestedOption {
    get ignoreEmptyValue(): boolean;
    set ignoreEmptyValue(value: boolean);
    get max(): Date | number | string;
    set max(value: Date | number | string);
    get message(): string;
    set message(value: string);
    get min(): Date | number | string;
    set min(value: Date | number | string);
    get reevaluate(): boolean;
    set reevaluate(value: boolean);
    get type(): ValidationRuleType;
    set type(value: ValidationRuleType);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiTreeListRangeRuleComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiTreeListRangeRuleComponent, "dxi-tree-list-range-rule", never, { "ignoreEmptyValue": { "alias": "ignoreEmptyValue"; "required": false; }; "max": { "alias": "max"; "required": false; }; "message": { "alias": "message"; "required": false; }; "min": { "alias": "min"; "required": false; }; "reevaluate": { "alias": "reevaluate"; "required": false; }; "type": { "alias": "type"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxiTreeListRangeRuleModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiTreeListRangeRuleModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiTreeListRangeRuleModule, never, [typeof DxiTreeListRangeRuleComponent], [typeof DxiTreeListRangeRuleComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiTreeListRangeRuleModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoTreeListRemoteOperationsComponent extends NestedOption implements OnDestroy, OnInit {
    get filtering(): boolean;
    set filtering(value: boolean);
    get grouping(): boolean;
    set grouping(value: boolean);
    get sorting(): boolean;
    set sorting(value: boolean);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTreeListRemoteOperationsComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoTreeListRemoteOperationsComponent, "dxo-tree-list-remote-operations", never, { "filtering": { "alias": "filtering"; "required": false; }; "grouping": { "alias": "grouping"; "required": false; }; "sorting": { "alias": "sorting"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoTreeListRemoteOperationsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTreeListRemoteOperationsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoTreeListRemoteOperationsModule, never, [typeof DxoTreeListRemoteOperationsComponent], [typeof DxoTreeListRemoteOperationsComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoTreeListRemoteOperationsModule>;
}

declare class DxiTreeListRequiredRuleComponent extends CollectionNestedOption {
    get message(): string;
    set message(value: string);
    get trim(): boolean;
    set trim(value: boolean);
    get type(): ValidationRuleType;
    set type(value: ValidationRuleType);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiTreeListRequiredRuleComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiTreeListRequiredRuleComponent, "dxi-tree-list-required-rule", never, { "message": { "alias": "message"; "required": false; }; "trim": { "alias": "trim"; "required": false; }; "type": { "alias": "type"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxiTreeListRequiredRuleModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiTreeListRequiredRuleModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiTreeListRequiredRuleModule, never, [typeof DxiTreeListRequiredRuleComponent], [typeof DxiTreeListRequiredRuleComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiTreeListRequiredRuleModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoTreeListRowDraggingComponent extends NestedOption implements OnDestroy, OnInit {
    get allowDropInsideItem(): boolean;
    set allowDropInsideItem(value: boolean);
    get allowReordering(): boolean;
    set allowReordering(value: boolean);
    get autoScroll(): boolean;
    set autoScroll(value: boolean);
    get boundary(): any | string | undefined;
    set boundary(value: any | string | undefined);
    get container(): any | string | undefined;
    set container(value: any | string | undefined);
    get cursorOffset(): string | {
        x?: number;
        y?: number;
    };
    set cursorOffset(value: string | {
        x?: number;
        y?: number;
    });
    get data(): any | undefined;
    set data(value: any | undefined);
    get dragDirection(): DragDirection;
    set dragDirection(value: DragDirection);
    get dragTemplate(): any;
    set dragTemplate(value: any);
    get dropFeedbackMode(): DragHighlight;
    set dropFeedbackMode(value: DragHighlight);
    get filter(): string;
    set filter(value: string);
    get group(): string | undefined;
    set group(value: string | undefined);
    get handle(): string;
    set handle(value: string);
    get onAdd(): ((e: RowDraggingAddEvent) => void);
    set onAdd(value: ((e: RowDraggingAddEvent) => void));
    get onDragChange(): ((e: RowDraggingChangeEvent) => void);
    set onDragChange(value: ((e: RowDraggingChangeEvent) => void));
    get onDragEnd(): ((e: RowDraggingEndEvent) => void);
    set onDragEnd(value: ((e: RowDraggingEndEvent) => void));
    get onDragMove(): ((e: RowDraggingMoveEvent) => void);
    set onDragMove(value: ((e: RowDraggingMoveEvent) => void));
    get onDragStart(): ((e: RowDraggingStartEvent) => void);
    set onDragStart(value: ((e: RowDraggingStartEvent) => void));
    get onRemove(): ((e: RowDraggingRemoveEvent) => void);
    set onRemove(value: ((e: RowDraggingRemoveEvent) => void));
    get onReorder(): ((e: RowDraggingReorderEvent) => void);
    set onReorder(value: ((e: RowDraggingReorderEvent) => void));
    get scrollSensitivity(): number;
    set scrollSensitivity(value: number);
    get scrollSpeed(): number;
    set scrollSpeed(value: number);
    get showDragIcons(): boolean;
    set showDragIcons(value: boolean);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTreeListRowDraggingComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoTreeListRowDraggingComponent, "dxo-tree-list-row-dragging", never, { "allowDropInsideItem": { "alias": "allowDropInsideItem"; "required": false; }; "allowReordering": { "alias": "allowReordering"; "required": false; }; "autoScroll": { "alias": "autoScroll"; "required": false; }; "boundary": { "alias": "boundary"; "required": false; }; "container": { "alias": "container"; "required": false; }; "cursorOffset": { "alias": "cursorOffset"; "required": false; }; "data": { "alias": "data"; "required": false; }; "dragDirection": { "alias": "dragDirection"; "required": false; }; "dragTemplate": { "alias": "dragTemplate"; "required": false; }; "dropFeedbackMode": { "alias": "dropFeedbackMode"; "required": false; }; "filter": { "alias": "filter"; "required": false; }; "group": { "alias": "group"; "required": false; }; "handle": { "alias": "handle"; "required": false; }; "onAdd": { "alias": "onAdd"; "required": false; }; "onDragChange": { "alias": "onDragChange"; "required": false; }; "onDragEnd": { "alias": "onDragEnd"; "required": false; }; "onDragMove": { "alias": "onDragMove"; "required": false; }; "onDragStart": { "alias": "onDragStart"; "required": false; }; "onRemove": { "alias": "onRemove"; "required": false; }; "onReorder": { "alias": "onReorder"; "required": false; }; "scrollSensitivity": { "alias": "scrollSensitivity"; "required": false; }; "scrollSpeed": { "alias": "scrollSpeed"; "required": false; }; "showDragIcons": { "alias": "showDragIcons"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoTreeListRowDraggingModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTreeListRowDraggingModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoTreeListRowDraggingModule, never, [typeof DxoTreeListRowDraggingComponent], [typeof DxoTreeListRowDraggingComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoTreeListRowDraggingModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoTreeListScrollingComponent extends NestedOption implements OnDestroy, OnInit {
    get columnRenderingMode(): DataRenderMode;
    set columnRenderingMode(value: DataRenderMode);
    get mode(): ScrollMode;
    set mode(value: ScrollMode);
    get preloadEnabled(): boolean;
    set preloadEnabled(value: boolean);
    get renderAsync(): boolean | undefined;
    set renderAsync(value: boolean | undefined);
    get rowRenderingMode(): DataRenderMode;
    set rowRenderingMode(value: DataRenderMode);
    get scrollByContent(): boolean;
    set scrollByContent(value: boolean);
    get scrollByThumb(): boolean;
    set scrollByThumb(value: boolean);
    get showScrollbar(): ScrollbarMode;
    set showScrollbar(value: ScrollbarMode);
    get useNative(): boolean | Mode;
    set useNative(value: boolean | Mode);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTreeListScrollingComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoTreeListScrollingComponent, "dxo-tree-list-scrolling", never, { "columnRenderingMode": { "alias": "columnRenderingMode"; "required": false; }; "mode": { "alias": "mode"; "required": false; }; "preloadEnabled": { "alias": "preloadEnabled"; "required": false; }; "renderAsync": { "alias": "renderAsync"; "required": false; }; "rowRenderingMode": { "alias": "rowRenderingMode"; "required": false; }; "scrollByContent": { "alias": "scrollByContent"; "required": false; }; "scrollByThumb": { "alias": "scrollByThumb"; "required": false; }; "showScrollbar": { "alias": "showScrollbar"; "required": false; }; "useNative": { "alias": "useNative"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoTreeListScrollingModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTreeListScrollingModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoTreeListScrollingModule, never, [typeof DxoTreeListScrollingComponent], [typeof DxoTreeListScrollingComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoTreeListScrollingModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoTreeListSearchPanelComponent extends NestedOption implements OnDestroy, OnInit {
    get highlightCaseSensitive(): boolean;
    set highlightCaseSensitive(value: boolean);
    get highlightSearchText(): boolean;
    set highlightSearchText(value: boolean);
    get placeholder(): string;
    set placeholder(value: string);
    get searchVisibleColumnsOnly(): boolean;
    set searchVisibleColumnsOnly(value: boolean);
    get text(): string;
    set text(value: string);
    get visible(): boolean;
    set visible(value: boolean);
    get width(): number | string;
    set width(value: number | string);
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    textChange: EventEmitter<string>;
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTreeListSearchPanelComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoTreeListSearchPanelComponent, "dxo-tree-list-search-panel", never, { "highlightCaseSensitive": { "alias": "highlightCaseSensitive"; "required": false; }; "highlightSearchText": { "alias": "highlightSearchText"; "required": false; }; "placeholder": { "alias": "placeholder"; "required": false; }; "searchVisibleColumnsOnly": { "alias": "searchVisibleColumnsOnly"; "required": false; }; "text": { "alias": "text"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, { "textChange": "textChange"; }, never, never, true, never>;
}
declare class DxoTreeListSearchPanelModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTreeListSearchPanelModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoTreeListSearchPanelModule, never, [typeof DxoTreeListSearchPanelComponent], [typeof DxoTreeListSearchPanelComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoTreeListSearchPanelModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoTreeListSearchComponent extends NestedOption implements OnDestroy, OnInit {
    get editorOptions(): any;
    set editorOptions(value: any);
    get enabled(): boolean;
    set enabled(value: boolean);
    get mode(): SearchMode;
    set mode(value: SearchMode);
    get searchExpr(): Array<Function | string> | Function | string | undefined;
    set searchExpr(value: Array<Function | string> | Function | string | undefined);
    get timeout(): number;
    set timeout(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTreeListSearchComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoTreeListSearchComponent, "dxo-tree-list-search", never, { "editorOptions": { "alias": "editorOptions"; "required": false; }; "enabled": { "alias": "enabled"; "required": false; }; "mode": { "alias": "mode"; "required": false; }; "searchExpr": { "alias": "searchExpr"; "required": false; }; "timeout": { "alias": "timeout"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoTreeListSearchModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTreeListSearchModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoTreeListSearchModule, never, [typeof DxoTreeListSearchComponent], [typeof DxoTreeListSearchComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoTreeListSearchModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoTreeListSelectionComponent extends NestedOption implements OnDestroy, OnInit {
    get allowSelectAll(): boolean;
    set allowSelectAll(value: boolean);
    get mode(): SingleMultipleOrNone;
    set mode(value: SingleMultipleOrNone);
    get recursive(): boolean;
    set recursive(value: boolean);
    get selectByClick(): boolean;
    set selectByClick(value: boolean);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTreeListSelectionComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoTreeListSelectionComponent, "dxo-tree-list-selection", never, { "allowSelectAll": { "alias": "allowSelectAll"; "required": false; }; "mode": { "alias": "mode"; "required": false; }; "recursive": { "alias": "recursive"; "required": false; }; "selectByClick": { "alias": "selectByClick"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoTreeListSelectionModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTreeListSelectionModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoTreeListSelectionModule, never, [typeof DxoTreeListSelectionComponent], [typeof DxoTreeListSelectionComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoTreeListSelectionModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoTreeListShowComponent extends NestedOption implements OnDestroy, OnInit {
    get complete(): (($element: any, config: AnimationConfig) => void);
    set complete(value: (($element: any, config: AnimationConfig) => void));
    get delay(): number;
    set delay(value: number);
    get direction(): Direction | undefined;
    set direction(value: Direction | undefined);
    get duration(): number;
    set duration(value: number);
    get easing(): string;
    set easing(value: string);
    get from(): AnimationState;
    set from(value: AnimationState);
    get staggerDelay(): number | undefined;
    set staggerDelay(value: number | undefined);
    get start(): (($element: any, config: AnimationConfig) => void);
    set start(value: (($element: any, config: AnimationConfig) => void));
    get to(): AnimationState;
    set to(value: AnimationState);
    get type(): AnimationType;
    set type(value: AnimationType);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTreeListShowComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoTreeListShowComponent, "dxo-tree-list-show", never, { "complete": { "alias": "complete"; "required": false; }; "delay": { "alias": "delay"; "required": false; }; "direction": { "alias": "direction"; "required": false; }; "duration": { "alias": "duration"; "required": false; }; "easing": { "alias": "easing"; "required": false; }; "from": { "alias": "from"; "required": false; }; "staggerDelay": { "alias": "staggerDelay"; "required": false; }; "start": { "alias": "start"; "required": false; }; "to": { "alias": "to"; "required": false; }; "type": { "alias": "type"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoTreeListShowModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTreeListShowModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoTreeListShowModule, never, [typeof DxoTreeListShowComponent], [typeof DxoTreeListShowComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoTreeListShowModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxiTreeListSimpleItemComponent extends CollectionNestedOption implements AfterViewInit, IDxTemplateHost {
    private renderer;
    private document;
    private element;
    set _validationRulesContentChildren(value: QueryList<CollectionNestedOption>);
    get aiOptions(): {
        disabled?: boolean;
        instruction?: string | undefined;
    };
    set aiOptions(value: {
        disabled?: boolean;
        instruction?: string | undefined;
    });
    get colSpan(): number | undefined;
    set colSpan(value: number | undefined);
    get cssClass(): string | undefined;
    set cssClass(value: string | undefined);
    get dataField(): string | undefined;
    set dataField(value: string | undefined);
    get editorOptions(): any | undefined;
    set editorOptions(value: any | undefined);
    get editorType(): FormItemComponent;
    set editorType(value: FormItemComponent);
    get helpText(): string | undefined;
    set helpText(value: string | undefined);
    get isRequired(): boolean | undefined;
    set isRequired(value: boolean | undefined);
    get itemType(): FormItemType;
    set itemType(value: FormItemType);
    get label(): {
        alignment?: HorizontalAlignment;
        location?: LabelLocation;
        showColon?: boolean;
        template?: any;
        text?: string | undefined;
        visible?: boolean;
    };
    set label(value: {
        alignment?: HorizontalAlignment;
        location?: LabelLocation;
        showColon?: boolean;
        template?: any;
        text?: string | undefined;
        visible?: boolean;
    });
    get name(): string | undefined;
    set name(value: string | undefined);
    get template(): any;
    set template(value: any);
    get validationRules(): Array<CommonTypes.ValidationRule>;
    set validationRules(value: Array<CommonTypes.ValidationRule>);
    get visible(): boolean;
    set visible(value: boolean);
    get visibleIndex(): number | undefined;
    set visibleIndex(value: number | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost, renderer: Renderer2, document: any, templateHost: DxTemplateHost, element: ElementRef);
    setTemplate(template: DxTemplateDirective): void;
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiTreeListSimpleItemComponent, [{ host: true; skipSelf: true; }, { host: true; }, null, null, { host: true; }, null]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiTreeListSimpleItemComponent, "dxi-tree-list-simple-item", never, { "aiOptions": { "alias": "aiOptions"; "required": false; }; "colSpan": { "alias": "colSpan"; "required": false; }; "cssClass": { "alias": "cssClass"; "required": false; }; "dataField": { "alias": "dataField"; "required": false; }; "editorOptions": { "alias": "editorOptions"; "required": false; }; "editorType": { "alias": "editorType"; "required": false; }; "helpText": { "alias": "helpText"; "required": false; }; "isRequired": { "alias": "isRequired"; "required": false; }; "itemType": { "alias": "itemType"; "required": false; }; "label": { "alias": "label"; "required": false; }; "name": { "alias": "name"; "required": false; }; "template": { "alias": "template"; "required": false; }; "validationRules": { "alias": "validationRules"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "visibleIndex": { "alias": "visibleIndex"; "required": false; }; }, {}, ["_validationRulesContentChildren"], ["*"], true, never>;
}
declare class DxiTreeListSimpleItemModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiTreeListSimpleItemModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiTreeListSimpleItemModule, never, [typeof DxiTreeListSimpleItemComponent], [typeof DxiTreeListSimpleItemComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiTreeListSimpleItemModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoTreeListSortingComponent extends NestedOption implements OnDestroy, OnInit {
    get ascendingText(): string;
    set ascendingText(value: string);
    get clearText(): string;
    set clearText(value: string);
    get descendingText(): string;
    set descendingText(value: string);
    get mode(): SingleMultipleOrNone;
    set mode(value: SingleMultipleOrNone);
    get showSortIndexes(): boolean;
    set showSortIndexes(value: boolean);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTreeListSortingComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoTreeListSortingComponent, "dxo-tree-list-sorting", never, { "ascendingText": { "alias": "ascendingText"; "required": false; }; "clearText": { "alias": "clearText"; "required": false; }; "descendingText": { "alias": "descendingText"; "required": false; }; "mode": { "alias": "mode"; "required": false; }; "showSortIndexes": { "alias": "showSortIndexes"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoTreeListSortingModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTreeListSortingModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoTreeListSortingModule, never, [typeof DxoTreeListSortingComponent], [typeof DxoTreeListSortingComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoTreeListSortingModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoTreeListStateStoringComponent extends NestedOption implements OnDestroy, OnInit {
    get customLoad(): Function;
    set customLoad(value: Function);
    get customSave(): ((gridState: any) => void);
    set customSave(value: ((gridState: any) => void));
    get enabled(): boolean;
    set enabled(value: boolean);
    get savingTimeout(): number;
    set savingTimeout(value: number);
    get storageKey(): string | undefined;
    set storageKey(value: string | undefined);
    get type(): StateStoreType;
    set type(value: StateStoreType);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTreeListStateStoringComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoTreeListStateStoringComponent, "dxo-tree-list-state-storing", never, { "customLoad": { "alias": "customLoad"; "required": false; }; "customSave": { "alias": "customSave"; "required": false; }; "enabled": { "alias": "enabled"; "required": false; }; "savingTimeout": { "alias": "savingTimeout"; "required": false; }; "storageKey": { "alias": "storageKey"; "required": false; }; "type": { "alias": "type"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoTreeListStateStoringModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTreeListStateStoringModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoTreeListStateStoringModule, never, [typeof DxoTreeListStateStoringComponent], [typeof DxoTreeListStateStoringComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoTreeListStateStoringModule>;
}

declare class DxiTreeListStringLengthRuleComponent extends CollectionNestedOption {
    get ignoreEmptyValue(): boolean;
    set ignoreEmptyValue(value: boolean);
    get max(): number;
    set max(value: number);
    get message(): string;
    set message(value: string);
    get min(): number;
    set min(value: number);
    get trim(): boolean;
    set trim(value: boolean);
    get type(): ValidationRuleType;
    set type(value: ValidationRuleType);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiTreeListStringLengthRuleComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiTreeListStringLengthRuleComponent, "dxi-tree-list-string-length-rule", never, { "ignoreEmptyValue": { "alias": "ignoreEmptyValue"; "required": false; }; "max": { "alias": "max"; "required": false; }; "message": { "alias": "message"; "required": false; }; "min": { "alias": "min"; "required": false; }; "trim": { "alias": "trim"; "required": false; }; "type": { "alias": "type"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxiTreeListStringLengthRuleModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiTreeListStringLengthRuleModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiTreeListStringLengthRuleModule, never, [typeof DxiTreeListStringLengthRuleComponent], [typeof DxiTreeListStringLengthRuleComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiTreeListStringLengthRuleModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxiTreeListTabComponent extends CollectionNestedOption implements AfterViewInit, IDxTemplateHost {
    private renderer;
    private document;
    private element;
    set _itemsContentChildren(value: QueryList<CollectionNestedOption>);
    get alignItemLabels(): boolean;
    set alignItemLabels(value: boolean);
    get badge(): string | undefined;
    set badge(value: string | undefined);
    get colCount(): number;
    set colCount(value: number);
    get colCountByScreen(): {
        lg?: number | undefined;
        md?: number | undefined;
        sm?: number | undefined;
        xs?: number | undefined;
    };
    set colCountByScreen(value: {
        lg?: number | undefined;
        md?: number | undefined;
        sm?: number | undefined;
        xs?: number | undefined;
    });
    get disabled(): boolean;
    set disabled(value: boolean);
    get icon(): string | undefined;
    set icon(value: string | undefined);
    get items(): Array<dxFormButtonItem | dxFormEmptyItem | dxFormGroupItem | dxFormSimpleItem | dxFormTabbedItem>;
    set items(value: Array<dxFormButtonItem | dxFormEmptyItem | dxFormGroupItem | dxFormSimpleItem | dxFormTabbedItem>);
    get tabTemplate(): any;
    set tabTemplate(value: any);
    get template(): any;
    set template(value: any);
    get title(): string | undefined;
    set title(value: string | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost, renderer: Renderer2, document: any, templateHost: DxTemplateHost, element: ElementRef);
    setTemplate(template: DxTemplateDirective): void;
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiTreeListTabComponent, [{ host: true; skipSelf: true; }, { host: true; }, null, null, { host: true; }, null]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiTreeListTabComponent, "dxi-tree-list-tab", never, { "alignItemLabels": { "alias": "alignItemLabels"; "required": false; }; "badge": { "alias": "badge"; "required": false; }; "colCount": { "alias": "colCount"; "required": false; }; "colCountByScreen": { "alias": "colCountByScreen"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "icon": { "alias": "icon"; "required": false; }; "items": { "alias": "items"; "required": false; }; "tabTemplate": { "alias": "tabTemplate"; "required": false; }; "template": { "alias": "template"; "required": false; }; "title": { "alias": "title"; "required": false; }; }, {}, ["_itemsContentChildren"], ["*"], true, never>;
}
declare class DxiTreeListTabModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiTreeListTabModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiTreeListTabModule, never, [typeof DxiTreeListTabComponent], [typeof DxiTreeListTabComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiTreeListTabModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxiTreeListTabPanelOptionsItemComponent extends CollectionNestedOption implements AfterViewInit, IDxTemplateHost {
    private renderer;
    private document;
    private element;
    get badge(): string;
    set badge(value: string);
    get disabled(): boolean;
    set disabled(value: boolean);
    get html(): string;
    set html(value: string);
    get icon(): string;
    set icon(value: string);
    get tabTemplate(): any;
    set tabTemplate(value: any);
    get template(): any;
    set template(value: any);
    get text(): string;
    set text(value: string);
    get title(): string;
    set title(value: string);
    get visible(): boolean;
    set visible(value: boolean);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost, renderer: Renderer2, document: any, templateHost: DxTemplateHost, element: ElementRef);
    setTemplate(template: DxTemplateDirective): void;
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiTreeListTabPanelOptionsItemComponent, [{ host: true; skipSelf: true; }, { host: true; }, null, null, { host: true; }, null]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiTreeListTabPanelOptionsItemComponent, "dxi-tree-list-tab-panel-options-item", never, { "badge": { "alias": "badge"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "html": { "alias": "html"; "required": false; }; "icon": { "alias": "icon"; "required": false; }; "tabTemplate": { "alias": "tabTemplate"; "required": false; }; "template": { "alias": "template"; "required": false; }; "text": { "alias": "text"; "required": false; }; "title": { "alias": "title"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; }, {}, never, ["*"], true, never>;
}
declare class DxiTreeListTabPanelOptionsItemModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiTreeListTabPanelOptionsItemModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiTreeListTabPanelOptionsItemModule, never, [typeof DxiTreeListTabPanelOptionsItemComponent], [typeof DxiTreeListTabPanelOptionsItemComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiTreeListTabPanelOptionsItemModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoTreeListTabPanelOptionsComponent extends NestedOption implements OnDestroy, OnInit {
    set _itemsContentChildren(value: QueryList<CollectionNestedOption>);
    get accessKey(): string | undefined;
    set accessKey(value: string | undefined);
    get activeStateEnabled(): boolean;
    set activeStateEnabled(value: boolean);
    get animationEnabled(): boolean;
    set animationEnabled(value: boolean);
    get dataSource(): Array<any | dxTabPanelItem | string> | DataSource | DataSourceOptions | null | Store | string;
    set dataSource(value: Array<any | dxTabPanelItem | string> | DataSource | DataSourceOptions | null | Store | string);
    get deferRendering(): boolean;
    set deferRendering(value: boolean);
    get disabled(): boolean;
    set disabled(value: boolean);
    get elementAttr(): Record<string, any>;
    set elementAttr(value: Record<string, any>);
    get focusStateEnabled(): boolean;
    set focusStateEnabled(value: boolean);
    get height(): number | string | undefined;
    set height(value: number | string | undefined);
    get hint(): string | undefined;
    set hint(value: string | undefined);
    get hoverStateEnabled(): boolean;
    set hoverStateEnabled(value: boolean);
    get iconPosition(): TabsIconPosition;
    set iconPosition(value: TabsIconPosition);
    get itemHoldTimeout(): number;
    set itemHoldTimeout(value: number);
    get items(): Array<any | dxTabPanelItem | string>;
    set items(value: Array<any | dxTabPanelItem | string>);
    get itemTemplate(): any;
    set itemTemplate(value: any);
    get itemTitleTemplate(): any;
    set itemTitleTemplate(value: any);
    get keyExpr(): ((item: any) => any) | string;
    set keyExpr(value: ((item: any) => any) | string);
    get loop(): boolean;
    set loop(value: boolean);
    get noDataText(): string;
    set noDataText(value: string);
    get onContentReady(): ((e: ContentReadyEvent$4) => void);
    set onContentReady(value: ((e: ContentReadyEvent$4) => void));
    get onDisposing(): ((e: DisposingEvent$4) => void);
    set onDisposing(value: ((e: DisposingEvent$4) => void));
    get onInitialized(): ((e: InitializedEvent$4) => void);
    set onInitialized(value: ((e: InitializedEvent$4) => void));
    get onItemClick(): ((e: ItemClickEvent) => void);
    set onItemClick(value: ((e: ItemClickEvent) => void));
    get onItemContextMenu(): ((e: ItemContextMenuEvent) => void);
    set onItemContextMenu(value: ((e: ItemContextMenuEvent) => void));
    get onItemHold(): ((e: ItemHoldEvent) => void);
    set onItemHold(value: ((e: ItemHoldEvent) => void));
    get onItemRendered(): ((e: ItemRenderedEvent) => void);
    set onItemRendered(value: ((e: ItemRenderedEvent) => void));
    get onOptionChanged(): ((e: OptionChangedEvent$4) => void);
    set onOptionChanged(value: ((e: OptionChangedEvent$4) => void));
    get onSelectionChanged(): ((e: SelectionChangedEvent) => void);
    set onSelectionChanged(value: ((e: SelectionChangedEvent) => void));
    get onSelectionChanging(): ((e: SelectionChangingEvent) => void);
    set onSelectionChanging(value: ((e: SelectionChangingEvent) => void));
    get onTitleClick(): ((e: TitleClickEvent) => void);
    set onTitleClick(value: ((e: TitleClickEvent) => void));
    get onTitleHold(): ((e: TitleHoldEvent) => void) | undefined;
    set onTitleHold(value: ((e: TitleHoldEvent) => void) | undefined);
    get onTitleRendered(): ((e: TitleRenderedEvent) => void) | undefined;
    set onTitleRendered(value: ((e: TitleRenderedEvent) => void) | undefined);
    get repaintChangesOnly(): boolean;
    set repaintChangesOnly(value: boolean);
    get rtlEnabled(): boolean;
    set rtlEnabled(value: boolean);
    get scrollByContent(): boolean;
    set scrollByContent(value: boolean);
    get scrollingEnabled(): boolean;
    set scrollingEnabled(value: boolean);
    get selectedIndex(): number;
    set selectedIndex(value: number);
    get selectedItem(): any | null;
    set selectedItem(value: any | null);
    get showNavButtons(): boolean;
    set showNavButtons(value: boolean);
    get stylingMode(): TabsStyle;
    set stylingMode(value: TabsStyle);
    get swipeEnabled(): boolean;
    set swipeEnabled(value: boolean);
    get tabIndex(): number;
    set tabIndex(value: number);
    get tabsPosition(): Position;
    set tabsPosition(value: Position);
    get visible(): boolean;
    set visible(value: boolean);
    get width(): number | string | undefined;
    set width(value: number | string | undefined);
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    itemsChange: EventEmitter<Array<any | dxTabPanelItem | string>>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    selectedIndexChange: EventEmitter<number>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    selectedItemChange: EventEmitter<any | null>;
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTreeListTabPanelOptionsComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoTreeListTabPanelOptionsComponent, "dxo-tree-list-tab-panel-options", never, { "accessKey": { "alias": "accessKey"; "required": false; }; "activeStateEnabled": { "alias": "activeStateEnabled"; "required": false; }; "animationEnabled": { "alias": "animationEnabled"; "required": false; }; "dataSource": { "alias": "dataSource"; "required": false; }; "deferRendering": { "alias": "deferRendering"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "elementAttr": { "alias": "elementAttr"; "required": false; }; "focusStateEnabled": { "alias": "focusStateEnabled"; "required": false; }; "height": { "alias": "height"; "required": false; }; "hint": { "alias": "hint"; "required": false; }; "hoverStateEnabled": { "alias": "hoverStateEnabled"; "required": false; }; "iconPosition": { "alias": "iconPosition"; "required": false; }; "itemHoldTimeout": { "alias": "itemHoldTimeout"; "required": false; }; "items": { "alias": "items"; "required": false; }; "itemTemplate": { "alias": "itemTemplate"; "required": false; }; "itemTitleTemplate": { "alias": "itemTitleTemplate"; "required": false; }; "keyExpr": { "alias": "keyExpr"; "required": false; }; "loop": { "alias": "loop"; "required": false; }; "noDataText": { "alias": "noDataText"; "required": false; }; "onContentReady": { "alias": "onContentReady"; "required": false; }; "onDisposing": { "alias": "onDisposing"; "required": false; }; "onInitialized": { "alias": "onInitialized"; "required": false; }; "onItemClick": { "alias": "onItemClick"; "required": false; }; "onItemContextMenu": { "alias": "onItemContextMenu"; "required": false; }; "onItemHold": { "alias": "onItemHold"; "required": false; }; "onItemRendered": { "alias": "onItemRendered"; "required": false; }; "onOptionChanged": { "alias": "onOptionChanged"; "required": false; }; "onSelectionChanged": { "alias": "onSelectionChanged"; "required": false; }; "onSelectionChanging": { "alias": "onSelectionChanging"; "required": false; }; "onTitleClick": { "alias": "onTitleClick"; "required": false; }; "onTitleHold": { "alias": "onTitleHold"; "required": false; }; "onTitleRendered": { "alias": "onTitleRendered"; "required": false; }; "repaintChangesOnly": { "alias": "repaintChangesOnly"; "required": false; }; "rtlEnabled": { "alias": "rtlEnabled"; "required": false; }; "scrollByContent": { "alias": "scrollByContent"; "required": false; }; "scrollingEnabled": { "alias": "scrollingEnabled"; "required": false; }; "selectedIndex": { "alias": "selectedIndex"; "required": false; }; "selectedItem": { "alias": "selectedItem"; "required": false; }; "showNavButtons": { "alias": "showNavButtons"; "required": false; }; "stylingMode": { "alias": "stylingMode"; "required": false; }; "swipeEnabled": { "alias": "swipeEnabled"; "required": false; }; "tabIndex": { "alias": "tabIndex"; "required": false; }; "tabsPosition": { "alias": "tabsPosition"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, { "itemsChange": "itemsChange"; "selectedIndexChange": "selectedIndexChange"; "selectedItemChange": "selectedItemChange"; }, ["_itemsContentChildren"], never, true, never>;
}
declare class DxoTreeListTabPanelOptionsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTreeListTabPanelOptionsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoTreeListTabPanelOptionsModule, never, [typeof DxoTreeListTabPanelOptionsComponent], [typeof DxoTreeListTabPanelOptionsComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoTreeListTabPanelOptionsModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxiTreeListTabbedItemComponent extends CollectionNestedOption {
    set _tabsContentChildren(value: QueryList<CollectionNestedOption>);
    get colSpan(): number | undefined;
    set colSpan(value: number | undefined);
    get cssClass(): string | undefined;
    set cssClass(value: string | undefined);
    get itemType(): FormItemType;
    set itemType(value: FormItemType);
    get name(): string | undefined;
    set name(value: string | undefined);
    get tabPanelOptions(): dxTabPanelOptions | undefined;
    set tabPanelOptions(value: dxTabPanelOptions | undefined);
    get tabs(): {
        alignItemLabels?: boolean;
        badge?: string | undefined;
        colCount?: number;
        colCountByScreen?: {
            lg?: number | undefined;
            md?: number | undefined;
            sm?: number | undefined;
            xs?: number | undefined;
        };
        disabled?: boolean;
        icon?: string | undefined;
        items?: Array<dxFormButtonItem | dxFormEmptyItem | dxFormGroupItem | dxFormSimpleItem | dxFormTabbedItem>;
        tabTemplate?: any;
        template?: any;
        title?: string | undefined;
    }[];
    set tabs(value: {
        alignItemLabels?: boolean;
        badge?: string | undefined;
        colCount?: number;
        colCountByScreen?: {
            lg?: number | undefined;
            md?: number | undefined;
            sm?: number | undefined;
            xs?: number | undefined;
        };
        disabled?: boolean;
        icon?: string | undefined;
        items?: Array<dxFormButtonItem | dxFormEmptyItem | dxFormGroupItem | dxFormSimpleItem | dxFormTabbedItem>;
        tabTemplate?: any;
        template?: any;
        title?: string | undefined;
    }[]);
    get visible(): boolean;
    set visible(value: boolean);
    get visibleIndex(): number | undefined;
    set visibleIndex(value: number | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiTreeListTabbedItemComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiTreeListTabbedItemComponent, "dxi-tree-list-tabbed-item", never, { "colSpan": { "alias": "colSpan"; "required": false; }; "cssClass": { "alias": "cssClass"; "required": false; }; "itemType": { "alias": "itemType"; "required": false; }; "name": { "alias": "name"; "required": false; }; "tabPanelOptions": { "alias": "tabPanelOptions"; "required": false; }; "tabs": { "alias": "tabs"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "visibleIndex": { "alias": "visibleIndex"; "required": false; }; }, {}, ["_tabsContentChildren"], never, true, never>;
}
declare class DxiTreeListTabbedItemModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiTreeListTabbedItemModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiTreeListTabbedItemModule, never, [typeof DxiTreeListTabbedItemComponent], [typeof DxiTreeListTabbedItemComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiTreeListTabbedItemModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoTreeListTextsComponent extends NestedOption implements OnDestroy, OnInit {
    get addRow(): string;
    set addRow(value: string);
    get addRowToNode(): string;
    set addRowToNode(value: string);
    get cancelAllChanges(): string;
    set cancelAllChanges(value: string);
    get cancelRowChanges(): string;
    set cancelRowChanges(value: string);
    get confirmDeleteMessage(): string;
    set confirmDeleteMessage(value: string);
    get confirmDeleteTitle(): string;
    set confirmDeleteTitle(value: string);
    get deleteRow(): string;
    set deleteRow(value: string);
    get editRow(): string;
    set editRow(value: string);
    get saveAllChanges(): string;
    set saveAllChanges(value: string);
    get saveRowChanges(): string;
    set saveRowChanges(value: string);
    get undeleteRow(): string;
    set undeleteRow(value: string);
    get validationCancelChanges(): string;
    set validationCancelChanges(value: string);
    get fix(): string;
    set fix(value: string);
    get leftPosition(): string;
    set leftPosition(value: string);
    get rightPosition(): string;
    set rightPosition(value: string);
    get stickyPosition(): string;
    set stickyPosition(value: string);
    get unfix(): string;
    set unfix(value: string);
    get clearFilter(): string;
    set clearFilter(value: string);
    get createFilter(): string;
    set createFilter(value: string);
    get filterEnabledHint(): string;
    set filterEnabledHint(value: string);
    get cancel(): string;
    set cancel(value: string);
    get emptyValue(): string;
    set emptyValue(value: string);
    get ok(): string;
    set ok(value: string);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTreeListTextsComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoTreeListTextsComponent, "dxo-tree-list-texts", never, { "addRow": { "alias": "addRow"; "required": false; }; "addRowToNode": { "alias": "addRowToNode"; "required": false; }; "cancelAllChanges": { "alias": "cancelAllChanges"; "required": false; }; "cancelRowChanges": { "alias": "cancelRowChanges"; "required": false; }; "confirmDeleteMessage": { "alias": "confirmDeleteMessage"; "required": false; }; "confirmDeleteTitle": { "alias": "confirmDeleteTitle"; "required": false; }; "deleteRow": { "alias": "deleteRow"; "required": false; }; "editRow": { "alias": "editRow"; "required": false; }; "saveAllChanges": { "alias": "saveAllChanges"; "required": false; }; "saveRowChanges": { "alias": "saveRowChanges"; "required": false; }; "undeleteRow": { "alias": "undeleteRow"; "required": false; }; "validationCancelChanges": { "alias": "validationCancelChanges"; "required": false; }; "fix": { "alias": "fix"; "required": false; }; "leftPosition": { "alias": "leftPosition"; "required": false; }; "rightPosition": { "alias": "rightPosition"; "required": false; }; "stickyPosition": { "alias": "stickyPosition"; "required": false; }; "unfix": { "alias": "unfix"; "required": false; }; "clearFilter": { "alias": "clearFilter"; "required": false; }; "createFilter": { "alias": "createFilter"; "required": false; }; "filterEnabledHint": { "alias": "filterEnabledHint"; "required": false; }; "cancel": { "alias": "cancel"; "required": false; }; "emptyValue": { "alias": "emptyValue"; "required": false; }; "ok": { "alias": "ok"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoTreeListTextsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTreeListTextsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoTreeListTextsModule, never, [typeof DxoTreeListTextsComponent], [typeof DxoTreeListTextsComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoTreeListTextsModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoTreeListToComponent extends NestedOption implements OnDestroy, OnInit {
    get left(): number;
    set left(value: number);
    get opacity(): number;
    set opacity(value: number);
    get position(): PositionConfig;
    set position(value: PositionConfig);
    get scale(): number;
    set scale(value: number);
    get top(): number;
    set top(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTreeListToComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoTreeListToComponent, "dxo-tree-list-to", never, { "left": { "alias": "left"; "required": false; }; "opacity": { "alias": "opacity"; "required": false; }; "position": { "alias": "position"; "required": false; }; "scale": { "alias": "scale"; "required": false; }; "top": { "alias": "top"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoTreeListToModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTreeListToModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoTreeListToModule, never, [typeof DxoTreeListToComponent], [typeof DxoTreeListToComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoTreeListToModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxiTreeListToolbarItemComponent extends CollectionNestedOption implements AfterViewInit, IDxTemplateHost {
    private renderer;
    private document;
    private element;
    get cssClass(): string | undefined;
    set cssClass(value: string | undefined);
    get disabled(): boolean;
    set disabled(value: boolean);
    get html(): string;
    set html(value: string);
    get locateInMenu(): LocateInMenuMode;
    set locateInMenu(value: LocateInMenuMode);
    get location(): ToolbarItemLocation;
    set location(value: ToolbarItemLocation);
    get menuItemTemplate(): any;
    set menuItemTemplate(value: any);
    get options(): any;
    set options(value: any);
    get showText(): ShowTextMode;
    set showText(value: ShowTextMode);
    get template(): any;
    set template(value: any);
    get text(): string;
    set text(value: string);
    get toolbar(): ToolbarLocation;
    set toolbar(value: ToolbarLocation);
    get visible(): boolean;
    set visible(value: boolean);
    get widget(): ToolbarItemComponent;
    set widget(value: ToolbarItemComponent);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost, renderer: Renderer2, document: any, templateHost: DxTemplateHost, element: ElementRef);
    setTemplate(template: DxTemplateDirective): void;
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiTreeListToolbarItemComponent, [{ host: true; skipSelf: true; }, { host: true; }, null, null, { host: true; }, null]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiTreeListToolbarItemComponent, "dxi-tree-list-toolbar-item", never, { "cssClass": { "alias": "cssClass"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "html": { "alias": "html"; "required": false; }; "locateInMenu": { "alias": "locateInMenu"; "required": false; }; "location": { "alias": "location"; "required": false; }; "menuItemTemplate": { "alias": "menuItemTemplate"; "required": false; }; "options": { "alias": "options"; "required": false; }; "showText": { "alias": "showText"; "required": false; }; "template": { "alias": "template"; "required": false; }; "text": { "alias": "text"; "required": false; }; "toolbar": { "alias": "toolbar"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "widget": { "alias": "widget"; "required": false; }; }, {}, never, ["*"], true, never>;
}
declare class DxiTreeListToolbarItemModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiTreeListToolbarItemModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiTreeListToolbarItemModule, never, [typeof DxiTreeListToolbarItemComponent], [typeof DxiTreeListToolbarItemComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiTreeListToolbarItemModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoTreeListToolbarComponent extends NestedOption implements OnDestroy, OnInit {
    set _itemsContentChildren(value: QueryList<CollectionNestedOption>);
    get disabled(): boolean;
    set disabled(value: boolean);
    get items(): Array<dxTreeListToolbarItem | TreeListPredefinedToolbarItem>;
    set items(value: Array<dxTreeListToolbarItem | TreeListPredefinedToolbarItem>);
    get visible(): boolean | undefined;
    set visible(value: boolean | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTreeListToolbarComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoTreeListToolbarComponent, "dxo-tree-list-toolbar", never, { "disabled": { "alias": "disabled"; "required": false; }; "items": { "alias": "items"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; }, {}, ["_itemsContentChildren"], never, true, never>;
}
declare class DxoTreeListToolbarModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTreeListToolbarModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoTreeListToolbarModule, never, [typeof DxoTreeListToolbarComponent], [typeof DxoTreeListToolbarComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoTreeListToolbarModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoTreeListTreeListHeaderFilterSearchComponent extends NestedOption implements OnDestroy, OnInit {
    get editorOptions(): any;
    set editorOptions(value: any);
    get enabled(): boolean;
    set enabled(value: boolean);
    get mode(): SearchMode;
    set mode(value: SearchMode);
    get timeout(): number;
    set timeout(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTreeListTreeListHeaderFilterSearchComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoTreeListTreeListHeaderFilterSearchComponent, "dxo-tree-list-tree-list-header-filter-search", never, { "editorOptions": { "alias": "editorOptions"; "required": false; }; "enabled": { "alias": "enabled"; "required": false; }; "mode": { "alias": "mode"; "required": false; }; "timeout": { "alias": "timeout"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoTreeListTreeListHeaderFilterSearchModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTreeListTreeListHeaderFilterSearchModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoTreeListTreeListHeaderFilterSearchModule, never, [typeof DxoTreeListTreeListHeaderFilterSearchComponent], [typeof DxoTreeListTreeListHeaderFilterSearchComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoTreeListTreeListHeaderFilterSearchModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoTreeListTreeListHeaderFilterTextsComponent extends NestedOption implements OnDestroy, OnInit {
    get cancel(): string;
    set cancel(value: string);
    get emptyValue(): string;
    set emptyValue(value: string);
    get ok(): string;
    set ok(value: string);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTreeListTreeListHeaderFilterTextsComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoTreeListTreeListHeaderFilterTextsComponent, "dxo-tree-list-tree-list-header-filter-texts", never, { "cancel": { "alias": "cancel"; "required": false; }; "emptyValue": { "alias": "emptyValue"; "required": false; }; "ok": { "alias": "ok"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoTreeListTreeListHeaderFilterTextsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTreeListTreeListHeaderFilterTextsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoTreeListTreeListHeaderFilterTextsModule, never, [typeof DxoTreeListTreeListHeaderFilterTextsComponent], [typeof DxoTreeListTreeListHeaderFilterTextsComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoTreeListTreeListHeaderFilterTextsModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoTreeListTreeListHeaderFilterComponent extends NestedOption implements OnDestroy, OnInit {
    get allowSearch(): boolean;
    set allowSearch(value: boolean);
    get allowSelectAll(): boolean;
    set allowSelectAll(value: boolean);
    get height(): number | string;
    set height(value: number | string);
    get search(): HeaderFilterSearchConfig;
    set search(value: HeaderFilterSearchConfig);
    get searchTimeout(): number;
    set searchTimeout(value: number);
    get texts(): HeaderFilterTexts;
    set texts(value: HeaderFilterTexts);
    get visible(): boolean;
    set visible(value: boolean);
    get width(): number | string;
    set width(value: number | string);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTreeListTreeListHeaderFilterComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoTreeListTreeListHeaderFilterComponent, "dxo-tree-list-tree-list-header-filter", never, { "allowSearch": { "alias": "allowSearch"; "required": false; }; "allowSelectAll": { "alias": "allowSelectAll"; "required": false; }; "height": { "alias": "height"; "required": false; }; "search": { "alias": "search"; "required": false; }; "searchTimeout": { "alias": "searchTimeout"; "required": false; }; "texts": { "alias": "texts"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoTreeListTreeListHeaderFilterModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTreeListTreeListHeaderFilterModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoTreeListTreeListHeaderFilterModule, never, [typeof DxoTreeListTreeListHeaderFilterComponent], [typeof DxoTreeListTreeListHeaderFilterComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoTreeListTreeListHeaderFilterModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoTreeListTreeListSelectionComponent extends NestedOption implements OnDestroy, OnInit {
    get allowSelectAll(): boolean;
    set allowSelectAll(value: boolean);
    get mode(): SingleMultipleOrNone;
    set mode(value: SingleMultipleOrNone);
    get recursive(): boolean;
    set recursive(value: boolean);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTreeListTreeListSelectionComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoTreeListTreeListSelectionComponent, "dxo-tree-list-tree-list-selection", never, { "allowSelectAll": { "alias": "allowSelectAll"; "required": false; }; "mode": { "alias": "mode"; "required": false; }; "recursive": { "alias": "recursive"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoTreeListTreeListSelectionModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoTreeListTreeListSelectionModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoTreeListTreeListSelectionModule, never, [typeof DxoTreeListTreeListSelectionComponent], [typeof DxoTreeListTreeListSelectionComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoTreeListTreeListSelectionModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxiTreeListTreeListToolbarItemComponent extends CollectionNestedOption implements AfterViewInit, IDxTemplateHost {
    private renderer;
    private document;
    private element;
    get cssClass(): string | undefined;
    set cssClass(value: string | undefined);
    get disabled(): boolean;
    set disabled(value: boolean);
    get html(): string;
    set html(value: string);
    get locateInMenu(): LocateInMenuMode;
    set locateInMenu(value: LocateInMenuMode);
    get location(): ToolbarItemLocation;
    set location(value: ToolbarItemLocation);
    get menuItemTemplate(): any;
    set menuItemTemplate(value: any);
    get name(): string | TreeListPredefinedToolbarItem;
    set name(value: string | TreeListPredefinedToolbarItem);
    get options(): any;
    set options(value: any);
    get showText(): ShowTextMode;
    set showText(value: ShowTextMode);
    get template(): any;
    set template(value: any);
    get text(): string;
    set text(value: string);
    get visible(): boolean;
    set visible(value: boolean);
    get widget(): ToolbarItemComponent;
    set widget(value: ToolbarItemComponent);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost, renderer: Renderer2, document: any, templateHost: DxTemplateHost, element: ElementRef);
    setTemplate(template: DxTemplateDirective): void;
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiTreeListTreeListToolbarItemComponent, [{ host: true; skipSelf: true; }, { host: true; }, null, null, { host: true; }, null]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiTreeListTreeListToolbarItemComponent, "dxi-tree-list-tree-list-toolbar-item", never, { "cssClass": { "alias": "cssClass"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "html": { "alias": "html"; "required": false; }; "locateInMenu": { "alias": "locateInMenu"; "required": false; }; "location": { "alias": "location"; "required": false; }; "menuItemTemplate": { "alias": "menuItemTemplate"; "required": false; }; "name": { "alias": "name"; "required": false; }; "options": { "alias": "options"; "required": false; }; "showText": { "alias": "showText"; "required": false; }; "template": { "alias": "template"; "required": false; }; "text": { "alias": "text"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "widget": { "alias": "widget"; "required": false; }; }, {}, never, ["*"], true, never>;
}
declare class DxiTreeListTreeListToolbarItemModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiTreeListTreeListToolbarItemModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiTreeListTreeListToolbarItemModule, never, [typeof DxiTreeListTreeListToolbarItemComponent], [typeof DxiTreeListTreeListToolbarItemComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiTreeListTreeListToolbarItemModule>;
}

declare class DxiTreeListValidationRuleComponent extends CollectionNestedOption {
    get message(): string;
    set message(value: string);
    get trim(): boolean;
    set trim(value: boolean);
    get type(): ValidationRuleType;
    set type(value: ValidationRuleType);
    get ignoreEmptyValue(): boolean;
    set ignoreEmptyValue(value: boolean);
    get max(): Date | number | string;
    set max(value: Date | number | string);
    get min(): Date | number | string;
    set min(value: Date | number | string);
    get reevaluate(): boolean;
    set reevaluate(value: boolean);
    get validationCallback(): ((options: {
        column: Record<string, any>;
        data: Record<string, any>;
        formItem: Record<string, any>;
        rule: Record<string, any>;
        validator: Record<string, any>;
        value: any;
    }) => boolean);
    set validationCallback(value: ((options: {
        column: Record<string, any>;
        data: Record<string, any>;
        formItem: Record<string, any>;
        rule: Record<string, any>;
        validator: Record<string, any>;
        value: any;
    }) => boolean));
    get comparisonTarget(): Function;
    set comparisonTarget(value: Function);
    get comparisonType(): ComparisonOperator;
    set comparisonType(value: ComparisonOperator);
    get pattern(): RegExp | string;
    set pattern(value: RegExp | string);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiTreeListValidationRuleComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiTreeListValidationRuleComponent, "dxi-tree-list-validation-rule", never, { "message": { "alias": "message"; "required": false; }; "trim": { "alias": "trim"; "required": false; }; "type": { "alias": "type"; "required": false; }; "ignoreEmptyValue": { "alias": "ignoreEmptyValue"; "required": false; }; "max": { "alias": "max"; "required": false; }; "min": { "alias": "min"; "required": false; }; "reevaluate": { "alias": "reevaluate"; "required": false; }; "validationCallback": { "alias": "validationCallback"; "required": false; }; "comparisonTarget": { "alias": "comparisonTarget"; "required": false; }; "comparisonType": { "alias": "comparisonType"; "required": false; }; "pattern": { "alias": "pattern"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxiTreeListValidationRuleModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiTreeListValidationRuleModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiTreeListValidationRuleModule, never, [typeof DxiTreeListValidationRuleComponent], [typeof DxiTreeListValidationRuleComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiTreeListValidationRuleModule>;
}

export { DxiTreeListAsyncRuleComponent, DxiTreeListAsyncRuleModule, DxiTreeListButtonComponent, DxiTreeListButtonItemComponent, DxiTreeListButtonItemModule, DxiTreeListButtonModule, DxiTreeListChangeComponent, DxiTreeListChangeModule, DxiTreeListColumnButtonComponent, DxiTreeListColumnButtonModule, DxiTreeListColumnComponent, DxiTreeListColumnModule, DxiTreeListCompareRuleComponent, DxiTreeListCompareRuleModule, DxiTreeListCustomOperationComponent, DxiTreeListCustomOperationModule, DxiTreeListCustomRuleComponent, DxiTreeListCustomRuleModule, DxiTreeListEditorOptionsButtonComponent, DxiTreeListEditorOptionsButtonModule, DxiTreeListEmailRuleComponent, DxiTreeListEmailRuleModule, DxiTreeListEmptyItemComponent, DxiTreeListEmptyItemModule, DxiTreeListFieldComponent, DxiTreeListFieldModule, DxiTreeListGroupItemComponent, DxiTreeListGroupItemModule, DxiTreeListItemComponent, DxiTreeListItemModule, DxiTreeListNumericRuleComponent, DxiTreeListNumericRuleModule, DxiTreeListPatternRuleComponent, DxiTreeListPatternRuleModule, DxiTreeListRangeRuleComponent, DxiTreeListRangeRuleModule, DxiTreeListRequiredRuleComponent, DxiTreeListRequiredRuleModule, DxiTreeListSimpleItemComponent, DxiTreeListSimpleItemModule, DxiTreeListStringLengthRuleComponent, DxiTreeListStringLengthRuleModule, DxiTreeListTabComponent, DxiTreeListTabModule, DxiTreeListTabPanelOptionsItemComponent, DxiTreeListTabPanelOptionsItemModule, DxiTreeListTabbedItemComponent, DxiTreeListTabbedItemModule, DxiTreeListToolbarItemComponent, DxiTreeListToolbarItemModule, DxiTreeListTreeListToolbarItemComponent, DxiTreeListTreeListToolbarItemModule, DxiTreeListValidationRuleComponent, DxiTreeListValidationRuleModule, DxoTreeListAIAssistantComponent, DxoTreeListAIAssistantModule, DxoTreeListAIComponent, DxoTreeListAIModule, DxoTreeListAIOptionsComponent, DxoTreeListAIOptionsModule, DxoTreeListAnimationComponent, DxoTreeListAnimationModule, DxoTreeListAtComponent, DxoTreeListAtModule, DxoTreeListBoundaryOffsetComponent, DxoTreeListBoundaryOffsetModule, DxoTreeListButtonOptionsComponent, DxoTreeListButtonOptionsModule, DxoTreeListColCountByScreenComponent, DxoTreeListColCountByScreenModule, DxoTreeListCollisionComponent, DxoTreeListCollisionModule, DxoTreeListColumnChooserComponent, DxoTreeListColumnChooserModule, DxoTreeListColumnChooserSearchComponent, DxoTreeListColumnChooserSearchModule, DxoTreeListColumnChooserSelectionComponent, DxoTreeListColumnChooserSelectionModule, DxoTreeListColumnFixingComponent, DxoTreeListColumnFixingModule, DxoTreeListColumnFixingTextsComponent, DxoTreeListColumnFixingTextsModule, DxoTreeListColumnHeaderFilterComponent, DxoTreeListColumnHeaderFilterModule, DxoTreeListColumnHeaderFilterSearchComponent, DxoTreeListColumnHeaderFilterSearchModule, DxoTreeListColumnLookupComponent, DxoTreeListColumnLookupModule, DxoTreeListCursorOffsetComponent, DxoTreeListCursorOffsetModule, DxoTreeListEditingComponent, DxoTreeListEditingModule, DxoTreeListEditingTextsComponent, DxoTreeListEditingTextsModule, DxoTreeListEditorOptionsComponent, DxoTreeListEditorOptionsModule, DxoTreeListFieldLookupComponent, DxoTreeListFieldLookupModule, DxoTreeListFilterBuilderComponent, DxoTreeListFilterBuilderModule, DxoTreeListFilterBuilderPopupComponent, DxoTreeListFilterBuilderPopupModule, DxoTreeListFilterOperationDescriptionsComponent, DxoTreeListFilterOperationDescriptionsModule, DxoTreeListFilterPanelComponent, DxoTreeListFilterPanelModule, DxoTreeListFilterPanelTextsComponent, DxoTreeListFilterPanelTextsModule, DxoTreeListFilterRowComponent, DxoTreeListFilterRowModule, DxoTreeListFormComponent, DxoTreeListFormItemComponent, DxoTreeListFormItemModule, DxoTreeListFormModule, DxoTreeListFormatComponent, DxoTreeListFormatModule, DxoTreeListFromComponent, DxoTreeListFromModule, DxoTreeListGroupOperationDescriptionsComponent, DxoTreeListGroupOperationDescriptionsModule, DxoTreeListHeaderFilterComponent, DxoTreeListHeaderFilterModule, DxoTreeListHideComponent, DxoTreeListHideModule, DxoTreeListIconsComponent, DxoTreeListIconsModule, DxoTreeListIndicatorOptionsComponent, DxoTreeListIndicatorOptionsModule, DxoTreeListKeyboardNavigationComponent, DxoTreeListKeyboardNavigationModule, DxoTreeListLabelComponent, DxoTreeListLabelModule, DxoTreeListLoadPanelComponent, DxoTreeListLoadPanelModule, DxoTreeListLookupComponent, DxoTreeListLookupModule, DxoTreeListMyComponent, DxoTreeListMyModule, DxoTreeListOffsetComponent, DxoTreeListOffsetModule, DxoTreeListOperationDescriptionsComponent, DxoTreeListOperationDescriptionsModule, DxoTreeListOptionsComponent, DxoTreeListOptionsModule, DxoTreeListPagerComponent, DxoTreeListPagerModule, DxoTreeListPagingComponent, DxoTreeListPagingModule, DxoTreeListPopupComponent, DxoTreeListPopupModule, DxoTreeListPositionComponent, DxoTreeListPositionModule, DxoTreeListRemoteOperationsComponent, DxoTreeListRemoteOperationsModule, DxoTreeListRowDraggingComponent, DxoTreeListRowDraggingModule, DxoTreeListScrollingComponent, DxoTreeListScrollingModule, DxoTreeListSearchComponent, DxoTreeListSearchModule, DxoTreeListSearchPanelComponent, DxoTreeListSearchPanelModule, DxoTreeListSelectionComponent, DxoTreeListSelectionModule, DxoTreeListShowComponent, DxoTreeListShowModule, DxoTreeListSortingComponent, DxoTreeListSortingModule, DxoTreeListStateStoringComponent, DxoTreeListStateStoringModule, DxoTreeListTabPanelOptionsComponent, DxoTreeListTabPanelOptionsModule, DxoTreeListTextsComponent, DxoTreeListTextsModule, DxoTreeListToComponent, DxoTreeListToModule, DxoTreeListToolbarComponent, DxoTreeListToolbarModule, DxoTreeListTreeListHeaderFilterComponent, DxoTreeListTreeListHeaderFilterModule, DxoTreeListTreeListHeaderFilterSearchComponent, DxoTreeListTreeListHeaderFilterSearchModule, DxoTreeListTreeListHeaderFilterTextsComponent, DxoTreeListTreeListHeaderFilterTextsModule, DxoTreeListTreeListSelectionComponent, DxoTreeListTreeListSelectionModule };
//# sourceMappingURL=index.d.ts.map
