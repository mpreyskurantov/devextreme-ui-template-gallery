import * as i0 from '@angular/core';
import { OnDestroy, OnInit, EventEmitter } from '@angular/core';
import { NestedOption, NestedOptionHost } from 'devextreme-angular/core';
import { DashStyle, HatchDirection, Font, TextOverflow, WordWrap } from 'devextreme/common/charts';
import { ExportFormat, Format, HorizontalAlignment, VerticalEdge } from 'devextreme/common';
import { dxSankeyNode, SankeyColorMode } from 'devextreme/viz/sankey';
import { Format as Format$1 } from 'devextreme/common/core/localization';

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoSankeyAdaptiveLayoutComponent extends NestedOption implements OnDestroy, OnInit {
    get height(): number;
    set height(value: number);
    get keepLabels(): boolean;
    set keepLabels(value: boolean);
    get width(): number;
    set width(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoSankeyAdaptiveLayoutComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoSankeyAdaptiveLayoutComponent, "dxo-sankey-adaptive-layout", never, { "height": { "alias": "height"; "required": false; }; "keepLabels": { "alias": "keepLabels"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoSankeyAdaptiveLayoutModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoSankeyAdaptiveLayoutModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoSankeyAdaptiveLayoutModule, never, [typeof DxoSankeyAdaptiveLayoutComponent], [typeof DxoSankeyAdaptiveLayoutComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoSankeyAdaptiveLayoutModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoSankeyBorderComponent extends NestedOption implements OnDestroy, OnInit {
    get color(): string | undefined;
    set color(value: string | undefined);
    get visible(): boolean | undefined;
    set visible(value: boolean | undefined);
    get width(): number | undefined;
    set width(value: number | undefined);
    get dashStyle(): DashStyle;
    set dashStyle(value: DashStyle);
    get opacity(): number | undefined;
    set opacity(value: number | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoSankeyBorderComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoSankeyBorderComponent, "dxo-sankey-border", never, { "color": { "alias": "color"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; "dashStyle": { "alias": "dashStyle"; "required": false; }; "opacity": { "alias": "opacity"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoSankeyBorderModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoSankeyBorderModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoSankeyBorderModule, never, [typeof DxoSankeyBorderComponent], [typeof DxoSankeyBorderComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoSankeyBorderModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoSankeyExportComponent extends NestedOption implements OnDestroy, OnInit {
    get backgroundColor(): string;
    set backgroundColor(value: string);
    get enabled(): boolean;
    set enabled(value: boolean);
    get fileName(): string;
    set fileName(value: string);
    get formats(): Array<ExportFormat>;
    set formats(value: Array<ExportFormat>);
    get margin(): number;
    set margin(value: number);
    get printingEnabled(): boolean;
    set printingEnabled(value: boolean);
    get svgToCanvas(): ((svg: any, canvas: any) => any) | undefined;
    set svgToCanvas(value: ((svg: any, canvas: any) => any) | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoSankeyExportComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoSankeyExportComponent, "dxo-sankey-export", never, { "backgroundColor": { "alias": "backgroundColor"; "required": false; }; "enabled": { "alias": "enabled"; "required": false; }; "fileName": { "alias": "fileName"; "required": false; }; "formats": { "alias": "formats"; "required": false; }; "margin": { "alias": "margin"; "required": false; }; "printingEnabled": { "alias": "printingEnabled"; "required": false; }; "svgToCanvas": { "alias": "svgToCanvas"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoSankeyExportModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoSankeyExportModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoSankeyExportModule, never, [typeof DxoSankeyExportComponent], [typeof DxoSankeyExportComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoSankeyExportModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoSankeyFontComponent extends NestedOption implements OnDestroy, OnInit {
    get color(): string;
    set color(value: string);
    get family(): string;
    set family(value: string);
    get opacity(): number;
    set opacity(value: number);
    get size(): number | string;
    set size(value: number | string);
    get weight(): number;
    set weight(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoSankeyFontComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoSankeyFontComponent, "dxo-sankey-font", never, { "color": { "alias": "color"; "required": false; }; "family": { "alias": "family"; "required": false; }; "opacity": { "alias": "opacity"; "required": false; }; "size": { "alias": "size"; "required": false; }; "weight": { "alias": "weight"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoSankeyFontModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoSankeyFontModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoSankeyFontModule, never, [typeof DxoSankeyFontComponent], [typeof DxoSankeyFontComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoSankeyFontModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoSankeyFormatComponent extends NestedOption implements OnDestroy, OnInit {
    get currency(): string;
    set currency(value: string);
    get formatter(): ((value: number | Date) => string);
    set formatter(value: ((value: number | Date) => string));
    get parser(): ((value: string) => number | Date);
    set parser(value: ((value: string) => number | Date));
    get precision(): number;
    set precision(value: number);
    get type(): Format | string;
    set type(value: Format | string);
    get useCurrencyAccountingStyle(): boolean;
    set useCurrencyAccountingStyle(value: boolean);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoSankeyFormatComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoSankeyFormatComponent, "dxo-sankey-format", never, { "currency": { "alias": "currency"; "required": false; }; "formatter": { "alias": "formatter"; "required": false; }; "parser": { "alias": "parser"; "required": false; }; "precision": { "alias": "precision"; "required": false; }; "type": { "alias": "type"; "required": false; }; "useCurrencyAccountingStyle": { "alias": "useCurrencyAccountingStyle"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoSankeyFormatModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoSankeyFormatModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoSankeyFormatModule, never, [typeof DxoSankeyFormatComponent], [typeof DxoSankeyFormatComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoSankeyFormatModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoSankeyHatchingComponent extends NestedOption implements OnDestroy, OnInit {
    get direction(): HatchDirection;
    set direction(value: HatchDirection);
    get opacity(): number;
    set opacity(value: number);
    get step(): number;
    set step(value: number);
    get width(): number;
    set width(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoSankeyHatchingComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoSankeyHatchingComponent, "dxo-sankey-hatching", never, { "direction": { "alias": "direction"; "required": false; }; "opacity": { "alias": "opacity"; "required": false; }; "step": { "alias": "step"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoSankeyHatchingModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoSankeyHatchingModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoSankeyHatchingModule, never, [typeof DxoSankeyHatchingComponent], [typeof DxoSankeyHatchingComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoSankeyHatchingModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoSankeyHoverStyleComponent extends NestedOption implements OnDestroy, OnInit {
    get border(): {
        color?: string | undefined;
        visible?: boolean | undefined;
        width?: number | undefined;
    };
    set border(value: {
        color?: string | undefined;
        visible?: boolean | undefined;
        width?: number | undefined;
    });
    get color(): string | undefined;
    set color(value: string | undefined);
    get hatching(): {
        direction?: HatchDirection;
        opacity?: number;
        step?: number;
        width?: number;
    };
    set hatching(value: {
        direction?: HatchDirection;
        opacity?: number;
        step?: number;
        width?: number;
    });
    get opacity(): number | undefined;
    set opacity(value: number | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoSankeyHoverStyleComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoSankeyHoverStyleComponent, "dxo-sankey-hover-style", never, { "border": { "alias": "border"; "required": false; }; "color": { "alias": "color"; "required": false; }; "hatching": { "alias": "hatching"; "required": false; }; "opacity": { "alias": "opacity"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoSankeyHoverStyleModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoSankeyHoverStyleModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoSankeyHoverStyleModule, never, [typeof DxoSankeyHoverStyleComponent], [typeof DxoSankeyHoverStyleComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoSankeyHoverStyleModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoSankeyLabelComponent extends NestedOption implements OnDestroy, OnInit {
    get border(): {
        color?: string | undefined;
        visible?: boolean | undefined;
        width?: number | undefined;
    };
    set border(value: {
        color?: string | undefined;
        visible?: boolean | undefined;
        width?: number | undefined;
    });
    get customizeText(): ((itemInfo: dxSankeyNode) => string);
    set customizeText(value: ((itemInfo: dxSankeyNode) => string));
    get font(): Font;
    set font(value: Font);
    get horizontalOffset(): number;
    set horizontalOffset(value: number);
    get overlappingBehavior(): TextOverflow;
    set overlappingBehavior(value: TextOverflow);
    get shadow(): {
        blur?: number;
        color?: string;
        offsetX?: number;
        offsetY?: number;
        opacity?: number;
    };
    set shadow(value: {
        blur?: number;
        color?: string;
        offsetX?: number;
        offsetY?: number;
        opacity?: number;
    });
    get useNodeColors(): boolean;
    set useNodeColors(value: boolean);
    get verticalOffset(): number;
    set verticalOffset(value: number);
    get visible(): boolean;
    set visible(value: boolean);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoSankeyLabelComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoSankeyLabelComponent, "dxo-sankey-label", never, { "border": { "alias": "border"; "required": false; }; "customizeText": { "alias": "customizeText"; "required": false; }; "font": { "alias": "font"; "required": false; }; "horizontalOffset": { "alias": "horizontalOffset"; "required": false; }; "overlappingBehavior": { "alias": "overlappingBehavior"; "required": false; }; "shadow": { "alias": "shadow"; "required": false; }; "useNodeColors": { "alias": "useNodeColors"; "required": false; }; "verticalOffset": { "alias": "verticalOffset"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoSankeyLabelModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoSankeyLabelModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoSankeyLabelModule, never, [typeof DxoSankeyLabelComponent], [typeof DxoSankeyLabelComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoSankeyLabelModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoSankeyLinkComponent extends NestedOption implements OnDestroy, OnInit {
    get border(): {
        color?: string | undefined;
        visible?: boolean | undefined;
        width?: number | undefined;
    };
    set border(value: {
        color?: string | undefined;
        visible?: boolean | undefined;
        width?: number | undefined;
    });
    get color(): string;
    set color(value: string);
    get colorMode(): SankeyColorMode;
    set colorMode(value: SankeyColorMode);
    get hoverStyle(): {
        border?: {
            color?: string | undefined;
            visible?: boolean | undefined;
            width?: number | undefined;
        };
        color?: string | undefined;
        hatching?: {
            direction?: HatchDirection;
            opacity?: number;
            step?: number;
            width?: number;
        };
        opacity?: number | undefined;
    };
    set hoverStyle(value: {
        border?: {
            color?: string | undefined;
            visible?: boolean | undefined;
            width?: number | undefined;
        };
        color?: string | undefined;
        hatching?: {
            direction?: HatchDirection;
            opacity?: number;
            step?: number;
            width?: number;
        };
        opacity?: number | undefined;
    });
    get opacity(): number;
    set opacity(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoSankeyLinkComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoSankeyLinkComponent, "dxo-sankey-link", never, { "border": { "alias": "border"; "required": false; }; "color": { "alias": "color"; "required": false; }; "colorMode": { "alias": "colorMode"; "required": false; }; "hoverStyle": { "alias": "hoverStyle"; "required": false; }; "opacity": { "alias": "opacity"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoSankeyLinkModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoSankeyLinkModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoSankeyLinkModule, never, [typeof DxoSankeyLinkComponent], [typeof DxoSankeyLinkComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoSankeyLinkModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoSankeyLoadingIndicatorComponent extends NestedOption implements OnDestroy, OnInit {
    get backgroundColor(): string;
    set backgroundColor(value: string);
    get enabled(): boolean;
    set enabled(value: boolean);
    get font(): Font;
    set font(value: Font);
    get show(): boolean;
    set show(value: boolean);
    get text(): string;
    set text(value: string);
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    showChange: EventEmitter<boolean>;
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoSankeyLoadingIndicatorComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoSankeyLoadingIndicatorComponent, "dxo-sankey-loading-indicator", never, { "backgroundColor": { "alias": "backgroundColor"; "required": false; }; "enabled": { "alias": "enabled"; "required": false; }; "font": { "alias": "font"; "required": false; }; "show": { "alias": "show"; "required": false; }; "text": { "alias": "text"; "required": false; }; }, { "showChange": "showChange"; }, never, never, true, never>;
}
declare class DxoSankeyLoadingIndicatorModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoSankeyLoadingIndicatorModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoSankeyLoadingIndicatorModule, never, [typeof DxoSankeyLoadingIndicatorComponent], [typeof DxoSankeyLoadingIndicatorComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoSankeyLoadingIndicatorModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoSankeyMarginComponent extends NestedOption implements OnDestroy, OnInit {
    get bottom(): number;
    set bottom(value: number);
    get left(): number;
    set left(value: number);
    get right(): number;
    set right(value: number);
    get top(): number;
    set top(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoSankeyMarginComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoSankeyMarginComponent, "dxo-sankey-margin", never, { "bottom": { "alias": "bottom"; "required": false; }; "left": { "alias": "left"; "required": false; }; "right": { "alias": "right"; "required": false; }; "top": { "alias": "top"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoSankeyMarginModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoSankeyMarginModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoSankeyMarginModule, never, [typeof DxoSankeyMarginComponent], [typeof DxoSankeyMarginComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoSankeyMarginModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoSankeyNodeComponent extends NestedOption implements OnDestroy, OnInit {
    get border(): {
        color?: string | undefined;
        visible?: boolean | undefined;
        width?: number | undefined;
    };
    set border(value: {
        color?: string | undefined;
        visible?: boolean | undefined;
        width?: number | undefined;
    });
    get color(): string | undefined;
    set color(value: string | undefined);
    get hoverStyle(): {
        border?: {
            color?: string | undefined;
            visible?: boolean | undefined;
            width?: number | undefined;
        };
        color?: string | undefined;
        hatching?: {
            direction?: HatchDirection;
            opacity?: number;
            step?: number;
            width?: number;
        };
        opacity?: number | undefined;
    };
    set hoverStyle(value: {
        border?: {
            color?: string | undefined;
            visible?: boolean | undefined;
            width?: number | undefined;
        };
        color?: string | undefined;
        hatching?: {
            direction?: HatchDirection;
            opacity?: number;
            step?: number;
            width?: number;
        };
        opacity?: number | undefined;
    });
    get opacity(): number;
    set opacity(value: number);
    get padding(): number;
    set padding(value: number);
    get width(): number;
    set width(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoSankeyNodeComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoSankeyNodeComponent, "dxo-sankey-node", never, { "border": { "alias": "border"; "required": false; }; "color": { "alias": "color"; "required": false; }; "hoverStyle": { "alias": "hoverStyle"; "required": false; }; "opacity": { "alias": "opacity"; "required": false; }; "padding": { "alias": "padding"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoSankeyNodeModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoSankeyNodeModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoSankeyNodeModule, never, [typeof DxoSankeyNodeComponent], [typeof DxoSankeyNodeComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoSankeyNodeModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoSankeySankeyborderComponent extends NestedOption implements OnDestroy, OnInit {
    get color(): string | undefined;
    set color(value: string | undefined);
    get visible(): boolean | undefined;
    set visible(value: boolean | undefined);
    get width(): number | undefined;
    set width(value: number | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoSankeySankeyborderComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoSankeySankeyborderComponent, "dxo-sankey-sankeyborder", never, { "color": { "alias": "color"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoSankeySankeyborderModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoSankeySankeyborderModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoSankeySankeyborderModule, never, [typeof DxoSankeySankeyborderComponent], [typeof DxoSankeySankeyborderComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoSankeySankeyborderModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoSankeyShadowComponent extends NestedOption implements OnDestroy, OnInit {
    get blur(): number;
    set blur(value: number);
    get color(): string;
    set color(value: string);
    get offsetX(): number;
    set offsetX(value: number);
    get offsetY(): number;
    set offsetY(value: number);
    get opacity(): number;
    set opacity(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoSankeyShadowComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoSankeyShadowComponent, "dxo-sankey-shadow", never, { "blur": { "alias": "blur"; "required": false; }; "color": { "alias": "color"; "required": false; }; "offsetX": { "alias": "offsetX"; "required": false; }; "offsetY": { "alias": "offsetY"; "required": false; }; "opacity": { "alias": "opacity"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoSankeyShadowModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoSankeyShadowModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoSankeyShadowModule, never, [typeof DxoSankeyShadowComponent], [typeof DxoSankeyShadowComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoSankeyShadowModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoSankeySizeComponent extends NestedOption implements OnDestroy, OnInit {
    get height(): number | undefined;
    set height(value: number | undefined);
    get width(): number | undefined;
    set width(value: number | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoSankeySizeComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoSankeySizeComponent, "dxo-sankey-size", never, { "height": { "alias": "height"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoSankeySizeModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoSankeySizeModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoSankeySizeModule, never, [typeof DxoSankeySizeComponent], [typeof DxoSankeySizeComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoSankeySizeModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoSankeySubtitleComponent extends NestedOption implements OnDestroy, OnInit {
    get font(): Font;
    set font(value: Font);
    get offset(): number;
    set offset(value: number);
    get text(): string | undefined;
    set text(value: string | undefined);
    get textOverflow(): TextOverflow;
    set textOverflow(value: TextOverflow);
    get wordWrap(): WordWrap;
    set wordWrap(value: WordWrap);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoSankeySubtitleComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoSankeySubtitleComponent, "dxo-sankey-subtitle", never, { "font": { "alias": "font"; "required": false; }; "offset": { "alias": "offset"; "required": false; }; "text": { "alias": "text"; "required": false; }; "textOverflow": { "alias": "textOverflow"; "required": false; }; "wordWrap": { "alias": "wordWrap"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoSankeySubtitleModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoSankeySubtitleModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoSankeySubtitleModule, never, [typeof DxoSankeySubtitleComponent], [typeof DxoSankeySubtitleComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoSankeySubtitleModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoSankeyTitleComponent extends NestedOption implements OnDestroy, OnInit {
    get font(): Font;
    set font(value: Font);
    get horizontalAlignment(): HorizontalAlignment;
    set horizontalAlignment(value: HorizontalAlignment);
    get margin(): number | {
        bottom?: number;
        left?: number;
        right?: number;
        top?: number;
    };
    set margin(value: number | {
        bottom?: number;
        left?: number;
        right?: number;
        top?: number;
    });
    get placeholderSize(): number | undefined;
    set placeholderSize(value: number | undefined);
    get subtitle(): string | {
        font?: Font;
        offset?: number;
        text?: string | undefined;
        textOverflow?: TextOverflow;
        wordWrap?: WordWrap;
    };
    set subtitle(value: string | {
        font?: Font;
        offset?: number;
        text?: string | undefined;
        textOverflow?: TextOverflow;
        wordWrap?: WordWrap;
    });
    get text(): string | undefined;
    set text(value: string | undefined);
    get textOverflow(): TextOverflow;
    set textOverflow(value: TextOverflow);
    get verticalAlignment(): VerticalEdge;
    set verticalAlignment(value: VerticalEdge);
    get wordWrap(): WordWrap;
    set wordWrap(value: WordWrap);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoSankeyTitleComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoSankeyTitleComponent, "dxo-sankey-title", never, { "font": { "alias": "font"; "required": false; }; "horizontalAlignment": { "alias": "horizontalAlignment"; "required": false; }; "margin": { "alias": "margin"; "required": false; }; "placeholderSize": { "alias": "placeholderSize"; "required": false; }; "subtitle": { "alias": "subtitle"; "required": false; }; "text": { "alias": "text"; "required": false; }; "textOverflow": { "alias": "textOverflow"; "required": false; }; "verticalAlignment": { "alias": "verticalAlignment"; "required": false; }; "wordWrap": { "alias": "wordWrap"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoSankeyTitleModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoSankeyTitleModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoSankeyTitleModule, never, [typeof DxoSankeyTitleComponent], [typeof DxoSankeyTitleComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoSankeyTitleModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoSankeyTooltipBorderComponent extends NestedOption implements OnDestroy, OnInit {
    get color(): string;
    set color(value: string);
    get dashStyle(): DashStyle;
    set dashStyle(value: DashStyle);
    get opacity(): number | undefined;
    set opacity(value: number | undefined);
    get visible(): boolean;
    set visible(value: boolean);
    get width(): number;
    set width(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoSankeyTooltipBorderComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoSankeyTooltipBorderComponent, "dxo-sankey-tooltip-border", never, { "color": { "alias": "color"; "required": false; }; "dashStyle": { "alias": "dashStyle"; "required": false; }; "opacity": { "alias": "opacity"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoSankeyTooltipBorderModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoSankeyTooltipBorderModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoSankeyTooltipBorderModule, never, [typeof DxoSankeyTooltipBorderComponent], [typeof DxoSankeyTooltipBorderComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoSankeyTooltipBorderModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoSankeyTooltipComponent extends NestedOption implements OnDestroy, OnInit {
    get arrowLength(): number;
    set arrowLength(value: number);
    get border(): {
        color?: string;
        dashStyle?: DashStyle;
        opacity?: number | undefined;
        visible?: boolean;
        width?: number;
    };
    set border(value: {
        color?: string;
        dashStyle?: DashStyle;
        opacity?: number | undefined;
        visible?: boolean;
        width?: number;
    });
    get color(): string;
    set color(value: string);
    get container(): any | string | undefined;
    set container(value: any | string | undefined);
    get cornerRadius(): number;
    set cornerRadius(value: number);
    get customizeLinkTooltip(): ((info: {
        source: string;
        target: string;
        weight: number;
    }) => Record<string, any>) | undefined;
    set customizeLinkTooltip(value: ((info: {
        source: string;
        target: string;
        weight: number;
    }) => Record<string, any>) | undefined);
    get customizeNodeTooltip(): ((info: {
        label: string;
        title: string;
        weightIn: number;
        weightOut: number;
    }) => Record<string, any>) | undefined;
    set customizeNodeTooltip(value: ((info: {
        label: string;
        title: string;
        weightIn: number;
        weightOut: number;
    }) => Record<string, any>) | undefined);
    get enabled(): boolean;
    set enabled(value: boolean);
    get font(): Font;
    set font(value: Font);
    get format(): Format$1 | undefined;
    set format(value: Format$1 | undefined);
    get linkTooltipTemplate(): any;
    set linkTooltipTemplate(value: any);
    get nodeTooltipTemplate(): any;
    set nodeTooltipTemplate(value: any);
    get opacity(): number | undefined;
    set opacity(value: number | undefined);
    get paddingLeftRight(): number;
    set paddingLeftRight(value: number);
    get paddingTopBottom(): number;
    set paddingTopBottom(value: number);
    get shadow(): {
        blur?: number;
        color?: string;
        offsetX?: number;
        offsetY?: number;
        opacity?: number;
    };
    set shadow(value: {
        blur?: number;
        color?: string;
        offsetX?: number;
        offsetY?: number;
        opacity?: number;
    });
    get zIndex(): number | undefined;
    set zIndex(value: number | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoSankeyTooltipComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoSankeyTooltipComponent, "dxo-sankey-tooltip", never, { "arrowLength": { "alias": "arrowLength"; "required": false; }; "border": { "alias": "border"; "required": false; }; "color": { "alias": "color"; "required": false; }; "container": { "alias": "container"; "required": false; }; "cornerRadius": { "alias": "cornerRadius"; "required": false; }; "customizeLinkTooltip": { "alias": "customizeLinkTooltip"; "required": false; }; "customizeNodeTooltip": { "alias": "customizeNodeTooltip"; "required": false; }; "enabled": { "alias": "enabled"; "required": false; }; "font": { "alias": "font"; "required": false; }; "format": { "alias": "format"; "required": false; }; "linkTooltipTemplate": { "alias": "linkTooltipTemplate"; "required": false; }; "nodeTooltipTemplate": { "alias": "nodeTooltipTemplate"; "required": false; }; "opacity": { "alias": "opacity"; "required": false; }; "paddingLeftRight": { "alias": "paddingLeftRight"; "required": false; }; "paddingTopBottom": { "alias": "paddingTopBottom"; "required": false; }; "shadow": { "alias": "shadow"; "required": false; }; "zIndex": { "alias": "zIndex"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoSankeyTooltipModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoSankeyTooltipModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoSankeyTooltipModule, never, [typeof DxoSankeyTooltipComponent], [typeof DxoSankeyTooltipComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoSankeyTooltipModule>;
}

export { DxoSankeyAdaptiveLayoutComponent, DxoSankeyAdaptiveLayoutModule, DxoSankeyBorderComponent, DxoSankeyBorderModule, DxoSankeyExportComponent, DxoSankeyExportModule, DxoSankeyFontComponent, DxoSankeyFontModule, DxoSankeyFormatComponent, DxoSankeyFormatModule, DxoSankeyHatchingComponent, DxoSankeyHatchingModule, DxoSankeyHoverStyleComponent, DxoSankeyHoverStyleModule, DxoSankeyLabelComponent, DxoSankeyLabelModule, DxoSankeyLinkComponent, DxoSankeyLinkModule, DxoSankeyLoadingIndicatorComponent, DxoSankeyLoadingIndicatorModule, DxoSankeyMarginComponent, DxoSankeyMarginModule, DxoSankeyNodeComponent, DxoSankeyNodeModule, DxoSankeySankeyborderComponent, DxoSankeySankeyborderModule, DxoSankeyShadowComponent, DxoSankeyShadowModule, DxoSankeySizeComponent, DxoSankeySizeModule, DxoSankeySubtitleComponent, DxoSankeySubtitleModule, DxoSankeyTitleComponent, DxoSankeyTitleModule, DxoSankeyTooltipBorderComponent, DxoSankeyTooltipBorderModule, DxoSankeyTooltipComponent, DxoSankeyTooltipModule };
//# sourceMappingURL=index.d.ts.map
