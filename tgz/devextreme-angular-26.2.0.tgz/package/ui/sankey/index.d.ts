import * as i0 from '@angular/core';
import { OnDestroy, OnChanges, DoCheck, EventEmitter, ElementRef, NgZone, TransferState, SimpleChanges } from '@angular/core';
import { VerticalAlignment, ExportFormat, HorizontalAlignment, VerticalEdge } from 'devextreme/common';
import DataSource, { DataSourceOptions } from 'devextreme/data/data_source';
import { Store } from 'devextreme/data/store';
import DxSankey, { dxSankeyNode, SankeyColorMode, DisposingEvent, DrawnEvent, ExportedEvent, ExportingEvent, FileSavingEvent, IncidentOccurredEvent, InitializedEvent, LinkClickEvent, LinkHoverEvent, NodeClickEvent, NodeHoverEvent, OptionChangedEvent } from 'devextreme/viz/sankey';
import { Font, TextOverflow, HatchDirection, Palette, PaletteExtensionMode, Theme, WordWrap, DashStyle } from 'devextreme/common/charts';
import { Format } from 'devextreme/common/core/localization';
import * as i3 from 'devextreme-angular/core';
import { DxComponent, DxTemplateHost, WatcherHelper, IterableDifferHelper, NestedOptionHost } from 'devextreme-angular/core';
import * as i1 from 'devextreme-angular/ui/nested';
import * as i2 from 'devextreme-angular/ui/sankey/nested';
export * from 'devextreme-angular/ui/sankey/nested';
import * as sankey_types from 'devextreme/viz/sankey_types';
export { sankey_types as DxSankeyTypes };

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

/**
 * [descr:dxSankey]

 */
declare class DxSankeyComponent extends DxComponent implements OnDestroy, OnChanges, DoCheck {
    private _watcherHelper;
    private _idh;
    instance: DxSankey;
    /**
     * [descr:dxSankeyOptions.adaptiveLayout]
    
     */
    get adaptiveLayout(): {
        height?: number;
        keepLabels?: boolean;
        width?: number;
    };
    set adaptiveLayout(value: {
        height?: number;
        keepLabels?: boolean;
        width?: number;
    });
    /**
     * [descr:dxSankeyOptions.alignment]
    
     */
    get alignment(): Array<VerticalAlignment> | VerticalAlignment;
    set alignment(value: Array<VerticalAlignment> | VerticalAlignment);
    /**
     * [descr:dxSankeyOptions.dataSource]
    
     */
    get dataSource(): Array<any> | DataSource | DataSourceOptions | null | Store | string;
    set dataSource(value: Array<any> | DataSource | DataSourceOptions | null | Store | string);
    /**
     * [descr:BaseWidgetOptions.disabled]
    
     */
    get disabled(): boolean;
    set disabled(value: boolean);
    /**
     * [descr:DOMComponentOptions.elementAttr]
    
     */
    get elementAttr(): Record<string, any>;
    set elementAttr(value: Record<string, any>);
    /**
     * [descr:BaseWidgetOptions.encodeHtml]
    
     */
    get encodeHtml(): boolean;
    set encodeHtml(value: boolean);
    /**
     * [descr:BaseWidgetOptions.export]
    
     */
    get export(): {
        backgroundColor?: string;
        enabled?: boolean;
        fileName?: string;
        formats?: Array<ExportFormat>;
        margin?: number;
        printingEnabled?: boolean;
        svgToCanvas?: ((svg: any, canvas: any) => any) | undefined;
    };
    set export(value: {
        backgroundColor?: string;
        enabled?: boolean;
        fileName?: string;
        formats?: Array<ExportFormat>;
        margin?: number;
        printingEnabled?: boolean;
        svgToCanvas?: ((svg: any, canvas: any) => any) | undefined;
    });
    /**
     * [descr:dxSankeyOptions.hoverEnabled]
    
     */
    get hoverEnabled(): boolean;
    set hoverEnabled(value: boolean);
    /**
     * [descr:dxSankeyOptions.label]
    
     */
    get label(): {
        border?: {
            color?: string | undefined;
            visible?: boolean | undefined;
            width?: number | undefined;
        };
        customizeText?: ((itemInfo: dxSankeyNode) => string);
        font?: Font;
        horizontalOffset?: number;
        overlappingBehavior?: TextOverflow;
        shadow?: {
            blur?: number;
            color?: string;
            offsetX?: number;
            offsetY?: number;
            opacity?: number;
        };
        useNodeColors?: boolean;
        verticalOffset?: number;
        visible?: boolean;
    };
    set label(value: {
        border?: {
            color?: string | undefined;
            visible?: boolean | undefined;
            width?: number | undefined;
        };
        customizeText?: ((itemInfo: dxSankeyNode) => string);
        font?: Font;
        horizontalOffset?: number;
        overlappingBehavior?: TextOverflow;
        shadow?: {
            blur?: number;
            color?: string;
            offsetX?: number;
            offsetY?: number;
            opacity?: number;
        };
        useNodeColors?: boolean;
        verticalOffset?: number;
        visible?: boolean;
    });
    /**
     * [descr:dxSankeyOptions.link]
    
     */
    get link(): {
        border?: {
            color?: string | undefined;
            visible?: boolean | undefined;
            width?: number | undefined;
        };
        color?: string;
        colorMode?: SankeyColorMode;
        hoverStyle?: {
            border?: {
                color?: string | undefined;
                visible?: boolean | undefined;
                width?: number | undefined;
            };
            color?: string | undefined;
            hatching?: {
                direction?: HatchDirection;
                opacity?: number;
                step?: number;
                width?: number;
            };
            opacity?: number | undefined;
        };
        opacity?: number;
    };
    set link(value: {
        border?: {
            color?: string | undefined;
            visible?: boolean | undefined;
            width?: number | undefined;
        };
        color?: string;
        colorMode?: SankeyColorMode;
        hoverStyle?: {
            border?: {
                color?: string | undefined;
                visible?: boolean | undefined;
                width?: number | undefined;
            };
            color?: string | undefined;
            hatching?: {
                direction?: HatchDirection;
                opacity?: number;
                step?: number;
                width?: number;
            };
            opacity?: number | undefined;
        };
        opacity?: number;
    });
    /**
     * [descr:BaseWidgetOptions.loadingIndicator]
    
     */
    get loadingIndicator(): {
        backgroundColor?: string;
        enabled?: boolean;
        font?: Font;
        show?: boolean;
        text?: string;
    };
    set loadingIndicator(value: {
        backgroundColor?: string;
        enabled?: boolean;
        font?: Font;
        show?: boolean;
        text?: string;
    });
    /**
     * [descr:BaseWidgetOptions.margin]
    
     */
    get margin(): {
        bottom?: number;
        left?: number;
        right?: number;
        top?: number;
    };
    set margin(value: {
        bottom?: number;
        left?: number;
        right?: number;
        top?: number;
    });
    /**
     * [descr:dxSankeyOptions.node]
    
     */
    get node(): {
        border?: {
            color?: string | undefined;
            visible?: boolean | undefined;
            width?: number | undefined;
        };
        color?: string | undefined;
        hoverStyle?: {
            border?: {
                color?: string | undefined;
                visible?: boolean | undefined;
                width?: number | undefined;
            };
            color?: string | undefined;
            hatching?: {
                direction?: HatchDirection;
                opacity?: number;
                step?: number;
                width?: number;
            };
            opacity?: number | undefined;
        };
        opacity?: number;
        padding?: number;
        width?: number;
    };
    set node(value: {
        border?: {
            color?: string | undefined;
            visible?: boolean | undefined;
            width?: number | undefined;
        };
        color?: string | undefined;
        hoverStyle?: {
            border?: {
                color?: string | undefined;
                visible?: boolean | undefined;
                width?: number | undefined;
            };
            color?: string | undefined;
            hatching?: {
                direction?: HatchDirection;
                opacity?: number;
                step?: number;
                width?: number;
            };
            opacity?: number | undefined;
        };
        opacity?: number;
        padding?: number;
        width?: number;
    });
    /**
     * [descr:dxSankeyOptions.palette]
    
     */
    get palette(): Array<string> | Palette;
    set palette(value: Array<string> | Palette);
    /**
     * [descr:dxSankeyOptions.paletteExtensionMode]
    
     */
    get paletteExtensionMode(): PaletteExtensionMode;
    set paletteExtensionMode(value: PaletteExtensionMode);
    /**
     * [descr:BaseWidgetOptions.pathModified]
    
     */
    get pathModified(): boolean;
    set pathModified(value: boolean);
    /**
     * [descr:BaseWidgetOptions.redrawOnResize]
    
     */
    get redrawOnResize(): boolean;
    set redrawOnResize(value: boolean);
    /**
     * [descr:BaseWidgetOptions.rtlEnabled]
    
     */
    get rtlEnabled(): boolean;
    set rtlEnabled(value: boolean);
    /**
     * [descr:BaseWidgetOptions.size]
    
     */
    get size(): {
        height?: number | undefined;
        width?: number | undefined;
    };
    set size(value: {
        height?: number | undefined;
        width?: number | undefined;
    });
    /**
     * [descr:dxSankeyOptions.sortData]
    
     */
    get sortData(): any | undefined;
    set sortData(value: any | undefined);
    /**
     * [descr:dxSankeyOptions.sourceField]
    
     */
    get sourceField(): string;
    set sourceField(value: string);
    /**
     * [descr:dxSankeyOptions.targetField]
    
     */
    get targetField(): string;
    set targetField(value: string);
    /**
     * [descr:BaseWidgetOptions.theme]
    
     */
    get theme(): Theme;
    set theme(value: Theme);
    /**
     * [descr:BaseWidgetOptions.title]
    
     */
    get title(): string | {
        font?: Font;
        horizontalAlignment?: HorizontalAlignment;
        margin?: number | {
            bottom?: number;
            left?: number;
            right?: number;
            top?: number;
        };
        placeholderSize?: number | undefined;
        subtitle?: string | {
            font?: Font;
            offset?: number;
            text?: string | undefined;
            textOverflow?: TextOverflow;
            wordWrap?: WordWrap;
        };
        text?: string | undefined;
        textOverflow?: TextOverflow;
        verticalAlignment?: VerticalEdge;
        wordWrap?: WordWrap;
    };
    set title(value: string | {
        font?: Font;
        horizontalAlignment?: HorizontalAlignment;
        margin?: number | {
            bottom?: number;
            left?: number;
            right?: number;
            top?: number;
        };
        placeholderSize?: number | undefined;
        subtitle?: string | {
            font?: Font;
            offset?: number;
            text?: string | undefined;
            textOverflow?: TextOverflow;
            wordWrap?: WordWrap;
        };
        text?: string | undefined;
        textOverflow?: TextOverflow;
        verticalAlignment?: VerticalEdge;
        wordWrap?: WordWrap;
    });
    /**
     * [descr:dxSankeyOptions.tooltip]
    
     */
    get tooltip(): {
        arrowLength?: number;
        border?: {
            color?: string;
            dashStyle?: DashStyle;
            opacity?: number | undefined;
            visible?: boolean;
            width?: number;
        };
        color?: string;
        container?: any | string | undefined;
        cornerRadius?: number;
        customizeLinkTooltip?: ((info: {
            source: string;
            target: string;
            weight: number;
        }) => Record<string, any>) | undefined;
        customizeNodeTooltip?: ((info: {
            label: string;
            title: string;
            weightIn: number;
            weightOut: number;
        }) => Record<string, any>) | undefined;
        enabled?: boolean;
        font?: Font;
        format?: Format | undefined;
        linkTooltipTemplate?: any;
        nodeTooltipTemplate?: any;
        opacity?: number | undefined;
        paddingLeftRight?: number;
        paddingTopBottom?: number;
        shadow?: {
            blur?: number;
            color?: string;
            offsetX?: number;
            offsetY?: number;
            opacity?: number;
        };
        zIndex?: number | undefined;
    };
    set tooltip(value: {
        arrowLength?: number;
        border?: {
            color?: string;
            dashStyle?: DashStyle;
            opacity?: number | undefined;
            visible?: boolean;
            width?: number;
        };
        color?: string;
        container?: any | string | undefined;
        cornerRadius?: number;
        customizeLinkTooltip?: ((info: {
            source: string;
            target: string;
            weight: number;
        }) => Record<string, any>) | undefined;
        customizeNodeTooltip?: ((info: {
            label: string;
            title: string;
            weightIn: number;
            weightOut: number;
        }) => Record<string, any>) | undefined;
        enabled?: boolean;
        font?: Font;
        format?: Format | undefined;
        linkTooltipTemplate?: any;
        nodeTooltipTemplate?: any;
        opacity?: number | undefined;
        paddingLeftRight?: number;
        paddingTopBottom?: number;
        shadow?: {
            blur?: number;
            color?: string;
            offsetX?: number;
            offsetY?: number;
            opacity?: number;
        };
        zIndex?: number | undefined;
    });
    /**
     * [descr:dxSankeyOptions.weightField]
    
     */
    get weightField(): string;
    set weightField(value: string);
    /**
    
     * [descr:dxSankeyOptions.onDisposing]
    
    
     */
    onDisposing: EventEmitter<DisposingEvent>;
    /**
    
     * [descr:dxSankeyOptions.onDrawn]
    
    
     */
    onDrawn: EventEmitter<DrawnEvent>;
    /**
    
     * [descr:dxSankeyOptions.onExported]
    
    
     */
    onExported: EventEmitter<ExportedEvent>;
    /**
    
     * [descr:dxSankeyOptions.onExporting]
    
    
     */
    onExporting: EventEmitter<ExportingEvent>;
    /**
    
     * [descr:dxSankeyOptions.onFileSaving]
    
    
     */
    onFileSaving: EventEmitter<FileSavingEvent>;
    /**
    
     * [descr:dxSankeyOptions.onIncidentOccurred]
    
    
     */
    onIncidentOccurred: EventEmitter<IncidentOccurredEvent>;
    /**
    
     * [descr:dxSankeyOptions.onInitialized]
    
    
     */
    onInitialized: EventEmitter<InitializedEvent>;
    /**
    
     * [descr:dxSankeyOptions.onLinkClick]
    
    
     */
    onLinkClick: EventEmitter<LinkClickEvent>;
    /**
    
     * [descr:dxSankeyOptions.onLinkHoverChanged]
    
    
     */
    onLinkHoverChanged: EventEmitter<LinkHoverEvent>;
    /**
    
     * [descr:dxSankeyOptions.onNodeClick]
    
    
     */
    onNodeClick: EventEmitter<NodeClickEvent>;
    /**
    
     * [descr:dxSankeyOptions.onNodeHoverChanged]
    
    
     */
    onNodeHoverChanged: EventEmitter<NodeHoverEvent>;
    /**
    
     * [descr:dxSankeyOptions.onOptionChanged]
    
    
     */
    onOptionChanged: EventEmitter<OptionChangedEvent>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    adaptiveLayoutChange: EventEmitter<{
        height?: number;
        keepLabels?: boolean;
        width?: number;
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    alignmentChange: EventEmitter<Array<VerticalAlignment> | VerticalAlignment>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    dataSourceChange: EventEmitter<Array<any> | DataSource | DataSourceOptions | null | Store | string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    disabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    elementAttrChange: EventEmitter<Record<string, any>>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    encodeHtmlChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    exportChange: EventEmitter<{
        backgroundColor?: string;
        enabled?: boolean;
        fileName?: string;
        formats?: Array<ExportFormat>;
        margin?: number;
        printingEnabled?: boolean;
        svgToCanvas?: ((svg: any, canvas: any) => any) | undefined;
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    hoverEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    labelChange: EventEmitter<{
        border?: {
            color?: string | undefined;
            visible?: boolean | undefined;
            width?: number | undefined;
        };
        customizeText?: ((itemInfo: dxSankeyNode) => string);
        font?: Font;
        horizontalOffset?: number;
        overlappingBehavior?: TextOverflow;
        shadow?: {
            blur?: number;
            color?: string;
            offsetX?: number;
            offsetY?: number;
            opacity?: number;
        };
        useNodeColors?: boolean;
        verticalOffset?: number;
        visible?: boolean;
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    linkChange: EventEmitter<{
        border?: {
            color?: string | undefined;
            visible?: boolean | undefined;
            width?: number | undefined;
        };
        color?: string;
        colorMode?: SankeyColorMode;
        hoverStyle?: {
            border?: {
                color?: string | undefined;
                visible?: boolean | undefined;
                width?: number | undefined;
            };
            color?: string | undefined;
            hatching?: {
                direction?: HatchDirection;
                opacity?: number;
                step?: number;
                width?: number;
            };
            opacity?: number | undefined;
        };
        opacity?: number;
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    loadingIndicatorChange: EventEmitter<{
        backgroundColor?: string;
        enabled?: boolean;
        font?: Font;
        show?: boolean;
        text?: string;
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    marginChange: EventEmitter<{
        bottom?: number;
        left?: number;
        right?: number;
        top?: number;
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    nodeChange: EventEmitter<{
        border?: {
            color?: string | undefined;
            visible?: boolean | undefined;
            width?: number | undefined;
        };
        color?: string | undefined;
        hoverStyle?: {
            border?: {
                color?: string | undefined;
                visible?: boolean | undefined;
                width?: number | undefined;
            };
            color?: string | undefined;
            hatching?: {
                direction?: HatchDirection;
                opacity?: number;
                step?: number;
                width?: number;
            };
            opacity?: number | undefined;
        };
        opacity?: number;
        padding?: number;
        width?: number;
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    paletteChange: EventEmitter<Array<string> | Palette>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    paletteExtensionModeChange: EventEmitter<PaletteExtensionMode>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    pathModifiedChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    redrawOnResizeChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    rtlEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    sizeChange: EventEmitter<{
        height?: number | undefined;
        width?: number | undefined;
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    sortDataChange: EventEmitter<any | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    sourceFieldChange: EventEmitter<string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    targetFieldChange: EventEmitter<string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    themeChange: EventEmitter<Theme>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    titleChange: EventEmitter<string | {
        font?: Font;
        horizontalAlignment?: HorizontalAlignment;
        margin?: number | {
            bottom?: number;
            left?: number;
            right?: number;
            top?: number;
        };
        placeholderSize?: number | undefined;
        subtitle?: string | {
            font?: Font;
            offset?: number;
            text?: string | undefined;
            textOverflow?: TextOverflow;
            wordWrap?: WordWrap;
        };
        text?: string | undefined;
        textOverflow?: TextOverflow;
        verticalAlignment?: VerticalEdge;
        wordWrap?: WordWrap;
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    tooltipChange: EventEmitter<{
        arrowLength?: number;
        border?: {
            color?: string;
            dashStyle?: DashStyle;
            opacity?: number | undefined;
            visible?: boolean;
            width?: number;
        };
        color?: string;
        container?: any | string | undefined;
        cornerRadius?: number;
        customizeLinkTooltip?: ((info: {
            source: string;
            target: string;
            weight: number;
        }) => Record<string, any>) | undefined;
        customizeNodeTooltip?: ((info: {
            label: string;
            title: string;
            weightIn: number;
            weightOut: number;
        }) => Record<string, any>) | undefined;
        enabled?: boolean;
        font?: Font;
        format?: Format | undefined;
        linkTooltipTemplate?: any;
        nodeTooltipTemplate?: any;
        opacity?: number | undefined;
        paddingLeftRight?: number;
        paddingTopBottom?: number;
        shadow?: {
            blur?: number;
            color?: string;
            offsetX?: number;
            offsetY?: number;
            opacity?: number;
        };
        zIndex?: number | undefined;
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    weightFieldChange: EventEmitter<string>;
    constructor(elementRef: ElementRef, ngZone: NgZone, templateHost: DxTemplateHost, _watcherHelper: WatcherHelper, _idh: IterableDifferHelper, optionHost: NestedOptionHost, transferState: TransferState, platformId: any);
    protected _createInstance(element: any, options: any): DxSankey;
    ngOnDestroy(): void;
    ngOnChanges(changes: SimpleChanges): void;
    setupChanges(prop: string, changes: SimpleChanges): void;
    ngDoCheck(): void;
    _setOption(name: string, value: any): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxSankeyComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxSankeyComponent, "dx-sankey", never, { "adaptiveLayout": { "alias": "adaptiveLayout"; "required": false; }; "alignment": { "alias": "alignment"; "required": false; }; "dataSource": { "alias": "dataSource"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "elementAttr": { "alias": "elementAttr"; "required": false; }; "encodeHtml": { "alias": "encodeHtml"; "required": false; }; "export": { "alias": "export"; "required": false; }; "hoverEnabled": { "alias": "hoverEnabled"; "required": false; }; "label": { "alias": "label"; "required": false; }; "link": { "alias": "link"; "required": false; }; "loadingIndicator": { "alias": "loadingIndicator"; "required": false; }; "margin": { "alias": "margin"; "required": false; }; "node": { "alias": "node"; "required": false; }; "palette": { "alias": "palette"; "required": false; }; "paletteExtensionMode": { "alias": "paletteExtensionMode"; "required": false; }; "pathModified": { "alias": "pathModified"; "required": false; }; "redrawOnResize": { "alias": "redrawOnResize"; "required": false; }; "rtlEnabled": { "alias": "rtlEnabled"; "required": false; }; "size": { "alias": "size"; "required": false; }; "sortData": { "alias": "sortData"; "required": false; }; "sourceField": { "alias": "sourceField"; "required": false; }; "targetField": { "alias": "targetField"; "required": false; }; "theme": { "alias": "theme"; "required": false; }; "title": { "alias": "title"; "required": false; }; "tooltip": { "alias": "tooltip"; "required": false; }; "weightField": { "alias": "weightField"; "required": false; }; }, { "onDisposing": "onDisposing"; "onDrawn": "onDrawn"; "onExported": "onExported"; "onExporting": "onExporting"; "onFileSaving": "onFileSaving"; "onIncidentOccurred": "onIncidentOccurred"; "onInitialized": "onInitialized"; "onLinkClick": "onLinkClick"; "onLinkHoverChanged": "onLinkHoverChanged"; "onNodeClick": "onNodeClick"; "onNodeHoverChanged": "onNodeHoverChanged"; "onOptionChanged": "onOptionChanged"; "adaptiveLayoutChange": "adaptiveLayoutChange"; "alignmentChange": "alignmentChange"; "dataSourceChange": "dataSourceChange"; "disabledChange": "disabledChange"; "elementAttrChange": "elementAttrChange"; "encodeHtmlChange": "encodeHtmlChange"; "exportChange": "exportChange"; "hoverEnabledChange": "hoverEnabledChange"; "labelChange": "labelChange"; "linkChange": "linkChange"; "loadingIndicatorChange": "loadingIndicatorChange"; "marginChange": "marginChange"; "nodeChange": "nodeChange"; "paletteChange": "paletteChange"; "paletteExtensionModeChange": "paletteExtensionModeChange"; "pathModifiedChange": "pathModifiedChange"; "redrawOnResizeChange": "redrawOnResizeChange"; "rtlEnabledChange": "rtlEnabledChange"; "sizeChange": "sizeChange"; "sortDataChange": "sortDataChange"; "sourceFieldChange": "sourceFieldChange"; "targetFieldChange": "targetFieldChange"; "themeChange": "themeChange"; "titleChange": "titleChange"; "tooltipChange": "tooltipChange"; "weightFieldChange": "weightFieldChange"; }, never, never, true, never>;
}
declare class DxSankeyModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxSankeyModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxSankeyModule, never, [typeof DxSankeyComponent, typeof i1.DxoAdaptiveLayoutModule, typeof i1.DxoExportModule, typeof i1.DxoLabelModule, typeof i1.DxoBorderModule, typeof i1.DxoFontModule, typeof i1.DxoShadowModule, typeof i1.DxoLinkModule, typeof i1.DxoHoverStyleModule, typeof i1.DxoHatchingModule, typeof i1.DxoLoadingIndicatorModule, typeof i1.DxoMarginModule, typeof i1.DxoNodeModule, typeof i1.DxoSizeModule, typeof i1.DxoTitleModule, typeof i1.DxoSubtitleModule, typeof i1.DxoTooltipModule, typeof i1.DxoFormatModule, typeof i2.DxoSankeyAdaptiveLayoutModule, typeof i2.DxoSankeyBorderModule, typeof i2.DxoSankeyExportModule, typeof i2.DxoSankeyFontModule, typeof i2.DxoSankeyFormatModule, typeof i2.DxoSankeyHatchingModule, typeof i2.DxoSankeyHoverStyleModule, typeof i2.DxoSankeyLabelModule, typeof i2.DxoSankeyLinkModule, typeof i2.DxoSankeyLoadingIndicatorModule, typeof i2.DxoSankeyMarginModule, typeof i2.DxoSankeyNodeModule, typeof i2.DxoSankeySankeyborderModule, typeof i2.DxoSankeyShadowModule, typeof i2.DxoSankeySizeModule, typeof i2.DxoSankeySubtitleModule, typeof i2.DxoSankeyTitleModule, typeof i2.DxoSankeyTooltipModule, typeof i2.DxoSankeyTooltipBorderModule, typeof i3.DxIntegrationModule, typeof i3.DxTemplateModule], [typeof DxSankeyComponent, typeof i1.DxoAdaptiveLayoutModule, typeof i1.DxoExportModule, typeof i1.DxoLabelModule, typeof i1.DxoBorderModule, typeof i1.DxoFontModule, typeof i1.DxoShadowModule, typeof i1.DxoLinkModule, typeof i1.DxoHoverStyleModule, typeof i1.DxoHatchingModule, typeof i1.DxoLoadingIndicatorModule, typeof i1.DxoMarginModule, typeof i1.DxoNodeModule, typeof i1.DxoSizeModule, typeof i1.DxoTitleModule, typeof i1.DxoSubtitleModule, typeof i1.DxoTooltipModule, typeof i1.DxoFormatModule, typeof i2.DxoSankeyAdaptiveLayoutModule, typeof i2.DxoSankeyBorderModule, typeof i2.DxoSankeyExportModule, typeof i2.DxoSankeyFontModule, typeof i2.DxoSankeyFormatModule, typeof i2.DxoSankeyHatchingModule, typeof i2.DxoSankeyHoverStyleModule, typeof i2.DxoSankeyLabelModule, typeof i2.DxoSankeyLinkModule, typeof i2.DxoSankeyLoadingIndicatorModule, typeof i2.DxoSankeyMarginModule, typeof i2.DxoSankeyNodeModule, typeof i2.DxoSankeySankeyborderModule, typeof i2.DxoSankeyShadowModule, typeof i2.DxoSankeySizeModule, typeof i2.DxoSankeySubtitleModule, typeof i2.DxoSankeyTitleModule, typeof i2.DxoSankeyTooltipModule, typeof i2.DxoSankeyTooltipBorderModule, typeof i3.DxTemplateModule]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxSankeyModule>;
}

export { DxSankeyComponent, DxSankeyModule };
//# sourceMappingURL=index.d.ts.map
