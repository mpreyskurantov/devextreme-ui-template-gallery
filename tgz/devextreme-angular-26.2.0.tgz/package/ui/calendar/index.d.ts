import * as i0 from '@angular/core';
import { OnDestroy, OnChanges, DoCheck, EventEmitter, ElementRef, NgZone, TransferState, SimpleChanges } from '@angular/core';
import DxCalendar, { DisabledDate, CalendarZoomLevel, CalendarSelectionMode, WeekNumberRule, DisposingEvent, InitializedEvent, OptionChangedEvent, ValueChangedEvent } from 'devextreme/ui/calendar';
import { DayOfWeek, ValidationMessageMode, Position, ValidationStatus } from 'devextreme/common';
import { ControlValueAccessor } from '@angular/forms';
import * as i1 from 'devextreme-angular/core';
import { DxComponent, DxTemplateHost, WatcherHelper, IterableDifferHelper, NestedOptionHost } from 'devextreme-angular/core';
import * as calendar_types from 'devextreme/ui/calendar_types';
export { calendar_types as DxCalendarTypes };

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

/**
 * [descr:dxCalendar]

 */
declare class DxCalendarComponent extends DxComponent implements OnDestroy, ControlValueAccessor, OnChanges, DoCheck {
    private _watcherHelper;
    private _idh;
    instance: DxCalendar;
    /**
     * [descr:WidgetOptions.accessKey]
    
     */
    get accessKey(): string | undefined;
    set accessKey(value: string | undefined);
    /**
     * [descr:dxCalendarOptions.activeStateEnabled]
    
     */
    get activeStateEnabled(): boolean;
    set activeStateEnabled(value: boolean);
    /**
     * [descr:dxCalendarOptions.cellTemplate]
    
     */
    get cellTemplate(): any;
    set cellTemplate(value: any);
    /**
     * [descr:dxCalendarOptions.dateSerializationFormat]
    
     */
    get dateSerializationFormat(): string | undefined;
    set dateSerializationFormat(value: string | undefined);
    /**
     * [descr:WidgetOptions.disabled]
    
     */
    get disabled(): boolean;
    set disabled(value: boolean);
    /**
     * [descr:dxCalendarOptions.disabledDates]
    
     */
    get disabledDates(): Array<Date> | ((data: DisabledDate) => boolean) | null;
    set disabledDates(value: Array<Date> | ((data: DisabledDate) => boolean) | null);
    /**
     * [descr:DOMComponentOptions.elementAttr]
    
     */
    get elementAttr(): Record<string, any>;
    set elementAttr(value: Record<string, any>);
    /**
     * [descr:dxCalendarOptions.firstDayOfWeek]
    
     */
    get firstDayOfWeek(): DayOfWeek | undefined;
    set firstDayOfWeek(value: DayOfWeek | undefined);
    /**
     * [descr:dxCalendarOptions.focusStateEnabled]
    
     */
    get focusStateEnabled(): boolean;
    set focusStateEnabled(value: boolean);
    /**
     * [descr:DOMComponentOptions.height]
    
     */
    get height(): number | string | undefined;
    set height(value: number | string | undefined);
    /**
     * [descr:WidgetOptions.hint]
    
     */
    get hint(): string | undefined;
    set hint(value: string | undefined);
    /**
     * [descr:dxCalendarOptions.hoverStateEnabled]
    
     */
    get hoverStateEnabled(): boolean;
    set hoverStateEnabled(value: boolean);
    /**
     * [descr:EditorOptions.isDirty]
    
     */
    get isDirty(): boolean;
    set isDirty(value: boolean);
    /**
     * [descr:EditorOptions.isValid]
    
     */
    get isValid(): boolean;
    set isValid(value: boolean);
    /**
     * [descr:dxCalendarOptions.max]
    
     */
    get max(): Date | null | number | string;
    set max(value: Date | null | number | string);
    /**
     * [descr:dxCalendarOptions.maxZoomLevel]
    
     */
    get maxZoomLevel(): CalendarZoomLevel;
    set maxZoomLevel(value: CalendarZoomLevel);
    /**
     * [descr:dxCalendarOptions.min]
    
     */
    get min(): Date | null | number | string;
    set min(value: Date | null | number | string);
    /**
     * [descr:dxCalendarOptions.minZoomLevel]
    
     */
    get minZoomLevel(): CalendarZoomLevel;
    set minZoomLevel(value: CalendarZoomLevel);
    /**
     * [descr:dxCalendarOptions.name]
    
     */
    get name(): string;
    set name(value: string);
    /**
     * [descr:EditorOptions.readOnly]
    
     */
    get readOnly(): boolean;
    set readOnly(value: boolean);
    /**
     * [descr:DOMComponentOptions.rtlEnabled]
    
     */
    get rtlEnabled(): boolean;
    set rtlEnabled(value: boolean);
    /**
     * [descr:dxCalendarOptions.selectionMode]
    
     */
    get selectionMode(): CalendarSelectionMode;
    set selectionMode(value: CalendarSelectionMode);
    /**
     * [descr:dxCalendarOptions.selectWeekOnClick]
    
     */
    get selectWeekOnClick(): boolean;
    set selectWeekOnClick(value: boolean);
    /**
     * [descr:dxCalendarOptions.showTodayButton]
    
     */
    get showTodayButton(): boolean;
    set showTodayButton(value: boolean);
    /**
     * [descr:dxCalendarOptions.showWeekNumbers]
    
     */
    get showWeekNumbers(): boolean;
    set showWeekNumbers(value: boolean);
    /**
     * [descr:WidgetOptions.tabIndex]
    
     */
    get tabIndex(): number;
    set tabIndex(value: number);
    get todayButtonText(): string;
    set todayButtonText(value: string);
    /**
     * [descr:EditorOptions.validationError]
    
     */
    get validationError(): any | null;
    set validationError(value: any | null);
    /**
     * [descr:EditorOptions.validationErrors]
    
     */
    get validationErrors(): Array<any> | null;
    set validationErrors(value: Array<any> | null);
    /**
     * [descr:EditorOptions.validationMessageMode]
    
     */
    get validationMessageMode(): ValidationMessageMode;
    set validationMessageMode(value: ValidationMessageMode);
    /**
     * [descr:EditorOptions.validationMessagePosition]
    
     */
    get validationMessagePosition(): Position;
    set validationMessagePosition(value: Position);
    /**
     * [descr:EditorOptions.validationStatus]
    
     */
    get validationStatus(): ValidationStatus;
    set validationStatus(value: ValidationStatus);
    /**
     * [descr:dxCalendarOptions.value]
    
     */
    get value(): Array<Date | null | number | string> | Date | null | number | string;
    set value(value: Array<Date | null | number | string> | Date | null | number | string);
    /**
     * [descr:WidgetOptions.visible]
    
     */
    get visible(): boolean;
    set visible(value: boolean);
    /**
     * [descr:dxCalendarOptions.weekNumberRule]
    
     */
    get weekNumberRule(): WeekNumberRule;
    set weekNumberRule(value: WeekNumberRule);
    /**
     * [descr:DOMComponentOptions.width]
    
     */
    get width(): number | string | undefined;
    set width(value: number | string | undefined);
    /**
     * [descr:dxCalendarOptions.zoomLevel]
    
     */
    get zoomLevel(): CalendarZoomLevel;
    set zoomLevel(value: CalendarZoomLevel);
    /**
    
     * [descr:dxCalendarOptions.onDisposing]
    
    
     */
    onDisposing: EventEmitter<DisposingEvent>;
    /**
    
     * [descr:dxCalendarOptions.onInitialized]
    
    
     */
    onInitialized: EventEmitter<InitializedEvent>;
    /**
    
     * [descr:dxCalendarOptions.onOptionChanged]
    
    
     */
    onOptionChanged: EventEmitter<OptionChangedEvent>;
    /**
    
     * [descr:dxCalendarOptions.onValueChanged]
    
    
     */
    onValueChanged: EventEmitter<ValueChangedEvent>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    accessKeyChange: EventEmitter<string | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    activeStateEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    cellTemplateChange: EventEmitter<any>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    dateSerializationFormatChange: EventEmitter<string | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    disabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    disabledDatesChange: EventEmitter<Array<Date> | ((data: DisabledDate) => boolean) | null>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    elementAttrChange: EventEmitter<Record<string, any>>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    firstDayOfWeekChange: EventEmitter<DayOfWeek | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    focusStateEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    heightChange: EventEmitter<number | string | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    hintChange: EventEmitter<string | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    hoverStateEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    isDirtyChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    isValidChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    maxChange: EventEmitter<Date | null | number | string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    maxZoomLevelChange: EventEmitter<CalendarZoomLevel>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    minChange: EventEmitter<Date | null | number | string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    minZoomLevelChange: EventEmitter<CalendarZoomLevel>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    nameChange: EventEmitter<string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    readOnlyChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    rtlEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    selectionModeChange: EventEmitter<CalendarSelectionMode>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    selectWeekOnClickChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    showTodayButtonChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    showWeekNumbersChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    tabIndexChange: EventEmitter<number>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    todayButtonTextChange: EventEmitter<string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    validationErrorChange: EventEmitter<any | null>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    validationErrorsChange: EventEmitter<Array<any> | null>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    validationMessageModeChange: EventEmitter<ValidationMessageMode>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    validationMessagePositionChange: EventEmitter<Position>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    validationStatusChange: EventEmitter<ValidationStatus>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    valueChange: EventEmitter<Array<Date | null | number | string> | Date | null | number | string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    visibleChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    weekNumberRuleChange: EventEmitter<WeekNumberRule>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    widthChange: EventEmitter<number | string | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    zoomLevelChange: EventEmitter<CalendarZoomLevel>;
    /**
    
     * [descr:undefined]
    
    
     */
    onBlur: EventEmitter<any>;
    change(_: any): void;
    touched: (_: any) => void;
    constructor(elementRef: ElementRef, ngZone: NgZone, templateHost: DxTemplateHost, _watcherHelper: WatcherHelper, _idh: IterableDifferHelper, optionHost: NestedOptionHost, transferState: TransferState, platformId: any);
    protected _createInstance(element: any, options: any): DxCalendar;
    writeValue(value: any): void;
    setDisabledState(isDisabled: boolean): void;
    registerOnChange(fn: (_: any) => void): void;
    registerOnTouched(fn: () => void): void;
    _createWidget(element: any): void;
    ngOnDestroy(): void;
    ngOnChanges(changes: SimpleChanges): void;
    setupChanges(prop: string, changes: SimpleChanges): void;
    ngDoCheck(): void;
    _setOption(name: string, value: any): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxCalendarComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxCalendarComponent, "dx-calendar", never, { "accessKey": { "alias": "accessKey"; "required": false; }; "activeStateEnabled": { "alias": "activeStateEnabled"; "required": false; }; "cellTemplate": { "alias": "cellTemplate"; "required": false; }; "dateSerializationFormat": { "alias": "dateSerializationFormat"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "disabledDates": { "alias": "disabledDates"; "required": false; }; "elementAttr": { "alias": "elementAttr"; "required": false; }; "firstDayOfWeek": { "alias": "firstDayOfWeek"; "required": false; }; "focusStateEnabled": { "alias": "focusStateEnabled"; "required": false; }; "height": { "alias": "height"; "required": false; }; "hint": { "alias": "hint"; "required": false; }; "hoverStateEnabled": { "alias": "hoverStateEnabled"; "required": false; }; "isDirty": { "alias": "isDirty"; "required": false; }; "isValid": { "alias": "isValid"; "required": false; }; "max": { "alias": "max"; "required": false; }; "maxZoomLevel": { "alias": "maxZoomLevel"; "required": false; }; "min": { "alias": "min"; "required": false; }; "minZoomLevel": { "alias": "minZoomLevel"; "required": false; }; "name": { "alias": "name"; "required": false; }; "readOnly": { "alias": "readOnly"; "required": false; }; "rtlEnabled": { "alias": "rtlEnabled"; "required": false; }; "selectionMode": { "alias": "selectionMode"; "required": false; }; "selectWeekOnClick": { "alias": "selectWeekOnClick"; "required": false; }; "showTodayButton": { "alias": "showTodayButton"; "required": false; }; "showWeekNumbers": { "alias": "showWeekNumbers"; "required": false; }; "tabIndex": { "alias": "tabIndex"; "required": false; }; "todayButtonText": { "alias": "todayButtonText"; "required": false; }; "validationError": { "alias": "validationError"; "required": false; }; "validationErrors": { "alias": "validationErrors"; "required": false; }; "validationMessageMode": { "alias": "validationMessageMode"; "required": false; }; "validationMessagePosition": { "alias": "validationMessagePosition"; "required": false; }; "validationStatus": { "alias": "validationStatus"; "required": false; }; "value": { "alias": "value"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "weekNumberRule": { "alias": "weekNumberRule"; "required": false; }; "width": { "alias": "width"; "required": false; }; "zoomLevel": { "alias": "zoomLevel"; "required": false; }; }, { "onDisposing": "onDisposing"; "onInitialized": "onInitialized"; "onOptionChanged": "onOptionChanged"; "onValueChanged": "onValueChanged"; "accessKeyChange": "accessKeyChange"; "activeStateEnabledChange": "activeStateEnabledChange"; "cellTemplateChange": "cellTemplateChange"; "dateSerializationFormatChange": "dateSerializationFormatChange"; "disabledChange": "disabledChange"; "disabledDatesChange": "disabledDatesChange"; "elementAttrChange": "elementAttrChange"; "firstDayOfWeekChange": "firstDayOfWeekChange"; "focusStateEnabledChange": "focusStateEnabledChange"; "heightChange": "heightChange"; "hintChange": "hintChange"; "hoverStateEnabledChange": "hoverStateEnabledChange"; "isDirtyChange": "isDirtyChange"; "isValidChange": "isValidChange"; "maxChange": "maxChange"; "maxZoomLevelChange": "maxZoomLevelChange"; "minChange": "minChange"; "minZoomLevelChange": "minZoomLevelChange"; "nameChange": "nameChange"; "readOnlyChange": "readOnlyChange"; "rtlEnabledChange": "rtlEnabledChange"; "selectionModeChange": "selectionModeChange"; "selectWeekOnClickChange": "selectWeekOnClickChange"; "showTodayButtonChange": "showTodayButtonChange"; "showWeekNumbersChange": "showWeekNumbersChange"; "tabIndexChange": "tabIndexChange"; "todayButtonTextChange": "todayButtonTextChange"; "validationErrorChange": "validationErrorChange"; "validationErrorsChange": "validationErrorsChange"; "validationMessageModeChange": "validationMessageModeChange"; "validationMessagePositionChange": "validationMessagePositionChange"; "validationStatusChange": "validationStatusChange"; "valueChange": "valueChange"; "visibleChange": "visibleChange"; "weekNumberRuleChange": "weekNumberRuleChange"; "widthChange": "widthChange"; "zoomLevelChange": "zoomLevelChange"; "onBlur": "onBlur"; }, never, never, true, never>;
}
declare class DxCalendarModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxCalendarModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxCalendarModule, never, [typeof DxCalendarComponent, typeof i1.DxIntegrationModule, typeof i1.DxTemplateModule], [typeof DxCalendarComponent, typeof i1.DxTemplateModule]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxCalendarModule>;
}

export { DxCalendarComponent, DxCalendarModule };
//# sourceMappingURL=index.d.ts.map
