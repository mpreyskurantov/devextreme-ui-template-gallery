import { HorizontalAlignment, DataType, SortOrder, ToolbarItemLocation, ToolbarItemComponent } from 'devextreme/common';
import { CollectionNestedOption, NestedOptionHost, NestedOption } from 'devextreme-angular/core';
import * as i0 from '@angular/core';
import { QueryList, OnDestroy, OnInit } from '@angular/core';
import { dxFileManagerContextMenuItem, FileManagerPredefinedContextMenuItem, dxFileManagerDetailsColumn, FileManagerPredefinedToolbarItem, FileManagerItemViewMode, dxFileManagerToolbarItem } from 'devextreme/ui/file_manager';
import { LocateInMenuMode, ShowTextMode } from 'devextreme/ui/toolbar';

declare class DxiFileManagerColumnComponent extends CollectionNestedOption {
    get alignment(): HorizontalAlignment | undefined;
    set alignment(value: HorizontalAlignment | undefined);
    get caption(): string | undefined;
    set caption(value: string | undefined);
    get cssClass(): string | undefined;
    set cssClass(value: string | undefined);
    get dataField(): string | undefined;
    set dataField(value: string | undefined);
    get dataType(): DataType | undefined;
    set dataType(value: DataType | undefined);
    get hidingPriority(): number | undefined;
    set hidingPriority(value: number | undefined);
    get sortIndex(): number | undefined;
    set sortIndex(value: number | undefined);
    get sortOrder(): SortOrder | undefined;
    set sortOrder(value: SortOrder | undefined);
    get visible(): boolean;
    set visible(value: boolean);
    get visibleIndex(): number | undefined;
    set visibleIndex(value: number | undefined);
    get width(): number | string | undefined;
    set width(value: number | string | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiFileManagerColumnComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiFileManagerColumnComponent, "dxi-file-manager-column", never, { "alignment": { "alias": "alignment"; "required": false; }; "caption": { "alias": "caption"; "required": false; }; "cssClass": { "alias": "cssClass"; "required": false; }; "dataField": { "alias": "dataField"; "required": false; }; "dataType": { "alias": "dataType"; "required": false; }; "hidingPriority": { "alias": "hidingPriority"; "required": false; }; "sortIndex": { "alias": "sortIndex"; "required": false; }; "sortOrder": { "alias": "sortOrder"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "visibleIndex": { "alias": "visibleIndex"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxiFileManagerColumnModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiFileManagerColumnModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiFileManagerColumnModule, never, [typeof DxiFileManagerColumnComponent], [typeof DxiFileManagerColumnComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiFileManagerColumnModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxiFileManagerContextMenuItemComponent extends CollectionNestedOption {
    set _itemsContentChildren(value: QueryList<CollectionNestedOption>);
    get beginGroup(): boolean;
    set beginGroup(value: boolean);
    get closeMenuOnClick(): boolean;
    set closeMenuOnClick(value: boolean);
    get disabled(): boolean;
    set disabled(value: boolean);
    get icon(): string;
    set icon(value: string);
    get items(): Array<dxFileManagerContextMenuItem>;
    set items(value: Array<dxFileManagerContextMenuItem>);
    get name(): FileManagerPredefinedContextMenuItem | string;
    set name(value: FileManagerPredefinedContextMenuItem | string);
    get selectable(): boolean;
    set selectable(value: boolean);
    get selected(): boolean;
    set selected(value: boolean);
    get text(): string;
    set text(value: string);
    get visible(): boolean | undefined;
    set visible(value: boolean | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiFileManagerContextMenuItemComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiFileManagerContextMenuItemComponent, "dxi-file-manager-context-menu-item", never, { "beginGroup": { "alias": "beginGroup"; "required": false; }; "closeMenuOnClick": { "alias": "closeMenuOnClick"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "icon": { "alias": "icon"; "required": false; }; "items": { "alias": "items"; "required": false; }; "name": { "alias": "name"; "required": false; }; "selectable": { "alias": "selectable"; "required": false; }; "selected": { "alias": "selected"; "required": false; }; "text": { "alias": "text"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; }, {}, ["_itemsContentChildren"], never, true, never>;
}
declare class DxiFileManagerContextMenuItemModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiFileManagerContextMenuItemModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiFileManagerContextMenuItemModule, never, [typeof DxiFileManagerContextMenuItemComponent], [typeof DxiFileManagerContextMenuItemComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiFileManagerContextMenuItemModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoFileManagerContextMenuComponent extends NestedOption implements OnDestroy, OnInit {
    set _itemsContentChildren(value: QueryList<CollectionNestedOption>);
    get items(): Array<dxFileManagerContextMenuItem | FileManagerPredefinedContextMenuItem>;
    set items(value: Array<dxFileManagerContextMenuItem | FileManagerPredefinedContextMenuItem>);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoFileManagerContextMenuComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoFileManagerContextMenuComponent, "dxo-file-manager-context-menu", never, { "items": { "alias": "items"; "required": false; }; }, {}, ["_itemsContentChildren"], never, true, never>;
}
declare class DxoFileManagerContextMenuModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoFileManagerContextMenuModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoFileManagerContextMenuModule, never, [typeof DxoFileManagerContextMenuComponent], [typeof DxoFileManagerContextMenuComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoFileManagerContextMenuModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoFileManagerDetailsComponent extends NestedOption implements OnDestroy, OnInit {
    set _columnsContentChildren(value: QueryList<CollectionNestedOption>);
    get columns(): Array<dxFileManagerDetailsColumn | string>;
    set columns(value: Array<dxFileManagerDetailsColumn | string>);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoFileManagerDetailsComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoFileManagerDetailsComponent, "dxo-file-manager-details", never, { "columns": { "alias": "columns"; "required": false; }; }, {}, ["_columnsContentChildren"], never, true, never>;
}
declare class DxoFileManagerDetailsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoFileManagerDetailsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoFileManagerDetailsModule, never, [typeof DxoFileManagerDetailsComponent], [typeof DxoFileManagerDetailsComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoFileManagerDetailsModule>;
}

declare class DxiFileManagerFileSelectionItemComponent extends CollectionNestedOption {
    get cssClass(): string | undefined;
    set cssClass(value: string | undefined);
    get disabled(): boolean;
    set disabled(value: boolean);
    get icon(): string;
    set icon(value: string);
    get locateInMenu(): LocateInMenuMode;
    set locateInMenu(value: LocateInMenuMode);
    get location(): ToolbarItemLocation;
    set location(value: ToolbarItemLocation);
    get name(): FileManagerPredefinedToolbarItem | string;
    set name(value: FileManagerPredefinedToolbarItem | string);
    get options(): any;
    set options(value: any);
    get showText(): ShowTextMode;
    set showText(value: ShowTextMode);
    get text(): string;
    set text(value: string);
    get visible(): boolean | undefined;
    set visible(value: boolean | undefined);
    get widget(): ToolbarItemComponent;
    set widget(value: ToolbarItemComponent);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiFileManagerFileSelectionItemComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiFileManagerFileSelectionItemComponent, "dxi-file-manager-file-selection-item", never, { "cssClass": { "alias": "cssClass"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "icon": { "alias": "icon"; "required": false; }; "locateInMenu": { "alias": "locateInMenu"; "required": false; }; "location": { "alias": "location"; "required": false; }; "name": { "alias": "name"; "required": false; }; "options": { "alias": "options"; "required": false; }; "showText": { "alias": "showText"; "required": false; }; "text": { "alias": "text"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "widget": { "alias": "widget"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxiFileManagerFileSelectionItemModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiFileManagerFileSelectionItemModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiFileManagerFileSelectionItemModule, never, [typeof DxiFileManagerFileSelectionItemComponent], [typeof DxiFileManagerFileSelectionItemComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiFileManagerFileSelectionItemModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxiFileManagerItemComponent extends CollectionNestedOption {
    set _itemsContentChildren(value: QueryList<CollectionNestedOption>);
    get beginGroup(): boolean;
    set beginGroup(value: boolean);
    get closeMenuOnClick(): boolean;
    set closeMenuOnClick(value: boolean);
    get disabled(): boolean;
    set disabled(value: boolean);
    get icon(): string;
    set icon(value: string);
    get items(): Array<dxFileManagerContextMenuItem>;
    set items(value: Array<dxFileManagerContextMenuItem>);
    get name(): FileManagerPredefinedContextMenuItem | string | FileManagerPredefinedToolbarItem;
    set name(value: FileManagerPredefinedContextMenuItem | string | FileManagerPredefinedToolbarItem);
    get selectable(): boolean;
    set selectable(value: boolean);
    get selected(): boolean;
    set selected(value: boolean);
    get text(): string;
    set text(value: string);
    get visible(): boolean | undefined;
    set visible(value: boolean | undefined);
    get cssClass(): string | undefined;
    set cssClass(value: string | undefined);
    get locateInMenu(): LocateInMenuMode;
    set locateInMenu(value: LocateInMenuMode);
    get location(): ToolbarItemLocation;
    set location(value: ToolbarItemLocation);
    get options(): any;
    set options(value: any);
    get showText(): ShowTextMode;
    set showText(value: ShowTextMode);
    get widget(): ToolbarItemComponent;
    set widget(value: ToolbarItemComponent);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiFileManagerItemComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiFileManagerItemComponent, "dxi-file-manager-item", never, { "beginGroup": { "alias": "beginGroup"; "required": false; }; "closeMenuOnClick": { "alias": "closeMenuOnClick"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "icon": { "alias": "icon"; "required": false; }; "items": { "alias": "items"; "required": false; }; "name": { "alias": "name"; "required": false; }; "selectable": { "alias": "selectable"; "required": false; }; "selected": { "alias": "selected"; "required": false; }; "text": { "alias": "text"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "cssClass": { "alias": "cssClass"; "required": false; }; "locateInMenu": { "alias": "locateInMenu"; "required": false; }; "location": { "alias": "location"; "required": false; }; "options": { "alias": "options"; "required": false; }; "showText": { "alias": "showText"; "required": false; }; "widget": { "alias": "widget"; "required": false; }; }, {}, ["_itemsContentChildren"], never, true, never>;
}
declare class DxiFileManagerItemModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiFileManagerItemModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiFileManagerItemModule, never, [typeof DxiFileManagerItemComponent], [typeof DxiFileManagerItemComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiFileManagerItemModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoFileManagerItemViewComponent extends NestedOption implements OnDestroy, OnInit {
    get details(): {
        columns?: Array<dxFileManagerDetailsColumn | string>;
    };
    set details(value: {
        columns?: Array<dxFileManagerDetailsColumn | string>;
    });
    get mode(): FileManagerItemViewMode;
    set mode(value: FileManagerItemViewMode);
    get showFolders(): boolean;
    set showFolders(value: boolean);
    get showParentFolder(): boolean;
    set showParentFolder(value: boolean);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoFileManagerItemViewComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoFileManagerItemViewComponent, "dxo-file-manager-item-view", never, { "details": { "alias": "details"; "required": false; }; "mode": { "alias": "mode"; "required": false; }; "showFolders": { "alias": "showFolders"; "required": false; }; "showParentFolder": { "alias": "showParentFolder"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoFileManagerItemViewModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoFileManagerItemViewModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoFileManagerItemViewModule, never, [typeof DxoFileManagerItemViewComponent], [typeof DxoFileManagerItemViewComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoFileManagerItemViewModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoFileManagerNotificationsComponent extends NestedOption implements OnDestroy, OnInit {
    get showPanel(): boolean;
    set showPanel(value: boolean);
    get showPopup(): boolean;
    set showPopup(value: boolean);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoFileManagerNotificationsComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoFileManagerNotificationsComponent, "dxo-file-manager-notifications", never, { "showPanel": { "alias": "showPanel"; "required": false; }; "showPopup": { "alias": "showPopup"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoFileManagerNotificationsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoFileManagerNotificationsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoFileManagerNotificationsModule, never, [typeof DxoFileManagerNotificationsComponent], [typeof DxoFileManagerNotificationsComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoFileManagerNotificationsModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoFileManagerPermissionsComponent extends NestedOption implements OnDestroy, OnInit {
    get copy(): boolean;
    set copy(value: boolean);
    get create(): boolean;
    set create(value: boolean);
    get delete(): boolean;
    set delete(value: boolean);
    get download(): boolean;
    set download(value: boolean);
    get move(): boolean;
    set move(value: boolean);
    get rename(): boolean;
    set rename(value: boolean);
    get upload(): boolean;
    set upload(value: boolean);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoFileManagerPermissionsComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoFileManagerPermissionsComponent, "dxo-file-manager-permissions", never, { "copy": { "alias": "copy"; "required": false; }; "create": { "alias": "create"; "required": false; }; "delete": { "alias": "delete"; "required": false; }; "download": { "alias": "download"; "required": false; }; "move": { "alias": "move"; "required": false; }; "rename": { "alias": "rename"; "required": false; }; "upload": { "alias": "upload"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoFileManagerPermissionsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoFileManagerPermissionsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoFileManagerPermissionsModule, never, [typeof DxoFileManagerPermissionsComponent], [typeof DxoFileManagerPermissionsComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoFileManagerPermissionsModule>;
}

declare class DxiFileManagerToolbarItemComponent extends CollectionNestedOption {
    get cssClass(): string | undefined;
    set cssClass(value: string | undefined);
    get disabled(): boolean;
    set disabled(value: boolean);
    get icon(): string;
    set icon(value: string);
    get locateInMenu(): LocateInMenuMode;
    set locateInMenu(value: LocateInMenuMode);
    get location(): ToolbarItemLocation;
    set location(value: ToolbarItemLocation);
    get name(): FileManagerPredefinedToolbarItem | string;
    set name(value: FileManagerPredefinedToolbarItem | string);
    get options(): any;
    set options(value: any);
    get showText(): ShowTextMode;
    set showText(value: ShowTextMode);
    get text(): string;
    set text(value: string);
    get visible(): boolean | undefined;
    set visible(value: boolean | undefined);
    get widget(): ToolbarItemComponent;
    set widget(value: ToolbarItemComponent);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiFileManagerToolbarItemComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiFileManagerToolbarItemComponent, "dxi-file-manager-toolbar-item", never, { "cssClass": { "alias": "cssClass"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "icon": { "alias": "icon"; "required": false; }; "locateInMenu": { "alias": "locateInMenu"; "required": false; }; "location": { "alias": "location"; "required": false; }; "name": { "alias": "name"; "required": false; }; "options": { "alias": "options"; "required": false; }; "showText": { "alias": "showText"; "required": false; }; "text": { "alias": "text"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "widget": { "alias": "widget"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxiFileManagerToolbarItemModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiFileManagerToolbarItemModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiFileManagerToolbarItemModule, never, [typeof DxiFileManagerToolbarItemComponent], [typeof DxiFileManagerToolbarItemComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiFileManagerToolbarItemModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoFileManagerToolbarComponent extends NestedOption implements OnDestroy, OnInit {
    set _fileSelectionItemsContentChildren(value: QueryList<CollectionNestedOption>);
    set _itemsContentChildren(value: QueryList<CollectionNestedOption>);
    get fileSelectionItems(): Array<dxFileManagerToolbarItem | FileManagerPredefinedToolbarItem>;
    set fileSelectionItems(value: Array<dxFileManagerToolbarItem | FileManagerPredefinedToolbarItem>);
    get items(): Array<dxFileManagerToolbarItem | FileManagerPredefinedToolbarItem>;
    set items(value: Array<dxFileManagerToolbarItem | FileManagerPredefinedToolbarItem>);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoFileManagerToolbarComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoFileManagerToolbarComponent, "dxo-file-manager-toolbar", never, { "fileSelectionItems": { "alias": "fileSelectionItems"; "required": false; }; "items": { "alias": "items"; "required": false; }; }, {}, ["_fileSelectionItemsContentChildren", "_itemsContentChildren"], never, true, never>;
}
declare class DxoFileManagerToolbarModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoFileManagerToolbarModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoFileManagerToolbarModule, never, [typeof DxoFileManagerToolbarComponent], [typeof DxoFileManagerToolbarComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoFileManagerToolbarModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoFileManagerUploadComponent extends NestedOption implements OnDestroy, OnInit {
    get chunkSize(): number;
    set chunkSize(value: number);
    get maxFileSize(): number;
    set maxFileSize(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoFileManagerUploadComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoFileManagerUploadComponent, "dxo-file-manager-upload", never, { "chunkSize": { "alias": "chunkSize"; "required": false; }; "maxFileSize": { "alias": "maxFileSize"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoFileManagerUploadModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoFileManagerUploadModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoFileManagerUploadModule, never, [typeof DxoFileManagerUploadComponent], [typeof DxoFileManagerUploadComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoFileManagerUploadModule>;
}

export { DxiFileManagerColumnComponent, DxiFileManagerColumnModule, DxiFileManagerContextMenuItemComponent, DxiFileManagerContextMenuItemModule, DxiFileManagerFileSelectionItemComponent, DxiFileManagerFileSelectionItemModule, DxiFileManagerItemComponent, DxiFileManagerItemModule, DxiFileManagerToolbarItemComponent, DxiFileManagerToolbarItemModule, DxoFileManagerContextMenuComponent, DxoFileManagerContextMenuModule, DxoFileManagerDetailsComponent, DxoFileManagerDetailsModule, DxoFileManagerItemViewComponent, DxoFileManagerItemViewModule, DxoFileManagerNotificationsComponent, DxoFileManagerNotificationsModule, DxoFileManagerPermissionsComponent, DxoFileManagerPermissionsModule, DxoFileManagerToolbarComponent, DxoFileManagerToolbarModule, DxoFileManagerUploadComponent, DxoFileManagerUploadModule };
//# sourceMappingURL=index.d.ts.map
