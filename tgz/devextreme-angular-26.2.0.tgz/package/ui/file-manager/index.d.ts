import * as i0 from '@angular/core';
import { OnDestroy, OnChanges, DoCheck, QueryList, EventEmitter, ElementRef, NgZone, TransferState, SimpleChanges } from '@angular/core';
import FileSystemItem from 'devextreme/file_management/file_system_item';
import DxFileManager, { dxFileManagerContextMenu, dxFileManagerDetailsColumn, FileManagerItemViewMode, dxFileManagerToolbar, ContentReadyEvent, ContextMenuItemClickEvent, ContextMenuShowingEvent, CurrentDirectoryChangedEvent, DirectoryCreatedEvent, DirectoryCreatingEvent, DisposingEvent, ErrorOccurredEvent, FileUploadedEvent, FileUploadingEvent, FocusedItemChangedEvent, InitializedEvent, ItemCopiedEvent, ItemCopyingEvent, ItemDeletedEvent, ItemDeletingEvent, ItemDownloadingEvent, ItemMovedEvent, ItemMovingEvent, ItemRenamedEvent, ItemRenamingEvent, OptionChangedEvent, SelectedFileOpenedEvent, SelectionChangedEvent, ToolbarItemClickEvent } from 'devextreme/ui/file_manager';
import { SingleOrMultiple } from 'devextreme/common';
import * as i3 from 'devextreme-angular/core';
import { DxComponent, CollectionNestedOption, DxTemplateHost, WatcherHelper, IterableDifferHelper, NestedOptionHost } from 'devextreme-angular/core';
import * as i1 from 'devextreme-angular/ui/nested';
import * as i2 from 'devextreme-angular/ui/file-manager/nested';
export * from 'devextreme-angular/ui/file-manager/nested';
import * as file_manager_types from 'devextreme/ui/file_manager_types';
export { file_manager_types as DxFileManagerTypes };

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

/**
 * [descr:dxFileManager]

 */
declare class DxFileManagerComponent extends DxComponent implements OnDestroy, OnChanges, DoCheck {
    private _watcherHelper;
    private _idh;
    set _columnsContentChildren(value: QueryList<CollectionNestedOption>);
    set _itemsContentChildren(value: QueryList<CollectionNestedOption>);
    set _fileSelectionItemsContentChildren(value: QueryList<CollectionNestedOption>);
    instance: DxFileManager;
    /**
     * [descr:WidgetOptions.accessKey]
    
     */
    get accessKey(): string | undefined;
    set accessKey(value: string | undefined);
    /**
     * [descr:WidgetOptions.activeStateEnabled]
    
     */
    get activeStateEnabled(): boolean;
    set activeStateEnabled(value: boolean);
    /**
     * [descr:dxFileManagerOptions.allowedFileExtensions]
    
     */
    get allowedFileExtensions(): Array<string>;
    set allowedFileExtensions(value: Array<string>);
    /**
     * [descr:dxFileManagerOptions.contextMenu]
    
     */
    get contextMenu(): dxFileManagerContextMenu;
    set contextMenu(value: dxFileManagerContextMenu);
    /**
     * [descr:dxFileManagerOptions.currentPath]
    
     */
    get currentPath(): string;
    set currentPath(value: string);
    /**
     * [descr:dxFileManagerOptions.currentPathKeys]
    
     */
    get currentPathKeys(): Array<string>;
    set currentPathKeys(value: Array<string>);
    /**
     * [descr:dxFileManagerOptions.customizeDetailColumns]
    
     */
    get customizeDetailColumns(): ((columns: Array<dxFileManagerDetailsColumn>) => Array<dxFileManagerDetailsColumn>);
    set customizeDetailColumns(value: ((columns: Array<dxFileManagerDetailsColumn>) => Array<dxFileManagerDetailsColumn>));
    /**
     * [descr:dxFileManagerOptions.customizeThumbnail]
    
     */
    get customizeThumbnail(): ((fileSystemItem: FileSystemItem) => string);
    set customizeThumbnail(value: ((fileSystemItem: FileSystemItem) => string));
    /**
     * [descr:WidgetOptions.disabled]
    
     */
    get disabled(): boolean;
    set disabled(value: boolean);
    /**
     * [descr:DOMComponentOptions.elementAttr]
    
     */
    get elementAttr(): Record<string, any>;
    set elementAttr(value: Record<string, any>);
    /**
     * [descr:dxFileManagerOptions.fileSystemProvider]
    
     */
    get fileSystemProvider(): any | null;
    set fileSystemProvider(value: any | null);
    /**
     * [descr:dxFileManagerOptions.focusedItemKey]
    
     */
    get focusedItemKey(): string | undefined;
    set focusedItemKey(value: string | undefined);
    /**
     * [descr:WidgetOptions.focusStateEnabled]
    
     */
    get focusStateEnabled(): boolean;
    set focusStateEnabled(value: boolean);
    /**
     * [descr:DOMComponentOptions.height]
    
     */
    get height(): number | string | undefined;
    set height(value: number | string | undefined);
    /**
     * [descr:WidgetOptions.hint]
    
     */
    get hint(): string | undefined;
    set hint(value: string | undefined);
    /**
     * [descr:WidgetOptions.hoverStateEnabled]
    
     */
    get hoverStateEnabled(): boolean;
    set hoverStateEnabled(value: boolean);
    /**
     * [descr:dxFileManagerOptions.itemView]
    
     */
    get itemView(): {
        details?: {
            columns?: Array<dxFileManagerDetailsColumn | string>;
        };
        mode?: FileManagerItemViewMode;
        showFolders?: boolean;
        showParentFolder?: boolean;
    };
    set itemView(value: {
        details?: {
            columns?: Array<dxFileManagerDetailsColumn | string>;
        };
        mode?: FileManagerItemViewMode;
        showFolders?: boolean;
        showParentFolder?: boolean;
    });
    /**
     * [descr:dxFileManagerOptions.notifications]
    
     */
    get notifications(): {
        showPanel?: boolean;
        showPopup?: boolean;
    };
    set notifications(value: {
        showPanel?: boolean;
        showPopup?: boolean;
    });
    /**
     * [descr:dxFileManagerOptions.permissions]
    
     */
    get permissions(): {
        copy?: boolean;
        create?: boolean;
        delete?: boolean;
        download?: boolean;
        move?: boolean;
        rename?: boolean;
        upload?: boolean;
    };
    set permissions(value: {
        copy?: boolean;
        create?: boolean;
        delete?: boolean;
        download?: boolean;
        move?: boolean;
        rename?: boolean;
        upload?: boolean;
    });
    /**
     * [descr:dxFileManagerOptions.rootFolderName]
    
     */
    get rootFolderName(): string;
    set rootFolderName(value: string);
    /**
     * [descr:DOMComponentOptions.rtlEnabled]
    
     */
    get rtlEnabled(): boolean;
    set rtlEnabled(value: boolean);
    /**
     * [descr:dxFileManagerOptions.selectedItemKeys]
    
     */
    get selectedItemKeys(): Array<string>;
    set selectedItemKeys(value: Array<string>);
    /**
     * [descr:dxFileManagerOptions.selectionMode]
    
     */
    get selectionMode(): SingleOrMultiple;
    set selectionMode(value: SingleOrMultiple);
    /**
     * [descr:WidgetOptions.tabIndex]
    
     */
    get tabIndex(): number;
    set tabIndex(value: number);
    /**
     * [descr:dxFileManagerOptions.toolbar]
    
     */
    get toolbar(): dxFileManagerToolbar;
    set toolbar(value: dxFileManagerToolbar);
    /**
     * [descr:dxFileManagerOptions.upload]
    
     */
    get upload(): {
        chunkSize?: number;
        maxFileSize?: number;
    };
    set upload(value: {
        chunkSize?: number;
        maxFileSize?: number;
    });
    /**
     * [descr:WidgetOptions.visible]
    
     */
    get visible(): boolean;
    set visible(value: boolean);
    /**
     * [descr:DOMComponentOptions.width]
    
     */
    get width(): number | string | undefined;
    set width(value: number | string | undefined);
    /**
    
     * [descr:dxFileManagerOptions.onContentReady]
    
    
     */
    onContentReady: EventEmitter<ContentReadyEvent>;
    /**
    
     * [descr:dxFileManagerOptions.onContextMenuItemClick]
    
    
     */
    onContextMenuItemClick: EventEmitter<ContextMenuItemClickEvent>;
    /**
    
     * [descr:dxFileManagerOptions.onContextMenuShowing]
    
    
     */
    onContextMenuShowing: EventEmitter<ContextMenuShowingEvent>;
    /**
    
     * [descr:dxFileManagerOptions.onCurrentDirectoryChanged]
    
    
     */
    onCurrentDirectoryChanged: EventEmitter<CurrentDirectoryChangedEvent>;
    /**
    
     * [descr:dxFileManagerOptions.onDirectoryCreated]
    
    
     */
    onDirectoryCreated: EventEmitter<DirectoryCreatedEvent>;
    /**
    
     * [descr:dxFileManagerOptions.onDirectoryCreating]
    
    
     */
    onDirectoryCreating: EventEmitter<DirectoryCreatingEvent>;
    /**
    
     * [descr:dxFileManagerOptions.onDisposing]
    
    
     */
    onDisposing: EventEmitter<DisposingEvent>;
    /**
    
     * [descr:dxFileManagerOptions.onErrorOccurred]
    
    
     */
    onErrorOccurred: EventEmitter<ErrorOccurredEvent>;
    /**
    
     * [descr:dxFileManagerOptions.onFileUploaded]
    
    
     */
    onFileUploaded: EventEmitter<FileUploadedEvent>;
    /**
    
     * [descr:dxFileManagerOptions.onFileUploading]
    
    
     */
    onFileUploading: EventEmitter<FileUploadingEvent>;
    /**
    
     * [descr:dxFileManagerOptions.onFocusedItemChanged]
    
    
     */
    onFocusedItemChanged: EventEmitter<FocusedItemChangedEvent>;
    /**
    
     * [descr:dxFileManagerOptions.onInitialized]
    
    
     */
    onInitialized: EventEmitter<InitializedEvent>;
    /**
    
     * [descr:dxFileManagerOptions.onItemCopied]
    
    
     */
    onItemCopied: EventEmitter<ItemCopiedEvent>;
    /**
    
     * [descr:dxFileManagerOptions.onItemCopying]
    
    
     */
    onItemCopying: EventEmitter<ItemCopyingEvent>;
    /**
    
     * [descr:dxFileManagerOptions.onItemDeleted]
    
    
     */
    onItemDeleted: EventEmitter<ItemDeletedEvent>;
    /**
    
     * [descr:dxFileManagerOptions.onItemDeleting]
    
    
     */
    onItemDeleting: EventEmitter<ItemDeletingEvent>;
    /**
    
     * [descr:dxFileManagerOptions.onItemDownloading]
    
    
     */
    onItemDownloading: EventEmitter<ItemDownloadingEvent>;
    /**
    
     * [descr:dxFileManagerOptions.onItemMoved]
    
    
     */
    onItemMoved: EventEmitter<ItemMovedEvent>;
    /**
    
     * [descr:dxFileManagerOptions.onItemMoving]
    
    
     */
    onItemMoving: EventEmitter<ItemMovingEvent>;
    /**
    
     * [descr:dxFileManagerOptions.onItemRenamed]
    
    
     */
    onItemRenamed: EventEmitter<ItemRenamedEvent>;
    /**
    
     * [descr:dxFileManagerOptions.onItemRenaming]
    
    
     */
    onItemRenaming: EventEmitter<ItemRenamingEvent>;
    /**
    
     * [descr:dxFileManagerOptions.onOptionChanged]
    
    
     */
    onOptionChanged: EventEmitter<OptionChangedEvent>;
    /**
    
     * [descr:dxFileManagerOptions.onSelectedFileOpened]
    
    
     */
    onSelectedFileOpened: EventEmitter<SelectedFileOpenedEvent>;
    /**
    
     * [descr:dxFileManagerOptions.onSelectionChanged]
    
    
     */
    onSelectionChanged: EventEmitter<SelectionChangedEvent>;
    /**
    
     * [descr:dxFileManagerOptions.onToolbarItemClick]
    
    
     */
    onToolbarItemClick: EventEmitter<ToolbarItemClickEvent>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    accessKeyChange: EventEmitter<string | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    activeStateEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    allowedFileExtensionsChange: EventEmitter<Array<string>>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    contextMenuChange: EventEmitter<dxFileManagerContextMenu>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    currentPathChange: EventEmitter<string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    currentPathKeysChange: EventEmitter<Array<string>>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    customizeDetailColumnsChange: EventEmitter<((columns: Array<dxFileManagerDetailsColumn>) => Array<dxFileManagerDetailsColumn>)>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    customizeThumbnailChange: EventEmitter<((fileSystemItem: FileSystemItem) => string)>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    disabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    elementAttrChange: EventEmitter<Record<string, any>>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    fileSystemProviderChange: EventEmitter<any | null>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    focusedItemKeyChange: EventEmitter<string | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    focusStateEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    heightChange: EventEmitter<number | string | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    hintChange: EventEmitter<string | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    hoverStateEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    itemViewChange: EventEmitter<{
        details?: {
            columns?: Array<dxFileManagerDetailsColumn | string>;
        };
        mode?: FileManagerItemViewMode;
        showFolders?: boolean;
        showParentFolder?: boolean;
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    notificationsChange: EventEmitter<{
        showPanel?: boolean;
        showPopup?: boolean;
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    permissionsChange: EventEmitter<{
        copy?: boolean;
        create?: boolean;
        delete?: boolean;
        download?: boolean;
        move?: boolean;
        rename?: boolean;
        upload?: boolean;
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    rootFolderNameChange: EventEmitter<string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    rtlEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    selectedItemKeysChange: EventEmitter<Array<string>>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    selectionModeChange: EventEmitter<SingleOrMultiple>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    tabIndexChange: EventEmitter<number>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    toolbarChange: EventEmitter<dxFileManagerToolbar>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    uploadChange: EventEmitter<{
        chunkSize?: number;
        maxFileSize?: number;
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    visibleChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    widthChange: EventEmitter<number | string | undefined>;
    constructor(elementRef: ElementRef, ngZone: NgZone, templateHost: DxTemplateHost, _watcherHelper: WatcherHelper, _idh: IterableDifferHelper, optionHost: NestedOptionHost, transferState: TransferState, platformId: any);
    protected _createInstance(element: any, options: any): DxFileManager;
    ngOnDestroy(): void;
    ngOnChanges(changes: SimpleChanges): void;
    setupChanges(prop: string, changes: SimpleChanges): void;
    ngDoCheck(): void;
    _setOption(name: string, value: any): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxFileManagerComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxFileManagerComponent, "dx-file-manager", never, { "accessKey": { "alias": "accessKey"; "required": false; }; "activeStateEnabled": { "alias": "activeStateEnabled"; "required": false; }; "allowedFileExtensions": { "alias": "allowedFileExtensions"; "required": false; }; "contextMenu": { "alias": "contextMenu"; "required": false; }; "currentPath": { "alias": "currentPath"; "required": false; }; "currentPathKeys": { "alias": "currentPathKeys"; "required": false; }; "customizeDetailColumns": { "alias": "customizeDetailColumns"; "required": false; }; "customizeThumbnail": { "alias": "customizeThumbnail"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "elementAttr": { "alias": "elementAttr"; "required": false; }; "fileSystemProvider": { "alias": "fileSystemProvider"; "required": false; }; "focusedItemKey": { "alias": "focusedItemKey"; "required": false; }; "focusStateEnabled": { "alias": "focusStateEnabled"; "required": false; }; "height": { "alias": "height"; "required": false; }; "hint": { "alias": "hint"; "required": false; }; "hoverStateEnabled": { "alias": "hoverStateEnabled"; "required": false; }; "itemView": { "alias": "itemView"; "required": false; }; "notifications": { "alias": "notifications"; "required": false; }; "permissions": { "alias": "permissions"; "required": false; }; "rootFolderName": { "alias": "rootFolderName"; "required": false; }; "rtlEnabled": { "alias": "rtlEnabled"; "required": false; }; "selectedItemKeys": { "alias": "selectedItemKeys"; "required": false; }; "selectionMode": { "alias": "selectionMode"; "required": false; }; "tabIndex": { "alias": "tabIndex"; "required": false; }; "toolbar": { "alias": "toolbar"; "required": false; }; "upload": { "alias": "upload"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, { "onContentReady": "onContentReady"; "onContextMenuItemClick": "onContextMenuItemClick"; "onContextMenuShowing": "onContextMenuShowing"; "onCurrentDirectoryChanged": "onCurrentDirectoryChanged"; "onDirectoryCreated": "onDirectoryCreated"; "onDirectoryCreating": "onDirectoryCreating"; "onDisposing": "onDisposing"; "onErrorOccurred": "onErrorOccurred"; "onFileUploaded": "onFileUploaded"; "onFileUploading": "onFileUploading"; "onFocusedItemChanged": "onFocusedItemChanged"; "onInitialized": "onInitialized"; "onItemCopied": "onItemCopied"; "onItemCopying": "onItemCopying"; "onItemDeleted": "onItemDeleted"; "onItemDeleting": "onItemDeleting"; "onItemDownloading": "onItemDownloading"; "onItemMoved": "onItemMoved"; "onItemMoving": "onItemMoving"; "onItemRenamed": "onItemRenamed"; "onItemRenaming": "onItemRenaming"; "onOptionChanged": "onOptionChanged"; "onSelectedFileOpened": "onSelectedFileOpened"; "onSelectionChanged": "onSelectionChanged"; "onToolbarItemClick": "onToolbarItemClick"; "accessKeyChange": "accessKeyChange"; "activeStateEnabledChange": "activeStateEnabledChange"; "allowedFileExtensionsChange": "allowedFileExtensionsChange"; "contextMenuChange": "contextMenuChange"; "currentPathChange": "currentPathChange"; "currentPathKeysChange": "currentPathKeysChange"; "customizeDetailColumnsChange": "customizeDetailColumnsChange"; "customizeThumbnailChange": "customizeThumbnailChange"; "disabledChange": "disabledChange"; "elementAttrChange": "elementAttrChange"; "fileSystemProviderChange": "fileSystemProviderChange"; "focusedItemKeyChange": "focusedItemKeyChange"; "focusStateEnabledChange": "focusStateEnabledChange"; "heightChange": "heightChange"; "hintChange": "hintChange"; "hoverStateEnabledChange": "hoverStateEnabledChange"; "itemViewChange": "itemViewChange"; "notificationsChange": "notificationsChange"; "permissionsChange": "permissionsChange"; "rootFolderNameChange": "rootFolderNameChange"; "rtlEnabledChange": "rtlEnabledChange"; "selectedItemKeysChange": "selectedItemKeysChange"; "selectionModeChange": "selectionModeChange"; "tabIndexChange": "tabIndexChange"; "toolbarChange": "toolbarChange"; "uploadChange": "uploadChange"; "visibleChange": "visibleChange"; "widthChange": "widthChange"; }, ["_columnsContentChildren", "_itemsContentChildren", "_fileSelectionItemsContentChildren"], never, true, never>;
}
declare class DxFileManagerModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxFileManagerModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxFileManagerModule, never, [typeof DxFileManagerComponent, typeof i1.DxoContextMenuModule, typeof i1.DxiItemModule, typeof i1.DxoItemViewModule, typeof i1.DxoDetailsModule, typeof i1.DxiColumnModule, typeof i1.DxoNotificationsModule, typeof i1.DxoPermissionsModule, typeof i1.DxoToolbarModule, typeof i1.DxiFileSelectionItemModule, typeof i1.DxoUploadModule, typeof i2.DxiFileManagerColumnModule, typeof i2.DxoFileManagerContextMenuModule, typeof i2.DxiFileManagerContextMenuItemModule, typeof i2.DxoFileManagerDetailsModule, typeof i2.DxiFileManagerFileSelectionItemModule, typeof i2.DxiFileManagerItemModule, typeof i2.DxoFileManagerItemViewModule, typeof i2.DxoFileManagerNotificationsModule, typeof i2.DxoFileManagerPermissionsModule, typeof i2.DxoFileManagerToolbarModule, typeof i2.DxiFileManagerToolbarItemModule, typeof i2.DxoFileManagerUploadModule, typeof i3.DxIntegrationModule, typeof i3.DxTemplateModule], [typeof DxFileManagerComponent, typeof i1.DxoContextMenuModule, typeof i1.DxiItemModule, typeof i1.DxoItemViewModule, typeof i1.DxoDetailsModule, typeof i1.DxiColumnModule, typeof i1.DxoNotificationsModule, typeof i1.DxoPermissionsModule, typeof i1.DxoToolbarModule, typeof i1.DxiFileSelectionItemModule, typeof i1.DxoUploadModule, typeof i2.DxiFileManagerColumnModule, typeof i2.DxoFileManagerContextMenuModule, typeof i2.DxiFileManagerContextMenuItemModule, typeof i2.DxoFileManagerDetailsModule, typeof i2.DxiFileManagerFileSelectionItemModule, typeof i2.DxiFileManagerItemModule, typeof i2.DxoFileManagerItemViewModule, typeof i2.DxoFileManagerNotificationsModule, typeof i2.DxoFileManagerPermissionsModule, typeof i2.DxoFileManagerToolbarModule, typeof i2.DxiFileManagerToolbarItemModule, typeof i2.DxoFileManagerUploadModule, typeof i3.DxTemplateModule]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxFileManagerModule>;
}

export { DxFileManagerComponent, DxFileManagerModule };
//# sourceMappingURL=index.d.ts.map
