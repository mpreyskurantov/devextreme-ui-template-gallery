import * as i0 from '@angular/core';
import { OnDestroy, OnChanges, DoCheck, QueryList, EventEmitter, ElementRef, NgZone, TransferState, SimpleChanges } from '@angular/core';
import dxChat, { Alert, Message, SendButtonProperties, User, AttachmentDownloadClickEvent, DisposingEvent, InitializedEvent, InputFieldTextChangedEvent, MessageDeletedEvent, MessageDeletingEvent, MessageEditCanceledEvent, MessageEditingStartEvent, MessageEnteredEvent, MessageUpdatedEvent, MessageUpdatingEvent, OptionChangedEvent, TypingEndEvent, TypingStartEvent } from 'devextreme/ui/chat';
import DataSource, { DataSourceOptions } from 'devextreme/data/data_source';
import { Store } from 'devextreme/data/store';
import { Format } from 'devextreme/common/core/localization';
import { dxFileUploaderOptions } from 'devextreme/ui/file_uploader';
import { dxSpeechToTextOptions } from 'devextreme/ui/speech_to_text';
import { dxButtonGroupOptions } from 'devextreme/ui/button_group';
import * as i3 from 'devextreme-angular/core';
import { DxComponent, CollectionNestedOption, DxTemplateHost, WatcherHelper, IterableDifferHelper, NestedOptionHost } from 'devextreme-angular/core';
import * as i1 from 'devextreme-angular/ui/nested';
import * as i2 from 'devextreme-angular/ui/chat/nested';
export * from 'devextreme-angular/ui/chat/nested';
import * as chat_types from 'devextreme/ui/chat_types';
export { chat_types as DxChatTypes };

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

/**
 * [descr:dxChat]

 */
declare class DxChatComponent extends DxComponent implements OnDestroy, OnChanges, DoCheck {
    private _watcherHelper;
    private _idh;
    set _alertsContentChildren(value: QueryList<CollectionNestedOption>);
    set _attachmentsContentChildren(value: QueryList<CollectionNestedOption>);
    set _itemsContentChildren(value: QueryList<CollectionNestedOption>);
    set _typingUsersContentChildren(value: QueryList<CollectionNestedOption>);
    instance: dxChat;
    /**
     * [descr:WidgetOptions.accessKey]
    
     */
    get accessKey(): string | undefined;
    set accessKey(value: string | undefined);
    /**
     * [descr:dxChatOptions.activeStateEnabled]
    
     */
    get activeStateEnabled(): boolean;
    set activeStateEnabled(value: boolean);
    /**
     * [descr:dxChatOptions.alerts]
    
     */
    get alerts(): Array<Alert>;
    set alerts(value: Array<Alert>);
    /**
     * [descr:dxChatOptions.dataSource]
    
     */
    get dataSource(): Array<Message> | DataSource | DataSourceOptions | null | Store | string;
    set dataSource(value: Array<Message> | DataSource | DataSourceOptions | null | Store | string);
    /**
     * [descr:dxChatOptions.dayHeaderFormat]
    
     */
    get dayHeaderFormat(): Format;
    set dayHeaderFormat(value: Format);
    /**
     * [descr:WidgetOptions.disabled]
    
     */
    get disabled(): boolean;
    set disabled(value: boolean);
    /**
     * [descr:dxChatOptions.editing]
    
     */
    get editing(): {
        allowDeleting?: boolean | ((options: {
            component: dxChat;
            message: Message;
        }) => boolean);
        allowUpdating?: boolean | ((options: {
            component: dxChat;
            message: Message;
        }) => boolean);
    };
    set editing(value: {
        allowDeleting?: boolean | ((options: {
            component: dxChat;
            message: Message;
        }) => boolean);
        allowUpdating?: boolean | ((options: {
            component: dxChat;
            message: Message;
        }) => boolean);
    });
    /**
     * [descr:DOMComponentOptions.elementAttr]
    
     */
    get elementAttr(): Record<string, any>;
    set elementAttr(value: Record<string, any>);
    /**
     * [descr:dxChatOptions.emptyViewTemplate]
    
     */
    get emptyViewTemplate(): any;
    set emptyViewTemplate(value: any);
    get fileUploaderOptions(): dxFileUploaderOptions;
    set fileUploaderOptions(value: dxFileUploaderOptions);
    /**
     * [descr:dxChatOptions.focusStateEnabled]
    
     */
    get focusStateEnabled(): boolean;
    set focusStateEnabled(value: boolean);
    /**
     * [descr:DOMComponentOptions.height]
    
     */
    get height(): number | string | undefined;
    set height(value: number | string | undefined);
    /**
     * [descr:WidgetOptions.hint]
    
     */
    get hint(): string | undefined;
    set hint(value: string | undefined);
    /**
     * [descr:dxChatOptions.hoverStateEnabled]
    
     */
    get hoverStateEnabled(): boolean;
    set hoverStateEnabled(value: boolean);
    get inputFieldText(): string | undefined;
    set inputFieldText(value: string | undefined);
    /**
     * [descr:dxChatOptions.items]
    
     */
    get items(): Array<Message>;
    set items(value: Array<Message>);
    /**
     * [descr:dxChatOptions.messageTemplate]
    
     */
    get messageTemplate(): any;
    set messageTemplate(value: any);
    /**
     * [descr:dxChatOptions.messageTimestampFormat]
    
     */
    get messageTimestampFormat(): Format;
    set messageTimestampFormat(value: Format);
    /**
     * [descr:dxChatOptions.reloadOnChange]
    
     */
    get reloadOnChange(): boolean;
    set reloadOnChange(value: boolean);
    /**
     * [descr:DOMComponentOptions.rtlEnabled]
    
     */
    get rtlEnabled(): boolean;
    set rtlEnabled(value: boolean);
    get sendButtonOptions(): SendButtonProperties;
    set sendButtonOptions(value: SendButtonProperties);
    /**
     * [descr:dxChatOptions.showAvatar]
    
     */
    get showAvatar(): boolean;
    set showAvatar(value: boolean);
    /**
     * [descr:dxChatOptions.showDayHeaders]
    
     */
    get showDayHeaders(): boolean;
    set showDayHeaders(value: boolean);
    /**
     * [descr:dxChatOptions.showMessageTimestamp]
    
     */
    get showMessageTimestamp(): boolean;
    set showMessageTimestamp(value: boolean);
    /**
     * [descr:dxChatOptions.showUserName]
    
     */
    get showUserName(): boolean;
    set showUserName(value: boolean);
    /**
     * [descr:dxChatOptions.speechToTextEnabled]
    
     */
    get speechToTextEnabled(): boolean;
    set speechToTextEnabled(value: boolean);
    get speechToTextOptions(): dxSpeechToTextOptions;
    set speechToTextOptions(value: dxSpeechToTextOptions);
    get suggestions(): dxButtonGroupOptions;
    set suggestions(value: dxButtonGroupOptions);
    /**
     * [descr:dxChatOptions.typingUsers]
    
     */
    get typingUsers(): Array<User>;
    set typingUsers(value: Array<User>);
    /**
     * [descr:dxChatOptions.user]
    
     */
    get user(): User;
    set user(value: User);
    /**
     * [descr:WidgetOptions.visible]
    
     */
    get visible(): boolean;
    set visible(value: boolean);
    /**
     * [descr:DOMComponentOptions.width]
    
     */
    get width(): number | string | undefined;
    set width(value: number | string | undefined);
    /**
    
     * [descr:undefined]
    
    
     */
    onAttachmentDownloadClick: EventEmitter<AttachmentDownloadClickEvent>;
    /**
    
     * [descr:dxChatOptions.onDisposing]
    
    
     */
    onDisposing: EventEmitter<DisposingEvent>;
    /**
    
     * [descr:dxChatOptions.onInitialized]
    
    
     */
    onInitialized: EventEmitter<InitializedEvent>;
    /**
    
     * [descr:dxChatOptions.onInputFieldTextChanged]
    
    
     */
    onInputFieldTextChanged: EventEmitter<InputFieldTextChangedEvent>;
    /**
    
     * [descr:dxChatOptions.onMessageDeleted]
    
    
     */
    onMessageDeleted: EventEmitter<MessageDeletedEvent>;
    /**
    
     * [descr:dxChatOptions.onMessageDeleting]
    
    
     */
    onMessageDeleting: EventEmitter<MessageDeletingEvent>;
    /**
    
     * [descr:dxChatOptions.onMessageEditCanceled]
    
    
     */
    onMessageEditCanceled: EventEmitter<MessageEditCanceledEvent>;
    /**
    
     * [descr:dxChatOptions.onMessageEditingStart]
    
    
     */
    onMessageEditingStart: EventEmitter<MessageEditingStartEvent>;
    /**
    
     * [descr:dxChatOptions.onMessageEntered]
    
    
     */
    onMessageEntered: EventEmitter<MessageEnteredEvent>;
    /**
    
     * [descr:dxChatOptions.onMessageUpdated]
    
    
     */
    onMessageUpdated: EventEmitter<MessageUpdatedEvent>;
    /**
    
     * [descr:dxChatOptions.onMessageUpdating]
    
    
     */
    onMessageUpdating: EventEmitter<MessageUpdatingEvent>;
    /**
    
     * [descr:dxChatOptions.onOptionChanged]
    
    
     */
    onOptionChanged: EventEmitter<OptionChangedEvent>;
    /**
    
     * [descr:dxChatOptions.onTypingEnd]
    
    
     */
    onTypingEnd: EventEmitter<TypingEndEvent>;
    /**
    
     * [descr:dxChatOptions.onTypingStart]
    
    
     */
    onTypingStart: EventEmitter<TypingStartEvent>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    accessKeyChange: EventEmitter<string | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    activeStateEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    alertsChange: EventEmitter<Array<Alert>>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    dataSourceChange: EventEmitter<Array<Message> | DataSource | DataSourceOptions | null | Store | string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    dayHeaderFormatChange: EventEmitter<Format>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    disabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    editingChange: EventEmitter<{
        allowDeleting?: boolean | ((options: {
            component: dxChat;
            message: Message;
        }) => boolean);
        allowUpdating?: boolean | ((options: {
            component: dxChat;
            message: Message;
        }) => boolean);
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    elementAttrChange: EventEmitter<Record<string, any>>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    emptyViewTemplateChange: EventEmitter<any>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    fileUploaderOptionsChange: EventEmitter<dxFileUploaderOptions>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    focusStateEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    heightChange: EventEmitter<number | string | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    hintChange: EventEmitter<string | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    hoverStateEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    inputFieldTextChange: EventEmitter<string | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    itemsChange: EventEmitter<Array<Message>>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    messageTemplateChange: EventEmitter<any>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    messageTimestampFormatChange: EventEmitter<Format>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    reloadOnChangeChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    rtlEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    sendButtonOptionsChange: EventEmitter<SendButtonProperties>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    showAvatarChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    showDayHeadersChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    showMessageTimestampChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    showUserNameChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    speechToTextEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    speechToTextOptionsChange: EventEmitter<dxSpeechToTextOptions>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    suggestionsChange: EventEmitter<dxButtonGroupOptions>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    typingUsersChange: EventEmitter<Array<User>>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    userChange: EventEmitter<User>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    visibleChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    widthChange: EventEmitter<number | string | undefined>;
    constructor(elementRef: ElementRef, ngZone: NgZone, templateHost: DxTemplateHost, _watcherHelper: WatcherHelper, _idh: IterableDifferHelper, optionHost: NestedOptionHost, transferState: TransferState, platformId: any);
    protected _createInstance(element: any, options: any): dxChat;
    ngOnDestroy(): void;
    ngOnChanges(changes: SimpleChanges): void;
    setupChanges(prop: string, changes: SimpleChanges): void;
    ngDoCheck(): void;
    _setOption(name: string, value: any): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxChatComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxChatComponent, "dx-chat", never, { "accessKey": { "alias": "accessKey"; "required": false; }; "activeStateEnabled": { "alias": "activeStateEnabled"; "required": false; }; "alerts": { "alias": "alerts"; "required": false; }; "dataSource": { "alias": "dataSource"; "required": false; }; "dayHeaderFormat": { "alias": "dayHeaderFormat"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "editing": { "alias": "editing"; "required": false; }; "elementAttr": { "alias": "elementAttr"; "required": false; }; "emptyViewTemplate": { "alias": "emptyViewTemplate"; "required": false; }; "fileUploaderOptions": { "alias": "fileUploaderOptions"; "required": false; }; "focusStateEnabled": { "alias": "focusStateEnabled"; "required": false; }; "height": { "alias": "height"; "required": false; }; "hint": { "alias": "hint"; "required": false; }; "hoverStateEnabled": { "alias": "hoverStateEnabled"; "required": false; }; "inputFieldText": { "alias": "inputFieldText"; "required": false; }; "items": { "alias": "items"; "required": false; }; "messageTemplate": { "alias": "messageTemplate"; "required": false; }; "messageTimestampFormat": { "alias": "messageTimestampFormat"; "required": false; }; "reloadOnChange": { "alias": "reloadOnChange"; "required": false; }; "rtlEnabled": { "alias": "rtlEnabled"; "required": false; }; "sendButtonOptions": { "alias": "sendButtonOptions"; "required": false; }; "showAvatar": { "alias": "showAvatar"; "required": false; }; "showDayHeaders": { "alias": "showDayHeaders"; "required": false; }; "showMessageTimestamp": { "alias": "showMessageTimestamp"; "required": false; }; "showUserName": { "alias": "showUserName"; "required": false; }; "speechToTextEnabled": { "alias": "speechToTextEnabled"; "required": false; }; "speechToTextOptions": { "alias": "speechToTextOptions"; "required": false; }; "suggestions": { "alias": "suggestions"; "required": false; }; "typingUsers": { "alias": "typingUsers"; "required": false; }; "user": { "alias": "user"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, { "onAttachmentDownloadClick": "onAttachmentDownloadClick"; "onDisposing": "onDisposing"; "onInitialized": "onInitialized"; "onInputFieldTextChanged": "onInputFieldTextChanged"; "onMessageDeleted": "onMessageDeleted"; "onMessageDeleting": "onMessageDeleting"; "onMessageEditCanceled": "onMessageEditCanceled"; "onMessageEditingStart": "onMessageEditingStart"; "onMessageEntered": "onMessageEntered"; "onMessageUpdated": "onMessageUpdated"; "onMessageUpdating": "onMessageUpdating"; "onOptionChanged": "onOptionChanged"; "onTypingEnd": "onTypingEnd"; "onTypingStart": "onTypingStart"; "accessKeyChange": "accessKeyChange"; "activeStateEnabledChange": "activeStateEnabledChange"; "alertsChange": "alertsChange"; "dataSourceChange": "dataSourceChange"; "dayHeaderFormatChange": "dayHeaderFormatChange"; "disabledChange": "disabledChange"; "editingChange": "editingChange"; "elementAttrChange": "elementAttrChange"; "emptyViewTemplateChange": "emptyViewTemplateChange"; "fileUploaderOptionsChange": "fileUploaderOptionsChange"; "focusStateEnabledChange": "focusStateEnabledChange"; "heightChange": "heightChange"; "hintChange": "hintChange"; "hoverStateEnabledChange": "hoverStateEnabledChange"; "inputFieldTextChange": "inputFieldTextChange"; "itemsChange": "itemsChange"; "messageTemplateChange": "messageTemplateChange"; "messageTimestampFormatChange": "messageTimestampFormatChange"; "reloadOnChangeChange": "reloadOnChangeChange"; "rtlEnabledChange": "rtlEnabledChange"; "sendButtonOptionsChange": "sendButtonOptionsChange"; "showAvatarChange": "showAvatarChange"; "showDayHeadersChange": "showDayHeadersChange"; "showMessageTimestampChange": "showMessageTimestampChange"; "showUserNameChange": "showUserNameChange"; "speechToTextEnabledChange": "speechToTextEnabledChange"; "speechToTextOptionsChange": "speechToTextOptionsChange"; "suggestionsChange": "suggestionsChange"; "typingUsersChange": "typingUsersChange"; "userChange": "userChange"; "visibleChange": "visibleChange"; "widthChange": "widthChange"; }, ["_alertsContentChildren", "_attachmentsContentChildren", "_itemsContentChildren", "_typingUsersContentChildren"], never, true, never>;
}
declare class DxChatModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxChatModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxChatModule, never, [typeof DxChatComponent, typeof i1.DxiAlertModule, typeof i1.DxoDayHeaderFormatModule, typeof i1.DxoEditingModule, typeof i1.DxiItemModule, typeof i1.DxoAuthorModule, typeof i1.DxoMessageTimestampFormatModule, typeof i1.DxiTypingUserModule, typeof i1.DxoUserModule, typeof i2.DxiChatAlertModule, typeof i2.DxiChatAttachmentModule, typeof i2.DxoChatAuthorModule, typeof i2.DxiChatChatItemModule, typeof i2.DxoChatCustomSpeechRecognizerModule, typeof i2.DxoChatDayHeaderFormatModule, typeof i2.DxoChatEditingModule, typeof i2.DxoChatFileUploaderOptionsModule, typeof i2.DxiChatItemModule, typeof i2.DxoChatMessageTimestampFormatModule, typeof i2.DxoChatSendButtonOptionsModule, typeof i2.DxoChatSpeechRecognitionConfigModule, typeof i2.DxoChatSpeechToTextOptionsModule, typeof i2.DxoChatSuggestionsModule, typeof i2.DxiChatSuggestionsItemModule, typeof i2.DxiChatTypingUserModule, typeof i2.DxoChatUserModule, typeof i3.DxIntegrationModule, typeof i3.DxTemplateModule], [typeof DxChatComponent, typeof i1.DxiAlertModule, typeof i1.DxoDayHeaderFormatModule, typeof i1.DxoEditingModule, typeof i1.DxiItemModule, typeof i1.DxoAuthorModule, typeof i1.DxoMessageTimestampFormatModule, typeof i1.DxiTypingUserModule, typeof i1.DxoUserModule, typeof i2.DxiChatAlertModule, typeof i2.DxiChatAttachmentModule, typeof i2.DxoChatAuthorModule, typeof i2.DxiChatChatItemModule, typeof i2.DxoChatCustomSpeechRecognizerModule, typeof i2.DxoChatDayHeaderFormatModule, typeof i2.DxoChatEditingModule, typeof i2.DxoChatFileUploaderOptionsModule, typeof i2.DxiChatItemModule, typeof i2.DxoChatMessageTimestampFormatModule, typeof i2.DxoChatSendButtonOptionsModule, typeof i2.DxoChatSpeechRecognitionConfigModule, typeof i2.DxoChatSpeechToTextOptionsModule, typeof i2.DxoChatSuggestionsModule, typeof i2.DxiChatSuggestionsItemModule, typeof i2.DxiChatTypingUserModule, typeof i2.DxoChatUserModule, typeof i3.DxTemplateModule]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxChatModule>;
}

export { DxChatComponent, DxChatModule };
//# sourceMappingURL=index.d.ts.map
