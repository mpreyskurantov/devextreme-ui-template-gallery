import { CollectionNestedOption, NestedOptionHost, NestedOption, IDxTemplateHost, DxTemplateHost, DxTemplateDirective } from 'devextreme-angular/core';
import * as i0 from '@angular/core';
import { OnDestroy, OnInit, QueryList, EventEmitter, AfterViewInit, Renderer2, ElementRef } from '@angular/core';
import dxChat, { Attachment, User, MessageType, Message, SendButtonAction, SendButtonClickEvent } from 'devextreme/ui/chat';
import { Format, ValidationStatus, ButtonType, ButtonStyle, SingleMultipleOrNone } from 'devextreme/common';
import UploadInfo from 'devextreme/file_management/upload_info';
import { BeforeSendEvent, ContentReadyEvent, DisposingEvent, DropZoneEnterEvent, DropZoneLeaveEvent, FilesUploadedEvent, InitializedEvent, OptionChangedEvent, ProgressEvent, UploadAbortedEvent, UploadedEvent, UploadErrorEvent, UploadStartedEvent, ValueChangedEvent, UploadHttpMethod, FileUploadMode } from 'devextreme/ui/file_uploader';
import { CustomSpeechRecognizer, ContentReadyEvent as ContentReadyEvent$1, DisposingEvent as DisposingEvent$1, EndEvent, ErrorEvent, InitializedEvent as InitializedEvent$1, OptionChangedEvent as OptionChangedEvent$1, ResultEvent, StartClickEvent, StopClickEvent, SpeechRecognitionConfig } from 'devextreme/ui/speech_to_text';
import { dxButtonGroupItem, ContentReadyEvent as ContentReadyEvent$2, DisposingEvent as DisposingEvent$2, InitializedEvent as InitializedEvent$2, ItemClickEvent, OptionChangedEvent as OptionChangedEvent$2, SelectionChangedEvent } from 'devextreme/ui/button_group';

declare class DxiChatAlertComponent extends CollectionNestedOption {
    get id(): number | string;
    set id(value: number | string);
    get message(): string;
    set message(value: string);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiChatAlertComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiChatAlertComponent, "dxi-chat-alert", never, { "id": { "alias": "id"; "required": false; }; "message": { "alias": "message"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxiChatAlertModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiChatAlertModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiChatAlertModule, never, [typeof DxiChatAlertComponent], [typeof DxiChatAlertComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiChatAlertModule>;
}

declare class DxiChatAttachmentComponent extends CollectionNestedOption {
    get name(): string;
    set name(value: string);
    get size(): number;
    set size(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiChatAttachmentComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiChatAttachmentComponent, "dxi-chat-attachment", never, { "name": { "alias": "name"; "required": false; }; "size": { "alias": "size"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxiChatAttachmentModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiChatAttachmentModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiChatAttachmentModule, never, [typeof DxiChatAttachmentComponent], [typeof DxiChatAttachmentComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiChatAttachmentModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoChatAuthorComponent extends NestedOption implements OnDestroy, OnInit {
    get avatarAlt(): string;
    set avatarAlt(value: string);
    get avatarUrl(): string;
    set avatarUrl(value: string);
    get id(): number | string;
    set id(value: number | string);
    get name(): string;
    set name(value: string);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChatAuthorComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoChatAuthorComponent, "dxo-chat-author", never, { "avatarAlt": { "alias": "avatarAlt"; "required": false; }; "avatarUrl": { "alias": "avatarUrl"; "required": false; }; "id": { "alias": "id"; "required": false; }; "name": { "alias": "name"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoChatAuthorModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChatAuthorModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoChatAuthorModule, never, [typeof DxoChatAuthorComponent], [typeof DxoChatAuthorComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoChatAuthorModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxiChatChatItemComponent extends CollectionNestedOption {
    set _attachmentsContentChildren(value: QueryList<CollectionNestedOption>);
    get alt(): string;
    set alt(value: string);
    get attachments(): Array<Attachment>;
    set attachments(value: Array<Attachment>);
    get author(): User;
    set author(value: User);
    get id(): number | string;
    set id(value: number | string);
    get isDeleted(): boolean;
    set isDeleted(value: boolean);
    get isEdited(): boolean;
    set isEdited(value: boolean);
    get src(): string;
    set src(value: string);
    get text(): string;
    set text(value: string);
    get timestamp(): Date | number | string;
    set timestamp(value: Date | number | string);
    get type(): MessageType;
    set type(value: MessageType);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiChatChatItemComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiChatChatItemComponent, "dxi-chat-chat-item", never, { "alt": { "alias": "alt"; "required": false; }; "attachments": { "alias": "attachments"; "required": false; }; "author": { "alias": "author"; "required": false; }; "id": { "alias": "id"; "required": false; }; "isDeleted": { "alias": "isDeleted"; "required": false; }; "isEdited": { "alias": "isEdited"; "required": false; }; "src": { "alias": "src"; "required": false; }; "text": { "alias": "text"; "required": false; }; "timestamp": { "alias": "timestamp"; "required": false; }; "type": { "alias": "type"; "required": false; }; }, {}, ["_attachmentsContentChildren"], never, true, never>;
}
declare class DxiChatChatItemModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiChatChatItemModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiChatChatItemModule, never, [typeof DxiChatChatItemComponent], [typeof DxiChatChatItemComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiChatChatItemModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoChatCustomSpeechRecognizerComponent extends NestedOption implements OnDestroy, OnInit {
    get enabled(): boolean;
    set enabled(value: boolean);
    get isListening(): boolean;
    set isListening(value: boolean);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChatCustomSpeechRecognizerComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoChatCustomSpeechRecognizerComponent, "dxo-chat-custom-speech-recognizer", never, { "enabled": { "alias": "enabled"; "required": false; }; "isListening": { "alias": "isListening"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoChatCustomSpeechRecognizerModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChatCustomSpeechRecognizerModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoChatCustomSpeechRecognizerModule, never, [typeof DxoChatCustomSpeechRecognizerComponent], [typeof DxoChatCustomSpeechRecognizerComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoChatCustomSpeechRecognizerModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoChatDayHeaderFormatComponent extends NestedOption implements OnDestroy, OnInit {
    get currency(): string;
    set currency(value: string);
    get formatter(): ((value: number | Date) => string);
    set formatter(value: ((value: number | Date) => string));
    get parser(): ((value: string) => number | Date);
    set parser(value: ((value: string) => number | Date));
    get precision(): number;
    set precision(value: number);
    get type(): Format | string;
    set type(value: Format | string);
    get useCurrencyAccountingStyle(): boolean;
    set useCurrencyAccountingStyle(value: boolean);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChatDayHeaderFormatComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoChatDayHeaderFormatComponent, "dxo-chat-day-header-format", never, { "currency": { "alias": "currency"; "required": false; }; "formatter": { "alias": "formatter"; "required": false; }; "parser": { "alias": "parser"; "required": false; }; "precision": { "alias": "precision"; "required": false; }; "type": { "alias": "type"; "required": false; }; "useCurrencyAccountingStyle": { "alias": "useCurrencyAccountingStyle"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoChatDayHeaderFormatModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChatDayHeaderFormatModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoChatDayHeaderFormatModule, never, [typeof DxoChatDayHeaderFormatComponent], [typeof DxoChatDayHeaderFormatComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoChatDayHeaderFormatModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoChatEditingComponent extends NestedOption implements OnDestroy, OnInit {
    get allowDeleting(): boolean | ((options: {
        component: dxChat;
        message: Message;
    }) => boolean);
    set allowDeleting(value: boolean | ((options: {
        component: dxChat;
        message: Message;
    }) => boolean));
    get allowUpdating(): boolean | ((options: {
        component: dxChat;
        message: Message;
    }) => boolean);
    set allowUpdating(value: boolean | ((options: {
        component: dxChat;
        message: Message;
    }) => boolean));
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChatEditingComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoChatEditingComponent, "dxo-chat-editing", never, { "allowDeleting": { "alias": "allowDeleting"; "required": false; }; "allowUpdating": { "alias": "allowUpdating"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoChatEditingModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChatEditingModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoChatEditingModule, never, [typeof DxoChatEditingComponent], [typeof DxoChatEditingComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoChatEditingModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoChatFileUploaderOptionsComponent extends NestedOption implements OnDestroy, OnInit {
    get abortUpload(): ((file: any, uploadInfo?: UploadInfo) => any);
    set abortUpload(value: ((file: any, uploadInfo?: UploadInfo) => any));
    get accept(): string;
    set accept(value: string);
    get accessKey(): string | undefined;
    set accessKey(value: string | undefined);
    get activeStateEnabled(): boolean;
    set activeStateEnabled(value: boolean);
    get allowCanceling(): boolean;
    set allowCanceling(value: boolean);
    get allowedFileExtensions(): Array<string>;
    set allowedFileExtensions(value: Array<string>);
    get chunkSize(): number;
    set chunkSize(value: number);
    get dialogTrigger(): any | string | undefined;
    set dialogTrigger(value: any | string | undefined);
    get disabled(): boolean;
    set disabled(value: boolean);
    get dropZone(): any | string | undefined;
    set dropZone(value: any | string | undefined);
    get elementAttr(): Record<string, any>;
    set elementAttr(value: Record<string, any>);
    get focusStateEnabled(): boolean;
    set focusStateEnabled(value: boolean);
    get height(): number | string | undefined;
    set height(value: number | string | undefined);
    get hint(): string | undefined;
    set hint(value: string | undefined);
    get hoverStateEnabled(): boolean;
    set hoverStateEnabled(value: boolean);
    get inputAttr(): any;
    set inputAttr(value: any);
    get invalidFileExtensionMessage(): string;
    set invalidFileExtensionMessage(value: string);
    get invalidMaxFileSizeMessage(): string;
    set invalidMaxFileSizeMessage(value: string);
    get invalidMinFileSizeMessage(): string;
    set invalidMinFileSizeMessage(value: string);
    get isDirty(): boolean;
    set isDirty(value: boolean);
    get isValid(): boolean;
    set isValid(value: boolean);
    get labelText(): string;
    set labelText(value: string);
    get maxFileSize(): number;
    set maxFileSize(value: number);
    get minFileSize(): number;
    set minFileSize(value: number);
    get multiple(): boolean;
    set multiple(value: boolean);
    get name(): string;
    set name(value: string);
    get onBeforeSend(): ((e: BeforeSendEvent) => void) | undefined;
    set onBeforeSend(value: ((e: BeforeSendEvent) => void) | undefined);
    get onContentReady(): ((e: ContentReadyEvent) => void);
    set onContentReady(value: ((e: ContentReadyEvent) => void));
    get onDisposing(): ((e: DisposingEvent) => void);
    set onDisposing(value: ((e: DisposingEvent) => void));
    get onDropZoneEnter(): ((e: DropZoneEnterEvent) => void) | undefined;
    set onDropZoneEnter(value: ((e: DropZoneEnterEvent) => void) | undefined);
    get onDropZoneLeave(): ((e: DropZoneLeaveEvent) => void) | undefined;
    set onDropZoneLeave(value: ((e: DropZoneLeaveEvent) => void) | undefined);
    get onFilesUploaded(): ((e: FilesUploadedEvent) => void) | undefined;
    set onFilesUploaded(value: ((e: FilesUploadedEvent) => void) | undefined);
    get onInitialized(): ((e: InitializedEvent) => void);
    set onInitialized(value: ((e: InitializedEvent) => void));
    get onOptionChanged(): ((e: OptionChangedEvent) => void);
    set onOptionChanged(value: ((e: OptionChangedEvent) => void));
    get onProgress(): ((e: ProgressEvent) => void) | undefined;
    set onProgress(value: ((e: ProgressEvent) => void) | undefined);
    get onUploadAborted(): ((e: UploadAbortedEvent) => void) | undefined;
    set onUploadAborted(value: ((e: UploadAbortedEvent) => void) | undefined);
    get onUploaded(): ((e: UploadedEvent) => void) | undefined;
    set onUploaded(value: ((e: UploadedEvent) => void) | undefined);
    get onUploadError(): ((e: UploadErrorEvent) => void) | undefined;
    set onUploadError(value: ((e: UploadErrorEvent) => void) | undefined);
    get onUploadStarted(): ((e: UploadStartedEvent) => void) | undefined;
    set onUploadStarted(value: ((e: UploadStartedEvent) => void) | undefined);
    get onValueChanged(): ((e: ValueChangedEvent) => void) | undefined;
    set onValueChanged(value: ((e: ValueChangedEvent) => void) | undefined);
    get progress(): number;
    set progress(value: number);
    get readOnly(): boolean;
    set readOnly(value: boolean);
    get readyToUploadMessage(): string;
    set readyToUploadMessage(value: string);
    get rtlEnabled(): boolean;
    set rtlEnabled(value: boolean);
    get selectButtonText(): string;
    set selectButtonText(value: string);
    get showFileList(): boolean;
    set showFileList(value: boolean);
    get tabIndex(): number;
    set tabIndex(value: number);
    get uploadAbortedMessage(): string;
    set uploadAbortedMessage(value: string);
    get uploadButtonText(): string;
    set uploadButtonText(value: string);
    get uploadChunk(): ((file: any, uploadInfo: UploadInfo) => any);
    set uploadChunk(value: ((file: any, uploadInfo: UploadInfo) => any));
    get uploadCustomData(): any;
    set uploadCustomData(value: any);
    get uploadedMessage(): string;
    set uploadedMessage(value: string);
    get uploadFailedMessage(): string;
    set uploadFailedMessage(value: string);
    get uploadFile(): ((file: any, progressCallback: Function) => any);
    set uploadFile(value: ((file: any, progressCallback: Function) => any));
    get uploadHeaders(): any;
    set uploadHeaders(value: any);
    get uploadMethod(): UploadHttpMethod;
    set uploadMethod(value: UploadHttpMethod);
    get uploadMode(): FileUploadMode;
    set uploadMode(value: FileUploadMode);
    get uploadUrl(): string;
    set uploadUrl(value: string);
    get validationError(): any | null;
    set validationError(value: any | null);
    get validationErrors(): Array<any> | null;
    set validationErrors(value: Array<any> | null);
    get validationStatus(): ValidationStatus;
    set validationStatus(value: ValidationStatus);
    get value(): Array<any>;
    set value(value: Array<any>);
    get visible(): boolean;
    set visible(value: boolean);
    get width(): number | string | undefined;
    set width(value: number | string | undefined);
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    valueChange: EventEmitter<Array<any>>;
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChatFileUploaderOptionsComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoChatFileUploaderOptionsComponent, "dxo-chat-file-uploader-options", never, { "abortUpload": { "alias": "abortUpload"; "required": false; }; "accept": { "alias": "accept"; "required": false; }; "accessKey": { "alias": "accessKey"; "required": false; }; "activeStateEnabled": { "alias": "activeStateEnabled"; "required": false; }; "allowCanceling": { "alias": "allowCanceling"; "required": false; }; "allowedFileExtensions": { "alias": "allowedFileExtensions"; "required": false; }; "chunkSize": { "alias": "chunkSize"; "required": false; }; "dialogTrigger": { "alias": "dialogTrigger"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "dropZone": { "alias": "dropZone"; "required": false; }; "elementAttr": { "alias": "elementAttr"; "required": false; }; "focusStateEnabled": { "alias": "focusStateEnabled"; "required": false; }; "height": { "alias": "height"; "required": false; }; "hint": { "alias": "hint"; "required": false; }; "hoverStateEnabled": { "alias": "hoverStateEnabled"; "required": false; }; "inputAttr": { "alias": "inputAttr"; "required": false; }; "invalidFileExtensionMessage": { "alias": "invalidFileExtensionMessage"; "required": false; }; "invalidMaxFileSizeMessage": { "alias": "invalidMaxFileSizeMessage"; "required": false; }; "invalidMinFileSizeMessage": { "alias": "invalidMinFileSizeMessage"; "required": false; }; "isDirty": { "alias": "isDirty"; "required": false; }; "isValid": { "alias": "isValid"; "required": false; }; "labelText": { "alias": "labelText"; "required": false; }; "maxFileSize": { "alias": "maxFileSize"; "required": false; }; "minFileSize": { "alias": "minFileSize"; "required": false; }; "multiple": { "alias": "multiple"; "required": false; }; "name": { "alias": "name"; "required": false; }; "onBeforeSend": { "alias": "onBeforeSend"; "required": false; }; "onContentReady": { "alias": "onContentReady"; "required": false; }; "onDisposing": { "alias": "onDisposing"; "required": false; }; "onDropZoneEnter": { "alias": "onDropZoneEnter"; "required": false; }; "onDropZoneLeave": { "alias": "onDropZoneLeave"; "required": false; }; "onFilesUploaded": { "alias": "onFilesUploaded"; "required": false; }; "onInitialized": { "alias": "onInitialized"; "required": false; }; "onOptionChanged": { "alias": "onOptionChanged"; "required": false; }; "onProgress": { "alias": "onProgress"; "required": false; }; "onUploadAborted": { "alias": "onUploadAborted"; "required": false; }; "onUploaded": { "alias": "onUploaded"; "required": false; }; "onUploadError": { "alias": "onUploadError"; "required": false; }; "onUploadStarted": { "alias": "onUploadStarted"; "required": false; }; "onValueChanged": { "alias": "onValueChanged"; "required": false; }; "progress": { "alias": "progress"; "required": false; }; "readOnly": { "alias": "readOnly"; "required": false; }; "readyToUploadMessage": { "alias": "readyToUploadMessage"; "required": false; }; "rtlEnabled": { "alias": "rtlEnabled"; "required": false; }; "selectButtonText": { "alias": "selectButtonText"; "required": false; }; "showFileList": { "alias": "showFileList"; "required": false; }; "tabIndex": { "alias": "tabIndex"; "required": false; }; "uploadAbortedMessage": { "alias": "uploadAbortedMessage"; "required": false; }; "uploadButtonText": { "alias": "uploadButtonText"; "required": false; }; "uploadChunk": { "alias": "uploadChunk"; "required": false; }; "uploadCustomData": { "alias": "uploadCustomData"; "required": false; }; "uploadedMessage": { "alias": "uploadedMessage"; "required": false; }; "uploadFailedMessage": { "alias": "uploadFailedMessage"; "required": false; }; "uploadFile": { "alias": "uploadFile"; "required": false; }; "uploadHeaders": { "alias": "uploadHeaders"; "required": false; }; "uploadMethod": { "alias": "uploadMethod"; "required": false; }; "uploadMode": { "alias": "uploadMode"; "required": false; }; "uploadUrl": { "alias": "uploadUrl"; "required": false; }; "validationError": { "alias": "validationError"; "required": false; }; "validationErrors": { "alias": "validationErrors"; "required": false; }; "validationStatus": { "alias": "validationStatus"; "required": false; }; "value": { "alias": "value"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, { "valueChange": "valueChange"; }, never, never, true, never>;
}
declare class DxoChatFileUploaderOptionsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChatFileUploaderOptionsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoChatFileUploaderOptionsModule, never, [typeof DxoChatFileUploaderOptionsComponent], [typeof DxoChatFileUploaderOptionsComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoChatFileUploaderOptionsModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxiChatItemComponent extends CollectionNestedOption implements AfterViewInit, IDxTemplateHost {
    private renderer;
    private document;
    private element;
    set _attachmentsContentChildren(value: QueryList<CollectionNestedOption>);
    get alt(): string;
    set alt(value: string);
    get attachments(): Array<Attachment>;
    set attachments(value: Array<Attachment>);
    get author(): User;
    set author(value: User);
    get id(): number | string;
    set id(value: number | string);
    get isDeleted(): boolean;
    set isDeleted(value: boolean);
    get isEdited(): boolean;
    set isEdited(value: boolean);
    get src(): string;
    set src(value: string);
    get text(): string;
    set text(value: string);
    get timestamp(): Date | number | string;
    set timestamp(value: Date | number | string);
    get type(): MessageType | ButtonType | string;
    set type(value: MessageType | ButtonType | string);
    get disabled(): boolean;
    set disabled(value: boolean);
    get elementAttr(): Record<string, any>;
    set elementAttr(value: Record<string, any>);
    get hint(): string;
    set hint(value: string);
    get icon(): string;
    set icon(value: string);
    get template(): any;
    set template(value: any);
    get visible(): boolean;
    set visible(value: boolean);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost, renderer: Renderer2, document: any, templateHost: DxTemplateHost, element: ElementRef);
    setTemplate(template: DxTemplateDirective): void;
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiChatItemComponent, [{ host: true; skipSelf: true; }, { host: true; }, null, null, { host: true; }, null]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiChatItemComponent, "dxi-chat-item", never, { "alt": { "alias": "alt"; "required": false; }; "attachments": { "alias": "attachments"; "required": false; }; "author": { "alias": "author"; "required": false; }; "id": { "alias": "id"; "required": false; }; "isDeleted": { "alias": "isDeleted"; "required": false; }; "isEdited": { "alias": "isEdited"; "required": false; }; "src": { "alias": "src"; "required": false; }; "text": { "alias": "text"; "required": false; }; "timestamp": { "alias": "timestamp"; "required": false; }; "type": { "alias": "type"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "elementAttr": { "alias": "elementAttr"; "required": false; }; "hint": { "alias": "hint"; "required": false; }; "icon": { "alias": "icon"; "required": false; }; "template": { "alias": "template"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; }, {}, ["_attachmentsContentChildren"], ["*"], true, never>;
}
declare class DxiChatItemModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiChatItemModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiChatItemModule, never, [typeof DxiChatItemComponent], [typeof DxiChatItemComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiChatItemModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoChatMessageTimestampFormatComponent extends NestedOption implements OnDestroy, OnInit {
    get currency(): string;
    set currency(value: string);
    get formatter(): ((value: number | Date) => string);
    set formatter(value: ((value: number | Date) => string));
    get parser(): ((value: string) => number | Date);
    set parser(value: ((value: string) => number | Date));
    get precision(): number;
    set precision(value: number);
    get type(): Format | string;
    set type(value: Format | string);
    get useCurrencyAccountingStyle(): boolean;
    set useCurrencyAccountingStyle(value: boolean);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChatMessageTimestampFormatComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoChatMessageTimestampFormatComponent, "dxo-chat-message-timestamp-format", never, { "currency": { "alias": "currency"; "required": false; }; "formatter": { "alias": "formatter"; "required": false; }; "parser": { "alias": "parser"; "required": false; }; "precision": { "alias": "precision"; "required": false; }; "type": { "alias": "type"; "required": false; }; "useCurrencyAccountingStyle": { "alias": "useCurrencyAccountingStyle"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoChatMessageTimestampFormatModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChatMessageTimestampFormatModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoChatMessageTimestampFormatModule, never, [typeof DxoChatMessageTimestampFormatComponent], [typeof DxoChatMessageTimestampFormatComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoChatMessageTimestampFormatModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoChatSendButtonOptionsComponent extends NestedOption implements OnDestroy, OnInit {
    get action(): SendButtonAction;
    set action(value: SendButtonAction);
    get icon(): string;
    set icon(value: string);
    get onClick(): ((e: SendButtonClickEvent) => void);
    set onClick(value: ((e: SendButtonClickEvent) => void));
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChatSendButtonOptionsComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoChatSendButtonOptionsComponent, "dxo-chat-send-button-options", never, { "action": { "alias": "action"; "required": false; }; "icon": { "alias": "icon"; "required": false; }; "onClick": { "alias": "onClick"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoChatSendButtonOptionsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChatSendButtonOptionsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoChatSendButtonOptionsModule, never, [typeof DxoChatSendButtonOptionsComponent], [typeof DxoChatSendButtonOptionsComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoChatSendButtonOptionsModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoChatSpeechRecognitionConfigComponent extends NestedOption implements OnDestroy, OnInit {
    get continuous(): boolean;
    set continuous(value: boolean);
    get grammars(): Array<string>;
    set grammars(value: Array<string>);
    get interimResults(): boolean;
    set interimResults(value: boolean);
    get lang(): string;
    set lang(value: string);
    get maxAlternatives(): number;
    set maxAlternatives(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChatSpeechRecognitionConfigComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoChatSpeechRecognitionConfigComponent, "dxo-chat-speech-recognition-config", never, { "continuous": { "alias": "continuous"; "required": false; }; "grammars": { "alias": "grammars"; "required": false; }; "interimResults": { "alias": "interimResults"; "required": false; }; "lang": { "alias": "lang"; "required": false; }; "maxAlternatives": { "alias": "maxAlternatives"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoChatSpeechRecognitionConfigModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChatSpeechRecognitionConfigModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoChatSpeechRecognitionConfigModule, never, [typeof DxoChatSpeechRecognitionConfigComponent], [typeof DxoChatSpeechRecognitionConfigComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoChatSpeechRecognitionConfigModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoChatSpeechToTextOptionsComponent extends NestedOption implements OnDestroy, OnInit {
    get accessKey(): string | undefined;
    set accessKey(value: string | undefined);
    get activeStateEnabled(): boolean;
    set activeStateEnabled(value: boolean);
    get customSpeechRecognizer(): CustomSpeechRecognizer;
    set customSpeechRecognizer(value: CustomSpeechRecognizer);
    get disabled(): boolean;
    set disabled(value: boolean);
    get elementAttr(): Record<string, any>;
    set elementAttr(value: Record<string, any>);
    get focusStateEnabled(): boolean;
    set focusStateEnabled(value: boolean);
    get height(): number | string | undefined;
    set height(value: number | string | undefined);
    get hint(): string | undefined;
    set hint(value: string | undefined);
    get hoverStateEnabled(): boolean;
    set hoverStateEnabled(value: boolean);
    get onContentReady(): ((e: ContentReadyEvent$1) => void);
    set onContentReady(value: ((e: ContentReadyEvent$1) => void));
    get onDisposing(): ((e: DisposingEvent$1) => void);
    set onDisposing(value: ((e: DisposingEvent$1) => void));
    get onEnd(): ((e: EndEvent) => void) | undefined;
    set onEnd(value: ((e: EndEvent) => void) | undefined);
    get onError(): ((e: ErrorEvent) => void) | undefined;
    set onError(value: ((e: ErrorEvent) => void) | undefined);
    get onInitialized(): ((e: InitializedEvent$1) => void);
    set onInitialized(value: ((e: InitializedEvent$1) => void));
    get onOptionChanged(): ((e: OptionChangedEvent$1) => void);
    set onOptionChanged(value: ((e: OptionChangedEvent$1) => void));
    get onResult(): ((e: ResultEvent) => void) | undefined;
    set onResult(value: ((e: ResultEvent) => void) | undefined);
    get onStartClick(): ((e: StartClickEvent) => void) | undefined;
    set onStartClick(value: ((e: StartClickEvent) => void) | undefined);
    get onStopClick(): ((e: StopClickEvent) => void) | undefined;
    set onStopClick(value: ((e: StopClickEvent) => void) | undefined);
    get rtlEnabled(): boolean;
    set rtlEnabled(value: boolean);
    get speechRecognitionConfig(): Record<string, any> | SpeechRecognitionConfig;
    set speechRecognitionConfig(value: Record<string, any> | SpeechRecognitionConfig);
    get startIcon(): string;
    set startIcon(value: string);
    get startText(): string;
    set startText(value: string);
    get stopIcon(): string;
    set stopIcon(value: string);
    get stopText(): string;
    set stopText(value: string);
    get stylingMode(): ButtonStyle;
    set stylingMode(value: ButtonStyle);
    get tabIndex(): number;
    set tabIndex(value: number);
    get type(): ButtonType | string;
    set type(value: ButtonType | string);
    get visible(): boolean;
    set visible(value: boolean);
    get width(): number | string | undefined;
    set width(value: number | string | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChatSpeechToTextOptionsComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoChatSpeechToTextOptionsComponent, "dxo-chat-speech-to-text-options", never, { "accessKey": { "alias": "accessKey"; "required": false; }; "activeStateEnabled": { "alias": "activeStateEnabled"; "required": false; }; "customSpeechRecognizer": { "alias": "customSpeechRecognizer"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "elementAttr": { "alias": "elementAttr"; "required": false; }; "focusStateEnabled": { "alias": "focusStateEnabled"; "required": false; }; "height": { "alias": "height"; "required": false; }; "hint": { "alias": "hint"; "required": false; }; "hoverStateEnabled": { "alias": "hoverStateEnabled"; "required": false; }; "onContentReady": { "alias": "onContentReady"; "required": false; }; "onDisposing": { "alias": "onDisposing"; "required": false; }; "onEnd": { "alias": "onEnd"; "required": false; }; "onError": { "alias": "onError"; "required": false; }; "onInitialized": { "alias": "onInitialized"; "required": false; }; "onOptionChanged": { "alias": "onOptionChanged"; "required": false; }; "onResult": { "alias": "onResult"; "required": false; }; "onStartClick": { "alias": "onStartClick"; "required": false; }; "onStopClick": { "alias": "onStopClick"; "required": false; }; "rtlEnabled": { "alias": "rtlEnabled"; "required": false; }; "speechRecognitionConfig": { "alias": "speechRecognitionConfig"; "required": false; }; "startIcon": { "alias": "startIcon"; "required": false; }; "startText": { "alias": "startText"; "required": false; }; "stopIcon": { "alias": "stopIcon"; "required": false; }; "stopText": { "alias": "stopText"; "required": false; }; "stylingMode": { "alias": "stylingMode"; "required": false; }; "tabIndex": { "alias": "tabIndex"; "required": false; }; "type": { "alias": "type"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoChatSpeechToTextOptionsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChatSpeechToTextOptionsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoChatSpeechToTextOptionsModule, never, [typeof DxoChatSpeechToTextOptionsComponent], [typeof DxoChatSpeechToTextOptionsComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoChatSpeechToTextOptionsModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxiChatSuggestionsItemComponent extends CollectionNestedOption implements AfterViewInit, IDxTemplateHost {
    private renderer;
    private document;
    private element;
    get disabled(): boolean;
    set disabled(value: boolean);
    get elementAttr(): Record<string, any>;
    set elementAttr(value: Record<string, any>);
    get hint(): string;
    set hint(value: string);
    get icon(): string;
    set icon(value: string);
    get template(): any;
    set template(value: any);
    get text(): string;
    set text(value: string);
    get type(): ButtonType | string;
    set type(value: ButtonType | string);
    get visible(): boolean;
    set visible(value: boolean);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost, renderer: Renderer2, document: any, templateHost: DxTemplateHost, element: ElementRef);
    setTemplate(template: DxTemplateDirective): void;
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiChatSuggestionsItemComponent, [{ host: true; skipSelf: true; }, { host: true; }, null, null, { host: true; }, null]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiChatSuggestionsItemComponent, "dxi-chat-suggestions-item", never, { "disabled": { "alias": "disabled"; "required": false; }; "elementAttr": { "alias": "elementAttr"; "required": false; }; "hint": { "alias": "hint"; "required": false; }; "icon": { "alias": "icon"; "required": false; }; "template": { "alias": "template"; "required": false; }; "text": { "alias": "text"; "required": false; }; "type": { "alias": "type"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; }, {}, never, ["*"], true, never>;
}
declare class DxiChatSuggestionsItemModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiChatSuggestionsItemModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiChatSuggestionsItemModule, never, [typeof DxiChatSuggestionsItemComponent], [typeof DxiChatSuggestionsItemComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiChatSuggestionsItemModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoChatSuggestionsComponent extends NestedOption implements OnDestroy, OnInit {
    set _itemsContentChildren(value: QueryList<CollectionNestedOption>);
    get accessKey(): string | undefined;
    set accessKey(value: string | undefined);
    get activeStateEnabled(): boolean;
    set activeStateEnabled(value: boolean);
    get buttonTemplate(): any;
    set buttonTemplate(value: any);
    get disabled(): boolean;
    set disabled(value: boolean);
    get elementAttr(): Record<string, any>;
    set elementAttr(value: Record<string, any>);
    get focusStateEnabled(): boolean;
    set focusStateEnabled(value: boolean);
    get height(): number | string | undefined;
    set height(value: number | string | undefined);
    get hint(): string | undefined;
    set hint(value: string | undefined);
    get hoverStateEnabled(): boolean;
    set hoverStateEnabled(value: boolean);
    get items(): Array<dxButtonGroupItem>;
    set items(value: Array<dxButtonGroupItem>);
    get keyExpr(): ((item: any) => any) | string;
    set keyExpr(value: ((item: any) => any) | string);
    get onContentReady(): ((e: ContentReadyEvent$2) => void);
    set onContentReady(value: ((e: ContentReadyEvent$2) => void));
    get onDisposing(): ((e: DisposingEvent$2) => void);
    set onDisposing(value: ((e: DisposingEvent$2) => void));
    get onInitialized(): ((e: InitializedEvent$2) => void);
    set onInitialized(value: ((e: InitializedEvent$2) => void));
    get onItemClick(): ((e: ItemClickEvent) => void) | undefined;
    set onItemClick(value: ((e: ItemClickEvent) => void) | undefined);
    get onOptionChanged(): ((e: OptionChangedEvent$2) => void);
    set onOptionChanged(value: ((e: OptionChangedEvent$2) => void));
    get onSelectionChanged(): ((e: SelectionChangedEvent) => void) | undefined;
    set onSelectionChanged(value: ((e: SelectionChangedEvent) => void) | undefined);
    get rtlEnabled(): boolean;
    set rtlEnabled(value: boolean);
    get selectedItemKeys(): Array<any>;
    set selectedItemKeys(value: Array<any>);
    get selectedItems(): Array<any>;
    set selectedItems(value: Array<any>);
    get selectionMode(): SingleMultipleOrNone;
    set selectionMode(value: SingleMultipleOrNone);
    get stylingMode(): ButtonStyle;
    set stylingMode(value: ButtonStyle);
    get tabIndex(): number;
    set tabIndex(value: number);
    get visible(): boolean;
    set visible(value: boolean);
    get width(): number | string | undefined;
    set width(value: number | string | undefined);
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    selectedItemKeysChange: EventEmitter<Array<any>>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    selectedItemsChange: EventEmitter<Array<any>>;
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChatSuggestionsComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoChatSuggestionsComponent, "dxo-chat-suggestions", never, { "accessKey": { "alias": "accessKey"; "required": false; }; "activeStateEnabled": { "alias": "activeStateEnabled"; "required": false; }; "buttonTemplate": { "alias": "buttonTemplate"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "elementAttr": { "alias": "elementAttr"; "required": false; }; "focusStateEnabled": { "alias": "focusStateEnabled"; "required": false; }; "height": { "alias": "height"; "required": false; }; "hint": { "alias": "hint"; "required": false; }; "hoverStateEnabled": { "alias": "hoverStateEnabled"; "required": false; }; "items": { "alias": "items"; "required": false; }; "keyExpr": { "alias": "keyExpr"; "required": false; }; "onContentReady": { "alias": "onContentReady"; "required": false; }; "onDisposing": { "alias": "onDisposing"; "required": false; }; "onInitialized": { "alias": "onInitialized"; "required": false; }; "onItemClick": { "alias": "onItemClick"; "required": false; }; "onOptionChanged": { "alias": "onOptionChanged"; "required": false; }; "onSelectionChanged": { "alias": "onSelectionChanged"; "required": false; }; "rtlEnabled": { "alias": "rtlEnabled"; "required": false; }; "selectedItemKeys": { "alias": "selectedItemKeys"; "required": false; }; "selectedItems": { "alias": "selectedItems"; "required": false; }; "selectionMode": { "alias": "selectionMode"; "required": false; }; "stylingMode": { "alias": "stylingMode"; "required": false; }; "tabIndex": { "alias": "tabIndex"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, { "selectedItemKeysChange": "selectedItemKeysChange"; "selectedItemsChange": "selectedItemsChange"; }, ["_itemsContentChildren"], never, true, never>;
}
declare class DxoChatSuggestionsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChatSuggestionsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoChatSuggestionsModule, never, [typeof DxoChatSuggestionsComponent], [typeof DxoChatSuggestionsComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoChatSuggestionsModule>;
}

declare class DxiChatTypingUserComponent extends CollectionNestedOption {
    get avatarAlt(): string;
    set avatarAlt(value: string);
    get avatarUrl(): string;
    set avatarUrl(value: string);
    get id(): number | string;
    set id(value: number | string);
    get name(): string;
    set name(value: string);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiChatTypingUserComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiChatTypingUserComponent, "dxi-chat-typing-user", never, { "avatarAlt": { "alias": "avatarAlt"; "required": false; }; "avatarUrl": { "alias": "avatarUrl"; "required": false; }; "id": { "alias": "id"; "required": false; }; "name": { "alias": "name"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxiChatTypingUserModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiChatTypingUserModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiChatTypingUserModule, never, [typeof DxiChatTypingUserComponent], [typeof DxiChatTypingUserComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiChatTypingUserModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoChatUserComponent extends NestedOption implements OnDestroy, OnInit {
    get avatarAlt(): string;
    set avatarAlt(value: string);
    get avatarUrl(): string;
    set avatarUrl(value: string);
    get id(): number | string;
    set id(value: number | string);
    get name(): string;
    set name(value: string);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChatUserComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoChatUserComponent, "dxo-chat-user", never, { "avatarAlt": { "alias": "avatarAlt"; "required": false; }; "avatarUrl": { "alias": "avatarUrl"; "required": false; }; "id": { "alias": "id"; "required": false; }; "name": { "alias": "name"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoChatUserModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoChatUserModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoChatUserModule, never, [typeof DxoChatUserComponent], [typeof DxoChatUserComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoChatUserModule>;
}

export { DxiChatAlertComponent, DxiChatAlertModule, DxiChatAttachmentComponent, DxiChatAttachmentModule, DxiChatChatItemComponent, DxiChatChatItemModule, DxiChatItemComponent, DxiChatItemModule, DxiChatSuggestionsItemComponent, DxiChatSuggestionsItemModule, DxiChatTypingUserComponent, DxiChatTypingUserModule, DxoChatAuthorComponent, DxoChatAuthorModule, DxoChatCustomSpeechRecognizerComponent, DxoChatCustomSpeechRecognizerModule, DxoChatDayHeaderFormatComponent, DxoChatDayHeaderFormatModule, DxoChatEditingComponent, DxoChatEditingModule, DxoChatFileUploaderOptionsComponent, DxoChatFileUploaderOptionsModule, DxoChatMessageTimestampFormatComponent, DxoChatMessageTimestampFormatModule, DxoChatSendButtonOptionsComponent, DxoChatSendButtonOptionsModule, DxoChatSpeechRecognitionConfigComponent, DxoChatSpeechRecognitionConfigModule, DxoChatSpeechToTextOptionsComponent, DxoChatSpeechToTextOptionsModule, DxoChatSuggestionsComponent, DxoChatSuggestionsModule, DxoChatUserComponent, DxoChatUserModule };
//# sourceMappingURL=index.d.ts.map
