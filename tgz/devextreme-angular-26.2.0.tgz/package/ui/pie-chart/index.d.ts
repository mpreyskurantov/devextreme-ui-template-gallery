import * as i0 from '@angular/core';
import { OnDestroy, OnChanges, DoCheck, QueryList, EventEmitter, ElementRef, NgZone, TransferState, SimpleChanges } from '@angular/core';
import { AnimationEaseMode, ChartsDataType, DashStyle, ChartsColor, HatchDirection, Font, LabelPosition, TextOverflow, WordWrap, SeriesLabel, SeriesPoint, Palette, PaletteExtensionMode, ShiftLabelOverlap, Theme } from 'devextreme/common/charts';
import DxPieChart, { dxPieChartAnnotationConfig, dxPieChartCommonAnnotationConfig, PieChartSeriesInteractionMode, SmallValuesGroupingMode, PieChartLegendItem, PieChartLegendHoverMode, PieChartSegmentDirection, PieChartSeries, dxPieChartPointInfo, PieChartType, DisposingEvent, DoneEvent, DrawnEvent, ExportedEvent, ExportingEvent, FileSavingEvent, IncidentOccurredEvent, InitializedEvent, LegendClickEvent, OptionChangedEvent, PointClickEvent, PointHoverChangedEvent, PointSelectionChangedEvent, TooltipHiddenEvent, TooltipShownEvent } from 'devextreme/viz/pie_chart';
import { Format } from 'devextreme/common/core/localization';
import DataSource, { DataSourceOptions } from 'devextreme/data/data_source';
import { Store } from 'devextreme/data/store';
import { ExportFormat, HorizontalAlignment, Position, Orientation, VerticalEdge, SingleOrMultiple } from 'devextreme/common';
import * as i3 from 'devextreme-angular/core';
import { DxComponent, CollectionNestedOption, DxTemplateHost, WatcherHelper, IterableDifferHelper, NestedOptionHost } from 'devextreme-angular/core';
import * as i1 from 'devextreme-angular/ui/nested';
import * as i2 from 'devextreme-angular/ui/pie-chart/nested';
export * from 'devextreme-angular/ui/pie-chart/nested';
import * as pie_chart_types from 'devextreme/viz/pie_chart_types';
export { pie_chart_types as DxPieChartTypes };

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

/**
 * [descr:dxPieChart]

 */
declare class DxPieChartComponent extends DxComponent implements OnDestroy, OnChanges, DoCheck {
    private _watcherHelper;
    private _idh;
    set _annotationsContentChildren(value: QueryList<CollectionNestedOption>);
    set _seriesContentChildren(value: QueryList<CollectionNestedOption>);
    instance: DxPieChart;
    /**
     * [descr:dxPieChartOptions.adaptiveLayout]
    
     */
    get adaptiveLayout(): {
        height?: number;
        keepLabels?: boolean;
        width?: number;
    };
    set adaptiveLayout(value: {
        height?: number;
        keepLabels?: boolean;
        width?: number;
    });
    /**
     * [descr:BaseChartOptions.animation]
    
     */
    get animation(): boolean | {
        duration?: number;
        easing?: AnimationEaseMode;
        enabled?: boolean;
        maxPointCountSupported?: number;
    };
    set animation(value: boolean | {
        duration?: number;
        easing?: AnimationEaseMode;
        enabled?: boolean;
        maxPointCountSupported?: number;
    });
    /**
     * [descr:dxPieChartOptions.annotations]
    
     */
    get annotations(): Array<any | dxPieChartAnnotationConfig>;
    set annotations(value: Array<any | dxPieChartAnnotationConfig>);
    /**
     * [descr:dxPieChartOptions.centerTemplate]
    
     */
    get centerTemplate(): any;
    set centerTemplate(value: any);
    /**
     * [descr:dxPieChartOptions.commonAnnotationSettings]
    
     */
    get commonAnnotationSettings(): dxPieChartCommonAnnotationConfig;
    set commonAnnotationSettings(value: dxPieChartCommonAnnotationConfig);
    /**
     * [descr:dxPieChartOptions.commonSeriesSettings]
    
     */
    get commonSeriesSettings(): any | {
        argumentField?: string;
        argumentType?: ChartsDataType | undefined;
        border?: {
            color?: string | undefined;
            dashStyle?: DashStyle | undefined;
            visible?: boolean;
            width?: number;
        };
        color?: ChartsColor | string | undefined;
        hoverMode?: PieChartSeriesInteractionMode;
        hoverStyle?: {
            border?: {
                color?: string | undefined;
                dashStyle?: DashStyle | undefined;
                visible?: boolean;
                width?: number;
            };
            color?: ChartsColor | string | undefined;
            hatching?: {
                direction?: HatchDirection;
                opacity?: number;
                step?: number;
                width?: number;
            };
            highlight?: boolean;
        };
        label?: {
            argumentFormat?: Format | undefined;
            backgroundColor?: string | undefined;
            border?: {
                color?: string | undefined;
                dashStyle?: DashStyle | undefined;
                visible?: boolean;
                width?: number;
            };
            connector?: {
                color?: string | undefined;
                visible?: boolean;
                width?: number;
            };
            customizeText?: ((pointInfo: any) => string);
            displayFormat?: string | undefined;
            font?: Font;
            format?: Format | undefined;
            position?: LabelPosition;
            radialOffset?: number;
            rotationAngle?: number;
            textOverflow?: TextOverflow;
            visible?: boolean;
            wordWrap?: WordWrap;
        };
        maxLabelCount?: number | undefined;
        minSegmentSize?: number | undefined;
        selectionMode?: PieChartSeriesInteractionMode;
        selectionStyle?: {
            border?: {
                color?: string | undefined;
                dashStyle?: DashStyle | undefined;
                visible?: boolean;
                width?: number;
            };
            color?: ChartsColor | string | undefined;
            hatching?: {
                direction?: HatchDirection;
                opacity?: number;
                step?: number;
                width?: number;
            };
            highlight?: boolean;
        };
        smallValuesGrouping?: {
            groupName?: string;
            mode?: SmallValuesGroupingMode;
            threshold?: number | undefined;
            topCount?: number | undefined;
        };
        tagField?: string;
        valueField?: string;
    };
    set commonSeriesSettings(value: any | {
        argumentField?: string;
        argumentType?: ChartsDataType | undefined;
        border?: {
            color?: string | undefined;
            dashStyle?: DashStyle | undefined;
            visible?: boolean;
            width?: number;
        };
        color?: ChartsColor | string | undefined;
        hoverMode?: PieChartSeriesInteractionMode;
        hoverStyle?: {
            border?: {
                color?: string | undefined;
                dashStyle?: DashStyle | undefined;
                visible?: boolean;
                width?: number;
            };
            color?: ChartsColor | string | undefined;
            hatching?: {
                direction?: HatchDirection;
                opacity?: number;
                step?: number;
                width?: number;
            };
            highlight?: boolean;
        };
        label?: {
            argumentFormat?: Format | undefined;
            backgroundColor?: string | undefined;
            border?: {
                color?: string | undefined;
                dashStyle?: DashStyle | undefined;
                visible?: boolean;
                width?: number;
            };
            connector?: {
                color?: string | undefined;
                visible?: boolean;
                width?: number;
            };
            customizeText?: ((pointInfo: any) => string);
            displayFormat?: string | undefined;
            font?: Font;
            format?: Format | undefined;
            position?: LabelPosition;
            radialOffset?: number;
            rotationAngle?: number;
            textOverflow?: TextOverflow;
            visible?: boolean;
            wordWrap?: WordWrap;
        };
        maxLabelCount?: number | undefined;
        minSegmentSize?: number | undefined;
        selectionMode?: PieChartSeriesInteractionMode;
        selectionStyle?: {
            border?: {
                color?: string | undefined;
                dashStyle?: DashStyle | undefined;
                visible?: boolean;
                width?: number;
            };
            color?: ChartsColor | string | undefined;
            hatching?: {
                direction?: HatchDirection;
                opacity?: number;
                step?: number;
                width?: number;
            };
            highlight?: boolean;
        };
        smallValuesGrouping?: {
            groupName?: string;
            mode?: SmallValuesGroupingMode;
            threshold?: number | undefined;
            topCount?: number | undefined;
        };
        tagField?: string;
        valueField?: string;
    });
    /**
     * [descr:dxPieChartOptions.customizeAnnotation]
    
     */
    get customizeAnnotation(): ((annotation: dxPieChartAnnotationConfig | any) => dxPieChartAnnotationConfig) | undefined;
    set customizeAnnotation(value: ((annotation: dxPieChartAnnotationConfig | any) => dxPieChartAnnotationConfig) | undefined);
    /**
     * [descr:BaseChartOptions.customizeLabel]
    
     */
    get customizeLabel(): ((pointInfo: any) => SeriesLabel);
    set customizeLabel(value: ((pointInfo: any) => SeriesLabel));
    /**
     * [descr:BaseChartOptions.customizePoint]
    
     */
    get customizePoint(): ((pointInfo: any) => SeriesPoint);
    set customizePoint(value: ((pointInfo: any) => SeriesPoint));
    /**
     * [descr:BaseChartOptions.dataSource]
    
     */
    get dataSource(): Array<any> | DataSource | DataSourceOptions | null | Store | string;
    set dataSource(value: Array<any> | DataSource | DataSourceOptions | null | Store | string);
    /**
     * [descr:dxPieChartOptions.diameter]
    
     */
    get diameter(): number | undefined;
    set diameter(value: number | undefined);
    /**
     * [descr:BaseWidgetOptions.disabled]
    
     */
    get disabled(): boolean;
    set disabled(value: boolean);
    /**
     * [descr:DOMComponentOptions.elementAttr]
    
     */
    get elementAttr(): Record<string, any>;
    set elementAttr(value: Record<string, any>);
    /**
     * [descr:BaseWidgetOptions.encodeHtml]
    
     */
    get encodeHtml(): boolean;
    set encodeHtml(value: boolean);
    /**
     * [descr:BaseWidgetOptions.export]
    
     */
    get export(): {
        backgroundColor?: string;
        enabled?: boolean;
        fileName?: string;
        formats?: Array<ExportFormat>;
        margin?: number;
        printingEnabled?: boolean;
        svgToCanvas?: ((svg: any, canvas: any) => any) | undefined;
    };
    set export(value: {
        backgroundColor?: string;
        enabled?: boolean;
        fileName?: string;
        formats?: Array<ExportFormat>;
        margin?: number;
        printingEnabled?: boolean;
        svgToCanvas?: ((svg: any, canvas: any) => any) | undefined;
    });
    /**
     * [descr:dxPieChartOptions.innerRadius]
    
     */
    get innerRadius(): number;
    set innerRadius(value: number);
    /**
     * [descr:dxPieChartOptions.legend]
    
     */
    get legend(): {
        backgroundColor?: string | undefined;
        border?: {
            color?: string;
            cornerRadius?: number;
            dashStyle?: DashStyle;
            opacity?: number | undefined;
            visible?: boolean;
            width?: number;
        };
        columnCount?: number;
        columnItemSpacing?: number;
        customizeHint?: ((pointInfo: {
            pointColor: string;
            pointIndex: number;
            pointName: any;
        }) => string);
        customizeItems?: ((items: Array<PieChartLegendItem>) => Array<PieChartLegendItem>);
        customizeText?: ((pointInfo: {
            pointColor: string;
            pointIndex: number;
            pointName: any;
        }) => string);
        font?: Font;
        horizontalAlignment?: HorizontalAlignment;
        hoverMode?: PieChartLegendHoverMode;
        itemsAlignment?: HorizontalAlignment | undefined;
        itemTextPosition?: Position | undefined;
        margin?: number | {
            bottom?: number;
            left?: number;
            right?: number;
            top?: number;
        };
        markerSize?: number;
        markerTemplate?: any;
        orientation?: Orientation | undefined;
        paddingLeftRight?: number;
        paddingTopBottom?: number;
        rowCount?: number;
        rowItemSpacing?: number;
        title?: string | {
            font?: Font;
            horizontalAlignment?: HorizontalAlignment | undefined;
            margin?: {
                bottom?: number;
                left?: number;
                right?: number;
                top?: number;
            };
            placeholderSize?: number | undefined;
            subtitle?: string | {
                font?: Font;
                offset?: number;
                text?: string | undefined;
            };
            text?: string | undefined;
            verticalAlignment?: VerticalEdge;
        };
        verticalAlignment?: VerticalEdge;
        visible?: boolean;
    };
    set legend(value: {
        backgroundColor?: string | undefined;
        border?: {
            color?: string;
            cornerRadius?: number;
            dashStyle?: DashStyle;
            opacity?: number | undefined;
            visible?: boolean;
            width?: number;
        };
        columnCount?: number;
        columnItemSpacing?: number;
        customizeHint?: ((pointInfo: {
            pointColor: string;
            pointIndex: number;
            pointName: any;
        }) => string);
        customizeItems?: ((items: Array<PieChartLegendItem>) => Array<PieChartLegendItem>);
        customizeText?: ((pointInfo: {
            pointColor: string;
            pointIndex: number;
            pointName: any;
        }) => string);
        font?: Font;
        horizontalAlignment?: HorizontalAlignment;
        hoverMode?: PieChartLegendHoverMode;
        itemsAlignment?: HorizontalAlignment | undefined;
        itemTextPosition?: Position | undefined;
        margin?: number | {
            bottom?: number;
            left?: number;
            right?: number;
            top?: number;
        };
        markerSize?: number;
        markerTemplate?: any;
        orientation?: Orientation | undefined;
        paddingLeftRight?: number;
        paddingTopBottom?: number;
        rowCount?: number;
        rowItemSpacing?: number;
        title?: string | {
            font?: Font;
            horizontalAlignment?: HorizontalAlignment | undefined;
            margin?: {
                bottom?: number;
                left?: number;
                right?: number;
                top?: number;
            };
            placeholderSize?: number | undefined;
            subtitle?: string | {
                font?: Font;
                offset?: number;
                text?: string | undefined;
            };
            text?: string | undefined;
            verticalAlignment?: VerticalEdge;
        };
        verticalAlignment?: VerticalEdge;
        visible?: boolean;
    });
    /**
     * [descr:BaseWidgetOptions.loadingIndicator]
    
     */
    get loadingIndicator(): {
        backgroundColor?: string;
        enabled?: boolean;
        font?: Font;
        show?: boolean;
        text?: string;
    };
    set loadingIndicator(value: {
        backgroundColor?: string;
        enabled?: boolean;
        font?: Font;
        show?: boolean;
        text?: string;
    });
    /**
     * [descr:BaseWidgetOptions.margin]
    
     */
    get margin(): {
        bottom?: number;
        left?: number;
        right?: number;
        top?: number;
    };
    set margin(value: {
        bottom?: number;
        left?: number;
        right?: number;
        top?: number;
    });
    /**
     * [descr:dxPieChartOptions.minDiameter]
    
     */
    get minDiameter(): number;
    set minDiameter(value: number);
    /**
     * [descr:dxPieChartOptions.palette]
    
     */
    get palette(): Array<string> | Palette;
    set palette(value: Array<string> | Palette);
    /**
     * [descr:BaseChartOptions.paletteExtensionMode]
    
     */
    get paletteExtensionMode(): PaletteExtensionMode;
    set paletteExtensionMode(value: PaletteExtensionMode);
    /**
     * [descr:BaseWidgetOptions.pathModified]
    
     */
    get pathModified(): boolean;
    set pathModified(value: boolean);
    /**
     * [descr:BaseChartOptions.pointSelectionMode]
    
     */
    get pointSelectionMode(): SingleOrMultiple;
    set pointSelectionMode(value: SingleOrMultiple);
    /**
     * [descr:BaseWidgetOptions.redrawOnResize]
    
     */
    get redrawOnResize(): boolean;
    set redrawOnResize(value: boolean);
    /**
     * [descr:dxPieChartOptions.resolveLabelOverlapping]
    
     */
    get resolveLabelOverlapping(): ShiftLabelOverlap;
    set resolveLabelOverlapping(value: ShiftLabelOverlap);
    /**
     * [descr:BaseWidgetOptions.rtlEnabled]
    
     */
    get rtlEnabled(): boolean;
    set rtlEnabled(value: boolean);
    /**
     * [descr:dxPieChartOptions.segmentsDirection]
    
     */
    get segmentsDirection(): PieChartSegmentDirection;
    set segmentsDirection(value: PieChartSegmentDirection);
    /**
     * [descr:dxPieChartOptions.series]
    
     */
    get series(): Array<PieChartSeries> | PieChartSeries | undefined;
    set series(value: Array<PieChartSeries> | PieChartSeries | undefined);
    /**
     * [descr:dxPieChartOptions.seriesTemplate]
    
     */
    get seriesTemplate(): any;
    set seriesTemplate(value: any);
    /**
     * [descr:BaseWidgetOptions.size]
    
     */
    get size(): {
        height?: number | undefined;
        width?: number | undefined;
    };
    set size(value: {
        height?: number | undefined;
        width?: number | undefined;
    });
    /**
     * [descr:dxPieChartOptions.sizeGroup]
    
     */
    get sizeGroup(): string | undefined;
    set sizeGroup(value: string | undefined);
    /**
     * [descr:dxPieChartOptions.startAngle]
    
     */
    get startAngle(): number;
    set startAngle(value: number);
    /**
     * [descr:BaseWidgetOptions.theme]
    
     */
    get theme(): Theme;
    set theme(value: Theme);
    /**
     * [descr:BaseWidgetOptions.title]
    
     */
    get title(): string | {
        font?: Font;
        horizontalAlignment?: HorizontalAlignment;
        margin?: number | {
            bottom?: number;
            left?: number;
            right?: number;
            top?: number;
        };
        placeholderSize?: number | undefined;
        subtitle?: string | {
            font?: Font;
            offset?: number;
            text?: string | undefined;
            textOverflow?: TextOverflow;
            wordWrap?: WordWrap;
        };
        text?: string | undefined;
        textOverflow?: TextOverflow;
        verticalAlignment?: VerticalEdge;
        wordWrap?: WordWrap;
    };
    set title(value: string | {
        font?: Font;
        horizontalAlignment?: HorizontalAlignment;
        margin?: number | {
            bottom?: number;
            left?: number;
            right?: number;
            top?: number;
        };
        placeholderSize?: number | undefined;
        subtitle?: string | {
            font?: Font;
            offset?: number;
            text?: string | undefined;
            textOverflow?: TextOverflow;
            wordWrap?: WordWrap;
        };
        text?: string | undefined;
        textOverflow?: TextOverflow;
        verticalAlignment?: VerticalEdge;
        wordWrap?: WordWrap;
    });
    /**
     * [descr:dxPieChartOptions.tooltip]
    
     */
    get tooltip(): {
        argumentFormat?: Format | undefined;
        arrowLength?: number;
        border?: {
            color?: string;
            dashStyle?: DashStyle;
            opacity?: number | undefined;
            visible?: boolean;
            width?: number;
        };
        color?: string;
        container?: any | string | undefined;
        contentTemplate?: any;
        cornerRadius?: number;
        customizeTooltip?: ((pointInfo: dxPieChartPointInfo) => Record<string, any>) | undefined;
        enabled?: boolean;
        font?: Font;
        format?: Format | undefined;
        interactive?: boolean;
        opacity?: number | undefined;
        paddingLeftRight?: number;
        paddingTopBottom?: number;
        shadow?: {
            blur?: number;
            color?: string;
            offsetX?: number;
            offsetY?: number;
            opacity?: number;
        };
        shared?: boolean;
        zIndex?: number | undefined;
    };
    set tooltip(value: {
        argumentFormat?: Format | undefined;
        arrowLength?: number;
        border?: {
            color?: string;
            dashStyle?: DashStyle;
            opacity?: number | undefined;
            visible?: boolean;
            width?: number;
        };
        color?: string;
        container?: any | string | undefined;
        contentTemplate?: any;
        cornerRadius?: number;
        customizeTooltip?: ((pointInfo: dxPieChartPointInfo) => Record<string, any>) | undefined;
        enabled?: boolean;
        font?: Font;
        format?: Format | undefined;
        interactive?: boolean;
        opacity?: number | undefined;
        paddingLeftRight?: number;
        paddingTopBottom?: number;
        shadow?: {
            blur?: number;
            color?: string;
            offsetX?: number;
            offsetY?: number;
            opacity?: number;
        };
        shared?: boolean;
        zIndex?: number | undefined;
    });
    /**
     * [descr:dxPieChartOptions.type]
    
     */
    get type(): PieChartType;
    set type(value: PieChartType);
    /**
    
     * [descr:dxPieChartOptions.onDisposing]
    
    
     */
    onDisposing: EventEmitter<DisposingEvent>;
    /**
    
     * [descr:dxPieChartOptions.onDone]
    
    
     */
    onDone: EventEmitter<DoneEvent>;
    /**
    
     * [descr:dxPieChartOptions.onDrawn]
    
    
     */
    onDrawn: EventEmitter<DrawnEvent>;
    /**
    
     * [descr:dxPieChartOptions.onExported]
    
    
     */
    onExported: EventEmitter<ExportedEvent>;
    /**
    
     * [descr:dxPieChartOptions.onExporting]
    
    
     */
    onExporting: EventEmitter<ExportingEvent>;
    /**
    
     * [descr:dxPieChartOptions.onFileSaving]
    
    
     */
    onFileSaving: EventEmitter<FileSavingEvent>;
    /**
    
     * [descr:dxPieChartOptions.onIncidentOccurred]
    
    
     */
    onIncidentOccurred: EventEmitter<IncidentOccurredEvent>;
    /**
    
     * [descr:dxPieChartOptions.onInitialized]
    
    
     */
    onInitialized: EventEmitter<InitializedEvent>;
    /**
    
     * [descr:dxPieChartOptions.onLegendClick]
    
    
     */
    onLegendClick: EventEmitter<LegendClickEvent>;
    /**
    
     * [descr:dxPieChartOptions.onOptionChanged]
    
    
     */
    onOptionChanged: EventEmitter<OptionChangedEvent>;
    /**
    
     * [descr:dxPieChartOptions.onPointClick]
    
    
     */
    onPointClick: EventEmitter<PointClickEvent>;
    /**
    
     * [descr:dxPieChartOptions.onPointHoverChanged]
    
    
     */
    onPointHoverChanged: EventEmitter<PointHoverChangedEvent>;
    /**
    
     * [descr:dxPieChartOptions.onPointSelectionChanged]
    
    
     */
    onPointSelectionChanged: EventEmitter<PointSelectionChangedEvent>;
    /**
    
     * [descr:dxPieChartOptions.onTooltipHidden]
    
    
     */
    onTooltipHidden: EventEmitter<TooltipHiddenEvent>;
    /**
    
     * [descr:dxPieChartOptions.onTooltipShown]
    
    
     */
    onTooltipShown: EventEmitter<TooltipShownEvent>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    adaptiveLayoutChange: EventEmitter<{
        height?: number;
        keepLabels?: boolean;
        width?: number;
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    animationChange: EventEmitter<boolean | {
        duration?: number;
        easing?: AnimationEaseMode;
        enabled?: boolean;
        maxPointCountSupported?: number;
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    annotationsChange: EventEmitter<Array<any | dxPieChartAnnotationConfig>>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    centerTemplateChange: EventEmitter<any>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    commonAnnotationSettingsChange: EventEmitter<dxPieChartCommonAnnotationConfig>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    commonSeriesSettingsChange: EventEmitter<any | {
        argumentField?: string;
        argumentType?: ChartsDataType | undefined;
        border?: {
            color?: string | undefined;
            dashStyle?: DashStyle | undefined;
            visible?: boolean;
            width?: number;
        };
        color?: ChartsColor | string | undefined;
        hoverMode?: PieChartSeriesInteractionMode;
        hoverStyle?: {
            border?: {
                color?: string | undefined;
                dashStyle?: DashStyle | undefined;
                visible?: boolean;
                width?: number;
            };
            color?: ChartsColor | string | undefined;
            hatching?: {
                direction?: HatchDirection;
                opacity?: number;
                step?: number;
                width?: number;
            };
            highlight?: boolean;
        };
        label?: {
            argumentFormat?: Format | undefined;
            backgroundColor?: string | undefined;
            border?: {
                color?: string | undefined;
                dashStyle?: DashStyle | undefined;
                visible?: boolean;
                width?: number;
            };
            connector?: {
                color?: string | undefined;
                visible?: boolean;
                width?: number;
            };
            customizeText?: ((pointInfo: any) => string);
            displayFormat?: string | undefined;
            font?: Font;
            format?: Format | undefined;
            position?: LabelPosition;
            radialOffset?: number;
            rotationAngle?: number;
            textOverflow?: TextOverflow;
            visible?: boolean;
            wordWrap?: WordWrap;
        };
        maxLabelCount?: number | undefined;
        minSegmentSize?: number | undefined;
        selectionMode?: PieChartSeriesInteractionMode;
        selectionStyle?: {
            border?: {
                color?: string | undefined;
                dashStyle?: DashStyle | undefined;
                visible?: boolean;
                width?: number;
            };
            color?: ChartsColor | string | undefined;
            hatching?: {
                direction?: HatchDirection;
                opacity?: number;
                step?: number;
                width?: number;
            };
            highlight?: boolean;
        };
        smallValuesGrouping?: {
            groupName?: string;
            mode?: SmallValuesGroupingMode;
            threshold?: number | undefined;
            topCount?: number | undefined;
        };
        tagField?: string;
        valueField?: string;
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    customizeAnnotationChange: EventEmitter<((annotation: dxPieChartAnnotationConfig | any) => dxPieChartAnnotationConfig) | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    customizeLabelChange: EventEmitter<((pointInfo: any) => SeriesLabel)>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    customizePointChange: EventEmitter<((pointInfo: any) => SeriesPoint)>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    dataSourceChange: EventEmitter<Array<any> | DataSource | DataSourceOptions | null | Store | string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    diameterChange: EventEmitter<number | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    disabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    elementAttrChange: EventEmitter<Record<string, any>>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    encodeHtmlChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    exportChange: EventEmitter<{
        backgroundColor?: string;
        enabled?: boolean;
        fileName?: string;
        formats?: Array<ExportFormat>;
        margin?: number;
        printingEnabled?: boolean;
        svgToCanvas?: ((svg: any, canvas: any) => any) | undefined;
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    innerRadiusChange: EventEmitter<number>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    legendChange: EventEmitter<{
        backgroundColor?: string | undefined;
        border?: {
            color?: string;
            cornerRadius?: number;
            dashStyle?: DashStyle;
            opacity?: number | undefined;
            visible?: boolean;
            width?: number;
        };
        columnCount?: number;
        columnItemSpacing?: number;
        customizeHint?: ((pointInfo: {
            pointColor: string;
            pointIndex: number;
            pointName: any;
        }) => string);
        customizeItems?: ((items: Array<PieChartLegendItem>) => Array<PieChartLegendItem>);
        customizeText?: ((pointInfo: {
            pointColor: string;
            pointIndex: number;
            pointName: any;
        }) => string);
        font?: Font;
        horizontalAlignment?: HorizontalAlignment;
        hoverMode?: PieChartLegendHoverMode;
        itemsAlignment?: HorizontalAlignment | undefined;
        itemTextPosition?: Position | undefined;
        margin?: number | {
            bottom?: number;
            left?: number;
            right?: number;
            top?: number;
        };
        markerSize?: number;
        markerTemplate?: any;
        orientation?: Orientation | undefined;
        paddingLeftRight?: number;
        paddingTopBottom?: number;
        rowCount?: number;
        rowItemSpacing?: number;
        title?: string | {
            font?: Font;
            horizontalAlignment?: HorizontalAlignment | undefined;
            margin?: {
                bottom?: number;
                left?: number;
                right?: number;
                top?: number;
            };
            placeholderSize?: number | undefined;
            subtitle?: string | {
                font?: Font;
                offset?: number;
                text?: string | undefined;
            };
            text?: string | undefined;
            verticalAlignment?: VerticalEdge;
        };
        verticalAlignment?: VerticalEdge;
        visible?: boolean;
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    loadingIndicatorChange: EventEmitter<{
        backgroundColor?: string;
        enabled?: boolean;
        font?: Font;
        show?: boolean;
        text?: string;
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    marginChange: EventEmitter<{
        bottom?: number;
        left?: number;
        right?: number;
        top?: number;
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    minDiameterChange: EventEmitter<number>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    paletteChange: EventEmitter<Array<string> | Palette>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    paletteExtensionModeChange: EventEmitter<PaletteExtensionMode>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    pathModifiedChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    pointSelectionModeChange: EventEmitter<SingleOrMultiple>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    redrawOnResizeChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    resolveLabelOverlappingChange: EventEmitter<ShiftLabelOverlap>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    rtlEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    segmentsDirectionChange: EventEmitter<PieChartSegmentDirection>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    seriesChange: EventEmitter<Array<PieChartSeries> | PieChartSeries | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    seriesTemplateChange: EventEmitter<any>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    sizeChange: EventEmitter<{
        height?: number | undefined;
        width?: number | undefined;
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    sizeGroupChange: EventEmitter<string | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    startAngleChange: EventEmitter<number>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    themeChange: EventEmitter<Theme>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    titleChange: EventEmitter<string | {
        font?: Font;
        horizontalAlignment?: HorizontalAlignment;
        margin?: number | {
            bottom?: number;
            left?: number;
            right?: number;
            top?: number;
        };
        placeholderSize?: number | undefined;
        subtitle?: string | {
            font?: Font;
            offset?: number;
            text?: string | undefined;
            textOverflow?: TextOverflow;
            wordWrap?: WordWrap;
        };
        text?: string | undefined;
        textOverflow?: TextOverflow;
        verticalAlignment?: VerticalEdge;
        wordWrap?: WordWrap;
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    tooltipChange: EventEmitter<{
        argumentFormat?: Format | undefined;
        arrowLength?: number;
        border?: {
            color?: string;
            dashStyle?: DashStyle;
            opacity?: number | undefined;
            visible?: boolean;
            width?: number;
        };
        color?: string;
        container?: any | string | undefined;
        contentTemplate?: any;
        cornerRadius?: number;
        customizeTooltip?: ((pointInfo: dxPieChartPointInfo) => Record<string, any>) | undefined;
        enabled?: boolean;
        font?: Font;
        format?: Format | undefined;
        interactive?: boolean;
        opacity?: number | undefined;
        paddingLeftRight?: number;
        paddingTopBottom?: number;
        shadow?: {
            blur?: number;
            color?: string;
            offsetX?: number;
            offsetY?: number;
            opacity?: number;
        };
        shared?: boolean;
        zIndex?: number | undefined;
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    typeChange: EventEmitter<PieChartType>;
    constructor(elementRef: ElementRef, ngZone: NgZone, templateHost: DxTemplateHost, _watcherHelper: WatcherHelper, _idh: IterableDifferHelper, optionHost: NestedOptionHost, transferState: TransferState, platformId: any);
    protected _createInstance(element: any, options: any): DxPieChart;
    ngOnDestroy(): void;
    ngOnChanges(changes: SimpleChanges): void;
    setupChanges(prop: string, changes: SimpleChanges): void;
    ngDoCheck(): void;
    _setOption(name: string, value: any): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxPieChartComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxPieChartComponent, "dx-pie-chart", never, { "adaptiveLayout": { "alias": "adaptiveLayout"; "required": false; }; "animation": { "alias": "animation"; "required": false; }; "annotations": { "alias": "annotations"; "required": false; }; "centerTemplate": { "alias": "centerTemplate"; "required": false; }; "commonAnnotationSettings": { "alias": "commonAnnotationSettings"; "required": false; }; "commonSeriesSettings": { "alias": "commonSeriesSettings"; "required": false; }; "customizeAnnotation": { "alias": "customizeAnnotation"; "required": false; }; "customizeLabel": { "alias": "customizeLabel"; "required": false; }; "customizePoint": { "alias": "customizePoint"; "required": false; }; "dataSource": { "alias": "dataSource"; "required": false; }; "diameter": { "alias": "diameter"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "elementAttr": { "alias": "elementAttr"; "required": false; }; "encodeHtml": { "alias": "encodeHtml"; "required": false; }; "export": { "alias": "export"; "required": false; }; "innerRadius": { "alias": "innerRadius"; "required": false; }; "legend": { "alias": "legend"; "required": false; }; "loadingIndicator": { "alias": "loadingIndicator"; "required": false; }; "margin": { "alias": "margin"; "required": false; }; "minDiameter": { "alias": "minDiameter"; "required": false; }; "palette": { "alias": "palette"; "required": false; }; "paletteExtensionMode": { "alias": "paletteExtensionMode"; "required": false; }; "pathModified": { "alias": "pathModified"; "required": false; }; "pointSelectionMode": { "alias": "pointSelectionMode"; "required": false; }; "redrawOnResize": { "alias": "redrawOnResize"; "required": false; }; "resolveLabelOverlapping": { "alias": "resolveLabelOverlapping"; "required": false; }; "rtlEnabled": { "alias": "rtlEnabled"; "required": false; }; "segmentsDirection": { "alias": "segmentsDirection"; "required": false; }; "series": { "alias": "series"; "required": false; }; "seriesTemplate": { "alias": "seriesTemplate"; "required": false; }; "size": { "alias": "size"; "required": false; }; "sizeGroup": { "alias": "sizeGroup"; "required": false; }; "startAngle": { "alias": "startAngle"; "required": false; }; "theme": { "alias": "theme"; "required": false; }; "title": { "alias": "title"; "required": false; }; "tooltip": { "alias": "tooltip"; "required": false; }; "type": { "alias": "type"; "required": false; }; }, { "onDisposing": "onDisposing"; "onDone": "onDone"; "onDrawn": "onDrawn"; "onExported": "onExported"; "onExporting": "onExporting"; "onFileSaving": "onFileSaving"; "onIncidentOccurred": "onIncidentOccurred"; "onInitialized": "onInitialized"; "onLegendClick": "onLegendClick"; "onOptionChanged": "onOptionChanged"; "onPointClick": "onPointClick"; "onPointHoverChanged": "onPointHoverChanged"; "onPointSelectionChanged": "onPointSelectionChanged"; "onTooltipHidden": "onTooltipHidden"; "onTooltipShown": "onTooltipShown"; "adaptiveLayoutChange": "adaptiveLayoutChange"; "animationChange": "animationChange"; "annotationsChange": "annotationsChange"; "centerTemplateChange": "centerTemplateChange"; "commonAnnotationSettingsChange": "commonAnnotationSettingsChange"; "commonSeriesSettingsChange": "commonSeriesSettingsChange"; "customizeAnnotationChange": "customizeAnnotationChange"; "customizeLabelChange": "customizeLabelChange"; "customizePointChange": "customizePointChange"; "dataSourceChange": "dataSourceChange"; "diameterChange": "diameterChange"; "disabledChange": "disabledChange"; "elementAttrChange": "elementAttrChange"; "encodeHtmlChange": "encodeHtmlChange"; "exportChange": "exportChange"; "innerRadiusChange": "innerRadiusChange"; "legendChange": "legendChange"; "loadingIndicatorChange": "loadingIndicatorChange"; "marginChange": "marginChange"; "minDiameterChange": "minDiameterChange"; "paletteChange": "paletteChange"; "paletteExtensionModeChange": "paletteExtensionModeChange"; "pathModifiedChange": "pathModifiedChange"; "pointSelectionModeChange": "pointSelectionModeChange"; "redrawOnResizeChange": "redrawOnResizeChange"; "resolveLabelOverlappingChange": "resolveLabelOverlappingChange"; "rtlEnabledChange": "rtlEnabledChange"; "segmentsDirectionChange": "segmentsDirectionChange"; "seriesChange": "seriesChange"; "seriesTemplateChange": "seriesTemplateChange"; "sizeChange": "sizeChange"; "sizeGroupChange": "sizeGroupChange"; "startAngleChange": "startAngleChange"; "themeChange": "themeChange"; "titleChange": "titleChange"; "tooltipChange": "tooltipChange"; "typeChange": "typeChange"; }, ["_annotationsContentChildren", "_seriesContentChildren"], never, true, never>;
}
declare class DxPieChartModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxPieChartModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxPieChartModule, never, [typeof DxPieChartComponent, typeof i1.DxoAdaptiveLayoutModule, typeof i1.DxoAnimationModule, typeof i1.DxiAnnotationModule, typeof i1.DxoBorderModule, typeof i1.DxoFontModule, typeof i1.DxoImageModule, typeof i1.DxoShadowModule, typeof i1.DxoCommonAnnotationSettingsModule, typeof i1.DxoCommonSeriesSettingsModule, typeof i1.DxoColorModule, typeof i1.DxoHoverStyleModule, typeof i1.DxoHatchingModule, typeof i1.DxoLabelModule, typeof i1.DxoArgumentFormatModule, typeof i1.DxoConnectorModule, typeof i1.DxoFormatModule, typeof i1.DxoSelectionStyleModule, typeof i1.DxoSmallValuesGroupingModule, typeof i1.DxoExportModule, typeof i1.DxoLegendModule, typeof i1.DxoMarginModule, typeof i1.DxoTitleModule, typeof i1.DxoSubtitleModule, typeof i1.DxoLoadingIndicatorModule, typeof i1.DxiSeriesModule, typeof i1.DxoSeriesTemplateModule, typeof i1.DxoSizeModule, typeof i1.DxoTooltipModule, typeof i2.DxoPieChartAdaptiveLayoutModule, typeof i2.DxoPieChartAnimationModule, typeof i2.DxiPieChartAnnotationModule, typeof i2.DxoPieChartAnnotationBorderModule, typeof i2.DxoPieChartArgumentFormatModule, typeof i2.DxoPieChartBorderModule, typeof i2.DxoPieChartColorModule, typeof i2.DxoPieChartCommonAnnotationSettingsModule, typeof i2.DxoPieChartCommonSeriesSettingsModule, typeof i2.DxoPieChartConnectorModule, typeof i2.DxoPieChartExportModule, typeof i2.DxoPieChartFontModule, typeof i2.DxoPieChartFormatModule, typeof i2.DxoPieChartHatchingModule, typeof i2.DxoPieChartHoverStyleModule, typeof i2.DxoPieChartImageModule, typeof i2.DxoPieChartLabelModule, typeof i2.DxoPieChartLegendModule, typeof i2.DxoPieChartLegendTitleModule, typeof i2.DxoPieChartLegendTitleSubtitleModule, typeof i2.DxoPieChartLoadingIndicatorModule, typeof i2.DxoPieChartMarginModule, typeof i2.DxoPieChartPieChartTitleModule, typeof i2.DxoPieChartPieChartTitleSubtitleModule, typeof i2.DxoPieChartSelectionStyleModule, typeof i2.DxiPieChartSeriesModule, typeof i2.DxoPieChartSeriesBorderModule, typeof i2.DxoPieChartSeriesTemplateModule, typeof i2.DxoPieChartShadowModule, typeof i2.DxoPieChartSizeModule, typeof i2.DxoPieChartSmallValuesGroupingModule, typeof i2.DxoPieChartSubtitleModule, typeof i2.DxoPieChartTitleModule, typeof i2.DxoPieChartTooltipModule, typeof i2.DxoPieChartTooltipBorderModule, typeof i3.DxIntegrationModule, typeof i3.DxTemplateModule], [typeof DxPieChartComponent, typeof i1.DxoAdaptiveLayoutModule, typeof i1.DxoAnimationModule, typeof i1.DxiAnnotationModule, typeof i1.DxoBorderModule, typeof i1.DxoFontModule, typeof i1.DxoImageModule, typeof i1.DxoShadowModule, typeof i1.DxoCommonAnnotationSettingsModule, typeof i1.DxoCommonSeriesSettingsModule, typeof i1.DxoColorModule, typeof i1.DxoHoverStyleModule, typeof i1.DxoHatchingModule, typeof i1.DxoLabelModule, typeof i1.DxoArgumentFormatModule, typeof i1.DxoConnectorModule, typeof i1.DxoFormatModule, typeof i1.DxoSelectionStyleModule, typeof i1.DxoSmallValuesGroupingModule, typeof i1.DxoExportModule, typeof i1.DxoLegendModule, typeof i1.DxoMarginModule, typeof i1.DxoTitleModule, typeof i1.DxoSubtitleModule, typeof i1.DxoLoadingIndicatorModule, typeof i1.DxiSeriesModule, typeof i1.DxoSeriesTemplateModule, typeof i1.DxoSizeModule, typeof i1.DxoTooltipModule, typeof i2.DxoPieChartAdaptiveLayoutModule, typeof i2.DxoPieChartAnimationModule, typeof i2.DxiPieChartAnnotationModule, typeof i2.DxoPieChartAnnotationBorderModule, typeof i2.DxoPieChartArgumentFormatModule, typeof i2.DxoPieChartBorderModule, typeof i2.DxoPieChartColorModule, typeof i2.DxoPieChartCommonAnnotationSettingsModule, typeof i2.DxoPieChartCommonSeriesSettingsModule, typeof i2.DxoPieChartConnectorModule, typeof i2.DxoPieChartExportModule, typeof i2.DxoPieChartFontModule, typeof i2.DxoPieChartFormatModule, typeof i2.DxoPieChartHatchingModule, typeof i2.DxoPieChartHoverStyleModule, typeof i2.DxoPieChartImageModule, typeof i2.DxoPieChartLabelModule, typeof i2.DxoPieChartLegendModule, typeof i2.DxoPieChartLegendTitleModule, typeof i2.DxoPieChartLegendTitleSubtitleModule, typeof i2.DxoPieChartLoadingIndicatorModule, typeof i2.DxoPieChartMarginModule, typeof i2.DxoPieChartPieChartTitleModule, typeof i2.DxoPieChartPieChartTitleSubtitleModule, typeof i2.DxoPieChartSelectionStyleModule, typeof i2.DxiPieChartSeriesModule, typeof i2.DxoPieChartSeriesBorderModule, typeof i2.DxoPieChartSeriesTemplateModule, typeof i2.DxoPieChartShadowModule, typeof i2.DxoPieChartSizeModule, typeof i2.DxoPieChartSmallValuesGroupingModule, typeof i2.DxoPieChartSubtitleModule, typeof i2.DxoPieChartTitleModule, typeof i2.DxoPieChartTooltipModule, typeof i2.DxoPieChartTooltipBorderModule, typeof i3.DxTemplateModule]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxPieChartModule>;
}

export { DxPieChartComponent, DxPieChartModule };
//# sourceMappingURL=index.d.ts.map
