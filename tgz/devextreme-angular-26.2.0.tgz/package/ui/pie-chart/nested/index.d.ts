import * as i0 from '@angular/core';
import { OnDestroy, OnInit, AfterViewInit, Renderer2, ElementRef, EventEmitter } from '@angular/core';
import { NestedOption, NestedOptionHost, CollectionNestedOption, IDxTemplateHost, DxTemplateHost, DxTemplateDirective } from 'devextreme-angular/core';
import { AnimationEaseMode, DashStyle, Font, TextOverflow, AnnotationType, WordWrap, ChartsDataType, ChartsColor, HatchDirection, LabelPosition } from 'devextreme/common/charts';
import { dxPieChartAnnotationConfig, PieChartAnnotationLocation, PieChartSeriesInteractionMode, SmallValuesGroupingMode, PieChartLegendItem, PieChartLegendHoverMode, PieChartSeries, dxPieChartPointInfo } from 'devextreme/viz/pie_chart';
import { Format, ExportFormat, HorizontalAlignment, VerticalEdge, Position, Orientation } from 'devextreme/common';
import { Format as Format$1 } from 'devextreme/common/core/localization';

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoPieChartAdaptiveLayoutComponent extends NestedOption implements OnDestroy, OnInit {
    get height(): number;
    set height(value: number);
    get keepLabels(): boolean;
    set keepLabels(value: boolean);
    get width(): number;
    set width(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPieChartAdaptiveLayoutComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoPieChartAdaptiveLayoutComponent, "dxo-pie-chart-adaptive-layout", never, { "height": { "alias": "height"; "required": false; }; "keepLabels": { "alias": "keepLabels"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoPieChartAdaptiveLayoutModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPieChartAdaptiveLayoutModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoPieChartAdaptiveLayoutModule, never, [typeof DxoPieChartAdaptiveLayoutComponent], [typeof DxoPieChartAdaptiveLayoutComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoPieChartAdaptiveLayoutModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoPieChartAnimationComponent extends NestedOption implements OnDestroy, OnInit {
    get duration(): number;
    set duration(value: number);
    get easing(): AnimationEaseMode;
    set easing(value: AnimationEaseMode);
    get enabled(): boolean;
    set enabled(value: boolean);
    get maxPointCountSupported(): number;
    set maxPointCountSupported(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPieChartAnimationComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoPieChartAnimationComponent, "dxo-pie-chart-animation", never, { "duration": { "alias": "duration"; "required": false; }; "easing": { "alias": "easing"; "required": false; }; "enabled": { "alias": "enabled"; "required": false; }; "maxPointCountSupported": { "alias": "maxPointCountSupported"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoPieChartAnimationModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPieChartAnimationModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoPieChartAnimationModule, never, [typeof DxoPieChartAnimationComponent], [typeof DxoPieChartAnimationComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoPieChartAnimationModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoPieChartAnnotationBorderComponent extends NestedOption implements OnDestroy, OnInit {
    get color(): string;
    set color(value: string);
    get cornerRadius(): number;
    set cornerRadius(value: number);
    get dashStyle(): DashStyle;
    set dashStyle(value: DashStyle);
    get opacity(): number | undefined;
    set opacity(value: number | undefined);
    get visible(): boolean;
    set visible(value: boolean);
    get width(): number;
    set width(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPieChartAnnotationBorderComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoPieChartAnnotationBorderComponent, "dxo-pie-chart-annotation-border", never, { "color": { "alias": "color"; "required": false; }; "cornerRadius": { "alias": "cornerRadius"; "required": false; }; "dashStyle": { "alias": "dashStyle"; "required": false; }; "opacity": { "alias": "opacity"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoPieChartAnnotationBorderModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPieChartAnnotationBorderModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoPieChartAnnotationBorderModule, never, [typeof DxoPieChartAnnotationBorderComponent], [typeof DxoPieChartAnnotationBorderComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoPieChartAnnotationBorderModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxiPieChartAnnotationComponent extends CollectionNestedOption implements AfterViewInit, IDxTemplateHost {
    private renderer;
    private document;
    private element;
    get allowDragging(): boolean;
    set allowDragging(value: boolean);
    get argument(): Date | number | string | undefined;
    set argument(value: Date | number | string | undefined);
    get arrowLength(): number;
    set arrowLength(value: number);
    get arrowWidth(): number;
    set arrowWidth(value: number);
    get border(): {
        color?: string;
        cornerRadius?: number;
        dashStyle?: DashStyle;
        opacity?: number | undefined;
        visible?: boolean;
        width?: number;
    };
    set border(value: {
        color?: string;
        cornerRadius?: number;
        dashStyle?: DashStyle;
        opacity?: number | undefined;
        visible?: boolean;
        width?: number;
    });
    get color(): string;
    set color(value: string);
    get customizeTooltip(): ((annotation: dxPieChartAnnotationConfig | any) => Record<string, any>) | undefined;
    set customizeTooltip(value: ((annotation: dxPieChartAnnotationConfig | any) => Record<string, any>) | undefined);
    get data(): any;
    set data(value: any);
    get description(): string | undefined;
    set description(value: string | undefined);
    get font(): Font;
    set font(value: Font);
    get height(): number | undefined;
    set height(value: number | undefined);
    get image(): string | {
        height?: number;
        url?: string | undefined;
        width?: number;
    };
    set image(value: string | {
        height?: number;
        url?: string | undefined;
        width?: number;
    });
    get location(): PieChartAnnotationLocation;
    set location(value: PieChartAnnotationLocation);
    get name(): string | undefined;
    set name(value: string | undefined);
    get offsetX(): number | undefined;
    set offsetX(value: number | undefined);
    get offsetY(): number | undefined;
    set offsetY(value: number | undefined);
    get opacity(): number;
    set opacity(value: number);
    get paddingLeftRight(): number;
    set paddingLeftRight(value: number);
    get paddingTopBottom(): number;
    set paddingTopBottom(value: number);
    get series(): string | undefined;
    set series(value: string | undefined);
    get shadow(): {
        blur?: number;
        color?: string;
        offsetX?: number;
        offsetY?: number;
        opacity?: number;
    };
    set shadow(value: {
        blur?: number;
        color?: string;
        offsetX?: number;
        offsetY?: number;
        opacity?: number;
    });
    get template(): any;
    set template(value: any);
    get text(): string | undefined;
    set text(value: string | undefined);
    get textOverflow(): TextOverflow;
    set textOverflow(value: TextOverflow);
    get tooltipEnabled(): boolean;
    set tooltipEnabled(value: boolean);
    get tooltipTemplate(): any;
    set tooltipTemplate(value: any);
    get type(): AnnotationType | undefined;
    set type(value: AnnotationType | undefined);
    get width(): number | undefined;
    set width(value: number | undefined);
    get wordWrap(): WordWrap;
    set wordWrap(value: WordWrap);
    get x(): number | undefined;
    set x(value: number | undefined);
    get y(): number | undefined;
    set y(value: number | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost, renderer: Renderer2, document: any, templateHost: DxTemplateHost, element: ElementRef);
    setTemplate(template: DxTemplateDirective): void;
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiPieChartAnnotationComponent, [{ host: true; skipSelf: true; }, { host: true; }, null, null, { host: true; }, null]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiPieChartAnnotationComponent, "dxi-pie-chart-annotation", never, { "allowDragging": { "alias": "allowDragging"; "required": false; }; "argument": { "alias": "argument"; "required": false; }; "arrowLength": { "alias": "arrowLength"; "required": false; }; "arrowWidth": { "alias": "arrowWidth"; "required": false; }; "border": { "alias": "border"; "required": false; }; "color": { "alias": "color"; "required": false; }; "customizeTooltip": { "alias": "customizeTooltip"; "required": false; }; "data": { "alias": "data"; "required": false; }; "description": { "alias": "description"; "required": false; }; "font": { "alias": "font"; "required": false; }; "height": { "alias": "height"; "required": false; }; "image": { "alias": "image"; "required": false; }; "location": { "alias": "location"; "required": false; }; "name": { "alias": "name"; "required": false; }; "offsetX": { "alias": "offsetX"; "required": false; }; "offsetY": { "alias": "offsetY"; "required": false; }; "opacity": { "alias": "opacity"; "required": false; }; "paddingLeftRight": { "alias": "paddingLeftRight"; "required": false; }; "paddingTopBottom": { "alias": "paddingTopBottom"; "required": false; }; "series": { "alias": "series"; "required": false; }; "shadow": { "alias": "shadow"; "required": false; }; "template": { "alias": "template"; "required": false; }; "text": { "alias": "text"; "required": false; }; "textOverflow": { "alias": "textOverflow"; "required": false; }; "tooltipEnabled": { "alias": "tooltipEnabled"; "required": false; }; "tooltipTemplate": { "alias": "tooltipTemplate"; "required": false; }; "type": { "alias": "type"; "required": false; }; "width": { "alias": "width"; "required": false; }; "wordWrap": { "alias": "wordWrap"; "required": false; }; "x": { "alias": "x"; "required": false; }; "y": { "alias": "y"; "required": false; }; }, {}, never, ["*"], true, never>;
}
declare class DxiPieChartAnnotationModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiPieChartAnnotationModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiPieChartAnnotationModule, never, [typeof DxiPieChartAnnotationComponent], [typeof DxiPieChartAnnotationComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiPieChartAnnotationModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoPieChartArgumentFormatComponent extends NestedOption implements OnDestroy, OnInit {
    get currency(): string;
    set currency(value: string);
    get formatter(): ((value: number | Date) => string);
    set formatter(value: ((value: number | Date) => string));
    get parser(): ((value: string) => number | Date);
    set parser(value: ((value: string) => number | Date));
    get precision(): number;
    set precision(value: number);
    get type(): Format | string;
    set type(value: Format | string);
    get useCurrencyAccountingStyle(): boolean;
    set useCurrencyAccountingStyle(value: boolean);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPieChartArgumentFormatComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoPieChartArgumentFormatComponent, "dxo-pie-chart-argument-format", never, { "currency": { "alias": "currency"; "required": false; }; "formatter": { "alias": "formatter"; "required": false; }; "parser": { "alias": "parser"; "required": false; }; "precision": { "alias": "precision"; "required": false; }; "type": { "alias": "type"; "required": false; }; "useCurrencyAccountingStyle": { "alias": "useCurrencyAccountingStyle"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoPieChartArgumentFormatModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPieChartArgumentFormatModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoPieChartArgumentFormatModule, never, [typeof DxoPieChartArgumentFormatComponent], [typeof DxoPieChartArgumentFormatComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoPieChartArgumentFormatModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoPieChartBorderComponent extends NestedOption implements OnDestroy, OnInit {
    get color(): string | undefined;
    set color(value: string | undefined);
    get cornerRadius(): number;
    set cornerRadius(value: number);
    get dashStyle(): DashStyle | undefined;
    set dashStyle(value: DashStyle | undefined);
    get opacity(): number | undefined;
    set opacity(value: number | undefined);
    get visible(): boolean;
    set visible(value: boolean);
    get width(): number;
    set width(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPieChartBorderComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoPieChartBorderComponent, "dxo-pie-chart-border", never, { "color": { "alias": "color"; "required": false; }; "cornerRadius": { "alias": "cornerRadius"; "required": false; }; "dashStyle": { "alias": "dashStyle"; "required": false; }; "opacity": { "alias": "opacity"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoPieChartBorderModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPieChartBorderModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoPieChartBorderModule, never, [typeof DxoPieChartBorderComponent], [typeof DxoPieChartBorderComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoPieChartBorderModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoPieChartColorComponent extends NestedOption implements OnDestroy, OnInit {
    get base(): string | undefined;
    set base(value: string | undefined);
    get fillId(): string | undefined;
    set fillId(value: string | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPieChartColorComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoPieChartColorComponent, "dxo-pie-chart-color", never, { "base": { "alias": "base"; "required": false; }; "fillId": { "alias": "fillId"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoPieChartColorModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPieChartColorModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoPieChartColorModule, never, [typeof DxoPieChartColorComponent], [typeof DxoPieChartColorComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoPieChartColorModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoPieChartCommonAnnotationSettingsComponent extends NestedOption implements AfterViewInit, OnDestroy, OnInit, IDxTemplateHost {
    private renderer;
    private document;
    private element;
    get allowDragging(): boolean;
    set allowDragging(value: boolean);
    get argument(): Date | number | string | undefined;
    set argument(value: Date | number | string | undefined);
    get arrowLength(): number;
    set arrowLength(value: number);
    get arrowWidth(): number;
    set arrowWidth(value: number);
    get border(): {
        color?: string;
        cornerRadius?: number;
        dashStyle?: DashStyle;
        opacity?: number | undefined;
        visible?: boolean;
        width?: number;
    };
    set border(value: {
        color?: string;
        cornerRadius?: number;
        dashStyle?: DashStyle;
        opacity?: number | undefined;
        visible?: boolean;
        width?: number;
    });
    get color(): string;
    set color(value: string);
    get customizeTooltip(): ((annotation: dxPieChartAnnotationConfig | any) => Record<string, any>) | undefined;
    set customizeTooltip(value: ((annotation: dxPieChartAnnotationConfig | any) => Record<string, any>) | undefined);
    get data(): any;
    set data(value: any);
    get description(): string | undefined;
    set description(value: string | undefined);
    get font(): Font;
    set font(value: Font);
    get height(): number | undefined;
    set height(value: number | undefined);
    get image(): string | {
        height?: number;
        url?: string | undefined;
        width?: number;
    };
    set image(value: string | {
        height?: number;
        url?: string | undefined;
        width?: number;
    });
    get location(): PieChartAnnotationLocation;
    set location(value: PieChartAnnotationLocation);
    get offsetX(): number | undefined;
    set offsetX(value: number | undefined);
    get offsetY(): number | undefined;
    set offsetY(value: number | undefined);
    get opacity(): number;
    set opacity(value: number);
    get paddingLeftRight(): number;
    set paddingLeftRight(value: number);
    get paddingTopBottom(): number;
    set paddingTopBottom(value: number);
    get series(): string | undefined;
    set series(value: string | undefined);
    get shadow(): {
        blur?: number;
        color?: string;
        offsetX?: number;
        offsetY?: number;
        opacity?: number;
    };
    set shadow(value: {
        blur?: number;
        color?: string;
        offsetX?: number;
        offsetY?: number;
        opacity?: number;
    });
    get template(): any;
    set template(value: any);
    get text(): string | undefined;
    set text(value: string | undefined);
    get textOverflow(): TextOverflow;
    set textOverflow(value: TextOverflow);
    get tooltipEnabled(): boolean;
    set tooltipEnabled(value: boolean);
    get tooltipTemplate(): any;
    set tooltipTemplate(value: any);
    get type(): AnnotationType | undefined;
    set type(value: AnnotationType | undefined);
    get width(): number | undefined;
    set width(value: number | undefined);
    get wordWrap(): WordWrap;
    set wordWrap(value: WordWrap);
    get x(): number | undefined;
    set x(value: number | undefined);
    get y(): number | undefined;
    set y(value: number | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost, renderer: Renderer2, document: any, templateHost: DxTemplateHost, element: ElementRef);
    setTemplate(template: DxTemplateDirective): void;
    ngAfterViewInit(): void;
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPieChartCommonAnnotationSettingsComponent, [{ host: true; skipSelf: true; }, { host: true; }, null, null, { host: true; }, null]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoPieChartCommonAnnotationSettingsComponent, "dxo-pie-chart-common-annotation-settings", never, { "allowDragging": { "alias": "allowDragging"; "required": false; }; "argument": { "alias": "argument"; "required": false; }; "arrowLength": { "alias": "arrowLength"; "required": false; }; "arrowWidth": { "alias": "arrowWidth"; "required": false; }; "border": { "alias": "border"; "required": false; }; "color": { "alias": "color"; "required": false; }; "customizeTooltip": { "alias": "customizeTooltip"; "required": false; }; "data": { "alias": "data"; "required": false; }; "description": { "alias": "description"; "required": false; }; "font": { "alias": "font"; "required": false; }; "height": { "alias": "height"; "required": false; }; "image": { "alias": "image"; "required": false; }; "location": { "alias": "location"; "required": false; }; "offsetX": { "alias": "offsetX"; "required": false; }; "offsetY": { "alias": "offsetY"; "required": false; }; "opacity": { "alias": "opacity"; "required": false; }; "paddingLeftRight": { "alias": "paddingLeftRight"; "required": false; }; "paddingTopBottom": { "alias": "paddingTopBottom"; "required": false; }; "series": { "alias": "series"; "required": false; }; "shadow": { "alias": "shadow"; "required": false; }; "template": { "alias": "template"; "required": false; }; "text": { "alias": "text"; "required": false; }; "textOverflow": { "alias": "textOverflow"; "required": false; }; "tooltipEnabled": { "alias": "tooltipEnabled"; "required": false; }; "tooltipTemplate": { "alias": "tooltipTemplate"; "required": false; }; "type": { "alias": "type"; "required": false; }; "width": { "alias": "width"; "required": false; }; "wordWrap": { "alias": "wordWrap"; "required": false; }; "x": { "alias": "x"; "required": false; }; "y": { "alias": "y"; "required": false; }; }, {}, never, ["*"], true, never>;
}
declare class DxoPieChartCommonAnnotationSettingsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPieChartCommonAnnotationSettingsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoPieChartCommonAnnotationSettingsModule, never, [typeof DxoPieChartCommonAnnotationSettingsComponent], [typeof DxoPieChartCommonAnnotationSettingsComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoPieChartCommonAnnotationSettingsModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoPieChartCommonSeriesSettingsComponent extends NestedOption implements OnDestroy, OnInit {
    get argumentField(): string;
    set argumentField(value: string);
    get argumentType(): ChartsDataType | undefined;
    set argumentType(value: ChartsDataType | undefined);
    get border(): {
        color?: string | undefined;
        dashStyle?: DashStyle | undefined;
        visible?: boolean;
        width?: number;
    };
    set border(value: {
        color?: string | undefined;
        dashStyle?: DashStyle | undefined;
        visible?: boolean;
        width?: number;
    });
    get color(): ChartsColor | string | undefined;
    set color(value: ChartsColor | string | undefined);
    get hoverMode(): PieChartSeriesInteractionMode;
    set hoverMode(value: PieChartSeriesInteractionMode);
    get hoverStyle(): {
        border?: {
            color?: string | undefined;
            dashStyle?: DashStyle | undefined;
            visible?: boolean;
            width?: number;
        };
        color?: ChartsColor | string | undefined;
        hatching?: {
            direction?: HatchDirection;
            opacity?: number;
            step?: number;
            width?: number;
        };
        highlight?: boolean;
    };
    set hoverStyle(value: {
        border?: {
            color?: string | undefined;
            dashStyle?: DashStyle | undefined;
            visible?: boolean;
            width?: number;
        };
        color?: ChartsColor | string | undefined;
        hatching?: {
            direction?: HatchDirection;
            opacity?: number;
            step?: number;
            width?: number;
        };
        highlight?: boolean;
    });
    get label(): {
        argumentFormat?: Format$1 | undefined;
        backgroundColor?: string | undefined;
        border?: {
            color?: string | undefined;
            dashStyle?: DashStyle | undefined;
            visible?: boolean;
            width?: number;
        };
        connector?: {
            color?: string | undefined;
            visible?: boolean;
            width?: number;
        };
        customizeText?: ((pointInfo: any) => string);
        displayFormat?: string | undefined;
        font?: Font;
        format?: Format$1 | undefined;
        position?: LabelPosition;
        radialOffset?: number;
        rotationAngle?: number;
        textOverflow?: TextOverflow;
        visible?: boolean;
        wordWrap?: WordWrap;
    };
    set label(value: {
        argumentFormat?: Format$1 | undefined;
        backgroundColor?: string | undefined;
        border?: {
            color?: string | undefined;
            dashStyle?: DashStyle | undefined;
            visible?: boolean;
            width?: number;
        };
        connector?: {
            color?: string | undefined;
            visible?: boolean;
            width?: number;
        };
        customizeText?: ((pointInfo: any) => string);
        displayFormat?: string | undefined;
        font?: Font;
        format?: Format$1 | undefined;
        position?: LabelPosition;
        radialOffset?: number;
        rotationAngle?: number;
        textOverflow?: TextOverflow;
        visible?: boolean;
        wordWrap?: WordWrap;
    });
    get maxLabelCount(): number | undefined;
    set maxLabelCount(value: number | undefined);
    get minSegmentSize(): number | undefined;
    set minSegmentSize(value: number | undefined);
    get selectionMode(): PieChartSeriesInteractionMode;
    set selectionMode(value: PieChartSeriesInteractionMode);
    get selectionStyle(): {
        border?: {
            color?: string | undefined;
            dashStyle?: DashStyle | undefined;
            visible?: boolean;
            width?: number;
        };
        color?: ChartsColor | string | undefined;
        hatching?: {
            direction?: HatchDirection;
            opacity?: number;
            step?: number;
            width?: number;
        };
        highlight?: boolean;
    };
    set selectionStyle(value: {
        border?: {
            color?: string | undefined;
            dashStyle?: DashStyle | undefined;
            visible?: boolean;
            width?: number;
        };
        color?: ChartsColor | string | undefined;
        hatching?: {
            direction?: HatchDirection;
            opacity?: number;
            step?: number;
            width?: number;
        };
        highlight?: boolean;
    });
    get smallValuesGrouping(): {
        groupName?: string;
        mode?: SmallValuesGroupingMode;
        threshold?: number | undefined;
        topCount?: number | undefined;
    };
    set smallValuesGrouping(value: {
        groupName?: string;
        mode?: SmallValuesGroupingMode;
        threshold?: number | undefined;
        topCount?: number | undefined;
    });
    get tagField(): string;
    set tagField(value: string);
    get valueField(): string;
    set valueField(value: string);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPieChartCommonSeriesSettingsComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoPieChartCommonSeriesSettingsComponent, "dxo-pie-chart-common-series-settings", never, { "argumentField": { "alias": "argumentField"; "required": false; }; "argumentType": { "alias": "argumentType"; "required": false; }; "border": { "alias": "border"; "required": false; }; "color": { "alias": "color"; "required": false; }; "hoverMode": { "alias": "hoverMode"; "required": false; }; "hoverStyle": { "alias": "hoverStyle"; "required": false; }; "label": { "alias": "label"; "required": false; }; "maxLabelCount": { "alias": "maxLabelCount"; "required": false; }; "minSegmentSize": { "alias": "minSegmentSize"; "required": false; }; "selectionMode": { "alias": "selectionMode"; "required": false; }; "selectionStyle": { "alias": "selectionStyle"; "required": false; }; "smallValuesGrouping": { "alias": "smallValuesGrouping"; "required": false; }; "tagField": { "alias": "tagField"; "required": false; }; "valueField": { "alias": "valueField"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoPieChartCommonSeriesSettingsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPieChartCommonSeriesSettingsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoPieChartCommonSeriesSettingsModule, never, [typeof DxoPieChartCommonSeriesSettingsComponent], [typeof DxoPieChartCommonSeriesSettingsComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoPieChartCommonSeriesSettingsModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoPieChartConnectorComponent extends NestedOption implements OnDestroy, OnInit {
    get color(): string | undefined;
    set color(value: string | undefined);
    get visible(): boolean;
    set visible(value: boolean);
    get width(): number;
    set width(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPieChartConnectorComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoPieChartConnectorComponent, "dxo-pie-chart-connector", never, { "color": { "alias": "color"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoPieChartConnectorModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPieChartConnectorModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoPieChartConnectorModule, never, [typeof DxoPieChartConnectorComponent], [typeof DxoPieChartConnectorComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoPieChartConnectorModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoPieChartExportComponent extends NestedOption implements OnDestroy, OnInit {
    get backgroundColor(): string;
    set backgroundColor(value: string);
    get enabled(): boolean;
    set enabled(value: boolean);
    get fileName(): string;
    set fileName(value: string);
    get formats(): Array<ExportFormat>;
    set formats(value: Array<ExportFormat>);
    get margin(): number;
    set margin(value: number);
    get printingEnabled(): boolean;
    set printingEnabled(value: boolean);
    get svgToCanvas(): ((svg: any, canvas: any) => any) | undefined;
    set svgToCanvas(value: ((svg: any, canvas: any) => any) | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPieChartExportComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoPieChartExportComponent, "dxo-pie-chart-export", never, { "backgroundColor": { "alias": "backgroundColor"; "required": false; }; "enabled": { "alias": "enabled"; "required": false; }; "fileName": { "alias": "fileName"; "required": false; }; "formats": { "alias": "formats"; "required": false; }; "margin": { "alias": "margin"; "required": false; }; "printingEnabled": { "alias": "printingEnabled"; "required": false; }; "svgToCanvas": { "alias": "svgToCanvas"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoPieChartExportModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPieChartExportModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoPieChartExportModule, never, [typeof DxoPieChartExportComponent], [typeof DxoPieChartExportComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoPieChartExportModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoPieChartFontComponent extends NestedOption implements OnDestroy, OnInit {
    get color(): string;
    set color(value: string);
    get family(): string;
    set family(value: string);
    get opacity(): number;
    set opacity(value: number);
    get size(): number | string;
    set size(value: number | string);
    get weight(): number;
    set weight(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPieChartFontComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoPieChartFontComponent, "dxo-pie-chart-font", never, { "color": { "alias": "color"; "required": false; }; "family": { "alias": "family"; "required": false; }; "opacity": { "alias": "opacity"; "required": false; }; "size": { "alias": "size"; "required": false; }; "weight": { "alias": "weight"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoPieChartFontModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPieChartFontModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoPieChartFontModule, never, [typeof DxoPieChartFontComponent], [typeof DxoPieChartFontComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoPieChartFontModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoPieChartFormatComponent extends NestedOption implements OnDestroy, OnInit {
    get currency(): string;
    set currency(value: string);
    get formatter(): ((value: number | Date) => string);
    set formatter(value: ((value: number | Date) => string));
    get parser(): ((value: string) => number | Date);
    set parser(value: ((value: string) => number | Date));
    get precision(): number;
    set precision(value: number);
    get type(): Format | string;
    set type(value: Format | string);
    get useCurrencyAccountingStyle(): boolean;
    set useCurrencyAccountingStyle(value: boolean);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPieChartFormatComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoPieChartFormatComponent, "dxo-pie-chart-format", never, { "currency": { "alias": "currency"; "required": false; }; "formatter": { "alias": "formatter"; "required": false; }; "parser": { "alias": "parser"; "required": false; }; "precision": { "alias": "precision"; "required": false; }; "type": { "alias": "type"; "required": false; }; "useCurrencyAccountingStyle": { "alias": "useCurrencyAccountingStyle"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoPieChartFormatModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPieChartFormatModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoPieChartFormatModule, never, [typeof DxoPieChartFormatComponent], [typeof DxoPieChartFormatComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoPieChartFormatModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoPieChartHatchingComponent extends NestedOption implements OnDestroy, OnInit {
    get direction(): HatchDirection;
    set direction(value: HatchDirection);
    get opacity(): number;
    set opacity(value: number);
    get step(): number;
    set step(value: number);
    get width(): number;
    set width(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPieChartHatchingComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoPieChartHatchingComponent, "dxo-pie-chart-hatching", never, { "direction": { "alias": "direction"; "required": false; }; "opacity": { "alias": "opacity"; "required": false; }; "step": { "alias": "step"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoPieChartHatchingModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPieChartHatchingModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoPieChartHatchingModule, never, [typeof DxoPieChartHatchingComponent], [typeof DxoPieChartHatchingComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoPieChartHatchingModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoPieChartHoverStyleComponent extends NestedOption implements OnDestroy, OnInit {
    get border(): {
        color?: string | undefined;
        dashStyle?: DashStyle | undefined;
        visible?: boolean;
        width?: number;
    };
    set border(value: {
        color?: string | undefined;
        dashStyle?: DashStyle | undefined;
        visible?: boolean;
        width?: number;
    });
    get color(): ChartsColor | string | undefined;
    set color(value: ChartsColor | string | undefined);
    get hatching(): {
        direction?: HatchDirection;
        opacity?: number;
        step?: number;
        width?: number;
    };
    set hatching(value: {
        direction?: HatchDirection;
        opacity?: number;
        step?: number;
        width?: number;
    });
    get highlight(): boolean;
    set highlight(value: boolean);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPieChartHoverStyleComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoPieChartHoverStyleComponent, "dxo-pie-chart-hover-style", never, { "border": { "alias": "border"; "required": false; }; "color": { "alias": "color"; "required": false; }; "hatching": { "alias": "hatching"; "required": false; }; "highlight": { "alias": "highlight"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoPieChartHoverStyleModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPieChartHoverStyleModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoPieChartHoverStyleModule, never, [typeof DxoPieChartHoverStyleComponent], [typeof DxoPieChartHoverStyleComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoPieChartHoverStyleModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoPieChartImageComponent extends NestedOption implements OnDestroy, OnInit {
    get height(): number;
    set height(value: number);
    get url(): string | undefined;
    set url(value: string | undefined);
    get width(): number;
    set width(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPieChartImageComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoPieChartImageComponent, "dxo-pie-chart-image", never, { "height": { "alias": "height"; "required": false; }; "url": { "alias": "url"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoPieChartImageModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPieChartImageModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoPieChartImageModule, never, [typeof DxoPieChartImageComponent], [typeof DxoPieChartImageComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoPieChartImageModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoPieChartLabelComponent extends NestedOption implements OnDestroy, OnInit {
    get argumentFormat(): Format$1 | undefined;
    set argumentFormat(value: Format$1 | undefined);
    get backgroundColor(): string | undefined;
    set backgroundColor(value: string | undefined);
    get border(): {
        color?: string | undefined;
        dashStyle?: DashStyle | undefined;
        visible?: boolean;
        width?: number;
    };
    set border(value: {
        color?: string | undefined;
        dashStyle?: DashStyle | undefined;
        visible?: boolean;
        width?: number;
    });
    get connector(): {
        color?: string | undefined;
        visible?: boolean;
        width?: number;
    };
    set connector(value: {
        color?: string | undefined;
        visible?: boolean;
        width?: number;
    });
    get customizeText(): ((pointInfo: any) => string);
    set customizeText(value: ((pointInfo: any) => string));
    get displayFormat(): string | undefined;
    set displayFormat(value: string | undefined);
    get font(): Font;
    set font(value: Font);
    get format(): Format$1 | undefined;
    set format(value: Format$1 | undefined);
    get position(): LabelPosition;
    set position(value: LabelPosition);
    get radialOffset(): number;
    set radialOffset(value: number);
    get rotationAngle(): number;
    set rotationAngle(value: number);
    get textOverflow(): TextOverflow;
    set textOverflow(value: TextOverflow);
    get visible(): boolean;
    set visible(value: boolean);
    get wordWrap(): WordWrap;
    set wordWrap(value: WordWrap);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPieChartLabelComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoPieChartLabelComponent, "dxo-pie-chart-label", never, { "argumentFormat": { "alias": "argumentFormat"; "required": false; }; "backgroundColor": { "alias": "backgroundColor"; "required": false; }; "border": { "alias": "border"; "required": false; }; "connector": { "alias": "connector"; "required": false; }; "customizeText": { "alias": "customizeText"; "required": false; }; "displayFormat": { "alias": "displayFormat"; "required": false; }; "font": { "alias": "font"; "required": false; }; "format": { "alias": "format"; "required": false; }; "position": { "alias": "position"; "required": false; }; "radialOffset": { "alias": "radialOffset"; "required": false; }; "rotationAngle": { "alias": "rotationAngle"; "required": false; }; "textOverflow": { "alias": "textOverflow"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "wordWrap": { "alias": "wordWrap"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoPieChartLabelModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPieChartLabelModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoPieChartLabelModule, never, [typeof DxoPieChartLabelComponent], [typeof DxoPieChartLabelComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoPieChartLabelModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoPieChartLegendTitleSubtitleComponent extends NestedOption implements OnDestroy, OnInit {
    get font(): Font;
    set font(value: Font);
    get offset(): number;
    set offset(value: number);
    get text(): string | undefined;
    set text(value: string | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPieChartLegendTitleSubtitleComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoPieChartLegendTitleSubtitleComponent, "dxo-pie-chart-legend-title-subtitle", never, { "font": { "alias": "font"; "required": false; }; "offset": { "alias": "offset"; "required": false; }; "text": { "alias": "text"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoPieChartLegendTitleSubtitleModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPieChartLegendTitleSubtitleModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoPieChartLegendTitleSubtitleModule, never, [typeof DxoPieChartLegendTitleSubtitleComponent], [typeof DxoPieChartLegendTitleSubtitleComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoPieChartLegendTitleSubtitleModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoPieChartLegendTitleComponent extends NestedOption implements OnDestroy, OnInit {
    get font(): Font;
    set font(value: Font);
    get horizontalAlignment(): HorizontalAlignment | undefined;
    set horizontalAlignment(value: HorizontalAlignment | undefined);
    get margin(): {
        bottom?: number;
        left?: number;
        right?: number;
        top?: number;
    };
    set margin(value: {
        bottom?: number;
        left?: number;
        right?: number;
        top?: number;
    });
    get placeholderSize(): number | undefined;
    set placeholderSize(value: number | undefined);
    get subtitle(): string | {
        font?: Font;
        offset?: number;
        text?: string | undefined;
    };
    set subtitle(value: string | {
        font?: Font;
        offset?: number;
        text?: string | undefined;
    });
    get text(): string | undefined;
    set text(value: string | undefined);
    get verticalAlignment(): VerticalEdge;
    set verticalAlignment(value: VerticalEdge);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPieChartLegendTitleComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoPieChartLegendTitleComponent, "dxo-pie-chart-legend-title", never, { "font": { "alias": "font"; "required": false; }; "horizontalAlignment": { "alias": "horizontalAlignment"; "required": false; }; "margin": { "alias": "margin"; "required": false; }; "placeholderSize": { "alias": "placeholderSize"; "required": false; }; "subtitle": { "alias": "subtitle"; "required": false; }; "text": { "alias": "text"; "required": false; }; "verticalAlignment": { "alias": "verticalAlignment"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoPieChartLegendTitleModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPieChartLegendTitleModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoPieChartLegendTitleModule, never, [typeof DxoPieChartLegendTitleComponent], [typeof DxoPieChartLegendTitleComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoPieChartLegendTitleModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoPieChartLegendComponent extends NestedOption implements OnDestroy, OnInit {
    get backgroundColor(): string | undefined;
    set backgroundColor(value: string | undefined);
    get border(): {
        color?: string;
        cornerRadius?: number;
        dashStyle?: DashStyle;
        opacity?: number | undefined;
        visible?: boolean;
        width?: number;
    };
    set border(value: {
        color?: string;
        cornerRadius?: number;
        dashStyle?: DashStyle;
        opacity?: number | undefined;
        visible?: boolean;
        width?: number;
    });
    get columnCount(): number;
    set columnCount(value: number);
    get columnItemSpacing(): number;
    set columnItemSpacing(value: number);
    get customizeHint(): ((pointInfo: {
        pointColor: string;
        pointIndex: number;
        pointName: any;
    }) => string);
    set customizeHint(value: ((pointInfo: {
        pointColor: string;
        pointIndex: number;
        pointName: any;
    }) => string));
    get customizeItems(): ((items: Array<PieChartLegendItem>) => Array<PieChartLegendItem>);
    set customizeItems(value: ((items: Array<PieChartLegendItem>) => Array<PieChartLegendItem>));
    get customizeText(): ((pointInfo: {
        pointColor: string;
        pointIndex: number;
        pointName: any;
    }) => string);
    set customizeText(value: ((pointInfo: {
        pointColor: string;
        pointIndex: number;
        pointName: any;
    }) => string));
    get font(): Font;
    set font(value: Font);
    get horizontalAlignment(): HorizontalAlignment;
    set horizontalAlignment(value: HorizontalAlignment);
    get hoverMode(): PieChartLegendHoverMode;
    set hoverMode(value: PieChartLegendHoverMode);
    get itemsAlignment(): HorizontalAlignment | undefined;
    set itemsAlignment(value: HorizontalAlignment | undefined);
    get itemTextPosition(): Position | undefined;
    set itemTextPosition(value: Position | undefined);
    get margin(): number | {
        bottom?: number;
        left?: number;
        right?: number;
        top?: number;
    };
    set margin(value: number | {
        bottom?: number;
        left?: number;
        right?: number;
        top?: number;
    });
    get markerSize(): number;
    set markerSize(value: number);
    get markerTemplate(): any;
    set markerTemplate(value: any);
    get orientation(): Orientation | undefined;
    set orientation(value: Orientation | undefined);
    get paddingLeftRight(): number;
    set paddingLeftRight(value: number);
    get paddingTopBottom(): number;
    set paddingTopBottom(value: number);
    get rowCount(): number;
    set rowCount(value: number);
    get rowItemSpacing(): number;
    set rowItemSpacing(value: number);
    get title(): string | {
        font?: Font;
        horizontalAlignment?: HorizontalAlignment | undefined;
        margin?: {
            bottom?: number;
            left?: number;
            right?: number;
            top?: number;
        };
        placeholderSize?: number | undefined;
        subtitle?: string | {
            font?: Font;
            offset?: number;
            text?: string | undefined;
        };
        text?: string | undefined;
        verticalAlignment?: VerticalEdge;
    };
    set title(value: string | {
        font?: Font;
        horizontalAlignment?: HorizontalAlignment | undefined;
        margin?: {
            bottom?: number;
            left?: number;
            right?: number;
            top?: number;
        };
        placeholderSize?: number | undefined;
        subtitle?: string | {
            font?: Font;
            offset?: number;
            text?: string | undefined;
        };
        text?: string | undefined;
        verticalAlignment?: VerticalEdge;
    });
    get verticalAlignment(): VerticalEdge;
    set verticalAlignment(value: VerticalEdge);
    get visible(): boolean;
    set visible(value: boolean);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPieChartLegendComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoPieChartLegendComponent, "dxo-pie-chart-legend", never, { "backgroundColor": { "alias": "backgroundColor"; "required": false; }; "border": { "alias": "border"; "required": false; }; "columnCount": { "alias": "columnCount"; "required": false; }; "columnItemSpacing": { "alias": "columnItemSpacing"; "required": false; }; "customizeHint": { "alias": "customizeHint"; "required": false; }; "customizeItems": { "alias": "customizeItems"; "required": false; }; "customizeText": { "alias": "customizeText"; "required": false; }; "font": { "alias": "font"; "required": false; }; "horizontalAlignment": { "alias": "horizontalAlignment"; "required": false; }; "hoverMode": { "alias": "hoverMode"; "required": false; }; "itemsAlignment": { "alias": "itemsAlignment"; "required": false; }; "itemTextPosition": { "alias": "itemTextPosition"; "required": false; }; "margin": { "alias": "margin"; "required": false; }; "markerSize": { "alias": "markerSize"; "required": false; }; "markerTemplate": { "alias": "markerTemplate"; "required": false; }; "orientation": { "alias": "orientation"; "required": false; }; "paddingLeftRight": { "alias": "paddingLeftRight"; "required": false; }; "paddingTopBottom": { "alias": "paddingTopBottom"; "required": false; }; "rowCount": { "alias": "rowCount"; "required": false; }; "rowItemSpacing": { "alias": "rowItemSpacing"; "required": false; }; "title": { "alias": "title"; "required": false; }; "verticalAlignment": { "alias": "verticalAlignment"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoPieChartLegendModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPieChartLegendModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoPieChartLegendModule, never, [typeof DxoPieChartLegendComponent], [typeof DxoPieChartLegendComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoPieChartLegendModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoPieChartLoadingIndicatorComponent extends NestedOption implements OnDestroy, OnInit {
    get backgroundColor(): string;
    set backgroundColor(value: string);
    get enabled(): boolean;
    set enabled(value: boolean);
    get font(): Font;
    set font(value: Font);
    get show(): boolean;
    set show(value: boolean);
    get text(): string;
    set text(value: string);
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    showChange: EventEmitter<boolean>;
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPieChartLoadingIndicatorComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoPieChartLoadingIndicatorComponent, "dxo-pie-chart-loading-indicator", never, { "backgroundColor": { "alias": "backgroundColor"; "required": false; }; "enabled": { "alias": "enabled"; "required": false; }; "font": { "alias": "font"; "required": false; }; "show": { "alias": "show"; "required": false; }; "text": { "alias": "text"; "required": false; }; }, { "showChange": "showChange"; }, never, never, true, never>;
}
declare class DxoPieChartLoadingIndicatorModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPieChartLoadingIndicatorModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoPieChartLoadingIndicatorModule, never, [typeof DxoPieChartLoadingIndicatorComponent], [typeof DxoPieChartLoadingIndicatorComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoPieChartLoadingIndicatorModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoPieChartMarginComponent extends NestedOption implements OnDestroy, OnInit {
    get bottom(): number;
    set bottom(value: number);
    get left(): number;
    set left(value: number);
    get right(): number;
    set right(value: number);
    get top(): number;
    set top(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPieChartMarginComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoPieChartMarginComponent, "dxo-pie-chart-margin", never, { "bottom": { "alias": "bottom"; "required": false; }; "left": { "alias": "left"; "required": false; }; "right": { "alias": "right"; "required": false; }; "top": { "alias": "top"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoPieChartMarginModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPieChartMarginModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoPieChartMarginModule, never, [typeof DxoPieChartMarginComponent], [typeof DxoPieChartMarginComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoPieChartMarginModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoPieChartPieChartTitleSubtitleComponent extends NestedOption implements OnDestroy, OnInit {
    get font(): Font;
    set font(value: Font);
    get offset(): number;
    set offset(value: number);
    get text(): string | undefined;
    set text(value: string | undefined);
    get textOverflow(): TextOverflow;
    set textOverflow(value: TextOverflow);
    get wordWrap(): WordWrap;
    set wordWrap(value: WordWrap);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPieChartPieChartTitleSubtitleComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoPieChartPieChartTitleSubtitleComponent, "dxo-pie-chart-pie-chart-title-subtitle", never, { "font": { "alias": "font"; "required": false; }; "offset": { "alias": "offset"; "required": false; }; "text": { "alias": "text"; "required": false; }; "textOverflow": { "alias": "textOverflow"; "required": false; }; "wordWrap": { "alias": "wordWrap"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoPieChartPieChartTitleSubtitleModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPieChartPieChartTitleSubtitleModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoPieChartPieChartTitleSubtitleModule, never, [typeof DxoPieChartPieChartTitleSubtitleComponent], [typeof DxoPieChartPieChartTitleSubtitleComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoPieChartPieChartTitleSubtitleModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoPieChartPieChartTitleComponent extends NestedOption implements OnDestroy, OnInit {
    get font(): Font;
    set font(value: Font);
    get horizontalAlignment(): HorizontalAlignment;
    set horizontalAlignment(value: HorizontalAlignment);
    get margin(): number | {
        bottom?: number;
        left?: number;
        right?: number;
        top?: number;
    };
    set margin(value: number | {
        bottom?: number;
        left?: number;
        right?: number;
        top?: number;
    });
    get placeholderSize(): number | undefined;
    set placeholderSize(value: number | undefined);
    get subtitle(): string | {
        font?: Font;
        offset?: number;
        text?: string | undefined;
        textOverflow?: TextOverflow;
        wordWrap?: WordWrap;
    };
    set subtitle(value: string | {
        font?: Font;
        offset?: number;
        text?: string | undefined;
        textOverflow?: TextOverflow;
        wordWrap?: WordWrap;
    });
    get text(): string | undefined;
    set text(value: string | undefined);
    get textOverflow(): TextOverflow;
    set textOverflow(value: TextOverflow);
    get verticalAlignment(): VerticalEdge;
    set verticalAlignment(value: VerticalEdge);
    get wordWrap(): WordWrap;
    set wordWrap(value: WordWrap);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPieChartPieChartTitleComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoPieChartPieChartTitleComponent, "dxo-pie-chart-pie-chart-title", never, { "font": { "alias": "font"; "required": false; }; "horizontalAlignment": { "alias": "horizontalAlignment"; "required": false; }; "margin": { "alias": "margin"; "required": false; }; "placeholderSize": { "alias": "placeholderSize"; "required": false; }; "subtitle": { "alias": "subtitle"; "required": false; }; "text": { "alias": "text"; "required": false; }; "textOverflow": { "alias": "textOverflow"; "required": false; }; "verticalAlignment": { "alias": "verticalAlignment"; "required": false; }; "wordWrap": { "alias": "wordWrap"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoPieChartPieChartTitleModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPieChartPieChartTitleModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoPieChartPieChartTitleModule, never, [typeof DxoPieChartPieChartTitleComponent], [typeof DxoPieChartPieChartTitleComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoPieChartPieChartTitleModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoPieChartSelectionStyleComponent extends NestedOption implements OnDestroy, OnInit {
    get border(): {
        color?: string | undefined;
        dashStyle?: DashStyle | undefined;
        visible?: boolean;
        width?: number;
    };
    set border(value: {
        color?: string | undefined;
        dashStyle?: DashStyle | undefined;
        visible?: boolean;
        width?: number;
    });
    get color(): ChartsColor | string | undefined;
    set color(value: ChartsColor | string | undefined);
    get hatching(): {
        direction?: HatchDirection;
        opacity?: number;
        step?: number;
        width?: number;
    };
    set hatching(value: {
        direction?: HatchDirection;
        opacity?: number;
        step?: number;
        width?: number;
    });
    get highlight(): boolean;
    set highlight(value: boolean);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPieChartSelectionStyleComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoPieChartSelectionStyleComponent, "dxo-pie-chart-selection-style", never, { "border": { "alias": "border"; "required": false; }; "color": { "alias": "color"; "required": false; }; "hatching": { "alias": "hatching"; "required": false; }; "highlight": { "alias": "highlight"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoPieChartSelectionStyleModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPieChartSelectionStyleModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoPieChartSelectionStyleModule, never, [typeof DxoPieChartSelectionStyleComponent], [typeof DxoPieChartSelectionStyleComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoPieChartSelectionStyleModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoPieChartSeriesBorderComponent extends NestedOption implements OnDestroy, OnInit {
    get color(): string | undefined;
    set color(value: string | undefined);
    get dashStyle(): DashStyle | undefined;
    set dashStyle(value: DashStyle | undefined);
    get visible(): boolean;
    set visible(value: boolean);
    get width(): number;
    set width(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPieChartSeriesBorderComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoPieChartSeriesBorderComponent, "dxo-pie-chart-series-border", never, { "color": { "alias": "color"; "required": false; }; "dashStyle": { "alias": "dashStyle"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoPieChartSeriesBorderModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPieChartSeriesBorderModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoPieChartSeriesBorderModule, never, [typeof DxoPieChartSeriesBorderComponent], [typeof DxoPieChartSeriesBorderComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoPieChartSeriesBorderModule>;
}

declare class DxiPieChartSeriesComponent extends CollectionNestedOption {
    get argumentField(): string;
    set argumentField(value: string);
    get argumentType(): ChartsDataType | undefined;
    set argumentType(value: ChartsDataType | undefined);
    get border(): {
        color?: string | undefined;
        dashStyle?: DashStyle | undefined;
        visible?: boolean;
        width?: number;
    };
    set border(value: {
        color?: string | undefined;
        dashStyle?: DashStyle | undefined;
        visible?: boolean;
        width?: number;
    });
    get color(): ChartsColor | string | undefined;
    set color(value: ChartsColor | string | undefined);
    get hoverMode(): PieChartSeriesInteractionMode;
    set hoverMode(value: PieChartSeriesInteractionMode);
    get hoverStyle(): {
        border?: {
            color?: string | undefined;
            dashStyle?: DashStyle | undefined;
            visible?: boolean;
            width?: number;
        };
        color?: ChartsColor | string | undefined;
        hatching?: {
            direction?: HatchDirection;
            opacity?: number;
            step?: number;
            width?: number;
        };
        highlight?: boolean;
    };
    set hoverStyle(value: {
        border?: {
            color?: string | undefined;
            dashStyle?: DashStyle | undefined;
            visible?: boolean;
            width?: number;
        };
        color?: ChartsColor | string | undefined;
        hatching?: {
            direction?: HatchDirection;
            opacity?: number;
            step?: number;
            width?: number;
        };
        highlight?: boolean;
    });
    get label(): {
        argumentFormat?: Format$1 | undefined;
        backgroundColor?: string | undefined;
        border?: {
            color?: string | undefined;
            dashStyle?: DashStyle | undefined;
            visible?: boolean;
            width?: number;
        };
        connector?: {
            color?: string | undefined;
            visible?: boolean;
            width?: number;
        };
        customizeText?: ((pointInfo: any) => string);
        displayFormat?: string | undefined;
        font?: Font;
        format?: Format$1 | undefined;
        position?: LabelPosition;
        radialOffset?: number;
        rotationAngle?: number;
        textOverflow?: TextOverflow;
        visible?: boolean;
        wordWrap?: WordWrap;
    };
    set label(value: {
        argumentFormat?: Format$1 | undefined;
        backgroundColor?: string | undefined;
        border?: {
            color?: string | undefined;
            dashStyle?: DashStyle | undefined;
            visible?: boolean;
            width?: number;
        };
        connector?: {
            color?: string | undefined;
            visible?: boolean;
            width?: number;
        };
        customizeText?: ((pointInfo: any) => string);
        displayFormat?: string | undefined;
        font?: Font;
        format?: Format$1 | undefined;
        position?: LabelPosition;
        radialOffset?: number;
        rotationAngle?: number;
        textOverflow?: TextOverflow;
        visible?: boolean;
        wordWrap?: WordWrap;
    });
    get maxLabelCount(): number | undefined;
    set maxLabelCount(value: number | undefined);
    get minSegmentSize(): number | undefined;
    set minSegmentSize(value: number | undefined);
    get name(): string | undefined;
    set name(value: string | undefined);
    get selectionMode(): PieChartSeriesInteractionMode;
    set selectionMode(value: PieChartSeriesInteractionMode);
    get selectionStyle(): {
        border?: {
            color?: string | undefined;
            dashStyle?: DashStyle | undefined;
            visible?: boolean;
            width?: number;
        };
        color?: ChartsColor | string | undefined;
        hatching?: {
            direction?: HatchDirection;
            opacity?: number;
            step?: number;
            width?: number;
        };
        highlight?: boolean;
    };
    set selectionStyle(value: {
        border?: {
            color?: string | undefined;
            dashStyle?: DashStyle | undefined;
            visible?: boolean;
            width?: number;
        };
        color?: ChartsColor | string | undefined;
        hatching?: {
            direction?: HatchDirection;
            opacity?: number;
            step?: number;
            width?: number;
        };
        highlight?: boolean;
    });
    get smallValuesGrouping(): {
        groupName?: string;
        mode?: SmallValuesGroupingMode;
        threshold?: number | undefined;
        topCount?: number | undefined;
    };
    set smallValuesGrouping(value: {
        groupName?: string;
        mode?: SmallValuesGroupingMode;
        threshold?: number | undefined;
        topCount?: number | undefined;
    });
    get tag(): any | undefined;
    set tag(value: any | undefined);
    get tagField(): string;
    set tagField(value: string);
    get valueField(): string;
    set valueField(value: string);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiPieChartSeriesComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiPieChartSeriesComponent, "dxi-pie-chart-series", never, { "argumentField": { "alias": "argumentField"; "required": false; }; "argumentType": { "alias": "argumentType"; "required": false; }; "border": { "alias": "border"; "required": false; }; "color": { "alias": "color"; "required": false; }; "hoverMode": { "alias": "hoverMode"; "required": false; }; "hoverStyle": { "alias": "hoverStyle"; "required": false; }; "label": { "alias": "label"; "required": false; }; "maxLabelCount": { "alias": "maxLabelCount"; "required": false; }; "minSegmentSize": { "alias": "minSegmentSize"; "required": false; }; "name": { "alias": "name"; "required": false; }; "selectionMode": { "alias": "selectionMode"; "required": false; }; "selectionStyle": { "alias": "selectionStyle"; "required": false; }; "smallValuesGrouping": { "alias": "smallValuesGrouping"; "required": false; }; "tag": { "alias": "tag"; "required": false; }; "tagField": { "alias": "tagField"; "required": false; }; "valueField": { "alias": "valueField"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxiPieChartSeriesModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiPieChartSeriesModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiPieChartSeriesModule, never, [typeof DxiPieChartSeriesComponent], [typeof DxiPieChartSeriesComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiPieChartSeriesModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoPieChartSeriesTemplateComponent extends NestedOption implements OnDestroy, OnInit {
    get customizeSeries(): ((seriesName: any) => PieChartSeries);
    set customizeSeries(value: ((seriesName: any) => PieChartSeries));
    get nameField(): string;
    set nameField(value: string);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPieChartSeriesTemplateComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoPieChartSeriesTemplateComponent, "dxo-pie-chart-series-template", never, { "customizeSeries": { "alias": "customizeSeries"; "required": false; }; "nameField": { "alias": "nameField"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoPieChartSeriesTemplateModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPieChartSeriesTemplateModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoPieChartSeriesTemplateModule, never, [typeof DxoPieChartSeriesTemplateComponent], [typeof DxoPieChartSeriesTemplateComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoPieChartSeriesTemplateModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoPieChartShadowComponent extends NestedOption implements OnDestroy, OnInit {
    get blur(): number;
    set blur(value: number);
    get color(): string;
    set color(value: string);
    get offsetX(): number;
    set offsetX(value: number);
    get offsetY(): number;
    set offsetY(value: number);
    get opacity(): number;
    set opacity(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPieChartShadowComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoPieChartShadowComponent, "dxo-pie-chart-shadow", never, { "blur": { "alias": "blur"; "required": false; }; "color": { "alias": "color"; "required": false; }; "offsetX": { "alias": "offsetX"; "required": false; }; "offsetY": { "alias": "offsetY"; "required": false; }; "opacity": { "alias": "opacity"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoPieChartShadowModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPieChartShadowModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoPieChartShadowModule, never, [typeof DxoPieChartShadowComponent], [typeof DxoPieChartShadowComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoPieChartShadowModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoPieChartSizeComponent extends NestedOption implements OnDestroy, OnInit {
    get height(): number | undefined;
    set height(value: number | undefined);
    get width(): number | undefined;
    set width(value: number | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPieChartSizeComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoPieChartSizeComponent, "dxo-pie-chart-size", never, { "height": { "alias": "height"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoPieChartSizeModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPieChartSizeModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoPieChartSizeModule, never, [typeof DxoPieChartSizeComponent], [typeof DxoPieChartSizeComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoPieChartSizeModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoPieChartSmallValuesGroupingComponent extends NestedOption implements OnDestroy, OnInit {
    get groupName(): string;
    set groupName(value: string);
    get mode(): SmallValuesGroupingMode;
    set mode(value: SmallValuesGroupingMode);
    get threshold(): number | undefined;
    set threshold(value: number | undefined);
    get topCount(): number | undefined;
    set topCount(value: number | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPieChartSmallValuesGroupingComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoPieChartSmallValuesGroupingComponent, "dxo-pie-chart-small-values-grouping", never, { "groupName": { "alias": "groupName"; "required": false; }; "mode": { "alias": "mode"; "required": false; }; "threshold": { "alias": "threshold"; "required": false; }; "topCount": { "alias": "topCount"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoPieChartSmallValuesGroupingModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPieChartSmallValuesGroupingModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoPieChartSmallValuesGroupingModule, never, [typeof DxoPieChartSmallValuesGroupingComponent], [typeof DxoPieChartSmallValuesGroupingComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoPieChartSmallValuesGroupingModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoPieChartSubtitleComponent extends NestedOption implements OnDestroy, OnInit {
    get font(): Font;
    set font(value: Font);
    get offset(): number;
    set offset(value: number);
    get text(): string | undefined;
    set text(value: string | undefined);
    get textOverflow(): TextOverflow;
    set textOverflow(value: TextOverflow);
    get wordWrap(): WordWrap;
    set wordWrap(value: WordWrap);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPieChartSubtitleComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoPieChartSubtitleComponent, "dxo-pie-chart-subtitle", never, { "font": { "alias": "font"; "required": false; }; "offset": { "alias": "offset"; "required": false; }; "text": { "alias": "text"; "required": false; }; "textOverflow": { "alias": "textOverflow"; "required": false; }; "wordWrap": { "alias": "wordWrap"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoPieChartSubtitleModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPieChartSubtitleModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoPieChartSubtitleModule, never, [typeof DxoPieChartSubtitleComponent], [typeof DxoPieChartSubtitleComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoPieChartSubtitleModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoPieChartTitleComponent extends NestedOption implements OnDestroy, OnInit {
    get font(): Font;
    set font(value: Font);
    get horizontalAlignment(): HorizontalAlignment | undefined;
    set horizontalAlignment(value: HorizontalAlignment | undefined);
    get margin(): number | {
        bottom?: number;
        left?: number;
        right?: number;
        top?: number;
    };
    set margin(value: number | {
        bottom?: number;
        left?: number;
        right?: number;
        top?: number;
    });
    get placeholderSize(): number | undefined;
    set placeholderSize(value: number | undefined);
    get subtitle(): string | {
        font?: Font;
        offset?: number;
        text?: string | undefined;
        textOverflow?: TextOverflow;
        wordWrap?: WordWrap;
    };
    set subtitle(value: string | {
        font?: Font;
        offset?: number;
        text?: string | undefined;
        textOverflow?: TextOverflow;
        wordWrap?: WordWrap;
    });
    get text(): string | undefined;
    set text(value: string | undefined);
    get verticalAlignment(): VerticalEdge;
    set verticalAlignment(value: VerticalEdge);
    get textOverflow(): TextOverflow;
    set textOverflow(value: TextOverflow);
    get wordWrap(): WordWrap;
    set wordWrap(value: WordWrap);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPieChartTitleComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoPieChartTitleComponent, "dxo-pie-chart-title", never, { "font": { "alias": "font"; "required": false; }; "horizontalAlignment": { "alias": "horizontalAlignment"; "required": false; }; "margin": { "alias": "margin"; "required": false; }; "placeholderSize": { "alias": "placeholderSize"; "required": false; }; "subtitle": { "alias": "subtitle"; "required": false; }; "text": { "alias": "text"; "required": false; }; "verticalAlignment": { "alias": "verticalAlignment"; "required": false; }; "textOverflow": { "alias": "textOverflow"; "required": false; }; "wordWrap": { "alias": "wordWrap"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoPieChartTitleModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPieChartTitleModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoPieChartTitleModule, never, [typeof DxoPieChartTitleComponent], [typeof DxoPieChartTitleComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoPieChartTitleModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoPieChartTooltipBorderComponent extends NestedOption implements OnDestroy, OnInit {
    get color(): string;
    set color(value: string);
    get dashStyle(): DashStyle;
    set dashStyle(value: DashStyle);
    get opacity(): number | undefined;
    set opacity(value: number | undefined);
    get visible(): boolean;
    set visible(value: boolean);
    get width(): number;
    set width(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPieChartTooltipBorderComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoPieChartTooltipBorderComponent, "dxo-pie-chart-tooltip-border", never, { "color": { "alias": "color"; "required": false; }; "dashStyle": { "alias": "dashStyle"; "required": false; }; "opacity": { "alias": "opacity"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoPieChartTooltipBorderModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPieChartTooltipBorderModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoPieChartTooltipBorderModule, never, [typeof DxoPieChartTooltipBorderComponent], [typeof DxoPieChartTooltipBorderComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoPieChartTooltipBorderModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoPieChartTooltipComponent extends NestedOption implements OnDestroy, OnInit {
    get argumentFormat(): Format$1 | undefined;
    set argumentFormat(value: Format$1 | undefined);
    get arrowLength(): number;
    set arrowLength(value: number);
    get border(): {
        color?: string;
        dashStyle?: DashStyle;
        opacity?: number | undefined;
        visible?: boolean;
        width?: number;
    };
    set border(value: {
        color?: string;
        dashStyle?: DashStyle;
        opacity?: number | undefined;
        visible?: boolean;
        width?: number;
    });
    get color(): string;
    set color(value: string);
    get container(): any | string | undefined;
    set container(value: any | string | undefined);
    get contentTemplate(): any;
    set contentTemplate(value: any);
    get cornerRadius(): number;
    set cornerRadius(value: number);
    get customizeTooltip(): ((pointInfo: dxPieChartPointInfo) => Record<string, any>) | undefined;
    set customizeTooltip(value: ((pointInfo: dxPieChartPointInfo) => Record<string, any>) | undefined);
    get enabled(): boolean;
    set enabled(value: boolean);
    get font(): Font;
    set font(value: Font);
    get format(): Format$1 | undefined;
    set format(value: Format$1 | undefined);
    get interactive(): boolean;
    set interactive(value: boolean);
    get opacity(): number | undefined;
    set opacity(value: number | undefined);
    get paddingLeftRight(): number;
    set paddingLeftRight(value: number);
    get paddingTopBottom(): number;
    set paddingTopBottom(value: number);
    get shadow(): {
        blur?: number;
        color?: string;
        offsetX?: number;
        offsetY?: number;
        opacity?: number;
    };
    set shadow(value: {
        blur?: number;
        color?: string;
        offsetX?: number;
        offsetY?: number;
        opacity?: number;
    });
    get shared(): boolean;
    set shared(value: boolean);
    get zIndex(): number | undefined;
    set zIndex(value: number | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPieChartTooltipComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoPieChartTooltipComponent, "dxo-pie-chart-tooltip", never, { "argumentFormat": { "alias": "argumentFormat"; "required": false; }; "arrowLength": { "alias": "arrowLength"; "required": false; }; "border": { "alias": "border"; "required": false; }; "color": { "alias": "color"; "required": false; }; "container": { "alias": "container"; "required": false; }; "contentTemplate": { "alias": "contentTemplate"; "required": false; }; "cornerRadius": { "alias": "cornerRadius"; "required": false; }; "customizeTooltip": { "alias": "customizeTooltip"; "required": false; }; "enabled": { "alias": "enabled"; "required": false; }; "font": { "alias": "font"; "required": false; }; "format": { "alias": "format"; "required": false; }; "interactive": { "alias": "interactive"; "required": false; }; "opacity": { "alias": "opacity"; "required": false; }; "paddingLeftRight": { "alias": "paddingLeftRight"; "required": false; }; "paddingTopBottom": { "alias": "paddingTopBottom"; "required": false; }; "shadow": { "alias": "shadow"; "required": false; }; "shared": { "alias": "shared"; "required": false; }; "zIndex": { "alias": "zIndex"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoPieChartTooltipModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPieChartTooltipModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoPieChartTooltipModule, never, [typeof DxoPieChartTooltipComponent], [typeof DxoPieChartTooltipComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoPieChartTooltipModule>;
}

export { DxiPieChartAnnotationComponent, DxiPieChartAnnotationModule, DxiPieChartSeriesComponent, DxiPieChartSeriesModule, DxoPieChartAdaptiveLayoutComponent, DxoPieChartAdaptiveLayoutModule, DxoPieChartAnimationComponent, DxoPieChartAnimationModule, DxoPieChartAnnotationBorderComponent, DxoPieChartAnnotationBorderModule, DxoPieChartArgumentFormatComponent, DxoPieChartArgumentFormatModule, DxoPieChartBorderComponent, DxoPieChartBorderModule, DxoPieChartColorComponent, DxoPieChartColorModule, DxoPieChartCommonAnnotationSettingsComponent, DxoPieChartCommonAnnotationSettingsModule, DxoPieChartCommonSeriesSettingsComponent, DxoPieChartCommonSeriesSettingsModule, DxoPieChartConnectorComponent, DxoPieChartConnectorModule, DxoPieChartExportComponent, DxoPieChartExportModule, DxoPieChartFontComponent, DxoPieChartFontModule, DxoPieChartFormatComponent, DxoPieChartFormatModule, DxoPieChartHatchingComponent, DxoPieChartHatchingModule, DxoPieChartHoverStyleComponent, DxoPieChartHoverStyleModule, DxoPieChartImageComponent, DxoPieChartImageModule, DxoPieChartLabelComponent, DxoPieChartLabelModule, DxoPieChartLegendComponent, DxoPieChartLegendModule, DxoPieChartLegendTitleComponent, DxoPieChartLegendTitleModule, DxoPieChartLegendTitleSubtitleComponent, DxoPieChartLegendTitleSubtitleModule, DxoPieChartLoadingIndicatorComponent, DxoPieChartLoadingIndicatorModule, DxoPieChartMarginComponent, DxoPieChartMarginModule, DxoPieChartPieChartTitleComponent, DxoPieChartPieChartTitleModule, DxoPieChartPieChartTitleSubtitleComponent, DxoPieChartPieChartTitleSubtitleModule, DxoPieChartSelectionStyleComponent, DxoPieChartSelectionStyleModule, DxoPieChartSeriesBorderComponent, DxoPieChartSeriesBorderModule, DxoPieChartSeriesTemplateComponent, DxoPieChartSeriesTemplateModule, DxoPieChartShadowComponent, DxoPieChartShadowModule, DxoPieChartSizeComponent, DxoPieChartSizeModule, DxoPieChartSmallValuesGroupingComponent, DxoPieChartSmallValuesGroupingModule, DxoPieChartSubtitleComponent, DxoPieChartSubtitleModule, DxoPieChartTitleComponent, DxoPieChartTitleModule, DxoPieChartTooltipBorderComponent, DxoPieChartTooltipBorderModule, DxoPieChartTooltipComponent, DxoPieChartTooltipModule };
//# sourceMappingURL=index.d.ts.map
