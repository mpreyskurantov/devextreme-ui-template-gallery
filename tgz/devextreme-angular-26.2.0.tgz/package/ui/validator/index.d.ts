import * as i0 from '@angular/core';
import { OnDestroy, OnChanges, DoCheck, QueryList, EventEmitter, ElementRef, NgZone, TransferState, SimpleChanges } from '@angular/core';
import * as CommonTypes from 'devextreme/common';
import DxValidator, { DisposingEvent, InitializedEvent, OptionChangedEvent, ValidatedEvent } from 'devextreme/ui/validator';
import * as i3 from 'devextreme-angular/core';
import { DxComponentExtension, CollectionNestedOption, DxTemplateHost, WatcherHelper, IterableDifferHelper, NestedOptionHost } from 'devextreme-angular/core';
import * as i1 from 'devextreme-angular/ui/nested';
import * as i2 from 'devextreme-angular/ui/validator/nested';
export * from 'devextreme-angular/ui/validator/nested';
import * as validator_types from 'devextreme/ui/validator_types';
export { validator_types as DxValidatorTypes };

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

/**
 * [descr:dxValidator]

 */
declare class DxValidatorComponent extends DxComponentExtension implements OnDestroy, OnChanges, DoCheck {
    private _watcherHelper;
    private _idh;
    set _validationRulesContentChildren(value: QueryList<CollectionNestedOption>);
    instance: DxValidator;
    /**
     * [descr:dxValidatorOptions.adapter]
    
     */
    get adapter(): {
        applyValidationResults?: Function;
        bypass?: Function;
        focus?: Function;
        getValue?: Function;
        reset?: Function;
        validationRequestsCallbacks?: Array<Function>;
    };
    set adapter(value: {
        applyValidationResults?: Function;
        bypass?: Function;
        focus?: Function;
        getValue?: Function;
        reset?: Function;
        validationRequestsCallbacks?: Array<Function>;
    });
    /**
     * [descr:DOMComponentOptions.elementAttr]
    
     */
    get elementAttr(): Record<string, any>;
    set elementAttr(value: Record<string, any>);
    /**
     * [descr:DOMComponentOptions.height]
    
     */
    get height(): number | string | undefined;
    set height(value: number | string | undefined);
    /**
     * [descr:dxValidatorOptions.name]
    
     */
    get name(): string;
    set name(value: string);
    /**
     * [descr:dxValidatorOptions.validationGroup]
    
     */
    get validationGroup(): string;
    set validationGroup(value: string);
    /**
     * [descr:dxValidatorOptions.validationRules]
    
     */
    get validationRules(): Array<CommonTypes.ValidationRule>;
    set validationRules(value: Array<CommonTypes.ValidationRule>);
    /**
     * [descr:DOMComponentOptions.width]
    
     */
    get width(): number | string | undefined;
    set width(value: number | string | undefined);
    /**
    
     * [descr:dxValidatorOptions.onDisposing]
    
    
     */
    onDisposing: EventEmitter<DisposingEvent>;
    /**
    
     * [descr:dxValidatorOptions.onInitialized]
    
    
     */
    onInitialized: EventEmitter<InitializedEvent>;
    /**
    
     * [descr:dxValidatorOptions.onOptionChanged]
    
    
     */
    onOptionChanged: EventEmitter<OptionChangedEvent>;
    /**
    
     * [descr:dxValidatorOptions.onValidated]
    
    
     */
    onValidated: EventEmitter<ValidatedEvent>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    adapterChange: EventEmitter<{
        applyValidationResults?: Function;
        bypass?: Function;
        focus?: Function;
        getValue?: Function;
        reset?: Function;
        validationRequestsCallbacks?: Array<Function>;
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    elementAttrChange: EventEmitter<Record<string, any>>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    heightChange: EventEmitter<number | string | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    nameChange: EventEmitter<string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    validationGroupChange: EventEmitter<string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    validationRulesChange: EventEmitter<Array<CommonTypes.ValidationRule>>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    widthChange: EventEmitter<number | string | undefined>;
    parentElement: any;
    constructor(elementRef: ElementRef, ngZone: NgZone, templateHost: DxTemplateHost, _watcherHelper: WatcherHelper, _idh: IterableDifferHelper, parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost, transferState: TransferState, platformId: any);
    protected _createInstance(element: any, options: any): DxValidator;
    private getParentElement;
    ngOnDestroy(): void;
    ngOnChanges(changes: SimpleChanges): void;
    setupChanges(prop: string, changes: SimpleChanges): void;
    ngDoCheck(): void;
    _setOption(name: string, value: any): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxValidatorComponent, [null, null, null, null, null, { optional: true; host: true; skipSelf: true; }, null, null, null]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxValidatorComponent, "dx-validator", never, { "adapter": { "alias": "adapter"; "required": false; }; "elementAttr": { "alias": "elementAttr"; "required": false; }; "height": { "alias": "height"; "required": false; }; "name": { "alias": "name"; "required": false; }; "validationGroup": { "alias": "validationGroup"; "required": false; }; "validationRules": { "alias": "validationRules"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, { "onDisposing": "onDisposing"; "onInitialized": "onInitialized"; "onOptionChanged": "onOptionChanged"; "onValidated": "onValidated"; "adapterChange": "adapterChange"; "elementAttrChange": "elementAttrChange"; "heightChange": "heightChange"; "nameChange": "nameChange"; "validationGroupChange": "validationGroupChange"; "validationRulesChange": "validationRulesChange"; "widthChange": "widthChange"; }, ["_validationRulesContentChildren"], never, true, never>;
}
declare class DxValidatorModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxValidatorModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxValidatorModule, never, [typeof DxValidatorComponent, typeof i1.DxoAdapterModule, typeof i1.DxiValidationRuleModule, typeof i2.DxoValidatorAdapterModule, typeof i2.DxiValidatorAsyncRuleModule, typeof i2.DxiValidatorCompareRuleModule, typeof i2.DxiValidatorCustomRuleModule, typeof i2.DxiValidatorEmailRuleModule, typeof i2.DxiValidatorNumericRuleModule, typeof i2.DxiValidatorPatternRuleModule, typeof i2.DxiValidatorRangeRuleModule, typeof i2.DxiValidatorRequiredRuleModule, typeof i2.DxiValidatorStringLengthRuleModule, typeof i2.DxiValidatorValidationRuleModule, typeof i3.DxIntegrationModule, typeof i3.DxTemplateModule], [typeof DxValidatorComponent, typeof i1.DxoAdapterModule, typeof i1.DxiValidationRuleModule, typeof i2.DxoValidatorAdapterModule, typeof i2.DxiValidatorAsyncRuleModule, typeof i2.DxiValidatorCompareRuleModule, typeof i2.DxiValidatorCustomRuleModule, typeof i2.DxiValidatorEmailRuleModule, typeof i2.DxiValidatorNumericRuleModule, typeof i2.DxiValidatorPatternRuleModule, typeof i2.DxiValidatorRangeRuleModule, typeof i2.DxiValidatorRequiredRuleModule, typeof i2.DxiValidatorStringLengthRuleModule, typeof i2.DxiValidatorValidationRuleModule, typeof i3.DxTemplateModule]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxValidatorModule>;
}

export { DxValidatorComponent, DxValidatorModule };
//# sourceMappingURL=index.d.ts.map
