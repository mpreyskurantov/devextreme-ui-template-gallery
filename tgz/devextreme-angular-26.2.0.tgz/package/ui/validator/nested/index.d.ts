import * as i0 from '@angular/core';
import { OnDestroy, OnInit } from '@angular/core';
import { NestedOption, NestedOptionHost, CollectionNestedOption } from 'devextreme-angular/core';
import { ValidationRuleType, ComparisonOperator } from 'devextreme/common';

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoValidatorAdapterComponent extends NestedOption implements OnDestroy, OnInit {
    get applyValidationResults(): Function;
    set applyValidationResults(value: Function);
    get bypass(): Function;
    set bypass(value: Function);
    get focus(): Function;
    set focus(value: Function);
    get getValue(): Function;
    set getValue(value: Function);
    get reset(): Function;
    set reset(value: Function);
    get validationRequestsCallbacks(): Array<Function>;
    set validationRequestsCallbacks(value: Array<Function>);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoValidatorAdapterComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoValidatorAdapterComponent, "dxo-validator-adapter", never, { "applyValidationResults": { "alias": "applyValidationResults"; "required": false; }; "bypass": { "alias": "bypass"; "required": false; }; "focus": { "alias": "focus"; "required": false; }; "getValue": { "alias": "getValue"; "required": false; }; "reset": { "alias": "reset"; "required": false; }; "validationRequestsCallbacks": { "alias": "validationRequestsCallbacks"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoValidatorAdapterModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoValidatorAdapterModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoValidatorAdapterModule, never, [typeof DxoValidatorAdapterComponent], [typeof DxoValidatorAdapterComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoValidatorAdapterModule>;
}

declare class DxiValidatorAsyncRuleComponent extends CollectionNestedOption {
    get ignoreEmptyValue(): boolean;
    set ignoreEmptyValue(value: boolean);
    get message(): string;
    set message(value: string);
    get reevaluate(): boolean;
    set reevaluate(value: boolean);
    get type(): ValidationRuleType;
    set type(value: ValidationRuleType);
    get validationCallback(): ((options: {
        column: Record<string, any>;
        data: Record<string, any>;
        formItem: Record<string, any>;
        rule: Record<string, any>;
        validator: Record<string, any>;
        value: any;
    }) => any);
    set validationCallback(value: ((options: {
        column: Record<string, any>;
        data: Record<string, any>;
        formItem: Record<string, any>;
        rule: Record<string, any>;
        validator: Record<string, any>;
        value: any;
    }) => any));
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiValidatorAsyncRuleComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiValidatorAsyncRuleComponent, "dxi-validator-async-rule", never, { "ignoreEmptyValue": { "alias": "ignoreEmptyValue"; "required": false; }; "message": { "alias": "message"; "required": false; }; "reevaluate": { "alias": "reevaluate"; "required": false; }; "type": { "alias": "type"; "required": false; }; "validationCallback": { "alias": "validationCallback"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxiValidatorAsyncRuleModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiValidatorAsyncRuleModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiValidatorAsyncRuleModule, never, [typeof DxiValidatorAsyncRuleComponent], [typeof DxiValidatorAsyncRuleComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiValidatorAsyncRuleModule>;
}

declare class DxiValidatorCompareRuleComponent extends CollectionNestedOption {
    get comparisonTarget(): Function;
    set comparisonTarget(value: Function);
    get comparisonType(): ComparisonOperator;
    set comparisonType(value: ComparisonOperator);
    get ignoreEmptyValue(): boolean;
    set ignoreEmptyValue(value: boolean);
    get message(): string;
    set message(value: string);
    get type(): ValidationRuleType;
    set type(value: ValidationRuleType);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiValidatorCompareRuleComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiValidatorCompareRuleComponent, "dxi-validator-compare-rule", never, { "comparisonTarget": { "alias": "comparisonTarget"; "required": false; }; "comparisonType": { "alias": "comparisonType"; "required": false; }; "ignoreEmptyValue": { "alias": "ignoreEmptyValue"; "required": false; }; "message": { "alias": "message"; "required": false; }; "type": { "alias": "type"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxiValidatorCompareRuleModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiValidatorCompareRuleModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiValidatorCompareRuleModule, never, [typeof DxiValidatorCompareRuleComponent], [typeof DxiValidatorCompareRuleComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiValidatorCompareRuleModule>;
}

declare class DxiValidatorCustomRuleComponent extends CollectionNestedOption {
    get ignoreEmptyValue(): boolean;
    set ignoreEmptyValue(value: boolean);
    get message(): string;
    set message(value: string);
    get reevaluate(): boolean;
    set reevaluate(value: boolean);
    get type(): ValidationRuleType;
    set type(value: ValidationRuleType);
    get validationCallback(): ((options: {
        column: Record<string, any>;
        data: Record<string, any>;
        formItem: Record<string, any>;
        rule: Record<string, any>;
        validator: Record<string, any>;
        value: any;
    }) => boolean);
    set validationCallback(value: ((options: {
        column: Record<string, any>;
        data: Record<string, any>;
        formItem: Record<string, any>;
        rule: Record<string, any>;
        validator: Record<string, any>;
        value: any;
    }) => boolean));
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiValidatorCustomRuleComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiValidatorCustomRuleComponent, "dxi-validator-custom-rule", never, { "ignoreEmptyValue": { "alias": "ignoreEmptyValue"; "required": false; }; "message": { "alias": "message"; "required": false; }; "reevaluate": { "alias": "reevaluate"; "required": false; }; "type": { "alias": "type"; "required": false; }; "validationCallback": { "alias": "validationCallback"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxiValidatorCustomRuleModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiValidatorCustomRuleModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiValidatorCustomRuleModule, never, [typeof DxiValidatorCustomRuleComponent], [typeof DxiValidatorCustomRuleComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiValidatorCustomRuleModule>;
}

declare class DxiValidatorEmailRuleComponent extends CollectionNestedOption {
    get ignoreEmptyValue(): boolean;
    set ignoreEmptyValue(value: boolean);
    get message(): string;
    set message(value: string);
    get type(): ValidationRuleType;
    set type(value: ValidationRuleType);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiValidatorEmailRuleComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiValidatorEmailRuleComponent, "dxi-validator-email-rule", never, { "ignoreEmptyValue": { "alias": "ignoreEmptyValue"; "required": false; }; "message": { "alias": "message"; "required": false; }; "type": { "alias": "type"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxiValidatorEmailRuleModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiValidatorEmailRuleModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiValidatorEmailRuleModule, never, [typeof DxiValidatorEmailRuleComponent], [typeof DxiValidatorEmailRuleComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiValidatorEmailRuleModule>;
}

declare class DxiValidatorNumericRuleComponent extends CollectionNestedOption {
    get ignoreEmptyValue(): boolean;
    set ignoreEmptyValue(value: boolean);
    get message(): string;
    set message(value: string);
    get type(): ValidationRuleType;
    set type(value: ValidationRuleType);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiValidatorNumericRuleComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiValidatorNumericRuleComponent, "dxi-validator-numeric-rule", never, { "ignoreEmptyValue": { "alias": "ignoreEmptyValue"; "required": false; }; "message": { "alias": "message"; "required": false; }; "type": { "alias": "type"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxiValidatorNumericRuleModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiValidatorNumericRuleModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiValidatorNumericRuleModule, never, [typeof DxiValidatorNumericRuleComponent], [typeof DxiValidatorNumericRuleComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiValidatorNumericRuleModule>;
}

declare class DxiValidatorPatternRuleComponent extends CollectionNestedOption {
    get ignoreEmptyValue(): boolean;
    set ignoreEmptyValue(value: boolean);
    get message(): string;
    set message(value: string);
    get pattern(): RegExp | string;
    set pattern(value: RegExp | string);
    get type(): ValidationRuleType;
    set type(value: ValidationRuleType);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiValidatorPatternRuleComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiValidatorPatternRuleComponent, "dxi-validator-pattern-rule", never, { "ignoreEmptyValue": { "alias": "ignoreEmptyValue"; "required": false; }; "message": { "alias": "message"; "required": false; }; "pattern": { "alias": "pattern"; "required": false; }; "type": { "alias": "type"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxiValidatorPatternRuleModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiValidatorPatternRuleModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiValidatorPatternRuleModule, never, [typeof DxiValidatorPatternRuleComponent], [typeof DxiValidatorPatternRuleComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiValidatorPatternRuleModule>;
}

declare class DxiValidatorRangeRuleComponent extends CollectionNestedOption {
    get ignoreEmptyValue(): boolean;
    set ignoreEmptyValue(value: boolean);
    get max(): Date | number | string;
    set max(value: Date | number | string);
    get message(): string;
    set message(value: string);
    get min(): Date | number | string;
    set min(value: Date | number | string);
    get reevaluate(): boolean;
    set reevaluate(value: boolean);
    get type(): ValidationRuleType;
    set type(value: ValidationRuleType);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiValidatorRangeRuleComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiValidatorRangeRuleComponent, "dxi-validator-range-rule", never, { "ignoreEmptyValue": { "alias": "ignoreEmptyValue"; "required": false; }; "max": { "alias": "max"; "required": false; }; "message": { "alias": "message"; "required": false; }; "min": { "alias": "min"; "required": false; }; "reevaluate": { "alias": "reevaluate"; "required": false; }; "type": { "alias": "type"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxiValidatorRangeRuleModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiValidatorRangeRuleModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiValidatorRangeRuleModule, never, [typeof DxiValidatorRangeRuleComponent], [typeof DxiValidatorRangeRuleComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiValidatorRangeRuleModule>;
}

declare class DxiValidatorRequiredRuleComponent extends CollectionNestedOption {
    get message(): string;
    set message(value: string);
    get trim(): boolean;
    set trim(value: boolean);
    get type(): ValidationRuleType;
    set type(value: ValidationRuleType);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiValidatorRequiredRuleComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiValidatorRequiredRuleComponent, "dxi-validator-required-rule", never, { "message": { "alias": "message"; "required": false; }; "trim": { "alias": "trim"; "required": false; }; "type": { "alias": "type"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxiValidatorRequiredRuleModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiValidatorRequiredRuleModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiValidatorRequiredRuleModule, never, [typeof DxiValidatorRequiredRuleComponent], [typeof DxiValidatorRequiredRuleComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiValidatorRequiredRuleModule>;
}

declare class DxiValidatorStringLengthRuleComponent extends CollectionNestedOption {
    get ignoreEmptyValue(): boolean;
    set ignoreEmptyValue(value: boolean);
    get max(): number;
    set max(value: number);
    get message(): string;
    set message(value: string);
    get min(): number;
    set min(value: number);
    get trim(): boolean;
    set trim(value: boolean);
    get type(): ValidationRuleType;
    set type(value: ValidationRuleType);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiValidatorStringLengthRuleComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiValidatorStringLengthRuleComponent, "dxi-validator-string-length-rule", never, { "ignoreEmptyValue": { "alias": "ignoreEmptyValue"; "required": false; }; "max": { "alias": "max"; "required": false; }; "message": { "alias": "message"; "required": false; }; "min": { "alias": "min"; "required": false; }; "trim": { "alias": "trim"; "required": false; }; "type": { "alias": "type"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxiValidatorStringLengthRuleModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiValidatorStringLengthRuleModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiValidatorStringLengthRuleModule, never, [typeof DxiValidatorStringLengthRuleComponent], [typeof DxiValidatorStringLengthRuleComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiValidatorStringLengthRuleModule>;
}

declare class DxiValidatorValidationRuleComponent extends CollectionNestedOption {
    get message(): string;
    set message(value: string);
    get trim(): boolean;
    set trim(value: boolean);
    get type(): ValidationRuleType;
    set type(value: ValidationRuleType);
    get ignoreEmptyValue(): boolean;
    set ignoreEmptyValue(value: boolean);
    get max(): Date | number | string;
    set max(value: Date | number | string);
    get min(): Date | number | string;
    set min(value: Date | number | string);
    get reevaluate(): boolean;
    set reevaluate(value: boolean);
    get validationCallback(): ((options: {
        column: Record<string, any>;
        data: Record<string, any>;
        formItem: Record<string, any>;
        rule: Record<string, any>;
        validator: Record<string, any>;
        value: any;
    }) => boolean);
    set validationCallback(value: ((options: {
        column: Record<string, any>;
        data: Record<string, any>;
        formItem: Record<string, any>;
        rule: Record<string, any>;
        validator: Record<string, any>;
        value: any;
    }) => boolean));
    get comparisonTarget(): Function;
    set comparisonTarget(value: Function);
    get comparisonType(): ComparisonOperator;
    set comparisonType(value: ComparisonOperator);
    get pattern(): RegExp | string;
    set pattern(value: RegExp | string);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiValidatorValidationRuleComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiValidatorValidationRuleComponent, "dxi-validator-validation-rule", never, { "message": { "alias": "message"; "required": false; }; "trim": { "alias": "trim"; "required": false; }; "type": { "alias": "type"; "required": false; }; "ignoreEmptyValue": { "alias": "ignoreEmptyValue"; "required": false; }; "max": { "alias": "max"; "required": false; }; "min": { "alias": "min"; "required": false; }; "reevaluate": { "alias": "reevaluate"; "required": false; }; "validationCallback": { "alias": "validationCallback"; "required": false; }; "comparisonTarget": { "alias": "comparisonTarget"; "required": false; }; "comparisonType": { "alias": "comparisonType"; "required": false; }; "pattern": { "alias": "pattern"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxiValidatorValidationRuleModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiValidatorValidationRuleModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiValidatorValidationRuleModule, never, [typeof DxiValidatorValidationRuleComponent], [typeof DxiValidatorValidationRuleComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiValidatorValidationRuleModule>;
}

export { DxiValidatorAsyncRuleComponent, DxiValidatorAsyncRuleModule, DxiValidatorCompareRuleComponent, DxiValidatorCompareRuleModule, DxiValidatorCustomRuleComponent, DxiValidatorCustomRuleModule, DxiValidatorEmailRuleComponent, DxiValidatorEmailRuleModule, DxiValidatorNumericRuleComponent, DxiValidatorNumericRuleModule, DxiValidatorPatternRuleComponent, DxiValidatorPatternRuleModule, DxiValidatorRangeRuleComponent, DxiValidatorRangeRuleModule, DxiValidatorRequiredRuleComponent, DxiValidatorRequiredRuleModule, DxiValidatorStringLengthRuleComponent, DxiValidatorStringLengthRuleModule, DxiValidatorValidationRuleComponent, DxiValidatorValidationRuleModule, DxoValidatorAdapterComponent, DxoValidatorAdapterModule };
//# sourceMappingURL=index.d.ts.map
