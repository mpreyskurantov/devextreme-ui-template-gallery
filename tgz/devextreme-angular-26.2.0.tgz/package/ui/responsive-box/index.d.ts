import * as i0 from '@angular/core';
import { OnDestroy, OnChanges, DoCheck, QueryList, EventEmitter, ElementRef, NgZone, TransferState, SimpleChanges } from '@angular/core';
import DxResponsiveBox, { dxResponsiveBoxItem, ContentReadyEvent, DisposingEvent, InitializedEvent, ItemClickEvent, ItemContextMenuEvent, ItemHoldEvent, ItemRenderedEvent, OptionChangedEvent } from 'devextreme/ui/responsive_box';
export { ExplicitTypes } from 'devextreme/ui/responsive_box';
import DataSource, { DataSourceOptions } from 'devextreme/data/data_source';
import { Store } from 'devextreme/data/store';
import * as i3 from 'devextreme-angular/core';
import { DxComponent, CollectionNestedOption, DxTemplateHost, WatcherHelper, IterableDifferHelper, NestedOptionHost } from 'devextreme-angular/core';
import * as i1 from 'devextreme-angular/ui/nested';
import * as i2 from 'devextreme-angular/ui/responsive-box/nested';
export * from 'devextreme-angular/ui/responsive-box/nested';
import * as responsive_box_types from 'devextreme/ui/responsive_box_types';
export { responsive_box_types as DxResponsiveBoxTypes };

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

/**
 * [descr:dxResponsiveBox]

 */
declare class DxResponsiveBoxComponent<TItem = any, TKey = any> extends DxComponent implements OnDestroy, OnChanges, DoCheck {
    private _watcherHelper;
    private _idh;
    set _colsContentChildren(value: QueryList<CollectionNestedOption>);
    set _itemsContentChildren(value: QueryList<CollectionNestedOption>);
    set _locationContentChildren(value: QueryList<CollectionNestedOption>);
    set _rowsContentChildren(value: QueryList<CollectionNestedOption>);
    instance: DxResponsiveBox<TItem, TKey>;
    /**
     * [descr:dxResponsiveBoxOptions.cols]
    
     */
    get cols(): {
        baseSize?: number | string;
        ratio?: number;
        screen?: string | undefined;
        shrink?: number;
    }[];
    set cols(value: {
        baseSize?: number | string;
        ratio?: number;
        screen?: string | undefined;
        shrink?: number;
    }[]);
    /**
     * [descr:dxResponsiveBoxOptions.dataSource]
    
     */
    get dataSource(): Array<any | dxResponsiveBoxItem | string> | DataSource | DataSourceOptions | null | Store | string;
    set dataSource(value: Array<any | dxResponsiveBoxItem | string> | DataSource | DataSourceOptions | null | Store | string);
    /**
     * [descr:WidgetOptions.disabled]
    
     */
    get disabled(): boolean;
    set disabled(value: boolean);
    /**
     * [descr:DOMComponentOptions.elementAttr]
    
     */
    get elementAttr(): Record<string, any>;
    set elementAttr(value: Record<string, any>);
    /**
     * [descr:dxResponsiveBoxOptions.height]
    
     */
    get height(): number | string;
    set height(value: number | string);
    /**
     * [descr:WidgetOptions.hoverStateEnabled]
    
     */
    get hoverStateEnabled(): boolean;
    set hoverStateEnabled(value: boolean);
    /**
     * [descr:CollectionWidgetOptions.itemHoldTimeout]
    
     */
    get itemHoldTimeout(): number;
    set itemHoldTimeout(value: number);
    /**
     * [descr:dxResponsiveBoxOptions.items]
    
     */
    get items(): Array<any | dxResponsiveBoxItem | string>;
    set items(value: Array<any | dxResponsiveBoxItem | string>);
    /**
     * [descr:CollectionWidgetOptions.itemTemplate]
    
     */
    get itemTemplate(): any;
    set itemTemplate(value: any);
    /**
     * [descr:dxResponsiveBoxOptions.rows]
    
     */
    get rows(): {
        baseSize?: number | string;
        ratio?: number;
        screen?: string | undefined;
        shrink?: number;
    }[];
    set rows(value: {
        baseSize?: number | string;
        ratio?: number;
        screen?: string | undefined;
        shrink?: number;
    }[]);
    /**
     * [descr:DOMComponentOptions.rtlEnabled]
    
     */
    get rtlEnabled(): boolean;
    set rtlEnabled(value: boolean);
    /**
     * [descr:dxResponsiveBoxOptions.screenByWidth]
    
     */
    get screenByWidth(): Function | undefined;
    set screenByWidth(value: Function | undefined);
    /**
     * [descr:dxResponsiveBoxOptions.singleColumnScreen]
    
     */
    get singleColumnScreen(): string;
    set singleColumnScreen(value: string);
    /**
     * [descr:WidgetOptions.visible]
    
     */
    get visible(): boolean;
    set visible(value: boolean);
    /**
     * [descr:dxResponsiveBoxOptions.width]
    
     */
    get width(): number | string;
    set width(value: number | string);
    /**
    
     * [descr:dxResponsiveBoxOptions.onContentReady]
    
    
     */
    onContentReady: EventEmitter<ContentReadyEvent>;
    /**
    
     * [descr:dxResponsiveBoxOptions.onDisposing]
    
    
     */
    onDisposing: EventEmitter<DisposingEvent>;
    /**
    
     * [descr:dxResponsiveBoxOptions.onInitialized]
    
    
     */
    onInitialized: EventEmitter<InitializedEvent>;
    /**
    
     * [descr:dxResponsiveBoxOptions.onItemClick]
    
    
     */
    onItemClick: EventEmitter<ItemClickEvent>;
    /**
    
     * [descr:dxResponsiveBoxOptions.onItemContextMenu]
    
    
     */
    onItemContextMenu: EventEmitter<ItemContextMenuEvent>;
    /**
    
     * [descr:dxResponsiveBoxOptions.onItemHold]
    
    
     */
    onItemHold: EventEmitter<ItemHoldEvent>;
    /**
    
     * [descr:dxResponsiveBoxOptions.onItemRendered]
    
    
     */
    onItemRendered: EventEmitter<ItemRenderedEvent>;
    /**
    
     * [descr:dxResponsiveBoxOptions.onOptionChanged]
    
    
     */
    onOptionChanged: EventEmitter<OptionChangedEvent>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    colsChange: EventEmitter<{
        baseSize?: number | string;
        ratio?: number;
        screen?: string | undefined;
        shrink?: number;
    }[]>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    dataSourceChange: EventEmitter<Array<any | dxResponsiveBoxItem | string> | DataSource | DataSourceOptions | null | Store | string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    disabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    elementAttrChange: EventEmitter<Record<string, any>>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    heightChange: EventEmitter<number | string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    hoverStateEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    itemHoldTimeoutChange: EventEmitter<number>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    itemsChange: EventEmitter<Array<any | dxResponsiveBoxItem | string>>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    itemTemplateChange: EventEmitter<any>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    rowsChange: EventEmitter<{
        baseSize?: number | string;
        ratio?: number;
        screen?: string | undefined;
        shrink?: number;
    }[]>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    rtlEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    screenByWidthChange: EventEmitter<Function | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    singleColumnScreenChange: EventEmitter<string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    visibleChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    widthChange: EventEmitter<number | string>;
    constructor(elementRef: ElementRef, ngZone: NgZone, templateHost: DxTemplateHost, _watcherHelper: WatcherHelper, _idh: IterableDifferHelper, optionHost: NestedOptionHost, transferState: TransferState, platformId: any);
    protected _createInstance(element: any, options: any): DxResponsiveBox<any, any>;
    ngOnDestroy(): void;
    ngOnChanges(changes: SimpleChanges): void;
    setupChanges(prop: string, changes: SimpleChanges): void;
    ngDoCheck(): void;
    _setOption(name: string, value: any): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxResponsiveBoxComponent<any, any>, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxResponsiveBoxComponent<any, any>, "dx-responsive-box", never, { "cols": { "alias": "cols"; "required": false; }; "dataSource": { "alias": "dataSource"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "elementAttr": { "alias": "elementAttr"; "required": false; }; "height": { "alias": "height"; "required": false; }; "hoverStateEnabled": { "alias": "hoverStateEnabled"; "required": false; }; "itemHoldTimeout": { "alias": "itemHoldTimeout"; "required": false; }; "items": { "alias": "items"; "required": false; }; "itemTemplate": { "alias": "itemTemplate"; "required": false; }; "rows": { "alias": "rows"; "required": false; }; "rtlEnabled": { "alias": "rtlEnabled"; "required": false; }; "screenByWidth": { "alias": "screenByWidth"; "required": false; }; "singleColumnScreen": { "alias": "singleColumnScreen"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, { "onContentReady": "onContentReady"; "onDisposing": "onDisposing"; "onInitialized": "onInitialized"; "onItemClick": "onItemClick"; "onItemContextMenu": "onItemContextMenu"; "onItemHold": "onItemHold"; "onItemRendered": "onItemRendered"; "onOptionChanged": "onOptionChanged"; "colsChange": "colsChange"; "dataSourceChange": "dataSourceChange"; "disabledChange": "disabledChange"; "elementAttrChange": "elementAttrChange"; "heightChange": "heightChange"; "hoverStateEnabledChange": "hoverStateEnabledChange"; "itemHoldTimeoutChange": "itemHoldTimeoutChange"; "itemsChange": "itemsChange"; "itemTemplateChange": "itemTemplateChange"; "rowsChange": "rowsChange"; "rtlEnabledChange": "rtlEnabledChange"; "screenByWidthChange": "screenByWidthChange"; "singleColumnScreenChange": "singleColumnScreenChange"; "visibleChange": "visibleChange"; "widthChange": "widthChange"; }, ["_colsContentChildren", "_itemsContentChildren", "_locationContentChildren", "_rowsContentChildren"], never, true, never>;
}
declare class DxResponsiveBoxModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxResponsiveBoxModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxResponsiveBoxModule, never, [typeof DxResponsiveBoxComponent, typeof i1.DxiColModule, typeof i1.DxiItemModule, typeof i1.DxiLocationModule, typeof i1.DxiRowModule, typeof i2.DxiResponsiveBoxColModule, typeof i2.DxiResponsiveBoxItemModule, typeof i2.DxiResponsiveBoxLocationModule, typeof i2.DxiResponsiveBoxRowModule, typeof i3.DxIntegrationModule, typeof i3.DxTemplateModule], [typeof DxResponsiveBoxComponent, typeof i1.DxiColModule, typeof i1.DxiItemModule, typeof i1.DxiLocationModule, typeof i1.DxiRowModule, typeof i2.DxiResponsiveBoxColModule, typeof i2.DxiResponsiveBoxItemModule, typeof i2.DxiResponsiveBoxLocationModule, typeof i2.DxiResponsiveBoxRowModule, typeof i3.DxTemplateModule]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxResponsiveBoxModule>;
}

export { DxResponsiveBoxComponent, DxResponsiveBoxModule };
//# sourceMappingURL=index.d.ts.map
