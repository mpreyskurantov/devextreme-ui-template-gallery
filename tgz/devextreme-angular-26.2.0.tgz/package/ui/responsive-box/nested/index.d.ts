import { CollectionNestedOption, NestedOptionHost, IDxTemplateHost, DxTemplateHost, DxTemplateDirective } from 'devextreme-angular/core';
import * as i0 from '@angular/core';
import { AfterViewInit, QueryList, Renderer2, ElementRef } from '@angular/core';

declare class DxiResponsiveBoxColComponent extends CollectionNestedOption {
    get baseSize(): number | string;
    set baseSize(value: number | string);
    get ratio(): number;
    set ratio(value: number);
    get screen(): string | undefined;
    set screen(value: string | undefined);
    get shrink(): number;
    set shrink(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiResponsiveBoxColComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiResponsiveBoxColComponent, "dxi-responsive-box-col", never, { "baseSize": { "alias": "baseSize"; "required": false; }; "ratio": { "alias": "ratio"; "required": false; }; "screen": { "alias": "screen"; "required": false; }; "shrink": { "alias": "shrink"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxiResponsiveBoxColModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiResponsiveBoxColModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiResponsiveBoxColModule, never, [typeof DxiResponsiveBoxColComponent], [typeof DxiResponsiveBoxColComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiResponsiveBoxColModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxiResponsiveBoxItemComponent extends CollectionNestedOption implements AfterViewInit, IDxTemplateHost {
    private renderer;
    private document;
    private element;
    set _locationContentChildren(value: QueryList<CollectionNestedOption>);
    get disabled(): boolean;
    set disabled(value: boolean);
    get html(): string;
    set html(value: string);
    get location(): {
        col?: number;
        colspan?: number | undefined;
        row?: number;
        rowspan?: number | undefined;
        screen?: string | undefined;
    }[];
    set location(value: {
        col?: number;
        colspan?: number | undefined;
        row?: number;
        rowspan?: number | undefined;
        screen?: string | undefined;
    }[]);
    get template(): any;
    set template(value: any);
    get text(): string;
    set text(value: string);
    get visible(): boolean;
    set visible(value: boolean);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost, renderer: Renderer2, document: any, templateHost: DxTemplateHost, element: ElementRef);
    setTemplate(template: DxTemplateDirective): void;
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiResponsiveBoxItemComponent, [{ host: true; skipSelf: true; }, { host: true; }, null, null, { host: true; }, null]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiResponsiveBoxItemComponent, "dxi-responsive-box-item", never, { "disabled": { "alias": "disabled"; "required": false; }; "html": { "alias": "html"; "required": false; }; "location": { "alias": "location"; "required": false; }; "template": { "alias": "template"; "required": false; }; "text": { "alias": "text"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; }, {}, ["_locationContentChildren"], ["*"], true, never>;
}
declare class DxiResponsiveBoxItemModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiResponsiveBoxItemModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiResponsiveBoxItemModule, never, [typeof DxiResponsiveBoxItemComponent], [typeof DxiResponsiveBoxItemComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiResponsiveBoxItemModule>;
}

declare class DxiResponsiveBoxLocationComponent extends CollectionNestedOption {
    get col(): number;
    set col(value: number);
    get colspan(): number | undefined;
    set colspan(value: number | undefined);
    get row(): number;
    set row(value: number);
    get rowspan(): number | undefined;
    set rowspan(value: number | undefined);
    get screen(): string | undefined;
    set screen(value: string | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiResponsiveBoxLocationComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiResponsiveBoxLocationComponent, "dxi-responsive-box-location", never, { "col": { "alias": "col"; "required": false; }; "colspan": { "alias": "colspan"; "required": false; }; "row": { "alias": "row"; "required": false; }; "rowspan": { "alias": "rowspan"; "required": false; }; "screen": { "alias": "screen"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxiResponsiveBoxLocationModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiResponsiveBoxLocationModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiResponsiveBoxLocationModule, never, [typeof DxiResponsiveBoxLocationComponent], [typeof DxiResponsiveBoxLocationComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiResponsiveBoxLocationModule>;
}

declare class DxiResponsiveBoxRowComponent extends CollectionNestedOption {
    get baseSize(): number | string;
    set baseSize(value: number | string);
    get ratio(): number;
    set ratio(value: number);
    get screen(): string | undefined;
    set screen(value: string | undefined);
    get shrink(): number;
    set shrink(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiResponsiveBoxRowComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiResponsiveBoxRowComponent, "dxi-responsive-box-row", never, { "baseSize": { "alias": "baseSize"; "required": false; }; "ratio": { "alias": "ratio"; "required": false; }; "screen": { "alias": "screen"; "required": false; }; "shrink": { "alias": "shrink"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxiResponsiveBoxRowModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiResponsiveBoxRowModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiResponsiveBoxRowModule, never, [typeof DxiResponsiveBoxRowComponent], [typeof DxiResponsiveBoxRowComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiResponsiveBoxRowModule>;
}

export { DxiResponsiveBoxColComponent, DxiResponsiveBoxColModule, DxiResponsiveBoxItemComponent, DxiResponsiveBoxItemModule, DxiResponsiveBoxLocationComponent, DxiResponsiveBoxLocationModule, DxiResponsiveBoxRowComponent, DxiResponsiveBoxRowModule };
//# sourceMappingURL=index.d.ts.map
