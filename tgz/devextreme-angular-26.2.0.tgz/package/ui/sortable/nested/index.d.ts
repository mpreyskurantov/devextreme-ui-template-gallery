import * as i0 from '@angular/core';
import { OnDestroy, OnInit } from '@angular/core';
import { NestedOption, NestedOptionHost } from 'devextreme-angular/core';

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoSortableCursorOffsetComponent extends NestedOption implements OnDestroy, OnInit {
    get x(): number;
    set x(value: number);
    get y(): number;
    set y(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoSortableCursorOffsetComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoSortableCursorOffsetComponent, "dxo-sortable-cursor-offset", never, { "x": { "alias": "x"; "required": false; }; "y": { "alias": "y"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoSortableCursorOffsetModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoSortableCursorOffsetModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoSortableCursorOffsetModule, never, [typeof DxoSortableCursorOffsetComponent], [typeof DxoSortableCursorOffsetComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoSortableCursorOffsetModule>;
}

export { DxoSortableCursorOffsetComponent, DxoSortableCursorOffsetModule };
//# sourceMappingURL=index.d.ts.map
