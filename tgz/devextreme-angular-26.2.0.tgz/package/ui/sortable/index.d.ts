import * as i0 from '@angular/core';
import { OnDestroy, EventEmitter, ElementRef, NgZone, TransferState } from '@angular/core';
import { DragDirection, DragHighlight, Orientation } from 'devextreme/common';
import DxSortable, { AddEvent, DisposingEvent, DragChangeEvent, DragEndEvent, DragMoveEvent, DragStartEvent, InitializedEvent, OptionChangedEvent, RemoveEvent, ReorderEvent } from 'devextreme/ui/sortable';
import * as i3 from 'devextreme-angular/core';
import { DxComponent, DxTemplateHost, WatcherHelper, NestedOptionHost } from 'devextreme-angular/core';
import * as i1 from 'devextreme-angular/ui/nested';
import * as i2 from 'devextreme-angular/ui/sortable/nested';
export * from 'devextreme-angular/ui/sortable/nested';
import * as sortable_types from 'devextreme/ui/sortable_types';
export { sortable_types as DxSortableTypes };

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

/**
 * [descr:dxSortable]

 */
declare class DxSortableComponent extends DxComponent implements OnDestroy {
    instance: DxSortable;
    /**
     * [descr:dxSortableOptions.allowDropInsideItem]
    
     */
    get allowDropInsideItem(): boolean;
    set allowDropInsideItem(value: boolean);
    /**
     * [descr:dxSortableOptions.allowReordering]
    
     */
    get allowReordering(): boolean;
    set allowReordering(value: boolean);
    /**
     * [descr:DraggableBaseOptions.autoScroll]
    
     */
    get autoScroll(): boolean;
    set autoScroll(value: boolean);
    /**
     * [descr:DraggableBaseOptions.boundary]
    
     */
    get boundary(): any | string | undefined;
    set boundary(value: any | string | undefined);
    /**
     * [descr:DraggableBaseOptions.container]
    
     */
    get container(): any | string | undefined;
    set container(value: any | string | undefined);
    /**
     * [descr:DraggableBaseOptions.cursorOffset]
    
     */
    get cursorOffset(): string | {
        x?: number;
        y?: number;
    };
    set cursorOffset(value: string | {
        x?: number;
        y?: number;
    });
    /**
     * [descr:DraggableBaseOptions.data]
    
     */
    get data(): any | undefined;
    set data(value: any | undefined);
    /**
     * [descr:DraggableBaseOptions.dragDirection]
    
     */
    get dragDirection(): DragDirection;
    set dragDirection(value: DragDirection);
    /**
     * [descr:dxSortableOptions.dragTemplate]
    
     */
    get dragTemplate(): any;
    set dragTemplate(value: any);
    /**
     * [descr:dxSortableOptions.dropFeedbackMode]
    
     */
    get dropFeedbackMode(): DragHighlight;
    set dropFeedbackMode(value: DragHighlight);
    /**
     * [descr:DOMComponentOptions.elementAttr]
    
     */
    get elementAttr(): Record<string, any>;
    set elementAttr(value: Record<string, any>);
    /**
     * [descr:dxSortableOptions.filter]
    
     */
    get filter(): string;
    set filter(value: string);
    /**
     * [descr:DraggableBaseOptions.group]
    
     */
    get group(): string | undefined;
    set group(value: string | undefined);
    /**
     * [descr:DraggableBaseOptions.handle]
    
     */
    get handle(): string;
    set handle(value: string);
    /**
     * [descr:DOMComponentOptions.height]
    
     */
    get height(): number | string | undefined;
    set height(value: number | string | undefined);
    /**
     * [descr:dxSortableOptions.itemOrientation]
    
     */
    get itemOrientation(): Orientation;
    set itemOrientation(value: Orientation);
    /**
     * [descr:dxSortableOptions.moveItemOnDrop]
    
     */
    get moveItemOnDrop(): boolean;
    set moveItemOnDrop(value: boolean);
    /**
     * [descr:DOMComponentOptions.rtlEnabled]
    
     */
    get rtlEnabled(): boolean;
    set rtlEnabled(value: boolean);
    /**
     * [descr:DraggableBaseOptions.scrollSensitivity]
    
     */
    get scrollSensitivity(): number;
    set scrollSensitivity(value: number);
    /**
     * [descr:DraggableBaseOptions.scrollSpeed]
    
     */
    get scrollSpeed(): number;
    set scrollSpeed(value: number);
    /**
     * [descr:DOMComponentOptions.width]
    
     */
    get width(): number | string | undefined;
    set width(value: number | string | undefined);
    /**
    
     * [descr:dxSortableOptions.onAdd]
    
    
     */
    onAdd: EventEmitter<AddEvent>;
    /**
    
     * [descr:dxSortableOptions.onDisposing]
    
    
     */
    onDisposing: EventEmitter<DisposingEvent>;
    /**
    
     * [descr:dxSortableOptions.onDragChange]
    
    
     */
    onDragChange: EventEmitter<DragChangeEvent>;
    /**
    
     * [descr:dxSortableOptions.onDragEnd]
    
    
     */
    onDragEnd: EventEmitter<DragEndEvent>;
    /**
    
     * [descr:dxSortableOptions.onDragMove]
    
    
     */
    onDragMove: EventEmitter<DragMoveEvent>;
    /**
    
     * [descr:dxSortableOptions.onDragStart]
    
    
     */
    onDragStart: EventEmitter<DragStartEvent>;
    /**
    
     * [descr:dxSortableOptions.onInitialized]
    
    
     */
    onInitialized: EventEmitter<InitializedEvent>;
    /**
    
     * [descr:dxSortableOptions.onOptionChanged]
    
    
     */
    onOptionChanged: EventEmitter<OptionChangedEvent>;
    /**
    
     * [descr:dxSortableOptions.onRemove]
    
    
     */
    onRemove: EventEmitter<RemoveEvent>;
    /**
    
     * [descr:dxSortableOptions.onReorder]
    
    
     */
    onReorder: EventEmitter<ReorderEvent>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    allowDropInsideItemChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    allowReorderingChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    autoScrollChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    boundaryChange: EventEmitter<any | string | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    containerChange: EventEmitter<any | string | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    cursorOffsetChange: EventEmitter<string | {
        x?: number;
        y?: number;
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    dataChange: EventEmitter<any | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    dragDirectionChange: EventEmitter<DragDirection>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    dragTemplateChange: EventEmitter<any>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    dropFeedbackModeChange: EventEmitter<DragHighlight>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    elementAttrChange: EventEmitter<Record<string, any>>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    filterChange: EventEmitter<string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    groupChange: EventEmitter<string | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    handleChange: EventEmitter<string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    heightChange: EventEmitter<number | string | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    itemOrientationChange: EventEmitter<Orientation>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    moveItemOnDropChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    rtlEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    scrollSensitivityChange: EventEmitter<number>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    scrollSpeedChange: EventEmitter<number>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    widthChange: EventEmitter<number | string | undefined>;
    constructor(elementRef: ElementRef, ngZone: NgZone, templateHost: DxTemplateHost, _watcherHelper: WatcherHelper, optionHost: NestedOptionHost, transferState: TransferState, platformId: any);
    protected _createInstance(element: any, options: any): DxSortable;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxSortableComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxSortableComponent, "dx-sortable", never, { "allowDropInsideItem": { "alias": "allowDropInsideItem"; "required": false; }; "allowReordering": { "alias": "allowReordering"; "required": false; }; "autoScroll": { "alias": "autoScroll"; "required": false; }; "boundary": { "alias": "boundary"; "required": false; }; "container": { "alias": "container"; "required": false; }; "cursorOffset": { "alias": "cursorOffset"; "required": false; }; "data": { "alias": "data"; "required": false; }; "dragDirection": { "alias": "dragDirection"; "required": false; }; "dragTemplate": { "alias": "dragTemplate"; "required": false; }; "dropFeedbackMode": { "alias": "dropFeedbackMode"; "required": false; }; "elementAttr": { "alias": "elementAttr"; "required": false; }; "filter": { "alias": "filter"; "required": false; }; "group": { "alias": "group"; "required": false; }; "handle": { "alias": "handle"; "required": false; }; "height": { "alias": "height"; "required": false; }; "itemOrientation": { "alias": "itemOrientation"; "required": false; }; "moveItemOnDrop": { "alias": "moveItemOnDrop"; "required": false; }; "rtlEnabled": { "alias": "rtlEnabled"; "required": false; }; "scrollSensitivity": { "alias": "scrollSensitivity"; "required": false; }; "scrollSpeed": { "alias": "scrollSpeed"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, { "onAdd": "onAdd"; "onDisposing": "onDisposing"; "onDragChange": "onDragChange"; "onDragEnd": "onDragEnd"; "onDragMove": "onDragMove"; "onDragStart": "onDragStart"; "onInitialized": "onInitialized"; "onOptionChanged": "onOptionChanged"; "onRemove": "onRemove"; "onReorder": "onReorder"; "allowDropInsideItemChange": "allowDropInsideItemChange"; "allowReorderingChange": "allowReorderingChange"; "autoScrollChange": "autoScrollChange"; "boundaryChange": "boundaryChange"; "containerChange": "containerChange"; "cursorOffsetChange": "cursorOffsetChange"; "dataChange": "dataChange"; "dragDirectionChange": "dragDirectionChange"; "dragTemplateChange": "dragTemplateChange"; "dropFeedbackModeChange": "dropFeedbackModeChange"; "elementAttrChange": "elementAttrChange"; "filterChange": "filterChange"; "groupChange": "groupChange"; "handleChange": "handleChange"; "heightChange": "heightChange"; "itemOrientationChange": "itemOrientationChange"; "moveItemOnDropChange": "moveItemOnDropChange"; "rtlEnabledChange": "rtlEnabledChange"; "scrollSensitivityChange": "scrollSensitivityChange"; "scrollSpeedChange": "scrollSpeedChange"; "widthChange": "widthChange"; }, never, ["*"], true, never>;
}
declare class DxSortableModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxSortableModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxSortableModule, never, [typeof DxSortableComponent, typeof i1.DxoCursorOffsetModule, typeof i2.DxoSortableCursorOffsetModule, typeof i3.DxIntegrationModule, typeof i3.DxTemplateModule], [typeof DxSortableComponent, typeof i1.DxoCursorOffsetModule, typeof i2.DxoSortableCursorOffsetModule, typeof i3.DxTemplateModule]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxSortableModule>;
}

export { DxSortableComponent, DxSortableModule };
//# sourceMappingURL=index.d.ts.map
