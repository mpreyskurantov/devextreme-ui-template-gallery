import * as i0 from '@angular/core';
import { OnDestroy, OnChanges, DoCheck, QueryList, EventEmitter, ElementRef, NgZone, TransferState, SimpleChanges } from '@angular/core';
import { AIAssistant, ColumnChooser, ColumnResizeMode, DataChange, GridsEditMode, NewRowPosition, GridsEditRefreshMode, StartEditAction, FilterPanel, ApplyFilterMode, GroupExpandMode, HeaderFilter, EnterKeyAction, EnterKeyDirection, Pager, DataRenderMode, SearchPanel, SelectionColumnDisplayMode, Sorting, StateStoreType, SummaryType } from 'devextreme/common/grids';
import { AIIntegration } from 'devextreme/common/ai-integration';
import dxDataGrid, { dxDataGridColumn, dxDataGridRowObject, DataGridExportFormat, RowDraggingAddEvent, RowDraggingChangeEvent, RowDraggingEndEvent, RowDraggingMoveEvent, RowDraggingStartEvent, RowDraggingRemoveEvent, RowDraggingReorderEvent, DataGridScrollMode, SelectionSensitivity, dxDataGridToolbar, AdaptiveDetailRowPreparingEvent, AIAssistantRequestCreatingEvent, AIColumnRequestCreatingEvent, CellClickEvent, CellDblClickEvent, CellHoverChangedEvent, CellPreparedEvent, ContentReadyEvent, ContextMenuPreparingEvent, DataErrorOccurredEvent, DisposingEvent, EditCanceledEvent, EditCancelingEvent, EditingStartEvent, EditorPreparedEvent, EditorPreparingEvent, ExportingEvent, FocusedCellChangedEvent, FocusedCellChangingEvent, FocusedRowChangedEvent, FocusedRowChangingEvent, InitializedEvent, InitNewRowEvent, KeyDownEvent, OptionChangedEvent, RowClickEvent, RowCollapsedEvent, RowCollapsingEvent, RowDblClickEvent, RowExpandedEvent, RowExpandingEvent, RowInsertedEvent, RowInsertingEvent, RowPreparedEvent, RowRemovedEvent, RowRemovingEvent, RowUpdatedEvent, RowUpdatingEvent, RowValidatingEvent, SavedEvent, SavingEvent, SelectionChangedEvent, ToolbarPreparingEvent } from 'devextreme/ui/data_grid';
export { ExplicitTypes } from 'devextreme/ui/data_grid';
import { Mode, DragDirection, DragHighlight, ScrollbarMode, SingleMultipleOrNone, SelectAllMode, SortOrder, HorizontalAlignment } from 'devextreme/common';
import DataSource, { DataSourceOptions } from 'devextreme/data/data_source';
import { Store } from 'devextreme/data/store';
import { dxFormOptions } from 'devextreme/ui/form';
import { dxPopupOptions } from 'devextreme/ui/popup';
import { dxFilterBuilderOptions } from 'devextreme/ui/filter_builder';
import { LoadPanelIndicatorProperties } from 'devextreme/ui/load_panel';
import { Format } from 'devextreme/common/core/localization';
import * as i3 from 'devextreme-angular/core';
import { DxComponent, CollectionNestedOption, DxTemplateHost, WatcherHelper, IterableDifferHelper, NestedOptionHost } from 'devextreme-angular/core';
import * as i1 from 'devextreme-angular/ui/nested';
import * as i2 from 'devextreme-angular/ui/data-grid/nested';
export * from 'devextreme-angular/ui/data-grid/nested';
import * as data_grid_types from 'devextreme/ui/data_grid_types';
export { data_grid_types as DxDataGridTypes };

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

/**
 * [descr:dxDataGrid]

 */
declare class DxDataGridComponent<TRowData = any, TKey = any> extends DxComponent implements OnDestroy, OnChanges, DoCheck {
    private _watcherHelper;
    private _idh;
    set _validationRulesContentChildren(value: QueryList<CollectionNestedOption>);
    set _buttonsContentChildren(value: QueryList<CollectionNestedOption>);
    set _itemsContentChildren(value: QueryList<CollectionNestedOption>);
    set _changesContentChildren(value: QueryList<CollectionNestedOption>);
    set _columnsContentChildren(value: QueryList<CollectionNestedOption>);
    set _customOperationsContentChildren(value: QueryList<CollectionNestedOption>);
    set _fieldsContentChildren(value: QueryList<CollectionNestedOption>);
    set _groupItemsContentChildren(value: QueryList<CollectionNestedOption>);
    set _sortByGroupSummaryInfoContentChildren(value: QueryList<CollectionNestedOption>);
    set _tabsContentChildren(value: QueryList<CollectionNestedOption>);
    set _toolbarItemsContentChildren(value: QueryList<CollectionNestedOption>);
    set _totalItemsContentChildren(value: QueryList<CollectionNestedOption>);
    instance: dxDataGrid<TRowData, TKey>;
    /**
     * [descr:WidgetOptions.accessKey]
    
     */
    get accessKey(): string | undefined;
    set accessKey(value: string | undefined);
    /**
     * [descr:WidgetOptions.activeStateEnabled]
    
     */
    get activeStateEnabled(): boolean;
    set activeStateEnabled(value: boolean);
    /**
     * [descr:dxDataGridOptions.aiAssistant]
    
     */
    get aiAssistant(): AIAssistant;
    set aiAssistant(value: AIAssistant);
    /**
     * [descr:GridBaseOptions.aiIntegration]
    
     */
    get aiIntegration(): AIIntegration | undefined;
    set aiIntegration(value: AIIntegration | undefined);
    /**
     * [descr:GridBaseOptions.allowColumnReordering]
    
     */
    get allowColumnReordering(): boolean;
    set allowColumnReordering(value: boolean);
    /**
     * [descr:GridBaseOptions.allowColumnResizing]
    
     */
    get allowColumnResizing(): boolean;
    set allowColumnResizing(value: boolean);
    /**
     * [descr:GridBaseOptions.autoNavigateToFocusedRow]
    
     */
    get autoNavigateToFocusedRow(): boolean;
    set autoNavigateToFocusedRow(value: boolean);
    /**
     * [descr:GridBaseOptions.cacheEnabled]
    
     */
    get cacheEnabled(): boolean;
    set cacheEnabled(value: boolean);
    /**
     * [descr:GridBaseOptions.cellHintEnabled]
    
     */
    get cellHintEnabled(): boolean;
    set cellHintEnabled(value: boolean);
    /**
     * [descr:GridBaseOptions.columnAutoWidth]
    
     */
    get columnAutoWidth(): boolean;
    set columnAutoWidth(value: boolean);
    /**
     * [descr:GridBaseOptions.columnChooser]
    
     */
    get columnChooser(): ColumnChooser;
    set columnChooser(value: ColumnChooser);
    /**
     * [descr:GridBaseOptions.columnFixing]
    
     */
    get columnFixing(): {
        enabled?: boolean;
        icons?: {
            fix?: string;
            leftPosition?: string;
            rightPosition?: string;
            stickyPosition?: string;
            unfix?: string;
        };
        texts?: {
            fix?: string;
            leftPosition?: string;
            rightPosition?: string;
            stickyPosition?: string;
            unfix?: string;
        };
    };
    set columnFixing(value: {
        enabled?: boolean;
        icons?: {
            fix?: string;
            leftPosition?: string;
            rightPosition?: string;
            stickyPosition?: string;
            unfix?: string;
        };
        texts?: {
            fix?: string;
            leftPosition?: string;
            rightPosition?: string;
            stickyPosition?: string;
            unfix?: string;
        };
    });
    /**
     * [descr:GridBaseOptions.columnHidingEnabled]
    
     */
    get columnHidingEnabled(): boolean;
    set columnHidingEnabled(value: boolean);
    /**
     * [descr:GridBaseOptions.columnMinWidth]
    
     */
    get columnMinWidth(): number | undefined;
    set columnMinWidth(value: number | undefined);
    /**
     * [descr:GridBaseOptions.columnResizingMode]
    
     */
    get columnResizingMode(): ColumnResizeMode;
    set columnResizingMode(value: ColumnResizeMode);
    /**
     * [descr:dxDataGridOptions.columns]
    
     */
    get columns(): Array<dxDataGridColumn | string>;
    set columns(value: Array<dxDataGridColumn | string>);
    /**
     * [descr:GridBaseOptions.columnWidth]
    
     */
    get columnWidth(): Mode | number | undefined;
    set columnWidth(value: Mode | number | undefined);
    /**
     * [descr:dxDataGridOptions.customizeColumns]
    
     */
    get customizeColumns(): ((columns: Array<dxDataGridColumn>) => void);
    set customizeColumns(value: ((columns: Array<dxDataGridColumn>) => void));
    /**
     * [descr:dxDataGridOptions.dataRowTemplate]
    
     */
    get dataRowTemplate(): any;
    set dataRowTemplate(value: any);
    /**
     * [descr:GridBaseOptions.dataSource]
    
     */
    get dataSource(): Array<any> | DataSource | DataSourceOptions | Store | string | undefined;
    set dataSource(value: Array<any> | DataSource | DataSourceOptions | Store | string | undefined);
    /**
     * [descr:GridBaseOptions.dateSerializationFormat]
    
     */
    get dateSerializationFormat(): string;
    set dateSerializationFormat(value: string);
    /**
     * [descr:WidgetOptions.disabled]
    
     */
    get disabled(): boolean;
    set disabled(value: boolean);
    /**
     * [descr:dxDataGridOptions.editing]
    
     */
    get editing(): {
        allowAdding?: boolean;
        allowDeleting?: boolean | ((options: {
            component: dxDataGrid;
            row: dxDataGridRowObject;
        }) => boolean);
        allowUpdating?: boolean | ((options: {
            component: dxDataGrid;
            row: dxDataGridRowObject;
        }) => boolean);
        changes?: Array<DataChange>;
        confirmDelete?: boolean;
        editColumnName?: string | undefined;
        editRowKey?: any | undefined;
        form?: dxFormOptions;
        mode?: GridsEditMode;
        newRowPosition?: NewRowPosition;
        popup?: dxPopupOptions<any>;
        refreshMode?: GridsEditRefreshMode;
        selectTextOnEditStart?: boolean;
        startEditAction?: StartEditAction;
        texts?: any | {
            addRow?: string;
            cancelAllChanges?: string;
            cancelRowChanges?: string;
            confirmDeleteMessage?: string;
            confirmDeleteTitle?: string;
            deleteRow?: string;
            editRow?: string;
            saveAllChanges?: string;
            saveRowChanges?: string;
            undeleteRow?: string;
            validationCancelChanges?: string;
        };
        useIcons?: boolean;
    };
    set editing(value: {
        allowAdding?: boolean;
        allowDeleting?: boolean | ((options: {
            component: dxDataGrid;
            row: dxDataGridRowObject;
        }) => boolean);
        allowUpdating?: boolean | ((options: {
            component: dxDataGrid;
            row: dxDataGridRowObject;
        }) => boolean);
        changes?: Array<DataChange>;
        confirmDelete?: boolean;
        editColumnName?: string | undefined;
        editRowKey?: any | undefined;
        form?: dxFormOptions;
        mode?: GridsEditMode;
        newRowPosition?: NewRowPosition;
        popup?: dxPopupOptions<any>;
        refreshMode?: GridsEditRefreshMode;
        selectTextOnEditStart?: boolean;
        startEditAction?: StartEditAction;
        texts?: any | {
            addRow?: string;
            cancelAllChanges?: string;
            cancelRowChanges?: string;
            confirmDeleteMessage?: string;
            confirmDeleteTitle?: string;
            deleteRow?: string;
            editRow?: string;
            saveAllChanges?: string;
            saveRowChanges?: string;
            undeleteRow?: string;
            validationCancelChanges?: string;
        };
        useIcons?: boolean;
    });
    /**
     * [descr:DOMComponentOptions.elementAttr]
    
     */
    get elementAttr(): Record<string, any>;
    set elementAttr(value: Record<string, any>);
    /**
     * [descr:GridBaseOptions.errorRowEnabled]
    
     */
    get errorRowEnabled(): boolean;
    set errorRowEnabled(value: boolean);
    /**
     * [descr:dxDataGridOptions.export]
    
     */
    get export(): {
        allowExportSelectedData?: boolean;
        enabled?: boolean;
        formats?: Array<DataGridExportFormat | string>;
        texts?: {
            exportAll?: string;
            exportSelectedRows?: string;
            exportTo?: string;
        };
    };
    set export(value: {
        allowExportSelectedData?: boolean;
        enabled?: boolean;
        formats?: Array<DataGridExportFormat | string>;
        texts?: {
            exportAll?: string;
            exportSelectedRows?: string;
            exportTo?: string;
        };
    });
    /**
     * [descr:GridBaseOptions.filterBuilder]
    
     */
    get filterBuilder(): dxFilterBuilderOptions;
    set filterBuilder(value: dxFilterBuilderOptions);
    /**
     * [descr:GridBaseOptions.filterBuilderPopup]
    
     */
    get filterBuilderPopup(): dxPopupOptions<any>;
    set filterBuilderPopup(value: dxPopupOptions<any>);
    /**
     * [descr:GridBaseOptions.filterPanel]
    
     */
    get filterPanel(): FilterPanel;
    set filterPanel(value: FilterPanel);
    /**
     * [descr:GridBaseOptions.filterRow]
    
     */
    get filterRow(): {
        applyFilter?: ApplyFilterMode;
        applyFilterText?: string;
        betweenEndText?: string;
        betweenStartText?: string;
        operationDescriptions?: {
            between?: string;
            contains?: string;
            endsWith?: string;
            equal?: string;
            greaterThan?: string;
            greaterThanOrEqual?: string;
            lessThan?: string;
            lessThanOrEqual?: string;
            notContains?: string;
            notEqual?: string;
            startsWith?: string;
        };
        resetOperationText?: string;
        showAllText?: string;
        showOperationChooser?: boolean;
        visible?: boolean;
    };
    set filterRow(value: {
        applyFilter?: ApplyFilterMode;
        applyFilterText?: string;
        betweenEndText?: string;
        betweenStartText?: string;
        operationDescriptions?: {
            between?: string;
            contains?: string;
            endsWith?: string;
            equal?: string;
            greaterThan?: string;
            greaterThanOrEqual?: string;
            lessThan?: string;
            lessThanOrEqual?: string;
            notContains?: string;
            notEqual?: string;
            startsWith?: string;
        };
        resetOperationText?: string;
        showAllText?: string;
        showOperationChooser?: boolean;
        visible?: boolean;
    });
    /**
     * [descr:GridBaseOptions.filterSyncEnabled]
    
     */
    get filterSyncEnabled(): boolean | Mode;
    set filterSyncEnabled(value: boolean | Mode);
    /**
     * [descr:GridBaseOptions.filterValue]
    
     */
    get filterValue(): Array<any> | Function | string;
    set filterValue(value: Array<any> | Function | string);
    /**
     * [descr:GridBaseOptions.focusedColumnIndex]
    
     */
    get focusedColumnIndex(): number;
    set focusedColumnIndex(value: number);
    /**
     * [descr:GridBaseOptions.focusedRowEnabled]
    
     */
    get focusedRowEnabled(): boolean;
    set focusedRowEnabled(value: boolean);
    /**
     * [descr:GridBaseOptions.focusedRowIndex]
    
     */
    get focusedRowIndex(): number;
    set focusedRowIndex(value: number);
    /**
     * [descr:GridBaseOptions.focusedRowKey]
    
     */
    get focusedRowKey(): any | undefined;
    set focusedRowKey(value: any | undefined);
    /**
     * [descr:dxDataGridOptions.grouping]
    
     */
    get grouping(): {
        allowCollapsing?: boolean;
        autoExpandAll?: boolean;
        contextMenuEnabled?: boolean;
        expandMode?: GroupExpandMode;
        texts?: {
            groupByThisColumn?: string;
            groupContinuedMessage?: string;
            groupContinuesMessage?: string;
            ungroup?: string;
            ungroupAll?: string;
        };
    };
    set grouping(value: {
        allowCollapsing?: boolean;
        autoExpandAll?: boolean;
        contextMenuEnabled?: boolean;
        expandMode?: GroupExpandMode;
        texts?: {
            groupByThisColumn?: string;
            groupContinuedMessage?: string;
            groupContinuesMessage?: string;
            ungroup?: string;
            ungroupAll?: string;
        };
    });
    /**
     * [descr:dxDataGridOptions.groupPanel]
    
     */
    get groupPanel(): {
        allowColumnDragging?: boolean;
        emptyPanelText?: string;
        visible?: boolean | Mode;
    };
    set groupPanel(value: {
        allowColumnDragging?: boolean;
        emptyPanelText?: string;
        visible?: boolean | Mode;
    });
    /**
     * [descr:GridBaseOptions.headerFilter]
    
     */
    get headerFilter(): HeaderFilter;
    set headerFilter(value: HeaderFilter);
    /**
     * [descr:DOMComponentOptions.height]
    
     */
    get height(): number | string | undefined;
    set height(value: number | string | undefined);
    /**
     * [descr:GridBaseOptions.highlightChanges]
    
     */
    get highlightChanges(): boolean;
    set highlightChanges(value: boolean);
    /**
     * [descr:WidgetOptions.hint]
    
     */
    get hint(): string | undefined;
    set hint(value: string | undefined);
    /**
     * [descr:WidgetOptions.hoverStateEnabled]
    
     */
    get hoverStateEnabled(): boolean;
    set hoverStateEnabled(value: boolean);
    /**
     * [descr:GridBaseOptions.keyboardNavigation]
    
     */
    get keyboardNavigation(): {
        editOnKeyPress?: boolean;
        enabled?: boolean;
        enterKeyAction?: EnterKeyAction;
        enterKeyDirection?: EnterKeyDirection;
    };
    set keyboardNavigation(value: {
        editOnKeyPress?: boolean;
        enabled?: boolean;
        enterKeyAction?: EnterKeyAction;
        enterKeyDirection?: EnterKeyDirection;
    });
    /**
     * [descr:dxDataGridOptions.keyExpr]
    
     */
    get keyExpr(): Array<string> | string | undefined;
    set keyExpr(value: Array<string> | string | undefined);
    /**
     * [descr:GridBaseOptions.loadPanel]
    
     */
    get loadPanel(): {
        enabled?: boolean | Mode;
        height?: number | string;
        indicatorOptions?: LoadPanelIndicatorProperties;
        indicatorSrc?: string;
        shading?: boolean;
        shadingColor?: string;
        showIndicator?: boolean;
        showPane?: boolean;
        text?: string;
        width?: number | string;
    };
    set loadPanel(value: {
        enabled?: boolean | Mode;
        height?: number | string;
        indicatorOptions?: LoadPanelIndicatorProperties;
        indicatorSrc?: string;
        shading?: boolean;
        shadingColor?: string;
        showIndicator?: boolean;
        showPane?: boolean;
        text?: string;
        width?: number | string;
    });
    /**
     * [descr:dxDataGridOptions.masterDetail]
    
     */
    get masterDetail(): {
        autoExpandAll?: boolean;
        enabled?: boolean;
        template?: any;
    };
    set masterDetail(value: {
        autoExpandAll?: boolean;
        enabled?: boolean;
        template?: any;
    });
    /**
     * [descr:GridBaseOptions.noDataText]
    
     */
    get noDataText(): string;
    set noDataText(value: string);
    /**
     * [descr:GridBaseOptions.pager]
    
     */
    get pager(): Pager;
    set pager(value: Pager);
    /**
     * [descr:GridBaseOptions.paging]
    
     */
    get paging(): {
        enabled?: boolean;
        pageIndex?: number;
        pageSize?: number;
    };
    set paging(value: {
        enabled?: boolean;
        pageIndex?: number;
        pageSize?: number;
    });
    /**
     * [descr:dxDataGridOptions.remoteOperations]
    
     */
    get remoteOperations(): boolean | Mode | {
        filtering?: boolean;
        grouping?: boolean;
        groupPaging?: boolean;
        paging?: boolean;
        sorting?: boolean;
        summary?: boolean;
    };
    set remoteOperations(value: boolean | Mode | {
        filtering?: boolean;
        grouping?: boolean;
        groupPaging?: boolean;
        paging?: boolean;
        sorting?: boolean;
        summary?: boolean;
    });
    /**
     * [descr:GridBaseOptions.renderAsync]
    
     */
    get renderAsync(): boolean;
    set renderAsync(value: boolean);
    /**
     * [descr:GridBaseOptions.repaintChangesOnly]
    
     */
    get repaintChangesOnly(): boolean;
    set repaintChangesOnly(value: boolean);
    /**
     * [descr:GridBaseOptions.rowAlternationEnabled]
    
     */
    get rowAlternationEnabled(): boolean;
    set rowAlternationEnabled(value: boolean);
    /**
     * [descr:GridBaseOptions.rowDragging]
    
     */
    get rowDragging(): {
        allowDropInsideItem?: boolean;
        allowReordering?: boolean;
        autoScroll?: boolean;
        boundary?: any | string | undefined;
        container?: any | string | undefined;
        cursorOffset?: string | {
            x?: number;
            y?: number;
        };
        data?: any | undefined;
        dragDirection?: DragDirection;
        dragTemplate?: any;
        dropFeedbackMode?: DragHighlight;
        filter?: string;
        group?: string | undefined;
        handle?: string;
        onAdd?: ((e: RowDraggingAddEvent) => void);
        onDragChange?: ((e: RowDraggingChangeEvent) => void);
        onDragEnd?: ((e: RowDraggingEndEvent) => void);
        onDragMove?: ((e: RowDraggingMoveEvent) => void);
        onDragStart?: ((e: RowDraggingStartEvent) => void);
        onRemove?: ((e: RowDraggingRemoveEvent) => void);
        onReorder?: ((e: RowDraggingReorderEvent) => void);
        scrollSensitivity?: number;
        scrollSpeed?: number;
        showDragIcons?: boolean;
    };
    set rowDragging(value: {
        allowDropInsideItem?: boolean;
        allowReordering?: boolean;
        autoScroll?: boolean;
        boundary?: any | string | undefined;
        container?: any | string | undefined;
        cursorOffset?: string | {
            x?: number;
            y?: number;
        };
        data?: any | undefined;
        dragDirection?: DragDirection;
        dragTemplate?: any;
        dropFeedbackMode?: DragHighlight;
        filter?: string;
        group?: string | undefined;
        handle?: string;
        onAdd?: ((e: RowDraggingAddEvent) => void);
        onDragChange?: ((e: RowDraggingChangeEvent) => void);
        onDragEnd?: ((e: RowDraggingEndEvent) => void);
        onDragMove?: ((e: RowDraggingMoveEvent) => void);
        onDragStart?: ((e: RowDraggingStartEvent) => void);
        onRemove?: ((e: RowDraggingRemoveEvent) => void);
        onReorder?: ((e: RowDraggingReorderEvent) => void);
        scrollSensitivity?: number;
        scrollSpeed?: number;
        showDragIcons?: boolean;
    });
    /**
     * [descr:dxDataGridOptions.rowTemplate]
    
     * @deprecated [depNote:dxDataGridOptions.rowTemplate]
    
     */
    get rowTemplate(): any;
    set rowTemplate(value: any);
    /**
     * [descr:DOMComponentOptions.rtlEnabled]
    
     */
    get rtlEnabled(): boolean;
    set rtlEnabled(value: boolean);
    /**
     * [descr:dxDataGridOptions.scrolling]
    
     */
    get scrolling(): {
        columnRenderingMode?: DataRenderMode;
        mode?: DataGridScrollMode;
        preloadEnabled?: boolean;
        renderAsync?: boolean | undefined;
        rowRenderingMode?: DataRenderMode;
        scrollByContent?: boolean;
        scrollByThumb?: boolean;
        showScrollbar?: ScrollbarMode;
        useNative?: boolean | Mode;
    };
    set scrolling(value: {
        columnRenderingMode?: DataRenderMode;
        mode?: DataGridScrollMode;
        preloadEnabled?: boolean;
        renderAsync?: boolean | undefined;
        rowRenderingMode?: DataRenderMode;
        scrollByContent?: boolean;
        scrollByThumb?: boolean;
        showScrollbar?: ScrollbarMode;
        useNative?: boolean | Mode;
    });
    /**
     * [descr:GridBaseOptions.searchPanel]
    
     */
    get searchPanel(): SearchPanel;
    set searchPanel(value: SearchPanel);
    /**
     * [descr:GridBaseOptions.selectedRowKeys]
    
     */
    get selectedRowKeys(): Array<any>;
    set selectedRowKeys(value: Array<any>);
    /**
     * [descr:dxDataGridOptions.selection]
    
     */
    get selection(): {
        allowSelectAll?: boolean;
        deferred?: boolean;
        mode?: SingleMultipleOrNone;
        selectAllMode?: SelectAllMode;
        sensitivity?: SelectionSensitivity;
        showCheckBoxesMode?: SelectionColumnDisplayMode;
    };
    set selection(value: {
        allowSelectAll?: boolean;
        deferred?: boolean;
        mode?: SingleMultipleOrNone;
        selectAllMode?: SelectAllMode;
        sensitivity?: SelectionSensitivity;
        showCheckBoxesMode?: SelectionColumnDisplayMode;
    });
    /**
     * [descr:dxDataGridOptions.selectionFilter]
    
     */
    get selectionFilter(): Array<any> | Function | string;
    set selectionFilter(value: Array<any> | Function | string);
    /**
     * [descr:GridBaseOptions.showBorders]
    
     */
    get showBorders(): boolean;
    set showBorders(value: boolean);
    /**
     * [descr:GridBaseOptions.showColumnHeaders]
    
     */
    get showColumnHeaders(): boolean;
    set showColumnHeaders(value: boolean);
    /**
     * [descr:GridBaseOptions.showColumnLines]
    
     */
    get showColumnLines(): boolean;
    set showColumnLines(value: boolean);
    /**
     * [descr:GridBaseOptions.showRowLines]
    
     */
    get showRowLines(): boolean;
    set showRowLines(value: boolean);
    /**
     * [descr:dxDataGridOptions.sortByGroupSummaryInfo]
    
     */
    get sortByGroupSummaryInfo(): {
        groupColumn?: string | undefined;
        sortOrder?: SortOrder | undefined;
        summaryItem?: number | string | undefined;
    }[];
    set sortByGroupSummaryInfo(value: {
        groupColumn?: string | undefined;
        sortOrder?: SortOrder | undefined;
        summaryItem?: number | string | undefined;
    }[]);
    /**
     * [descr:GridBaseOptions.sorting]
    
     */
    get sorting(): Sorting;
    set sorting(value: Sorting);
    /**
     * [descr:GridBaseOptions.stateStoring]
    
     */
    get stateStoring(): {
        customLoad?: Function;
        customSave?: ((gridState: any) => void);
        enabled?: boolean;
        savingTimeout?: number;
        storageKey?: string | undefined;
        type?: StateStoreType;
    };
    set stateStoring(value: {
        customLoad?: Function;
        customSave?: ((gridState: any) => void);
        enabled?: boolean;
        savingTimeout?: number;
        storageKey?: string | undefined;
        type?: StateStoreType;
    });
    /**
     * [descr:dxDataGridOptions.summary]
    
     */
    get summary(): {
        calculateCustomSummary?: ((options: {
            component: dxDataGrid;
            groupIndex: number;
            name: string;
            summaryProcess: string;
            totalValue: any;
            value: any;
        }) => void);
        groupItems?: {
            alignByColumn?: boolean;
            column?: string | undefined;
            customizeText?: ((itemInfo: {
                value: string | number | Date;
                valueText: string;
            }) => string);
            displayFormat?: string | undefined;
            name?: string | undefined;
            showInColumn?: string | undefined;
            showInGroupFooter?: boolean;
            skipEmptyValues?: boolean;
            summaryType?: string | SummaryType | undefined;
            valueFormat?: Format | undefined;
        }[];
        recalculateWhileEditing?: boolean;
        skipEmptyValues?: boolean;
        texts?: {
            avg?: string;
            avgOtherColumn?: string;
            count?: string;
            max?: string;
            maxOtherColumn?: string;
            min?: string;
            minOtherColumn?: string;
            sum?: string;
            sumOtherColumn?: string;
        };
        totalItems?: {
            alignment?: HorizontalAlignment | undefined;
            column?: string | undefined;
            cssClass?: string | undefined;
            customizeText?: ((itemInfo: {
                value: string | number | Date;
                valueText: string;
            }) => string);
            displayFormat?: string | undefined;
            name?: string | undefined;
            showInColumn?: string | undefined;
            skipEmptyValues?: boolean;
            summaryType?: string | SummaryType | undefined;
            valueFormat?: Format | undefined;
        }[];
    };
    set summary(value: {
        calculateCustomSummary?: ((options: {
            component: dxDataGrid;
            groupIndex: number;
            name: string;
            summaryProcess: string;
            totalValue: any;
            value: any;
        }) => void);
        groupItems?: {
            alignByColumn?: boolean;
            column?: string | undefined;
            customizeText?: ((itemInfo: {
                value: string | number | Date;
                valueText: string;
            }) => string);
            displayFormat?: string | undefined;
            name?: string | undefined;
            showInColumn?: string | undefined;
            showInGroupFooter?: boolean;
            skipEmptyValues?: boolean;
            summaryType?: string | SummaryType | undefined;
            valueFormat?: Format | undefined;
        }[];
        recalculateWhileEditing?: boolean;
        skipEmptyValues?: boolean;
        texts?: {
            avg?: string;
            avgOtherColumn?: string;
            count?: string;
            max?: string;
            maxOtherColumn?: string;
            min?: string;
            minOtherColumn?: string;
            sum?: string;
            sumOtherColumn?: string;
        };
        totalItems?: {
            alignment?: HorizontalAlignment | undefined;
            column?: string | undefined;
            cssClass?: string | undefined;
            customizeText?: ((itemInfo: {
                value: string | number | Date;
                valueText: string;
            }) => string);
            displayFormat?: string | undefined;
            name?: string | undefined;
            showInColumn?: string | undefined;
            skipEmptyValues?: boolean;
            summaryType?: string | SummaryType | undefined;
            valueFormat?: Format | undefined;
        }[];
    });
    /**
     * [descr:GridBaseOptions.syncLookupFilterValues]
    
     */
    get syncLookupFilterValues(): boolean;
    set syncLookupFilterValues(value: boolean);
    /**
     * [descr:WidgetOptions.tabIndex]
    
     */
    get tabIndex(): number;
    set tabIndex(value: number);
    /**
     * [descr:dxDataGridOptions.toolbar]
    
     */
    get toolbar(): dxDataGridToolbar | undefined;
    set toolbar(value: dxDataGridToolbar | undefined);
    /**
     * [descr:GridBaseOptions.twoWayBindingEnabled]
    
     */
    get twoWayBindingEnabled(): boolean;
    set twoWayBindingEnabled(value: boolean);
    /**
     * [descr:WidgetOptions.visible]
    
     */
    get visible(): boolean;
    set visible(value: boolean);
    /**
     * [descr:DOMComponentOptions.width]
    
     */
    get width(): number | string | undefined;
    set width(value: number | string | undefined);
    /**
     * [descr:GridBaseOptions.wordWrapEnabled]
    
     */
    get wordWrapEnabled(): boolean;
    set wordWrapEnabled(value: boolean);
    /**
    
     * [descr:dxDataGridOptions.onAdaptiveDetailRowPreparing]
    
    
     */
    onAdaptiveDetailRowPreparing: EventEmitter<AdaptiveDetailRowPreparingEvent>;
    /**
    
     * [descr:dxDataGridOptions.onAIAssistantRequestCreating]
    
    
     */
    onAIAssistantRequestCreating: EventEmitter<AIAssistantRequestCreatingEvent>;
    /**
    
     * [descr:dxDataGridOptions.onAIColumnRequestCreating]
    
    
     */
    onAIColumnRequestCreating: EventEmitter<AIColumnRequestCreatingEvent>;
    /**
    
     * [descr:dxDataGridOptions.onCellClick]
    
    
     */
    onCellClick: EventEmitter<CellClickEvent>;
    /**
    
     * [descr:dxDataGridOptions.onCellDblClick]
    
    
     */
    onCellDblClick: EventEmitter<CellDblClickEvent>;
    /**
    
     * [descr:dxDataGridOptions.onCellHoverChanged]
    
    
     */
    onCellHoverChanged: EventEmitter<CellHoverChangedEvent>;
    /**
    
     * [descr:dxDataGridOptions.onCellPrepared]
    
    
     */
    onCellPrepared: EventEmitter<CellPreparedEvent>;
    /**
    
     * [descr:dxDataGridOptions.onContentReady]
    
    
     */
    onContentReady: EventEmitter<ContentReadyEvent>;
    /**
    
     * [descr:dxDataGridOptions.onContextMenuPreparing]
    
    
     */
    onContextMenuPreparing: EventEmitter<ContextMenuPreparingEvent>;
    /**
    
     * [descr:dxDataGridOptions.onDataErrorOccurred]
    
    
     */
    onDataErrorOccurred: EventEmitter<DataErrorOccurredEvent>;
    /**
    
     * [descr:dxDataGridOptions.onDisposing]
    
    
     */
    onDisposing: EventEmitter<DisposingEvent>;
    /**
    
     * [descr:dxDataGridOptions.onEditCanceled]
    
    
     */
    onEditCanceled: EventEmitter<EditCanceledEvent>;
    /**
    
     * [descr:dxDataGridOptions.onEditCanceling]
    
    
     */
    onEditCanceling: EventEmitter<EditCancelingEvent>;
    /**
    
     * [descr:dxDataGridOptions.onEditingStart]
    
    
     */
    onEditingStart: EventEmitter<EditingStartEvent>;
    /**
    
     * [descr:dxDataGridOptions.onEditorPrepared]
    
    
     */
    onEditorPrepared: EventEmitter<EditorPreparedEvent>;
    /**
    
     * [descr:dxDataGridOptions.onEditorPreparing]
    
    
     */
    onEditorPreparing: EventEmitter<EditorPreparingEvent>;
    /**
    
     * [descr:dxDataGridOptions.onExporting]
    
    
     */
    onExporting: EventEmitter<ExportingEvent>;
    /**
    
     * [descr:dxDataGridOptions.onFocusedCellChanged]
    
    
     */
    onFocusedCellChanged: EventEmitter<FocusedCellChangedEvent>;
    /**
    
     * [descr:dxDataGridOptions.onFocusedCellChanging]
    
    
     */
    onFocusedCellChanging: EventEmitter<FocusedCellChangingEvent>;
    /**
    
     * [descr:dxDataGridOptions.onFocusedRowChanged]
    
    
     */
    onFocusedRowChanged: EventEmitter<FocusedRowChangedEvent>;
    /**
    
     * [descr:dxDataGridOptions.onFocusedRowChanging]
    
    
     */
    onFocusedRowChanging: EventEmitter<FocusedRowChangingEvent>;
    /**
    
     * [descr:dxDataGridOptions.onInitialized]
    
    
     */
    onInitialized: EventEmitter<InitializedEvent>;
    /**
    
     * [descr:dxDataGridOptions.onInitNewRow]
    
    
     */
    onInitNewRow: EventEmitter<InitNewRowEvent>;
    /**
    
     * [descr:dxDataGridOptions.onKeyDown]
    
    
     */
    onKeyDown: EventEmitter<KeyDownEvent>;
    /**
    
     * [descr:dxDataGridOptions.onOptionChanged]
    
    
     */
    onOptionChanged: EventEmitter<OptionChangedEvent>;
    /**
    
     * [descr:dxDataGridOptions.onRowClick]
    
    
     */
    onRowClick: EventEmitter<RowClickEvent>;
    /**
    
     * [descr:dxDataGridOptions.onRowCollapsed]
    
    
     */
    onRowCollapsed: EventEmitter<RowCollapsedEvent>;
    /**
    
     * [descr:dxDataGridOptions.onRowCollapsing]
    
    
     */
    onRowCollapsing: EventEmitter<RowCollapsingEvent>;
    /**
    
     * [descr:dxDataGridOptions.onRowDblClick]
    
    
     */
    onRowDblClick: EventEmitter<RowDblClickEvent>;
    /**
    
     * [descr:dxDataGridOptions.onRowExpanded]
    
    
     */
    onRowExpanded: EventEmitter<RowExpandedEvent>;
    /**
    
     * [descr:dxDataGridOptions.onRowExpanding]
    
    
     */
    onRowExpanding: EventEmitter<RowExpandingEvent>;
    /**
    
     * [descr:dxDataGridOptions.onRowInserted]
    
    
     */
    onRowInserted: EventEmitter<RowInsertedEvent>;
    /**
    
     * [descr:dxDataGridOptions.onRowInserting]
    
    
     */
    onRowInserting: EventEmitter<RowInsertingEvent>;
    /**
    
     * [descr:dxDataGridOptions.onRowPrepared]
    
    
     */
    onRowPrepared: EventEmitter<RowPreparedEvent>;
    /**
    
     * [descr:dxDataGridOptions.onRowRemoved]
    
    
     */
    onRowRemoved: EventEmitter<RowRemovedEvent>;
    /**
    
     * [descr:dxDataGridOptions.onRowRemoving]
    
    
     */
    onRowRemoving: EventEmitter<RowRemovingEvent>;
    /**
    
     * [descr:dxDataGridOptions.onRowUpdated]
    
    
     */
    onRowUpdated: EventEmitter<RowUpdatedEvent>;
    /**
    
     * [descr:dxDataGridOptions.onRowUpdating]
    
    
     */
    onRowUpdating: EventEmitter<RowUpdatingEvent>;
    /**
    
     * [descr:dxDataGridOptions.onRowValidating]
    
    
     */
    onRowValidating: EventEmitter<RowValidatingEvent>;
    /**
    
     * [descr:dxDataGridOptions.onSaved]
    
    
     */
    onSaved: EventEmitter<SavedEvent>;
    /**
    
     * [descr:dxDataGridOptions.onSaving]
    
    
     */
    onSaving: EventEmitter<SavingEvent>;
    /**
    
     * [descr:dxDataGridOptions.onSelectionChanged]
    
    
     */
    onSelectionChanged: EventEmitter<SelectionChangedEvent>;
    /**
    
     * [descr:dxDataGridOptions.onToolbarPreparing]
    
    
     */
    onToolbarPreparing: EventEmitter<ToolbarPreparingEvent>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    accessKeyChange: EventEmitter<string | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    activeStateEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    aiAssistantChange: EventEmitter<AIAssistant>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    aiIntegrationChange: EventEmitter<AIIntegration | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    allowColumnReorderingChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    allowColumnResizingChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    autoNavigateToFocusedRowChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    cacheEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    cellHintEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    columnAutoWidthChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    columnChooserChange: EventEmitter<ColumnChooser>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    columnFixingChange: EventEmitter<{
        enabled?: boolean;
        icons?: {
            fix?: string;
            leftPosition?: string;
            rightPosition?: string;
            stickyPosition?: string;
            unfix?: string;
        };
        texts?: {
            fix?: string;
            leftPosition?: string;
            rightPosition?: string;
            stickyPosition?: string;
            unfix?: string;
        };
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    columnHidingEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    columnMinWidthChange: EventEmitter<number | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    columnResizingModeChange: EventEmitter<ColumnResizeMode>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    columnsChange: EventEmitter<Array<dxDataGridColumn | string>>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    columnWidthChange: EventEmitter<Mode | number | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    customizeColumnsChange: EventEmitter<((columns: Array<dxDataGridColumn>) => void)>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    dataRowTemplateChange: EventEmitter<any>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    dataSourceChange: EventEmitter<Array<any> | DataSource | DataSourceOptions | Store | string | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    dateSerializationFormatChange: EventEmitter<string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    disabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    editingChange: EventEmitter<{
        allowAdding?: boolean;
        allowDeleting?: boolean | ((options: {
            component: dxDataGrid;
            row: dxDataGridRowObject;
        }) => boolean);
        allowUpdating?: boolean | ((options: {
            component: dxDataGrid;
            row: dxDataGridRowObject;
        }) => boolean);
        changes?: Array<DataChange>;
        confirmDelete?: boolean;
        editColumnName?: string | undefined;
        editRowKey?: any | undefined;
        form?: dxFormOptions;
        mode?: GridsEditMode;
        newRowPosition?: NewRowPosition;
        popup?: dxPopupOptions<any>;
        refreshMode?: GridsEditRefreshMode;
        selectTextOnEditStart?: boolean;
        startEditAction?: StartEditAction;
        texts?: any | {
            addRow?: string;
            cancelAllChanges?: string;
            cancelRowChanges?: string;
            confirmDeleteMessage?: string;
            confirmDeleteTitle?: string;
            deleteRow?: string;
            editRow?: string;
            saveAllChanges?: string;
            saveRowChanges?: string;
            undeleteRow?: string;
            validationCancelChanges?: string;
        };
        useIcons?: boolean;
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    elementAttrChange: EventEmitter<Record<string, any>>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    errorRowEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    exportChange: EventEmitter<{
        allowExportSelectedData?: boolean;
        enabled?: boolean;
        formats?: Array<DataGridExportFormat | string>;
        texts?: {
            exportAll?: string;
            exportSelectedRows?: string;
            exportTo?: string;
        };
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    filterBuilderChange: EventEmitter<dxFilterBuilderOptions>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    filterBuilderPopupChange: EventEmitter<dxPopupOptions<any>>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    filterPanelChange: EventEmitter<FilterPanel>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    filterRowChange: EventEmitter<{
        applyFilter?: ApplyFilterMode;
        applyFilterText?: string;
        betweenEndText?: string;
        betweenStartText?: string;
        operationDescriptions?: {
            between?: string;
            contains?: string;
            endsWith?: string;
            equal?: string;
            greaterThan?: string;
            greaterThanOrEqual?: string;
            lessThan?: string;
            lessThanOrEqual?: string;
            notContains?: string;
            notEqual?: string;
            startsWith?: string;
        };
        resetOperationText?: string;
        showAllText?: string;
        showOperationChooser?: boolean;
        visible?: boolean;
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    filterSyncEnabledChange: EventEmitter<boolean | Mode>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    filterValueChange: EventEmitter<Array<any> | Function | string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    focusedColumnIndexChange: EventEmitter<number>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    focusedRowEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    focusedRowIndexChange: EventEmitter<number>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    focusedRowKeyChange: EventEmitter<any | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    groupingChange: EventEmitter<{
        allowCollapsing?: boolean;
        autoExpandAll?: boolean;
        contextMenuEnabled?: boolean;
        expandMode?: GroupExpandMode;
        texts?: {
            groupByThisColumn?: string;
            groupContinuedMessage?: string;
            groupContinuesMessage?: string;
            ungroup?: string;
            ungroupAll?: string;
        };
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    groupPanelChange: EventEmitter<{
        allowColumnDragging?: boolean;
        emptyPanelText?: string;
        visible?: boolean | Mode;
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    headerFilterChange: EventEmitter<HeaderFilter>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    heightChange: EventEmitter<number | string | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    highlightChangesChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    hintChange: EventEmitter<string | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    hoverStateEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    keyboardNavigationChange: EventEmitter<{
        editOnKeyPress?: boolean;
        enabled?: boolean;
        enterKeyAction?: EnterKeyAction;
        enterKeyDirection?: EnterKeyDirection;
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    keyExprChange: EventEmitter<Array<string> | string | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    loadPanelChange: EventEmitter<{
        enabled?: boolean | Mode;
        height?: number | string;
        indicatorOptions?: LoadPanelIndicatorProperties;
        indicatorSrc?: string;
        shading?: boolean;
        shadingColor?: string;
        showIndicator?: boolean;
        showPane?: boolean;
        text?: string;
        width?: number | string;
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    masterDetailChange: EventEmitter<{
        autoExpandAll?: boolean;
        enabled?: boolean;
        template?: any;
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    noDataTextChange: EventEmitter<string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    pagerChange: EventEmitter<Pager>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    pagingChange: EventEmitter<{
        enabled?: boolean;
        pageIndex?: number;
        pageSize?: number;
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    remoteOperationsChange: EventEmitter<boolean | Mode | {
        filtering?: boolean;
        grouping?: boolean;
        groupPaging?: boolean;
        paging?: boolean;
        sorting?: boolean;
        summary?: boolean;
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    renderAsyncChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    repaintChangesOnlyChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    rowAlternationEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    rowDraggingChange: EventEmitter<{
        allowDropInsideItem?: boolean;
        allowReordering?: boolean;
        autoScroll?: boolean;
        boundary?: any | string | undefined;
        container?: any | string | undefined;
        cursorOffset?: string | {
            x?: number;
            y?: number;
        };
        data?: any | undefined;
        dragDirection?: DragDirection;
        dragTemplate?: any;
        dropFeedbackMode?: DragHighlight;
        filter?: string;
        group?: string | undefined;
        handle?: string;
        onAdd?: ((e: RowDraggingAddEvent) => void);
        onDragChange?: ((e: RowDraggingChangeEvent) => void);
        onDragEnd?: ((e: RowDraggingEndEvent) => void);
        onDragMove?: ((e: RowDraggingMoveEvent) => void);
        onDragStart?: ((e: RowDraggingStartEvent) => void);
        onRemove?: ((e: RowDraggingRemoveEvent) => void);
        onReorder?: ((e: RowDraggingReorderEvent) => void);
        scrollSensitivity?: number;
        scrollSpeed?: number;
        showDragIcons?: boolean;
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    rowTemplateChange: EventEmitter<any>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    rtlEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    scrollingChange: EventEmitter<{
        columnRenderingMode?: DataRenderMode;
        mode?: DataGridScrollMode;
        preloadEnabled?: boolean;
        renderAsync?: boolean | undefined;
        rowRenderingMode?: DataRenderMode;
        scrollByContent?: boolean;
        scrollByThumb?: boolean;
        showScrollbar?: ScrollbarMode;
        useNative?: boolean | Mode;
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    searchPanelChange: EventEmitter<SearchPanel>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    selectedRowKeysChange: EventEmitter<Array<any>>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    selectionChange: EventEmitter<{
        allowSelectAll?: boolean;
        deferred?: boolean;
        mode?: SingleMultipleOrNone;
        selectAllMode?: SelectAllMode;
        sensitivity?: SelectionSensitivity;
        showCheckBoxesMode?: SelectionColumnDisplayMode;
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    selectionFilterChange: EventEmitter<Array<any> | Function | string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    showBordersChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    showColumnHeadersChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    showColumnLinesChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    showRowLinesChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    sortByGroupSummaryInfoChange: EventEmitter<{
        groupColumn?: string | undefined;
        sortOrder?: SortOrder | undefined;
        summaryItem?: number | string | undefined;
    }[]>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    sortingChange: EventEmitter<Sorting>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    stateStoringChange: EventEmitter<{
        customLoad?: Function;
        customSave?: ((gridState: any) => void);
        enabled?: boolean;
        savingTimeout?: number;
        storageKey?: string | undefined;
        type?: StateStoreType;
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    summaryChange: EventEmitter<{
        calculateCustomSummary?: ((options: {
            component: dxDataGrid;
            groupIndex: number;
            name: string;
            summaryProcess: string;
            totalValue: any;
            value: any;
        }) => void);
        groupItems?: {
            alignByColumn?: boolean;
            column?: string | undefined;
            customizeText?: ((itemInfo: {
                value: string | number | Date;
                valueText: string;
            }) => string);
            displayFormat?: string | undefined;
            name?: string | undefined;
            showInColumn?: string | undefined;
            showInGroupFooter?: boolean;
            skipEmptyValues?: boolean;
            summaryType?: string | SummaryType | undefined;
            valueFormat?: Format | undefined;
        }[];
        recalculateWhileEditing?: boolean;
        skipEmptyValues?: boolean;
        texts?: {
            avg?: string;
            avgOtherColumn?: string;
            count?: string;
            max?: string;
            maxOtherColumn?: string;
            min?: string;
            minOtherColumn?: string;
            sum?: string;
            sumOtherColumn?: string;
        };
        totalItems?: {
            alignment?: HorizontalAlignment | undefined;
            column?: string | undefined;
            cssClass?: string | undefined;
            customizeText?: ((itemInfo: {
                value: string | number | Date;
                valueText: string;
            }) => string);
            displayFormat?: string | undefined;
            name?: string | undefined;
            showInColumn?: string | undefined;
            skipEmptyValues?: boolean;
            summaryType?: string | SummaryType | undefined;
            valueFormat?: Format | undefined;
        }[];
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    syncLookupFilterValuesChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    tabIndexChange: EventEmitter<number>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    toolbarChange: EventEmitter<dxDataGridToolbar | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    twoWayBindingEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    visibleChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    widthChange: EventEmitter<number | string | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    wordWrapEnabledChange: EventEmitter<boolean>;
    constructor(elementRef: ElementRef, ngZone: NgZone, templateHost: DxTemplateHost, _watcherHelper: WatcherHelper, _idh: IterableDifferHelper, optionHost: NestedOptionHost, transferState: TransferState, platformId: any);
    protected _createInstance(element: any, options: any): dxDataGrid<any, any>;
    ngOnDestroy(): void;
    ngOnChanges(changes: SimpleChanges): void;
    setupChanges(prop: string, changes: SimpleChanges): void;
    ngDoCheck(): void;
    _setOption(name: string, value: any): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxDataGridComponent<any, any>, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxDataGridComponent<any, any>, "dx-data-grid", never, { "accessKey": { "alias": "accessKey"; "required": false; }; "activeStateEnabled": { "alias": "activeStateEnabled"; "required": false; }; "aiAssistant": { "alias": "aiAssistant"; "required": false; }; "aiIntegration": { "alias": "aiIntegration"; "required": false; }; "allowColumnReordering": { "alias": "allowColumnReordering"; "required": false; }; "allowColumnResizing": { "alias": "allowColumnResizing"; "required": false; }; "autoNavigateToFocusedRow": { "alias": "autoNavigateToFocusedRow"; "required": false; }; "cacheEnabled": { "alias": "cacheEnabled"; "required": false; }; "cellHintEnabled": { "alias": "cellHintEnabled"; "required": false; }; "columnAutoWidth": { "alias": "columnAutoWidth"; "required": false; }; "columnChooser": { "alias": "columnChooser"; "required": false; }; "columnFixing": { "alias": "columnFixing"; "required": false; }; "columnHidingEnabled": { "alias": "columnHidingEnabled"; "required": false; }; "columnMinWidth": { "alias": "columnMinWidth"; "required": false; }; "columnResizingMode": { "alias": "columnResizingMode"; "required": false; }; "columns": { "alias": "columns"; "required": false; }; "columnWidth": { "alias": "columnWidth"; "required": false; }; "customizeColumns": { "alias": "customizeColumns"; "required": false; }; "dataRowTemplate": { "alias": "dataRowTemplate"; "required": false; }; "dataSource": { "alias": "dataSource"; "required": false; }; "dateSerializationFormat": { "alias": "dateSerializationFormat"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "editing": { "alias": "editing"; "required": false; }; "elementAttr": { "alias": "elementAttr"; "required": false; }; "errorRowEnabled": { "alias": "errorRowEnabled"; "required": false; }; "export": { "alias": "export"; "required": false; }; "filterBuilder": { "alias": "filterBuilder"; "required": false; }; "filterBuilderPopup": { "alias": "filterBuilderPopup"; "required": false; }; "filterPanel": { "alias": "filterPanel"; "required": false; }; "filterRow": { "alias": "filterRow"; "required": false; }; "filterSyncEnabled": { "alias": "filterSyncEnabled"; "required": false; }; "filterValue": { "alias": "filterValue"; "required": false; }; "focusedColumnIndex": { "alias": "focusedColumnIndex"; "required": false; }; "focusedRowEnabled": { "alias": "focusedRowEnabled"; "required": false; }; "focusedRowIndex": { "alias": "focusedRowIndex"; "required": false; }; "focusedRowKey": { "alias": "focusedRowKey"; "required": false; }; "grouping": { "alias": "grouping"; "required": false; }; "groupPanel": { "alias": "groupPanel"; "required": false; }; "headerFilter": { "alias": "headerFilter"; "required": false; }; "height": { "alias": "height"; "required": false; }; "highlightChanges": { "alias": "highlightChanges"; "required": false; }; "hint": { "alias": "hint"; "required": false; }; "hoverStateEnabled": { "alias": "hoverStateEnabled"; "required": false; }; "keyboardNavigation": { "alias": "keyboardNavigation"; "required": false; }; "keyExpr": { "alias": "keyExpr"; "required": false; }; "loadPanel": { "alias": "loadPanel"; "required": false; }; "masterDetail": { "alias": "masterDetail"; "required": false; }; "noDataText": { "alias": "noDataText"; "required": false; }; "pager": { "alias": "pager"; "required": false; }; "paging": { "alias": "paging"; "required": false; }; "remoteOperations": { "alias": "remoteOperations"; "required": false; }; "renderAsync": { "alias": "renderAsync"; "required": false; }; "repaintChangesOnly": { "alias": "repaintChangesOnly"; "required": false; }; "rowAlternationEnabled": { "alias": "rowAlternationEnabled"; "required": false; }; "rowDragging": { "alias": "rowDragging"; "required": false; }; "rowTemplate": { "alias": "rowTemplate"; "required": false; }; "rtlEnabled": { "alias": "rtlEnabled"; "required": false; }; "scrolling": { "alias": "scrolling"; "required": false; }; "searchPanel": { "alias": "searchPanel"; "required": false; }; "selectedRowKeys": { "alias": "selectedRowKeys"; "required": false; }; "selection": { "alias": "selection"; "required": false; }; "selectionFilter": { "alias": "selectionFilter"; "required": false; }; "showBorders": { "alias": "showBorders"; "required": false; }; "showColumnHeaders": { "alias": "showColumnHeaders"; "required": false; }; "showColumnLines": { "alias": "showColumnLines"; "required": false; }; "showRowLines": { "alias": "showRowLines"; "required": false; }; "sortByGroupSummaryInfo": { "alias": "sortByGroupSummaryInfo"; "required": false; }; "sorting": { "alias": "sorting"; "required": false; }; "stateStoring": { "alias": "stateStoring"; "required": false; }; "summary": { "alias": "summary"; "required": false; }; "syncLookupFilterValues": { "alias": "syncLookupFilterValues"; "required": false; }; "tabIndex": { "alias": "tabIndex"; "required": false; }; "toolbar": { "alias": "toolbar"; "required": false; }; "twoWayBindingEnabled": { "alias": "twoWayBindingEnabled"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; "wordWrapEnabled": { "alias": "wordWrapEnabled"; "required": false; }; }, { "onAdaptiveDetailRowPreparing": "onAdaptiveDetailRowPreparing"; "onAIAssistantRequestCreating": "onAIAssistantRequestCreating"; "onAIColumnRequestCreating": "onAIColumnRequestCreating"; "onCellClick": "onCellClick"; "onCellDblClick": "onCellDblClick"; "onCellHoverChanged": "onCellHoverChanged"; "onCellPrepared": "onCellPrepared"; "onContentReady": "onContentReady"; "onContextMenuPreparing": "onContextMenuPreparing"; "onDataErrorOccurred": "onDataErrorOccurred"; "onDisposing": "onDisposing"; "onEditCanceled": "onEditCanceled"; "onEditCanceling": "onEditCanceling"; "onEditingStart": "onEditingStart"; "onEditorPrepared": "onEditorPrepared"; "onEditorPreparing": "onEditorPreparing"; "onExporting": "onExporting"; "onFocusedCellChanged": "onFocusedCellChanged"; "onFocusedCellChanging": "onFocusedCellChanging"; "onFocusedRowChanged": "onFocusedRowChanged"; "onFocusedRowChanging": "onFocusedRowChanging"; "onInitialized": "onInitialized"; "onInitNewRow": "onInitNewRow"; "onKeyDown": "onKeyDown"; "onOptionChanged": "onOptionChanged"; "onRowClick": "onRowClick"; "onRowCollapsed": "onRowCollapsed"; "onRowCollapsing": "onRowCollapsing"; "onRowDblClick": "onRowDblClick"; "onRowExpanded": "onRowExpanded"; "onRowExpanding": "onRowExpanding"; "onRowInserted": "onRowInserted"; "onRowInserting": "onRowInserting"; "onRowPrepared": "onRowPrepared"; "onRowRemoved": "onRowRemoved"; "onRowRemoving": "onRowRemoving"; "onRowUpdated": "onRowUpdated"; "onRowUpdating": "onRowUpdating"; "onRowValidating": "onRowValidating"; "onSaved": "onSaved"; "onSaving": "onSaving"; "onSelectionChanged": "onSelectionChanged"; "onToolbarPreparing": "onToolbarPreparing"; "accessKeyChange": "accessKeyChange"; "activeStateEnabledChange": "activeStateEnabledChange"; "aiAssistantChange": "aiAssistantChange"; "aiIntegrationChange": "aiIntegrationChange"; "allowColumnReorderingChange": "allowColumnReorderingChange"; "allowColumnResizingChange": "allowColumnResizingChange"; "autoNavigateToFocusedRowChange": "autoNavigateToFocusedRowChange"; "cacheEnabledChange": "cacheEnabledChange"; "cellHintEnabledChange": "cellHintEnabledChange"; "columnAutoWidthChange": "columnAutoWidthChange"; "columnChooserChange": "columnChooserChange"; "columnFixingChange": "columnFixingChange"; "columnHidingEnabledChange": "columnHidingEnabledChange"; "columnMinWidthChange": "columnMinWidthChange"; "columnResizingModeChange": "columnResizingModeChange"; "columnsChange": "columnsChange"; "columnWidthChange": "columnWidthChange"; "customizeColumnsChange": "customizeColumnsChange"; "dataRowTemplateChange": "dataRowTemplateChange"; "dataSourceChange": "dataSourceChange"; "dateSerializationFormatChange": "dateSerializationFormatChange"; "disabledChange": "disabledChange"; "editingChange": "editingChange"; "elementAttrChange": "elementAttrChange"; "errorRowEnabledChange": "errorRowEnabledChange"; "exportChange": "exportChange"; "filterBuilderChange": "filterBuilderChange"; "filterBuilderPopupChange": "filterBuilderPopupChange"; "filterPanelChange": "filterPanelChange"; "filterRowChange": "filterRowChange"; "filterSyncEnabledChange": "filterSyncEnabledChange"; "filterValueChange": "filterValueChange"; "focusedColumnIndexChange": "focusedColumnIndexChange"; "focusedRowEnabledChange": "focusedRowEnabledChange"; "focusedRowIndexChange": "focusedRowIndexChange"; "focusedRowKeyChange": "focusedRowKeyChange"; "groupingChange": "groupingChange"; "groupPanelChange": "groupPanelChange"; "headerFilterChange": "headerFilterChange"; "heightChange": "heightChange"; "highlightChangesChange": "highlightChangesChange"; "hintChange": "hintChange"; "hoverStateEnabledChange": "hoverStateEnabledChange"; "keyboardNavigationChange": "keyboardNavigationChange"; "keyExprChange": "keyExprChange"; "loadPanelChange": "loadPanelChange"; "masterDetailChange": "masterDetailChange"; "noDataTextChange": "noDataTextChange"; "pagerChange": "pagerChange"; "pagingChange": "pagingChange"; "remoteOperationsChange": "remoteOperationsChange"; "renderAsyncChange": "renderAsyncChange"; "repaintChangesOnlyChange": "repaintChangesOnlyChange"; "rowAlternationEnabledChange": "rowAlternationEnabledChange"; "rowDraggingChange": "rowDraggingChange"; "rowTemplateChange": "rowTemplateChange"; "rtlEnabledChange": "rtlEnabledChange"; "scrollingChange": "scrollingChange"; "searchPanelChange": "searchPanelChange"; "selectedRowKeysChange": "selectedRowKeysChange"; "selectionChange": "selectionChange"; "selectionFilterChange": "selectionFilterChange"; "showBordersChange": "showBordersChange"; "showColumnHeadersChange": "showColumnHeadersChange"; "showColumnLinesChange": "showColumnLinesChange"; "showRowLinesChange": "showRowLinesChange"; "sortByGroupSummaryInfoChange": "sortByGroupSummaryInfoChange"; "sortingChange": "sortingChange"; "stateStoringChange": "stateStoringChange"; "summaryChange": "summaryChange"; "syncLookupFilterValuesChange": "syncLookupFilterValuesChange"; "tabIndexChange": "tabIndexChange"; "toolbarChange": "toolbarChange"; "twoWayBindingEnabledChange": "twoWayBindingEnabledChange"; "visibleChange": "visibleChange"; "widthChange": "widthChange"; "wordWrapEnabledChange": "wordWrapEnabledChange"; }, ["_validationRulesContentChildren", "_buttonsContentChildren", "_itemsContentChildren", "_changesContentChildren", "_columnsContentChildren", "_customOperationsContentChildren", "_fieldsContentChildren", "_groupItemsContentChildren", "_sortByGroupSummaryInfoContentChildren", "_tabsContentChildren", "_toolbarItemsContentChildren", "_totalItemsContentChildren"], never, true, never>;
}
declare class DxDataGridModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxDataGridModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxDataGridModule, never, [typeof DxDataGridComponent, typeof i1.DxoColumnChooserModule, typeof i1.DxoPositionModule, typeof i1.DxoAtModule, typeof i1.DxoBoundaryOffsetModule, typeof i1.DxoCollisionModule, typeof i1.DxoMyModule, typeof i1.DxoOffsetModule, typeof i1.DxoSearchModule, typeof i1.DxoSelectionModule, typeof i1.DxoColumnFixingModule, typeof i1.DxoIconsModule, typeof i1.DxoTextsModule, typeof i1.DxiColumnModule, typeof i1.DxiButtonModule, typeof i1.DxoLookupModule, typeof i1.DxoFormatModule, typeof i1.DxoFormItemModule, typeof i1.DxoLabelModule, typeof i1.DxiValidationRuleModule, typeof i1.DxoHeaderFilterModule, typeof i1.DxoEditingModule, typeof i1.DxiChangeModule, typeof i1.DxoFormModule, typeof i1.DxoColCountByScreenModule, typeof i1.DxiItemModule, typeof i1.DxoTabPanelOptionsModule, typeof i1.DxiTabModule, typeof i1.DxoButtonOptionsModule, typeof i1.DxoPopupModule, typeof i1.DxoAnimationModule, typeof i1.DxoHideModule, typeof i1.DxoFromModule, typeof i1.DxoToModule, typeof i1.DxoShowModule, typeof i1.DxoExportModule, typeof i1.DxoFilterBuilderModule, typeof i1.DxiCustomOperationModule, typeof i1.DxiFieldModule, typeof i1.DxoFilterOperationDescriptionsModule, typeof i1.DxoGroupOperationDescriptionsModule, typeof i1.DxoFilterBuilderPopupModule, typeof i1.DxoFilterPanelModule, typeof i1.DxoFilterRowModule, typeof i1.DxoOperationDescriptionsModule, typeof i1.DxoGroupingModule, typeof i1.DxoGroupPanelModule, typeof i1.DxoKeyboardNavigationModule, typeof i1.DxoLoadPanelModule, typeof i1.DxoMasterDetailModule, typeof i1.DxoPagerModule, typeof i1.DxoPagingModule, typeof i1.DxoRemoteOperationsModule, typeof i1.DxoRowDraggingModule, typeof i1.DxoCursorOffsetModule, typeof i1.DxoScrollingModule, typeof i1.DxoSearchPanelModule, typeof i1.DxiSortByGroupSummaryInfoModule, typeof i1.DxoSortingModule, typeof i1.DxoStateStoringModule, typeof i1.DxoSummaryModule, typeof i1.DxiGroupItemModule, typeof i1.DxoValueFormatModule, typeof i1.DxiTotalItemModule, typeof i1.DxoToolbarModule, typeof i2.DxoDataGridAIModule, typeof i2.DxoDataGridAIAssistantModule, typeof i2.DxoDataGridAIOptionsModule, typeof i2.DxoDataGridAnimationModule, typeof i2.DxiDataGridAsyncRuleModule, typeof i2.DxoDataGridAtModule, typeof i2.DxoDataGridBoundaryOffsetModule, typeof i2.DxiDataGridButtonModule, typeof i2.DxiDataGridButtonItemModule, typeof i2.DxoDataGridButtonOptionsModule, typeof i2.DxiDataGridChangeModule, typeof i2.DxoDataGridColCountByScreenModule, typeof i2.DxoDataGridCollisionModule, typeof i2.DxiDataGridColumnModule, typeof i2.DxiDataGridColumnButtonModule, typeof i2.DxoDataGridColumnChooserModule, typeof i2.DxoDataGridColumnChooserSearchModule, typeof i2.DxoDataGridColumnChooserSelectionModule, typeof i2.DxoDataGridColumnFixingModule, typeof i2.DxoDataGridColumnFixingTextsModule, typeof i2.DxoDataGridColumnHeaderFilterModule, typeof i2.DxoDataGridColumnHeaderFilterSearchModule, typeof i2.DxoDataGridColumnLookupModule, typeof i2.DxiDataGridCompareRuleModule, typeof i2.DxoDataGridCursorOffsetModule, typeof i2.DxiDataGridCustomOperationModule, typeof i2.DxiDataGridCustomRuleModule, typeof i2.DxoDataGridDataGridHeaderFilterModule, typeof i2.DxoDataGridDataGridHeaderFilterSearchModule, typeof i2.DxoDataGridDataGridHeaderFilterTextsModule, typeof i2.DxoDataGridDataGridSelectionModule, typeof i2.DxiDataGridDataGridToolbarItemModule, typeof i2.DxoDataGridEditingModule, typeof i2.DxoDataGridEditingTextsModule, typeof i2.DxoDataGridEditorOptionsModule, typeof i2.DxiDataGridEditorOptionsButtonModule, typeof i2.DxiDataGridEmailRuleModule, typeof i2.DxiDataGridEmptyItemModule, typeof i2.DxoDataGridExportModule, typeof i2.DxoDataGridExportTextsModule, typeof i2.DxiDataGridFieldModule, typeof i2.DxoDataGridFieldLookupModule, typeof i2.DxoDataGridFilterBuilderModule, typeof i2.DxoDataGridFilterBuilderPopupModule, typeof i2.DxoDataGridFilterOperationDescriptionsModule, typeof i2.DxoDataGridFilterPanelModule, typeof i2.DxoDataGridFilterPanelTextsModule, typeof i2.DxoDataGridFilterRowModule, typeof i2.DxoDataGridFormModule, typeof i2.DxoDataGridFormatModule, typeof i2.DxiDataGridFormGroupItemModule, typeof i2.DxoDataGridFormItemModule, typeof i2.DxoDataGridFromModule, typeof i2.DxoDataGridGroupingModule, typeof i2.DxoDataGridGroupingTextsModule, typeof i2.DxiDataGridGroupItemModule, typeof i2.DxoDataGridGroupOperationDescriptionsModule, typeof i2.DxoDataGridGroupPanelModule, typeof i2.DxoDataGridHeaderFilterModule, typeof i2.DxoDataGridHideModule, typeof i2.DxoDataGridIconsModule, typeof i2.DxoDataGridIndicatorOptionsModule, typeof i2.DxiDataGridItemModule, typeof i2.DxoDataGridKeyboardNavigationModule, typeof i2.DxoDataGridLabelModule, typeof i2.DxoDataGridLoadPanelModule, typeof i2.DxoDataGridLookupModule, typeof i2.DxoDataGridMasterDetailModule, typeof i2.DxoDataGridMyModule, typeof i2.DxiDataGridNumericRuleModule, typeof i2.DxoDataGridOffsetModule, typeof i2.DxoDataGridOperationDescriptionsModule, typeof i2.DxoDataGridOptionsModule, typeof i2.DxoDataGridPagerModule, typeof i2.DxoDataGridPagingModule, typeof i2.DxiDataGridPatternRuleModule, typeof i2.DxoDataGridPopupModule, typeof i2.DxoDataGridPositionModule, typeof i2.DxiDataGridRangeRuleModule, typeof i2.DxoDataGridRemoteOperationsModule, typeof i2.DxiDataGridRequiredRuleModule, typeof i2.DxoDataGridRowDraggingModule, typeof i2.DxoDataGridScrollingModule, typeof i2.DxoDataGridSearchModule, typeof i2.DxoDataGridSearchPanelModule, typeof i2.DxoDataGridSelectionModule, typeof i2.DxoDataGridShowModule, typeof i2.DxiDataGridSimpleItemModule, typeof i2.DxiDataGridSortByGroupSummaryInfoModule, typeof i2.DxoDataGridSortingModule, typeof i2.DxoDataGridStateStoringModule, typeof i2.DxiDataGridStringLengthRuleModule, typeof i2.DxoDataGridSummaryModule, typeof i2.DxoDataGridSummaryTextsModule, typeof i2.DxiDataGridTabModule, typeof i2.DxiDataGridTabbedItemModule, typeof i2.DxoDataGridTabPanelOptionsModule, typeof i2.DxiDataGridTabPanelOptionsItemModule, typeof i2.DxoDataGridTextsModule, typeof i2.DxoDataGridToModule, typeof i2.DxoDataGridToolbarModule, typeof i2.DxiDataGridToolbarItemModule, typeof i2.DxiDataGridTotalItemModule, typeof i2.DxiDataGridValidationRuleModule, typeof i2.DxoDataGridValueFormatModule, typeof i3.DxIntegrationModule, typeof i3.DxTemplateModule], [typeof DxDataGridComponent, typeof i1.DxoColumnChooserModule, typeof i1.DxoPositionModule, typeof i1.DxoAtModule, typeof i1.DxoBoundaryOffsetModule, typeof i1.DxoCollisionModule, typeof i1.DxoMyModule, typeof i1.DxoOffsetModule, typeof i1.DxoSearchModule, typeof i1.DxoSelectionModule, typeof i1.DxoColumnFixingModule, typeof i1.DxoIconsModule, typeof i1.DxoTextsModule, typeof i1.DxiColumnModule, typeof i1.DxiButtonModule, typeof i1.DxoLookupModule, typeof i1.DxoFormatModule, typeof i1.DxoFormItemModule, typeof i1.DxoLabelModule, typeof i1.DxiValidationRuleModule, typeof i1.DxoHeaderFilterModule, typeof i1.DxoEditingModule, typeof i1.DxiChangeModule, typeof i1.DxoFormModule, typeof i1.DxoColCountByScreenModule, typeof i1.DxiItemModule, typeof i1.DxoTabPanelOptionsModule, typeof i1.DxiTabModule, typeof i1.DxoButtonOptionsModule, typeof i1.DxoPopupModule, typeof i1.DxoAnimationModule, typeof i1.DxoHideModule, typeof i1.DxoFromModule, typeof i1.DxoToModule, typeof i1.DxoShowModule, typeof i1.DxoExportModule, typeof i1.DxoFilterBuilderModule, typeof i1.DxiCustomOperationModule, typeof i1.DxiFieldModule, typeof i1.DxoFilterOperationDescriptionsModule, typeof i1.DxoGroupOperationDescriptionsModule, typeof i1.DxoFilterBuilderPopupModule, typeof i1.DxoFilterPanelModule, typeof i1.DxoFilterRowModule, typeof i1.DxoOperationDescriptionsModule, typeof i1.DxoGroupingModule, typeof i1.DxoGroupPanelModule, typeof i1.DxoKeyboardNavigationModule, typeof i1.DxoLoadPanelModule, typeof i1.DxoMasterDetailModule, typeof i1.DxoPagerModule, typeof i1.DxoPagingModule, typeof i1.DxoRemoteOperationsModule, typeof i1.DxoRowDraggingModule, typeof i1.DxoCursorOffsetModule, typeof i1.DxoScrollingModule, typeof i1.DxoSearchPanelModule, typeof i1.DxiSortByGroupSummaryInfoModule, typeof i1.DxoSortingModule, typeof i1.DxoStateStoringModule, typeof i1.DxoSummaryModule, typeof i1.DxiGroupItemModule, typeof i1.DxoValueFormatModule, typeof i1.DxiTotalItemModule, typeof i1.DxoToolbarModule, typeof i2.DxoDataGridAIModule, typeof i2.DxoDataGridAIAssistantModule, typeof i2.DxoDataGridAIOptionsModule, typeof i2.DxoDataGridAnimationModule, typeof i2.DxiDataGridAsyncRuleModule, typeof i2.DxoDataGridAtModule, typeof i2.DxoDataGridBoundaryOffsetModule, typeof i2.DxiDataGridButtonModule, typeof i2.DxiDataGridButtonItemModule, typeof i2.DxoDataGridButtonOptionsModule, typeof i2.DxiDataGridChangeModule, typeof i2.DxoDataGridColCountByScreenModule, typeof i2.DxoDataGridCollisionModule, typeof i2.DxiDataGridColumnModule, typeof i2.DxiDataGridColumnButtonModule, typeof i2.DxoDataGridColumnChooserModule, typeof i2.DxoDataGridColumnChooserSearchModule, typeof i2.DxoDataGridColumnChooserSelectionModule, typeof i2.DxoDataGridColumnFixingModule, typeof i2.DxoDataGridColumnFixingTextsModule, typeof i2.DxoDataGridColumnHeaderFilterModule, typeof i2.DxoDataGridColumnHeaderFilterSearchModule, typeof i2.DxoDataGridColumnLookupModule, typeof i2.DxiDataGridCompareRuleModule, typeof i2.DxoDataGridCursorOffsetModule, typeof i2.DxiDataGridCustomOperationModule, typeof i2.DxiDataGridCustomRuleModule, typeof i2.DxoDataGridDataGridHeaderFilterModule, typeof i2.DxoDataGridDataGridHeaderFilterSearchModule, typeof i2.DxoDataGridDataGridHeaderFilterTextsModule, typeof i2.DxoDataGridDataGridSelectionModule, typeof i2.DxiDataGridDataGridToolbarItemModule, typeof i2.DxoDataGridEditingModule, typeof i2.DxoDataGridEditingTextsModule, typeof i2.DxoDataGridEditorOptionsModule, typeof i2.DxiDataGridEditorOptionsButtonModule, typeof i2.DxiDataGridEmailRuleModule, typeof i2.DxiDataGridEmptyItemModule, typeof i2.DxoDataGridExportModule, typeof i2.DxoDataGridExportTextsModule, typeof i2.DxiDataGridFieldModule, typeof i2.DxoDataGridFieldLookupModule, typeof i2.DxoDataGridFilterBuilderModule, typeof i2.DxoDataGridFilterBuilderPopupModule, typeof i2.DxoDataGridFilterOperationDescriptionsModule, typeof i2.DxoDataGridFilterPanelModule, typeof i2.DxoDataGridFilterPanelTextsModule, typeof i2.DxoDataGridFilterRowModule, typeof i2.DxoDataGridFormModule, typeof i2.DxoDataGridFormatModule, typeof i2.DxiDataGridFormGroupItemModule, typeof i2.DxoDataGridFormItemModule, typeof i2.DxoDataGridFromModule, typeof i2.DxoDataGridGroupingModule, typeof i2.DxoDataGridGroupingTextsModule, typeof i2.DxiDataGridGroupItemModule, typeof i2.DxoDataGridGroupOperationDescriptionsModule, typeof i2.DxoDataGridGroupPanelModule, typeof i2.DxoDataGridHeaderFilterModule, typeof i2.DxoDataGridHideModule, typeof i2.DxoDataGridIconsModule, typeof i2.DxoDataGridIndicatorOptionsModule, typeof i2.DxiDataGridItemModule, typeof i2.DxoDataGridKeyboardNavigationModule, typeof i2.DxoDataGridLabelModule, typeof i2.DxoDataGridLoadPanelModule, typeof i2.DxoDataGridLookupModule, typeof i2.DxoDataGridMasterDetailModule, typeof i2.DxoDataGridMyModule, typeof i2.DxiDataGridNumericRuleModule, typeof i2.DxoDataGridOffsetModule, typeof i2.DxoDataGridOperationDescriptionsModule, typeof i2.DxoDataGridOptionsModule, typeof i2.DxoDataGridPagerModule, typeof i2.DxoDataGridPagingModule, typeof i2.DxiDataGridPatternRuleModule, typeof i2.DxoDataGridPopupModule, typeof i2.DxoDataGridPositionModule, typeof i2.DxiDataGridRangeRuleModule, typeof i2.DxoDataGridRemoteOperationsModule, typeof i2.DxiDataGridRequiredRuleModule, typeof i2.DxoDataGridRowDraggingModule, typeof i2.DxoDataGridScrollingModule, typeof i2.DxoDataGridSearchModule, typeof i2.DxoDataGridSearchPanelModule, typeof i2.DxoDataGridSelectionModule, typeof i2.DxoDataGridShowModule, typeof i2.DxiDataGridSimpleItemModule, typeof i2.DxiDataGridSortByGroupSummaryInfoModule, typeof i2.DxoDataGridSortingModule, typeof i2.DxoDataGridStateStoringModule, typeof i2.DxiDataGridStringLengthRuleModule, typeof i2.DxoDataGridSummaryModule, typeof i2.DxoDataGridSummaryTextsModule, typeof i2.DxiDataGridTabModule, typeof i2.DxiDataGridTabbedItemModule, typeof i2.DxoDataGridTabPanelOptionsModule, typeof i2.DxiDataGridTabPanelOptionsItemModule, typeof i2.DxoDataGridTextsModule, typeof i2.DxoDataGridToModule, typeof i2.DxoDataGridToolbarModule, typeof i2.DxiDataGridToolbarItemModule, typeof i2.DxiDataGridTotalItemModule, typeof i2.DxiDataGridValidationRuleModule, typeof i2.DxoDataGridValueFormatModule, typeof i3.DxTemplateModule]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxDataGridModule>;
}

export { DxDataGridComponent, DxDataGridModule };
//# sourceMappingURL=index.d.ts.map
