import * as i0 from '@angular/core';
import { OnDestroy, OnInit, AfterViewInit, Renderer2, ElementRef, QueryList, EventEmitter } from '@angular/core';
import { AIIntegration } from 'devextreme/common/ai-integration';
import { CommandInfo, ResponseStatusTexts, ResponseStatus, AIColumnMode, DataChangeType, ColumnChooserMode, ColumnChooserSearchConfig, ColumnChooserSelectionConfig, ColumnAIOptions, FilterOperation, FilterType, FixedPosition, ColumnHeaderFilter, SelectedFilterOperation, HeaderFilterGroupInterval, ColumnHeaderFilterSearchConfig, HeaderFilterSearchConfig, HeaderFilterTexts, SelectionColumnDisplayMode, DataChange, GridsEditMode, NewRowPosition, GridsEditRefreshMode, StartEditAction, FilterPanel, FilterPanelTexts, ApplyFilterMode, SummaryType, GroupExpandMode, EnterKeyAction, EnterKeyDirection, PagerPageSize, DataRenderMode, StateStoreType } from 'devextreme/common/grids';
import dxPopup, { dxPopupOptions, dxPopupToolbarItem, ToolbarLocation } from 'devextreme/ui/popup';
import { NestedOption, NestedOptionHost, CollectionNestedOption, IDxTemplateHost, DxTemplateHost, DxTemplateDirective } from 'devextreme-angular/core';
import { dxTextBoxOptions, TextBoxType, ChangeEvent, ContentReadyEvent as ContentReadyEvent$1, CopyEvent, CutEvent, DisposingEvent as DisposingEvent$1, EnterKeyEvent, FocusInEvent, FocusOutEvent, InitializedEvent as InitializedEvent$1, InputEvent, KeyDownEvent, KeyUpEvent, OptionChangedEvent as OptionChangedEvent$1, PasteEvent, ValueChangedEvent } from 'devextreme/ui/text_box';
import { AnimationConfig, CollisionResolution, PositionConfig, AnimationState, AnimationType, CollisionResolutionCombination } from 'devextreme/common/core/animation';
import * as CommonTypes from 'devextreme/common';
import { ValidationRuleType, HorizontalAlignment, VerticalAlignment, TextEditorButtonLocation, ButtonStyle, ButtonType, SortOrder, DataType, SearchMode, ComparisonOperator, SingleMultipleOrNone, SelectAllMode, ToolbarItemLocation, ToolbarItemComponent, TextBoxPredefinedButton, TextEditorButton, LabelMode, MaskMode, EditorStyle, ValidationMessageMode, Position, ValidationStatus, PositionAlignment, Mode, Format as Format$1, Direction, DisplayMode, DragDirection, DragHighlight, ScrollbarMode, TabsIconPosition, TabsStyle } from 'devextreme/common';
import dxDataGrid, { dxDataGridColumn, dxDataGridRowObject, DataGridPredefinedColumnButton, ColumnButtonClickEvent, dxDataGridColumnButton, DataGridCommandColumnType, SelectionSensitivity, DataGridPredefinedToolbarItem, DataGridExportFormat, RowDraggingAddEvent, RowDraggingChangeEvent, RowDraggingEndEvent, RowDraggingMoveEvent, RowDraggingStartEvent, RowDraggingRemoveEvent, RowDraggingReorderEvent, DataGridScrollMode, dxDataGridToolbarItem } from 'devextreme/ui/data_grid';
import { dxButtonOptions, ClickEvent, ContentReadyEvent, DisposingEvent, InitializedEvent, OptionChangedEvent } from 'devextreme/ui/button';
import { FormItemType, FormPredefinedButtonItem, dxFormSimpleItem, dxFormOptions, dxFormButtonItem, dxFormEmptyItem, dxFormGroupItem, dxFormTabbedItem, FormItemComponent, LabelLocation, FormLabelMode, ContentReadyEvent as ContentReadyEvent$3, DisposingEvent as DisposingEvent$3, EditorEnterKeyEvent, FieldDataChangedEvent, InitializedEvent as InitializedEvent$3, OptionChangedEvent as OptionChangedEvent$3, SmartPastedEvent, SmartPastingEvent } from 'devextreme/ui/form';
import { Format } from 'devextreme/common/core/localization';
import DataSource, { DataSourceOptions } from 'devextreme/data/data_source';
import { Store } from 'devextreme/data/store';
import { dxFilterBuilderField, FieldInfo, FilterBuilderOperation, dxFilterBuilderCustomOperation, GroupOperation, ContentReadyEvent as ContentReadyEvent$2, DisposingEvent as DisposingEvent$2, EditorPreparedEvent, EditorPreparingEvent, InitializedEvent as InitializedEvent$2, OptionChangedEvent as OptionChangedEvent$2, ValueChangedEvent as ValueChangedEvent$1 } from 'devextreme/ui/filter_builder';
import { LocateInMenuMode, ShowTextMode } from 'devextreme/ui/toolbar';
import dxOverlay from 'devextreme/ui/overlay';
import DOMComponent from 'devextreme/core/dom_component';
import { event } from 'devextreme/events/events.types';
import { EventInfo } from 'devextreme/common/core/events';
import { Component } from 'devextreme/core/component';
import { LoadingAnimationType } from 'devextreme/ui/load_indicator';
import { dxTabPanelOptions, dxTabPanelItem, ContentReadyEvent as ContentReadyEvent$4, DisposingEvent as DisposingEvent$4, InitializedEvent as InitializedEvent$4, ItemClickEvent, ItemContextMenuEvent, ItemHoldEvent, ItemRenderedEvent, OptionChangedEvent as OptionChangedEvent$4, SelectionChangedEvent, SelectionChangingEvent, TitleClickEvent, TitleHoldEvent, TitleRenderedEvent } from 'devextreme/ui/tab_panel';
import { LoadPanelIndicatorProperties } from 'devextreme/ui/load_panel';

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoDataGridAIAssistantComponent extends NestedOption implements OnDestroy, OnInit {
    get aiIntegration(): AIIntegration;
    set aiIntegration(value: AIIntegration);
    get chat(): Record<string, any>;
    set chat(value: Record<string, any>);
    get customizeResponseText(): ((command: CommandInfo) => ResponseStatusTexts);
    set customizeResponseText(value: ((command: CommandInfo) => ResponseStatusTexts));
    get customizeResponseTitle(): ((status: ResponseStatus, commandNames: Array<string>) => string);
    set customizeResponseTitle(value: ((status: ResponseStatus, commandNames: Array<string>) => string));
    get enabled(): boolean;
    set enabled(value: boolean);
    get popup(): dxPopupOptions<any>;
    set popup(value: dxPopupOptions<any>);
    get title(): string;
    set title(value: string);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDataGridAIAssistantComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoDataGridAIAssistantComponent, "dxo-data-grid-ai-assistant", never, { "aiIntegration": { "alias": "aiIntegration"; "required": false; }; "chat": { "alias": "chat"; "required": false; }; "customizeResponseText": { "alias": "customizeResponseText"; "required": false; }; "customizeResponseTitle": { "alias": "customizeResponseTitle"; "required": false; }; "enabled": { "alias": "enabled"; "required": false; }; "popup": { "alias": "popup"; "required": false; }; "title": { "alias": "title"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoDataGridAIAssistantModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDataGridAIAssistantModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoDataGridAIAssistantModule, never, [typeof DxoDataGridAIAssistantComponent], [typeof DxoDataGridAIAssistantComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoDataGridAIAssistantModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoDataGridAIOptionsComponent extends NestedOption implements OnDestroy, OnInit {
    get disabled(): boolean;
    set disabled(value: boolean);
    get instruction(): string | undefined;
    set instruction(value: string | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDataGridAIOptionsComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoDataGridAIOptionsComponent, "dxo-data-grid-ai-options", never, { "disabled": { "alias": "disabled"; "required": false; }; "instruction": { "alias": "instruction"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoDataGridAIOptionsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDataGridAIOptionsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoDataGridAIOptionsModule, never, [typeof DxoDataGridAIOptionsComponent], [typeof DxoDataGridAIOptionsComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoDataGridAIOptionsModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoDataGridAIComponent extends NestedOption implements OnDestroy, OnInit {
    get aiIntegration(): AIIntegration | undefined;
    set aiIntegration(value: AIIntegration | undefined);
    get editorOptions(): dxTextBoxOptions<any>;
    set editorOptions(value: dxTextBoxOptions<any>);
    get emptyText(): string;
    set emptyText(value: string);
    get mode(): AIColumnMode;
    set mode(value: AIColumnMode);
    get noDataText(): string;
    set noDataText(value: string);
    get popup(): Record<string, any>;
    set popup(value: Record<string, any>);
    get prompt(): string;
    set prompt(value: string);
    get showHeaderMenu(): boolean;
    set showHeaderMenu(value: boolean);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDataGridAIComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoDataGridAIComponent, "dxo-data-grid-ai", never, { "aiIntegration": { "alias": "aiIntegration"; "required": false; }; "editorOptions": { "alias": "editorOptions"; "required": false; }; "emptyText": { "alias": "emptyText"; "required": false; }; "mode": { "alias": "mode"; "required": false; }; "noDataText": { "alias": "noDataText"; "required": false; }; "popup": { "alias": "popup"; "required": false; }; "prompt": { "alias": "prompt"; "required": false; }; "showHeaderMenu": { "alias": "showHeaderMenu"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoDataGridAIModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDataGridAIModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoDataGridAIModule, never, [typeof DxoDataGridAIComponent], [typeof DxoDataGridAIComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoDataGridAIModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoDataGridAnimationComponent extends NestedOption implements OnDestroy, OnInit {
    get hide(): AnimationConfig;
    set hide(value: AnimationConfig);
    get show(): AnimationConfig;
    set show(value: AnimationConfig);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDataGridAnimationComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoDataGridAnimationComponent, "dxo-data-grid-animation", never, { "hide": { "alias": "hide"; "required": false; }; "show": { "alias": "show"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoDataGridAnimationModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDataGridAnimationModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoDataGridAnimationModule, never, [typeof DxoDataGridAnimationComponent], [typeof DxoDataGridAnimationComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoDataGridAnimationModule>;
}

declare class DxiDataGridAsyncRuleComponent extends CollectionNestedOption {
    get ignoreEmptyValue(): boolean;
    set ignoreEmptyValue(value: boolean);
    get message(): string;
    set message(value: string);
    get reevaluate(): boolean;
    set reevaluate(value: boolean);
    get type(): ValidationRuleType;
    set type(value: ValidationRuleType);
    get validationCallback(): ((options: {
        column: Record<string, any>;
        data: Record<string, any>;
        formItem: Record<string, any>;
        rule: Record<string, any>;
        validator: Record<string, any>;
        value: any;
    }) => any);
    set validationCallback(value: ((options: {
        column: Record<string, any>;
        data: Record<string, any>;
        formItem: Record<string, any>;
        rule: Record<string, any>;
        validator: Record<string, any>;
        value: any;
    }) => any));
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiDataGridAsyncRuleComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiDataGridAsyncRuleComponent, "dxi-data-grid-async-rule", never, { "ignoreEmptyValue": { "alias": "ignoreEmptyValue"; "required": false; }; "message": { "alias": "message"; "required": false; }; "reevaluate": { "alias": "reevaluate"; "required": false; }; "type": { "alias": "type"; "required": false; }; "validationCallback": { "alias": "validationCallback"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxiDataGridAsyncRuleModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiDataGridAsyncRuleModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiDataGridAsyncRuleModule, never, [typeof DxiDataGridAsyncRuleComponent], [typeof DxiDataGridAsyncRuleComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiDataGridAsyncRuleModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoDataGridAtComponent extends NestedOption implements OnDestroy, OnInit {
    get x(): HorizontalAlignment;
    set x(value: HorizontalAlignment);
    get y(): VerticalAlignment;
    set y(value: VerticalAlignment);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDataGridAtComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoDataGridAtComponent, "dxo-data-grid-at", never, { "x": { "alias": "x"; "required": false; }; "y": { "alias": "y"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoDataGridAtModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDataGridAtModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoDataGridAtModule, never, [typeof DxoDataGridAtComponent], [typeof DxoDataGridAtComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoDataGridAtModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoDataGridBoundaryOffsetComponent extends NestedOption implements OnDestroy, OnInit {
    get x(): number;
    set x(value: number);
    get y(): number;
    set y(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDataGridBoundaryOffsetComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoDataGridBoundaryOffsetComponent, "dxo-data-grid-boundary-offset", never, { "x": { "alias": "x"; "required": false; }; "y": { "alias": "y"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoDataGridBoundaryOffsetModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDataGridBoundaryOffsetModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoDataGridBoundaryOffsetModule, never, [typeof DxoDataGridBoundaryOffsetComponent], [typeof DxoDataGridBoundaryOffsetComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoDataGridBoundaryOffsetModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxiDataGridButtonComponent extends CollectionNestedOption implements AfterViewInit, IDxTemplateHost {
    private renderer;
    private document;
    private element;
    get cssClass(): string;
    set cssClass(value: string);
    get disabled(): boolean | ((options: {
        column: dxDataGridColumn;
        component: dxDataGrid;
        row: dxDataGridRowObject;
    }) => boolean);
    set disabled(value: boolean | ((options: {
        column: dxDataGridColumn;
        component: dxDataGrid;
        row: dxDataGridRowObject;
    }) => boolean));
    get hint(): string;
    set hint(value: string);
    get icon(): string;
    set icon(value: string);
    get name(): DataGridPredefinedColumnButton | string | undefined;
    set name(value: DataGridPredefinedColumnButton | string | undefined);
    get onClick(): ((e: ColumnButtonClickEvent) => void);
    set onClick(value: ((e: ColumnButtonClickEvent) => void));
    get template(): any;
    set template(value: any);
    get text(): string;
    set text(value: string);
    get visible(): boolean | ((options: {
        column: dxDataGridColumn;
        component: dxDataGrid;
        row: dxDataGridRowObject;
    }) => boolean);
    set visible(value: boolean | ((options: {
        column: dxDataGridColumn;
        component: dxDataGrid;
        row: dxDataGridRowObject;
    }) => boolean));
    get location(): TextEditorButtonLocation;
    set location(value: TextEditorButtonLocation);
    get options(): dxButtonOptions | undefined;
    set options(value: dxButtonOptions | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost, renderer: Renderer2, document: any, templateHost: DxTemplateHost, element: ElementRef);
    setTemplate(template: DxTemplateDirective): void;
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiDataGridButtonComponent, [{ host: true; skipSelf: true; }, { host: true; }, null, null, { host: true; }, null]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiDataGridButtonComponent, "dxi-data-grid-button", never, { "cssClass": { "alias": "cssClass"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "hint": { "alias": "hint"; "required": false; }; "icon": { "alias": "icon"; "required": false; }; "name": { "alias": "name"; "required": false; }; "onClick": { "alias": "onClick"; "required": false; }; "template": { "alias": "template"; "required": false; }; "text": { "alias": "text"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "location": { "alias": "location"; "required": false; }; "options": { "alias": "options"; "required": false; }; }, {}, never, ["*"], true, never>;
}
declare class DxiDataGridButtonModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiDataGridButtonModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiDataGridButtonModule, never, [typeof DxiDataGridButtonComponent], [typeof DxiDataGridButtonComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiDataGridButtonModule>;
}

declare class DxiDataGridButtonItemComponent extends CollectionNestedOption {
    get buttonOptions(): dxButtonOptions | undefined;
    set buttonOptions(value: dxButtonOptions | undefined);
    get colSpan(): number | undefined;
    set colSpan(value: number | undefined);
    get cssClass(): string | undefined;
    set cssClass(value: string | undefined);
    get horizontalAlignment(): HorizontalAlignment;
    set horizontalAlignment(value: HorizontalAlignment);
    get itemType(): FormItemType;
    set itemType(value: FormItemType);
    get name(): FormPredefinedButtonItem | string | undefined;
    set name(value: FormPredefinedButtonItem | string | undefined);
    get verticalAlignment(): VerticalAlignment;
    set verticalAlignment(value: VerticalAlignment);
    get visible(): boolean;
    set visible(value: boolean);
    get visibleIndex(): number | undefined;
    set visibleIndex(value: number | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiDataGridButtonItemComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiDataGridButtonItemComponent, "dxi-data-grid-button-item", never, { "buttonOptions": { "alias": "buttonOptions"; "required": false; }; "colSpan": { "alias": "colSpan"; "required": false; }; "cssClass": { "alias": "cssClass"; "required": false; }; "horizontalAlignment": { "alias": "horizontalAlignment"; "required": false; }; "itemType": { "alias": "itemType"; "required": false; }; "name": { "alias": "name"; "required": false; }; "verticalAlignment": { "alias": "verticalAlignment"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "visibleIndex": { "alias": "visibleIndex"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxiDataGridButtonItemModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiDataGridButtonItemModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiDataGridButtonItemModule, never, [typeof DxiDataGridButtonItemComponent], [typeof DxiDataGridButtonItemComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiDataGridButtonItemModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoDataGridButtonOptionsComponent extends NestedOption implements AfterViewInit, OnDestroy, OnInit, IDxTemplateHost {
    private renderer;
    private document;
    private element;
    get accessKey(): string | undefined;
    set accessKey(value: string | undefined);
    get activeStateEnabled(): boolean;
    set activeStateEnabled(value: boolean);
    get disabled(): boolean;
    set disabled(value: boolean);
    get elementAttr(): Record<string, any>;
    set elementAttr(value: Record<string, any>);
    get focusStateEnabled(): boolean;
    set focusStateEnabled(value: boolean);
    get height(): number | string | undefined;
    set height(value: number | string | undefined);
    get hint(): string | undefined;
    set hint(value: string | undefined);
    get hoverStateEnabled(): boolean;
    set hoverStateEnabled(value: boolean);
    get icon(): string;
    set icon(value: string);
    get onClick(): ((e: ClickEvent) => void) | undefined;
    set onClick(value: ((e: ClickEvent) => void) | undefined);
    get onContentReady(): ((e: ContentReadyEvent) => void);
    set onContentReady(value: ((e: ContentReadyEvent) => void));
    get onDisposing(): ((e: DisposingEvent) => void);
    set onDisposing(value: ((e: DisposingEvent) => void));
    get onInitialized(): ((e: InitializedEvent) => void);
    set onInitialized(value: ((e: InitializedEvent) => void));
    get onOptionChanged(): ((e: OptionChangedEvent) => void);
    set onOptionChanged(value: ((e: OptionChangedEvent) => void));
    get rtlEnabled(): boolean;
    set rtlEnabled(value: boolean);
    get stylingMode(): ButtonStyle;
    set stylingMode(value: ButtonStyle);
    get tabIndex(): number;
    set tabIndex(value: number);
    get template(): any;
    set template(value: any);
    get text(): string;
    set text(value: string);
    get type(): ButtonType | string;
    set type(value: ButtonType | string);
    get useSubmitBehavior(): boolean;
    set useSubmitBehavior(value: boolean);
    get validationGroup(): string | undefined;
    set validationGroup(value: string | undefined);
    get visible(): boolean;
    set visible(value: boolean);
    get width(): number | string | undefined;
    set width(value: number | string | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost, renderer: Renderer2, document: any, templateHost: DxTemplateHost, element: ElementRef);
    setTemplate(template: DxTemplateDirective): void;
    ngAfterViewInit(): void;
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDataGridButtonOptionsComponent, [{ host: true; skipSelf: true; }, { host: true; }, null, null, { host: true; }, null]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoDataGridButtonOptionsComponent, "dxo-data-grid-button-options", never, { "accessKey": { "alias": "accessKey"; "required": false; }; "activeStateEnabled": { "alias": "activeStateEnabled"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "elementAttr": { "alias": "elementAttr"; "required": false; }; "focusStateEnabled": { "alias": "focusStateEnabled"; "required": false; }; "height": { "alias": "height"; "required": false; }; "hint": { "alias": "hint"; "required": false; }; "hoverStateEnabled": { "alias": "hoverStateEnabled"; "required": false; }; "icon": { "alias": "icon"; "required": false; }; "onClick": { "alias": "onClick"; "required": false; }; "onContentReady": { "alias": "onContentReady"; "required": false; }; "onDisposing": { "alias": "onDisposing"; "required": false; }; "onInitialized": { "alias": "onInitialized"; "required": false; }; "onOptionChanged": { "alias": "onOptionChanged"; "required": false; }; "rtlEnabled": { "alias": "rtlEnabled"; "required": false; }; "stylingMode": { "alias": "stylingMode"; "required": false; }; "tabIndex": { "alias": "tabIndex"; "required": false; }; "template": { "alias": "template"; "required": false; }; "text": { "alias": "text"; "required": false; }; "type": { "alias": "type"; "required": false; }; "useSubmitBehavior": { "alias": "useSubmitBehavior"; "required": false; }; "validationGroup": { "alias": "validationGroup"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, ["*"], true, never>;
}
declare class DxoDataGridButtonOptionsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDataGridButtonOptionsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoDataGridButtonOptionsModule, never, [typeof DxoDataGridButtonOptionsComponent], [typeof DxoDataGridButtonOptionsComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoDataGridButtonOptionsModule>;
}

declare class DxiDataGridChangeComponent extends CollectionNestedOption {
    get data(): any;
    set data(value: any);
    get insertAfterKey(): any;
    set insertAfterKey(value: any);
    get insertBeforeKey(): any;
    set insertBeforeKey(value: any);
    get key(): any;
    set key(value: any);
    get type(): DataChangeType;
    set type(value: DataChangeType);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiDataGridChangeComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiDataGridChangeComponent, "dxi-data-grid-change", never, { "data": { "alias": "data"; "required": false; }; "insertAfterKey": { "alias": "insertAfterKey"; "required": false; }; "insertBeforeKey": { "alias": "insertBeforeKey"; "required": false; }; "key": { "alias": "key"; "required": false; }; "type": { "alias": "type"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxiDataGridChangeModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiDataGridChangeModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiDataGridChangeModule, never, [typeof DxiDataGridChangeComponent], [typeof DxiDataGridChangeComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiDataGridChangeModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoDataGridColCountByScreenComponent extends NestedOption implements OnDestroy, OnInit {
    get lg(): number | undefined;
    set lg(value: number | undefined);
    get md(): number | undefined;
    set md(value: number | undefined);
    get sm(): number | undefined;
    set sm(value: number | undefined);
    get xs(): number | undefined;
    set xs(value: number | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDataGridColCountByScreenComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoDataGridColCountByScreenComponent, "dxo-data-grid-col-count-by-screen", never, { "lg": { "alias": "lg"; "required": false; }; "md": { "alias": "md"; "required": false; }; "sm": { "alias": "sm"; "required": false; }; "xs": { "alias": "xs"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoDataGridColCountByScreenModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDataGridColCountByScreenModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoDataGridColCountByScreenModule, never, [typeof DxoDataGridColCountByScreenComponent], [typeof DxoDataGridColCountByScreenComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoDataGridColCountByScreenModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoDataGridCollisionComponent extends NestedOption implements OnDestroy, OnInit {
    get x(): CollisionResolution;
    set x(value: CollisionResolution);
    get y(): CollisionResolution;
    set y(value: CollisionResolution);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDataGridCollisionComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoDataGridCollisionComponent, "dxo-data-grid-collision", never, { "x": { "alias": "x"; "required": false; }; "y": { "alias": "y"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoDataGridCollisionModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDataGridCollisionModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoDataGridCollisionModule, never, [typeof DxoDataGridCollisionComponent], [typeof DxoDataGridCollisionComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoDataGridCollisionModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxiDataGridColumnButtonComponent extends CollectionNestedOption implements AfterViewInit, IDxTemplateHost {
    private renderer;
    private document;
    private element;
    get cssClass(): string;
    set cssClass(value: string);
    get disabled(): boolean | ((options: {
        column: dxDataGridColumn;
        component: dxDataGrid;
        row: dxDataGridRowObject;
    }) => boolean);
    set disabled(value: boolean | ((options: {
        column: dxDataGridColumn;
        component: dxDataGrid;
        row: dxDataGridRowObject;
    }) => boolean));
    get hint(): string;
    set hint(value: string);
    get icon(): string;
    set icon(value: string);
    get name(): DataGridPredefinedColumnButton | string;
    set name(value: DataGridPredefinedColumnButton | string);
    get onClick(): ((e: ColumnButtonClickEvent) => void);
    set onClick(value: ((e: ColumnButtonClickEvent) => void));
    get template(): any;
    set template(value: any);
    get text(): string;
    set text(value: string);
    get visible(): boolean | ((options: {
        column: dxDataGridColumn;
        component: dxDataGrid;
        row: dxDataGridRowObject;
    }) => boolean);
    set visible(value: boolean | ((options: {
        column: dxDataGridColumn;
        component: dxDataGrid;
        row: dxDataGridRowObject;
    }) => boolean));
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost, renderer: Renderer2, document: any, templateHost: DxTemplateHost, element: ElementRef);
    setTemplate(template: DxTemplateDirective): void;
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiDataGridColumnButtonComponent, [{ host: true; skipSelf: true; }, { host: true; }, null, null, { host: true; }, null]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiDataGridColumnButtonComponent, "dxi-data-grid-column-button", never, { "cssClass": { "alias": "cssClass"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "hint": { "alias": "hint"; "required": false; }; "icon": { "alias": "icon"; "required": false; }; "name": { "alias": "name"; "required": false; }; "onClick": { "alias": "onClick"; "required": false; }; "template": { "alias": "template"; "required": false; }; "text": { "alias": "text"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; }, {}, never, ["*"], true, never>;
}
declare class DxiDataGridColumnButtonModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiDataGridColumnButtonModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiDataGridColumnButtonModule, never, [typeof DxiDataGridColumnButtonComponent], [typeof DxiDataGridColumnButtonComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiDataGridColumnButtonModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoDataGridColumnChooserSearchComponent extends NestedOption implements OnDestroy, OnInit {
    get editorOptions(): any;
    set editorOptions(value: any);
    get enabled(): boolean;
    set enabled(value: boolean);
    get timeout(): number;
    set timeout(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDataGridColumnChooserSearchComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoDataGridColumnChooserSearchComponent, "dxo-data-grid-column-chooser-search", never, { "editorOptions": { "alias": "editorOptions"; "required": false; }; "enabled": { "alias": "enabled"; "required": false; }; "timeout": { "alias": "timeout"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoDataGridColumnChooserSearchModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDataGridColumnChooserSearchModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoDataGridColumnChooserSearchModule, never, [typeof DxoDataGridColumnChooserSearchComponent], [typeof DxoDataGridColumnChooserSearchComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoDataGridColumnChooserSearchModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoDataGridColumnChooserSelectionComponent extends NestedOption implements OnDestroy, OnInit {
    get allowSelectAll(): boolean;
    set allowSelectAll(value: boolean);
    get recursive(): boolean;
    set recursive(value: boolean);
    get selectByClick(): boolean;
    set selectByClick(value: boolean);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDataGridColumnChooserSelectionComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoDataGridColumnChooserSelectionComponent, "dxo-data-grid-column-chooser-selection", never, { "allowSelectAll": { "alias": "allowSelectAll"; "required": false; }; "recursive": { "alias": "recursive"; "required": false; }; "selectByClick": { "alias": "selectByClick"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoDataGridColumnChooserSelectionModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDataGridColumnChooserSelectionModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoDataGridColumnChooserSelectionModule, never, [typeof DxoDataGridColumnChooserSelectionComponent], [typeof DxoDataGridColumnChooserSelectionComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoDataGridColumnChooserSelectionModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoDataGridColumnChooserComponent extends NestedOption implements OnDestroy, OnInit {
    get allowSearch(): boolean;
    set allowSearch(value: boolean);
    get container(): any | string | undefined;
    set container(value: any | string | undefined);
    get emptyPanelText(): string;
    set emptyPanelText(value: string);
    get enabled(): boolean;
    set enabled(value: boolean);
    get height(): number | string;
    set height(value: number | string);
    get mode(): ColumnChooserMode;
    set mode(value: ColumnChooserMode);
    get position(): PositionConfig | undefined;
    set position(value: PositionConfig | undefined);
    get search(): ColumnChooserSearchConfig;
    set search(value: ColumnChooserSearchConfig);
    get searchTimeout(): number;
    set searchTimeout(value: number);
    get selection(): ColumnChooserSelectionConfig;
    set selection(value: ColumnChooserSelectionConfig);
    get sortOrder(): SortOrder | undefined;
    set sortOrder(value: SortOrder | undefined);
    get title(): string;
    set title(value: string);
    get width(): number | string;
    set width(value: number | string);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDataGridColumnChooserComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoDataGridColumnChooserComponent, "dxo-data-grid-column-chooser", never, { "allowSearch": { "alias": "allowSearch"; "required": false; }; "container": { "alias": "container"; "required": false; }; "emptyPanelText": { "alias": "emptyPanelText"; "required": false; }; "enabled": { "alias": "enabled"; "required": false; }; "height": { "alias": "height"; "required": false; }; "mode": { "alias": "mode"; "required": false; }; "position": { "alias": "position"; "required": false; }; "search": { "alias": "search"; "required": false; }; "searchTimeout": { "alias": "searchTimeout"; "required": false; }; "selection": { "alias": "selection"; "required": false; }; "sortOrder": { "alias": "sortOrder"; "required": false; }; "title": { "alias": "title"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoDataGridColumnChooserModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDataGridColumnChooserModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoDataGridColumnChooserModule, never, [typeof DxoDataGridColumnChooserComponent], [typeof DxoDataGridColumnChooserComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoDataGridColumnChooserModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxiDataGridColumnComponent extends CollectionNestedOption {
    set _validationRulesContentChildren(value: QueryList<CollectionNestedOption>);
    set _buttonsContentChildren(value: QueryList<CollectionNestedOption>);
    set _columnsContentChildren(value: QueryList<CollectionNestedOption>);
    get ai(): ColumnAIOptions;
    set ai(value: ColumnAIOptions);
    get alignment(): HorizontalAlignment | undefined;
    set alignment(value: HorizontalAlignment | undefined);
    get allowEditing(): boolean;
    set allowEditing(value: boolean);
    get allowExporting(): boolean;
    set allowExporting(value: boolean);
    get allowFiltering(): boolean;
    set allowFiltering(value: boolean);
    get allowFixing(): boolean;
    set allowFixing(value: boolean);
    get allowGrouping(): boolean;
    set allowGrouping(value: boolean);
    get allowHeaderFiltering(): boolean;
    set allowHeaderFiltering(value: boolean);
    get allowHiding(): boolean;
    set allowHiding(value: boolean);
    get allowReordering(): boolean;
    set allowReordering(value: boolean);
    get allowResizing(): boolean;
    set allowResizing(value: boolean);
    get allowSearch(): boolean;
    set allowSearch(value: boolean);
    get allowSorting(): boolean;
    set allowSorting(value: boolean);
    get autoExpandGroup(): boolean;
    set autoExpandGroup(value: boolean);
    get buttons(): Array<DataGridPredefinedColumnButton | dxDataGridColumnButton>;
    set buttons(value: Array<DataGridPredefinedColumnButton | dxDataGridColumnButton>);
    get calculateCellValue(): ((rowData: any) => any);
    set calculateCellValue(value: ((rowData: any) => any));
    get calculateDisplayValue(): ((rowData: any) => any) | string;
    set calculateDisplayValue(value: ((rowData: any) => any) | string);
    get calculateFilterExpression(): ((filterValue: any, selectedFilterOperation: string | null, target: string) => string | Function | Array<any>);
    set calculateFilterExpression(value: ((filterValue: any, selectedFilterOperation: string | null, target: string) => string | Function | Array<any>));
    get calculateGroupValue(): ((rowData: any) => any) | string;
    set calculateGroupValue(value: ((rowData: any) => any) | string);
    get calculateSortValue(): ((rowData: any) => any) | string;
    set calculateSortValue(value: ((rowData: any) => any) | string);
    get caption(): string | undefined;
    set caption(value: string | undefined);
    get cellTemplate(): any;
    set cellTemplate(value: any);
    get columns(): Array<dxDataGridColumn | string>;
    set columns(value: Array<dxDataGridColumn | string>);
    get cssClass(): string | undefined;
    set cssClass(value: string | undefined);
    get customizeText(): ((cellInfo: {
        groupInterval: string | number;
        target: string;
        value: any;
        valueText: string;
    }) => string);
    set customizeText(value: ((cellInfo: {
        groupInterval: string | number;
        target: string;
        value: any;
        valueText: string;
    }) => string));
    get dataField(): string | undefined;
    set dataField(value: string | undefined);
    get dataType(): DataType | undefined;
    set dataType(value: DataType | undefined);
    get editCellTemplate(): any;
    set editCellTemplate(value: any);
    get editorOptions(): any;
    set editorOptions(value: any);
    get encodeHtml(): boolean;
    set encodeHtml(value: boolean);
    get falseText(): string;
    set falseText(value: string);
    get filterOperations(): Array<FilterOperation | string>;
    set filterOperations(value: Array<FilterOperation | string>);
    get filterType(): FilterType;
    set filterType(value: FilterType);
    get filterValue(): any | undefined;
    set filterValue(value: any | undefined);
    get filterValues(): Array<any>;
    set filterValues(value: Array<any>);
    get fixed(): boolean;
    set fixed(value: boolean);
    get fixedPosition(): FixedPosition | undefined;
    set fixedPosition(value: FixedPosition | undefined);
    get format(): Format;
    set format(value: Format);
    get formItem(): dxFormSimpleItem;
    set formItem(value: dxFormSimpleItem);
    get groupCellTemplate(): any;
    set groupCellTemplate(value: any);
    get groupIndex(): number | undefined;
    set groupIndex(value: number | undefined);
    get headerCellTemplate(): any;
    set headerCellTemplate(value: any);
    get headerFilter(): ColumnHeaderFilter | undefined;
    set headerFilter(value: ColumnHeaderFilter | undefined);
    get hidingPriority(): number | undefined;
    set hidingPriority(value: number | undefined);
    get isBand(): boolean | undefined;
    set isBand(value: boolean | undefined);
    get lookup(): {
        allowClearing?: boolean;
        calculateCellValue?: ((rowData: any) => any);
        dataSource?: Array<any> | DataSourceOptions | ((options: {
            data: Record<string, any>;
            key: any;
        }) => Array<any> | Store | DataSourceOptions) | null | Store | undefined;
        displayExpr?: ((data: any) => string) | string | undefined;
        valueExpr?: string | undefined;
    };
    set lookup(value: {
        allowClearing?: boolean;
        calculateCellValue?: ((rowData: any) => any);
        dataSource?: Array<any> | DataSourceOptions | ((options: {
            data: Record<string, any>;
            key: any;
        }) => Array<any> | Store | DataSourceOptions) | null | Store | undefined;
        displayExpr?: ((data: any) => string) | string | undefined;
        valueExpr?: string | undefined;
    });
    get minWidth(): number | undefined;
    set minWidth(value: number | undefined);
    get name(): string | undefined;
    set name(value: string | undefined);
    get ownerBand(): number | undefined;
    set ownerBand(value: number | undefined);
    get renderAsync(): boolean;
    set renderAsync(value: boolean);
    get selectedFilterOperation(): SelectedFilterOperation | undefined;
    set selectedFilterOperation(value: SelectedFilterOperation | undefined);
    get setCellValue(): ((newData: any, value: any, currentRowData: any) => any);
    set setCellValue(value: ((newData: any, value: any, currentRowData: any) => any));
    get showEditorAlways(): boolean;
    set showEditorAlways(value: boolean);
    get showInColumnChooser(): boolean;
    set showInColumnChooser(value: boolean);
    get showWhenGrouped(): boolean;
    set showWhenGrouped(value: boolean);
    get sortIndex(): number | undefined;
    set sortIndex(value: number | undefined);
    get sortingMethod(): ((value1: any, value2: any) => number) | undefined;
    set sortingMethod(value: ((value1: any, value2: any) => number) | undefined);
    get sortOrder(): SortOrder | undefined;
    set sortOrder(value: SortOrder | undefined);
    get trueText(): string;
    set trueText(value: string);
    get type(): DataGridCommandColumnType;
    set type(value: DataGridCommandColumnType);
    get validationRules(): Array<CommonTypes.ValidationRule>;
    set validationRules(value: Array<CommonTypes.ValidationRule>);
    get visible(): boolean;
    set visible(value: boolean);
    get visibleIndex(): number | undefined;
    set visibleIndex(value: number | undefined);
    get width(): number | string | undefined;
    set width(value: number | string | undefined);
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    filterValueChange: EventEmitter<any | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    filterValuesChange: EventEmitter<Array<any>>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    groupIndexChange: EventEmitter<number | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    selectedFilterOperationChange: EventEmitter<SelectedFilterOperation | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    sortIndexChange: EventEmitter<number | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    sortOrderChange: EventEmitter<SortOrder | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    visibleChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    visibleIndexChange: EventEmitter<number | undefined>;
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiDataGridColumnComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiDataGridColumnComponent, "dxi-data-grid-column", never, { "ai": { "alias": "ai"; "required": false; }; "alignment": { "alias": "alignment"; "required": false; }; "allowEditing": { "alias": "allowEditing"; "required": false; }; "allowExporting": { "alias": "allowExporting"; "required": false; }; "allowFiltering": { "alias": "allowFiltering"; "required": false; }; "allowFixing": { "alias": "allowFixing"; "required": false; }; "allowGrouping": { "alias": "allowGrouping"; "required": false; }; "allowHeaderFiltering": { "alias": "allowHeaderFiltering"; "required": false; }; "allowHiding": { "alias": "allowHiding"; "required": false; }; "allowReordering": { "alias": "allowReordering"; "required": false; }; "allowResizing": { "alias": "allowResizing"; "required": false; }; "allowSearch": { "alias": "allowSearch"; "required": false; }; "allowSorting": { "alias": "allowSorting"; "required": false; }; "autoExpandGroup": { "alias": "autoExpandGroup"; "required": false; }; "buttons": { "alias": "buttons"; "required": false; }; "calculateCellValue": { "alias": "calculateCellValue"; "required": false; }; "calculateDisplayValue": { "alias": "calculateDisplayValue"; "required": false; }; "calculateFilterExpression": { "alias": "calculateFilterExpression"; "required": false; }; "calculateGroupValue": { "alias": "calculateGroupValue"; "required": false; }; "calculateSortValue": { "alias": "calculateSortValue"; "required": false; }; "caption": { "alias": "caption"; "required": false; }; "cellTemplate": { "alias": "cellTemplate"; "required": false; }; "columns": { "alias": "columns"; "required": false; }; "cssClass": { "alias": "cssClass"; "required": false; }; "customizeText": { "alias": "customizeText"; "required": false; }; "dataField": { "alias": "dataField"; "required": false; }; "dataType": { "alias": "dataType"; "required": false; }; "editCellTemplate": { "alias": "editCellTemplate"; "required": false; }; "editorOptions": { "alias": "editorOptions"; "required": false; }; "encodeHtml": { "alias": "encodeHtml"; "required": false; }; "falseText": { "alias": "falseText"; "required": false; }; "filterOperations": { "alias": "filterOperations"; "required": false; }; "filterType": { "alias": "filterType"; "required": false; }; "filterValue": { "alias": "filterValue"; "required": false; }; "filterValues": { "alias": "filterValues"; "required": false; }; "fixed": { "alias": "fixed"; "required": false; }; "fixedPosition": { "alias": "fixedPosition"; "required": false; }; "format": { "alias": "format"; "required": false; }; "formItem": { "alias": "formItem"; "required": false; }; "groupCellTemplate": { "alias": "groupCellTemplate"; "required": false; }; "groupIndex": { "alias": "groupIndex"; "required": false; }; "headerCellTemplate": { "alias": "headerCellTemplate"; "required": false; }; "headerFilter": { "alias": "headerFilter"; "required": false; }; "hidingPriority": { "alias": "hidingPriority"; "required": false; }; "isBand": { "alias": "isBand"; "required": false; }; "lookup": { "alias": "lookup"; "required": false; }; "minWidth": { "alias": "minWidth"; "required": false; }; "name": { "alias": "name"; "required": false; }; "ownerBand": { "alias": "ownerBand"; "required": false; }; "renderAsync": { "alias": "renderAsync"; "required": false; }; "selectedFilterOperation": { "alias": "selectedFilterOperation"; "required": false; }; "setCellValue": { "alias": "setCellValue"; "required": false; }; "showEditorAlways": { "alias": "showEditorAlways"; "required": false; }; "showInColumnChooser": { "alias": "showInColumnChooser"; "required": false; }; "showWhenGrouped": { "alias": "showWhenGrouped"; "required": false; }; "sortIndex": { "alias": "sortIndex"; "required": false; }; "sortingMethod": { "alias": "sortingMethod"; "required": false; }; "sortOrder": { "alias": "sortOrder"; "required": false; }; "trueText": { "alias": "trueText"; "required": false; }; "type": { "alias": "type"; "required": false; }; "validationRules": { "alias": "validationRules"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "visibleIndex": { "alias": "visibleIndex"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, { "filterValueChange": "filterValueChange"; "filterValuesChange": "filterValuesChange"; "groupIndexChange": "groupIndexChange"; "selectedFilterOperationChange": "selectedFilterOperationChange"; "sortIndexChange": "sortIndexChange"; "sortOrderChange": "sortOrderChange"; "visibleChange": "visibleChange"; "visibleIndexChange": "visibleIndexChange"; }, ["_validationRulesContentChildren", "_buttonsContentChildren", "_columnsContentChildren"], never, true, never>;
}
declare class DxiDataGridColumnModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiDataGridColumnModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiDataGridColumnModule, never, [typeof DxiDataGridColumnComponent], [typeof DxiDataGridColumnComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiDataGridColumnModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoDataGridColumnFixingTextsComponent extends NestedOption implements OnDestroy, OnInit {
    get fix(): string;
    set fix(value: string);
    get leftPosition(): string;
    set leftPosition(value: string);
    get rightPosition(): string;
    set rightPosition(value: string);
    get stickyPosition(): string;
    set stickyPosition(value: string);
    get unfix(): string;
    set unfix(value: string);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDataGridColumnFixingTextsComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoDataGridColumnFixingTextsComponent, "dxo-data-grid-column-fixing-texts", never, { "fix": { "alias": "fix"; "required": false; }; "leftPosition": { "alias": "leftPosition"; "required": false; }; "rightPosition": { "alias": "rightPosition"; "required": false; }; "stickyPosition": { "alias": "stickyPosition"; "required": false; }; "unfix": { "alias": "unfix"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoDataGridColumnFixingTextsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDataGridColumnFixingTextsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoDataGridColumnFixingTextsModule, never, [typeof DxoDataGridColumnFixingTextsComponent], [typeof DxoDataGridColumnFixingTextsComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoDataGridColumnFixingTextsModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoDataGridColumnFixingComponent extends NestedOption implements OnDestroy, OnInit {
    get enabled(): boolean;
    set enabled(value: boolean);
    get icons(): {
        fix?: string;
        leftPosition?: string;
        rightPosition?: string;
        stickyPosition?: string;
        unfix?: string;
    };
    set icons(value: {
        fix?: string;
        leftPosition?: string;
        rightPosition?: string;
        stickyPosition?: string;
        unfix?: string;
    });
    get texts(): {
        fix?: string;
        leftPosition?: string;
        rightPosition?: string;
        stickyPosition?: string;
        unfix?: string;
    };
    set texts(value: {
        fix?: string;
        leftPosition?: string;
        rightPosition?: string;
        stickyPosition?: string;
        unfix?: string;
    });
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDataGridColumnFixingComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoDataGridColumnFixingComponent, "dxo-data-grid-column-fixing", never, { "enabled": { "alias": "enabled"; "required": false; }; "icons": { "alias": "icons"; "required": false; }; "texts": { "alias": "texts"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoDataGridColumnFixingModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDataGridColumnFixingModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoDataGridColumnFixingModule, never, [typeof DxoDataGridColumnFixingComponent], [typeof DxoDataGridColumnFixingComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoDataGridColumnFixingModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoDataGridColumnHeaderFilterSearchComponent extends NestedOption implements OnDestroy, OnInit {
    get editorOptions(): any;
    set editorOptions(value: any);
    get enabled(): boolean;
    set enabled(value: boolean);
    get mode(): SearchMode;
    set mode(value: SearchMode);
    get searchExpr(): Array<Function | string> | Function | string | undefined;
    set searchExpr(value: Array<Function | string> | Function | string | undefined);
    get timeout(): number;
    set timeout(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDataGridColumnHeaderFilterSearchComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoDataGridColumnHeaderFilterSearchComponent, "dxo-data-grid-column-header-filter-search", never, { "editorOptions": { "alias": "editorOptions"; "required": false; }; "enabled": { "alias": "enabled"; "required": false; }; "mode": { "alias": "mode"; "required": false; }; "searchExpr": { "alias": "searchExpr"; "required": false; }; "timeout": { "alias": "timeout"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoDataGridColumnHeaderFilterSearchModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDataGridColumnHeaderFilterSearchModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoDataGridColumnHeaderFilterSearchModule, never, [typeof DxoDataGridColumnHeaderFilterSearchComponent], [typeof DxoDataGridColumnHeaderFilterSearchComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoDataGridColumnHeaderFilterSearchModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoDataGridColumnHeaderFilterComponent extends NestedOption implements OnDestroy, OnInit {
    get allowSearch(): boolean;
    set allowSearch(value: boolean);
    get allowSelectAll(): boolean;
    set allowSelectAll(value: boolean);
    get dataSource(): Array<any> | DataSourceOptions | ((options: {
        component: Record<string, any>;
        dataSource: DataSourceOptions | null;
    }) => void) | null | Store | undefined;
    set dataSource(value: Array<any> | DataSourceOptions | ((options: {
        component: Record<string, any>;
        dataSource: DataSourceOptions | null;
    }) => void) | null | Store | undefined);
    get groupInterval(): Array<number | string> | HeaderFilterGroupInterval | number | undefined;
    set groupInterval(value: Array<number | string> | HeaderFilterGroupInterval | number | undefined);
    get height(): number | string | undefined;
    set height(value: number | string | undefined);
    get search(): ColumnHeaderFilterSearchConfig;
    set search(value: ColumnHeaderFilterSearchConfig);
    get searchMode(): SearchMode;
    set searchMode(value: SearchMode);
    get width(): number | string | undefined;
    set width(value: number | string | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDataGridColumnHeaderFilterComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoDataGridColumnHeaderFilterComponent, "dxo-data-grid-column-header-filter", never, { "allowSearch": { "alias": "allowSearch"; "required": false; }; "allowSelectAll": { "alias": "allowSelectAll"; "required": false; }; "dataSource": { "alias": "dataSource"; "required": false; }; "groupInterval": { "alias": "groupInterval"; "required": false; }; "height": { "alias": "height"; "required": false; }; "search": { "alias": "search"; "required": false; }; "searchMode": { "alias": "searchMode"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoDataGridColumnHeaderFilterModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDataGridColumnHeaderFilterModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoDataGridColumnHeaderFilterModule, never, [typeof DxoDataGridColumnHeaderFilterComponent], [typeof DxoDataGridColumnHeaderFilterComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoDataGridColumnHeaderFilterModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoDataGridColumnLookupComponent extends NestedOption implements OnDestroy, OnInit {
    get allowClearing(): boolean;
    set allowClearing(value: boolean);
    get calculateCellValue(): ((rowData: any) => any);
    set calculateCellValue(value: ((rowData: any) => any));
    get dataSource(): Array<any> | DataSourceOptions | ((options: {
        data: Record<string, any>;
        key: any;
    }) => Array<any> | Store | DataSourceOptions) | null | Store | undefined;
    set dataSource(value: Array<any> | DataSourceOptions | ((options: {
        data: Record<string, any>;
        key: any;
    }) => Array<any> | Store | DataSourceOptions) | null | Store | undefined);
    get displayExpr(): ((data: any) => string) | string | undefined;
    set displayExpr(value: ((data: any) => string) | string | undefined);
    get valueExpr(): string | undefined;
    set valueExpr(value: string | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDataGridColumnLookupComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoDataGridColumnLookupComponent, "dxo-data-grid-column-lookup", never, { "allowClearing": { "alias": "allowClearing"; "required": false; }; "calculateCellValue": { "alias": "calculateCellValue"; "required": false; }; "dataSource": { "alias": "dataSource"; "required": false; }; "displayExpr": { "alias": "displayExpr"; "required": false; }; "valueExpr": { "alias": "valueExpr"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoDataGridColumnLookupModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDataGridColumnLookupModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoDataGridColumnLookupModule, never, [typeof DxoDataGridColumnLookupComponent], [typeof DxoDataGridColumnLookupComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoDataGridColumnLookupModule>;
}

declare class DxiDataGridCompareRuleComponent extends CollectionNestedOption {
    get comparisonTarget(): Function;
    set comparisonTarget(value: Function);
    get comparisonType(): ComparisonOperator;
    set comparisonType(value: ComparisonOperator);
    get ignoreEmptyValue(): boolean;
    set ignoreEmptyValue(value: boolean);
    get message(): string;
    set message(value: string);
    get type(): ValidationRuleType;
    set type(value: ValidationRuleType);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiDataGridCompareRuleComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiDataGridCompareRuleComponent, "dxi-data-grid-compare-rule", never, { "comparisonTarget": { "alias": "comparisonTarget"; "required": false; }; "comparisonType": { "alias": "comparisonType"; "required": false; }; "ignoreEmptyValue": { "alias": "ignoreEmptyValue"; "required": false; }; "message": { "alias": "message"; "required": false; }; "type": { "alias": "type"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxiDataGridCompareRuleModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiDataGridCompareRuleModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiDataGridCompareRuleModule, never, [typeof DxiDataGridCompareRuleComponent], [typeof DxiDataGridCompareRuleComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiDataGridCompareRuleModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoDataGridCursorOffsetComponent extends NestedOption implements OnDestroy, OnInit {
    get x(): number;
    set x(value: number);
    get y(): number;
    set y(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDataGridCursorOffsetComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoDataGridCursorOffsetComponent, "dxo-data-grid-cursor-offset", never, { "x": { "alias": "x"; "required": false; }; "y": { "alias": "y"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoDataGridCursorOffsetModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDataGridCursorOffsetModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoDataGridCursorOffsetModule, never, [typeof DxoDataGridCursorOffsetComponent], [typeof DxoDataGridCursorOffsetComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoDataGridCursorOffsetModule>;
}

declare class DxiDataGridCustomOperationComponent extends CollectionNestedOption {
    get calculateFilterExpression(): ((filterValue: any, field: dxFilterBuilderField) => string | Function | Array<any>);
    set calculateFilterExpression(value: ((filterValue: any, field: dxFilterBuilderField) => string | Function | Array<any>));
    get caption(): string | undefined;
    set caption(value: string | undefined);
    get customizeText(): ((fieldInfo: FieldInfo) => string);
    set customizeText(value: ((fieldInfo: FieldInfo) => string));
    get dataTypes(): Array<DataType> | undefined;
    set dataTypes(value: Array<DataType> | undefined);
    get editorTemplate(): any;
    set editorTemplate(value: any);
    get hasValue(): boolean;
    set hasValue(value: boolean);
    get icon(): string | undefined;
    set icon(value: string | undefined);
    get name(): string | undefined;
    set name(value: string | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiDataGridCustomOperationComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiDataGridCustomOperationComponent, "dxi-data-grid-custom-operation", never, { "calculateFilterExpression": { "alias": "calculateFilterExpression"; "required": false; }; "caption": { "alias": "caption"; "required": false; }; "customizeText": { "alias": "customizeText"; "required": false; }; "dataTypes": { "alias": "dataTypes"; "required": false; }; "editorTemplate": { "alias": "editorTemplate"; "required": false; }; "hasValue": { "alias": "hasValue"; "required": false; }; "icon": { "alias": "icon"; "required": false; }; "name": { "alias": "name"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxiDataGridCustomOperationModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiDataGridCustomOperationModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiDataGridCustomOperationModule, never, [typeof DxiDataGridCustomOperationComponent], [typeof DxiDataGridCustomOperationComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiDataGridCustomOperationModule>;
}

declare class DxiDataGridCustomRuleComponent extends CollectionNestedOption {
    get ignoreEmptyValue(): boolean;
    set ignoreEmptyValue(value: boolean);
    get message(): string;
    set message(value: string);
    get reevaluate(): boolean;
    set reevaluate(value: boolean);
    get type(): ValidationRuleType;
    set type(value: ValidationRuleType);
    get validationCallback(): ((options: {
        column: Record<string, any>;
        data: Record<string, any>;
        formItem: Record<string, any>;
        rule: Record<string, any>;
        validator: Record<string, any>;
        value: any;
    }) => boolean);
    set validationCallback(value: ((options: {
        column: Record<string, any>;
        data: Record<string, any>;
        formItem: Record<string, any>;
        rule: Record<string, any>;
        validator: Record<string, any>;
        value: any;
    }) => boolean));
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiDataGridCustomRuleComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiDataGridCustomRuleComponent, "dxi-data-grid-custom-rule", never, { "ignoreEmptyValue": { "alias": "ignoreEmptyValue"; "required": false; }; "message": { "alias": "message"; "required": false; }; "reevaluate": { "alias": "reevaluate"; "required": false; }; "type": { "alias": "type"; "required": false; }; "validationCallback": { "alias": "validationCallback"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxiDataGridCustomRuleModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiDataGridCustomRuleModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiDataGridCustomRuleModule, never, [typeof DxiDataGridCustomRuleComponent], [typeof DxiDataGridCustomRuleComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiDataGridCustomRuleModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoDataGridDataGridHeaderFilterSearchComponent extends NestedOption implements OnDestroy, OnInit {
    get editorOptions(): any;
    set editorOptions(value: any);
    get enabled(): boolean;
    set enabled(value: boolean);
    get mode(): SearchMode;
    set mode(value: SearchMode);
    get timeout(): number;
    set timeout(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDataGridDataGridHeaderFilterSearchComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoDataGridDataGridHeaderFilterSearchComponent, "dxo-data-grid-data-grid-header-filter-search", never, { "editorOptions": { "alias": "editorOptions"; "required": false; }; "enabled": { "alias": "enabled"; "required": false; }; "mode": { "alias": "mode"; "required": false; }; "timeout": { "alias": "timeout"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoDataGridDataGridHeaderFilterSearchModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDataGridDataGridHeaderFilterSearchModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoDataGridDataGridHeaderFilterSearchModule, never, [typeof DxoDataGridDataGridHeaderFilterSearchComponent], [typeof DxoDataGridDataGridHeaderFilterSearchComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoDataGridDataGridHeaderFilterSearchModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoDataGridDataGridHeaderFilterTextsComponent extends NestedOption implements OnDestroy, OnInit {
    get cancel(): string;
    set cancel(value: string);
    get emptyValue(): string;
    set emptyValue(value: string);
    get ok(): string;
    set ok(value: string);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDataGridDataGridHeaderFilterTextsComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoDataGridDataGridHeaderFilterTextsComponent, "dxo-data-grid-data-grid-header-filter-texts", never, { "cancel": { "alias": "cancel"; "required": false; }; "emptyValue": { "alias": "emptyValue"; "required": false; }; "ok": { "alias": "ok"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoDataGridDataGridHeaderFilterTextsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDataGridDataGridHeaderFilterTextsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoDataGridDataGridHeaderFilterTextsModule, never, [typeof DxoDataGridDataGridHeaderFilterTextsComponent], [typeof DxoDataGridDataGridHeaderFilterTextsComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoDataGridDataGridHeaderFilterTextsModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoDataGridDataGridHeaderFilterComponent extends NestedOption implements OnDestroy, OnInit {
    get allowSearch(): boolean;
    set allowSearch(value: boolean);
    get allowSelectAll(): boolean;
    set allowSelectAll(value: boolean);
    get height(): number | string;
    set height(value: number | string);
    get search(): HeaderFilterSearchConfig;
    set search(value: HeaderFilterSearchConfig);
    get searchTimeout(): number;
    set searchTimeout(value: number);
    get texts(): HeaderFilterTexts;
    set texts(value: HeaderFilterTexts);
    get visible(): boolean;
    set visible(value: boolean);
    get width(): number | string;
    set width(value: number | string);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDataGridDataGridHeaderFilterComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoDataGridDataGridHeaderFilterComponent, "dxo-data-grid-data-grid-header-filter", never, { "allowSearch": { "alias": "allowSearch"; "required": false; }; "allowSelectAll": { "alias": "allowSelectAll"; "required": false; }; "height": { "alias": "height"; "required": false; }; "search": { "alias": "search"; "required": false; }; "searchTimeout": { "alias": "searchTimeout"; "required": false; }; "texts": { "alias": "texts"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoDataGridDataGridHeaderFilterModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDataGridDataGridHeaderFilterModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoDataGridDataGridHeaderFilterModule, never, [typeof DxoDataGridDataGridHeaderFilterComponent], [typeof DxoDataGridDataGridHeaderFilterComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoDataGridDataGridHeaderFilterModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoDataGridDataGridSelectionComponent extends NestedOption implements OnDestroy, OnInit {
    get allowSelectAll(): boolean;
    set allowSelectAll(value: boolean);
    get deferred(): boolean;
    set deferred(value: boolean);
    get mode(): SingleMultipleOrNone;
    set mode(value: SingleMultipleOrNone);
    get selectAllMode(): SelectAllMode;
    set selectAllMode(value: SelectAllMode);
    get sensitivity(): SelectionSensitivity;
    set sensitivity(value: SelectionSensitivity);
    get showCheckBoxesMode(): SelectionColumnDisplayMode;
    set showCheckBoxesMode(value: SelectionColumnDisplayMode);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDataGridDataGridSelectionComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoDataGridDataGridSelectionComponent, "dxo-data-grid-data-grid-selection", never, { "allowSelectAll": { "alias": "allowSelectAll"; "required": false; }; "deferred": { "alias": "deferred"; "required": false; }; "mode": { "alias": "mode"; "required": false; }; "selectAllMode": { "alias": "selectAllMode"; "required": false; }; "sensitivity": { "alias": "sensitivity"; "required": false; }; "showCheckBoxesMode": { "alias": "showCheckBoxesMode"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoDataGridDataGridSelectionModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDataGridDataGridSelectionModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoDataGridDataGridSelectionModule, never, [typeof DxoDataGridDataGridSelectionComponent], [typeof DxoDataGridDataGridSelectionComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoDataGridDataGridSelectionModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxiDataGridDataGridToolbarItemComponent extends CollectionNestedOption implements AfterViewInit, IDxTemplateHost {
    private renderer;
    private document;
    private element;
    get cssClass(): string | undefined;
    set cssClass(value: string | undefined);
    get disabled(): boolean;
    set disabled(value: boolean);
    get html(): string;
    set html(value: string);
    get locateInMenu(): LocateInMenuMode;
    set locateInMenu(value: LocateInMenuMode);
    get location(): ToolbarItemLocation;
    set location(value: ToolbarItemLocation);
    get menuItemTemplate(): any;
    set menuItemTemplate(value: any);
    get name(): DataGridPredefinedToolbarItem | string;
    set name(value: DataGridPredefinedToolbarItem | string);
    get options(): any;
    set options(value: any);
    get showText(): ShowTextMode;
    set showText(value: ShowTextMode);
    get template(): any;
    set template(value: any);
    get text(): string;
    set text(value: string);
    get visible(): boolean;
    set visible(value: boolean);
    get widget(): ToolbarItemComponent;
    set widget(value: ToolbarItemComponent);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost, renderer: Renderer2, document: any, templateHost: DxTemplateHost, element: ElementRef);
    setTemplate(template: DxTemplateDirective): void;
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiDataGridDataGridToolbarItemComponent, [{ host: true; skipSelf: true; }, { host: true; }, null, null, { host: true; }, null]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiDataGridDataGridToolbarItemComponent, "dxi-data-grid-data-grid-toolbar-item", never, { "cssClass": { "alias": "cssClass"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "html": { "alias": "html"; "required": false; }; "locateInMenu": { "alias": "locateInMenu"; "required": false; }; "location": { "alias": "location"; "required": false; }; "menuItemTemplate": { "alias": "menuItemTemplate"; "required": false; }; "name": { "alias": "name"; "required": false; }; "options": { "alias": "options"; "required": false; }; "showText": { "alias": "showText"; "required": false; }; "template": { "alias": "template"; "required": false; }; "text": { "alias": "text"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "widget": { "alias": "widget"; "required": false; }; }, {}, never, ["*"], true, never>;
}
declare class DxiDataGridDataGridToolbarItemModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiDataGridDataGridToolbarItemModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiDataGridDataGridToolbarItemModule, never, [typeof DxiDataGridDataGridToolbarItemComponent], [typeof DxiDataGridDataGridToolbarItemComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiDataGridDataGridToolbarItemModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoDataGridEditingTextsComponent extends NestedOption implements OnDestroy, OnInit {
    get addRow(): string;
    set addRow(value: string);
    get cancelAllChanges(): string;
    set cancelAllChanges(value: string);
    get cancelRowChanges(): string;
    set cancelRowChanges(value: string);
    get confirmDeleteMessage(): string;
    set confirmDeleteMessage(value: string);
    get confirmDeleteTitle(): string;
    set confirmDeleteTitle(value: string);
    get deleteRow(): string;
    set deleteRow(value: string);
    get editRow(): string;
    set editRow(value: string);
    get saveAllChanges(): string;
    set saveAllChanges(value: string);
    get saveRowChanges(): string;
    set saveRowChanges(value: string);
    get undeleteRow(): string;
    set undeleteRow(value: string);
    get validationCancelChanges(): string;
    set validationCancelChanges(value: string);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDataGridEditingTextsComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoDataGridEditingTextsComponent, "dxo-data-grid-editing-texts", never, { "addRow": { "alias": "addRow"; "required": false; }; "cancelAllChanges": { "alias": "cancelAllChanges"; "required": false; }; "cancelRowChanges": { "alias": "cancelRowChanges"; "required": false; }; "confirmDeleteMessage": { "alias": "confirmDeleteMessage"; "required": false; }; "confirmDeleteTitle": { "alias": "confirmDeleteTitle"; "required": false; }; "deleteRow": { "alias": "deleteRow"; "required": false; }; "editRow": { "alias": "editRow"; "required": false; }; "saveAllChanges": { "alias": "saveAllChanges"; "required": false; }; "saveRowChanges": { "alias": "saveRowChanges"; "required": false; }; "undeleteRow": { "alias": "undeleteRow"; "required": false; }; "validationCancelChanges": { "alias": "validationCancelChanges"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoDataGridEditingTextsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDataGridEditingTextsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoDataGridEditingTextsModule, never, [typeof DxoDataGridEditingTextsComponent], [typeof DxoDataGridEditingTextsComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoDataGridEditingTextsModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoDataGridEditingComponent extends NestedOption implements OnDestroy, OnInit {
    set _changesContentChildren(value: QueryList<CollectionNestedOption>);
    get allowAdding(): boolean;
    set allowAdding(value: boolean);
    get allowDeleting(): boolean | ((options: {
        component: dxDataGrid;
        row: dxDataGridRowObject;
    }) => boolean);
    set allowDeleting(value: boolean | ((options: {
        component: dxDataGrid;
        row: dxDataGridRowObject;
    }) => boolean));
    get allowUpdating(): boolean | ((options: {
        component: dxDataGrid;
        row: dxDataGridRowObject;
    }) => boolean);
    set allowUpdating(value: boolean | ((options: {
        component: dxDataGrid;
        row: dxDataGridRowObject;
    }) => boolean));
    get changes(): Array<DataChange>;
    set changes(value: Array<DataChange>);
    get confirmDelete(): boolean;
    set confirmDelete(value: boolean);
    get editColumnName(): string | undefined;
    set editColumnName(value: string | undefined);
    get editRowKey(): any | undefined;
    set editRowKey(value: any | undefined);
    get form(): dxFormOptions;
    set form(value: dxFormOptions);
    get mode(): GridsEditMode;
    set mode(value: GridsEditMode);
    get newRowPosition(): NewRowPosition;
    set newRowPosition(value: NewRowPosition);
    get popup(): dxPopupOptions<any>;
    set popup(value: dxPopupOptions<any>);
    get refreshMode(): GridsEditRefreshMode;
    set refreshMode(value: GridsEditRefreshMode);
    get selectTextOnEditStart(): boolean;
    set selectTextOnEditStart(value: boolean);
    get startEditAction(): StartEditAction;
    set startEditAction(value: StartEditAction);
    get texts(): any | {
        addRow?: string;
        cancelAllChanges?: string;
        cancelRowChanges?: string;
        confirmDeleteMessage?: string;
        confirmDeleteTitle?: string;
        deleteRow?: string;
        editRow?: string;
        saveAllChanges?: string;
        saveRowChanges?: string;
        undeleteRow?: string;
        validationCancelChanges?: string;
    };
    set texts(value: any | {
        addRow?: string;
        cancelAllChanges?: string;
        cancelRowChanges?: string;
        confirmDeleteMessage?: string;
        confirmDeleteTitle?: string;
        deleteRow?: string;
        editRow?: string;
        saveAllChanges?: string;
        saveRowChanges?: string;
        undeleteRow?: string;
        validationCancelChanges?: string;
    });
    get useIcons(): boolean;
    set useIcons(value: boolean);
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    changesChange: EventEmitter<Array<DataChange>>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    editColumnNameChange: EventEmitter<string | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    editRowKeyChange: EventEmitter<any | undefined>;
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDataGridEditingComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoDataGridEditingComponent, "dxo-data-grid-editing", never, { "allowAdding": { "alias": "allowAdding"; "required": false; }; "allowDeleting": { "alias": "allowDeleting"; "required": false; }; "allowUpdating": { "alias": "allowUpdating"; "required": false; }; "changes": { "alias": "changes"; "required": false; }; "confirmDelete": { "alias": "confirmDelete"; "required": false; }; "editColumnName": { "alias": "editColumnName"; "required": false; }; "editRowKey": { "alias": "editRowKey"; "required": false; }; "form": { "alias": "form"; "required": false; }; "mode": { "alias": "mode"; "required": false; }; "newRowPosition": { "alias": "newRowPosition"; "required": false; }; "popup": { "alias": "popup"; "required": false; }; "refreshMode": { "alias": "refreshMode"; "required": false; }; "selectTextOnEditStart": { "alias": "selectTextOnEditStart"; "required": false; }; "startEditAction": { "alias": "startEditAction"; "required": false; }; "texts": { "alias": "texts"; "required": false; }; "useIcons": { "alias": "useIcons"; "required": false; }; }, { "changesChange": "changesChange"; "editColumnNameChange": "editColumnNameChange"; "editRowKeyChange": "editRowKeyChange"; }, ["_changesContentChildren"], never, true, never>;
}
declare class DxoDataGridEditingModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDataGridEditingModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoDataGridEditingModule, never, [typeof DxoDataGridEditingComponent], [typeof DxoDataGridEditingComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoDataGridEditingModule>;
}

declare class DxiDataGridEditorOptionsButtonComponent extends CollectionNestedOption {
    get location(): TextEditorButtonLocation;
    set location(value: TextEditorButtonLocation);
    get name(): string | undefined;
    set name(value: string | undefined);
    get options(): dxButtonOptions | undefined;
    set options(value: dxButtonOptions | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiDataGridEditorOptionsButtonComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiDataGridEditorOptionsButtonComponent, "dxi-data-grid-editor-options-button", never, { "location": { "alias": "location"; "required": false; }; "name": { "alias": "name"; "required": false; }; "options": { "alias": "options"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxiDataGridEditorOptionsButtonModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiDataGridEditorOptionsButtonModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiDataGridEditorOptionsButtonModule, never, [typeof DxiDataGridEditorOptionsButtonComponent], [typeof DxiDataGridEditorOptionsButtonComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiDataGridEditorOptionsButtonModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoDataGridEditorOptionsComponent extends NestedOption implements OnDestroy, OnInit {
    set _buttonsContentChildren(value: QueryList<CollectionNestedOption>);
    get accessKey(): string | undefined;
    set accessKey(value: string | undefined);
    get activeStateEnabled(): boolean;
    set activeStateEnabled(value: boolean);
    get buttons(): Array<string | TextBoxPredefinedButton | TextEditorButton> | undefined;
    set buttons(value: Array<string | TextBoxPredefinedButton | TextEditorButton> | undefined);
    get disabled(): boolean;
    set disabled(value: boolean);
    get elementAttr(): Record<string, any>;
    set elementAttr(value: Record<string, any>);
    get focusStateEnabled(): boolean;
    set focusStateEnabled(value: boolean);
    get height(): number | string | undefined;
    set height(value: number | string | undefined);
    get hint(): string | undefined;
    set hint(value: string | undefined);
    get hoverStateEnabled(): boolean;
    set hoverStateEnabled(value: boolean);
    get inputAttr(): any;
    set inputAttr(value: any);
    get isDirty(): boolean;
    set isDirty(value: boolean);
    get isValid(): boolean;
    set isValid(value: boolean);
    get label(): string;
    set label(value: string);
    get labelMode(): LabelMode;
    set labelMode(value: LabelMode);
    get mask(): string;
    set mask(value: string);
    get maskChar(): string;
    set maskChar(value: string);
    get maskInvalidMessage(): string;
    set maskInvalidMessage(value: string);
    get maskRules(): any;
    set maskRules(value: any);
    get maxLength(): null | number | string;
    set maxLength(value: null | number | string);
    get mode(): TextBoxType;
    set mode(value: TextBoxType);
    get name(): string;
    set name(value: string);
    get onChange(): ((e: ChangeEvent) => void);
    set onChange(value: ((e: ChangeEvent) => void));
    get onContentReady(): ((e: ContentReadyEvent$1) => void);
    set onContentReady(value: ((e: ContentReadyEvent$1) => void));
    get onCopy(): ((e: CopyEvent) => void);
    set onCopy(value: ((e: CopyEvent) => void));
    get onCut(): ((e: CutEvent) => void);
    set onCut(value: ((e: CutEvent) => void));
    get onDisposing(): ((e: DisposingEvent$1) => void);
    set onDisposing(value: ((e: DisposingEvent$1) => void));
    get onEnterKey(): ((e: EnterKeyEvent) => void);
    set onEnterKey(value: ((e: EnterKeyEvent) => void));
    get onFocusIn(): ((e: FocusInEvent) => void);
    set onFocusIn(value: ((e: FocusInEvent) => void));
    get onFocusOut(): ((e: FocusOutEvent) => void);
    set onFocusOut(value: ((e: FocusOutEvent) => void));
    get onInitialized(): ((e: InitializedEvent$1) => void);
    set onInitialized(value: ((e: InitializedEvent$1) => void));
    get onInput(): ((e: InputEvent) => void);
    set onInput(value: ((e: InputEvent) => void));
    get onKeyDown(): ((e: KeyDownEvent) => void);
    set onKeyDown(value: ((e: KeyDownEvent) => void));
    get onKeyUp(): ((e: KeyUpEvent) => void);
    set onKeyUp(value: ((e: KeyUpEvent) => void));
    get onOptionChanged(): ((e: OptionChangedEvent$1) => void);
    set onOptionChanged(value: ((e: OptionChangedEvent$1) => void));
    get onPaste(): ((e: PasteEvent) => void);
    set onPaste(value: ((e: PasteEvent) => void));
    get onValueChanged(): ((e: ValueChangedEvent) => void);
    set onValueChanged(value: ((e: ValueChangedEvent) => void));
    get placeholder(): string;
    set placeholder(value: string);
    get readOnly(): boolean;
    set readOnly(value: boolean);
    get rtlEnabled(): boolean;
    set rtlEnabled(value: boolean);
    get showClearButton(): boolean;
    set showClearButton(value: boolean);
    get showMaskMode(): MaskMode;
    set showMaskMode(value: MaskMode);
    get spellcheck(): boolean;
    set spellcheck(value: boolean);
    get stylingMode(): EditorStyle;
    set stylingMode(value: EditorStyle);
    get tabIndex(): number;
    set tabIndex(value: number);
    get text(): string;
    set text(value: string);
    get useMaskedValue(): boolean;
    set useMaskedValue(value: boolean);
    get validationError(): any | null;
    set validationError(value: any | null);
    get validationErrors(): Array<any> | null;
    set validationErrors(value: Array<any> | null);
    get validationMessageMode(): ValidationMessageMode;
    set validationMessageMode(value: ValidationMessageMode);
    get validationMessagePosition(): Position;
    set validationMessagePosition(value: Position);
    get validationStatus(): ValidationStatus;
    set validationStatus(value: ValidationStatus);
    get value(): string;
    set value(value: string);
    get valueChangeEvent(): string;
    set valueChangeEvent(value: string);
    get visible(): boolean;
    set visible(value: boolean);
    get width(): number | string | undefined;
    set width(value: number | string | undefined);
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    valueChange: EventEmitter<string>;
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDataGridEditorOptionsComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoDataGridEditorOptionsComponent, "dxo-data-grid-editor-options", never, { "accessKey": { "alias": "accessKey"; "required": false; }; "activeStateEnabled": { "alias": "activeStateEnabled"; "required": false; }; "buttons": { "alias": "buttons"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "elementAttr": { "alias": "elementAttr"; "required": false; }; "focusStateEnabled": { "alias": "focusStateEnabled"; "required": false; }; "height": { "alias": "height"; "required": false; }; "hint": { "alias": "hint"; "required": false; }; "hoverStateEnabled": { "alias": "hoverStateEnabled"; "required": false; }; "inputAttr": { "alias": "inputAttr"; "required": false; }; "isDirty": { "alias": "isDirty"; "required": false; }; "isValid": { "alias": "isValid"; "required": false; }; "label": { "alias": "label"; "required": false; }; "labelMode": { "alias": "labelMode"; "required": false; }; "mask": { "alias": "mask"; "required": false; }; "maskChar": { "alias": "maskChar"; "required": false; }; "maskInvalidMessage": { "alias": "maskInvalidMessage"; "required": false; }; "maskRules": { "alias": "maskRules"; "required": false; }; "maxLength": { "alias": "maxLength"; "required": false; }; "mode": { "alias": "mode"; "required": false; }; "name": { "alias": "name"; "required": false; }; "onChange": { "alias": "onChange"; "required": false; }; "onContentReady": { "alias": "onContentReady"; "required": false; }; "onCopy": { "alias": "onCopy"; "required": false; }; "onCut": { "alias": "onCut"; "required": false; }; "onDisposing": { "alias": "onDisposing"; "required": false; }; "onEnterKey": { "alias": "onEnterKey"; "required": false; }; "onFocusIn": { "alias": "onFocusIn"; "required": false; }; "onFocusOut": { "alias": "onFocusOut"; "required": false; }; "onInitialized": { "alias": "onInitialized"; "required": false; }; "onInput": { "alias": "onInput"; "required": false; }; "onKeyDown": { "alias": "onKeyDown"; "required": false; }; "onKeyUp": { "alias": "onKeyUp"; "required": false; }; "onOptionChanged": { "alias": "onOptionChanged"; "required": false; }; "onPaste": { "alias": "onPaste"; "required": false; }; "onValueChanged": { "alias": "onValueChanged"; "required": false; }; "placeholder": { "alias": "placeholder"; "required": false; }; "readOnly": { "alias": "readOnly"; "required": false; }; "rtlEnabled": { "alias": "rtlEnabled"; "required": false; }; "showClearButton": { "alias": "showClearButton"; "required": false; }; "showMaskMode": { "alias": "showMaskMode"; "required": false; }; "spellcheck": { "alias": "spellcheck"; "required": false; }; "stylingMode": { "alias": "stylingMode"; "required": false; }; "tabIndex": { "alias": "tabIndex"; "required": false; }; "text": { "alias": "text"; "required": false; }; "useMaskedValue": { "alias": "useMaskedValue"; "required": false; }; "validationError": { "alias": "validationError"; "required": false; }; "validationErrors": { "alias": "validationErrors"; "required": false; }; "validationMessageMode": { "alias": "validationMessageMode"; "required": false; }; "validationMessagePosition": { "alias": "validationMessagePosition"; "required": false; }; "validationStatus": { "alias": "validationStatus"; "required": false; }; "value": { "alias": "value"; "required": false; }; "valueChangeEvent": { "alias": "valueChangeEvent"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, { "valueChange": "valueChange"; }, ["_buttonsContentChildren"], never, true, never>;
}
declare class DxoDataGridEditorOptionsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDataGridEditorOptionsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoDataGridEditorOptionsModule, never, [typeof DxoDataGridEditorOptionsComponent], [typeof DxoDataGridEditorOptionsComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoDataGridEditorOptionsModule>;
}

declare class DxiDataGridEmailRuleComponent extends CollectionNestedOption {
    get ignoreEmptyValue(): boolean;
    set ignoreEmptyValue(value: boolean);
    get message(): string;
    set message(value: string);
    get type(): ValidationRuleType;
    set type(value: ValidationRuleType);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiDataGridEmailRuleComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiDataGridEmailRuleComponent, "dxi-data-grid-email-rule", never, { "ignoreEmptyValue": { "alias": "ignoreEmptyValue"; "required": false; }; "message": { "alias": "message"; "required": false; }; "type": { "alias": "type"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxiDataGridEmailRuleModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiDataGridEmailRuleModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiDataGridEmailRuleModule, never, [typeof DxiDataGridEmailRuleComponent], [typeof DxiDataGridEmailRuleComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiDataGridEmailRuleModule>;
}

declare class DxiDataGridEmptyItemComponent extends CollectionNestedOption {
    get colSpan(): number | undefined;
    set colSpan(value: number | undefined);
    get cssClass(): string | undefined;
    set cssClass(value: string | undefined);
    get itemType(): FormItemType;
    set itemType(value: FormItemType);
    get name(): string | undefined;
    set name(value: string | undefined);
    get visible(): boolean;
    set visible(value: boolean);
    get visibleIndex(): number | undefined;
    set visibleIndex(value: number | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiDataGridEmptyItemComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiDataGridEmptyItemComponent, "dxi-data-grid-empty-item", never, { "colSpan": { "alias": "colSpan"; "required": false; }; "cssClass": { "alias": "cssClass"; "required": false; }; "itemType": { "alias": "itemType"; "required": false; }; "name": { "alias": "name"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "visibleIndex": { "alias": "visibleIndex"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxiDataGridEmptyItemModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiDataGridEmptyItemModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiDataGridEmptyItemModule, never, [typeof DxiDataGridEmptyItemComponent], [typeof DxiDataGridEmptyItemComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiDataGridEmptyItemModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoDataGridExportTextsComponent extends NestedOption implements OnDestroy, OnInit {
    get exportAll(): string;
    set exportAll(value: string);
    get exportSelectedRows(): string;
    set exportSelectedRows(value: string);
    get exportTo(): string;
    set exportTo(value: string);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDataGridExportTextsComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoDataGridExportTextsComponent, "dxo-data-grid-export-texts", never, { "exportAll": { "alias": "exportAll"; "required": false; }; "exportSelectedRows": { "alias": "exportSelectedRows"; "required": false; }; "exportTo": { "alias": "exportTo"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoDataGridExportTextsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDataGridExportTextsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoDataGridExportTextsModule, never, [typeof DxoDataGridExportTextsComponent], [typeof DxoDataGridExportTextsComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoDataGridExportTextsModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoDataGridExportComponent extends NestedOption implements OnDestroy, OnInit {
    get allowExportSelectedData(): boolean;
    set allowExportSelectedData(value: boolean);
    get enabled(): boolean;
    set enabled(value: boolean);
    get formats(): Array<DataGridExportFormat | string>;
    set formats(value: Array<DataGridExportFormat | string>);
    get texts(): {
        exportAll?: string;
        exportSelectedRows?: string;
        exportTo?: string;
    };
    set texts(value: {
        exportAll?: string;
        exportSelectedRows?: string;
        exportTo?: string;
    });
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDataGridExportComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoDataGridExportComponent, "dxo-data-grid-export", never, { "allowExportSelectedData": { "alias": "allowExportSelectedData"; "required": false; }; "enabled": { "alias": "enabled"; "required": false; }; "formats": { "alias": "formats"; "required": false; }; "texts": { "alias": "texts"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoDataGridExportModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDataGridExportModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoDataGridExportModule, never, [typeof DxoDataGridExportComponent], [typeof DxoDataGridExportComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoDataGridExportModule>;
}

declare class DxiDataGridFieldComponent extends CollectionNestedOption {
    get calculateFilterExpression(): ((filterValue: any, selectedFilterOperation: string) => string | Function | Array<any>);
    set calculateFilterExpression(value: ((filterValue: any, selectedFilterOperation: string) => string | Function | Array<any>));
    get caption(): string | undefined;
    set caption(value: string | undefined);
    get customizeText(): ((fieldInfo: FieldInfo) => string);
    set customizeText(value: ((fieldInfo: FieldInfo) => string));
    get dataField(): string | undefined;
    set dataField(value: string | undefined);
    get dataType(): DataType;
    set dataType(value: DataType);
    get editorOptions(): any;
    set editorOptions(value: any);
    get editorTemplate(): any;
    set editorTemplate(value: any);
    get falseText(): string;
    set falseText(value: string);
    get filterOperations(): Array<FilterBuilderOperation | string>;
    set filterOperations(value: Array<FilterBuilderOperation | string>);
    get format(): Format;
    set format(value: Format);
    get lookup(): {
        allowClearing?: boolean;
        dataSource?: Array<any> | DataSourceOptions | Store | undefined;
        displayExpr?: ((data: any) => string) | string | undefined;
        valueExpr?: ((data: any) => string | number | boolean) | string | undefined;
    };
    set lookup(value: {
        allowClearing?: boolean;
        dataSource?: Array<any> | DataSourceOptions | Store | undefined;
        displayExpr?: ((data: any) => string) | string | undefined;
        valueExpr?: ((data: any) => string | number | boolean) | string | undefined;
    });
    get name(): string | undefined;
    set name(value: string | undefined);
    get trueText(): string;
    set trueText(value: string);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiDataGridFieldComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiDataGridFieldComponent, "dxi-data-grid-field", never, { "calculateFilterExpression": { "alias": "calculateFilterExpression"; "required": false; }; "caption": { "alias": "caption"; "required": false; }; "customizeText": { "alias": "customizeText"; "required": false; }; "dataField": { "alias": "dataField"; "required": false; }; "dataType": { "alias": "dataType"; "required": false; }; "editorOptions": { "alias": "editorOptions"; "required": false; }; "editorTemplate": { "alias": "editorTemplate"; "required": false; }; "falseText": { "alias": "falseText"; "required": false; }; "filterOperations": { "alias": "filterOperations"; "required": false; }; "format": { "alias": "format"; "required": false; }; "lookup": { "alias": "lookup"; "required": false; }; "name": { "alias": "name"; "required": false; }; "trueText": { "alias": "trueText"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxiDataGridFieldModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiDataGridFieldModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiDataGridFieldModule, never, [typeof DxiDataGridFieldComponent], [typeof DxiDataGridFieldComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiDataGridFieldModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoDataGridFieldLookupComponent extends NestedOption implements OnDestroy, OnInit {
    get allowClearing(): boolean;
    set allowClearing(value: boolean);
    get dataSource(): Array<any> | DataSourceOptions | Store | undefined;
    set dataSource(value: Array<any> | DataSourceOptions | Store | undefined);
    get displayExpr(): ((data: any) => string) | string | undefined;
    set displayExpr(value: ((data: any) => string) | string | undefined);
    get valueExpr(): ((data: any) => string | number | boolean) | string | undefined;
    set valueExpr(value: ((data: any) => string | number | boolean) | string | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDataGridFieldLookupComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoDataGridFieldLookupComponent, "dxo-data-grid-field-lookup", never, { "allowClearing": { "alias": "allowClearing"; "required": false; }; "dataSource": { "alias": "dataSource"; "required": false; }; "displayExpr": { "alias": "displayExpr"; "required": false; }; "valueExpr": { "alias": "valueExpr"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoDataGridFieldLookupModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDataGridFieldLookupModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoDataGridFieldLookupModule, never, [typeof DxoDataGridFieldLookupComponent], [typeof DxoDataGridFieldLookupComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoDataGridFieldLookupModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoDataGridFilterBuilderPopupComponent extends NestedOption implements OnDestroy, OnInit {
    set _toolbarItemsContentChildren(value: QueryList<CollectionNestedOption>);
    get accessKey(): string | undefined;
    set accessKey(value: string | undefined);
    get animation(): {
        hide?: AnimationConfig;
        show?: AnimationConfig;
    };
    set animation(value: {
        hide?: AnimationConfig;
        show?: AnimationConfig;
    });
    get container(): any | string | undefined;
    set container(value: any | string | undefined);
    get contentTemplate(): any;
    set contentTemplate(value: any);
    get deferRendering(): boolean;
    set deferRendering(value: boolean);
    get disabled(): boolean;
    set disabled(value: boolean);
    get dragAndResizeArea(): any | string | undefined;
    set dragAndResizeArea(value: any | string | undefined);
    get dragEnabled(): boolean;
    set dragEnabled(value: boolean);
    get dragOutsideBoundary(): boolean;
    set dragOutsideBoundary(value: boolean);
    get enableBodyScroll(): boolean;
    set enableBodyScroll(value: boolean);
    get focusStateEnabled(): boolean;
    set focusStateEnabled(value: boolean);
    get fullScreen(): boolean;
    set fullScreen(value: boolean);
    get height(): number | string;
    set height(value: number | string);
    get hideOnOutsideClick(): boolean | ((event: event) => boolean);
    set hideOnOutsideClick(value: boolean | ((event: event) => boolean));
    get hideOnParentScroll(): boolean;
    set hideOnParentScroll(value: boolean);
    get hint(): string | undefined;
    set hint(value: string | undefined);
    get hoverStateEnabled(): boolean;
    set hoverStateEnabled(value: boolean);
    get maxHeight(): number | string;
    set maxHeight(value: number | string);
    get maxWidth(): number | string;
    set maxWidth(value: number | string);
    get minHeight(): number | string;
    set minHeight(value: number | string);
    get minWidth(): number | string;
    set minWidth(value: number | string);
    get onContentReady(): ((e: EventInfo<any>) => void) | undefined;
    set onContentReady(value: ((e: EventInfo<any>) => void) | undefined);
    get onDisposing(): ((e: EventInfo<any>) => void) | undefined;
    set onDisposing(value: ((e: EventInfo<any>) => void) | undefined);
    get onHidden(): ((e: EventInfo<any>) => void);
    set onHidden(value: ((e: EventInfo<any>) => void));
    get onHiding(): ((e: {
        cancel: boolean | any;
        component: dxOverlay<any>;
        element: any;
        model: any;
    }) => void);
    set onHiding(value: ((e: {
        cancel: boolean | any;
        component: dxOverlay<any>;
        element: any;
        model: any;
    }) => void));
    get onInitialized(): ((e: {
        component: Component<any>;
        element: any;
    }) => void) | undefined;
    set onInitialized(value: ((e: {
        component: Component<any>;
        element: any;
    }) => void) | undefined);
    get onOptionChanged(): ((e: {
        component: DOMComponent;
        element: any;
        fullName: string;
        model: any;
        name: string;
        previousValue: any;
        value: any;
    }) => void) | undefined;
    set onOptionChanged(value: ((e: {
        component: DOMComponent;
        element: any;
        fullName: string;
        model: any;
        name: string;
        previousValue: any;
        value: any;
    }) => void) | undefined);
    get onResize(): ((e: {
        component: dxPopup;
        element: any;
        event: event;
        height: number;
        model: any;
        width: number;
    }) => void) | undefined;
    set onResize(value: ((e: {
        component: dxPopup;
        element: any;
        event: event;
        height: number;
        model: any;
        width: number;
    }) => void) | undefined);
    get onResizeEnd(): ((e: {
        component: dxPopup;
        element: any;
        event: event;
        height: number;
        model: any;
        width: number;
    }) => void) | undefined;
    set onResizeEnd(value: ((e: {
        component: dxPopup;
        element: any;
        event: event;
        height: number;
        model: any;
        width: number;
    }) => void) | undefined);
    get onResizeStart(): ((e: {
        component: dxPopup;
        element: any;
        event: event;
        height: number;
        model: any;
        width: number;
    }) => void) | undefined;
    set onResizeStart(value: ((e: {
        component: dxPopup;
        element: any;
        event: event;
        height: number;
        model: any;
        width: number;
    }) => void) | undefined);
    get onShowing(): ((e: {
        cancel: boolean | any;
        component: dxOverlay<any>;
        element: any;
        model: any;
    }) => void);
    set onShowing(value: ((e: {
        cancel: boolean | any;
        component: dxOverlay<any>;
        element: any;
        model: any;
    }) => void));
    get onShown(): ((e: EventInfo<any>) => void);
    set onShown(value: ((e: EventInfo<any>) => void));
    get onTitleRendered(): ((e: {
        component: dxPopup;
        element: any;
        model: any;
        titleElement: any;
    }) => void) | undefined;
    set onTitleRendered(value: ((e: {
        component: dxPopup;
        element: any;
        model: any;
        titleElement: any;
    }) => void) | undefined);
    get position(): Function | PositionAlignment | PositionConfig;
    set position(value: Function | PositionAlignment | PositionConfig);
    get resizeEnabled(): boolean;
    set resizeEnabled(value: boolean);
    get restorePosition(): boolean;
    set restorePosition(value: boolean);
    get rtlEnabled(): boolean;
    set rtlEnabled(value: boolean);
    get shading(): boolean;
    set shading(value: boolean);
    get shadingColor(): string;
    set shadingColor(value: string);
    get showCloseButton(): boolean;
    set showCloseButton(value: boolean);
    get showTitle(): boolean;
    set showTitle(value: boolean);
    get tabFocusLoopEnabled(): boolean;
    set tabFocusLoopEnabled(value: boolean);
    get tabIndex(): number;
    set tabIndex(value: number);
    get title(): string;
    set title(value: string);
    get titleTemplate(): any;
    set titleTemplate(value: any);
    get toolbarItems(): Array<dxPopupToolbarItem>;
    set toolbarItems(value: Array<dxPopupToolbarItem>);
    get visible(): boolean;
    set visible(value: boolean);
    get width(): number | string;
    set width(value: number | string);
    get wrapperAttr(): any;
    set wrapperAttr(value: any);
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    heightChange: EventEmitter<number | string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    positionChange: EventEmitter<Function | PositionAlignment | PositionConfig>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    visibleChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    widthChange: EventEmitter<number | string>;
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDataGridFilterBuilderPopupComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoDataGridFilterBuilderPopupComponent, "dxo-data-grid-filter-builder-popup", never, { "accessKey": { "alias": "accessKey"; "required": false; }; "animation": { "alias": "animation"; "required": false; }; "container": { "alias": "container"; "required": false; }; "contentTemplate": { "alias": "contentTemplate"; "required": false; }; "deferRendering": { "alias": "deferRendering"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "dragAndResizeArea": { "alias": "dragAndResizeArea"; "required": false; }; "dragEnabled": { "alias": "dragEnabled"; "required": false; }; "dragOutsideBoundary": { "alias": "dragOutsideBoundary"; "required": false; }; "enableBodyScroll": { "alias": "enableBodyScroll"; "required": false; }; "focusStateEnabled": { "alias": "focusStateEnabled"; "required": false; }; "fullScreen": { "alias": "fullScreen"; "required": false; }; "height": { "alias": "height"; "required": false; }; "hideOnOutsideClick": { "alias": "hideOnOutsideClick"; "required": false; }; "hideOnParentScroll": { "alias": "hideOnParentScroll"; "required": false; }; "hint": { "alias": "hint"; "required": false; }; "hoverStateEnabled": { "alias": "hoverStateEnabled"; "required": false; }; "maxHeight": { "alias": "maxHeight"; "required": false; }; "maxWidth": { "alias": "maxWidth"; "required": false; }; "minHeight": { "alias": "minHeight"; "required": false; }; "minWidth": { "alias": "minWidth"; "required": false; }; "onContentReady": { "alias": "onContentReady"; "required": false; }; "onDisposing": { "alias": "onDisposing"; "required": false; }; "onHidden": { "alias": "onHidden"; "required": false; }; "onHiding": { "alias": "onHiding"; "required": false; }; "onInitialized": { "alias": "onInitialized"; "required": false; }; "onOptionChanged": { "alias": "onOptionChanged"; "required": false; }; "onResize": { "alias": "onResize"; "required": false; }; "onResizeEnd": { "alias": "onResizeEnd"; "required": false; }; "onResizeStart": { "alias": "onResizeStart"; "required": false; }; "onShowing": { "alias": "onShowing"; "required": false; }; "onShown": { "alias": "onShown"; "required": false; }; "onTitleRendered": { "alias": "onTitleRendered"; "required": false; }; "position": { "alias": "position"; "required": false; }; "resizeEnabled": { "alias": "resizeEnabled"; "required": false; }; "restorePosition": { "alias": "restorePosition"; "required": false; }; "rtlEnabled": { "alias": "rtlEnabled"; "required": false; }; "shading": { "alias": "shading"; "required": false; }; "shadingColor": { "alias": "shadingColor"; "required": false; }; "showCloseButton": { "alias": "showCloseButton"; "required": false; }; "showTitle": { "alias": "showTitle"; "required": false; }; "tabFocusLoopEnabled": { "alias": "tabFocusLoopEnabled"; "required": false; }; "tabIndex": { "alias": "tabIndex"; "required": false; }; "title": { "alias": "title"; "required": false; }; "titleTemplate": { "alias": "titleTemplate"; "required": false; }; "toolbarItems": { "alias": "toolbarItems"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; "wrapperAttr": { "alias": "wrapperAttr"; "required": false; }; }, { "heightChange": "heightChange"; "positionChange": "positionChange"; "visibleChange": "visibleChange"; "widthChange": "widthChange"; }, ["_toolbarItemsContentChildren"], never, true, never>;
}
declare class DxoDataGridFilterBuilderPopupModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDataGridFilterBuilderPopupModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoDataGridFilterBuilderPopupModule, never, [typeof DxoDataGridFilterBuilderPopupComponent], [typeof DxoDataGridFilterBuilderPopupComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoDataGridFilterBuilderPopupModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoDataGridFilterBuilderComponent extends NestedOption implements OnDestroy, OnInit {
    set _customOperationsContentChildren(value: QueryList<CollectionNestedOption>);
    set _fieldsContentChildren(value: QueryList<CollectionNestedOption>);
    get accessKey(): string | undefined;
    set accessKey(value: string | undefined);
    get activeStateEnabled(): boolean;
    set activeStateEnabled(value: boolean);
    get allowHierarchicalFields(): boolean;
    set allowHierarchicalFields(value: boolean);
    get customOperations(): Array<dxFilterBuilderCustomOperation>;
    set customOperations(value: Array<dxFilterBuilderCustomOperation>);
    get disabled(): boolean;
    set disabled(value: boolean);
    get elementAttr(): Record<string, any>;
    set elementAttr(value: Record<string, any>);
    get fields(): Array<dxFilterBuilderField>;
    set fields(value: Array<dxFilterBuilderField>);
    get filterOperationDescriptions(): {
        between?: string;
        contains?: string;
        endsWith?: string;
        equal?: string;
        greaterThan?: string;
        greaterThanOrEqual?: string;
        isBlank?: string;
        isNotBlank?: string;
        lessThan?: string;
        lessThanOrEqual?: string;
        notContains?: string;
        notEqual?: string;
        startsWith?: string;
    };
    set filterOperationDescriptions(value: {
        between?: string;
        contains?: string;
        endsWith?: string;
        equal?: string;
        greaterThan?: string;
        greaterThanOrEqual?: string;
        isBlank?: string;
        isNotBlank?: string;
        lessThan?: string;
        lessThanOrEqual?: string;
        notContains?: string;
        notEqual?: string;
        startsWith?: string;
    });
    get focusStateEnabled(): boolean;
    set focusStateEnabled(value: boolean);
    get groupOperationDescriptions(): {
        and?: string;
        notAnd?: string;
        notOr?: string;
        or?: string;
    };
    set groupOperationDescriptions(value: {
        and?: string;
        notAnd?: string;
        notOr?: string;
        or?: string;
    });
    get groupOperations(): Array<GroupOperation>;
    set groupOperations(value: Array<GroupOperation>);
    get height(): number | string | undefined;
    set height(value: number | string | undefined);
    get hint(): string | undefined;
    set hint(value: string | undefined);
    get hoverStateEnabled(): boolean;
    set hoverStateEnabled(value: boolean);
    get maxGroupLevel(): number | undefined;
    set maxGroupLevel(value: number | undefined);
    get onContentReady(): ((e: ContentReadyEvent$2) => void);
    set onContentReady(value: ((e: ContentReadyEvent$2) => void));
    get onDisposing(): ((e: DisposingEvent$2) => void);
    set onDisposing(value: ((e: DisposingEvent$2) => void));
    get onEditorPrepared(): ((e: EditorPreparedEvent) => void) | undefined;
    set onEditorPrepared(value: ((e: EditorPreparedEvent) => void) | undefined);
    get onEditorPreparing(): ((e: EditorPreparingEvent) => void) | undefined;
    set onEditorPreparing(value: ((e: EditorPreparingEvent) => void) | undefined);
    get onInitialized(): ((e: InitializedEvent$2) => void);
    set onInitialized(value: ((e: InitializedEvent$2) => void));
    get onOptionChanged(): ((e: OptionChangedEvent$2) => void);
    set onOptionChanged(value: ((e: OptionChangedEvent$2) => void));
    get onValueChanged(): ((e: ValueChangedEvent$1) => void) | undefined;
    set onValueChanged(value: ((e: ValueChangedEvent$1) => void) | undefined);
    get rtlEnabled(): boolean;
    set rtlEnabled(value: boolean);
    get tabIndex(): number;
    set tabIndex(value: number);
    get value(): Array<any> | Function | string;
    set value(value: Array<any> | Function | string);
    get visible(): boolean;
    set visible(value: boolean);
    get width(): number | string | undefined;
    set width(value: number | string | undefined);
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    valueChange: EventEmitter<Array<any> | Function | string>;
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDataGridFilterBuilderComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoDataGridFilterBuilderComponent, "dxo-data-grid-filter-builder", never, { "accessKey": { "alias": "accessKey"; "required": false; }; "activeStateEnabled": { "alias": "activeStateEnabled"; "required": false; }; "allowHierarchicalFields": { "alias": "allowHierarchicalFields"; "required": false; }; "customOperations": { "alias": "customOperations"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "elementAttr": { "alias": "elementAttr"; "required": false; }; "fields": { "alias": "fields"; "required": false; }; "filterOperationDescriptions": { "alias": "filterOperationDescriptions"; "required": false; }; "focusStateEnabled": { "alias": "focusStateEnabled"; "required": false; }; "groupOperationDescriptions": { "alias": "groupOperationDescriptions"; "required": false; }; "groupOperations": { "alias": "groupOperations"; "required": false; }; "height": { "alias": "height"; "required": false; }; "hint": { "alias": "hint"; "required": false; }; "hoverStateEnabled": { "alias": "hoverStateEnabled"; "required": false; }; "maxGroupLevel": { "alias": "maxGroupLevel"; "required": false; }; "onContentReady": { "alias": "onContentReady"; "required": false; }; "onDisposing": { "alias": "onDisposing"; "required": false; }; "onEditorPrepared": { "alias": "onEditorPrepared"; "required": false; }; "onEditorPreparing": { "alias": "onEditorPreparing"; "required": false; }; "onInitialized": { "alias": "onInitialized"; "required": false; }; "onOptionChanged": { "alias": "onOptionChanged"; "required": false; }; "onValueChanged": { "alias": "onValueChanged"; "required": false; }; "rtlEnabled": { "alias": "rtlEnabled"; "required": false; }; "tabIndex": { "alias": "tabIndex"; "required": false; }; "value": { "alias": "value"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, { "valueChange": "valueChange"; }, ["_customOperationsContentChildren", "_fieldsContentChildren"], never, true, never>;
}
declare class DxoDataGridFilterBuilderModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDataGridFilterBuilderModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoDataGridFilterBuilderModule, never, [typeof DxoDataGridFilterBuilderComponent], [typeof DxoDataGridFilterBuilderComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoDataGridFilterBuilderModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoDataGridFilterOperationDescriptionsComponent extends NestedOption implements OnDestroy, OnInit {
    get between(): string;
    set between(value: string);
    get contains(): string;
    set contains(value: string);
    get endsWith(): string;
    set endsWith(value: string);
    get equal(): string;
    set equal(value: string);
    get greaterThan(): string;
    set greaterThan(value: string);
    get greaterThanOrEqual(): string;
    set greaterThanOrEqual(value: string);
    get isBlank(): string;
    set isBlank(value: string);
    get isNotBlank(): string;
    set isNotBlank(value: string);
    get lessThan(): string;
    set lessThan(value: string);
    get lessThanOrEqual(): string;
    set lessThanOrEqual(value: string);
    get notContains(): string;
    set notContains(value: string);
    get notEqual(): string;
    set notEqual(value: string);
    get startsWith(): string;
    set startsWith(value: string);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDataGridFilterOperationDescriptionsComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoDataGridFilterOperationDescriptionsComponent, "dxo-data-grid-filter-operation-descriptions", never, { "between": { "alias": "between"; "required": false; }; "contains": { "alias": "contains"; "required": false; }; "endsWith": { "alias": "endsWith"; "required": false; }; "equal": { "alias": "equal"; "required": false; }; "greaterThan": { "alias": "greaterThan"; "required": false; }; "greaterThanOrEqual": { "alias": "greaterThanOrEqual"; "required": false; }; "isBlank": { "alias": "isBlank"; "required": false; }; "isNotBlank": { "alias": "isNotBlank"; "required": false; }; "lessThan": { "alias": "lessThan"; "required": false; }; "lessThanOrEqual": { "alias": "lessThanOrEqual"; "required": false; }; "notContains": { "alias": "notContains"; "required": false; }; "notEqual": { "alias": "notEqual"; "required": false; }; "startsWith": { "alias": "startsWith"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoDataGridFilterOperationDescriptionsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDataGridFilterOperationDescriptionsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoDataGridFilterOperationDescriptionsModule, never, [typeof DxoDataGridFilterOperationDescriptionsComponent], [typeof DxoDataGridFilterOperationDescriptionsComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoDataGridFilterOperationDescriptionsModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoDataGridFilterPanelTextsComponent extends NestedOption implements OnDestroy, OnInit {
    get clearFilter(): string;
    set clearFilter(value: string);
    get createFilter(): string;
    set createFilter(value: string);
    get filterEnabledHint(): string;
    set filterEnabledHint(value: string);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDataGridFilterPanelTextsComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoDataGridFilterPanelTextsComponent, "dxo-data-grid-filter-panel-texts", never, { "clearFilter": { "alias": "clearFilter"; "required": false; }; "createFilter": { "alias": "createFilter"; "required": false; }; "filterEnabledHint": { "alias": "filterEnabledHint"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoDataGridFilterPanelTextsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDataGridFilterPanelTextsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoDataGridFilterPanelTextsModule, never, [typeof DxoDataGridFilterPanelTextsComponent], [typeof DxoDataGridFilterPanelTextsComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoDataGridFilterPanelTextsModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoDataGridFilterPanelComponent extends NestedOption implements OnDestroy, OnInit {
    get customizeText(): ((e: {
        component: FilterPanel;
        filterValue: Record<string, any>;
        text: string;
    }) => string);
    set customizeText(value: ((e: {
        component: FilterPanel;
        filterValue: Record<string, any>;
        text: string;
    }) => string));
    get filterEnabled(): boolean;
    set filterEnabled(value: boolean);
    get texts(): FilterPanelTexts;
    set texts(value: FilterPanelTexts);
    get visible(): boolean;
    set visible(value: boolean);
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    filterEnabledChange: EventEmitter<boolean>;
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDataGridFilterPanelComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoDataGridFilterPanelComponent, "dxo-data-grid-filter-panel", never, { "customizeText": { "alias": "customizeText"; "required": false; }; "filterEnabled": { "alias": "filterEnabled"; "required": false; }; "texts": { "alias": "texts"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; }, { "filterEnabledChange": "filterEnabledChange"; }, never, never, true, never>;
}
declare class DxoDataGridFilterPanelModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDataGridFilterPanelModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoDataGridFilterPanelModule, never, [typeof DxoDataGridFilterPanelComponent], [typeof DxoDataGridFilterPanelComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoDataGridFilterPanelModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoDataGridFilterRowComponent extends NestedOption implements OnDestroy, OnInit {
    get applyFilter(): ApplyFilterMode;
    set applyFilter(value: ApplyFilterMode);
    get applyFilterText(): string;
    set applyFilterText(value: string);
    get betweenEndText(): string;
    set betweenEndText(value: string);
    get betweenStartText(): string;
    set betweenStartText(value: string);
    get operationDescriptions(): {
        between?: string;
        contains?: string;
        endsWith?: string;
        equal?: string;
        greaterThan?: string;
        greaterThanOrEqual?: string;
        lessThan?: string;
        lessThanOrEqual?: string;
        notContains?: string;
        notEqual?: string;
        startsWith?: string;
    };
    set operationDescriptions(value: {
        between?: string;
        contains?: string;
        endsWith?: string;
        equal?: string;
        greaterThan?: string;
        greaterThanOrEqual?: string;
        lessThan?: string;
        lessThanOrEqual?: string;
        notContains?: string;
        notEqual?: string;
        startsWith?: string;
    });
    get resetOperationText(): string;
    set resetOperationText(value: string);
    get showAllText(): string;
    set showAllText(value: string);
    get showOperationChooser(): boolean;
    set showOperationChooser(value: boolean);
    get visible(): boolean;
    set visible(value: boolean);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDataGridFilterRowComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoDataGridFilterRowComponent, "dxo-data-grid-filter-row", never, { "applyFilter": { "alias": "applyFilter"; "required": false; }; "applyFilterText": { "alias": "applyFilterText"; "required": false; }; "betweenEndText": { "alias": "betweenEndText"; "required": false; }; "betweenStartText": { "alias": "betweenStartText"; "required": false; }; "operationDescriptions": { "alias": "operationDescriptions"; "required": false; }; "resetOperationText": { "alias": "resetOperationText"; "required": false; }; "showAllText": { "alias": "showAllText"; "required": false; }; "showOperationChooser": { "alias": "showOperationChooser"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoDataGridFilterRowModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDataGridFilterRowModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoDataGridFilterRowModule, never, [typeof DxoDataGridFilterRowComponent], [typeof DxoDataGridFilterRowComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoDataGridFilterRowModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxiDataGridFormGroupItemComponent extends CollectionNestedOption implements AfterViewInit, IDxTemplateHost {
    private renderer;
    private document;
    private element;
    set _itemsContentChildren(value: QueryList<CollectionNestedOption>);
    get alignItemLabels(): boolean;
    set alignItemLabels(value: boolean);
    get caption(): string | undefined;
    set caption(value: string | undefined);
    get captionTemplate(): any;
    set captionTemplate(value: any);
    get colCount(): number;
    set colCount(value: number);
    get colCountByScreen(): {
        lg?: number | undefined;
        md?: number | undefined;
        sm?: number | undefined;
        xs?: number | undefined;
    };
    set colCountByScreen(value: {
        lg?: number | undefined;
        md?: number | undefined;
        sm?: number | undefined;
        xs?: number | undefined;
    });
    get colSpan(): number | undefined;
    set colSpan(value: number | undefined);
    get cssClass(): string | undefined;
    set cssClass(value: string | undefined);
    get items(): Array<dxFormButtonItem | dxFormEmptyItem | dxFormGroupItem | dxFormSimpleItem | dxFormTabbedItem>;
    set items(value: Array<dxFormButtonItem | dxFormEmptyItem | dxFormGroupItem | dxFormSimpleItem | dxFormTabbedItem>);
    get itemType(): FormItemType;
    set itemType(value: FormItemType);
    get name(): string | undefined;
    set name(value: string | undefined);
    get template(): any;
    set template(value: any);
    get visible(): boolean;
    set visible(value: boolean);
    get visibleIndex(): number | undefined;
    set visibleIndex(value: number | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost, renderer: Renderer2, document: any, templateHost: DxTemplateHost, element: ElementRef);
    setTemplate(template: DxTemplateDirective): void;
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiDataGridFormGroupItemComponent, [{ host: true; skipSelf: true; }, { host: true; }, null, null, { host: true; }, null]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiDataGridFormGroupItemComponent, "dxi-data-grid-form-group-item", never, { "alignItemLabels": { "alias": "alignItemLabels"; "required": false; }; "caption": { "alias": "caption"; "required": false; }; "captionTemplate": { "alias": "captionTemplate"; "required": false; }; "colCount": { "alias": "colCount"; "required": false; }; "colCountByScreen": { "alias": "colCountByScreen"; "required": false; }; "colSpan": { "alias": "colSpan"; "required": false; }; "cssClass": { "alias": "cssClass"; "required": false; }; "items": { "alias": "items"; "required": false; }; "itemType": { "alias": "itemType"; "required": false; }; "name": { "alias": "name"; "required": false; }; "template": { "alias": "template"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "visibleIndex": { "alias": "visibleIndex"; "required": false; }; }, {}, ["_itemsContentChildren"], ["*"], true, never>;
}
declare class DxiDataGridFormGroupItemModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiDataGridFormGroupItemModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiDataGridFormGroupItemModule, never, [typeof DxiDataGridFormGroupItemComponent], [typeof DxiDataGridFormGroupItemComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiDataGridFormGroupItemModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoDataGridFormItemComponent extends NestedOption implements AfterViewInit, OnDestroy, OnInit, IDxTemplateHost {
    private renderer;
    private document;
    private element;
    set _validationRulesContentChildren(value: QueryList<CollectionNestedOption>);
    get aiOptions(): {
        disabled?: boolean;
        instruction?: string | undefined;
    };
    set aiOptions(value: {
        disabled?: boolean;
        instruction?: string | undefined;
    });
    get colSpan(): number | undefined;
    set colSpan(value: number | undefined);
    get cssClass(): string | undefined;
    set cssClass(value: string | undefined);
    get dataField(): string | undefined;
    set dataField(value: string | undefined);
    get editorOptions(): any | undefined;
    set editorOptions(value: any | undefined);
    get editorType(): FormItemComponent;
    set editorType(value: FormItemComponent);
    get helpText(): string | undefined;
    set helpText(value: string | undefined);
    get isRequired(): boolean | undefined;
    set isRequired(value: boolean | undefined);
    get itemType(): FormItemType;
    set itemType(value: FormItemType);
    get label(): {
        alignment?: HorizontalAlignment;
        location?: LabelLocation;
        showColon?: boolean;
        template?: any;
        text?: string | undefined;
        visible?: boolean;
    };
    set label(value: {
        alignment?: HorizontalAlignment;
        location?: LabelLocation;
        showColon?: boolean;
        template?: any;
        text?: string | undefined;
        visible?: boolean;
    });
    get name(): string | undefined;
    set name(value: string | undefined);
    get template(): any;
    set template(value: any);
    get validationRules(): Array<CommonTypes.ValidationRule>;
    set validationRules(value: Array<CommonTypes.ValidationRule>);
    get visible(): boolean;
    set visible(value: boolean);
    get visibleIndex(): number | undefined;
    set visibleIndex(value: number | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost, renderer: Renderer2, document: any, templateHost: DxTemplateHost, element: ElementRef);
    setTemplate(template: DxTemplateDirective): void;
    ngAfterViewInit(): void;
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDataGridFormItemComponent, [{ host: true; skipSelf: true; }, { host: true; }, null, null, { host: true; }, null]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoDataGridFormItemComponent, "dxo-data-grid-form-item", never, { "aiOptions": { "alias": "aiOptions"; "required": false; }; "colSpan": { "alias": "colSpan"; "required": false; }; "cssClass": { "alias": "cssClass"; "required": false; }; "dataField": { "alias": "dataField"; "required": false; }; "editorOptions": { "alias": "editorOptions"; "required": false; }; "editorType": { "alias": "editorType"; "required": false; }; "helpText": { "alias": "helpText"; "required": false; }; "isRequired": { "alias": "isRequired"; "required": false; }; "itemType": { "alias": "itemType"; "required": false; }; "label": { "alias": "label"; "required": false; }; "name": { "alias": "name"; "required": false; }; "template": { "alias": "template"; "required": false; }; "validationRules": { "alias": "validationRules"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "visibleIndex": { "alias": "visibleIndex"; "required": false; }; }, {}, ["_validationRulesContentChildren"], ["*"], true, never>;
}
declare class DxoDataGridFormItemModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDataGridFormItemModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoDataGridFormItemModule, never, [typeof DxoDataGridFormItemComponent], [typeof DxoDataGridFormItemComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoDataGridFormItemModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoDataGridFormComponent extends NestedOption implements OnDestroy, OnInit {
    set _itemsContentChildren(value: QueryList<CollectionNestedOption>);
    get accessKey(): string | undefined;
    set accessKey(value: string | undefined);
    get activeStateEnabled(): boolean;
    set activeStateEnabled(value: boolean);
    get aiIntegration(): AIIntegration | undefined;
    set aiIntegration(value: AIIntegration | undefined);
    get alignItemLabels(): boolean;
    set alignItemLabels(value: boolean);
    get alignItemLabelsInAllGroups(): boolean;
    set alignItemLabelsInAllGroups(value: boolean);
    get colCount(): Mode | number;
    set colCount(value: Mode | number);
    get colCountByScreen(): {
        lg?: number | undefined;
        md?: number | undefined;
        sm?: number | undefined;
        xs?: number | undefined;
    };
    set colCountByScreen(value: {
        lg?: number | undefined;
        md?: number | undefined;
        sm?: number | undefined;
        xs?: number | undefined;
    });
    get customizeItem(): ((item: dxFormSimpleItem | dxFormGroupItem | dxFormTabbedItem | dxFormEmptyItem | dxFormButtonItem) => void);
    set customizeItem(value: ((item: dxFormSimpleItem | dxFormGroupItem | dxFormTabbedItem | dxFormEmptyItem | dxFormButtonItem) => void));
    get disabled(): boolean;
    set disabled(value: boolean);
    get elementAttr(): Record<string, any>;
    set elementAttr(value: Record<string, any>);
    get focusStateEnabled(): boolean;
    set focusStateEnabled(value: boolean);
    get formData(): any;
    set formData(value: any);
    get height(): number | string | undefined;
    set height(value: number | string | undefined);
    get hint(): string | undefined;
    set hint(value: string | undefined);
    get hoverStateEnabled(): boolean;
    set hoverStateEnabled(value: boolean);
    get isDirty(): boolean;
    set isDirty(value: boolean);
    get items(): Array<dxFormButtonItem | dxFormEmptyItem | dxFormGroupItem | dxFormSimpleItem | dxFormTabbedItem>;
    set items(value: Array<dxFormButtonItem | dxFormEmptyItem | dxFormGroupItem | dxFormSimpleItem | dxFormTabbedItem>);
    get labelLocation(): LabelLocation;
    set labelLocation(value: LabelLocation);
    get labelMode(): FormLabelMode;
    set labelMode(value: FormLabelMode);
    get minColWidth(): number;
    set minColWidth(value: number);
    get onContentReady(): ((e: ContentReadyEvent$3) => void);
    set onContentReady(value: ((e: ContentReadyEvent$3) => void));
    get onDisposing(): ((e: DisposingEvent$3) => void);
    set onDisposing(value: ((e: DisposingEvent$3) => void));
    get onEditorEnterKey(): ((e: EditorEnterKeyEvent) => void) | undefined;
    set onEditorEnterKey(value: ((e: EditorEnterKeyEvent) => void) | undefined);
    get onFieldDataChanged(): ((e: FieldDataChangedEvent) => void) | undefined;
    set onFieldDataChanged(value: ((e: FieldDataChangedEvent) => void) | undefined);
    get onInitialized(): ((e: InitializedEvent$3) => void);
    set onInitialized(value: ((e: InitializedEvent$3) => void));
    get onOptionChanged(): ((e: OptionChangedEvent$3) => void);
    set onOptionChanged(value: ((e: OptionChangedEvent$3) => void));
    get onSmartPasted(): ((e: SmartPastedEvent) => void) | undefined;
    set onSmartPasted(value: ((e: SmartPastedEvent) => void) | undefined);
    get onSmartPasting(): ((e: SmartPastingEvent) => void) | undefined;
    set onSmartPasting(value: ((e: SmartPastingEvent) => void) | undefined);
    get optionalMark(): string;
    set optionalMark(value: string);
    get readOnly(): boolean;
    set readOnly(value: boolean);
    get requiredMark(): string;
    set requiredMark(value: string);
    get requiredMessage(): string;
    set requiredMessage(value: string);
    get rtlEnabled(): boolean;
    set rtlEnabled(value: boolean);
    get screenByWidth(): Function;
    set screenByWidth(value: Function);
    get scrollingEnabled(): boolean;
    set scrollingEnabled(value: boolean);
    get showColonAfterLabel(): boolean;
    set showColonAfterLabel(value: boolean);
    get showOptionalMark(): boolean;
    set showOptionalMark(value: boolean);
    get showRequiredMark(): boolean;
    set showRequiredMark(value: boolean);
    get showValidationSummary(): boolean;
    set showValidationSummary(value: boolean);
    get tabIndex(): number;
    set tabIndex(value: number);
    get validationGroup(): string | undefined;
    set validationGroup(value: string | undefined);
    get visible(): boolean;
    set visible(value: boolean);
    get width(): number | string | undefined;
    set width(value: number | string | undefined);
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    formDataChange: EventEmitter<any>;
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDataGridFormComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoDataGridFormComponent, "dxo-data-grid-form", never, { "accessKey": { "alias": "accessKey"; "required": false; }; "activeStateEnabled": { "alias": "activeStateEnabled"; "required": false; }; "aiIntegration": { "alias": "aiIntegration"; "required": false; }; "alignItemLabels": { "alias": "alignItemLabels"; "required": false; }; "alignItemLabelsInAllGroups": { "alias": "alignItemLabelsInAllGroups"; "required": false; }; "colCount": { "alias": "colCount"; "required": false; }; "colCountByScreen": { "alias": "colCountByScreen"; "required": false; }; "customizeItem": { "alias": "customizeItem"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "elementAttr": { "alias": "elementAttr"; "required": false; }; "focusStateEnabled": { "alias": "focusStateEnabled"; "required": false; }; "formData": { "alias": "formData"; "required": false; }; "height": { "alias": "height"; "required": false; }; "hint": { "alias": "hint"; "required": false; }; "hoverStateEnabled": { "alias": "hoverStateEnabled"; "required": false; }; "isDirty": { "alias": "isDirty"; "required": false; }; "items": { "alias": "items"; "required": false; }; "labelLocation": { "alias": "labelLocation"; "required": false; }; "labelMode": { "alias": "labelMode"; "required": false; }; "minColWidth": { "alias": "minColWidth"; "required": false; }; "onContentReady": { "alias": "onContentReady"; "required": false; }; "onDisposing": { "alias": "onDisposing"; "required": false; }; "onEditorEnterKey": { "alias": "onEditorEnterKey"; "required": false; }; "onFieldDataChanged": { "alias": "onFieldDataChanged"; "required": false; }; "onInitialized": { "alias": "onInitialized"; "required": false; }; "onOptionChanged": { "alias": "onOptionChanged"; "required": false; }; "onSmartPasted": { "alias": "onSmartPasted"; "required": false; }; "onSmartPasting": { "alias": "onSmartPasting"; "required": false; }; "optionalMark": { "alias": "optionalMark"; "required": false; }; "readOnly": { "alias": "readOnly"; "required": false; }; "requiredMark": { "alias": "requiredMark"; "required": false; }; "requiredMessage": { "alias": "requiredMessage"; "required": false; }; "rtlEnabled": { "alias": "rtlEnabled"; "required": false; }; "screenByWidth": { "alias": "screenByWidth"; "required": false; }; "scrollingEnabled": { "alias": "scrollingEnabled"; "required": false; }; "showColonAfterLabel": { "alias": "showColonAfterLabel"; "required": false; }; "showOptionalMark": { "alias": "showOptionalMark"; "required": false; }; "showRequiredMark": { "alias": "showRequiredMark"; "required": false; }; "showValidationSummary": { "alias": "showValidationSummary"; "required": false; }; "tabIndex": { "alias": "tabIndex"; "required": false; }; "validationGroup": { "alias": "validationGroup"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, { "formDataChange": "formDataChange"; }, ["_itemsContentChildren"], never, true, never>;
}
declare class DxoDataGridFormModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDataGridFormModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoDataGridFormModule, never, [typeof DxoDataGridFormComponent], [typeof DxoDataGridFormComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoDataGridFormModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoDataGridFormatComponent extends NestedOption implements OnDestroy, OnInit {
    get currency(): string;
    set currency(value: string);
    get formatter(): ((value: number | Date) => string);
    set formatter(value: ((value: number | Date) => string));
    get parser(): ((value: string) => number | Date);
    set parser(value: ((value: string) => number | Date));
    get precision(): number;
    set precision(value: number);
    get type(): Format$1 | string;
    set type(value: Format$1 | string);
    get useCurrencyAccountingStyle(): boolean;
    set useCurrencyAccountingStyle(value: boolean);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDataGridFormatComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoDataGridFormatComponent, "dxo-data-grid-format", never, { "currency": { "alias": "currency"; "required": false; }; "formatter": { "alias": "formatter"; "required": false; }; "parser": { "alias": "parser"; "required": false; }; "precision": { "alias": "precision"; "required": false; }; "type": { "alias": "type"; "required": false; }; "useCurrencyAccountingStyle": { "alias": "useCurrencyAccountingStyle"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoDataGridFormatModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDataGridFormatModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoDataGridFormatModule, never, [typeof DxoDataGridFormatComponent], [typeof DxoDataGridFormatComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoDataGridFormatModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoDataGridFromComponent extends NestedOption implements OnDestroy, OnInit {
    get left(): number;
    set left(value: number);
    get opacity(): number;
    set opacity(value: number);
    get position(): PositionConfig;
    set position(value: PositionConfig);
    get scale(): number;
    set scale(value: number);
    get top(): number;
    set top(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDataGridFromComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoDataGridFromComponent, "dxo-data-grid-from", never, { "left": { "alias": "left"; "required": false; }; "opacity": { "alias": "opacity"; "required": false; }; "position": { "alias": "position"; "required": false; }; "scale": { "alias": "scale"; "required": false; }; "top": { "alias": "top"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoDataGridFromModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDataGridFromModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoDataGridFromModule, never, [typeof DxoDataGridFromComponent], [typeof DxoDataGridFromComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoDataGridFromModule>;
}

declare class DxiDataGridGroupItemComponent extends CollectionNestedOption {
    get alignByColumn(): boolean;
    set alignByColumn(value: boolean);
    get column(): string | undefined;
    set column(value: string | undefined);
    get customizeText(): ((itemInfo: {
        value: string | number | Date;
        valueText: string;
    }) => string);
    set customizeText(value: ((itemInfo: {
        value: string | number | Date;
        valueText: string;
    }) => string));
    get displayFormat(): string | undefined;
    set displayFormat(value: string | undefined);
    get name(): string | undefined;
    set name(value: string | undefined);
    get showInColumn(): string | undefined;
    set showInColumn(value: string | undefined);
    get showInGroupFooter(): boolean;
    set showInGroupFooter(value: boolean);
    get skipEmptyValues(): boolean;
    set skipEmptyValues(value: boolean);
    get summaryType(): string | SummaryType | undefined;
    set summaryType(value: string | SummaryType | undefined);
    get valueFormat(): Format | undefined;
    set valueFormat(value: Format | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiDataGridGroupItemComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiDataGridGroupItemComponent, "dxi-data-grid-group-item", never, { "alignByColumn": { "alias": "alignByColumn"; "required": false; }; "column": { "alias": "column"; "required": false; }; "customizeText": { "alias": "customizeText"; "required": false; }; "displayFormat": { "alias": "displayFormat"; "required": false; }; "name": { "alias": "name"; "required": false; }; "showInColumn": { "alias": "showInColumn"; "required": false; }; "showInGroupFooter": { "alias": "showInGroupFooter"; "required": false; }; "skipEmptyValues": { "alias": "skipEmptyValues"; "required": false; }; "summaryType": { "alias": "summaryType"; "required": false; }; "valueFormat": { "alias": "valueFormat"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxiDataGridGroupItemModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiDataGridGroupItemModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiDataGridGroupItemModule, never, [typeof DxiDataGridGroupItemComponent], [typeof DxiDataGridGroupItemComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiDataGridGroupItemModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoDataGridGroupOperationDescriptionsComponent extends NestedOption implements OnDestroy, OnInit {
    get and(): string;
    set and(value: string);
    get notAnd(): string;
    set notAnd(value: string);
    get notOr(): string;
    set notOr(value: string);
    get or(): string;
    set or(value: string);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDataGridGroupOperationDescriptionsComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoDataGridGroupOperationDescriptionsComponent, "dxo-data-grid-group-operation-descriptions", never, { "and": { "alias": "and"; "required": false; }; "notAnd": { "alias": "notAnd"; "required": false; }; "notOr": { "alias": "notOr"; "required": false; }; "or": { "alias": "or"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoDataGridGroupOperationDescriptionsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDataGridGroupOperationDescriptionsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoDataGridGroupOperationDescriptionsModule, never, [typeof DxoDataGridGroupOperationDescriptionsComponent], [typeof DxoDataGridGroupOperationDescriptionsComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoDataGridGroupOperationDescriptionsModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoDataGridGroupPanelComponent extends NestedOption implements OnDestroy, OnInit {
    get allowColumnDragging(): boolean;
    set allowColumnDragging(value: boolean);
    get emptyPanelText(): string;
    set emptyPanelText(value: string);
    get visible(): boolean | Mode;
    set visible(value: boolean | Mode);
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    visibleChange: EventEmitter<boolean | Mode>;
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDataGridGroupPanelComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoDataGridGroupPanelComponent, "dxo-data-grid-group-panel", never, { "allowColumnDragging": { "alias": "allowColumnDragging"; "required": false; }; "emptyPanelText": { "alias": "emptyPanelText"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; }, { "visibleChange": "visibleChange"; }, never, never, true, never>;
}
declare class DxoDataGridGroupPanelModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDataGridGroupPanelModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoDataGridGroupPanelModule, never, [typeof DxoDataGridGroupPanelComponent], [typeof DxoDataGridGroupPanelComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoDataGridGroupPanelModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoDataGridGroupingTextsComponent extends NestedOption implements OnDestroy, OnInit {
    get groupByThisColumn(): string;
    set groupByThisColumn(value: string);
    get groupContinuedMessage(): string;
    set groupContinuedMessage(value: string);
    get groupContinuesMessage(): string;
    set groupContinuesMessage(value: string);
    get ungroup(): string;
    set ungroup(value: string);
    get ungroupAll(): string;
    set ungroupAll(value: string);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDataGridGroupingTextsComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoDataGridGroupingTextsComponent, "dxo-data-grid-grouping-texts", never, { "groupByThisColumn": { "alias": "groupByThisColumn"; "required": false; }; "groupContinuedMessage": { "alias": "groupContinuedMessage"; "required": false; }; "groupContinuesMessage": { "alias": "groupContinuesMessage"; "required": false; }; "ungroup": { "alias": "ungroup"; "required": false; }; "ungroupAll": { "alias": "ungroupAll"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoDataGridGroupingTextsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDataGridGroupingTextsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoDataGridGroupingTextsModule, never, [typeof DxoDataGridGroupingTextsComponent], [typeof DxoDataGridGroupingTextsComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoDataGridGroupingTextsModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoDataGridGroupingComponent extends NestedOption implements OnDestroy, OnInit {
    get allowCollapsing(): boolean;
    set allowCollapsing(value: boolean);
    get autoExpandAll(): boolean;
    set autoExpandAll(value: boolean);
    get contextMenuEnabled(): boolean;
    set contextMenuEnabled(value: boolean);
    get expandMode(): GroupExpandMode;
    set expandMode(value: GroupExpandMode);
    get texts(): {
        groupByThisColumn?: string;
        groupContinuedMessage?: string;
        groupContinuesMessage?: string;
        ungroup?: string;
        ungroupAll?: string;
    };
    set texts(value: {
        groupByThisColumn?: string;
        groupContinuedMessage?: string;
        groupContinuesMessage?: string;
        ungroup?: string;
        ungroupAll?: string;
    });
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDataGridGroupingComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoDataGridGroupingComponent, "dxo-data-grid-grouping", never, { "allowCollapsing": { "alias": "allowCollapsing"; "required": false; }; "autoExpandAll": { "alias": "autoExpandAll"; "required": false; }; "contextMenuEnabled": { "alias": "contextMenuEnabled"; "required": false; }; "expandMode": { "alias": "expandMode"; "required": false; }; "texts": { "alias": "texts"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoDataGridGroupingModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDataGridGroupingModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoDataGridGroupingModule, never, [typeof DxoDataGridGroupingComponent], [typeof DxoDataGridGroupingComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoDataGridGroupingModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoDataGridHeaderFilterComponent extends NestedOption implements OnDestroy, OnInit {
    get allowSearch(): boolean;
    set allowSearch(value: boolean);
    get allowSelectAll(): boolean;
    set allowSelectAll(value: boolean);
    get dataSource(): Array<any> | DataSourceOptions | ((options: {
        component: Record<string, any>;
        dataSource: DataSourceOptions | null;
    }) => void) | null | Store | undefined;
    set dataSource(value: Array<any> | DataSourceOptions | ((options: {
        component: Record<string, any>;
        dataSource: DataSourceOptions | null;
    }) => void) | null | Store | undefined);
    get groupInterval(): Array<number | string> | HeaderFilterGroupInterval | number | undefined;
    set groupInterval(value: Array<number | string> | HeaderFilterGroupInterval | number | undefined);
    get height(): number | string | undefined;
    set height(value: number | string | undefined);
    get search(): ColumnHeaderFilterSearchConfig | HeaderFilterSearchConfig;
    set search(value: ColumnHeaderFilterSearchConfig | HeaderFilterSearchConfig);
    get searchMode(): SearchMode;
    set searchMode(value: SearchMode);
    get width(): number | string | undefined;
    set width(value: number | string | undefined);
    get searchTimeout(): number;
    set searchTimeout(value: number);
    get texts(): HeaderFilterTexts;
    set texts(value: HeaderFilterTexts);
    get visible(): boolean;
    set visible(value: boolean);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDataGridHeaderFilterComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoDataGridHeaderFilterComponent, "dxo-data-grid-header-filter", never, { "allowSearch": { "alias": "allowSearch"; "required": false; }; "allowSelectAll": { "alias": "allowSelectAll"; "required": false; }; "dataSource": { "alias": "dataSource"; "required": false; }; "groupInterval": { "alias": "groupInterval"; "required": false; }; "height": { "alias": "height"; "required": false; }; "search": { "alias": "search"; "required": false; }; "searchMode": { "alias": "searchMode"; "required": false; }; "width": { "alias": "width"; "required": false; }; "searchTimeout": { "alias": "searchTimeout"; "required": false; }; "texts": { "alias": "texts"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoDataGridHeaderFilterModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDataGridHeaderFilterModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoDataGridHeaderFilterModule, never, [typeof DxoDataGridHeaderFilterComponent], [typeof DxoDataGridHeaderFilterComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoDataGridHeaderFilterModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoDataGridHideComponent extends NestedOption implements OnDestroy, OnInit {
    get complete(): (($element: any, config: AnimationConfig) => void);
    set complete(value: (($element: any, config: AnimationConfig) => void));
    get delay(): number;
    set delay(value: number);
    get direction(): Direction | undefined;
    set direction(value: Direction | undefined);
    get duration(): number;
    set duration(value: number);
    get easing(): string;
    set easing(value: string);
    get from(): AnimationState;
    set from(value: AnimationState);
    get staggerDelay(): number | undefined;
    set staggerDelay(value: number | undefined);
    get start(): (($element: any, config: AnimationConfig) => void);
    set start(value: (($element: any, config: AnimationConfig) => void));
    get to(): AnimationState;
    set to(value: AnimationState);
    get type(): AnimationType;
    set type(value: AnimationType);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDataGridHideComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoDataGridHideComponent, "dxo-data-grid-hide", never, { "complete": { "alias": "complete"; "required": false; }; "delay": { "alias": "delay"; "required": false; }; "direction": { "alias": "direction"; "required": false; }; "duration": { "alias": "duration"; "required": false; }; "easing": { "alias": "easing"; "required": false; }; "from": { "alias": "from"; "required": false; }; "staggerDelay": { "alias": "staggerDelay"; "required": false; }; "start": { "alias": "start"; "required": false; }; "to": { "alias": "to"; "required": false; }; "type": { "alias": "type"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoDataGridHideModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDataGridHideModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoDataGridHideModule, never, [typeof DxoDataGridHideComponent], [typeof DxoDataGridHideComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoDataGridHideModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoDataGridIconsComponent extends NestedOption implements OnDestroy, OnInit {
    get fix(): string;
    set fix(value: string);
    get leftPosition(): string;
    set leftPosition(value: string);
    get rightPosition(): string;
    set rightPosition(value: string);
    get stickyPosition(): string;
    set stickyPosition(value: string);
    get unfix(): string;
    set unfix(value: string);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDataGridIconsComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoDataGridIconsComponent, "dxo-data-grid-icons", never, { "fix": { "alias": "fix"; "required": false; }; "leftPosition": { "alias": "leftPosition"; "required": false; }; "rightPosition": { "alias": "rightPosition"; "required": false; }; "stickyPosition": { "alias": "stickyPosition"; "required": false; }; "unfix": { "alias": "unfix"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoDataGridIconsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDataGridIconsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoDataGridIconsModule, never, [typeof DxoDataGridIconsComponent], [typeof DxoDataGridIconsComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoDataGridIconsModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoDataGridIndicatorOptionsComponent extends NestedOption implements OnDestroy, OnInit {
    get animationType(): LoadingAnimationType;
    set animationType(value: LoadingAnimationType);
    get height(): number | string | undefined;
    set height(value: number | string | undefined);
    get src(): string;
    set src(value: string);
    get width(): number | string | undefined;
    set width(value: number | string | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDataGridIndicatorOptionsComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoDataGridIndicatorOptionsComponent, "dxo-data-grid-indicator-options", never, { "animationType": { "alias": "animationType"; "required": false; }; "height": { "alias": "height"; "required": false; }; "src": { "alias": "src"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoDataGridIndicatorOptionsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDataGridIndicatorOptionsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoDataGridIndicatorOptionsModule, never, [typeof DxoDataGridIndicatorOptionsComponent], [typeof DxoDataGridIndicatorOptionsComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoDataGridIndicatorOptionsModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxiDataGridItemComponent extends CollectionNestedOption implements AfterViewInit, IDxTemplateHost {
    private renderer;
    private document;
    private element;
    set _validationRulesContentChildren(value: QueryList<CollectionNestedOption>);
    set _tabsContentChildren(value: QueryList<CollectionNestedOption>);
    set _itemsContentChildren(value: QueryList<CollectionNestedOption>);
    get badge(): string;
    set badge(value: string);
    get disabled(): boolean;
    set disabled(value: boolean);
    get html(): string;
    set html(value: string);
    get icon(): string;
    set icon(value: string);
    get tabTemplate(): any;
    set tabTemplate(value: any);
    get template(): any;
    set template(value: any);
    get text(): string;
    set text(value: string);
    get title(): string;
    set title(value: string);
    get visible(): boolean;
    set visible(value: boolean);
    get aiOptions(): {
        disabled?: boolean;
        instruction?: string | undefined;
    };
    set aiOptions(value: {
        disabled?: boolean;
        instruction?: string | undefined;
    });
    get colSpan(): number | undefined;
    set colSpan(value: number | undefined);
    get cssClass(): string | undefined;
    set cssClass(value: string | undefined);
    get dataField(): string | undefined;
    set dataField(value: string | undefined);
    get editorOptions(): any | undefined;
    set editorOptions(value: any | undefined);
    get editorType(): FormItemComponent;
    set editorType(value: FormItemComponent);
    get helpText(): string | undefined;
    set helpText(value: string | undefined);
    get isRequired(): boolean | undefined;
    set isRequired(value: boolean | undefined);
    get itemType(): FormItemType;
    set itemType(value: FormItemType);
    get label(): {
        alignment?: HorizontalAlignment;
        location?: LabelLocation;
        showColon?: boolean;
        template?: any;
        text?: string | undefined;
        visible?: boolean;
    };
    set label(value: {
        alignment?: HorizontalAlignment;
        location?: LabelLocation;
        showColon?: boolean;
        template?: any;
        text?: string | undefined;
        visible?: boolean;
    });
    get name(): string | undefined | FormPredefinedButtonItem | DataGridPredefinedToolbarItem;
    set name(value: string | undefined | FormPredefinedButtonItem | DataGridPredefinedToolbarItem);
    get validationRules(): Array<CommonTypes.ValidationRule>;
    set validationRules(value: Array<CommonTypes.ValidationRule>);
    get visibleIndex(): number | undefined;
    set visibleIndex(value: number | undefined);
    get alignItemLabels(): boolean;
    set alignItemLabels(value: boolean);
    get caption(): string | undefined;
    set caption(value: string | undefined);
    get captionTemplate(): any;
    set captionTemplate(value: any);
    get colCount(): number;
    set colCount(value: number);
    get colCountByScreen(): {
        lg?: number | undefined;
        md?: number | undefined;
        sm?: number | undefined;
        xs?: number | undefined;
    };
    set colCountByScreen(value: {
        lg?: number | undefined;
        md?: number | undefined;
        sm?: number | undefined;
        xs?: number | undefined;
    });
    get items(): Array<dxFormButtonItem | dxFormEmptyItem | dxFormGroupItem | dxFormSimpleItem | dxFormTabbedItem>;
    set items(value: Array<dxFormButtonItem | dxFormEmptyItem | dxFormGroupItem | dxFormSimpleItem | dxFormTabbedItem>);
    get tabPanelOptions(): dxTabPanelOptions | undefined;
    set tabPanelOptions(value: dxTabPanelOptions | undefined);
    get tabs(): {
        alignItemLabels?: boolean;
        badge?: string | undefined;
        colCount?: number;
        colCountByScreen?: {
            lg?: number | undefined;
            md?: number | undefined;
            sm?: number | undefined;
            xs?: number | undefined;
        };
        disabled?: boolean;
        icon?: string | undefined;
        items?: Array<dxFormButtonItem | dxFormEmptyItem | dxFormGroupItem | dxFormSimpleItem | dxFormTabbedItem>;
        tabTemplate?: any;
        template?: any;
        title?: string | undefined;
    }[];
    set tabs(value: {
        alignItemLabels?: boolean;
        badge?: string | undefined;
        colCount?: number;
        colCountByScreen?: {
            lg?: number | undefined;
            md?: number | undefined;
            sm?: number | undefined;
            xs?: number | undefined;
        };
        disabled?: boolean;
        icon?: string | undefined;
        items?: Array<dxFormButtonItem | dxFormEmptyItem | dxFormGroupItem | dxFormSimpleItem | dxFormTabbedItem>;
        tabTemplate?: any;
        template?: any;
        title?: string | undefined;
    }[]);
    get buttonOptions(): dxButtonOptions | undefined;
    set buttonOptions(value: dxButtonOptions | undefined);
    get horizontalAlignment(): HorizontalAlignment;
    set horizontalAlignment(value: HorizontalAlignment);
    get verticalAlignment(): VerticalAlignment;
    set verticalAlignment(value: VerticalAlignment);
    get locateInMenu(): LocateInMenuMode;
    set locateInMenu(value: LocateInMenuMode);
    get location(): ToolbarItemLocation;
    set location(value: ToolbarItemLocation);
    get menuItemTemplate(): any;
    set menuItemTemplate(value: any);
    get options(): any;
    set options(value: any);
    get showText(): ShowTextMode;
    set showText(value: ShowTextMode);
    get widget(): ToolbarItemComponent;
    set widget(value: ToolbarItemComponent);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost, renderer: Renderer2, document: any, templateHost: DxTemplateHost, element: ElementRef);
    setTemplate(template: DxTemplateDirective): void;
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiDataGridItemComponent, [{ host: true; skipSelf: true; }, { host: true; }, null, null, { host: true; }, null]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiDataGridItemComponent, "dxi-data-grid-item", never, { "badge": { "alias": "badge"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "html": { "alias": "html"; "required": false; }; "icon": { "alias": "icon"; "required": false; }; "tabTemplate": { "alias": "tabTemplate"; "required": false; }; "template": { "alias": "template"; "required": false; }; "text": { "alias": "text"; "required": false; }; "title": { "alias": "title"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "aiOptions": { "alias": "aiOptions"; "required": false; }; "colSpan": { "alias": "colSpan"; "required": false; }; "cssClass": { "alias": "cssClass"; "required": false; }; "dataField": { "alias": "dataField"; "required": false; }; "editorOptions": { "alias": "editorOptions"; "required": false; }; "editorType": { "alias": "editorType"; "required": false; }; "helpText": { "alias": "helpText"; "required": false; }; "isRequired": { "alias": "isRequired"; "required": false; }; "itemType": { "alias": "itemType"; "required": false; }; "label": { "alias": "label"; "required": false; }; "name": { "alias": "name"; "required": false; }; "validationRules": { "alias": "validationRules"; "required": false; }; "visibleIndex": { "alias": "visibleIndex"; "required": false; }; "alignItemLabels": { "alias": "alignItemLabels"; "required": false; }; "caption": { "alias": "caption"; "required": false; }; "captionTemplate": { "alias": "captionTemplate"; "required": false; }; "colCount": { "alias": "colCount"; "required": false; }; "colCountByScreen": { "alias": "colCountByScreen"; "required": false; }; "items": { "alias": "items"; "required": false; }; "tabPanelOptions": { "alias": "tabPanelOptions"; "required": false; }; "tabs": { "alias": "tabs"; "required": false; }; "buttonOptions": { "alias": "buttonOptions"; "required": false; }; "horizontalAlignment": { "alias": "horizontalAlignment"; "required": false; }; "verticalAlignment": { "alias": "verticalAlignment"; "required": false; }; "locateInMenu": { "alias": "locateInMenu"; "required": false; }; "location": { "alias": "location"; "required": false; }; "menuItemTemplate": { "alias": "menuItemTemplate"; "required": false; }; "options": { "alias": "options"; "required": false; }; "showText": { "alias": "showText"; "required": false; }; "widget": { "alias": "widget"; "required": false; }; }, {}, ["_validationRulesContentChildren", "_tabsContentChildren", "_itemsContentChildren"], ["*"], true, never>;
}
declare class DxiDataGridItemModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiDataGridItemModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiDataGridItemModule, never, [typeof DxiDataGridItemComponent], [typeof DxiDataGridItemComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiDataGridItemModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoDataGridKeyboardNavigationComponent extends NestedOption implements OnDestroy, OnInit {
    get editOnKeyPress(): boolean;
    set editOnKeyPress(value: boolean);
    get enabled(): boolean;
    set enabled(value: boolean);
    get enterKeyAction(): EnterKeyAction;
    set enterKeyAction(value: EnterKeyAction);
    get enterKeyDirection(): EnterKeyDirection;
    set enterKeyDirection(value: EnterKeyDirection);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDataGridKeyboardNavigationComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoDataGridKeyboardNavigationComponent, "dxo-data-grid-keyboard-navigation", never, { "editOnKeyPress": { "alias": "editOnKeyPress"; "required": false; }; "enabled": { "alias": "enabled"; "required": false; }; "enterKeyAction": { "alias": "enterKeyAction"; "required": false; }; "enterKeyDirection": { "alias": "enterKeyDirection"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoDataGridKeyboardNavigationModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDataGridKeyboardNavigationModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoDataGridKeyboardNavigationModule, never, [typeof DxoDataGridKeyboardNavigationComponent], [typeof DxoDataGridKeyboardNavigationComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoDataGridKeyboardNavigationModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoDataGridLabelComponent extends NestedOption implements AfterViewInit, OnDestroy, OnInit, IDxTemplateHost {
    private renderer;
    private document;
    private element;
    get alignment(): HorizontalAlignment;
    set alignment(value: HorizontalAlignment);
    get location(): LabelLocation;
    set location(value: LabelLocation);
    get showColon(): boolean;
    set showColon(value: boolean);
    get template(): any;
    set template(value: any);
    get text(): string | undefined;
    set text(value: string | undefined);
    get visible(): boolean;
    set visible(value: boolean);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost, renderer: Renderer2, document: any, templateHost: DxTemplateHost, element: ElementRef);
    setTemplate(template: DxTemplateDirective): void;
    ngAfterViewInit(): void;
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDataGridLabelComponent, [{ host: true; skipSelf: true; }, { host: true; }, null, null, { host: true; }, null]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoDataGridLabelComponent, "dxo-data-grid-label", never, { "alignment": { "alias": "alignment"; "required": false; }; "location": { "alias": "location"; "required": false; }; "showColon": { "alias": "showColon"; "required": false; }; "template": { "alias": "template"; "required": false; }; "text": { "alias": "text"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; }, {}, never, ["*"], true, never>;
}
declare class DxoDataGridLabelModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDataGridLabelModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoDataGridLabelModule, never, [typeof DxoDataGridLabelComponent], [typeof DxoDataGridLabelComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoDataGridLabelModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoDataGridLoadPanelComponent extends NestedOption implements OnDestroy, OnInit {
    get enabled(): boolean | Mode;
    set enabled(value: boolean | Mode);
    get height(): number | string;
    set height(value: number | string);
    get indicatorOptions(): LoadPanelIndicatorProperties;
    set indicatorOptions(value: LoadPanelIndicatorProperties);
    get indicatorSrc(): string;
    set indicatorSrc(value: string);
    get shading(): boolean;
    set shading(value: boolean);
    get shadingColor(): string;
    set shadingColor(value: string);
    get showIndicator(): boolean;
    set showIndicator(value: boolean);
    get showPane(): boolean;
    set showPane(value: boolean);
    get text(): string;
    set text(value: string);
    get width(): number | string;
    set width(value: number | string);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDataGridLoadPanelComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoDataGridLoadPanelComponent, "dxo-data-grid-load-panel", never, { "enabled": { "alias": "enabled"; "required": false; }; "height": { "alias": "height"; "required": false; }; "indicatorOptions": { "alias": "indicatorOptions"; "required": false; }; "indicatorSrc": { "alias": "indicatorSrc"; "required": false; }; "shading": { "alias": "shading"; "required": false; }; "shadingColor": { "alias": "shadingColor"; "required": false; }; "showIndicator": { "alias": "showIndicator"; "required": false; }; "showPane": { "alias": "showPane"; "required": false; }; "text": { "alias": "text"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoDataGridLoadPanelModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDataGridLoadPanelModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoDataGridLoadPanelModule, never, [typeof DxoDataGridLoadPanelComponent], [typeof DxoDataGridLoadPanelComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoDataGridLoadPanelModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoDataGridLookupComponent extends NestedOption implements OnDestroy, OnInit {
    get allowClearing(): boolean;
    set allowClearing(value: boolean);
    get calculateCellValue(): ((rowData: any) => any);
    set calculateCellValue(value: ((rowData: any) => any));
    get dataSource(): Array<any> | DataSourceOptions | ((options: {
        data: Record<string, any>;
        key: any;
    }) => Array<any> | Store | DataSourceOptions) | null | Store | undefined;
    set dataSource(value: Array<any> | DataSourceOptions | ((options: {
        data: Record<string, any>;
        key: any;
    }) => Array<any> | Store | DataSourceOptions) | null | Store | undefined);
    get displayExpr(): ((data: any) => string) | string | undefined;
    set displayExpr(value: ((data: any) => string) | string | undefined);
    get valueExpr(): string | undefined | ((data: any) => string | number | boolean);
    set valueExpr(value: string | undefined | ((data: any) => string | number | boolean));
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDataGridLookupComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoDataGridLookupComponent, "dxo-data-grid-lookup", never, { "allowClearing": { "alias": "allowClearing"; "required": false; }; "calculateCellValue": { "alias": "calculateCellValue"; "required": false; }; "dataSource": { "alias": "dataSource"; "required": false; }; "displayExpr": { "alias": "displayExpr"; "required": false; }; "valueExpr": { "alias": "valueExpr"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoDataGridLookupModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDataGridLookupModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoDataGridLookupModule, never, [typeof DxoDataGridLookupComponent], [typeof DxoDataGridLookupComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoDataGridLookupModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoDataGridMasterDetailComponent extends NestedOption implements AfterViewInit, OnDestroy, OnInit, IDxTemplateHost {
    private renderer;
    private document;
    private element;
    get autoExpandAll(): boolean;
    set autoExpandAll(value: boolean);
    get enabled(): boolean;
    set enabled(value: boolean);
    get template(): any;
    set template(value: any);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost, renderer: Renderer2, document: any, templateHost: DxTemplateHost, element: ElementRef);
    setTemplate(template: DxTemplateDirective): void;
    ngAfterViewInit(): void;
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDataGridMasterDetailComponent, [{ host: true; skipSelf: true; }, { host: true; }, null, null, { host: true; }, null]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoDataGridMasterDetailComponent, "dxo-data-grid-master-detail", never, { "autoExpandAll": { "alias": "autoExpandAll"; "required": false; }; "enabled": { "alias": "enabled"; "required": false; }; "template": { "alias": "template"; "required": false; }; }, {}, never, ["*"], true, never>;
}
declare class DxoDataGridMasterDetailModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDataGridMasterDetailModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoDataGridMasterDetailModule, never, [typeof DxoDataGridMasterDetailComponent], [typeof DxoDataGridMasterDetailComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoDataGridMasterDetailModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoDataGridMyComponent extends NestedOption implements OnDestroy, OnInit {
    get x(): HorizontalAlignment;
    set x(value: HorizontalAlignment);
    get y(): VerticalAlignment;
    set y(value: VerticalAlignment);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDataGridMyComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoDataGridMyComponent, "dxo-data-grid-my", never, { "x": { "alias": "x"; "required": false; }; "y": { "alias": "y"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoDataGridMyModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDataGridMyModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoDataGridMyModule, never, [typeof DxoDataGridMyComponent], [typeof DxoDataGridMyComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoDataGridMyModule>;
}

declare class DxiDataGridNumericRuleComponent extends CollectionNestedOption {
    get ignoreEmptyValue(): boolean;
    set ignoreEmptyValue(value: boolean);
    get message(): string;
    set message(value: string);
    get type(): ValidationRuleType;
    set type(value: ValidationRuleType);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiDataGridNumericRuleComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiDataGridNumericRuleComponent, "dxi-data-grid-numeric-rule", never, { "ignoreEmptyValue": { "alias": "ignoreEmptyValue"; "required": false; }; "message": { "alias": "message"; "required": false; }; "type": { "alias": "type"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxiDataGridNumericRuleModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiDataGridNumericRuleModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiDataGridNumericRuleModule, never, [typeof DxiDataGridNumericRuleComponent], [typeof DxiDataGridNumericRuleComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiDataGridNumericRuleModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoDataGridOffsetComponent extends NestedOption implements OnDestroy, OnInit {
    get x(): number;
    set x(value: number);
    get y(): number;
    set y(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDataGridOffsetComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoDataGridOffsetComponent, "dxo-data-grid-offset", never, { "x": { "alias": "x"; "required": false; }; "y": { "alias": "y"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoDataGridOffsetModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDataGridOffsetModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoDataGridOffsetModule, never, [typeof DxoDataGridOffsetComponent], [typeof DxoDataGridOffsetComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoDataGridOffsetModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoDataGridOperationDescriptionsComponent extends NestedOption implements OnDestroy, OnInit {
    get between(): string;
    set between(value: string);
    get contains(): string;
    set contains(value: string);
    get endsWith(): string;
    set endsWith(value: string);
    get equal(): string;
    set equal(value: string);
    get greaterThan(): string;
    set greaterThan(value: string);
    get greaterThanOrEqual(): string;
    set greaterThanOrEqual(value: string);
    get lessThan(): string;
    set lessThan(value: string);
    get lessThanOrEqual(): string;
    set lessThanOrEqual(value: string);
    get notContains(): string;
    set notContains(value: string);
    get notEqual(): string;
    set notEqual(value: string);
    get startsWith(): string;
    set startsWith(value: string);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDataGridOperationDescriptionsComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoDataGridOperationDescriptionsComponent, "dxo-data-grid-operation-descriptions", never, { "between": { "alias": "between"; "required": false; }; "contains": { "alias": "contains"; "required": false; }; "endsWith": { "alias": "endsWith"; "required": false; }; "equal": { "alias": "equal"; "required": false; }; "greaterThan": { "alias": "greaterThan"; "required": false; }; "greaterThanOrEqual": { "alias": "greaterThanOrEqual"; "required": false; }; "lessThan": { "alias": "lessThan"; "required": false; }; "lessThanOrEqual": { "alias": "lessThanOrEqual"; "required": false; }; "notContains": { "alias": "notContains"; "required": false; }; "notEqual": { "alias": "notEqual"; "required": false; }; "startsWith": { "alias": "startsWith"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoDataGridOperationDescriptionsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDataGridOperationDescriptionsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoDataGridOperationDescriptionsModule, never, [typeof DxoDataGridOperationDescriptionsComponent], [typeof DxoDataGridOperationDescriptionsComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoDataGridOperationDescriptionsModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoDataGridOptionsComponent extends NestedOption implements AfterViewInit, OnDestroy, OnInit, IDxTemplateHost {
    private renderer;
    private document;
    private element;
    get accessKey(): string | undefined;
    set accessKey(value: string | undefined);
    get activeStateEnabled(): boolean;
    set activeStateEnabled(value: boolean);
    get disabled(): boolean;
    set disabled(value: boolean);
    get elementAttr(): Record<string, any>;
    set elementAttr(value: Record<string, any>);
    get focusStateEnabled(): boolean;
    set focusStateEnabled(value: boolean);
    get height(): number | string | undefined;
    set height(value: number | string | undefined);
    get hint(): string | undefined;
    set hint(value: string | undefined);
    get hoverStateEnabled(): boolean;
    set hoverStateEnabled(value: boolean);
    get icon(): string;
    set icon(value: string);
    get onClick(): ((e: ClickEvent) => void) | undefined;
    set onClick(value: ((e: ClickEvent) => void) | undefined);
    get onContentReady(): ((e: ContentReadyEvent) => void);
    set onContentReady(value: ((e: ContentReadyEvent) => void));
    get onDisposing(): ((e: DisposingEvent) => void);
    set onDisposing(value: ((e: DisposingEvent) => void));
    get onInitialized(): ((e: InitializedEvent) => void);
    set onInitialized(value: ((e: InitializedEvent) => void));
    get onOptionChanged(): ((e: OptionChangedEvent) => void);
    set onOptionChanged(value: ((e: OptionChangedEvent) => void));
    get rtlEnabled(): boolean;
    set rtlEnabled(value: boolean);
    get stylingMode(): ButtonStyle;
    set stylingMode(value: ButtonStyle);
    get tabIndex(): number;
    set tabIndex(value: number);
    get template(): any;
    set template(value: any);
    get text(): string;
    set text(value: string);
    get type(): ButtonType | string;
    set type(value: ButtonType | string);
    get useSubmitBehavior(): boolean;
    set useSubmitBehavior(value: boolean);
    get validationGroup(): string | undefined;
    set validationGroup(value: string | undefined);
    get visible(): boolean;
    set visible(value: boolean);
    get width(): number | string | undefined;
    set width(value: number | string | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost, renderer: Renderer2, document: any, templateHost: DxTemplateHost, element: ElementRef);
    setTemplate(template: DxTemplateDirective): void;
    ngAfterViewInit(): void;
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDataGridOptionsComponent, [{ host: true; skipSelf: true; }, { host: true; }, null, null, { host: true; }, null]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoDataGridOptionsComponent, "dxo-data-grid-options", never, { "accessKey": { "alias": "accessKey"; "required": false; }; "activeStateEnabled": { "alias": "activeStateEnabled"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "elementAttr": { "alias": "elementAttr"; "required": false; }; "focusStateEnabled": { "alias": "focusStateEnabled"; "required": false; }; "height": { "alias": "height"; "required": false; }; "hint": { "alias": "hint"; "required": false; }; "hoverStateEnabled": { "alias": "hoverStateEnabled"; "required": false; }; "icon": { "alias": "icon"; "required": false; }; "onClick": { "alias": "onClick"; "required": false; }; "onContentReady": { "alias": "onContentReady"; "required": false; }; "onDisposing": { "alias": "onDisposing"; "required": false; }; "onInitialized": { "alias": "onInitialized"; "required": false; }; "onOptionChanged": { "alias": "onOptionChanged"; "required": false; }; "rtlEnabled": { "alias": "rtlEnabled"; "required": false; }; "stylingMode": { "alias": "stylingMode"; "required": false; }; "tabIndex": { "alias": "tabIndex"; "required": false; }; "template": { "alias": "template"; "required": false; }; "text": { "alias": "text"; "required": false; }; "type": { "alias": "type"; "required": false; }; "useSubmitBehavior": { "alias": "useSubmitBehavior"; "required": false; }; "validationGroup": { "alias": "validationGroup"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, ["*"], true, never>;
}
declare class DxoDataGridOptionsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDataGridOptionsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoDataGridOptionsModule, never, [typeof DxoDataGridOptionsComponent], [typeof DxoDataGridOptionsComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoDataGridOptionsModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoDataGridPagerComponent extends NestedOption implements OnDestroy, OnInit {
    get allowedPageSizes(): Array<number | PagerPageSize> | Mode;
    set allowedPageSizes(value: Array<number | PagerPageSize> | Mode);
    get displayMode(): DisplayMode;
    set displayMode(value: DisplayMode);
    get infoText(): string;
    set infoText(value: string);
    get label(): string;
    set label(value: string);
    get showInfo(): boolean;
    set showInfo(value: boolean);
    get showNavigationButtons(): boolean;
    set showNavigationButtons(value: boolean);
    get showPageSizeSelector(): boolean | Mode;
    set showPageSizeSelector(value: boolean | Mode);
    get visible(): boolean | Mode;
    set visible(value: boolean | Mode);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDataGridPagerComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoDataGridPagerComponent, "dxo-data-grid-pager", never, { "allowedPageSizes": { "alias": "allowedPageSizes"; "required": false; }; "displayMode": { "alias": "displayMode"; "required": false; }; "infoText": { "alias": "infoText"; "required": false; }; "label": { "alias": "label"; "required": false; }; "showInfo": { "alias": "showInfo"; "required": false; }; "showNavigationButtons": { "alias": "showNavigationButtons"; "required": false; }; "showPageSizeSelector": { "alias": "showPageSizeSelector"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoDataGridPagerModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDataGridPagerModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoDataGridPagerModule, never, [typeof DxoDataGridPagerComponent], [typeof DxoDataGridPagerComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoDataGridPagerModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoDataGridPagingComponent extends NestedOption implements OnDestroy, OnInit {
    get enabled(): boolean;
    set enabled(value: boolean);
    get pageIndex(): number;
    set pageIndex(value: number);
    get pageSize(): number;
    set pageSize(value: number);
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    pageIndexChange: EventEmitter<number>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    pageSizeChange: EventEmitter<number>;
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDataGridPagingComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoDataGridPagingComponent, "dxo-data-grid-paging", never, { "enabled": { "alias": "enabled"; "required": false; }; "pageIndex": { "alias": "pageIndex"; "required": false; }; "pageSize": { "alias": "pageSize"; "required": false; }; }, { "pageIndexChange": "pageIndexChange"; "pageSizeChange": "pageSizeChange"; }, never, never, true, never>;
}
declare class DxoDataGridPagingModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDataGridPagingModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoDataGridPagingModule, never, [typeof DxoDataGridPagingComponent], [typeof DxoDataGridPagingComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoDataGridPagingModule>;
}

declare class DxiDataGridPatternRuleComponent extends CollectionNestedOption {
    get ignoreEmptyValue(): boolean;
    set ignoreEmptyValue(value: boolean);
    get message(): string;
    set message(value: string);
    get pattern(): RegExp | string;
    set pattern(value: RegExp | string);
    get type(): ValidationRuleType;
    set type(value: ValidationRuleType);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiDataGridPatternRuleComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiDataGridPatternRuleComponent, "dxi-data-grid-pattern-rule", never, { "ignoreEmptyValue": { "alias": "ignoreEmptyValue"; "required": false; }; "message": { "alias": "message"; "required": false; }; "pattern": { "alias": "pattern"; "required": false; }; "type": { "alias": "type"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxiDataGridPatternRuleModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiDataGridPatternRuleModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiDataGridPatternRuleModule, never, [typeof DxiDataGridPatternRuleComponent], [typeof DxiDataGridPatternRuleComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiDataGridPatternRuleModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoDataGridPopupComponent extends NestedOption implements OnDestroy, OnInit {
    set _toolbarItemsContentChildren(value: QueryList<CollectionNestedOption>);
    get accessKey(): string | undefined;
    set accessKey(value: string | undefined);
    get animation(): {
        hide?: AnimationConfig;
        show?: AnimationConfig;
    };
    set animation(value: {
        hide?: AnimationConfig;
        show?: AnimationConfig;
    });
    get container(): any | string | undefined;
    set container(value: any | string | undefined);
    get contentTemplate(): any;
    set contentTemplate(value: any);
    get deferRendering(): boolean;
    set deferRendering(value: boolean);
    get disabled(): boolean;
    set disabled(value: boolean);
    get dragAndResizeArea(): any | string | undefined;
    set dragAndResizeArea(value: any | string | undefined);
    get dragEnabled(): boolean;
    set dragEnabled(value: boolean);
    get dragOutsideBoundary(): boolean;
    set dragOutsideBoundary(value: boolean);
    get enableBodyScroll(): boolean;
    set enableBodyScroll(value: boolean);
    get focusStateEnabled(): boolean;
    set focusStateEnabled(value: boolean);
    get fullScreen(): boolean;
    set fullScreen(value: boolean);
    get height(): number | string;
    set height(value: number | string);
    get hideOnOutsideClick(): boolean | ((event: event) => boolean);
    set hideOnOutsideClick(value: boolean | ((event: event) => boolean));
    get hideOnParentScroll(): boolean;
    set hideOnParentScroll(value: boolean);
    get hint(): string | undefined;
    set hint(value: string | undefined);
    get hoverStateEnabled(): boolean;
    set hoverStateEnabled(value: boolean);
    get maxHeight(): number | string;
    set maxHeight(value: number | string);
    get maxWidth(): number | string;
    set maxWidth(value: number | string);
    get minHeight(): number | string;
    set minHeight(value: number | string);
    get minWidth(): number | string;
    set minWidth(value: number | string);
    get onContentReady(): ((e: EventInfo<any>) => void) | undefined;
    set onContentReady(value: ((e: EventInfo<any>) => void) | undefined);
    get onDisposing(): ((e: EventInfo<any>) => void) | undefined;
    set onDisposing(value: ((e: EventInfo<any>) => void) | undefined);
    get onHidden(): ((e: EventInfo<any>) => void);
    set onHidden(value: ((e: EventInfo<any>) => void));
    get onHiding(): ((e: {
        cancel: boolean | any;
        component: dxOverlay<any>;
        element: any;
        model: any;
    }) => void);
    set onHiding(value: ((e: {
        cancel: boolean | any;
        component: dxOverlay<any>;
        element: any;
        model: any;
    }) => void));
    get onInitialized(): ((e: {
        component: Component<any>;
        element: any;
    }) => void) | undefined;
    set onInitialized(value: ((e: {
        component: Component<any>;
        element: any;
    }) => void) | undefined);
    get onOptionChanged(): ((e: {
        component: DOMComponent;
        element: any;
        fullName: string;
        model: any;
        name: string;
        previousValue: any;
        value: any;
    }) => void) | undefined;
    set onOptionChanged(value: ((e: {
        component: DOMComponent;
        element: any;
        fullName: string;
        model: any;
        name: string;
        previousValue: any;
        value: any;
    }) => void) | undefined);
    get onResize(): ((e: {
        component: dxPopup;
        element: any;
        event: event;
        height: number;
        model: any;
        width: number;
    }) => void) | undefined;
    set onResize(value: ((e: {
        component: dxPopup;
        element: any;
        event: event;
        height: number;
        model: any;
        width: number;
    }) => void) | undefined);
    get onResizeEnd(): ((e: {
        component: dxPopup;
        element: any;
        event: event;
        height: number;
        model: any;
        width: number;
    }) => void) | undefined;
    set onResizeEnd(value: ((e: {
        component: dxPopup;
        element: any;
        event: event;
        height: number;
        model: any;
        width: number;
    }) => void) | undefined);
    get onResizeStart(): ((e: {
        component: dxPopup;
        element: any;
        event: event;
        height: number;
        model: any;
        width: number;
    }) => void) | undefined;
    set onResizeStart(value: ((e: {
        component: dxPopup;
        element: any;
        event: event;
        height: number;
        model: any;
        width: number;
    }) => void) | undefined);
    get onShowing(): ((e: {
        cancel: boolean | any;
        component: dxOverlay<any>;
        element: any;
        model: any;
    }) => void);
    set onShowing(value: ((e: {
        cancel: boolean | any;
        component: dxOverlay<any>;
        element: any;
        model: any;
    }) => void));
    get onShown(): ((e: EventInfo<any>) => void);
    set onShown(value: ((e: EventInfo<any>) => void));
    get onTitleRendered(): ((e: {
        component: dxPopup;
        element: any;
        model: any;
        titleElement: any;
    }) => void) | undefined;
    set onTitleRendered(value: ((e: {
        component: dxPopup;
        element: any;
        model: any;
        titleElement: any;
    }) => void) | undefined);
    get position(): Function | PositionAlignment | PositionConfig;
    set position(value: Function | PositionAlignment | PositionConfig);
    get resizeEnabled(): boolean;
    set resizeEnabled(value: boolean);
    get restorePosition(): boolean;
    set restorePosition(value: boolean);
    get rtlEnabled(): boolean;
    set rtlEnabled(value: boolean);
    get shading(): boolean;
    set shading(value: boolean);
    get shadingColor(): string;
    set shadingColor(value: string);
    get showCloseButton(): boolean;
    set showCloseButton(value: boolean);
    get showTitle(): boolean;
    set showTitle(value: boolean);
    get tabFocusLoopEnabled(): boolean;
    set tabFocusLoopEnabled(value: boolean);
    get tabIndex(): number;
    set tabIndex(value: number);
    get title(): string;
    set title(value: string);
    get titleTemplate(): any;
    set titleTemplate(value: any);
    get toolbarItems(): Array<dxPopupToolbarItem>;
    set toolbarItems(value: Array<dxPopupToolbarItem>);
    get visible(): boolean;
    set visible(value: boolean);
    get width(): number | string;
    set width(value: number | string);
    get wrapperAttr(): any;
    set wrapperAttr(value: any);
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    heightChange: EventEmitter<number | string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    positionChange: EventEmitter<Function | PositionAlignment | PositionConfig>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    visibleChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    widthChange: EventEmitter<number | string>;
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDataGridPopupComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoDataGridPopupComponent, "dxo-data-grid-popup", never, { "accessKey": { "alias": "accessKey"; "required": false; }; "animation": { "alias": "animation"; "required": false; }; "container": { "alias": "container"; "required": false; }; "contentTemplate": { "alias": "contentTemplate"; "required": false; }; "deferRendering": { "alias": "deferRendering"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "dragAndResizeArea": { "alias": "dragAndResizeArea"; "required": false; }; "dragEnabled": { "alias": "dragEnabled"; "required": false; }; "dragOutsideBoundary": { "alias": "dragOutsideBoundary"; "required": false; }; "enableBodyScroll": { "alias": "enableBodyScroll"; "required": false; }; "focusStateEnabled": { "alias": "focusStateEnabled"; "required": false; }; "fullScreen": { "alias": "fullScreen"; "required": false; }; "height": { "alias": "height"; "required": false; }; "hideOnOutsideClick": { "alias": "hideOnOutsideClick"; "required": false; }; "hideOnParentScroll": { "alias": "hideOnParentScroll"; "required": false; }; "hint": { "alias": "hint"; "required": false; }; "hoverStateEnabled": { "alias": "hoverStateEnabled"; "required": false; }; "maxHeight": { "alias": "maxHeight"; "required": false; }; "maxWidth": { "alias": "maxWidth"; "required": false; }; "minHeight": { "alias": "minHeight"; "required": false; }; "minWidth": { "alias": "minWidth"; "required": false; }; "onContentReady": { "alias": "onContentReady"; "required": false; }; "onDisposing": { "alias": "onDisposing"; "required": false; }; "onHidden": { "alias": "onHidden"; "required": false; }; "onHiding": { "alias": "onHiding"; "required": false; }; "onInitialized": { "alias": "onInitialized"; "required": false; }; "onOptionChanged": { "alias": "onOptionChanged"; "required": false; }; "onResize": { "alias": "onResize"; "required": false; }; "onResizeEnd": { "alias": "onResizeEnd"; "required": false; }; "onResizeStart": { "alias": "onResizeStart"; "required": false; }; "onShowing": { "alias": "onShowing"; "required": false; }; "onShown": { "alias": "onShown"; "required": false; }; "onTitleRendered": { "alias": "onTitleRendered"; "required": false; }; "position": { "alias": "position"; "required": false; }; "resizeEnabled": { "alias": "resizeEnabled"; "required": false; }; "restorePosition": { "alias": "restorePosition"; "required": false; }; "rtlEnabled": { "alias": "rtlEnabled"; "required": false; }; "shading": { "alias": "shading"; "required": false; }; "shadingColor": { "alias": "shadingColor"; "required": false; }; "showCloseButton": { "alias": "showCloseButton"; "required": false; }; "showTitle": { "alias": "showTitle"; "required": false; }; "tabFocusLoopEnabled": { "alias": "tabFocusLoopEnabled"; "required": false; }; "tabIndex": { "alias": "tabIndex"; "required": false; }; "title": { "alias": "title"; "required": false; }; "titleTemplate": { "alias": "titleTemplate"; "required": false; }; "toolbarItems": { "alias": "toolbarItems"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; "wrapperAttr": { "alias": "wrapperAttr"; "required": false; }; }, { "heightChange": "heightChange"; "positionChange": "positionChange"; "visibleChange": "visibleChange"; "widthChange": "widthChange"; }, ["_toolbarItemsContentChildren"], never, true, never>;
}
declare class DxoDataGridPopupModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDataGridPopupModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoDataGridPopupModule, never, [typeof DxoDataGridPopupComponent], [typeof DxoDataGridPopupComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoDataGridPopupModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoDataGridPositionComponent extends NestedOption implements OnDestroy, OnInit {
    get at(): PositionAlignment | {
        x?: HorizontalAlignment;
        y?: VerticalAlignment;
    };
    set at(value: PositionAlignment | {
        x?: HorizontalAlignment;
        y?: VerticalAlignment;
    });
    get boundary(): any | string;
    set boundary(value: any | string);
    get boundaryOffset(): string | {
        x?: number;
        y?: number;
    };
    set boundaryOffset(value: string | {
        x?: number;
        y?: number;
    });
    get collision(): CollisionResolutionCombination | {
        x?: CollisionResolution;
        y?: CollisionResolution;
    };
    set collision(value: CollisionResolutionCombination | {
        x?: CollisionResolution;
        y?: CollisionResolution;
    });
    get my(): PositionAlignment | {
        x?: HorizontalAlignment;
        y?: VerticalAlignment;
    };
    set my(value: PositionAlignment | {
        x?: HorizontalAlignment;
        y?: VerticalAlignment;
    });
    get of(): any | string;
    set of(value: any | string);
    get offset(): string | {
        x?: number;
        y?: number;
    };
    set offset(value: string | {
        x?: number;
        y?: number;
    });
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDataGridPositionComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoDataGridPositionComponent, "dxo-data-grid-position", never, { "at": { "alias": "at"; "required": false; }; "boundary": { "alias": "boundary"; "required": false; }; "boundaryOffset": { "alias": "boundaryOffset"; "required": false; }; "collision": { "alias": "collision"; "required": false; }; "my": { "alias": "my"; "required": false; }; "of": { "alias": "of"; "required": false; }; "offset": { "alias": "offset"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoDataGridPositionModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDataGridPositionModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoDataGridPositionModule, never, [typeof DxoDataGridPositionComponent], [typeof DxoDataGridPositionComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoDataGridPositionModule>;
}

declare class DxiDataGridRangeRuleComponent extends CollectionNestedOption {
    get ignoreEmptyValue(): boolean;
    set ignoreEmptyValue(value: boolean);
    get max(): Date | number | string;
    set max(value: Date | number | string);
    get message(): string;
    set message(value: string);
    get min(): Date | number | string;
    set min(value: Date | number | string);
    get reevaluate(): boolean;
    set reevaluate(value: boolean);
    get type(): ValidationRuleType;
    set type(value: ValidationRuleType);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiDataGridRangeRuleComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiDataGridRangeRuleComponent, "dxi-data-grid-range-rule", never, { "ignoreEmptyValue": { "alias": "ignoreEmptyValue"; "required": false; }; "max": { "alias": "max"; "required": false; }; "message": { "alias": "message"; "required": false; }; "min": { "alias": "min"; "required": false; }; "reevaluate": { "alias": "reevaluate"; "required": false; }; "type": { "alias": "type"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxiDataGridRangeRuleModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiDataGridRangeRuleModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiDataGridRangeRuleModule, never, [typeof DxiDataGridRangeRuleComponent], [typeof DxiDataGridRangeRuleComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiDataGridRangeRuleModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoDataGridRemoteOperationsComponent extends NestedOption implements OnDestroy, OnInit {
    get filtering(): boolean;
    set filtering(value: boolean);
    get grouping(): boolean;
    set grouping(value: boolean);
    get groupPaging(): boolean;
    set groupPaging(value: boolean);
    get paging(): boolean;
    set paging(value: boolean);
    get sorting(): boolean;
    set sorting(value: boolean);
    get summary(): boolean;
    set summary(value: boolean);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDataGridRemoteOperationsComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoDataGridRemoteOperationsComponent, "dxo-data-grid-remote-operations", never, { "filtering": { "alias": "filtering"; "required": false; }; "grouping": { "alias": "grouping"; "required": false; }; "groupPaging": { "alias": "groupPaging"; "required": false; }; "paging": { "alias": "paging"; "required": false; }; "sorting": { "alias": "sorting"; "required": false; }; "summary": { "alias": "summary"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoDataGridRemoteOperationsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDataGridRemoteOperationsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoDataGridRemoteOperationsModule, never, [typeof DxoDataGridRemoteOperationsComponent], [typeof DxoDataGridRemoteOperationsComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoDataGridRemoteOperationsModule>;
}

declare class DxiDataGridRequiredRuleComponent extends CollectionNestedOption {
    get message(): string;
    set message(value: string);
    get trim(): boolean;
    set trim(value: boolean);
    get type(): ValidationRuleType;
    set type(value: ValidationRuleType);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiDataGridRequiredRuleComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiDataGridRequiredRuleComponent, "dxi-data-grid-required-rule", never, { "message": { "alias": "message"; "required": false; }; "trim": { "alias": "trim"; "required": false; }; "type": { "alias": "type"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxiDataGridRequiredRuleModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiDataGridRequiredRuleModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiDataGridRequiredRuleModule, never, [typeof DxiDataGridRequiredRuleComponent], [typeof DxiDataGridRequiredRuleComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiDataGridRequiredRuleModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoDataGridRowDraggingComponent extends NestedOption implements OnDestroy, OnInit {
    get allowDropInsideItem(): boolean;
    set allowDropInsideItem(value: boolean);
    get allowReordering(): boolean;
    set allowReordering(value: boolean);
    get autoScroll(): boolean;
    set autoScroll(value: boolean);
    get boundary(): any | string | undefined;
    set boundary(value: any | string | undefined);
    get container(): any | string | undefined;
    set container(value: any | string | undefined);
    get cursorOffset(): string | {
        x?: number;
        y?: number;
    };
    set cursorOffset(value: string | {
        x?: number;
        y?: number;
    });
    get data(): any | undefined;
    set data(value: any | undefined);
    get dragDirection(): DragDirection;
    set dragDirection(value: DragDirection);
    get dragTemplate(): any;
    set dragTemplate(value: any);
    get dropFeedbackMode(): DragHighlight;
    set dropFeedbackMode(value: DragHighlight);
    get filter(): string;
    set filter(value: string);
    get group(): string | undefined;
    set group(value: string | undefined);
    get handle(): string;
    set handle(value: string);
    get onAdd(): ((e: RowDraggingAddEvent) => void);
    set onAdd(value: ((e: RowDraggingAddEvent) => void));
    get onDragChange(): ((e: RowDraggingChangeEvent) => void);
    set onDragChange(value: ((e: RowDraggingChangeEvent) => void));
    get onDragEnd(): ((e: RowDraggingEndEvent) => void);
    set onDragEnd(value: ((e: RowDraggingEndEvent) => void));
    get onDragMove(): ((e: RowDraggingMoveEvent) => void);
    set onDragMove(value: ((e: RowDraggingMoveEvent) => void));
    get onDragStart(): ((e: RowDraggingStartEvent) => void);
    set onDragStart(value: ((e: RowDraggingStartEvent) => void));
    get onRemove(): ((e: RowDraggingRemoveEvent) => void);
    set onRemove(value: ((e: RowDraggingRemoveEvent) => void));
    get onReorder(): ((e: RowDraggingReorderEvent) => void);
    set onReorder(value: ((e: RowDraggingReorderEvent) => void));
    get scrollSensitivity(): number;
    set scrollSensitivity(value: number);
    get scrollSpeed(): number;
    set scrollSpeed(value: number);
    get showDragIcons(): boolean;
    set showDragIcons(value: boolean);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDataGridRowDraggingComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoDataGridRowDraggingComponent, "dxo-data-grid-row-dragging", never, { "allowDropInsideItem": { "alias": "allowDropInsideItem"; "required": false; }; "allowReordering": { "alias": "allowReordering"; "required": false; }; "autoScroll": { "alias": "autoScroll"; "required": false; }; "boundary": { "alias": "boundary"; "required": false; }; "container": { "alias": "container"; "required": false; }; "cursorOffset": { "alias": "cursorOffset"; "required": false; }; "data": { "alias": "data"; "required": false; }; "dragDirection": { "alias": "dragDirection"; "required": false; }; "dragTemplate": { "alias": "dragTemplate"; "required": false; }; "dropFeedbackMode": { "alias": "dropFeedbackMode"; "required": false; }; "filter": { "alias": "filter"; "required": false; }; "group": { "alias": "group"; "required": false; }; "handle": { "alias": "handle"; "required": false; }; "onAdd": { "alias": "onAdd"; "required": false; }; "onDragChange": { "alias": "onDragChange"; "required": false; }; "onDragEnd": { "alias": "onDragEnd"; "required": false; }; "onDragMove": { "alias": "onDragMove"; "required": false; }; "onDragStart": { "alias": "onDragStart"; "required": false; }; "onRemove": { "alias": "onRemove"; "required": false; }; "onReorder": { "alias": "onReorder"; "required": false; }; "scrollSensitivity": { "alias": "scrollSensitivity"; "required": false; }; "scrollSpeed": { "alias": "scrollSpeed"; "required": false; }; "showDragIcons": { "alias": "showDragIcons"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoDataGridRowDraggingModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDataGridRowDraggingModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoDataGridRowDraggingModule, never, [typeof DxoDataGridRowDraggingComponent], [typeof DxoDataGridRowDraggingComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoDataGridRowDraggingModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoDataGridScrollingComponent extends NestedOption implements OnDestroy, OnInit {
    get columnRenderingMode(): DataRenderMode;
    set columnRenderingMode(value: DataRenderMode);
    get mode(): DataGridScrollMode;
    set mode(value: DataGridScrollMode);
    get preloadEnabled(): boolean;
    set preloadEnabled(value: boolean);
    get renderAsync(): boolean | undefined;
    set renderAsync(value: boolean | undefined);
    get rowRenderingMode(): DataRenderMode;
    set rowRenderingMode(value: DataRenderMode);
    get scrollByContent(): boolean;
    set scrollByContent(value: boolean);
    get scrollByThumb(): boolean;
    set scrollByThumb(value: boolean);
    get showScrollbar(): ScrollbarMode;
    set showScrollbar(value: ScrollbarMode);
    get useNative(): boolean | Mode;
    set useNative(value: boolean | Mode);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDataGridScrollingComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoDataGridScrollingComponent, "dxo-data-grid-scrolling", never, { "columnRenderingMode": { "alias": "columnRenderingMode"; "required": false; }; "mode": { "alias": "mode"; "required": false; }; "preloadEnabled": { "alias": "preloadEnabled"; "required": false; }; "renderAsync": { "alias": "renderAsync"; "required": false; }; "rowRenderingMode": { "alias": "rowRenderingMode"; "required": false; }; "scrollByContent": { "alias": "scrollByContent"; "required": false; }; "scrollByThumb": { "alias": "scrollByThumb"; "required": false; }; "showScrollbar": { "alias": "showScrollbar"; "required": false; }; "useNative": { "alias": "useNative"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoDataGridScrollingModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDataGridScrollingModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoDataGridScrollingModule, never, [typeof DxoDataGridScrollingComponent], [typeof DxoDataGridScrollingComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoDataGridScrollingModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoDataGridSearchPanelComponent extends NestedOption implements OnDestroy, OnInit {
    get highlightCaseSensitive(): boolean;
    set highlightCaseSensitive(value: boolean);
    get highlightSearchText(): boolean;
    set highlightSearchText(value: boolean);
    get placeholder(): string;
    set placeholder(value: string);
    get searchVisibleColumnsOnly(): boolean;
    set searchVisibleColumnsOnly(value: boolean);
    get text(): string;
    set text(value: string);
    get visible(): boolean;
    set visible(value: boolean);
    get width(): number | string;
    set width(value: number | string);
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    textChange: EventEmitter<string>;
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDataGridSearchPanelComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoDataGridSearchPanelComponent, "dxo-data-grid-search-panel", never, { "highlightCaseSensitive": { "alias": "highlightCaseSensitive"; "required": false; }; "highlightSearchText": { "alias": "highlightSearchText"; "required": false; }; "placeholder": { "alias": "placeholder"; "required": false; }; "searchVisibleColumnsOnly": { "alias": "searchVisibleColumnsOnly"; "required": false; }; "text": { "alias": "text"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, { "textChange": "textChange"; }, never, never, true, never>;
}
declare class DxoDataGridSearchPanelModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDataGridSearchPanelModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoDataGridSearchPanelModule, never, [typeof DxoDataGridSearchPanelComponent], [typeof DxoDataGridSearchPanelComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoDataGridSearchPanelModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoDataGridSearchComponent extends NestedOption implements OnDestroy, OnInit {
    get editorOptions(): any;
    set editorOptions(value: any);
    get enabled(): boolean;
    set enabled(value: boolean);
    get mode(): SearchMode;
    set mode(value: SearchMode);
    get searchExpr(): Array<Function | string> | Function | string | undefined;
    set searchExpr(value: Array<Function | string> | Function | string | undefined);
    get timeout(): number;
    set timeout(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDataGridSearchComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoDataGridSearchComponent, "dxo-data-grid-search", never, { "editorOptions": { "alias": "editorOptions"; "required": false; }; "enabled": { "alias": "enabled"; "required": false; }; "mode": { "alias": "mode"; "required": false; }; "searchExpr": { "alias": "searchExpr"; "required": false; }; "timeout": { "alias": "timeout"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoDataGridSearchModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDataGridSearchModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoDataGridSearchModule, never, [typeof DxoDataGridSearchComponent], [typeof DxoDataGridSearchComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoDataGridSearchModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoDataGridSelectionComponent extends NestedOption implements OnDestroy, OnInit {
    get allowSelectAll(): boolean;
    set allowSelectAll(value: boolean);
    get deferred(): boolean;
    set deferred(value: boolean);
    get mode(): SingleMultipleOrNone;
    set mode(value: SingleMultipleOrNone);
    get selectAllMode(): SelectAllMode;
    set selectAllMode(value: SelectAllMode);
    get sensitivity(): SelectionSensitivity;
    set sensitivity(value: SelectionSensitivity);
    get showCheckBoxesMode(): SelectionColumnDisplayMode;
    set showCheckBoxesMode(value: SelectionColumnDisplayMode);
    get recursive(): boolean;
    set recursive(value: boolean);
    get selectByClick(): boolean;
    set selectByClick(value: boolean);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDataGridSelectionComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoDataGridSelectionComponent, "dxo-data-grid-selection", never, { "allowSelectAll": { "alias": "allowSelectAll"; "required": false; }; "deferred": { "alias": "deferred"; "required": false; }; "mode": { "alias": "mode"; "required": false; }; "selectAllMode": { "alias": "selectAllMode"; "required": false; }; "sensitivity": { "alias": "sensitivity"; "required": false; }; "showCheckBoxesMode": { "alias": "showCheckBoxesMode"; "required": false; }; "recursive": { "alias": "recursive"; "required": false; }; "selectByClick": { "alias": "selectByClick"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoDataGridSelectionModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDataGridSelectionModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoDataGridSelectionModule, never, [typeof DxoDataGridSelectionComponent], [typeof DxoDataGridSelectionComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoDataGridSelectionModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoDataGridShowComponent extends NestedOption implements OnDestroy, OnInit {
    get complete(): (($element: any, config: AnimationConfig) => void);
    set complete(value: (($element: any, config: AnimationConfig) => void));
    get delay(): number;
    set delay(value: number);
    get direction(): Direction | undefined;
    set direction(value: Direction | undefined);
    get duration(): number;
    set duration(value: number);
    get easing(): string;
    set easing(value: string);
    get from(): AnimationState;
    set from(value: AnimationState);
    get staggerDelay(): number | undefined;
    set staggerDelay(value: number | undefined);
    get start(): (($element: any, config: AnimationConfig) => void);
    set start(value: (($element: any, config: AnimationConfig) => void));
    get to(): AnimationState;
    set to(value: AnimationState);
    get type(): AnimationType;
    set type(value: AnimationType);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDataGridShowComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoDataGridShowComponent, "dxo-data-grid-show", never, { "complete": { "alias": "complete"; "required": false; }; "delay": { "alias": "delay"; "required": false; }; "direction": { "alias": "direction"; "required": false; }; "duration": { "alias": "duration"; "required": false; }; "easing": { "alias": "easing"; "required": false; }; "from": { "alias": "from"; "required": false; }; "staggerDelay": { "alias": "staggerDelay"; "required": false; }; "start": { "alias": "start"; "required": false; }; "to": { "alias": "to"; "required": false; }; "type": { "alias": "type"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoDataGridShowModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDataGridShowModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoDataGridShowModule, never, [typeof DxoDataGridShowComponent], [typeof DxoDataGridShowComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoDataGridShowModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxiDataGridSimpleItemComponent extends CollectionNestedOption implements AfterViewInit, IDxTemplateHost {
    private renderer;
    private document;
    private element;
    set _validationRulesContentChildren(value: QueryList<CollectionNestedOption>);
    get aiOptions(): {
        disabled?: boolean;
        instruction?: string | undefined;
    };
    set aiOptions(value: {
        disabled?: boolean;
        instruction?: string | undefined;
    });
    get colSpan(): number | undefined;
    set colSpan(value: number | undefined);
    get cssClass(): string | undefined;
    set cssClass(value: string | undefined);
    get dataField(): string | undefined;
    set dataField(value: string | undefined);
    get editorOptions(): any | undefined;
    set editorOptions(value: any | undefined);
    get editorType(): FormItemComponent;
    set editorType(value: FormItemComponent);
    get helpText(): string | undefined;
    set helpText(value: string | undefined);
    get isRequired(): boolean | undefined;
    set isRequired(value: boolean | undefined);
    get itemType(): FormItemType;
    set itemType(value: FormItemType);
    get label(): {
        alignment?: HorizontalAlignment;
        location?: LabelLocation;
        showColon?: boolean;
        template?: any;
        text?: string | undefined;
        visible?: boolean;
    };
    set label(value: {
        alignment?: HorizontalAlignment;
        location?: LabelLocation;
        showColon?: boolean;
        template?: any;
        text?: string | undefined;
        visible?: boolean;
    });
    get name(): string | undefined;
    set name(value: string | undefined);
    get template(): any;
    set template(value: any);
    get validationRules(): Array<CommonTypes.ValidationRule>;
    set validationRules(value: Array<CommonTypes.ValidationRule>);
    get visible(): boolean;
    set visible(value: boolean);
    get visibleIndex(): number | undefined;
    set visibleIndex(value: number | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost, renderer: Renderer2, document: any, templateHost: DxTemplateHost, element: ElementRef);
    setTemplate(template: DxTemplateDirective): void;
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiDataGridSimpleItemComponent, [{ host: true; skipSelf: true; }, { host: true; }, null, null, { host: true; }, null]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiDataGridSimpleItemComponent, "dxi-data-grid-simple-item", never, { "aiOptions": { "alias": "aiOptions"; "required": false; }; "colSpan": { "alias": "colSpan"; "required": false; }; "cssClass": { "alias": "cssClass"; "required": false; }; "dataField": { "alias": "dataField"; "required": false; }; "editorOptions": { "alias": "editorOptions"; "required": false; }; "editorType": { "alias": "editorType"; "required": false; }; "helpText": { "alias": "helpText"; "required": false; }; "isRequired": { "alias": "isRequired"; "required": false; }; "itemType": { "alias": "itemType"; "required": false; }; "label": { "alias": "label"; "required": false; }; "name": { "alias": "name"; "required": false; }; "template": { "alias": "template"; "required": false; }; "validationRules": { "alias": "validationRules"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "visibleIndex": { "alias": "visibleIndex"; "required": false; }; }, {}, ["_validationRulesContentChildren"], ["*"], true, never>;
}
declare class DxiDataGridSimpleItemModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiDataGridSimpleItemModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiDataGridSimpleItemModule, never, [typeof DxiDataGridSimpleItemComponent], [typeof DxiDataGridSimpleItemComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiDataGridSimpleItemModule>;
}

declare class DxiDataGridSortByGroupSummaryInfoComponent extends CollectionNestedOption {
    get groupColumn(): string | undefined;
    set groupColumn(value: string | undefined);
    get sortOrder(): SortOrder | undefined;
    set sortOrder(value: SortOrder | undefined);
    get summaryItem(): number | string | undefined;
    set summaryItem(value: number | string | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiDataGridSortByGroupSummaryInfoComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiDataGridSortByGroupSummaryInfoComponent, "dxi-data-grid-sort-by-group-summary-info", never, { "groupColumn": { "alias": "groupColumn"; "required": false; }; "sortOrder": { "alias": "sortOrder"; "required": false; }; "summaryItem": { "alias": "summaryItem"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxiDataGridSortByGroupSummaryInfoModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiDataGridSortByGroupSummaryInfoModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiDataGridSortByGroupSummaryInfoModule, never, [typeof DxiDataGridSortByGroupSummaryInfoComponent], [typeof DxiDataGridSortByGroupSummaryInfoComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiDataGridSortByGroupSummaryInfoModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoDataGridSortingComponent extends NestedOption implements OnDestroy, OnInit {
    get ascendingText(): string;
    set ascendingText(value: string);
    get clearText(): string;
    set clearText(value: string);
    get descendingText(): string;
    set descendingText(value: string);
    get mode(): SingleMultipleOrNone;
    set mode(value: SingleMultipleOrNone);
    get showSortIndexes(): boolean;
    set showSortIndexes(value: boolean);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDataGridSortingComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoDataGridSortingComponent, "dxo-data-grid-sorting", never, { "ascendingText": { "alias": "ascendingText"; "required": false; }; "clearText": { "alias": "clearText"; "required": false; }; "descendingText": { "alias": "descendingText"; "required": false; }; "mode": { "alias": "mode"; "required": false; }; "showSortIndexes": { "alias": "showSortIndexes"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoDataGridSortingModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDataGridSortingModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoDataGridSortingModule, never, [typeof DxoDataGridSortingComponent], [typeof DxoDataGridSortingComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoDataGridSortingModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoDataGridStateStoringComponent extends NestedOption implements OnDestroy, OnInit {
    get customLoad(): Function;
    set customLoad(value: Function);
    get customSave(): ((gridState: any) => void);
    set customSave(value: ((gridState: any) => void));
    get enabled(): boolean;
    set enabled(value: boolean);
    get savingTimeout(): number;
    set savingTimeout(value: number);
    get storageKey(): string | undefined;
    set storageKey(value: string | undefined);
    get type(): StateStoreType;
    set type(value: StateStoreType);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDataGridStateStoringComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoDataGridStateStoringComponent, "dxo-data-grid-state-storing", never, { "customLoad": { "alias": "customLoad"; "required": false; }; "customSave": { "alias": "customSave"; "required": false; }; "enabled": { "alias": "enabled"; "required": false; }; "savingTimeout": { "alias": "savingTimeout"; "required": false; }; "storageKey": { "alias": "storageKey"; "required": false; }; "type": { "alias": "type"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoDataGridStateStoringModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDataGridStateStoringModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoDataGridStateStoringModule, never, [typeof DxoDataGridStateStoringComponent], [typeof DxoDataGridStateStoringComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoDataGridStateStoringModule>;
}

declare class DxiDataGridStringLengthRuleComponent extends CollectionNestedOption {
    get ignoreEmptyValue(): boolean;
    set ignoreEmptyValue(value: boolean);
    get max(): number;
    set max(value: number);
    get message(): string;
    set message(value: string);
    get min(): number;
    set min(value: number);
    get trim(): boolean;
    set trim(value: boolean);
    get type(): ValidationRuleType;
    set type(value: ValidationRuleType);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiDataGridStringLengthRuleComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiDataGridStringLengthRuleComponent, "dxi-data-grid-string-length-rule", never, { "ignoreEmptyValue": { "alias": "ignoreEmptyValue"; "required": false; }; "max": { "alias": "max"; "required": false; }; "message": { "alias": "message"; "required": false; }; "min": { "alias": "min"; "required": false; }; "trim": { "alias": "trim"; "required": false; }; "type": { "alias": "type"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxiDataGridStringLengthRuleModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiDataGridStringLengthRuleModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiDataGridStringLengthRuleModule, never, [typeof DxiDataGridStringLengthRuleComponent], [typeof DxiDataGridStringLengthRuleComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiDataGridStringLengthRuleModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoDataGridSummaryTextsComponent extends NestedOption implements OnDestroy, OnInit {
    get avg(): string;
    set avg(value: string);
    get avgOtherColumn(): string;
    set avgOtherColumn(value: string);
    get count(): string;
    set count(value: string);
    get max(): string;
    set max(value: string);
    get maxOtherColumn(): string;
    set maxOtherColumn(value: string);
    get min(): string;
    set min(value: string);
    get minOtherColumn(): string;
    set minOtherColumn(value: string);
    get sum(): string;
    set sum(value: string);
    get sumOtherColumn(): string;
    set sumOtherColumn(value: string);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDataGridSummaryTextsComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoDataGridSummaryTextsComponent, "dxo-data-grid-summary-texts", never, { "avg": { "alias": "avg"; "required": false; }; "avgOtherColumn": { "alias": "avgOtherColumn"; "required": false; }; "count": { "alias": "count"; "required": false; }; "max": { "alias": "max"; "required": false; }; "maxOtherColumn": { "alias": "maxOtherColumn"; "required": false; }; "min": { "alias": "min"; "required": false; }; "minOtherColumn": { "alias": "minOtherColumn"; "required": false; }; "sum": { "alias": "sum"; "required": false; }; "sumOtherColumn": { "alias": "sumOtherColumn"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoDataGridSummaryTextsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDataGridSummaryTextsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoDataGridSummaryTextsModule, never, [typeof DxoDataGridSummaryTextsComponent], [typeof DxoDataGridSummaryTextsComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoDataGridSummaryTextsModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoDataGridSummaryComponent extends NestedOption implements OnDestroy, OnInit {
    set _groupItemsContentChildren(value: QueryList<CollectionNestedOption>);
    set _totalItemsContentChildren(value: QueryList<CollectionNestedOption>);
    get calculateCustomSummary(): ((options: {
        component: dxDataGrid;
        groupIndex: number;
        name: string;
        summaryProcess: string;
        totalValue: any;
        value: any;
    }) => void);
    set calculateCustomSummary(value: ((options: {
        component: dxDataGrid;
        groupIndex: number;
        name: string;
        summaryProcess: string;
        totalValue: any;
        value: any;
    }) => void));
    get groupItems(): {
        alignByColumn?: boolean;
        column?: string | undefined;
        customizeText?: ((itemInfo: {
            value: string | number | Date;
            valueText: string;
        }) => string);
        displayFormat?: string | undefined;
        name?: string | undefined;
        showInColumn?: string | undefined;
        showInGroupFooter?: boolean;
        skipEmptyValues?: boolean;
        summaryType?: string | SummaryType | undefined;
        valueFormat?: Format | undefined;
    }[];
    set groupItems(value: {
        alignByColumn?: boolean;
        column?: string | undefined;
        customizeText?: ((itemInfo: {
            value: string | number | Date;
            valueText: string;
        }) => string);
        displayFormat?: string | undefined;
        name?: string | undefined;
        showInColumn?: string | undefined;
        showInGroupFooter?: boolean;
        skipEmptyValues?: boolean;
        summaryType?: string | SummaryType | undefined;
        valueFormat?: Format | undefined;
    }[]);
    get recalculateWhileEditing(): boolean;
    set recalculateWhileEditing(value: boolean);
    get skipEmptyValues(): boolean;
    set skipEmptyValues(value: boolean);
    get texts(): {
        avg?: string;
        avgOtherColumn?: string;
        count?: string;
        max?: string;
        maxOtherColumn?: string;
        min?: string;
        minOtherColumn?: string;
        sum?: string;
        sumOtherColumn?: string;
    };
    set texts(value: {
        avg?: string;
        avgOtherColumn?: string;
        count?: string;
        max?: string;
        maxOtherColumn?: string;
        min?: string;
        minOtherColumn?: string;
        sum?: string;
        sumOtherColumn?: string;
    });
    get totalItems(): {
        alignment?: HorizontalAlignment | undefined;
        column?: string | undefined;
        cssClass?: string | undefined;
        customizeText?: ((itemInfo: {
            value: string | number | Date;
            valueText: string;
        }) => string);
        displayFormat?: string | undefined;
        name?: string | undefined;
        showInColumn?: string | undefined;
        skipEmptyValues?: boolean;
        summaryType?: string | SummaryType | undefined;
        valueFormat?: Format | undefined;
    }[];
    set totalItems(value: {
        alignment?: HorizontalAlignment | undefined;
        column?: string | undefined;
        cssClass?: string | undefined;
        customizeText?: ((itemInfo: {
            value: string | number | Date;
            valueText: string;
        }) => string);
        displayFormat?: string | undefined;
        name?: string | undefined;
        showInColumn?: string | undefined;
        skipEmptyValues?: boolean;
        summaryType?: string | SummaryType | undefined;
        valueFormat?: Format | undefined;
    }[]);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDataGridSummaryComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoDataGridSummaryComponent, "dxo-data-grid-summary", never, { "calculateCustomSummary": { "alias": "calculateCustomSummary"; "required": false; }; "groupItems": { "alias": "groupItems"; "required": false; }; "recalculateWhileEditing": { "alias": "recalculateWhileEditing"; "required": false; }; "skipEmptyValues": { "alias": "skipEmptyValues"; "required": false; }; "texts": { "alias": "texts"; "required": false; }; "totalItems": { "alias": "totalItems"; "required": false; }; }, {}, ["_groupItemsContentChildren", "_totalItemsContentChildren"], never, true, never>;
}
declare class DxoDataGridSummaryModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDataGridSummaryModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoDataGridSummaryModule, never, [typeof DxoDataGridSummaryComponent], [typeof DxoDataGridSummaryComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoDataGridSummaryModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxiDataGridTabComponent extends CollectionNestedOption implements AfterViewInit, IDxTemplateHost {
    private renderer;
    private document;
    private element;
    set _itemsContentChildren(value: QueryList<CollectionNestedOption>);
    get alignItemLabels(): boolean;
    set alignItemLabels(value: boolean);
    get badge(): string | undefined;
    set badge(value: string | undefined);
    get colCount(): number;
    set colCount(value: number);
    get colCountByScreen(): {
        lg?: number | undefined;
        md?: number | undefined;
        sm?: number | undefined;
        xs?: number | undefined;
    };
    set colCountByScreen(value: {
        lg?: number | undefined;
        md?: number | undefined;
        sm?: number | undefined;
        xs?: number | undefined;
    });
    get disabled(): boolean;
    set disabled(value: boolean);
    get icon(): string | undefined;
    set icon(value: string | undefined);
    get items(): Array<dxFormButtonItem | dxFormEmptyItem | dxFormGroupItem | dxFormSimpleItem | dxFormTabbedItem>;
    set items(value: Array<dxFormButtonItem | dxFormEmptyItem | dxFormGroupItem | dxFormSimpleItem | dxFormTabbedItem>);
    get tabTemplate(): any;
    set tabTemplate(value: any);
    get template(): any;
    set template(value: any);
    get title(): string | undefined;
    set title(value: string | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost, renderer: Renderer2, document: any, templateHost: DxTemplateHost, element: ElementRef);
    setTemplate(template: DxTemplateDirective): void;
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiDataGridTabComponent, [{ host: true; skipSelf: true; }, { host: true; }, null, null, { host: true; }, null]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiDataGridTabComponent, "dxi-data-grid-tab", never, { "alignItemLabels": { "alias": "alignItemLabels"; "required": false; }; "badge": { "alias": "badge"; "required": false; }; "colCount": { "alias": "colCount"; "required": false; }; "colCountByScreen": { "alias": "colCountByScreen"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "icon": { "alias": "icon"; "required": false; }; "items": { "alias": "items"; "required": false; }; "tabTemplate": { "alias": "tabTemplate"; "required": false; }; "template": { "alias": "template"; "required": false; }; "title": { "alias": "title"; "required": false; }; }, {}, ["_itemsContentChildren"], ["*"], true, never>;
}
declare class DxiDataGridTabModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiDataGridTabModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiDataGridTabModule, never, [typeof DxiDataGridTabComponent], [typeof DxiDataGridTabComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiDataGridTabModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxiDataGridTabPanelOptionsItemComponent extends CollectionNestedOption implements AfterViewInit, IDxTemplateHost {
    private renderer;
    private document;
    private element;
    get badge(): string;
    set badge(value: string);
    get disabled(): boolean;
    set disabled(value: boolean);
    get html(): string;
    set html(value: string);
    get icon(): string;
    set icon(value: string);
    get tabTemplate(): any;
    set tabTemplate(value: any);
    get template(): any;
    set template(value: any);
    get text(): string;
    set text(value: string);
    get title(): string;
    set title(value: string);
    get visible(): boolean;
    set visible(value: boolean);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost, renderer: Renderer2, document: any, templateHost: DxTemplateHost, element: ElementRef);
    setTemplate(template: DxTemplateDirective): void;
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiDataGridTabPanelOptionsItemComponent, [{ host: true; skipSelf: true; }, { host: true; }, null, null, { host: true; }, null]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiDataGridTabPanelOptionsItemComponent, "dxi-data-grid-tab-panel-options-item", never, { "badge": { "alias": "badge"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "html": { "alias": "html"; "required": false; }; "icon": { "alias": "icon"; "required": false; }; "tabTemplate": { "alias": "tabTemplate"; "required": false; }; "template": { "alias": "template"; "required": false; }; "text": { "alias": "text"; "required": false; }; "title": { "alias": "title"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; }, {}, never, ["*"], true, never>;
}
declare class DxiDataGridTabPanelOptionsItemModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiDataGridTabPanelOptionsItemModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiDataGridTabPanelOptionsItemModule, never, [typeof DxiDataGridTabPanelOptionsItemComponent], [typeof DxiDataGridTabPanelOptionsItemComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiDataGridTabPanelOptionsItemModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoDataGridTabPanelOptionsComponent extends NestedOption implements OnDestroy, OnInit {
    set _itemsContentChildren(value: QueryList<CollectionNestedOption>);
    get accessKey(): string | undefined;
    set accessKey(value: string | undefined);
    get activeStateEnabled(): boolean;
    set activeStateEnabled(value: boolean);
    get animationEnabled(): boolean;
    set animationEnabled(value: boolean);
    get dataSource(): Array<any | dxTabPanelItem | string> | DataSource | DataSourceOptions | null | Store | string;
    set dataSource(value: Array<any | dxTabPanelItem | string> | DataSource | DataSourceOptions | null | Store | string);
    get deferRendering(): boolean;
    set deferRendering(value: boolean);
    get disabled(): boolean;
    set disabled(value: boolean);
    get elementAttr(): Record<string, any>;
    set elementAttr(value: Record<string, any>);
    get focusStateEnabled(): boolean;
    set focusStateEnabled(value: boolean);
    get height(): number | string | undefined;
    set height(value: number | string | undefined);
    get hint(): string | undefined;
    set hint(value: string | undefined);
    get hoverStateEnabled(): boolean;
    set hoverStateEnabled(value: boolean);
    get iconPosition(): TabsIconPosition;
    set iconPosition(value: TabsIconPosition);
    get itemHoldTimeout(): number;
    set itemHoldTimeout(value: number);
    get items(): Array<any | dxTabPanelItem | string>;
    set items(value: Array<any | dxTabPanelItem | string>);
    get itemTemplate(): any;
    set itemTemplate(value: any);
    get itemTitleTemplate(): any;
    set itemTitleTemplate(value: any);
    get keyExpr(): ((item: any) => any) | string;
    set keyExpr(value: ((item: any) => any) | string);
    get loop(): boolean;
    set loop(value: boolean);
    get noDataText(): string;
    set noDataText(value: string);
    get onContentReady(): ((e: ContentReadyEvent$4) => void);
    set onContentReady(value: ((e: ContentReadyEvent$4) => void));
    get onDisposing(): ((e: DisposingEvent$4) => void);
    set onDisposing(value: ((e: DisposingEvent$4) => void));
    get onInitialized(): ((e: InitializedEvent$4) => void);
    set onInitialized(value: ((e: InitializedEvent$4) => void));
    get onItemClick(): ((e: ItemClickEvent) => void);
    set onItemClick(value: ((e: ItemClickEvent) => void));
    get onItemContextMenu(): ((e: ItemContextMenuEvent) => void);
    set onItemContextMenu(value: ((e: ItemContextMenuEvent) => void));
    get onItemHold(): ((e: ItemHoldEvent) => void);
    set onItemHold(value: ((e: ItemHoldEvent) => void));
    get onItemRendered(): ((e: ItemRenderedEvent) => void);
    set onItemRendered(value: ((e: ItemRenderedEvent) => void));
    get onOptionChanged(): ((e: OptionChangedEvent$4) => void);
    set onOptionChanged(value: ((e: OptionChangedEvent$4) => void));
    get onSelectionChanged(): ((e: SelectionChangedEvent) => void);
    set onSelectionChanged(value: ((e: SelectionChangedEvent) => void));
    get onSelectionChanging(): ((e: SelectionChangingEvent) => void);
    set onSelectionChanging(value: ((e: SelectionChangingEvent) => void));
    get onTitleClick(): ((e: TitleClickEvent) => void);
    set onTitleClick(value: ((e: TitleClickEvent) => void));
    get onTitleHold(): ((e: TitleHoldEvent) => void) | undefined;
    set onTitleHold(value: ((e: TitleHoldEvent) => void) | undefined);
    get onTitleRendered(): ((e: TitleRenderedEvent) => void) | undefined;
    set onTitleRendered(value: ((e: TitleRenderedEvent) => void) | undefined);
    get repaintChangesOnly(): boolean;
    set repaintChangesOnly(value: boolean);
    get rtlEnabled(): boolean;
    set rtlEnabled(value: boolean);
    get scrollByContent(): boolean;
    set scrollByContent(value: boolean);
    get scrollingEnabled(): boolean;
    set scrollingEnabled(value: boolean);
    get selectedIndex(): number;
    set selectedIndex(value: number);
    get selectedItem(): any | null;
    set selectedItem(value: any | null);
    get showNavButtons(): boolean;
    set showNavButtons(value: boolean);
    get stylingMode(): TabsStyle;
    set stylingMode(value: TabsStyle);
    get swipeEnabled(): boolean;
    set swipeEnabled(value: boolean);
    get tabIndex(): number;
    set tabIndex(value: number);
    get tabsPosition(): Position;
    set tabsPosition(value: Position);
    get visible(): boolean;
    set visible(value: boolean);
    get width(): number | string | undefined;
    set width(value: number | string | undefined);
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    itemsChange: EventEmitter<Array<any | dxTabPanelItem | string>>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    selectedIndexChange: EventEmitter<number>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    selectedItemChange: EventEmitter<any | null>;
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDataGridTabPanelOptionsComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoDataGridTabPanelOptionsComponent, "dxo-data-grid-tab-panel-options", never, { "accessKey": { "alias": "accessKey"; "required": false; }; "activeStateEnabled": { "alias": "activeStateEnabled"; "required": false; }; "animationEnabled": { "alias": "animationEnabled"; "required": false; }; "dataSource": { "alias": "dataSource"; "required": false; }; "deferRendering": { "alias": "deferRendering"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "elementAttr": { "alias": "elementAttr"; "required": false; }; "focusStateEnabled": { "alias": "focusStateEnabled"; "required": false; }; "height": { "alias": "height"; "required": false; }; "hint": { "alias": "hint"; "required": false; }; "hoverStateEnabled": { "alias": "hoverStateEnabled"; "required": false; }; "iconPosition": { "alias": "iconPosition"; "required": false; }; "itemHoldTimeout": { "alias": "itemHoldTimeout"; "required": false; }; "items": { "alias": "items"; "required": false; }; "itemTemplate": { "alias": "itemTemplate"; "required": false; }; "itemTitleTemplate": { "alias": "itemTitleTemplate"; "required": false; }; "keyExpr": { "alias": "keyExpr"; "required": false; }; "loop": { "alias": "loop"; "required": false; }; "noDataText": { "alias": "noDataText"; "required": false; }; "onContentReady": { "alias": "onContentReady"; "required": false; }; "onDisposing": { "alias": "onDisposing"; "required": false; }; "onInitialized": { "alias": "onInitialized"; "required": false; }; "onItemClick": { "alias": "onItemClick"; "required": false; }; "onItemContextMenu": { "alias": "onItemContextMenu"; "required": false; }; "onItemHold": { "alias": "onItemHold"; "required": false; }; "onItemRendered": { "alias": "onItemRendered"; "required": false; }; "onOptionChanged": { "alias": "onOptionChanged"; "required": false; }; "onSelectionChanged": { "alias": "onSelectionChanged"; "required": false; }; "onSelectionChanging": { "alias": "onSelectionChanging"; "required": false; }; "onTitleClick": { "alias": "onTitleClick"; "required": false; }; "onTitleHold": { "alias": "onTitleHold"; "required": false; }; "onTitleRendered": { "alias": "onTitleRendered"; "required": false; }; "repaintChangesOnly": { "alias": "repaintChangesOnly"; "required": false; }; "rtlEnabled": { "alias": "rtlEnabled"; "required": false; }; "scrollByContent": { "alias": "scrollByContent"; "required": false; }; "scrollingEnabled": { "alias": "scrollingEnabled"; "required": false; }; "selectedIndex": { "alias": "selectedIndex"; "required": false; }; "selectedItem": { "alias": "selectedItem"; "required": false; }; "showNavButtons": { "alias": "showNavButtons"; "required": false; }; "stylingMode": { "alias": "stylingMode"; "required": false; }; "swipeEnabled": { "alias": "swipeEnabled"; "required": false; }; "tabIndex": { "alias": "tabIndex"; "required": false; }; "tabsPosition": { "alias": "tabsPosition"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, { "itemsChange": "itemsChange"; "selectedIndexChange": "selectedIndexChange"; "selectedItemChange": "selectedItemChange"; }, ["_itemsContentChildren"], never, true, never>;
}
declare class DxoDataGridTabPanelOptionsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDataGridTabPanelOptionsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoDataGridTabPanelOptionsModule, never, [typeof DxoDataGridTabPanelOptionsComponent], [typeof DxoDataGridTabPanelOptionsComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoDataGridTabPanelOptionsModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxiDataGridTabbedItemComponent extends CollectionNestedOption {
    set _tabsContentChildren(value: QueryList<CollectionNestedOption>);
    get colSpan(): number | undefined;
    set colSpan(value: number | undefined);
    get cssClass(): string | undefined;
    set cssClass(value: string | undefined);
    get itemType(): FormItemType;
    set itemType(value: FormItemType);
    get name(): string | undefined;
    set name(value: string | undefined);
    get tabPanelOptions(): dxTabPanelOptions | undefined;
    set tabPanelOptions(value: dxTabPanelOptions | undefined);
    get tabs(): {
        alignItemLabels?: boolean;
        badge?: string | undefined;
        colCount?: number;
        colCountByScreen?: {
            lg?: number | undefined;
            md?: number | undefined;
            sm?: number | undefined;
            xs?: number | undefined;
        };
        disabled?: boolean;
        icon?: string | undefined;
        items?: Array<dxFormButtonItem | dxFormEmptyItem | dxFormGroupItem | dxFormSimpleItem | dxFormTabbedItem>;
        tabTemplate?: any;
        template?: any;
        title?: string | undefined;
    }[];
    set tabs(value: {
        alignItemLabels?: boolean;
        badge?: string | undefined;
        colCount?: number;
        colCountByScreen?: {
            lg?: number | undefined;
            md?: number | undefined;
            sm?: number | undefined;
            xs?: number | undefined;
        };
        disabled?: boolean;
        icon?: string | undefined;
        items?: Array<dxFormButtonItem | dxFormEmptyItem | dxFormGroupItem | dxFormSimpleItem | dxFormTabbedItem>;
        tabTemplate?: any;
        template?: any;
        title?: string | undefined;
    }[]);
    get visible(): boolean;
    set visible(value: boolean);
    get visibleIndex(): number | undefined;
    set visibleIndex(value: number | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiDataGridTabbedItemComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiDataGridTabbedItemComponent, "dxi-data-grid-tabbed-item", never, { "colSpan": { "alias": "colSpan"; "required": false; }; "cssClass": { "alias": "cssClass"; "required": false; }; "itemType": { "alias": "itemType"; "required": false; }; "name": { "alias": "name"; "required": false; }; "tabPanelOptions": { "alias": "tabPanelOptions"; "required": false; }; "tabs": { "alias": "tabs"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "visibleIndex": { "alias": "visibleIndex"; "required": false; }; }, {}, ["_tabsContentChildren"], never, true, never>;
}
declare class DxiDataGridTabbedItemModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiDataGridTabbedItemModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiDataGridTabbedItemModule, never, [typeof DxiDataGridTabbedItemComponent], [typeof DxiDataGridTabbedItemComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiDataGridTabbedItemModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoDataGridTextsComponent extends NestedOption implements OnDestroy, OnInit {
    get addRow(): string;
    set addRow(value: string);
    get cancelAllChanges(): string;
    set cancelAllChanges(value: string);
    get cancelRowChanges(): string;
    set cancelRowChanges(value: string);
    get confirmDeleteMessage(): string;
    set confirmDeleteMessage(value: string);
    get confirmDeleteTitle(): string;
    set confirmDeleteTitle(value: string);
    get deleteRow(): string;
    set deleteRow(value: string);
    get editRow(): string;
    set editRow(value: string);
    get saveAllChanges(): string;
    set saveAllChanges(value: string);
    get saveRowChanges(): string;
    set saveRowChanges(value: string);
    get undeleteRow(): string;
    set undeleteRow(value: string);
    get validationCancelChanges(): string;
    set validationCancelChanges(value: string);
    get exportAll(): string;
    set exportAll(value: string);
    get exportSelectedRows(): string;
    set exportSelectedRows(value: string);
    get exportTo(): string;
    set exportTo(value: string);
    get groupByThisColumn(): string;
    set groupByThisColumn(value: string);
    get groupContinuedMessage(): string;
    set groupContinuedMessage(value: string);
    get groupContinuesMessage(): string;
    set groupContinuesMessage(value: string);
    get ungroup(): string;
    set ungroup(value: string);
    get ungroupAll(): string;
    set ungroupAll(value: string);
    get avg(): string;
    set avg(value: string);
    get avgOtherColumn(): string;
    set avgOtherColumn(value: string);
    get count(): string;
    set count(value: string);
    get max(): string;
    set max(value: string);
    get maxOtherColumn(): string;
    set maxOtherColumn(value: string);
    get min(): string;
    set min(value: string);
    get minOtherColumn(): string;
    set minOtherColumn(value: string);
    get sum(): string;
    set sum(value: string);
    get sumOtherColumn(): string;
    set sumOtherColumn(value: string);
    get fix(): string;
    set fix(value: string);
    get leftPosition(): string;
    set leftPosition(value: string);
    get rightPosition(): string;
    set rightPosition(value: string);
    get stickyPosition(): string;
    set stickyPosition(value: string);
    get unfix(): string;
    set unfix(value: string);
    get clearFilter(): string;
    set clearFilter(value: string);
    get createFilter(): string;
    set createFilter(value: string);
    get filterEnabledHint(): string;
    set filterEnabledHint(value: string);
    get cancel(): string;
    set cancel(value: string);
    get emptyValue(): string;
    set emptyValue(value: string);
    get ok(): string;
    set ok(value: string);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDataGridTextsComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoDataGridTextsComponent, "dxo-data-grid-texts", never, { "addRow": { "alias": "addRow"; "required": false; }; "cancelAllChanges": { "alias": "cancelAllChanges"; "required": false; }; "cancelRowChanges": { "alias": "cancelRowChanges"; "required": false; }; "confirmDeleteMessage": { "alias": "confirmDeleteMessage"; "required": false; }; "confirmDeleteTitle": { "alias": "confirmDeleteTitle"; "required": false; }; "deleteRow": { "alias": "deleteRow"; "required": false; }; "editRow": { "alias": "editRow"; "required": false; }; "saveAllChanges": { "alias": "saveAllChanges"; "required": false; }; "saveRowChanges": { "alias": "saveRowChanges"; "required": false; }; "undeleteRow": { "alias": "undeleteRow"; "required": false; }; "validationCancelChanges": { "alias": "validationCancelChanges"; "required": false; }; "exportAll": { "alias": "exportAll"; "required": false; }; "exportSelectedRows": { "alias": "exportSelectedRows"; "required": false; }; "exportTo": { "alias": "exportTo"; "required": false; }; "groupByThisColumn": { "alias": "groupByThisColumn"; "required": false; }; "groupContinuedMessage": { "alias": "groupContinuedMessage"; "required": false; }; "groupContinuesMessage": { "alias": "groupContinuesMessage"; "required": false; }; "ungroup": { "alias": "ungroup"; "required": false; }; "ungroupAll": { "alias": "ungroupAll"; "required": false; }; "avg": { "alias": "avg"; "required": false; }; "avgOtherColumn": { "alias": "avgOtherColumn"; "required": false; }; "count": { "alias": "count"; "required": false; }; "max": { "alias": "max"; "required": false; }; "maxOtherColumn": { "alias": "maxOtherColumn"; "required": false; }; "min": { "alias": "min"; "required": false; }; "minOtherColumn": { "alias": "minOtherColumn"; "required": false; }; "sum": { "alias": "sum"; "required": false; }; "sumOtherColumn": { "alias": "sumOtherColumn"; "required": false; }; "fix": { "alias": "fix"; "required": false; }; "leftPosition": { "alias": "leftPosition"; "required": false; }; "rightPosition": { "alias": "rightPosition"; "required": false; }; "stickyPosition": { "alias": "stickyPosition"; "required": false; }; "unfix": { "alias": "unfix"; "required": false; }; "clearFilter": { "alias": "clearFilter"; "required": false; }; "createFilter": { "alias": "createFilter"; "required": false; }; "filterEnabledHint": { "alias": "filterEnabledHint"; "required": false; }; "cancel": { "alias": "cancel"; "required": false; }; "emptyValue": { "alias": "emptyValue"; "required": false; }; "ok": { "alias": "ok"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoDataGridTextsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDataGridTextsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoDataGridTextsModule, never, [typeof DxoDataGridTextsComponent], [typeof DxoDataGridTextsComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoDataGridTextsModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoDataGridToComponent extends NestedOption implements OnDestroy, OnInit {
    get left(): number;
    set left(value: number);
    get opacity(): number;
    set opacity(value: number);
    get position(): PositionConfig;
    set position(value: PositionConfig);
    get scale(): number;
    set scale(value: number);
    get top(): number;
    set top(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDataGridToComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoDataGridToComponent, "dxo-data-grid-to", never, { "left": { "alias": "left"; "required": false; }; "opacity": { "alias": "opacity"; "required": false; }; "position": { "alias": "position"; "required": false; }; "scale": { "alias": "scale"; "required": false; }; "top": { "alias": "top"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoDataGridToModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDataGridToModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoDataGridToModule, never, [typeof DxoDataGridToComponent], [typeof DxoDataGridToComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoDataGridToModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxiDataGridToolbarItemComponent extends CollectionNestedOption implements AfterViewInit, IDxTemplateHost {
    private renderer;
    private document;
    private element;
    get cssClass(): string | undefined;
    set cssClass(value: string | undefined);
    get disabled(): boolean;
    set disabled(value: boolean);
    get html(): string;
    set html(value: string);
    get locateInMenu(): LocateInMenuMode;
    set locateInMenu(value: LocateInMenuMode);
    get location(): ToolbarItemLocation;
    set location(value: ToolbarItemLocation);
    get menuItemTemplate(): any;
    set menuItemTemplate(value: any);
    get options(): any;
    set options(value: any);
    get showText(): ShowTextMode;
    set showText(value: ShowTextMode);
    get template(): any;
    set template(value: any);
    get text(): string;
    set text(value: string);
    get toolbar(): ToolbarLocation;
    set toolbar(value: ToolbarLocation);
    get visible(): boolean;
    set visible(value: boolean);
    get widget(): ToolbarItemComponent;
    set widget(value: ToolbarItemComponent);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost, renderer: Renderer2, document: any, templateHost: DxTemplateHost, element: ElementRef);
    setTemplate(template: DxTemplateDirective): void;
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiDataGridToolbarItemComponent, [{ host: true; skipSelf: true; }, { host: true; }, null, null, { host: true; }, null]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiDataGridToolbarItemComponent, "dxi-data-grid-toolbar-item", never, { "cssClass": { "alias": "cssClass"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "html": { "alias": "html"; "required": false; }; "locateInMenu": { "alias": "locateInMenu"; "required": false; }; "location": { "alias": "location"; "required": false; }; "menuItemTemplate": { "alias": "menuItemTemplate"; "required": false; }; "options": { "alias": "options"; "required": false; }; "showText": { "alias": "showText"; "required": false; }; "template": { "alias": "template"; "required": false; }; "text": { "alias": "text"; "required": false; }; "toolbar": { "alias": "toolbar"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "widget": { "alias": "widget"; "required": false; }; }, {}, never, ["*"], true, never>;
}
declare class DxiDataGridToolbarItemModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiDataGridToolbarItemModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiDataGridToolbarItemModule, never, [typeof DxiDataGridToolbarItemComponent], [typeof DxiDataGridToolbarItemComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiDataGridToolbarItemModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoDataGridToolbarComponent extends NestedOption implements OnDestroy, OnInit {
    set _itemsContentChildren(value: QueryList<CollectionNestedOption>);
    get disabled(): boolean;
    set disabled(value: boolean);
    get items(): Array<DataGridPredefinedToolbarItem | dxDataGridToolbarItem>;
    set items(value: Array<DataGridPredefinedToolbarItem | dxDataGridToolbarItem>);
    get visible(): boolean | undefined;
    set visible(value: boolean | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDataGridToolbarComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoDataGridToolbarComponent, "dxo-data-grid-toolbar", never, { "disabled": { "alias": "disabled"; "required": false; }; "items": { "alias": "items"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; }, {}, ["_itemsContentChildren"], never, true, never>;
}
declare class DxoDataGridToolbarModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDataGridToolbarModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoDataGridToolbarModule, never, [typeof DxoDataGridToolbarComponent], [typeof DxoDataGridToolbarComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoDataGridToolbarModule>;
}

declare class DxiDataGridTotalItemComponent extends CollectionNestedOption {
    get alignment(): HorizontalAlignment | undefined;
    set alignment(value: HorizontalAlignment | undefined);
    get column(): string | undefined;
    set column(value: string | undefined);
    get cssClass(): string | undefined;
    set cssClass(value: string | undefined);
    get customizeText(): ((itemInfo: {
        value: string | number | Date;
        valueText: string;
    }) => string);
    set customizeText(value: ((itemInfo: {
        value: string | number | Date;
        valueText: string;
    }) => string));
    get displayFormat(): string | undefined;
    set displayFormat(value: string | undefined);
    get name(): string | undefined;
    set name(value: string | undefined);
    get showInColumn(): string | undefined;
    set showInColumn(value: string | undefined);
    get skipEmptyValues(): boolean;
    set skipEmptyValues(value: boolean);
    get summaryType(): string | SummaryType | undefined;
    set summaryType(value: string | SummaryType | undefined);
    get valueFormat(): Format | undefined;
    set valueFormat(value: Format | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiDataGridTotalItemComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiDataGridTotalItemComponent, "dxi-data-grid-total-item", never, { "alignment": { "alias": "alignment"; "required": false; }; "column": { "alias": "column"; "required": false; }; "cssClass": { "alias": "cssClass"; "required": false; }; "customizeText": { "alias": "customizeText"; "required": false; }; "displayFormat": { "alias": "displayFormat"; "required": false; }; "name": { "alias": "name"; "required": false; }; "showInColumn": { "alias": "showInColumn"; "required": false; }; "skipEmptyValues": { "alias": "skipEmptyValues"; "required": false; }; "summaryType": { "alias": "summaryType"; "required": false; }; "valueFormat": { "alias": "valueFormat"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxiDataGridTotalItemModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiDataGridTotalItemModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiDataGridTotalItemModule, never, [typeof DxiDataGridTotalItemComponent], [typeof DxiDataGridTotalItemComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiDataGridTotalItemModule>;
}

declare class DxiDataGridValidationRuleComponent extends CollectionNestedOption {
    get message(): string;
    set message(value: string);
    get trim(): boolean;
    set trim(value: boolean);
    get type(): ValidationRuleType;
    set type(value: ValidationRuleType);
    get ignoreEmptyValue(): boolean;
    set ignoreEmptyValue(value: boolean);
    get max(): Date | number | string;
    set max(value: Date | number | string);
    get min(): Date | number | string;
    set min(value: Date | number | string);
    get reevaluate(): boolean;
    set reevaluate(value: boolean);
    get validationCallback(): ((options: {
        column: Record<string, any>;
        data: Record<string, any>;
        formItem: Record<string, any>;
        rule: Record<string, any>;
        validator: Record<string, any>;
        value: any;
    }) => boolean);
    set validationCallback(value: ((options: {
        column: Record<string, any>;
        data: Record<string, any>;
        formItem: Record<string, any>;
        rule: Record<string, any>;
        validator: Record<string, any>;
        value: any;
    }) => boolean));
    get comparisonTarget(): Function;
    set comparisonTarget(value: Function);
    get comparisonType(): ComparisonOperator;
    set comparisonType(value: ComparisonOperator);
    get pattern(): RegExp | string;
    set pattern(value: RegExp | string);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiDataGridValidationRuleComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiDataGridValidationRuleComponent, "dxi-data-grid-validation-rule", never, { "message": { "alias": "message"; "required": false; }; "trim": { "alias": "trim"; "required": false; }; "type": { "alias": "type"; "required": false; }; "ignoreEmptyValue": { "alias": "ignoreEmptyValue"; "required": false; }; "max": { "alias": "max"; "required": false; }; "min": { "alias": "min"; "required": false; }; "reevaluate": { "alias": "reevaluate"; "required": false; }; "validationCallback": { "alias": "validationCallback"; "required": false; }; "comparisonTarget": { "alias": "comparisonTarget"; "required": false; }; "comparisonType": { "alias": "comparisonType"; "required": false; }; "pattern": { "alias": "pattern"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxiDataGridValidationRuleModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiDataGridValidationRuleModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiDataGridValidationRuleModule, never, [typeof DxiDataGridValidationRuleComponent], [typeof DxiDataGridValidationRuleComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiDataGridValidationRuleModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoDataGridValueFormatComponent extends NestedOption implements OnDestroy, OnInit {
    get currency(): string;
    set currency(value: string);
    get formatter(): ((value: number | Date) => string);
    set formatter(value: ((value: number | Date) => string));
    get parser(): ((value: string) => number | Date);
    set parser(value: ((value: string) => number | Date));
    get precision(): number;
    set precision(value: number);
    get type(): Format$1 | string;
    set type(value: Format$1 | string);
    get useCurrencyAccountingStyle(): boolean;
    set useCurrencyAccountingStyle(value: boolean);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDataGridValueFormatComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoDataGridValueFormatComponent, "dxo-data-grid-value-format", never, { "currency": { "alias": "currency"; "required": false; }; "formatter": { "alias": "formatter"; "required": false; }; "parser": { "alias": "parser"; "required": false; }; "precision": { "alias": "precision"; "required": false; }; "type": { "alias": "type"; "required": false; }; "useCurrencyAccountingStyle": { "alias": "useCurrencyAccountingStyle"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoDataGridValueFormatModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoDataGridValueFormatModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoDataGridValueFormatModule, never, [typeof DxoDataGridValueFormatComponent], [typeof DxoDataGridValueFormatComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoDataGridValueFormatModule>;
}

export { DxiDataGridAsyncRuleComponent, DxiDataGridAsyncRuleModule, DxiDataGridButtonComponent, DxiDataGridButtonItemComponent, DxiDataGridButtonItemModule, DxiDataGridButtonModule, DxiDataGridChangeComponent, DxiDataGridChangeModule, DxiDataGridColumnButtonComponent, DxiDataGridColumnButtonModule, DxiDataGridColumnComponent, DxiDataGridColumnModule, DxiDataGridCompareRuleComponent, DxiDataGridCompareRuleModule, DxiDataGridCustomOperationComponent, DxiDataGridCustomOperationModule, DxiDataGridCustomRuleComponent, DxiDataGridCustomRuleModule, DxiDataGridDataGridToolbarItemComponent, DxiDataGridDataGridToolbarItemModule, DxiDataGridEditorOptionsButtonComponent, DxiDataGridEditorOptionsButtonModule, DxiDataGridEmailRuleComponent, DxiDataGridEmailRuleModule, DxiDataGridEmptyItemComponent, DxiDataGridEmptyItemModule, DxiDataGridFieldComponent, DxiDataGridFieldModule, DxiDataGridFormGroupItemComponent, DxiDataGridFormGroupItemModule, DxiDataGridGroupItemComponent, DxiDataGridGroupItemModule, DxiDataGridItemComponent, DxiDataGridItemModule, DxiDataGridNumericRuleComponent, DxiDataGridNumericRuleModule, DxiDataGridPatternRuleComponent, DxiDataGridPatternRuleModule, DxiDataGridRangeRuleComponent, DxiDataGridRangeRuleModule, DxiDataGridRequiredRuleComponent, DxiDataGridRequiredRuleModule, DxiDataGridSimpleItemComponent, DxiDataGridSimpleItemModule, DxiDataGridSortByGroupSummaryInfoComponent, DxiDataGridSortByGroupSummaryInfoModule, DxiDataGridStringLengthRuleComponent, DxiDataGridStringLengthRuleModule, DxiDataGridTabComponent, DxiDataGridTabModule, DxiDataGridTabPanelOptionsItemComponent, DxiDataGridTabPanelOptionsItemModule, DxiDataGridTabbedItemComponent, DxiDataGridTabbedItemModule, DxiDataGridToolbarItemComponent, DxiDataGridToolbarItemModule, DxiDataGridTotalItemComponent, DxiDataGridTotalItemModule, DxiDataGridValidationRuleComponent, DxiDataGridValidationRuleModule, DxoDataGridAIAssistantComponent, DxoDataGridAIAssistantModule, DxoDataGridAIComponent, DxoDataGridAIModule, DxoDataGridAIOptionsComponent, DxoDataGridAIOptionsModule, DxoDataGridAnimationComponent, DxoDataGridAnimationModule, DxoDataGridAtComponent, DxoDataGridAtModule, DxoDataGridBoundaryOffsetComponent, DxoDataGridBoundaryOffsetModule, DxoDataGridButtonOptionsComponent, DxoDataGridButtonOptionsModule, DxoDataGridColCountByScreenComponent, DxoDataGridColCountByScreenModule, DxoDataGridCollisionComponent, DxoDataGridCollisionModule, DxoDataGridColumnChooserComponent, DxoDataGridColumnChooserModule, DxoDataGridColumnChooserSearchComponent, DxoDataGridColumnChooserSearchModule, DxoDataGridColumnChooserSelectionComponent, DxoDataGridColumnChooserSelectionModule, DxoDataGridColumnFixingComponent, DxoDataGridColumnFixingModule, DxoDataGridColumnFixingTextsComponent, DxoDataGridColumnFixingTextsModule, DxoDataGridColumnHeaderFilterComponent, DxoDataGridColumnHeaderFilterModule, DxoDataGridColumnHeaderFilterSearchComponent, DxoDataGridColumnHeaderFilterSearchModule, DxoDataGridColumnLookupComponent, DxoDataGridColumnLookupModule, DxoDataGridCursorOffsetComponent, DxoDataGridCursorOffsetModule, DxoDataGridDataGridHeaderFilterComponent, DxoDataGridDataGridHeaderFilterModule, DxoDataGridDataGridHeaderFilterSearchComponent, DxoDataGridDataGridHeaderFilterSearchModule, DxoDataGridDataGridHeaderFilterTextsComponent, DxoDataGridDataGridHeaderFilterTextsModule, DxoDataGridDataGridSelectionComponent, DxoDataGridDataGridSelectionModule, DxoDataGridEditingComponent, DxoDataGridEditingModule, DxoDataGridEditingTextsComponent, DxoDataGridEditingTextsModule, DxoDataGridEditorOptionsComponent, DxoDataGridEditorOptionsModule, DxoDataGridExportComponent, DxoDataGridExportModule, DxoDataGridExportTextsComponent, DxoDataGridExportTextsModule, DxoDataGridFieldLookupComponent, DxoDataGridFieldLookupModule, DxoDataGridFilterBuilderComponent, DxoDataGridFilterBuilderModule, DxoDataGridFilterBuilderPopupComponent, DxoDataGridFilterBuilderPopupModule, DxoDataGridFilterOperationDescriptionsComponent, DxoDataGridFilterOperationDescriptionsModule, DxoDataGridFilterPanelComponent, DxoDataGridFilterPanelModule, DxoDataGridFilterPanelTextsComponent, DxoDataGridFilterPanelTextsModule, DxoDataGridFilterRowComponent, DxoDataGridFilterRowModule, DxoDataGridFormComponent, DxoDataGridFormItemComponent, DxoDataGridFormItemModule, DxoDataGridFormModule, DxoDataGridFormatComponent, DxoDataGridFormatModule, DxoDataGridFromComponent, DxoDataGridFromModule, DxoDataGridGroupOperationDescriptionsComponent, DxoDataGridGroupOperationDescriptionsModule, DxoDataGridGroupPanelComponent, DxoDataGridGroupPanelModule, DxoDataGridGroupingComponent, DxoDataGridGroupingModule, DxoDataGridGroupingTextsComponent, DxoDataGridGroupingTextsModule, DxoDataGridHeaderFilterComponent, DxoDataGridHeaderFilterModule, DxoDataGridHideComponent, DxoDataGridHideModule, DxoDataGridIconsComponent, DxoDataGridIconsModule, DxoDataGridIndicatorOptionsComponent, DxoDataGridIndicatorOptionsModule, DxoDataGridKeyboardNavigationComponent, DxoDataGridKeyboardNavigationModule, DxoDataGridLabelComponent, DxoDataGridLabelModule, DxoDataGridLoadPanelComponent, DxoDataGridLoadPanelModule, DxoDataGridLookupComponent, DxoDataGridLookupModule, DxoDataGridMasterDetailComponent, DxoDataGridMasterDetailModule, DxoDataGridMyComponent, DxoDataGridMyModule, DxoDataGridOffsetComponent, DxoDataGridOffsetModule, DxoDataGridOperationDescriptionsComponent, DxoDataGridOperationDescriptionsModule, DxoDataGridOptionsComponent, DxoDataGridOptionsModule, DxoDataGridPagerComponent, DxoDataGridPagerModule, DxoDataGridPagingComponent, DxoDataGridPagingModule, DxoDataGridPopupComponent, DxoDataGridPopupModule, DxoDataGridPositionComponent, DxoDataGridPositionModule, DxoDataGridRemoteOperationsComponent, DxoDataGridRemoteOperationsModule, DxoDataGridRowDraggingComponent, DxoDataGridRowDraggingModule, DxoDataGridScrollingComponent, DxoDataGridScrollingModule, DxoDataGridSearchComponent, DxoDataGridSearchModule, DxoDataGridSearchPanelComponent, DxoDataGridSearchPanelModule, DxoDataGridSelectionComponent, DxoDataGridSelectionModule, DxoDataGridShowComponent, DxoDataGridShowModule, DxoDataGridSortingComponent, DxoDataGridSortingModule, DxoDataGridStateStoringComponent, DxoDataGridStateStoringModule, DxoDataGridSummaryComponent, DxoDataGridSummaryModule, DxoDataGridSummaryTextsComponent, DxoDataGridSummaryTextsModule, DxoDataGridTabPanelOptionsComponent, DxoDataGridTabPanelOptionsModule, DxoDataGridTextsComponent, DxoDataGridTextsModule, DxoDataGridToComponent, DxoDataGridToModule, DxoDataGridToolbarComponent, DxoDataGridToolbarModule, DxoDataGridValueFormatComponent, DxoDataGridValueFormatModule };
//# sourceMappingURL=index.d.ts.map
