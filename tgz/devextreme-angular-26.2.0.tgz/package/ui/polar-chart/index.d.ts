import * as i0 from '@angular/core';
import { OnDestroy, OnChanges, DoCheck, QueryList, EventEmitter, ElementRef, NgZone, TransferState, SimpleChanges } from '@angular/core';
import * as CommonChartTypes from 'devextreme/common/charts';
import { AnimationEaseMode, ChartsDataType, DashStyle, Font, DiscreteAxisDivisionMode, ArgumentAxisHoverMode, LabelOverlap, TimeInterval, AxisScaleType, ChartsColor, SeriesHoverMode, HatchDirection, RelativePosition, PointInteractionMode, PointSymbol, SeriesSelectionMode, ValueErrorBarDisplayMode, ValueErrorBarType, SeriesLabel, SeriesPoint, LegendItem, LegendHoverMode, Palette, PaletteExtensionMode, Theme, TextOverflow, WordWrap, ValueAxisVisualRangeUpdateMode } from 'devextreme/common/charts';
import DxPolarChart, { dxPolarChartAnnotationConfig, dxPolarChartCommonAnnotationConfig, PolarChartSeriesType, PolarChartSeries, dxPolarChartPointInfo, ArgumentAxisClickEvent, DisposingEvent, DoneEvent, DrawnEvent, ExportedEvent, ExportingEvent, FileSavingEvent, IncidentOccurredEvent, InitializedEvent, LegendClickEvent, OptionChangedEvent, PointClickEvent, PointHoverChangedEvent, PointSelectionChangedEvent, SeriesClickEvent, SeriesHoverChangedEvent, SeriesSelectionChangedEvent, TooltipHiddenEvent, TooltipShownEvent, ZoomEndEvent, ZoomStartEvent } from 'devextreme/viz/polar_chart';
import { Format } from 'devextreme/common/core/localization';
import DataSource, { DataSourceOptions } from 'devextreme/data/data_source';
import { Store } from 'devextreme/data/store';
import { ExportFormat, HorizontalAlignment, Position, Orientation, VerticalEdge, SingleOrMultiple } from 'devextreme/common';
import * as i3 from 'devextreme-angular/core';
import { DxComponent, CollectionNestedOption, DxTemplateHost, WatcherHelper, IterableDifferHelper, NestedOptionHost } from 'devextreme-angular/core';
import * as i1 from 'devextreme-angular/ui/nested';
import * as i2 from 'devextreme-angular/ui/polar-chart/nested';
export * from 'devextreme-angular/ui/polar-chart/nested';
import * as polar_chart_types from 'devextreme/viz/polar_chart_types';
export { polar_chart_types as DxPolarChartTypes };

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

/**
 * [descr:dxPolarChart]

 */
declare class DxPolarChartComponent extends DxComponent implements OnDestroy, OnChanges, DoCheck {
    private _watcherHelper;
    private _idh;
    set _annotationsContentChildren(value: QueryList<CollectionNestedOption>);
    set _constantLinesContentChildren(value: QueryList<CollectionNestedOption>);
    set _seriesContentChildren(value: QueryList<CollectionNestedOption>);
    set _stripsContentChildren(value: QueryList<CollectionNestedOption>);
    instance: DxPolarChart;
    /**
     * [descr:dxPolarChartOptions.adaptiveLayout]
    
     */
    get adaptiveLayout(): {
        height?: number;
        keepLabels?: boolean;
        width?: number;
    };
    set adaptiveLayout(value: {
        height?: number;
        keepLabels?: boolean;
        width?: number;
    });
    /**
     * [descr:BaseChartOptions.animation]
    
     */
    get animation(): boolean | {
        duration?: number;
        easing?: AnimationEaseMode;
        enabled?: boolean;
        maxPointCountSupported?: number;
    };
    set animation(value: boolean | {
        duration?: number;
        easing?: AnimationEaseMode;
        enabled?: boolean;
        maxPointCountSupported?: number;
    });
    /**
     * [descr:dxPolarChartOptions.annotations]
    
     */
    get annotations(): Array<any | dxPolarChartAnnotationConfig>;
    set annotations(value: Array<any | dxPolarChartAnnotationConfig>);
    /**
     * [descr:dxPolarChartOptions.argumentAxis]
    
     */
    get argumentAxis(): {
        allowDecimals?: boolean | undefined;
        argumentType?: ChartsDataType | undefined;
        axisDivisionFactor?: number;
        categories?: Array<Date | number | string>;
        color?: string;
        constantLines?: {
            color?: string;
            dashStyle?: DashStyle;
            displayBehindSeries?: boolean;
            extendAxis?: boolean;
            label?: {
                font?: Font;
                text?: string | undefined;
                visible?: boolean;
            };
            value?: Date | number | string | undefined;
            width?: number;
        }[];
        constantLineStyle?: {
            color?: string;
            dashStyle?: DashStyle;
            label?: {
                font?: Font;
                visible?: boolean;
            };
            width?: number;
        };
        discreteAxisDivisionMode?: DiscreteAxisDivisionMode;
        endOnTick?: boolean | undefined;
        firstPointOnStartAngle?: boolean;
        grid?: {
            color?: string;
            opacity?: number | undefined;
            visible?: boolean;
            width?: number;
        };
        hoverMode?: ArgumentAxisHoverMode;
        inverted?: boolean;
        label?: {
            customizeHint?: ((argument: {
                value: Date | number | string;
                valueText: string;
            }) => string);
            customizeText?: ((argument: {
                value: Date | number | string;
                valueText: string;
            }) => string);
            font?: Font;
            format?: Format | undefined;
            indentFromAxis?: number;
            overlappingBehavior?: LabelOverlap;
            visible?: boolean;
        };
        linearThreshold?: number | undefined;
        logarithmBase?: number;
        minorGrid?: {
            color?: string;
            opacity?: number | undefined;
            visible?: boolean;
            width?: number;
        };
        minorTick?: {
            color?: string;
            length?: number;
            opacity?: number;
            shift?: number;
            visible?: boolean;
            width?: number;
        };
        minorTickCount?: number | undefined;
        minorTickInterval?: number | TimeInterval | {
            days?: number;
            hours?: number;
            milliseconds?: number;
            minutes?: number;
            months?: number;
            quarters?: number;
            seconds?: number;
            weeks?: number;
            years?: number;
        };
        opacity?: number | undefined;
        originValue?: number | undefined;
        period?: number | undefined;
        startAngle?: number;
        strips?: {
            color?: string | undefined;
            endValue?: Date | number | string | undefined;
            label?: {
                font?: Font;
                text?: string | undefined;
            };
            startValue?: Date | number | string | undefined;
        }[];
        stripStyle?: {
            label?: {
                font?: Font;
            };
        };
        tick?: {
            color?: string;
            length?: number;
            opacity?: number | undefined;
            shift?: number;
            visible?: boolean;
            width?: number;
        };
        tickInterval?: number | TimeInterval | {
            days?: number;
            hours?: number;
            milliseconds?: number;
            minutes?: number;
            months?: number;
            quarters?: number;
            seconds?: number;
            weeks?: number;
            years?: number;
        };
        type?: AxisScaleType | undefined;
        visible?: boolean;
        width?: number;
    };
    set argumentAxis(value: {
        allowDecimals?: boolean | undefined;
        argumentType?: ChartsDataType | undefined;
        axisDivisionFactor?: number;
        categories?: Array<Date | number | string>;
        color?: string;
        constantLines?: {
            color?: string;
            dashStyle?: DashStyle;
            displayBehindSeries?: boolean;
            extendAxis?: boolean;
            label?: {
                font?: Font;
                text?: string | undefined;
                visible?: boolean;
            };
            value?: Date | number | string | undefined;
            width?: number;
        }[];
        constantLineStyle?: {
            color?: string;
            dashStyle?: DashStyle;
            label?: {
                font?: Font;
                visible?: boolean;
            };
            width?: number;
        };
        discreteAxisDivisionMode?: DiscreteAxisDivisionMode;
        endOnTick?: boolean | undefined;
        firstPointOnStartAngle?: boolean;
        grid?: {
            color?: string;
            opacity?: number | undefined;
            visible?: boolean;
            width?: number;
        };
        hoverMode?: ArgumentAxisHoverMode;
        inverted?: boolean;
        label?: {
            customizeHint?: ((argument: {
                value: Date | number | string;
                valueText: string;
            }) => string);
            customizeText?: ((argument: {
                value: Date | number | string;
                valueText: string;
            }) => string);
            font?: Font;
            format?: Format | undefined;
            indentFromAxis?: number;
            overlappingBehavior?: LabelOverlap;
            visible?: boolean;
        };
        linearThreshold?: number | undefined;
        logarithmBase?: number;
        minorGrid?: {
            color?: string;
            opacity?: number | undefined;
            visible?: boolean;
            width?: number;
        };
        minorTick?: {
            color?: string;
            length?: number;
            opacity?: number;
            shift?: number;
            visible?: boolean;
            width?: number;
        };
        minorTickCount?: number | undefined;
        minorTickInterval?: number | TimeInterval | {
            days?: number;
            hours?: number;
            milliseconds?: number;
            minutes?: number;
            months?: number;
            quarters?: number;
            seconds?: number;
            weeks?: number;
            years?: number;
        };
        opacity?: number | undefined;
        originValue?: number | undefined;
        period?: number | undefined;
        startAngle?: number;
        strips?: {
            color?: string | undefined;
            endValue?: Date | number | string | undefined;
            label?: {
                font?: Font;
                text?: string | undefined;
            };
            startValue?: Date | number | string | undefined;
        }[];
        stripStyle?: {
            label?: {
                font?: Font;
            };
        };
        tick?: {
            color?: string;
            length?: number;
            opacity?: number | undefined;
            shift?: number;
            visible?: boolean;
            width?: number;
        };
        tickInterval?: number | TimeInterval | {
            days?: number;
            hours?: number;
            milliseconds?: number;
            minutes?: number;
            months?: number;
            quarters?: number;
            seconds?: number;
            weeks?: number;
            years?: number;
        };
        type?: AxisScaleType | undefined;
        visible?: boolean;
        width?: number;
    });
    /**
     * [descr:dxPolarChartOptions.barGroupPadding]
    
     */
    get barGroupPadding(): number;
    set barGroupPadding(value: number);
    /**
     * [descr:dxPolarChartOptions.barGroupWidth]
    
     */
    get barGroupWidth(): number | undefined;
    set barGroupWidth(value: number | undefined);
    /**
     * [descr:dxPolarChartOptions.commonAnnotationSettings]
    
     */
    get commonAnnotationSettings(): dxPolarChartCommonAnnotationConfig;
    set commonAnnotationSettings(value: dxPolarChartCommonAnnotationConfig);
    /**
     * [descr:dxPolarChartOptions.commonAxisSettings]
    
     */
    get commonAxisSettings(): {
        allowDecimals?: boolean | undefined;
        color?: string;
        constantLineStyle?: {
            color?: string;
            dashStyle?: DashStyle;
            label?: {
                font?: Font;
                visible?: boolean;
            };
            width?: number;
        };
        discreteAxisDivisionMode?: DiscreteAxisDivisionMode;
        endOnTick?: boolean | undefined;
        grid?: {
            color?: string;
            opacity?: number | undefined;
            visible?: boolean;
            width?: number;
        };
        inverted?: boolean;
        label?: {
            font?: Font;
            indentFromAxis?: number;
            overlappingBehavior?: LabelOverlap;
            visible?: boolean;
        };
        minorGrid?: {
            color?: string;
            opacity?: number | undefined;
            visible?: boolean;
            width?: number;
        };
        minorTick?: {
            color?: string;
            length?: number;
            opacity?: number;
            visible?: boolean;
            width?: number;
        };
        opacity?: number | undefined;
        stripStyle?: {
            label?: {
                font?: Font;
            };
        };
        tick?: {
            color?: string;
            length?: number;
            opacity?: number | undefined;
            visible?: boolean;
            width?: number;
        };
        visible?: boolean;
        width?: number;
    };
    set commonAxisSettings(value: {
        allowDecimals?: boolean | undefined;
        color?: string;
        constantLineStyle?: {
            color?: string;
            dashStyle?: DashStyle;
            label?: {
                font?: Font;
                visible?: boolean;
            };
            width?: number;
        };
        discreteAxisDivisionMode?: DiscreteAxisDivisionMode;
        endOnTick?: boolean | undefined;
        grid?: {
            color?: string;
            opacity?: number | undefined;
            visible?: boolean;
            width?: number;
        };
        inverted?: boolean;
        label?: {
            font?: Font;
            indentFromAxis?: number;
            overlappingBehavior?: LabelOverlap;
            visible?: boolean;
        };
        minorGrid?: {
            color?: string;
            opacity?: number | undefined;
            visible?: boolean;
            width?: number;
        };
        minorTick?: {
            color?: string;
            length?: number;
            opacity?: number;
            visible?: boolean;
            width?: number;
        };
        opacity?: number | undefined;
        stripStyle?: {
            label?: {
                font?: Font;
            };
        };
        tick?: {
            color?: string;
            length?: number;
            opacity?: number | undefined;
            visible?: boolean;
            width?: number;
        };
        visible?: boolean;
        width?: number;
    });
    /**
     * [descr:dxPolarChartOptions.commonSeriesSettings]
    
     */
    get commonSeriesSettings(): {
        area?: any;
        argumentField?: string;
        bar?: any;
        barPadding?: number | undefined;
        barWidth?: number | undefined;
        border?: {
            color?: string | undefined;
            dashStyle?: DashStyle | undefined;
            visible?: boolean;
            width?: number;
        };
        closed?: boolean;
        color?: ChartsColor | string | undefined;
        dashStyle?: DashStyle;
        hoverMode?: SeriesHoverMode;
        hoverStyle?: {
            border?: {
                color?: string | undefined;
                dashStyle?: DashStyle | undefined;
                visible?: boolean;
                width?: number;
            };
            color?: ChartsColor | string | undefined;
            dashStyle?: DashStyle;
            hatching?: {
                direction?: HatchDirection;
                opacity?: number;
                step?: number;
                width?: number;
            };
            highlight?: boolean;
            width?: number;
        };
        ignoreEmptyPoints?: boolean;
        label?: {
            argumentFormat?: Format | undefined;
            backgroundColor?: string | undefined;
            border?: {
                color?: string | undefined;
                dashStyle?: DashStyle | undefined;
                visible?: boolean;
                width?: number;
            };
            connector?: {
                color?: string | undefined;
                visible?: boolean;
                width?: number;
            };
            customizeText?: ((pointInfo: any) => string);
            displayFormat?: string | undefined;
            font?: Font;
            format?: Format | undefined;
            position?: RelativePosition;
            rotationAngle?: number;
            showForZeroValues?: boolean;
            visible?: boolean;
        };
        line?: any;
        maxLabelCount?: number | undefined;
        minBarSize?: number | undefined;
        opacity?: number;
        point?: {
            border?: {
                color?: string | undefined;
                visible?: boolean;
                width?: number;
            };
            color?: ChartsColor | string | undefined;
            hoverMode?: PointInteractionMode;
            hoverStyle?: {
                border?: {
                    color?: string | undefined;
                    visible?: boolean;
                    width?: number;
                };
                color?: ChartsColor | string | undefined;
                size?: number;
            };
            image?: string | undefined | {
                height?: number;
                url?: string | undefined;
                width?: number;
            };
            selectionMode?: PointInteractionMode;
            selectionStyle?: {
                border?: {
                    color?: string | undefined;
                    visible?: boolean;
                    width?: number;
                };
                color?: ChartsColor | string | undefined;
                size?: number;
            };
            size?: number;
            symbol?: PointSymbol;
            visible?: boolean;
        };
        scatter?: any;
        selectionMode?: SeriesSelectionMode;
        selectionStyle?: {
            border?: {
                color?: string | undefined;
                dashStyle?: DashStyle | undefined;
                visible?: boolean;
                width?: number;
            };
            color?: ChartsColor | string | undefined;
            dashStyle?: DashStyle;
            hatching?: {
                direction?: HatchDirection;
                opacity?: number;
                step?: number;
                width?: number;
            };
            highlight?: boolean;
            width?: number;
        };
        showInLegend?: boolean;
        stack?: string;
        stackedbar?: any;
        tagField?: string;
        type?: PolarChartSeriesType;
        valueErrorBar?: {
            color?: string;
            displayMode?: ValueErrorBarDisplayMode;
            edgeLength?: number;
            highValueField?: string | undefined;
            lineWidth?: number;
            lowValueField?: string | undefined;
            opacity?: number | undefined;
            type?: undefined | ValueErrorBarType;
            value?: number;
        };
        valueField?: string;
        visible?: boolean;
        width?: number;
    };
    set commonSeriesSettings(value: {
        area?: any;
        argumentField?: string;
        bar?: any;
        barPadding?: number | undefined;
        barWidth?: number | undefined;
        border?: {
            color?: string | undefined;
            dashStyle?: DashStyle | undefined;
            visible?: boolean;
            width?: number;
        };
        closed?: boolean;
        color?: ChartsColor | string | undefined;
        dashStyle?: DashStyle;
        hoverMode?: SeriesHoverMode;
        hoverStyle?: {
            border?: {
                color?: string | undefined;
                dashStyle?: DashStyle | undefined;
                visible?: boolean;
                width?: number;
            };
            color?: ChartsColor | string | undefined;
            dashStyle?: DashStyle;
            hatching?: {
                direction?: HatchDirection;
                opacity?: number;
                step?: number;
                width?: number;
            };
            highlight?: boolean;
            width?: number;
        };
        ignoreEmptyPoints?: boolean;
        label?: {
            argumentFormat?: Format | undefined;
            backgroundColor?: string | undefined;
            border?: {
                color?: string | undefined;
                dashStyle?: DashStyle | undefined;
                visible?: boolean;
                width?: number;
            };
            connector?: {
                color?: string | undefined;
                visible?: boolean;
                width?: number;
            };
            customizeText?: ((pointInfo: any) => string);
            displayFormat?: string | undefined;
            font?: Font;
            format?: Format | undefined;
            position?: RelativePosition;
            rotationAngle?: number;
            showForZeroValues?: boolean;
            visible?: boolean;
        };
        line?: any;
        maxLabelCount?: number | undefined;
        minBarSize?: number | undefined;
        opacity?: number;
        point?: {
            border?: {
                color?: string | undefined;
                visible?: boolean;
                width?: number;
            };
            color?: ChartsColor | string | undefined;
            hoverMode?: PointInteractionMode;
            hoverStyle?: {
                border?: {
                    color?: string | undefined;
                    visible?: boolean;
                    width?: number;
                };
                color?: ChartsColor | string | undefined;
                size?: number;
            };
            image?: string | undefined | {
                height?: number;
                url?: string | undefined;
                width?: number;
            };
            selectionMode?: PointInteractionMode;
            selectionStyle?: {
                border?: {
                    color?: string | undefined;
                    visible?: boolean;
                    width?: number;
                };
                color?: ChartsColor | string | undefined;
                size?: number;
            };
            size?: number;
            symbol?: PointSymbol;
            visible?: boolean;
        };
        scatter?: any;
        selectionMode?: SeriesSelectionMode;
        selectionStyle?: {
            border?: {
                color?: string | undefined;
                dashStyle?: DashStyle | undefined;
                visible?: boolean;
                width?: number;
            };
            color?: ChartsColor | string | undefined;
            dashStyle?: DashStyle;
            hatching?: {
                direction?: HatchDirection;
                opacity?: number;
                step?: number;
                width?: number;
            };
            highlight?: boolean;
            width?: number;
        };
        showInLegend?: boolean;
        stack?: string;
        stackedbar?: any;
        tagField?: string;
        type?: PolarChartSeriesType;
        valueErrorBar?: {
            color?: string;
            displayMode?: ValueErrorBarDisplayMode;
            edgeLength?: number;
            highValueField?: string | undefined;
            lineWidth?: number;
            lowValueField?: string | undefined;
            opacity?: number | undefined;
            type?: undefined | ValueErrorBarType;
            value?: number;
        };
        valueField?: string;
        visible?: boolean;
        width?: number;
    });
    /**
     * [descr:dxPolarChartOptions.containerBackgroundColor]
    
     */
    get containerBackgroundColor(): string;
    set containerBackgroundColor(value: string);
    /**
     * [descr:dxPolarChartOptions.customizeAnnotation]
    
     */
    get customizeAnnotation(): ((annotation: dxPolarChartAnnotationConfig | any) => dxPolarChartAnnotationConfig) | undefined;
    set customizeAnnotation(value: ((annotation: dxPolarChartAnnotationConfig | any) => dxPolarChartAnnotationConfig) | undefined);
    /**
     * [descr:BaseChartOptions.customizeLabel]
    
     */
    get customizeLabel(): ((pointInfo: any) => SeriesLabel);
    set customizeLabel(value: ((pointInfo: any) => SeriesLabel));
    /**
     * [descr:BaseChartOptions.customizePoint]
    
     */
    get customizePoint(): ((pointInfo: any) => SeriesPoint);
    set customizePoint(value: ((pointInfo: any) => SeriesPoint));
    /**
     * [descr:dxPolarChartOptions.dataPrepareSettings]
    
     */
    get dataPrepareSettings(): {
        checkTypeForAllData?: boolean;
        convertToAxisDataType?: boolean;
        sortingMethod?: boolean | ((a: {
            arg: Date | number | string;
            val: Date | number | string;
        }, b: {
            arg: Date | number | string;
            val: Date | number | string;
        }) => number);
    };
    set dataPrepareSettings(value: {
        checkTypeForAllData?: boolean;
        convertToAxisDataType?: boolean;
        sortingMethod?: boolean | ((a: {
            arg: Date | number | string;
            val: Date | number | string;
        }, b: {
            arg: Date | number | string;
            val: Date | number | string;
        }) => number);
    });
    /**
     * [descr:BaseChartOptions.dataSource]
    
     */
    get dataSource(): Array<any> | DataSource | DataSourceOptions | null | Store | string;
    set dataSource(value: Array<any> | DataSource | DataSourceOptions | null | Store | string);
    /**
     * [descr:BaseWidgetOptions.disabled]
    
     */
    get disabled(): boolean;
    set disabled(value: boolean);
    /**
     * [descr:DOMComponentOptions.elementAttr]
    
     */
    get elementAttr(): Record<string, any>;
    set elementAttr(value: Record<string, any>);
    /**
     * [descr:BaseWidgetOptions.encodeHtml]
    
     */
    get encodeHtml(): boolean;
    set encodeHtml(value: boolean);
    /**
     * [descr:BaseWidgetOptions.export]
    
     */
    get export(): {
        backgroundColor?: string;
        enabled?: boolean;
        fileName?: string;
        formats?: Array<ExportFormat>;
        margin?: number;
        printingEnabled?: boolean;
        svgToCanvas?: ((svg: any, canvas: any) => any) | undefined;
    };
    set export(value: {
        backgroundColor?: string;
        enabled?: boolean;
        fileName?: string;
        formats?: Array<ExportFormat>;
        margin?: number;
        printingEnabled?: boolean;
        svgToCanvas?: ((svg: any, canvas: any) => any) | undefined;
    });
    /**
     * [descr:dxPolarChartOptions.legend]
    
     */
    get legend(): {
        backgroundColor?: string | undefined;
        border?: {
            color?: string;
            cornerRadius?: number;
            dashStyle?: DashStyle;
            opacity?: number | undefined;
            visible?: boolean;
            width?: number;
        };
        columnCount?: number;
        columnItemSpacing?: number;
        customizeHint?: ((seriesInfo: {
            seriesColor: string;
            seriesIndex: number;
            seriesName: any;
        }) => string);
        customizeItems?: ((items: Array<LegendItem>) => Array<LegendItem>);
        customizeText?: ((seriesInfo: {
            seriesColor: string;
            seriesIndex: number;
            seriesName: any;
        }) => string);
        font?: Font;
        horizontalAlignment?: HorizontalAlignment;
        hoverMode?: LegendHoverMode;
        itemsAlignment?: HorizontalAlignment | undefined;
        itemTextPosition?: Position | undefined;
        margin?: number | {
            bottom?: number;
            left?: number;
            right?: number;
            top?: number;
        };
        markerSize?: number;
        markerTemplate?: any;
        orientation?: Orientation | undefined;
        paddingLeftRight?: number;
        paddingTopBottom?: number;
        rowCount?: number;
        rowItemSpacing?: number;
        title?: string | {
            font?: Font;
            horizontalAlignment?: HorizontalAlignment | undefined;
            margin?: {
                bottom?: number;
                left?: number;
                right?: number;
                top?: number;
            };
            placeholderSize?: number | undefined;
            subtitle?: string | {
                font?: Font;
                offset?: number;
                text?: string | undefined;
            };
            text?: string | undefined;
            verticalAlignment?: VerticalEdge;
        };
        verticalAlignment?: VerticalEdge;
        visible?: boolean;
    };
    set legend(value: {
        backgroundColor?: string | undefined;
        border?: {
            color?: string;
            cornerRadius?: number;
            dashStyle?: DashStyle;
            opacity?: number | undefined;
            visible?: boolean;
            width?: number;
        };
        columnCount?: number;
        columnItemSpacing?: number;
        customizeHint?: ((seriesInfo: {
            seriesColor: string;
            seriesIndex: number;
            seriesName: any;
        }) => string);
        customizeItems?: ((items: Array<LegendItem>) => Array<LegendItem>);
        customizeText?: ((seriesInfo: {
            seriesColor: string;
            seriesIndex: number;
            seriesName: any;
        }) => string);
        font?: Font;
        horizontalAlignment?: HorizontalAlignment;
        hoverMode?: LegendHoverMode;
        itemsAlignment?: HorizontalAlignment | undefined;
        itemTextPosition?: Position | undefined;
        margin?: number | {
            bottom?: number;
            left?: number;
            right?: number;
            top?: number;
        };
        markerSize?: number;
        markerTemplate?: any;
        orientation?: Orientation | undefined;
        paddingLeftRight?: number;
        paddingTopBottom?: number;
        rowCount?: number;
        rowItemSpacing?: number;
        title?: string | {
            font?: Font;
            horizontalAlignment?: HorizontalAlignment | undefined;
            margin?: {
                bottom?: number;
                left?: number;
                right?: number;
                top?: number;
            };
            placeholderSize?: number | undefined;
            subtitle?: string | {
                font?: Font;
                offset?: number;
                text?: string | undefined;
            };
            text?: string | undefined;
            verticalAlignment?: VerticalEdge;
        };
        verticalAlignment?: VerticalEdge;
        visible?: boolean;
    });
    /**
     * [descr:BaseWidgetOptions.loadingIndicator]
    
     */
    get loadingIndicator(): {
        backgroundColor?: string;
        enabled?: boolean;
        font?: Font;
        show?: boolean;
        text?: string;
    };
    set loadingIndicator(value: {
        backgroundColor?: string;
        enabled?: boolean;
        font?: Font;
        show?: boolean;
        text?: string;
    });
    /**
     * [descr:BaseWidgetOptions.margin]
    
     */
    get margin(): {
        bottom?: number;
        left?: number;
        right?: number;
        top?: number;
    };
    set margin(value: {
        bottom?: number;
        left?: number;
        right?: number;
        top?: number;
    });
    /**
     * [descr:dxPolarChartOptions.negativesAsZeroes]
    
     */
    get negativesAsZeroes(): boolean;
    set negativesAsZeroes(value: boolean);
    /**
     * [descr:BaseChartOptions.palette]
    
     */
    get palette(): Array<string> | Palette;
    set palette(value: Array<string> | Palette);
    /**
     * [descr:BaseChartOptions.paletteExtensionMode]
    
     */
    get paletteExtensionMode(): PaletteExtensionMode;
    set paletteExtensionMode(value: PaletteExtensionMode);
    /**
     * [descr:BaseWidgetOptions.pathModified]
    
     */
    get pathModified(): boolean;
    set pathModified(value: boolean);
    /**
     * [descr:BaseChartOptions.pointSelectionMode]
    
     */
    get pointSelectionMode(): SingleOrMultiple;
    set pointSelectionMode(value: SingleOrMultiple);
    /**
     * [descr:BaseWidgetOptions.redrawOnResize]
    
     */
    get redrawOnResize(): boolean;
    set redrawOnResize(value: boolean);
    /**
     * [descr:dxPolarChartOptions.resolveLabelOverlapping]
    
     */
    get resolveLabelOverlapping(): LabelOverlap;
    set resolveLabelOverlapping(value: LabelOverlap);
    /**
     * [descr:BaseWidgetOptions.rtlEnabled]
    
     */
    get rtlEnabled(): boolean;
    set rtlEnabled(value: boolean);
    /**
     * [descr:dxPolarChartOptions.series]
    
     */
    get series(): Array<PolarChartSeries> | PolarChartSeries | undefined;
    set series(value: Array<PolarChartSeries> | PolarChartSeries | undefined);
    /**
     * [descr:dxPolarChartOptions.seriesSelectionMode]
    
     */
    get seriesSelectionMode(): SingleOrMultiple;
    set seriesSelectionMode(value: SingleOrMultiple);
    /**
     * [descr:dxPolarChartOptions.seriesTemplate]
    
     */
    get seriesTemplate(): any;
    set seriesTemplate(value: any);
    /**
     * [descr:BaseWidgetOptions.size]
    
     */
    get size(): {
        height?: number | undefined;
        width?: number | undefined;
    };
    set size(value: {
        height?: number | undefined;
        width?: number | undefined;
    });
    /**
     * [descr:BaseWidgetOptions.theme]
    
     */
    get theme(): Theme;
    set theme(value: Theme);
    /**
     * [descr:BaseWidgetOptions.title]
    
     */
    get title(): string | {
        font?: Font;
        horizontalAlignment?: HorizontalAlignment;
        margin?: number | {
            bottom?: number;
            left?: number;
            right?: number;
            top?: number;
        };
        placeholderSize?: number | undefined;
        subtitle?: string | {
            font?: Font;
            offset?: number;
            text?: string | undefined;
            textOverflow?: TextOverflow;
            wordWrap?: WordWrap;
        };
        text?: string | undefined;
        textOverflow?: TextOverflow;
        verticalAlignment?: VerticalEdge;
        wordWrap?: WordWrap;
    };
    set title(value: string | {
        font?: Font;
        horizontalAlignment?: HorizontalAlignment;
        margin?: number | {
            bottom?: number;
            left?: number;
            right?: number;
            top?: number;
        };
        placeholderSize?: number | undefined;
        subtitle?: string | {
            font?: Font;
            offset?: number;
            text?: string | undefined;
            textOverflow?: TextOverflow;
            wordWrap?: WordWrap;
        };
        text?: string | undefined;
        textOverflow?: TextOverflow;
        verticalAlignment?: VerticalEdge;
        wordWrap?: WordWrap;
    });
    /**
     * [descr:dxPolarChartOptions.tooltip]
    
     */
    get tooltip(): {
        argumentFormat?: Format | undefined;
        arrowLength?: number;
        border?: {
            color?: string;
            dashStyle?: DashStyle;
            opacity?: number | undefined;
            visible?: boolean;
            width?: number;
        };
        color?: string;
        container?: any | string | undefined;
        contentTemplate?: any;
        cornerRadius?: number;
        customizeTooltip?: ((pointInfo: dxPolarChartPointInfo) => Record<string, any>) | undefined;
        enabled?: boolean;
        font?: Font;
        format?: Format | undefined;
        interactive?: boolean;
        opacity?: number | undefined;
        paddingLeftRight?: number;
        paddingTopBottom?: number;
        shadow?: {
            blur?: number;
            color?: string;
            offsetX?: number;
            offsetY?: number;
            opacity?: number;
        };
        shared?: boolean;
        zIndex?: number | undefined;
    };
    set tooltip(value: {
        argumentFormat?: Format | undefined;
        arrowLength?: number;
        border?: {
            color?: string;
            dashStyle?: DashStyle;
            opacity?: number | undefined;
            visible?: boolean;
            width?: number;
        };
        color?: string;
        container?: any | string | undefined;
        contentTemplate?: any;
        cornerRadius?: number;
        customizeTooltip?: ((pointInfo: dxPolarChartPointInfo) => Record<string, any>) | undefined;
        enabled?: boolean;
        font?: Font;
        format?: Format | undefined;
        interactive?: boolean;
        opacity?: number | undefined;
        paddingLeftRight?: number;
        paddingTopBottom?: number;
        shadow?: {
            blur?: number;
            color?: string;
            offsetX?: number;
            offsetY?: number;
            opacity?: number;
        };
        shared?: boolean;
        zIndex?: number | undefined;
    });
    /**
     * [descr:dxPolarChartOptions.useSpiderWeb]
    
     */
    get useSpiderWeb(): boolean;
    set useSpiderWeb(value: boolean);
    /**
     * [descr:dxPolarChartOptions.valueAxis]
    
     */
    get valueAxis(): {
        allowDecimals?: boolean | undefined;
        axisDivisionFactor?: number;
        categories?: Array<Date | number | string>;
        color?: string;
        constantLines?: {
            color?: string;
            dashStyle?: DashStyle;
            displayBehindSeries?: boolean;
            extendAxis?: boolean;
            label?: {
                font?: Font;
                text?: string | undefined;
                visible?: boolean;
            };
            value?: Date | number | string | undefined;
            width?: number;
        }[];
        constantLineStyle?: {
            color?: string;
            dashStyle?: DashStyle;
            label?: {
                font?: Font;
                visible?: boolean;
            };
            width?: number;
        };
        discreteAxisDivisionMode?: DiscreteAxisDivisionMode;
        endOnTick?: boolean;
        grid?: {
            color?: string;
            opacity?: number | undefined;
            visible?: boolean;
            width?: number;
        };
        inverted?: boolean;
        label?: {
            customizeHint?: ((axisValue: {
                value: Date | number | string;
                valueText: string;
            }) => string);
            customizeText?: ((axisValue: {
                value: Date | number | string;
                valueText: string;
            }) => string);
            font?: Font;
            format?: Format | undefined;
            indentFromAxis?: number;
            overlappingBehavior?: LabelOverlap;
            visible?: boolean;
        };
        linearThreshold?: number | undefined;
        logarithmBase?: number;
        maxValueMargin?: number | undefined;
        minorGrid?: {
            color?: string;
            opacity?: number | undefined;
            visible?: boolean;
            width?: number;
        };
        minorTick?: {
            color?: string;
            length?: number;
            opacity?: number;
            visible?: boolean;
            width?: number;
        };
        minorTickCount?: number | undefined;
        minorTickInterval?: number | TimeInterval | {
            days?: number;
            hours?: number;
            milliseconds?: number;
            minutes?: number;
            months?: number;
            quarters?: number;
            seconds?: number;
            weeks?: number;
            years?: number;
        };
        minValueMargin?: number | undefined;
        minVisualRangeLength?: number | TimeInterval | undefined | {
            days?: number;
            hours?: number;
            milliseconds?: number;
            minutes?: number;
            months?: number;
            quarters?: number;
            seconds?: number;
            weeks?: number;
            years?: number;
        };
        opacity?: number | undefined;
        showZero?: boolean | undefined;
        strips?: {
            color?: string | undefined;
            endValue?: Date | number | string | undefined;
            label?: {
                font?: Font;
                text?: string | undefined;
            };
            startValue?: Date | number | string | undefined;
        }[];
        stripStyle?: {
            label?: {
                font?: Font;
            };
        };
        tick?: {
            color?: string;
            length?: number;
            opacity?: number | undefined;
            visible?: boolean;
            width?: number;
        };
        tickInterval?: number | TimeInterval | {
            days?: number;
            hours?: number;
            milliseconds?: number;
            minutes?: number;
            months?: number;
            quarters?: number;
            seconds?: number;
            weeks?: number;
            years?: number;
        };
        type?: AxisScaleType | undefined;
        valueMarginsEnabled?: boolean;
        valueType?: ChartsDataType | undefined;
        visible?: boolean;
        visualRange?: Array<Date | number | string> | CommonChartTypes.VisualRange;
        visualRangeUpdateMode?: ValueAxisVisualRangeUpdateMode;
        wholeRange?: Array<Date | number | string> | undefined | CommonChartTypes.VisualRange;
        width?: number;
    };
    set valueAxis(value: {
        allowDecimals?: boolean | undefined;
        axisDivisionFactor?: number;
        categories?: Array<Date | number | string>;
        color?: string;
        constantLines?: {
            color?: string;
            dashStyle?: DashStyle;
            displayBehindSeries?: boolean;
            extendAxis?: boolean;
            label?: {
                font?: Font;
                text?: string | undefined;
                visible?: boolean;
            };
            value?: Date | number | string | undefined;
            width?: number;
        }[];
        constantLineStyle?: {
            color?: string;
            dashStyle?: DashStyle;
            label?: {
                font?: Font;
                visible?: boolean;
            };
            width?: number;
        };
        discreteAxisDivisionMode?: DiscreteAxisDivisionMode;
        endOnTick?: boolean;
        grid?: {
            color?: string;
            opacity?: number | undefined;
            visible?: boolean;
            width?: number;
        };
        inverted?: boolean;
        label?: {
            customizeHint?: ((axisValue: {
                value: Date | number | string;
                valueText: string;
            }) => string);
            customizeText?: ((axisValue: {
                value: Date | number | string;
                valueText: string;
            }) => string);
            font?: Font;
            format?: Format | undefined;
            indentFromAxis?: number;
            overlappingBehavior?: LabelOverlap;
            visible?: boolean;
        };
        linearThreshold?: number | undefined;
        logarithmBase?: number;
        maxValueMargin?: number | undefined;
        minorGrid?: {
            color?: string;
            opacity?: number | undefined;
            visible?: boolean;
            width?: number;
        };
        minorTick?: {
            color?: string;
            length?: number;
            opacity?: number;
            visible?: boolean;
            width?: number;
        };
        minorTickCount?: number | undefined;
        minorTickInterval?: number | TimeInterval | {
            days?: number;
            hours?: number;
            milliseconds?: number;
            minutes?: number;
            months?: number;
            quarters?: number;
            seconds?: number;
            weeks?: number;
            years?: number;
        };
        minValueMargin?: number | undefined;
        minVisualRangeLength?: number | TimeInterval | undefined | {
            days?: number;
            hours?: number;
            milliseconds?: number;
            minutes?: number;
            months?: number;
            quarters?: number;
            seconds?: number;
            weeks?: number;
            years?: number;
        };
        opacity?: number | undefined;
        showZero?: boolean | undefined;
        strips?: {
            color?: string | undefined;
            endValue?: Date | number | string | undefined;
            label?: {
                font?: Font;
                text?: string | undefined;
            };
            startValue?: Date | number | string | undefined;
        }[];
        stripStyle?: {
            label?: {
                font?: Font;
            };
        };
        tick?: {
            color?: string;
            length?: number;
            opacity?: number | undefined;
            visible?: boolean;
            width?: number;
        };
        tickInterval?: number | TimeInterval | {
            days?: number;
            hours?: number;
            milliseconds?: number;
            minutes?: number;
            months?: number;
            quarters?: number;
            seconds?: number;
            weeks?: number;
            years?: number;
        };
        type?: AxisScaleType | undefined;
        valueMarginsEnabled?: boolean;
        valueType?: ChartsDataType | undefined;
        visible?: boolean;
        visualRange?: Array<Date | number | string> | CommonChartTypes.VisualRange;
        visualRangeUpdateMode?: ValueAxisVisualRangeUpdateMode;
        wholeRange?: Array<Date | number | string> | undefined | CommonChartTypes.VisualRange;
        width?: number;
    });
    /**
    
     * [descr:dxPolarChartOptions.onArgumentAxisClick]
    
    
     */
    onArgumentAxisClick: EventEmitter<ArgumentAxisClickEvent>;
    /**
    
     * [descr:dxPolarChartOptions.onDisposing]
    
    
     */
    onDisposing: EventEmitter<DisposingEvent>;
    /**
    
     * [descr:dxPolarChartOptions.onDone]
    
    
     */
    onDone: EventEmitter<DoneEvent>;
    /**
    
     * [descr:dxPolarChartOptions.onDrawn]
    
    
     */
    onDrawn: EventEmitter<DrawnEvent>;
    /**
    
     * [descr:dxPolarChartOptions.onExported]
    
    
     */
    onExported: EventEmitter<ExportedEvent>;
    /**
    
     * [descr:dxPolarChartOptions.onExporting]
    
    
     */
    onExporting: EventEmitter<ExportingEvent>;
    /**
    
     * [descr:dxPolarChartOptions.onFileSaving]
    
    
     */
    onFileSaving: EventEmitter<FileSavingEvent>;
    /**
    
     * [descr:dxPolarChartOptions.onIncidentOccurred]
    
    
     */
    onIncidentOccurred: EventEmitter<IncidentOccurredEvent>;
    /**
    
     * [descr:dxPolarChartOptions.onInitialized]
    
    
     */
    onInitialized: EventEmitter<InitializedEvent>;
    /**
    
     * [descr:dxPolarChartOptions.onLegendClick]
    
    
     */
    onLegendClick: EventEmitter<LegendClickEvent>;
    /**
    
     * [descr:dxPolarChartOptions.onOptionChanged]
    
    
     */
    onOptionChanged: EventEmitter<OptionChangedEvent>;
    /**
    
     * [descr:dxPolarChartOptions.onPointClick]
    
    
     */
    onPointClick: EventEmitter<PointClickEvent>;
    /**
    
     * [descr:dxPolarChartOptions.onPointHoverChanged]
    
    
     */
    onPointHoverChanged: EventEmitter<PointHoverChangedEvent>;
    /**
    
     * [descr:dxPolarChartOptions.onPointSelectionChanged]
    
    
     */
    onPointSelectionChanged: EventEmitter<PointSelectionChangedEvent>;
    /**
    
     * [descr:dxPolarChartOptions.onSeriesClick]
    
    
     */
    onSeriesClick: EventEmitter<SeriesClickEvent>;
    /**
    
     * [descr:dxPolarChartOptions.onSeriesHoverChanged]
    
    
     */
    onSeriesHoverChanged: EventEmitter<SeriesHoverChangedEvent>;
    /**
    
     * [descr:dxPolarChartOptions.onSeriesSelectionChanged]
    
    
     */
    onSeriesSelectionChanged: EventEmitter<SeriesSelectionChangedEvent>;
    /**
    
     * [descr:dxPolarChartOptions.onTooltipHidden]
    
    
     */
    onTooltipHidden: EventEmitter<TooltipHiddenEvent>;
    /**
    
     * [descr:dxPolarChartOptions.onTooltipShown]
    
    
     */
    onTooltipShown: EventEmitter<TooltipShownEvent>;
    /**
    
     * [descr:dxPolarChartOptions.onZoomEnd]
    
    
     */
    onZoomEnd: EventEmitter<ZoomEndEvent>;
    /**
    
     * [descr:dxPolarChartOptions.onZoomStart]
    
    
     */
    onZoomStart: EventEmitter<ZoomStartEvent>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    adaptiveLayoutChange: EventEmitter<{
        height?: number;
        keepLabels?: boolean;
        width?: number;
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    animationChange: EventEmitter<boolean | {
        duration?: number;
        easing?: AnimationEaseMode;
        enabled?: boolean;
        maxPointCountSupported?: number;
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    annotationsChange: EventEmitter<Array<any | dxPolarChartAnnotationConfig>>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    argumentAxisChange: EventEmitter<{
        allowDecimals?: boolean | undefined;
        argumentType?: ChartsDataType | undefined;
        axisDivisionFactor?: number;
        categories?: Array<Date | number | string>;
        color?: string;
        constantLines?: {
            color?: string;
            dashStyle?: DashStyle;
            displayBehindSeries?: boolean;
            extendAxis?: boolean;
            label?: {
                font?: Font;
                text?: string | undefined;
                visible?: boolean;
            };
            value?: Date | number | string | undefined;
            width?: number;
        }[];
        constantLineStyle?: {
            color?: string;
            dashStyle?: DashStyle;
            label?: {
                font?: Font;
                visible?: boolean;
            };
            width?: number;
        };
        discreteAxisDivisionMode?: DiscreteAxisDivisionMode;
        endOnTick?: boolean | undefined;
        firstPointOnStartAngle?: boolean;
        grid?: {
            color?: string;
            opacity?: number | undefined;
            visible?: boolean;
            width?: number;
        };
        hoverMode?: ArgumentAxisHoverMode;
        inverted?: boolean;
        label?: {
            customizeHint?: ((argument: {
                value: Date | number | string;
                valueText: string;
            }) => string);
            customizeText?: ((argument: {
                value: Date | number | string;
                valueText: string;
            }) => string);
            font?: Font;
            format?: Format | undefined;
            indentFromAxis?: number;
            overlappingBehavior?: LabelOverlap;
            visible?: boolean;
        };
        linearThreshold?: number | undefined;
        logarithmBase?: number;
        minorGrid?: {
            color?: string;
            opacity?: number | undefined;
            visible?: boolean;
            width?: number;
        };
        minorTick?: {
            color?: string;
            length?: number;
            opacity?: number;
            shift?: number;
            visible?: boolean;
            width?: number;
        };
        minorTickCount?: number | undefined;
        minorTickInterval?: number | TimeInterval | {
            days?: number;
            hours?: number;
            milliseconds?: number;
            minutes?: number;
            months?: number;
            quarters?: number;
            seconds?: number;
            weeks?: number;
            years?: number;
        };
        opacity?: number | undefined;
        originValue?: number | undefined;
        period?: number | undefined;
        startAngle?: number;
        strips?: {
            color?: string | undefined;
            endValue?: Date | number | string | undefined;
            label?: {
                font?: Font;
                text?: string | undefined;
            };
            startValue?: Date | number | string | undefined;
        }[];
        stripStyle?: {
            label?: {
                font?: Font;
            };
        };
        tick?: {
            color?: string;
            length?: number;
            opacity?: number | undefined;
            shift?: number;
            visible?: boolean;
            width?: number;
        };
        tickInterval?: number | TimeInterval | {
            days?: number;
            hours?: number;
            milliseconds?: number;
            minutes?: number;
            months?: number;
            quarters?: number;
            seconds?: number;
            weeks?: number;
            years?: number;
        };
        type?: AxisScaleType | undefined;
        visible?: boolean;
        width?: number;
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    barGroupPaddingChange: EventEmitter<number>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    barGroupWidthChange: EventEmitter<number | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    commonAnnotationSettingsChange: EventEmitter<dxPolarChartCommonAnnotationConfig>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    commonAxisSettingsChange: EventEmitter<{
        allowDecimals?: boolean | undefined;
        color?: string;
        constantLineStyle?: {
            color?: string;
            dashStyle?: DashStyle;
            label?: {
                font?: Font;
                visible?: boolean;
            };
            width?: number;
        };
        discreteAxisDivisionMode?: DiscreteAxisDivisionMode;
        endOnTick?: boolean | undefined;
        grid?: {
            color?: string;
            opacity?: number | undefined;
            visible?: boolean;
            width?: number;
        };
        inverted?: boolean;
        label?: {
            font?: Font;
            indentFromAxis?: number;
            overlappingBehavior?: LabelOverlap;
            visible?: boolean;
        };
        minorGrid?: {
            color?: string;
            opacity?: number | undefined;
            visible?: boolean;
            width?: number;
        };
        minorTick?: {
            color?: string;
            length?: number;
            opacity?: number;
            visible?: boolean;
            width?: number;
        };
        opacity?: number | undefined;
        stripStyle?: {
            label?: {
                font?: Font;
            };
        };
        tick?: {
            color?: string;
            length?: number;
            opacity?: number | undefined;
            visible?: boolean;
            width?: number;
        };
        visible?: boolean;
        width?: number;
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    commonSeriesSettingsChange: EventEmitter<{
        area?: any;
        argumentField?: string;
        bar?: any;
        barPadding?: number | undefined;
        barWidth?: number | undefined;
        border?: {
            color?: string | undefined;
            dashStyle?: DashStyle | undefined;
            visible?: boolean;
            width?: number;
        };
        closed?: boolean;
        color?: ChartsColor | string | undefined;
        dashStyle?: DashStyle;
        hoverMode?: SeriesHoverMode;
        hoverStyle?: {
            border?: {
                color?: string | undefined;
                dashStyle?: DashStyle | undefined;
                visible?: boolean;
                width?: number;
            };
            color?: ChartsColor | string | undefined;
            dashStyle?: DashStyle;
            hatching?: {
                direction?: HatchDirection;
                opacity?: number;
                step?: number;
                width?: number;
            };
            highlight?: boolean;
            width?: number;
        };
        ignoreEmptyPoints?: boolean;
        label?: {
            argumentFormat?: Format | undefined;
            backgroundColor?: string | undefined;
            border?: {
                color?: string | undefined;
                dashStyle?: DashStyle | undefined;
                visible?: boolean;
                width?: number;
            };
            connector?: {
                color?: string | undefined;
                visible?: boolean;
                width?: number;
            };
            customizeText?: ((pointInfo: any) => string);
            displayFormat?: string | undefined;
            font?: Font;
            format?: Format | undefined;
            position?: RelativePosition;
            rotationAngle?: number;
            showForZeroValues?: boolean;
            visible?: boolean;
        };
        line?: any;
        maxLabelCount?: number | undefined;
        minBarSize?: number | undefined;
        opacity?: number;
        point?: {
            border?: {
                color?: string | undefined;
                visible?: boolean;
                width?: number;
            };
            color?: ChartsColor | string | undefined;
            hoverMode?: PointInteractionMode;
            hoverStyle?: {
                border?: {
                    color?: string | undefined;
                    visible?: boolean;
                    width?: number;
                };
                color?: ChartsColor | string | undefined;
                size?: number;
            };
            image?: string | undefined | {
                height?: number;
                url?: string | undefined;
                width?: number;
            };
            selectionMode?: PointInteractionMode;
            selectionStyle?: {
                border?: {
                    color?: string | undefined;
                    visible?: boolean;
                    width?: number;
                };
                color?: ChartsColor | string | undefined;
                size?: number;
            };
            size?: number;
            symbol?: PointSymbol;
            visible?: boolean;
        };
        scatter?: any;
        selectionMode?: SeriesSelectionMode;
        selectionStyle?: {
            border?: {
                color?: string | undefined;
                dashStyle?: DashStyle | undefined;
                visible?: boolean;
                width?: number;
            };
            color?: ChartsColor | string | undefined;
            dashStyle?: DashStyle;
            hatching?: {
                direction?: HatchDirection;
                opacity?: number;
                step?: number;
                width?: number;
            };
            highlight?: boolean;
            width?: number;
        };
        showInLegend?: boolean;
        stack?: string;
        stackedbar?: any;
        tagField?: string;
        type?: PolarChartSeriesType;
        valueErrorBar?: {
            color?: string;
            displayMode?: ValueErrorBarDisplayMode;
            edgeLength?: number;
            highValueField?: string | undefined;
            lineWidth?: number;
            lowValueField?: string | undefined;
            opacity?: number | undefined;
            type?: undefined | ValueErrorBarType;
            value?: number;
        };
        valueField?: string;
        visible?: boolean;
        width?: number;
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    containerBackgroundColorChange: EventEmitter<string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    customizeAnnotationChange: EventEmitter<((annotation: dxPolarChartAnnotationConfig | any) => dxPolarChartAnnotationConfig) | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    customizeLabelChange: EventEmitter<((pointInfo: any) => SeriesLabel)>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    customizePointChange: EventEmitter<((pointInfo: any) => SeriesPoint)>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    dataPrepareSettingsChange: EventEmitter<{
        checkTypeForAllData?: boolean;
        convertToAxisDataType?: boolean;
        sortingMethod?: boolean | ((a: {
            arg: Date | number | string;
            val: Date | number | string;
        }, b: {
            arg: Date | number | string;
            val: Date | number | string;
        }) => number);
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    dataSourceChange: EventEmitter<Array<any> | DataSource | DataSourceOptions | null | Store | string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    disabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    elementAttrChange: EventEmitter<Record<string, any>>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    encodeHtmlChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    exportChange: EventEmitter<{
        backgroundColor?: string;
        enabled?: boolean;
        fileName?: string;
        formats?: Array<ExportFormat>;
        margin?: number;
        printingEnabled?: boolean;
        svgToCanvas?: ((svg: any, canvas: any) => any) | undefined;
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    legendChange: EventEmitter<{
        backgroundColor?: string | undefined;
        border?: {
            color?: string;
            cornerRadius?: number;
            dashStyle?: DashStyle;
            opacity?: number | undefined;
            visible?: boolean;
            width?: number;
        };
        columnCount?: number;
        columnItemSpacing?: number;
        customizeHint?: ((seriesInfo: {
            seriesColor: string;
            seriesIndex: number;
            seriesName: any;
        }) => string);
        customizeItems?: ((items: Array<LegendItem>) => Array<LegendItem>);
        customizeText?: ((seriesInfo: {
            seriesColor: string;
            seriesIndex: number;
            seriesName: any;
        }) => string);
        font?: Font;
        horizontalAlignment?: HorizontalAlignment;
        hoverMode?: LegendHoverMode;
        itemsAlignment?: HorizontalAlignment | undefined;
        itemTextPosition?: Position | undefined;
        margin?: number | {
            bottom?: number;
            left?: number;
            right?: number;
            top?: number;
        };
        markerSize?: number;
        markerTemplate?: any;
        orientation?: Orientation | undefined;
        paddingLeftRight?: number;
        paddingTopBottom?: number;
        rowCount?: number;
        rowItemSpacing?: number;
        title?: string | {
            font?: Font;
            horizontalAlignment?: HorizontalAlignment | undefined;
            margin?: {
                bottom?: number;
                left?: number;
                right?: number;
                top?: number;
            };
            placeholderSize?: number | undefined;
            subtitle?: string | {
                font?: Font;
                offset?: number;
                text?: string | undefined;
            };
            text?: string | undefined;
            verticalAlignment?: VerticalEdge;
        };
        verticalAlignment?: VerticalEdge;
        visible?: boolean;
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    loadingIndicatorChange: EventEmitter<{
        backgroundColor?: string;
        enabled?: boolean;
        font?: Font;
        show?: boolean;
        text?: string;
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    marginChange: EventEmitter<{
        bottom?: number;
        left?: number;
        right?: number;
        top?: number;
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    negativesAsZeroesChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    paletteChange: EventEmitter<Array<string> | Palette>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    paletteExtensionModeChange: EventEmitter<PaletteExtensionMode>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    pathModifiedChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    pointSelectionModeChange: EventEmitter<SingleOrMultiple>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    redrawOnResizeChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    resolveLabelOverlappingChange: EventEmitter<LabelOverlap>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    rtlEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    seriesChange: EventEmitter<Array<PolarChartSeries> | PolarChartSeries | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    seriesSelectionModeChange: EventEmitter<SingleOrMultiple>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    seriesTemplateChange: EventEmitter<any>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    sizeChange: EventEmitter<{
        height?: number | undefined;
        width?: number | undefined;
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    themeChange: EventEmitter<Theme>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    titleChange: EventEmitter<string | {
        font?: Font;
        horizontalAlignment?: HorizontalAlignment;
        margin?: number | {
            bottom?: number;
            left?: number;
            right?: number;
            top?: number;
        };
        placeholderSize?: number | undefined;
        subtitle?: string | {
            font?: Font;
            offset?: number;
            text?: string | undefined;
            textOverflow?: TextOverflow;
            wordWrap?: WordWrap;
        };
        text?: string | undefined;
        textOverflow?: TextOverflow;
        verticalAlignment?: VerticalEdge;
        wordWrap?: WordWrap;
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    tooltipChange: EventEmitter<{
        argumentFormat?: Format | undefined;
        arrowLength?: number;
        border?: {
            color?: string;
            dashStyle?: DashStyle;
            opacity?: number | undefined;
            visible?: boolean;
            width?: number;
        };
        color?: string;
        container?: any | string | undefined;
        contentTemplate?: any;
        cornerRadius?: number;
        customizeTooltip?: ((pointInfo: dxPolarChartPointInfo) => Record<string, any>) | undefined;
        enabled?: boolean;
        font?: Font;
        format?: Format | undefined;
        interactive?: boolean;
        opacity?: number | undefined;
        paddingLeftRight?: number;
        paddingTopBottom?: number;
        shadow?: {
            blur?: number;
            color?: string;
            offsetX?: number;
            offsetY?: number;
            opacity?: number;
        };
        shared?: boolean;
        zIndex?: number | undefined;
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    useSpiderWebChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    valueAxisChange: EventEmitter<{
        allowDecimals?: boolean | undefined;
        axisDivisionFactor?: number;
        categories?: Array<Date | number | string>;
        color?: string;
        constantLines?: {
            color?: string;
            dashStyle?: DashStyle;
            displayBehindSeries?: boolean;
            extendAxis?: boolean;
            label?: {
                font?: Font;
                text?: string | undefined;
                visible?: boolean;
            };
            value?: Date | number | string | undefined;
            width?: number;
        }[];
        constantLineStyle?: {
            color?: string;
            dashStyle?: DashStyle;
            label?: {
                font?: Font;
                visible?: boolean;
            };
            width?: number;
        };
        discreteAxisDivisionMode?: DiscreteAxisDivisionMode;
        endOnTick?: boolean;
        grid?: {
            color?: string;
            opacity?: number | undefined;
            visible?: boolean;
            width?: number;
        };
        inverted?: boolean;
        label?: {
            customizeHint?: ((axisValue: {
                value: Date | number | string;
                valueText: string;
            }) => string);
            customizeText?: ((axisValue: {
                value: Date | number | string;
                valueText: string;
            }) => string);
            font?: Font;
            format?: Format | undefined;
            indentFromAxis?: number;
            overlappingBehavior?: LabelOverlap;
            visible?: boolean;
        };
        linearThreshold?: number | undefined;
        logarithmBase?: number;
        maxValueMargin?: number | undefined;
        minorGrid?: {
            color?: string;
            opacity?: number | undefined;
            visible?: boolean;
            width?: number;
        };
        minorTick?: {
            color?: string;
            length?: number;
            opacity?: number;
            visible?: boolean;
            width?: number;
        };
        minorTickCount?: number | undefined;
        minorTickInterval?: number | TimeInterval | {
            days?: number;
            hours?: number;
            milliseconds?: number;
            minutes?: number;
            months?: number;
            quarters?: number;
            seconds?: number;
            weeks?: number;
            years?: number;
        };
        minValueMargin?: number | undefined;
        minVisualRangeLength?: number | TimeInterval | undefined | {
            days?: number;
            hours?: number;
            milliseconds?: number;
            minutes?: number;
            months?: number;
            quarters?: number;
            seconds?: number;
            weeks?: number;
            years?: number;
        };
        opacity?: number | undefined;
        showZero?: boolean | undefined;
        strips?: {
            color?: string | undefined;
            endValue?: Date | number | string | undefined;
            label?: {
                font?: Font;
                text?: string | undefined;
            };
            startValue?: Date | number | string | undefined;
        }[];
        stripStyle?: {
            label?: {
                font?: Font;
            };
        };
        tick?: {
            color?: string;
            length?: number;
            opacity?: number | undefined;
            visible?: boolean;
            width?: number;
        };
        tickInterval?: number | TimeInterval | {
            days?: number;
            hours?: number;
            milliseconds?: number;
            minutes?: number;
            months?: number;
            quarters?: number;
            seconds?: number;
            weeks?: number;
            years?: number;
        };
        type?: AxisScaleType | undefined;
        valueMarginsEnabled?: boolean;
        valueType?: ChartsDataType | undefined;
        visible?: boolean;
        visualRange?: Array<Date | number | string> | CommonChartTypes.VisualRange;
        visualRangeUpdateMode?: ValueAxisVisualRangeUpdateMode;
        wholeRange?: Array<Date | number | string> | undefined | CommonChartTypes.VisualRange;
        width?: number;
    }>;
    constructor(elementRef: ElementRef, ngZone: NgZone, templateHost: DxTemplateHost, _watcherHelper: WatcherHelper, _idh: IterableDifferHelper, optionHost: NestedOptionHost, transferState: TransferState, platformId: any);
    protected _createInstance(element: any, options: any): DxPolarChart;
    ngOnDestroy(): void;
    ngOnChanges(changes: SimpleChanges): void;
    setupChanges(prop: string, changes: SimpleChanges): void;
    ngDoCheck(): void;
    _setOption(name: string, value: any): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxPolarChartComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxPolarChartComponent, "dx-polar-chart", never, { "adaptiveLayout": { "alias": "adaptiveLayout"; "required": false; }; "animation": { "alias": "animation"; "required": false; }; "annotations": { "alias": "annotations"; "required": false; }; "argumentAxis": { "alias": "argumentAxis"; "required": false; }; "barGroupPadding": { "alias": "barGroupPadding"; "required": false; }; "barGroupWidth": { "alias": "barGroupWidth"; "required": false; }; "commonAnnotationSettings": { "alias": "commonAnnotationSettings"; "required": false; }; "commonAxisSettings": { "alias": "commonAxisSettings"; "required": false; }; "commonSeriesSettings": { "alias": "commonSeriesSettings"; "required": false; }; "containerBackgroundColor": { "alias": "containerBackgroundColor"; "required": false; }; "customizeAnnotation": { "alias": "customizeAnnotation"; "required": false; }; "customizeLabel": { "alias": "customizeLabel"; "required": false; }; "customizePoint": { "alias": "customizePoint"; "required": false; }; "dataPrepareSettings": { "alias": "dataPrepareSettings"; "required": false; }; "dataSource": { "alias": "dataSource"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "elementAttr": { "alias": "elementAttr"; "required": false; }; "encodeHtml": { "alias": "encodeHtml"; "required": false; }; "export": { "alias": "export"; "required": false; }; "legend": { "alias": "legend"; "required": false; }; "loadingIndicator": { "alias": "loadingIndicator"; "required": false; }; "margin": { "alias": "margin"; "required": false; }; "negativesAsZeroes": { "alias": "negativesAsZeroes"; "required": false; }; "palette": { "alias": "palette"; "required": false; }; "paletteExtensionMode": { "alias": "paletteExtensionMode"; "required": false; }; "pathModified": { "alias": "pathModified"; "required": false; }; "pointSelectionMode": { "alias": "pointSelectionMode"; "required": false; }; "redrawOnResize": { "alias": "redrawOnResize"; "required": false; }; "resolveLabelOverlapping": { "alias": "resolveLabelOverlapping"; "required": false; }; "rtlEnabled": { "alias": "rtlEnabled"; "required": false; }; "series": { "alias": "series"; "required": false; }; "seriesSelectionMode": { "alias": "seriesSelectionMode"; "required": false; }; "seriesTemplate": { "alias": "seriesTemplate"; "required": false; }; "size": { "alias": "size"; "required": false; }; "theme": { "alias": "theme"; "required": false; }; "title": { "alias": "title"; "required": false; }; "tooltip": { "alias": "tooltip"; "required": false; }; "useSpiderWeb": { "alias": "useSpiderWeb"; "required": false; }; "valueAxis": { "alias": "valueAxis"; "required": false; }; }, { "onArgumentAxisClick": "onArgumentAxisClick"; "onDisposing": "onDisposing"; "onDone": "onDone"; "onDrawn": "onDrawn"; "onExported": "onExported"; "onExporting": "onExporting"; "onFileSaving": "onFileSaving"; "onIncidentOccurred": "onIncidentOccurred"; "onInitialized": "onInitialized"; "onLegendClick": "onLegendClick"; "onOptionChanged": "onOptionChanged"; "onPointClick": "onPointClick"; "onPointHoverChanged": "onPointHoverChanged"; "onPointSelectionChanged": "onPointSelectionChanged"; "onSeriesClick": "onSeriesClick"; "onSeriesHoverChanged": "onSeriesHoverChanged"; "onSeriesSelectionChanged": "onSeriesSelectionChanged"; "onTooltipHidden": "onTooltipHidden"; "onTooltipShown": "onTooltipShown"; "onZoomEnd": "onZoomEnd"; "onZoomStart": "onZoomStart"; "adaptiveLayoutChange": "adaptiveLayoutChange"; "animationChange": "animationChange"; "annotationsChange": "annotationsChange"; "argumentAxisChange": "argumentAxisChange"; "barGroupPaddingChange": "barGroupPaddingChange"; "barGroupWidthChange": "barGroupWidthChange"; "commonAnnotationSettingsChange": "commonAnnotationSettingsChange"; "commonAxisSettingsChange": "commonAxisSettingsChange"; "commonSeriesSettingsChange": "commonSeriesSettingsChange"; "containerBackgroundColorChange": "containerBackgroundColorChange"; "customizeAnnotationChange": "customizeAnnotationChange"; "customizeLabelChange": "customizeLabelChange"; "customizePointChange": "customizePointChange"; "dataPrepareSettingsChange": "dataPrepareSettingsChange"; "dataSourceChange": "dataSourceChange"; "disabledChange": "disabledChange"; "elementAttrChange": "elementAttrChange"; "encodeHtmlChange": "encodeHtmlChange"; "exportChange": "exportChange"; "legendChange": "legendChange"; "loadingIndicatorChange": "loadingIndicatorChange"; "marginChange": "marginChange"; "negativesAsZeroesChange": "negativesAsZeroesChange"; "paletteChange": "paletteChange"; "paletteExtensionModeChange": "paletteExtensionModeChange"; "pathModifiedChange": "pathModifiedChange"; "pointSelectionModeChange": "pointSelectionModeChange"; "redrawOnResizeChange": "redrawOnResizeChange"; "resolveLabelOverlappingChange": "resolveLabelOverlappingChange"; "rtlEnabledChange": "rtlEnabledChange"; "seriesChange": "seriesChange"; "seriesSelectionModeChange": "seriesSelectionModeChange"; "seriesTemplateChange": "seriesTemplateChange"; "sizeChange": "sizeChange"; "themeChange": "themeChange"; "titleChange": "titleChange"; "tooltipChange": "tooltipChange"; "useSpiderWebChange": "useSpiderWebChange"; "valueAxisChange": "valueAxisChange"; }, ["_annotationsContentChildren", "_constantLinesContentChildren", "_seriesContentChildren", "_stripsContentChildren"], never, true, never>;
}
declare class DxPolarChartModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxPolarChartModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxPolarChartModule, never, [typeof DxPolarChartComponent, typeof i1.DxoAdaptiveLayoutModule, typeof i1.DxoAnimationModule, typeof i1.DxiAnnotationModule, typeof i1.DxoBorderModule, typeof i1.DxoFontModule, typeof i1.DxoImageModule, typeof i1.DxoShadowModule, typeof i1.DxoArgumentAxisModule, typeof i1.DxiConstantLineModule, typeof i1.DxoLabelModule, typeof i1.DxoConstantLineStyleModule, typeof i1.DxoGridModule, typeof i1.DxoFormatModule, typeof i1.DxoMinorGridModule, typeof i1.DxoMinorTickModule, typeof i1.DxoMinorTickIntervalModule, typeof i1.DxiStripModule, typeof i1.DxoStripStyleModule, typeof i1.DxoTickModule, typeof i1.DxoTickIntervalModule, typeof i1.DxoCommonAnnotationSettingsModule, typeof i1.DxoCommonAxisSettingsModule, typeof i1.DxoCommonSeriesSettingsModule, typeof i1.DxoAreaModule, typeof i1.DxoHoverStyleModule, typeof i1.DxoHatchingModule, typeof i1.DxoConnectorModule, typeof i1.DxoPointModule, typeof i1.DxoSelectionStyleModule, typeof i1.DxoValueErrorBarModule, typeof i1.DxoBarModule, typeof i1.DxoColorModule, typeof i1.DxoArgumentFormatModule, typeof i1.DxoLineModule, typeof i1.DxoScatterModule, typeof i1.DxoStackedbarModule, typeof i1.DxoDataPrepareSettingsModule, typeof i1.DxoExportModule, typeof i1.DxoLegendModule, typeof i1.DxoMarginModule, typeof i1.DxoTitleModule, typeof i1.DxoSubtitleModule, typeof i1.DxoLoadingIndicatorModule, typeof i1.DxiSeriesModule, typeof i1.DxoSeriesTemplateModule, typeof i1.DxoSizeModule, typeof i1.DxoTooltipModule, typeof i1.DxoValueAxisModule, typeof i1.DxoMinVisualRangeLengthModule, typeof i2.DxoPolarChartAdaptiveLayoutModule, typeof i2.DxoPolarChartAnimationModule, typeof i2.DxiPolarChartAnnotationModule, typeof i2.DxoPolarChartAnnotationBorderModule, typeof i2.DxoPolarChartArgumentAxisModule, typeof i2.DxoPolarChartArgumentAxisMinorTickModule, typeof i2.DxoPolarChartArgumentAxisTickModule, typeof i2.DxoPolarChartArgumentFormatModule, typeof i2.DxoPolarChartAxisLabelModule, typeof i2.DxoPolarChartBorderModule, typeof i2.DxoPolarChartColorModule, typeof i2.DxoPolarChartCommonAnnotationSettingsModule, typeof i2.DxoPolarChartCommonAxisSettingsModule, typeof i2.DxoPolarChartCommonAxisSettingsLabelModule, typeof i2.DxoPolarChartCommonAxisSettingsMinorTickModule, typeof i2.DxoPolarChartCommonAxisSettingsTickModule, typeof i2.DxoPolarChartCommonSeriesSettingsModule, typeof i2.DxoPolarChartCommonSeriesSettingsHoverStyleModule, typeof i2.DxoPolarChartCommonSeriesSettingsLabelModule, typeof i2.DxoPolarChartCommonSeriesSettingsSelectionStyleModule, typeof i2.DxoPolarChartConnectorModule, typeof i2.DxiPolarChartConstantLineModule, typeof i2.DxoPolarChartConstantLineLabelModule, typeof i2.DxoPolarChartConstantLineStyleModule, typeof i2.DxoPolarChartConstantLineStyleLabelModule, typeof i2.DxoPolarChartDataPrepareSettingsModule, typeof i2.DxoPolarChartExportModule, typeof i2.DxoPolarChartFontModule, typeof i2.DxoPolarChartFormatModule, typeof i2.DxoPolarChartGridModule, typeof i2.DxoPolarChartHatchingModule, typeof i2.DxoPolarChartHoverStyleModule, typeof i2.DxoPolarChartImageModule, typeof i2.DxoPolarChartLabelModule, typeof i2.DxoPolarChartLegendModule, typeof i2.DxoPolarChartLegendTitleModule, typeof i2.DxoPolarChartLegendTitleSubtitleModule, typeof i2.DxoPolarChartLengthModule, typeof i2.DxoPolarChartLoadingIndicatorModule, typeof i2.DxoPolarChartMarginModule, typeof i2.DxoPolarChartMinorGridModule, typeof i2.DxoPolarChartMinorTickModule, typeof i2.DxoPolarChartMinorTickIntervalModule, typeof i2.DxoPolarChartMinVisualRangeLengthModule, typeof i2.DxoPolarChartPointModule, typeof i2.DxoPolarChartPointBorderModule, typeof i2.DxoPolarChartPointHoverStyleModule, typeof i2.DxoPolarChartPointSelectionStyleModule, typeof i2.DxoPolarChartPolarChartTitleModule, typeof i2.DxoPolarChartPolarChartTitleSubtitleModule, typeof i2.DxoPolarChartSelectionStyleModule, typeof i2.DxiPolarChartSeriesModule, typeof i2.DxoPolarChartSeriesBorderModule, typeof i2.DxoPolarChartSeriesTemplateModule, typeof i2.DxoPolarChartShadowModule, typeof i2.DxoPolarChartSizeModule, typeof i2.DxiPolarChartStripModule, typeof i2.DxoPolarChartStripLabelModule, typeof i2.DxoPolarChartStripStyleModule, typeof i2.DxoPolarChartStripStyleLabelModule, typeof i2.DxoPolarChartSubtitleModule, typeof i2.DxoPolarChartTickModule, typeof i2.DxoPolarChartTickIntervalModule, typeof i2.DxoPolarChartTitleModule, typeof i2.DxoPolarChartTooltipModule, typeof i2.DxoPolarChartTooltipBorderModule, typeof i2.DxoPolarChartValueAxisModule, typeof i2.DxoPolarChartValueErrorBarModule, typeof i2.DxoPolarChartVisualRangeModule, typeof i2.DxoPolarChartWholeRangeModule, typeof i3.DxIntegrationModule, typeof i3.DxTemplateModule], [typeof DxPolarChartComponent, typeof i1.DxoAdaptiveLayoutModule, typeof i1.DxoAnimationModule, typeof i1.DxiAnnotationModule, typeof i1.DxoBorderModule, typeof i1.DxoFontModule, typeof i1.DxoImageModule, typeof i1.DxoShadowModule, typeof i1.DxoArgumentAxisModule, typeof i1.DxiConstantLineModule, typeof i1.DxoLabelModule, typeof i1.DxoConstantLineStyleModule, typeof i1.DxoGridModule, typeof i1.DxoFormatModule, typeof i1.DxoMinorGridModule, typeof i1.DxoMinorTickModule, typeof i1.DxoMinorTickIntervalModule, typeof i1.DxiStripModule, typeof i1.DxoStripStyleModule, typeof i1.DxoTickModule, typeof i1.DxoTickIntervalModule, typeof i1.DxoCommonAnnotationSettingsModule, typeof i1.DxoCommonAxisSettingsModule, typeof i1.DxoCommonSeriesSettingsModule, typeof i1.DxoAreaModule, typeof i1.DxoHoverStyleModule, typeof i1.DxoHatchingModule, typeof i1.DxoConnectorModule, typeof i1.DxoPointModule, typeof i1.DxoSelectionStyleModule, typeof i1.DxoValueErrorBarModule, typeof i1.DxoBarModule, typeof i1.DxoColorModule, typeof i1.DxoArgumentFormatModule, typeof i1.DxoLineModule, typeof i1.DxoScatterModule, typeof i1.DxoStackedbarModule, typeof i1.DxoDataPrepareSettingsModule, typeof i1.DxoExportModule, typeof i1.DxoLegendModule, typeof i1.DxoMarginModule, typeof i1.DxoTitleModule, typeof i1.DxoSubtitleModule, typeof i1.DxoLoadingIndicatorModule, typeof i1.DxiSeriesModule, typeof i1.DxoSeriesTemplateModule, typeof i1.DxoSizeModule, typeof i1.DxoTooltipModule, typeof i1.DxoValueAxisModule, typeof i1.DxoMinVisualRangeLengthModule, typeof i2.DxoPolarChartAdaptiveLayoutModule, typeof i2.DxoPolarChartAnimationModule, typeof i2.DxiPolarChartAnnotationModule, typeof i2.DxoPolarChartAnnotationBorderModule, typeof i2.DxoPolarChartArgumentAxisModule, typeof i2.DxoPolarChartArgumentAxisMinorTickModule, typeof i2.DxoPolarChartArgumentAxisTickModule, typeof i2.DxoPolarChartArgumentFormatModule, typeof i2.DxoPolarChartAxisLabelModule, typeof i2.DxoPolarChartBorderModule, typeof i2.DxoPolarChartColorModule, typeof i2.DxoPolarChartCommonAnnotationSettingsModule, typeof i2.DxoPolarChartCommonAxisSettingsModule, typeof i2.DxoPolarChartCommonAxisSettingsLabelModule, typeof i2.DxoPolarChartCommonAxisSettingsMinorTickModule, typeof i2.DxoPolarChartCommonAxisSettingsTickModule, typeof i2.DxoPolarChartCommonSeriesSettingsModule, typeof i2.DxoPolarChartCommonSeriesSettingsHoverStyleModule, typeof i2.DxoPolarChartCommonSeriesSettingsLabelModule, typeof i2.DxoPolarChartCommonSeriesSettingsSelectionStyleModule, typeof i2.DxoPolarChartConnectorModule, typeof i2.DxiPolarChartConstantLineModule, typeof i2.DxoPolarChartConstantLineLabelModule, typeof i2.DxoPolarChartConstantLineStyleModule, typeof i2.DxoPolarChartConstantLineStyleLabelModule, typeof i2.DxoPolarChartDataPrepareSettingsModule, typeof i2.DxoPolarChartExportModule, typeof i2.DxoPolarChartFontModule, typeof i2.DxoPolarChartFormatModule, typeof i2.DxoPolarChartGridModule, typeof i2.DxoPolarChartHatchingModule, typeof i2.DxoPolarChartHoverStyleModule, typeof i2.DxoPolarChartImageModule, typeof i2.DxoPolarChartLabelModule, typeof i2.DxoPolarChartLegendModule, typeof i2.DxoPolarChartLegendTitleModule, typeof i2.DxoPolarChartLegendTitleSubtitleModule, typeof i2.DxoPolarChartLengthModule, typeof i2.DxoPolarChartLoadingIndicatorModule, typeof i2.DxoPolarChartMarginModule, typeof i2.DxoPolarChartMinorGridModule, typeof i2.DxoPolarChartMinorTickModule, typeof i2.DxoPolarChartMinorTickIntervalModule, typeof i2.DxoPolarChartMinVisualRangeLengthModule, typeof i2.DxoPolarChartPointModule, typeof i2.DxoPolarChartPointBorderModule, typeof i2.DxoPolarChartPointHoverStyleModule, typeof i2.DxoPolarChartPointSelectionStyleModule, typeof i2.DxoPolarChartPolarChartTitleModule, typeof i2.DxoPolarChartPolarChartTitleSubtitleModule, typeof i2.DxoPolarChartSelectionStyleModule, typeof i2.DxiPolarChartSeriesModule, typeof i2.DxoPolarChartSeriesBorderModule, typeof i2.DxoPolarChartSeriesTemplateModule, typeof i2.DxoPolarChartShadowModule, typeof i2.DxoPolarChartSizeModule, typeof i2.DxiPolarChartStripModule, typeof i2.DxoPolarChartStripLabelModule, typeof i2.DxoPolarChartStripStyleModule, typeof i2.DxoPolarChartStripStyleLabelModule, typeof i2.DxoPolarChartSubtitleModule, typeof i2.DxoPolarChartTickModule, typeof i2.DxoPolarChartTickIntervalModule, typeof i2.DxoPolarChartTitleModule, typeof i2.DxoPolarChartTooltipModule, typeof i2.DxoPolarChartTooltipBorderModule, typeof i2.DxoPolarChartValueAxisModule, typeof i2.DxoPolarChartValueErrorBarModule, typeof i2.DxoPolarChartVisualRangeModule, typeof i2.DxoPolarChartWholeRangeModule, typeof i3.DxTemplateModule]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxPolarChartModule>;
}

export { DxPolarChartComponent, DxPolarChartModule };
//# sourceMappingURL=index.d.ts.map
