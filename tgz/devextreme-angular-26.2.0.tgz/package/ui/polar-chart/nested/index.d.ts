import * as i0 from '@angular/core';
import { OnDestroy, OnInit, AfterViewInit, Renderer2, ElementRef, QueryList, EventEmitter } from '@angular/core';
import { NestedOption, NestedOptionHost, CollectionNestedOption, IDxTemplateHost, DxTemplateHost, DxTemplateDirective } from 'devextreme-angular/core';
import * as CommonChartTypes from 'devextreme/common/charts';
import { AnimationEaseMode, DashStyle, Font, TextOverflow, AnnotationType, WordWrap, ChartsDataType, DiscreteAxisDivisionMode, ArgumentAxisHoverMode, LabelOverlap, TimeInterval, AxisScaleType, ChartsColor, HatchDirection, RelativePosition, SeriesHoverMode, PointInteractionMode, PointSymbol, SeriesSelectionMode, ValueErrorBarDisplayMode, ValueErrorBarType, LegendItem, LegendHoverMode, ValueAxisVisualRangeUpdateMode } from 'devextreme/common/charts';
import { dxPolarChartAnnotationConfig, PolarChartSeriesType, PolarChartSeries, dxPolarChartPointInfo } from 'devextreme/viz/polar_chart';
import { Format } from 'devextreme/common/core/localization';
import { Format as Format$1, ExportFormat, HorizontalAlignment, VerticalEdge, Position, Orientation } from 'devextreme/common';

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoPolarChartAdaptiveLayoutComponent extends NestedOption implements OnDestroy, OnInit {
    get height(): number;
    set height(value: number);
    get keepLabels(): boolean;
    set keepLabels(value: boolean);
    get width(): number;
    set width(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPolarChartAdaptiveLayoutComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoPolarChartAdaptiveLayoutComponent, "dxo-polar-chart-adaptive-layout", never, { "height": { "alias": "height"; "required": false; }; "keepLabels": { "alias": "keepLabels"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoPolarChartAdaptiveLayoutModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPolarChartAdaptiveLayoutModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoPolarChartAdaptiveLayoutModule, never, [typeof DxoPolarChartAdaptiveLayoutComponent], [typeof DxoPolarChartAdaptiveLayoutComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoPolarChartAdaptiveLayoutModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoPolarChartAnimationComponent extends NestedOption implements OnDestroy, OnInit {
    get duration(): number;
    set duration(value: number);
    get easing(): AnimationEaseMode;
    set easing(value: AnimationEaseMode);
    get enabled(): boolean;
    set enabled(value: boolean);
    get maxPointCountSupported(): number;
    set maxPointCountSupported(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPolarChartAnimationComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoPolarChartAnimationComponent, "dxo-polar-chart-animation", never, { "duration": { "alias": "duration"; "required": false; }; "easing": { "alias": "easing"; "required": false; }; "enabled": { "alias": "enabled"; "required": false; }; "maxPointCountSupported": { "alias": "maxPointCountSupported"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoPolarChartAnimationModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPolarChartAnimationModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoPolarChartAnimationModule, never, [typeof DxoPolarChartAnimationComponent], [typeof DxoPolarChartAnimationComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoPolarChartAnimationModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoPolarChartAnnotationBorderComponent extends NestedOption implements OnDestroy, OnInit {
    get color(): string;
    set color(value: string);
    get cornerRadius(): number;
    set cornerRadius(value: number);
    get dashStyle(): DashStyle;
    set dashStyle(value: DashStyle);
    get opacity(): number | undefined;
    set opacity(value: number | undefined);
    get visible(): boolean;
    set visible(value: boolean);
    get width(): number;
    set width(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPolarChartAnnotationBorderComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoPolarChartAnnotationBorderComponent, "dxo-polar-chart-annotation-border", never, { "color": { "alias": "color"; "required": false; }; "cornerRadius": { "alias": "cornerRadius"; "required": false; }; "dashStyle": { "alias": "dashStyle"; "required": false; }; "opacity": { "alias": "opacity"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoPolarChartAnnotationBorderModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPolarChartAnnotationBorderModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoPolarChartAnnotationBorderModule, never, [typeof DxoPolarChartAnnotationBorderComponent], [typeof DxoPolarChartAnnotationBorderComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoPolarChartAnnotationBorderModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxiPolarChartAnnotationComponent extends CollectionNestedOption implements AfterViewInit, IDxTemplateHost {
    private renderer;
    private document;
    private element;
    get allowDragging(): boolean;
    set allowDragging(value: boolean);
    get angle(): number | undefined;
    set angle(value: number | undefined);
    get argument(): Date | number | string | undefined;
    set argument(value: Date | number | string | undefined);
    get arrowLength(): number;
    set arrowLength(value: number);
    get arrowWidth(): number;
    set arrowWidth(value: number);
    get border(): {
        color?: string;
        cornerRadius?: number;
        dashStyle?: DashStyle;
        opacity?: number | undefined;
        visible?: boolean;
        width?: number;
    };
    set border(value: {
        color?: string;
        cornerRadius?: number;
        dashStyle?: DashStyle;
        opacity?: number | undefined;
        visible?: boolean;
        width?: number;
    });
    get color(): string;
    set color(value: string);
    get customizeTooltip(): ((annotation: dxPolarChartAnnotationConfig | any) => Record<string, any>) | undefined;
    set customizeTooltip(value: ((annotation: dxPolarChartAnnotationConfig | any) => Record<string, any>) | undefined);
    get data(): any;
    set data(value: any);
    get description(): string | undefined;
    set description(value: string | undefined);
    get font(): Font;
    set font(value: Font);
    get height(): number | undefined;
    set height(value: number | undefined);
    get image(): string | {
        height?: number;
        url?: string | undefined;
        width?: number;
    };
    set image(value: string | {
        height?: number;
        url?: string | undefined;
        width?: number;
    });
    get name(): string | undefined;
    set name(value: string | undefined);
    get offsetX(): number | undefined;
    set offsetX(value: number | undefined);
    get offsetY(): number | undefined;
    set offsetY(value: number | undefined);
    get opacity(): number;
    set opacity(value: number);
    get paddingLeftRight(): number;
    set paddingLeftRight(value: number);
    get paddingTopBottom(): number;
    set paddingTopBottom(value: number);
    get radius(): number | undefined;
    set radius(value: number | undefined);
    get series(): string | undefined;
    set series(value: string | undefined);
    get shadow(): {
        blur?: number;
        color?: string;
        offsetX?: number;
        offsetY?: number;
        opacity?: number;
    };
    set shadow(value: {
        blur?: number;
        color?: string;
        offsetX?: number;
        offsetY?: number;
        opacity?: number;
    });
    get template(): any;
    set template(value: any);
    get text(): string | undefined;
    set text(value: string | undefined);
    get textOverflow(): TextOverflow;
    set textOverflow(value: TextOverflow);
    get tooltipEnabled(): boolean;
    set tooltipEnabled(value: boolean);
    get tooltipTemplate(): any;
    set tooltipTemplate(value: any);
    get type(): AnnotationType | undefined;
    set type(value: AnnotationType | undefined);
    get value(): Date | number | string | undefined;
    set value(value: Date | number | string | undefined);
    get width(): number | undefined;
    set width(value: number | undefined);
    get wordWrap(): WordWrap;
    set wordWrap(value: WordWrap);
    get x(): number | undefined;
    set x(value: number | undefined);
    get y(): number | undefined;
    set y(value: number | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost, renderer: Renderer2, document: any, templateHost: DxTemplateHost, element: ElementRef);
    setTemplate(template: DxTemplateDirective): void;
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiPolarChartAnnotationComponent, [{ host: true; skipSelf: true; }, { host: true; }, null, null, { host: true; }, null]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiPolarChartAnnotationComponent, "dxi-polar-chart-annotation", never, { "allowDragging": { "alias": "allowDragging"; "required": false; }; "angle": { "alias": "angle"; "required": false; }; "argument": { "alias": "argument"; "required": false; }; "arrowLength": { "alias": "arrowLength"; "required": false; }; "arrowWidth": { "alias": "arrowWidth"; "required": false; }; "border": { "alias": "border"; "required": false; }; "color": { "alias": "color"; "required": false; }; "customizeTooltip": { "alias": "customizeTooltip"; "required": false; }; "data": { "alias": "data"; "required": false; }; "description": { "alias": "description"; "required": false; }; "font": { "alias": "font"; "required": false; }; "height": { "alias": "height"; "required": false; }; "image": { "alias": "image"; "required": false; }; "name": { "alias": "name"; "required": false; }; "offsetX": { "alias": "offsetX"; "required": false; }; "offsetY": { "alias": "offsetY"; "required": false; }; "opacity": { "alias": "opacity"; "required": false; }; "paddingLeftRight": { "alias": "paddingLeftRight"; "required": false; }; "paddingTopBottom": { "alias": "paddingTopBottom"; "required": false; }; "radius": { "alias": "radius"; "required": false; }; "series": { "alias": "series"; "required": false; }; "shadow": { "alias": "shadow"; "required": false; }; "template": { "alias": "template"; "required": false; }; "text": { "alias": "text"; "required": false; }; "textOverflow": { "alias": "textOverflow"; "required": false; }; "tooltipEnabled": { "alias": "tooltipEnabled"; "required": false; }; "tooltipTemplate": { "alias": "tooltipTemplate"; "required": false; }; "type": { "alias": "type"; "required": false; }; "value": { "alias": "value"; "required": false; }; "width": { "alias": "width"; "required": false; }; "wordWrap": { "alias": "wordWrap"; "required": false; }; "x": { "alias": "x"; "required": false; }; "y": { "alias": "y"; "required": false; }; }, {}, never, ["*"], true, never>;
}
declare class DxiPolarChartAnnotationModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiPolarChartAnnotationModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiPolarChartAnnotationModule, never, [typeof DxiPolarChartAnnotationComponent], [typeof DxiPolarChartAnnotationComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiPolarChartAnnotationModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoPolarChartArgumentAxisMinorTickComponent extends NestedOption implements OnDestroy, OnInit {
    get color(): string;
    set color(value: string);
    get length(): number;
    set length(value: number);
    get opacity(): number;
    set opacity(value: number);
    get shift(): number;
    set shift(value: number);
    get visible(): boolean;
    set visible(value: boolean);
    get width(): number;
    set width(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPolarChartArgumentAxisMinorTickComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoPolarChartArgumentAxisMinorTickComponent, "dxo-polar-chart-argument-axis-minor-tick", never, { "color": { "alias": "color"; "required": false; }; "length": { "alias": "length"; "required": false; }; "opacity": { "alias": "opacity"; "required": false; }; "shift": { "alias": "shift"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoPolarChartArgumentAxisMinorTickModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPolarChartArgumentAxisMinorTickModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoPolarChartArgumentAxisMinorTickModule, never, [typeof DxoPolarChartArgumentAxisMinorTickComponent], [typeof DxoPolarChartArgumentAxisMinorTickComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoPolarChartArgumentAxisMinorTickModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoPolarChartArgumentAxisTickComponent extends NestedOption implements OnDestroy, OnInit {
    get color(): string;
    set color(value: string);
    get length(): number;
    set length(value: number);
    get opacity(): number | undefined;
    set opacity(value: number | undefined);
    get shift(): number;
    set shift(value: number);
    get visible(): boolean;
    set visible(value: boolean);
    get width(): number;
    set width(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPolarChartArgumentAxisTickComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoPolarChartArgumentAxisTickComponent, "dxo-polar-chart-argument-axis-tick", never, { "color": { "alias": "color"; "required": false; }; "length": { "alias": "length"; "required": false; }; "opacity": { "alias": "opacity"; "required": false; }; "shift": { "alias": "shift"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoPolarChartArgumentAxisTickModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPolarChartArgumentAxisTickModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoPolarChartArgumentAxisTickModule, never, [typeof DxoPolarChartArgumentAxisTickComponent], [typeof DxoPolarChartArgumentAxisTickComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoPolarChartArgumentAxisTickModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoPolarChartArgumentAxisComponent extends NestedOption implements OnDestroy, OnInit {
    set _constantLinesContentChildren(value: QueryList<CollectionNestedOption>);
    set _stripsContentChildren(value: QueryList<CollectionNestedOption>);
    get allowDecimals(): boolean | undefined;
    set allowDecimals(value: boolean | undefined);
    get argumentType(): ChartsDataType | undefined;
    set argumentType(value: ChartsDataType | undefined);
    get axisDivisionFactor(): number;
    set axisDivisionFactor(value: number);
    get categories(): Array<Date | number | string>;
    set categories(value: Array<Date | number | string>);
    get color(): string;
    set color(value: string);
    get constantLines(): {
        color?: string;
        dashStyle?: DashStyle;
        displayBehindSeries?: boolean;
        extendAxis?: boolean;
        label?: {
            font?: Font;
            text?: string | undefined;
            visible?: boolean;
        };
        value?: Date | number | string | undefined;
        width?: number;
    }[];
    set constantLines(value: {
        color?: string;
        dashStyle?: DashStyle;
        displayBehindSeries?: boolean;
        extendAxis?: boolean;
        label?: {
            font?: Font;
            text?: string | undefined;
            visible?: boolean;
        };
        value?: Date | number | string | undefined;
        width?: number;
    }[]);
    get constantLineStyle(): {
        color?: string;
        dashStyle?: DashStyle;
        label?: {
            font?: Font;
            visible?: boolean;
        };
        width?: number;
    };
    set constantLineStyle(value: {
        color?: string;
        dashStyle?: DashStyle;
        label?: {
            font?: Font;
            visible?: boolean;
        };
        width?: number;
    });
    get discreteAxisDivisionMode(): DiscreteAxisDivisionMode;
    set discreteAxisDivisionMode(value: DiscreteAxisDivisionMode);
    get endOnTick(): boolean | undefined;
    set endOnTick(value: boolean | undefined);
    get firstPointOnStartAngle(): boolean;
    set firstPointOnStartAngle(value: boolean);
    get grid(): {
        color?: string;
        opacity?: number | undefined;
        visible?: boolean;
        width?: number;
    };
    set grid(value: {
        color?: string;
        opacity?: number | undefined;
        visible?: boolean;
        width?: number;
    });
    get hoverMode(): ArgumentAxisHoverMode;
    set hoverMode(value: ArgumentAxisHoverMode);
    get inverted(): boolean;
    set inverted(value: boolean);
    get label(): {
        customizeHint?: ((argument: {
            value: Date | number | string;
            valueText: string;
        }) => string);
        customizeText?: ((argument: {
            value: Date | number | string;
            valueText: string;
        }) => string);
        font?: Font;
        format?: Format | undefined;
        indentFromAxis?: number;
        overlappingBehavior?: LabelOverlap;
        visible?: boolean;
    };
    set label(value: {
        customizeHint?: ((argument: {
            value: Date | number | string;
            valueText: string;
        }) => string);
        customizeText?: ((argument: {
            value: Date | number | string;
            valueText: string;
        }) => string);
        font?: Font;
        format?: Format | undefined;
        indentFromAxis?: number;
        overlappingBehavior?: LabelOverlap;
        visible?: boolean;
    });
    get linearThreshold(): number | undefined;
    set linearThreshold(value: number | undefined);
    get logarithmBase(): number;
    set logarithmBase(value: number);
    get minorGrid(): {
        color?: string;
        opacity?: number | undefined;
        visible?: boolean;
        width?: number;
    };
    set minorGrid(value: {
        color?: string;
        opacity?: number | undefined;
        visible?: boolean;
        width?: number;
    });
    get minorTick(): {
        color?: string;
        length?: number;
        opacity?: number;
        shift?: number;
        visible?: boolean;
        width?: number;
    };
    set minorTick(value: {
        color?: string;
        length?: number;
        opacity?: number;
        shift?: number;
        visible?: boolean;
        width?: number;
    });
    get minorTickCount(): number | undefined;
    set minorTickCount(value: number | undefined);
    get minorTickInterval(): number | TimeInterval | {
        days?: number;
        hours?: number;
        milliseconds?: number;
        minutes?: number;
        months?: number;
        quarters?: number;
        seconds?: number;
        weeks?: number;
        years?: number;
    };
    set minorTickInterval(value: number | TimeInterval | {
        days?: number;
        hours?: number;
        milliseconds?: number;
        minutes?: number;
        months?: number;
        quarters?: number;
        seconds?: number;
        weeks?: number;
        years?: number;
    });
    get opacity(): number | undefined;
    set opacity(value: number | undefined);
    get originValue(): number | undefined;
    set originValue(value: number | undefined);
    get period(): number | undefined;
    set period(value: number | undefined);
    get startAngle(): number;
    set startAngle(value: number);
    get strips(): {
        color?: string | undefined;
        endValue?: Date | number | string | undefined;
        label?: {
            font?: Font;
            text?: string | undefined;
        };
        startValue?: Date | number | string | undefined;
    }[];
    set strips(value: {
        color?: string | undefined;
        endValue?: Date | number | string | undefined;
        label?: {
            font?: Font;
            text?: string | undefined;
        };
        startValue?: Date | number | string | undefined;
    }[]);
    get stripStyle(): {
        label?: {
            font?: Font;
        };
    };
    set stripStyle(value: {
        label?: {
            font?: Font;
        };
    });
    get tick(): {
        color?: string;
        length?: number;
        opacity?: number | undefined;
        shift?: number;
        visible?: boolean;
        width?: number;
    };
    set tick(value: {
        color?: string;
        length?: number;
        opacity?: number | undefined;
        shift?: number;
        visible?: boolean;
        width?: number;
    });
    get tickInterval(): number | TimeInterval | {
        days?: number;
        hours?: number;
        milliseconds?: number;
        minutes?: number;
        months?: number;
        quarters?: number;
        seconds?: number;
        weeks?: number;
        years?: number;
    };
    set tickInterval(value: number | TimeInterval | {
        days?: number;
        hours?: number;
        milliseconds?: number;
        minutes?: number;
        months?: number;
        quarters?: number;
        seconds?: number;
        weeks?: number;
        years?: number;
    });
    get type(): AxisScaleType | undefined;
    set type(value: AxisScaleType | undefined);
    get visible(): boolean;
    set visible(value: boolean);
    get width(): number;
    set width(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPolarChartArgumentAxisComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoPolarChartArgumentAxisComponent, "dxo-polar-chart-argument-axis", never, { "allowDecimals": { "alias": "allowDecimals"; "required": false; }; "argumentType": { "alias": "argumentType"; "required": false; }; "axisDivisionFactor": { "alias": "axisDivisionFactor"; "required": false; }; "categories": { "alias": "categories"; "required": false; }; "color": { "alias": "color"; "required": false; }; "constantLines": { "alias": "constantLines"; "required": false; }; "constantLineStyle": { "alias": "constantLineStyle"; "required": false; }; "discreteAxisDivisionMode": { "alias": "discreteAxisDivisionMode"; "required": false; }; "endOnTick": { "alias": "endOnTick"; "required": false; }; "firstPointOnStartAngle": { "alias": "firstPointOnStartAngle"; "required": false; }; "grid": { "alias": "grid"; "required": false; }; "hoverMode": { "alias": "hoverMode"; "required": false; }; "inverted": { "alias": "inverted"; "required": false; }; "label": { "alias": "label"; "required": false; }; "linearThreshold": { "alias": "linearThreshold"; "required": false; }; "logarithmBase": { "alias": "logarithmBase"; "required": false; }; "minorGrid": { "alias": "minorGrid"; "required": false; }; "minorTick": { "alias": "minorTick"; "required": false; }; "minorTickCount": { "alias": "minorTickCount"; "required": false; }; "minorTickInterval": { "alias": "minorTickInterval"; "required": false; }; "opacity": { "alias": "opacity"; "required": false; }; "originValue": { "alias": "originValue"; "required": false; }; "period": { "alias": "period"; "required": false; }; "startAngle": { "alias": "startAngle"; "required": false; }; "strips": { "alias": "strips"; "required": false; }; "stripStyle": { "alias": "stripStyle"; "required": false; }; "tick": { "alias": "tick"; "required": false; }; "tickInterval": { "alias": "tickInterval"; "required": false; }; "type": { "alias": "type"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, ["_constantLinesContentChildren", "_stripsContentChildren"], never, true, never>;
}
declare class DxoPolarChartArgumentAxisModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPolarChartArgumentAxisModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoPolarChartArgumentAxisModule, never, [typeof DxoPolarChartArgumentAxisComponent], [typeof DxoPolarChartArgumentAxisComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoPolarChartArgumentAxisModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoPolarChartArgumentFormatComponent extends NestedOption implements OnDestroy, OnInit {
    get currency(): string;
    set currency(value: string);
    get formatter(): ((value: number | Date) => string);
    set formatter(value: ((value: number | Date) => string));
    get parser(): ((value: string) => number | Date);
    set parser(value: ((value: string) => number | Date));
    get precision(): number;
    set precision(value: number);
    get type(): Format$1 | string;
    set type(value: Format$1 | string);
    get useCurrencyAccountingStyle(): boolean;
    set useCurrencyAccountingStyle(value: boolean);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPolarChartArgumentFormatComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoPolarChartArgumentFormatComponent, "dxo-polar-chart-argument-format", never, { "currency": { "alias": "currency"; "required": false; }; "formatter": { "alias": "formatter"; "required": false; }; "parser": { "alias": "parser"; "required": false; }; "precision": { "alias": "precision"; "required": false; }; "type": { "alias": "type"; "required": false; }; "useCurrencyAccountingStyle": { "alias": "useCurrencyAccountingStyle"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoPolarChartArgumentFormatModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPolarChartArgumentFormatModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoPolarChartArgumentFormatModule, never, [typeof DxoPolarChartArgumentFormatComponent], [typeof DxoPolarChartArgumentFormatComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoPolarChartArgumentFormatModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoPolarChartAxisLabelComponent extends NestedOption implements OnDestroy, OnInit {
    get customizeHint(): ((argument: {
        value: Date | number | string;
        valueText: string;
    }) => string);
    set customizeHint(value: ((argument: {
        value: Date | number | string;
        valueText: string;
    }) => string));
    get customizeText(): ((argument: {
        value: Date | number | string;
        valueText: string;
    }) => string);
    set customizeText(value: ((argument: {
        value: Date | number | string;
        valueText: string;
    }) => string));
    get font(): Font;
    set font(value: Font);
    get format(): Format | undefined;
    set format(value: Format | undefined);
    get indentFromAxis(): number;
    set indentFromAxis(value: number);
    get overlappingBehavior(): LabelOverlap;
    set overlappingBehavior(value: LabelOverlap);
    get visible(): boolean;
    set visible(value: boolean);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPolarChartAxisLabelComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoPolarChartAxisLabelComponent, "dxo-polar-chart-axis-label", never, { "customizeHint": { "alias": "customizeHint"; "required": false; }; "customizeText": { "alias": "customizeText"; "required": false; }; "font": { "alias": "font"; "required": false; }; "format": { "alias": "format"; "required": false; }; "indentFromAxis": { "alias": "indentFromAxis"; "required": false; }; "overlappingBehavior": { "alias": "overlappingBehavior"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoPolarChartAxisLabelModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPolarChartAxisLabelModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoPolarChartAxisLabelModule, never, [typeof DxoPolarChartAxisLabelComponent], [typeof DxoPolarChartAxisLabelComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoPolarChartAxisLabelModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoPolarChartBorderComponent extends NestedOption implements OnDestroy, OnInit {
    get color(): string | undefined;
    set color(value: string | undefined);
    get cornerRadius(): number;
    set cornerRadius(value: number);
    get dashStyle(): DashStyle | undefined;
    set dashStyle(value: DashStyle | undefined);
    get opacity(): number | undefined;
    set opacity(value: number | undefined);
    get visible(): boolean;
    set visible(value: boolean);
    get width(): number;
    set width(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPolarChartBorderComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoPolarChartBorderComponent, "dxo-polar-chart-border", never, { "color": { "alias": "color"; "required": false; }; "cornerRadius": { "alias": "cornerRadius"; "required": false; }; "dashStyle": { "alias": "dashStyle"; "required": false; }; "opacity": { "alias": "opacity"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoPolarChartBorderModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPolarChartBorderModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoPolarChartBorderModule, never, [typeof DxoPolarChartBorderComponent], [typeof DxoPolarChartBorderComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoPolarChartBorderModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoPolarChartColorComponent extends NestedOption implements OnDestroy, OnInit {
    get base(): string | undefined;
    set base(value: string | undefined);
    get fillId(): string | undefined;
    set fillId(value: string | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPolarChartColorComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoPolarChartColorComponent, "dxo-polar-chart-color", never, { "base": { "alias": "base"; "required": false; }; "fillId": { "alias": "fillId"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoPolarChartColorModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPolarChartColorModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoPolarChartColorModule, never, [typeof DxoPolarChartColorComponent], [typeof DxoPolarChartColorComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoPolarChartColorModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoPolarChartCommonAnnotationSettingsComponent extends NestedOption implements AfterViewInit, OnDestroy, OnInit, IDxTemplateHost {
    private renderer;
    private document;
    private element;
    get allowDragging(): boolean;
    set allowDragging(value: boolean);
    get angle(): number | undefined;
    set angle(value: number | undefined);
    get argument(): Date | number | string | undefined;
    set argument(value: Date | number | string | undefined);
    get arrowLength(): number;
    set arrowLength(value: number);
    get arrowWidth(): number;
    set arrowWidth(value: number);
    get border(): {
        color?: string;
        cornerRadius?: number;
        dashStyle?: DashStyle;
        opacity?: number | undefined;
        visible?: boolean;
        width?: number;
    };
    set border(value: {
        color?: string;
        cornerRadius?: number;
        dashStyle?: DashStyle;
        opacity?: number | undefined;
        visible?: boolean;
        width?: number;
    });
    get color(): string;
    set color(value: string);
    get customizeTooltip(): ((annotation: dxPolarChartAnnotationConfig | any) => Record<string, any>) | undefined;
    set customizeTooltip(value: ((annotation: dxPolarChartAnnotationConfig | any) => Record<string, any>) | undefined);
    get data(): any;
    set data(value: any);
    get description(): string | undefined;
    set description(value: string | undefined);
    get font(): Font;
    set font(value: Font);
    get height(): number | undefined;
    set height(value: number | undefined);
    get image(): string | {
        height?: number;
        url?: string | undefined;
        width?: number;
    };
    set image(value: string | {
        height?: number;
        url?: string | undefined;
        width?: number;
    });
    get offsetX(): number | undefined;
    set offsetX(value: number | undefined);
    get offsetY(): number | undefined;
    set offsetY(value: number | undefined);
    get opacity(): number;
    set opacity(value: number);
    get paddingLeftRight(): number;
    set paddingLeftRight(value: number);
    get paddingTopBottom(): number;
    set paddingTopBottom(value: number);
    get radius(): number | undefined;
    set radius(value: number | undefined);
    get series(): string | undefined;
    set series(value: string | undefined);
    get shadow(): {
        blur?: number;
        color?: string;
        offsetX?: number;
        offsetY?: number;
        opacity?: number;
    };
    set shadow(value: {
        blur?: number;
        color?: string;
        offsetX?: number;
        offsetY?: number;
        opacity?: number;
    });
    get template(): any;
    set template(value: any);
    get text(): string | undefined;
    set text(value: string | undefined);
    get textOverflow(): TextOverflow;
    set textOverflow(value: TextOverflow);
    get tooltipEnabled(): boolean;
    set tooltipEnabled(value: boolean);
    get tooltipTemplate(): any;
    set tooltipTemplate(value: any);
    get type(): AnnotationType | undefined;
    set type(value: AnnotationType | undefined);
    get value(): Date | number | string | undefined;
    set value(value: Date | number | string | undefined);
    get width(): number | undefined;
    set width(value: number | undefined);
    get wordWrap(): WordWrap;
    set wordWrap(value: WordWrap);
    get x(): number | undefined;
    set x(value: number | undefined);
    get y(): number | undefined;
    set y(value: number | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost, renderer: Renderer2, document: any, templateHost: DxTemplateHost, element: ElementRef);
    setTemplate(template: DxTemplateDirective): void;
    ngAfterViewInit(): void;
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPolarChartCommonAnnotationSettingsComponent, [{ host: true; skipSelf: true; }, { host: true; }, null, null, { host: true; }, null]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoPolarChartCommonAnnotationSettingsComponent, "dxo-polar-chart-common-annotation-settings", never, { "allowDragging": { "alias": "allowDragging"; "required": false; }; "angle": { "alias": "angle"; "required": false; }; "argument": { "alias": "argument"; "required": false; }; "arrowLength": { "alias": "arrowLength"; "required": false; }; "arrowWidth": { "alias": "arrowWidth"; "required": false; }; "border": { "alias": "border"; "required": false; }; "color": { "alias": "color"; "required": false; }; "customizeTooltip": { "alias": "customizeTooltip"; "required": false; }; "data": { "alias": "data"; "required": false; }; "description": { "alias": "description"; "required": false; }; "font": { "alias": "font"; "required": false; }; "height": { "alias": "height"; "required": false; }; "image": { "alias": "image"; "required": false; }; "offsetX": { "alias": "offsetX"; "required": false; }; "offsetY": { "alias": "offsetY"; "required": false; }; "opacity": { "alias": "opacity"; "required": false; }; "paddingLeftRight": { "alias": "paddingLeftRight"; "required": false; }; "paddingTopBottom": { "alias": "paddingTopBottom"; "required": false; }; "radius": { "alias": "radius"; "required": false; }; "series": { "alias": "series"; "required": false; }; "shadow": { "alias": "shadow"; "required": false; }; "template": { "alias": "template"; "required": false; }; "text": { "alias": "text"; "required": false; }; "textOverflow": { "alias": "textOverflow"; "required": false; }; "tooltipEnabled": { "alias": "tooltipEnabled"; "required": false; }; "tooltipTemplate": { "alias": "tooltipTemplate"; "required": false; }; "type": { "alias": "type"; "required": false; }; "value": { "alias": "value"; "required": false; }; "width": { "alias": "width"; "required": false; }; "wordWrap": { "alias": "wordWrap"; "required": false; }; "x": { "alias": "x"; "required": false; }; "y": { "alias": "y"; "required": false; }; }, {}, never, ["*"], true, never>;
}
declare class DxoPolarChartCommonAnnotationSettingsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPolarChartCommonAnnotationSettingsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoPolarChartCommonAnnotationSettingsModule, never, [typeof DxoPolarChartCommonAnnotationSettingsComponent], [typeof DxoPolarChartCommonAnnotationSettingsComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoPolarChartCommonAnnotationSettingsModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoPolarChartCommonAxisSettingsLabelComponent extends NestedOption implements OnDestroy, OnInit {
    get font(): Font;
    set font(value: Font);
    get indentFromAxis(): number;
    set indentFromAxis(value: number);
    get overlappingBehavior(): LabelOverlap;
    set overlappingBehavior(value: LabelOverlap);
    get visible(): boolean;
    set visible(value: boolean);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPolarChartCommonAxisSettingsLabelComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoPolarChartCommonAxisSettingsLabelComponent, "dxo-polar-chart-common-axis-settings-label", never, { "font": { "alias": "font"; "required": false; }; "indentFromAxis": { "alias": "indentFromAxis"; "required": false; }; "overlappingBehavior": { "alias": "overlappingBehavior"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoPolarChartCommonAxisSettingsLabelModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPolarChartCommonAxisSettingsLabelModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoPolarChartCommonAxisSettingsLabelModule, never, [typeof DxoPolarChartCommonAxisSettingsLabelComponent], [typeof DxoPolarChartCommonAxisSettingsLabelComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoPolarChartCommonAxisSettingsLabelModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoPolarChartCommonAxisSettingsMinorTickComponent extends NestedOption implements OnDestroy, OnInit {
    get color(): string;
    set color(value: string);
    get length(): number;
    set length(value: number);
    get opacity(): number;
    set opacity(value: number);
    get visible(): boolean;
    set visible(value: boolean);
    get width(): number;
    set width(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPolarChartCommonAxisSettingsMinorTickComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoPolarChartCommonAxisSettingsMinorTickComponent, "dxo-polar-chart-common-axis-settings-minor-tick", never, { "color": { "alias": "color"; "required": false; }; "length": { "alias": "length"; "required": false; }; "opacity": { "alias": "opacity"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoPolarChartCommonAxisSettingsMinorTickModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPolarChartCommonAxisSettingsMinorTickModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoPolarChartCommonAxisSettingsMinorTickModule, never, [typeof DxoPolarChartCommonAxisSettingsMinorTickComponent], [typeof DxoPolarChartCommonAxisSettingsMinorTickComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoPolarChartCommonAxisSettingsMinorTickModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoPolarChartCommonAxisSettingsTickComponent extends NestedOption implements OnDestroy, OnInit {
    get color(): string;
    set color(value: string);
    get length(): number;
    set length(value: number);
    get opacity(): number | undefined;
    set opacity(value: number | undefined);
    get visible(): boolean;
    set visible(value: boolean);
    get width(): number;
    set width(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPolarChartCommonAxisSettingsTickComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoPolarChartCommonAxisSettingsTickComponent, "dxo-polar-chart-common-axis-settings-tick", never, { "color": { "alias": "color"; "required": false; }; "length": { "alias": "length"; "required": false; }; "opacity": { "alias": "opacity"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoPolarChartCommonAxisSettingsTickModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPolarChartCommonAxisSettingsTickModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoPolarChartCommonAxisSettingsTickModule, never, [typeof DxoPolarChartCommonAxisSettingsTickComponent], [typeof DxoPolarChartCommonAxisSettingsTickComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoPolarChartCommonAxisSettingsTickModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoPolarChartCommonAxisSettingsComponent extends NestedOption implements OnDestroy, OnInit {
    get allowDecimals(): boolean | undefined;
    set allowDecimals(value: boolean | undefined);
    get color(): string;
    set color(value: string);
    get constantLineStyle(): {
        color?: string;
        dashStyle?: DashStyle;
        label?: {
            font?: Font;
            visible?: boolean;
        };
        width?: number;
    };
    set constantLineStyle(value: {
        color?: string;
        dashStyle?: DashStyle;
        label?: {
            font?: Font;
            visible?: boolean;
        };
        width?: number;
    });
    get discreteAxisDivisionMode(): DiscreteAxisDivisionMode;
    set discreteAxisDivisionMode(value: DiscreteAxisDivisionMode);
    get endOnTick(): boolean | undefined;
    set endOnTick(value: boolean | undefined);
    get grid(): {
        color?: string;
        opacity?: number | undefined;
        visible?: boolean;
        width?: number;
    };
    set grid(value: {
        color?: string;
        opacity?: number | undefined;
        visible?: boolean;
        width?: number;
    });
    get inverted(): boolean;
    set inverted(value: boolean);
    get label(): {
        font?: Font;
        indentFromAxis?: number;
        overlappingBehavior?: LabelOverlap;
        visible?: boolean;
    };
    set label(value: {
        font?: Font;
        indentFromAxis?: number;
        overlappingBehavior?: LabelOverlap;
        visible?: boolean;
    });
    get minorGrid(): {
        color?: string;
        opacity?: number | undefined;
        visible?: boolean;
        width?: number;
    };
    set minorGrid(value: {
        color?: string;
        opacity?: number | undefined;
        visible?: boolean;
        width?: number;
    });
    get minorTick(): {
        color?: string;
        length?: number;
        opacity?: number;
        visible?: boolean;
        width?: number;
    };
    set minorTick(value: {
        color?: string;
        length?: number;
        opacity?: number;
        visible?: boolean;
        width?: number;
    });
    get opacity(): number | undefined;
    set opacity(value: number | undefined);
    get stripStyle(): {
        label?: {
            font?: Font;
        };
    };
    set stripStyle(value: {
        label?: {
            font?: Font;
        };
    });
    get tick(): {
        color?: string;
        length?: number;
        opacity?: number | undefined;
        visible?: boolean;
        width?: number;
    };
    set tick(value: {
        color?: string;
        length?: number;
        opacity?: number | undefined;
        visible?: boolean;
        width?: number;
    });
    get visible(): boolean;
    set visible(value: boolean);
    get width(): number;
    set width(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPolarChartCommonAxisSettingsComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoPolarChartCommonAxisSettingsComponent, "dxo-polar-chart-common-axis-settings", never, { "allowDecimals": { "alias": "allowDecimals"; "required": false; }; "color": { "alias": "color"; "required": false; }; "constantLineStyle": { "alias": "constantLineStyle"; "required": false; }; "discreteAxisDivisionMode": { "alias": "discreteAxisDivisionMode"; "required": false; }; "endOnTick": { "alias": "endOnTick"; "required": false; }; "grid": { "alias": "grid"; "required": false; }; "inverted": { "alias": "inverted"; "required": false; }; "label": { "alias": "label"; "required": false; }; "minorGrid": { "alias": "minorGrid"; "required": false; }; "minorTick": { "alias": "minorTick"; "required": false; }; "opacity": { "alias": "opacity"; "required": false; }; "stripStyle": { "alias": "stripStyle"; "required": false; }; "tick": { "alias": "tick"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoPolarChartCommonAxisSettingsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPolarChartCommonAxisSettingsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoPolarChartCommonAxisSettingsModule, never, [typeof DxoPolarChartCommonAxisSettingsComponent], [typeof DxoPolarChartCommonAxisSettingsComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoPolarChartCommonAxisSettingsModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoPolarChartCommonSeriesSettingsHoverStyleComponent extends NestedOption implements OnDestroy, OnInit {
    get border(): {
        color?: string | undefined;
        dashStyle?: DashStyle | undefined;
        visible?: boolean;
        width?: number;
    };
    set border(value: {
        color?: string | undefined;
        dashStyle?: DashStyle | undefined;
        visible?: boolean;
        width?: number;
    });
    get color(): ChartsColor | string | undefined;
    set color(value: ChartsColor | string | undefined);
    get dashStyle(): DashStyle;
    set dashStyle(value: DashStyle);
    get hatching(): {
        direction?: HatchDirection;
        opacity?: number;
        step?: number;
        width?: number;
    };
    set hatching(value: {
        direction?: HatchDirection;
        opacity?: number;
        step?: number;
        width?: number;
    });
    get highlight(): boolean;
    set highlight(value: boolean);
    get width(): number;
    set width(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPolarChartCommonSeriesSettingsHoverStyleComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoPolarChartCommonSeriesSettingsHoverStyleComponent, "dxo-polar-chart-common-series-settings-hover-style", never, { "border": { "alias": "border"; "required": false; }; "color": { "alias": "color"; "required": false; }; "dashStyle": { "alias": "dashStyle"; "required": false; }; "hatching": { "alias": "hatching"; "required": false; }; "highlight": { "alias": "highlight"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoPolarChartCommonSeriesSettingsHoverStyleModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPolarChartCommonSeriesSettingsHoverStyleModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoPolarChartCommonSeriesSettingsHoverStyleModule, never, [typeof DxoPolarChartCommonSeriesSettingsHoverStyleComponent], [typeof DxoPolarChartCommonSeriesSettingsHoverStyleComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoPolarChartCommonSeriesSettingsHoverStyleModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoPolarChartCommonSeriesSettingsLabelComponent extends NestedOption implements OnDestroy, OnInit {
    get argumentFormat(): Format | undefined;
    set argumentFormat(value: Format | undefined);
    get backgroundColor(): string | undefined;
    set backgroundColor(value: string | undefined);
    get border(): {
        color?: string | undefined;
        dashStyle?: DashStyle | undefined;
        visible?: boolean;
        width?: number;
    };
    set border(value: {
        color?: string | undefined;
        dashStyle?: DashStyle | undefined;
        visible?: boolean;
        width?: number;
    });
    get connector(): {
        color?: string | undefined;
        visible?: boolean;
        width?: number;
    };
    set connector(value: {
        color?: string | undefined;
        visible?: boolean;
        width?: number;
    });
    get customizeText(): ((pointInfo: any) => string);
    set customizeText(value: ((pointInfo: any) => string));
    get displayFormat(): string | undefined;
    set displayFormat(value: string | undefined);
    get font(): Font;
    set font(value: Font);
    get format(): Format | undefined;
    set format(value: Format | undefined);
    get position(): RelativePosition;
    set position(value: RelativePosition);
    get rotationAngle(): number;
    set rotationAngle(value: number);
    get showForZeroValues(): boolean;
    set showForZeroValues(value: boolean);
    get visible(): boolean;
    set visible(value: boolean);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPolarChartCommonSeriesSettingsLabelComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoPolarChartCommonSeriesSettingsLabelComponent, "dxo-polar-chart-common-series-settings-label", never, { "argumentFormat": { "alias": "argumentFormat"; "required": false; }; "backgroundColor": { "alias": "backgroundColor"; "required": false; }; "border": { "alias": "border"; "required": false; }; "connector": { "alias": "connector"; "required": false; }; "customizeText": { "alias": "customizeText"; "required": false; }; "displayFormat": { "alias": "displayFormat"; "required": false; }; "font": { "alias": "font"; "required": false; }; "format": { "alias": "format"; "required": false; }; "position": { "alias": "position"; "required": false; }; "rotationAngle": { "alias": "rotationAngle"; "required": false; }; "showForZeroValues": { "alias": "showForZeroValues"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoPolarChartCommonSeriesSettingsLabelModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPolarChartCommonSeriesSettingsLabelModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoPolarChartCommonSeriesSettingsLabelModule, never, [typeof DxoPolarChartCommonSeriesSettingsLabelComponent], [typeof DxoPolarChartCommonSeriesSettingsLabelComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoPolarChartCommonSeriesSettingsLabelModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoPolarChartCommonSeriesSettingsSelectionStyleComponent extends NestedOption implements OnDestroy, OnInit {
    get border(): {
        color?: string | undefined;
        dashStyle?: DashStyle | undefined;
        visible?: boolean;
        width?: number;
    };
    set border(value: {
        color?: string | undefined;
        dashStyle?: DashStyle | undefined;
        visible?: boolean;
        width?: number;
    });
    get color(): ChartsColor | string | undefined;
    set color(value: ChartsColor | string | undefined);
    get dashStyle(): DashStyle;
    set dashStyle(value: DashStyle);
    get hatching(): {
        direction?: HatchDirection;
        opacity?: number;
        step?: number;
        width?: number;
    };
    set hatching(value: {
        direction?: HatchDirection;
        opacity?: number;
        step?: number;
        width?: number;
    });
    get highlight(): boolean;
    set highlight(value: boolean);
    get width(): number;
    set width(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPolarChartCommonSeriesSettingsSelectionStyleComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoPolarChartCommonSeriesSettingsSelectionStyleComponent, "dxo-polar-chart-common-series-settings-selection-style", never, { "border": { "alias": "border"; "required": false; }; "color": { "alias": "color"; "required": false; }; "dashStyle": { "alias": "dashStyle"; "required": false; }; "hatching": { "alias": "hatching"; "required": false; }; "highlight": { "alias": "highlight"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoPolarChartCommonSeriesSettingsSelectionStyleModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPolarChartCommonSeriesSettingsSelectionStyleModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoPolarChartCommonSeriesSettingsSelectionStyleModule, never, [typeof DxoPolarChartCommonSeriesSettingsSelectionStyleComponent], [typeof DxoPolarChartCommonSeriesSettingsSelectionStyleComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoPolarChartCommonSeriesSettingsSelectionStyleModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoPolarChartCommonSeriesSettingsComponent extends NestedOption implements OnDestroy, OnInit {
    get area(): any;
    set area(value: any);
    get argumentField(): string;
    set argumentField(value: string);
    get bar(): any;
    set bar(value: any);
    get barPadding(): number | undefined;
    set barPadding(value: number | undefined);
    get barWidth(): number | undefined;
    set barWidth(value: number | undefined);
    get border(): {
        color?: string | undefined;
        dashStyle?: DashStyle | undefined;
        visible?: boolean;
        width?: number;
    };
    set border(value: {
        color?: string | undefined;
        dashStyle?: DashStyle | undefined;
        visible?: boolean;
        width?: number;
    });
    get closed(): boolean;
    set closed(value: boolean);
    get color(): ChartsColor | string | undefined;
    set color(value: ChartsColor | string | undefined);
    get dashStyle(): DashStyle;
    set dashStyle(value: DashStyle);
    get hoverMode(): SeriesHoverMode;
    set hoverMode(value: SeriesHoverMode);
    get hoverStyle(): {
        border?: {
            color?: string | undefined;
            dashStyle?: DashStyle | undefined;
            visible?: boolean;
            width?: number;
        };
        color?: ChartsColor | string | undefined;
        dashStyle?: DashStyle;
        hatching?: {
            direction?: HatchDirection;
            opacity?: number;
            step?: number;
            width?: number;
        };
        highlight?: boolean;
        width?: number;
    };
    set hoverStyle(value: {
        border?: {
            color?: string | undefined;
            dashStyle?: DashStyle | undefined;
            visible?: boolean;
            width?: number;
        };
        color?: ChartsColor | string | undefined;
        dashStyle?: DashStyle;
        hatching?: {
            direction?: HatchDirection;
            opacity?: number;
            step?: number;
            width?: number;
        };
        highlight?: boolean;
        width?: number;
    });
    get ignoreEmptyPoints(): boolean;
    set ignoreEmptyPoints(value: boolean);
    get label(): {
        argumentFormat?: Format | undefined;
        backgroundColor?: string | undefined;
        border?: {
            color?: string | undefined;
            dashStyle?: DashStyle | undefined;
            visible?: boolean;
            width?: number;
        };
        connector?: {
            color?: string | undefined;
            visible?: boolean;
            width?: number;
        };
        customizeText?: ((pointInfo: any) => string);
        displayFormat?: string | undefined;
        font?: Font;
        format?: Format | undefined;
        position?: RelativePosition;
        rotationAngle?: number;
        showForZeroValues?: boolean;
        visible?: boolean;
    };
    set label(value: {
        argumentFormat?: Format | undefined;
        backgroundColor?: string | undefined;
        border?: {
            color?: string | undefined;
            dashStyle?: DashStyle | undefined;
            visible?: boolean;
            width?: number;
        };
        connector?: {
            color?: string | undefined;
            visible?: boolean;
            width?: number;
        };
        customizeText?: ((pointInfo: any) => string);
        displayFormat?: string | undefined;
        font?: Font;
        format?: Format | undefined;
        position?: RelativePosition;
        rotationAngle?: number;
        showForZeroValues?: boolean;
        visible?: boolean;
    });
    get line(): any;
    set line(value: any);
    get maxLabelCount(): number | undefined;
    set maxLabelCount(value: number | undefined);
    get minBarSize(): number | undefined;
    set minBarSize(value: number | undefined);
    get opacity(): number;
    set opacity(value: number);
    get point(): {
        border?: {
            color?: string | undefined;
            visible?: boolean;
            width?: number;
        };
        color?: ChartsColor | string | undefined;
        hoverMode?: PointInteractionMode;
        hoverStyle?: {
            border?: {
                color?: string | undefined;
                visible?: boolean;
                width?: number;
            };
            color?: ChartsColor | string | undefined;
            size?: number;
        };
        image?: string | undefined | {
            height?: number;
            url?: string | undefined;
            width?: number;
        };
        selectionMode?: PointInteractionMode;
        selectionStyle?: {
            border?: {
                color?: string | undefined;
                visible?: boolean;
                width?: number;
            };
            color?: ChartsColor | string | undefined;
            size?: number;
        };
        size?: number;
        symbol?: PointSymbol;
        visible?: boolean;
    };
    set point(value: {
        border?: {
            color?: string | undefined;
            visible?: boolean;
            width?: number;
        };
        color?: ChartsColor | string | undefined;
        hoverMode?: PointInteractionMode;
        hoverStyle?: {
            border?: {
                color?: string | undefined;
                visible?: boolean;
                width?: number;
            };
            color?: ChartsColor | string | undefined;
            size?: number;
        };
        image?: string | undefined | {
            height?: number;
            url?: string | undefined;
            width?: number;
        };
        selectionMode?: PointInteractionMode;
        selectionStyle?: {
            border?: {
                color?: string | undefined;
                visible?: boolean;
                width?: number;
            };
            color?: ChartsColor | string | undefined;
            size?: number;
        };
        size?: number;
        symbol?: PointSymbol;
        visible?: boolean;
    });
    get scatter(): any;
    set scatter(value: any);
    get selectionMode(): SeriesSelectionMode;
    set selectionMode(value: SeriesSelectionMode);
    get selectionStyle(): {
        border?: {
            color?: string | undefined;
            dashStyle?: DashStyle | undefined;
            visible?: boolean;
            width?: number;
        };
        color?: ChartsColor | string | undefined;
        dashStyle?: DashStyle;
        hatching?: {
            direction?: HatchDirection;
            opacity?: number;
            step?: number;
            width?: number;
        };
        highlight?: boolean;
        width?: number;
    };
    set selectionStyle(value: {
        border?: {
            color?: string | undefined;
            dashStyle?: DashStyle | undefined;
            visible?: boolean;
            width?: number;
        };
        color?: ChartsColor | string | undefined;
        dashStyle?: DashStyle;
        hatching?: {
            direction?: HatchDirection;
            opacity?: number;
            step?: number;
            width?: number;
        };
        highlight?: boolean;
        width?: number;
    });
    get showInLegend(): boolean;
    set showInLegend(value: boolean);
    get stack(): string;
    set stack(value: string);
    get stackedbar(): any;
    set stackedbar(value: any);
    get tagField(): string;
    set tagField(value: string);
    get type(): PolarChartSeriesType;
    set type(value: PolarChartSeriesType);
    get valueErrorBar(): {
        color?: string;
        displayMode?: ValueErrorBarDisplayMode;
        edgeLength?: number;
        highValueField?: string | undefined;
        lineWidth?: number;
        lowValueField?: string | undefined;
        opacity?: number | undefined;
        type?: undefined | ValueErrorBarType;
        value?: number;
    };
    set valueErrorBar(value: {
        color?: string;
        displayMode?: ValueErrorBarDisplayMode;
        edgeLength?: number;
        highValueField?: string | undefined;
        lineWidth?: number;
        lowValueField?: string | undefined;
        opacity?: number | undefined;
        type?: undefined | ValueErrorBarType;
        value?: number;
    });
    get valueField(): string;
    set valueField(value: string);
    get visible(): boolean;
    set visible(value: boolean);
    get width(): number;
    set width(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPolarChartCommonSeriesSettingsComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoPolarChartCommonSeriesSettingsComponent, "dxo-polar-chart-common-series-settings", never, { "area": { "alias": "area"; "required": false; }; "argumentField": { "alias": "argumentField"; "required": false; }; "bar": { "alias": "bar"; "required": false; }; "barPadding": { "alias": "barPadding"; "required": false; }; "barWidth": { "alias": "barWidth"; "required": false; }; "border": { "alias": "border"; "required": false; }; "closed": { "alias": "closed"; "required": false; }; "color": { "alias": "color"; "required": false; }; "dashStyle": { "alias": "dashStyle"; "required": false; }; "hoverMode": { "alias": "hoverMode"; "required": false; }; "hoverStyle": { "alias": "hoverStyle"; "required": false; }; "ignoreEmptyPoints": { "alias": "ignoreEmptyPoints"; "required": false; }; "label": { "alias": "label"; "required": false; }; "line": { "alias": "line"; "required": false; }; "maxLabelCount": { "alias": "maxLabelCount"; "required": false; }; "minBarSize": { "alias": "minBarSize"; "required": false; }; "opacity": { "alias": "opacity"; "required": false; }; "point": { "alias": "point"; "required": false; }; "scatter": { "alias": "scatter"; "required": false; }; "selectionMode": { "alias": "selectionMode"; "required": false; }; "selectionStyle": { "alias": "selectionStyle"; "required": false; }; "showInLegend": { "alias": "showInLegend"; "required": false; }; "stack": { "alias": "stack"; "required": false; }; "stackedbar": { "alias": "stackedbar"; "required": false; }; "tagField": { "alias": "tagField"; "required": false; }; "type": { "alias": "type"; "required": false; }; "valueErrorBar": { "alias": "valueErrorBar"; "required": false; }; "valueField": { "alias": "valueField"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoPolarChartCommonSeriesSettingsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPolarChartCommonSeriesSettingsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoPolarChartCommonSeriesSettingsModule, never, [typeof DxoPolarChartCommonSeriesSettingsComponent], [typeof DxoPolarChartCommonSeriesSettingsComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoPolarChartCommonSeriesSettingsModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoPolarChartConnectorComponent extends NestedOption implements OnDestroy, OnInit {
    get color(): string | undefined;
    set color(value: string | undefined);
    get visible(): boolean;
    set visible(value: boolean);
    get width(): number;
    set width(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPolarChartConnectorComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoPolarChartConnectorComponent, "dxo-polar-chart-connector", never, { "color": { "alias": "color"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoPolarChartConnectorModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPolarChartConnectorModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoPolarChartConnectorModule, never, [typeof DxoPolarChartConnectorComponent], [typeof DxoPolarChartConnectorComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoPolarChartConnectorModule>;
}

declare class DxiPolarChartConstantLineComponent extends CollectionNestedOption {
    get color(): string;
    set color(value: string);
    get dashStyle(): DashStyle;
    set dashStyle(value: DashStyle);
    get displayBehindSeries(): boolean;
    set displayBehindSeries(value: boolean);
    get extendAxis(): boolean;
    set extendAxis(value: boolean);
    get label(): {
        font?: Font;
        text?: string | undefined;
        visible?: boolean;
    };
    set label(value: {
        font?: Font;
        text?: string | undefined;
        visible?: boolean;
    });
    get value(): Date | number | string | undefined;
    set value(value: Date | number | string | undefined);
    get width(): number;
    set width(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiPolarChartConstantLineComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiPolarChartConstantLineComponent, "dxi-polar-chart-constant-line", never, { "color": { "alias": "color"; "required": false; }; "dashStyle": { "alias": "dashStyle"; "required": false; }; "displayBehindSeries": { "alias": "displayBehindSeries"; "required": false; }; "extendAxis": { "alias": "extendAxis"; "required": false; }; "label": { "alias": "label"; "required": false; }; "value": { "alias": "value"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxiPolarChartConstantLineModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiPolarChartConstantLineModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiPolarChartConstantLineModule, never, [typeof DxiPolarChartConstantLineComponent], [typeof DxiPolarChartConstantLineComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiPolarChartConstantLineModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoPolarChartConstantLineLabelComponent extends NestedOption implements OnDestroy, OnInit {
    get font(): Font;
    set font(value: Font);
    get text(): string | undefined;
    set text(value: string | undefined);
    get visible(): boolean;
    set visible(value: boolean);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPolarChartConstantLineLabelComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoPolarChartConstantLineLabelComponent, "dxo-polar-chart-constant-line-label", never, { "font": { "alias": "font"; "required": false; }; "text": { "alias": "text"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoPolarChartConstantLineLabelModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPolarChartConstantLineLabelModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoPolarChartConstantLineLabelModule, never, [typeof DxoPolarChartConstantLineLabelComponent], [typeof DxoPolarChartConstantLineLabelComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoPolarChartConstantLineLabelModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoPolarChartConstantLineStyleLabelComponent extends NestedOption implements OnDestroy, OnInit {
    get font(): Font;
    set font(value: Font);
    get visible(): boolean;
    set visible(value: boolean);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPolarChartConstantLineStyleLabelComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoPolarChartConstantLineStyleLabelComponent, "dxo-polar-chart-constant-line-style-label", never, { "font": { "alias": "font"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoPolarChartConstantLineStyleLabelModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPolarChartConstantLineStyleLabelModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoPolarChartConstantLineStyleLabelModule, never, [typeof DxoPolarChartConstantLineStyleLabelComponent], [typeof DxoPolarChartConstantLineStyleLabelComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoPolarChartConstantLineStyleLabelModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoPolarChartConstantLineStyleComponent extends NestedOption implements OnDestroy, OnInit {
    get color(): string;
    set color(value: string);
    get dashStyle(): DashStyle;
    set dashStyle(value: DashStyle);
    get label(): {
        font?: Font;
        visible?: boolean;
    };
    set label(value: {
        font?: Font;
        visible?: boolean;
    });
    get width(): number;
    set width(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPolarChartConstantLineStyleComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoPolarChartConstantLineStyleComponent, "dxo-polar-chart-constant-line-style", never, { "color": { "alias": "color"; "required": false; }; "dashStyle": { "alias": "dashStyle"; "required": false; }; "label": { "alias": "label"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoPolarChartConstantLineStyleModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPolarChartConstantLineStyleModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoPolarChartConstantLineStyleModule, never, [typeof DxoPolarChartConstantLineStyleComponent], [typeof DxoPolarChartConstantLineStyleComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoPolarChartConstantLineStyleModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoPolarChartDataPrepareSettingsComponent extends NestedOption implements OnDestroy, OnInit {
    get checkTypeForAllData(): boolean;
    set checkTypeForAllData(value: boolean);
    get convertToAxisDataType(): boolean;
    set convertToAxisDataType(value: boolean);
    get sortingMethod(): boolean | ((a: {
        arg: Date | number | string;
        val: Date | number | string;
    }, b: {
        arg: Date | number | string;
        val: Date | number | string;
    }) => number);
    set sortingMethod(value: boolean | ((a: {
        arg: Date | number | string;
        val: Date | number | string;
    }, b: {
        arg: Date | number | string;
        val: Date | number | string;
    }) => number));
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPolarChartDataPrepareSettingsComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoPolarChartDataPrepareSettingsComponent, "dxo-polar-chart-data-prepare-settings", never, { "checkTypeForAllData": { "alias": "checkTypeForAllData"; "required": false; }; "convertToAxisDataType": { "alias": "convertToAxisDataType"; "required": false; }; "sortingMethod": { "alias": "sortingMethod"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoPolarChartDataPrepareSettingsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPolarChartDataPrepareSettingsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoPolarChartDataPrepareSettingsModule, never, [typeof DxoPolarChartDataPrepareSettingsComponent], [typeof DxoPolarChartDataPrepareSettingsComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoPolarChartDataPrepareSettingsModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoPolarChartExportComponent extends NestedOption implements OnDestroy, OnInit {
    get backgroundColor(): string;
    set backgroundColor(value: string);
    get enabled(): boolean;
    set enabled(value: boolean);
    get fileName(): string;
    set fileName(value: string);
    get formats(): Array<ExportFormat>;
    set formats(value: Array<ExportFormat>);
    get margin(): number;
    set margin(value: number);
    get printingEnabled(): boolean;
    set printingEnabled(value: boolean);
    get svgToCanvas(): ((svg: any, canvas: any) => any) | undefined;
    set svgToCanvas(value: ((svg: any, canvas: any) => any) | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPolarChartExportComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoPolarChartExportComponent, "dxo-polar-chart-export", never, { "backgroundColor": { "alias": "backgroundColor"; "required": false; }; "enabled": { "alias": "enabled"; "required": false; }; "fileName": { "alias": "fileName"; "required": false; }; "formats": { "alias": "formats"; "required": false; }; "margin": { "alias": "margin"; "required": false; }; "printingEnabled": { "alias": "printingEnabled"; "required": false; }; "svgToCanvas": { "alias": "svgToCanvas"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoPolarChartExportModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPolarChartExportModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoPolarChartExportModule, never, [typeof DxoPolarChartExportComponent], [typeof DxoPolarChartExportComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoPolarChartExportModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoPolarChartFontComponent extends NestedOption implements OnDestroy, OnInit {
    get color(): string;
    set color(value: string);
    get family(): string;
    set family(value: string);
    get opacity(): number;
    set opacity(value: number);
    get size(): number | string;
    set size(value: number | string);
    get weight(): number;
    set weight(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPolarChartFontComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoPolarChartFontComponent, "dxo-polar-chart-font", never, { "color": { "alias": "color"; "required": false; }; "family": { "alias": "family"; "required": false; }; "opacity": { "alias": "opacity"; "required": false; }; "size": { "alias": "size"; "required": false; }; "weight": { "alias": "weight"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoPolarChartFontModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPolarChartFontModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoPolarChartFontModule, never, [typeof DxoPolarChartFontComponent], [typeof DxoPolarChartFontComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoPolarChartFontModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoPolarChartFormatComponent extends NestedOption implements OnDestroy, OnInit {
    get currency(): string;
    set currency(value: string);
    get formatter(): ((value: number | Date) => string);
    set formatter(value: ((value: number | Date) => string));
    get parser(): ((value: string) => number | Date);
    set parser(value: ((value: string) => number | Date));
    get precision(): number;
    set precision(value: number);
    get type(): Format$1 | string;
    set type(value: Format$1 | string);
    get useCurrencyAccountingStyle(): boolean;
    set useCurrencyAccountingStyle(value: boolean);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPolarChartFormatComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoPolarChartFormatComponent, "dxo-polar-chart-format", never, { "currency": { "alias": "currency"; "required": false; }; "formatter": { "alias": "formatter"; "required": false; }; "parser": { "alias": "parser"; "required": false; }; "precision": { "alias": "precision"; "required": false; }; "type": { "alias": "type"; "required": false; }; "useCurrencyAccountingStyle": { "alias": "useCurrencyAccountingStyle"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoPolarChartFormatModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPolarChartFormatModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoPolarChartFormatModule, never, [typeof DxoPolarChartFormatComponent], [typeof DxoPolarChartFormatComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoPolarChartFormatModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoPolarChartGridComponent extends NestedOption implements OnDestroy, OnInit {
    get color(): string;
    set color(value: string);
    get opacity(): number | undefined;
    set opacity(value: number | undefined);
    get visible(): boolean;
    set visible(value: boolean);
    get width(): number;
    set width(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPolarChartGridComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoPolarChartGridComponent, "dxo-polar-chart-grid", never, { "color": { "alias": "color"; "required": false; }; "opacity": { "alias": "opacity"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoPolarChartGridModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPolarChartGridModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoPolarChartGridModule, never, [typeof DxoPolarChartGridComponent], [typeof DxoPolarChartGridComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoPolarChartGridModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoPolarChartHatchingComponent extends NestedOption implements OnDestroy, OnInit {
    get direction(): HatchDirection;
    set direction(value: HatchDirection);
    get opacity(): number;
    set opacity(value: number);
    get step(): number;
    set step(value: number);
    get width(): number;
    set width(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPolarChartHatchingComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoPolarChartHatchingComponent, "dxo-polar-chart-hatching", never, { "direction": { "alias": "direction"; "required": false; }; "opacity": { "alias": "opacity"; "required": false; }; "step": { "alias": "step"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoPolarChartHatchingModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPolarChartHatchingModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoPolarChartHatchingModule, never, [typeof DxoPolarChartHatchingComponent], [typeof DxoPolarChartHatchingComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoPolarChartHatchingModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoPolarChartHoverStyleComponent extends NestedOption implements OnDestroy, OnInit {
    get border(): {
        color?: string | undefined;
        dashStyle?: DashStyle | undefined;
        visible?: boolean;
        width?: number;
    };
    set border(value: {
        color?: string | undefined;
        dashStyle?: DashStyle | undefined;
        visible?: boolean;
        width?: number;
    });
    get color(): ChartsColor | string | undefined;
    set color(value: ChartsColor | string | undefined);
    get dashStyle(): DashStyle;
    set dashStyle(value: DashStyle);
    get hatching(): {
        direction?: HatchDirection;
        opacity?: number;
        step?: number;
        width?: number;
    };
    set hatching(value: {
        direction?: HatchDirection;
        opacity?: number;
        step?: number;
        width?: number;
    });
    get highlight(): boolean;
    set highlight(value: boolean);
    get width(): number;
    set width(value: number);
    get size(): number;
    set size(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPolarChartHoverStyleComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoPolarChartHoverStyleComponent, "dxo-polar-chart-hover-style", never, { "border": { "alias": "border"; "required": false; }; "color": { "alias": "color"; "required": false; }; "dashStyle": { "alias": "dashStyle"; "required": false; }; "hatching": { "alias": "hatching"; "required": false; }; "highlight": { "alias": "highlight"; "required": false; }; "width": { "alias": "width"; "required": false; }; "size": { "alias": "size"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoPolarChartHoverStyleModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPolarChartHoverStyleModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoPolarChartHoverStyleModule, never, [typeof DxoPolarChartHoverStyleComponent], [typeof DxoPolarChartHoverStyleComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoPolarChartHoverStyleModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoPolarChartImageComponent extends NestedOption implements OnDestroy, OnInit {
    get height(): number;
    set height(value: number);
    get url(): string | undefined;
    set url(value: string | undefined);
    get width(): number;
    set width(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPolarChartImageComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoPolarChartImageComponent, "dxo-polar-chart-image", never, { "height": { "alias": "height"; "required": false; }; "url": { "alias": "url"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoPolarChartImageModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPolarChartImageModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoPolarChartImageModule, never, [typeof DxoPolarChartImageComponent], [typeof DxoPolarChartImageComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoPolarChartImageModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoPolarChartLabelComponent extends NestedOption implements OnDestroy, OnInit {
    get font(): Font;
    set font(value: Font);
    get text(): string | undefined;
    set text(value: string | undefined);
    get visible(): boolean;
    set visible(value: boolean);
    get customizeHint(): ((argument: {
        value: Date | number | string;
        valueText: string;
    }) => string);
    set customizeHint(value: ((argument: {
        value: Date | number | string;
        valueText: string;
    }) => string));
    get customizeText(): ((argument: {
        value: Date | number | string;
        valueText: string;
    }) => string);
    set customizeText(value: ((argument: {
        value: Date | number | string;
        valueText: string;
    }) => string));
    get format(): Format | undefined;
    set format(value: Format | undefined);
    get indentFromAxis(): number;
    set indentFromAxis(value: number);
    get overlappingBehavior(): LabelOverlap;
    set overlappingBehavior(value: LabelOverlap);
    get argumentFormat(): Format | undefined;
    set argumentFormat(value: Format | undefined);
    get backgroundColor(): string | undefined;
    set backgroundColor(value: string | undefined);
    get border(): {
        color?: string | undefined;
        dashStyle?: DashStyle | undefined;
        visible?: boolean;
        width?: number;
    };
    set border(value: {
        color?: string | undefined;
        dashStyle?: DashStyle | undefined;
        visible?: boolean;
        width?: number;
    });
    get connector(): {
        color?: string | undefined;
        visible?: boolean;
        width?: number;
    };
    set connector(value: {
        color?: string | undefined;
        visible?: boolean;
        width?: number;
    });
    get displayFormat(): string | undefined;
    set displayFormat(value: string | undefined);
    get position(): RelativePosition;
    set position(value: RelativePosition);
    get rotationAngle(): number;
    set rotationAngle(value: number);
    get showForZeroValues(): boolean;
    set showForZeroValues(value: boolean);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPolarChartLabelComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoPolarChartLabelComponent, "dxo-polar-chart-label", never, { "font": { "alias": "font"; "required": false; }; "text": { "alias": "text"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "customizeHint": { "alias": "customizeHint"; "required": false; }; "customizeText": { "alias": "customizeText"; "required": false; }; "format": { "alias": "format"; "required": false; }; "indentFromAxis": { "alias": "indentFromAxis"; "required": false; }; "overlappingBehavior": { "alias": "overlappingBehavior"; "required": false; }; "argumentFormat": { "alias": "argumentFormat"; "required": false; }; "backgroundColor": { "alias": "backgroundColor"; "required": false; }; "border": { "alias": "border"; "required": false; }; "connector": { "alias": "connector"; "required": false; }; "displayFormat": { "alias": "displayFormat"; "required": false; }; "position": { "alias": "position"; "required": false; }; "rotationAngle": { "alias": "rotationAngle"; "required": false; }; "showForZeroValues": { "alias": "showForZeroValues"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoPolarChartLabelModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPolarChartLabelModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoPolarChartLabelModule, never, [typeof DxoPolarChartLabelComponent], [typeof DxoPolarChartLabelComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoPolarChartLabelModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoPolarChartLegendTitleSubtitleComponent extends NestedOption implements OnDestroy, OnInit {
    get font(): Font;
    set font(value: Font);
    get offset(): number;
    set offset(value: number);
    get text(): string | undefined;
    set text(value: string | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPolarChartLegendTitleSubtitleComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoPolarChartLegendTitleSubtitleComponent, "dxo-polar-chart-legend-title-subtitle", never, { "font": { "alias": "font"; "required": false; }; "offset": { "alias": "offset"; "required": false; }; "text": { "alias": "text"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoPolarChartLegendTitleSubtitleModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPolarChartLegendTitleSubtitleModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoPolarChartLegendTitleSubtitleModule, never, [typeof DxoPolarChartLegendTitleSubtitleComponent], [typeof DxoPolarChartLegendTitleSubtitleComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoPolarChartLegendTitleSubtitleModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoPolarChartLegendTitleComponent extends NestedOption implements OnDestroy, OnInit {
    get font(): Font;
    set font(value: Font);
    get horizontalAlignment(): HorizontalAlignment | undefined;
    set horizontalAlignment(value: HorizontalAlignment | undefined);
    get margin(): {
        bottom?: number;
        left?: number;
        right?: number;
        top?: number;
    };
    set margin(value: {
        bottom?: number;
        left?: number;
        right?: number;
        top?: number;
    });
    get placeholderSize(): number | undefined;
    set placeholderSize(value: number | undefined);
    get subtitle(): string | {
        font?: Font;
        offset?: number;
        text?: string | undefined;
    };
    set subtitle(value: string | {
        font?: Font;
        offset?: number;
        text?: string | undefined;
    });
    get text(): string | undefined;
    set text(value: string | undefined);
    get verticalAlignment(): VerticalEdge;
    set verticalAlignment(value: VerticalEdge);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPolarChartLegendTitleComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoPolarChartLegendTitleComponent, "dxo-polar-chart-legend-title", never, { "font": { "alias": "font"; "required": false; }; "horizontalAlignment": { "alias": "horizontalAlignment"; "required": false; }; "margin": { "alias": "margin"; "required": false; }; "placeholderSize": { "alias": "placeholderSize"; "required": false; }; "subtitle": { "alias": "subtitle"; "required": false; }; "text": { "alias": "text"; "required": false; }; "verticalAlignment": { "alias": "verticalAlignment"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoPolarChartLegendTitleModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPolarChartLegendTitleModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoPolarChartLegendTitleModule, never, [typeof DxoPolarChartLegendTitleComponent], [typeof DxoPolarChartLegendTitleComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoPolarChartLegendTitleModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoPolarChartLegendComponent extends NestedOption implements OnDestroy, OnInit {
    get backgroundColor(): string | undefined;
    set backgroundColor(value: string | undefined);
    get border(): {
        color?: string;
        cornerRadius?: number;
        dashStyle?: DashStyle;
        opacity?: number | undefined;
        visible?: boolean;
        width?: number;
    };
    set border(value: {
        color?: string;
        cornerRadius?: number;
        dashStyle?: DashStyle;
        opacity?: number | undefined;
        visible?: boolean;
        width?: number;
    });
    get columnCount(): number;
    set columnCount(value: number);
    get columnItemSpacing(): number;
    set columnItemSpacing(value: number);
    get customizeHint(): ((seriesInfo: {
        seriesColor: string;
        seriesIndex: number;
        seriesName: any;
    }) => string);
    set customizeHint(value: ((seriesInfo: {
        seriesColor: string;
        seriesIndex: number;
        seriesName: any;
    }) => string));
    get customizeItems(): ((items: Array<LegendItem>) => Array<LegendItem>);
    set customizeItems(value: ((items: Array<LegendItem>) => Array<LegendItem>));
    get customizeText(): ((seriesInfo: {
        seriesColor: string;
        seriesIndex: number;
        seriesName: any;
    }) => string);
    set customizeText(value: ((seriesInfo: {
        seriesColor: string;
        seriesIndex: number;
        seriesName: any;
    }) => string));
    get font(): Font;
    set font(value: Font);
    get horizontalAlignment(): HorizontalAlignment;
    set horizontalAlignment(value: HorizontalAlignment);
    get hoverMode(): LegendHoverMode;
    set hoverMode(value: LegendHoverMode);
    get itemsAlignment(): HorizontalAlignment | undefined;
    set itemsAlignment(value: HorizontalAlignment | undefined);
    get itemTextPosition(): Position | undefined;
    set itemTextPosition(value: Position | undefined);
    get margin(): number | {
        bottom?: number;
        left?: number;
        right?: number;
        top?: number;
    };
    set margin(value: number | {
        bottom?: number;
        left?: number;
        right?: number;
        top?: number;
    });
    get markerSize(): number;
    set markerSize(value: number);
    get markerTemplate(): any;
    set markerTemplate(value: any);
    get orientation(): Orientation | undefined;
    set orientation(value: Orientation | undefined);
    get paddingLeftRight(): number;
    set paddingLeftRight(value: number);
    get paddingTopBottom(): number;
    set paddingTopBottom(value: number);
    get rowCount(): number;
    set rowCount(value: number);
    get rowItemSpacing(): number;
    set rowItemSpacing(value: number);
    get title(): string | {
        font?: Font;
        horizontalAlignment?: HorizontalAlignment | undefined;
        margin?: {
            bottom?: number;
            left?: number;
            right?: number;
            top?: number;
        };
        placeholderSize?: number | undefined;
        subtitle?: string | {
            font?: Font;
            offset?: number;
            text?: string | undefined;
        };
        text?: string | undefined;
        verticalAlignment?: VerticalEdge;
    };
    set title(value: string | {
        font?: Font;
        horizontalAlignment?: HorizontalAlignment | undefined;
        margin?: {
            bottom?: number;
            left?: number;
            right?: number;
            top?: number;
        };
        placeholderSize?: number | undefined;
        subtitle?: string | {
            font?: Font;
            offset?: number;
            text?: string | undefined;
        };
        text?: string | undefined;
        verticalAlignment?: VerticalEdge;
    });
    get verticalAlignment(): VerticalEdge;
    set verticalAlignment(value: VerticalEdge);
    get visible(): boolean;
    set visible(value: boolean);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPolarChartLegendComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoPolarChartLegendComponent, "dxo-polar-chart-legend", never, { "backgroundColor": { "alias": "backgroundColor"; "required": false; }; "border": { "alias": "border"; "required": false; }; "columnCount": { "alias": "columnCount"; "required": false; }; "columnItemSpacing": { "alias": "columnItemSpacing"; "required": false; }; "customizeHint": { "alias": "customizeHint"; "required": false; }; "customizeItems": { "alias": "customizeItems"; "required": false; }; "customizeText": { "alias": "customizeText"; "required": false; }; "font": { "alias": "font"; "required": false; }; "horizontalAlignment": { "alias": "horizontalAlignment"; "required": false; }; "hoverMode": { "alias": "hoverMode"; "required": false; }; "itemsAlignment": { "alias": "itemsAlignment"; "required": false; }; "itemTextPosition": { "alias": "itemTextPosition"; "required": false; }; "margin": { "alias": "margin"; "required": false; }; "markerSize": { "alias": "markerSize"; "required": false; }; "markerTemplate": { "alias": "markerTemplate"; "required": false; }; "orientation": { "alias": "orientation"; "required": false; }; "paddingLeftRight": { "alias": "paddingLeftRight"; "required": false; }; "paddingTopBottom": { "alias": "paddingTopBottom"; "required": false; }; "rowCount": { "alias": "rowCount"; "required": false; }; "rowItemSpacing": { "alias": "rowItemSpacing"; "required": false; }; "title": { "alias": "title"; "required": false; }; "verticalAlignment": { "alias": "verticalAlignment"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoPolarChartLegendModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPolarChartLegendModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoPolarChartLegendModule, never, [typeof DxoPolarChartLegendComponent], [typeof DxoPolarChartLegendComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoPolarChartLegendModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoPolarChartLengthComponent extends NestedOption implements OnDestroy, OnInit {
    get days(): number;
    set days(value: number);
    get hours(): number;
    set hours(value: number);
    get milliseconds(): number;
    set milliseconds(value: number);
    get minutes(): number;
    set minutes(value: number);
    get months(): number;
    set months(value: number);
    get quarters(): number;
    set quarters(value: number);
    get seconds(): number;
    set seconds(value: number);
    get weeks(): number;
    set weeks(value: number);
    get years(): number;
    set years(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPolarChartLengthComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoPolarChartLengthComponent, "dxo-polar-chart-length", never, { "days": { "alias": "days"; "required": false; }; "hours": { "alias": "hours"; "required": false; }; "milliseconds": { "alias": "milliseconds"; "required": false; }; "minutes": { "alias": "minutes"; "required": false; }; "months": { "alias": "months"; "required": false; }; "quarters": { "alias": "quarters"; "required": false; }; "seconds": { "alias": "seconds"; "required": false; }; "weeks": { "alias": "weeks"; "required": false; }; "years": { "alias": "years"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoPolarChartLengthModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPolarChartLengthModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoPolarChartLengthModule, never, [typeof DxoPolarChartLengthComponent], [typeof DxoPolarChartLengthComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoPolarChartLengthModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoPolarChartLoadingIndicatorComponent extends NestedOption implements OnDestroy, OnInit {
    get backgroundColor(): string;
    set backgroundColor(value: string);
    get enabled(): boolean;
    set enabled(value: boolean);
    get font(): Font;
    set font(value: Font);
    get show(): boolean;
    set show(value: boolean);
    get text(): string;
    set text(value: string);
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    showChange: EventEmitter<boolean>;
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPolarChartLoadingIndicatorComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoPolarChartLoadingIndicatorComponent, "dxo-polar-chart-loading-indicator", never, { "backgroundColor": { "alias": "backgroundColor"; "required": false; }; "enabled": { "alias": "enabled"; "required": false; }; "font": { "alias": "font"; "required": false; }; "show": { "alias": "show"; "required": false; }; "text": { "alias": "text"; "required": false; }; }, { "showChange": "showChange"; }, never, never, true, never>;
}
declare class DxoPolarChartLoadingIndicatorModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPolarChartLoadingIndicatorModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoPolarChartLoadingIndicatorModule, never, [typeof DxoPolarChartLoadingIndicatorComponent], [typeof DxoPolarChartLoadingIndicatorComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoPolarChartLoadingIndicatorModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoPolarChartMarginComponent extends NestedOption implements OnDestroy, OnInit {
    get bottom(): number;
    set bottom(value: number);
    get left(): number;
    set left(value: number);
    get right(): number;
    set right(value: number);
    get top(): number;
    set top(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPolarChartMarginComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoPolarChartMarginComponent, "dxo-polar-chart-margin", never, { "bottom": { "alias": "bottom"; "required": false; }; "left": { "alias": "left"; "required": false; }; "right": { "alias": "right"; "required": false; }; "top": { "alias": "top"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoPolarChartMarginModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPolarChartMarginModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoPolarChartMarginModule, never, [typeof DxoPolarChartMarginComponent], [typeof DxoPolarChartMarginComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoPolarChartMarginModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoPolarChartMinVisualRangeLengthComponent extends NestedOption implements OnDestroy, OnInit {
    get days(): number;
    set days(value: number);
    get hours(): number;
    set hours(value: number);
    get milliseconds(): number;
    set milliseconds(value: number);
    get minutes(): number;
    set minutes(value: number);
    get months(): number;
    set months(value: number);
    get quarters(): number;
    set quarters(value: number);
    get seconds(): number;
    set seconds(value: number);
    get weeks(): number;
    set weeks(value: number);
    get years(): number;
    set years(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPolarChartMinVisualRangeLengthComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoPolarChartMinVisualRangeLengthComponent, "dxo-polar-chart-min-visual-range-length", never, { "days": { "alias": "days"; "required": false; }; "hours": { "alias": "hours"; "required": false; }; "milliseconds": { "alias": "milliseconds"; "required": false; }; "minutes": { "alias": "minutes"; "required": false; }; "months": { "alias": "months"; "required": false; }; "quarters": { "alias": "quarters"; "required": false; }; "seconds": { "alias": "seconds"; "required": false; }; "weeks": { "alias": "weeks"; "required": false; }; "years": { "alias": "years"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoPolarChartMinVisualRangeLengthModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPolarChartMinVisualRangeLengthModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoPolarChartMinVisualRangeLengthModule, never, [typeof DxoPolarChartMinVisualRangeLengthComponent], [typeof DxoPolarChartMinVisualRangeLengthComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoPolarChartMinVisualRangeLengthModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoPolarChartMinorGridComponent extends NestedOption implements OnDestroy, OnInit {
    get color(): string;
    set color(value: string);
    get opacity(): number | undefined;
    set opacity(value: number | undefined);
    get visible(): boolean;
    set visible(value: boolean);
    get width(): number;
    set width(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPolarChartMinorGridComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoPolarChartMinorGridComponent, "dxo-polar-chart-minor-grid", never, { "color": { "alias": "color"; "required": false; }; "opacity": { "alias": "opacity"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoPolarChartMinorGridModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPolarChartMinorGridModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoPolarChartMinorGridModule, never, [typeof DxoPolarChartMinorGridComponent], [typeof DxoPolarChartMinorGridComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoPolarChartMinorGridModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoPolarChartMinorTickIntervalComponent extends NestedOption implements OnDestroy, OnInit {
    get days(): number;
    set days(value: number);
    get hours(): number;
    set hours(value: number);
    get milliseconds(): number;
    set milliseconds(value: number);
    get minutes(): number;
    set minutes(value: number);
    get months(): number;
    set months(value: number);
    get quarters(): number;
    set quarters(value: number);
    get seconds(): number;
    set seconds(value: number);
    get weeks(): number;
    set weeks(value: number);
    get years(): number;
    set years(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPolarChartMinorTickIntervalComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoPolarChartMinorTickIntervalComponent, "dxo-polar-chart-minor-tick-interval", never, { "days": { "alias": "days"; "required": false; }; "hours": { "alias": "hours"; "required": false; }; "milliseconds": { "alias": "milliseconds"; "required": false; }; "minutes": { "alias": "minutes"; "required": false; }; "months": { "alias": "months"; "required": false; }; "quarters": { "alias": "quarters"; "required": false; }; "seconds": { "alias": "seconds"; "required": false; }; "weeks": { "alias": "weeks"; "required": false; }; "years": { "alias": "years"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoPolarChartMinorTickIntervalModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPolarChartMinorTickIntervalModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoPolarChartMinorTickIntervalModule, never, [typeof DxoPolarChartMinorTickIntervalComponent], [typeof DxoPolarChartMinorTickIntervalComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoPolarChartMinorTickIntervalModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoPolarChartMinorTickComponent extends NestedOption implements OnDestroy, OnInit {
    get color(): string;
    set color(value: string);
    get length(): number;
    set length(value: number);
    get opacity(): number;
    set opacity(value: number);
    get shift(): number;
    set shift(value: number);
    get visible(): boolean;
    set visible(value: boolean);
    get width(): number;
    set width(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPolarChartMinorTickComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoPolarChartMinorTickComponent, "dxo-polar-chart-minor-tick", never, { "color": { "alias": "color"; "required": false; }; "length": { "alias": "length"; "required": false; }; "opacity": { "alias": "opacity"; "required": false; }; "shift": { "alias": "shift"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoPolarChartMinorTickModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPolarChartMinorTickModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoPolarChartMinorTickModule, never, [typeof DxoPolarChartMinorTickComponent], [typeof DxoPolarChartMinorTickComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoPolarChartMinorTickModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoPolarChartPointBorderComponent extends NestedOption implements OnDestroy, OnInit {
    get color(): string | undefined;
    set color(value: string | undefined);
    get visible(): boolean;
    set visible(value: boolean);
    get width(): number;
    set width(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPolarChartPointBorderComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoPolarChartPointBorderComponent, "dxo-polar-chart-point-border", never, { "color": { "alias": "color"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoPolarChartPointBorderModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPolarChartPointBorderModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoPolarChartPointBorderModule, never, [typeof DxoPolarChartPointBorderComponent], [typeof DxoPolarChartPointBorderComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoPolarChartPointBorderModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoPolarChartPointHoverStyleComponent extends NestedOption implements OnDestroy, OnInit {
    get border(): {
        color?: string | undefined;
        visible?: boolean;
        width?: number;
    };
    set border(value: {
        color?: string | undefined;
        visible?: boolean;
        width?: number;
    });
    get color(): ChartsColor | string | undefined;
    set color(value: ChartsColor | string | undefined);
    get size(): number;
    set size(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPolarChartPointHoverStyleComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoPolarChartPointHoverStyleComponent, "dxo-polar-chart-point-hover-style", never, { "border": { "alias": "border"; "required": false; }; "color": { "alias": "color"; "required": false; }; "size": { "alias": "size"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoPolarChartPointHoverStyleModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPolarChartPointHoverStyleModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoPolarChartPointHoverStyleModule, never, [typeof DxoPolarChartPointHoverStyleComponent], [typeof DxoPolarChartPointHoverStyleComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoPolarChartPointHoverStyleModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoPolarChartPointSelectionStyleComponent extends NestedOption implements OnDestroy, OnInit {
    get border(): {
        color?: string | undefined;
        visible?: boolean;
        width?: number;
    };
    set border(value: {
        color?: string | undefined;
        visible?: boolean;
        width?: number;
    });
    get color(): ChartsColor | string | undefined;
    set color(value: ChartsColor | string | undefined);
    get size(): number;
    set size(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPolarChartPointSelectionStyleComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoPolarChartPointSelectionStyleComponent, "dxo-polar-chart-point-selection-style", never, { "border": { "alias": "border"; "required": false; }; "color": { "alias": "color"; "required": false; }; "size": { "alias": "size"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoPolarChartPointSelectionStyleModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPolarChartPointSelectionStyleModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoPolarChartPointSelectionStyleModule, never, [typeof DxoPolarChartPointSelectionStyleComponent], [typeof DxoPolarChartPointSelectionStyleComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoPolarChartPointSelectionStyleModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoPolarChartPointComponent extends NestedOption implements OnDestroy, OnInit {
    get border(): {
        color?: string | undefined;
        visible?: boolean;
        width?: number;
    };
    set border(value: {
        color?: string | undefined;
        visible?: boolean;
        width?: number;
    });
    get color(): ChartsColor | string | undefined;
    set color(value: ChartsColor | string | undefined);
    get hoverMode(): PointInteractionMode;
    set hoverMode(value: PointInteractionMode);
    get hoverStyle(): {
        border?: {
            color?: string | undefined;
            visible?: boolean;
            width?: number;
        };
        color?: ChartsColor | string | undefined;
        size?: number;
    };
    set hoverStyle(value: {
        border?: {
            color?: string | undefined;
            visible?: boolean;
            width?: number;
        };
        color?: ChartsColor | string | undefined;
        size?: number;
    });
    get image(): string | undefined | {
        height?: number;
        url?: string | undefined;
        width?: number;
    };
    set image(value: string | undefined | {
        height?: number;
        url?: string | undefined;
        width?: number;
    });
    get selectionMode(): PointInteractionMode;
    set selectionMode(value: PointInteractionMode);
    get selectionStyle(): {
        border?: {
            color?: string | undefined;
            visible?: boolean;
            width?: number;
        };
        color?: ChartsColor | string | undefined;
        size?: number;
    };
    set selectionStyle(value: {
        border?: {
            color?: string | undefined;
            visible?: boolean;
            width?: number;
        };
        color?: ChartsColor | string | undefined;
        size?: number;
    });
    get size(): number;
    set size(value: number);
    get symbol(): PointSymbol;
    set symbol(value: PointSymbol);
    get visible(): boolean;
    set visible(value: boolean);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPolarChartPointComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoPolarChartPointComponent, "dxo-polar-chart-point", never, { "border": { "alias": "border"; "required": false; }; "color": { "alias": "color"; "required": false; }; "hoverMode": { "alias": "hoverMode"; "required": false; }; "hoverStyle": { "alias": "hoverStyle"; "required": false; }; "image": { "alias": "image"; "required": false; }; "selectionMode": { "alias": "selectionMode"; "required": false; }; "selectionStyle": { "alias": "selectionStyle"; "required": false; }; "size": { "alias": "size"; "required": false; }; "symbol": { "alias": "symbol"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoPolarChartPointModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPolarChartPointModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoPolarChartPointModule, never, [typeof DxoPolarChartPointComponent], [typeof DxoPolarChartPointComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoPolarChartPointModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoPolarChartPolarChartTitleSubtitleComponent extends NestedOption implements OnDestroy, OnInit {
    get font(): Font;
    set font(value: Font);
    get offset(): number;
    set offset(value: number);
    get text(): string | undefined;
    set text(value: string | undefined);
    get textOverflow(): TextOverflow;
    set textOverflow(value: TextOverflow);
    get wordWrap(): WordWrap;
    set wordWrap(value: WordWrap);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPolarChartPolarChartTitleSubtitleComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoPolarChartPolarChartTitleSubtitleComponent, "dxo-polar-chart-polar-chart-title-subtitle", never, { "font": { "alias": "font"; "required": false; }; "offset": { "alias": "offset"; "required": false; }; "text": { "alias": "text"; "required": false; }; "textOverflow": { "alias": "textOverflow"; "required": false; }; "wordWrap": { "alias": "wordWrap"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoPolarChartPolarChartTitleSubtitleModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPolarChartPolarChartTitleSubtitleModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoPolarChartPolarChartTitleSubtitleModule, never, [typeof DxoPolarChartPolarChartTitleSubtitleComponent], [typeof DxoPolarChartPolarChartTitleSubtitleComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoPolarChartPolarChartTitleSubtitleModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoPolarChartPolarChartTitleComponent extends NestedOption implements OnDestroy, OnInit {
    get font(): Font;
    set font(value: Font);
    get horizontalAlignment(): HorizontalAlignment;
    set horizontalAlignment(value: HorizontalAlignment);
    get margin(): number | {
        bottom?: number;
        left?: number;
        right?: number;
        top?: number;
    };
    set margin(value: number | {
        bottom?: number;
        left?: number;
        right?: number;
        top?: number;
    });
    get placeholderSize(): number | undefined;
    set placeholderSize(value: number | undefined);
    get subtitle(): string | {
        font?: Font;
        offset?: number;
        text?: string | undefined;
        textOverflow?: TextOverflow;
        wordWrap?: WordWrap;
    };
    set subtitle(value: string | {
        font?: Font;
        offset?: number;
        text?: string | undefined;
        textOverflow?: TextOverflow;
        wordWrap?: WordWrap;
    });
    get text(): string | undefined;
    set text(value: string | undefined);
    get textOverflow(): TextOverflow;
    set textOverflow(value: TextOverflow);
    get verticalAlignment(): VerticalEdge;
    set verticalAlignment(value: VerticalEdge);
    get wordWrap(): WordWrap;
    set wordWrap(value: WordWrap);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPolarChartPolarChartTitleComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoPolarChartPolarChartTitleComponent, "dxo-polar-chart-polar-chart-title", never, { "font": { "alias": "font"; "required": false; }; "horizontalAlignment": { "alias": "horizontalAlignment"; "required": false; }; "margin": { "alias": "margin"; "required": false; }; "placeholderSize": { "alias": "placeholderSize"; "required": false; }; "subtitle": { "alias": "subtitle"; "required": false; }; "text": { "alias": "text"; "required": false; }; "textOverflow": { "alias": "textOverflow"; "required": false; }; "verticalAlignment": { "alias": "verticalAlignment"; "required": false; }; "wordWrap": { "alias": "wordWrap"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoPolarChartPolarChartTitleModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPolarChartPolarChartTitleModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoPolarChartPolarChartTitleModule, never, [typeof DxoPolarChartPolarChartTitleComponent], [typeof DxoPolarChartPolarChartTitleComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoPolarChartPolarChartTitleModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoPolarChartSelectionStyleComponent extends NestedOption implements OnDestroy, OnInit {
    get border(): {
        color?: string | undefined;
        visible?: boolean;
        width?: number;
        dashStyle?: DashStyle | undefined;
    };
    set border(value: {
        color?: string | undefined;
        visible?: boolean;
        width?: number;
        dashStyle?: DashStyle | undefined;
    });
    get color(): ChartsColor | string | undefined;
    set color(value: ChartsColor | string | undefined);
    get size(): number;
    set size(value: number);
    get dashStyle(): DashStyle;
    set dashStyle(value: DashStyle);
    get hatching(): {
        direction?: HatchDirection;
        opacity?: number;
        step?: number;
        width?: number;
    };
    set hatching(value: {
        direction?: HatchDirection;
        opacity?: number;
        step?: number;
        width?: number;
    });
    get highlight(): boolean;
    set highlight(value: boolean);
    get width(): number;
    set width(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPolarChartSelectionStyleComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoPolarChartSelectionStyleComponent, "dxo-polar-chart-selection-style", never, { "border": { "alias": "border"; "required": false; }; "color": { "alias": "color"; "required": false; }; "size": { "alias": "size"; "required": false; }; "dashStyle": { "alias": "dashStyle"; "required": false; }; "hatching": { "alias": "hatching"; "required": false; }; "highlight": { "alias": "highlight"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoPolarChartSelectionStyleModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPolarChartSelectionStyleModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoPolarChartSelectionStyleModule, never, [typeof DxoPolarChartSelectionStyleComponent], [typeof DxoPolarChartSelectionStyleComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoPolarChartSelectionStyleModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoPolarChartSeriesBorderComponent extends NestedOption implements OnDestroy, OnInit {
    get color(): string | undefined;
    set color(value: string | undefined);
    get dashStyle(): DashStyle | undefined;
    set dashStyle(value: DashStyle | undefined);
    get visible(): boolean;
    set visible(value: boolean);
    get width(): number;
    set width(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPolarChartSeriesBorderComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoPolarChartSeriesBorderComponent, "dxo-polar-chart-series-border", never, { "color": { "alias": "color"; "required": false; }; "dashStyle": { "alias": "dashStyle"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoPolarChartSeriesBorderModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPolarChartSeriesBorderModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoPolarChartSeriesBorderModule, never, [typeof DxoPolarChartSeriesBorderComponent], [typeof DxoPolarChartSeriesBorderComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoPolarChartSeriesBorderModule>;
}

declare class DxiPolarChartSeriesComponent extends CollectionNestedOption {
    get argumentField(): string;
    set argumentField(value: string);
    get barPadding(): number | undefined;
    set barPadding(value: number | undefined);
    get barWidth(): number | undefined;
    set barWidth(value: number | undefined);
    get border(): {
        color?: string | undefined;
        dashStyle?: DashStyle | undefined;
        visible?: boolean;
        width?: number;
    };
    set border(value: {
        color?: string | undefined;
        dashStyle?: DashStyle | undefined;
        visible?: boolean;
        width?: number;
    });
    get closed(): boolean;
    set closed(value: boolean);
    get color(): ChartsColor | string | undefined;
    set color(value: ChartsColor | string | undefined);
    get dashStyle(): DashStyle;
    set dashStyle(value: DashStyle);
    get hoverMode(): SeriesHoverMode;
    set hoverMode(value: SeriesHoverMode);
    get hoverStyle(): {
        border?: {
            color?: string | undefined;
            dashStyle?: DashStyle | undefined;
            visible?: boolean;
            width?: number;
        };
        color?: ChartsColor | string | undefined;
        dashStyle?: DashStyle;
        hatching?: {
            direction?: HatchDirection;
            opacity?: number;
            step?: number;
            width?: number;
        };
        highlight?: boolean;
        width?: number;
    };
    set hoverStyle(value: {
        border?: {
            color?: string | undefined;
            dashStyle?: DashStyle | undefined;
            visible?: boolean;
            width?: number;
        };
        color?: ChartsColor | string | undefined;
        dashStyle?: DashStyle;
        hatching?: {
            direction?: HatchDirection;
            opacity?: number;
            step?: number;
            width?: number;
        };
        highlight?: boolean;
        width?: number;
    });
    get ignoreEmptyPoints(): boolean;
    set ignoreEmptyPoints(value: boolean);
    get label(): {
        argumentFormat?: Format | undefined;
        backgroundColor?: string | undefined;
        border?: {
            color?: string | undefined;
            dashStyle?: DashStyle | undefined;
            visible?: boolean;
            width?: number;
        };
        connector?: {
            color?: string | undefined;
            visible?: boolean;
            width?: number;
        };
        customizeText?: ((pointInfo: any) => string);
        displayFormat?: string | undefined;
        font?: Font;
        format?: Format | undefined;
        position?: RelativePosition;
        rotationAngle?: number;
        showForZeroValues?: boolean;
        visible?: boolean;
    };
    set label(value: {
        argumentFormat?: Format | undefined;
        backgroundColor?: string | undefined;
        border?: {
            color?: string | undefined;
            dashStyle?: DashStyle | undefined;
            visible?: boolean;
            width?: number;
        };
        connector?: {
            color?: string | undefined;
            visible?: boolean;
            width?: number;
        };
        customizeText?: ((pointInfo: any) => string);
        displayFormat?: string | undefined;
        font?: Font;
        format?: Format | undefined;
        position?: RelativePosition;
        rotationAngle?: number;
        showForZeroValues?: boolean;
        visible?: boolean;
    });
    get maxLabelCount(): number | undefined;
    set maxLabelCount(value: number | undefined);
    get minBarSize(): number | undefined;
    set minBarSize(value: number | undefined);
    get name(): string | undefined;
    set name(value: string | undefined);
    get opacity(): number;
    set opacity(value: number);
    get point(): {
        border?: {
            color?: string | undefined;
            visible?: boolean;
            width?: number;
        };
        color?: ChartsColor | string | undefined;
        hoverMode?: PointInteractionMode;
        hoverStyle?: {
            border?: {
                color?: string | undefined;
                visible?: boolean;
                width?: number;
            };
            color?: ChartsColor | string | undefined;
            size?: number;
        };
        image?: string | undefined | {
            height?: number;
            url?: string | undefined;
            width?: number;
        };
        selectionMode?: PointInteractionMode;
        selectionStyle?: {
            border?: {
                color?: string | undefined;
                visible?: boolean;
                width?: number;
            };
            color?: ChartsColor | string | undefined;
            size?: number;
        };
        size?: number;
        symbol?: PointSymbol;
        visible?: boolean;
    };
    set point(value: {
        border?: {
            color?: string | undefined;
            visible?: boolean;
            width?: number;
        };
        color?: ChartsColor | string | undefined;
        hoverMode?: PointInteractionMode;
        hoverStyle?: {
            border?: {
                color?: string | undefined;
                visible?: boolean;
                width?: number;
            };
            color?: ChartsColor | string | undefined;
            size?: number;
        };
        image?: string | undefined | {
            height?: number;
            url?: string | undefined;
            width?: number;
        };
        selectionMode?: PointInteractionMode;
        selectionStyle?: {
            border?: {
                color?: string | undefined;
                visible?: boolean;
                width?: number;
            };
            color?: ChartsColor | string | undefined;
            size?: number;
        };
        size?: number;
        symbol?: PointSymbol;
        visible?: boolean;
    });
    get selectionMode(): SeriesSelectionMode;
    set selectionMode(value: SeriesSelectionMode);
    get selectionStyle(): {
        border?: {
            color?: string | undefined;
            dashStyle?: DashStyle | undefined;
            visible?: boolean;
            width?: number;
        };
        color?: ChartsColor | string | undefined;
        dashStyle?: DashStyle;
        hatching?: {
            direction?: HatchDirection;
            opacity?: number;
            step?: number;
            width?: number;
        };
        highlight?: boolean;
        width?: number;
    };
    set selectionStyle(value: {
        border?: {
            color?: string | undefined;
            dashStyle?: DashStyle | undefined;
            visible?: boolean;
            width?: number;
        };
        color?: ChartsColor | string | undefined;
        dashStyle?: DashStyle;
        hatching?: {
            direction?: HatchDirection;
            opacity?: number;
            step?: number;
            width?: number;
        };
        highlight?: boolean;
        width?: number;
    });
    get showInLegend(): boolean;
    set showInLegend(value: boolean);
    get stack(): string;
    set stack(value: string);
    get tag(): any | undefined;
    set tag(value: any | undefined);
    get tagField(): string;
    set tagField(value: string);
    get type(): PolarChartSeriesType;
    set type(value: PolarChartSeriesType);
    get valueErrorBar(): {
        color?: string;
        displayMode?: ValueErrorBarDisplayMode;
        edgeLength?: number;
        highValueField?: string | undefined;
        lineWidth?: number;
        lowValueField?: string | undefined;
        opacity?: number | undefined;
        type?: undefined | ValueErrorBarType;
        value?: number;
    };
    set valueErrorBar(value: {
        color?: string;
        displayMode?: ValueErrorBarDisplayMode;
        edgeLength?: number;
        highValueField?: string | undefined;
        lineWidth?: number;
        lowValueField?: string | undefined;
        opacity?: number | undefined;
        type?: undefined | ValueErrorBarType;
        value?: number;
    });
    get valueField(): string;
    set valueField(value: string);
    get visible(): boolean;
    set visible(value: boolean);
    get width(): number;
    set width(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiPolarChartSeriesComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiPolarChartSeriesComponent, "dxi-polar-chart-series", never, { "argumentField": { "alias": "argumentField"; "required": false; }; "barPadding": { "alias": "barPadding"; "required": false; }; "barWidth": { "alias": "barWidth"; "required": false; }; "border": { "alias": "border"; "required": false; }; "closed": { "alias": "closed"; "required": false; }; "color": { "alias": "color"; "required": false; }; "dashStyle": { "alias": "dashStyle"; "required": false; }; "hoverMode": { "alias": "hoverMode"; "required": false; }; "hoverStyle": { "alias": "hoverStyle"; "required": false; }; "ignoreEmptyPoints": { "alias": "ignoreEmptyPoints"; "required": false; }; "label": { "alias": "label"; "required": false; }; "maxLabelCount": { "alias": "maxLabelCount"; "required": false; }; "minBarSize": { "alias": "minBarSize"; "required": false; }; "name": { "alias": "name"; "required": false; }; "opacity": { "alias": "opacity"; "required": false; }; "point": { "alias": "point"; "required": false; }; "selectionMode": { "alias": "selectionMode"; "required": false; }; "selectionStyle": { "alias": "selectionStyle"; "required": false; }; "showInLegend": { "alias": "showInLegend"; "required": false; }; "stack": { "alias": "stack"; "required": false; }; "tag": { "alias": "tag"; "required": false; }; "tagField": { "alias": "tagField"; "required": false; }; "type": { "alias": "type"; "required": false; }; "valueErrorBar": { "alias": "valueErrorBar"; "required": false; }; "valueField": { "alias": "valueField"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxiPolarChartSeriesModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiPolarChartSeriesModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiPolarChartSeriesModule, never, [typeof DxiPolarChartSeriesComponent], [typeof DxiPolarChartSeriesComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiPolarChartSeriesModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoPolarChartSeriesTemplateComponent extends NestedOption implements OnDestroy, OnInit {
    get customizeSeries(): ((seriesName: any) => PolarChartSeries);
    set customizeSeries(value: ((seriesName: any) => PolarChartSeries));
    get nameField(): string;
    set nameField(value: string);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPolarChartSeriesTemplateComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoPolarChartSeriesTemplateComponent, "dxo-polar-chart-series-template", never, { "customizeSeries": { "alias": "customizeSeries"; "required": false; }; "nameField": { "alias": "nameField"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoPolarChartSeriesTemplateModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPolarChartSeriesTemplateModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoPolarChartSeriesTemplateModule, never, [typeof DxoPolarChartSeriesTemplateComponent], [typeof DxoPolarChartSeriesTemplateComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoPolarChartSeriesTemplateModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoPolarChartShadowComponent extends NestedOption implements OnDestroy, OnInit {
    get blur(): number;
    set blur(value: number);
    get color(): string;
    set color(value: string);
    get offsetX(): number;
    set offsetX(value: number);
    get offsetY(): number;
    set offsetY(value: number);
    get opacity(): number;
    set opacity(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPolarChartShadowComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoPolarChartShadowComponent, "dxo-polar-chart-shadow", never, { "blur": { "alias": "blur"; "required": false; }; "color": { "alias": "color"; "required": false; }; "offsetX": { "alias": "offsetX"; "required": false; }; "offsetY": { "alias": "offsetY"; "required": false; }; "opacity": { "alias": "opacity"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoPolarChartShadowModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPolarChartShadowModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoPolarChartShadowModule, never, [typeof DxoPolarChartShadowComponent], [typeof DxoPolarChartShadowComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoPolarChartShadowModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoPolarChartSizeComponent extends NestedOption implements OnDestroy, OnInit {
    get height(): number | undefined;
    set height(value: number | undefined);
    get width(): number | undefined;
    set width(value: number | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPolarChartSizeComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoPolarChartSizeComponent, "dxo-polar-chart-size", never, { "height": { "alias": "height"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoPolarChartSizeModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPolarChartSizeModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoPolarChartSizeModule, never, [typeof DxoPolarChartSizeComponent], [typeof DxoPolarChartSizeComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoPolarChartSizeModule>;
}

declare class DxiPolarChartStripComponent extends CollectionNestedOption {
    get color(): string | undefined;
    set color(value: string | undefined);
    get endValue(): Date | number | string | undefined;
    set endValue(value: Date | number | string | undefined);
    get label(): {
        font?: Font;
        text?: string | undefined;
    };
    set label(value: {
        font?: Font;
        text?: string | undefined;
    });
    get startValue(): Date | number | string | undefined;
    set startValue(value: Date | number | string | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiPolarChartStripComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiPolarChartStripComponent, "dxi-polar-chart-strip", never, { "color": { "alias": "color"; "required": false; }; "endValue": { "alias": "endValue"; "required": false; }; "label": { "alias": "label"; "required": false; }; "startValue": { "alias": "startValue"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxiPolarChartStripModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiPolarChartStripModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiPolarChartStripModule, never, [typeof DxiPolarChartStripComponent], [typeof DxiPolarChartStripComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiPolarChartStripModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoPolarChartStripLabelComponent extends NestedOption implements OnDestroy, OnInit {
    get font(): Font;
    set font(value: Font);
    get text(): string | undefined;
    set text(value: string | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPolarChartStripLabelComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoPolarChartStripLabelComponent, "dxo-polar-chart-strip-label", never, { "font": { "alias": "font"; "required": false; }; "text": { "alias": "text"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoPolarChartStripLabelModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPolarChartStripLabelModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoPolarChartStripLabelModule, never, [typeof DxoPolarChartStripLabelComponent], [typeof DxoPolarChartStripLabelComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoPolarChartStripLabelModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoPolarChartStripStyleLabelComponent extends NestedOption implements OnDestroy, OnInit {
    get font(): Font;
    set font(value: Font);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPolarChartStripStyleLabelComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoPolarChartStripStyleLabelComponent, "dxo-polar-chart-strip-style-label", never, { "font": { "alias": "font"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoPolarChartStripStyleLabelModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPolarChartStripStyleLabelModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoPolarChartStripStyleLabelModule, never, [typeof DxoPolarChartStripStyleLabelComponent], [typeof DxoPolarChartStripStyleLabelComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoPolarChartStripStyleLabelModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoPolarChartStripStyleComponent extends NestedOption implements OnDestroy, OnInit {
    get label(): {
        font?: Font;
    };
    set label(value: {
        font?: Font;
    });
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPolarChartStripStyleComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoPolarChartStripStyleComponent, "dxo-polar-chart-strip-style", never, { "label": { "alias": "label"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoPolarChartStripStyleModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPolarChartStripStyleModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoPolarChartStripStyleModule, never, [typeof DxoPolarChartStripStyleComponent], [typeof DxoPolarChartStripStyleComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoPolarChartStripStyleModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoPolarChartSubtitleComponent extends NestedOption implements OnDestroy, OnInit {
    get font(): Font;
    set font(value: Font);
    get offset(): number;
    set offset(value: number);
    get text(): string | undefined;
    set text(value: string | undefined);
    get textOverflow(): TextOverflow;
    set textOverflow(value: TextOverflow);
    get wordWrap(): WordWrap;
    set wordWrap(value: WordWrap);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPolarChartSubtitleComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoPolarChartSubtitleComponent, "dxo-polar-chart-subtitle", never, { "font": { "alias": "font"; "required": false; }; "offset": { "alias": "offset"; "required": false; }; "text": { "alias": "text"; "required": false; }; "textOverflow": { "alias": "textOverflow"; "required": false; }; "wordWrap": { "alias": "wordWrap"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoPolarChartSubtitleModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPolarChartSubtitleModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoPolarChartSubtitleModule, never, [typeof DxoPolarChartSubtitleComponent], [typeof DxoPolarChartSubtitleComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoPolarChartSubtitleModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoPolarChartTickIntervalComponent extends NestedOption implements OnDestroy, OnInit {
    get days(): number;
    set days(value: number);
    get hours(): number;
    set hours(value: number);
    get milliseconds(): number;
    set milliseconds(value: number);
    get minutes(): number;
    set minutes(value: number);
    get months(): number;
    set months(value: number);
    get quarters(): number;
    set quarters(value: number);
    get seconds(): number;
    set seconds(value: number);
    get weeks(): number;
    set weeks(value: number);
    get years(): number;
    set years(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPolarChartTickIntervalComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoPolarChartTickIntervalComponent, "dxo-polar-chart-tick-interval", never, { "days": { "alias": "days"; "required": false; }; "hours": { "alias": "hours"; "required": false; }; "milliseconds": { "alias": "milliseconds"; "required": false; }; "minutes": { "alias": "minutes"; "required": false; }; "months": { "alias": "months"; "required": false; }; "quarters": { "alias": "quarters"; "required": false; }; "seconds": { "alias": "seconds"; "required": false; }; "weeks": { "alias": "weeks"; "required": false; }; "years": { "alias": "years"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoPolarChartTickIntervalModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPolarChartTickIntervalModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoPolarChartTickIntervalModule, never, [typeof DxoPolarChartTickIntervalComponent], [typeof DxoPolarChartTickIntervalComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoPolarChartTickIntervalModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoPolarChartTickComponent extends NestedOption implements OnDestroy, OnInit {
    get color(): string;
    set color(value: string);
    get length(): number;
    set length(value: number);
    get opacity(): number | undefined;
    set opacity(value: number | undefined);
    get shift(): number;
    set shift(value: number);
    get visible(): boolean;
    set visible(value: boolean);
    get width(): number;
    set width(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPolarChartTickComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoPolarChartTickComponent, "dxo-polar-chart-tick", never, { "color": { "alias": "color"; "required": false; }; "length": { "alias": "length"; "required": false; }; "opacity": { "alias": "opacity"; "required": false; }; "shift": { "alias": "shift"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoPolarChartTickModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPolarChartTickModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoPolarChartTickModule, never, [typeof DxoPolarChartTickComponent], [typeof DxoPolarChartTickComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoPolarChartTickModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoPolarChartTitleComponent extends NestedOption implements OnDestroy, OnInit {
    get font(): Font;
    set font(value: Font);
    get horizontalAlignment(): HorizontalAlignment | undefined;
    set horizontalAlignment(value: HorizontalAlignment | undefined);
    get margin(): number | {
        bottom?: number;
        left?: number;
        right?: number;
        top?: number;
    };
    set margin(value: number | {
        bottom?: number;
        left?: number;
        right?: number;
        top?: number;
    });
    get placeholderSize(): number | undefined;
    set placeholderSize(value: number | undefined);
    get subtitle(): string | {
        font?: Font;
        offset?: number;
        text?: string | undefined;
        textOverflow?: TextOverflow;
        wordWrap?: WordWrap;
    };
    set subtitle(value: string | {
        font?: Font;
        offset?: number;
        text?: string | undefined;
        textOverflow?: TextOverflow;
        wordWrap?: WordWrap;
    });
    get text(): string | undefined;
    set text(value: string | undefined);
    get verticalAlignment(): VerticalEdge;
    set verticalAlignment(value: VerticalEdge);
    get textOverflow(): TextOverflow;
    set textOverflow(value: TextOverflow);
    get wordWrap(): WordWrap;
    set wordWrap(value: WordWrap);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPolarChartTitleComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoPolarChartTitleComponent, "dxo-polar-chart-title", never, { "font": { "alias": "font"; "required": false; }; "horizontalAlignment": { "alias": "horizontalAlignment"; "required": false; }; "margin": { "alias": "margin"; "required": false; }; "placeholderSize": { "alias": "placeholderSize"; "required": false; }; "subtitle": { "alias": "subtitle"; "required": false; }; "text": { "alias": "text"; "required": false; }; "verticalAlignment": { "alias": "verticalAlignment"; "required": false; }; "textOverflow": { "alias": "textOverflow"; "required": false; }; "wordWrap": { "alias": "wordWrap"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoPolarChartTitleModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPolarChartTitleModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoPolarChartTitleModule, never, [typeof DxoPolarChartTitleComponent], [typeof DxoPolarChartTitleComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoPolarChartTitleModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoPolarChartTooltipBorderComponent extends NestedOption implements OnDestroy, OnInit {
    get color(): string;
    set color(value: string);
    get dashStyle(): DashStyle;
    set dashStyle(value: DashStyle);
    get opacity(): number | undefined;
    set opacity(value: number | undefined);
    get visible(): boolean;
    set visible(value: boolean);
    get width(): number;
    set width(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPolarChartTooltipBorderComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoPolarChartTooltipBorderComponent, "dxo-polar-chart-tooltip-border", never, { "color": { "alias": "color"; "required": false; }; "dashStyle": { "alias": "dashStyle"; "required": false; }; "opacity": { "alias": "opacity"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoPolarChartTooltipBorderModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPolarChartTooltipBorderModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoPolarChartTooltipBorderModule, never, [typeof DxoPolarChartTooltipBorderComponent], [typeof DxoPolarChartTooltipBorderComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoPolarChartTooltipBorderModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoPolarChartTooltipComponent extends NestedOption implements OnDestroy, OnInit {
    get argumentFormat(): Format | undefined;
    set argumentFormat(value: Format | undefined);
    get arrowLength(): number;
    set arrowLength(value: number);
    get border(): {
        color?: string;
        dashStyle?: DashStyle;
        opacity?: number | undefined;
        visible?: boolean;
        width?: number;
    };
    set border(value: {
        color?: string;
        dashStyle?: DashStyle;
        opacity?: number | undefined;
        visible?: boolean;
        width?: number;
    });
    get color(): string;
    set color(value: string);
    get container(): any | string | undefined;
    set container(value: any | string | undefined);
    get contentTemplate(): any;
    set contentTemplate(value: any);
    get cornerRadius(): number;
    set cornerRadius(value: number);
    get customizeTooltip(): ((pointInfo: dxPolarChartPointInfo) => Record<string, any>) | undefined;
    set customizeTooltip(value: ((pointInfo: dxPolarChartPointInfo) => Record<string, any>) | undefined);
    get enabled(): boolean;
    set enabled(value: boolean);
    get font(): Font;
    set font(value: Font);
    get format(): Format | undefined;
    set format(value: Format | undefined);
    get interactive(): boolean;
    set interactive(value: boolean);
    get opacity(): number | undefined;
    set opacity(value: number | undefined);
    get paddingLeftRight(): number;
    set paddingLeftRight(value: number);
    get paddingTopBottom(): number;
    set paddingTopBottom(value: number);
    get shadow(): {
        blur?: number;
        color?: string;
        offsetX?: number;
        offsetY?: number;
        opacity?: number;
    };
    set shadow(value: {
        blur?: number;
        color?: string;
        offsetX?: number;
        offsetY?: number;
        opacity?: number;
    });
    get shared(): boolean;
    set shared(value: boolean);
    get zIndex(): number | undefined;
    set zIndex(value: number | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPolarChartTooltipComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoPolarChartTooltipComponent, "dxo-polar-chart-tooltip", never, { "argumentFormat": { "alias": "argumentFormat"; "required": false; }; "arrowLength": { "alias": "arrowLength"; "required": false; }; "border": { "alias": "border"; "required": false; }; "color": { "alias": "color"; "required": false; }; "container": { "alias": "container"; "required": false; }; "contentTemplate": { "alias": "contentTemplate"; "required": false; }; "cornerRadius": { "alias": "cornerRadius"; "required": false; }; "customizeTooltip": { "alias": "customizeTooltip"; "required": false; }; "enabled": { "alias": "enabled"; "required": false; }; "font": { "alias": "font"; "required": false; }; "format": { "alias": "format"; "required": false; }; "interactive": { "alias": "interactive"; "required": false; }; "opacity": { "alias": "opacity"; "required": false; }; "paddingLeftRight": { "alias": "paddingLeftRight"; "required": false; }; "paddingTopBottom": { "alias": "paddingTopBottom"; "required": false; }; "shadow": { "alias": "shadow"; "required": false; }; "shared": { "alias": "shared"; "required": false; }; "zIndex": { "alias": "zIndex"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoPolarChartTooltipModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPolarChartTooltipModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoPolarChartTooltipModule, never, [typeof DxoPolarChartTooltipComponent], [typeof DxoPolarChartTooltipComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoPolarChartTooltipModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoPolarChartValueAxisComponent extends NestedOption implements OnDestroy, OnInit {
    set _constantLinesContentChildren(value: QueryList<CollectionNestedOption>);
    set _stripsContentChildren(value: QueryList<CollectionNestedOption>);
    get allowDecimals(): boolean | undefined;
    set allowDecimals(value: boolean | undefined);
    get axisDivisionFactor(): number;
    set axisDivisionFactor(value: number);
    get categories(): Array<Date | number | string>;
    set categories(value: Array<Date | number | string>);
    get color(): string;
    set color(value: string);
    get constantLines(): {
        color?: string;
        dashStyle?: DashStyle;
        displayBehindSeries?: boolean;
        extendAxis?: boolean;
        label?: {
            font?: Font;
            text?: string | undefined;
            visible?: boolean;
        };
        value?: Date | number | string | undefined;
        width?: number;
    }[];
    set constantLines(value: {
        color?: string;
        dashStyle?: DashStyle;
        displayBehindSeries?: boolean;
        extendAxis?: boolean;
        label?: {
            font?: Font;
            text?: string | undefined;
            visible?: boolean;
        };
        value?: Date | number | string | undefined;
        width?: number;
    }[]);
    get constantLineStyle(): {
        color?: string;
        dashStyle?: DashStyle;
        label?: {
            font?: Font;
            visible?: boolean;
        };
        width?: number;
    };
    set constantLineStyle(value: {
        color?: string;
        dashStyle?: DashStyle;
        label?: {
            font?: Font;
            visible?: boolean;
        };
        width?: number;
    });
    get discreteAxisDivisionMode(): DiscreteAxisDivisionMode;
    set discreteAxisDivisionMode(value: DiscreteAxisDivisionMode);
    get endOnTick(): boolean;
    set endOnTick(value: boolean);
    get grid(): {
        color?: string;
        opacity?: number | undefined;
        visible?: boolean;
        width?: number;
    };
    set grid(value: {
        color?: string;
        opacity?: number | undefined;
        visible?: boolean;
        width?: number;
    });
    get inverted(): boolean;
    set inverted(value: boolean);
    get label(): {
        customizeHint?: ((axisValue: {
            value: Date | number | string;
            valueText: string;
        }) => string);
        customizeText?: ((axisValue: {
            value: Date | number | string;
            valueText: string;
        }) => string);
        font?: Font;
        format?: Format | undefined;
        indentFromAxis?: number;
        overlappingBehavior?: LabelOverlap;
        visible?: boolean;
    };
    set label(value: {
        customizeHint?: ((axisValue: {
            value: Date | number | string;
            valueText: string;
        }) => string);
        customizeText?: ((axisValue: {
            value: Date | number | string;
            valueText: string;
        }) => string);
        font?: Font;
        format?: Format | undefined;
        indentFromAxis?: number;
        overlappingBehavior?: LabelOverlap;
        visible?: boolean;
    });
    get linearThreshold(): number | undefined;
    set linearThreshold(value: number | undefined);
    get logarithmBase(): number;
    set logarithmBase(value: number);
    get maxValueMargin(): number | undefined;
    set maxValueMargin(value: number | undefined);
    get minorGrid(): {
        color?: string;
        opacity?: number | undefined;
        visible?: boolean;
        width?: number;
    };
    set minorGrid(value: {
        color?: string;
        opacity?: number | undefined;
        visible?: boolean;
        width?: number;
    });
    get minorTick(): {
        color?: string;
        length?: number;
        opacity?: number;
        visible?: boolean;
        width?: number;
    };
    set minorTick(value: {
        color?: string;
        length?: number;
        opacity?: number;
        visible?: boolean;
        width?: number;
    });
    get minorTickCount(): number | undefined;
    set minorTickCount(value: number | undefined);
    get minorTickInterval(): number | TimeInterval | {
        days?: number;
        hours?: number;
        milliseconds?: number;
        minutes?: number;
        months?: number;
        quarters?: number;
        seconds?: number;
        weeks?: number;
        years?: number;
    };
    set minorTickInterval(value: number | TimeInterval | {
        days?: number;
        hours?: number;
        milliseconds?: number;
        minutes?: number;
        months?: number;
        quarters?: number;
        seconds?: number;
        weeks?: number;
        years?: number;
    });
    get minValueMargin(): number | undefined;
    set minValueMargin(value: number | undefined);
    get minVisualRangeLength(): number | TimeInterval | undefined | {
        days?: number;
        hours?: number;
        milliseconds?: number;
        minutes?: number;
        months?: number;
        quarters?: number;
        seconds?: number;
        weeks?: number;
        years?: number;
    };
    set minVisualRangeLength(value: number | TimeInterval | undefined | {
        days?: number;
        hours?: number;
        milliseconds?: number;
        minutes?: number;
        months?: number;
        quarters?: number;
        seconds?: number;
        weeks?: number;
        years?: number;
    });
    get opacity(): number | undefined;
    set opacity(value: number | undefined);
    get showZero(): boolean | undefined;
    set showZero(value: boolean | undefined);
    get strips(): {
        color?: string | undefined;
        endValue?: Date | number | string | undefined;
        label?: {
            font?: Font;
            text?: string | undefined;
        };
        startValue?: Date | number | string | undefined;
    }[];
    set strips(value: {
        color?: string | undefined;
        endValue?: Date | number | string | undefined;
        label?: {
            font?: Font;
            text?: string | undefined;
        };
        startValue?: Date | number | string | undefined;
    }[]);
    get stripStyle(): {
        label?: {
            font?: Font;
        };
    };
    set stripStyle(value: {
        label?: {
            font?: Font;
        };
    });
    get tick(): {
        color?: string;
        length?: number;
        opacity?: number | undefined;
        visible?: boolean;
        width?: number;
    };
    set tick(value: {
        color?: string;
        length?: number;
        opacity?: number | undefined;
        visible?: boolean;
        width?: number;
    });
    get tickInterval(): number | TimeInterval | {
        days?: number;
        hours?: number;
        milliseconds?: number;
        minutes?: number;
        months?: number;
        quarters?: number;
        seconds?: number;
        weeks?: number;
        years?: number;
    };
    set tickInterval(value: number | TimeInterval | {
        days?: number;
        hours?: number;
        milliseconds?: number;
        minutes?: number;
        months?: number;
        quarters?: number;
        seconds?: number;
        weeks?: number;
        years?: number;
    });
    get type(): AxisScaleType | undefined;
    set type(value: AxisScaleType | undefined);
    get valueMarginsEnabled(): boolean;
    set valueMarginsEnabled(value: boolean);
    get valueType(): ChartsDataType | undefined;
    set valueType(value: ChartsDataType | undefined);
    get visible(): boolean;
    set visible(value: boolean);
    get visualRange(): Array<Date | number | string> | CommonChartTypes.VisualRange;
    set visualRange(value: Array<Date | number | string> | CommonChartTypes.VisualRange);
    get visualRangeUpdateMode(): ValueAxisVisualRangeUpdateMode;
    set visualRangeUpdateMode(value: ValueAxisVisualRangeUpdateMode);
    get wholeRange(): Array<Date | number | string> | undefined | CommonChartTypes.VisualRange;
    set wholeRange(value: Array<Date | number | string> | undefined | CommonChartTypes.VisualRange);
    get width(): number;
    set width(value: number);
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    visualRangeChange: EventEmitter<Array<Date | number | string> | CommonChartTypes.VisualRange>;
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPolarChartValueAxisComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoPolarChartValueAxisComponent, "dxo-polar-chart-value-axis", never, { "allowDecimals": { "alias": "allowDecimals"; "required": false; }; "axisDivisionFactor": { "alias": "axisDivisionFactor"; "required": false; }; "categories": { "alias": "categories"; "required": false; }; "color": { "alias": "color"; "required": false; }; "constantLines": { "alias": "constantLines"; "required": false; }; "constantLineStyle": { "alias": "constantLineStyle"; "required": false; }; "discreteAxisDivisionMode": { "alias": "discreteAxisDivisionMode"; "required": false; }; "endOnTick": { "alias": "endOnTick"; "required": false; }; "grid": { "alias": "grid"; "required": false; }; "inverted": { "alias": "inverted"; "required": false; }; "label": { "alias": "label"; "required": false; }; "linearThreshold": { "alias": "linearThreshold"; "required": false; }; "logarithmBase": { "alias": "logarithmBase"; "required": false; }; "maxValueMargin": { "alias": "maxValueMargin"; "required": false; }; "minorGrid": { "alias": "minorGrid"; "required": false; }; "minorTick": { "alias": "minorTick"; "required": false; }; "minorTickCount": { "alias": "minorTickCount"; "required": false; }; "minorTickInterval": { "alias": "minorTickInterval"; "required": false; }; "minValueMargin": { "alias": "minValueMargin"; "required": false; }; "minVisualRangeLength": { "alias": "minVisualRangeLength"; "required": false; }; "opacity": { "alias": "opacity"; "required": false; }; "showZero": { "alias": "showZero"; "required": false; }; "strips": { "alias": "strips"; "required": false; }; "stripStyle": { "alias": "stripStyle"; "required": false; }; "tick": { "alias": "tick"; "required": false; }; "tickInterval": { "alias": "tickInterval"; "required": false; }; "type": { "alias": "type"; "required": false; }; "valueMarginsEnabled": { "alias": "valueMarginsEnabled"; "required": false; }; "valueType": { "alias": "valueType"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "visualRange": { "alias": "visualRange"; "required": false; }; "visualRangeUpdateMode": { "alias": "visualRangeUpdateMode"; "required": false; }; "wholeRange": { "alias": "wholeRange"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, { "visualRangeChange": "visualRangeChange"; }, ["_constantLinesContentChildren", "_stripsContentChildren"], never, true, never>;
}
declare class DxoPolarChartValueAxisModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPolarChartValueAxisModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoPolarChartValueAxisModule, never, [typeof DxoPolarChartValueAxisComponent], [typeof DxoPolarChartValueAxisComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoPolarChartValueAxisModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoPolarChartValueErrorBarComponent extends NestedOption implements OnDestroy, OnInit {
    get color(): string;
    set color(value: string);
    get displayMode(): ValueErrorBarDisplayMode;
    set displayMode(value: ValueErrorBarDisplayMode);
    get edgeLength(): number;
    set edgeLength(value: number);
    get highValueField(): string | undefined;
    set highValueField(value: string | undefined);
    get lineWidth(): number;
    set lineWidth(value: number);
    get lowValueField(): string | undefined;
    set lowValueField(value: string | undefined);
    get opacity(): number | undefined;
    set opacity(value: number | undefined);
    get type(): undefined | ValueErrorBarType;
    set type(value: undefined | ValueErrorBarType);
    get value(): number;
    set value(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPolarChartValueErrorBarComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoPolarChartValueErrorBarComponent, "dxo-polar-chart-value-error-bar", never, { "color": { "alias": "color"; "required": false; }; "displayMode": { "alias": "displayMode"; "required": false; }; "edgeLength": { "alias": "edgeLength"; "required": false; }; "highValueField": { "alias": "highValueField"; "required": false; }; "lineWidth": { "alias": "lineWidth"; "required": false; }; "lowValueField": { "alias": "lowValueField"; "required": false; }; "opacity": { "alias": "opacity"; "required": false; }; "type": { "alias": "type"; "required": false; }; "value": { "alias": "value"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoPolarChartValueErrorBarModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPolarChartValueErrorBarModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoPolarChartValueErrorBarModule, never, [typeof DxoPolarChartValueErrorBarComponent], [typeof DxoPolarChartValueErrorBarComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoPolarChartValueErrorBarModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoPolarChartVisualRangeComponent extends NestedOption implements OnDestroy, OnInit {
    get endValue(): Date | number | string | undefined;
    set endValue(value: Date | number | string | undefined);
    get length(): number | TimeInterval | undefined | {
        days?: number;
        hours?: number;
        milliseconds?: number;
        minutes?: number;
        months?: number;
        quarters?: number;
        seconds?: number;
        weeks?: number;
        years?: number;
    };
    set length(value: number | TimeInterval | undefined | {
        days?: number;
        hours?: number;
        milliseconds?: number;
        minutes?: number;
        months?: number;
        quarters?: number;
        seconds?: number;
        weeks?: number;
        years?: number;
    });
    get startValue(): Date | number | string | undefined;
    set startValue(value: Date | number | string | undefined);
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    endValueChange: EventEmitter<Date | number | string | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    startValueChange: EventEmitter<Date | number | string | undefined>;
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPolarChartVisualRangeComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoPolarChartVisualRangeComponent, "dxo-polar-chart-visual-range", never, { "endValue": { "alias": "endValue"; "required": false; }; "length": { "alias": "length"; "required": false; }; "startValue": { "alias": "startValue"; "required": false; }; }, { "endValueChange": "endValueChange"; "startValueChange": "startValueChange"; }, never, never, true, never>;
}
declare class DxoPolarChartVisualRangeModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPolarChartVisualRangeModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoPolarChartVisualRangeModule, never, [typeof DxoPolarChartVisualRangeComponent], [typeof DxoPolarChartVisualRangeComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoPolarChartVisualRangeModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoPolarChartWholeRangeComponent extends NestedOption implements OnDestroy, OnInit {
    get endValue(): Date | number | string | undefined;
    set endValue(value: Date | number | string | undefined);
    get length(): number | TimeInterval | undefined | {
        days?: number;
        hours?: number;
        milliseconds?: number;
        minutes?: number;
        months?: number;
        quarters?: number;
        seconds?: number;
        weeks?: number;
        years?: number;
    };
    set length(value: number | TimeInterval | undefined | {
        days?: number;
        hours?: number;
        milliseconds?: number;
        minutes?: number;
        months?: number;
        quarters?: number;
        seconds?: number;
        weeks?: number;
        years?: number;
    });
    get startValue(): Date | number | string | undefined;
    set startValue(value: Date | number | string | undefined);
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    endValueChange: EventEmitter<Date | number | string | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    startValueChange: EventEmitter<Date | number | string | undefined>;
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPolarChartWholeRangeComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoPolarChartWholeRangeComponent, "dxo-polar-chart-whole-range", never, { "endValue": { "alias": "endValue"; "required": false; }; "length": { "alias": "length"; "required": false; }; "startValue": { "alias": "startValue"; "required": false; }; }, { "endValueChange": "endValueChange"; "startValueChange": "startValueChange"; }, never, never, true, never>;
}
declare class DxoPolarChartWholeRangeModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoPolarChartWholeRangeModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoPolarChartWholeRangeModule, never, [typeof DxoPolarChartWholeRangeComponent], [typeof DxoPolarChartWholeRangeComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoPolarChartWholeRangeModule>;
}

export { DxiPolarChartAnnotationComponent, DxiPolarChartAnnotationModule, DxiPolarChartConstantLineComponent, DxiPolarChartConstantLineModule, DxiPolarChartSeriesComponent, DxiPolarChartSeriesModule, DxiPolarChartStripComponent, DxiPolarChartStripModule, DxoPolarChartAdaptiveLayoutComponent, DxoPolarChartAdaptiveLayoutModule, DxoPolarChartAnimationComponent, DxoPolarChartAnimationModule, DxoPolarChartAnnotationBorderComponent, DxoPolarChartAnnotationBorderModule, DxoPolarChartArgumentAxisComponent, DxoPolarChartArgumentAxisMinorTickComponent, DxoPolarChartArgumentAxisMinorTickModule, DxoPolarChartArgumentAxisModule, DxoPolarChartArgumentAxisTickComponent, DxoPolarChartArgumentAxisTickModule, DxoPolarChartArgumentFormatComponent, DxoPolarChartArgumentFormatModule, DxoPolarChartAxisLabelComponent, DxoPolarChartAxisLabelModule, DxoPolarChartBorderComponent, DxoPolarChartBorderModule, DxoPolarChartColorComponent, DxoPolarChartColorModule, DxoPolarChartCommonAnnotationSettingsComponent, DxoPolarChartCommonAnnotationSettingsModule, DxoPolarChartCommonAxisSettingsComponent, DxoPolarChartCommonAxisSettingsLabelComponent, DxoPolarChartCommonAxisSettingsLabelModule, DxoPolarChartCommonAxisSettingsMinorTickComponent, DxoPolarChartCommonAxisSettingsMinorTickModule, DxoPolarChartCommonAxisSettingsModule, DxoPolarChartCommonAxisSettingsTickComponent, DxoPolarChartCommonAxisSettingsTickModule, DxoPolarChartCommonSeriesSettingsComponent, DxoPolarChartCommonSeriesSettingsHoverStyleComponent, DxoPolarChartCommonSeriesSettingsHoverStyleModule, DxoPolarChartCommonSeriesSettingsLabelComponent, DxoPolarChartCommonSeriesSettingsLabelModule, DxoPolarChartCommonSeriesSettingsModule, DxoPolarChartCommonSeriesSettingsSelectionStyleComponent, DxoPolarChartCommonSeriesSettingsSelectionStyleModule, DxoPolarChartConnectorComponent, DxoPolarChartConnectorModule, DxoPolarChartConstantLineLabelComponent, DxoPolarChartConstantLineLabelModule, DxoPolarChartConstantLineStyleComponent, DxoPolarChartConstantLineStyleLabelComponent, DxoPolarChartConstantLineStyleLabelModule, DxoPolarChartConstantLineStyleModule, DxoPolarChartDataPrepareSettingsComponent, DxoPolarChartDataPrepareSettingsModule, DxoPolarChartExportComponent, DxoPolarChartExportModule, DxoPolarChartFontComponent, DxoPolarChartFontModule, DxoPolarChartFormatComponent, DxoPolarChartFormatModule, DxoPolarChartGridComponent, DxoPolarChartGridModule, DxoPolarChartHatchingComponent, DxoPolarChartHatchingModule, DxoPolarChartHoverStyleComponent, DxoPolarChartHoverStyleModule, DxoPolarChartImageComponent, DxoPolarChartImageModule, DxoPolarChartLabelComponent, DxoPolarChartLabelModule, DxoPolarChartLegendComponent, DxoPolarChartLegendModule, DxoPolarChartLegendTitleComponent, DxoPolarChartLegendTitleModule, DxoPolarChartLegendTitleSubtitleComponent, DxoPolarChartLegendTitleSubtitleModule, DxoPolarChartLengthComponent, DxoPolarChartLengthModule, DxoPolarChartLoadingIndicatorComponent, DxoPolarChartLoadingIndicatorModule, DxoPolarChartMarginComponent, DxoPolarChartMarginModule, DxoPolarChartMinVisualRangeLengthComponent, DxoPolarChartMinVisualRangeLengthModule, DxoPolarChartMinorGridComponent, DxoPolarChartMinorGridModule, DxoPolarChartMinorTickComponent, DxoPolarChartMinorTickIntervalComponent, DxoPolarChartMinorTickIntervalModule, DxoPolarChartMinorTickModule, DxoPolarChartPointBorderComponent, DxoPolarChartPointBorderModule, DxoPolarChartPointComponent, DxoPolarChartPointHoverStyleComponent, DxoPolarChartPointHoverStyleModule, DxoPolarChartPointModule, DxoPolarChartPointSelectionStyleComponent, DxoPolarChartPointSelectionStyleModule, DxoPolarChartPolarChartTitleComponent, DxoPolarChartPolarChartTitleModule, DxoPolarChartPolarChartTitleSubtitleComponent, DxoPolarChartPolarChartTitleSubtitleModule, DxoPolarChartSelectionStyleComponent, DxoPolarChartSelectionStyleModule, DxoPolarChartSeriesBorderComponent, DxoPolarChartSeriesBorderModule, DxoPolarChartSeriesTemplateComponent, DxoPolarChartSeriesTemplateModule, DxoPolarChartShadowComponent, DxoPolarChartShadowModule, DxoPolarChartSizeComponent, DxoPolarChartSizeModule, DxoPolarChartStripLabelComponent, DxoPolarChartStripLabelModule, DxoPolarChartStripStyleComponent, DxoPolarChartStripStyleLabelComponent, DxoPolarChartStripStyleLabelModule, DxoPolarChartStripStyleModule, DxoPolarChartSubtitleComponent, DxoPolarChartSubtitleModule, DxoPolarChartTickComponent, DxoPolarChartTickIntervalComponent, DxoPolarChartTickIntervalModule, DxoPolarChartTickModule, DxoPolarChartTitleComponent, DxoPolarChartTitleModule, DxoPolarChartTooltipBorderComponent, DxoPolarChartTooltipBorderModule, DxoPolarChartTooltipComponent, DxoPolarChartTooltipModule, DxoPolarChartValueAxisComponent, DxoPolarChartValueAxisModule, DxoPolarChartValueErrorBarComponent, DxoPolarChartValueErrorBarModule, DxoPolarChartVisualRangeComponent, DxoPolarChartVisualRangeModule, DxoPolarChartWholeRangeComponent, DxoPolarChartWholeRangeModule };
//# sourceMappingURL=index.d.ts.map
