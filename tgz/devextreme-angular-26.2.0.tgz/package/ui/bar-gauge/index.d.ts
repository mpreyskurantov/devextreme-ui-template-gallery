import * as i0 from '@angular/core';
import { OnDestroy, OnChanges, DoCheck, EventEmitter, ElementRef, NgZone, TransferState, SimpleChanges } from '@angular/core';
import { AnimationEaseMode, Font, DashStyle, Palette, PaletteExtensionMode, ShiftLabelOverlap, Theme, TextOverflow, WordWrap } from 'devextreme/common/charts';
import { ExportFormat, HorizontalAlignment, Position, Orientation, VerticalEdge } from 'devextreme/common';
import { Format } from 'devextreme/common/core/localization';
import DxBarGauge, { BarGaugeBarInfo, BarGaugeLegendItem, DisposingEvent, DrawnEvent, ExportedEvent, ExportingEvent, FileSavingEvent, IncidentOccurredEvent, InitializedEvent, OptionChangedEvent, TooltipHiddenEvent, TooltipShownEvent } from 'devextreme/viz/bar_gauge';
import * as i3 from 'devextreme-angular/core';
import { DxComponent, DxTemplateHost, WatcherHelper, IterableDifferHelper, NestedOptionHost } from 'devextreme-angular/core';
import * as i1 from 'devextreme-angular/ui/nested';
import * as i2 from 'devextreme-angular/ui/bar-gauge/nested';
export * from 'devextreme-angular/ui/bar-gauge/nested';
import * as bar_gauge_types from 'devextreme/viz/bar_gauge_types';
export { bar_gauge_types as DxBarGaugeTypes };

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

/**
 * [descr:dxBarGauge]

 */
declare class DxBarGaugeComponent extends DxComponent implements OnDestroy, OnChanges, DoCheck {
    private _watcherHelper;
    private _idh;
    instance: DxBarGauge;
    /**
     * [descr:dxBarGaugeOptions.animation]
    
     */
    get animation(): any | {
        duration?: number;
        easing?: AnimationEaseMode;
        enabled?: boolean;
    };
    set animation(value: any | {
        duration?: number;
        easing?: AnimationEaseMode;
        enabled?: boolean;
    });
    /**
     * [descr:dxBarGaugeOptions.backgroundColor]
    
     */
    get backgroundColor(): string;
    set backgroundColor(value: string);
    /**
     * [descr:dxBarGaugeOptions.barSpacing]
    
     */
    get barSpacing(): number;
    set barSpacing(value: number);
    /**
     * [descr:dxBarGaugeOptions.baseValue]
    
     */
    get baseValue(): number;
    set baseValue(value: number);
    /**
     * [descr:dxBarGaugeOptions.centerTemplate]
    
     */
    get centerTemplate(): any;
    set centerTemplate(value: any);
    /**
     * [descr:BaseWidgetOptions.disabled]
    
     */
    get disabled(): boolean;
    set disabled(value: boolean);
    /**
     * [descr:DOMComponentOptions.elementAttr]
    
     */
    get elementAttr(): Record<string, any>;
    set elementAttr(value: Record<string, any>);
    /**
     * [descr:BaseWidgetOptions.encodeHtml]
    
     */
    get encodeHtml(): boolean;
    set encodeHtml(value: boolean);
    /**
     * [descr:dxBarGaugeOptions.endValue]
    
     */
    get endValue(): number;
    set endValue(value: number);
    /**
     * [descr:BaseWidgetOptions.export]
    
     */
    get export(): {
        backgroundColor?: string;
        enabled?: boolean;
        fileName?: string;
        formats?: Array<ExportFormat>;
        margin?: number;
        printingEnabled?: boolean;
        svgToCanvas?: ((svg: any, canvas: any) => any) | undefined;
    };
    set export(value: {
        backgroundColor?: string;
        enabled?: boolean;
        fileName?: string;
        formats?: Array<ExportFormat>;
        margin?: number;
        printingEnabled?: boolean;
        svgToCanvas?: ((svg: any, canvas: any) => any) | undefined;
    });
    /**
     * [descr:dxBarGaugeOptions.geometry]
    
     */
    get geometry(): {
        endAngle?: number;
        startAngle?: number;
    };
    set geometry(value: {
        endAngle?: number;
        startAngle?: number;
    });
    /**
     * [descr:dxBarGaugeOptions.label]
    
     */
    get label(): {
        connectorColor?: string | undefined;
        connectorWidth?: number;
        customizeText?: ((barValue: {
            value: number;
            valueText: string;
        }) => string);
        font?: Font;
        format?: Format | undefined;
        indent?: number;
        visible?: boolean;
    };
    set label(value: {
        connectorColor?: string | undefined;
        connectorWidth?: number;
        customizeText?: ((barValue: {
            value: number;
            valueText: string;
        }) => string);
        font?: Font;
        format?: Format | undefined;
        indent?: number;
        visible?: boolean;
    });
    /**
     * [descr:dxBarGaugeOptions.legend]
    
     */
    get legend(): {
        backgroundColor?: string | undefined;
        border?: {
            color?: string;
            cornerRadius?: number;
            dashStyle?: DashStyle;
            opacity?: number | undefined;
            visible?: boolean;
            width?: number;
        };
        columnCount?: number;
        columnItemSpacing?: number;
        customizeHint?: ((arg: {
            item: BarGaugeBarInfo;
            text: string;
        }) => string);
        customizeItems?: ((items: Array<BarGaugeLegendItem>) => Array<BarGaugeLegendItem>);
        customizeText?: ((arg: {
            item: BarGaugeBarInfo;
            text: string;
        }) => string);
        font?: Font;
        horizontalAlignment?: HorizontalAlignment;
        itemsAlignment?: HorizontalAlignment | undefined;
        itemTextFormat?: Format | undefined;
        itemTextPosition?: Position | undefined;
        margin?: number | {
            bottom?: number;
            left?: number;
            right?: number;
            top?: number;
        };
        markerSize?: number;
        markerTemplate?: any;
        orientation?: Orientation | undefined;
        paddingLeftRight?: number;
        paddingTopBottom?: number;
        rowCount?: number;
        rowItemSpacing?: number;
        title?: string | {
            font?: Font;
            horizontalAlignment?: HorizontalAlignment | undefined;
            margin?: {
                bottom?: number;
                left?: number;
                right?: number;
                top?: number;
            };
            placeholderSize?: number | undefined;
            subtitle?: string | {
                font?: Font;
                offset?: number;
                text?: string | undefined;
            };
            text?: string | undefined;
            verticalAlignment?: VerticalEdge;
        };
        verticalAlignment?: VerticalEdge;
        visible?: boolean;
    };
    set legend(value: {
        backgroundColor?: string | undefined;
        border?: {
            color?: string;
            cornerRadius?: number;
            dashStyle?: DashStyle;
            opacity?: number | undefined;
            visible?: boolean;
            width?: number;
        };
        columnCount?: number;
        columnItemSpacing?: number;
        customizeHint?: ((arg: {
            item: BarGaugeBarInfo;
            text: string;
        }) => string);
        customizeItems?: ((items: Array<BarGaugeLegendItem>) => Array<BarGaugeLegendItem>);
        customizeText?: ((arg: {
            item: BarGaugeBarInfo;
            text: string;
        }) => string);
        font?: Font;
        horizontalAlignment?: HorizontalAlignment;
        itemsAlignment?: HorizontalAlignment | undefined;
        itemTextFormat?: Format | undefined;
        itemTextPosition?: Position | undefined;
        margin?: number | {
            bottom?: number;
            left?: number;
            right?: number;
            top?: number;
        };
        markerSize?: number;
        markerTemplate?: any;
        orientation?: Orientation | undefined;
        paddingLeftRight?: number;
        paddingTopBottom?: number;
        rowCount?: number;
        rowItemSpacing?: number;
        title?: string | {
            font?: Font;
            horizontalAlignment?: HorizontalAlignment | undefined;
            margin?: {
                bottom?: number;
                left?: number;
                right?: number;
                top?: number;
            };
            placeholderSize?: number | undefined;
            subtitle?: string | {
                font?: Font;
                offset?: number;
                text?: string | undefined;
            };
            text?: string | undefined;
            verticalAlignment?: VerticalEdge;
        };
        verticalAlignment?: VerticalEdge;
        visible?: boolean;
    });
    /**
     * [descr:dxBarGaugeOptions.loadingIndicator]
    
     */
    get loadingIndicator(): {
        backgroundColor?: string;
        font?: Font;
        show?: boolean;
        text?: string;
    };
    set loadingIndicator(value: {
        backgroundColor?: string;
        font?: Font;
        show?: boolean;
        text?: string;
    });
    /**
     * [descr:BaseWidgetOptions.margin]
    
     */
    get margin(): {
        bottom?: number;
        left?: number;
        right?: number;
        top?: number;
    };
    set margin(value: {
        bottom?: number;
        left?: number;
        right?: number;
        top?: number;
    });
    /**
     * [descr:dxBarGaugeOptions.palette]
    
     */
    get palette(): Array<string> | Palette;
    set palette(value: Array<string> | Palette);
    /**
     * [descr:dxBarGaugeOptions.paletteExtensionMode]
    
     */
    get paletteExtensionMode(): PaletteExtensionMode;
    set paletteExtensionMode(value: PaletteExtensionMode);
    /**
     * [descr:BaseWidgetOptions.pathModified]
    
     */
    get pathModified(): boolean;
    set pathModified(value: boolean);
    /**
     * [descr:BaseWidgetOptions.redrawOnResize]
    
     */
    get redrawOnResize(): boolean;
    set redrawOnResize(value: boolean);
    /**
     * [descr:dxBarGaugeOptions.relativeInnerRadius]
    
     */
    get relativeInnerRadius(): number;
    set relativeInnerRadius(value: number);
    /**
     * [descr:dxBarGaugeOptions.resolveLabelOverlapping]
    
     */
    get resolveLabelOverlapping(): ShiftLabelOverlap;
    set resolveLabelOverlapping(value: ShiftLabelOverlap);
    /**
     * [descr:BaseWidgetOptions.rtlEnabled]
    
     */
    get rtlEnabled(): boolean;
    set rtlEnabled(value: boolean);
    /**
     * [descr:BaseWidgetOptions.size]
    
     */
    get size(): {
        height?: number | undefined;
        width?: number | undefined;
    };
    set size(value: {
        height?: number | undefined;
        width?: number | undefined;
    });
    /**
     * [descr:dxBarGaugeOptions.startValue]
    
     */
    get startValue(): number;
    set startValue(value: number);
    /**
     * [descr:BaseWidgetOptions.theme]
    
     */
    get theme(): Theme;
    set theme(value: Theme);
    /**
     * [descr:BaseWidgetOptions.title]
    
     */
    get title(): string | {
        font?: Font;
        horizontalAlignment?: HorizontalAlignment;
        margin?: number | {
            bottom?: number;
            left?: number;
            right?: number;
            top?: number;
        };
        placeholderSize?: number | undefined;
        subtitle?: string | {
            font?: Font;
            offset?: number;
            text?: string | undefined;
            textOverflow?: TextOverflow;
            wordWrap?: WordWrap;
        };
        text?: string | undefined;
        textOverflow?: TextOverflow;
        verticalAlignment?: VerticalEdge;
        wordWrap?: WordWrap;
    };
    set title(value: string | {
        font?: Font;
        horizontalAlignment?: HorizontalAlignment;
        margin?: number | {
            bottom?: number;
            left?: number;
            right?: number;
            top?: number;
        };
        placeholderSize?: number | undefined;
        subtitle?: string | {
            font?: Font;
            offset?: number;
            text?: string | undefined;
            textOverflow?: TextOverflow;
            wordWrap?: WordWrap;
        };
        text?: string | undefined;
        textOverflow?: TextOverflow;
        verticalAlignment?: VerticalEdge;
        wordWrap?: WordWrap;
    });
    /**
     * [descr:dxBarGaugeOptions.tooltip]
    
     */
    get tooltip(): {
        arrowLength?: number;
        border?: {
            color?: string;
            dashStyle?: DashStyle;
            opacity?: number | undefined;
            visible?: boolean;
            width?: number;
        };
        color?: string;
        container?: any | string | undefined;
        contentTemplate?: any;
        cornerRadius?: number;
        customizeTooltip?: ((scaleValue: {
            index: number;
            value: number;
            valueText: string;
        }) => Record<string, any>) | undefined;
        enabled?: boolean;
        font?: Font;
        format?: Format | undefined;
        interactive?: boolean;
        opacity?: number | undefined;
        paddingLeftRight?: number;
        paddingTopBottom?: number;
        shadow?: {
            blur?: number;
            color?: string;
            offsetX?: number;
            offsetY?: number;
            opacity?: number;
        };
        zIndex?: number | undefined;
    };
    set tooltip(value: {
        arrowLength?: number;
        border?: {
            color?: string;
            dashStyle?: DashStyle;
            opacity?: number | undefined;
            visible?: boolean;
            width?: number;
        };
        color?: string;
        container?: any | string | undefined;
        contentTemplate?: any;
        cornerRadius?: number;
        customizeTooltip?: ((scaleValue: {
            index: number;
            value: number;
            valueText: string;
        }) => Record<string, any>) | undefined;
        enabled?: boolean;
        font?: Font;
        format?: Format | undefined;
        interactive?: boolean;
        opacity?: number | undefined;
        paddingLeftRight?: number;
        paddingTopBottom?: number;
        shadow?: {
            blur?: number;
            color?: string;
            offsetX?: number;
            offsetY?: number;
            opacity?: number;
        };
        zIndex?: number | undefined;
    });
    /**
     * [descr:dxBarGaugeOptions.values]
    
     */
    get values(): Array<number>;
    set values(value: Array<number>);
    /**
    
     * [descr:dxBarGaugeOptions.onDisposing]
    
    
     */
    onDisposing: EventEmitter<DisposingEvent>;
    /**
    
     * [descr:dxBarGaugeOptions.onDrawn]
    
    
     */
    onDrawn: EventEmitter<DrawnEvent>;
    /**
    
     * [descr:dxBarGaugeOptions.onExported]
    
    
     */
    onExported: EventEmitter<ExportedEvent>;
    /**
    
     * [descr:dxBarGaugeOptions.onExporting]
    
    
     */
    onExporting: EventEmitter<ExportingEvent>;
    /**
    
     * [descr:dxBarGaugeOptions.onFileSaving]
    
    
     */
    onFileSaving: EventEmitter<FileSavingEvent>;
    /**
    
     * [descr:dxBarGaugeOptions.onIncidentOccurred]
    
    
     */
    onIncidentOccurred: EventEmitter<IncidentOccurredEvent>;
    /**
    
     * [descr:dxBarGaugeOptions.onInitialized]
    
    
     */
    onInitialized: EventEmitter<InitializedEvent>;
    /**
    
     * [descr:dxBarGaugeOptions.onOptionChanged]
    
    
     */
    onOptionChanged: EventEmitter<OptionChangedEvent>;
    /**
    
     * [descr:dxBarGaugeOptions.onTooltipHidden]
    
    
     */
    onTooltipHidden: EventEmitter<TooltipHiddenEvent>;
    /**
    
     * [descr:dxBarGaugeOptions.onTooltipShown]
    
    
     */
    onTooltipShown: EventEmitter<TooltipShownEvent>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    animationChange: EventEmitter<any | {
        duration?: number;
        easing?: AnimationEaseMode;
        enabled?: boolean;
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    backgroundColorChange: EventEmitter<string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    barSpacingChange: EventEmitter<number>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    baseValueChange: EventEmitter<number>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    centerTemplateChange: EventEmitter<any>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    disabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    elementAttrChange: EventEmitter<Record<string, any>>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    encodeHtmlChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    endValueChange: EventEmitter<number>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    exportChange: EventEmitter<{
        backgroundColor?: string;
        enabled?: boolean;
        fileName?: string;
        formats?: Array<ExportFormat>;
        margin?: number;
        printingEnabled?: boolean;
        svgToCanvas?: ((svg: any, canvas: any) => any) | undefined;
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    geometryChange: EventEmitter<{
        endAngle?: number;
        startAngle?: number;
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    labelChange: EventEmitter<{
        connectorColor?: string | undefined;
        connectorWidth?: number;
        customizeText?: ((barValue: {
            value: number;
            valueText: string;
        }) => string);
        font?: Font;
        format?: Format | undefined;
        indent?: number;
        visible?: boolean;
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    legendChange: EventEmitter<{
        backgroundColor?: string | undefined;
        border?: {
            color?: string;
            cornerRadius?: number;
            dashStyle?: DashStyle;
            opacity?: number | undefined;
            visible?: boolean;
            width?: number;
        };
        columnCount?: number;
        columnItemSpacing?: number;
        customizeHint?: ((arg: {
            item: BarGaugeBarInfo;
            text: string;
        }) => string);
        customizeItems?: ((items: Array<BarGaugeLegendItem>) => Array<BarGaugeLegendItem>);
        customizeText?: ((arg: {
            item: BarGaugeBarInfo;
            text: string;
        }) => string);
        font?: Font;
        horizontalAlignment?: HorizontalAlignment;
        itemsAlignment?: HorizontalAlignment | undefined;
        itemTextFormat?: Format | undefined;
        itemTextPosition?: Position | undefined;
        margin?: number | {
            bottom?: number;
            left?: number;
            right?: number;
            top?: number;
        };
        markerSize?: number;
        markerTemplate?: any;
        orientation?: Orientation | undefined;
        paddingLeftRight?: number;
        paddingTopBottom?: number;
        rowCount?: number;
        rowItemSpacing?: number;
        title?: string | {
            font?: Font;
            horizontalAlignment?: HorizontalAlignment | undefined;
            margin?: {
                bottom?: number;
                left?: number;
                right?: number;
                top?: number;
            };
            placeholderSize?: number | undefined;
            subtitle?: string | {
                font?: Font;
                offset?: number;
                text?: string | undefined;
            };
            text?: string | undefined;
            verticalAlignment?: VerticalEdge;
        };
        verticalAlignment?: VerticalEdge;
        visible?: boolean;
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    loadingIndicatorChange: EventEmitter<{
        backgroundColor?: string;
        font?: Font;
        show?: boolean;
        text?: string;
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    marginChange: EventEmitter<{
        bottom?: number;
        left?: number;
        right?: number;
        top?: number;
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    paletteChange: EventEmitter<Array<string> | Palette>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    paletteExtensionModeChange: EventEmitter<PaletteExtensionMode>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    pathModifiedChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    redrawOnResizeChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    relativeInnerRadiusChange: EventEmitter<number>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    resolveLabelOverlappingChange: EventEmitter<ShiftLabelOverlap>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    rtlEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    sizeChange: EventEmitter<{
        height?: number | undefined;
        width?: number | undefined;
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    startValueChange: EventEmitter<number>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    themeChange: EventEmitter<Theme>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    titleChange: EventEmitter<string | {
        font?: Font;
        horizontalAlignment?: HorizontalAlignment;
        margin?: number | {
            bottom?: number;
            left?: number;
            right?: number;
            top?: number;
        };
        placeholderSize?: number | undefined;
        subtitle?: string | {
            font?: Font;
            offset?: number;
            text?: string | undefined;
            textOverflow?: TextOverflow;
            wordWrap?: WordWrap;
        };
        text?: string | undefined;
        textOverflow?: TextOverflow;
        verticalAlignment?: VerticalEdge;
        wordWrap?: WordWrap;
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    tooltipChange: EventEmitter<{
        arrowLength?: number;
        border?: {
            color?: string;
            dashStyle?: DashStyle;
            opacity?: number | undefined;
            visible?: boolean;
            width?: number;
        };
        color?: string;
        container?: any | string | undefined;
        contentTemplate?: any;
        cornerRadius?: number;
        customizeTooltip?: ((scaleValue: {
            index: number;
            value: number;
            valueText: string;
        }) => Record<string, any>) | undefined;
        enabled?: boolean;
        font?: Font;
        format?: Format | undefined;
        interactive?: boolean;
        opacity?: number | undefined;
        paddingLeftRight?: number;
        paddingTopBottom?: number;
        shadow?: {
            blur?: number;
            color?: string;
            offsetX?: number;
            offsetY?: number;
            opacity?: number;
        };
        zIndex?: number | undefined;
    }>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    valuesChange: EventEmitter<Array<number>>;
    constructor(elementRef: ElementRef, ngZone: NgZone, templateHost: DxTemplateHost, _watcherHelper: WatcherHelper, _idh: IterableDifferHelper, optionHost: NestedOptionHost, transferState: TransferState, platformId: any);
    protected _createInstance(element: any, options: any): DxBarGauge;
    ngOnDestroy(): void;
    ngOnChanges(changes: SimpleChanges): void;
    setupChanges(prop: string, changes: SimpleChanges): void;
    ngDoCheck(): void;
    _setOption(name: string, value: any): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxBarGaugeComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxBarGaugeComponent, "dx-bar-gauge", never, { "animation": { "alias": "animation"; "required": false; }; "backgroundColor": { "alias": "backgroundColor"; "required": false; }; "barSpacing": { "alias": "barSpacing"; "required": false; }; "baseValue": { "alias": "baseValue"; "required": false; }; "centerTemplate": { "alias": "centerTemplate"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "elementAttr": { "alias": "elementAttr"; "required": false; }; "encodeHtml": { "alias": "encodeHtml"; "required": false; }; "endValue": { "alias": "endValue"; "required": false; }; "export": { "alias": "export"; "required": false; }; "geometry": { "alias": "geometry"; "required": false; }; "label": { "alias": "label"; "required": false; }; "legend": { "alias": "legend"; "required": false; }; "loadingIndicator": { "alias": "loadingIndicator"; "required": false; }; "margin": { "alias": "margin"; "required": false; }; "palette": { "alias": "palette"; "required": false; }; "paletteExtensionMode": { "alias": "paletteExtensionMode"; "required": false; }; "pathModified": { "alias": "pathModified"; "required": false; }; "redrawOnResize": { "alias": "redrawOnResize"; "required": false; }; "relativeInnerRadius": { "alias": "relativeInnerRadius"; "required": false; }; "resolveLabelOverlapping": { "alias": "resolveLabelOverlapping"; "required": false; }; "rtlEnabled": { "alias": "rtlEnabled"; "required": false; }; "size": { "alias": "size"; "required": false; }; "startValue": { "alias": "startValue"; "required": false; }; "theme": { "alias": "theme"; "required": false; }; "title": { "alias": "title"; "required": false; }; "tooltip": { "alias": "tooltip"; "required": false; }; "values": { "alias": "values"; "required": false; }; }, { "onDisposing": "onDisposing"; "onDrawn": "onDrawn"; "onExported": "onExported"; "onExporting": "onExporting"; "onFileSaving": "onFileSaving"; "onIncidentOccurred": "onIncidentOccurred"; "onInitialized": "onInitialized"; "onOptionChanged": "onOptionChanged"; "onTooltipHidden": "onTooltipHidden"; "onTooltipShown": "onTooltipShown"; "animationChange": "animationChange"; "backgroundColorChange": "backgroundColorChange"; "barSpacingChange": "barSpacingChange"; "baseValueChange": "baseValueChange"; "centerTemplateChange": "centerTemplateChange"; "disabledChange": "disabledChange"; "elementAttrChange": "elementAttrChange"; "encodeHtmlChange": "encodeHtmlChange"; "endValueChange": "endValueChange"; "exportChange": "exportChange"; "geometryChange": "geometryChange"; "labelChange": "labelChange"; "legendChange": "legendChange"; "loadingIndicatorChange": "loadingIndicatorChange"; "marginChange": "marginChange"; "paletteChange": "paletteChange"; "paletteExtensionModeChange": "paletteExtensionModeChange"; "pathModifiedChange": "pathModifiedChange"; "redrawOnResizeChange": "redrawOnResizeChange"; "relativeInnerRadiusChange": "relativeInnerRadiusChange"; "resolveLabelOverlappingChange": "resolveLabelOverlappingChange"; "rtlEnabledChange": "rtlEnabledChange"; "sizeChange": "sizeChange"; "startValueChange": "startValueChange"; "themeChange": "themeChange"; "titleChange": "titleChange"; "tooltipChange": "tooltipChange"; "valuesChange": "valuesChange"; }, never, never, true, never>;
}
declare class DxBarGaugeModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxBarGaugeModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxBarGaugeModule, never, [typeof DxBarGaugeComponent, typeof i1.DxoAnimationModule, typeof i1.DxoExportModule, typeof i1.DxoGeometryModule, typeof i1.DxoLabelModule, typeof i1.DxoFontModule, typeof i1.DxoFormatModule, typeof i1.DxoLegendModule, typeof i1.DxoBorderModule, typeof i1.DxoItemTextFormatModule, typeof i1.DxoMarginModule, typeof i1.DxoTitleModule, typeof i1.DxoSubtitleModule, typeof i1.DxoLoadingIndicatorModule, typeof i1.DxoSizeModule, typeof i1.DxoTooltipModule, typeof i1.DxoShadowModule, typeof i2.DxoBarGaugeAnimationModule, typeof i2.DxoBarGaugeBarGaugeTitleModule, typeof i2.DxoBarGaugeBarGaugeTitleSubtitleModule, typeof i2.DxoBarGaugeBorderModule, typeof i2.DxoBarGaugeExportModule, typeof i2.DxoBarGaugeFontModule, typeof i2.DxoBarGaugeFormatModule, typeof i2.DxoBarGaugeGeometryModule, typeof i2.DxoBarGaugeItemTextFormatModule, typeof i2.DxoBarGaugeLabelModule, typeof i2.DxoBarGaugeLegendModule, typeof i2.DxoBarGaugeLegendBorderModule, typeof i2.DxoBarGaugeLegendTitleModule, typeof i2.DxoBarGaugeLegendTitleSubtitleModule, typeof i2.DxoBarGaugeLoadingIndicatorModule, typeof i2.DxoBarGaugeMarginModule, typeof i2.DxoBarGaugeShadowModule, typeof i2.DxoBarGaugeSizeModule, typeof i2.DxoBarGaugeSubtitleModule, typeof i2.DxoBarGaugeTitleModule, typeof i2.DxoBarGaugeTooltipModule, typeof i2.DxoBarGaugeTooltipBorderModule, typeof i3.DxIntegrationModule, typeof i3.DxTemplateModule], [typeof DxBarGaugeComponent, typeof i1.DxoAnimationModule, typeof i1.DxoExportModule, typeof i1.DxoGeometryModule, typeof i1.DxoLabelModule, typeof i1.DxoFontModule, typeof i1.DxoFormatModule, typeof i1.DxoLegendModule, typeof i1.DxoBorderModule, typeof i1.DxoItemTextFormatModule, typeof i1.DxoMarginModule, typeof i1.DxoTitleModule, typeof i1.DxoSubtitleModule, typeof i1.DxoLoadingIndicatorModule, typeof i1.DxoSizeModule, typeof i1.DxoTooltipModule, typeof i1.DxoShadowModule, typeof i2.DxoBarGaugeAnimationModule, typeof i2.DxoBarGaugeBarGaugeTitleModule, typeof i2.DxoBarGaugeBarGaugeTitleSubtitleModule, typeof i2.DxoBarGaugeBorderModule, typeof i2.DxoBarGaugeExportModule, typeof i2.DxoBarGaugeFontModule, typeof i2.DxoBarGaugeFormatModule, typeof i2.DxoBarGaugeGeometryModule, typeof i2.DxoBarGaugeItemTextFormatModule, typeof i2.DxoBarGaugeLabelModule, typeof i2.DxoBarGaugeLegendModule, typeof i2.DxoBarGaugeLegendBorderModule, typeof i2.DxoBarGaugeLegendTitleModule, typeof i2.DxoBarGaugeLegendTitleSubtitleModule, typeof i2.DxoBarGaugeLoadingIndicatorModule, typeof i2.DxoBarGaugeMarginModule, typeof i2.DxoBarGaugeShadowModule, typeof i2.DxoBarGaugeSizeModule, typeof i2.DxoBarGaugeSubtitleModule, typeof i2.DxoBarGaugeTitleModule, typeof i2.DxoBarGaugeTooltipModule, typeof i2.DxoBarGaugeTooltipBorderModule, typeof i3.DxTemplateModule]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxBarGaugeModule>;
}

export { DxBarGaugeComponent, DxBarGaugeModule };
//# sourceMappingURL=index.d.ts.map
