import * as i0 from '@angular/core';
import { OnDestroy, OnInit, EventEmitter } from '@angular/core';
import { AnimationEaseMode, Font, TextOverflow, WordWrap, DashStyle } from 'devextreme/common/charts';
import { NestedOption, NestedOptionHost } from 'devextreme-angular/core';
import { HorizontalAlignment, VerticalEdge, ExportFormat, Format, Position, Orientation } from 'devextreme/common';
import { Format as Format$1 } from 'devextreme/common/core/localization';
import { BarGaugeBarInfo, BarGaugeLegendItem } from 'devextreme/viz/bar_gauge';

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoBarGaugeAnimationComponent extends NestedOption implements OnDestroy, OnInit {
    get duration(): number;
    set duration(value: number);
    get easing(): AnimationEaseMode;
    set easing(value: AnimationEaseMode);
    get enabled(): boolean;
    set enabled(value: boolean);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoBarGaugeAnimationComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoBarGaugeAnimationComponent, "dxo-bar-gauge-animation", never, { "duration": { "alias": "duration"; "required": false; }; "easing": { "alias": "easing"; "required": false; }; "enabled": { "alias": "enabled"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoBarGaugeAnimationModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoBarGaugeAnimationModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoBarGaugeAnimationModule, never, [typeof DxoBarGaugeAnimationComponent], [typeof DxoBarGaugeAnimationComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoBarGaugeAnimationModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoBarGaugeBarGaugeTitleSubtitleComponent extends NestedOption implements OnDestroy, OnInit {
    get font(): Font;
    set font(value: Font);
    get offset(): number;
    set offset(value: number);
    get text(): string | undefined;
    set text(value: string | undefined);
    get textOverflow(): TextOverflow;
    set textOverflow(value: TextOverflow);
    get wordWrap(): WordWrap;
    set wordWrap(value: WordWrap);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoBarGaugeBarGaugeTitleSubtitleComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoBarGaugeBarGaugeTitleSubtitleComponent, "dxo-bar-gauge-bar-gauge-title-subtitle", never, { "font": { "alias": "font"; "required": false; }; "offset": { "alias": "offset"; "required": false; }; "text": { "alias": "text"; "required": false; }; "textOverflow": { "alias": "textOverflow"; "required": false; }; "wordWrap": { "alias": "wordWrap"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoBarGaugeBarGaugeTitleSubtitleModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoBarGaugeBarGaugeTitleSubtitleModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoBarGaugeBarGaugeTitleSubtitleModule, never, [typeof DxoBarGaugeBarGaugeTitleSubtitleComponent], [typeof DxoBarGaugeBarGaugeTitleSubtitleComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoBarGaugeBarGaugeTitleSubtitleModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoBarGaugeBarGaugeTitleComponent extends NestedOption implements OnDestroy, OnInit {
    get font(): Font;
    set font(value: Font);
    get horizontalAlignment(): HorizontalAlignment;
    set horizontalAlignment(value: HorizontalAlignment);
    get margin(): number | {
        bottom?: number;
        left?: number;
        right?: number;
        top?: number;
    };
    set margin(value: number | {
        bottom?: number;
        left?: number;
        right?: number;
        top?: number;
    });
    get placeholderSize(): number | undefined;
    set placeholderSize(value: number | undefined);
    get subtitle(): string | {
        font?: Font;
        offset?: number;
        text?: string | undefined;
        textOverflow?: TextOverflow;
        wordWrap?: WordWrap;
    };
    set subtitle(value: string | {
        font?: Font;
        offset?: number;
        text?: string | undefined;
        textOverflow?: TextOverflow;
        wordWrap?: WordWrap;
    });
    get text(): string | undefined;
    set text(value: string | undefined);
    get textOverflow(): TextOverflow;
    set textOverflow(value: TextOverflow);
    get verticalAlignment(): VerticalEdge;
    set verticalAlignment(value: VerticalEdge);
    get wordWrap(): WordWrap;
    set wordWrap(value: WordWrap);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoBarGaugeBarGaugeTitleComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoBarGaugeBarGaugeTitleComponent, "dxo-bar-gauge-bar-gauge-title", never, { "font": { "alias": "font"; "required": false; }; "horizontalAlignment": { "alias": "horizontalAlignment"; "required": false; }; "margin": { "alias": "margin"; "required": false; }; "placeholderSize": { "alias": "placeholderSize"; "required": false; }; "subtitle": { "alias": "subtitle"; "required": false; }; "text": { "alias": "text"; "required": false; }; "textOverflow": { "alias": "textOverflow"; "required": false; }; "verticalAlignment": { "alias": "verticalAlignment"; "required": false; }; "wordWrap": { "alias": "wordWrap"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoBarGaugeBarGaugeTitleModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoBarGaugeBarGaugeTitleModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoBarGaugeBarGaugeTitleModule, never, [typeof DxoBarGaugeBarGaugeTitleComponent], [typeof DxoBarGaugeBarGaugeTitleComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoBarGaugeBarGaugeTitleModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoBarGaugeBorderComponent extends NestedOption implements OnDestroy, OnInit {
    get color(): string;
    set color(value: string);
    get cornerRadius(): number;
    set cornerRadius(value: number);
    get dashStyle(): DashStyle;
    set dashStyle(value: DashStyle);
    get opacity(): number | undefined;
    set opacity(value: number | undefined);
    get visible(): boolean;
    set visible(value: boolean);
    get width(): number;
    set width(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoBarGaugeBorderComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoBarGaugeBorderComponent, "dxo-bar-gauge-border", never, { "color": { "alias": "color"; "required": false; }; "cornerRadius": { "alias": "cornerRadius"; "required": false; }; "dashStyle": { "alias": "dashStyle"; "required": false; }; "opacity": { "alias": "opacity"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoBarGaugeBorderModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoBarGaugeBorderModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoBarGaugeBorderModule, never, [typeof DxoBarGaugeBorderComponent], [typeof DxoBarGaugeBorderComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoBarGaugeBorderModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoBarGaugeExportComponent extends NestedOption implements OnDestroy, OnInit {
    get backgroundColor(): string;
    set backgroundColor(value: string);
    get enabled(): boolean;
    set enabled(value: boolean);
    get fileName(): string;
    set fileName(value: string);
    get formats(): Array<ExportFormat>;
    set formats(value: Array<ExportFormat>);
    get margin(): number;
    set margin(value: number);
    get printingEnabled(): boolean;
    set printingEnabled(value: boolean);
    get svgToCanvas(): ((svg: any, canvas: any) => any) | undefined;
    set svgToCanvas(value: ((svg: any, canvas: any) => any) | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoBarGaugeExportComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoBarGaugeExportComponent, "dxo-bar-gauge-export", never, { "backgroundColor": { "alias": "backgroundColor"; "required": false; }; "enabled": { "alias": "enabled"; "required": false; }; "fileName": { "alias": "fileName"; "required": false; }; "formats": { "alias": "formats"; "required": false; }; "margin": { "alias": "margin"; "required": false; }; "printingEnabled": { "alias": "printingEnabled"; "required": false; }; "svgToCanvas": { "alias": "svgToCanvas"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoBarGaugeExportModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoBarGaugeExportModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoBarGaugeExportModule, never, [typeof DxoBarGaugeExportComponent], [typeof DxoBarGaugeExportComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoBarGaugeExportModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoBarGaugeFontComponent extends NestedOption implements OnDestroy, OnInit {
    get color(): string;
    set color(value: string);
    get family(): string;
    set family(value: string);
    get opacity(): number;
    set opacity(value: number);
    get size(): number | string;
    set size(value: number | string);
    get weight(): number;
    set weight(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoBarGaugeFontComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoBarGaugeFontComponent, "dxo-bar-gauge-font", never, { "color": { "alias": "color"; "required": false; }; "family": { "alias": "family"; "required": false; }; "opacity": { "alias": "opacity"; "required": false; }; "size": { "alias": "size"; "required": false; }; "weight": { "alias": "weight"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoBarGaugeFontModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoBarGaugeFontModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoBarGaugeFontModule, never, [typeof DxoBarGaugeFontComponent], [typeof DxoBarGaugeFontComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoBarGaugeFontModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoBarGaugeFormatComponent extends NestedOption implements OnDestroy, OnInit {
    get currency(): string;
    set currency(value: string);
    get formatter(): ((value: number | Date) => string);
    set formatter(value: ((value: number | Date) => string));
    get parser(): ((value: string) => number | Date);
    set parser(value: ((value: string) => number | Date));
    get precision(): number;
    set precision(value: number);
    get type(): Format | string;
    set type(value: Format | string);
    get useCurrencyAccountingStyle(): boolean;
    set useCurrencyAccountingStyle(value: boolean);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoBarGaugeFormatComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoBarGaugeFormatComponent, "dxo-bar-gauge-format", never, { "currency": { "alias": "currency"; "required": false; }; "formatter": { "alias": "formatter"; "required": false; }; "parser": { "alias": "parser"; "required": false; }; "precision": { "alias": "precision"; "required": false; }; "type": { "alias": "type"; "required": false; }; "useCurrencyAccountingStyle": { "alias": "useCurrencyAccountingStyle"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoBarGaugeFormatModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoBarGaugeFormatModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoBarGaugeFormatModule, never, [typeof DxoBarGaugeFormatComponent], [typeof DxoBarGaugeFormatComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoBarGaugeFormatModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoBarGaugeGeometryComponent extends NestedOption implements OnDestroy, OnInit {
    get endAngle(): number;
    set endAngle(value: number);
    get startAngle(): number;
    set startAngle(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoBarGaugeGeometryComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoBarGaugeGeometryComponent, "dxo-bar-gauge-geometry", never, { "endAngle": { "alias": "endAngle"; "required": false; }; "startAngle": { "alias": "startAngle"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoBarGaugeGeometryModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoBarGaugeGeometryModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoBarGaugeGeometryModule, never, [typeof DxoBarGaugeGeometryComponent], [typeof DxoBarGaugeGeometryComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoBarGaugeGeometryModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoBarGaugeItemTextFormatComponent extends NestedOption implements OnDestroy, OnInit {
    get currency(): string;
    set currency(value: string);
    get formatter(): ((value: number | Date) => string);
    set formatter(value: ((value: number | Date) => string));
    get parser(): ((value: string) => number | Date);
    set parser(value: ((value: string) => number | Date));
    get precision(): number;
    set precision(value: number);
    get type(): Format | string;
    set type(value: Format | string);
    get useCurrencyAccountingStyle(): boolean;
    set useCurrencyAccountingStyle(value: boolean);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoBarGaugeItemTextFormatComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoBarGaugeItemTextFormatComponent, "dxo-bar-gauge-item-text-format", never, { "currency": { "alias": "currency"; "required": false; }; "formatter": { "alias": "formatter"; "required": false; }; "parser": { "alias": "parser"; "required": false; }; "precision": { "alias": "precision"; "required": false; }; "type": { "alias": "type"; "required": false; }; "useCurrencyAccountingStyle": { "alias": "useCurrencyAccountingStyle"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoBarGaugeItemTextFormatModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoBarGaugeItemTextFormatModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoBarGaugeItemTextFormatModule, never, [typeof DxoBarGaugeItemTextFormatComponent], [typeof DxoBarGaugeItemTextFormatComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoBarGaugeItemTextFormatModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoBarGaugeLabelComponent extends NestedOption implements OnDestroy, OnInit {
    get connectorColor(): string | undefined;
    set connectorColor(value: string | undefined);
    get connectorWidth(): number;
    set connectorWidth(value: number);
    get customizeText(): ((barValue: {
        value: number;
        valueText: string;
    }) => string);
    set customizeText(value: ((barValue: {
        value: number;
        valueText: string;
    }) => string));
    get font(): Font;
    set font(value: Font);
    get format(): Format$1 | undefined;
    set format(value: Format$1 | undefined);
    get indent(): number;
    set indent(value: number);
    get visible(): boolean;
    set visible(value: boolean);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoBarGaugeLabelComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoBarGaugeLabelComponent, "dxo-bar-gauge-label", never, { "connectorColor": { "alias": "connectorColor"; "required": false; }; "connectorWidth": { "alias": "connectorWidth"; "required": false; }; "customizeText": { "alias": "customizeText"; "required": false; }; "font": { "alias": "font"; "required": false; }; "format": { "alias": "format"; "required": false; }; "indent": { "alias": "indent"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoBarGaugeLabelModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoBarGaugeLabelModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoBarGaugeLabelModule, never, [typeof DxoBarGaugeLabelComponent], [typeof DxoBarGaugeLabelComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoBarGaugeLabelModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoBarGaugeLegendBorderComponent extends NestedOption implements OnDestroy, OnInit {
    get color(): string;
    set color(value: string);
    get cornerRadius(): number;
    set cornerRadius(value: number);
    get dashStyle(): DashStyle;
    set dashStyle(value: DashStyle);
    get opacity(): number | undefined;
    set opacity(value: number | undefined);
    get visible(): boolean;
    set visible(value: boolean);
    get width(): number;
    set width(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoBarGaugeLegendBorderComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoBarGaugeLegendBorderComponent, "dxo-bar-gauge-legend-border", never, { "color": { "alias": "color"; "required": false; }; "cornerRadius": { "alias": "cornerRadius"; "required": false; }; "dashStyle": { "alias": "dashStyle"; "required": false; }; "opacity": { "alias": "opacity"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoBarGaugeLegendBorderModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoBarGaugeLegendBorderModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoBarGaugeLegendBorderModule, never, [typeof DxoBarGaugeLegendBorderComponent], [typeof DxoBarGaugeLegendBorderComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoBarGaugeLegendBorderModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoBarGaugeLegendTitleSubtitleComponent extends NestedOption implements OnDestroy, OnInit {
    get font(): Font;
    set font(value: Font);
    get offset(): number;
    set offset(value: number);
    get text(): string | undefined;
    set text(value: string | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoBarGaugeLegendTitleSubtitleComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoBarGaugeLegendTitleSubtitleComponent, "dxo-bar-gauge-legend-title-subtitle", never, { "font": { "alias": "font"; "required": false; }; "offset": { "alias": "offset"; "required": false; }; "text": { "alias": "text"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoBarGaugeLegendTitleSubtitleModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoBarGaugeLegendTitleSubtitleModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoBarGaugeLegendTitleSubtitleModule, never, [typeof DxoBarGaugeLegendTitleSubtitleComponent], [typeof DxoBarGaugeLegendTitleSubtitleComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoBarGaugeLegendTitleSubtitleModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoBarGaugeLegendTitleComponent extends NestedOption implements OnDestroy, OnInit {
    get font(): Font;
    set font(value: Font);
    get horizontalAlignment(): HorizontalAlignment | undefined;
    set horizontalAlignment(value: HorizontalAlignment | undefined);
    get margin(): {
        bottom?: number;
        left?: number;
        right?: number;
        top?: number;
    };
    set margin(value: {
        bottom?: number;
        left?: number;
        right?: number;
        top?: number;
    });
    get placeholderSize(): number | undefined;
    set placeholderSize(value: number | undefined);
    get subtitle(): string | {
        font?: Font;
        offset?: number;
        text?: string | undefined;
    };
    set subtitle(value: string | {
        font?: Font;
        offset?: number;
        text?: string | undefined;
    });
    get text(): string | undefined;
    set text(value: string | undefined);
    get verticalAlignment(): VerticalEdge;
    set verticalAlignment(value: VerticalEdge);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoBarGaugeLegendTitleComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoBarGaugeLegendTitleComponent, "dxo-bar-gauge-legend-title", never, { "font": { "alias": "font"; "required": false; }; "horizontalAlignment": { "alias": "horizontalAlignment"; "required": false; }; "margin": { "alias": "margin"; "required": false; }; "placeholderSize": { "alias": "placeholderSize"; "required": false; }; "subtitle": { "alias": "subtitle"; "required": false; }; "text": { "alias": "text"; "required": false; }; "verticalAlignment": { "alias": "verticalAlignment"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoBarGaugeLegendTitleModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoBarGaugeLegendTitleModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoBarGaugeLegendTitleModule, never, [typeof DxoBarGaugeLegendTitleComponent], [typeof DxoBarGaugeLegendTitleComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoBarGaugeLegendTitleModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoBarGaugeLegendComponent extends NestedOption implements OnDestroy, OnInit {
    get backgroundColor(): string | undefined;
    set backgroundColor(value: string | undefined);
    get border(): {
        color?: string;
        cornerRadius?: number;
        dashStyle?: DashStyle;
        opacity?: number | undefined;
        visible?: boolean;
        width?: number;
    };
    set border(value: {
        color?: string;
        cornerRadius?: number;
        dashStyle?: DashStyle;
        opacity?: number | undefined;
        visible?: boolean;
        width?: number;
    });
    get columnCount(): number;
    set columnCount(value: number);
    get columnItemSpacing(): number;
    set columnItemSpacing(value: number);
    get customizeHint(): ((arg: {
        item: BarGaugeBarInfo;
        text: string;
    }) => string);
    set customizeHint(value: ((arg: {
        item: BarGaugeBarInfo;
        text: string;
    }) => string));
    get customizeItems(): ((items: Array<BarGaugeLegendItem>) => Array<BarGaugeLegendItem>);
    set customizeItems(value: ((items: Array<BarGaugeLegendItem>) => Array<BarGaugeLegendItem>));
    get customizeText(): ((arg: {
        item: BarGaugeBarInfo;
        text: string;
    }) => string);
    set customizeText(value: ((arg: {
        item: BarGaugeBarInfo;
        text: string;
    }) => string));
    get font(): Font;
    set font(value: Font);
    get horizontalAlignment(): HorizontalAlignment;
    set horizontalAlignment(value: HorizontalAlignment);
    get itemsAlignment(): HorizontalAlignment | undefined;
    set itemsAlignment(value: HorizontalAlignment | undefined);
    get itemTextFormat(): Format$1 | undefined;
    set itemTextFormat(value: Format$1 | undefined);
    get itemTextPosition(): Position | undefined;
    set itemTextPosition(value: Position | undefined);
    get margin(): number | {
        bottom?: number;
        left?: number;
        right?: number;
        top?: number;
    };
    set margin(value: number | {
        bottom?: number;
        left?: number;
        right?: number;
        top?: number;
    });
    get markerSize(): number;
    set markerSize(value: number);
    get markerTemplate(): any;
    set markerTemplate(value: any);
    get orientation(): Orientation | undefined;
    set orientation(value: Orientation | undefined);
    get paddingLeftRight(): number;
    set paddingLeftRight(value: number);
    get paddingTopBottom(): number;
    set paddingTopBottom(value: number);
    get rowCount(): number;
    set rowCount(value: number);
    get rowItemSpacing(): number;
    set rowItemSpacing(value: number);
    get title(): string | {
        font?: Font;
        horizontalAlignment?: HorizontalAlignment | undefined;
        margin?: {
            bottom?: number;
            left?: number;
            right?: number;
            top?: number;
        };
        placeholderSize?: number | undefined;
        subtitle?: string | {
            font?: Font;
            offset?: number;
            text?: string | undefined;
        };
        text?: string | undefined;
        verticalAlignment?: VerticalEdge;
    };
    set title(value: string | {
        font?: Font;
        horizontalAlignment?: HorizontalAlignment | undefined;
        margin?: {
            bottom?: number;
            left?: number;
            right?: number;
            top?: number;
        };
        placeholderSize?: number | undefined;
        subtitle?: string | {
            font?: Font;
            offset?: number;
            text?: string | undefined;
        };
        text?: string | undefined;
        verticalAlignment?: VerticalEdge;
    });
    get verticalAlignment(): VerticalEdge;
    set verticalAlignment(value: VerticalEdge);
    get visible(): boolean;
    set visible(value: boolean);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoBarGaugeLegendComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoBarGaugeLegendComponent, "dxo-bar-gauge-legend", never, { "backgroundColor": { "alias": "backgroundColor"; "required": false; }; "border": { "alias": "border"; "required": false; }; "columnCount": { "alias": "columnCount"; "required": false; }; "columnItemSpacing": { "alias": "columnItemSpacing"; "required": false; }; "customizeHint": { "alias": "customizeHint"; "required": false; }; "customizeItems": { "alias": "customizeItems"; "required": false; }; "customizeText": { "alias": "customizeText"; "required": false; }; "font": { "alias": "font"; "required": false; }; "horizontalAlignment": { "alias": "horizontalAlignment"; "required": false; }; "itemsAlignment": { "alias": "itemsAlignment"; "required": false; }; "itemTextFormat": { "alias": "itemTextFormat"; "required": false; }; "itemTextPosition": { "alias": "itemTextPosition"; "required": false; }; "margin": { "alias": "margin"; "required": false; }; "markerSize": { "alias": "markerSize"; "required": false; }; "markerTemplate": { "alias": "markerTemplate"; "required": false; }; "orientation": { "alias": "orientation"; "required": false; }; "paddingLeftRight": { "alias": "paddingLeftRight"; "required": false; }; "paddingTopBottom": { "alias": "paddingTopBottom"; "required": false; }; "rowCount": { "alias": "rowCount"; "required": false; }; "rowItemSpacing": { "alias": "rowItemSpacing"; "required": false; }; "title": { "alias": "title"; "required": false; }; "verticalAlignment": { "alias": "verticalAlignment"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoBarGaugeLegendModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoBarGaugeLegendModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoBarGaugeLegendModule, never, [typeof DxoBarGaugeLegendComponent], [typeof DxoBarGaugeLegendComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoBarGaugeLegendModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoBarGaugeLoadingIndicatorComponent extends NestedOption implements OnDestroy, OnInit {
    get backgroundColor(): string;
    set backgroundColor(value: string);
    get font(): Font;
    set font(value: Font);
    get show(): boolean;
    set show(value: boolean);
    get text(): string;
    set text(value: string);
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    showChange: EventEmitter<boolean>;
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoBarGaugeLoadingIndicatorComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoBarGaugeLoadingIndicatorComponent, "dxo-bar-gauge-loading-indicator", never, { "backgroundColor": { "alias": "backgroundColor"; "required": false; }; "font": { "alias": "font"; "required": false; }; "show": { "alias": "show"; "required": false; }; "text": { "alias": "text"; "required": false; }; }, { "showChange": "showChange"; }, never, never, true, never>;
}
declare class DxoBarGaugeLoadingIndicatorModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoBarGaugeLoadingIndicatorModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoBarGaugeLoadingIndicatorModule, never, [typeof DxoBarGaugeLoadingIndicatorComponent], [typeof DxoBarGaugeLoadingIndicatorComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoBarGaugeLoadingIndicatorModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoBarGaugeMarginComponent extends NestedOption implements OnDestroy, OnInit {
    get bottom(): number;
    set bottom(value: number);
    get left(): number;
    set left(value: number);
    get right(): number;
    set right(value: number);
    get top(): number;
    set top(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoBarGaugeMarginComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoBarGaugeMarginComponent, "dxo-bar-gauge-margin", never, { "bottom": { "alias": "bottom"; "required": false; }; "left": { "alias": "left"; "required": false; }; "right": { "alias": "right"; "required": false; }; "top": { "alias": "top"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoBarGaugeMarginModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoBarGaugeMarginModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoBarGaugeMarginModule, never, [typeof DxoBarGaugeMarginComponent], [typeof DxoBarGaugeMarginComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoBarGaugeMarginModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoBarGaugeShadowComponent extends NestedOption implements OnDestroy, OnInit {
    get blur(): number;
    set blur(value: number);
    get color(): string;
    set color(value: string);
    get offsetX(): number;
    set offsetX(value: number);
    get offsetY(): number;
    set offsetY(value: number);
    get opacity(): number;
    set opacity(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoBarGaugeShadowComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoBarGaugeShadowComponent, "dxo-bar-gauge-shadow", never, { "blur": { "alias": "blur"; "required": false; }; "color": { "alias": "color"; "required": false; }; "offsetX": { "alias": "offsetX"; "required": false; }; "offsetY": { "alias": "offsetY"; "required": false; }; "opacity": { "alias": "opacity"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoBarGaugeShadowModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoBarGaugeShadowModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoBarGaugeShadowModule, never, [typeof DxoBarGaugeShadowComponent], [typeof DxoBarGaugeShadowComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoBarGaugeShadowModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoBarGaugeSizeComponent extends NestedOption implements OnDestroy, OnInit {
    get height(): number | undefined;
    set height(value: number | undefined);
    get width(): number | undefined;
    set width(value: number | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoBarGaugeSizeComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoBarGaugeSizeComponent, "dxo-bar-gauge-size", never, { "height": { "alias": "height"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoBarGaugeSizeModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoBarGaugeSizeModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoBarGaugeSizeModule, never, [typeof DxoBarGaugeSizeComponent], [typeof DxoBarGaugeSizeComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoBarGaugeSizeModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoBarGaugeSubtitleComponent extends NestedOption implements OnDestroy, OnInit {
    get font(): Font;
    set font(value: Font);
    get offset(): number;
    set offset(value: number);
    get text(): string | undefined;
    set text(value: string | undefined);
    get textOverflow(): TextOverflow;
    set textOverflow(value: TextOverflow);
    get wordWrap(): WordWrap;
    set wordWrap(value: WordWrap);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoBarGaugeSubtitleComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoBarGaugeSubtitleComponent, "dxo-bar-gauge-subtitle", never, { "font": { "alias": "font"; "required": false; }; "offset": { "alias": "offset"; "required": false; }; "text": { "alias": "text"; "required": false; }; "textOverflow": { "alias": "textOverflow"; "required": false; }; "wordWrap": { "alias": "wordWrap"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoBarGaugeSubtitleModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoBarGaugeSubtitleModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoBarGaugeSubtitleModule, never, [typeof DxoBarGaugeSubtitleComponent], [typeof DxoBarGaugeSubtitleComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoBarGaugeSubtitleModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoBarGaugeTitleComponent extends NestedOption implements OnDestroy, OnInit {
    get font(): Font;
    set font(value: Font);
    get horizontalAlignment(): HorizontalAlignment | undefined;
    set horizontalAlignment(value: HorizontalAlignment | undefined);
    get margin(): number | {
        bottom?: number;
        left?: number;
        right?: number;
        top?: number;
    };
    set margin(value: number | {
        bottom?: number;
        left?: number;
        right?: number;
        top?: number;
    });
    get placeholderSize(): number | undefined;
    set placeholderSize(value: number | undefined);
    get subtitle(): string | {
        font?: Font;
        offset?: number;
        text?: string | undefined;
        textOverflow?: TextOverflow;
        wordWrap?: WordWrap;
    };
    set subtitle(value: string | {
        font?: Font;
        offset?: number;
        text?: string | undefined;
        textOverflow?: TextOverflow;
        wordWrap?: WordWrap;
    });
    get text(): string | undefined;
    set text(value: string | undefined);
    get verticalAlignment(): VerticalEdge;
    set verticalAlignment(value: VerticalEdge);
    get textOverflow(): TextOverflow;
    set textOverflow(value: TextOverflow);
    get wordWrap(): WordWrap;
    set wordWrap(value: WordWrap);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoBarGaugeTitleComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoBarGaugeTitleComponent, "dxo-bar-gauge-title", never, { "font": { "alias": "font"; "required": false; }; "horizontalAlignment": { "alias": "horizontalAlignment"; "required": false; }; "margin": { "alias": "margin"; "required": false; }; "placeholderSize": { "alias": "placeholderSize"; "required": false; }; "subtitle": { "alias": "subtitle"; "required": false; }; "text": { "alias": "text"; "required": false; }; "verticalAlignment": { "alias": "verticalAlignment"; "required": false; }; "textOverflow": { "alias": "textOverflow"; "required": false; }; "wordWrap": { "alias": "wordWrap"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoBarGaugeTitleModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoBarGaugeTitleModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoBarGaugeTitleModule, never, [typeof DxoBarGaugeTitleComponent], [typeof DxoBarGaugeTitleComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoBarGaugeTitleModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoBarGaugeTooltipBorderComponent extends NestedOption implements OnDestroy, OnInit {
    get color(): string;
    set color(value: string);
    get dashStyle(): DashStyle;
    set dashStyle(value: DashStyle);
    get opacity(): number | undefined;
    set opacity(value: number | undefined);
    get visible(): boolean;
    set visible(value: boolean);
    get width(): number;
    set width(value: number);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoBarGaugeTooltipBorderComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoBarGaugeTooltipBorderComponent, "dxo-bar-gauge-tooltip-border", never, { "color": { "alias": "color"; "required": false; }; "dashStyle": { "alias": "dashStyle"; "required": false; }; "opacity": { "alias": "opacity"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoBarGaugeTooltipBorderModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoBarGaugeTooltipBorderModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoBarGaugeTooltipBorderModule, never, [typeof DxoBarGaugeTooltipBorderComponent], [typeof DxoBarGaugeTooltipBorderComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoBarGaugeTooltipBorderModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxoBarGaugeTooltipComponent extends NestedOption implements OnDestroy, OnInit {
    get arrowLength(): number;
    set arrowLength(value: number);
    get border(): {
        color?: string;
        dashStyle?: DashStyle;
        opacity?: number | undefined;
        visible?: boolean;
        width?: number;
    };
    set border(value: {
        color?: string;
        dashStyle?: DashStyle;
        opacity?: number | undefined;
        visible?: boolean;
        width?: number;
    });
    get color(): string;
    set color(value: string);
    get container(): any | string | undefined;
    set container(value: any | string | undefined);
    get contentTemplate(): any;
    set contentTemplate(value: any);
    get cornerRadius(): number;
    set cornerRadius(value: number);
    get customizeTooltip(): ((scaleValue: {
        index: number;
        value: number;
        valueText: string;
    }) => Record<string, any>) | undefined;
    set customizeTooltip(value: ((scaleValue: {
        index: number;
        value: number;
        valueText: string;
    }) => Record<string, any>) | undefined);
    get enabled(): boolean;
    set enabled(value: boolean);
    get font(): Font;
    set font(value: Font);
    get format(): Format$1 | undefined;
    set format(value: Format$1 | undefined);
    get interactive(): boolean;
    set interactive(value: boolean);
    get opacity(): number | undefined;
    set opacity(value: number | undefined);
    get paddingLeftRight(): number;
    set paddingLeftRight(value: number);
    get paddingTopBottom(): number;
    set paddingTopBottom(value: number);
    get shadow(): {
        blur?: number;
        color?: string;
        offsetX?: number;
        offsetY?: number;
        opacity?: number;
    };
    set shadow(value: {
        blur?: number;
        color?: string;
        offsetX?: number;
        offsetY?: number;
        opacity?: number;
    });
    get zIndex(): number | undefined;
    set zIndex(value: number | undefined);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoBarGaugeTooltipComponent, [{ host: true; skipSelf: true; }, { host: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxoBarGaugeTooltipComponent, "dxo-bar-gauge-tooltip", never, { "arrowLength": { "alias": "arrowLength"; "required": false; }; "border": { "alias": "border"; "required": false; }; "color": { "alias": "color"; "required": false; }; "container": { "alias": "container"; "required": false; }; "contentTemplate": { "alias": "contentTemplate"; "required": false; }; "cornerRadius": { "alias": "cornerRadius"; "required": false; }; "customizeTooltip": { "alias": "customizeTooltip"; "required": false; }; "enabled": { "alias": "enabled"; "required": false; }; "font": { "alias": "font"; "required": false; }; "format": { "alias": "format"; "required": false; }; "interactive": { "alias": "interactive"; "required": false; }; "opacity": { "alias": "opacity"; "required": false; }; "paddingLeftRight": { "alias": "paddingLeftRight"; "required": false; }; "paddingTopBottom": { "alias": "paddingTopBottom"; "required": false; }; "shadow": { "alias": "shadow"; "required": false; }; "zIndex": { "alias": "zIndex"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxoBarGaugeTooltipModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxoBarGaugeTooltipModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxoBarGaugeTooltipModule, never, [typeof DxoBarGaugeTooltipComponent], [typeof DxoBarGaugeTooltipComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxoBarGaugeTooltipModule>;
}

export { DxoBarGaugeAnimationComponent, DxoBarGaugeAnimationModule, DxoBarGaugeBarGaugeTitleComponent, DxoBarGaugeBarGaugeTitleModule, DxoBarGaugeBarGaugeTitleSubtitleComponent, DxoBarGaugeBarGaugeTitleSubtitleModule, DxoBarGaugeBorderComponent, DxoBarGaugeBorderModule, DxoBarGaugeExportComponent, DxoBarGaugeExportModule, DxoBarGaugeFontComponent, DxoBarGaugeFontModule, DxoBarGaugeFormatComponent, DxoBarGaugeFormatModule, DxoBarGaugeGeometryComponent, DxoBarGaugeGeometryModule, DxoBarGaugeItemTextFormatComponent, DxoBarGaugeItemTextFormatModule, DxoBarGaugeLabelComponent, DxoBarGaugeLabelModule, DxoBarGaugeLegendBorderComponent, DxoBarGaugeLegendBorderModule, DxoBarGaugeLegendComponent, DxoBarGaugeLegendModule, DxoBarGaugeLegendTitleComponent, DxoBarGaugeLegendTitleModule, DxoBarGaugeLegendTitleSubtitleComponent, DxoBarGaugeLegendTitleSubtitleModule, DxoBarGaugeLoadingIndicatorComponent, DxoBarGaugeLoadingIndicatorModule, DxoBarGaugeMarginComponent, DxoBarGaugeMarginModule, DxoBarGaugeShadowComponent, DxoBarGaugeShadowModule, DxoBarGaugeSizeComponent, DxoBarGaugeSizeModule, DxoBarGaugeSubtitleComponent, DxoBarGaugeSubtitleModule, DxoBarGaugeTitleComponent, DxoBarGaugeTitleModule, DxoBarGaugeTooltipBorderComponent, DxoBarGaugeTooltipBorderModule, DxoBarGaugeTooltipComponent, DxoBarGaugeTooltipModule };
//# sourceMappingURL=index.d.ts.map
