import * as i0 from '@angular/core';
import { OnDestroy, EventEmitter, ElementRef, NgZone, TransferState } from '@angular/core';
import DxLoadIndicator, { LoadingAnimationType, ContentReadyEvent, DisposingEvent, InitializedEvent, OptionChangedEvent } from 'devextreme/ui/load_indicator';
import * as i1 from 'devextreme-angular/core';
import { DxComponent, DxTemplateHost, WatcherHelper, NestedOptionHost } from 'devextreme-angular/core';
import * as load_indicator_types from 'devextreme/ui/load_indicator_types';
export { load_indicator_types as DxLoadIndicatorTypes };

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

/**
 * [descr:dxLoadIndicator]

 */
declare class DxLoadIndicatorComponent extends DxComponent implements OnDestroy {
    instance: DxLoadIndicator;
    /**
     * [descr:dxLoadIndicatorOptions.animationType]
    
     */
    get animationType(): LoadingAnimationType;
    set animationType(value: LoadingAnimationType);
    /**
     * [descr:DOMComponentOptions.elementAttr]
    
     */
    get elementAttr(): Record<string, any>;
    set elementAttr(value: Record<string, any>);
    /**
     * [descr:DOMComponentOptions.height]
    
     */
    get height(): number | string | undefined;
    set height(value: number | string | undefined);
    /**
     * [descr:WidgetOptions.hint]
    
     */
    get hint(): string | undefined;
    set hint(value: string | undefined);
    /**
     * [descr:dxLoadIndicatorOptions.indicatorSrc]
    
     */
    get indicatorSrc(): string;
    set indicatorSrc(value: string);
    /**
     * [descr:DOMComponentOptions.rtlEnabled]
    
     */
    get rtlEnabled(): boolean;
    set rtlEnabled(value: boolean);
    /**
     * [descr:WidgetOptions.visible]
    
     */
    get visible(): boolean;
    set visible(value: boolean);
    /**
     * [descr:DOMComponentOptions.width]
    
     */
    get width(): number | string | undefined;
    set width(value: number | string | undefined);
    /**
    
     * [descr:dxLoadIndicatorOptions.onContentReady]
    
    
     */
    onContentReady: EventEmitter<ContentReadyEvent>;
    /**
    
     * [descr:dxLoadIndicatorOptions.onDisposing]
    
    
     */
    onDisposing: EventEmitter<DisposingEvent>;
    /**
    
     * [descr:dxLoadIndicatorOptions.onInitialized]
    
    
     */
    onInitialized: EventEmitter<InitializedEvent>;
    /**
    
     * [descr:dxLoadIndicatorOptions.onOptionChanged]
    
    
     */
    onOptionChanged: EventEmitter<OptionChangedEvent>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    animationTypeChange: EventEmitter<LoadingAnimationType>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    elementAttrChange: EventEmitter<Record<string, any>>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    heightChange: EventEmitter<number | string | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    hintChange: EventEmitter<string | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    indicatorSrcChange: EventEmitter<string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    rtlEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    visibleChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    widthChange: EventEmitter<number | string | undefined>;
    constructor(elementRef: ElementRef, ngZone: NgZone, templateHost: DxTemplateHost, _watcherHelper: WatcherHelper, optionHost: NestedOptionHost, transferState: TransferState, platformId: any);
    protected _createInstance(element: any, options: any): DxLoadIndicator;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxLoadIndicatorComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxLoadIndicatorComponent, "dx-load-indicator", never, { "animationType": { "alias": "animationType"; "required": false; }; "elementAttr": { "alias": "elementAttr"; "required": false; }; "height": { "alias": "height"; "required": false; }; "hint": { "alias": "hint"; "required": false; }; "indicatorSrc": { "alias": "indicatorSrc"; "required": false; }; "rtlEnabled": { "alias": "rtlEnabled"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, { "onContentReady": "onContentReady"; "onDisposing": "onDisposing"; "onInitialized": "onInitialized"; "onOptionChanged": "onOptionChanged"; "animationTypeChange": "animationTypeChange"; "elementAttrChange": "elementAttrChange"; "heightChange": "heightChange"; "hintChange": "hintChange"; "indicatorSrcChange": "indicatorSrcChange"; "rtlEnabledChange": "rtlEnabledChange"; "visibleChange": "visibleChange"; "widthChange": "widthChange"; }, never, never, true, never>;
}
declare class DxLoadIndicatorModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxLoadIndicatorModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxLoadIndicatorModule, never, [typeof DxLoadIndicatorComponent, typeof i1.DxIntegrationModule, typeof i1.DxTemplateModule], [typeof DxLoadIndicatorComponent, typeof i1.DxTemplateModule]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxLoadIndicatorModule>;
}

export { DxLoadIndicatorComponent, DxLoadIndicatorModule };
//# sourceMappingURL=index.d.ts.map
