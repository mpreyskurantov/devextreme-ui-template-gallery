import * as i0 from '@angular/core';
import { AfterViewInit, Renderer2, ElementRef } from '@angular/core';
import { dxBoxOptions } from 'devextreme/ui/box';
import { CollectionNestedOption, IDxTemplateHost, NestedOptionHost, DxTemplateHost, DxTemplateDirective } from 'devextreme-angular/core';

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxiBoxItemComponent extends CollectionNestedOption implements AfterViewInit, IDxTemplateHost {
    private renderer;
    private document;
    private element;
    get baseSize(): number | string;
    set baseSize(value: number | string);
    get box(): dxBoxOptions | undefined;
    set box(value: dxBoxOptions | undefined);
    get disabled(): boolean;
    set disabled(value: boolean);
    get html(): string;
    set html(value: string);
    get ratio(): number;
    set ratio(value: number);
    get shrink(): number;
    set shrink(value: number);
    get template(): any;
    set template(value: any);
    get text(): string;
    set text(value: string);
    get visible(): boolean;
    set visible(value: boolean);
    protected get _optionPath(): string;
    constructor(parentOptionHost: NestedOptionHost, optionHost: NestedOptionHost, renderer: Renderer2, document: any, templateHost: DxTemplateHost, element: ElementRef);
    setTemplate(template: DxTemplateDirective): void;
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiBoxItemComponent, [{ host: true; skipSelf: true; }, { host: true; }, null, null, { host: true; }, null]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxiBoxItemComponent, "dxi-box-item", never, { "baseSize": { "alias": "baseSize"; "required": false; }; "box": { "alias": "box"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "html": { "alias": "html"; "required": false; }; "ratio": { "alias": "ratio"; "required": false; }; "shrink": { "alias": "shrink"; "required": false; }; "template": { "alias": "template"; "required": false; }; "text": { "alias": "text"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; }, {}, never, ["*"], true, never>;
}
declare class DxiBoxItemModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxiBoxItemModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxiBoxItemModule, never, [typeof DxiBoxItemComponent], [typeof DxiBoxItemComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxiBoxItemModule>;
}

export { DxiBoxItemComponent, DxiBoxItemModule };
//# sourceMappingURL=index.d.ts.map
