import * as i0 from '@angular/core';
import { OnDestroy, OnChanges, DoCheck, QueryList, EventEmitter, ElementRef, NgZone, TransferState, SimpleChanges } from '@angular/core';
import { ApplyValueMode, TextEditorButton, LabelMode, EditorStyle, ValidationMessageMode, Mode, Position, ValidationStatus } from 'devextreme/common';
import { DropDownPredefinedButton } from 'devextreme/ui/drop_down_editor/ui.drop_down_editor';
import { dxCalendarOptions } from 'devextreme/ui/calendar';
import { Format } from 'devextreme/common/core/localization';
import { dxPopupOptions } from 'devextreme/ui/popup';
import DxDateRangeBox, { ChangeEvent, ClosedEvent, ContentReadyEvent, CopyEvent, CutEvent, DisposingEvent, EnterKeyEvent, FocusInEvent, FocusOutEvent, InitializedEvent, InputEvent, KeyDownEvent, KeyUpEvent, OpenedEvent, OptionChangedEvent, PasteEvent, ValueChangedEvent } from 'devextreme/ui/date_range_box';
import { ControlValueAccessor } from '@angular/forms';
import * as i3 from 'devextreme-angular/core';
import { DxComponent, CollectionNestedOption, DxTemplateHost, WatcherHelper, IterableDifferHelper, NestedOptionHost } from 'devextreme-angular/core';
import * as i1 from 'devextreme-angular/ui/nested';
import * as i2 from 'devextreme-angular/ui/date-range-box/nested';
export * from 'devextreme-angular/ui/date-range-box/nested';
import * as date_range_box_types from 'devextreme/ui/date_range_box_types';
export { date_range_box_types as DxDateRangeBoxTypes };

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

/**
 * [descr:dxDateRangeBox]

 */
declare class DxDateRangeBoxComponent extends DxComponent implements OnDestroy, ControlValueAccessor, OnChanges, DoCheck {
    private _watcherHelper;
    private _idh;
    set _buttonsContentChildren(value: QueryList<CollectionNestedOption>);
    set _toolbarItemsContentChildren(value: QueryList<CollectionNestedOption>);
    instance: DxDateRangeBox;
    /**
     * [descr:dxDropDownEditorOptions.acceptCustomValue]
    
     */
    get acceptCustomValue(): boolean;
    set acceptCustomValue(value: boolean);
    /**
     * [descr:WidgetOptions.accessKey]
    
     */
    get accessKey(): string | undefined;
    set accessKey(value: string | undefined);
    /**
     * [descr:dxDropDownEditorOptions.activeStateEnabled]
    
     */
    get activeStateEnabled(): boolean;
    set activeStateEnabled(value: boolean);
    /**
     * [descr:DateBoxBaseOptions.applyButtonText]
    
     */
    get applyButtonText(): string;
    set applyButtonText(value: string);
    /**
     * [descr:dxDropDownEditorOptions.applyValueMode]
    
     */
    get applyValueMode(): ApplyValueMode;
    set applyValueMode(value: ApplyValueMode);
    /**
     * [descr:dxDropDownEditorOptions.buttons]
    
     */
    get buttons(): Array<DropDownPredefinedButton | TextEditorButton> | undefined;
    set buttons(value: Array<DropDownPredefinedButton | TextEditorButton> | undefined);
    /**
     * [descr:DateBoxBaseOptions.calendarOptions]
    
     */
    get calendarOptions(): dxCalendarOptions;
    set calendarOptions(value: dxCalendarOptions);
    /**
     * [descr:DateBoxBaseOptions.cancelButtonText]
    
     */
    get cancelButtonText(): string;
    set cancelButtonText(value: string);
    /**
     * [descr:DateBoxBaseOptions.dateSerializationFormat]
    
     */
    get dateSerializationFormat(): string | undefined;
    set dateSerializationFormat(value: string | undefined);
    /**
     * [descr:dxDropDownEditorOptions.deferRendering]
    
     */
    get deferRendering(): boolean;
    set deferRendering(value: boolean);
    /**
     * [descr:WidgetOptions.disabled]
    
     */
    get disabled(): boolean;
    set disabled(value: boolean);
    /**
     * [descr:dxDateRangeBoxOptions.disableOutOfRangeSelection]
    
     */
    get disableOutOfRangeSelection(): boolean;
    set disableOutOfRangeSelection(value: boolean);
    /**
     * [descr:DateBoxBaseOptions.displayFormat]
    
     */
    get displayFormat(): Format | null;
    set displayFormat(value: Format | null);
    /**
     * [descr:dxDropDownEditorOptions.dropDownButtonTemplate]
    
     */
    get dropDownButtonTemplate(): any;
    set dropDownButtonTemplate(value: any);
    /**
     * [descr:DateBoxBaseOptions.dropDownOptions]
    
     */
    get dropDownOptions(): dxPopupOptions<any>;
    set dropDownOptions(value: dxPopupOptions<any>);
    /**
     * [descr:DOMComponentOptions.elementAttr]
    
     */
    get elementAttr(): Record<string, any>;
    set elementAttr(value: Record<string, any>);
    /**
     * [descr:dxDateRangeBoxOptions.endDate]
    
     */
    get endDate(): Date | null | number | string;
    set endDate(value: Date | null | number | string);
    /**
     * [descr:dxDateRangeBoxOptions.endDateInputAttr]
    
     */
    get endDateInputAttr(): any;
    set endDateInputAttr(value: any);
    /**
     * [descr:dxDateRangeBoxOptions.endDateLabel]
    
     */
    get endDateLabel(): string;
    set endDateLabel(value: string);
    /**
     * [descr:dxDateRangeBoxOptions.endDateName]
    
     */
    get endDateName(): string;
    set endDateName(value: string);
    /**
     * [descr:dxDateRangeBoxOptions.endDateOutOfRangeMessage]
    
     */
    get endDateOutOfRangeMessage(): string;
    set endDateOutOfRangeMessage(value: string);
    /**
     * [descr:dxDateRangeBoxOptions.endDatePlaceholder]
    
     */
    get endDatePlaceholder(): string;
    set endDatePlaceholder(value: string);
    /**
     * [descr:dxDateRangeBoxOptions.endDateText]
    
     */
    get endDateText(): string;
    set endDateText(value: string);
    /**
     * [descr:dxTextEditorOptions.focusStateEnabled]
    
     */
    get focusStateEnabled(): boolean;
    set focusStateEnabled(value: boolean);
    /**
     * [descr:DOMComponentOptions.height]
    
     */
    get height(): number | string | undefined;
    set height(value: number | string | undefined);
    /**
     * [descr:WidgetOptions.hint]
    
     */
    get hint(): string | undefined;
    set hint(value: string | undefined);
    /**
     * [descr:dxTextEditorOptions.hoverStateEnabled]
    
     */
    get hoverStateEnabled(): boolean;
    set hoverStateEnabled(value: boolean);
    /**
     * [descr:dxDateRangeBoxOptions.invalidEndDateMessage]
    
     */
    get invalidEndDateMessage(): string;
    set invalidEndDateMessage(value: string);
    /**
     * [descr:dxDateRangeBoxOptions.invalidStartDateMessage]
    
     */
    get invalidStartDateMessage(): string;
    set invalidStartDateMessage(value: string);
    /**
     * [descr:EditorOptions.isDirty]
    
     */
    get isDirty(): boolean;
    set isDirty(value: boolean);
    /**
     * [descr:EditorOptions.isValid]
    
     */
    get isValid(): boolean;
    set isValid(value: boolean);
    /**
     * [descr:dxTextEditorOptions.labelMode]
    
     */
    get labelMode(): LabelMode;
    set labelMode(value: LabelMode);
    /**
     * [descr:DateBoxBaseOptions.max]
    
     */
    get max(): Date | null | number | string | undefined;
    set max(value: Date | null | number | string | undefined);
    /**
     * [descr:DateBoxBaseOptions.min]
    
     */
    get min(): Date | null | number | string | undefined;
    set min(value: Date | null | number | string | undefined);
    /**
     * [descr:dxDateRangeBoxOptions.multiView]
    
     */
    get multiView(): boolean;
    set multiView(value: boolean);
    /**
     * [descr:dxDropDownEditorOptions.opened]
    
     */
    get opened(): boolean;
    set opened(value: boolean);
    /**
     * [descr:dxDateRangeBoxOptions.openOnFieldClick]
    
     */
    get openOnFieldClick(): boolean;
    set openOnFieldClick(value: boolean);
    /**
     * [descr:EditorOptions.readOnly]
    
     */
    get readOnly(): boolean;
    set readOnly(value: boolean);
    /**
     * [descr:DOMComponentOptions.rtlEnabled]
    
     */
    get rtlEnabled(): boolean;
    set rtlEnabled(value: boolean);
    /**
     * [descr:dxTextEditorOptions.showClearButton]
    
     */
    get showClearButton(): boolean;
    set showClearButton(value: boolean);
    /**
     * [descr:dxDropDownEditorOptions.showDropDownButton]
    
     */
    get showDropDownButton(): boolean;
    set showDropDownButton(value: boolean);
    /**
     * [descr:dxTextEditorOptions.spellcheck]
    
     */
    get spellcheck(): boolean;
    set spellcheck(value: boolean);
    /**
     * [descr:dxDateRangeBoxOptions.startDate]
    
     */
    get startDate(): Date | null | number | string;
    set startDate(value: Date | null | number | string);
    /**
     * [descr:dxDateRangeBoxOptions.startDateInputAttr]
    
     */
    get startDateInputAttr(): any;
    set startDateInputAttr(value: any);
    /**
     * [descr:dxDateRangeBoxOptions.startDateLabel]
    
     */
    get startDateLabel(): string;
    set startDateLabel(value: string);
    /**
     * [descr:dxDateRangeBoxOptions.startDateName]
    
     */
    get startDateName(): string;
    set startDateName(value: string);
    /**
     * [descr:dxDateRangeBoxOptions.startDateOutOfRangeMessage]
    
     */
    get startDateOutOfRangeMessage(): string;
    set startDateOutOfRangeMessage(value: string);
    /**
     * [descr:dxDateRangeBoxOptions.startDatePlaceholder]
    
     */
    get startDatePlaceholder(): string;
    set startDatePlaceholder(value: string);
    /**
     * [descr:dxDateRangeBoxOptions.startDateText]
    
     */
    get startDateText(): string;
    set startDateText(value: string);
    /**
     * [descr:dxTextEditorOptions.stylingMode]
    
     */
    get stylingMode(): EditorStyle;
    set stylingMode(value: EditorStyle);
    /**
     * [descr:WidgetOptions.tabIndex]
    
     */
    get tabIndex(): number;
    set tabIndex(value: number);
    /**
     * [descr:DateBoxBaseOptions.todayButtonText]
    
     */
    get todayButtonText(): string;
    set todayButtonText(value: string);
    /**
     * [descr:DateBoxBaseOptions.useMaskBehavior]
    
     */
    get useMaskBehavior(): boolean;
    set useMaskBehavior(value: boolean);
    /**
     * [descr:EditorOptions.validationError]
    
     */
    get validationError(): any | null;
    set validationError(value: any | null);
    /**
     * [descr:EditorOptions.validationErrors]
    
     */
    get validationErrors(): Array<any> | null;
    set validationErrors(value: Array<any> | null);
    /**
     * [descr:EditorOptions.validationMessageMode]
    
     */
    get validationMessageMode(): ValidationMessageMode;
    set validationMessageMode(value: ValidationMessageMode);
    /**
     * [descr:dxDropDownEditorOptions.validationMessagePosition]
    
     */
    get validationMessagePosition(): Mode | Position;
    set validationMessagePosition(value: Mode | Position);
    /**
     * [descr:EditorOptions.validationStatus]
    
     */
    get validationStatus(): ValidationStatus;
    set validationStatus(value: ValidationStatus);
    /**
     * [descr:dxDateRangeBoxOptions.value]
    
     */
    get value(): Array<Date | null | number | string>;
    set value(value: Array<Date | null | number | string>);
    /**
     * [descr:dxTextEditorOptions.valueChangeEvent]
    
     */
    get valueChangeEvent(): string;
    set valueChangeEvent(value: string);
    /**
     * [descr:WidgetOptions.visible]
    
     */
    get visible(): boolean;
    set visible(value: boolean);
    /**
     * [descr:DOMComponentOptions.width]
    
     */
    get width(): number | string | undefined;
    set width(value: number | string | undefined);
    /**
    
     * [descr:dxDateRangeBoxOptions.onChange]
    
    
     */
    onChange: EventEmitter<ChangeEvent>;
    /**
    
     * [descr:dxDateRangeBoxOptions.onClosed]
    
    
     */
    onClosed: EventEmitter<ClosedEvent>;
    /**
    
     * [descr:dxDateRangeBoxOptions.onContentReady]
    
    
     */
    onContentReady: EventEmitter<ContentReadyEvent>;
    /**
    
     * [descr:dxDateRangeBoxOptions.onCopy]
    
    
     */
    onCopy: EventEmitter<CopyEvent>;
    /**
    
     * [descr:dxDateRangeBoxOptions.onCut]
    
    
     */
    onCut: EventEmitter<CutEvent>;
    /**
    
     * [descr:dxDateRangeBoxOptions.onDisposing]
    
    
     */
    onDisposing: EventEmitter<DisposingEvent>;
    /**
    
     * [descr:dxDateRangeBoxOptions.onEnterKey]
    
    
     */
    onEnterKey: EventEmitter<EnterKeyEvent>;
    /**
    
     * [descr:dxDateRangeBoxOptions.onFocusIn]
    
    
     */
    onFocusIn: EventEmitter<FocusInEvent>;
    /**
    
     * [descr:dxDateRangeBoxOptions.onFocusOut]
    
    
     */
    onFocusOut: EventEmitter<FocusOutEvent>;
    /**
    
     * [descr:dxDateRangeBoxOptions.onInitialized]
    
    
     */
    onInitialized: EventEmitter<InitializedEvent>;
    /**
    
     * [descr:dxDateRangeBoxOptions.onInput]
    
    
     */
    onInput: EventEmitter<InputEvent>;
    /**
    
     * [descr:dxDateRangeBoxOptions.onKeyDown]
    
    
     */
    onKeyDown: EventEmitter<KeyDownEvent>;
    /**
    
     * [descr:dxDateRangeBoxOptions.onKeyUp]
    
    
     */
    onKeyUp: EventEmitter<KeyUpEvent>;
    /**
    
     * [descr:dxDateRangeBoxOptions.onOpened]
    
    
     */
    onOpened: EventEmitter<OpenedEvent>;
    /**
    
     * [descr:dxDateRangeBoxOptions.onOptionChanged]
    
    
     */
    onOptionChanged: EventEmitter<OptionChangedEvent>;
    /**
    
     * [descr:dxDateRangeBoxOptions.onPaste]
    
    
     */
    onPaste: EventEmitter<PasteEvent>;
    /**
    
     * [descr:dxDateRangeBoxOptions.onValueChanged]
    
    
     */
    onValueChanged: EventEmitter<ValueChangedEvent>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    acceptCustomValueChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    accessKeyChange: EventEmitter<string | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    activeStateEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    applyButtonTextChange: EventEmitter<string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    applyValueModeChange: EventEmitter<ApplyValueMode>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    buttonsChange: EventEmitter<Array<DropDownPredefinedButton | TextEditorButton> | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    calendarOptionsChange: EventEmitter<dxCalendarOptions>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    cancelButtonTextChange: EventEmitter<string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    dateSerializationFormatChange: EventEmitter<string | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    deferRenderingChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    disabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    disableOutOfRangeSelectionChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    displayFormatChange: EventEmitter<Format | null>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    dropDownButtonTemplateChange: EventEmitter<any>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    dropDownOptionsChange: EventEmitter<dxPopupOptions<any>>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    elementAttrChange: EventEmitter<Record<string, any>>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    endDateChange: EventEmitter<Date | null | number | string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    endDateInputAttrChange: EventEmitter<any>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    endDateLabelChange: EventEmitter<string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    endDateNameChange: EventEmitter<string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    endDateOutOfRangeMessageChange: EventEmitter<string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    endDatePlaceholderChange: EventEmitter<string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    endDateTextChange: EventEmitter<string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    focusStateEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    heightChange: EventEmitter<number | string | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    hintChange: EventEmitter<string | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    hoverStateEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    invalidEndDateMessageChange: EventEmitter<string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    invalidStartDateMessageChange: EventEmitter<string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    isDirtyChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    isValidChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    labelModeChange: EventEmitter<LabelMode>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    maxChange: EventEmitter<Date | null | number | string | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    minChange: EventEmitter<Date | null | number | string | undefined>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    multiViewChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    openedChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    openOnFieldClickChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    readOnlyChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    rtlEnabledChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    showClearButtonChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    showDropDownButtonChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    spellcheckChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    startDateChange: EventEmitter<Date | null | number | string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    startDateInputAttrChange: EventEmitter<any>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    startDateLabelChange: EventEmitter<string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    startDateNameChange: EventEmitter<string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    startDateOutOfRangeMessageChange: EventEmitter<string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    startDatePlaceholderChange: EventEmitter<string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    startDateTextChange: EventEmitter<string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    stylingModeChange: EventEmitter<EditorStyle>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    tabIndexChange: EventEmitter<number>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    todayButtonTextChange: EventEmitter<string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    useMaskBehaviorChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    validationErrorChange: EventEmitter<any | null>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    validationErrorsChange: EventEmitter<Array<any> | null>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    validationMessageModeChange: EventEmitter<ValidationMessageMode>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    validationMessagePositionChange: EventEmitter<Mode | Position>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    validationStatusChange: EventEmitter<ValidationStatus>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    valueChange: EventEmitter<Array<Date | null | number | string>>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    valueChangeEventChange: EventEmitter<string>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    visibleChange: EventEmitter<boolean>;
    /**
    
     * This member supports the internal infrastructure and is not intended to be used directly from your code.
    
     */
    widthChange: EventEmitter<number | string | undefined>;
    /**
    
     * [descr:undefined]
    
    
     */
    onBlur: EventEmitter<any>;
    change(_: any): void;
    touched: (_: any) => void;
    constructor(elementRef: ElementRef, ngZone: NgZone, templateHost: DxTemplateHost, _watcherHelper: WatcherHelper, _idh: IterableDifferHelper, optionHost: NestedOptionHost, transferState: TransferState, platformId: any);
    protected _createInstance(element: any, options: any): DxDateRangeBox;
    writeValue(value: any): void;
    setDisabledState(isDisabled: boolean): void;
    registerOnChange(fn: (_: any) => void): void;
    registerOnTouched(fn: () => void): void;
    _createWidget(element: any): void;
    ngOnDestroy(): void;
    ngOnChanges(changes: SimpleChanges): void;
    setupChanges(prop: string, changes: SimpleChanges): void;
    ngDoCheck(): void;
    _setOption(name: string, value: any): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxDateRangeBoxComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxDateRangeBoxComponent, "dx-date-range-box", never, { "acceptCustomValue": { "alias": "acceptCustomValue"; "required": false; }; "accessKey": { "alias": "accessKey"; "required": false; }; "activeStateEnabled": { "alias": "activeStateEnabled"; "required": false; }; "applyButtonText": { "alias": "applyButtonText"; "required": false; }; "applyValueMode": { "alias": "applyValueMode"; "required": false; }; "buttons": { "alias": "buttons"; "required": false; }; "calendarOptions": { "alias": "calendarOptions"; "required": false; }; "cancelButtonText": { "alias": "cancelButtonText"; "required": false; }; "dateSerializationFormat": { "alias": "dateSerializationFormat"; "required": false; }; "deferRendering": { "alias": "deferRendering"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "disableOutOfRangeSelection": { "alias": "disableOutOfRangeSelection"; "required": false; }; "displayFormat": { "alias": "displayFormat"; "required": false; }; "dropDownButtonTemplate": { "alias": "dropDownButtonTemplate"; "required": false; }; "dropDownOptions": { "alias": "dropDownOptions"; "required": false; }; "elementAttr": { "alias": "elementAttr"; "required": false; }; "endDate": { "alias": "endDate"; "required": false; }; "endDateInputAttr": { "alias": "endDateInputAttr"; "required": false; }; "endDateLabel": { "alias": "endDateLabel"; "required": false; }; "endDateName": { "alias": "endDateName"; "required": false; }; "endDateOutOfRangeMessage": { "alias": "endDateOutOfRangeMessage"; "required": false; }; "endDatePlaceholder": { "alias": "endDatePlaceholder"; "required": false; }; "endDateText": { "alias": "endDateText"; "required": false; }; "focusStateEnabled": { "alias": "focusStateEnabled"; "required": false; }; "height": { "alias": "height"; "required": false; }; "hint": { "alias": "hint"; "required": false; }; "hoverStateEnabled": { "alias": "hoverStateEnabled"; "required": false; }; "invalidEndDateMessage": { "alias": "invalidEndDateMessage"; "required": false; }; "invalidStartDateMessage": { "alias": "invalidStartDateMessage"; "required": false; }; "isDirty": { "alias": "isDirty"; "required": false; }; "isValid": { "alias": "isValid"; "required": false; }; "labelMode": { "alias": "labelMode"; "required": false; }; "max": { "alias": "max"; "required": false; }; "min": { "alias": "min"; "required": false; }; "multiView": { "alias": "multiView"; "required": false; }; "opened": { "alias": "opened"; "required": false; }; "openOnFieldClick": { "alias": "openOnFieldClick"; "required": false; }; "readOnly": { "alias": "readOnly"; "required": false; }; "rtlEnabled": { "alias": "rtlEnabled"; "required": false; }; "showClearButton": { "alias": "showClearButton"; "required": false; }; "showDropDownButton": { "alias": "showDropDownButton"; "required": false; }; "spellcheck": { "alias": "spellcheck"; "required": false; }; "startDate": { "alias": "startDate"; "required": false; }; "startDateInputAttr": { "alias": "startDateInputAttr"; "required": false; }; "startDateLabel": { "alias": "startDateLabel"; "required": false; }; "startDateName": { "alias": "startDateName"; "required": false; }; "startDateOutOfRangeMessage": { "alias": "startDateOutOfRangeMessage"; "required": false; }; "startDatePlaceholder": { "alias": "startDatePlaceholder"; "required": false; }; "startDateText": { "alias": "startDateText"; "required": false; }; "stylingMode": { "alias": "stylingMode"; "required": false; }; "tabIndex": { "alias": "tabIndex"; "required": false; }; "todayButtonText": { "alias": "todayButtonText"; "required": false; }; "useMaskBehavior": { "alias": "useMaskBehavior"; "required": false; }; "validationError": { "alias": "validationError"; "required": false; }; "validationErrors": { "alias": "validationErrors"; "required": false; }; "validationMessageMode": { "alias": "validationMessageMode"; "required": false; }; "validationMessagePosition": { "alias": "validationMessagePosition"; "required": false; }; "validationStatus": { "alias": "validationStatus"; "required": false; }; "value": { "alias": "value"; "required": false; }; "valueChangeEvent": { "alias": "valueChangeEvent"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, { "onChange": "onChange"; "onClosed": "onClosed"; "onContentReady": "onContentReady"; "onCopy": "onCopy"; "onCut": "onCut"; "onDisposing": "onDisposing"; "onEnterKey": "onEnterKey"; "onFocusIn": "onFocusIn"; "onFocusOut": "onFocusOut"; "onInitialized": "onInitialized"; "onInput": "onInput"; "onKeyDown": "onKeyDown"; "onKeyUp": "onKeyUp"; "onOpened": "onOpened"; "onOptionChanged": "onOptionChanged"; "onPaste": "onPaste"; "onValueChanged": "onValueChanged"; "acceptCustomValueChange": "acceptCustomValueChange"; "accessKeyChange": "accessKeyChange"; "activeStateEnabledChange": "activeStateEnabledChange"; "applyButtonTextChange": "applyButtonTextChange"; "applyValueModeChange": "applyValueModeChange"; "buttonsChange": "buttonsChange"; "calendarOptionsChange": "calendarOptionsChange"; "cancelButtonTextChange": "cancelButtonTextChange"; "dateSerializationFormatChange": "dateSerializationFormatChange"; "deferRenderingChange": "deferRenderingChange"; "disabledChange": "disabledChange"; "disableOutOfRangeSelectionChange": "disableOutOfRangeSelectionChange"; "displayFormatChange": "displayFormatChange"; "dropDownButtonTemplateChange": "dropDownButtonTemplateChange"; "dropDownOptionsChange": "dropDownOptionsChange"; "elementAttrChange": "elementAttrChange"; "endDateChange": "endDateChange"; "endDateInputAttrChange": "endDateInputAttrChange"; "endDateLabelChange": "endDateLabelChange"; "endDateNameChange": "endDateNameChange"; "endDateOutOfRangeMessageChange": "endDateOutOfRangeMessageChange"; "endDatePlaceholderChange": "endDatePlaceholderChange"; "endDateTextChange": "endDateTextChange"; "focusStateEnabledChange": "focusStateEnabledChange"; "heightChange": "heightChange"; "hintChange": "hintChange"; "hoverStateEnabledChange": "hoverStateEnabledChange"; "invalidEndDateMessageChange": "invalidEndDateMessageChange"; "invalidStartDateMessageChange": "invalidStartDateMessageChange"; "isDirtyChange": "isDirtyChange"; "isValidChange": "isValidChange"; "labelModeChange": "labelModeChange"; "maxChange": "maxChange"; "minChange": "minChange"; "multiViewChange": "multiViewChange"; "openedChange": "openedChange"; "openOnFieldClickChange": "openOnFieldClickChange"; "readOnlyChange": "readOnlyChange"; "rtlEnabledChange": "rtlEnabledChange"; "showClearButtonChange": "showClearButtonChange"; "showDropDownButtonChange": "showDropDownButtonChange"; "spellcheckChange": "spellcheckChange"; "startDateChange": "startDateChange"; "startDateInputAttrChange": "startDateInputAttrChange"; "startDateLabelChange": "startDateLabelChange"; "startDateNameChange": "startDateNameChange"; "startDateOutOfRangeMessageChange": "startDateOutOfRangeMessageChange"; "startDatePlaceholderChange": "startDatePlaceholderChange"; "startDateTextChange": "startDateTextChange"; "stylingModeChange": "stylingModeChange"; "tabIndexChange": "tabIndexChange"; "todayButtonTextChange": "todayButtonTextChange"; "useMaskBehaviorChange": "useMaskBehaviorChange"; "validationErrorChange": "validationErrorChange"; "validationErrorsChange": "validationErrorsChange"; "validationMessageModeChange": "validationMessageModeChange"; "validationMessagePositionChange": "validationMessagePositionChange"; "validationStatusChange": "validationStatusChange"; "valueChange": "valueChange"; "valueChangeEventChange": "valueChangeEventChange"; "visibleChange": "visibleChange"; "widthChange": "widthChange"; "onBlur": "onBlur"; }, ["_buttonsContentChildren", "_toolbarItemsContentChildren"], never, true, never>;
}
declare class DxDateRangeBoxModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxDateRangeBoxModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxDateRangeBoxModule, never, [typeof DxDateRangeBoxComponent, typeof i1.DxiButtonModule, typeof i1.DxoOptionsModule, typeof i1.DxoCalendarOptionsModule, typeof i1.DxoDisplayFormatModule, typeof i1.DxoDropDownOptionsModule, typeof i1.DxoAnimationModule, typeof i1.DxoHideModule, typeof i1.DxoFromModule, typeof i1.DxoPositionModule, typeof i1.DxoAtModule, typeof i1.DxoBoundaryOffsetModule, typeof i1.DxoCollisionModule, typeof i1.DxoMyModule, typeof i1.DxoOffsetModule, typeof i1.DxoToModule, typeof i1.DxoShowModule, typeof i2.DxoDateRangeBoxAnimationModule, typeof i2.DxoDateRangeBoxAtModule, typeof i2.DxoDateRangeBoxBoundaryOffsetModule, typeof i2.DxiDateRangeBoxButtonModule, typeof i2.DxoDateRangeBoxCalendarOptionsModule, typeof i2.DxoDateRangeBoxCollisionModule, typeof i2.DxoDateRangeBoxDisplayFormatModule, typeof i2.DxoDateRangeBoxDropDownOptionsModule, typeof i2.DxoDateRangeBoxFromModule, typeof i2.DxoDateRangeBoxHideModule, typeof i2.DxoDateRangeBoxMyModule, typeof i2.DxoDateRangeBoxOffsetModule, typeof i2.DxoDateRangeBoxOptionsModule, typeof i2.DxoDateRangeBoxPositionModule, typeof i2.DxoDateRangeBoxShowModule, typeof i2.DxoDateRangeBoxToModule, typeof i2.DxiDateRangeBoxToolbarItemModule, typeof i3.DxIntegrationModule, typeof i3.DxTemplateModule], [typeof DxDateRangeBoxComponent, typeof i1.DxiButtonModule, typeof i1.DxoOptionsModule, typeof i1.DxoCalendarOptionsModule, typeof i1.DxoDisplayFormatModule, typeof i1.DxoDropDownOptionsModule, typeof i1.DxoAnimationModule, typeof i1.DxoHideModule, typeof i1.DxoFromModule, typeof i1.DxoPositionModule, typeof i1.DxoAtModule, typeof i1.DxoBoundaryOffsetModule, typeof i1.DxoCollisionModule, typeof i1.DxoMyModule, typeof i1.DxoOffsetModule, typeof i1.DxoToModule, typeof i1.DxoShowModule, typeof i2.DxoDateRangeBoxAnimationModule, typeof i2.DxoDateRangeBoxAtModule, typeof i2.DxoDateRangeBoxBoundaryOffsetModule, typeof i2.DxiDateRangeBoxButtonModule, typeof i2.DxoDateRangeBoxCalendarOptionsModule, typeof i2.DxoDateRangeBoxCollisionModule, typeof i2.DxoDateRangeBoxDisplayFormatModule, typeof i2.DxoDateRangeBoxDropDownOptionsModule, typeof i2.DxoDateRangeBoxFromModule, typeof i2.DxoDateRangeBoxHideModule, typeof i2.DxoDateRangeBoxMyModule, typeof i2.DxoDateRangeBoxOffsetModule, typeof i2.DxoDateRangeBoxOptionsModule, typeof i2.DxoDateRangeBoxPositionModule, typeof i2.DxoDateRangeBoxShowModule, typeof i2.DxoDateRangeBoxToModule, typeof i2.DxiDateRangeBoxToolbarItemModule, typeof i3.DxTemplateModule]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxDateRangeBoxModule>;
}

export { DxDateRangeBoxComponent, DxDateRangeBoxModule };
//# sourceMappingURL=index.d.ts.map
