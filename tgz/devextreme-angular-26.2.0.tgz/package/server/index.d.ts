import * as i0 from '@angular/core';

declare class DxServerModule {
    constructor(platformId: any);
    static ɵfac: i0.ɵɵFactoryDeclaration<DxServerModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxServerModule, never, never, never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxServerModule>;
}

export { DxServerModule };
//# sourceMappingURL=index.d.ts.map
