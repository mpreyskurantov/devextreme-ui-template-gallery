import { InjectionToken } from '@angular/core';

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare const PROPERTY_TOKEN_items: InjectionToken<string>;
declare const PROPERTY_TOKEN_buttons: InjectionToken<string>;
declare const PROPERTY_TOKEN_toolbarItems: InjectionToken<string>;
declare const PROPERTY_TOKEN_validationRules: InjectionToken<string>;
declare const PROPERTY_TOKEN_changes: InjectionToken<string>;
declare const PROPERTY_TOKEN_columns: InjectionToken<string>;
declare const PROPERTY_TOKEN_customOperations: InjectionToken<string>;
declare const PROPERTY_TOKEN_fields: InjectionToken<string>;
declare const PROPERTY_TOKEN_tabs: InjectionToken<string>;
declare const PROPERTY_TOKEN_annotations: InjectionToken<string>;
declare const PROPERTY_TOKEN_breaks: InjectionToken<string>;
declare const PROPERTY_TOKEN_constantLines: InjectionToken<string>;
declare const PROPERTY_TOKEN_panes: InjectionToken<string>;
declare const PROPERTY_TOKEN_series: InjectionToken<string>;
declare const PROPERTY_TOKEN_strips: InjectionToken<string>;
declare const PROPERTY_TOKEN_valueAxis: InjectionToken<string>;
declare const PROPERTY_TOKEN_alerts: InjectionToken<string>;
declare const PROPERTY_TOKEN_attachments: InjectionToken<string>;
declare const PROPERTY_TOKEN_typingUsers: InjectionToken<string>;
declare const PROPERTY_TOKEN_ranges: InjectionToken<string>;
declare const PROPERTY_TOKEN_groupItems: InjectionToken<string>;
declare const PROPERTY_TOKEN_sortByGroupSummaryInfo: InjectionToken<string>;
declare const PROPERTY_TOKEN_totalItems: InjectionToken<string>;
declare const PROPERTY_TOKEN_commands: InjectionToken<string>;
declare const PROPERTY_TOKEN_connectionPoints: InjectionToken<string>;
declare const PROPERTY_TOKEN_customShapes: InjectionToken<string>;
declare const PROPERTY_TOKEN_groups: InjectionToken<string>;
declare const PROPERTY_TOKEN_fileSelectionItems: InjectionToken<string>;
declare const PROPERTY_TOKEN_stripLines: InjectionToken<string>;
declare const PROPERTY_TOKEN_mentions: InjectionToken<string>;
declare const PROPERTY_TOKEN_menuItems: InjectionToken<string>;
declare const PROPERTY_TOKEN_locations: InjectionToken<string>;
declare const PROPERTY_TOKEN_markers: InjectionToken<string>;
declare const PROPERTY_TOKEN_routes: InjectionToken<string>;
declare const PROPERTY_TOKEN_cols: InjectionToken<string>;
declare const PROPERTY_TOKEN_location: InjectionToken<string>;
declare const PROPERTY_TOKEN_rows: InjectionToken<string>;
declare const PROPERTY_TOKEN_resources: InjectionToken<string>;
declare const PROPERTY_TOKEN_views: InjectionToken<string>;
declare const PROPERTY_TOKEN_layers: InjectionToken<string>;
declare const PROPERTY_TOKEN_legends: InjectionToken<string>;
declare const PROPERTY_TOKEN_center: InjectionToken<string>;

export { PROPERTY_TOKEN_alerts, PROPERTY_TOKEN_annotations, PROPERTY_TOKEN_attachments, PROPERTY_TOKEN_breaks, PROPERTY_TOKEN_buttons, PROPERTY_TOKEN_center, PROPERTY_TOKEN_changes, PROPERTY_TOKEN_cols, PROPERTY_TOKEN_columns, PROPERTY_TOKEN_commands, PROPERTY_TOKEN_connectionPoints, PROPERTY_TOKEN_constantLines, PROPERTY_TOKEN_customOperations, PROPERTY_TOKEN_customShapes, PROPERTY_TOKEN_fields, PROPERTY_TOKEN_fileSelectionItems, PROPERTY_TOKEN_groupItems, PROPERTY_TOKEN_groups, PROPERTY_TOKEN_items, PROPERTY_TOKEN_layers, PROPERTY_TOKEN_legends, PROPERTY_TOKEN_location, PROPERTY_TOKEN_locations, PROPERTY_TOKEN_markers, PROPERTY_TOKEN_mentions, PROPERTY_TOKEN_menuItems, PROPERTY_TOKEN_panes, PROPERTY_TOKEN_ranges, PROPERTY_TOKEN_resources, PROPERTY_TOKEN_routes, PROPERTY_TOKEN_rows, PROPERTY_TOKEN_series, PROPERTY_TOKEN_sortByGroupSummaryInfo, PROPERTY_TOKEN_stripLines, PROPERTY_TOKEN_strips, PROPERTY_TOKEN_tabs, PROPERTY_TOKEN_toolbarItems, PROPERTY_TOKEN_totalItems, PROPERTY_TOKEN_typingUsers, PROPERTY_TOKEN_validationRules, PROPERTY_TOKEN_valueAxis, PROPERTY_TOKEN_views };
//# sourceMappingURL=index.d.ts.map
