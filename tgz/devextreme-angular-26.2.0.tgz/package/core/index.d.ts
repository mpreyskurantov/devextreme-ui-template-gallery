import * as i0 from '@angular/core';
import { TemplateRef, ViewContainerRef, Renderer2, NgZone, EventEmitter, QueryList, ElementRef, OnChanges, OnInit, DoCheck, AfterContentChecked, AfterViewInit, AfterViewChecked, TransferState, SimpleChanges, IterableDiffers } from '@angular/core';
import { XhrFactory } from '@angular/common';

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

interface IDxTemplateHost {
    setTemplate: (template: DxTemplateDirective) => any;
}
declare class DxTemplateHost {
    host: IDxTemplateHost;
    setHost(host: IDxTemplateHost): void;
    setTemplate(template: DxTemplateDirective): void;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare const DX_TEMPLATE_WRAPPER_CLASS = "dx-template-wrapper";
declare class RenderData {
    model: any;
    index: number;
    container: any;
}
declare class DxTemplateDirective {
    private readonly templateRef;
    private readonly viewContainerRef;
    private readonly renderer;
    private readonly zone;
    set dxTemplateOf(value: any);
    name: string;
    constructor(templateRef: TemplateRef<any>, viewContainerRef: ViewContainerRef, templateHost: DxTemplateHost, renderer: Renderer2, zone: NgZone);
    private renderTemplate;
    render(renderData: RenderData): any;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxTemplateDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<DxTemplateDirective, "[dxTemplate]", never, { "dxTemplateOf": { "alias": "dxTemplateOf"; "required": false; }; }, {}, never, never, true, never>;
}
declare class DxTemplateModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DxTemplateModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxTemplateModule, never, [typeof DxTemplateDirective], [typeof DxTemplateDirective]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxTemplateModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class NgEventsStrategy {
    private readonly instance;
    private readonly zone;
    private subscriptions;
    private events;
    constructor(instance: any, zone: NgZone);
    hasEvent(name: string): boolean;
    fireEvent(name: any, args: any): void;
    on(name: string | object, handler?: Function): void;
    off(name: any, handler: any): void;
    dispose(): void;
    addEmitter(eventName: string, emitter: EventEmitter<any>): void;
    private getEmitter;
}
declare class EmitterHelper {
    private readonly zone;
    private component;
    lockedValueChangeEvent: boolean;
    constructor(zone: NgZone, component: DxComponent);
    fireNgEvent(eventName: string, eventArgs: any): void;
    createEmitters(events: any[]): void;
}

declare class WatcherHelper {
    private readonly _watchers;
    getWatchMethod(): (valueGetter: any, valueChangeCallback: any, options: any) => () => void;
    private _isDifferentValues;
    private _toComparable;
    private _checkObjectsFields;
    checkWatchers(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<WatcherHelper, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<WatcherHelper>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

interface INestedOptionContainer {
    instance: any;
    isLinked: boolean;
    removedNestedComponents: string[];
    optionChangedHandlers: EventEmitter<any>;
    recreatedNestedComponents: any[];
    resetOptions: (collectionName?: string) => void;
    isRecreated: (name: string) => boolean;
}
type IOptionPathGetter = () => string;
declare abstract class BaseNestedOption implements INestedOptionContainer, ICollectionNestedOptionContainer {
    protected _host: INestedOptionContainer;
    protected _hostOptionPath: IOptionPathGetter;
    private readonly _collectionContainerImpl;
    protected _initialOptions: {};
    protected abstract get _optionPath(): string;
    protected abstract _fullOptionPath(): string;
    constructor();
    protected _optionChangedHandler(e: any): void;
    protected _createEventEmitters(events: any): void;
    protected _getOption(name: string): any;
    protected _setOption(name: string, value: any): void;
    protected _addRemovedOption(name: string): void;
    protected _deleteRemovedOptions(name: string): void;
    protected _addRecreatedComponent(): void;
    protected _getOptionPath(): string;
    setHost(host: INestedOptionContainer, optionPath: IOptionPathGetter): void;
    setChildren<T extends ICollectionNestedOption>(propertyName: string, items: QueryList<T>): any;
    _filterItems(items: QueryList<BaseNestedOption>): BaseNestedOption[];
    get instance(): any;
    get resetOptions(): (collectionName?: string) => void;
    get isRecreated(): (name: string) => boolean;
    get removedNestedComponents(): string[];
    set removedNestedComponents(value: string[]);
    get recreatedNestedComponents(): any[];
    set recreatedNestedComponents(value: any[]);
    get isLinked(): boolean;
    get optionChangedHandlers(): EventEmitter<any>;
    static ɵfac: i0.ɵɵFactoryDeclaration<BaseNestedOption, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<BaseNestedOption, "ng-component", never, {}, {}, never, never, true, never>;
}
interface ICollectionNestedOptionContainer {
    setChildren: <T extends ICollectionNestedOption>(propertyName: string, items: QueryList<T>) => any;
}
declare class CollectionNestedOptionContainerImpl implements ICollectionNestedOptionContainer {
    private readonly _setOption;
    private readonly _filterItems?;
    private _activatedQueries;
    constructor(_setOption: Function, _filterItems?: Function);
    setChildren<T extends ICollectionNestedOption>(propertyName: string, items: QueryList<T>): void;
}
declare abstract class NestedOption extends BaseNestedOption {
    setHost(host: INestedOptionContainer, optionPath: IOptionPathGetter): void;
    protected _fullOptionPath(): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<NestedOption, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<NestedOption, "ng-component", never, {}, {}, never, never, true, never>;
}
interface ICollectionNestedOption {
    _index: number;
    _value: object;
}
declare abstract class CollectionNestedOption extends BaseNestedOption implements ICollectionNestedOption {
    _index: number;
    protected _fullOptionPath(): string;
    get _value(): {};
    get isLinked(): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<CollectionNestedOption, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CollectionNestedOption, "ng-component", never, {}, {}, never, never, true, never>;
}
interface IOptionWithTemplate extends BaseNestedOption {
    template: any;
}
declare function extractTemplate(option: IOptionWithTemplate, element: ElementRef, renderer: Renderer2, document: any): void;
declare class NestedOptionHost {
    private _host;
    private _optionPath;
    getHost(): INestedOptionContainer;
    setHost(host: INestedOptionContainer, optionPath?: IOptionPathGetter): void;
    setNestedOption(nestedOption: BaseNestedOption): void;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare const getServerStateKey: () => any;
declare abstract class DxComponent implements OnChanges, OnInit, DoCheck, AfterContentChecked, AfterViewInit, AfterViewChecked, INestedOptionContainer, ICollectionNestedOptionContainer, IDxTemplateHost {
    protected element: ElementRef;
    private readonly ngZone;
    private readonly watcherHelper;
    private readonly transferState;
    private readonly platformId;
    private _initialOptions;
    protected _optionsToUpdate: any;
    private readonly _collectionContainerImpl;
    eventHelper: EmitterHelper;
    optionChangedHandlers: EventEmitter<any>;
    templates: DxTemplateDirective[];
    instance: any;
    isLinked: boolean;
    changedOptions: {};
    removedNestedComponents: string[];
    recreatedNestedComponents: any[];
    widgetUpdateLocked: boolean;
    templateUpdateRequired: boolean;
    private _updateTemplates;
    private _initEvents;
    private _initOptions;
    private _initPlatform;
    protected _createEventEmitters(events: any): void;
    _shouldOptionChange(name: string, value: any): boolean;
    clearChangedOptions(): void;
    protected _getOption(name: string): any;
    lockWidgetUpdate(): void;
    unlockWidgetUpdate(): void;
    protected _setOption(name: string, value: any): void;
    protected abstract _createInstance(element: any, options: any): any;
    protected _createWidget(element: any): void;
    protected _destroyWidget(): void;
    protected _setChildren(propertyName: any, value: any, className: any): void;
    constructor(element: ElementRef, ngZone: NgZone, templateHost: DxTemplateHost, watcherHelper: WatcherHelper, transferState: TransferState, platformId: any);
    ngOnChanges(changes: SimpleChanges): void;
    ngOnInit(): void;
    ngDoCheck(): void;
    ngAfterContentChecked(): void;
    ngAfterViewInit(): void;
    ngAfterViewChecked(): void;
    applyOptions(): void;
    resetOptions(collectionName?: string): void;
    isRecreated(name: string): boolean;
    setTemplate(template: DxTemplateDirective): void;
    contentChildren: {};
    checkContentChildren<T>(propertyName: string, items: QueryList<T>, className: string): boolean;
    setContentChildren<T>(propertyName: string, items: QueryList<T>, className: string): void;
    setChildren<T extends ICollectionNestedOption>(propertyName: string, items: QueryList<T>): any;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxComponent, "ng-component", never, {}, {}, never, never, true, never>;
}
declare abstract class DxComponentExtension extends DxComponent implements OnInit, AfterViewInit {
    createInstance(element: any): void;
    ngOnInit(): void;
    ngAfterViewInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxComponentExtension, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DxComponentExtension, "ng-component", never, {}, {}, never, never, true, never>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxIntegrationModule {
    static initialized: boolean;
    constructor(document: any, ngZone: NgZone, xhrFactory: XhrFactory);
    static ɵfac: i0.ɵɵFactoryDeclaration<DxIntegrationModule, [null, null, { optional: true; }]>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxIntegrationModule, never, never, never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxIntegrationModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class IterableDifferHelper {
    private readonly _differs;
    private _host;
    private _propertyDiffers;
    constructor(_differs: IterableDiffers);
    setHost(host: DxComponent): void;
    setup(prop: string, changes: SimpleChanges): void;
    setupSingle(prop: string, value: any): boolean;
    getChanges(prop: string, value: any): any;
    checkChangedOptions(propName: string, hostValue: any): boolean;
    doCheck(prop: string): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<IterableDifferHelper, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<IterableDifferHelper>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

declare class DxServerTransferStateModule {
    private readonly state;
    private readonly platformId;
    constructor(state: TransferState, platformId: any);
    generateKey(args: any): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<DxServerTransferStateModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DxServerTransferStateModule, never, never, never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DxServerTransferStateModule>;
}

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
declare function getElement(element: any): any;

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */
declare const WARNING_CODES: {
    readonly LEGACY_CONFIG_COMPONENT_USED: {
        readonly code: "W3001";
        readonly template: string;
    };
};
type WarningId = keyof typeof WARNING_CODES;
type WarningDefinition = typeof WARNING_CODES[WarningId];

/*!
 * devextreme-angular
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

type TemplatePrimitive = string | number | boolean;
type TemplateArgs = TemplatePrimitive[] | Record<string, TemplatePrimitive>;
declare function logWarning(warning: WarningDefinition, args?: TemplateArgs): void;

export { BaseNestedOption, CollectionNestedOption, CollectionNestedOptionContainerImpl, DX_TEMPLATE_WRAPPER_CLASS, DxComponent, DxComponentExtension, DxIntegrationModule, DxServerTransferStateModule, DxTemplateDirective, DxTemplateHost, DxTemplateModule, EmitterHelper, IterableDifferHelper, NestedOption, NestedOptionHost, NgEventsStrategy, RenderData, WatcherHelper, extractTemplate, getElement, getServerStateKey, logWarning };
export type { ICollectionNestedOption, ICollectionNestedOptionContainer, IDxTemplateHost, INestedOptionContainer, IOptionPathGetter, IOptionWithTemplate, TemplateArgs, WarningDefinition, WarningId };
//# sourceMappingURL=index.d.ts.map
