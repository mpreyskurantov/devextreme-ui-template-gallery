/*!
 * devextreme-vue
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

import { PropType } from "vue";
import FilterBuilder, { Properties } from "devextreme/ui/filter_builder";
import { dxFilterBuilderCustomOperation, dxFilterBuilderField, GroupOperation, ContentReadyEvent, DisposingEvent, EditorPreparedEvent, EditorPreparingEvent, InitializedEvent, OptionChangedEvent, ValueChangedEvent, FieldInfo } from "devextreme/ui/filter_builder";
import { DataType } from "devextreme/common";
import { DataSourceOptions } from "devextreme/common/data";
import { Store } from "devextreme/data/store";
type AccessibleOptions = Pick<Properties, "accessKey" | "activeStateEnabled" | "allowHierarchicalFields" | "customOperations" | "disabled" | "elementAttr" | "fields" | "filterOperationDescriptions" | "focusStateEnabled" | "groupOperationDescriptions" | "groupOperations" | "height" | "hint" | "hoverStateEnabled" | "maxGroupLevel" | "onContentReady" | "onDisposing" | "onEditorPrepared" | "onEditorPreparing" | "onInitialized" | "onOptionChanged" | "onValueChanged" | "rtlEnabled" | "tabIndex" | "value" | "visible" | "width">;
interface DxFilterBuilder extends AccessibleOptions {
    readonly instance?: FilterBuilder;
}
declare const DxFilterBuilder: import("vue").DefineComponent<{
    accessKey: StringConstructor;
    activeStateEnabled: BooleanConstructor;
    allowHierarchicalFields: BooleanConstructor;
    customOperations: PropType<dxFilterBuilderCustomOperation[]>;
    disabled: BooleanConstructor;
    elementAttr: PropType<Record<string, any>>;
    fields: PropType<dxFilterBuilderField[]>;
    filterOperationDescriptions: PropType<Record<string, any>>;
    focusStateEnabled: BooleanConstructor;
    groupOperationDescriptions: PropType<Record<string, any>>;
    groupOperations: PropType<GroupOperation[]>;
    height: (NumberConstructor | StringConstructor)[];
    hint: StringConstructor;
    hoverStateEnabled: BooleanConstructor;
    maxGroupLevel: NumberConstructor;
    onContentReady: PropType<(e: ContentReadyEvent) => void>;
    onDisposing: PropType<(e: DisposingEvent) => void>;
    onEditorPrepared: PropType<(e: EditorPreparedEvent) => void>;
    onEditorPreparing: PropType<(e: EditorPreparingEvent) => void>;
    onInitialized: PropType<(e: InitializedEvent) => void>;
    onOptionChanged: PropType<(e: OptionChangedEvent) => void>;
    onValueChanged: PropType<(e: ValueChangedEvent) => void>;
    rtlEnabled: BooleanConstructor;
    tabIndex: NumberConstructor;
    value: PropType<string | any[] | (() => any)>;
    visible: BooleanConstructor;
    width: (NumberConstructor | StringConstructor)[];
}, unknown, unknown, {
    instance(): FilterBuilder;
}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:accessKey": null;
    "update:activeStateEnabled": null;
    "update:allowHierarchicalFields": null;
    "update:customOperations": null;
    "update:disabled": null;
    "update:elementAttr": null;
    "update:fields": null;
    "update:filterOperationDescriptions": null;
    "update:focusStateEnabled": null;
    "update:groupOperationDescriptions": null;
    "update:groupOperations": null;
    "update:height": null;
    "update:hint": null;
    "update:hoverStateEnabled": null;
    "update:maxGroupLevel": null;
    "update:onContentReady": null;
    "update:onDisposing": null;
    "update:onEditorPrepared": null;
    "update:onEditorPreparing": null;
    "update:onInitialized": null;
    "update:onOptionChanged": null;
    "update:onValueChanged": null;
    "update:rtlEnabled": null;
    "update:tabIndex": null;
    "update:value": null;
    "update:visible": null;
    "update:width": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    accessKey: StringConstructor;
    activeStateEnabled: BooleanConstructor;
    allowHierarchicalFields: BooleanConstructor;
    customOperations: PropType<dxFilterBuilderCustomOperation[]>;
    disabled: BooleanConstructor;
    elementAttr: PropType<Record<string, any>>;
    fields: PropType<dxFilterBuilderField[]>;
    filterOperationDescriptions: PropType<Record<string, any>>;
    focusStateEnabled: BooleanConstructor;
    groupOperationDescriptions: PropType<Record<string, any>>;
    groupOperations: PropType<GroupOperation[]>;
    height: (NumberConstructor | StringConstructor)[];
    hint: StringConstructor;
    hoverStateEnabled: BooleanConstructor;
    maxGroupLevel: NumberConstructor;
    onContentReady: PropType<(e: ContentReadyEvent) => void>;
    onDisposing: PropType<(e: DisposingEvent) => void>;
    onEditorPrepared: PropType<(e: EditorPreparedEvent) => void>;
    onEditorPreparing: PropType<(e: EditorPreparingEvent) => void>;
    onInitialized: PropType<(e: InitializedEvent) => void>;
    onOptionChanged: PropType<(e: OptionChangedEvent) => void>;
    onValueChanged: PropType<(e: ValueChangedEvent) => void>;
    rtlEnabled: BooleanConstructor;
    tabIndex: NumberConstructor;
    value: PropType<string | any[] | (() => any)>;
    visible: BooleanConstructor;
    width: (NumberConstructor | StringConstructor)[];
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:disabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:elementAttr"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onDisposing"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onInitialized"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onOptionChanged"?: ((...args: any[]) => any) | undefined;
    "onUpdate:rtlEnabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:height"?: ((...args: any[]) => any) | undefined;
    "onUpdate:width"?: ((...args: any[]) => any) | undefined;
    "onUpdate:visible"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoverStateEnabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onContentReady"?: ((...args: any[]) => any) | undefined;
    "onUpdate:accessKey"?: ((...args: any[]) => any) | undefined;
    "onUpdate:activeStateEnabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:focusStateEnabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hint"?: ((...args: any[]) => any) | undefined;
    "onUpdate:tabIndex"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onValueChanged"?: ((...args: any[]) => any) | undefined;
    "onUpdate:value"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onEditorPrepared"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onEditorPreparing"?: ((...args: any[]) => any) | undefined;
    "onUpdate:allowHierarchicalFields"?: ((...args: any[]) => any) | undefined;
    "onUpdate:customOperations"?: ((...args: any[]) => any) | undefined;
    "onUpdate:fields"?: ((...args: any[]) => any) | undefined;
    "onUpdate:filterOperationDescriptions"?: ((...args: any[]) => any) | undefined;
    "onUpdate:groupOperationDescriptions"?: ((...args: any[]) => any) | undefined;
    "onUpdate:groupOperations"?: ((...args: any[]) => any) | undefined;
    "onUpdate:maxGroupLevel"?: ((...args: any[]) => any) | undefined;
}, {
    disabled: boolean;
    rtlEnabled: boolean;
    visible: boolean;
    hoverStateEnabled: boolean;
    activeStateEnabled: boolean;
    focusStateEnabled: boolean;
    allowHierarchicalFields: boolean;
}>;
declare const DxCustomOperation: import("vue").DefineComponent<{
    calculateFilterExpression: PropType<(filterValue: any, field: dxFilterBuilderField) => string | (() => any) | Array<any>>;
    caption: StringConstructor;
    customizeText: PropType<(fieldInfo: FieldInfo) => string>;
    dataTypes: PropType<DataType[]>;
    editorTemplate: {};
    hasValue: BooleanConstructor;
    icon: StringConstructor;
    name: StringConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:calculateFilterExpression": null;
    "update:caption": null;
    "update:customizeText": null;
    "update:dataTypes": null;
    "update:editorTemplate": null;
    "update:hasValue": null;
    "update:icon": null;
    "update:name": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    calculateFilterExpression: PropType<(filterValue: any, field: dxFilterBuilderField) => string | (() => any) | Array<any>>;
    caption: StringConstructor;
    customizeText: PropType<(fieldInfo: FieldInfo) => string>;
    dataTypes: PropType<DataType[]>;
    editorTemplate: {};
    hasValue: BooleanConstructor;
    icon: StringConstructor;
    name: StringConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:name"?: ((...args: any[]) => any) | undefined;
    "onUpdate:customizeText"?: ((...args: any[]) => any) | undefined;
    "onUpdate:icon"?: ((...args: any[]) => any) | undefined;
    "onUpdate:calculateFilterExpression"?: ((...args: any[]) => any) | undefined;
    "onUpdate:caption"?: ((...args: any[]) => any) | undefined;
    "onUpdate:dataTypes"?: ((...args: any[]) => any) | undefined;
    "onUpdate:editorTemplate"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hasValue"?: ((...args: any[]) => any) | undefined;
}, {
    hasValue: boolean;
}>;
declare const DxField: import("vue").DefineComponent<{
    calculateFilterExpression: PropType<(filterValue: any, selectedFilterOperation: string) => string | (() => any) | Array<any>>;
    caption: StringConstructor;
    customizeText: PropType<(fieldInfo: FieldInfo) => string>;
    dataField: StringConstructor;
    dataType: PropType<DataType>;
    editorOptions: {};
    editorTemplate: {};
    falseText: StringConstructor;
    filterOperations: PropType<string[]>;
    format: PropType<string | Record<string, any> | import("devextreme/common/core/localization").FormatObject | ((value: number | Date) => string) | ((value: Date) => string) | ((value: number) => string) | Intl.DateTimeFormatOptions | Intl.NumberFormatOptions | ((value: number | Date) => string) | undefined>;
    lookup: PropType<Record<string, any>>;
    name: StringConstructor;
    trueText: StringConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:calculateFilterExpression": null;
    "update:caption": null;
    "update:customizeText": null;
    "update:dataField": null;
    "update:dataType": null;
    "update:editorOptions": null;
    "update:editorTemplate": null;
    "update:falseText": null;
    "update:filterOperations": null;
    "update:format": null;
    "update:lookup": null;
    "update:name": null;
    "update:trueText": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    calculateFilterExpression: PropType<(filterValue: any, selectedFilterOperation: string) => string | (() => any) | Array<any>>;
    caption: StringConstructor;
    customizeText: PropType<(fieldInfo: FieldInfo) => string>;
    dataField: StringConstructor;
    dataType: PropType<DataType>;
    editorOptions: {};
    editorTemplate: {};
    falseText: StringConstructor;
    filterOperations: PropType<string[]>;
    format: PropType<string | Record<string, any> | import("devextreme/common/core/localization").FormatObject | ((value: number | Date) => string) | ((value: Date) => string) | ((value: number) => string) | Intl.DateTimeFormatOptions | Intl.NumberFormatOptions | ((value: number | Date) => string) | undefined>;
    lookup: PropType<Record<string, any>>;
    name: StringConstructor;
    trueText: StringConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:name"?: ((...args: any[]) => any) | undefined;
    "onUpdate:dataField"?: ((...args: any[]) => any) | undefined;
    "onUpdate:customizeText"?: ((...args: any[]) => any) | undefined;
    "onUpdate:format"?: ((...args: any[]) => any) | undefined;
    "onUpdate:editorOptions"?: ((...args: any[]) => any) | undefined;
    "onUpdate:calculateFilterExpression"?: ((...args: any[]) => any) | undefined;
    "onUpdate:caption"?: ((...args: any[]) => any) | undefined;
    "onUpdate:dataType"?: ((...args: any[]) => any) | undefined;
    "onUpdate:falseText"?: ((...args: any[]) => any) | undefined;
    "onUpdate:filterOperations"?: ((...args: any[]) => any) | undefined;
    "onUpdate:lookup"?: ((...args: any[]) => any) | undefined;
    "onUpdate:trueText"?: ((...args: any[]) => any) | undefined;
    "onUpdate:editorTemplate"?: ((...args: any[]) => any) | undefined;
}, {}>;
declare const DxFilterOperationDescriptions: import("vue").DefineComponent<{
    between: StringConstructor;
    contains: StringConstructor;
    endsWith: StringConstructor;
    equal: StringConstructor;
    greaterThan: StringConstructor;
    greaterThanOrEqual: StringConstructor;
    isBlank: StringConstructor;
    isNotBlank: StringConstructor;
    lessThan: StringConstructor;
    lessThanOrEqual: StringConstructor;
    notContains: StringConstructor;
    notEqual: StringConstructor;
    startsWith: StringConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:between": null;
    "update:contains": null;
    "update:endsWith": null;
    "update:equal": null;
    "update:greaterThan": null;
    "update:greaterThanOrEqual": null;
    "update:isBlank": null;
    "update:isNotBlank": null;
    "update:lessThan": null;
    "update:lessThanOrEqual": null;
    "update:notContains": null;
    "update:notEqual": null;
    "update:startsWith": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    between: StringConstructor;
    contains: StringConstructor;
    endsWith: StringConstructor;
    equal: StringConstructor;
    greaterThan: StringConstructor;
    greaterThanOrEqual: StringConstructor;
    isBlank: StringConstructor;
    isNotBlank: StringConstructor;
    lessThan: StringConstructor;
    lessThanOrEqual: StringConstructor;
    notContains: StringConstructor;
    notEqual: StringConstructor;
    startsWith: StringConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:between"?: ((...args: any[]) => any) | undefined;
    "onUpdate:contains"?: ((...args: any[]) => any) | undefined;
    "onUpdate:endsWith"?: ((...args: any[]) => any) | undefined;
    "onUpdate:equal"?: ((...args: any[]) => any) | undefined;
    "onUpdate:greaterThan"?: ((...args: any[]) => any) | undefined;
    "onUpdate:greaterThanOrEqual"?: ((...args: any[]) => any) | undefined;
    "onUpdate:isBlank"?: ((...args: any[]) => any) | undefined;
    "onUpdate:isNotBlank"?: ((...args: any[]) => any) | undefined;
    "onUpdate:lessThan"?: ((...args: any[]) => any) | undefined;
    "onUpdate:lessThanOrEqual"?: ((...args: any[]) => any) | undefined;
    "onUpdate:notContains"?: ((...args: any[]) => any) | undefined;
    "onUpdate:notEqual"?: ((...args: any[]) => any) | undefined;
    "onUpdate:startsWith"?: ((...args: any[]) => any) | undefined;
}, {}>;
declare const DxFormat: import("vue").DefineComponent<{
    currency: StringConstructor;
    formatter: PropType<(value: number | Date) => string>;
    parser: PropType<(value: string) => number | Date>;
    precision: NumberConstructor;
    type: PropType<string>;
    useCurrencyAccountingStyle: BooleanConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:currency": null;
    "update:formatter": null;
    "update:parser": null;
    "update:precision": null;
    "update:type": null;
    "update:useCurrencyAccountingStyle": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    currency: StringConstructor;
    formatter: PropType<(value: number | Date) => string>;
    parser: PropType<(value: string) => number | Date>;
    precision: NumberConstructor;
    type: PropType<string>;
    useCurrencyAccountingStyle: BooleanConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:type"?: ((...args: any[]) => any) | undefined;
    "onUpdate:currency"?: ((...args: any[]) => any) | undefined;
    "onUpdate:formatter"?: ((...args: any[]) => any) | undefined;
    "onUpdate:parser"?: ((...args: any[]) => any) | undefined;
    "onUpdate:precision"?: ((...args: any[]) => any) | undefined;
    "onUpdate:useCurrencyAccountingStyle"?: ((...args: any[]) => any) | undefined;
}, {
    useCurrencyAccountingStyle: boolean;
}>;
declare const DxGroupOperationDescriptions: import("vue").DefineComponent<{
    and: StringConstructor;
    notAnd: StringConstructor;
    notOr: StringConstructor;
    or: StringConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:and": null;
    "update:notAnd": null;
    "update:notOr": null;
    "update:or": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    and: StringConstructor;
    notAnd: StringConstructor;
    notOr: StringConstructor;
    or: StringConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:and"?: ((...args: any[]) => any) | undefined;
    "onUpdate:notAnd"?: ((...args: any[]) => any) | undefined;
    "onUpdate:notOr"?: ((...args: any[]) => any) | undefined;
    "onUpdate:or"?: ((...args: any[]) => any) | undefined;
}, {}>;
declare const DxLookup: import("vue").DefineComponent<{
    allowClearing: BooleanConstructor;
    dataSource: PropType<any[] | Record<string, any> | DataSourceOptions<any, any, any, any> | Store<any, any>>;
    displayExpr: PropType<string | ((data: any) => string)>;
    valueExpr: PropType<string | ((data: any) => string | number | boolean)>;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:allowClearing": null;
    "update:dataSource": null;
    "update:displayExpr": null;
    "update:valueExpr": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    allowClearing: BooleanConstructor;
    dataSource: PropType<any[] | Record<string, any> | DataSourceOptions<any, any, any, any> | Store<any, any>>;
    displayExpr: PropType<string | ((data: any) => string)>;
    valueExpr: PropType<string | ((data: any) => string | number | boolean)>;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:dataSource"?: ((...args: any[]) => any) | undefined;
    "onUpdate:displayExpr"?: ((...args: any[]) => any) | undefined;
    "onUpdate:allowClearing"?: ((...args: any[]) => any) | undefined;
    "onUpdate:valueExpr"?: ((...args: any[]) => any) | undefined;
}, {
    allowClearing: boolean;
}>;
export default DxFilterBuilder;
export { DxFilterBuilder, DxCustomOperation, DxField, DxFilterOperationDescriptions, DxFormat, DxGroupOperationDescriptions, DxLookup };
import type * as DxFilterBuilderTypes from "devextreme/ui/filter_builder_types";
export { DxFilterBuilderTypes };
