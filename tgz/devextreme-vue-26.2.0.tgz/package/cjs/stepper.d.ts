/*!
 * devextreme-vue
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

export { ExplicitTypes } from "devextreme/ui/stepper";
import { PropType } from "vue";
import Stepper, { Properties } from "devextreme/ui/stepper";
import DataSource from "devextreme/data/data_source";
import { dxStepperItem, DisposingEvent, InitializedEvent, ItemClickEvent, ItemContextMenuEvent, ItemRenderedEvent, OptionChangedEvent, SelectionChangedEvent, SelectionChangingEvent } from "devextreme/ui/stepper";
import { DataSourceOptions } from "devextreme/common/data";
import { Store } from "devextreme/data/store";
import { Orientation } from "devextreme/common";
type AccessibleOptions = Pick<Properties, "accessKey" | "activeStateEnabled" | "dataSource" | "disabled" | "elementAttr" | "focusStateEnabled" | "height" | "hint" | "hoverStateEnabled" | "items" | "itemTemplate" | "linear" | "onDisposing" | "onInitialized" | "onItemClick" | "onItemContextMenu" | "onItemRendered" | "onOptionChanged" | "onSelectionChanged" | "onSelectionChanging" | "orientation" | "rtlEnabled" | "selectedIndex" | "selectedItem" | "selectOnFocus" | "tabIndex" | "visible" | "width">;
interface DxStepper extends AccessibleOptions {
    readonly instance?: Stepper;
}
declare const DxStepper: import("vue").DefineComponent<{
    accessKey: StringConstructor;
    activeStateEnabled: BooleanConstructor;
    dataSource: PropType<string | Record<string, any> | DataSource<any, any> | DataSourceOptions<any, any, any, any> | Store<any, any> | dxStepperItem[] | null>;
    disabled: BooleanConstructor;
    elementAttr: PropType<Record<string, any>>;
    focusStateEnabled: BooleanConstructor;
    height: (NumberConstructor | StringConstructor)[];
    hint: StringConstructor;
    hoverStateEnabled: BooleanConstructor;
    items: PropType<dxStepperItem[]>;
    itemTemplate: {};
    linear: BooleanConstructor;
    onDisposing: PropType<(e: DisposingEvent) => void>;
    onInitialized: PropType<(e: InitializedEvent) => void>;
    onItemClick: PropType<(e: ItemClickEvent) => void>;
    onItemContextMenu: PropType<(e: ItemContextMenuEvent) => void>;
    onItemRendered: PropType<(e: ItemRenderedEvent) => void>;
    onOptionChanged: PropType<(e: OptionChangedEvent) => void>;
    onSelectionChanged: PropType<(e: SelectionChangedEvent) => void>;
    onSelectionChanging: PropType<(e: SelectionChangingEvent) => void>;
    orientation: PropType<Orientation>;
    rtlEnabled: BooleanConstructor;
    selectedIndex: NumberConstructor;
    selectedItem: {};
    selectOnFocus: BooleanConstructor;
    tabIndex: NumberConstructor;
    visible: BooleanConstructor;
    width: (NumberConstructor | StringConstructor)[];
}, unknown, unknown, {
    instance(): Stepper;
}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:accessKey": null;
    "update:activeStateEnabled": null;
    "update:dataSource": null;
    "update:disabled": null;
    "update:elementAttr": null;
    "update:focusStateEnabled": null;
    "update:height": null;
    "update:hint": null;
    "update:hoverStateEnabled": null;
    "update:items": null;
    "update:itemTemplate": null;
    "update:linear": null;
    "update:onDisposing": null;
    "update:onInitialized": null;
    "update:onItemClick": null;
    "update:onItemContextMenu": null;
    "update:onItemRendered": null;
    "update:onOptionChanged": null;
    "update:onSelectionChanged": null;
    "update:onSelectionChanging": null;
    "update:orientation": null;
    "update:rtlEnabled": null;
    "update:selectedIndex": null;
    "update:selectedItem": null;
    "update:selectOnFocus": null;
    "update:tabIndex": null;
    "update:visible": null;
    "update:width": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    accessKey: StringConstructor;
    activeStateEnabled: BooleanConstructor;
    dataSource: PropType<string | Record<string, any> | DataSource<any, any> | DataSourceOptions<any, any, any, any> | Store<any, any> | dxStepperItem[] | null>;
    disabled: BooleanConstructor;
    elementAttr: PropType<Record<string, any>>;
    focusStateEnabled: BooleanConstructor;
    height: (NumberConstructor | StringConstructor)[];
    hint: StringConstructor;
    hoverStateEnabled: BooleanConstructor;
    items: PropType<dxStepperItem[]>;
    itemTemplate: {};
    linear: BooleanConstructor;
    onDisposing: PropType<(e: DisposingEvent) => void>;
    onInitialized: PropType<(e: InitializedEvent) => void>;
    onItemClick: PropType<(e: ItemClickEvent) => void>;
    onItemContextMenu: PropType<(e: ItemContextMenuEvent) => void>;
    onItemRendered: PropType<(e: ItemRenderedEvent) => void>;
    onOptionChanged: PropType<(e: OptionChangedEvent) => void>;
    onSelectionChanged: PropType<(e: SelectionChangedEvent) => void>;
    onSelectionChanging: PropType<(e: SelectionChangingEvent) => void>;
    orientation: PropType<Orientation>;
    rtlEnabled: BooleanConstructor;
    selectedIndex: NumberConstructor;
    selectedItem: {};
    selectOnFocus: BooleanConstructor;
    tabIndex: NumberConstructor;
    visible: BooleanConstructor;
    width: (NumberConstructor | StringConstructor)[];
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:disabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:elementAttr"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onDisposing"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onInitialized"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onOptionChanged"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onSelectionChanged"?: ((...args: any[]) => any) | undefined;
    "onUpdate:rtlEnabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:height"?: ((...args: any[]) => any) | undefined;
    "onUpdate:width"?: ((...args: any[]) => any) | undefined;
    "onUpdate:visible"?: ((...args: any[]) => any) | undefined;
    "onUpdate:dataSource"?: ((...args: any[]) => any) | undefined;
    "onUpdate:orientation"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoverStateEnabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:items"?: ((...args: any[]) => any) | undefined;
    "onUpdate:itemTemplate"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onItemClick"?: ((...args: any[]) => any) | undefined;
    "onUpdate:accessKey"?: ((...args: any[]) => any) | undefined;
    "onUpdate:activeStateEnabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:focusStateEnabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hint"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onItemContextMenu"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onItemRendered"?: ((...args: any[]) => any) | undefined;
    "onUpdate:tabIndex"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onSelectionChanging"?: ((...args: any[]) => any) | undefined;
    "onUpdate:selectedIndex"?: ((...args: any[]) => any) | undefined;
    "onUpdate:selectedItem"?: ((...args: any[]) => any) | undefined;
    "onUpdate:linear"?: ((...args: any[]) => any) | undefined;
    "onUpdate:selectOnFocus"?: ((...args: any[]) => any) | undefined;
}, {
    disabled: boolean;
    rtlEnabled: boolean;
    visible: boolean;
    hoverStateEnabled: boolean;
    activeStateEnabled: boolean;
    focusStateEnabled: boolean;
    linear: boolean;
    selectOnFocus: boolean;
}>;
declare const DxItem: import("vue").DefineComponent<{
    disabled: BooleanConstructor;
    hint: StringConstructor;
    icon: StringConstructor;
    isValid: BooleanConstructor;
    label: StringConstructor;
    optional: BooleanConstructor;
    template: {};
    text: StringConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:disabled": null;
    "update:hint": null;
    "update:icon": null;
    "update:isValid": null;
    "update:label": null;
    "update:optional": null;
    "update:template": null;
    "update:text": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    disabled: BooleanConstructor;
    hint: StringConstructor;
    icon: StringConstructor;
    isValid: BooleanConstructor;
    label: StringConstructor;
    optional: BooleanConstructor;
    template: {};
    text: StringConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:disabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:template"?: ((...args: any[]) => any) | undefined;
    "onUpdate:text"?: ((...args: any[]) => any) | undefined;
    "onUpdate:label"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hint"?: ((...args: any[]) => any) | undefined;
    "onUpdate:icon"?: ((...args: any[]) => any) | undefined;
    "onUpdate:isValid"?: ((...args: any[]) => any) | undefined;
    "onUpdate:optional"?: ((...args: any[]) => any) | undefined;
}, {
    disabled: boolean;
    isValid: boolean;
    optional: boolean;
}>;
export default DxStepper;
export { DxStepper, DxItem };
import type * as DxStepperTypes from "devextreme/ui/stepper_types";
export { DxStepperTypes };
