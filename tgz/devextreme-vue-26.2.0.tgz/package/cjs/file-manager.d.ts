/*!
 * devextreme-vue
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

import { PropType } from "vue";
import FileManager, { Properties } from "devextreme/ui/file_manager";
import FileSystemItem from "devextreme/file_management/file_system_item";
import { dxFileManagerContextMenu, dxFileManagerDetailsColumn, ContentReadyEvent, ContextMenuItemClickEvent, ContextMenuShowingEvent, CurrentDirectoryChangedEvent, DirectoryCreatedEvent, DirectoryCreatingEvent, DisposingEvent, ErrorOccurredEvent, FileUploadedEvent, FileUploadingEvent, FocusedItemChangedEvent, InitializedEvent, ItemCopiedEvent, ItemCopyingEvent, ItemDeletedEvent, ItemDeletingEvent, ItemDownloadingEvent, ItemMovedEvent, ItemMovingEvent, ItemRenamedEvent, ItemRenamingEvent, OptionChangedEvent, SelectedFileOpenedEvent, SelectionChangedEvent, ToolbarItemClickEvent, dxFileManagerToolbar, dxFileManagerContextMenuItem, FileManagerPredefinedContextMenuItem, FileManagerPredefinedToolbarItem, FileManagerItemViewMode, dxFileManagerToolbarItem } from "devextreme/ui/file_manager";
import { SingleOrMultiple, HorizontalAlignment, DataType, SortOrder, ToolbarItemLocation, ToolbarItemComponent } from "devextreme/common";
import { LocateInMenuMode, ShowTextMode } from "devextreme/ui/toolbar";
type AccessibleOptions = Pick<Properties, "accessKey" | "activeStateEnabled" | "allowedFileExtensions" | "contextMenu" | "currentPath" | "currentPathKeys" | "customizeDetailColumns" | "customizeThumbnail" | "disabled" | "elementAttr" | "fileSystemProvider" | "focusedItemKey" | "focusStateEnabled" | "height" | "hint" | "hoverStateEnabled" | "itemView" | "notifications" | "onContentReady" | "onContextMenuItemClick" | "onContextMenuShowing" | "onCurrentDirectoryChanged" | "onDirectoryCreated" | "onDirectoryCreating" | "onDisposing" | "onErrorOccurred" | "onFileUploaded" | "onFileUploading" | "onFocusedItemChanged" | "onInitialized" | "onItemCopied" | "onItemCopying" | "onItemDeleted" | "onItemDeleting" | "onItemDownloading" | "onItemMoved" | "onItemMoving" | "onItemRenamed" | "onItemRenaming" | "onOptionChanged" | "onSelectedFileOpened" | "onSelectionChanged" | "onToolbarItemClick" | "permissions" | "rootFolderName" | "rtlEnabled" | "selectedItemKeys" | "selectionMode" | "tabIndex" | "toolbar" | "upload" | "visible" | "width">;
interface DxFileManager extends AccessibleOptions {
    readonly instance?: FileManager;
}
declare const DxFileManager: import("vue").DefineComponent<{
    accessKey: StringConstructor;
    activeStateEnabled: BooleanConstructor;
    allowedFileExtensions: PropType<string[]>;
    contextMenu: PropType<Record<string, any> | dxFileManagerContextMenu>;
    currentPath: StringConstructor;
    currentPathKeys: PropType<string[]>;
    customizeDetailColumns: PropType<(columns: Array<dxFileManagerDetailsColumn>) => Array<dxFileManagerDetailsColumn>>;
    customizeThumbnail: PropType<(fileSystemItem: FileSystemItem) => string>;
    disabled: BooleanConstructor;
    elementAttr: PropType<Record<string, any>>;
    fileSystemProvider: {};
    focusedItemKey: StringConstructor;
    focusStateEnabled: BooleanConstructor;
    height: (NumberConstructor | StringConstructor)[];
    hint: StringConstructor;
    hoverStateEnabled: BooleanConstructor;
    itemView: PropType<Record<string, any>>;
    notifications: PropType<Record<string, any>>;
    onContentReady: PropType<(e: ContentReadyEvent) => void>;
    onContextMenuItemClick: PropType<(e: ContextMenuItemClickEvent) => void>;
    onContextMenuShowing: PropType<(e: ContextMenuShowingEvent) => void>;
    onCurrentDirectoryChanged: PropType<(e: CurrentDirectoryChangedEvent) => void>;
    onDirectoryCreated: PropType<(e: DirectoryCreatedEvent) => void>;
    onDirectoryCreating: PropType<(e: DirectoryCreatingEvent) => void>;
    onDisposing: PropType<(e: DisposingEvent) => void>;
    onErrorOccurred: PropType<(e: ErrorOccurredEvent) => void>;
    onFileUploaded: PropType<(e: FileUploadedEvent) => void>;
    onFileUploading: PropType<(e: FileUploadingEvent) => void>;
    onFocusedItemChanged: PropType<(e: FocusedItemChangedEvent) => void>;
    onInitialized: PropType<(e: InitializedEvent) => void>;
    onItemCopied: PropType<(e: ItemCopiedEvent) => void>;
    onItemCopying: PropType<(e: ItemCopyingEvent) => void>;
    onItemDeleted: PropType<(e: ItemDeletedEvent) => void>;
    onItemDeleting: PropType<(e: ItemDeletingEvent) => void>;
    onItemDownloading: PropType<(e: ItemDownloadingEvent) => void>;
    onItemMoved: PropType<(e: ItemMovedEvent) => void>;
    onItemMoving: PropType<(e: ItemMovingEvent) => void>;
    onItemRenamed: PropType<(e: ItemRenamedEvent) => void>;
    onItemRenaming: PropType<(e: ItemRenamingEvent) => void>;
    onOptionChanged: PropType<(e: OptionChangedEvent) => void>;
    onSelectedFileOpened: PropType<(e: SelectedFileOpenedEvent) => void>;
    onSelectionChanged: PropType<(e: SelectionChangedEvent) => void>;
    onToolbarItemClick: PropType<(e: ToolbarItemClickEvent) => void>;
    permissions: PropType<Record<string, any>>;
    rootFolderName: StringConstructor;
    rtlEnabled: BooleanConstructor;
    selectedItemKeys: PropType<string[]>;
    selectionMode: PropType<SingleOrMultiple>;
    tabIndex: NumberConstructor;
    toolbar: PropType<Record<string, any> | dxFileManagerToolbar>;
    upload: PropType<Record<string, any>>;
    visible: BooleanConstructor;
    width: (NumberConstructor | StringConstructor)[];
}, unknown, unknown, {
    instance(): FileManager;
}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:accessKey": null;
    "update:activeStateEnabled": null;
    "update:allowedFileExtensions": null;
    "update:contextMenu": null;
    "update:currentPath": null;
    "update:currentPathKeys": null;
    "update:customizeDetailColumns": null;
    "update:customizeThumbnail": null;
    "update:disabled": null;
    "update:elementAttr": null;
    "update:fileSystemProvider": null;
    "update:focusedItemKey": null;
    "update:focusStateEnabled": null;
    "update:height": null;
    "update:hint": null;
    "update:hoverStateEnabled": null;
    "update:itemView": null;
    "update:notifications": null;
    "update:onContentReady": null;
    "update:onContextMenuItemClick": null;
    "update:onContextMenuShowing": null;
    "update:onCurrentDirectoryChanged": null;
    "update:onDirectoryCreated": null;
    "update:onDirectoryCreating": null;
    "update:onDisposing": null;
    "update:onErrorOccurred": null;
    "update:onFileUploaded": null;
    "update:onFileUploading": null;
    "update:onFocusedItemChanged": null;
    "update:onInitialized": null;
    "update:onItemCopied": null;
    "update:onItemCopying": null;
    "update:onItemDeleted": null;
    "update:onItemDeleting": null;
    "update:onItemDownloading": null;
    "update:onItemMoved": null;
    "update:onItemMoving": null;
    "update:onItemRenamed": null;
    "update:onItemRenaming": null;
    "update:onOptionChanged": null;
    "update:onSelectedFileOpened": null;
    "update:onSelectionChanged": null;
    "update:onToolbarItemClick": null;
    "update:permissions": null;
    "update:rootFolderName": null;
    "update:rtlEnabled": null;
    "update:selectedItemKeys": null;
    "update:selectionMode": null;
    "update:tabIndex": null;
    "update:toolbar": null;
    "update:upload": null;
    "update:visible": null;
    "update:width": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    accessKey: StringConstructor;
    activeStateEnabled: BooleanConstructor;
    allowedFileExtensions: PropType<string[]>;
    contextMenu: PropType<Record<string, any> | dxFileManagerContextMenu>;
    currentPath: StringConstructor;
    currentPathKeys: PropType<string[]>;
    customizeDetailColumns: PropType<(columns: Array<dxFileManagerDetailsColumn>) => Array<dxFileManagerDetailsColumn>>;
    customizeThumbnail: PropType<(fileSystemItem: FileSystemItem) => string>;
    disabled: BooleanConstructor;
    elementAttr: PropType<Record<string, any>>;
    fileSystemProvider: {};
    focusedItemKey: StringConstructor;
    focusStateEnabled: BooleanConstructor;
    height: (NumberConstructor | StringConstructor)[];
    hint: StringConstructor;
    hoverStateEnabled: BooleanConstructor;
    itemView: PropType<Record<string, any>>;
    notifications: PropType<Record<string, any>>;
    onContentReady: PropType<(e: ContentReadyEvent) => void>;
    onContextMenuItemClick: PropType<(e: ContextMenuItemClickEvent) => void>;
    onContextMenuShowing: PropType<(e: ContextMenuShowingEvent) => void>;
    onCurrentDirectoryChanged: PropType<(e: CurrentDirectoryChangedEvent) => void>;
    onDirectoryCreated: PropType<(e: DirectoryCreatedEvent) => void>;
    onDirectoryCreating: PropType<(e: DirectoryCreatingEvent) => void>;
    onDisposing: PropType<(e: DisposingEvent) => void>;
    onErrorOccurred: PropType<(e: ErrorOccurredEvent) => void>;
    onFileUploaded: PropType<(e: FileUploadedEvent) => void>;
    onFileUploading: PropType<(e: FileUploadingEvent) => void>;
    onFocusedItemChanged: PropType<(e: FocusedItemChangedEvent) => void>;
    onInitialized: PropType<(e: InitializedEvent) => void>;
    onItemCopied: PropType<(e: ItemCopiedEvent) => void>;
    onItemCopying: PropType<(e: ItemCopyingEvent) => void>;
    onItemDeleted: PropType<(e: ItemDeletedEvent) => void>;
    onItemDeleting: PropType<(e: ItemDeletingEvent) => void>;
    onItemDownloading: PropType<(e: ItemDownloadingEvent) => void>;
    onItemMoved: PropType<(e: ItemMovedEvent) => void>;
    onItemMoving: PropType<(e: ItemMovingEvent) => void>;
    onItemRenamed: PropType<(e: ItemRenamedEvent) => void>;
    onItemRenaming: PropType<(e: ItemRenamingEvent) => void>;
    onOptionChanged: PropType<(e: OptionChangedEvent) => void>;
    onSelectedFileOpened: PropType<(e: SelectedFileOpenedEvent) => void>;
    onSelectionChanged: PropType<(e: SelectionChangedEvent) => void>;
    onToolbarItemClick: PropType<(e: ToolbarItemClickEvent) => void>;
    permissions: PropType<Record<string, any>>;
    rootFolderName: StringConstructor;
    rtlEnabled: BooleanConstructor;
    selectedItemKeys: PropType<string[]>;
    selectionMode: PropType<SingleOrMultiple>;
    tabIndex: NumberConstructor;
    toolbar: PropType<Record<string, any> | dxFileManagerToolbar>;
    upload: PropType<Record<string, any>>;
    visible: BooleanConstructor;
    width: (NumberConstructor | StringConstructor)[];
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:disabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:elementAttr"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onDisposing"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onInitialized"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onOptionChanged"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onSelectionChanged"?: ((...args: any[]) => any) | undefined;
    "onUpdate:rtlEnabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:height"?: ((...args: any[]) => any) | undefined;
    "onUpdate:width"?: ((...args: any[]) => any) | undefined;
    "onUpdate:visible"?: ((...args: any[]) => any) | undefined;
    "onUpdate:selectionMode"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoverStateEnabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onContentReady"?: ((...args: any[]) => any) | undefined;
    "onUpdate:accessKey"?: ((...args: any[]) => any) | undefined;
    "onUpdate:activeStateEnabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:focusStateEnabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hint"?: ((...args: any[]) => any) | undefined;
    "onUpdate:tabIndex"?: ((...args: any[]) => any) | undefined;
    "onUpdate:toolbar"?: ((...args: any[]) => any) | undefined;
    "onUpdate:selectedItemKeys"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onItemDeleted"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onItemDeleting"?: ((...args: any[]) => any) | undefined;
    "onUpdate:allowedFileExtensions"?: ((...args: any[]) => any) | undefined;
    "onUpdate:contextMenu"?: ((...args: any[]) => any) | undefined;
    "onUpdate:currentPath"?: ((...args: any[]) => any) | undefined;
    "onUpdate:currentPathKeys"?: ((...args: any[]) => any) | undefined;
    "onUpdate:customizeDetailColumns"?: ((...args: any[]) => any) | undefined;
    "onUpdate:customizeThumbnail"?: ((...args: any[]) => any) | undefined;
    "onUpdate:fileSystemProvider"?: ((...args: any[]) => any) | undefined;
    "onUpdate:focusedItemKey"?: ((...args: any[]) => any) | undefined;
    "onUpdate:itemView"?: ((...args: any[]) => any) | undefined;
    "onUpdate:notifications"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onContextMenuItemClick"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onContextMenuShowing"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onCurrentDirectoryChanged"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onDirectoryCreated"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onDirectoryCreating"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onErrorOccurred"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onFileUploaded"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onFileUploading"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onFocusedItemChanged"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onItemCopied"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onItemCopying"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onItemDownloading"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onItemMoved"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onItemMoving"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onItemRenamed"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onItemRenaming"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onSelectedFileOpened"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onToolbarItemClick"?: ((...args: any[]) => any) | undefined;
    "onUpdate:permissions"?: ((...args: any[]) => any) | undefined;
    "onUpdate:rootFolderName"?: ((...args: any[]) => any) | undefined;
    "onUpdate:upload"?: ((...args: any[]) => any) | undefined;
}, {
    disabled: boolean;
    rtlEnabled: boolean;
    visible: boolean;
    hoverStateEnabled: boolean;
    activeStateEnabled: boolean;
    focusStateEnabled: boolean;
}>;
declare const DxColumn: import("vue").DefineComponent<{
    alignment: PropType<HorizontalAlignment>;
    caption: StringConstructor;
    cssClass: StringConstructor;
    dataField: StringConstructor;
    dataType: PropType<DataType>;
    hidingPriority: NumberConstructor;
    sortIndex: NumberConstructor;
    sortOrder: PropType<SortOrder>;
    visible: BooleanConstructor;
    visibleIndex: NumberConstructor;
    width: (NumberConstructor | StringConstructor)[];
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:alignment": null;
    "update:caption": null;
    "update:cssClass": null;
    "update:dataField": null;
    "update:dataType": null;
    "update:hidingPriority": null;
    "update:sortIndex": null;
    "update:sortOrder": null;
    "update:visible": null;
    "update:visibleIndex": null;
    "update:width": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    alignment: PropType<HorizontalAlignment>;
    caption: StringConstructor;
    cssClass: StringConstructor;
    dataField: StringConstructor;
    dataType: PropType<DataType>;
    hidingPriority: NumberConstructor;
    sortIndex: NumberConstructor;
    sortOrder: PropType<SortOrder>;
    visible: BooleanConstructor;
    visibleIndex: NumberConstructor;
    width: (NumberConstructor | StringConstructor)[];
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:width"?: ((...args: any[]) => any) | undefined;
    "onUpdate:visible"?: ((...args: any[]) => any) | undefined;
    "onUpdate:dataField"?: ((...args: any[]) => any) | undefined;
    "onUpdate:cssClass"?: ((...args: any[]) => any) | undefined;
    "onUpdate:visibleIndex"?: ((...args: any[]) => any) | undefined;
    "onUpdate:alignment"?: ((...args: any[]) => any) | undefined;
    "onUpdate:caption"?: ((...args: any[]) => any) | undefined;
    "onUpdate:dataType"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hidingPriority"?: ((...args: any[]) => any) | undefined;
    "onUpdate:sortIndex"?: ((...args: any[]) => any) | undefined;
    "onUpdate:sortOrder"?: ((...args: any[]) => any) | undefined;
}, {
    visible: boolean;
}>;
declare const DxContextMenu: import("vue").DefineComponent<{
    items: PropType<(dxFileManagerContextMenuItem | FileManagerPredefinedContextMenuItem)[]>;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:items": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    items: PropType<(dxFileManagerContextMenuItem | FileManagerPredefinedContextMenuItem)[]>;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:items"?: ((...args: any[]) => any) | undefined;
}, {}>;
declare const DxContextMenuItem: import("vue").DefineComponent<{
    beginGroup: BooleanConstructor;
    closeMenuOnClick: BooleanConstructor;
    disabled: BooleanConstructor;
    icon: StringConstructor;
    items: PropType<dxFileManagerContextMenuItem[]>;
    name: PropType<string>;
    selectable: BooleanConstructor;
    selected: BooleanConstructor;
    text: StringConstructor;
    visible: BooleanConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:beginGroup": null;
    "update:closeMenuOnClick": null;
    "update:disabled": null;
    "update:icon": null;
    "update:items": null;
    "update:name": null;
    "update:selectable": null;
    "update:selected": null;
    "update:text": null;
    "update:visible": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    beginGroup: BooleanConstructor;
    closeMenuOnClick: BooleanConstructor;
    disabled: BooleanConstructor;
    icon: StringConstructor;
    items: PropType<dxFileManagerContextMenuItem[]>;
    name: PropType<string>;
    selectable: BooleanConstructor;
    selected: BooleanConstructor;
    text: StringConstructor;
    visible: BooleanConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:disabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:name"?: ((...args: any[]) => any) | undefined;
    "onUpdate:text"?: ((...args: any[]) => any) | undefined;
    "onUpdate:visible"?: ((...args: any[]) => any) | undefined;
    "onUpdate:items"?: ((...args: any[]) => any) | undefined;
    "onUpdate:icon"?: ((...args: any[]) => any) | undefined;
    "onUpdate:selected"?: ((...args: any[]) => any) | undefined;
    "onUpdate:beginGroup"?: ((...args: any[]) => any) | undefined;
    "onUpdate:closeMenuOnClick"?: ((...args: any[]) => any) | undefined;
    "onUpdate:selectable"?: ((...args: any[]) => any) | undefined;
}, {
    disabled: boolean;
    visible: boolean;
    selected: boolean;
    beginGroup: boolean;
    closeMenuOnClick: boolean;
    selectable: boolean;
}>;
declare const DxDetails: import("vue").DefineComponent<{
    columns: PropType<(string | dxFileManagerDetailsColumn)[]>;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:columns": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    columns: PropType<(string | dxFileManagerDetailsColumn)[]>;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:columns"?: ((...args: any[]) => any) | undefined;
}, {}>;
declare const DxFileSelectionItem: import("vue").DefineComponent<{
    cssClass: StringConstructor;
    disabled: BooleanConstructor;
    icon: StringConstructor;
    locateInMenu: PropType<LocateInMenuMode>;
    location: PropType<ToolbarItemLocation>;
    name: PropType<string>;
    options: {};
    showText: PropType<ShowTextMode>;
    text: StringConstructor;
    visible: BooleanConstructor;
    widget: PropType<ToolbarItemComponent>;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:cssClass": null;
    "update:disabled": null;
    "update:icon": null;
    "update:locateInMenu": null;
    "update:location": null;
    "update:name": null;
    "update:options": null;
    "update:showText": null;
    "update:text": null;
    "update:visible": null;
    "update:widget": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    cssClass: StringConstructor;
    disabled: BooleanConstructor;
    icon: StringConstructor;
    locateInMenu: PropType<LocateInMenuMode>;
    location: PropType<ToolbarItemLocation>;
    name: PropType<string>;
    options: {};
    showText: PropType<ShowTextMode>;
    text: StringConstructor;
    visible: BooleanConstructor;
    widget: PropType<ToolbarItemComponent>;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:disabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:name"?: ((...args: any[]) => any) | undefined;
    "onUpdate:text"?: ((...args: any[]) => any) | undefined;
    "onUpdate:visible"?: ((...args: any[]) => any) | undefined;
    "onUpdate:location"?: ((...args: any[]) => any) | undefined;
    "onUpdate:options"?: ((...args: any[]) => any) | undefined;
    "onUpdate:icon"?: ((...args: any[]) => any) | undefined;
    "onUpdate:cssClass"?: ((...args: any[]) => any) | undefined;
    "onUpdate:locateInMenu"?: ((...args: any[]) => any) | undefined;
    "onUpdate:showText"?: ((...args: any[]) => any) | undefined;
    "onUpdate:widget"?: ((...args: any[]) => any) | undefined;
}, {
    disabled: boolean;
    visible: boolean;
}>;
declare const DxItem: import("vue").DefineComponent<{
    beginGroup: BooleanConstructor;
    closeMenuOnClick: BooleanConstructor;
    cssClass: StringConstructor;
    disabled: BooleanConstructor;
    icon: StringConstructor;
    items: PropType<dxFileManagerContextMenuItem[]>;
    locateInMenu: PropType<LocateInMenuMode>;
    location: PropType<ToolbarItemLocation>;
    name: PropType<string>;
    options: {};
    selectable: BooleanConstructor;
    selected: BooleanConstructor;
    showText: PropType<ShowTextMode>;
    text: StringConstructor;
    visible: BooleanConstructor;
    widget: PropType<ToolbarItemComponent>;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:beginGroup": null;
    "update:closeMenuOnClick": null;
    "update:cssClass": null;
    "update:disabled": null;
    "update:icon": null;
    "update:items": null;
    "update:locateInMenu": null;
    "update:location": null;
    "update:name": null;
    "update:options": null;
    "update:selectable": null;
    "update:selected": null;
    "update:showText": null;
    "update:text": null;
    "update:visible": null;
    "update:widget": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    beginGroup: BooleanConstructor;
    closeMenuOnClick: BooleanConstructor;
    cssClass: StringConstructor;
    disabled: BooleanConstructor;
    icon: StringConstructor;
    items: PropType<dxFileManagerContextMenuItem[]>;
    locateInMenu: PropType<LocateInMenuMode>;
    location: PropType<ToolbarItemLocation>;
    name: PropType<string>;
    options: {};
    selectable: BooleanConstructor;
    selected: BooleanConstructor;
    showText: PropType<ShowTextMode>;
    text: StringConstructor;
    visible: BooleanConstructor;
    widget: PropType<ToolbarItemComponent>;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:disabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:name"?: ((...args: any[]) => any) | undefined;
    "onUpdate:text"?: ((...args: any[]) => any) | undefined;
    "onUpdate:visible"?: ((...args: any[]) => any) | undefined;
    "onUpdate:items"?: ((...args: any[]) => any) | undefined;
    "onUpdate:location"?: ((...args: any[]) => any) | undefined;
    "onUpdate:options"?: ((...args: any[]) => any) | undefined;
    "onUpdate:icon"?: ((...args: any[]) => any) | undefined;
    "onUpdate:selected"?: ((...args: any[]) => any) | undefined;
    "onUpdate:cssClass"?: ((...args: any[]) => any) | undefined;
    "onUpdate:locateInMenu"?: ((...args: any[]) => any) | undefined;
    "onUpdate:showText"?: ((...args: any[]) => any) | undefined;
    "onUpdate:widget"?: ((...args: any[]) => any) | undefined;
    "onUpdate:beginGroup"?: ((...args: any[]) => any) | undefined;
    "onUpdate:closeMenuOnClick"?: ((...args: any[]) => any) | undefined;
    "onUpdate:selectable"?: ((...args: any[]) => any) | undefined;
}, {
    disabled: boolean;
    visible: boolean;
    selected: boolean;
    beginGroup: boolean;
    closeMenuOnClick: boolean;
    selectable: boolean;
}>;
declare const DxItemView: import("vue").DefineComponent<{
    details: PropType<Record<string, any>>;
    mode: PropType<FileManagerItemViewMode>;
    showFolders: BooleanConstructor;
    showParentFolder: BooleanConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:details": null;
    "update:mode": null;
    "update:showFolders": null;
    "update:showParentFolder": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    details: PropType<Record<string, any>>;
    mode: PropType<FileManagerItemViewMode>;
    showFolders: BooleanConstructor;
    showParentFolder: BooleanConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:mode"?: ((...args: any[]) => any) | undefined;
    "onUpdate:details"?: ((...args: any[]) => any) | undefined;
    "onUpdate:showFolders"?: ((...args: any[]) => any) | undefined;
    "onUpdate:showParentFolder"?: ((...args: any[]) => any) | undefined;
}, {
    showFolders: boolean;
    showParentFolder: boolean;
}>;
declare const DxNotifications: import("vue").DefineComponent<{
    showPanel: BooleanConstructor;
    showPopup: BooleanConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:showPanel": null;
    "update:showPopup": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    showPanel: BooleanConstructor;
    showPopup: BooleanConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:showPanel"?: ((...args: any[]) => any) | undefined;
    "onUpdate:showPopup"?: ((...args: any[]) => any) | undefined;
}, {
    showPanel: boolean;
    showPopup: boolean;
}>;
declare const DxPermissions: import("vue").DefineComponent<{
    copy: BooleanConstructor;
    create: BooleanConstructor;
    delete: BooleanConstructor;
    download: BooleanConstructor;
    move: BooleanConstructor;
    rename: BooleanConstructor;
    upload: BooleanConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:copy": null;
    "update:create": null;
    "update:delete": null;
    "update:download": null;
    "update:move": null;
    "update:rename": null;
    "update:upload": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    copy: BooleanConstructor;
    create: BooleanConstructor;
    delete: BooleanConstructor;
    download: BooleanConstructor;
    move: BooleanConstructor;
    rename: BooleanConstructor;
    upload: BooleanConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:upload"?: ((...args: any[]) => any) | undefined;
    "onUpdate:copy"?: ((...args: any[]) => any) | undefined;
    "onUpdate:create"?: ((...args: any[]) => any) | undefined;
    "onUpdate:delete"?: ((...args: any[]) => any) | undefined;
    "onUpdate:download"?: ((...args: any[]) => any) | undefined;
    "onUpdate:move"?: ((...args: any[]) => any) | undefined;
    "onUpdate:rename"?: ((...args: any[]) => any) | undefined;
}, {
    delete: boolean;
    copy: boolean;
    upload: boolean;
    create: boolean;
    download: boolean;
    move: boolean;
    rename: boolean;
}>;
declare const DxToolbar: import("vue").DefineComponent<{
    fileSelectionItems: PropType<(FileManagerPredefinedToolbarItem | dxFileManagerToolbarItem)[]>;
    items: PropType<(FileManagerPredefinedToolbarItem | dxFileManagerToolbarItem)[]>;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:fileSelectionItems": null;
    "update:items": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    fileSelectionItems: PropType<(FileManagerPredefinedToolbarItem | dxFileManagerToolbarItem)[]>;
    items: PropType<(FileManagerPredefinedToolbarItem | dxFileManagerToolbarItem)[]>;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:items"?: ((...args: any[]) => any) | undefined;
    "onUpdate:fileSelectionItems"?: ((...args: any[]) => any) | undefined;
}, {}>;
declare const DxToolbarItem: import("vue").DefineComponent<{
    cssClass: StringConstructor;
    disabled: BooleanConstructor;
    icon: StringConstructor;
    locateInMenu: PropType<LocateInMenuMode>;
    location: PropType<ToolbarItemLocation>;
    name: PropType<string>;
    options: {};
    showText: PropType<ShowTextMode>;
    text: StringConstructor;
    visible: BooleanConstructor;
    widget: PropType<ToolbarItemComponent>;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:cssClass": null;
    "update:disabled": null;
    "update:icon": null;
    "update:locateInMenu": null;
    "update:location": null;
    "update:name": null;
    "update:options": null;
    "update:showText": null;
    "update:text": null;
    "update:visible": null;
    "update:widget": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    cssClass: StringConstructor;
    disabled: BooleanConstructor;
    icon: StringConstructor;
    locateInMenu: PropType<LocateInMenuMode>;
    location: PropType<ToolbarItemLocation>;
    name: PropType<string>;
    options: {};
    showText: PropType<ShowTextMode>;
    text: StringConstructor;
    visible: BooleanConstructor;
    widget: PropType<ToolbarItemComponent>;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:disabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:name"?: ((...args: any[]) => any) | undefined;
    "onUpdate:text"?: ((...args: any[]) => any) | undefined;
    "onUpdate:visible"?: ((...args: any[]) => any) | undefined;
    "onUpdate:location"?: ((...args: any[]) => any) | undefined;
    "onUpdate:options"?: ((...args: any[]) => any) | undefined;
    "onUpdate:icon"?: ((...args: any[]) => any) | undefined;
    "onUpdate:cssClass"?: ((...args: any[]) => any) | undefined;
    "onUpdate:locateInMenu"?: ((...args: any[]) => any) | undefined;
    "onUpdate:showText"?: ((...args: any[]) => any) | undefined;
    "onUpdate:widget"?: ((...args: any[]) => any) | undefined;
}, {
    disabled: boolean;
    visible: boolean;
}>;
declare const DxUpload: import("vue").DefineComponent<{
    chunkSize: NumberConstructor;
    maxFileSize: NumberConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:chunkSize": null;
    "update:maxFileSize": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    chunkSize: NumberConstructor;
    maxFileSize: NumberConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:chunkSize"?: ((...args: any[]) => any) | undefined;
    "onUpdate:maxFileSize"?: ((...args: any[]) => any) | undefined;
}, {}>;
export default DxFileManager;
export { DxFileManager, DxColumn, DxContextMenu, DxContextMenuItem, DxDetails, DxFileSelectionItem, DxItem, DxItemView, DxNotifications, DxPermissions, DxToolbar, DxToolbarItem, DxUpload };
import type * as DxFileManagerTypes from "devextreme/ui/file_manager_types";
export { DxFileManagerTypes };
