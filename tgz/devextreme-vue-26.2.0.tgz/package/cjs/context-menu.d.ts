/*!
 * devextreme-vue
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

export { ExplicitTypes } from "devextreme/ui/context_menu";
import { PropType } from "vue";
import ContextMenu, { Properties } from "devextreme/ui/context_menu";
import DataSource from "devextreme/data/data_source";
import { dxContextMenuItem, ContentReadyEvent, DisposingEvent, HiddenEvent, HidingEvent, InitializedEvent, ItemClickEvent, ItemContextMenuEvent, ItemRenderedEvent, OptionChangedEvent, PositioningEvent, SelectionChangedEvent, ShowingEvent, ShownEvent, ContextSubmenuDirection } from "devextreme/ui/context_menu";
import { DataSourceOptions } from "devextreme/common/data";
import { Store } from "devextreme/data/store";
import { event } from "devextreme/events/events.types";
import { PositionConfig, AnimationConfig, CollisionResolution, AnimationState, AnimationType, CollisionResolutionCombination } from "devextreme/common/core/animation";
import { SingleOrNone, SubmenuShowMode, HorizontalAlignment, VerticalAlignment, Direction, PositionAlignment } from "devextreme/common";
type AccessibleOptions = Pick<Properties, "accessKey" | "activeStateEnabled" | "animation" | "cssClass" | "dataSource" | "disabled" | "disabledExpr" | "displayExpr" | "elementAttr" | "focusStateEnabled" | "height" | "hideOnOutsideClick" | "hint" | "hoverStateEnabled" | "items" | "itemsExpr" | "itemTemplate" | "onContentReady" | "onDisposing" | "onHidden" | "onHiding" | "onInitialized" | "onItemClick" | "onItemContextMenu" | "onItemRendered" | "onOptionChanged" | "onPositioning" | "onSelectionChanged" | "onShowing" | "onShown" | "position" | "rtlEnabled" | "selectByClick" | "selectedExpr" | "selectedItem" | "selectionMode" | "showEvent" | "showSubmenuMode" | "submenuDirection" | "tabIndex" | "target" | "visible" | "width">;
interface DxContextMenu extends AccessibleOptions {
    readonly instance?: ContextMenu;
}
declare const DxContextMenu: import("vue").DefineComponent<{
    accessKey: StringConstructor;
    activeStateEnabled: BooleanConstructor;
    animation: PropType<Record<string, any>>;
    cssClass: StringConstructor;
    dataSource: PropType<string | Record<string, any> | DataSource<any, any> | DataSourceOptions<any, any, any, any> | Store<any, any> | dxContextMenuItem[] | null>;
    disabled: BooleanConstructor;
    disabledExpr: PropType<string | ((item: any) => boolean | undefined)>;
    displayExpr: PropType<string | ((item: any) => string)>;
    elementAttr: PropType<Record<string, any>>;
    focusStateEnabled: BooleanConstructor;
    height: (NumberConstructor | StringConstructor)[];
    hideOnOutsideClick: PropType<boolean | ((event: event) => boolean)>;
    hint: StringConstructor;
    hoverStateEnabled: BooleanConstructor;
    items: PropType<any[]>;
    itemsExpr: PropType<string | ((item: any) => Array<any> | undefined)>;
    itemTemplate: {};
    onContentReady: PropType<(e: ContentReadyEvent) => void>;
    onDisposing: PropType<(e: DisposingEvent) => void>;
    onHidden: PropType<(e: HiddenEvent) => void>;
    onHiding: PropType<(e: HidingEvent) => void>;
    onInitialized: PropType<(e: InitializedEvent) => void>;
    onItemClick: PropType<(e: ItemClickEvent) => void>;
    onItemContextMenu: PropType<(e: ItemContextMenuEvent) => void>;
    onItemRendered: PropType<(e: ItemRenderedEvent) => void>;
    onOptionChanged: PropType<(e: OptionChangedEvent) => void>;
    onPositioning: PropType<(e: PositioningEvent) => void>;
    onSelectionChanged: PropType<(e: SelectionChangedEvent) => void>;
    onShowing: PropType<(e: ShowingEvent) => void>;
    onShown: PropType<(e: ShownEvent) => void>;
    position: PropType<Record<string, any> | PositionConfig>;
    rtlEnabled: BooleanConstructor;
    selectByClick: BooleanConstructor;
    selectedExpr: PropType<string | ((item: any, value: boolean) => boolean | undefined)>;
    selectedItem: {};
    selectionMode: PropType<SingleOrNone>;
    showEvent: PropType<string | Record<string, any>>;
    showSubmenuMode: PropType<Record<string, any> | SubmenuShowMode>;
    submenuDirection: PropType<ContextSubmenuDirection>;
    tabIndex: NumberConstructor;
    target: {};
    visible: BooleanConstructor;
    width: (NumberConstructor | StringConstructor)[];
}, unknown, unknown, {
    instance(): ContextMenu;
}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:accessKey": null;
    "update:activeStateEnabled": null;
    "update:animation": null;
    "update:cssClass": null;
    "update:dataSource": null;
    "update:disabled": null;
    "update:disabledExpr": null;
    "update:displayExpr": null;
    "update:elementAttr": null;
    "update:focusStateEnabled": null;
    "update:height": null;
    "update:hideOnOutsideClick": null;
    "update:hint": null;
    "update:hoverStateEnabled": null;
    "update:items": null;
    "update:itemsExpr": null;
    "update:itemTemplate": null;
    "update:onContentReady": null;
    "update:onDisposing": null;
    "update:onHidden": null;
    "update:onHiding": null;
    "update:onInitialized": null;
    "update:onItemClick": null;
    "update:onItemContextMenu": null;
    "update:onItemRendered": null;
    "update:onOptionChanged": null;
    "update:onPositioning": null;
    "update:onSelectionChanged": null;
    "update:onShowing": null;
    "update:onShown": null;
    "update:position": null;
    "update:rtlEnabled": null;
    "update:selectByClick": null;
    "update:selectedExpr": null;
    "update:selectedItem": null;
    "update:selectionMode": null;
    "update:showEvent": null;
    "update:showSubmenuMode": null;
    "update:submenuDirection": null;
    "update:tabIndex": null;
    "update:target": null;
    "update:visible": null;
    "update:width": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    accessKey: StringConstructor;
    activeStateEnabled: BooleanConstructor;
    animation: PropType<Record<string, any>>;
    cssClass: StringConstructor;
    dataSource: PropType<string | Record<string, any> | DataSource<any, any> | DataSourceOptions<any, any, any, any> | Store<any, any> | dxContextMenuItem[] | null>;
    disabled: BooleanConstructor;
    disabledExpr: PropType<string | ((item: any) => boolean | undefined)>;
    displayExpr: PropType<string | ((item: any) => string)>;
    elementAttr: PropType<Record<string, any>>;
    focusStateEnabled: BooleanConstructor;
    height: (NumberConstructor | StringConstructor)[];
    hideOnOutsideClick: PropType<boolean | ((event: event) => boolean)>;
    hint: StringConstructor;
    hoverStateEnabled: BooleanConstructor;
    items: PropType<any[]>;
    itemsExpr: PropType<string | ((item: any) => Array<any> | undefined)>;
    itemTemplate: {};
    onContentReady: PropType<(e: ContentReadyEvent) => void>;
    onDisposing: PropType<(e: DisposingEvent) => void>;
    onHidden: PropType<(e: HiddenEvent) => void>;
    onHiding: PropType<(e: HidingEvent) => void>;
    onInitialized: PropType<(e: InitializedEvent) => void>;
    onItemClick: PropType<(e: ItemClickEvent) => void>;
    onItemContextMenu: PropType<(e: ItemContextMenuEvent) => void>;
    onItemRendered: PropType<(e: ItemRenderedEvent) => void>;
    onOptionChanged: PropType<(e: OptionChangedEvent) => void>;
    onPositioning: PropType<(e: PositioningEvent) => void>;
    onSelectionChanged: PropType<(e: SelectionChangedEvent) => void>;
    onShowing: PropType<(e: ShowingEvent) => void>;
    onShown: PropType<(e: ShownEvent) => void>;
    position: PropType<Record<string, any> | PositionConfig>;
    rtlEnabled: BooleanConstructor;
    selectByClick: BooleanConstructor;
    selectedExpr: PropType<string | ((item: any, value: boolean) => boolean | undefined)>;
    selectedItem: {};
    selectionMode: PropType<SingleOrNone>;
    showEvent: PropType<string | Record<string, any>>;
    showSubmenuMode: PropType<Record<string, any> | SubmenuShowMode>;
    submenuDirection: PropType<ContextSubmenuDirection>;
    tabIndex: NumberConstructor;
    target: {};
    visible: BooleanConstructor;
    width: (NumberConstructor | StringConstructor)[];
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:disabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:elementAttr"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onDisposing"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onInitialized"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onOptionChanged"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onSelectionChanged"?: ((...args: any[]) => any) | undefined;
    "onUpdate:rtlEnabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:height"?: ((...args: any[]) => any) | undefined;
    "onUpdate:width"?: ((...args: any[]) => any) | undefined;
    "onUpdate:visible"?: ((...args: any[]) => any) | undefined;
    "onUpdate:dataSource"?: ((...args: any[]) => any) | undefined;
    "onUpdate:selectionMode"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoverStateEnabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:items"?: ((...args: any[]) => any) | undefined;
    "onUpdate:itemTemplate"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onContentReady"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onItemClick"?: ((...args: any[]) => any) | undefined;
    "onUpdate:accessKey"?: ((...args: any[]) => any) | undefined;
    "onUpdate:activeStateEnabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:disabledExpr"?: ((...args: any[]) => any) | undefined;
    "onUpdate:displayExpr"?: ((...args: any[]) => any) | undefined;
    "onUpdate:focusStateEnabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hint"?: ((...args: any[]) => any) | undefined;
    "onUpdate:itemsExpr"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onItemContextMenu"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onItemRendered"?: ((...args: any[]) => any) | undefined;
    "onUpdate:selectByClick"?: ((...args: any[]) => any) | undefined;
    "onUpdate:selectedExpr"?: ((...args: any[]) => any) | undefined;
    "onUpdate:tabIndex"?: ((...args: any[]) => any) | undefined;
    "onUpdate:cssClass"?: ((...args: any[]) => any) | undefined;
    "onUpdate:position"?: ((...args: any[]) => any) | undefined;
    "onUpdate:animation"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hideOnOutsideClick"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onHidden"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onHiding"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onShowing"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onShown"?: ((...args: any[]) => any) | undefined;
    "onUpdate:selectedItem"?: ((...args: any[]) => any) | undefined;
    "onUpdate:showEvent"?: ((...args: any[]) => any) | undefined;
    "onUpdate:target"?: ((...args: any[]) => any) | undefined;
    "onUpdate:showSubmenuMode"?: ((...args: any[]) => any) | undefined;
    "onUpdate:submenuDirection"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onPositioning"?: ((...args: any[]) => any) | undefined;
}, {
    disabled: boolean;
    rtlEnabled: boolean;
    visible: boolean;
    hoverStateEnabled: boolean;
    activeStateEnabled: boolean;
    focusStateEnabled: boolean;
    selectByClick: boolean;
}>;
declare const DxAnimation: import("vue").DefineComponent<{
    hide: PropType<string | number | Record<string, any> | AnimationConfig>;
    show: PropType<string | number | Record<string, any> | AnimationConfig>;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:hide": null;
    "update:show": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    hide: PropType<string | number | Record<string, any> | AnimationConfig>;
    show: PropType<string | number | Record<string, any> | AnimationConfig>;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:show"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hide"?: ((...args: any[]) => any) | undefined;
}, {}>;
declare const DxAt: import("vue").DefineComponent<{
    x: PropType<HorizontalAlignment>;
    y: PropType<VerticalAlignment>;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:x": null;
    "update:y": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    x: PropType<HorizontalAlignment>;
    y: PropType<VerticalAlignment>;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:x"?: ((...args: any[]) => any) | undefined;
    "onUpdate:y"?: ((...args: any[]) => any) | undefined;
}, {}>;
declare const DxBoundaryOffset: import("vue").DefineComponent<{
    x: NumberConstructor;
    y: NumberConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:x": null;
    "update:y": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    x: NumberConstructor;
    y: NumberConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:x"?: ((...args: any[]) => any) | undefined;
    "onUpdate:y"?: ((...args: any[]) => any) | undefined;
}, {}>;
declare const DxCollision: import("vue").DefineComponent<{
    x: PropType<CollisionResolution>;
    y: PropType<CollisionResolution>;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:x": null;
    "update:y": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    x: PropType<CollisionResolution>;
    y: PropType<CollisionResolution>;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:x"?: ((...args: any[]) => any) | undefined;
    "onUpdate:y"?: ((...args: any[]) => any) | undefined;
}, {}>;
declare const DxDelay: import("vue").DefineComponent<{
    hide: NumberConstructor;
    show: NumberConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:hide": null;
    "update:show": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    hide: NumberConstructor;
    show: NumberConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:show"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hide"?: ((...args: any[]) => any) | undefined;
}, {}>;
declare const DxFrom: import("vue").DefineComponent<{
    left: NumberConstructor;
    opacity: NumberConstructor;
    position: PropType<Record<string, any> | PositionConfig>;
    scale: NumberConstructor;
    top: NumberConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:left": null;
    "update:opacity": null;
    "update:position": null;
    "update:scale": null;
    "update:top": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    left: NumberConstructor;
    opacity: NumberConstructor;
    position: PropType<Record<string, any> | PositionConfig>;
    scale: NumberConstructor;
    top: NumberConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:opacity"?: ((...args: any[]) => any) | undefined;
    "onUpdate:left"?: ((...args: any[]) => any) | undefined;
    "onUpdate:top"?: ((...args: any[]) => any) | undefined;
    "onUpdate:position"?: ((...args: any[]) => any) | undefined;
    "onUpdate:scale"?: ((...args: any[]) => any) | undefined;
}, {}>;
declare const DxHide: import("vue").DefineComponent<{
    complete: PropType<($element: any, config: AnimationConfig) => void>;
    delay: NumberConstructor;
    direction: PropType<Direction>;
    duration: NumberConstructor;
    easing: StringConstructor;
    from: PropType<Record<string, any> | AnimationState>;
    staggerDelay: NumberConstructor;
    start: PropType<($element: any, config: AnimationConfig) => void>;
    to: PropType<Record<string, any> | AnimationState>;
    type: PropType<AnimationType>;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:complete": null;
    "update:delay": null;
    "update:direction": null;
    "update:duration": null;
    "update:easing": null;
    "update:from": null;
    "update:staggerDelay": null;
    "update:start": null;
    "update:to": null;
    "update:type": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    complete: PropType<($element: any, config: AnimationConfig) => void>;
    delay: NumberConstructor;
    direction: PropType<Direction>;
    duration: NumberConstructor;
    easing: StringConstructor;
    from: PropType<Record<string, any> | AnimationState>;
    staggerDelay: NumberConstructor;
    start: PropType<($element: any, config: AnimationConfig) => void>;
    to: PropType<Record<string, any> | AnimationState>;
    type: PropType<AnimationType>;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:type"?: ((...args: any[]) => any) | undefined;
    "onUpdate:from"?: ((...args: any[]) => any) | undefined;
    "onUpdate:to"?: ((...args: any[]) => any) | undefined;
    "onUpdate:complete"?: ((...args: any[]) => any) | undefined;
    "onUpdate:delay"?: ((...args: any[]) => any) | undefined;
    "onUpdate:direction"?: ((...args: any[]) => any) | undefined;
    "onUpdate:duration"?: ((...args: any[]) => any) | undefined;
    "onUpdate:easing"?: ((...args: any[]) => any) | undefined;
    "onUpdate:staggerDelay"?: ((...args: any[]) => any) | undefined;
    "onUpdate:start"?: ((...args: any[]) => any) | undefined;
}, {}>;
declare const DxItem: import("vue").DefineComponent<{
    beginGroup: BooleanConstructor;
    closeMenuOnClick: BooleanConstructor;
    disabled: BooleanConstructor;
    icon: StringConstructor;
    items: PropType<dxContextMenuItem[]>;
    selectable: BooleanConstructor;
    selected: BooleanConstructor;
    template: {};
    text: StringConstructor;
    visible: BooleanConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:beginGroup": null;
    "update:closeMenuOnClick": null;
    "update:disabled": null;
    "update:icon": null;
    "update:items": null;
    "update:selectable": null;
    "update:selected": null;
    "update:template": null;
    "update:text": null;
    "update:visible": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    beginGroup: BooleanConstructor;
    closeMenuOnClick: BooleanConstructor;
    disabled: BooleanConstructor;
    icon: StringConstructor;
    items: PropType<dxContextMenuItem[]>;
    selectable: BooleanConstructor;
    selected: BooleanConstructor;
    template: {};
    text: StringConstructor;
    visible: BooleanConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:disabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:template"?: ((...args: any[]) => any) | undefined;
    "onUpdate:text"?: ((...args: any[]) => any) | undefined;
    "onUpdate:visible"?: ((...args: any[]) => any) | undefined;
    "onUpdate:items"?: ((...args: any[]) => any) | undefined;
    "onUpdate:icon"?: ((...args: any[]) => any) | undefined;
    "onUpdate:selected"?: ((...args: any[]) => any) | undefined;
    "onUpdate:beginGroup"?: ((...args: any[]) => any) | undefined;
    "onUpdate:closeMenuOnClick"?: ((...args: any[]) => any) | undefined;
    "onUpdate:selectable"?: ((...args: any[]) => any) | undefined;
}, {
    disabled: boolean;
    visible: boolean;
    selected: boolean;
    beginGroup: boolean;
    closeMenuOnClick: boolean;
    selectable: boolean;
}>;
declare const DxMy: import("vue").DefineComponent<{
    x: PropType<HorizontalAlignment>;
    y: PropType<VerticalAlignment>;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:x": null;
    "update:y": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    x: PropType<HorizontalAlignment>;
    y: PropType<VerticalAlignment>;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:x"?: ((...args: any[]) => any) | undefined;
    "onUpdate:y"?: ((...args: any[]) => any) | undefined;
}, {}>;
declare const DxOffset: import("vue").DefineComponent<{
    x: NumberConstructor;
    y: NumberConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:x": null;
    "update:y": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    x: NumberConstructor;
    y: NumberConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:x"?: ((...args: any[]) => any) | undefined;
    "onUpdate:y"?: ((...args: any[]) => any) | undefined;
}, {}>;
declare const DxPosition: import("vue").DefineComponent<{
    at: PropType<Record<string, any> | PositionAlignment>;
    boundary: {};
    boundaryOffset: PropType<string | Record<string, any>>;
    collision: PropType<Record<string, any> | CollisionResolutionCombination>;
    my: PropType<Record<string, any> | PositionAlignment>;
    of: {};
    offset: PropType<string | Record<string, any>>;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:at": null;
    "update:boundary": null;
    "update:boundaryOffset": null;
    "update:collision": null;
    "update:my": null;
    "update:of": null;
    "update:offset": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    at: PropType<Record<string, any> | PositionAlignment>;
    boundary: {};
    boundaryOffset: PropType<string | Record<string, any>>;
    collision: PropType<Record<string, any> | CollisionResolutionCombination>;
    my: PropType<Record<string, any> | PositionAlignment>;
    of: {};
    offset: PropType<string | Record<string, any>>;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:offset"?: ((...args: any[]) => any) | undefined;
    "onUpdate:at"?: ((...args: any[]) => any) | undefined;
    "onUpdate:boundary"?: ((...args: any[]) => any) | undefined;
    "onUpdate:boundaryOffset"?: ((...args: any[]) => any) | undefined;
    "onUpdate:collision"?: ((...args: any[]) => any) | undefined;
    "onUpdate:my"?: ((...args: any[]) => any) | undefined;
    "onUpdate:of"?: ((...args: any[]) => any) | undefined;
}, {}>;
declare const DxShow: import("vue").DefineComponent<{
    complete: PropType<($element: any, config: AnimationConfig) => void>;
    delay: NumberConstructor;
    direction: PropType<Direction>;
    duration: NumberConstructor;
    easing: StringConstructor;
    from: PropType<Record<string, any> | AnimationState>;
    staggerDelay: NumberConstructor;
    start: PropType<($element: any, config: AnimationConfig) => void>;
    to: PropType<Record<string, any> | AnimationState>;
    type: PropType<AnimationType>;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:complete": null;
    "update:delay": null;
    "update:direction": null;
    "update:duration": null;
    "update:easing": null;
    "update:from": null;
    "update:staggerDelay": null;
    "update:start": null;
    "update:to": null;
    "update:type": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    complete: PropType<($element: any, config: AnimationConfig) => void>;
    delay: NumberConstructor;
    direction: PropType<Direction>;
    duration: NumberConstructor;
    easing: StringConstructor;
    from: PropType<Record<string, any> | AnimationState>;
    staggerDelay: NumberConstructor;
    start: PropType<($element: any, config: AnimationConfig) => void>;
    to: PropType<Record<string, any> | AnimationState>;
    type: PropType<AnimationType>;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:type"?: ((...args: any[]) => any) | undefined;
    "onUpdate:from"?: ((...args: any[]) => any) | undefined;
    "onUpdate:to"?: ((...args: any[]) => any) | undefined;
    "onUpdate:complete"?: ((...args: any[]) => any) | undefined;
    "onUpdate:delay"?: ((...args: any[]) => any) | undefined;
    "onUpdate:direction"?: ((...args: any[]) => any) | undefined;
    "onUpdate:duration"?: ((...args: any[]) => any) | undefined;
    "onUpdate:easing"?: ((...args: any[]) => any) | undefined;
    "onUpdate:staggerDelay"?: ((...args: any[]) => any) | undefined;
    "onUpdate:start"?: ((...args: any[]) => any) | undefined;
}, {}>;
declare const DxShowEvent: import("vue").DefineComponent<{
    delay: NumberConstructor;
    name: StringConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:delay": null;
    "update:name": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    delay: NumberConstructor;
    name: StringConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:name"?: ((...args: any[]) => any) | undefined;
    "onUpdate:delay"?: ((...args: any[]) => any) | undefined;
}, {}>;
declare const DxShowSubmenuMode: import("vue").DefineComponent<{
    delay: PropType<number | Record<string, any>>;
    name: PropType<SubmenuShowMode>;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:delay": null;
    "update:name": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    delay: PropType<number | Record<string, any>>;
    name: PropType<SubmenuShowMode>;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:name"?: ((...args: any[]) => any) | undefined;
    "onUpdate:delay"?: ((...args: any[]) => any) | undefined;
}, {}>;
declare const DxTo: import("vue").DefineComponent<{
    left: NumberConstructor;
    opacity: NumberConstructor;
    position: PropType<Record<string, any> | PositionConfig>;
    scale: NumberConstructor;
    top: NumberConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:left": null;
    "update:opacity": null;
    "update:position": null;
    "update:scale": null;
    "update:top": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    left: NumberConstructor;
    opacity: NumberConstructor;
    position: PropType<Record<string, any> | PositionConfig>;
    scale: NumberConstructor;
    top: NumberConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:opacity"?: ((...args: any[]) => any) | undefined;
    "onUpdate:left"?: ((...args: any[]) => any) | undefined;
    "onUpdate:top"?: ((...args: any[]) => any) | undefined;
    "onUpdate:position"?: ((...args: any[]) => any) | undefined;
    "onUpdate:scale"?: ((...args: any[]) => any) | undefined;
}, {}>;
export default DxContextMenu;
export { DxContextMenu, DxAnimation, DxAt, DxBoundaryOffset, DxCollision, DxDelay, DxFrom, DxHide, DxItem, DxMy, DxOffset, DxPosition, DxShow, DxShowEvent, DxShowSubmenuMode, DxTo };
import type * as DxContextMenuTypes from "devextreme/ui/context_menu_types";
export { DxContextMenuTypes };
