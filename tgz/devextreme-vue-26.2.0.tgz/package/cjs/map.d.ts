/*!
 * devextreme-vue
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

import { PropType } from "vue";
import Map, { Properties } from "devextreme/ui/map";
import { ClickEvent, DisposingEvent, InitializedEvent, MarkerAddedEvent, MarkerRemovedEvent, OptionChangedEvent, ReadyEvent, RouteAddedEvent, RouteRemovedEvent, MapProvider, MapType } from "devextreme/ui/map";
type AccessibleOptions = Pick<Properties, "accessKey" | "activeStateEnabled" | "apiKey" | "autoAdjust" | "center" | "controls" | "disabled" | "elementAttr" | "focusStateEnabled" | "height" | "hint" | "hoverStateEnabled" | "markerIconSrc" | "markers" | "onClick" | "onDisposing" | "onInitialized" | "onMarkerAdded" | "onMarkerRemoved" | "onOptionChanged" | "onReady" | "onRouteAdded" | "onRouteRemoved" | "provider" | "providerConfig" | "routes" | "rtlEnabled" | "tabIndex" | "type" | "visible" | "width" | "zoom">;
interface DxMap extends AccessibleOptions {
    readonly instance?: Map;
}
declare const DxMap: import("vue").DefineComponent<{
    accessKey: StringConstructor;
    activeStateEnabled: BooleanConstructor;
    apiKey: PropType<string | Record<string, any>>;
    autoAdjust: BooleanConstructor;
    center: PropType<string | Record<string, any> | number[]>;
    controls: BooleanConstructor;
    disabled: BooleanConstructor;
    elementAttr: PropType<Record<string, any>>;
    focusStateEnabled: BooleanConstructor;
    height: (NumberConstructor | StringConstructor)[];
    hint: StringConstructor;
    hoverStateEnabled: BooleanConstructor;
    markerIconSrc: StringConstructor;
    markers: PropType<Record<string, any>[]>;
    onClick: PropType<(e: ClickEvent) => void>;
    onDisposing: PropType<(e: DisposingEvent) => void>;
    onInitialized: PropType<(e: InitializedEvent) => void>;
    onMarkerAdded: PropType<(e: MarkerAddedEvent) => void>;
    onMarkerRemoved: PropType<(e: MarkerRemovedEvent) => void>;
    onOptionChanged: PropType<(e: OptionChangedEvent) => void>;
    onReady: PropType<(e: ReadyEvent) => void>;
    onRouteAdded: PropType<(e: RouteAddedEvent) => void>;
    onRouteRemoved: PropType<(e: RouteRemovedEvent) => void>;
    provider: PropType<MapProvider>;
    providerConfig: PropType<Record<string, any>>;
    routes: PropType<Record<string, any>[]>;
    rtlEnabled: BooleanConstructor;
    tabIndex: NumberConstructor;
    type: PropType<MapType>;
    visible: BooleanConstructor;
    width: (NumberConstructor | StringConstructor)[];
    zoom: NumberConstructor;
}, unknown, unknown, {
    instance(): Map;
}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:accessKey": null;
    "update:activeStateEnabled": null;
    "update:apiKey": null;
    "update:autoAdjust": null;
    "update:center": null;
    "update:controls": null;
    "update:disabled": null;
    "update:elementAttr": null;
    "update:focusStateEnabled": null;
    "update:height": null;
    "update:hint": null;
    "update:hoverStateEnabled": null;
    "update:markerIconSrc": null;
    "update:markers": null;
    "update:onClick": null;
    "update:onDisposing": null;
    "update:onInitialized": null;
    "update:onMarkerAdded": null;
    "update:onMarkerRemoved": null;
    "update:onOptionChanged": null;
    "update:onReady": null;
    "update:onRouteAdded": null;
    "update:onRouteRemoved": null;
    "update:provider": null;
    "update:providerConfig": null;
    "update:routes": null;
    "update:rtlEnabled": null;
    "update:tabIndex": null;
    "update:type": null;
    "update:visible": null;
    "update:width": null;
    "update:zoom": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    accessKey: StringConstructor;
    activeStateEnabled: BooleanConstructor;
    apiKey: PropType<string | Record<string, any>>;
    autoAdjust: BooleanConstructor;
    center: PropType<string | Record<string, any> | number[]>;
    controls: BooleanConstructor;
    disabled: BooleanConstructor;
    elementAttr: PropType<Record<string, any>>;
    focusStateEnabled: BooleanConstructor;
    height: (NumberConstructor | StringConstructor)[];
    hint: StringConstructor;
    hoverStateEnabled: BooleanConstructor;
    markerIconSrc: StringConstructor;
    markers: PropType<Record<string, any>[]>;
    onClick: PropType<(e: ClickEvent) => void>;
    onDisposing: PropType<(e: DisposingEvent) => void>;
    onInitialized: PropType<(e: InitializedEvent) => void>;
    onMarkerAdded: PropType<(e: MarkerAddedEvent) => void>;
    onMarkerRemoved: PropType<(e: MarkerRemovedEvent) => void>;
    onOptionChanged: PropType<(e: OptionChangedEvent) => void>;
    onReady: PropType<(e: ReadyEvent) => void>;
    onRouteAdded: PropType<(e: RouteAddedEvent) => void>;
    onRouteRemoved: PropType<(e: RouteRemovedEvent) => void>;
    provider: PropType<MapProvider>;
    providerConfig: PropType<Record<string, any>>;
    routes: PropType<Record<string, any>[]>;
    rtlEnabled: BooleanConstructor;
    tabIndex: NumberConstructor;
    type: PropType<MapType>;
    visible: BooleanConstructor;
    width: (NumberConstructor | StringConstructor)[];
    zoom: NumberConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:center"?: ((...args: any[]) => any) | undefined;
    "onUpdate:disabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:elementAttr"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onClick"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onDisposing"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onInitialized"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onOptionChanged"?: ((...args: any[]) => any) | undefined;
    "onUpdate:rtlEnabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:height"?: ((...args: any[]) => any) | undefined;
    "onUpdate:type"?: ((...args: any[]) => any) | undefined;
    "onUpdate:width"?: ((...args: any[]) => any) | undefined;
    "onUpdate:visible"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoverStateEnabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:accessKey"?: ((...args: any[]) => any) | undefined;
    "onUpdate:activeStateEnabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:focusStateEnabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hint"?: ((...args: any[]) => any) | undefined;
    "onUpdate:tabIndex"?: ((...args: any[]) => any) | undefined;
    "onUpdate:apiKey"?: ((...args: any[]) => any) | undefined;
    "onUpdate:autoAdjust"?: ((...args: any[]) => any) | undefined;
    "onUpdate:controls"?: ((...args: any[]) => any) | undefined;
    "onUpdate:markerIconSrc"?: ((...args: any[]) => any) | undefined;
    "onUpdate:markers"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onMarkerAdded"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onMarkerRemoved"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onReady"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onRouteAdded"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onRouteRemoved"?: ((...args: any[]) => any) | undefined;
    "onUpdate:provider"?: ((...args: any[]) => any) | undefined;
    "onUpdate:providerConfig"?: ((...args: any[]) => any) | undefined;
    "onUpdate:routes"?: ((...args: any[]) => any) | undefined;
    "onUpdate:zoom"?: ((...args: any[]) => any) | undefined;
}, {
    disabled: boolean;
    rtlEnabled: boolean;
    visible: boolean;
    hoverStateEnabled: boolean;
    activeStateEnabled: boolean;
    focusStateEnabled: boolean;
    autoAdjust: boolean;
    controls: boolean;
}>;
declare const DxApiKey: import("vue").DefineComponent<{
    azure: StringConstructor;
    bing: StringConstructor;
    google: StringConstructor;
    googleStatic: StringConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:azure": null;
    "update:bing": null;
    "update:google": null;
    "update:googleStatic": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    azure: StringConstructor;
    bing: StringConstructor;
    google: StringConstructor;
    googleStatic: StringConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:azure"?: ((...args: any[]) => any) | undefined;
    "onUpdate:bing"?: ((...args: any[]) => any) | undefined;
    "onUpdate:google"?: ((...args: any[]) => any) | undefined;
    "onUpdate:googleStatic"?: ((...args: any[]) => any) | undefined;
}, {}>;
declare const DxCenter: import("vue").DefineComponent<{
    lat: NumberConstructor;
    lng: NumberConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:lat": null;
    "update:lng": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    lat: NumberConstructor;
    lng: NumberConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:lat"?: ((...args: any[]) => any) | undefined;
    "onUpdate:lng"?: ((...args: any[]) => any) | undefined;
}, {}>;
declare const DxLocation: import("vue").DefineComponent<{
    lat: NumberConstructor;
    lng: NumberConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:lat": null;
    "update:lng": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    lat: NumberConstructor;
    lng: NumberConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:lat"?: ((...args: any[]) => any) | undefined;
    "onUpdate:lng"?: ((...args: any[]) => any) | undefined;
}, {}>;
declare const DxMarker: import("vue").DefineComponent<{
    iconSrc: StringConstructor;
    location: PropType<string | Record<string, any> | number[]>;
    onClick: PropType<() => void>;
    tooltip: PropType<string | Record<string, any>>;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:iconSrc": null;
    "update:location": null;
    "update:onClick": null;
    "update:tooltip": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    iconSrc: StringConstructor;
    location: PropType<string | Record<string, any> | number[]>;
    onClick: PropType<() => void>;
    tooltip: PropType<string | Record<string, any>>;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onClick"?: ((...args: any[]) => any) | undefined;
    "onUpdate:tooltip"?: ((...args: any[]) => any) | undefined;
    "onUpdate:location"?: ((...args: any[]) => any) | undefined;
    "onUpdate:iconSrc"?: ((...args: any[]) => any) | undefined;
}, {}>;
declare const DxProviderConfig: import("vue").DefineComponent<{
    mapId: StringConstructor;
    useAdvancedMarkers: BooleanConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:mapId": null;
    "update:useAdvancedMarkers": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    mapId: StringConstructor;
    useAdvancedMarkers: BooleanConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:mapId"?: ((...args: any[]) => any) | undefined;
    "onUpdate:useAdvancedMarkers"?: ((...args: any[]) => any) | undefined;
}, {
    useAdvancedMarkers: boolean;
}>;
declare const DxRoute: import("vue").DefineComponent<{
    color: StringConstructor;
    locations: PropType<Record<string, any>[]>;
    mode: PropType<string>;
    opacity: NumberConstructor;
    weight: NumberConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:color": null;
    "update:locations": null;
    "update:mode": null;
    "update:opacity": null;
    "update:weight": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    color: StringConstructor;
    locations: PropType<Record<string, any>[]>;
    mode: PropType<string>;
    opacity: NumberConstructor;
    weight: NumberConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:color"?: ((...args: any[]) => any) | undefined;
    "onUpdate:opacity"?: ((...args: any[]) => any) | undefined;
    "onUpdate:weight"?: ((...args: any[]) => any) | undefined;
    "onUpdate:mode"?: ((...args: any[]) => any) | undefined;
    "onUpdate:locations"?: ((...args: any[]) => any) | undefined;
}, {}>;
declare const DxTooltip: import("vue").DefineComponent<{
    isShown: BooleanConstructor;
    text: StringConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:isShown": null;
    "update:text": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    isShown: BooleanConstructor;
    text: StringConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:text"?: ((...args: any[]) => any) | undefined;
    "onUpdate:isShown"?: ((...args: any[]) => any) | undefined;
}, {
    isShown: boolean;
}>;
export default DxMap;
export { DxMap, DxApiKey, DxCenter, DxLocation, DxMarker, DxProviderConfig, DxRoute, DxTooltip };
import type * as DxMapTypes from "devextreme/ui/map_types";
export { DxMapTypes };
