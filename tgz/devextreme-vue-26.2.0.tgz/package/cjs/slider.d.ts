/*!
 * devextreme-vue
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

import { PropType } from "vue";
import Slider, { Properties } from "devextreme/ui/slider";
import { ContentReadyEvent, DisposingEvent, InitializedEvent, OptionChangedEvent, ValueChangedEvent } from "devextreme/ui/slider";
import { ValidationMessageMode, Position, ValidationStatus, SliderValueChangeMode, VerticalEdge, TooltipShowMode } from "devextreme/common";
type AccessibleOptions = Pick<Properties, "accessKey" | "activeStateEnabled" | "disabled" | "elementAttr" | "focusStateEnabled" | "height" | "hint" | "hoverStateEnabled" | "isDirty" | "isValid" | "keyStep" | "label" | "max" | "min" | "name" | "onContentReady" | "onDisposing" | "onInitialized" | "onOptionChanged" | "onValueChanged" | "readOnly" | "rtlEnabled" | "showRange" | "step" | "tabIndex" | "tooltip" | "validationError" | "validationErrors" | "validationMessageMode" | "validationMessagePosition" | "validationStatus" | "value" | "valueChangeMode" | "visible" | "width">;
interface DxSlider extends AccessibleOptions {
    readonly instance?: Slider;
}
declare const DxSlider: import("vue").DefineComponent<{
    accessKey: StringConstructor;
    activeStateEnabled: BooleanConstructor;
    disabled: BooleanConstructor;
    elementAttr: PropType<Record<string, any>>;
    focusStateEnabled: BooleanConstructor;
    height: (NumberConstructor | StringConstructor)[];
    hint: StringConstructor;
    hoverStateEnabled: BooleanConstructor;
    isDirty: BooleanConstructor;
    isValid: BooleanConstructor;
    keyStep: NumberConstructor;
    label: PropType<Record<string, any>>;
    max: NumberConstructor;
    min: NumberConstructor;
    name: StringConstructor;
    onContentReady: PropType<(e: ContentReadyEvent) => void>;
    onDisposing: PropType<(e: DisposingEvent) => void>;
    onInitialized: PropType<(e: InitializedEvent) => void>;
    onOptionChanged: PropType<(e: OptionChangedEvent) => void>;
    onValueChanged: PropType<(e: ValueChangedEvent) => void>;
    readOnly: BooleanConstructor;
    rtlEnabled: BooleanConstructor;
    showRange: BooleanConstructor;
    step: NumberConstructor;
    tabIndex: NumberConstructor;
    tooltip: PropType<Record<string, any>>;
    validationError: {};
    validationErrors: PropType<any[] | null>;
    validationMessageMode: PropType<ValidationMessageMode>;
    validationMessagePosition: PropType<Position>;
    validationStatus: PropType<ValidationStatus>;
    value: NumberConstructor;
    valueChangeMode: PropType<SliderValueChangeMode>;
    visible: BooleanConstructor;
    width: (NumberConstructor | StringConstructor)[];
}, unknown, unknown, {
    instance(): Slider;
}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:accessKey": null;
    "update:activeStateEnabled": null;
    "update:disabled": null;
    "update:elementAttr": null;
    "update:focusStateEnabled": null;
    "update:height": null;
    "update:hint": null;
    "update:hoverStateEnabled": null;
    "update:isDirty": null;
    "update:isValid": null;
    "update:keyStep": null;
    "update:label": null;
    "update:max": null;
    "update:min": null;
    "update:name": null;
    "update:onContentReady": null;
    "update:onDisposing": null;
    "update:onInitialized": null;
    "update:onOptionChanged": null;
    "update:onValueChanged": null;
    "update:readOnly": null;
    "update:rtlEnabled": null;
    "update:showRange": null;
    "update:step": null;
    "update:tabIndex": null;
    "update:tooltip": null;
    "update:validationError": null;
    "update:validationErrors": null;
    "update:validationMessageMode": null;
    "update:validationMessagePosition": null;
    "update:validationStatus": null;
    "update:value": null;
    "update:valueChangeMode": null;
    "update:visible": null;
    "update:width": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    accessKey: StringConstructor;
    activeStateEnabled: BooleanConstructor;
    disabled: BooleanConstructor;
    elementAttr: PropType<Record<string, any>>;
    focusStateEnabled: BooleanConstructor;
    height: (NumberConstructor | StringConstructor)[];
    hint: StringConstructor;
    hoverStateEnabled: BooleanConstructor;
    isDirty: BooleanConstructor;
    isValid: BooleanConstructor;
    keyStep: NumberConstructor;
    label: PropType<Record<string, any>>;
    max: NumberConstructor;
    min: NumberConstructor;
    name: StringConstructor;
    onContentReady: PropType<(e: ContentReadyEvent) => void>;
    onDisposing: PropType<(e: DisposingEvent) => void>;
    onInitialized: PropType<(e: InitializedEvent) => void>;
    onOptionChanged: PropType<(e: OptionChangedEvent) => void>;
    onValueChanged: PropType<(e: ValueChangedEvent) => void>;
    readOnly: BooleanConstructor;
    rtlEnabled: BooleanConstructor;
    showRange: BooleanConstructor;
    step: NumberConstructor;
    tabIndex: NumberConstructor;
    tooltip: PropType<Record<string, any>>;
    validationError: {};
    validationErrors: PropType<any[] | null>;
    validationMessageMode: PropType<ValidationMessageMode>;
    validationMessagePosition: PropType<Position>;
    validationStatus: PropType<ValidationStatus>;
    value: NumberConstructor;
    valueChangeMode: PropType<SliderValueChangeMode>;
    visible: BooleanConstructor;
    width: (NumberConstructor | StringConstructor)[];
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:disabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:elementAttr"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onDisposing"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onInitialized"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onOptionChanged"?: ((...args: any[]) => any) | undefined;
    "onUpdate:rtlEnabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:tooltip"?: ((...args: any[]) => any) | undefined;
    "onUpdate:height"?: ((...args: any[]) => any) | undefined;
    "onUpdate:name"?: ((...args: any[]) => any) | undefined;
    "onUpdate:width"?: ((...args: any[]) => any) | undefined;
    "onUpdate:visible"?: ((...args: any[]) => any) | undefined;
    "onUpdate:label"?: ((...args: any[]) => any) | undefined;
    "onUpdate:max"?: ((...args: any[]) => any) | undefined;
    "onUpdate:min"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoverStateEnabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onContentReady"?: ((...args: any[]) => any) | undefined;
    "onUpdate:accessKey"?: ((...args: any[]) => any) | undefined;
    "onUpdate:activeStateEnabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:focusStateEnabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hint"?: ((...args: any[]) => any) | undefined;
    "onUpdate:tabIndex"?: ((...args: any[]) => any) | undefined;
    "onUpdate:isDirty"?: ((...args: any[]) => any) | undefined;
    "onUpdate:isValid"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onValueChanged"?: ((...args: any[]) => any) | undefined;
    "onUpdate:readOnly"?: ((...args: any[]) => any) | undefined;
    "onUpdate:validationError"?: ((...args: any[]) => any) | undefined;
    "onUpdate:validationErrors"?: ((...args: any[]) => any) | undefined;
    "onUpdate:validationMessageMode"?: ((...args: any[]) => any) | undefined;
    "onUpdate:validationMessagePosition"?: ((...args: any[]) => any) | undefined;
    "onUpdate:validationStatus"?: ((...args: any[]) => any) | undefined;
    "onUpdate:value"?: ((...args: any[]) => any) | undefined;
    "onUpdate:keyStep"?: ((...args: any[]) => any) | undefined;
    "onUpdate:showRange"?: ((...args: any[]) => any) | undefined;
    "onUpdate:step"?: ((...args: any[]) => any) | undefined;
    "onUpdate:valueChangeMode"?: ((...args: any[]) => any) | undefined;
}, {
    disabled: boolean;
    rtlEnabled: boolean;
    visible: boolean;
    hoverStateEnabled: boolean;
    activeStateEnabled: boolean;
    focusStateEnabled: boolean;
    isDirty: boolean;
    isValid: boolean;
    readOnly: boolean;
    showRange: boolean;
}>;
declare const DxFormat: import("vue").DefineComponent<{
    currency: StringConstructor;
    formatter: PropType<(value: number | Date) => string>;
    parser: PropType<(value: string) => number | Date>;
    precision: NumberConstructor;
    type: PropType<string>;
    useCurrencyAccountingStyle: BooleanConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:currency": null;
    "update:formatter": null;
    "update:parser": null;
    "update:precision": null;
    "update:type": null;
    "update:useCurrencyAccountingStyle": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    currency: StringConstructor;
    formatter: PropType<(value: number | Date) => string>;
    parser: PropType<(value: string) => number | Date>;
    precision: NumberConstructor;
    type: PropType<string>;
    useCurrencyAccountingStyle: BooleanConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:type"?: ((...args: any[]) => any) | undefined;
    "onUpdate:currency"?: ((...args: any[]) => any) | undefined;
    "onUpdate:formatter"?: ((...args: any[]) => any) | undefined;
    "onUpdate:parser"?: ((...args: any[]) => any) | undefined;
    "onUpdate:precision"?: ((...args: any[]) => any) | undefined;
    "onUpdate:useCurrencyAccountingStyle"?: ((...args: any[]) => any) | undefined;
}, {
    useCurrencyAccountingStyle: boolean;
}>;
declare const DxLabel: import("vue").DefineComponent<{
    format: PropType<string | Record<string, any> | import("devextreme/common/core/localization").FormatObject | ((value: number | Date) => string) | ((value: Date) => string) | ((value: number) => string) | Intl.DateTimeFormatOptions | Intl.NumberFormatOptions | ((value: number | Date) => string) | undefined>;
    position: PropType<VerticalEdge>;
    visible: BooleanConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:format": null;
    "update:position": null;
    "update:visible": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    format: PropType<string | Record<string, any> | import("devextreme/common/core/localization").FormatObject | ((value: number | Date) => string) | ((value: Date) => string) | ((value: number) => string) | Intl.DateTimeFormatOptions | Intl.NumberFormatOptions | ((value: number | Date) => string) | undefined>;
    position: PropType<VerticalEdge>;
    visible: BooleanConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:visible"?: ((...args: any[]) => any) | undefined;
    "onUpdate:format"?: ((...args: any[]) => any) | undefined;
    "onUpdate:position"?: ((...args: any[]) => any) | undefined;
}, {
    visible: boolean;
}>;
declare const DxTooltip: import("vue").DefineComponent<{
    enabled: BooleanConstructor;
    format: PropType<string | Record<string, any> | import("devextreme/common/core/localization").FormatObject | ((value: number | Date) => string) | ((value: Date) => string) | ((value: number) => string) | Intl.DateTimeFormatOptions | Intl.NumberFormatOptions | ((value: number | Date) => string) | undefined>;
    position: PropType<VerticalEdge>;
    showMode: PropType<TooltipShowMode>;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:enabled": null;
    "update:format": null;
    "update:position": null;
    "update:showMode": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    enabled: BooleanConstructor;
    format: PropType<string | Record<string, any> | import("devextreme/common/core/localization").FormatObject | ((value: number | Date) => string) | ((value: Date) => string) | ((value: number) => string) | Intl.DateTimeFormatOptions | Intl.NumberFormatOptions | ((value: number | Date) => string) | undefined>;
    position: PropType<VerticalEdge>;
    showMode: PropType<TooltipShowMode>;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:enabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:format"?: ((...args: any[]) => any) | undefined;
    "onUpdate:position"?: ((...args: any[]) => any) | undefined;
    "onUpdate:showMode"?: ((...args: any[]) => any) | undefined;
}, {
    enabled: boolean;
}>;
export default DxSlider;
export { DxSlider, DxFormat, DxLabel, DxTooltip };
import type * as DxSliderTypes from "devextreme/ui/slider_types";
export { DxSliderTypes };
