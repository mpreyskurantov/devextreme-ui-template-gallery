/*!
 * devextreme-vue
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

import { PropType } from "vue";
import SpeechToText, { Properties } from "devextreme/ui/speech_to_text";
import { CustomSpeechRecognizer, ContentReadyEvent, DisposingEvent, EndEvent, ErrorEvent, InitializedEvent, OptionChangedEvent, ResultEvent, StartClickEvent, StopClickEvent, SpeechRecognitionConfig } from "devextreme/ui/speech_to_text";
import { ButtonStyle } from "devextreme/common";
type AccessibleOptions = Pick<Properties, "accessKey" | "activeStateEnabled" | "customSpeechRecognizer" | "disabled" | "elementAttr" | "focusStateEnabled" | "height" | "hint" | "hoverStateEnabled" | "onContentReady" | "onDisposing" | "onEnd" | "onError" | "onInitialized" | "onOptionChanged" | "onResult" | "onStartClick" | "onStopClick" | "rtlEnabled" | "speechRecognitionConfig" | "startIcon" | "startText" | "stopIcon" | "stopText" | "stylingMode" | "tabIndex" | "type" | "visible" | "width">;
interface DxSpeechToText extends AccessibleOptions {
    readonly instance?: SpeechToText;
}
declare const DxSpeechToText: import("vue").DefineComponent<{
    accessKey: StringConstructor;
    activeStateEnabled: BooleanConstructor;
    customSpeechRecognizer: PropType<Record<string, any> | CustomSpeechRecognizer>;
    disabled: BooleanConstructor;
    elementAttr: PropType<Record<string, any>>;
    focusStateEnabled: BooleanConstructor;
    height: (NumberConstructor | StringConstructor)[];
    hint: StringConstructor;
    hoverStateEnabled: BooleanConstructor;
    onContentReady: PropType<(e: ContentReadyEvent) => void>;
    onDisposing: PropType<(e: DisposingEvent) => void>;
    onEnd: PropType<(e: EndEvent) => void>;
    onError: PropType<(e: ErrorEvent) => void>;
    onInitialized: PropType<(e: InitializedEvent) => void>;
    onOptionChanged: PropType<(e: OptionChangedEvent) => void>;
    onResult: PropType<(e: ResultEvent) => void>;
    onStartClick: PropType<(e: StartClickEvent) => void>;
    onStopClick: PropType<(e: StopClickEvent) => void>;
    rtlEnabled: BooleanConstructor;
    speechRecognitionConfig: PropType<Record<string, any> | SpeechRecognitionConfig>;
    startIcon: StringConstructor;
    startText: StringConstructor;
    stopIcon: StringConstructor;
    stopText: StringConstructor;
    stylingMode: PropType<ButtonStyle>;
    tabIndex: NumberConstructor;
    type: PropType<string>;
    visible: BooleanConstructor;
    width: (NumberConstructor | StringConstructor)[];
}, unknown, unknown, {
    instance(): SpeechToText;
}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:accessKey": null;
    "update:activeStateEnabled": null;
    "update:customSpeechRecognizer": null;
    "update:disabled": null;
    "update:elementAttr": null;
    "update:focusStateEnabled": null;
    "update:height": null;
    "update:hint": null;
    "update:hoverStateEnabled": null;
    "update:onContentReady": null;
    "update:onDisposing": null;
    "update:onEnd": null;
    "update:onError": null;
    "update:onInitialized": null;
    "update:onOptionChanged": null;
    "update:onResult": null;
    "update:onStartClick": null;
    "update:onStopClick": null;
    "update:rtlEnabled": null;
    "update:speechRecognitionConfig": null;
    "update:startIcon": null;
    "update:startText": null;
    "update:stopIcon": null;
    "update:stopText": null;
    "update:stylingMode": null;
    "update:tabIndex": null;
    "update:type": null;
    "update:visible": null;
    "update:width": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    accessKey: StringConstructor;
    activeStateEnabled: BooleanConstructor;
    customSpeechRecognizer: PropType<Record<string, any> | CustomSpeechRecognizer>;
    disabled: BooleanConstructor;
    elementAttr: PropType<Record<string, any>>;
    focusStateEnabled: BooleanConstructor;
    height: (NumberConstructor | StringConstructor)[];
    hint: StringConstructor;
    hoverStateEnabled: BooleanConstructor;
    onContentReady: PropType<(e: ContentReadyEvent) => void>;
    onDisposing: PropType<(e: DisposingEvent) => void>;
    onEnd: PropType<(e: EndEvent) => void>;
    onError: PropType<(e: ErrorEvent) => void>;
    onInitialized: PropType<(e: InitializedEvent) => void>;
    onOptionChanged: PropType<(e: OptionChangedEvent) => void>;
    onResult: PropType<(e: ResultEvent) => void>;
    onStartClick: PropType<(e: StartClickEvent) => void>;
    onStopClick: PropType<(e: StopClickEvent) => void>;
    rtlEnabled: BooleanConstructor;
    speechRecognitionConfig: PropType<Record<string, any> | SpeechRecognitionConfig>;
    startIcon: StringConstructor;
    startText: StringConstructor;
    stopIcon: StringConstructor;
    stopText: StringConstructor;
    stylingMode: PropType<ButtonStyle>;
    tabIndex: NumberConstructor;
    type: PropType<string>;
    visible: BooleanConstructor;
    width: (NumberConstructor | StringConstructor)[];
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:disabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:elementAttr"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onDisposing"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onInitialized"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onOptionChanged"?: ((...args: any[]) => any) | undefined;
    "onUpdate:rtlEnabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:height"?: ((...args: any[]) => any) | undefined;
    "onUpdate:type"?: ((...args: any[]) => any) | undefined;
    "onUpdate:width"?: ((...args: any[]) => any) | undefined;
    "onUpdate:visible"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoverStateEnabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onContentReady"?: ((...args: any[]) => any) | undefined;
    "onUpdate:accessKey"?: ((...args: any[]) => any) | undefined;
    "onUpdate:activeStateEnabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:focusStateEnabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hint"?: ((...args: any[]) => any) | undefined;
    "onUpdate:tabIndex"?: ((...args: any[]) => any) | undefined;
    "onUpdate:stylingMode"?: ((...args: any[]) => any) | undefined;
    "onUpdate:customSpeechRecognizer"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onEnd"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onError"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onResult"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onStartClick"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onStopClick"?: ((...args: any[]) => any) | undefined;
    "onUpdate:speechRecognitionConfig"?: ((...args: any[]) => any) | undefined;
    "onUpdate:startIcon"?: ((...args: any[]) => any) | undefined;
    "onUpdate:startText"?: ((...args: any[]) => any) | undefined;
    "onUpdate:stopIcon"?: ((...args: any[]) => any) | undefined;
    "onUpdate:stopText"?: ((...args: any[]) => any) | undefined;
}, {
    disabled: boolean;
    rtlEnabled: boolean;
    visible: boolean;
    hoverStateEnabled: boolean;
    activeStateEnabled: boolean;
    focusStateEnabled: boolean;
}>;
declare const DxCustomSpeechRecognizer: import("vue").DefineComponent<{
    enabled: BooleanConstructor;
    isListening: BooleanConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:enabled": null;
    "update:isListening": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    enabled: BooleanConstructor;
    isListening: BooleanConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:enabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:isListening"?: ((...args: any[]) => any) | undefined;
}, {
    enabled: boolean;
    isListening: boolean;
}>;
declare const DxSpeechRecognitionConfig: import("vue").DefineComponent<{
    continuous: BooleanConstructor;
    grammars: PropType<string[]>;
    interimResults: BooleanConstructor;
    lang: StringConstructor;
    maxAlternatives: NumberConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:continuous": null;
    "update:grammars": null;
    "update:interimResults": null;
    "update:lang": null;
    "update:maxAlternatives": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    continuous: BooleanConstructor;
    grammars: PropType<string[]>;
    interimResults: BooleanConstructor;
    lang: StringConstructor;
    maxAlternatives: NumberConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:continuous"?: ((...args: any[]) => any) | undefined;
    "onUpdate:grammars"?: ((...args: any[]) => any) | undefined;
    "onUpdate:interimResults"?: ((...args: any[]) => any) | undefined;
    "onUpdate:lang"?: ((...args: any[]) => any) | undefined;
    "onUpdate:maxAlternatives"?: ((...args: any[]) => any) | undefined;
}, {
    continuous: boolean;
    interimResults: boolean;
}>;
export default DxSpeechToText;
export { DxSpeechToText, DxCustomSpeechRecognizer, DxSpeechRecognitionConfig };
import type * as DxSpeechToTextTypes from "devextreme/ui/speech_to_text_types";
export { DxSpeechToTextTypes };
