/*!
 * devextreme-vue
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

export { ExplicitTypes } from "devextreme/ui/action_sheet";
import { PropType } from "vue";
import ActionSheet, { Properties } from "devextreme/ui/action_sheet";
import DataSource from "devextreme/data/data_source";
import { CancelClickEvent, ContentReadyEvent, DisposingEvent, InitializedEvent, ItemClickEvent, ItemContextMenuEvent, ItemHoldEvent, ItemRenderedEvent, OptionChangedEvent } from "devextreme/ui/action_sheet";
import { DataSourceOptions } from "devextreme/common/data";
import { Store } from "devextreme/data/store";
import { NativeEventInfo } from "devextreme/common/core/events";
import { ButtonStyle } from "devextreme/common";
type AccessibleOptions = Pick<Properties, "cancelText" | "dataSource" | "disabled" | "elementAttr" | "height" | "hint" | "hoverStateEnabled" | "itemHoldTimeout" | "items" | "itemTemplate" | "onCancelClick" | "onContentReady" | "onDisposing" | "onInitialized" | "onItemClick" | "onItemContextMenu" | "onItemHold" | "onItemRendered" | "onOptionChanged" | "rtlEnabled" | "showCancelButton" | "showTitle" | "target" | "title" | "usePopover" | "visible" | "width">;
interface DxActionSheet extends AccessibleOptions {
    readonly instance?: ActionSheet;
}
declare const DxActionSheet: import("vue").DefineComponent<{
    cancelText: StringConstructor;
    dataSource: PropType<string | any[] | Record<string, any> | DataSource<any, any> | DataSourceOptions<any, any, any, any> | Store<any, any> | null>;
    disabled: BooleanConstructor;
    elementAttr: PropType<Record<string, any>>;
    height: (NumberConstructor | StringConstructor)[];
    hint: StringConstructor;
    hoverStateEnabled: BooleanConstructor;
    itemHoldTimeout: NumberConstructor;
    items: PropType<any[]>;
    itemTemplate: {};
    onCancelClick: PropType<(e: CancelClickEvent) => void>;
    onContentReady: PropType<(e: ContentReadyEvent) => void>;
    onDisposing: PropType<(e: DisposingEvent) => void>;
    onInitialized: PropType<(e: InitializedEvent) => void>;
    onItemClick: PropType<(e: ItemClickEvent) => void>;
    onItemContextMenu: PropType<(e: ItemContextMenuEvent) => void>;
    onItemHold: PropType<(e: ItemHoldEvent) => void>;
    onItemRendered: PropType<(e: ItemRenderedEvent) => void>;
    onOptionChanged: PropType<(e: OptionChangedEvent) => void>;
    rtlEnabled: BooleanConstructor;
    showCancelButton: BooleanConstructor;
    showTitle: BooleanConstructor;
    target: {};
    title: StringConstructor;
    usePopover: BooleanConstructor;
    visible: BooleanConstructor;
    width: (NumberConstructor | StringConstructor)[];
}, unknown, unknown, {
    instance(): ActionSheet;
}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:cancelText": null;
    "update:dataSource": null;
    "update:disabled": null;
    "update:elementAttr": null;
    "update:height": null;
    "update:hint": null;
    "update:hoverStateEnabled": null;
    "update:itemHoldTimeout": null;
    "update:items": null;
    "update:itemTemplate": null;
    "update:onCancelClick": null;
    "update:onContentReady": null;
    "update:onDisposing": null;
    "update:onInitialized": null;
    "update:onItemClick": null;
    "update:onItemContextMenu": null;
    "update:onItemHold": null;
    "update:onItemRendered": null;
    "update:onOptionChanged": null;
    "update:rtlEnabled": null;
    "update:showCancelButton": null;
    "update:showTitle": null;
    "update:target": null;
    "update:title": null;
    "update:usePopover": null;
    "update:visible": null;
    "update:width": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    cancelText: StringConstructor;
    dataSource: PropType<string | any[] | Record<string, any> | DataSource<any, any> | DataSourceOptions<any, any, any, any> | Store<any, any> | null>;
    disabled: BooleanConstructor;
    elementAttr: PropType<Record<string, any>>;
    height: (NumberConstructor | StringConstructor)[];
    hint: StringConstructor;
    hoverStateEnabled: BooleanConstructor;
    itemHoldTimeout: NumberConstructor;
    items: PropType<any[]>;
    itemTemplate: {};
    onCancelClick: PropType<(e: CancelClickEvent) => void>;
    onContentReady: PropType<(e: ContentReadyEvent) => void>;
    onDisposing: PropType<(e: DisposingEvent) => void>;
    onInitialized: PropType<(e: InitializedEvent) => void>;
    onItemClick: PropType<(e: ItemClickEvent) => void>;
    onItemContextMenu: PropType<(e: ItemContextMenuEvent) => void>;
    onItemHold: PropType<(e: ItemHoldEvent) => void>;
    onItemRendered: PropType<(e: ItemRenderedEvent) => void>;
    onOptionChanged: PropType<(e: OptionChangedEvent) => void>;
    rtlEnabled: BooleanConstructor;
    showCancelButton: BooleanConstructor;
    showTitle: BooleanConstructor;
    target: {};
    title: StringConstructor;
    usePopover: BooleanConstructor;
    visible: BooleanConstructor;
    width: (NumberConstructor | StringConstructor)[];
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:disabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:elementAttr"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onDisposing"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onInitialized"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onOptionChanged"?: ((...args: any[]) => any) | undefined;
    "onUpdate:rtlEnabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:title"?: ((...args: any[]) => any) | undefined;
    "onUpdate:height"?: ((...args: any[]) => any) | undefined;
    "onUpdate:width"?: ((...args: any[]) => any) | undefined;
    "onUpdate:visible"?: ((...args: any[]) => any) | undefined;
    "onUpdate:dataSource"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoverStateEnabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:items"?: ((...args: any[]) => any) | undefined;
    "onUpdate:itemTemplate"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onContentReady"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onItemClick"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hint"?: ((...args: any[]) => any) | undefined;
    "onUpdate:itemHoldTimeout"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onItemContextMenu"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onItemHold"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onItemRendered"?: ((...args: any[]) => any) | undefined;
    "onUpdate:showTitle"?: ((...args: any[]) => any) | undefined;
    "onUpdate:target"?: ((...args: any[]) => any) | undefined;
    "onUpdate:showCancelButton"?: ((...args: any[]) => any) | undefined;
    "onUpdate:usePopover"?: ((...args: any[]) => any) | undefined;
    "onUpdate:cancelText"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onCancelClick"?: ((...args: any[]) => any) | undefined;
}, {
    disabled: boolean;
    rtlEnabled: boolean;
    visible: boolean;
    hoverStateEnabled: boolean;
    showTitle: boolean;
    showCancelButton: boolean;
    usePopover: boolean;
}>;
declare const DxItem: import("vue").DefineComponent<{
    disabled: BooleanConstructor;
    icon: StringConstructor;
    onClick: PropType<(e: NativeEventInfo<any>) => void>;
    stylingMode: PropType<ButtonStyle>;
    template: {};
    text: StringConstructor;
    type: PropType<string>;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:disabled": null;
    "update:icon": null;
    "update:onClick": null;
    "update:stylingMode": null;
    "update:template": null;
    "update:text": null;
    "update:type": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    disabled: BooleanConstructor;
    icon: StringConstructor;
    onClick: PropType<(e: NativeEventInfo<any>) => void>;
    stylingMode: PropType<ButtonStyle>;
    template: {};
    text: StringConstructor;
    type: PropType<string>;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:disabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onClick"?: ((...args: any[]) => any) | undefined;
    "onUpdate:template"?: ((...args: any[]) => any) | undefined;
    "onUpdate:text"?: ((...args: any[]) => any) | undefined;
    "onUpdate:type"?: ((...args: any[]) => any) | undefined;
    "onUpdate:icon"?: ((...args: any[]) => any) | undefined;
    "onUpdate:stylingMode"?: ((...args: any[]) => any) | undefined;
}, {
    disabled: boolean;
}>;
export default DxActionSheet;
export { DxActionSheet, DxItem };
import type * as DxActionSheetTypes from "devextreme/ui/action_sheet_types";
export { DxActionSheetTypes };
