/*!
 * devextreme-vue
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

import { PropType } from "vue";
import PolarChart, { Properties } from "devextreme/viz/polar_chart";
import DataSource from "devextreme/data/data_source";
import { dxPolarChartAnnotationConfig, dxPolarChartCommonAnnotationConfig, ArgumentAxisClickEvent, DisposingEvent, DoneEvent, DrawnEvent, ExportedEvent, ExportingEvent, FileSavingEvent, IncidentOccurredEvent, InitializedEvent, LegendClickEvent, OptionChangedEvent, PointClickEvent, PointHoverChangedEvent, PointSelectionChangedEvent, SeriesClickEvent, SeriesHoverChangedEvent, SeriesSelectionChangedEvent, TooltipHiddenEvent, TooltipShownEvent, ZoomEndEvent, ZoomStartEvent, PolarChartSeries, PolarChartSeriesType, dxPolarChartPointInfo } from "devextreme/viz/polar_chart";
import { SeriesLabel, SeriesPoint, Palette, PaletteExtensionMode, LabelOverlap, Theme, AnimationEaseMode, Font, TextOverflow, AnnotationType, WordWrap, DashStyle, ChartsDataType, DiscreteAxisDivisionMode, ArgumentAxisHoverMode, TimeInterval, AxisScaleType, ChartsColor, SeriesHoverMode, SeriesSelectionMode, RelativePosition, HatchDirection, LegendItem, LegendHoverMode, PointInteractionMode, PointSymbol, ValueAxisVisualRangeUpdateMode, ValueErrorBarDisplayMode, ValueErrorBarType } from "devextreme/common/charts";
import { DataSourceOptions } from "devextreme/common/data";
import { Store } from "devextreme/data/store";
import { SingleOrMultiple, ExportFormat, HorizontalAlignment, Position, Orientation, VerticalEdge } from "devextreme/common";
import * as CommonChartTypes from "devextreme/common/charts";
type AccessibleOptions = Pick<Properties, "adaptiveLayout" | "animation" | "annotations" | "argumentAxis" | "barGroupPadding" | "barGroupWidth" | "commonAnnotationSettings" | "commonAxisSettings" | "commonSeriesSettings" | "containerBackgroundColor" | "customizeAnnotation" | "customizeLabel" | "customizePoint" | "dataPrepareSettings" | "dataSource" | "disabled" | "elementAttr" | "encodeHtml" | "export" | "legend" | "loadingIndicator" | "margin" | "negativesAsZeroes" | "onArgumentAxisClick" | "onDisposing" | "onDone" | "onDrawn" | "onExported" | "onExporting" | "onFileSaving" | "onIncidentOccurred" | "onInitialized" | "onLegendClick" | "onOptionChanged" | "onPointClick" | "onPointHoverChanged" | "onPointSelectionChanged" | "onSeriesClick" | "onSeriesHoverChanged" | "onSeriesSelectionChanged" | "onTooltipHidden" | "onTooltipShown" | "onZoomEnd" | "onZoomStart" | "palette" | "paletteExtensionMode" | "pathModified" | "pointSelectionMode" | "redrawOnResize" | "resolveLabelOverlapping" | "rtlEnabled" | "series" | "seriesSelectionMode" | "seriesTemplate" | "size" | "theme" | "title" | "tooltip" | "useSpiderWeb" | "valueAxis">;
interface DxPolarChart extends AccessibleOptions {
    readonly instance?: PolarChart;
}
declare const DxPolarChart: import("vue").DefineComponent<{
    adaptiveLayout: PropType<Record<string, any>>;
    animation: PropType<boolean | Record<string, any>>;
    annotations: PropType<any[]>;
    argumentAxis: PropType<Record<string, any>>;
    barGroupPadding: NumberConstructor;
    barGroupWidth: NumberConstructor;
    commonAnnotationSettings: PropType<Record<string, any> | dxPolarChartCommonAnnotationConfig>;
    commonAxisSettings: PropType<Record<string, any>>;
    commonSeriesSettings: PropType<Record<string, any>>;
    containerBackgroundColor: StringConstructor;
    customizeAnnotation: PropType<(annotation: dxPolarChartAnnotationConfig | any) => dxPolarChartAnnotationConfig>;
    customizeLabel: PropType<(pointInfo: any) => SeriesLabel>;
    customizePoint: PropType<(pointInfo: any) => SeriesPoint>;
    dataPrepareSettings: PropType<Record<string, any>>;
    dataSource: PropType<string | any[] | Record<string, any> | DataSource<any, any> | DataSourceOptions<any, any, any, any> | Store<any, any> | null>;
    disabled: BooleanConstructor;
    elementAttr: PropType<Record<string, any>>;
    encodeHtml: BooleanConstructor;
    export: PropType<Record<string, any>>;
    legend: PropType<Record<string, any>>;
    loadingIndicator: PropType<Record<string, any>>;
    margin: PropType<Record<string, any>>;
    negativesAsZeroes: BooleanConstructor;
    onArgumentAxisClick: PropType<(e: ArgumentAxisClickEvent) => void>;
    onDisposing: PropType<(e: DisposingEvent) => void>;
    onDone: PropType<(e: DoneEvent) => void>;
    onDrawn: PropType<(e: DrawnEvent) => void>;
    onExported: PropType<(e: ExportedEvent) => void>;
    onExporting: PropType<(e: ExportingEvent) => void>;
    onFileSaving: PropType<(e: FileSavingEvent) => void>;
    onIncidentOccurred: PropType<(e: IncidentOccurredEvent) => void>;
    onInitialized: PropType<(e: InitializedEvent) => void>;
    onLegendClick: PropType<(e: LegendClickEvent) => void>;
    onOptionChanged: PropType<(e: OptionChangedEvent) => void>;
    onPointClick: PropType<(e: PointClickEvent) => void>;
    onPointHoverChanged: PropType<(e: PointHoverChangedEvent) => void>;
    onPointSelectionChanged: PropType<(e: PointSelectionChangedEvent) => void>;
    onSeriesClick: PropType<(e: SeriesClickEvent) => void>;
    onSeriesHoverChanged: PropType<(e: SeriesHoverChangedEvent) => void>;
    onSeriesSelectionChanged: PropType<(e: SeriesSelectionChangedEvent) => void>;
    onTooltipHidden: PropType<(e: TooltipHiddenEvent) => void>;
    onTooltipShown: PropType<(e: TooltipShownEvent) => void>;
    onZoomEnd: PropType<(e: ZoomEndEvent) => void>;
    onZoomStart: PropType<(e: ZoomStartEvent) => void>;
    palette: PropType<string[] | Palette>;
    paletteExtensionMode: PropType<PaletteExtensionMode>;
    pathModified: BooleanConstructor;
    pointSelectionMode: PropType<SingleOrMultiple>;
    redrawOnResize: BooleanConstructor;
    resolveLabelOverlapping: PropType<LabelOverlap>;
    rtlEnabled: BooleanConstructor;
    series: PropType<Record<string, any> | PolarChartSeries | PolarChartSeries[]>;
    seriesSelectionMode: PropType<SingleOrMultiple>;
    seriesTemplate: PropType<Record<string, any>>;
    size: PropType<Record<string, any>>;
    theme: PropType<Theme>;
    title: PropType<string | Record<string, any>>;
    tooltip: PropType<Record<string, any>>;
    useSpiderWeb: BooleanConstructor;
    valueAxis: PropType<Record<string, any>>;
}, unknown, unknown, {
    instance(): PolarChart;
}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:adaptiveLayout": null;
    "update:animation": null;
    "update:annotations": null;
    "update:argumentAxis": null;
    "update:barGroupPadding": null;
    "update:barGroupWidth": null;
    "update:commonAnnotationSettings": null;
    "update:commonAxisSettings": null;
    "update:commonSeriesSettings": null;
    "update:containerBackgroundColor": null;
    "update:customizeAnnotation": null;
    "update:customizeLabel": null;
    "update:customizePoint": null;
    "update:dataPrepareSettings": null;
    "update:dataSource": null;
    "update:disabled": null;
    "update:elementAttr": null;
    "update:encodeHtml": null;
    "update:export": null;
    "update:legend": null;
    "update:loadingIndicator": null;
    "update:margin": null;
    "update:negativesAsZeroes": null;
    "update:onArgumentAxisClick": null;
    "update:onDisposing": null;
    "update:onDone": null;
    "update:onDrawn": null;
    "update:onExported": null;
    "update:onExporting": null;
    "update:onFileSaving": null;
    "update:onIncidentOccurred": null;
    "update:onInitialized": null;
    "update:onLegendClick": null;
    "update:onOptionChanged": null;
    "update:onPointClick": null;
    "update:onPointHoverChanged": null;
    "update:onPointSelectionChanged": null;
    "update:onSeriesClick": null;
    "update:onSeriesHoverChanged": null;
    "update:onSeriesSelectionChanged": null;
    "update:onTooltipHidden": null;
    "update:onTooltipShown": null;
    "update:onZoomEnd": null;
    "update:onZoomStart": null;
    "update:palette": null;
    "update:paletteExtensionMode": null;
    "update:pathModified": null;
    "update:pointSelectionMode": null;
    "update:redrawOnResize": null;
    "update:resolveLabelOverlapping": null;
    "update:rtlEnabled": null;
    "update:series": null;
    "update:seriesSelectionMode": null;
    "update:seriesTemplate": null;
    "update:size": null;
    "update:theme": null;
    "update:title": null;
    "update:tooltip": null;
    "update:useSpiderWeb": null;
    "update:valueAxis": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    adaptiveLayout: PropType<Record<string, any>>;
    animation: PropType<boolean | Record<string, any>>;
    annotations: PropType<any[]>;
    argumentAxis: PropType<Record<string, any>>;
    barGroupPadding: NumberConstructor;
    barGroupWidth: NumberConstructor;
    commonAnnotationSettings: PropType<Record<string, any> | dxPolarChartCommonAnnotationConfig>;
    commonAxisSettings: PropType<Record<string, any>>;
    commonSeriesSettings: PropType<Record<string, any>>;
    containerBackgroundColor: StringConstructor;
    customizeAnnotation: PropType<(annotation: dxPolarChartAnnotationConfig | any) => dxPolarChartAnnotationConfig>;
    customizeLabel: PropType<(pointInfo: any) => SeriesLabel>;
    customizePoint: PropType<(pointInfo: any) => SeriesPoint>;
    dataPrepareSettings: PropType<Record<string, any>>;
    dataSource: PropType<string | any[] | Record<string, any> | DataSource<any, any> | DataSourceOptions<any, any, any, any> | Store<any, any> | null>;
    disabled: BooleanConstructor;
    elementAttr: PropType<Record<string, any>>;
    encodeHtml: BooleanConstructor;
    export: PropType<Record<string, any>>;
    legend: PropType<Record<string, any>>;
    loadingIndicator: PropType<Record<string, any>>;
    margin: PropType<Record<string, any>>;
    negativesAsZeroes: BooleanConstructor;
    onArgumentAxisClick: PropType<(e: ArgumentAxisClickEvent) => void>;
    onDisposing: PropType<(e: DisposingEvent) => void>;
    onDone: PropType<(e: DoneEvent) => void>;
    onDrawn: PropType<(e: DrawnEvent) => void>;
    onExported: PropType<(e: ExportedEvent) => void>;
    onExporting: PropType<(e: ExportingEvent) => void>;
    onFileSaving: PropType<(e: FileSavingEvent) => void>;
    onIncidentOccurred: PropType<(e: IncidentOccurredEvent) => void>;
    onInitialized: PropType<(e: InitializedEvent) => void>;
    onLegendClick: PropType<(e: LegendClickEvent) => void>;
    onOptionChanged: PropType<(e: OptionChangedEvent) => void>;
    onPointClick: PropType<(e: PointClickEvent) => void>;
    onPointHoverChanged: PropType<(e: PointHoverChangedEvent) => void>;
    onPointSelectionChanged: PropType<(e: PointSelectionChangedEvent) => void>;
    onSeriesClick: PropType<(e: SeriesClickEvent) => void>;
    onSeriesHoverChanged: PropType<(e: SeriesHoverChangedEvent) => void>;
    onSeriesSelectionChanged: PropType<(e: SeriesSelectionChangedEvent) => void>;
    onTooltipHidden: PropType<(e: TooltipHiddenEvent) => void>;
    onTooltipShown: PropType<(e: TooltipShownEvent) => void>;
    onZoomEnd: PropType<(e: ZoomEndEvent) => void>;
    onZoomStart: PropType<(e: ZoomStartEvent) => void>;
    palette: PropType<string[] | Palette>;
    paletteExtensionMode: PropType<PaletteExtensionMode>;
    pathModified: BooleanConstructor;
    pointSelectionMode: PropType<SingleOrMultiple>;
    redrawOnResize: BooleanConstructor;
    resolveLabelOverlapping: PropType<LabelOverlap>;
    rtlEnabled: BooleanConstructor;
    series: PropType<Record<string, any> | PolarChartSeries | PolarChartSeries[]>;
    seriesSelectionMode: PropType<SingleOrMultiple>;
    seriesTemplate: PropType<Record<string, any>>;
    size: PropType<Record<string, any>>;
    theme: PropType<Theme>;
    title: PropType<string | Record<string, any>>;
    tooltip: PropType<Record<string, any>>;
    useSpiderWeb: BooleanConstructor;
    valueAxis: PropType<Record<string, any>>;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:annotations"?: ((...args: any[]) => any) | undefined;
    "onUpdate:commonAnnotationSettings"?: ((...args: any[]) => any) | undefined;
    "onUpdate:customizeAnnotation"?: ((...args: any[]) => any) | undefined;
    "onUpdate:disabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:elementAttr"?: ((...args: any[]) => any) | undefined;
    "onUpdate:encodeHtml"?: ((...args: any[]) => any) | undefined;
    "onUpdate:export"?: ((...args: any[]) => any) | undefined;
    "onUpdate:loadingIndicator"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onDisposing"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onDrawn"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onExported"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onExporting"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onFileSaving"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onIncidentOccurred"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onInitialized"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onOptionChanged"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onTooltipHidden"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onTooltipShown"?: ((...args: any[]) => any) | undefined;
    "onUpdate:pathModified"?: ((...args: any[]) => any) | undefined;
    "onUpdate:redrawOnResize"?: ((...args: any[]) => any) | undefined;
    "onUpdate:rtlEnabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:size"?: ((...args: any[]) => any) | undefined;
    "onUpdate:theme"?: ((...args: any[]) => any) | undefined;
    "onUpdate:title"?: ((...args: any[]) => any) | undefined;
    "onUpdate:tooltip"?: ((...args: any[]) => any) | undefined;
    "onUpdate:margin"?: ((...args: any[]) => any) | undefined;
    "onUpdate:dataSource"?: ((...args: any[]) => any) | undefined;
    "onUpdate:palette"?: ((...args: any[]) => any) | undefined;
    "onUpdate:paletteExtensionMode"?: ((...args: any[]) => any) | undefined;
    "onUpdate:animation"?: ((...args: any[]) => any) | undefined;
    "onUpdate:adaptiveLayout"?: ((...args: any[]) => any) | undefined;
    "onUpdate:containerBackgroundColor"?: ((...args: any[]) => any) | undefined;
    "onUpdate:barGroupPadding"?: ((...args: any[]) => any) | undefined;
    "onUpdate:barGroupWidth"?: ((...args: any[]) => any) | undefined;
    "onUpdate:commonSeriesSettings"?: ((...args: any[]) => any) | undefined;
    "onUpdate:dataPrepareSettings"?: ((...args: any[]) => any) | undefined;
    "onUpdate:negativesAsZeroes"?: ((...args: any[]) => any) | undefined;
    "onUpdate:series"?: ((...args: any[]) => any) | undefined;
    "onUpdate:seriesTemplate"?: ((...args: any[]) => any) | undefined;
    "onUpdate:valueAxis"?: ((...args: any[]) => any) | undefined;
    "onUpdate:argumentAxis"?: ((...args: any[]) => any) | undefined;
    "onUpdate:commonAxisSettings"?: ((...args: any[]) => any) | undefined;
    "onUpdate:customizeLabel"?: ((...args: any[]) => any) | undefined;
    "onUpdate:customizePoint"?: ((...args: any[]) => any) | undefined;
    "onUpdate:legend"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onArgumentAxisClick"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onDone"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onLegendClick"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onPointClick"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onPointHoverChanged"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onPointSelectionChanged"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onSeriesClick"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onSeriesHoverChanged"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onSeriesSelectionChanged"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onZoomEnd"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onZoomStart"?: ((...args: any[]) => any) | undefined;
    "onUpdate:pointSelectionMode"?: ((...args: any[]) => any) | undefined;
    "onUpdate:resolveLabelOverlapping"?: ((...args: any[]) => any) | undefined;
    "onUpdate:seriesSelectionMode"?: ((...args: any[]) => any) | undefined;
    "onUpdate:useSpiderWeb"?: ((...args: any[]) => any) | undefined;
}, {
    disabled: boolean;
    encodeHtml: boolean;
    pathModified: boolean;
    redrawOnResize: boolean;
    rtlEnabled: boolean;
    negativesAsZeroes: boolean;
    useSpiderWeb: boolean;
}>;
declare const DxAdaptiveLayout: import("vue").DefineComponent<{
    height: NumberConstructor;
    keepLabels: BooleanConstructor;
    width: NumberConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:height": null;
    "update:keepLabels": null;
    "update:width": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    height: NumberConstructor;
    keepLabels: BooleanConstructor;
    width: NumberConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:height"?: ((...args: any[]) => any) | undefined;
    "onUpdate:width"?: ((...args: any[]) => any) | undefined;
    "onUpdate:keepLabels"?: ((...args: any[]) => any) | undefined;
}, {
    keepLabels: boolean;
}>;
declare const DxAnimation: import("vue").DefineComponent<{
    duration: NumberConstructor;
    easing: PropType<AnimationEaseMode>;
    enabled: BooleanConstructor;
    maxPointCountSupported: NumberConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:duration": null;
    "update:easing": null;
    "update:enabled": null;
    "update:maxPointCountSupported": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    duration: NumberConstructor;
    easing: PropType<AnimationEaseMode>;
    enabled: BooleanConstructor;
    maxPointCountSupported: NumberConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:enabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:duration"?: ((...args: any[]) => any) | undefined;
    "onUpdate:easing"?: ((...args: any[]) => any) | undefined;
    "onUpdate:maxPointCountSupported"?: ((...args: any[]) => any) | undefined;
}, {
    enabled: boolean;
}>;
declare const DxAnnotation: import("vue").DefineComponent<{
    allowDragging: BooleanConstructor;
    angle: NumberConstructor;
    argument: (DateConstructor | NumberConstructor | StringConstructor)[];
    arrowLength: NumberConstructor;
    arrowWidth: NumberConstructor;
    border: PropType<Record<string, any>>;
    color: StringConstructor;
    customizeTooltip: PropType<(annotation: dxPolarChartAnnotationConfig | any) => Record<string, any>>;
    data: {};
    description: StringConstructor;
    font: PropType<Record<string, any> | Font>;
    height: NumberConstructor;
    image: PropType<string | Record<string, any>>;
    name: StringConstructor;
    offsetX: NumberConstructor;
    offsetY: NumberConstructor;
    opacity: NumberConstructor;
    paddingLeftRight: NumberConstructor;
    paddingTopBottom: NumberConstructor;
    radius: NumberConstructor;
    series: StringConstructor;
    shadow: PropType<Record<string, any>>;
    template: {};
    text: StringConstructor;
    textOverflow: PropType<TextOverflow>;
    tooltipEnabled: BooleanConstructor;
    tooltipTemplate: {};
    type: PropType<AnnotationType>;
    value: (DateConstructor | NumberConstructor | StringConstructor)[];
    width: NumberConstructor;
    wordWrap: PropType<WordWrap>;
    x: NumberConstructor;
    y: NumberConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:allowDragging": null;
    "update:angle": null;
    "update:argument": null;
    "update:arrowLength": null;
    "update:arrowWidth": null;
    "update:border": null;
    "update:color": null;
    "update:customizeTooltip": null;
    "update:data": null;
    "update:description": null;
    "update:font": null;
    "update:height": null;
    "update:image": null;
    "update:name": null;
    "update:offsetX": null;
    "update:offsetY": null;
    "update:opacity": null;
    "update:paddingLeftRight": null;
    "update:paddingTopBottom": null;
    "update:radius": null;
    "update:series": null;
    "update:shadow": null;
    "update:template": null;
    "update:text": null;
    "update:textOverflow": null;
    "update:tooltipEnabled": null;
    "update:tooltipTemplate": null;
    "update:type": null;
    "update:value": null;
    "update:width": null;
    "update:wordWrap": null;
    "update:x": null;
    "update:y": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    allowDragging: BooleanConstructor;
    angle: NumberConstructor;
    argument: (DateConstructor | NumberConstructor | StringConstructor)[];
    arrowLength: NumberConstructor;
    arrowWidth: NumberConstructor;
    border: PropType<Record<string, any>>;
    color: StringConstructor;
    customizeTooltip: PropType<(annotation: dxPolarChartAnnotationConfig | any) => Record<string, any>>;
    data: {};
    description: StringConstructor;
    font: PropType<Record<string, any> | Font>;
    height: NumberConstructor;
    image: PropType<string | Record<string, any>>;
    name: StringConstructor;
    offsetX: NumberConstructor;
    offsetY: NumberConstructor;
    opacity: NumberConstructor;
    paddingLeftRight: NumberConstructor;
    paddingTopBottom: NumberConstructor;
    radius: NumberConstructor;
    series: StringConstructor;
    shadow: PropType<Record<string, any>>;
    template: {};
    text: StringConstructor;
    textOverflow: PropType<TextOverflow>;
    tooltipEnabled: BooleanConstructor;
    tooltipTemplate: {};
    type: PropType<AnnotationType>;
    value: (DateConstructor | NumberConstructor | StringConstructor)[];
    width: NumberConstructor;
    wordWrap: PropType<WordWrap>;
    x: NumberConstructor;
    y: NumberConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:allowDragging"?: ((...args: any[]) => any) | undefined;
    "onUpdate:arrowLength"?: ((...args: any[]) => any) | undefined;
    "onUpdate:arrowWidth"?: ((...args: any[]) => any) | undefined;
    "onUpdate:border"?: ((...args: any[]) => any) | undefined;
    "onUpdate:color"?: ((...args: any[]) => any) | undefined;
    "onUpdate:customizeTooltip"?: ((...args: any[]) => any) | undefined;
    "onUpdate:data"?: ((...args: any[]) => any) | undefined;
    "onUpdate:description"?: ((...args: any[]) => any) | undefined;
    "onUpdate:font"?: ((...args: any[]) => any) | undefined;
    "onUpdate:height"?: ((...args: any[]) => any) | undefined;
    "onUpdate:image"?: ((...args: any[]) => any) | undefined;
    "onUpdate:name"?: ((...args: any[]) => any) | undefined;
    "onUpdate:offsetX"?: ((...args: any[]) => any) | undefined;
    "onUpdate:offsetY"?: ((...args: any[]) => any) | undefined;
    "onUpdate:opacity"?: ((...args: any[]) => any) | undefined;
    "onUpdate:paddingLeftRight"?: ((...args: any[]) => any) | undefined;
    "onUpdate:paddingTopBottom"?: ((...args: any[]) => any) | undefined;
    "onUpdate:shadow"?: ((...args: any[]) => any) | undefined;
    "onUpdate:template"?: ((...args: any[]) => any) | undefined;
    "onUpdate:text"?: ((...args: any[]) => any) | undefined;
    "onUpdate:textOverflow"?: ((...args: any[]) => any) | undefined;
    "onUpdate:tooltipEnabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:tooltipTemplate"?: ((...args: any[]) => any) | undefined;
    "onUpdate:type"?: ((...args: any[]) => any) | undefined;
    "onUpdate:width"?: ((...args: any[]) => any) | undefined;
    "onUpdate:wordWrap"?: ((...args: any[]) => any) | undefined;
    "onUpdate:x"?: ((...args: any[]) => any) | undefined;
    "onUpdate:y"?: ((...args: any[]) => any) | undefined;
    "onUpdate:value"?: ((...args: any[]) => any) | undefined;
    "onUpdate:series"?: ((...args: any[]) => any) | undefined;
    "onUpdate:angle"?: ((...args: any[]) => any) | undefined;
    "onUpdate:argument"?: ((...args: any[]) => any) | undefined;
    "onUpdate:radius"?: ((...args: any[]) => any) | undefined;
}, {
    allowDragging: boolean;
    tooltipEnabled: boolean;
}>;
declare const DxAnnotationBorder: import("vue").DefineComponent<{
    color: StringConstructor;
    cornerRadius: NumberConstructor;
    dashStyle: PropType<DashStyle>;
    opacity: NumberConstructor;
    visible: BooleanConstructor;
    width: NumberConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:color": null;
    "update:cornerRadius": null;
    "update:dashStyle": null;
    "update:opacity": null;
    "update:visible": null;
    "update:width": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    color: StringConstructor;
    cornerRadius: NumberConstructor;
    dashStyle: PropType<DashStyle>;
    opacity: NumberConstructor;
    visible: BooleanConstructor;
    width: NumberConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:color"?: ((...args: any[]) => any) | undefined;
    "onUpdate:opacity"?: ((...args: any[]) => any) | undefined;
    "onUpdate:width"?: ((...args: any[]) => any) | undefined;
    "onUpdate:cornerRadius"?: ((...args: any[]) => any) | undefined;
    "onUpdate:dashStyle"?: ((...args: any[]) => any) | undefined;
    "onUpdate:visible"?: ((...args: any[]) => any) | undefined;
}, {
    visible: boolean;
}>;
declare const DxArgumentAxis: import("vue").DefineComponent<{
    allowDecimals: BooleanConstructor;
    argumentType: PropType<ChartsDataType>;
    axisDivisionFactor: NumberConstructor;
    categories: PropType<(string | number | Date)[]>;
    color: StringConstructor;
    constantLines: PropType<Record<string, any>[]>;
    constantLineStyle: PropType<Record<string, any>>;
    discreteAxisDivisionMode: PropType<DiscreteAxisDivisionMode>;
    endOnTick: BooleanConstructor;
    firstPointOnStartAngle: BooleanConstructor;
    grid: PropType<Record<string, any>>;
    hoverMode: PropType<ArgumentAxisHoverMode>;
    inverted: BooleanConstructor;
    label: PropType<Record<string, any>>;
    linearThreshold: NumberConstructor;
    logarithmBase: NumberConstructor;
    minorGrid: PropType<Record<string, any>>;
    minorTick: PropType<Record<string, any>>;
    minorTickCount: NumberConstructor;
    minorTickInterval: PropType<number | Record<string, any> | TimeInterval>;
    opacity: NumberConstructor;
    originValue: NumberConstructor;
    period: NumberConstructor;
    startAngle: NumberConstructor;
    strips: PropType<Record<string, any>[]>;
    stripStyle: PropType<Record<string, any>>;
    tick: PropType<Record<string, any>>;
    tickInterval: PropType<number | Record<string, any> | TimeInterval>;
    type: PropType<AxisScaleType>;
    visible: BooleanConstructor;
    width: NumberConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:allowDecimals": null;
    "update:argumentType": null;
    "update:axisDivisionFactor": null;
    "update:categories": null;
    "update:color": null;
    "update:constantLines": null;
    "update:constantLineStyle": null;
    "update:discreteAxisDivisionMode": null;
    "update:endOnTick": null;
    "update:firstPointOnStartAngle": null;
    "update:grid": null;
    "update:hoverMode": null;
    "update:inverted": null;
    "update:label": null;
    "update:linearThreshold": null;
    "update:logarithmBase": null;
    "update:minorGrid": null;
    "update:minorTick": null;
    "update:minorTickCount": null;
    "update:minorTickInterval": null;
    "update:opacity": null;
    "update:originValue": null;
    "update:period": null;
    "update:startAngle": null;
    "update:strips": null;
    "update:stripStyle": null;
    "update:tick": null;
    "update:tickInterval": null;
    "update:type": null;
    "update:visible": null;
    "update:width": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    allowDecimals: BooleanConstructor;
    argumentType: PropType<ChartsDataType>;
    axisDivisionFactor: NumberConstructor;
    categories: PropType<(string | number | Date)[]>;
    color: StringConstructor;
    constantLines: PropType<Record<string, any>[]>;
    constantLineStyle: PropType<Record<string, any>>;
    discreteAxisDivisionMode: PropType<DiscreteAxisDivisionMode>;
    endOnTick: BooleanConstructor;
    firstPointOnStartAngle: BooleanConstructor;
    grid: PropType<Record<string, any>>;
    hoverMode: PropType<ArgumentAxisHoverMode>;
    inverted: BooleanConstructor;
    label: PropType<Record<string, any>>;
    linearThreshold: NumberConstructor;
    logarithmBase: NumberConstructor;
    minorGrid: PropType<Record<string, any>>;
    minorTick: PropType<Record<string, any>>;
    minorTickCount: NumberConstructor;
    minorTickInterval: PropType<number | Record<string, any> | TimeInterval>;
    opacity: NumberConstructor;
    originValue: NumberConstructor;
    period: NumberConstructor;
    startAngle: NumberConstructor;
    strips: PropType<Record<string, any>[]>;
    stripStyle: PropType<Record<string, any>>;
    tick: PropType<Record<string, any>>;
    tickInterval: PropType<number | Record<string, any> | TimeInterval>;
    type: PropType<AxisScaleType>;
    visible: BooleanConstructor;
    width: NumberConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:color"?: ((...args: any[]) => any) | undefined;
    "onUpdate:opacity"?: ((...args: any[]) => any) | undefined;
    "onUpdate:type"?: ((...args: any[]) => any) | undefined;
    "onUpdate:width"?: ((...args: any[]) => any) | undefined;
    "onUpdate:visible"?: ((...args: any[]) => any) | undefined;
    "onUpdate:label"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoverMode"?: ((...args: any[]) => any) | undefined;
    "onUpdate:allowDecimals"?: ((...args: any[]) => any) | undefined;
    "onUpdate:categories"?: ((...args: any[]) => any) | undefined;
    "onUpdate:discreteAxisDivisionMode"?: ((...args: any[]) => any) | undefined;
    "onUpdate:endOnTick"?: ((...args: any[]) => any) | undefined;
    "onUpdate:linearThreshold"?: ((...args: any[]) => any) | undefined;
    "onUpdate:logarithmBase"?: ((...args: any[]) => any) | undefined;
    "onUpdate:minorTick"?: ((...args: any[]) => any) | undefined;
    "onUpdate:minorTickCount"?: ((...args: any[]) => any) | undefined;
    "onUpdate:minorTickInterval"?: ((...args: any[]) => any) | undefined;
    "onUpdate:tick"?: ((...args: any[]) => any) | undefined;
    "onUpdate:tickInterval"?: ((...args: any[]) => any) | undefined;
    "onUpdate:inverted"?: ((...args: any[]) => any) | undefined;
    "onUpdate:argumentType"?: ((...args: any[]) => any) | undefined;
    "onUpdate:axisDivisionFactor"?: ((...args: any[]) => any) | undefined;
    "onUpdate:constantLines"?: ((...args: any[]) => any) | undefined;
    "onUpdate:constantLineStyle"?: ((...args: any[]) => any) | undefined;
    "onUpdate:firstPointOnStartAngle"?: ((...args: any[]) => any) | undefined;
    "onUpdate:grid"?: ((...args: any[]) => any) | undefined;
    "onUpdate:minorGrid"?: ((...args: any[]) => any) | undefined;
    "onUpdate:originValue"?: ((...args: any[]) => any) | undefined;
    "onUpdate:period"?: ((...args: any[]) => any) | undefined;
    "onUpdate:startAngle"?: ((...args: any[]) => any) | undefined;
    "onUpdate:strips"?: ((...args: any[]) => any) | undefined;
    "onUpdate:stripStyle"?: ((...args: any[]) => any) | undefined;
}, {
    visible: boolean;
    allowDecimals: boolean;
    endOnTick: boolean;
    inverted: boolean;
    firstPointOnStartAngle: boolean;
}>;
declare const DxArgumentAxisMinorTick: import("vue").DefineComponent<{
    color: StringConstructor;
    length: NumberConstructor;
    opacity: NumberConstructor;
    shift: NumberConstructor;
    visible: BooleanConstructor;
    width: NumberConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:color": null;
    "update:length": null;
    "update:opacity": null;
    "update:shift": null;
    "update:visible": null;
    "update:width": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    color: StringConstructor;
    length: NumberConstructor;
    opacity: NumberConstructor;
    shift: NumberConstructor;
    visible: BooleanConstructor;
    width: NumberConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:color"?: ((...args: any[]) => any) | undefined;
    "onUpdate:opacity"?: ((...args: any[]) => any) | undefined;
    "onUpdate:width"?: ((...args: any[]) => any) | undefined;
    "onUpdate:visible"?: ((...args: any[]) => any) | undefined;
    "onUpdate:length"?: ((...args: any[]) => any) | undefined;
    "onUpdate:shift"?: ((...args: any[]) => any) | undefined;
}, {
    visible: boolean;
}>;
declare const DxArgumentAxisTick: import("vue").DefineComponent<{
    color: StringConstructor;
    length: NumberConstructor;
    opacity: NumberConstructor;
    shift: NumberConstructor;
    visible: BooleanConstructor;
    width: NumberConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:color": null;
    "update:length": null;
    "update:opacity": null;
    "update:shift": null;
    "update:visible": null;
    "update:width": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    color: StringConstructor;
    length: NumberConstructor;
    opacity: NumberConstructor;
    shift: NumberConstructor;
    visible: BooleanConstructor;
    width: NumberConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:color"?: ((...args: any[]) => any) | undefined;
    "onUpdate:opacity"?: ((...args: any[]) => any) | undefined;
    "onUpdate:width"?: ((...args: any[]) => any) | undefined;
    "onUpdate:visible"?: ((...args: any[]) => any) | undefined;
    "onUpdate:length"?: ((...args: any[]) => any) | undefined;
    "onUpdate:shift"?: ((...args: any[]) => any) | undefined;
}, {
    visible: boolean;
}>;
declare const DxArgumentFormat: import("vue").DefineComponent<{
    currency: StringConstructor;
    formatter: PropType<(value: number | Date) => string>;
    parser: PropType<(value: string) => number | Date>;
    precision: NumberConstructor;
    type: PropType<string>;
    useCurrencyAccountingStyle: BooleanConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:currency": null;
    "update:formatter": null;
    "update:parser": null;
    "update:precision": null;
    "update:type": null;
    "update:useCurrencyAccountingStyle": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    currency: StringConstructor;
    formatter: PropType<(value: number | Date) => string>;
    parser: PropType<(value: string) => number | Date>;
    precision: NumberConstructor;
    type: PropType<string>;
    useCurrencyAccountingStyle: BooleanConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:type"?: ((...args: any[]) => any) | undefined;
    "onUpdate:currency"?: ((...args: any[]) => any) | undefined;
    "onUpdate:formatter"?: ((...args: any[]) => any) | undefined;
    "onUpdate:parser"?: ((...args: any[]) => any) | undefined;
    "onUpdate:precision"?: ((...args: any[]) => any) | undefined;
    "onUpdate:useCurrencyAccountingStyle"?: ((...args: any[]) => any) | undefined;
}, {
    useCurrencyAccountingStyle: boolean;
}>;
declare const DxAxisLabel: import("vue").DefineComponent<{
    customizeHint: PropType<(argument: {
        value: Date | number | string;
        valueText: string;
    }) => string>;
    customizeText: PropType<(argument: {
        value: Date | number | string;
        valueText: string;
    }) => string>;
    font: PropType<Record<string, any> | Font>;
    format: PropType<string | Record<string, any> | import("devextreme/common/core/localization").FormatObject | ((value: number | Date) => string) | ((value: Date) => string) | ((value: number) => string) | Intl.DateTimeFormatOptions | Intl.NumberFormatOptions | ((value: number | Date) => string) | undefined>;
    indentFromAxis: NumberConstructor;
    overlappingBehavior: PropType<LabelOverlap>;
    visible: BooleanConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:customizeHint": null;
    "update:customizeText": null;
    "update:font": null;
    "update:format": null;
    "update:indentFromAxis": null;
    "update:overlappingBehavior": null;
    "update:visible": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    customizeHint: PropType<(argument: {
        value: Date | number | string;
        valueText: string;
    }) => string>;
    customizeText: PropType<(argument: {
        value: Date | number | string;
        valueText: string;
    }) => string>;
    font: PropType<Record<string, any> | Font>;
    format: PropType<string | Record<string, any> | import("devextreme/common/core/localization").FormatObject | ((value: number | Date) => string) | ((value: Date) => string) | ((value: number) => string) | Intl.DateTimeFormatOptions | Intl.NumberFormatOptions | ((value: number | Date) => string) | undefined>;
    indentFromAxis: NumberConstructor;
    overlappingBehavior: PropType<LabelOverlap>;
    visible: BooleanConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:font"?: ((...args: any[]) => any) | undefined;
    "onUpdate:visible"?: ((...args: any[]) => any) | undefined;
    "onUpdate:customizeHint"?: ((...args: any[]) => any) | undefined;
    "onUpdate:customizeText"?: ((...args: any[]) => any) | undefined;
    "onUpdate:format"?: ((...args: any[]) => any) | undefined;
    "onUpdate:overlappingBehavior"?: ((...args: any[]) => any) | undefined;
    "onUpdate:indentFromAxis"?: ((...args: any[]) => any) | undefined;
}, {
    visible: boolean;
}>;
declare const DxBorder: import("vue").DefineComponent<{
    color: StringConstructor;
    cornerRadius: NumberConstructor;
    dashStyle: PropType<DashStyle>;
    opacity: NumberConstructor;
    visible: BooleanConstructor;
    width: NumberConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:color": null;
    "update:cornerRadius": null;
    "update:dashStyle": null;
    "update:opacity": null;
    "update:visible": null;
    "update:width": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    color: StringConstructor;
    cornerRadius: NumberConstructor;
    dashStyle: PropType<DashStyle>;
    opacity: NumberConstructor;
    visible: BooleanConstructor;
    width: NumberConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:color"?: ((...args: any[]) => any) | undefined;
    "onUpdate:opacity"?: ((...args: any[]) => any) | undefined;
    "onUpdate:width"?: ((...args: any[]) => any) | undefined;
    "onUpdate:cornerRadius"?: ((...args: any[]) => any) | undefined;
    "onUpdate:dashStyle"?: ((...args: any[]) => any) | undefined;
    "onUpdate:visible"?: ((...args: any[]) => any) | undefined;
}, {
    visible: boolean;
}>;
declare const DxColor: import("vue").DefineComponent<{
    base: StringConstructor;
    fillId: StringConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:base": null;
    "update:fillId": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    base: StringConstructor;
    fillId: StringConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:base"?: ((...args: any[]) => any) | undefined;
    "onUpdate:fillId"?: ((...args: any[]) => any) | undefined;
}, {}>;
declare const DxCommonAnnotationSettings: import("vue").DefineComponent<{
    allowDragging: BooleanConstructor;
    angle: NumberConstructor;
    argument: (DateConstructor | NumberConstructor | StringConstructor)[];
    arrowLength: NumberConstructor;
    arrowWidth: NumberConstructor;
    border: PropType<Record<string, any>>;
    color: StringConstructor;
    customizeTooltip: PropType<(annotation: dxPolarChartAnnotationConfig | any) => Record<string, any>>;
    data: {};
    description: StringConstructor;
    font: PropType<Record<string, any> | Font>;
    height: NumberConstructor;
    image: PropType<string | Record<string, any>>;
    offsetX: NumberConstructor;
    offsetY: NumberConstructor;
    opacity: NumberConstructor;
    paddingLeftRight: NumberConstructor;
    paddingTopBottom: NumberConstructor;
    radius: NumberConstructor;
    series: StringConstructor;
    shadow: PropType<Record<string, any>>;
    template: {};
    text: StringConstructor;
    textOverflow: PropType<TextOverflow>;
    tooltipEnabled: BooleanConstructor;
    tooltipTemplate: {};
    type: PropType<AnnotationType>;
    value: (DateConstructor | NumberConstructor | StringConstructor)[];
    width: NumberConstructor;
    wordWrap: PropType<WordWrap>;
    x: NumberConstructor;
    y: NumberConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:allowDragging": null;
    "update:angle": null;
    "update:argument": null;
    "update:arrowLength": null;
    "update:arrowWidth": null;
    "update:border": null;
    "update:color": null;
    "update:customizeTooltip": null;
    "update:data": null;
    "update:description": null;
    "update:font": null;
    "update:height": null;
    "update:image": null;
    "update:offsetX": null;
    "update:offsetY": null;
    "update:opacity": null;
    "update:paddingLeftRight": null;
    "update:paddingTopBottom": null;
    "update:radius": null;
    "update:series": null;
    "update:shadow": null;
    "update:template": null;
    "update:text": null;
    "update:textOverflow": null;
    "update:tooltipEnabled": null;
    "update:tooltipTemplate": null;
    "update:type": null;
    "update:value": null;
    "update:width": null;
    "update:wordWrap": null;
    "update:x": null;
    "update:y": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    allowDragging: BooleanConstructor;
    angle: NumberConstructor;
    argument: (DateConstructor | NumberConstructor | StringConstructor)[];
    arrowLength: NumberConstructor;
    arrowWidth: NumberConstructor;
    border: PropType<Record<string, any>>;
    color: StringConstructor;
    customizeTooltip: PropType<(annotation: dxPolarChartAnnotationConfig | any) => Record<string, any>>;
    data: {};
    description: StringConstructor;
    font: PropType<Record<string, any> | Font>;
    height: NumberConstructor;
    image: PropType<string | Record<string, any>>;
    offsetX: NumberConstructor;
    offsetY: NumberConstructor;
    opacity: NumberConstructor;
    paddingLeftRight: NumberConstructor;
    paddingTopBottom: NumberConstructor;
    radius: NumberConstructor;
    series: StringConstructor;
    shadow: PropType<Record<string, any>>;
    template: {};
    text: StringConstructor;
    textOverflow: PropType<TextOverflow>;
    tooltipEnabled: BooleanConstructor;
    tooltipTemplate: {};
    type: PropType<AnnotationType>;
    value: (DateConstructor | NumberConstructor | StringConstructor)[];
    width: NumberConstructor;
    wordWrap: PropType<WordWrap>;
    x: NumberConstructor;
    y: NumberConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:allowDragging"?: ((...args: any[]) => any) | undefined;
    "onUpdate:arrowLength"?: ((...args: any[]) => any) | undefined;
    "onUpdate:arrowWidth"?: ((...args: any[]) => any) | undefined;
    "onUpdate:border"?: ((...args: any[]) => any) | undefined;
    "onUpdate:color"?: ((...args: any[]) => any) | undefined;
    "onUpdate:customizeTooltip"?: ((...args: any[]) => any) | undefined;
    "onUpdate:data"?: ((...args: any[]) => any) | undefined;
    "onUpdate:description"?: ((...args: any[]) => any) | undefined;
    "onUpdate:font"?: ((...args: any[]) => any) | undefined;
    "onUpdate:height"?: ((...args: any[]) => any) | undefined;
    "onUpdate:image"?: ((...args: any[]) => any) | undefined;
    "onUpdate:offsetX"?: ((...args: any[]) => any) | undefined;
    "onUpdate:offsetY"?: ((...args: any[]) => any) | undefined;
    "onUpdate:opacity"?: ((...args: any[]) => any) | undefined;
    "onUpdate:paddingLeftRight"?: ((...args: any[]) => any) | undefined;
    "onUpdate:paddingTopBottom"?: ((...args: any[]) => any) | undefined;
    "onUpdate:shadow"?: ((...args: any[]) => any) | undefined;
    "onUpdate:template"?: ((...args: any[]) => any) | undefined;
    "onUpdate:text"?: ((...args: any[]) => any) | undefined;
    "onUpdate:textOverflow"?: ((...args: any[]) => any) | undefined;
    "onUpdate:tooltipEnabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:tooltipTemplate"?: ((...args: any[]) => any) | undefined;
    "onUpdate:type"?: ((...args: any[]) => any) | undefined;
    "onUpdate:width"?: ((...args: any[]) => any) | undefined;
    "onUpdate:wordWrap"?: ((...args: any[]) => any) | undefined;
    "onUpdate:x"?: ((...args: any[]) => any) | undefined;
    "onUpdate:y"?: ((...args: any[]) => any) | undefined;
    "onUpdate:value"?: ((...args: any[]) => any) | undefined;
    "onUpdate:series"?: ((...args: any[]) => any) | undefined;
    "onUpdate:angle"?: ((...args: any[]) => any) | undefined;
    "onUpdate:argument"?: ((...args: any[]) => any) | undefined;
    "onUpdate:radius"?: ((...args: any[]) => any) | undefined;
}, {
    allowDragging: boolean;
    tooltipEnabled: boolean;
}>;
declare const DxCommonAxisSettings: import("vue").DefineComponent<{
    allowDecimals: BooleanConstructor;
    color: StringConstructor;
    constantLineStyle: PropType<Record<string, any>>;
    discreteAxisDivisionMode: PropType<DiscreteAxisDivisionMode>;
    endOnTick: BooleanConstructor;
    grid: PropType<Record<string, any>>;
    inverted: BooleanConstructor;
    label: PropType<Record<string, any>>;
    minorGrid: PropType<Record<string, any>>;
    minorTick: PropType<Record<string, any>>;
    opacity: NumberConstructor;
    stripStyle: PropType<Record<string, any>>;
    tick: PropType<Record<string, any>>;
    visible: BooleanConstructor;
    width: NumberConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:allowDecimals": null;
    "update:color": null;
    "update:constantLineStyle": null;
    "update:discreteAxisDivisionMode": null;
    "update:endOnTick": null;
    "update:grid": null;
    "update:inverted": null;
    "update:label": null;
    "update:minorGrid": null;
    "update:minorTick": null;
    "update:opacity": null;
    "update:stripStyle": null;
    "update:tick": null;
    "update:visible": null;
    "update:width": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    allowDecimals: BooleanConstructor;
    color: StringConstructor;
    constantLineStyle: PropType<Record<string, any>>;
    discreteAxisDivisionMode: PropType<DiscreteAxisDivisionMode>;
    endOnTick: BooleanConstructor;
    grid: PropType<Record<string, any>>;
    inverted: BooleanConstructor;
    label: PropType<Record<string, any>>;
    minorGrid: PropType<Record<string, any>>;
    minorTick: PropType<Record<string, any>>;
    opacity: NumberConstructor;
    stripStyle: PropType<Record<string, any>>;
    tick: PropType<Record<string, any>>;
    visible: BooleanConstructor;
    width: NumberConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:color"?: ((...args: any[]) => any) | undefined;
    "onUpdate:opacity"?: ((...args: any[]) => any) | undefined;
    "onUpdate:width"?: ((...args: any[]) => any) | undefined;
    "onUpdate:visible"?: ((...args: any[]) => any) | undefined;
    "onUpdate:label"?: ((...args: any[]) => any) | undefined;
    "onUpdate:allowDecimals"?: ((...args: any[]) => any) | undefined;
    "onUpdate:discreteAxisDivisionMode"?: ((...args: any[]) => any) | undefined;
    "onUpdate:endOnTick"?: ((...args: any[]) => any) | undefined;
    "onUpdate:minorTick"?: ((...args: any[]) => any) | undefined;
    "onUpdate:tick"?: ((...args: any[]) => any) | undefined;
    "onUpdate:inverted"?: ((...args: any[]) => any) | undefined;
    "onUpdate:constantLineStyle"?: ((...args: any[]) => any) | undefined;
    "onUpdate:grid"?: ((...args: any[]) => any) | undefined;
    "onUpdate:minorGrid"?: ((...args: any[]) => any) | undefined;
    "onUpdate:stripStyle"?: ((...args: any[]) => any) | undefined;
}, {
    visible: boolean;
    allowDecimals: boolean;
    endOnTick: boolean;
    inverted: boolean;
}>;
declare const DxCommonAxisSettingsLabel: import("vue").DefineComponent<{
    font: PropType<Record<string, any> | Font>;
    indentFromAxis: NumberConstructor;
    overlappingBehavior: PropType<LabelOverlap>;
    visible: BooleanConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:font": null;
    "update:indentFromAxis": null;
    "update:overlappingBehavior": null;
    "update:visible": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    font: PropType<Record<string, any> | Font>;
    indentFromAxis: NumberConstructor;
    overlappingBehavior: PropType<LabelOverlap>;
    visible: BooleanConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:font"?: ((...args: any[]) => any) | undefined;
    "onUpdate:visible"?: ((...args: any[]) => any) | undefined;
    "onUpdate:overlappingBehavior"?: ((...args: any[]) => any) | undefined;
    "onUpdate:indentFromAxis"?: ((...args: any[]) => any) | undefined;
}, {
    visible: boolean;
}>;
declare const DxCommonAxisSettingsMinorTick: import("vue").DefineComponent<{
    color: StringConstructor;
    length: NumberConstructor;
    opacity: NumberConstructor;
    visible: BooleanConstructor;
    width: NumberConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:color": null;
    "update:length": null;
    "update:opacity": null;
    "update:visible": null;
    "update:width": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    color: StringConstructor;
    length: NumberConstructor;
    opacity: NumberConstructor;
    visible: BooleanConstructor;
    width: NumberConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:color"?: ((...args: any[]) => any) | undefined;
    "onUpdate:opacity"?: ((...args: any[]) => any) | undefined;
    "onUpdate:width"?: ((...args: any[]) => any) | undefined;
    "onUpdate:visible"?: ((...args: any[]) => any) | undefined;
    "onUpdate:length"?: ((...args: any[]) => any) | undefined;
}, {
    visible: boolean;
}>;
declare const DxCommonAxisSettingsTick: import("vue").DefineComponent<{
    color: StringConstructor;
    length: NumberConstructor;
    opacity: NumberConstructor;
    visible: BooleanConstructor;
    width: NumberConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:color": null;
    "update:length": null;
    "update:opacity": null;
    "update:visible": null;
    "update:width": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    color: StringConstructor;
    length: NumberConstructor;
    opacity: NumberConstructor;
    visible: BooleanConstructor;
    width: NumberConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:color"?: ((...args: any[]) => any) | undefined;
    "onUpdate:opacity"?: ((...args: any[]) => any) | undefined;
    "onUpdate:width"?: ((...args: any[]) => any) | undefined;
    "onUpdate:visible"?: ((...args: any[]) => any) | undefined;
    "onUpdate:length"?: ((...args: any[]) => any) | undefined;
}, {
    visible: boolean;
}>;
declare const DxCommonSeriesSettings: import("vue").DefineComponent<{
    area: {};
    argumentField: StringConstructor;
    bar: {};
    barPadding: NumberConstructor;
    barWidth: NumberConstructor;
    border: PropType<Record<string, any>>;
    closed: BooleanConstructor;
    color: PropType<string | Record<string, any> | ChartsColor>;
    dashStyle: PropType<DashStyle>;
    hoverMode: PropType<SeriesHoverMode>;
    hoverStyle: PropType<Record<string, any>>;
    ignoreEmptyPoints: BooleanConstructor;
    label: PropType<Record<string, any>>;
    line: {};
    maxLabelCount: NumberConstructor;
    minBarSize: NumberConstructor;
    opacity: NumberConstructor;
    point: PropType<Record<string, any>>;
    scatter: {};
    selectionMode: PropType<SeriesSelectionMode>;
    selectionStyle: PropType<Record<string, any>>;
    showInLegend: BooleanConstructor;
    stack: StringConstructor;
    stackedbar: {};
    tagField: StringConstructor;
    type: PropType<PolarChartSeriesType>;
    valueErrorBar: PropType<Record<string, any>>;
    valueField: StringConstructor;
    visible: BooleanConstructor;
    width: NumberConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:area": null;
    "update:argumentField": null;
    "update:bar": null;
    "update:barPadding": null;
    "update:barWidth": null;
    "update:border": null;
    "update:closed": null;
    "update:color": null;
    "update:dashStyle": null;
    "update:hoverMode": null;
    "update:hoverStyle": null;
    "update:ignoreEmptyPoints": null;
    "update:label": null;
    "update:line": null;
    "update:maxLabelCount": null;
    "update:minBarSize": null;
    "update:opacity": null;
    "update:point": null;
    "update:scatter": null;
    "update:selectionMode": null;
    "update:selectionStyle": null;
    "update:showInLegend": null;
    "update:stack": null;
    "update:stackedbar": null;
    "update:tagField": null;
    "update:type": null;
    "update:valueErrorBar": null;
    "update:valueField": null;
    "update:visible": null;
    "update:width": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    area: {};
    argumentField: StringConstructor;
    bar: {};
    barPadding: NumberConstructor;
    barWidth: NumberConstructor;
    border: PropType<Record<string, any>>;
    closed: BooleanConstructor;
    color: PropType<string | Record<string, any> | ChartsColor>;
    dashStyle: PropType<DashStyle>;
    hoverMode: PropType<SeriesHoverMode>;
    hoverStyle: PropType<Record<string, any>>;
    ignoreEmptyPoints: BooleanConstructor;
    label: PropType<Record<string, any>>;
    line: {};
    maxLabelCount: NumberConstructor;
    minBarSize: NumberConstructor;
    opacity: NumberConstructor;
    point: PropType<Record<string, any>>;
    scatter: {};
    selectionMode: PropType<SeriesSelectionMode>;
    selectionStyle: PropType<Record<string, any>>;
    showInLegend: BooleanConstructor;
    stack: StringConstructor;
    stackedbar: {};
    tagField: StringConstructor;
    type: PropType<PolarChartSeriesType>;
    valueErrorBar: PropType<Record<string, any>>;
    valueField: StringConstructor;
    visible: BooleanConstructor;
    width: NumberConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:border"?: ((...args: any[]) => any) | undefined;
    "onUpdate:color"?: ((...args: any[]) => any) | undefined;
    "onUpdate:opacity"?: ((...args: any[]) => any) | undefined;
    "onUpdate:type"?: ((...args: any[]) => any) | undefined;
    "onUpdate:width"?: ((...args: any[]) => any) | undefined;
    "onUpdate:dashStyle"?: ((...args: any[]) => any) | undefined;
    "onUpdate:visible"?: ((...args: any[]) => any) | undefined;
    "onUpdate:label"?: ((...args: any[]) => any) | undefined;
    "onUpdate:selectionMode"?: ((...args: any[]) => any) | undefined;
    "onUpdate:valueField"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoverStyle"?: ((...args: any[]) => any) | undefined;
    "onUpdate:selectionStyle"?: ((...args: any[]) => any) | undefined;
    "onUpdate:argumentField"?: ((...args: any[]) => any) | undefined;
    "onUpdate:ignoreEmptyPoints"?: ((...args: any[]) => any) | undefined;
    "onUpdate:area"?: ((...args: any[]) => any) | undefined;
    "onUpdate:line"?: ((...args: any[]) => any) | undefined;
    "onUpdate:bar"?: ((...args: any[]) => any) | undefined;
    "onUpdate:barPadding"?: ((...args: any[]) => any) | undefined;
    "onUpdate:barWidth"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoverMode"?: ((...args: any[]) => any) | undefined;
    "onUpdate:maxLabelCount"?: ((...args: any[]) => any) | undefined;
    "onUpdate:minBarSize"?: ((...args: any[]) => any) | undefined;
    "onUpdate:point"?: ((...args: any[]) => any) | undefined;
    "onUpdate:scatter"?: ((...args: any[]) => any) | undefined;
    "onUpdate:showInLegend"?: ((...args: any[]) => any) | undefined;
    "onUpdate:stack"?: ((...args: any[]) => any) | undefined;
    "onUpdate:stackedbar"?: ((...args: any[]) => any) | undefined;
    "onUpdate:tagField"?: ((...args: any[]) => any) | undefined;
    "onUpdate:valueErrorBar"?: ((...args: any[]) => any) | undefined;
    "onUpdate:closed"?: ((...args: any[]) => any) | undefined;
}, {
    visible: boolean;
    ignoreEmptyPoints: boolean;
    showInLegend: boolean;
    closed: boolean;
}>;
declare const DxCommonSeriesSettingsHoverStyle: import("vue").DefineComponent<{
    border: PropType<Record<string, any>>;
    color: PropType<string | Record<string, any> | ChartsColor>;
    dashStyle: PropType<DashStyle>;
    hatching: PropType<Record<string, any>>;
    highlight: BooleanConstructor;
    width: NumberConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:border": null;
    "update:color": null;
    "update:dashStyle": null;
    "update:hatching": null;
    "update:highlight": null;
    "update:width": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    border: PropType<Record<string, any>>;
    color: PropType<string | Record<string, any> | ChartsColor>;
    dashStyle: PropType<DashStyle>;
    hatching: PropType<Record<string, any>>;
    highlight: BooleanConstructor;
    width: NumberConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:border"?: ((...args: any[]) => any) | undefined;
    "onUpdate:color"?: ((...args: any[]) => any) | undefined;
    "onUpdate:width"?: ((...args: any[]) => any) | undefined;
    "onUpdate:dashStyle"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hatching"?: ((...args: any[]) => any) | undefined;
    "onUpdate:highlight"?: ((...args: any[]) => any) | undefined;
}, {
    highlight: boolean;
}>;
declare const DxCommonSeriesSettingsLabel: import("vue").DefineComponent<{
    argumentFormat: PropType<string | Record<string, any> | import("devextreme/common/core/localization").FormatObject | ((value: number | Date) => string) | ((value: Date) => string) | ((value: number) => string) | Intl.DateTimeFormatOptions | Intl.NumberFormatOptions | ((value: number | Date) => string) | undefined>;
    backgroundColor: StringConstructor;
    border: PropType<Record<string, any>>;
    connector: PropType<Record<string, any>>;
    customizeText: PropType<(pointInfo: any) => string>;
    displayFormat: StringConstructor;
    font: PropType<Record<string, any> | Font>;
    format: PropType<string | Record<string, any> | import("devextreme/common/core/localization").FormatObject | ((value: number | Date) => string) | ((value: Date) => string) | ((value: number) => string) | Intl.DateTimeFormatOptions | Intl.NumberFormatOptions | ((value: number | Date) => string) | undefined>;
    position: PropType<RelativePosition>;
    rotationAngle: NumberConstructor;
    showForZeroValues: BooleanConstructor;
    visible: BooleanConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:argumentFormat": null;
    "update:backgroundColor": null;
    "update:border": null;
    "update:connector": null;
    "update:customizeText": null;
    "update:displayFormat": null;
    "update:font": null;
    "update:format": null;
    "update:position": null;
    "update:rotationAngle": null;
    "update:showForZeroValues": null;
    "update:visible": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    argumentFormat: PropType<string | Record<string, any> | import("devextreme/common/core/localization").FormatObject | ((value: number | Date) => string) | ((value: Date) => string) | ((value: number) => string) | Intl.DateTimeFormatOptions | Intl.NumberFormatOptions | ((value: number | Date) => string) | undefined>;
    backgroundColor: StringConstructor;
    border: PropType<Record<string, any>>;
    connector: PropType<Record<string, any>>;
    customizeText: PropType<(pointInfo: any) => string>;
    displayFormat: StringConstructor;
    font: PropType<Record<string, any> | Font>;
    format: PropType<string | Record<string, any> | import("devextreme/common/core/localization").FormatObject | ((value: number | Date) => string) | ((value: Date) => string) | ((value: number) => string) | Intl.DateTimeFormatOptions | Intl.NumberFormatOptions | ((value: number | Date) => string) | undefined>;
    position: PropType<RelativePosition>;
    rotationAngle: NumberConstructor;
    showForZeroValues: BooleanConstructor;
    visible: BooleanConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:border"?: ((...args: any[]) => any) | undefined;
    "onUpdate:font"?: ((...args: any[]) => any) | undefined;
    "onUpdate:visible"?: ((...args: any[]) => any) | undefined;
    "onUpdate:backgroundColor"?: ((...args: any[]) => any) | undefined;
    "onUpdate:customizeText"?: ((...args: any[]) => any) | undefined;
    "onUpdate:format"?: ((...args: any[]) => any) | undefined;
    "onUpdate:position"?: ((...args: any[]) => any) | undefined;
    "onUpdate:argumentFormat"?: ((...args: any[]) => any) | undefined;
    "onUpdate:connector"?: ((...args: any[]) => any) | undefined;
    "onUpdate:displayFormat"?: ((...args: any[]) => any) | undefined;
    "onUpdate:rotationAngle"?: ((...args: any[]) => any) | undefined;
    "onUpdate:showForZeroValues"?: ((...args: any[]) => any) | undefined;
}, {
    visible: boolean;
    showForZeroValues: boolean;
}>;
declare const DxCommonSeriesSettingsSelectionStyle: import("vue").DefineComponent<{
    border: PropType<Record<string, any>>;
    color: PropType<string | Record<string, any> | ChartsColor>;
    dashStyle: PropType<DashStyle>;
    hatching: PropType<Record<string, any>>;
    highlight: BooleanConstructor;
    width: NumberConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:border": null;
    "update:color": null;
    "update:dashStyle": null;
    "update:hatching": null;
    "update:highlight": null;
    "update:width": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    border: PropType<Record<string, any>>;
    color: PropType<string | Record<string, any> | ChartsColor>;
    dashStyle: PropType<DashStyle>;
    hatching: PropType<Record<string, any>>;
    highlight: BooleanConstructor;
    width: NumberConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:border"?: ((...args: any[]) => any) | undefined;
    "onUpdate:color"?: ((...args: any[]) => any) | undefined;
    "onUpdate:width"?: ((...args: any[]) => any) | undefined;
    "onUpdate:dashStyle"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hatching"?: ((...args: any[]) => any) | undefined;
    "onUpdate:highlight"?: ((...args: any[]) => any) | undefined;
}, {
    highlight: boolean;
}>;
declare const DxConnector: import("vue").DefineComponent<{
    color: StringConstructor;
    visible: BooleanConstructor;
    width: NumberConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:color": null;
    "update:visible": null;
    "update:width": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    color: StringConstructor;
    visible: BooleanConstructor;
    width: NumberConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:color"?: ((...args: any[]) => any) | undefined;
    "onUpdate:width"?: ((...args: any[]) => any) | undefined;
    "onUpdate:visible"?: ((...args: any[]) => any) | undefined;
}, {
    visible: boolean;
}>;
declare const DxConstantLine: import("vue").DefineComponent<{
    color: StringConstructor;
    dashStyle: PropType<DashStyle>;
    displayBehindSeries: BooleanConstructor;
    extendAxis: BooleanConstructor;
    label: PropType<Record<string, any>>;
    value: (DateConstructor | NumberConstructor | StringConstructor)[];
    width: NumberConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:color": null;
    "update:dashStyle": null;
    "update:displayBehindSeries": null;
    "update:extendAxis": null;
    "update:label": null;
    "update:value": null;
    "update:width": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    color: StringConstructor;
    dashStyle: PropType<DashStyle>;
    displayBehindSeries: BooleanConstructor;
    extendAxis: BooleanConstructor;
    label: PropType<Record<string, any>>;
    value: (DateConstructor | NumberConstructor | StringConstructor)[];
    width: NumberConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:color"?: ((...args: any[]) => any) | undefined;
    "onUpdate:width"?: ((...args: any[]) => any) | undefined;
    "onUpdate:dashStyle"?: ((...args: any[]) => any) | undefined;
    "onUpdate:label"?: ((...args: any[]) => any) | undefined;
    "onUpdate:value"?: ((...args: any[]) => any) | undefined;
    "onUpdate:displayBehindSeries"?: ((...args: any[]) => any) | undefined;
    "onUpdate:extendAxis"?: ((...args: any[]) => any) | undefined;
}, {
    displayBehindSeries: boolean;
    extendAxis: boolean;
}>;
declare const DxConstantLineLabel: import("vue").DefineComponent<{
    font: PropType<Record<string, any> | Font>;
    text: StringConstructor;
    visible: BooleanConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:font": null;
    "update:text": null;
    "update:visible": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    font: PropType<Record<string, any> | Font>;
    text: StringConstructor;
    visible: BooleanConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:font"?: ((...args: any[]) => any) | undefined;
    "onUpdate:text"?: ((...args: any[]) => any) | undefined;
    "onUpdate:visible"?: ((...args: any[]) => any) | undefined;
}, {
    visible: boolean;
}>;
declare const DxConstantLineStyle: import("vue").DefineComponent<{
    color: StringConstructor;
    dashStyle: PropType<DashStyle>;
    label: PropType<Record<string, any>>;
    width: NumberConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:color": null;
    "update:dashStyle": null;
    "update:label": null;
    "update:width": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    color: StringConstructor;
    dashStyle: PropType<DashStyle>;
    label: PropType<Record<string, any>>;
    width: NumberConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:color"?: ((...args: any[]) => any) | undefined;
    "onUpdate:width"?: ((...args: any[]) => any) | undefined;
    "onUpdate:dashStyle"?: ((...args: any[]) => any) | undefined;
    "onUpdate:label"?: ((...args: any[]) => any) | undefined;
}, {}>;
declare const DxConstantLineStyleLabel: import("vue").DefineComponent<{
    font: PropType<Record<string, any> | Font>;
    visible: BooleanConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:font": null;
    "update:visible": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    font: PropType<Record<string, any> | Font>;
    visible: BooleanConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:font"?: ((...args: any[]) => any) | undefined;
    "onUpdate:visible"?: ((...args: any[]) => any) | undefined;
}, {
    visible: boolean;
}>;
declare const DxDataPrepareSettings: import("vue").DefineComponent<{
    checkTypeForAllData: BooleanConstructor;
    convertToAxisDataType: BooleanConstructor;
    sortingMethod: PropType<boolean | ((a: {
        arg: Date | number | string;
        val: Date | number | string;
    }, b: {
        arg: Date | number | string;
        val: Date | number | string;
    }) => number)>;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:checkTypeForAllData": null;
    "update:convertToAxisDataType": null;
    "update:sortingMethod": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    checkTypeForAllData: BooleanConstructor;
    convertToAxisDataType: BooleanConstructor;
    sortingMethod: PropType<boolean | ((a: {
        arg: Date | number | string;
        val: Date | number | string;
    }, b: {
        arg: Date | number | string;
        val: Date | number | string;
    }) => number)>;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:sortingMethod"?: ((...args: any[]) => any) | undefined;
    "onUpdate:checkTypeForAllData"?: ((...args: any[]) => any) | undefined;
    "onUpdate:convertToAxisDataType"?: ((...args: any[]) => any) | undefined;
}, {
    checkTypeForAllData: boolean;
    convertToAxisDataType: boolean;
}>;
declare const DxExport: import("vue").DefineComponent<{
    backgroundColor: StringConstructor;
    enabled: BooleanConstructor;
    fileName: StringConstructor;
    formats: PropType<ExportFormat[]>;
    margin: NumberConstructor;
    printingEnabled: BooleanConstructor;
    svgToCanvas: PropType<(svg: any, canvas: any) => any>;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:backgroundColor": null;
    "update:enabled": null;
    "update:fileName": null;
    "update:formats": null;
    "update:margin": null;
    "update:printingEnabled": null;
    "update:svgToCanvas": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    backgroundColor: StringConstructor;
    enabled: BooleanConstructor;
    fileName: StringConstructor;
    formats: PropType<ExportFormat[]>;
    margin: NumberConstructor;
    printingEnabled: BooleanConstructor;
    svgToCanvas: PropType<(svg: any, canvas: any) => any>;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:enabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:margin"?: ((...args: any[]) => any) | undefined;
    "onUpdate:backgroundColor"?: ((...args: any[]) => any) | undefined;
    "onUpdate:fileName"?: ((...args: any[]) => any) | undefined;
    "onUpdate:formats"?: ((...args: any[]) => any) | undefined;
    "onUpdate:printingEnabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:svgToCanvas"?: ((...args: any[]) => any) | undefined;
}, {
    enabled: boolean;
    printingEnabled: boolean;
}>;
declare const DxFont: import("vue").DefineComponent<{
    color: StringConstructor;
    family: StringConstructor;
    opacity: NumberConstructor;
    size: (NumberConstructor | StringConstructor)[];
    weight: NumberConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:color": null;
    "update:family": null;
    "update:opacity": null;
    "update:size": null;
    "update:weight": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    color: StringConstructor;
    family: StringConstructor;
    opacity: NumberConstructor;
    size: (NumberConstructor | StringConstructor)[];
    weight: NumberConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:size"?: ((...args: any[]) => any) | undefined;
    "onUpdate:color"?: ((...args: any[]) => any) | undefined;
    "onUpdate:opacity"?: ((...args: any[]) => any) | undefined;
    "onUpdate:family"?: ((...args: any[]) => any) | undefined;
    "onUpdate:weight"?: ((...args: any[]) => any) | undefined;
}, {}>;
declare const DxFormat: import("vue").DefineComponent<{
    currency: StringConstructor;
    formatter: PropType<(value: number | Date) => string>;
    parser: PropType<(value: string) => number | Date>;
    precision: NumberConstructor;
    type: PropType<string>;
    useCurrencyAccountingStyle: BooleanConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:currency": null;
    "update:formatter": null;
    "update:parser": null;
    "update:precision": null;
    "update:type": null;
    "update:useCurrencyAccountingStyle": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    currency: StringConstructor;
    formatter: PropType<(value: number | Date) => string>;
    parser: PropType<(value: string) => number | Date>;
    precision: NumberConstructor;
    type: PropType<string>;
    useCurrencyAccountingStyle: BooleanConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:type"?: ((...args: any[]) => any) | undefined;
    "onUpdate:currency"?: ((...args: any[]) => any) | undefined;
    "onUpdate:formatter"?: ((...args: any[]) => any) | undefined;
    "onUpdate:parser"?: ((...args: any[]) => any) | undefined;
    "onUpdate:precision"?: ((...args: any[]) => any) | undefined;
    "onUpdate:useCurrencyAccountingStyle"?: ((...args: any[]) => any) | undefined;
}, {
    useCurrencyAccountingStyle: boolean;
}>;
declare const DxGrid: import("vue").DefineComponent<{
    color: StringConstructor;
    opacity: NumberConstructor;
    visible: BooleanConstructor;
    width: NumberConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:color": null;
    "update:opacity": null;
    "update:visible": null;
    "update:width": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    color: StringConstructor;
    opacity: NumberConstructor;
    visible: BooleanConstructor;
    width: NumberConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:color"?: ((...args: any[]) => any) | undefined;
    "onUpdate:opacity"?: ((...args: any[]) => any) | undefined;
    "onUpdate:width"?: ((...args: any[]) => any) | undefined;
    "onUpdate:visible"?: ((...args: any[]) => any) | undefined;
}, {
    visible: boolean;
}>;
declare const DxHatching: import("vue").DefineComponent<{
    direction: PropType<HatchDirection>;
    opacity: NumberConstructor;
    step: NumberConstructor;
    width: NumberConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:direction": null;
    "update:opacity": null;
    "update:step": null;
    "update:width": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    direction: PropType<HatchDirection>;
    opacity: NumberConstructor;
    step: NumberConstructor;
    width: NumberConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:opacity"?: ((...args: any[]) => any) | undefined;
    "onUpdate:width"?: ((...args: any[]) => any) | undefined;
    "onUpdate:direction"?: ((...args: any[]) => any) | undefined;
    "onUpdate:step"?: ((...args: any[]) => any) | undefined;
}, {}>;
declare const DxHoverStyle: import("vue").DefineComponent<{
    border: PropType<Record<string, any>>;
    color: PropType<string | Record<string, any> | ChartsColor>;
    dashStyle: PropType<DashStyle>;
    hatching: PropType<Record<string, any>>;
    highlight: BooleanConstructor;
    size: NumberConstructor;
    width: NumberConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:border": null;
    "update:color": null;
    "update:dashStyle": null;
    "update:hatching": null;
    "update:highlight": null;
    "update:size": null;
    "update:width": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    border: PropType<Record<string, any>>;
    color: PropType<string | Record<string, any> | ChartsColor>;
    dashStyle: PropType<DashStyle>;
    hatching: PropType<Record<string, any>>;
    highlight: BooleanConstructor;
    size: NumberConstructor;
    width: NumberConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:size"?: ((...args: any[]) => any) | undefined;
    "onUpdate:border"?: ((...args: any[]) => any) | undefined;
    "onUpdate:color"?: ((...args: any[]) => any) | undefined;
    "onUpdate:width"?: ((...args: any[]) => any) | undefined;
    "onUpdate:dashStyle"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hatching"?: ((...args: any[]) => any) | undefined;
    "onUpdate:highlight"?: ((...args: any[]) => any) | undefined;
}, {
    highlight: boolean;
}>;
declare const DxImage: import("vue").DefineComponent<{
    height: NumberConstructor;
    url: StringConstructor;
    width: NumberConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:height": null;
    "update:url": null;
    "update:width": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    height: NumberConstructor;
    url: StringConstructor;
    width: NumberConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:height"?: ((...args: any[]) => any) | undefined;
    "onUpdate:width"?: ((...args: any[]) => any) | undefined;
    "onUpdate:url"?: ((...args: any[]) => any) | undefined;
}, {}>;
declare const DxLabel: import("vue").DefineComponent<{
    argumentFormat: PropType<string | Record<string, any> | import("devextreme/common/core/localization").FormatObject | ((value: number | Date) => string) | ((value: Date) => string) | ((value: number) => string) | Intl.DateTimeFormatOptions | Intl.NumberFormatOptions | ((value: number | Date) => string) | undefined>;
    backgroundColor: StringConstructor;
    border: PropType<Record<string, any>>;
    connector: PropType<Record<string, any>>;
    customizeHint: PropType<(argument: {
        value: Date | number | string;
        valueText: string;
    }) => string>;
    customizeText: PropType<(argument: {
        value: Date | number | string;
        valueText: string;
    }) => string>;
    displayFormat: StringConstructor;
    font: PropType<Record<string, any> | Font>;
    format: PropType<string | Record<string, any> | import("devextreme/common/core/localization").FormatObject | ((value: number | Date) => string) | ((value: Date) => string) | ((value: number) => string) | Intl.DateTimeFormatOptions | Intl.NumberFormatOptions | ((value: number | Date) => string) | undefined>;
    indentFromAxis: NumberConstructor;
    overlappingBehavior: PropType<LabelOverlap>;
    position: PropType<RelativePosition>;
    rotationAngle: NumberConstructor;
    showForZeroValues: BooleanConstructor;
    text: StringConstructor;
    visible: BooleanConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:argumentFormat": null;
    "update:backgroundColor": null;
    "update:border": null;
    "update:connector": null;
    "update:customizeHint": null;
    "update:customizeText": null;
    "update:displayFormat": null;
    "update:font": null;
    "update:format": null;
    "update:indentFromAxis": null;
    "update:overlappingBehavior": null;
    "update:position": null;
    "update:rotationAngle": null;
    "update:showForZeroValues": null;
    "update:text": null;
    "update:visible": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    argumentFormat: PropType<string | Record<string, any> | import("devextreme/common/core/localization").FormatObject | ((value: number | Date) => string) | ((value: Date) => string) | ((value: number) => string) | Intl.DateTimeFormatOptions | Intl.NumberFormatOptions | ((value: number | Date) => string) | undefined>;
    backgroundColor: StringConstructor;
    border: PropType<Record<string, any>>;
    connector: PropType<Record<string, any>>;
    customizeHint: PropType<(argument: {
        value: Date | number | string;
        valueText: string;
    }) => string>;
    customizeText: PropType<(argument: {
        value: Date | number | string;
        valueText: string;
    }) => string>;
    displayFormat: StringConstructor;
    font: PropType<Record<string, any> | Font>;
    format: PropType<string | Record<string, any> | import("devextreme/common/core/localization").FormatObject | ((value: number | Date) => string) | ((value: Date) => string) | ((value: number) => string) | Intl.DateTimeFormatOptions | Intl.NumberFormatOptions | ((value: number | Date) => string) | undefined>;
    indentFromAxis: NumberConstructor;
    overlappingBehavior: PropType<LabelOverlap>;
    position: PropType<RelativePosition>;
    rotationAngle: NumberConstructor;
    showForZeroValues: BooleanConstructor;
    text: StringConstructor;
    visible: BooleanConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:border"?: ((...args: any[]) => any) | undefined;
    "onUpdate:font"?: ((...args: any[]) => any) | undefined;
    "onUpdate:text"?: ((...args: any[]) => any) | undefined;
    "onUpdate:visible"?: ((...args: any[]) => any) | undefined;
    "onUpdate:backgroundColor"?: ((...args: any[]) => any) | undefined;
    "onUpdate:customizeHint"?: ((...args: any[]) => any) | undefined;
    "onUpdate:customizeText"?: ((...args: any[]) => any) | undefined;
    "onUpdate:format"?: ((...args: any[]) => any) | undefined;
    "onUpdate:position"?: ((...args: any[]) => any) | undefined;
    "onUpdate:overlappingBehavior"?: ((...args: any[]) => any) | undefined;
    "onUpdate:argumentFormat"?: ((...args: any[]) => any) | undefined;
    "onUpdate:connector"?: ((...args: any[]) => any) | undefined;
    "onUpdate:displayFormat"?: ((...args: any[]) => any) | undefined;
    "onUpdate:rotationAngle"?: ((...args: any[]) => any) | undefined;
    "onUpdate:showForZeroValues"?: ((...args: any[]) => any) | undefined;
    "onUpdate:indentFromAxis"?: ((...args: any[]) => any) | undefined;
}, {
    visible: boolean;
    showForZeroValues: boolean;
}>;
declare const DxLegend: import("vue").DefineComponent<{
    backgroundColor: StringConstructor;
    border: PropType<Record<string, any>>;
    columnCount: NumberConstructor;
    columnItemSpacing: NumberConstructor;
    customizeHint: PropType<(seriesInfo: {
        seriesColor: string;
        seriesIndex: number;
        seriesName: any;
    }) => string>;
    customizeItems: PropType<(items: Array<LegendItem>) => Array<LegendItem>>;
    customizeText: PropType<(seriesInfo: {
        seriesColor: string;
        seriesIndex: number;
        seriesName: any;
    }) => string>;
    font: PropType<Record<string, any> | Font>;
    horizontalAlignment: PropType<HorizontalAlignment>;
    hoverMode: PropType<LegendHoverMode>;
    itemsAlignment: PropType<HorizontalAlignment>;
    itemTextPosition: PropType<Position>;
    margin: PropType<number | Record<string, any>>;
    markerSize: NumberConstructor;
    markerTemplate: {};
    orientation: PropType<Orientation>;
    paddingLeftRight: NumberConstructor;
    paddingTopBottom: NumberConstructor;
    rowCount: NumberConstructor;
    rowItemSpacing: NumberConstructor;
    title: PropType<string | Record<string, any>>;
    verticalAlignment: PropType<VerticalEdge>;
    visible: BooleanConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:backgroundColor": null;
    "update:border": null;
    "update:columnCount": null;
    "update:columnItemSpacing": null;
    "update:customizeHint": null;
    "update:customizeItems": null;
    "update:customizeText": null;
    "update:font": null;
    "update:horizontalAlignment": null;
    "update:hoverMode": null;
    "update:itemsAlignment": null;
    "update:itemTextPosition": null;
    "update:margin": null;
    "update:markerSize": null;
    "update:markerTemplate": null;
    "update:orientation": null;
    "update:paddingLeftRight": null;
    "update:paddingTopBottom": null;
    "update:rowCount": null;
    "update:rowItemSpacing": null;
    "update:title": null;
    "update:verticalAlignment": null;
    "update:visible": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    backgroundColor: StringConstructor;
    border: PropType<Record<string, any>>;
    columnCount: NumberConstructor;
    columnItemSpacing: NumberConstructor;
    customizeHint: PropType<(seriesInfo: {
        seriesColor: string;
        seriesIndex: number;
        seriesName: any;
    }) => string>;
    customizeItems: PropType<(items: Array<LegendItem>) => Array<LegendItem>>;
    customizeText: PropType<(seriesInfo: {
        seriesColor: string;
        seriesIndex: number;
        seriesName: any;
    }) => string>;
    font: PropType<Record<string, any> | Font>;
    horizontalAlignment: PropType<HorizontalAlignment>;
    hoverMode: PropType<LegendHoverMode>;
    itemsAlignment: PropType<HorizontalAlignment>;
    itemTextPosition: PropType<Position>;
    margin: PropType<number | Record<string, any>>;
    markerSize: NumberConstructor;
    markerTemplate: {};
    orientation: PropType<Orientation>;
    paddingLeftRight: NumberConstructor;
    paddingTopBottom: NumberConstructor;
    rowCount: NumberConstructor;
    rowItemSpacing: NumberConstructor;
    title: PropType<string | Record<string, any>>;
    verticalAlignment: PropType<VerticalEdge>;
    visible: BooleanConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:title"?: ((...args: any[]) => any) | undefined;
    "onUpdate:border"?: ((...args: any[]) => any) | undefined;
    "onUpdate:font"?: ((...args: any[]) => any) | undefined;
    "onUpdate:paddingLeftRight"?: ((...args: any[]) => any) | undefined;
    "onUpdate:paddingTopBottom"?: ((...args: any[]) => any) | undefined;
    "onUpdate:visible"?: ((...args: any[]) => any) | undefined;
    "onUpdate:horizontalAlignment"?: ((...args: any[]) => any) | undefined;
    "onUpdate:margin"?: ((...args: any[]) => any) | undefined;
    "onUpdate:verticalAlignment"?: ((...args: any[]) => any) | undefined;
    "onUpdate:backgroundColor"?: ((...args: any[]) => any) | undefined;
    "onUpdate:columnCount"?: ((...args: any[]) => any) | undefined;
    "onUpdate:columnItemSpacing"?: ((...args: any[]) => any) | undefined;
    "onUpdate:customizeHint"?: ((...args: any[]) => any) | undefined;
    "onUpdate:customizeItems"?: ((...args: any[]) => any) | undefined;
    "onUpdate:customizeText"?: ((...args: any[]) => any) | undefined;
    "onUpdate:itemsAlignment"?: ((...args: any[]) => any) | undefined;
    "onUpdate:itemTextPosition"?: ((...args: any[]) => any) | undefined;
    "onUpdate:markerSize"?: ((...args: any[]) => any) | undefined;
    "onUpdate:markerTemplate"?: ((...args: any[]) => any) | undefined;
    "onUpdate:orientation"?: ((...args: any[]) => any) | undefined;
    "onUpdate:rowCount"?: ((...args: any[]) => any) | undefined;
    "onUpdate:rowItemSpacing"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoverMode"?: ((...args: any[]) => any) | undefined;
}, {
    visible: boolean;
}>;
declare const DxLegendTitle: import("vue").DefineComponent<{
    font: PropType<Record<string, any> | Font>;
    horizontalAlignment: PropType<HorizontalAlignment>;
    margin: PropType<Record<string, any>>;
    placeholderSize: NumberConstructor;
    subtitle: PropType<string | Record<string, any>>;
    text: StringConstructor;
    verticalAlignment: PropType<VerticalEdge>;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:font": null;
    "update:horizontalAlignment": null;
    "update:margin": null;
    "update:placeholderSize": null;
    "update:subtitle": null;
    "update:text": null;
    "update:verticalAlignment": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    font: PropType<Record<string, any> | Font>;
    horizontalAlignment: PropType<HorizontalAlignment>;
    margin: PropType<Record<string, any>>;
    placeholderSize: NumberConstructor;
    subtitle: PropType<string | Record<string, any>>;
    text: StringConstructor;
    verticalAlignment: PropType<VerticalEdge>;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:font"?: ((...args: any[]) => any) | undefined;
    "onUpdate:text"?: ((...args: any[]) => any) | undefined;
    "onUpdate:horizontalAlignment"?: ((...args: any[]) => any) | undefined;
    "onUpdate:margin"?: ((...args: any[]) => any) | undefined;
    "onUpdate:verticalAlignment"?: ((...args: any[]) => any) | undefined;
    "onUpdate:placeholderSize"?: ((...args: any[]) => any) | undefined;
    "onUpdate:subtitle"?: ((...args: any[]) => any) | undefined;
}, {}>;
declare const DxLegendTitleSubtitle: import("vue").DefineComponent<{
    font: PropType<Record<string, any> | Font>;
    offset: NumberConstructor;
    text: StringConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:font": null;
    "update:offset": null;
    "update:text": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    font: PropType<Record<string, any> | Font>;
    offset: NumberConstructor;
    text: StringConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:font"?: ((...args: any[]) => any) | undefined;
    "onUpdate:text"?: ((...args: any[]) => any) | undefined;
    "onUpdate:offset"?: ((...args: any[]) => any) | undefined;
}, {}>;
declare const DxLength: import("vue").DefineComponent<{
    days: NumberConstructor;
    hours: NumberConstructor;
    milliseconds: NumberConstructor;
    minutes: NumberConstructor;
    months: NumberConstructor;
    quarters: NumberConstructor;
    seconds: NumberConstructor;
    weeks: NumberConstructor;
    years: NumberConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:days": null;
    "update:hours": null;
    "update:milliseconds": null;
    "update:minutes": null;
    "update:months": null;
    "update:quarters": null;
    "update:seconds": null;
    "update:weeks": null;
    "update:years": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    days: NumberConstructor;
    hours: NumberConstructor;
    milliseconds: NumberConstructor;
    minutes: NumberConstructor;
    months: NumberConstructor;
    quarters: NumberConstructor;
    seconds: NumberConstructor;
    weeks: NumberConstructor;
    years: NumberConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:days"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hours"?: ((...args: any[]) => any) | undefined;
    "onUpdate:milliseconds"?: ((...args: any[]) => any) | undefined;
    "onUpdate:minutes"?: ((...args: any[]) => any) | undefined;
    "onUpdate:months"?: ((...args: any[]) => any) | undefined;
    "onUpdate:quarters"?: ((...args: any[]) => any) | undefined;
    "onUpdate:seconds"?: ((...args: any[]) => any) | undefined;
    "onUpdate:weeks"?: ((...args: any[]) => any) | undefined;
    "onUpdate:years"?: ((...args: any[]) => any) | undefined;
}, {}>;
declare const DxLoadingIndicator: import("vue").DefineComponent<{
    backgroundColor: StringConstructor;
    enabled: BooleanConstructor;
    font: PropType<Record<string, any> | Font>;
    show: BooleanConstructor;
    text: StringConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:backgroundColor": null;
    "update:enabled": null;
    "update:font": null;
    "update:show": null;
    "update:text": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    backgroundColor: StringConstructor;
    enabled: BooleanConstructor;
    font: PropType<Record<string, any> | Font>;
    show: BooleanConstructor;
    text: StringConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:font"?: ((...args: any[]) => any) | undefined;
    "onUpdate:text"?: ((...args: any[]) => any) | undefined;
    "onUpdate:enabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:backgroundColor"?: ((...args: any[]) => any) | undefined;
    "onUpdate:show"?: ((...args: any[]) => any) | undefined;
}, {
    enabled: boolean;
    show: boolean;
}>;
declare const DxMargin: import("vue").DefineComponent<{
    bottom: NumberConstructor;
    left: NumberConstructor;
    right: NumberConstructor;
    top: NumberConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:bottom": null;
    "update:left": null;
    "update:right": null;
    "update:top": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    bottom: NumberConstructor;
    left: NumberConstructor;
    right: NumberConstructor;
    top: NumberConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:bottom"?: ((...args: any[]) => any) | undefined;
    "onUpdate:left"?: ((...args: any[]) => any) | undefined;
    "onUpdate:right"?: ((...args: any[]) => any) | undefined;
    "onUpdate:top"?: ((...args: any[]) => any) | undefined;
}, {}>;
declare const DxMinorGrid: import("vue").DefineComponent<{
    color: StringConstructor;
    opacity: NumberConstructor;
    visible: BooleanConstructor;
    width: NumberConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:color": null;
    "update:opacity": null;
    "update:visible": null;
    "update:width": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    color: StringConstructor;
    opacity: NumberConstructor;
    visible: BooleanConstructor;
    width: NumberConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:color"?: ((...args: any[]) => any) | undefined;
    "onUpdate:opacity"?: ((...args: any[]) => any) | undefined;
    "onUpdate:width"?: ((...args: any[]) => any) | undefined;
    "onUpdate:visible"?: ((...args: any[]) => any) | undefined;
}, {
    visible: boolean;
}>;
declare const DxMinorTick: import("vue").DefineComponent<{
    color: StringConstructor;
    length: NumberConstructor;
    opacity: NumberConstructor;
    shift: NumberConstructor;
    visible: BooleanConstructor;
    width: NumberConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:color": null;
    "update:length": null;
    "update:opacity": null;
    "update:shift": null;
    "update:visible": null;
    "update:width": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    color: StringConstructor;
    length: NumberConstructor;
    opacity: NumberConstructor;
    shift: NumberConstructor;
    visible: BooleanConstructor;
    width: NumberConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:color"?: ((...args: any[]) => any) | undefined;
    "onUpdate:opacity"?: ((...args: any[]) => any) | undefined;
    "onUpdate:width"?: ((...args: any[]) => any) | undefined;
    "onUpdate:visible"?: ((...args: any[]) => any) | undefined;
    "onUpdate:length"?: ((...args: any[]) => any) | undefined;
    "onUpdate:shift"?: ((...args: any[]) => any) | undefined;
}, {
    visible: boolean;
}>;
declare const DxMinorTickInterval: import("vue").DefineComponent<{
    days: NumberConstructor;
    hours: NumberConstructor;
    milliseconds: NumberConstructor;
    minutes: NumberConstructor;
    months: NumberConstructor;
    quarters: NumberConstructor;
    seconds: NumberConstructor;
    weeks: NumberConstructor;
    years: NumberConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:days": null;
    "update:hours": null;
    "update:milliseconds": null;
    "update:minutes": null;
    "update:months": null;
    "update:quarters": null;
    "update:seconds": null;
    "update:weeks": null;
    "update:years": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    days: NumberConstructor;
    hours: NumberConstructor;
    milliseconds: NumberConstructor;
    minutes: NumberConstructor;
    months: NumberConstructor;
    quarters: NumberConstructor;
    seconds: NumberConstructor;
    weeks: NumberConstructor;
    years: NumberConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:days"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hours"?: ((...args: any[]) => any) | undefined;
    "onUpdate:milliseconds"?: ((...args: any[]) => any) | undefined;
    "onUpdate:minutes"?: ((...args: any[]) => any) | undefined;
    "onUpdate:months"?: ((...args: any[]) => any) | undefined;
    "onUpdate:quarters"?: ((...args: any[]) => any) | undefined;
    "onUpdate:seconds"?: ((...args: any[]) => any) | undefined;
    "onUpdate:weeks"?: ((...args: any[]) => any) | undefined;
    "onUpdate:years"?: ((...args: any[]) => any) | undefined;
}, {}>;
declare const DxMinVisualRangeLength: import("vue").DefineComponent<{
    days: NumberConstructor;
    hours: NumberConstructor;
    milliseconds: NumberConstructor;
    minutes: NumberConstructor;
    months: NumberConstructor;
    quarters: NumberConstructor;
    seconds: NumberConstructor;
    weeks: NumberConstructor;
    years: NumberConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:days": null;
    "update:hours": null;
    "update:milliseconds": null;
    "update:minutes": null;
    "update:months": null;
    "update:quarters": null;
    "update:seconds": null;
    "update:weeks": null;
    "update:years": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    days: NumberConstructor;
    hours: NumberConstructor;
    milliseconds: NumberConstructor;
    minutes: NumberConstructor;
    months: NumberConstructor;
    quarters: NumberConstructor;
    seconds: NumberConstructor;
    weeks: NumberConstructor;
    years: NumberConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:days"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hours"?: ((...args: any[]) => any) | undefined;
    "onUpdate:milliseconds"?: ((...args: any[]) => any) | undefined;
    "onUpdate:minutes"?: ((...args: any[]) => any) | undefined;
    "onUpdate:months"?: ((...args: any[]) => any) | undefined;
    "onUpdate:quarters"?: ((...args: any[]) => any) | undefined;
    "onUpdate:seconds"?: ((...args: any[]) => any) | undefined;
    "onUpdate:weeks"?: ((...args: any[]) => any) | undefined;
    "onUpdate:years"?: ((...args: any[]) => any) | undefined;
}, {}>;
declare const DxPoint: import("vue").DefineComponent<{
    border: PropType<Record<string, any>>;
    color: PropType<string | Record<string, any> | ChartsColor>;
    hoverMode: PropType<PointInteractionMode>;
    hoverStyle: PropType<Record<string, any>>;
    image: PropType<string | Record<string, any>>;
    selectionMode: PropType<PointInteractionMode>;
    selectionStyle: PropType<Record<string, any>>;
    size: NumberConstructor;
    symbol: PropType<PointSymbol>;
    visible: BooleanConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:border": null;
    "update:color": null;
    "update:hoverMode": null;
    "update:hoverStyle": null;
    "update:image": null;
    "update:selectionMode": null;
    "update:selectionStyle": null;
    "update:size": null;
    "update:symbol": null;
    "update:visible": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    border: PropType<Record<string, any>>;
    color: PropType<string | Record<string, any> | ChartsColor>;
    hoverMode: PropType<PointInteractionMode>;
    hoverStyle: PropType<Record<string, any>>;
    image: PropType<string | Record<string, any>>;
    selectionMode: PropType<PointInteractionMode>;
    selectionStyle: PropType<Record<string, any>>;
    size: NumberConstructor;
    symbol: PropType<PointSymbol>;
    visible: BooleanConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:size"?: ((...args: any[]) => any) | undefined;
    "onUpdate:border"?: ((...args: any[]) => any) | undefined;
    "onUpdate:color"?: ((...args: any[]) => any) | undefined;
    "onUpdate:image"?: ((...args: any[]) => any) | undefined;
    "onUpdate:visible"?: ((...args: any[]) => any) | undefined;
    "onUpdate:selectionMode"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoverStyle"?: ((...args: any[]) => any) | undefined;
    "onUpdate:selectionStyle"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoverMode"?: ((...args: any[]) => any) | undefined;
    "onUpdate:symbol"?: ((...args: any[]) => any) | undefined;
}, {
    visible: boolean;
}>;
declare const DxPointBorder: import("vue").DefineComponent<{
    color: StringConstructor;
    visible: BooleanConstructor;
    width: NumberConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:color": null;
    "update:visible": null;
    "update:width": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    color: StringConstructor;
    visible: BooleanConstructor;
    width: NumberConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:color"?: ((...args: any[]) => any) | undefined;
    "onUpdate:width"?: ((...args: any[]) => any) | undefined;
    "onUpdate:visible"?: ((...args: any[]) => any) | undefined;
}, {
    visible: boolean;
}>;
declare const DxPointHoverStyle: import("vue").DefineComponent<{
    border: PropType<Record<string, any>>;
    color: PropType<string | Record<string, any> | ChartsColor>;
    size: NumberConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:border": null;
    "update:color": null;
    "update:size": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    border: PropType<Record<string, any>>;
    color: PropType<string | Record<string, any> | ChartsColor>;
    size: NumberConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:size"?: ((...args: any[]) => any) | undefined;
    "onUpdate:border"?: ((...args: any[]) => any) | undefined;
    "onUpdate:color"?: ((...args: any[]) => any) | undefined;
}, {}>;
declare const DxPointSelectionStyle: import("vue").DefineComponent<{
    border: PropType<Record<string, any>>;
    color: PropType<string | Record<string, any> | ChartsColor>;
    size: NumberConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:border": null;
    "update:color": null;
    "update:size": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    border: PropType<Record<string, any>>;
    color: PropType<string | Record<string, any> | ChartsColor>;
    size: NumberConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:size"?: ((...args: any[]) => any) | undefined;
    "onUpdate:border"?: ((...args: any[]) => any) | undefined;
    "onUpdate:color"?: ((...args: any[]) => any) | undefined;
}, {}>;
declare const DxPolarChartTitle: import("vue").DefineComponent<{
    font: PropType<Record<string, any> | Font>;
    horizontalAlignment: PropType<HorizontalAlignment>;
    margin: PropType<number | Record<string, any>>;
    placeholderSize: NumberConstructor;
    subtitle: PropType<string | Record<string, any>>;
    text: StringConstructor;
    textOverflow: PropType<TextOverflow>;
    verticalAlignment: PropType<VerticalEdge>;
    wordWrap: PropType<WordWrap>;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:font": null;
    "update:horizontalAlignment": null;
    "update:margin": null;
    "update:placeholderSize": null;
    "update:subtitle": null;
    "update:text": null;
    "update:textOverflow": null;
    "update:verticalAlignment": null;
    "update:wordWrap": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    font: PropType<Record<string, any> | Font>;
    horizontalAlignment: PropType<HorizontalAlignment>;
    margin: PropType<number | Record<string, any>>;
    placeholderSize: NumberConstructor;
    subtitle: PropType<string | Record<string, any>>;
    text: StringConstructor;
    textOverflow: PropType<TextOverflow>;
    verticalAlignment: PropType<VerticalEdge>;
    wordWrap: PropType<WordWrap>;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:font"?: ((...args: any[]) => any) | undefined;
    "onUpdate:text"?: ((...args: any[]) => any) | undefined;
    "onUpdate:textOverflow"?: ((...args: any[]) => any) | undefined;
    "onUpdate:wordWrap"?: ((...args: any[]) => any) | undefined;
    "onUpdate:horizontalAlignment"?: ((...args: any[]) => any) | undefined;
    "onUpdate:margin"?: ((...args: any[]) => any) | undefined;
    "onUpdate:verticalAlignment"?: ((...args: any[]) => any) | undefined;
    "onUpdate:placeholderSize"?: ((...args: any[]) => any) | undefined;
    "onUpdate:subtitle"?: ((...args: any[]) => any) | undefined;
}, {}>;
declare const DxPolarChartTitleSubtitle: import("vue").DefineComponent<{
    font: PropType<Record<string, any> | Font>;
    offset: NumberConstructor;
    text: StringConstructor;
    textOverflow: PropType<TextOverflow>;
    wordWrap: PropType<WordWrap>;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:font": null;
    "update:offset": null;
    "update:text": null;
    "update:textOverflow": null;
    "update:wordWrap": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    font: PropType<Record<string, any> | Font>;
    offset: NumberConstructor;
    text: StringConstructor;
    textOverflow: PropType<TextOverflow>;
    wordWrap: PropType<WordWrap>;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:font"?: ((...args: any[]) => any) | undefined;
    "onUpdate:text"?: ((...args: any[]) => any) | undefined;
    "onUpdate:textOverflow"?: ((...args: any[]) => any) | undefined;
    "onUpdate:wordWrap"?: ((...args: any[]) => any) | undefined;
    "onUpdate:offset"?: ((...args: any[]) => any) | undefined;
}, {}>;
declare const DxSelectionStyle: import("vue").DefineComponent<{
    border: PropType<Record<string, any>>;
    color: PropType<string | Record<string, any> | ChartsColor>;
    dashStyle: PropType<DashStyle>;
    hatching: PropType<Record<string, any>>;
    highlight: BooleanConstructor;
    size: NumberConstructor;
    width: NumberConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:border": null;
    "update:color": null;
    "update:dashStyle": null;
    "update:hatching": null;
    "update:highlight": null;
    "update:size": null;
    "update:width": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    border: PropType<Record<string, any>>;
    color: PropType<string | Record<string, any> | ChartsColor>;
    dashStyle: PropType<DashStyle>;
    hatching: PropType<Record<string, any>>;
    highlight: BooleanConstructor;
    size: NumberConstructor;
    width: NumberConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:size"?: ((...args: any[]) => any) | undefined;
    "onUpdate:border"?: ((...args: any[]) => any) | undefined;
    "onUpdate:color"?: ((...args: any[]) => any) | undefined;
    "onUpdate:width"?: ((...args: any[]) => any) | undefined;
    "onUpdate:dashStyle"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hatching"?: ((...args: any[]) => any) | undefined;
    "onUpdate:highlight"?: ((...args: any[]) => any) | undefined;
}, {
    highlight: boolean;
}>;
declare const DxSeries: import("vue").DefineComponent<{
    argumentField: StringConstructor;
    barPadding: NumberConstructor;
    barWidth: NumberConstructor;
    border: PropType<Record<string, any>>;
    closed: BooleanConstructor;
    color: PropType<string | Record<string, any> | ChartsColor>;
    dashStyle: PropType<DashStyle>;
    hoverMode: PropType<SeriesHoverMode>;
    hoverStyle: PropType<Record<string, any>>;
    ignoreEmptyPoints: BooleanConstructor;
    label: PropType<Record<string, any>>;
    maxLabelCount: NumberConstructor;
    minBarSize: NumberConstructor;
    name: StringConstructor;
    opacity: NumberConstructor;
    point: PropType<Record<string, any>>;
    selectionMode: PropType<SeriesSelectionMode>;
    selectionStyle: PropType<Record<string, any>>;
    showInLegend: BooleanConstructor;
    stack: StringConstructor;
    tag: {};
    tagField: StringConstructor;
    type: PropType<PolarChartSeriesType>;
    valueErrorBar: PropType<Record<string, any>>;
    valueField: StringConstructor;
    visible: BooleanConstructor;
    width: NumberConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:argumentField": null;
    "update:barPadding": null;
    "update:barWidth": null;
    "update:border": null;
    "update:closed": null;
    "update:color": null;
    "update:dashStyle": null;
    "update:hoverMode": null;
    "update:hoverStyle": null;
    "update:ignoreEmptyPoints": null;
    "update:label": null;
    "update:maxLabelCount": null;
    "update:minBarSize": null;
    "update:name": null;
    "update:opacity": null;
    "update:point": null;
    "update:selectionMode": null;
    "update:selectionStyle": null;
    "update:showInLegend": null;
    "update:stack": null;
    "update:tag": null;
    "update:tagField": null;
    "update:type": null;
    "update:valueErrorBar": null;
    "update:valueField": null;
    "update:visible": null;
    "update:width": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    argumentField: StringConstructor;
    barPadding: NumberConstructor;
    barWidth: NumberConstructor;
    border: PropType<Record<string, any>>;
    closed: BooleanConstructor;
    color: PropType<string | Record<string, any> | ChartsColor>;
    dashStyle: PropType<DashStyle>;
    hoverMode: PropType<SeriesHoverMode>;
    hoverStyle: PropType<Record<string, any>>;
    ignoreEmptyPoints: BooleanConstructor;
    label: PropType<Record<string, any>>;
    maxLabelCount: NumberConstructor;
    minBarSize: NumberConstructor;
    name: StringConstructor;
    opacity: NumberConstructor;
    point: PropType<Record<string, any>>;
    selectionMode: PropType<SeriesSelectionMode>;
    selectionStyle: PropType<Record<string, any>>;
    showInLegend: BooleanConstructor;
    stack: StringConstructor;
    tag: {};
    tagField: StringConstructor;
    type: PropType<PolarChartSeriesType>;
    valueErrorBar: PropType<Record<string, any>>;
    valueField: StringConstructor;
    visible: BooleanConstructor;
    width: NumberConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:border"?: ((...args: any[]) => any) | undefined;
    "onUpdate:color"?: ((...args: any[]) => any) | undefined;
    "onUpdate:name"?: ((...args: any[]) => any) | undefined;
    "onUpdate:opacity"?: ((...args: any[]) => any) | undefined;
    "onUpdate:type"?: ((...args: any[]) => any) | undefined;
    "onUpdate:width"?: ((...args: any[]) => any) | undefined;
    "onUpdate:dashStyle"?: ((...args: any[]) => any) | undefined;
    "onUpdate:visible"?: ((...args: any[]) => any) | undefined;
    "onUpdate:label"?: ((...args: any[]) => any) | undefined;
    "onUpdate:selectionMode"?: ((...args: any[]) => any) | undefined;
    "onUpdate:valueField"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoverStyle"?: ((...args: any[]) => any) | undefined;
    "onUpdate:selectionStyle"?: ((...args: any[]) => any) | undefined;
    "onUpdate:argumentField"?: ((...args: any[]) => any) | undefined;
    "onUpdate:ignoreEmptyPoints"?: ((...args: any[]) => any) | undefined;
    "onUpdate:barPadding"?: ((...args: any[]) => any) | undefined;
    "onUpdate:barWidth"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoverMode"?: ((...args: any[]) => any) | undefined;
    "onUpdate:maxLabelCount"?: ((...args: any[]) => any) | undefined;
    "onUpdate:minBarSize"?: ((...args: any[]) => any) | undefined;
    "onUpdate:point"?: ((...args: any[]) => any) | undefined;
    "onUpdate:showInLegend"?: ((...args: any[]) => any) | undefined;
    "onUpdate:stack"?: ((...args: any[]) => any) | undefined;
    "onUpdate:tagField"?: ((...args: any[]) => any) | undefined;
    "onUpdate:valueErrorBar"?: ((...args: any[]) => any) | undefined;
    "onUpdate:tag"?: ((...args: any[]) => any) | undefined;
    "onUpdate:closed"?: ((...args: any[]) => any) | undefined;
}, {
    visible: boolean;
    ignoreEmptyPoints: boolean;
    showInLegend: boolean;
    closed: boolean;
}>;
declare const DxSeriesBorder: import("vue").DefineComponent<{
    color: StringConstructor;
    dashStyle: PropType<DashStyle>;
    visible: BooleanConstructor;
    width: NumberConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:color": null;
    "update:dashStyle": null;
    "update:visible": null;
    "update:width": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    color: StringConstructor;
    dashStyle: PropType<DashStyle>;
    visible: BooleanConstructor;
    width: NumberConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:color"?: ((...args: any[]) => any) | undefined;
    "onUpdate:width"?: ((...args: any[]) => any) | undefined;
    "onUpdate:dashStyle"?: ((...args: any[]) => any) | undefined;
    "onUpdate:visible"?: ((...args: any[]) => any) | undefined;
}, {
    visible: boolean;
}>;
declare const DxSeriesTemplate: import("vue").DefineComponent<{
    customizeSeries: PropType<(seriesName: any) => PolarChartSeries>;
    nameField: StringConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:customizeSeries": null;
    "update:nameField": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    customizeSeries: PropType<(seriesName: any) => PolarChartSeries>;
    nameField: StringConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:customizeSeries"?: ((...args: any[]) => any) | undefined;
    "onUpdate:nameField"?: ((...args: any[]) => any) | undefined;
}, {}>;
declare const DxShadow: import("vue").DefineComponent<{
    blur: NumberConstructor;
    color: StringConstructor;
    offsetX: NumberConstructor;
    offsetY: NumberConstructor;
    opacity: NumberConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:blur": null;
    "update:color": null;
    "update:offsetX": null;
    "update:offsetY": null;
    "update:opacity": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    blur: NumberConstructor;
    color: StringConstructor;
    offsetX: NumberConstructor;
    offsetY: NumberConstructor;
    opacity: NumberConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:color"?: ((...args: any[]) => any) | undefined;
    "onUpdate:offsetX"?: ((...args: any[]) => any) | undefined;
    "onUpdate:offsetY"?: ((...args: any[]) => any) | undefined;
    "onUpdate:opacity"?: ((...args: any[]) => any) | undefined;
    "onUpdate:blur"?: ((...args: any[]) => any) | undefined;
}, {}>;
declare const DxSize: import("vue").DefineComponent<{
    height: NumberConstructor;
    width: NumberConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:height": null;
    "update:width": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    height: NumberConstructor;
    width: NumberConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:height"?: ((...args: any[]) => any) | undefined;
    "onUpdate:width"?: ((...args: any[]) => any) | undefined;
}, {}>;
declare const DxStrip: import("vue").DefineComponent<{
    color: StringConstructor;
    endValue: (DateConstructor | NumberConstructor | StringConstructor)[];
    label: PropType<Record<string, any>>;
    startValue: (DateConstructor | NumberConstructor | StringConstructor)[];
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:color": null;
    "update:endValue": null;
    "update:label": null;
    "update:startValue": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    color: StringConstructor;
    endValue: (DateConstructor | NumberConstructor | StringConstructor)[];
    label: PropType<Record<string, any>>;
    startValue: (DateConstructor | NumberConstructor | StringConstructor)[];
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:color"?: ((...args: any[]) => any) | undefined;
    "onUpdate:label"?: ((...args: any[]) => any) | undefined;
    "onUpdate:endValue"?: ((...args: any[]) => any) | undefined;
    "onUpdate:startValue"?: ((...args: any[]) => any) | undefined;
}, {}>;
declare const DxStripLabel: import("vue").DefineComponent<{
    font: PropType<Record<string, any> | Font>;
    text: StringConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:font": null;
    "update:text": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    font: PropType<Record<string, any> | Font>;
    text: StringConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:font"?: ((...args: any[]) => any) | undefined;
    "onUpdate:text"?: ((...args: any[]) => any) | undefined;
}, {}>;
declare const DxStripStyle: import("vue").DefineComponent<{
    label: PropType<Record<string, any>>;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:label": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    label: PropType<Record<string, any>>;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:label"?: ((...args: any[]) => any) | undefined;
}, {}>;
declare const DxStripStyleLabel: import("vue").DefineComponent<{
    font: PropType<Record<string, any> | Font>;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:font": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    font: PropType<Record<string, any> | Font>;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:font"?: ((...args: any[]) => any) | undefined;
}, {}>;
declare const DxSubtitle: import("vue").DefineComponent<{
    font: PropType<Record<string, any> | Font>;
    offset: NumberConstructor;
    text: StringConstructor;
    textOverflow: PropType<TextOverflow>;
    wordWrap: PropType<WordWrap>;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:font": null;
    "update:offset": null;
    "update:text": null;
    "update:textOverflow": null;
    "update:wordWrap": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    font: PropType<Record<string, any> | Font>;
    offset: NumberConstructor;
    text: StringConstructor;
    textOverflow: PropType<TextOverflow>;
    wordWrap: PropType<WordWrap>;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:font"?: ((...args: any[]) => any) | undefined;
    "onUpdate:text"?: ((...args: any[]) => any) | undefined;
    "onUpdate:textOverflow"?: ((...args: any[]) => any) | undefined;
    "onUpdate:wordWrap"?: ((...args: any[]) => any) | undefined;
    "onUpdate:offset"?: ((...args: any[]) => any) | undefined;
}, {}>;
declare const DxTick: import("vue").DefineComponent<{
    color: StringConstructor;
    length: NumberConstructor;
    opacity: NumberConstructor;
    shift: NumberConstructor;
    visible: BooleanConstructor;
    width: NumberConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:color": null;
    "update:length": null;
    "update:opacity": null;
    "update:shift": null;
    "update:visible": null;
    "update:width": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    color: StringConstructor;
    length: NumberConstructor;
    opacity: NumberConstructor;
    shift: NumberConstructor;
    visible: BooleanConstructor;
    width: NumberConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:color"?: ((...args: any[]) => any) | undefined;
    "onUpdate:opacity"?: ((...args: any[]) => any) | undefined;
    "onUpdate:width"?: ((...args: any[]) => any) | undefined;
    "onUpdate:visible"?: ((...args: any[]) => any) | undefined;
    "onUpdate:length"?: ((...args: any[]) => any) | undefined;
    "onUpdate:shift"?: ((...args: any[]) => any) | undefined;
}, {
    visible: boolean;
}>;
declare const DxTickInterval: import("vue").DefineComponent<{
    days: NumberConstructor;
    hours: NumberConstructor;
    milliseconds: NumberConstructor;
    minutes: NumberConstructor;
    months: NumberConstructor;
    quarters: NumberConstructor;
    seconds: NumberConstructor;
    weeks: NumberConstructor;
    years: NumberConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:days": null;
    "update:hours": null;
    "update:milliseconds": null;
    "update:minutes": null;
    "update:months": null;
    "update:quarters": null;
    "update:seconds": null;
    "update:weeks": null;
    "update:years": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    days: NumberConstructor;
    hours: NumberConstructor;
    milliseconds: NumberConstructor;
    minutes: NumberConstructor;
    months: NumberConstructor;
    quarters: NumberConstructor;
    seconds: NumberConstructor;
    weeks: NumberConstructor;
    years: NumberConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:days"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hours"?: ((...args: any[]) => any) | undefined;
    "onUpdate:milliseconds"?: ((...args: any[]) => any) | undefined;
    "onUpdate:minutes"?: ((...args: any[]) => any) | undefined;
    "onUpdate:months"?: ((...args: any[]) => any) | undefined;
    "onUpdate:quarters"?: ((...args: any[]) => any) | undefined;
    "onUpdate:seconds"?: ((...args: any[]) => any) | undefined;
    "onUpdate:weeks"?: ((...args: any[]) => any) | undefined;
    "onUpdate:years"?: ((...args: any[]) => any) | undefined;
}, {}>;
declare const DxTitle: import("vue").DefineComponent<{
    font: PropType<Record<string, any> | Font>;
    horizontalAlignment: PropType<HorizontalAlignment>;
    margin: PropType<number | Record<string, any>>;
    placeholderSize: NumberConstructor;
    subtitle: PropType<string | Record<string, any>>;
    text: StringConstructor;
    textOverflow: PropType<TextOverflow>;
    verticalAlignment: PropType<VerticalEdge>;
    wordWrap: PropType<WordWrap>;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:font": null;
    "update:horizontalAlignment": null;
    "update:margin": null;
    "update:placeholderSize": null;
    "update:subtitle": null;
    "update:text": null;
    "update:textOverflow": null;
    "update:verticalAlignment": null;
    "update:wordWrap": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    font: PropType<Record<string, any> | Font>;
    horizontalAlignment: PropType<HorizontalAlignment>;
    margin: PropType<number | Record<string, any>>;
    placeholderSize: NumberConstructor;
    subtitle: PropType<string | Record<string, any>>;
    text: StringConstructor;
    textOverflow: PropType<TextOverflow>;
    verticalAlignment: PropType<VerticalEdge>;
    wordWrap: PropType<WordWrap>;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:font"?: ((...args: any[]) => any) | undefined;
    "onUpdate:text"?: ((...args: any[]) => any) | undefined;
    "onUpdate:textOverflow"?: ((...args: any[]) => any) | undefined;
    "onUpdate:wordWrap"?: ((...args: any[]) => any) | undefined;
    "onUpdate:horizontalAlignment"?: ((...args: any[]) => any) | undefined;
    "onUpdate:margin"?: ((...args: any[]) => any) | undefined;
    "onUpdate:verticalAlignment"?: ((...args: any[]) => any) | undefined;
    "onUpdate:placeholderSize"?: ((...args: any[]) => any) | undefined;
    "onUpdate:subtitle"?: ((...args: any[]) => any) | undefined;
}, {}>;
declare const DxTooltip: import("vue").DefineComponent<{
    argumentFormat: PropType<string | Record<string, any> | import("devextreme/common/core/localization").FormatObject | ((value: number | Date) => string) | ((value: Date) => string) | ((value: number) => string) | Intl.DateTimeFormatOptions | Intl.NumberFormatOptions | ((value: number | Date) => string) | undefined>;
    arrowLength: NumberConstructor;
    border: PropType<Record<string, any>>;
    color: StringConstructor;
    container: {};
    contentTemplate: {};
    cornerRadius: NumberConstructor;
    customizeTooltip: PropType<(pointInfo: dxPolarChartPointInfo) => Record<string, any>>;
    enabled: BooleanConstructor;
    font: PropType<Record<string, any> | Font>;
    format: PropType<string | Record<string, any> | import("devextreme/common/core/localization").FormatObject | ((value: number | Date) => string) | ((value: Date) => string) | ((value: number) => string) | Intl.DateTimeFormatOptions | Intl.NumberFormatOptions | ((value: number | Date) => string) | undefined>;
    interactive: BooleanConstructor;
    opacity: NumberConstructor;
    paddingLeftRight: NumberConstructor;
    paddingTopBottom: NumberConstructor;
    shadow: PropType<Record<string, any>>;
    shared: BooleanConstructor;
    zIndex: NumberConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:argumentFormat": null;
    "update:arrowLength": null;
    "update:border": null;
    "update:color": null;
    "update:container": null;
    "update:contentTemplate": null;
    "update:cornerRadius": null;
    "update:customizeTooltip": null;
    "update:enabled": null;
    "update:font": null;
    "update:format": null;
    "update:interactive": null;
    "update:opacity": null;
    "update:paddingLeftRight": null;
    "update:paddingTopBottom": null;
    "update:shadow": null;
    "update:shared": null;
    "update:zIndex": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    argumentFormat: PropType<string | Record<string, any> | import("devextreme/common/core/localization").FormatObject | ((value: number | Date) => string) | ((value: Date) => string) | ((value: number) => string) | Intl.DateTimeFormatOptions | Intl.NumberFormatOptions | ((value: number | Date) => string) | undefined>;
    arrowLength: NumberConstructor;
    border: PropType<Record<string, any>>;
    color: StringConstructor;
    container: {};
    contentTemplate: {};
    cornerRadius: NumberConstructor;
    customizeTooltip: PropType<(pointInfo: dxPolarChartPointInfo) => Record<string, any>>;
    enabled: BooleanConstructor;
    font: PropType<Record<string, any> | Font>;
    format: PropType<string | Record<string, any> | import("devextreme/common/core/localization").FormatObject | ((value: number | Date) => string) | ((value: Date) => string) | ((value: number) => string) | Intl.DateTimeFormatOptions | Intl.NumberFormatOptions | ((value: number | Date) => string) | undefined>;
    interactive: BooleanConstructor;
    opacity: NumberConstructor;
    paddingLeftRight: NumberConstructor;
    paddingTopBottom: NumberConstructor;
    shadow: PropType<Record<string, any>>;
    shared: BooleanConstructor;
    zIndex: NumberConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:arrowLength"?: ((...args: any[]) => any) | undefined;
    "onUpdate:border"?: ((...args: any[]) => any) | undefined;
    "onUpdate:color"?: ((...args: any[]) => any) | undefined;
    "onUpdate:customizeTooltip"?: ((...args: any[]) => any) | undefined;
    "onUpdate:font"?: ((...args: any[]) => any) | undefined;
    "onUpdate:opacity"?: ((...args: any[]) => any) | undefined;
    "onUpdate:paddingLeftRight"?: ((...args: any[]) => any) | undefined;
    "onUpdate:paddingTopBottom"?: ((...args: any[]) => any) | undefined;
    "onUpdate:shadow"?: ((...args: any[]) => any) | undefined;
    "onUpdate:cornerRadius"?: ((...args: any[]) => any) | undefined;
    "onUpdate:enabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:container"?: ((...args: any[]) => any) | undefined;
    "onUpdate:contentTemplate"?: ((...args: any[]) => any) | undefined;
    "onUpdate:zIndex"?: ((...args: any[]) => any) | undefined;
    "onUpdate:format"?: ((...args: any[]) => any) | undefined;
    "onUpdate:interactive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:argumentFormat"?: ((...args: any[]) => any) | undefined;
    "onUpdate:shared"?: ((...args: any[]) => any) | undefined;
}, {
    enabled: boolean;
    interactive: boolean;
    shared: boolean;
}>;
declare const DxTooltipBorder: import("vue").DefineComponent<{
    color: StringConstructor;
    dashStyle: PropType<DashStyle>;
    opacity: NumberConstructor;
    visible: BooleanConstructor;
    width: NumberConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:color": null;
    "update:dashStyle": null;
    "update:opacity": null;
    "update:visible": null;
    "update:width": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    color: StringConstructor;
    dashStyle: PropType<DashStyle>;
    opacity: NumberConstructor;
    visible: BooleanConstructor;
    width: NumberConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:color"?: ((...args: any[]) => any) | undefined;
    "onUpdate:opacity"?: ((...args: any[]) => any) | undefined;
    "onUpdate:width"?: ((...args: any[]) => any) | undefined;
    "onUpdate:dashStyle"?: ((...args: any[]) => any) | undefined;
    "onUpdate:visible"?: ((...args: any[]) => any) | undefined;
}, {
    visible: boolean;
}>;
declare const DxValueAxis: import("vue").DefineComponent<{
    allowDecimals: BooleanConstructor;
    axisDivisionFactor: NumberConstructor;
    categories: PropType<(string | number | Date)[]>;
    color: StringConstructor;
    constantLines: PropType<Record<string, any>[]>;
    constantLineStyle: PropType<Record<string, any>>;
    discreteAxisDivisionMode: PropType<DiscreteAxisDivisionMode>;
    endOnTick: BooleanConstructor;
    grid: PropType<Record<string, any>>;
    inverted: BooleanConstructor;
    label: PropType<Record<string, any>>;
    linearThreshold: NumberConstructor;
    logarithmBase: NumberConstructor;
    maxValueMargin: NumberConstructor;
    minorGrid: PropType<Record<string, any>>;
    minorTick: PropType<Record<string, any>>;
    minorTickCount: NumberConstructor;
    minorTickInterval: PropType<number | Record<string, any> | TimeInterval>;
    minValueMargin: NumberConstructor;
    minVisualRangeLength: PropType<number | Record<string, any> | TimeInterval>;
    opacity: NumberConstructor;
    showZero: BooleanConstructor;
    strips: PropType<Record<string, any>[]>;
    stripStyle: PropType<Record<string, any>>;
    tick: PropType<Record<string, any>>;
    tickInterval: PropType<number | Record<string, any> | TimeInterval>;
    type: PropType<AxisScaleType>;
    valueMarginsEnabled: BooleanConstructor;
    valueType: PropType<ChartsDataType>;
    visible: BooleanConstructor;
    visualRange: PropType<Record<string, any> | (string | number | Date)[] | CommonChartTypes.VisualRange>;
    visualRangeUpdateMode: PropType<ValueAxisVisualRangeUpdateMode>;
    wholeRange: PropType<Record<string, any> | (string | number | Date)[] | CommonChartTypes.VisualRange>;
    width: NumberConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:allowDecimals": null;
    "update:axisDivisionFactor": null;
    "update:categories": null;
    "update:color": null;
    "update:constantLines": null;
    "update:constantLineStyle": null;
    "update:discreteAxisDivisionMode": null;
    "update:endOnTick": null;
    "update:grid": null;
    "update:inverted": null;
    "update:label": null;
    "update:linearThreshold": null;
    "update:logarithmBase": null;
    "update:maxValueMargin": null;
    "update:minorGrid": null;
    "update:minorTick": null;
    "update:minorTickCount": null;
    "update:minorTickInterval": null;
    "update:minValueMargin": null;
    "update:minVisualRangeLength": null;
    "update:opacity": null;
    "update:showZero": null;
    "update:strips": null;
    "update:stripStyle": null;
    "update:tick": null;
    "update:tickInterval": null;
    "update:type": null;
    "update:valueMarginsEnabled": null;
    "update:valueType": null;
    "update:visible": null;
    "update:visualRange": null;
    "update:visualRangeUpdateMode": null;
    "update:wholeRange": null;
    "update:width": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    allowDecimals: BooleanConstructor;
    axisDivisionFactor: NumberConstructor;
    categories: PropType<(string | number | Date)[]>;
    color: StringConstructor;
    constantLines: PropType<Record<string, any>[]>;
    constantLineStyle: PropType<Record<string, any>>;
    discreteAxisDivisionMode: PropType<DiscreteAxisDivisionMode>;
    endOnTick: BooleanConstructor;
    grid: PropType<Record<string, any>>;
    inverted: BooleanConstructor;
    label: PropType<Record<string, any>>;
    linearThreshold: NumberConstructor;
    logarithmBase: NumberConstructor;
    maxValueMargin: NumberConstructor;
    minorGrid: PropType<Record<string, any>>;
    minorTick: PropType<Record<string, any>>;
    minorTickCount: NumberConstructor;
    minorTickInterval: PropType<number | Record<string, any> | TimeInterval>;
    minValueMargin: NumberConstructor;
    minVisualRangeLength: PropType<number | Record<string, any> | TimeInterval>;
    opacity: NumberConstructor;
    showZero: BooleanConstructor;
    strips: PropType<Record<string, any>[]>;
    stripStyle: PropType<Record<string, any>>;
    tick: PropType<Record<string, any>>;
    tickInterval: PropType<number | Record<string, any> | TimeInterval>;
    type: PropType<AxisScaleType>;
    valueMarginsEnabled: BooleanConstructor;
    valueType: PropType<ChartsDataType>;
    visible: BooleanConstructor;
    visualRange: PropType<Record<string, any> | (string | number | Date)[] | CommonChartTypes.VisualRange>;
    visualRangeUpdateMode: PropType<ValueAxisVisualRangeUpdateMode>;
    wholeRange: PropType<Record<string, any> | (string | number | Date)[] | CommonChartTypes.VisualRange>;
    width: NumberConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:color"?: ((...args: any[]) => any) | undefined;
    "onUpdate:opacity"?: ((...args: any[]) => any) | undefined;
    "onUpdate:type"?: ((...args: any[]) => any) | undefined;
    "onUpdate:width"?: ((...args: any[]) => any) | undefined;
    "onUpdate:visible"?: ((...args: any[]) => any) | undefined;
    "onUpdate:label"?: ((...args: any[]) => any) | undefined;
    "onUpdate:allowDecimals"?: ((...args: any[]) => any) | undefined;
    "onUpdate:categories"?: ((...args: any[]) => any) | undefined;
    "onUpdate:discreteAxisDivisionMode"?: ((...args: any[]) => any) | undefined;
    "onUpdate:endOnTick"?: ((...args: any[]) => any) | undefined;
    "onUpdate:linearThreshold"?: ((...args: any[]) => any) | undefined;
    "onUpdate:logarithmBase"?: ((...args: any[]) => any) | undefined;
    "onUpdate:minorTick"?: ((...args: any[]) => any) | undefined;
    "onUpdate:minorTickCount"?: ((...args: any[]) => any) | undefined;
    "onUpdate:minorTickInterval"?: ((...args: any[]) => any) | undefined;
    "onUpdate:tick"?: ((...args: any[]) => any) | undefined;
    "onUpdate:tickInterval"?: ((...args: any[]) => any) | undefined;
    "onUpdate:valueType"?: ((...args: any[]) => any) | undefined;
    "onUpdate:inverted"?: ((...args: any[]) => any) | undefined;
    "onUpdate:axisDivisionFactor"?: ((...args: any[]) => any) | undefined;
    "onUpdate:constantLines"?: ((...args: any[]) => any) | undefined;
    "onUpdate:constantLineStyle"?: ((...args: any[]) => any) | undefined;
    "onUpdate:grid"?: ((...args: any[]) => any) | undefined;
    "onUpdate:minorGrid"?: ((...args: any[]) => any) | undefined;
    "onUpdate:strips"?: ((...args: any[]) => any) | undefined;
    "onUpdate:stripStyle"?: ((...args: any[]) => any) | undefined;
    "onUpdate:maxValueMargin"?: ((...args: any[]) => any) | undefined;
    "onUpdate:minValueMargin"?: ((...args: any[]) => any) | undefined;
    "onUpdate:minVisualRangeLength"?: ((...args: any[]) => any) | undefined;
    "onUpdate:showZero"?: ((...args: any[]) => any) | undefined;
    "onUpdate:valueMarginsEnabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:visualRange"?: ((...args: any[]) => any) | undefined;
    "onUpdate:visualRangeUpdateMode"?: ((...args: any[]) => any) | undefined;
    "onUpdate:wholeRange"?: ((...args: any[]) => any) | undefined;
}, {
    visible: boolean;
    allowDecimals: boolean;
    endOnTick: boolean;
    inverted: boolean;
    showZero: boolean;
    valueMarginsEnabled: boolean;
}>;
declare const DxValueErrorBar: import("vue").DefineComponent<{
    color: StringConstructor;
    displayMode: PropType<ValueErrorBarDisplayMode>;
    edgeLength: NumberConstructor;
    highValueField: StringConstructor;
    lineWidth: NumberConstructor;
    lowValueField: StringConstructor;
    opacity: NumberConstructor;
    type: PropType<ValueErrorBarType>;
    value: NumberConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:color": null;
    "update:displayMode": null;
    "update:edgeLength": null;
    "update:highValueField": null;
    "update:lineWidth": null;
    "update:lowValueField": null;
    "update:opacity": null;
    "update:type": null;
    "update:value": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    color: StringConstructor;
    displayMode: PropType<ValueErrorBarDisplayMode>;
    edgeLength: NumberConstructor;
    highValueField: StringConstructor;
    lineWidth: NumberConstructor;
    lowValueField: StringConstructor;
    opacity: NumberConstructor;
    type: PropType<ValueErrorBarType>;
    value: NumberConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:color"?: ((...args: any[]) => any) | undefined;
    "onUpdate:opacity"?: ((...args: any[]) => any) | undefined;
    "onUpdate:type"?: ((...args: any[]) => any) | undefined;
    "onUpdate:value"?: ((...args: any[]) => any) | undefined;
    "onUpdate:displayMode"?: ((...args: any[]) => any) | undefined;
    "onUpdate:lineWidth"?: ((...args: any[]) => any) | undefined;
    "onUpdate:highValueField"?: ((...args: any[]) => any) | undefined;
    "onUpdate:lowValueField"?: ((...args: any[]) => any) | undefined;
    "onUpdate:edgeLength"?: ((...args: any[]) => any) | undefined;
}, {}>;
declare const DxVisualRange: import("vue").DefineComponent<{
    endValue: (DateConstructor | NumberConstructor | StringConstructor)[];
    length: PropType<number | Record<string, any> | TimeInterval>;
    startValue: (DateConstructor | NumberConstructor | StringConstructor)[];
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:endValue": null;
    "update:length": null;
    "update:startValue": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    endValue: (DateConstructor | NumberConstructor | StringConstructor)[];
    length: PropType<number | Record<string, any> | TimeInterval>;
    startValue: (DateConstructor | NumberConstructor | StringConstructor)[];
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:endValue"?: ((...args: any[]) => any) | undefined;
    "onUpdate:startValue"?: ((...args: any[]) => any) | undefined;
    "onUpdate:length"?: ((...args: any[]) => any) | undefined;
}, {}>;
declare const DxWholeRange: import("vue").DefineComponent<{
    endValue: (DateConstructor | NumberConstructor | StringConstructor)[];
    length: PropType<number | Record<string, any> | TimeInterval>;
    startValue: (DateConstructor | NumberConstructor | StringConstructor)[];
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:endValue": null;
    "update:length": null;
    "update:startValue": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    endValue: (DateConstructor | NumberConstructor | StringConstructor)[];
    length: PropType<number | Record<string, any> | TimeInterval>;
    startValue: (DateConstructor | NumberConstructor | StringConstructor)[];
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:endValue"?: ((...args: any[]) => any) | undefined;
    "onUpdate:startValue"?: ((...args: any[]) => any) | undefined;
    "onUpdate:length"?: ((...args: any[]) => any) | undefined;
}, {}>;
export default DxPolarChart;
export { DxPolarChart, DxAdaptiveLayout, DxAnimation, DxAnnotation, DxAnnotationBorder, DxArgumentAxis, DxArgumentAxisMinorTick, DxArgumentAxisTick, DxArgumentFormat, DxAxisLabel, DxBorder, DxColor, DxCommonAnnotationSettings, DxCommonAxisSettings, DxCommonAxisSettingsLabel, DxCommonAxisSettingsMinorTick, DxCommonAxisSettingsTick, DxCommonSeriesSettings, DxCommonSeriesSettingsHoverStyle, DxCommonSeriesSettingsLabel, DxCommonSeriesSettingsSelectionStyle, DxConnector, DxConstantLine, DxConstantLineLabel, DxConstantLineStyle, DxConstantLineStyleLabel, DxDataPrepareSettings, DxExport, DxFont, DxFormat, DxGrid, DxHatching, DxHoverStyle, DxImage, DxLabel, DxLegend, DxLegendTitle, DxLegendTitleSubtitle, DxLength, DxLoadingIndicator, DxMargin, DxMinorGrid, DxMinorTick, DxMinorTickInterval, DxMinVisualRangeLength, DxPoint, DxPointBorder, DxPointHoverStyle, DxPointSelectionStyle, DxPolarChartTitle, DxPolarChartTitleSubtitle, DxSelectionStyle, DxSeries, DxSeriesBorder, DxSeriesTemplate, DxShadow, DxSize, DxStrip, DxStripLabel, DxStripStyle, DxStripStyleLabel, DxSubtitle, DxTick, DxTickInterval, DxTitle, DxTooltip, DxTooltipBorder, DxValueAxis, DxValueErrorBar, DxVisualRange, DxWholeRange };
import type * as DxPolarChartTypes from "devextreme/viz/polar_chart_types";
export { DxPolarChartTypes };
