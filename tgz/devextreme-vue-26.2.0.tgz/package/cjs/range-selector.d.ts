/*!
 * devextreme-vue
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

import { PropType } from "vue";
import RangeSelector, { Properties } from "devextreme/viz/range_selector";
import DataSource from "devextreme/data/data_source";
import { DataSourceOptions } from "devextreme/common/data";
import { Store } from "devextreme/data/store";
import { DisposingEvent, DrawnEvent, ExportedEvent, ExportingEvent, FileSavingEvent, IncidentOccurredEvent, InitializedEvent, OptionChangedEvent, ValueChangedEvent, BackgroundImageLocation, AxisScale, ChartAxisScale } from "devextreme/viz/range_selector";
import { VisualRangeUpdateMode, Theme, DashStyle, ScaleBreakLineStyle, Palette, PaletteExtensionMode, ChartsColor, SeriesHoverMode, SeriesSelectionMode, SeriesType, Font, RelativePosition, HatchDirection, LabelOverlap, PointInteractionMode, PointSymbol, TimeInterval, ScaleBreak, DiscreteAxisDivisionMode, ChartsDataType, TextOverflow, WordWrap, ValueErrorBarDisplayMode, ValueErrorBarType } from "devextreme/common/charts";
import { chartPointAggregationInfoObject, chartSeriesObject, ChartSeriesAggregationMethod, FinancialChartReductionLevel } from "devextreme/viz/chart";
import { SliderValueChangeMode, HorizontalAlignment, ExportFormat, VerticalEdge } from "devextreme/common";
import { ChartSeries } from "devextreme/viz/common";
import * as CommonChartTypes from "devextreme/common/charts";
type AccessibleOptions = Pick<Properties, "background" | "behavior" | "chart" | "containerBackgroundColor" | "dataSource" | "dataSourceField" | "disabled" | "elementAttr" | "encodeHtml" | "export" | "indent" | "loadingIndicator" | "margin" | "onDisposing" | "onDrawn" | "onExported" | "onExporting" | "onFileSaving" | "onIncidentOccurred" | "onInitialized" | "onOptionChanged" | "onValueChanged" | "pathModified" | "redrawOnResize" | "rtlEnabled" | "scale" | "selectedRangeColor" | "selectedRangeUpdateMode" | "shutter" | "size" | "sliderHandle" | "sliderMarker" | "theme" | "title" | "value">;
interface DxRangeSelector extends AccessibleOptions {
    readonly instance?: RangeSelector;
}
declare const DxRangeSelector: import("vue").DefineComponent<{
    background: PropType<Record<string, any>>;
    behavior: PropType<Record<string, any>>;
    chart: PropType<Record<string, any>>;
    containerBackgroundColor: StringConstructor;
    dataSource: PropType<string | any[] | Record<string, any> | DataSource<any, any> | DataSourceOptions<any, any, any, any> | Store<any, any> | null>;
    dataSourceField: StringConstructor;
    disabled: BooleanConstructor;
    elementAttr: PropType<Record<string, any>>;
    encodeHtml: BooleanConstructor;
    export: PropType<Record<string, any>>;
    indent: PropType<Record<string, any>>;
    loadingIndicator: PropType<Record<string, any>>;
    margin: PropType<Record<string, any>>;
    onDisposing: PropType<(e: DisposingEvent) => void>;
    onDrawn: PropType<(e: DrawnEvent) => void>;
    onExported: PropType<(e: ExportedEvent) => void>;
    onExporting: PropType<(e: ExportingEvent) => void>;
    onFileSaving: PropType<(e: FileSavingEvent) => void>;
    onIncidentOccurred: PropType<(e: IncidentOccurredEvent) => void>;
    onInitialized: PropType<(e: InitializedEvent) => void>;
    onOptionChanged: PropType<(e: OptionChangedEvent) => void>;
    onValueChanged: PropType<(e: ValueChangedEvent) => void>;
    pathModified: BooleanConstructor;
    redrawOnResize: BooleanConstructor;
    rtlEnabled: BooleanConstructor;
    scale: PropType<Record<string, any>>;
    selectedRangeColor: StringConstructor;
    selectedRangeUpdateMode: PropType<VisualRangeUpdateMode>;
    shutter: PropType<Record<string, any>>;
    size: PropType<Record<string, any>>;
    sliderHandle: PropType<Record<string, any>>;
    sliderMarker: PropType<Record<string, any>>;
    theme: PropType<Theme>;
    title: PropType<string | Record<string, any>>;
    value: PropType<Record<string, any> | (string | number | Date)[] | CommonChartTypes.VisualRange>;
}, unknown, unknown, {
    instance(): RangeSelector;
}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:background": null;
    "update:behavior": null;
    "update:chart": null;
    "update:containerBackgroundColor": null;
    "update:dataSource": null;
    "update:dataSourceField": null;
    "update:disabled": null;
    "update:elementAttr": null;
    "update:encodeHtml": null;
    "update:export": null;
    "update:indent": null;
    "update:loadingIndicator": null;
    "update:margin": null;
    "update:onDisposing": null;
    "update:onDrawn": null;
    "update:onExported": null;
    "update:onExporting": null;
    "update:onFileSaving": null;
    "update:onIncidentOccurred": null;
    "update:onInitialized": null;
    "update:onOptionChanged": null;
    "update:onValueChanged": null;
    "update:pathModified": null;
    "update:redrawOnResize": null;
    "update:rtlEnabled": null;
    "update:scale": null;
    "update:selectedRangeColor": null;
    "update:selectedRangeUpdateMode": null;
    "update:shutter": null;
    "update:size": null;
    "update:sliderHandle": null;
    "update:sliderMarker": null;
    "update:theme": null;
    "update:title": null;
    "update:value": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    background: PropType<Record<string, any>>;
    behavior: PropType<Record<string, any>>;
    chart: PropType<Record<string, any>>;
    containerBackgroundColor: StringConstructor;
    dataSource: PropType<string | any[] | Record<string, any> | DataSource<any, any> | DataSourceOptions<any, any, any, any> | Store<any, any> | null>;
    dataSourceField: StringConstructor;
    disabled: BooleanConstructor;
    elementAttr: PropType<Record<string, any>>;
    encodeHtml: BooleanConstructor;
    export: PropType<Record<string, any>>;
    indent: PropType<Record<string, any>>;
    loadingIndicator: PropType<Record<string, any>>;
    margin: PropType<Record<string, any>>;
    onDisposing: PropType<(e: DisposingEvent) => void>;
    onDrawn: PropType<(e: DrawnEvent) => void>;
    onExported: PropType<(e: ExportedEvent) => void>;
    onExporting: PropType<(e: ExportingEvent) => void>;
    onFileSaving: PropType<(e: FileSavingEvent) => void>;
    onIncidentOccurred: PropType<(e: IncidentOccurredEvent) => void>;
    onInitialized: PropType<(e: InitializedEvent) => void>;
    onOptionChanged: PropType<(e: OptionChangedEvent) => void>;
    onValueChanged: PropType<(e: ValueChangedEvent) => void>;
    pathModified: BooleanConstructor;
    redrawOnResize: BooleanConstructor;
    rtlEnabled: BooleanConstructor;
    scale: PropType<Record<string, any>>;
    selectedRangeColor: StringConstructor;
    selectedRangeUpdateMode: PropType<VisualRangeUpdateMode>;
    shutter: PropType<Record<string, any>>;
    size: PropType<Record<string, any>>;
    sliderHandle: PropType<Record<string, any>>;
    sliderMarker: PropType<Record<string, any>>;
    theme: PropType<Theme>;
    title: PropType<string | Record<string, any>>;
    value: PropType<Record<string, any> | (string | number | Date)[] | CommonChartTypes.VisualRange>;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:background"?: ((...args: any[]) => any) | undefined;
    "onUpdate:disabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:elementAttr"?: ((...args: any[]) => any) | undefined;
    "onUpdate:encodeHtml"?: ((...args: any[]) => any) | undefined;
    "onUpdate:export"?: ((...args: any[]) => any) | undefined;
    "onUpdate:loadingIndicator"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onDisposing"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onDrawn"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onExported"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onExporting"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onFileSaving"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onIncidentOccurred"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onInitialized"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onOptionChanged"?: ((...args: any[]) => any) | undefined;
    "onUpdate:pathModified"?: ((...args: any[]) => any) | undefined;
    "onUpdate:redrawOnResize"?: ((...args: any[]) => any) | undefined;
    "onUpdate:rtlEnabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:size"?: ((...args: any[]) => any) | undefined;
    "onUpdate:theme"?: ((...args: any[]) => any) | undefined;
    "onUpdate:title"?: ((...args: any[]) => any) | undefined;
    "onUpdate:margin"?: ((...args: any[]) => any) | undefined;
    "onUpdate:dataSource"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onValueChanged"?: ((...args: any[]) => any) | undefined;
    "onUpdate:value"?: ((...args: any[]) => any) | undefined;
    "onUpdate:scale"?: ((...args: any[]) => any) | undefined;
    "onUpdate:behavior"?: ((...args: any[]) => any) | undefined;
    "onUpdate:chart"?: ((...args: any[]) => any) | undefined;
    "onUpdate:containerBackgroundColor"?: ((...args: any[]) => any) | undefined;
    "onUpdate:dataSourceField"?: ((...args: any[]) => any) | undefined;
    "onUpdate:indent"?: ((...args: any[]) => any) | undefined;
    "onUpdate:selectedRangeColor"?: ((...args: any[]) => any) | undefined;
    "onUpdate:selectedRangeUpdateMode"?: ((...args: any[]) => any) | undefined;
    "onUpdate:shutter"?: ((...args: any[]) => any) | undefined;
    "onUpdate:sliderHandle"?: ((...args: any[]) => any) | undefined;
    "onUpdate:sliderMarker"?: ((...args: any[]) => any) | undefined;
}, {
    disabled: boolean;
    encodeHtml: boolean;
    pathModified: boolean;
    redrawOnResize: boolean;
    rtlEnabled: boolean;
}>;
declare const DxAggregation: import("vue").DefineComponent<{
    calculate: PropType<(aggregationInfo: chartPointAggregationInfoObject, series: chartSeriesObject) => Record<string, any> | Array<Record<string, any>>>;
    enabled: BooleanConstructor;
    method: PropType<ChartSeriesAggregationMethod>;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:calculate": null;
    "update:enabled": null;
    "update:method": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    calculate: PropType<(aggregationInfo: chartPointAggregationInfoObject, series: chartSeriesObject) => Record<string, any> | Array<Record<string, any>>>;
    enabled: BooleanConstructor;
    method: PropType<ChartSeriesAggregationMethod>;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:enabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:calculate"?: ((...args: any[]) => any) | undefined;
    "onUpdate:method"?: ((...args: any[]) => any) | undefined;
}, {
    enabled: boolean;
}>;
declare const DxAggregationInterval: import("vue").DefineComponent<{
    days: NumberConstructor;
    hours: NumberConstructor;
    milliseconds: NumberConstructor;
    minutes: NumberConstructor;
    months: NumberConstructor;
    quarters: NumberConstructor;
    seconds: NumberConstructor;
    weeks: NumberConstructor;
    years: NumberConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:days": null;
    "update:hours": null;
    "update:milliseconds": null;
    "update:minutes": null;
    "update:months": null;
    "update:quarters": null;
    "update:seconds": null;
    "update:weeks": null;
    "update:years": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    days: NumberConstructor;
    hours: NumberConstructor;
    milliseconds: NumberConstructor;
    minutes: NumberConstructor;
    months: NumberConstructor;
    quarters: NumberConstructor;
    seconds: NumberConstructor;
    weeks: NumberConstructor;
    years: NumberConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:days"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hours"?: ((...args: any[]) => any) | undefined;
    "onUpdate:milliseconds"?: ((...args: any[]) => any) | undefined;
    "onUpdate:minutes"?: ((...args: any[]) => any) | undefined;
    "onUpdate:months"?: ((...args: any[]) => any) | undefined;
    "onUpdate:quarters"?: ((...args: any[]) => any) | undefined;
    "onUpdate:seconds"?: ((...args: any[]) => any) | undefined;
    "onUpdate:weeks"?: ((...args: any[]) => any) | undefined;
    "onUpdate:years"?: ((...args: any[]) => any) | undefined;
}, {}>;
declare const DxArgumentFormat: import("vue").DefineComponent<{
    currency: StringConstructor;
    formatter: PropType<(value: number | Date) => string>;
    parser: PropType<(value: string) => number | Date>;
    precision: NumberConstructor;
    type: PropType<string>;
    useCurrencyAccountingStyle: BooleanConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:currency": null;
    "update:formatter": null;
    "update:parser": null;
    "update:precision": null;
    "update:type": null;
    "update:useCurrencyAccountingStyle": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    currency: StringConstructor;
    formatter: PropType<(value: number | Date) => string>;
    parser: PropType<(value: string) => number | Date>;
    precision: NumberConstructor;
    type: PropType<string>;
    useCurrencyAccountingStyle: BooleanConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:type"?: ((...args: any[]) => any) | undefined;
    "onUpdate:currency"?: ((...args: any[]) => any) | undefined;
    "onUpdate:formatter"?: ((...args: any[]) => any) | undefined;
    "onUpdate:parser"?: ((...args: any[]) => any) | undefined;
    "onUpdate:precision"?: ((...args: any[]) => any) | undefined;
    "onUpdate:useCurrencyAccountingStyle"?: ((...args: any[]) => any) | undefined;
}, {
    useCurrencyAccountingStyle: boolean;
}>;
declare const DxBackground: import("vue").DefineComponent<{
    color: StringConstructor;
    image: PropType<Record<string, any>>;
    visible: BooleanConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:color": null;
    "update:image": null;
    "update:visible": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    color: StringConstructor;
    image: PropType<Record<string, any>>;
    visible: BooleanConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:color"?: ((...args: any[]) => any) | undefined;
    "onUpdate:image"?: ((...args: any[]) => any) | undefined;
    "onUpdate:visible"?: ((...args: any[]) => any) | undefined;
}, {
    visible: boolean;
}>;
declare const DxBackgroundImage: import("vue").DefineComponent<{
    location: PropType<BackgroundImageLocation>;
    url: StringConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:location": null;
    "update:url": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    location: PropType<BackgroundImageLocation>;
    url: StringConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:url"?: ((...args: any[]) => any) | undefined;
    "onUpdate:location"?: ((...args: any[]) => any) | undefined;
}, {}>;
declare const DxBehavior: import("vue").DefineComponent<{
    allowSlidersSwap: BooleanConstructor;
    animationEnabled: BooleanConstructor;
    manualRangeSelectionEnabled: BooleanConstructor;
    moveSelectedRangeByClick: BooleanConstructor;
    snapToTicks: BooleanConstructor;
    valueChangeMode: PropType<SliderValueChangeMode>;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:allowSlidersSwap": null;
    "update:animationEnabled": null;
    "update:manualRangeSelectionEnabled": null;
    "update:moveSelectedRangeByClick": null;
    "update:snapToTicks": null;
    "update:valueChangeMode": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    allowSlidersSwap: BooleanConstructor;
    animationEnabled: BooleanConstructor;
    manualRangeSelectionEnabled: BooleanConstructor;
    moveSelectedRangeByClick: BooleanConstructor;
    snapToTicks: BooleanConstructor;
    valueChangeMode: PropType<SliderValueChangeMode>;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:animationEnabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:valueChangeMode"?: ((...args: any[]) => any) | undefined;
    "onUpdate:allowSlidersSwap"?: ((...args: any[]) => any) | undefined;
    "onUpdate:manualRangeSelectionEnabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:moveSelectedRangeByClick"?: ((...args: any[]) => any) | undefined;
    "onUpdate:snapToTicks"?: ((...args: any[]) => any) | undefined;
}, {
    animationEnabled: boolean;
    allowSlidersSwap: boolean;
    manualRangeSelectionEnabled: boolean;
    moveSelectedRangeByClick: boolean;
    snapToTicks: boolean;
}>;
declare const DxBorder: import("vue").DefineComponent<{
    color: StringConstructor;
    dashStyle: PropType<DashStyle>;
    visible: BooleanConstructor;
    width: NumberConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:color": null;
    "update:dashStyle": null;
    "update:visible": null;
    "update:width": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    color: StringConstructor;
    dashStyle: PropType<DashStyle>;
    visible: BooleanConstructor;
    width: NumberConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:color"?: ((...args: any[]) => any) | undefined;
    "onUpdate:width"?: ((...args: any[]) => any) | undefined;
    "onUpdate:dashStyle"?: ((...args: any[]) => any) | undefined;
    "onUpdate:visible"?: ((...args: any[]) => any) | undefined;
}, {
    visible: boolean;
}>;
declare const DxBreak: import("vue").DefineComponent<{
    endValue: (DateConstructor | NumberConstructor | StringConstructor)[];
    startValue: (DateConstructor | NumberConstructor | StringConstructor)[];
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:endValue": null;
    "update:startValue": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    endValue: (DateConstructor | NumberConstructor | StringConstructor)[];
    startValue: (DateConstructor | NumberConstructor | StringConstructor)[];
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:endValue"?: ((...args: any[]) => any) | undefined;
    "onUpdate:startValue"?: ((...args: any[]) => any) | undefined;
}, {}>;
declare const DxBreakStyle: import("vue").DefineComponent<{
    color: StringConstructor;
    line: PropType<ScaleBreakLineStyle>;
    width: NumberConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:color": null;
    "update:line": null;
    "update:width": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    color: StringConstructor;
    line: PropType<ScaleBreakLineStyle>;
    width: NumberConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:color"?: ((...args: any[]) => any) | undefined;
    "onUpdate:width"?: ((...args: any[]) => any) | undefined;
    "onUpdate:line"?: ((...args: any[]) => any) | undefined;
}, {}>;
declare const DxChart: import("vue").DefineComponent<{
    barGroupPadding: NumberConstructor;
    barGroupWidth: NumberConstructor;
    bottomIndent: NumberConstructor;
    commonSeriesSettings: PropType<Record<string, any> | import("devextreme/viz/chart").CommonSeriesSettings>;
    dataPrepareSettings: PropType<Record<string, any>>;
    maxBubbleSize: NumberConstructor;
    minBubbleSize: NumberConstructor;
    negativesAsZeroes: BooleanConstructor;
    palette: PropType<string[] | Palette>;
    paletteExtensionMode: PropType<PaletteExtensionMode>;
    series: PropType<Record<string, any> | ChartSeries | ChartSeries[]>;
    seriesTemplate: PropType<Record<string, any>>;
    topIndent: NumberConstructor;
    valueAxis: PropType<Record<string, any>>;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:barGroupPadding": null;
    "update:barGroupWidth": null;
    "update:bottomIndent": null;
    "update:commonSeriesSettings": null;
    "update:dataPrepareSettings": null;
    "update:maxBubbleSize": null;
    "update:minBubbleSize": null;
    "update:negativesAsZeroes": null;
    "update:palette": null;
    "update:paletteExtensionMode": null;
    "update:series": null;
    "update:seriesTemplate": null;
    "update:topIndent": null;
    "update:valueAxis": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    barGroupPadding: NumberConstructor;
    barGroupWidth: NumberConstructor;
    bottomIndent: NumberConstructor;
    commonSeriesSettings: PropType<Record<string, any> | import("devextreme/viz/chart").CommonSeriesSettings>;
    dataPrepareSettings: PropType<Record<string, any>>;
    maxBubbleSize: NumberConstructor;
    minBubbleSize: NumberConstructor;
    negativesAsZeroes: BooleanConstructor;
    palette: PropType<string[] | Palette>;
    paletteExtensionMode: PropType<PaletteExtensionMode>;
    series: PropType<Record<string, any> | ChartSeries | ChartSeries[]>;
    seriesTemplate: PropType<Record<string, any>>;
    topIndent: NumberConstructor;
    valueAxis: PropType<Record<string, any>>;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:palette"?: ((...args: any[]) => any) | undefined;
    "onUpdate:paletteExtensionMode"?: ((...args: any[]) => any) | undefined;
    "onUpdate:barGroupPadding"?: ((...args: any[]) => any) | undefined;
    "onUpdate:barGroupWidth"?: ((...args: any[]) => any) | undefined;
    "onUpdate:bottomIndent"?: ((...args: any[]) => any) | undefined;
    "onUpdate:commonSeriesSettings"?: ((...args: any[]) => any) | undefined;
    "onUpdate:dataPrepareSettings"?: ((...args: any[]) => any) | undefined;
    "onUpdate:maxBubbleSize"?: ((...args: any[]) => any) | undefined;
    "onUpdate:minBubbleSize"?: ((...args: any[]) => any) | undefined;
    "onUpdate:negativesAsZeroes"?: ((...args: any[]) => any) | undefined;
    "onUpdate:series"?: ((...args: any[]) => any) | undefined;
    "onUpdate:seriesTemplate"?: ((...args: any[]) => any) | undefined;
    "onUpdate:topIndent"?: ((...args: any[]) => any) | undefined;
    "onUpdate:valueAxis"?: ((...args: any[]) => any) | undefined;
}, {
    negativesAsZeroes: boolean;
}>;
declare const DxColor: import("vue").DefineComponent<{
    base: StringConstructor;
    fillId: StringConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:base": null;
    "update:fillId": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    base: StringConstructor;
    fillId: StringConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:base"?: ((...args: any[]) => any) | undefined;
    "onUpdate:fillId"?: ((...args: any[]) => any) | undefined;
}, {}>;
declare const DxCommonSeriesSettings: import("vue").DefineComponent<{
    aggregation: PropType<Record<string, any>>;
    area: {};
    argumentField: StringConstructor;
    axis: StringConstructor;
    bar: {};
    barOverlapGroup: StringConstructor;
    barPadding: NumberConstructor;
    barWidth: NumberConstructor;
    border: PropType<Record<string, any>>;
    bubble: {};
    candlestick: {};
    closeValueField: StringConstructor;
    color: PropType<string | Record<string, any> | ChartsColor>;
    cornerRadius: NumberConstructor;
    dashStyle: PropType<DashStyle>;
    fullstackedarea: {};
    fullstackedbar: {};
    fullstackedline: {};
    fullstackedspline: {};
    fullstackedsplinearea: {};
    highValueField: StringConstructor;
    hoverMode: PropType<SeriesHoverMode>;
    hoverStyle: PropType<Record<string, any>>;
    ignoreEmptyPoints: BooleanConstructor;
    innerColor: StringConstructor;
    label: PropType<Record<string, any>>;
    line: {};
    lowValueField: StringConstructor;
    maxLabelCount: NumberConstructor;
    minBarSize: NumberConstructor;
    opacity: NumberConstructor;
    openValueField: StringConstructor;
    pane: StringConstructor;
    point: PropType<Record<string, any>>;
    rangearea: {};
    rangebar: {};
    rangeValue1Field: StringConstructor;
    rangeValue2Field: StringConstructor;
    reduction: PropType<Record<string, any>>;
    scatter: {};
    selectionMode: PropType<SeriesSelectionMode>;
    selectionStyle: PropType<Record<string, any>>;
    showInLegend: BooleanConstructor;
    sizeField: StringConstructor;
    spline: {};
    splinearea: {};
    stack: StringConstructor;
    stackedarea: {};
    stackedbar: {};
    stackedline: {};
    stackedspline: {};
    stackedsplinearea: {};
    steparea: {};
    stepline: {};
    stock: {};
    tagField: StringConstructor;
    type: PropType<SeriesType>;
    valueErrorBar: PropType<Record<string, any>>;
    valueField: StringConstructor;
    visible: BooleanConstructor;
    width: NumberConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:aggregation": null;
    "update:area": null;
    "update:argumentField": null;
    "update:axis": null;
    "update:bar": null;
    "update:barOverlapGroup": null;
    "update:barPadding": null;
    "update:barWidth": null;
    "update:border": null;
    "update:bubble": null;
    "update:candlestick": null;
    "update:closeValueField": null;
    "update:color": null;
    "update:cornerRadius": null;
    "update:dashStyle": null;
    "update:fullstackedarea": null;
    "update:fullstackedbar": null;
    "update:fullstackedline": null;
    "update:fullstackedspline": null;
    "update:fullstackedsplinearea": null;
    "update:highValueField": null;
    "update:hoverMode": null;
    "update:hoverStyle": null;
    "update:ignoreEmptyPoints": null;
    "update:innerColor": null;
    "update:label": null;
    "update:line": null;
    "update:lowValueField": null;
    "update:maxLabelCount": null;
    "update:minBarSize": null;
    "update:opacity": null;
    "update:openValueField": null;
    "update:pane": null;
    "update:point": null;
    "update:rangearea": null;
    "update:rangebar": null;
    "update:rangeValue1Field": null;
    "update:rangeValue2Field": null;
    "update:reduction": null;
    "update:scatter": null;
    "update:selectionMode": null;
    "update:selectionStyle": null;
    "update:showInLegend": null;
    "update:sizeField": null;
    "update:spline": null;
    "update:splinearea": null;
    "update:stack": null;
    "update:stackedarea": null;
    "update:stackedbar": null;
    "update:stackedline": null;
    "update:stackedspline": null;
    "update:stackedsplinearea": null;
    "update:steparea": null;
    "update:stepline": null;
    "update:stock": null;
    "update:tagField": null;
    "update:type": null;
    "update:valueErrorBar": null;
    "update:valueField": null;
    "update:visible": null;
    "update:width": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    aggregation: PropType<Record<string, any>>;
    area: {};
    argumentField: StringConstructor;
    axis: StringConstructor;
    bar: {};
    barOverlapGroup: StringConstructor;
    barPadding: NumberConstructor;
    barWidth: NumberConstructor;
    border: PropType<Record<string, any>>;
    bubble: {};
    candlestick: {};
    closeValueField: StringConstructor;
    color: PropType<string | Record<string, any> | ChartsColor>;
    cornerRadius: NumberConstructor;
    dashStyle: PropType<DashStyle>;
    fullstackedarea: {};
    fullstackedbar: {};
    fullstackedline: {};
    fullstackedspline: {};
    fullstackedsplinearea: {};
    highValueField: StringConstructor;
    hoverMode: PropType<SeriesHoverMode>;
    hoverStyle: PropType<Record<string, any>>;
    ignoreEmptyPoints: BooleanConstructor;
    innerColor: StringConstructor;
    label: PropType<Record<string, any>>;
    line: {};
    lowValueField: StringConstructor;
    maxLabelCount: NumberConstructor;
    minBarSize: NumberConstructor;
    opacity: NumberConstructor;
    openValueField: StringConstructor;
    pane: StringConstructor;
    point: PropType<Record<string, any>>;
    rangearea: {};
    rangebar: {};
    rangeValue1Field: StringConstructor;
    rangeValue2Field: StringConstructor;
    reduction: PropType<Record<string, any>>;
    scatter: {};
    selectionMode: PropType<SeriesSelectionMode>;
    selectionStyle: PropType<Record<string, any>>;
    showInLegend: BooleanConstructor;
    sizeField: StringConstructor;
    spline: {};
    splinearea: {};
    stack: StringConstructor;
    stackedarea: {};
    stackedbar: {};
    stackedline: {};
    stackedspline: {};
    stackedsplinearea: {};
    steparea: {};
    stepline: {};
    stock: {};
    tagField: StringConstructor;
    type: PropType<SeriesType>;
    valueErrorBar: PropType<Record<string, any>>;
    valueField: StringConstructor;
    visible: BooleanConstructor;
    width: NumberConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:border"?: ((...args: any[]) => any) | undefined;
    "onUpdate:color"?: ((...args: any[]) => any) | undefined;
    "onUpdate:opacity"?: ((...args: any[]) => any) | undefined;
    "onUpdate:type"?: ((...args: any[]) => any) | undefined;
    "onUpdate:width"?: ((...args: any[]) => any) | undefined;
    "onUpdate:cornerRadius"?: ((...args: any[]) => any) | undefined;
    "onUpdate:dashStyle"?: ((...args: any[]) => any) | undefined;
    "onUpdate:visible"?: ((...args: any[]) => any) | undefined;
    "onUpdate:label"?: ((...args: any[]) => any) | undefined;
    "onUpdate:selectionMode"?: ((...args: any[]) => any) | undefined;
    "onUpdate:valueField"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoverStyle"?: ((...args: any[]) => any) | undefined;
    "onUpdate:selectionStyle"?: ((...args: any[]) => any) | undefined;
    "onUpdate:argumentField"?: ((...args: any[]) => any) | undefined;
    "onUpdate:ignoreEmptyPoints"?: ((...args: any[]) => any) | undefined;
    "onUpdate:area"?: ((...args: any[]) => any) | undefined;
    "onUpdate:line"?: ((...args: any[]) => any) | undefined;
    "onUpdate:aggregation"?: ((...args: any[]) => any) | undefined;
    "onUpdate:axis"?: ((...args: any[]) => any) | undefined;
    "onUpdate:bar"?: ((...args: any[]) => any) | undefined;
    "onUpdate:barOverlapGroup"?: ((...args: any[]) => any) | undefined;
    "onUpdate:barPadding"?: ((...args: any[]) => any) | undefined;
    "onUpdate:barWidth"?: ((...args: any[]) => any) | undefined;
    "onUpdate:bubble"?: ((...args: any[]) => any) | undefined;
    "onUpdate:candlestick"?: ((...args: any[]) => any) | undefined;
    "onUpdate:closeValueField"?: ((...args: any[]) => any) | undefined;
    "onUpdate:fullstackedarea"?: ((...args: any[]) => any) | undefined;
    "onUpdate:fullstackedbar"?: ((...args: any[]) => any) | undefined;
    "onUpdate:fullstackedline"?: ((...args: any[]) => any) | undefined;
    "onUpdate:fullstackedspline"?: ((...args: any[]) => any) | undefined;
    "onUpdate:fullstackedsplinearea"?: ((...args: any[]) => any) | undefined;
    "onUpdate:highValueField"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoverMode"?: ((...args: any[]) => any) | undefined;
    "onUpdate:innerColor"?: ((...args: any[]) => any) | undefined;
    "onUpdate:lowValueField"?: ((...args: any[]) => any) | undefined;
    "onUpdate:maxLabelCount"?: ((...args: any[]) => any) | undefined;
    "onUpdate:minBarSize"?: ((...args: any[]) => any) | undefined;
    "onUpdate:openValueField"?: ((...args: any[]) => any) | undefined;
    "onUpdate:pane"?: ((...args: any[]) => any) | undefined;
    "onUpdate:point"?: ((...args: any[]) => any) | undefined;
    "onUpdate:rangearea"?: ((...args: any[]) => any) | undefined;
    "onUpdate:rangebar"?: ((...args: any[]) => any) | undefined;
    "onUpdate:rangeValue1Field"?: ((...args: any[]) => any) | undefined;
    "onUpdate:rangeValue2Field"?: ((...args: any[]) => any) | undefined;
    "onUpdate:reduction"?: ((...args: any[]) => any) | undefined;
    "onUpdate:scatter"?: ((...args: any[]) => any) | undefined;
    "onUpdate:showInLegend"?: ((...args: any[]) => any) | undefined;
    "onUpdate:sizeField"?: ((...args: any[]) => any) | undefined;
    "onUpdate:spline"?: ((...args: any[]) => any) | undefined;
    "onUpdate:splinearea"?: ((...args: any[]) => any) | undefined;
    "onUpdate:stack"?: ((...args: any[]) => any) | undefined;
    "onUpdate:stackedarea"?: ((...args: any[]) => any) | undefined;
    "onUpdate:stackedbar"?: ((...args: any[]) => any) | undefined;
    "onUpdate:stackedline"?: ((...args: any[]) => any) | undefined;
    "onUpdate:stackedspline"?: ((...args: any[]) => any) | undefined;
    "onUpdate:stackedsplinearea"?: ((...args: any[]) => any) | undefined;
    "onUpdate:steparea"?: ((...args: any[]) => any) | undefined;
    "onUpdate:stepline"?: ((...args: any[]) => any) | undefined;
    "onUpdate:stock"?: ((...args: any[]) => any) | undefined;
    "onUpdate:tagField"?: ((...args: any[]) => any) | undefined;
    "onUpdate:valueErrorBar"?: ((...args: any[]) => any) | undefined;
}, {
    visible: boolean;
    ignoreEmptyPoints: boolean;
    showInLegend: boolean;
}>;
declare const DxCommonSeriesSettingsHoverStyle: import("vue").DefineComponent<{
    border: PropType<Record<string, any>>;
    color: PropType<string | Record<string, any> | ChartsColor>;
    dashStyle: PropType<DashStyle>;
    hatching: PropType<Record<string, any>>;
    highlight: BooleanConstructor;
    width: NumberConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:border": null;
    "update:color": null;
    "update:dashStyle": null;
    "update:hatching": null;
    "update:highlight": null;
    "update:width": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    border: PropType<Record<string, any>>;
    color: PropType<string | Record<string, any> | ChartsColor>;
    dashStyle: PropType<DashStyle>;
    hatching: PropType<Record<string, any>>;
    highlight: BooleanConstructor;
    width: NumberConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:border"?: ((...args: any[]) => any) | undefined;
    "onUpdate:color"?: ((...args: any[]) => any) | undefined;
    "onUpdate:width"?: ((...args: any[]) => any) | undefined;
    "onUpdate:dashStyle"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hatching"?: ((...args: any[]) => any) | undefined;
    "onUpdate:highlight"?: ((...args: any[]) => any) | undefined;
}, {
    highlight: boolean;
}>;
declare const DxCommonSeriesSettingsLabel: import("vue").DefineComponent<{
    alignment: PropType<HorizontalAlignment>;
    argumentFormat: PropType<string | Record<string, any> | import("devextreme/common/core/localization").FormatObject | ((value: number | Date) => string) | ((value: Date) => string) | ((value: number) => string) | Intl.DateTimeFormatOptions | Intl.NumberFormatOptions | ((value: number | Date) => string) | undefined>;
    backgroundColor: StringConstructor;
    border: PropType<Record<string, any>>;
    connector: PropType<Record<string, any>>;
    customizeText: PropType<(pointInfo: any) => string>;
    displayFormat: StringConstructor;
    font: PropType<Record<string, any> | Font>;
    format: PropType<string | Record<string, any> | import("devextreme/common/core/localization").FormatObject | ((value: number | Date) => string) | ((value: Date) => string) | ((value: number) => string) | Intl.DateTimeFormatOptions | Intl.NumberFormatOptions | ((value: number | Date) => string) | undefined>;
    horizontalOffset: NumberConstructor;
    position: PropType<RelativePosition>;
    rotationAngle: NumberConstructor;
    showForZeroValues: BooleanConstructor;
    verticalOffset: NumberConstructor;
    visible: BooleanConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:alignment": null;
    "update:argumentFormat": null;
    "update:backgroundColor": null;
    "update:border": null;
    "update:connector": null;
    "update:customizeText": null;
    "update:displayFormat": null;
    "update:font": null;
    "update:format": null;
    "update:horizontalOffset": null;
    "update:position": null;
    "update:rotationAngle": null;
    "update:showForZeroValues": null;
    "update:verticalOffset": null;
    "update:visible": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    alignment: PropType<HorizontalAlignment>;
    argumentFormat: PropType<string | Record<string, any> | import("devextreme/common/core/localization").FormatObject | ((value: number | Date) => string) | ((value: Date) => string) | ((value: number) => string) | Intl.DateTimeFormatOptions | Intl.NumberFormatOptions | ((value: number | Date) => string) | undefined>;
    backgroundColor: StringConstructor;
    border: PropType<Record<string, any>>;
    connector: PropType<Record<string, any>>;
    customizeText: PropType<(pointInfo: any) => string>;
    displayFormat: StringConstructor;
    font: PropType<Record<string, any> | Font>;
    format: PropType<string | Record<string, any> | import("devextreme/common/core/localization").FormatObject | ((value: number | Date) => string) | ((value: Date) => string) | ((value: number) => string) | Intl.DateTimeFormatOptions | Intl.NumberFormatOptions | ((value: number | Date) => string) | undefined>;
    horizontalOffset: NumberConstructor;
    position: PropType<RelativePosition>;
    rotationAngle: NumberConstructor;
    showForZeroValues: BooleanConstructor;
    verticalOffset: NumberConstructor;
    visible: BooleanConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:border"?: ((...args: any[]) => any) | undefined;
    "onUpdate:font"?: ((...args: any[]) => any) | undefined;
    "onUpdate:visible"?: ((...args: any[]) => any) | undefined;
    "onUpdate:backgroundColor"?: ((...args: any[]) => any) | undefined;
    "onUpdate:customizeText"?: ((...args: any[]) => any) | undefined;
    "onUpdate:format"?: ((...args: any[]) => any) | undefined;
    "onUpdate:alignment"?: ((...args: any[]) => any) | undefined;
    "onUpdate:position"?: ((...args: any[]) => any) | undefined;
    "onUpdate:horizontalOffset"?: ((...args: any[]) => any) | undefined;
    "onUpdate:verticalOffset"?: ((...args: any[]) => any) | undefined;
    "onUpdate:argumentFormat"?: ((...args: any[]) => any) | undefined;
    "onUpdate:connector"?: ((...args: any[]) => any) | undefined;
    "onUpdate:displayFormat"?: ((...args: any[]) => any) | undefined;
    "onUpdate:rotationAngle"?: ((...args: any[]) => any) | undefined;
    "onUpdate:showForZeroValues"?: ((...args: any[]) => any) | undefined;
}, {
    visible: boolean;
    showForZeroValues: boolean;
}>;
declare const DxCommonSeriesSettingsSelectionStyle: import("vue").DefineComponent<{
    border: PropType<Record<string, any>>;
    color: PropType<string | Record<string, any> | ChartsColor>;
    dashStyle: PropType<DashStyle>;
    hatching: PropType<Record<string, any>>;
    highlight: BooleanConstructor;
    width: NumberConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:border": null;
    "update:color": null;
    "update:dashStyle": null;
    "update:hatching": null;
    "update:highlight": null;
    "update:width": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    border: PropType<Record<string, any>>;
    color: PropType<string | Record<string, any> | ChartsColor>;
    dashStyle: PropType<DashStyle>;
    hatching: PropType<Record<string, any>>;
    highlight: BooleanConstructor;
    width: NumberConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:border"?: ((...args: any[]) => any) | undefined;
    "onUpdate:color"?: ((...args: any[]) => any) | undefined;
    "onUpdate:width"?: ((...args: any[]) => any) | undefined;
    "onUpdate:dashStyle"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hatching"?: ((...args: any[]) => any) | undefined;
    "onUpdate:highlight"?: ((...args: any[]) => any) | undefined;
}, {
    highlight: boolean;
}>;
declare const DxConnector: import("vue").DefineComponent<{
    color: StringConstructor;
    visible: BooleanConstructor;
    width: NumberConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:color": null;
    "update:visible": null;
    "update:width": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    color: StringConstructor;
    visible: BooleanConstructor;
    width: NumberConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:color"?: ((...args: any[]) => any) | undefined;
    "onUpdate:width"?: ((...args: any[]) => any) | undefined;
    "onUpdate:visible"?: ((...args: any[]) => any) | undefined;
}, {
    visible: boolean;
}>;
declare const DxDataPrepareSettings: import("vue").DefineComponent<{
    checkTypeForAllData: BooleanConstructor;
    convertToAxisDataType: BooleanConstructor;
    sortingMethod: PropType<boolean | ((a: {
        arg: Date | number | string;
        val: Date | number | string;
    }, b: {
        arg: Date | number | string;
        val: Date | number | string;
    }) => number)>;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:checkTypeForAllData": null;
    "update:convertToAxisDataType": null;
    "update:sortingMethod": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    checkTypeForAllData: BooleanConstructor;
    convertToAxisDataType: BooleanConstructor;
    sortingMethod: PropType<boolean | ((a: {
        arg: Date | number | string;
        val: Date | number | string;
    }, b: {
        arg: Date | number | string;
        val: Date | number | string;
    }) => number)>;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:sortingMethod"?: ((...args: any[]) => any) | undefined;
    "onUpdate:checkTypeForAllData"?: ((...args: any[]) => any) | undefined;
    "onUpdate:convertToAxisDataType"?: ((...args: any[]) => any) | undefined;
}, {
    checkTypeForAllData: boolean;
    convertToAxisDataType: boolean;
}>;
declare const DxExport: import("vue").DefineComponent<{
    backgroundColor: StringConstructor;
    enabled: BooleanConstructor;
    fileName: StringConstructor;
    formats: PropType<ExportFormat[]>;
    margin: NumberConstructor;
    printingEnabled: BooleanConstructor;
    svgToCanvas: PropType<(svg: any, canvas: any) => any>;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:backgroundColor": null;
    "update:enabled": null;
    "update:fileName": null;
    "update:formats": null;
    "update:margin": null;
    "update:printingEnabled": null;
    "update:svgToCanvas": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    backgroundColor: StringConstructor;
    enabled: BooleanConstructor;
    fileName: StringConstructor;
    formats: PropType<ExportFormat[]>;
    margin: NumberConstructor;
    printingEnabled: BooleanConstructor;
    svgToCanvas: PropType<(svg: any, canvas: any) => any>;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:enabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:margin"?: ((...args: any[]) => any) | undefined;
    "onUpdate:backgroundColor"?: ((...args: any[]) => any) | undefined;
    "onUpdate:fileName"?: ((...args: any[]) => any) | undefined;
    "onUpdate:formats"?: ((...args: any[]) => any) | undefined;
    "onUpdate:printingEnabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:svgToCanvas"?: ((...args: any[]) => any) | undefined;
}, {
    enabled: boolean;
    printingEnabled: boolean;
}>;
declare const DxFont: import("vue").DefineComponent<{
    color: StringConstructor;
    family: StringConstructor;
    opacity: NumberConstructor;
    size: (NumberConstructor | StringConstructor)[];
    weight: NumberConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:color": null;
    "update:family": null;
    "update:opacity": null;
    "update:size": null;
    "update:weight": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    color: StringConstructor;
    family: StringConstructor;
    opacity: NumberConstructor;
    size: (NumberConstructor | StringConstructor)[];
    weight: NumberConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:size"?: ((...args: any[]) => any) | undefined;
    "onUpdate:color"?: ((...args: any[]) => any) | undefined;
    "onUpdate:opacity"?: ((...args: any[]) => any) | undefined;
    "onUpdate:family"?: ((...args: any[]) => any) | undefined;
    "onUpdate:weight"?: ((...args: any[]) => any) | undefined;
}, {}>;
declare const DxFormat: import("vue").DefineComponent<{
    currency: StringConstructor;
    formatter: PropType<(value: number | Date) => string>;
    parser: PropType<(value: string) => number | Date>;
    precision: NumberConstructor;
    type: PropType<string>;
    useCurrencyAccountingStyle: BooleanConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:currency": null;
    "update:formatter": null;
    "update:parser": null;
    "update:precision": null;
    "update:type": null;
    "update:useCurrencyAccountingStyle": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    currency: StringConstructor;
    formatter: PropType<(value: number | Date) => string>;
    parser: PropType<(value: string) => number | Date>;
    precision: NumberConstructor;
    type: PropType<string>;
    useCurrencyAccountingStyle: BooleanConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:type"?: ((...args: any[]) => any) | undefined;
    "onUpdate:currency"?: ((...args: any[]) => any) | undefined;
    "onUpdate:formatter"?: ((...args: any[]) => any) | undefined;
    "onUpdate:parser"?: ((...args: any[]) => any) | undefined;
    "onUpdate:precision"?: ((...args: any[]) => any) | undefined;
    "onUpdate:useCurrencyAccountingStyle"?: ((...args: any[]) => any) | undefined;
}, {
    useCurrencyAccountingStyle: boolean;
}>;
declare const DxHatching: import("vue").DefineComponent<{
    direction: PropType<HatchDirection>;
    opacity: NumberConstructor;
    step: NumberConstructor;
    width: NumberConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:direction": null;
    "update:opacity": null;
    "update:step": null;
    "update:width": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    direction: PropType<HatchDirection>;
    opacity: NumberConstructor;
    step: NumberConstructor;
    width: NumberConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:opacity"?: ((...args: any[]) => any) | undefined;
    "onUpdate:width"?: ((...args: any[]) => any) | undefined;
    "onUpdate:direction"?: ((...args: any[]) => any) | undefined;
    "onUpdate:step"?: ((...args: any[]) => any) | undefined;
}, {}>;
declare const DxHeight: import("vue").DefineComponent<{
    rangeMaxPoint: NumberConstructor;
    rangeMinPoint: NumberConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:rangeMaxPoint": null;
    "update:rangeMinPoint": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    rangeMaxPoint: NumberConstructor;
    rangeMinPoint: NumberConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:rangeMaxPoint"?: ((...args: any[]) => any) | undefined;
    "onUpdate:rangeMinPoint"?: ((...args: any[]) => any) | undefined;
}, {}>;
declare const DxHoverStyle: import("vue").DefineComponent<{
    border: PropType<Record<string, any>>;
    color: PropType<string | Record<string, any> | ChartsColor>;
    dashStyle: PropType<DashStyle>;
    hatching: PropType<Record<string, any>>;
    highlight: BooleanConstructor;
    size: NumberConstructor;
    width: NumberConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:border": null;
    "update:color": null;
    "update:dashStyle": null;
    "update:hatching": null;
    "update:highlight": null;
    "update:size": null;
    "update:width": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    border: PropType<Record<string, any>>;
    color: PropType<string | Record<string, any> | ChartsColor>;
    dashStyle: PropType<DashStyle>;
    hatching: PropType<Record<string, any>>;
    highlight: BooleanConstructor;
    size: NumberConstructor;
    width: NumberConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:size"?: ((...args: any[]) => any) | undefined;
    "onUpdate:border"?: ((...args: any[]) => any) | undefined;
    "onUpdate:color"?: ((...args: any[]) => any) | undefined;
    "onUpdate:width"?: ((...args: any[]) => any) | undefined;
    "onUpdate:dashStyle"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hatching"?: ((...args: any[]) => any) | undefined;
    "onUpdate:highlight"?: ((...args: any[]) => any) | undefined;
}, {
    highlight: boolean;
}>;
declare const DxImage: import("vue").DefineComponent<{
    height: PropType<number | Record<string, any>>;
    location: PropType<BackgroundImageLocation>;
    url: PropType<string | Record<string, any>>;
    width: PropType<number | Record<string, any>>;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:height": null;
    "update:location": null;
    "update:url": null;
    "update:width": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    height: PropType<number | Record<string, any>>;
    location: PropType<BackgroundImageLocation>;
    url: PropType<string | Record<string, any>>;
    width: PropType<number | Record<string, any>>;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:height"?: ((...args: any[]) => any) | undefined;
    "onUpdate:width"?: ((...args: any[]) => any) | undefined;
    "onUpdate:url"?: ((...args: any[]) => any) | undefined;
    "onUpdate:location"?: ((...args: any[]) => any) | undefined;
}, {}>;
declare const DxIndent: import("vue").DefineComponent<{
    left: NumberConstructor;
    right: NumberConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:left": null;
    "update:right": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    left: NumberConstructor;
    right: NumberConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:left"?: ((...args: any[]) => any) | undefined;
    "onUpdate:right"?: ((...args: any[]) => any) | undefined;
}, {}>;
declare const DxLabel: import("vue").DefineComponent<{
    alignment: PropType<HorizontalAlignment>;
    argumentFormat: PropType<string | Record<string, any> | import("devextreme/common/core/localization").FormatObject | ((value: number | Date) => string) | ((value: Date) => string) | ((value: number) => string) | Intl.DateTimeFormatOptions | Intl.NumberFormatOptions | ((value: number | Date) => string) | undefined>;
    backgroundColor: StringConstructor;
    border: PropType<Record<string, any>>;
    connector: PropType<Record<string, any>>;
    customizeText: PropType<(pointInfo: any) => string>;
    displayFormat: StringConstructor;
    font: PropType<Record<string, any> | Font>;
    format: PropType<string | Record<string, any> | import("devextreme/common/core/localization").FormatObject | ((value: number | Date) => string) | ((value: Date) => string) | ((value: number) => string) | Intl.DateTimeFormatOptions | Intl.NumberFormatOptions | ((value: number | Date) => string) | undefined>;
    horizontalOffset: NumberConstructor;
    overlappingBehavior: PropType<LabelOverlap>;
    position: PropType<RelativePosition>;
    rotationAngle: NumberConstructor;
    showForZeroValues: BooleanConstructor;
    topIndent: NumberConstructor;
    verticalOffset: NumberConstructor;
    visible: BooleanConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:alignment": null;
    "update:argumentFormat": null;
    "update:backgroundColor": null;
    "update:border": null;
    "update:connector": null;
    "update:customizeText": null;
    "update:displayFormat": null;
    "update:font": null;
    "update:format": null;
    "update:horizontalOffset": null;
    "update:overlappingBehavior": null;
    "update:position": null;
    "update:rotationAngle": null;
    "update:showForZeroValues": null;
    "update:topIndent": null;
    "update:verticalOffset": null;
    "update:visible": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    alignment: PropType<HorizontalAlignment>;
    argumentFormat: PropType<string | Record<string, any> | import("devextreme/common/core/localization").FormatObject | ((value: number | Date) => string) | ((value: Date) => string) | ((value: number) => string) | Intl.DateTimeFormatOptions | Intl.NumberFormatOptions | ((value: number | Date) => string) | undefined>;
    backgroundColor: StringConstructor;
    border: PropType<Record<string, any>>;
    connector: PropType<Record<string, any>>;
    customizeText: PropType<(pointInfo: any) => string>;
    displayFormat: StringConstructor;
    font: PropType<Record<string, any> | Font>;
    format: PropType<string | Record<string, any> | import("devextreme/common/core/localization").FormatObject | ((value: number | Date) => string) | ((value: Date) => string) | ((value: number) => string) | Intl.DateTimeFormatOptions | Intl.NumberFormatOptions | ((value: number | Date) => string) | undefined>;
    horizontalOffset: NumberConstructor;
    overlappingBehavior: PropType<LabelOverlap>;
    position: PropType<RelativePosition>;
    rotationAngle: NumberConstructor;
    showForZeroValues: BooleanConstructor;
    topIndent: NumberConstructor;
    verticalOffset: NumberConstructor;
    visible: BooleanConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:border"?: ((...args: any[]) => any) | undefined;
    "onUpdate:font"?: ((...args: any[]) => any) | undefined;
    "onUpdate:visible"?: ((...args: any[]) => any) | undefined;
    "onUpdate:backgroundColor"?: ((...args: any[]) => any) | undefined;
    "onUpdate:customizeText"?: ((...args: any[]) => any) | undefined;
    "onUpdate:format"?: ((...args: any[]) => any) | undefined;
    "onUpdate:alignment"?: ((...args: any[]) => any) | undefined;
    "onUpdate:position"?: ((...args: any[]) => any) | undefined;
    "onUpdate:horizontalOffset"?: ((...args: any[]) => any) | undefined;
    "onUpdate:overlappingBehavior"?: ((...args: any[]) => any) | undefined;
    "onUpdate:verticalOffset"?: ((...args: any[]) => any) | undefined;
    "onUpdate:topIndent"?: ((...args: any[]) => any) | undefined;
    "onUpdate:argumentFormat"?: ((...args: any[]) => any) | undefined;
    "onUpdate:connector"?: ((...args: any[]) => any) | undefined;
    "onUpdate:displayFormat"?: ((...args: any[]) => any) | undefined;
    "onUpdate:rotationAngle"?: ((...args: any[]) => any) | undefined;
    "onUpdate:showForZeroValues"?: ((...args: any[]) => any) | undefined;
}, {
    visible: boolean;
    showForZeroValues: boolean;
}>;
declare const DxLength: import("vue").DefineComponent<{
    days: NumberConstructor;
    hours: NumberConstructor;
    milliseconds: NumberConstructor;
    minutes: NumberConstructor;
    months: NumberConstructor;
    quarters: NumberConstructor;
    seconds: NumberConstructor;
    weeks: NumberConstructor;
    years: NumberConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:days": null;
    "update:hours": null;
    "update:milliseconds": null;
    "update:minutes": null;
    "update:months": null;
    "update:quarters": null;
    "update:seconds": null;
    "update:weeks": null;
    "update:years": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    days: NumberConstructor;
    hours: NumberConstructor;
    milliseconds: NumberConstructor;
    minutes: NumberConstructor;
    months: NumberConstructor;
    quarters: NumberConstructor;
    seconds: NumberConstructor;
    weeks: NumberConstructor;
    years: NumberConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:days"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hours"?: ((...args: any[]) => any) | undefined;
    "onUpdate:milliseconds"?: ((...args: any[]) => any) | undefined;
    "onUpdate:minutes"?: ((...args: any[]) => any) | undefined;
    "onUpdate:months"?: ((...args: any[]) => any) | undefined;
    "onUpdate:quarters"?: ((...args: any[]) => any) | undefined;
    "onUpdate:seconds"?: ((...args: any[]) => any) | undefined;
    "onUpdate:weeks"?: ((...args: any[]) => any) | undefined;
    "onUpdate:years"?: ((...args: any[]) => any) | undefined;
}, {}>;
declare const DxLoadingIndicator: import("vue").DefineComponent<{
    backgroundColor: StringConstructor;
    enabled: BooleanConstructor;
    font: PropType<Record<string, any> | Font>;
    show: BooleanConstructor;
    text: StringConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:backgroundColor": null;
    "update:enabled": null;
    "update:font": null;
    "update:show": null;
    "update:text": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    backgroundColor: StringConstructor;
    enabled: BooleanConstructor;
    font: PropType<Record<string, any> | Font>;
    show: BooleanConstructor;
    text: StringConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:font"?: ((...args: any[]) => any) | undefined;
    "onUpdate:text"?: ((...args: any[]) => any) | undefined;
    "onUpdate:enabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:backgroundColor"?: ((...args: any[]) => any) | undefined;
    "onUpdate:show"?: ((...args: any[]) => any) | undefined;
}, {
    enabled: boolean;
    show: boolean;
}>;
declare const DxMargin: import("vue").DefineComponent<{
    bottom: NumberConstructor;
    left: NumberConstructor;
    right: NumberConstructor;
    top: NumberConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:bottom": null;
    "update:left": null;
    "update:right": null;
    "update:top": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    bottom: NumberConstructor;
    left: NumberConstructor;
    right: NumberConstructor;
    top: NumberConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:bottom"?: ((...args: any[]) => any) | undefined;
    "onUpdate:left"?: ((...args: any[]) => any) | undefined;
    "onUpdate:right"?: ((...args: any[]) => any) | undefined;
    "onUpdate:top"?: ((...args: any[]) => any) | undefined;
}, {}>;
declare const DxMarker: import("vue").DefineComponent<{
    label: PropType<Record<string, any>>;
    separatorHeight: NumberConstructor;
    textLeftIndent: NumberConstructor;
    textTopIndent: NumberConstructor;
    topIndent: NumberConstructor;
    visible: BooleanConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:label": null;
    "update:separatorHeight": null;
    "update:textLeftIndent": null;
    "update:textTopIndent": null;
    "update:topIndent": null;
    "update:visible": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    label: PropType<Record<string, any>>;
    separatorHeight: NumberConstructor;
    textLeftIndent: NumberConstructor;
    textTopIndent: NumberConstructor;
    topIndent: NumberConstructor;
    visible: BooleanConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:visible"?: ((...args: any[]) => any) | undefined;
    "onUpdate:label"?: ((...args: any[]) => any) | undefined;
    "onUpdate:topIndent"?: ((...args: any[]) => any) | undefined;
    "onUpdate:separatorHeight"?: ((...args: any[]) => any) | undefined;
    "onUpdate:textLeftIndent"?: ((...args: any[]) => any) | undefined;
    "onUpdate:textTopIndent"?: ((...args: any[]) => any) | undefined;
}, {
    visible: boolean;
}>;
declare const DxMarkerLabel: import("vue").DefineComponent<{
    customizeText: PropType<(markerValue: {
        value: Date | number;
        valueText: string;
    }) => string>;
    format: PropType<string | Record<string, any> | import("devextreme/common/core/localization").FormatObject | ((value: number | Date) => string) | ((value: Date) => string) | ((value: number) => string) | Intl.DateTimeFormatOptions | Intl.NumberFormatOptions | ((value: number | Date) => string) | undefined>;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:customizeText": null;
    "update:format": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    customizeText: PropType<(markerValue: {
        value: Date | number;
        valueText: string;
    }) => string>;
    format: PropType<string | Record<string, any> | import("devextreme/common/core/localization").FormatObject | ((value: number | Date) => string) | ((value: Date) => string) | ((value: number) => string) | Intl.DateTimeFormatOptions | Intl.NumberFormatOptions | ((value: number | Date) => string) | undefined>;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:customizeText"?: ((...args: any[]) => any) | undefined;
    "onUpdate:format"?: ((...args: any[]) => any) | undefined;
}, {}>;
declare const DxMaxRange: import("vue").DefineComponent<{
    days: NumberConstructor;
    hours: NumberConstructor;
    milliseconds: NumberConstructor;
    minutes: NumberConstructor;
    months: NumberConstructor;
    quarters: NumberConstructor;
    seconds: NumberConstructor;
    weeks: NumberConstructor;
    years: NumberConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:days": null;
    "update:hours": null;
    "update:milliseconds": null;
    "update:minutes": null;
    "update:months": null;
    "update:quarters": null;
    "update:seconds": null;
    "update:weeks": null;
    "update:years": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    days: NumberConstructor;
    hours: NumberConstructor;
    milliseconds: NumberConstructor;
    minutes: NumberConstructor;
    months: NumberConstructor;
    quarters: NumberConstructor;
    seconds: NumberConstructor;
    weeks: NumberConstructor;
    years: NumberConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:days"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hours"?: ((...args: any[]) => any) | undefined;
    "onUpdate:milliseconds"?: ((...args: any[]) => any) | undefined;
    "onUpdate:minutes"?: ((...args: any[]) => any) | undefined;
    "onUpdate:months"?: ((...args: any[]) => any) | undefined;
    "onUpdate:quarters"?: ((...args: any[]) => any) | undefined;
    "onUpdate:seconds"?: ((...args: any[]) => any) | undefined;
    "onUpdate:weeks"?: ((...args: any[]) => any) | undefined;
    "onUpdate:years"?: ((...args: any[]) => any) | undefined;
}, {}>;
declare const DxMinorTick: import("vue").DefineComponent<{
    color: StringConstructor;
    opacity: NumberConstructor;
    visible: BooleanConstructor;
    width: NumberConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:color": null;
    "update:opacity": null;
    "update:visible": null;
    "update:width": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    color: StringConstructor;
    opacity: NumberConstructor;
    visible: BooleanConstructor;
    width: NumberConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:color"?: ((...args: any[]) => any) | undefined;
    "onUpdate:opacity"?: ((...args: any[]) => any) | undefined;
    "onUpdate:width"?: ((...args: any[]) => any) | undefined;
    "onUpdate:visible"?: ((...args: any[]) => any) | undefined;
}, {
    visible: boolean;
}>;
declare const DxMinorTickInterval: import("vue").DefineComponent<{
    days: NumberConstructor;
    hours: NumberConstructor;
    milliseconds: NumberConstructor;
    minutes: NumberConstructor;
    months: NumberConstructor;
    quarters: NumberConstructor;
    seconds: NumberConstructor;
    weeks: NumberConstructor;
    years: NumberConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:days": null;
    "update:hours": null;
    "update:milliseconds": null;
    "update:minutes": null;
    "update:months": null;
    "update:quarters": null;
    "update:seconds": null;
    "update:weeks": null;
    "update:years": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    days: NumberConstructor;
    hours: NumberConstructor;
    milliseconds: NumberConstructor;
    minutes: NumberConstructor;
    months: NumberConstructor;
    quarters: NumberConstructor;
    seconds: NumberConstructor;
    weeks: NumberConstructor;
    years: NumberConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:days"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hours"?: ((...args: any[]) => any) | undefined;
    "onUpdate:milliseconds"?: ((...args: any[]) => any) | undefined;
    "onUpdate:minutes"?: ((...args: any[]) => any) | undefined;
    "onUpdate:months"?: ((...args: any[]) => any) | undefined;
    "onUpdate:quarters"?: ((...args: any[]) => any) | undefined;
    "onUpdate:seconds"?: ((...args: any[]) => any) | undefined;
    "onUpdate:weeks"?: ((...args: any[]) => any) | undefined;
    "onUpdate:years"?: ((...args: any[]) => any) | undefined;
}, {}>;
declare const DxMinRange: import("vue").DefineComponent<{
    days: NumberConstructor;
    hours: NumberConstructor;
    milliseconds: NumberConstructor;
    minutes: NumberConstructor;
    months: NumberConstructor;
    quarters: NumberConstructor;
    seconds: NumberConstructor;
    weeks: NumberConstructor;
    years: NumberConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:days": null;
    "update:hours": null;
    "update:milliseconds": null;
    "update:minutes": null;
    "update:months": null;
    "update:quarters": null;
    "update:seconds": null;
    "update:weeks": null;
    "update:years": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    days: NumberConstructor;
    hours: NumberConstructor;
    milliseconds: NumberConstructor;
    minutes: NumberConstructor;
    months: NumberConstructor;
    quarters: NumberConstructor;
    seconds: NumberConstructor;
    weeks: NumberConstructor;
    years: NumberConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:days"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hours"?: ((...args: any[]) => any) | undefined;
    "onUpdate:milliseconds"?: ((...args: any[]) => any) | undefined;
    "onUpdate:minutes"?: ((...args: any[]) => any) | undefined;
    "onUpdate:months"?: ((...args: any[]) => any) | undefined;
    "onUpdate:quarters"?: ((...args: any[]) => any) | undefined;
    "onUpdate:seconds"?: ((...args: any[]) => any) | undefined;
    "onUpdate:weeks"?: ((...args: any[]) => any) | undefined;
    "onUpdate:years"?: ((...args: any[]) => any) | undefined;
}, {}>;
declare const DxPoint: import("vue").DefineComponent<{
    border: PropType<Record<string, any>>;
    color: PropType<string | Record<string, any> | ChartsColor>;
    hoverMode: PropType<PointInteractionMode>;
    hoverStyle: PropType<Record<string, any>>;
    image: PropType<string | Record<string, any>>;
    selectionMode: PropType<PointInteractionMode>;
    selectionStyle: PropType<Record<string, any>>;
    size: NumberConstructor;
    symbol: PropType<PointSymbol>;
    visible: BooleanConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:border": null;
    "update:color": null;
    "update:hoverMode": null;
    "update:hoverStyle": null;
    "update:image": null;
    "update:selectionMode": null;
    "update:selectionStyle": null;
    "update:size": null;
    "update:symbol": null;
    "update:visible": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    border: PropType<Record<string, any>>;
    color: PropType<string | Record<string, any> | ChartsColor>;
    hoverMode: PropType<PointInteractionMode>;
    hoverStyle: PropType<Record<string, any>>;
    image: PropType<string | Record<string, any>>;
    selectionMode: PropType<PointInteractionMode>;
    selectionStyle: PropType<Record<string, any>>;
    size: NumberConstructor;
    symbol: PropType<PointSymbol>;
    visible: BooleanConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:size"?: ((...args: any[]) => any) | undefined;
    "onUpdate:border"?: ((...args: any[]) => any) | undefined;
    "onUpdate:color"?: ((...args: any[]) => any) | undefined;
    "onUpdate:image"?: ((...args: any[]) => any) | undefined;
    "onUpdate:visible"?: ((...args: any[]) => any) | undefined;
    "onUpdate:selectionMode"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoverStyle"?: ((...args: any[]) => any) | undefined;
    "onUpdate:selectionStyle"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoverMode"?: ((...args: any[]) => any) | undefined;
    "onUpdate:symbol"?: ((...args: any[]) => any) | undefined;
}, {
    visible: boolean;
}>;
declare const DxPointBorder: import("vue").DefineComponent<{
    color: StringConstructor;
    visible: BooleanConstructor;
    width: NumberConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:color": null;
    "update:visible": null;
    "update:width": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    color: StringConstructor;
    visible: BooleanConstructor;
    width: NumberConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:color"?: ((...args: any[]) => any) | undefined;
    "onUpdate:width"?: ((...args: any[]) => any) | undefined;
    "onUpdate:visible"?: ((...args: any[]) => any) | undefined;
}, {
    visible: boolean;
}>;
declare const DxPointHoverStyle: import("vue").DefineComponent<{
    border: PropType<Record<string, any>>;
    color: PropType<string | Record<string, any> | ChartsColor>;
    size: NumberConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:border": null;
    "update:color": null;
    "update:size": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    border: PropType<Record<string, any>>;
    color: PropType<string | Record<string, any> | ChartsColor>;
    size: NumberConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:size"?: ((...args: any[]) => any) | undefined;
    "onUpdate:border"?: ((...args: any[]) => any) | undefined;
    "onUpdate:color"?: ((...args: any[]) => any) | undefined;
}, {}>;
declare const DxPointImage: import("vue").DefineComponent<{
    height: PropType<number | Record<string, any>>;
    url: PropType<string | Record<string, any>>;
    width: PropType<number | Record<string, any>>;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:height": null;
    "update:url": null;
    "update:width": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    height: PropType<number | Record<string, any>>;
    url: PropType<string | Record<string, any>>;
    width: PropType<number | Record<string, any>>;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:height"?: ((...args: any[]) => any) | undefined;
    "onUpdate:width"?: ((...args: any[]) => any) | undefined;
    "onUpdate:url"?: ((...args: any[]) => any) | undefined;
}, {}>;
declare const DxPointSelectionStyle: import("vue").DefineComponent<{
    border: PropType<Record<string, any>>;
    color: PropType<string | Record<string, any> | ChartsColor>;
    size: NumberConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:border": null;
    "update:color": null;
    "update:size": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    border: PropType<Record<string, any>>;
    color: PropType<string | Record<string, any> | ChartsColor>;
    size: NumberConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:size"?: ((...args: any[]) => any) | undefined;
    "onUpdate:border"?: ((...args: any[]) => any) | undefined;
    "onUpdate:color"?: ((...args: any[]) => any) | undefined;
}, {}>;
declare const DxReduction: import("vue").DefineComponent<{
    color: StringConstructor;
    level: PropType<FinancialChartReductionLevel>;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:color": null;
    "update:level": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    color: StringConstructor;
    level: PropType<FinancialChartReductionLevel>;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:color"?: ((...args: any[]) => any) | undefined;
    "onUpdate:level"?: ((...args: any[]) => any) | undefined;
}, {}>;
declare const DxScale: import("vue").DefineComponent<{
    aggregationGroupWidth: NumberConstructor;
    aggregationInterval: PropType<number | Record<string, any> | TimeInterval>;
    allowDecimals: BooleanConstructor;
    breaks: PropType<ScaleBreak[]>;
    breakStyle: PropType<Record<string, any>>;
    categories: PropType<(string | number | Date)[]>;
    discreteAxisDivisionMode: PropType<DiscreteAxisDivisionMode>;
    endOnTick: BooleanConstructor;
    endValue: (DateConstructor | NumberConstructor | StringConstructor)[];
    holidays: PropType<number[] | (string | Date)[]>;
    label: PropType<Record<string, any>>;
    linearThreshold: NumberConstructor;
    logarithmBase: NumberConstructor;
    marker: PropType<Record<string, any>>;
    maxRange: PropType<number | Record<string, any> | TimeInterval>;
    minorTick: PropType<Record<string, any>>;
    minorTickCount: NumberConstructor;
    minorTickInterval: PropType<number | Record<string, any> | TimeInterval>;
    minRange: PropType<number | Record<string, any> | TimeInterval>;
    placeholderHeight: NumberConstructor;
    showCustomBoundaryTicks: BooleanConstructor;
    singleWorkdays: PropType<number[] | (string | Date)[]>;
    startValue: (DateConstructor | NumberConstructor | StringConstructor)[];
    tick: PropType<Record<string, any>>;
    tickInterval: PropType<number | Record<string, any> | TimeInterval>;
    type: PropType<AxisScale>;
    valueType: PropType<ChartsDataType>;
    workdaysOnly: BooleanConstructor;
    workWeek: PropType<number[]>;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:aggregationGroupWidth": null;
    "update:aggregationInterval": null;
    "update:allowDecimals": null;
    "update:breaks": null;
    "update:breakStyle": null;
    "update:categories": null;
    "update:discreteAxisDivisionMode": null;
    "update:endOnTick": null;
    "update:endValue": null;
    "update:holidays": null;
    "update:label": null;
    "update:linearThreshold": null;
    "update:logarithmBase": null;
    "update:marker": null;
    "update:maxRange": null;
    "update:minorTick": null;
    "update:minorTickCount": null;
    "update:minorTickInterval": null;
    "update:minRange": null;
    "update:placeholderHeight": null;
    "update:showCustomBoundaryTicks": null;
    "update:singleWorkdays": null;
    "update:startValue": null;
    "update:tick": null;
    "update:tickInterval": null;
    "update:type": null;
    "update:valueType": null;
    "update:workdaysOnly": null;
    "update:workWeek": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    aggregationGroupWidth: NumberConstructor;
    aggregationInterval: PropType<number | Record<string, any> | TimeInterval>;
    allowDecimals: BooleanConstructor;
    breaks: PropType<ScaleBreak[]>;
    breakStyle: PropType<Record<string, any>>;
    categories: PropType<(string | number | Date)[]>;
    discreteAxisDivisionMode: PropType<DiscreteAxisDivisionMode>;
    endOnTick: BooleanConstructor;
    endValue: (DateConstructor | NumberConstructor | StringConstructor)[];
    holidays: PropType<number[] | (string | Date)[]>;
    label: PropType<Record<string, any>>;
    linearThreshold: NumberConstructor;
    logarithmBase: NumberConstructor;
    marker: PropType<Record<string, any>>;
    maxRange: PropType<number | Record<string, any> | TimeInterval>;
    minorTick: PropType<Record<string, any>>;
    minorTickCount: NumberConstructor;
    minorTickInterval: PropType<number | Record<string, any> | TimeInterval>;
    minRange: PropType<number | Record<string, any> | TimeInterval>;
    placeholderHeight: NumberConstructor;
    showCustomBoundaryTicks: BooleanConstructor;
    singleWorkdays: PropType<number[] | (string | Date)[]>;
    startValue: (DateConstructor | NumberConstructor | StringConstructor)[];
    tick: PropType<Record<string, any>>;
    tickInterval: PropType<number | Record<string, any> | TimeInterval>;
    type: PropType<AxisScale>;
    valueType: PropType<ChartsDataType>;
    workdaysOnly: BooleanConstructor;
    workWeek: PropType<number[]>;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:type"?: ((...args: any[]) => any) | undefined;
    "onUpdate:label"?: ((...args: any[]) => any) | undefined;
    "onUpdate:endValue"?: ((...args: any[]) => any) | undefined;
    "onUpdate:startValue"?: ((...args: any[]) => any) | undefined;
    "onUpdate:aggregationGroupWidth"?: ((...args: any[]) => any) | undefined;
    "onUpdate:aggregationInterval"?: ((...args: any[]) => any) | undefined;
    "onUpdate:allowDecimals"?: ((...args: any[]) => any) | undefined;
    "onUpdate:breaks"?: ((...args: any[]) => any) | undefined;
    "onUpdate:breakStyle"?: ((...args: any[]) => any) | undefined;
    "onUpdate:categories"?: ((...args: any[]) => any) | undefined;
    "onUpdate:discreteAxisDivisionMode"?: ((...args: any[]) => any) | undefined;
    "onUpdate:endOnTick"?: ((...args: any[]) => any) | undefined;
    "onUpdate:holidays"?: ((...args: any[]) => any) | undefined;
    "onUpdate:linearThreshold"?: ((...args: any[]) => any) | undefined;
    "onUpdate:logarithmBase"?: ((...args: any[]) => any) | undefined;
    "onUpdate:marker"?: ((...args: any[]) => any) | undefined;
    "onUpdate:maxRange"?: ((...args: any[]) => any) | undefined;
    "onUpdate:minorTick"?: ((...args: any[]) => any) | undefined;
    "onUpdate:minorTickCount"?: ((...args: any[]) => any) | undefined;
    "onUpdate:minorTickInterval"?: ((...args: any[]) => any) | undefined;
    "onUpdate:minRange"?: ((...args: any[]) => any) | undefined;
    "onUpdate:placeholderHeight"?: ((...args: any[]) => any) | undefined;
    "onUpdate:showCustomBoundaryTicks"?: ((...args: any[]) => any) | undefined;
    "onUpdate:singleWorkdays"?: ((...args: any[]) => any) | undefined;
    "onUpdate:tick"?: ((...args: any[]) => any) | undefined;
    "onUpdate:tickInterval"?: ((...args: any[]) => any) | undefined;
    "onUpdate:valueType"?: ((...args: any[]) => any) | undefined;
    "onUpdate:workdaysOnly"?: ((...args: any[]) => any) | undefined;
    "onUpdate:workWeek"?: ((...args: any[]) => any) | undefined;
}, {
    allowDecimals: boolean;
    endOnTick: boolean;
    showCustomBoundaryTicks: boolean;
    workdaysOnly: boolean;
}>;
declare const DxScaleLabel: import("vue").DefineComponent<{
    customizeText: PropType<(scaleValue: {
        value: Date | number | string;
        valueText: string;
    }) => string>;
    font: PropType<Record<string, any> | Font>;
    format: PropType<string | Record<string, any> | import("devextreme/common/core/localization").FormatObject | ((value: number | Date) => string) | ((value: Date) => string) | ((value: number) => string) | Intl.DateTimeFormatOptions | Intl.NumberFormatOptions | ((value: number | Date) => string) | undefined>;
    overlappingBehavior: PropType<LabelOverlap>;
    topIndent: NumberConstructor;
    visible: BooleanConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:customizeText": null;
    "update:font": null;
    "update:format": null;
    "update:overlappingBehavior": null;
    "update:topIndent": null;
    "update:visible": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    customizeText: PropType<(scaleValue: {
        value: Date | number | string;
        valueText: string;
    }) => string>;
    font: PropType<Record<string, any> | Font>;
    format: PropType<string | Record<string, any> | import("devextreme/common/core/localization").FormatObject | ((value: number | Date) => string) | ((value: Date) => string) | ((value: number) => string) | Intl.DateTimeFormatOptions | Intl.NumberFormatOptions | ((value: number | Date) => string) | undefined>;
    overlappingBehavior: PropType<LabelOverlap>;
    topIndent: NumberConstructor;
    visible: BooleanConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:font"?: ((...args: any[]) => any) | undefined;
    "onUpdate:visible"?: ((...args: any[]) => any) | undefined;
    "onUpdate:customizeText"?: ((...args: any[]) => any) | undefined;
    "onUpdate:format"?: ((...args: any[]) => any) | undefined;
    "onUpdate:overlappingBehavior"?: ((...args: any[]) => any) | undefined;
    "onUpdate:topIndent"?: ((...args: any[]) => any) | undefined;
}, {
    visible: boolean;
}>;
declare const DxSelectionStyle: import("vue").DefineComponent<{
    border: PropType<Record<string, any>>;
    color: PropType<string | Record<string, any> | ChartsColor>;
    dashStyle: PropType<DashStyle>;
    hatching: PropType<Record<string, any>>;
    highlight: BooleanConstructor;
    size: NumberConstructor;
    width: NumberConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:border": null;
    "update:color": null;
    "update:dashStyle": null;
    "update:hatching": null;
    "update:highlight": null;
    "update:size": null;
    "update:width": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    border: PropType<Record<string, any>>;
    color: PropType<string | Record<string, any> | ChartsColor>;
    dashStyle: PropType<DashStyle>;
    hatching: PropType<Record<string, any>>;
    highlight: BooleanConstructor;
    size: NumberConstructor;
    width: NumberConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:size"?: ((...args: any[]) => any) | undefined;
    "onUpdate:border"?: ((...args: any[]) => any) | undefined;
    "onUpdate:color"?: ((...args: any[]) => any) | undefined;
    "onUpdate:width"?: ((...args: any[]) => any) | undefined;
    "onUpdate:dashStyle"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hatching"?: ((...args: any[]) => any) | undefined;
    "onUpdate:highlight"?: ((...args: any[]) => any) | undefined;
}, {
    highlight: boolean;
}>;
declare const DxSeries: import("vue").DefineComponent<{
    aggregation: PropType<Record<string, any>>;
    argumentField: StringConstructor;
    axis: StringConstructor;
    barOverlapGroup: StringConstructor;
    barPadding: NumberConstructor;
    barWidth: NumberConstructor;
    border: PropType<Record<string, any>>;
    closeValueField: StringConstructor;
    color: PropType<string | Record<string, any> | ChartsColor>;
    cornerRadius: NumberConstructor;
    dashStyle: PropType<DashStyle>;
    highValueField: StringConstructor;
    hoverMode: PropType<SeriesHoverMode>;
    hoverStyle: PropType<Record<string, any>>;
    ignoreEmptyPoints: BooleanConstructor;
    innerColor: StringConstructor;
    label: PropType<Record<string, any>>;
    lowValueField: StringConstructor;
    maxLabelCount: NumberConstructor;
    minBarSize: NumberConstructor;
    name: StringConstructor;
    opacity: NumberConstructor;
    openValueField: StringConstructor;
    pane: StringConstructor;
    point: PropType<Record<string, any>>;
    rangeValue1Field: StringConstructor;
    rangeValue2Field: StringConstructor;
    reduction: PropType<Record<string, any>>;
    selectionMode: PropType<SeriesSelectionMode>;
    selectionStyle: PropType<Record<string, any>>;
    showInLegend: BooleanConstructor;
    sizeField: StringConstructor;
    stack: StringConstructor;
    tag: {};
    tagField: StringConstructor;
    type: PropType<SeriesType>;
    valueErrorBar: PropType<Record<string, any>>;
    valueField: StringConstructor;
    visible: BooleanConstructor;
    width: NumberConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:aggregation": null;
    "update:argumentField": null;
    "update:axis": null;
    "update:barOverlapGroup": null;
    "update:barPadding": null;
    "update:barWidth": null;
    "update:border": null;
    "update:closeValueField": null;
    "update:color": null;
    "update:cornerRadius": null;
    "update:dashStyle": null;
    "update:highValueField": null;
    "update:hoverMode": null;
    "update:hoverStyle": null;
    "update:ignoreEmptyPoints": null;
    "update:innerColor": null;
    "update:label": null;
    "update:lowValueField": null;
    "update:maxLabelCount": null;
    "update:minBarSize": null;
    "update:name": null;
    "update:opacity": null;
    "update:openValueField": null;
    "update:pane": null;
    "update:point": null;
    "update:rangeValue1Field": null;
    "update:rangeValue2Field": null;
    "update:reduction": null;
    "update:selectionMode": null;
    "update:selectionStyle": null;
    "update:showInLegend": null;
    "update:sizeField": null;
    "update:stack": null;
    "update:tag": null;
    "update:tagField": null;
    "update:type": null;
    "update:valueErrorBar": null;
    "update:valueField": null;
    "update:visible": null;
    "update:width": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    aggregation: PropType<Record<string, any>>;
    argumentField: StringConstructor;
    axis: StringConstructor;
    barOverlapGroup: StringConstructor;
    barPadding: NumberConstructor;
    barWidth: NumberConstructor;
    border: PropType<Record<string, any>>;
    closeValueField: StringConstructor;
    color: PropType<string | Record<string, any> | ChartsColor>;
    cornerRadius: NumberConstructor;
    dashStyle: PropType<DashStyle>;
    highValueField: StringConstructor;
    hoverMode: PropType<SeriesHoverMode>;
    hoverStyle: PropType<Record<string, any>>;
    ignoreEmptyPoints: BooleanConstructor;
    innerColor: StringConstructor;
    label: PropType<Record<string, any>>;
    lowValueField: StringConstructor;
    maxLabelCount: NumberConstructor;
    minBarSize: NumberConstructor;
    name: StringConstructor;
    opacity: NumberConstructor;
    openValueField: StringConstructor;
    pane: StringConstructor;
    point: PropType<Record<string, any>>;
    rangeValue1Field: StringConstructor;
    rangeValue2Field: StringConstructor;
    reduction: PropType<Record<string, any>>;
    selectionMode: PropType<SeriesSelectionMode>;
    selectionStyle: PropType<Record<string, any>>;
    showInLegend: BooleanConstructor;
    sizeField: StringConstructor;
    stack: StringConstructor;
    tag: {};
    tagField: StringConstructor;
    type: PropType<SeriesType>;
    valueErrorBar: PropType<Record<string, any>>;
    valueField: StringConstructor;
    visible: BooleanConstructor;
    width: NumberConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:border"?: ((...args: any[]) => any) | undefined;
    "onUpdate:color"?: ((...args: any[]) => any) | undefined;
    "onUpdate:name"?: ((...args: any[]) => any) | undefined;
    "onUpdate:opacity"?: ((...args: any[]) => any) | undefined;
    "onUpdate:type"?: ((...args: any[]) => any) | undefined;
    "onUpdate:width"?: ((...args: any[]) => any) | undefined;
    "onUpdate:cornerRadius"?: ((...args: any[]) => any) | undefined;
    "onUpdate:dashStyle"?: ((...args: any[]) => any) | undefined;
    "onUpdate:visible"?: ((...args: any[]) => any) | undefined;
    "onUpdate:label"?: ((...args: any[]) => any) | undefined;
    "onUpdate:selectionMode"?: ((...args: any[]) => any) | undefined;
    "onUpdate:valueField"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoverStyle"?: ((...args: any[]) => any) | undefined;
    "onUpdate:selectionStyle"?: ((...args: any[]) => any) | undefined;
    "onUpdate:argumentField"?: ((...args: any[]) => any) | undefined;
    "onUpdate:ignoreEmptyPoints"?: ((...args: any[]) => any) | undefined;
    "onUpdate:aggregation"?: ((...args: any[]) => any) | undefined;
    "onUpdate:axis"?: ((...args: any[]) => any) | undefined;
    "onUpdate:barOverlapGroup"?: ((...args: any[]) => any) | undefined;
    "onUpdate:barPadding"?: ((...args: any[]) => any) | undefined;
    "onUpdate:barWidth"?: ((...args: any[]) => any) | undefined;
    "onUpdate:closeValueField"?: ((...args: any[]) => any) | undefined;
    "onUpdate:highValueField"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoverMode"?: ((...args: any[]) => any) | undefined;
    "onUpdate:innerColor"?: ((...args: any[]) => any) | undefined;
    "onUpdate:lowValueField"?: ((...args: any[]) => any) | undefined;
    "onUpdate:maxLabelCount"?: ((...args: any[]) => any) | undefined;
    "onUpdate:minBarSize"?: ((...args: any[]) => any) | undefined;
    "onUpdate:openValueField"?: ((...args: any[]) => any) | undefined;
    "onUpdate:pane"?: ((...args: any[]) => any) | undefined;
    "onUpdate:point"?: ((...args: any[]) => any) | undefined;
    "onUpdate:rangeValue1Field"?: ((...args: any[]) => any) | undefined;
    "onUpdate:rangeValue2Field"?: ((...args: any[]) => any) | undefined;
    "onUpdate:reduction"?: ((...args: any[]) => any) | undefined;
    "onUpdate:showInLegend"?: ((...args: any[]) => any) | undefined;
    "onUpdate:sizeField"?: ((...args: any[]) => any) | undefined;
    "onUpdate:stack"?: ((...args: any[]) => any) | undefined;
    "onUpdate:tagField"?: ((...args: any[]) => any) | undefined;
    "onUpdate:valueErrorBar"?: ((...args: any[]) => any) | undefined;
    "onUpdate:tag"?: ((...args: any[]) => any) | undefined;
}, {
    visible: boolean;
    ignoreEmptyPoints: boolean;
    showInLegend: boolean;
}>;
declare const DxSeriesBorder: import("vue").DefineComponent<{
    color: StringConstructor;
    dashStyle: PropType<DashStyle>;
    visible: BooleanConstructor;
    width: NumberConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:color": null;
    "update:dashStyle": null;
    "update:visible": null;
    "update:width": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    color: StringConstructor;
    dashStyle: PropType<DashStyle>;
    visible: BooleanConstructor;
    width: NumberConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:color"?: ((...args: any[]) => any) | undefined;
    "onUpdate:width"?: ((...args: any[]) => any) | undefined;
    "onUpdate:dashStyle"?: ((...args: any[]) => any) | undefined;
    "onUpdate:visible"?: ((...args: any[]) => any) | undefined;
}, {
    visible: boolean;
}>;
declare const DxSeriesTemplate: import("vue").DefineComponent<{
    customizeSeries: PropType<(seriesName: any) => ChartSeries>;
    nameField: StringConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:customizeSeries": null;
    "update:nameField": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    customizeSeries: PropType<(seriesName: any) => ChartSeries>;
    nameField: StringConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:customizeSeries"?: ((...args: any[]) => any) | undefined;
    "onUpdate:nameField"?: ((...args: any[]) => any) | undefined;
}, {}>;
declare const DxShutter: import("vue").DefineComponent<{
    color: StringConstructor;
    opacity: NumberConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:color": null;
    "update:opacity": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    color: StringConstructor;
    opacity: NumberConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:color"?: ((...args: any[]) => any) | undefined;
    "onUpdate:opacity"?: ((...args: any[]) => any) | undefined;
}, {}>;
declare const DxSize: import("vue").DefineComponent<{
    height: NumberConstructor;
    width: NumberConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:height": null;
    "update:width": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    height: NumberConstructor;
    width: NumberConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:height"?: ((...args: any[]) => any) | undefined;
    "onUpdate:width"?: ((...args: any[]) => any) | undefined;
}, {}>;
declare const DxSliderHandle: import("vue").DefineComponent<{
    color: StringConstructor;
    opacity: NumberConstructor;
    width: NumberConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:color": null;
    "update:opacity": null;
    "update:width": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    color: StringConstructor;
    opacity: NumberConstructor;
    width: NumberConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:color"?: ((...args: any[]) => any) | undefined;
    "onUpdate:opacity"?: ((...args: any[]) => any) | undefined;
    "onUpdate:width"?: ((...args: any[]) => any) | undefined;
}, {}>;
declare const DxSliderMarker: import("vue").DefineComponent<{
    color: StringConstructor;
    customizeText: PropType<(scaleValue: {
        value: Date | number | string;
        valueText: string;
    }) => string>;
    font: PropType<Record<string, any> | Font>;
    format: PropType<string | Record<string, any> | import("devextreme/common/core/localization").FormatObject | ((value: number | Date) => string) | ((value: Date) => string) | ((value: number) => string) | Intl.DateTimeFormatOptions | Intl.NumberFormatOptions | ((value: number | Date) => string) | undefined>;
    invalidRangeColor: StringConstructor;
    paddingLeftRight: NumberConstructor;
    paddingTopBottom: NumberConstructor;
    placeholderHeight: NumberConstructor;
    visible: BooleanConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:color": null;
    "update:customizeText": null;
    "update:font": null;
    "update:format": null;
    "update:invalidRangeColor": null;
    "update:paddingLeftRight": null;
    "update:paddingTopBottom": null;
    "update:placeholderHeight": null;
    "update:visible": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    color: StringConstructor;
    customizeText: PropType<(scaleValue: {
        value: Date | number | string;
        valueText: string;
    }) => string>;
    font: PropType<Record<string, any> | Font>;
    format: PropType<string | Record<string, any> | import("devextreme/common/core/localization").FormatObject | ((value: number | Date) => string) | ((value: Date) => string) | ((value: number) => string) | Intl.DateTimeFormatOptions | Intl.NumberFormatOptions | ((value: number | Date) => string) | undefined>;
    invalidRangeColor: StringConstructor;
    paddingLeftRight: NumberConstructor;
    paddingTopBottom: NumberConstructor;
    placeholderHeight: NumberConstructor;
    visible: BooleanConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:color"?: ((...args: any[]) => any) | undefined;
    "onUpdate:font"?: ((...args: any[]) => any) | undefined;
    "onUpdate:paddingLeftRight"?: ((...args: any[]) => any) | undefined;
    "onUpdate:paddingTopBottom"?: ((...args: any[]) => any) | undefined;
    "onUpdate:visible"?: ((...args: any[]) => any) | undefined;
    "onUpdate:customizeText"?: ((...args: any[]) => any) | undefined;
    "onUpdate:format"?: ((...args: any[]) => any) | undefined;
    "onUpdate:placeholderHeight"?: ((...args: any[]) => any) | undefined;
    "onUpdate:invalidRangeColor"?: ((...args: any[]) => any) | undefined;
}, {
    visible: boolean;
}>;
declare const DxSubtitle: import("vue").DefineComponent<{
    font: PropType<Record<string, any> | Font>;
    offset: NumberConstructor;
    text: StringConstructor;
    textOverflow: PropType<TextOverflow>;
    wordWrap: PropType<WordWrap>;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:font": null;
    "update:offset": null;
    "update:text": null;
    "update:textOverflow": null;
    "update:wordWrap": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    font: PropType<Record<string, any> | Font>;
    offset: NumberConstructor;
    text: StringConstructor;
    textOverflow: PropType<TextOverflow>;
    wordWrap: PropType<WordWrap>;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:font"?: ((...args: any[]) => any) | undefined;
    "onUpdate:text"?: ((...args: any[]) => any) | undefined;
    "onUpdate:textOverflow"?: ((...args: any[]) => any) | undefined;
    "onUpdate:wordWrap"?: ((...args: any[]) => any) | undefined;
    "onUpdate:offset"?: ((...args: any[]) => any) | undefined;
}, {}>;
declare const DxTick: import("vue").DefineComponent<{
    color: StringConstructor;
    opacity: NumberConstructor;
    width: NumberConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:color": null;
    "update:opacity": null;
    "update:width": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    color: StringConstructor;
    opacity: NumberConstructor;
    width: NumberConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:color"?: ((...args: any[]) => any) | undefined;
    "onUpdate:opacity"?: ((...args: any[]) => any) | undefined;
    "onUpdate:width"?: ((...args: any[]) => any) | undefined;
}, {}>;
declare const DxTickInterval: import("vue").DefineComponent<{
    days: NumberConstructor;
    hours: NumberConstructor;
    milliseconds: NumberConstructor;
    minutes: NumberConstructor;
    months: NumberConstructor;
    quarters: NumberConstructor;
    seconds: NumberConstructor;
    weeks: NumberConstructor;
    years: NumberConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:days": null;
    "update:hours": null;
    "update:milliseconds": null;
    "update:minutes": null;
    "update:months": null;
    "update:quarters": null;
    "update:seconds": null;
    "update:weeks": null;
    "update:years": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    days: NumberConstructor;
    hours: NumberConstructor;
    milliseconds: NumberConstructor;
    minutes: NumberConstructor;
    months: NumberConstructor;
    quarters: NumberConstructor;
    seconds: NumberConstructor;
    weeks: NumberConstructor;
    years: NumberConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:days"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hours"?: ((...args: any[]) => any) | undefined;
    "onUpdate:milliseconds"?: ((...args: any[]) => any) | undefined;
    "onUpdate:minutes"?: ((...args: any[]) => any) | undefined;
    "onUpdate:months"?: ((...args: any[]) => any) | undefined;
    "onUpdate:quarters"?: ((...args: any[]) => any) | undefined;
    "onUpdate:seconds"?: ((...args: any[]) => any) | undefined;
    "onUpdate:weeks"?: ((...args: any[]) => any) | undefined;
    "onUpdate:years"?: ((...args: any[]) => any) | undefined;
}, {}>;
declare const DxTitle: import("vue").DefineComponent<{
    font: PropType<Record<string, any> | Font>;
    horizontalAlignment: PropType<HorizontalAlignment>;
    margin: PropType<number | Record<string, any>>;
    placeholderSize: NumberConstructor;
    subtitle: PropType<string | Record<string, any>>;
    text: StringConstructor;
    textOverflow: PropType<TextOverflow>;
    verticalAlignment: PropType<VerticalEdge>;
    wordWrap: PropType<WordWrap>;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:font": null;
    "update:horizontalAlignment": null;
    "update:margin": null;
    "update:placeholderSize": null;
    "update:subtitle": null;
    "update:text": null;
    "update:textOverflow": null;
    "update:verticalAlignment": null;
    "update:wordWrap": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    font: PropType<Record<string, any> | Font>;
    horizontalAlignment: PropType<HorizontalAlignment>;
    margin: PropType<number | Record<string, any>>;
    placeholderSize: NumberConstructor;
    subtitle: PropType<string | Record<string, any>>;
    text: StringConstructor;
    textOverflow: PropType<TextOverflow>;
    verticalAlignment: PropType<VerticalEdge>;
    wordWrap: PropType<WordWrap>;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:font"?: ((...args: any[]) => any) | undefined;
    "onUpdate:text"?: ((...args: any[]) => any) | undefined;
    "onUpdate:textOverflow"?: ((...args: any[]) => any) | undefined;
    "onUpdate:wordWrap"?: ((...args: any[]) => any) | undefined;
    "onUpdate:horizontalAlignment"?: ((...args: any[]) => any) | undefined;
    "onUpdate:margin"?: ((...args: any[]) => any) | undefined;
    "onUpdate:verticalAlignment"?: ((...args: any[]) => any) | undefined;
    "onUpdate:placeholderSize"?: ((...args: any[]) => any) | undefined;
    "onUpdate:subtitle"?: ((...args: any[]) => any) | undefined;
}, {}>;
declare const DxUrl: import("vue").DefineComponent<{
    rangeMaxPoint: StringConstructor;
    rangeMinPoint: StringConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:rangeMaxPoint": null;
    "update:rangeMinPoint": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    rangeMaxPoint: StringConstructor;
    rangeMinPoint: StringConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:rangeMaxPoint"?: ((...args: any[]) => any) | undefined;
    "onUpdate:rangeMinPoint"?: ((...args: any[]) => any) | undefined;
}, {}>;
declare const DxValue: import("vue").DefineComponent<{
    endValue: (DateConstructor | NumberConstructor | StringConstructor)[];
    length: PropType<number | Record<string, any> | TimeInterval>;
    startValue: (DateConstructor | NumberConstructor | StringConstructor)[];
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:endValue": null;
    "update:length": null;
    "update:startValue": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    endValue: (DateConstructor | NumberConstructor | StringConstructor)[];
    length: PropType<number | Record<string, any> | TimeInterval>;
    startValue: (DateConstructor | NumberConstructor | StringConstructor)[];
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:endValue"?: ((...args: any[]) => any) | undefined;
    "onUpdate:startValue"?: ((...args: any[]) => any) | undefined;
    "onUpdate:length"?: ((...args: any[]) => any) | undefined;
}, {}>;
declare const DxValueAxis: import("vue").DefineComponent<{
    inverted: BooleanConstructor;
    logarithmBase: NumberConstructor;
    max: NumberConstructor;
    min: NumberConstructor;
    type: PropType<ChartAxisScale>;
    valueType: PropType<ChartsDataType>;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:inverted": null;
    "update:logarithmBase": null;
    "update:max": null;
    "update:min": null;
    "update:type": null;
    "update:valueType": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    inverted: BooleanConstructor;
    logarithmBase: NumberConstructor;
    max: NumberConstructor;
    min: NumberConstructor;
    type: PropType<ChartAxisScale>;
    valueType: PropType<ChartsDataType>;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:type"?: ((...args: any[]) => any) | undefined;
    "onUpdate:max"?: ((...args: any[]) => any) | undefined;
    "onUpdate:min"?: ((...args: any[]) => any) | undefined;
    "onUpdate:logarithmBase"?: ((...args: any[]) => any) | undefined;
    "onUpdate:valueType"?: ((...args: any[]) => any) | undefined;
    "onUpdate:inverted"?: ((...args: any[]) => any) | undefined;
}, {
    inverted: boolean;
}>;
declare const DxValueErrorBar: import("vue").DefineComponent<{
    color: StringConstructor;
    displayMode: PropType<ValueErrorBarDisplayMode>;
    edgeLength: NumberConstructor;
    highValueField: StringConstructor;
    lineWidth: NumberConstructor;
    lowValueField: StringConstructor;
    opacity: NumberConstructor;
    type: PropType<ValueErrorBarType>;
    value: NumberConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:color": null;
    "update:displayMode": null;
    "update:edgeLength": null;
    "update:highValueField": null;
    "update:lineWidth": null;
    "update:lowValueField": null;
    "update:opacity": null;
    "update:type": null;
    "update:value": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    color: StringConstructor;
    displayMode: PropType<ValueErrorBarDisplayMode>;
    edgeLength: NumberConstructor;
    highValueField: StringConstructor;
    lineWidth: NumberConstructor;
    lowValueField: StringConstructor;
    opacity: NumberConstructor;
    type: PropType<ValueErrorBarType>;
    value: NumberConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:color"?: ((...args: any[]) => any) | undefined;
    "onUpdate:opacity"?: ((...args: any[]) => any) | undefined;
    "onUpdate:type"?: ((...args: any[]) => any) | undefined;
    "onUpdate:value"?: ((...args: any[]) => any) | undefined;
    "onUpdate:displayMode"?: ((...args: any[]) => any) | undefined;
    "onUpdate:lineWidth"?: ((...args: any[]) => any) | undefined;
    "onUpdate:highValueField"?: ((...args: any[]) => any) | undefined;
    "onUpdate:lowValueField"?: ((...args: any[]) => any) | undefined;
    "onUpdate:edgeLength"?: ((...args: any[]) => any) | undefined;
}, {}>;
declare const DxWidth: import("vue").DefineComponent<{
    rangeMaxPoint: NumberConstructor;
    rangeMinPoint: NumberConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:rangeMaxPoint": null;
    "update:rangeMinPoint": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    rangeMaxPoint: NumberConstructor;
    rangeMinPoint: NumberConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:rangeMaxPoint"?: ((...args: any[]) => any) | undefined;
    "onUpdate:rangeMinPoint"?: ((...args: any[]) => any) | undefined;
}, {}>;
export default DxRangeSelector;
export { DxRangeSelector, DxAggregation, DxAggregationInterval, DxArgumentFormat, DxBackground, DxBackgroundImage, DxBehavior, DxBorder, DxBreak, DxBreakStyle, DxChart, DxColor, DxCommonSeriesSettings, DxCommonSeriesSettingsHoverStyle, DxCommonSeriesSettingsLabel, DxCommonSeriesSettingsSelectionStyle, DxConnector, DxDataPrepareSettings, DxExport, DxFont, DxFormat, DxHatching, DxHeight, DxHoverStyle, DxImage, DxIndent, DxLabel, DxLength, DxLoadingIndicator, DxMargin, DxMarker, DxMarkerLabel, DxMaxRange, DxMinorTick, DxMinorTickInterval, DxMinRange, DxPoint, DxPointBorder, DxPointHoverStyle, DxPointImage, DxPointSelectionStyle, DxReduction, DxScale, DxScaleLabel, DxSelectionStyle, DxSeries, DxSeriesBorder, DxSeriesTemplate, DxShutter, DxSize, DxSliderHandle, DxSliderMarker, DxSubtitle, DxTick, DxTickInterval, DxTitle, DxUrl, DxValue, DxValueAxis, DxValueErrorBar, DxWidth };
import type * as DxRangeSelectorTypes from "devextreme/viz/range_selector_types";
export { DxRangeSelectorTypes };
