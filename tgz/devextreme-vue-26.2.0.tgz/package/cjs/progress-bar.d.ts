/*!
 * devextreme-vue
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

import { PropType } from "vue";
import ProgressBar, { Properties } from "devextreme/ui/progress_bar";
import { CompleteEvent, ContentReadyEvent, DisposingEvent, InitializedEvent, OptionChangedEvent, ValueChangedEvent } from "devextreme/ui/progress_bar";
import { ValidationMessageMode, Position, ValidationStatus } from "devextreme/common";
type AccessibleOptions = Pick<Properties, "disabled" | "elementAttr" | "height" | "hint" | "hoverStateEnabled" | "isDirty" | "isValid" | "max" | "min" | "onComplete" | "onContentReady" | "onDisposing" | "onInitialized" | "onOptionChanged" | "onValueChanged" | "readOnly" | "rtlEnabled" | "showStatus" | "statusFormat" | "validationError" | "validationErrors" | "validationMessageMode" | "validationMessagePosition" | "validationStatus" | "value" | "visible" | "width">;
interface DxProgressBar extends AccessibleOptions {
    readonly instance?: ProgressBar;
}
declare const DxProgressBar: import("vue").DefineComponent<{
    disabled: BooleanConstructor;
    elementAttr: PropType<Record<string, any>>;
    height: (NumberConstructor | StringConstructor)[];
    hint: StringConstructor;
    hoverStateEnabled: BooleanConstructor;
    isDirty: BooleanConstructor;
    isValid: BooleanConstructor;
    max: NumberConstructor;
    min: NumberConstructor;
    onComplete: PropType<(e: CompleteEvent) => void>;
    onContentReady: PropType<(e: ContentReadyEvent) => void>;
    onDisposing: PropType<(e: DisposingEvent) => void>;
    onInitialized: PropType<(e: InitializedEvent) => void>;
    onOptionChanged: PropType<(e: OptionChangedEvent) => void>;
    onValueChanged: PropType<(e: ValueChangedEvent) => void>;
    readOnly: BooleanConstructor;
    rtlEnabled: BooleanConstructor;
    showStatus: BooleanConstructor;
    statusFormat: PropType<string | ((ratio: number, value: number) => string)>;
    validationError: {};
    validationErrors: PropType<any[] | null>;
    validationMessageMode: PropType<ValidationMessageMode>;
    validationMessagePosition: PropType<Position>;
    validationStatus: PropType<ValidationStatus>;
    value: {};
    visible: BooleanConstructor;
    width: (NumberConstructor | StringConstructor)[];
}, unknown, unknown, {
    instance(): ProgressBar;
}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:disabled": null;
    "update:elementAttr": null;
    "update:height": null;
    "update:hint": null;
    "update:hoverStateEnabled": null;
    "update:isDirty": null;
    "update:isValid": null;
    "update:max": null;
    "update:min": null;
    "update:onComplete": null;
    "update:onContentReady": null;
    "update:onDisposing": null;
    "update:onInitialized": null;
    "update:onOptionChanged": null;
    "update:onValueChanged": null;
    "update:readOnly": null;
    "update:rtlEnabled": null;
    "update:showStatus": null;
    "update:statusFormat": null;
    "update:validationError": null;
    "update:validationErrors": null;
    "update:validationMessageMode": null;
    "update:validationMessagePosition": null;
    "update:validationStatus": null;
    "update:value": null;
    "update:visible": null;
    "update:width": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    disabled: BooleanConstructor;
    elementAttr: PropType<Record<string, any>>;
    height: (NumberConstructor | StringConstructor)[];
    hint: StringConstructor;
    hoverStateEnabled: BooleanConstructor;
    isDirty: BooleanConstructor;
    isValid: BooleanConstructor;
    max: NumberConstructor;
    min: NumberConstructor;
    onComplete: PropType<(e: CompleteEvent) => void>;
    onContentReady: PropType<(e: ContentReadyEvent) => void>;
    onDisposing: PropType<(e: DisposingEvent) => void>;
    onInitialized: PropType<(e: InitializedEvent) => void>;
    onOptionChanged: PropType<(e: OptionChangedEvent) => void>;
    onValueChanged: PropType<(e: ValueChangedEvent) => void>;
    readOnly: BooleanConstructor;
    rtlEnabled: BooleanConstructor;
    showStatus: BooleanConstructor;
    statusFormat: PropType<string | ((ratio: number, value: number) => string)>;
    validationError: {};
    validationErrors: PropType<any[] | null>;
    validationMessageMode: PropType<ValidationMessageMode>;
    validationMessagePosition: PropType<Position>;
    validationStatus: PropType<ValidationStatus>;
    value: {};
    visible: BooleanConstructor;
    width: (NumberConstructor | StringConstructor)[];
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:disabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:elementAttr"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onDisposing"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onInitialized"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onOptionChanged"?: ((...args: any[]) => any) | undefined;
    "onUpdate:rtlEnabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:height"?: ((...args: any[]) => any) | undefined;
    "onUpdate:width"?: ((...args: any[]) => any) | undefined;
    "onUpdate:visible"?: ((...args: any[]) => any) | undefined;
    "onUpdate:max"?: ((...args: any[]) => any) | undefined;
    "onUpdate:min"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoverStateEnabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onContentReady"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hint"?: ((...args: any[]) => any) | undefined;
    "onUpdate:isDirty"?: ((...args: any[]) => any) | undefined;
    "onUpdate:isValid"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onValueChanged"?: ((...args: any[]) => any) | undefined;
    "onUpdate:readOnly"?: ((...args: any[]) => any) | undefined;
    "onUpdate:validationError"?: ((...args: any[]) => any) | undefined;
    "onUpdate:validationErrors"?: ((...args: any[]) => any) | undefined;
    "onUpdate:validationMessageMode"?: ((...args: any[]) => any) | undefined;
    "onUpdate:validationMessagePosition"?: ((...args: any[]) => any) | undefined;
    "onUpdate:validationStatus"?: ((...args: any[]) => any) | undefined;
    "onUpdate:value"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onComplete"?: ((...args: any[]) => any) | undefined;
    "onUpdate:showStatus"?: ((...args: any[]) => any) | undefined;
    "onUpdate:statusFormat"?: ((...args: any[]) => any) | undefined;
}, {
    disabled: boolean;
    rtlEnabled: boolean;
    visible: boolean;
    hoverStateEnabled: boolean;
    isDirty: boolean;
    isValid: boolean;
    readOnly: boolean;
    showStatus: boolean;
}>;
export default DxProgressBar;
export { DxProgressBar };
import type * as DxProgressBarTypes from "devextreme/ui/progress_bar_types";
export { DxProgressBarTypes };
