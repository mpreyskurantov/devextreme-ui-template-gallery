/*!
 * devextreme-vue
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

import { PropType } from "vue";
import ScrollView, { Properties } from "devextreme/ui/scroll_view";
import { ScrollDirection } from "devextreme/common";
import { DisposingEvent, InitializedEvent, OptionChangedEvent, PullDownEvent, ReachBottomEvent, ScrollEvent, UpdatedEvent } from "devextreme/ui/scroll_view";
type AccessibleOptions = Pick<Properties, "bounceEnabled" | "direction" | "disabled" | "elementAttr" | "height" | "onDisposing" | "onInitialized" | "onOptionChanged" | "onPullDown" | "onReachBottom" | "onScroll" | "onUpdated" | "pulledDownText" | "pullingDownText" | "reachBottomText" | "refreshingText" | "rtlEnabled" | "scrollByContent" | "scrollByThumb" | "showScrollbar" | "useNative" | "width">;
interface DxScrollView extends AccessibleOptions {
    readonly instance?: ScrollView;
}
declare const DxScrollView: import("vue").DefineComponent<{
    bounceEnabled: BooleanConstructor;
    direction: PropType<ScrollDirection>;
    disabled: BooleanConstructor;
    elementAttr: PropType<Record<string, any>>;
    height: (NumberConstructor | StringConstructor)[];
    onDisposing: PropType<(e: DisposingEvent) => void>;
    onInitialized: PropType<(e: InitializedEvent) => void>;
    onOptionChanged: PropType<(e: OptionChangedEvent) => void>;
    onPullDown: PropType<(e: PullDownEvent) => void>;
    onReachBottom: PropType<(e: ReachBottomEvent) => void>;
    onScroll: PropType<(e: ScrollEvent) => void>;
    onUpdated: PropType<(e: UpdatedEvent) => void>;
    pulledDownText: StringConstructor;
    pullingDownText: StringConstructor;
    reachBottomText: StringConstructor;
    refreshingText: StringConstructor;
    rtlEnabled: BooleanConstructor;
    scrollByContent: BooleanConstructor;
    scrollByThumb: BooleanConstructor;
    showScrollbar: PropType<"never" | "always" | "onHover" | "onScroll">;
    useNative: BooleanConstructor;
    width: (NumberConstructor | StringConstructor)[];
}, unknown, unknown, {
    instance(): ScrollView;
}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:bounceEnabled": null;
    "update:direction": null;
    "update:disabled": null;
    "update:elementAttr": null;
    "update:height": null;
    "update:onDisposing": null;
    "update:onInitialized": null;
    "update:onOptionChanged": null;
    "update:onPullDown": null;
    "update:onReachBottom": null;
    "update:onScroll": null;
    "update:onUpdated": null;
    "update:pulledDownText": null;
    "update:pullingDownText": null;
    "update:reachBottomText": null;
    "update:refreshingText": null;
    "update:rtlEnabled": null;
    "update:scrollByContent": null;
    "update:scrollByThumb": null;
    "update:showScrollbar": null;
    "update:useNative": null;
    "update:width": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    bounceEnabled: BooleanConstructor;
    direction: PropType<ScrollDirection>;
    disabled: BooleanConstructor;
    elementAttr: PropType<Record<string, any>>;
    height: (NumberConstructor | StringConstructor)[];
    onDisposing: PropType<(e: DisposingEvent) => void>;
    onInitialized: PropType<(e: InitializedEvent) => void>;
    onOptionChanged: PropType<(e: OptionChangedEvent) => void>;
    onPullDown: PropType<(e: PullDownEvent) => void>;
    onReachBottom: PropType<(e: ReachBottomEvent) => void>;
    onScroll: PropType<(e: ScrollEvent) => void>;
    onUpdated: PropType<(e: UpdatedEvent) => void>;
    pulledDownText: StringConstructor;
    pullingDownText: StringConstructor;
    reachBottomText: StringConstructor;
    refreshingText: StringConstructor;
    rtlEnabled: BooleanConstructor;
    scrollByContent: BooleanConstructor;
    scrollByThumb: BooleanConstructor;
    showScrollbar: PropType<"never" | "always" | "onHover" | "onScroll">;
    useNative: BooleanConstructor;
    width: (NumberConstructor | StringConstructor)[];
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:disabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:elementAttr"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onDisposing"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onInitialized"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onOptionChanged"?: ((...args: any[]) => any) | undefined;
    "onUpdate:rtlEnabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:height"?: ((...args: any[]) => any) | undefined;
    "onUpdate:width"?: ((...args: any[]) => any) | undefined;
    "onUpdate:direction"?: ((...args: any[]) => any) | undefined;
    "onUpdate:scrollByContent"?: ((...args: any[]) => any) | undefined;
    "onUpdate:scrollByThumb"?: ((...args: any[]) => any) | undefined;
    "onUpdate:showScrollbar"?: ((...args: any[]) => any) | undefined;
    "onUpdate:useNative"?: ((...args: any[]) => any) | undefined;
    "onUpdate:bounceEnabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onPullDown"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onReachBottom"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onScroll"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onUpdated"?: ((...args: any[]) => any) | undefined;
    "onUpdate:pulledDownText"?: ((...args: any[]) => any) | undefined;
    "onUpdate:pullingDownText"?: ((...args: any[]) => any) | undefined;
    "onUpdate:reachBottomText"?: ((...args: any[]) => any) | undefined;
    "onUpdate:refreshingText"?: ((...args: any[]) => any) | undefined;
}, {
    disabled: boolean;
    rtlEnabled: boolean;
    scrollByContent: boolean;
    scrollByThumb: boolean;
    useNative: boolean;
    bounceEnabled: boolean;
}>;
export default DxScrollView;
export { DxScrollView };
import type * as DxScrollViewTypes from "devextreme/ui/scroll_view_types";
export { DxScrollViewTypes };
