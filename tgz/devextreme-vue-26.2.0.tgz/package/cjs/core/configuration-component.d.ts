/*!
 * devextreme-vue
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

import { ComponentPublicInstance } from 'vue';
import Configuration, { ExpectedChild } from './configuration';
interface IConfigurationOwner {
    $_expectedChildren: Record<string, ExpectedChild>;
}
interface IConfigurationComponent extends IConfigurationOwner, ComponentPublicInstance {
    $_optionName: string;
    $_isCollectionItem: boolean;
    $_predefinedProps: Record<string, any>;
}
interface IConfigurable extends IConfigurationOwner {
    $_config: Configuration;
    $_innerChanges: any;
}
interface IComponentInfo {
    optionPath: string;
    isCollection: boolean;
    removed?: boolean;
}
declare function getConfig(vueInstance: Pick<ComponentPublicInstance, '$'>): Configuration | undefined;
declare function getInnerChanges(vueInstance: Pick<ComponentPublicInstance, '$'>): any;
declare function initOptionChangedFunc(config: any, props: any, vueInstance: Pick<ComponentPublicInstance, '$' | '$props' | '$emit' | '$options'>, innerChanges: any): void;
declare function initDxConfiguration(): import("vue").DefineComponent<{}, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{}>>, {}>;
export { initDxConfiguration, IComponentInfo, IConfigurable, IConfigurationComponent, initOptionChangedFunc, getConfig, getInnerChanges, };
