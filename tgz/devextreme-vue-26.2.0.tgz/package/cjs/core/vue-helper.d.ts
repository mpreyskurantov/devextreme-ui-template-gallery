/*!
 * devextreme-vue
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

import { ComponentPublicInstance, Slot, Slots, VNode, VNodeProps } from 'vue';
import { IBaseComponent } from './component';
import { IConfigurationComponent } from './configuration-component';
export declare const VMODEL_NAME = "modelValue";
export declare function getChildren(component: IBaseComponent): any;
export declare function getComponentInfo(component: any): IConfigurationComponent;
export declare function getNormalizedProps(props: VNodeProps): VNodeProps;
export declare function configurationChildren(component: any): VNode[];
export declare function configurationDefaultTemplate(node: any): Slot | undefined;
export declare function configurationTemplate(node: VNode): Slot | undefined;
export declare function declaredTemplates(component: any): Slots;
export declare function defaultSlots(component: ComponentPublicInstance): VNode[];
export declare function mount(options: any, parent: any, el: any): ComponentPublicInstance<{}, {}, {}, {}, {}, {}, {}, {}, false, import("vue").ComponentOptionsBase<any, any, any, any, any, any, any, any, any, {}, {}, string>, {}>;
export declare function getComponentProps(component: ComponentPublicInstance): VNodeProps;
export declare function getNodeOptions(component: Pick<ComponentPublicInstance, '$'>): VNode<import("vue").RendererNode, import("vue").RendererElement, {
    [key: string]: any;
}> | Pick<ComponentPublicInstance<{}, {}, {}, {}, {}, {}, {}, {}, false, import("vue").ComponentOptionsBase<any, any, any, any, any, any, any, any, any, {}, {}, string>, {}>, "$">;
export declare function getNodeTypeOfComponent(component: Pick<ComponentPublicInstance, '$'>): any;
export declare function getVModelValue(options: Record<string, any>): any;
export declare function setVModel(config: any): void;
export declare function getConfigurationOptions(node: VNode): any;
