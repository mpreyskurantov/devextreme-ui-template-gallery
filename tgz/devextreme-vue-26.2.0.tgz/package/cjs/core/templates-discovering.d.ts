/*!
 * devextreme-vue
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

import { ComponentPublicInstance, Slot } from 'vue';
interface IEventBusHolder {
    eventBus: {
        fire: () => void;
        add: (handler: () => void) => void;
        remove: (handler: () => void) => void;
    };
}
declare function discover(component: ComponentPublicInstance): Record<string, Slot>;
declare function mountTemplate(getSlot: () => Slot, parent: ComponentPublicInstance, data: any, name: string, placeholder: Element): ComponentPublicInstance;
export { mountTemplate, discover, IEventBusHolder, };
