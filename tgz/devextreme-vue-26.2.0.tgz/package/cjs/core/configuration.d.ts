/*!
 * devextreme-vue
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

import { ComponentPublicInstance as IVue } from 'vue';
import { IComponentInfo } from './configuration-component';
type UpdateFunc = (name: string, value: any) => void;
type EmitOptionChangedFunc = (name: string, value: any) => void;
interface ExpectedChild {
    isCollectionItem: boolean;
    optionName: string;
}
interface IOptionChangedArgs {
    fullName: string;
    value: any;
    previousValue: any;
    component: any;
}
declare class Configuration {
    private readonly _name;
    private readonly _isCollectionItem;
    private readonly _collectionItemIndex;
    private readonly _initialValues;
    private readonly _expectedChildren;
    private readonly _updateFunc;
    private readonly _ownerConfig;
    private _nestedConfigurations;
    private _prevNestedConfigOptions;
    private _emitOptionChanged;
    private _componentChanges;
    private _options;
    constructor(updateFunc: UpdateFunc, name: string | null, initialValues: Record<string, any>, expectedChildren?: Record<string, ExpectedChild>, isCollectionItem?: boolean, collectionItemIndex?: number, ownerConfig?: Pick<Configuration, 'fullPath'> | undefined);
    get name(): string | null;
    get fullName(): string | null;
    get componentsCountChanged(): IComponentInfo[];
    cleanComponentsCountChanged(): void;
    get fullPath(): string | null;
    get ownerConfig(): Pick<Configuration, 'fullPath'> | undefined;
    get options(): string[];
    get initialValues(): Record<string, any>;
    get expectedChildren(): Record<string, ExpectedChild>;
    get nested(): Configuration[];
    get prevNestedOptions(): any;
    get collectionItemIndex(): number | undefined;
    get isCollectionItem(): boolean;
    get updateFunc(): UpdateFunc;
    init(options: string[]): void;
    set emitOptionChanged(handler: EmitOptionChangedFunc);
    setPrevNestedOptions(value: any): void;
    onOptionChanged(args: IOptionChangedArgs): void;
    cleanNested(): void;
    createNested(name: string, initialValues: Record<string, any>, isCollectionItem?: boolean, expectedChildren?: Record<string, ExpectedChild>): Configuration;
    updateValue(nestedName: string, value: any): void;
    getNestedOptionValues(): Record<string, any> | undefined;
    getOptionsToWatch(): string[];
    private _onOptionChanged;
    private _getNestedConfig;
    private _tryEmitOptionChanged;
}
declare function bindOptionWatchers(config: Configuration, vueInstance: Pick<IVue, '$watch'>, innerChanges: Record<string, any>): void;
declare function setEmitOptionChangedFunc(config: Configuration, vueInstance: Pick<IVue, '$' | '$props' | '$emit' | '$options'>, innerChanges: Record<string, any>): void;
export default Configuration;
export { bindOptionWatchers, setEmitOptionChangedFunc, UpdateFunc, ExpectedChild, IOptionChangedArgs, };
