/*!
 * devextreme-vue
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

import { VNode } from 'vue';
import Configuration from './configuration';
declare function pullAllChildren(directChildren: VNode[], allChildren: VNode[], config: Configuration): void;
export declare function isFragment(node: any): boolean;
export declare function pullConfigComponents(children: VNode[], nodes: VNode[], ownerConfig: Configuration): void;
export { pullAllChildren, };
