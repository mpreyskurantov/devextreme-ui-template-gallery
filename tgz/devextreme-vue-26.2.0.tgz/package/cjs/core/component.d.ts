/*!
 * devextreme-vue
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

import { ComponentPublicInstance, VNode } from 'vue';
import { IConfigurable } from './configuration-component';
import { IEventBusHolder } from './templates-discovering';
import { TemplatesManager } from './templates-manager';
interface IWidgetComponent extends IConfigurable {
    $_instance: any;
    $_WidgetClass: any;
    $_pendingOptions: Record<string, any>;
    $_templatesManager: TemplatesManager;
}
export interface IBaseComponent extends ComponentPublicInstance, IWidgetComponent, IEventBusHolder {
    $_isExtension: boolean;
    $_applyConfigurationChanges: () => void;
    $_createWidget: (element: any) => void;
    $_getIntegrationOptions: () => void;
    $_getExtraIntegrationOptions: () => void;
    $_getWatchMethod: () => void;
    $_createEmitters: () => void;
    $_processChildren: () => void;
    $_getTemplates: () => object;
    $_hasAsyncTemplate: boolean;
}
declare function initBaseComponent(): import("vue").DefineComponent<{}, {}, {
    eventBus: import("devextreme/core/utils/callbacks").Callback<any[], any>;
    prevClassAttr: string;
}, {}, {
    $_syncElementClassesWithClassAttr(): void;
    $_applyConfigurationChanges(): void;
    $_createWidget(element: any): void;
    $_getIntegrationOptions(): object;
    $_getWatchMethod(): (valueGetter: () => any, valueChangeCallback: (value: any) => void, options: {
        deep: boolean;
        skipImmediate: boolean;
    }) => any;
    $_getExtraIntegrationOptions(): object;
    $_processChildren(_children: VNode[]): void;
    $_createEmitters(instance: any): void;
}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{}>>, {}>;
declare function initDxComponent(): import("vue").DefineComponent<{}, {}, {}, {}, {
    $_getExtraIntegrationOptions(): object;
    $_processChildren(children: VNode[]): void;
}, import("vue").ComponentOptionsMixin, import("vue").DefineComponent<{}, {}, {
    eventBus: import("devextreme/core/utils/callbacks").Callback<any[], any>;
    prevClassAttr: string;
}, {}, {
    $_syncElementClassesWithClassAttr(): void;
    $_applyConfigurationChanges(): void;
    $_createWidget(element: any): void;
    $_getIntegrationOptions(): object;
    $_getWatchMethod(): (valueGetter: () => any, valueChangeCallback: (value: any) => void, options: {
        deep: boolean;
        skipImmediate: boolean;
    }) => any;
    $_getExtraIntegrationOptions(): object;
    $_processChildren(_children: VNode<import("vue").RendererNode, import("vue").RendererElement, {
        [key: string]: any;
    }>[]): void;
    $_createEmitters(instance: any): void;
}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{}>>, {}>, {}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{}>>, {}>;
export { initDxComponent, initBaseComponent, IWidgetComponent };
