/*!
 * devextreme-vue
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

import { ComponentPublicInstance } from 'vue';
declare class TemplatesManager {
    private readonly _component;
    private _slots;
    private _templates;
    private _isDirty;
    constructor(component: ComponentPublicInstance);
    discover(): void;
    get templates(): Record<string, object>;
    get isDirty(): boolean;
    resetDirtyFlag(): void;
    private _prepareTemplates;
    private createDxTemplate;
}
export { TemplatesManager };
