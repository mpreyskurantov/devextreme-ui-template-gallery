/*!
 * devextreme-vue
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

import { PropType } from "vue";
import Drawer, { Properties } from "devextreme/ui/drawer";
import { event } from "devextreme/events/events.types";
import { DisposingEvent, InitializedEvent, OptionChangedEvent, OpenedStateMode, PanelLocation, RevealMode } from "devextreme/ui/drawer";
type AccessibleOptions = Pick<Properties, "activeStateEnabled" | "animationDuration" | "animationEnabled" | "closeOnOutsideClick" | "disabled" | "elementAttr" | "height" | "hint" | "hoverStateEnabled" | "maxSize" | "minSize" | "onDisposing" | "onInitialized" | "onOptionChanged" | "opened" | "openedStateMode" | "position" | "revealMode" | "rtlEnabled" | "shading" | "template" | "visible" | "width">;
interface DxDrawer extends AccessibleOptions {
    readonly instance?: Drawer;
}
declare const DxDrawer: import("vue").DefineComponent<{
    activeStateEnabled: BooleanConstructor;
    animationDuration: NumberConstructor;
    animationEnabled: BooleanConstructor;
    closeOnOutsideClick: PropType<boolean | ((event: event) => boolean)>;
    disabled: BooleanConstructor;
    elementAttr: PropType<Record<string, any>>;
    height: (NumberConstructor | StringConstructor)[];
    hint: StringConstructor;
    hoverStateEnabled: BooleanConstructor;
    maxSize: PropType<number | null>;
    minSize: PropType<number | null>;
    onDisposing: PropType<(e: DisposingEvent) => void>;
    onInitialized: PropType<(e: InitializedEvent) => void>;
    onOptionChanged: PropType<(e: OptionChangedEvent) => void>;
    opened: BooleanConstructor;
    openedStateMode: PropType<OpenedStateMode>;
    position: PropType<PanelLocation>;
    revealMode: PropType<RevealMode>;
    rtlEnabled: BooleanConstructor;
    shading: BooleanConstructor;
    template: {};
    visible: BooleanConstructor;
    width: (NumberConstructor | StringConstructor)[];
}, unknown, unknown, {
    instance(): Drawer;
}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:activeStateEnabled": null;
    "update:animationDuration": null;
    "update:animationEnabled": null;
    "update:closeOnOutsideClick": null;
    "update:disabled": null;
    "update:elementAttr": null;
    "update:height": null;
    "update:hint": null;
    "update:hoverStateEnabled": null;
    "update:maxSize": null;
    "update:minSize": null;
    "update:onDisposing": null;
    "update:onInitialized": null;
    "update:onOptionChanged": null;
    "update:opened": null;
    "update:openedStateMode": null;
    "update:position": null;
    "update:revealMode": null;
    "update:rtlEnabled": null;
    "update:shading": null;
    "update:template": null;
    "update:visible": null;
    "update:width": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    activeStateEnabled: BooleanConstructor;
    animationDuration: NumberConstructor;
    animationEnabled: BooleanConstructor;
    closeOnOutsideClick: PropType<boolean | ((event: event) => boolean)>;
    disabled: BooleanConstructor;
    elementAttr: PropType<Record<string, any>>;
    height: (NumberConstructor | StringConstructor)[];
    hint: StringConstructor;
    hoverStateEnabled: BooleanConstructor;
    maxSize: PropType<number | null>;
    minSize: PropType<number | null>;
    onDisposing: PropType<(e: DisposingEvent) => void>;
    onInitialized: PropType<(e: InitializedEvent) => void>;
    onOptionChanged: PropType<(e: OptionChangedEvent) => void>;
    opened: BooleanConstructor;
    openedStateMode: PropType<OpenedStateMode>;
    position: PropType<PanelLocation>;
    revealMode: PropType<RevealMode>;
    rtlEnabled: BooleanConstructor;
    shading: BooleanConstructor;
    template: {};
    visible: BooleanConstructor;
    width: (NumberConstructor | StringConstructor)[];
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:disabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:elementAttr"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onDisposing"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onInitialized"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onOptionChanged"?: ((...args: any[]) => any) | undefined;
    "onUpdate:rtlEnabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:height"?: ((...args: any[]) => any) | undefined;
    "onUpdate:template"?: ((...args: any[]) => any) | undefined;
    "onUpdate:width"?: ((...args: any[]) => any) | undefined;
    "onUpdate:visible"?: ((...args: any[]) => any) | undefined;
    "onUpdate:maxSize"?: ((...args: any[]) => any) | undefined;
    "onUpdate:minSize"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoverStateEnabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:activeStateEnabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:animationEnabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hint"?: ((...args: any[]) => any) | undefined;
    "onUpdate:position"?: ((...args: any[]) => any) | undefined;
    "onUpdate:shading"?: ((...args: any[]) => any) | undefined;
    "onUpdate:opened"?: ((...args: any[]) => any) | undefined;
    "onUpdate:animationDuration"?: ((...args: any[]) => any) | undefined;
    "onUpdate:closeOnOutsideClick"?: ((...args: any[]) => any) | undefined;
    "onUpdate:openedStateMode"?: ((...args: any[]) => any) | undefined;
    "onUpdate:revealMode"?: ((...args: any[]) => any) | undefined;
}, {
    disabled: boolean;
    rtlEnabled: boolean;
    visible: boolean;
    hoverStateEnabled: boolean;
    activeStateEnabled: boolean;
    animationEnabled: boolean;
    shading: boolean;
    opened: boolean;
}>;
export default DxDrawer;
export { DxDrawer };
import type * as DxDrawerTypes from "devextreme/ui/drawer_types";
export { DxDrawerTypes };
