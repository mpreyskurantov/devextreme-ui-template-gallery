/*!
 * devextreme-vue
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

export { ExplicitTypes } from "devextreme/ui/gallery";
import { PropType } from "vue";
import Gallery, { Properties } from "devextreme/ui/gallery";
import DataSource from "devextreme/data/data_source";
import { ContentReadyEvent, DisposingEvent, InitializedEvent, ItemClickEvent, ItemContextMenuEvent, ItemHoldEvent, ItemRenderedEvent, OptionChangedEvent, SelectionChangedEvent } from "devextreme/ui/gallery";
import { DataSourceOptions } from "devextreme/common/data";
import { Store } from "devextreme/data/store";
type AccessibleOptions = Pick<Properties, "accessKey" | "animationDuration" | "animationEnabled" | "dataSource" | "disabled" | "elementAttr" | "focusStateEnabled" | "height" | "hint" | "hoverStateEnabled" | "indicatorEnabled" | "initialItemWidth" | "itemHoldTimeout" | "items" | "itemTemplate" | "loop" | "noDataText" | "onContentReady" | "onDisposing" | "onInitialized" | "onItemClick" | "onItemContextMenu" | "onItemHold" | "onItemRendered" | "onOptionChanged" | "onSelectionChanged" | "rtlEnabled" | "selectedIndex" | "selectedItem" | "showIndicator" | "showNavButtons" | "slideshowDelay" | "stretchImages" | "swipeEnabled" | "tabIndex" | "visible" | "width" | "wrapAround">;
interface DxGallery extends AccessibleOptions {
    readonly instance?: Gallery;
}
declare const DxGallery: import("vue").DefineComponent<{
    accessKey: StringConstructor;
    animationDuration: NumberConstructor;
    animationEnabled: BooleanConstructor;
    dataSource: PropType<string | any[] | Record<string, any> | DataSource<any, any> | DataSourceOptions<any, any, any, any> | Store<any, any> | null>;
    disabled: BooleanConstructor;
    elementAttr: PropType<Record<string, any>>;
    focusStateEnabled: BooleanConstructor;
    height: (NumberConstructor | StringConstructor)[];
    hint: StringConstructor;
    hoverStateEnabled: BooleanConstructor;
    indicatorEnabled: BooleanConstructor;
    initialItemWidth: NumberConstructor;
    itemHoldTimeout: NumberConstructor;
    items: PropType<any[]>;
    itemTemplate: {};
    loop: BooleanConstructor;
    noDataText: StringConstructor;
    onContentReady: PropType<(e: ContentReadyEvent) => void>;
    onDisposing: PropType<(e: DisposingEvent) => void>;
    onInitialized: PropType<(e: InitializedEvent) => void>;
    onItemClick: PropType<(e: ItemClickEvent) => void>;
    onItemContextMenu: PropType<(e: ItemContextMenuEvent) => void>;
    onItemHold: PropType<(e: ItemHoldEvent) => void>;
    onItemRendered: PropType<(e: ItemRenderedEvent) => void>;
    onOptionChanged: PropType<(e: OptionChangedEvent) => void>;
    onSelectionChanged: PropType<(e: SelectionChangedEvent) => void>;
    rtlEnabled: BooleanConstructor;
    selectedIndex: NumberConstructor;
    selectedItem: {};
    showIndicator: BooleanConstructor;
    showNavButtons: BooleanConstructor;
    slideshowDelay: NumberConstructor;
    stretchImages: BooleanConstructor;
    swipeEnabled: BooleanConstructor;
    tabIndex: NumberConstructor;
    visible: BooleanConstructor;
    width: (NumberConstructor | StringConstructor)[];
    wrapAround: BooleanConstructor;
}, unknown, unknown, {
    instance(): Gallery;
}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:accessKey": null;
    "update:animationDuration": null;
    "update:animationEnabled": null;
    "update:dataSource": null;
    "update:disabled": null;
    "update:elementAttr": null;
    "update:focusStateEnabled": null;
    "update:height": null;
    "update:hint": null;
    "update:hoverStateEnabled": null;
    "update:indicatorEnabled": null;
    "update:initialItemWidth": null;
    "update:itemHoldTimeout": null;
    "update:items": null;
    "update:itemTemplate": null;
    "update:loop": null;
    "update:noDataText": null;
    "update:onContentReady": null;
    "update:onDisposing": null;
    "update:onInitialized": null;
    "update:onItemClick": null;
    "update:onItemContextMenu": null;
    "update:onItemHold": null;
    "update:onItemRendered": null;
    "update:onOptionChanged": null;
    "update:onSelectionChanged": null;
    "update:rtlEnabled": null;
    "update:selectedIndex": null;
    "update:selectedItem": null;
    "update:showIndicator": null;
    "update:showNavButtons": null;
    "update:slideshowDelay": null;
    "update:stretchImages": null;
    "update:swipeEnabled": null;
    "update:tabIndex": null;
    "update:visible": null;
    "update:width": null;
    "update:wrapAround": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    accessKey: StringConstructor;
    animationDuration: NumberConstructor;
    animationEnabled: BooleanConstructor;
    dataSource: PropType<string | any[] | Record<string, any> | DataSource<any, any> | DataSourceOptions<any, any, any, any> | Store<any, any> | null>;
    disabled: BooleanConstructor;
    elementAttr: PropType<Record<string, any>>;
    focusStateEnabled: BooleanConstructor;
    height: (NumberConstructor | StringConstructor)[];
    hint: StringConstructor;
    hoverStateEnabled: BooleanConstructor;
    indicatorEnabled: BooleanConstructor;
    initialItemWidth: NumberConstructor;
    itemHoldTimeout: NumberConstructor;
    items: PropType<any[]>;
    itemTemplate: {};
    loop: BooleanConstructor;
    noDataText: StringConstructor;
    onContentReady: PropType<(e: ContentReadyEvent) => void>;
    onDisposing: PropType<(e: DisposingEvent) => void>;
    onInitialized: PropType<(e: InitializedEvent) => void>;
    onItemClick: PropType<(e: ItemClickEvent) => void>;
    onItemContextMenu: PropType<(e: ItemContextMenuEvent) => void>;
    onItemHold: PropType<(e: ItemHoldEvent) => void>;
    onItemRendered: PropType<(e: ItemRenderedEvent) => void>;
    onOptionChanged: PropType<(e: OptionChangedEvent) => void>;
    onSelectionChanged: PropType<(e: SelectionChangedEvent) => void>;
    rtlEnabled: BooleanConstructor;
    selectedIndex: NumberConstructor;
    selectedItem: {};
    showIndicator: BooleanConstructor;
    showNavButtons: BooleanConstructor;
    slideshowDelay: NumberConstructor;
    stretchImages: BooleanConstructor;
    swipeEnabled: BooleanConstructor;
    tabIndex: NumberConstructor;
    visible: BooleanConstructor;
    width: (NumberConstructor | StringConstructor)[];
    wrapAround: BooleanConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:disabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:elementAttr"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onDisposing"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onInitialized"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onOptionChanged"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onSelectionChanged"?: ((...args: any[]) => any) | undefined;
    "onUpdate:rtlEnabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:height"?: ((...args: any[]) => any) | undefined;
    "onUpdate:width"?: ((...args: any[]) => any) | undefined;
    "onUpdate:visible"?: ((...args: any[]) => any) | undefined;
    "onUpdate:dataSource"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoverStateEnabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:items"?: ((...args: any[]) => any) | undefined;
    "onUpdate:itemTemplate"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onContentReady"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onItemClick"?: ((...args: any[]) => any) | undefined;
    "onUpdate:accessKey"?: ((...args: any[]) => any) | undefined;
    "onUpdate:animationEnabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:focusStateEnabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hint"?: ((...args: any[]) => any) | undefined;
    "onUpdate:itemHoldTimeout"?: ((...args: any[]) => any) | undefined;
    "onUpdate:noDataText"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onItemContextMenu"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onItemHold"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onItemRendered"?: ((...args: any[]) => any) | undefined;
    "onUpdate:tabIndex"?: ((...args: any[]) => any) | undefined;
    "onUpdate:showIndicator"?: ((...args: any[]) => any) | undefined;
    "onUpdate:loop"?: ((...args: any[]) => any) | undefined;
    "onUpdate:selectedIndex"?: ((...args: any[]) => any) | undefined;
    "onUpdate:selectedItem"?: ((...args: any[]) => any) | undefined;
    "onUpdate:showNavButtons"?: ((...args: any[]) => any) | undefined;
    "onUpdate:swipeEnabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:animationDuration"?: ((...args: any[]) => any) | undefined;
    "onUpdate:indicatorEnabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:initialItemWidth"?: ((...args: any[]) => any) | undefined;
    "onUpdate:slideshowDelay"?: ((...args: any[]) => any) | undefined;
    "onUpdate:stretchImages"?: ((...args: any[]) => any) | undefined;
    "onUpdate:wrapAround"?: ((...args: any[]) => any) | undefined;
}, {
    disabled: boolean;
    rtlEnabled: boolean;
    visible: boolean;
    hoverStateEnabled: boolean;
    focusStateEnabled: boolean;
    animationEnabled: boolean;
    showIndicator: boolean;
    loop: boolean;
    showNavButtons: boolean;
    swipeEnabled: boolean;
    indicatorEnabled: boolean;
    stretchImages: boolean;
    wrapAround: boolean;
}>;
declare const DxItem: import("vue").DefineComponent<{
    disabled: BooleanConstructor;
    html: StringConstructor;
    imageAlt: StringConstructor;
    imageSrc: StringConstructor;
    template: {};
    text: StringConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:disabled": null;
    "update:html": null;
    "update:imageAlt": null;
    "update:imageSrc": null;
    "update:template": null;
    "update:text": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    disabled: BooleanConstructor;
    html: StringConstructor;
    imageAlt: StringConstructor;
    imageSrc: StringConstructor;
    template: {};
    text: StringConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:disabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:template"?: ((...args: any[]) => any) | undefined;
    "onUpdate:text"?: ((...args: any[]) => any) | undefined;
    "onUpdate:html"?: ((...args: any[]) => any) | undefined;
    "onUpdate:imageAlt"?: ((...args: any[]) => any) | undefined;
    "onUpdate:imageSrc"?: ((...args: any[]) => any) | undefined;
}, {
    disabled: boolean;
}>;
export default DxGallery;
export { DxGallery, DxItem };
import type * as DxGalleryTypes from "devextreme/ui/gallery_types";
export { DxGalleryTypes };
