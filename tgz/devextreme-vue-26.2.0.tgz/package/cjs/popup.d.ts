/*!
 * devextreme-vue
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

import { PropType } from "vue";
import Popup, { Properties } from "devextreme/ui/popup";
import dxOverlay from "devextreme/ui/overlay";
import DOMComponent from "devextreme/core/dom_component";
import dxPopup from "devextreme/ui/popup";
import { event } from "devextreme/events/events.types";
import { EventInfo } from "devextreme/common/core/events";
import { Component } from "devextreme/core/component";
import { PositionAlignment, HorizontalAlignment, VerticalAlignment, Direction, ToolbarItemLocation, ToolbarItemComponent } from "devextreme/common";
import { PositionConfig, AnimationConfig, CollisionResolution, AnimationState, AnimationType, CollisionResolutionCombination } from "devextreme/common/core/animation";
import { ToolbarLocation } from "devextreme/ui/popup";
import { LocateInMenuMode, ShowTextMode } from "devextreme/ui/toolbar";
type AccessibleOptions = Pick<Properties, "accessKey" | "animation" | "container" | "contentTemplate" | "deferRendering" | "disabled" | "dragAndResizeArea" | "dragEnabled" | "dragOutsideBoundary" | "enableBodyScroll" | "focusStateEnabled" | "fullScreen" | "height" | "hideOnOutsideClick" | "hideOnParentScroll" | "hint" | "hoverStateEnabled" | "maxHeight" | "maxWidth" | "minHeight" | "minWidth" | "onContentReady" | "onDisposing" | "onHidden" | "onHiding" | "onInitialized" | "onOptionChanged" | "onResize" | "onResizeEnd" | "onResizeStart" | "onShowing" | "onShown" | "onTitleRendered" | "position" | "resizeEnabled" | "restorePosition" | "rtlEnabled" | "shading" | "shadingColor" | "showCloseButton" | "showTitle" | "tabFocusLoopEnabled" | "tabIndex" | "title" | "titleTemplate" | "toolbarItems" | "visible" | "width" | "wrapperAttr">;
interface DxPopup extends AccessibleOptions {
    readonly instance?: Popup;
}
declare const DxPopup: import("vue").DefineComponent<{
    accessKey: StringConstructor;
    animation: PropType<Record<string, any>>;
    container: {};
    contentTemplate: {};
    deferRendering: BooleanConstructor;
    disabled: BooleanConstructor;
    dragAndResizeArea: {};
    dragEnabled: BooleanConstructor;
    dragOutsideBoundary: BooleanConstructor;
    enableBodyScroll: BooleanConstructor;
    focusStateEnabled: BooleanConstructor;
    fullScreen: BooleanConstructor;
    height: (NumberConstructor | StringConstructor)[];
    hideOnOutsideClick: PropType<boolean | ((event: event) => boolean)>;
    hideOnParentScroll: BooleanConstructor;
    hint: StringConstructor;
    hoverStateEnabled: BooleanConstructor;
    maxHeight: (NumberConstructor | StringConstructor)[];
    maxWidth: (NumberConstructor | StringConstructor)[];
    minHeight: (NumberConstructor | StringConstructor)[];
    minWidth: (NumberConstructor | StringConstructor)[];
    onContentReady: PropType<(e: EventInfo<any>) => void>;
    onDisposing: PropType<(e: EventInfo<any>) => void>;
    onHidden: PropType<(e: EventInfo<any>) => void>;
    onHiding: PropType<(e: {
        cancel: boolean | any;
        component: dxOverlay<any>;
        element: any;
        model: any;
    }) => void>;
    onInitialized: PropType<(e: {
        component: Component<any>;
        element: any;
    }) => void>;
    onOptionChanged: PropType<(e: {
        component: DOMComponent;
        element: any;
        fullName: string;
        model: any;
        name: string;
        previousValue: any;
        value: any;
    }) => void>;
    onResize: PropType<(e: {
        component: dxPopup;
        element: any;
        event: event;
        height: number;
        model: any;
        width: number;
    }) => void>;
    onResizeEnd: PropType<(e: {
        component: dxPopup;
        element: any;
        event: event;
        height: number;
        model: any;
        width: number;
    }) => void>;
    onResizeStart: PropType<(e: {
        component: dxPopup;
        element: any;
        event: event;
        height: number;
        model: any;
        width: number;
    }) => void>;
    onShowing: PropType<(e: {
        cancel: boolean | any;
        component: dxOverlay<any>;
        element: any;
        model: any;
    }) => void>;
    onShown: PropType<(e: EventInfo<any>) => void>;
    onTitleRendered: PropType<(e: {
        component: dxPopup;
        element: any;
        model: any;
        titleElement: any;
    }) => void>;
    position: PropType<Record<string, any> | PositionConfig | PositionAlignment | (() => void)>;
    resizeEnabled: BooleanConstructor;
    restorePosition: BooleanConstructor;
    rtlEnabled: BooleanConstructor;
    shading: BooleanConstructor;
    shadingColor: StringConstructor;
    showCloseButton: BooleanConstructor;
    showTitle: BooleanConstructor;
    tabFocusLoopEnabled: BooleanConstructor;
    tabIndex: NumberConstructor;
    title: StringConstructor;
    titleTemplate: {};
    toolbarItems: PropType<DxPopupTypes.ToolbarItem[]>;
    visible: BooleanConstructor;
    width: (NumberConstructor | StringConstructor)[];
    wrapperAttr: {};
}, unknown, unknown, {
    instance(): Popup;
}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:accessKey": null;
    "update:animation": null;
    "update:container": null;
    "update:contentTemplate": null;
    "update:deferRendering": null;
    "update:disabled": null;
    "update:dragAndResizeArea": null;
    "update:dragEnabled": null;
    "update:dragOutsideBoundary": null;
    "update:enableBodyScroll": null;
    "update:focusStateEnabled": null;
    "update:fullScreen": null;
    "update:height": null;
    "update:hideOnOutsideClick": null;
    "update:hideOnParentScroll": null;
    "update:hint": null;
    "update:hoverStateEnabled": null;
    "update:maxHeight": null;
    "update:maxWidth": null;
    "update:minHeight": null;
    "update:minWidth": null;
    "update:onContentReady": null;
    "update:onDisposing": null;
    "update:onHidden": null;
    "update:onHiding": null;
    "update:onInitialized": null;
    "update:onOptionChanged": null;
    "update:onResize": null;
    "update:onResizeEnd": null;
    "update:onResizeStart": null;
    "update:onShowing": null;
    "update:onShown": null;
    "update:onTitleRendered": null;
    "update:position": null;
    "update:resizeEnabled": null;
    "update:restorePosition": null;
    "update:rtlEnabled": null;
    "update:shading": null;
    "update:shadingColor": null;
    "update:showCloseButton": null;
    "update:showTitle": null;
    "update:tabFocusLoopEnabled": null;
    "update:tabIndex": null;
    "update:title": null;
    "update:titleTemplate": null;
    "update:toolbarItems": null;
    "update:visible": null;
    "update:width": null;
    "update:wrapperAttr": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    accessKey: StringConstructor;
    animation: PropType<Record<string, any>>;
    container: {};
    contentTemplate: {};
    deferRendering: BooleanConstructor;
    disabled: BooleanConstructor;
    dragAndResizeArea: {};
    dragEnabled: BooleanConstructor;
    dragOutsideBoundary: BooleanConstructor;
    enableBodyScroll: BooleanConstructor;
    focusStateEnabled: BooleanConstructor;
    fullScreen: BooleanConstructor;
    height: (NumberConstructor | StringConstructor)[];
    hideOnOutsideClick: PropType<boolean | ((event: event) => boolean)>;
    hideOnParentScroll: BooleanConstructor;
    hint: StringConstructor;
    hoverStateEnabled: BooleanConstructor;
    maxHeight: (NumberConstructor | StringConstructor)[];
    maxWidth: (NumberConstructor | StringConstructor)[];
    minHeight: (NumberConstructor | StringConstructor)[];
    minWidth: (NumberConstructor | StringConstructor)[];
    onContentReady: PropType<(e: EventInfo<any>) => void>;
    onDisposing: PropType<(e: EventInfo<any>) => void>;
    onHidden: PropType<(e: EventInfo<any>) => void>;
    onHiding: PropType<(e: {
        cancel: boolean | any;
        component: dxOverlay<any>;
        element: any;
        model: any;
    }) => void>;
    onInitialized: PropType<(e: {
        component: Component<any>;
        element: any;
    }) => void>;
    onOptionChanged: PropType<(e: {
        component: DOMComponent;
        element: any;
        fullName: string;
        model: any;
        name: string;
        previousValue: any;
        value: any;
    }) => void>;
    onResize: PropType<(e: {
        component: dxPopup;
        element: any;
        event: event;
        height: number;
        model: any;
        width: number;
    }) => void>;
    onResizeEnd: PropType<(e: {
        component: dxPopup;
        element: any;
        event: event;
        height: number;
        model: any;
        width: number;
    }) => void>;
    onResizeStart: PropType<(e: {
        component: dxPopup;
        element: any;
        event: event;
        height: number;
        model: any;
        width: number;
    }) => void>;
    onShowing: PropType<(e: {
        cancel: boolean | any;
        component: dxOverlay<any>;
        element: any;
        model: any;
    }) => void>;
    onShown: PropType<(e: EventInfo<any>) => void>;
    onTitleRendered: PropType<(e: {
        component: dxPopup;
        element: any;
        model: any;
        titleElement: any;
    }) => void>;
    position: PropType<Record<string, any> | PositionConfig | PositionAlignment | (() => void)>;
    resizeEnabled: BooleanConstructor;
    restorePosition: BooleanConstructor;
    rtlEnabled: BooleanConstructor;
    shading: BooleanConstructor;
    shadingColor: StringConstructor;
    showCloseButton: BooleanConstructor;
    showTitle: BooleanConstructor;
    tabFocusLoopEnabled: BooleanConstructor;
    tabIndex: NumberConstructor;
    title: StringConstructor;
    titleTemplate: {};
    toolbarItems: PropType<DxPopupTypes.ToolbarItem[]>;
    visible: BooleanConstructor;
    width: (NumberConstructor | StringConstructor)[];
    wrapperAttr: {};
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:disabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onDisposing"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onInitialized"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onOptionChanged"?: ((...args: any[]) => any) | undefined;
    "onUpdate:rtlEnabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:title"?: ((...args: any[]) => any) | undefined;
    "onUpdate:height"?: ((...args: any[]) => any) | undefined;
    "onUpdate:width"?: ((...args: any[]) => any) | undefined;
    "onUpdate:visible"?: ((...args: any[]) => any) | undefined;
    "onUpdate:container"?: ((...args: any[]) => any) | undefined;
    "onUpdate:contentTemplate"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoverStateEnabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onContentReady"?: ((...args: any[]) => any) | undefined;
    "onUpdate:accessKey"?: ((...args: any[]) => any) | undefined;
    "onUpdate:focusStateEnabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hint"?: ((...args: any[]) => any) | undefined;
    "onUpdate:tabIndex"?: ((...args: any[]) => any) | undefined;
    "onUpdate:minWidth"?: ((...args: any[]) => any) | undefined;
    "onUpdate:position"?: ((...args: any[]) => any) | undefined;
    "onUpdate:animation"?: ((...args: any[]) => any) | undefined;
    "onUpdate:deferRendering"?: ((...args: any[]) => any) | undefined;
    "onUpdate:dragAndResizeArea"?: ((...args: any[]) => any) | undefined;
    "onUpdate:dragEnabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:dragOutsideBoundary"?: ((...args: any[]) => any) | undefined;
    "onUpdate:enableBodyScroll"?: ((...args: any[]) => any) | undefined;
    "onUpdate:fullScreen"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hideOnOutsideClick"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hideOnParentScroll"?: ((...args: any[]) => any) | undefined;
    "onUpdate:maxHeight"?: ((...args: any[]) => any) | undefined;
    "onUpdate:maxWidth"?: ((...args: any[]) => any) | undefined;
    "onUpdate:minHeight"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onHidden"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onHiding"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onResize"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onResizeEnd"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onResizeStart"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onShowing"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onShown"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onTitleRendered"?: ((...args: any[]) => any) | undefined;
    "onUpdate:resizeEnabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:restorePosition"?: ((...args: any[]) => any) | undefined;
    "onUpdate:shading"?: ((...args: any[]) => any) | undefined;
    "onUpdate:shadingColor"?: ((...args: any[]) => any) | undefined;
    "onUpdate:showCloseButton"?: ((...args: any[]) => any) | undefined;
    "onUpdate:showTitle"?: ((...args: any[]) => any) | undefined;
    "onUpdate:tabFocusLoopEnabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:titleTemplate"?: ((...args: any[]) => any) | undefined;
    "onUpdate:toolbarItems"?: ((...args: any[]) => any) | undefined;
    "onUpdate:wrapperAttr"?: ((...args: any[]) => any) | undefined;
}, {
    disabled: boolean;
    rtlEnabled: boolean;
    visible: boolean;
    hoverStateEnabled: boolean;
    focusStateEnabled: boolean;
    deferRendering: boolean;
    dragEnabled: boolean;
    dragOutsideBoundary: boolean;
    enableBodyScroll: boolean;
    fullScreen: boolean;
    hideOnParentScroll: boolean;
    resizeEnabled: boolean;
    restorePosition: boolean;
    shading: boolean;
    showCloseButton: boolean;
    showTitle: boolean;
    tabFocusLoopEnabled: boolean;
}>;
declare const DxAnimation: import("vue").DefineComponent<{
    hide: PropType<string | number | Record<string, any> | AnimationConfig>;
    show: PropType<string | number | Record<string, any> | AnimationConfig>;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:hide": null;
    "update:show": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    hide: PropType<string | number | Record<string, any> | AnimationConfig>;
    show: PropType<string | number | Record<string, any> | AnimationConfig>;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:show"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hide"?: ((...args: any[]) => any) | undefined;
}, {}>;
declare const DxAt: import("vue").DefineComponent<{
    x: PropType<HorizontalAlignment>;
    y: PropType<VerticalAlignment>;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:x": null;
    "update:y": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    x: PropType<HorizontalAlignment>;
    y: PropType<VerticalAlignment>;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:x"?: ((...args: any[]) => any) | undefined;
    "onUpdate:y"?: ((...args: any[]) => any) | undefined;
}, {}>;
declare const DxBoundaryOffset: import("vue").DefineComponent<{
    x: NumberConstructor;
    y: NumberConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:x": null;
    "update:y": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    x: NumberConstructor;
    y: NumberConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:x"?: ((...args: any[]) => any) | undefined;
    "onUpdate:y"?: ((...args: any[]) => any) | undefined;
}, {}>;
declare const DxCollision: import("vue").DefineComponent<{
    x: PropType<CollisionResolution>;
    y: PropType<CollisionResolution>;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:x": null;
    "update:y": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    x: PropType<CollisionResolution>;
    y: PropType<CollisionResolution>;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:x"?: ((...args: any[]) => any) | undefined;
    "onUpdate:y"?: ((...args: any[]) => any) | undefined;
}, {}>;
declare const DxFrom: import("vue").DefineComponent<{
    left: NumberConstructor;
    opacity: NumberConstructor;
    position: PropType<Record<string, any> | PositionConfig>;
    scale: NumberConstructor;
    top: NumberConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:left": null;
    "update:opacity": null;
    "update:position": null;
    "update:scale": null;
    "update:top": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    left: NumberConstructor;
    opacity: NumberConstructor;
    position: PropType<Record<string, any> | PositionConfig>;
    scale: NumberConstructor;
    top: NumberConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:opacity"?: ((...args: any[]) => any) | undefined;
    "onUpdate:left"?: ((...args: any[]) => any) | undefined;
    "onUpdate:top"?: ((...args: any[]) => any) | undefined;
    "onUpdate:position"?: ((...args: any[]) => any) | undefined;
    "onUpdate:scale"?: ((...args: any[]) => any) | undefined;
}, {}>;
declare const DxHide: import("vue").DefineComponent<{
    complete: PropType<($element: any, config: AnimationConfig) => void>;
    delay: NumberConstructor;
    direction: PropType<Direction>;
    duration: NumberConstructor;
    easing: StringConstructor;
    from: PropType<Record<string, any> | AnimationState>;
    staggerDelay: NumberConstructor;
    start: PropType<($element: any, config: AnimationConfig) => void>;
    to: PropType<Record<string, any> | AnimationState>;
    type: PropType<AnimationType>;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:complete": null;
    "update:delay": null;
    "update:direction": null;
    "update:duration": null;
    "update:easing": null;
    "update:from": null;
    "update:staggerDelay": null;
    "update:start": null;
    "update:to": null;
    "update:type": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    complete: PropType<($element: any, config: AnimationConfig) => void>;
    delay: NumberConstructor;
    direction: PropType<Direction>;
    duration: NumberConstructor;
    easing: StringConstructor;
    from: PropType<Record<string, any> | AnimationState>;
    staggerDelay: NumberConstructor;
    start: PropType<($element: any, config: AnimationConfig) => void>;
    to: PropType<Record<string, any> | AnimationState>;
    type: PropType<AnimationType>;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:type"?: ((...args: any[]) => any) | undefined;
    "onUpdate:from"?: ((...args: any[]) => any) | undefined;
    "onUpdate:to"?: ((...args: any[]) => any) | undefined;
    "onUpdate:complete"?: ((...args: any[]) => any) | undefined;
    "onUpdate:delay"?: ((...args: any[]) => any) | undefined;
    "onUpdate:direction"?: ((...args: any[]) => any) | undefined;
    "onUpdate:duration"?: ((...args: any[]) => any) | undefined;
    "onUpdate:easing"?: ((...args: any[]) => any) | undefined;
    "onUpdate:staggerDelay"?: ((...args: any[]) => any) | undefined;
    "onUpdate:start"?: ((...args: any[]) => any) | undefined;
}, {}>;
declare const DxMy: import("vue").DefineComponent<{
    x: PropType<HorizontalAlignment>;
    y: PropType<VerticalAlignment>;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:x": null;
    "update:y": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    x: PropType<HorizontalAlignment>;
    y: PropType<VerticalAlignment>;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:x"?: ((...args: any[]) => any) | undefined;
    "onUpdate:y"?: ((...args: any[]) => any) | undefined;
}, {}>;
declare const DxOffset: import("vue").DefineComponent<{
    x: NumberConstructor;
    y: NumberConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:x": null;
    "update:y": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    x: NumberConstructor;
    y: NumberConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:x"?: ((...args: any[]) => any) | undefined;
    "onUpdate:y"?: ((...args: any[]) => any) | undefined;
}, {}>;
declare const DxPosition: import("vue").DefineComponent<{
    at: PropType<Record<string, any> | PositionAlignment>;
    boundary: {};
    boundaryOffset: PropType<string | Record<string, any>>;
    collision: PropType<Record<string, any> | CollisionResolutionCombination>;
    my: PropType<Record<string, any> | PositionAlignment>;
    of: {};
    offset: PropType<string | Record<string, any>>;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:at": null;
    "update:boundary": null;
    "update:boundaryOffset": null;
    "update:collision": null;
    "update:my": null;
    "update:of": null;
    "update:offset": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    at: PropType<Record<string, any> | PositionAlignment>;
    boundary: {};
    boundaryOffset: PropType<string | Record<string, any>>;
    collision: PropType<Record<string, any> | CollisionResolutionCombination>;
    my: PropType<Record<string, any> | PositionAlignment>;
    of: {};
    offset: PropType<string | Record<string, any>>;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:offset"?: ((...args: any[]) => any) | undefined;
    "onUpdate:at"?: ((...args: any[]) => any) | undefined;
    "onUpdate:boundary"?: ((...args: any[]) => any) | undefined;
    "onUpdate:boundaryOffset"?: ((...args: any[]) => any) | undefined;
    "onUpdate:collision"?: ((...args: any[]) => any) | undefined;
    "onUpdate:my"?: ((...args: any[]) => any) | undefined;
    "onUpdate:of"?: ((...args: any[]) => any) | undefined;
}, {}>;
declare const DxShow: import("vue").DefineComponent<{
    complete: PropType<($element: any, config: AnimationConfig) => void>;
    delay: NumberConstructor;
    direction: PropType<Direction>;
    duration: NumberConstructor;
    easing: StringConstructor;
    from: PropType<Record<string, any> | AnimationState>;
    staggerDelay: NumberConstructor;
    start: PropType<($element: any, config: AnimationConfig) => void>;
    to: PropType<Record<string, any> | AnimationState>;
    type: PropType<AnimationType>;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:complete": null;
    "update:delay": null;
    "update:direction": null;
    "update:duration": null;
    "update:easing": null;
    "update:from": null;
    "update:staggerDelay": null;
    "update:start": null;
    "update:to": null;
    "update:type": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    complete: PropType<($element: any, config: AnimationConfig) => void>;
    delay: NumberConstructor;
    direction: PropType<Direction>;
    duration: NumberConstructor;
    easing: StringConstructor;
    from: PropType<Record<string, any> | AnimationState>;
    staggerDelay: NumberConstructor;
    start: PropType<($element: any, config: AnimationConfig) => void>;
    to: PropType<Record<string, any> | AnimationState>;
    type: PropType<AnimationType>;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:type"?: ((...args: any[]) => any) | undefined;
    "onUpdate:from"?: ((...args: any[]) => any) | undefined;
    "onUpdate:to"?: ((...args: any[]) => any) | undefined;
    "onUpdate:complete"?: ((...args: any[]) => any) | undefined;
    "onUpdate:delay"?: ((...args: any[]) => any) | undefined;
    "onUpdate:direction"?: ((...args: any[]) => any) | undefined;
    "onUpdate:duration"?: ((...args: any[]) => any) | undefined;
    "onUpdate:easing"?: ((...args: any[]) => any) | undefined;
    "onUpdate:staggerDelay"?: ((...args: any[]) => any) | undefined;
    "onUpdate:start"?: ((...args: any[]) => any) | undefined;
}, {}>;
declare const DxTo: import("vue").DefineComponent<{
    left: NumberConstructor;
    opacity: NumberConstructor;
    position: PropType<Record<string, any> | PositionConfig>;
    scale: NumberConstructor;
    top: NumberConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:left": null;
    "update:opacity": null;
    "update:position": null;
    "update:scale": null;
    "update:top": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    left: NumberConstructor;
    opacity: NumberConstructor;
    position: PropType<Record<string, any> | PositionConfig>;
    scale: NumberConstructor;
    top: NumberConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:opacity"?: ((...args: any[]) => any) | undefined;
    "onUpdate:left"?: ((...args: any[]) => any) | undefined;
    "onUpdate:top"?: ((...args: any[]) => any) | undefined;
    "onUpdate:position"?: ((...args: any[]) => any) | undefined;
    "onUpdate:scale"?: ((...args: any[]) => any) | undefined;
}, {}>;
declare const DxToolbarItem: import("vue").DefineComponent<{
    cssClass: StringConstructor;
    disabled: BooleanConstructor;
    html: StringConstructor;
    locateInMenu: PropType<LocateInMenuMode>;
    location: PropType<ToolbarItemLocation>;
    menuItemTemplate: {};
    options: {};
    showText: PropType<ShowTextMode>;
    template: {};
    text: StringConstructor;
    toolbar: PropType<ToolbarLocation>;
    visible: BooleanConstructor;
    widget: PropType<ToolbarItemComponent>;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:cssClass": null;
    "update:disabled": null;
    "update:html": null;
    "update:locateInMenu": null;
    "update:location": null;
    "update:menuItemTemplate": null;
    "update:options": null;
    "update:showText": null;
    "update:template": null;
    "update:text": null;
    "update:toolbar": null;
    "update:visible": null;
    "update:widget": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    cssClass: StringConstructor;
    disabled: BooleanConstructor;
    html: StringConstructor;
    locateInMenu: PropType<LocateInMenuMode>;
    location: PropType<ToolbarItemLocation>;
    menuItemTemplate: {};
    options: {};
    showText: PropType<ShowTextMode>;
    template: {};
    text: StringConstructor;
    toolbar: PropType<ToolbarLocation>;
    visible: BooleanConstructor;
    widget: PropType<ToolbarItemComponent>;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:disabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:template"?: ((...args: any[]) => any) | undefined;
    "onUpdate:text"?: ((...args: any[]) => any) | undefined;
    "onUpdate:visible"?: ((...args: any[]) => any) | undefined;
    "onUpdate:html"?: ((...args: any[]) => any) | undefined;
    "onUpdate:location"?: ((...args: any[]) => any) | undefined;
    "onUpdate:options"?: ((...args: any[]) => any) | undefined;
    "onUpdate:toolbar"?: ((...args: any[]) => any) | undefined;
    "onUpdate:cssClass"?: ((...args: any[]) => any) | undefined;
    "onUpdate:locateInMenu"?: ((...args: any[]) => any) | undefined;
    "onUpdate:menuItemTemplate"?: ((...args: any[]) => any) | undefined;
    "onUpdate:showText"?: ((...args: any[]) => any) | undefined;
    "onUpdate:widget"?: ((...args: any[]) => any) | undefined;
}, {
    disabled: boolean;
    visible: boolean;
}>;
export default DxPopup;
export { DxPopup, DxAnimation, DxAt, DxBoundaryOffset, DxCollision, DxFrom, DxHide, DxMy, DxOffset, DxPosition, DxShow, DxTo, DxToolbarItem };
import type * as DxPopupTypes from "devextreme/ui/popup_types";
export { DxPopupTypes };
