/*!
 * devextreme-vue
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

import { PropType } from "vue";
import Gantt, { Properties } from "devextreme/ui/gantt";
import DataSource from "devextreme/data/data_source";
import { dxGanttColumn, dxGanttContextMenu, dxGanttFilterRow, dxGanttHeaderFilter, ContentReadyEvent, ContextMenuPreparingEvent, CustomCommandEvent, DependencyDeletedEvent, DependencyDeletingEvent, DependencyInsertedEvent, DependencyInsertingEvent, DisposingEvent, InitializedEvent, OptionChangedEvent, ResourceAssignedEvent, ResourceAssigningEvent, ResourceDeletedEvent, ResourceDeletingEvent, ResourceInsertedEvent, ResourceInsertingEvent, ResourceManagerDialogShowingEvent, ResourceUnassignedEvent, ResourceUnassigningEvent, ScaleCellPreparedEvent, SelectionChangedEvent, TaskClickEvent, TaskDblClickEvent, TaskDeletedEvent, TaskDeletingEvent, TaskEditDialogShowingEvent, TaskInsertedEvent, TaskInsertingEvent, TaskMovingEvent, TaskUpdatedEvent, TaskUpdatingEvent, GanttScaleType, dxGanttSorting, dxGanttStripLine, GanttTaskTitlePosition, dxGanttToolbar, dxGanttContextMenuItem, GanttPredefinedContextMenuItem, dxGanttFilterRowOperationDescriptions, dxGanttHeaderFilterTexts, GanttPredefinedToolbarItem, dxGanttToolbarItem } from "devextreme/ui/gantt";
import { DayOfWeek, HorizontalAlignment, DataType, SortOrder, SearchMode, ToolbarItemLocation, ToolbarItemComponent } from "devextreme/common";
import { FilterType, ColumnHeaderFilter, SelectedFilterOperation, HeaderFilterGroupInterval, ColumnHeaderFilterSearchConfig, HeaderFilterSearchConfig } from "devextreme/common/grids";
import { DataSourceOptions } from "devextreme/common/data";
import { Store } from "devextreme/data/store";
import { dxContextMenuItem } from "devextreme/ui/context_menu";
import { LocateInMenuMode, ShowTextMode } from "devextreme/ui/toolbar";
type AccessibleOptions = Pick<Properties, "accessKey" | "activeStateEnabled" | "allowSelection" | "columns" | "contextMenu" | "dependencies" | "disabled" | "editing" | "elementAttr" | "endDateRange" | "filterRow" | "firstDayOfWeek" | "focusStateEnabled" | "headerFilter" | "height" | "hint" | "hoverStateEnabled" | "onContentReady" | "onContextMenuPreparing" | "onCustomCommand" | "onDependencyDeleted" | "onDependencyDeleting" | "onDependencyInserted" | "onDependencyInserting" | "onDisposing" | "onInitialized" | "onOptionChanged" | "onResourceAssigned" | "onResourceAssigning" | "onResourceDeleted" | "onResourceDeleting" | "onResourceInserted" | "onResourceInserting" | "onResourceManagerDialogShowing" | "onResourceUnassigned" | "onResourceUnassigning" | "onScaleCellPrepared" | "onSelectionChanged" | "onTaskClick" | "onTaskDblClick" | "onTaskDeleted" | "onTaskDeleting" | "onTaskEditDialogShowing" | "onTaskInserted" | "onTaskInserting" | "onTaskMoving" | "onTaskUpdated" | "onTaskUpdating" | "resourceAssignments" | "resources" | "rootValue" | "scaleType" | "scaleTypeRange" | "selectedRowKey" | "showDependencies" | "showResources" | "showRowLines" | "sorting" | "startDateRange" | "stripLines" | "tabIndex" | "taskContentTemplate" | "taskListWidth" | "taskProgressTooltipContentTemplate" | "tasks" | "taskTimeTooltipContentTemplate" | "taskTitlePosition" | "taskTooltipContentTemplate" | "toolbar" | "validation" | "visible" | "width">;
interface DxGantt extends AccessibleOptions {
    readonly instance?: Gantt;
}
declare const DxGantt: import("vue").DefineComponent<{
    accessKey: StringConstructor;
    activeStateEnabled: BooleanConstructor;
    allowSelection: BooleanConstructor;
    columns: PropType<(string | dxGanttColumn<any, any>)[]>;
    contextMenu: PropType<Record<string, any> | dxGanttContextMenu>;
    dependencies: PropType<Record<string, any>>;
    disabled: BooleanConstructor;
    editing: PropType<Record<string, any>>;
    elementAttr: PropType<Record<string, any>>;
    endDateRange: DateConstructor;
    filterRow: PropType<Record<string, any> | dxGanttFilterRow>;
    firstDayOfWeek: PropType<DayOfWeek>;
    focusStateEnabled: BooleanConstructor;
    headerFilter: PropType<Record<string, any> | dxGanttHeaderFilter>;
    height: (NumberConstructor | StringConstructor)[];
    hint: StringConstructor;
    hoverStateEnabled: BooleanConstructor;
    onContentReady: PropType<(e: ContentReadyEvent) => void>;
    onContextMenuPreparing: PropType<(e: ContextMenuPreparingEvent) => void>;
    onCustomCommand: PropType<(e: CustomCommandEvent) => void>;
    onDependencyDeleted: PropType<(e: DependencyDeletedEvent) => void>;
    onDependencyDeleting: PropType<(e: DependencyDeletingEvent) => void>;
    onDependencyInserted: PropType<(e: DependencyInsertedEvent) => void>;
    onDependencyInserting: PropType<(e: DependencyInsertingEvent) => void>;
    onDisposing: PropType<(e: DisposingEvent) => void>;
    onInitialized: PropType<(e: InitializedEvent) => void>;
    onOptionChanged: PropType<(e: OptionChangedEvent) => void>;
    onResourceAssigned: PropType<(e: ResourceAssignedEvent) => void>;
    onResourceAssigning: PropType<(e: ResourceAssigningEvent) => void>;
    onResourceDeleted: PropType<(e: ResourceDeletedEvent) => void>;
    onResourceDeleting: PropType<(e: ResourceDeletingEvent) => void>;
    onResourceInserted: PropType<(e: ResourceInsertedEvent) => void>;
    onResourceInserting: PropType<(e: ResourceInsertingEvent) => void>;
    onResourceManagerDialogShowing: PropType<(e: ResourceManagerDialogShowingEvent) => void>;
    onResourceUnassigned: PropType<(e: ResourceUnassignedEvent) => void>;
    onResourceUnassigning: PropType<(e: ResourceUnassigningEvent) => void>;
    onScaleCellPrepared: PropType<(e: ScaleCellPreparedEvent) => void>;
    onSelectionChanged: PropType<(e: SelectionChangedEvent) => void>;
    onTaskClick: PropType<(e: TaskClickEvent) => void>;
    onTaskDblClick: PropType<(e: TaskDblClickEvent) => void>;
    onTaskDeleted: PropType<(e: TaskDeletedEvent) => void>;
    onTaskDeleting: PropType<(e: TaskDeletingEvent) => void>;
    onTaskEditDialogShowing: PropType<(e: TaskEditDialogShowingEvent) => void>;
    onTaskInserted: PropType<(e: TaskInsertedEvent) => void>;
    onTaskInserting: PropType<(e: TaskInsertingEvent) => void>;
    onTaskMoving: PropType<(e: TaskMovingEvent) => void>;
    onTaskUpdated: PropType<(e: TaskUpdatedEvent) => void>;
    onTaskUpdating: PropType<(e: TaskUpdatingEvent) => void>;
    resourceAssignments: PropType<Record<string, any>>;
    resources: PropType<Record<string, any>>;
    rootValue: {};
    scaleType: PropType<GanttScaleType>;
    scaleTypeRange: PropType<Record<string, any>>;
    selectedRowKey: {};
    showDependencies: BooleanConstructor;
    showResources: BooleanConstructor;
    showRowLines: BooleanConstructor;
    sorting: PropType<Record<string, any> | dxGanttSorting>;
    startDateRange: DateConstructor;
    stripLines: PropType<dxGanttStripLine[]>;
    tabIndex: NumberConstructor;
    taskContentTemplate: {};
    taskListWidth: NumberConstructor;
    taskProgressTooltipContentTemplate: {};
    tasks: PropType<Record<string, any>>;
    taskTimeTooltipContentTemplate: {};
    taskTitlePosition: PropType<GanttTaskTitlePosition>;
    taskTooltipContentTemplate: {};
    toolbar: PropType<Record<string, any> | dxGanttToolbar>;
    validation: PropType<Record<string, any>>;
    visible: BooleanConstructor;
    width: (NumberConstructor | StringConstructor)[];
}, unknown, unknown, {
    instance(): Gantt;
}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:accessKey": null;
    "update:activeStateEnabled": null;
    "update:allowSelection": null;
    "update:columns": null;
    "update:contextMenu": null;
    "update:dependencies": null;
    "update:disabled": null;
    "update:editing": null;
    "update:elementAttr": null;
    "update:endDateRange": null;
    "update:filterRow": null;
    "update:firstDayOfWeek": null;
    "update:focusStateEnabled": null;
    "update:headerFilter": null;
    "update:height": null;
    "update:hint": null;
    "update:hoverStateEnabled": null;
    "update:onContentReady": null;
    "update:onContextMenuPreparing": null;
    "update:onCustomCommand": null;
    "update:onDependencyDeleted": null;
    "update:onDependencyDeleting": null;
    "update:onDependencyInserted": null;
    "update:onDependencyInserting": null;
    "update:onDisposing": null;
    "update:onInitialized": null;
    "update:onOptionChanged": null;
    "update:onResourceAssigned": null;
    "update:onResourceAssigning": null;
    "update:onResourceDeleted": null;
    "update:onResourceDeleting": null;
    "update:onResourceInserted": null;
    "update:onResourceInserting": null;
    "update:onResourceManagerDialogShowing": null;
    "update:onResourceUnassigned": null;
    "update:onResourceUnassigning": null;
    "update:onScaleCellPrepared": null;
    "update:onSelectionChanged": null;
    "update:onTaskClick": null;
    "update:onTaskDblClick": null;
    "update:onTaskDeleted": null;
    "update:onTaskDeleting": null;
    "update:onTaskEditDialogShowing": null;
    "update:onTaskInserted": null;
    "update:onTaskInserting": null;
    "update:onTaskMoving": null;
    "update:onTaskUpdated": null;
    "update:onTaskUpdating": null;
    "update:resourceAssignments": null;
    "update:resources": null;
    "update:rootValue": null;
    "update:scaleType": null;
    "update:scaleTypeRange": null;
    "update:selectedRowKey": null;
    "update:showDependencies": null;
    "update:showResources": null;
    "update:showRowLines": null;
    "update:sorting": null;
    "update:startDateRange": null;
    "update:stripLines": null;
    "update:tabIndex": null;
    "update:taskContentTemplate": null;
    "update:taskListWidth": null;
    "update:taskProgressTooltipContentTemplate": null;
    "update:tasks": null;
    "update:taskTimeTooltipContentTemplate": null;
    "update:taskTitlePosition": null;
    "update:taskTooltipContentTemplate": null;
    "update:toolbar": null;
    "update:validation": null;
    "update:visible": null;
    "update:width": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    accessKey: StringConstructor;
    activeStateEnabled: BooleanConstructor;
    allowSelection: BooleanConstructor;
    columns: PropType<(string | dxGanttColumn<any, any>)[]>;
    contextMenu: PropType<Record<string, any> | dxGanttContextMenu>;
    dependencies: PropType<Record<string, any>>;
    disabled: BooleanConstructor;
    editing: PropType<Record<string, any>>;
    elementAttr: PropType<Record<string, any>>;
    endDateRange: DateConstructor;
    filterRow: PropType<Record<string, any> | dxGanttFilterRow>;
    firstDayOfWeek: PropType<DayOfWeek>;
    focusStateEnabled: BooleanConstructor;
    headerFilter: PropType<Record<string, any> | dxGanttHeaderFilter>;
    height: (NumberConstructor | StringConstructor)[];
    hint: StringConstructor;
    hoverStateEnabled: BooleanConstructor;
    onContentReady: PropType<(e: ContentReadyEvent) => void>;
    onContextMenuPreparing: PropType<(e: ContextMenuPreparingEvent) => void>;
    onCustomCommand: PropType<(e: CustomCommandEvent) => void>;
    onDependencyDeleted: PropType<(e: DependencyDeletedEvent) => void>;
    onDependencyDeleting: PropType<(e: DependencyDeletingEvent) => void>;
    onDependencyInserted: PropType<(e: DependencyInsertedEvent) => void>;
    onDependencyInserting: PropType<(e: DependencyInsertingEvent) => void>;
    onDisposing: PropType<(e: DisposingEvent) => void>;
    onInitialized: PropType<(e: InitializedEvent) => void>;
    onOptionChanged: PropType<(e: OptionChangedEvent) => void>;
    onResourceAssigned: PropType<(e: ResourceAssignedEvent) => void>;
    onResourceAssigning: PropType<(e: ResourceAssigningEvent) => void>;
    onResourceDeleted: PropType<(e: ResourceDeletedEvent) => void>;
    onResourceDeleting: PropType<(e: ResourceDeletingEvent) => void>;
    onResourceInserted: PropType<(e: ResourceInsertedEvent) => void>;
    onResourceInserting: PropType<(e: ResourceInsertingEvent) => void>;
    onResourceManagerDialogShowing: PropType<(e: ResourceManagerDialogShowingEvent) => void>;
    onResourceUnassigned: PropType<(e: ResourceUnassignedEvent) => void>;
    onResourceUnassigning: PropType<(e: ResourceUnassigningEvent) => void>;
    onScaleCellPrepared: PropType<(e: ScaleCellPreparedEvent) => void>;
    onSelectionChanged: PropType<(e: SelectionChangedEvent) => void>;
    onTaskClick: PropType<(e: TaskClickEvent) => void>;
    onTaskDblClick: PropType<(e: TaskDblClickEvent) => void>;
    onTaskDeleted: PropType<(e: TaskDeletedEvent) => void>;
    onTaskDeleting: PropType<(e: TaskDeletingEvent) => void>;
    onTaskEditDialogShowing: PropType<(e: TaskEditDialogShowingEvent) => void>;
    onTaskInserted: PropType<(e: TaskInsertedEvent) => void>;
    onTaskInserting: PropType<(e: TaskInsertingEvent) => void>;
    onTaskMoving: PropType<(e: TaskMovingEvent) => void>;
    onTaskUpdated: PropType<(e: TaskUpdatedEvent) => void>;
    onTaskUpdating: PropType<(e: TaskUpdatingEvent) => void>;
    resourceAssignments: PropType<Record<string, any>>;
    resources: PropType<Record<string, any>>;
    rootValue: {};
    scaleType: PropType<GanttScaleType>;
    scaleTypeRange: PropType<Record<string, any>>;
    selectedRowKey: {};
    showDependencies: BooleanConstructor;
    showResources: BooleanConstructor;
    showRowLines: BooleanConstructor;
    sorting: PropType<Record<string, any> | dxGanttSorting>;
    startDateRange: DateConstructor;
    stripLines: PropType<dxGanttStripLine[]>;
    tabIndex: NumberConstructor;
    taskContentTemplate: {};
    taskListWidth: NumberConstructor;
    taskProgressTooltipContentTemplate: {};
    tasks: PropType<Record<string, any>>;
    taskTimeTooltipContentTemplate: {};
    taskTitlePosition: PropType<GanttTaskTitlePosition>;
    taskTooltipContentTemplate: {};
    toolbar: PropType<Record<string, any> | dxGanttToolbar>;
    validation: PropType<Record<string, any>>;
    visible: BooleanConstructor;
    width: (NumberConstructor | StringConstructor)[];
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:disabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:elementAttr"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onDisposing"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onInitialized"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onOptionChanged"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onSelectionChanged"?: ((...args: any[]) => any) | undefined;
    "onUpdate:height"?: ((...args: any[]) => any) | undefined;
    "onUpdate:width"?: ((...args: any[]) => any) | undefined;
    "onUpdate:visible"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoverStateEnabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onContentReady"?: ((...args: any[]) => any) | undefined;
    "onUpdate:accessKey"?: ((...args: any[]) => any) | undefined;
    "onUpdate:activeStateEnabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:focusStateEnabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hint"?: ((...args: any[]) => any) | undefined;
    "onUpdate:rootValue"?: ((...args: any[]) => any) | undefined;
    "onUpdate:tabIndex"?: ((...args: any[]) => any) | undefined;
    "onUpdate:columns"?: ((...args: any[]) => any) | undefined;
    "onUpdate:editing"?: ((...args: any[]) => any) | undefined;
    "onUpdate:filterRow"?: ((...args: any[]) => any) | undefined;
    "onUpdate:headerFilter"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onContextMenuPreparing"?: ((...args: any[]) => any) | undefined;
    "onUpdate:showRowLines"?: ((...args: any[]) => any) | undefined;
    "onUpdate:sorting"?: ((...args: any[]) => any) | undefined;
    "onUpdate:toolbar"?: ((...args: any[]) => any) | undefined;
    "onUpdate:firstDayOfWeek"?: ((...args: any[]) => any) | undefined;
    "onUpdate:resources"?: ((...args: any[]) => any) | undefined;
    "onUpdate:contextMenu"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onCustomCommand"?: ((...args: any[]) => any) | undefined;
    "onUpdate:allowSelection"?: ((...args: any[]) => any) | undefined;
    "onUpdate:dependencies"?: ((...args: any[]) => any) | undefined;
    "onUpdate:endDateRange"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onDependencyDeleted"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onDependencyDeleting"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onDependencyInserted"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onDependencyInserting"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onResourceAssigned"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onResourceAssigning"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onResourceDeleted"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onResourceDeleting"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onResourceInserted"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onResourceInserting"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onResourceManagerDialogShowing"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onResourceUnassigned"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onResourceUnassigning"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onScaleCellPrepared"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onTaskClick"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onTaskDblClick"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onTaskDeleted"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onTaskDeleting"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onTaskEditDialogShowing"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onTaskInserted"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onTaskInserting"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onTaskMoving"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onTaskUpdated"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onTaskUpdating"?: ((...args: any[]) => any) | undefined;
    "onUpdate:resourceAssignments"?: ((...args: any[]) => any) | undefined;
    "onUpdate:scaleType"?: ((...args: any[]) => any) | undefined;
    "onUpdate:scaleTypeRange"?: ((...args: any[]) => any) | undefined;
    "onUpdate:selectedRowKey"?: ((...args: any[]) => any) | undefined;
    "onUpdate:showDependencies"?: ((...args: any[]) => any) | undefined;
    "onUpdate:showResources"?: ((...args: any[]) => any) | undefined;
    "onUpdate:startDateRange"?: ((...args: any[]) => any) | undefined;
    "onUpdate:stripLines"?: ((...args: any[]) => any) | undefined;
    "onUpdate:taskContentTemplate"?: ((...args: any[]) => any) | undefined;
    "onUpdate:taskListWidth"?: ((...args: any[]) => any) | undefined;
    "onUpdate:taskProgressTooltipContentTemplate"?: ((...args: any[]) => any) | undefined;
    "onUpdate:tasks"?: ((...args: any[]) => any) | undefined;
    "onUpdate:taskTimeTooltipContentTemplate"?: ((...args: any[]) => any) | undefined;
    "onUpdate:taskTitlePosition"?: ((...args: any[]) => any) | undefined;
    "onUpdate:taskTooltipContentTemplate"?: ((...args: any[]) => any) | undefined;
    "onUpdate:validation"?: ((...args: any[]) => any) | undefined;
}, {
    disabled: boolean;
    visible: boolean;
    hoverStateEnabled: boolean;
    activeStateEnabled: boolean;
    focusStateEnabled: boolean;
    showRowLines: boolean;
    allowSelection: boolean;
    showDependencies: boolean;
    showResources: boolean;
}>;
declare const DxColumn: import("vue").DefineComponent<{
    alignment: PropType<HorizontalAlignment>;
    allowFiltering: BooleanConstructor;
    allowHeaderFiltering: BooleanConstructor;
    allowSorting: BooleanConstructor;
    calculateCellValue: PropType<(rowData: any) => any>;
    calculateDisplayValue: PropType<string | ((rowData: any) => any)>;
    calculateFilterExpression: PropType<(filterValue: any, selectedFilterOperation: string | null, target: string) => string | (() => any) | Array<any>>;
    calculateSortValue: PropType<string | ((rowData: any) => any)>;
    caption: StringConstructor;
    cellTemplate: {};
    cssClass: StringConstructor;
    customizeText: PropType<(cellInfo: {
        groupInterval: string | number;
        target: string;
        value: any;
        valueText: string;
    }) => string>;
    dataField: StringConstructor;
    dataType: PropType<DataType>;
    encodeHtml: BooleanConstructor;
    falseText: StringConstructor;
    filterOperations: PropType<string[]>;
    filterType: PropType<FilterType>;
    filterValue: {};
    filterValues: PropType<any[]>;
    format: PropType<string | Record<string, any> | import("devextreme/common/core/localization").FormatObject | ((value: number | Date) => string) | ((value: Date) => string) | ((value: number) => string) | Intl.DateTimeFormatOptions | Intl.NumberFormatOptions | ((value: number | Date) => string) | undefined>;
    headerCellTemplate: {};
    headerFilter: PropType<Record<string, any> | ColumnHeaderFilter>;
    minWidth: NumberConstructor;
    selectedFilterOperation: PropType<SelectedFilterOperation>;
    sortIndex: NumberConstructor;
    sortingMethod: PropType<(value1: any, value2: any) => number>;
    sortOrder: PropType<SortOrder>;
    trueText: StringConstructor;
    visible: BooleanConstructor;
    visibleIndex: NumberConstructor;
    width: (NumberConstructor | StringConstructor)[];
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:alignment": null;
    "update:allowFiltering": null;
    "update:allowHeaderFiltering": null;
    "update:allowSorting": null;
    "update:calculateCellValue": null;
    "update:calculateDisplayValue": null;
    "update:calculateFilterExpression": null;
    "update:calculateSortValue": null;
    "update:caption": null;
    "update:cellTemplate": null;
    "update:cssClass": null;
    "update:customizeText": null;
    "update:dataField": null;
    "update:dataType": null;
    "update:encodeHtml": null;
    "update:falseText": null;
    "update:filterOperations": null;
    "update:filterType": null;
    "update:filterValue": null;
    "update:filterValues": null;
    "update:format": null;
    "update:headerCellTemplate": null;
    "update:headerFilter": null;
    "update:minWidth": null;
    "update:selectedFilterOperation": null;
    "update:sortIndex": null;
    "update:sortingMethod": null;
    "update:sortOrder": null;
    "update:trueText": null;
    "update:visible": null;
    "update:visibleIndex": null;
    "update:width": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    alignment: PropType<HorizontalAlignment>;
    allowFiltering: BooleanConstructor;
    allowHeaderFiltering: BooleanConstructor;
    allowSorting: BooleanConstructor;
    calculateCellValue: PropType<(rowData: any) => any>;
    calculateDisplayValue: PropType<string | ((rowData: any) => any)>;
    calculateFilterExpression: PropType<(filterValue: any, selectedFilterOperation: string | null, target: string) => string | (() => any) | Array<any>>;
    calculateSortValue: PropType<string | ((rowData: any) => any)>;
    caption: StringConstructor;
    cellTemplate: {};
    cssClass: StringConstructor;
    customizeText: PropType<(cellInfo: {
        groupInterval: string | number;
        target: string;
        value: any;
        valueText: string;
    }) => string>;
    dataField: StringConstructor;
    dataType: PropType<DataType>;
    encodeHtml: BooleanConstructor;
    falseText: StringConstructor;
    filterOperations: PropType<string[]>;
    filterType: PropType<FilterType>;
    filterValue: {};
    filterValues: PropType<any[]>;
    format: PropType<string | Record<string, any> | import("devextreme/common/core/localization").FormatObject | ((value: number | Date) => string) | ((value: Date) => string) | ((value: number) => string) | Intl.DateTimeFormatOptions | Intl.NumberFormatOptions | ((value: number | Date) => string) | undefined>;
    headerCellTemplate: {};
    headerFilter: PropType<Record<string, any> | ColumnHeaderFilter>;
    minWidth: NumberConstructor;
    selectedFilterOperation: PropType<SelectedFilterOperation>;
    sortIndex: NumberConstructor;
    sortingMethod: PropType<(value1: any, value2: any) => number>;
    sortOrder: PropType<SortOrder>;
    trueText: StringConstructor;
    visible: BooleanConstructor;
    visibleIndex: NumberConstructor;
    width: (NumberConstructor | StringConstructor)[];
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:encodeHtml"?: ((...args: any[]) => any) | undefined;
    "onUpdate:width"?: ((...args: any[]) => any) | undefined;
    "onUpdate:visible"?: ((...args: any[]) => any) | undefined;
    "onUpdate:dataField"?: ((...args: any[]) => any) | undefined;
    "onUpdate:customizeText"?: ((...args: any[]) => any) | undefined;
    "onUpdate:format"?: ((...args: any[]) => any) | undefined;
    "onUpdate:filterValue"?: ((...args: any[]) => any) | undefined;
    "onUpdate:headerFilter"?: ((...args: any[]) => any) | undefined;
    "onUpdate:cssClass"?: ((...args: any[]) => any) | undefined;
    "onUpdate:visibleIndex"?: ((...args: any[]) => any) | undefined;
    "onUpdate:alignment"?: ((...args: any[]) => any) | undefined;
    "onUpdate:allowFiltering"?: ((...args: any[]) => any) | undefined;
    "onUpdate:allowHeaderFiltering"?: ((...args: any[]) => any) | undefined;
    "onUpdate:allowSorting"?: ((...args: any[]) => any) | undefined;
    "onUpdate:calculateCellValue"?: ((...args: any[]) => any) | undefined;
    "onUpdate:calculateDisplayValue"?: ((...args: any[]) => any) | undefined;
    "onUpdate:calculateFilterExpression"?: ((...args: any[]) => any) | undefined;
    "onUpdate:calculateSortValue"?: ((...args: any[]) => any) | undefined;
    "onUpdate:caption"?: ((...args: any[]) => any) | undefined;
    "onUpdate:cellTemplate"?: ((...args: any[]) => any) | undefined;
    "onUpdate:dataType"?: ((...args: any[]) => any) | undefined;
    "onUpdate:falseText"?: ((...args: any[]) => any) | undefined;
    "onUpdate:filterOperations"?: ((...args: any[]) => any) | undefined;
    "onUpdate:filterType"?: ((...args: any[]) => any) | undefined;
    "onUpdate:filterValues"?: ((...args: any[]) => any) | undefined;
    "onUpdate:headerCellTemplate"?: ((...args: any[]) => any) | undefined;
    "onUpdate:minWidth"?: ((...args: any[]) => any) | undefined;
    "onUpdate:selectedFilterOperation"?: ((...args: any[]) => any) | undefined;
    "onUpdate:sortIndex"?: ((...args: any[]) => any) | undefined;
    "onUpdate:sortingMethod"?: ((...args: any[]) => any) | undefined;
    "onUpdate:sortOrder"?: ((...args: any[]) => any) | undefined;
    "onUpdate:trueText"?: ((...args: any[]) => any) | undefined;
}, {
    encodeHtml: boolean;
    visible: boolean;
    allowFiltering: boolean;
    allowHeaderFiltering: boolean;
    allowSorting: boolean;
}>;
declare const DxColumnHeaderFilter: import("vue").DefineComponent<{
    allowSearch: BooleanConstructor;
    allowSelectAll: BooleanConstructor;
    dataSource: PropType<any[] | Record<string, any> | DataSourceOptions<any, any, any, any> | Store<any, any> | ((options: {
        component: Record<string, any>;
        dataSource: DataSourceOptions | null;
    }) => void) | null>;
    groupInterval: PropType<number | (string | number)[] | HeaderFilterGroupInterval>;
    height: (NumberConstructor | StringConstructor)[];
    search: PropType<Record<string, any> | HeaderFilterSearchConfig | ColumnHeaderFilterSearchConfig>;
    searchMode: PropType<SearchMode>;
    width: (NumberConstructor | StringConstructor)[];
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:allowSearch": null;
    "update:allowSelectAll": null;
    "update:dataSource": null;
    "update:groupInterval": null;
    "update:height": null;
    "update:search": null;
    "update:searchMode": null;
    "update:width": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    allowSearch: BooleanConstructor;
    allowSelectAll: BooleanConstructor;
    dataSource: PropType<any[] | Record<string, any> | DataSourceOptions<any, any, any, any> | Store<any, any> | ((options: {
        component: Record<string, any>;
        dataSource: DataSourceOptions | null;
    }) => void) | null>;
    groupInterval: PropType<number | (string | number)[] | HeaderFilterGroupInterval>;
    height: (NumberConstructor | StringConstructor)[];
    search: PropType<Record<string, any> | HeaderFilterSearchConfig | ColumnHeaderFilterSearchConfig>;
    searchMode: PropType<SearchMode>;
    width: (NumberConstructor | StringConstructor)[];
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:height"?: ((...args: any[]) => any) | undefined;
    "onUpdate:width"?: ((...args: any[]) => any) | undefined;
    "onUpdate:dataSource"?: ((...args: any[]) => any) | undefined;
    "onUpdate:searchMode"?: ((...args: any[]) => any) | undefined;
    "onUpdate:allowSearch"?: ((...args: any[]) => any) | undefined;
    "onUpdate:search"?: ((...args: any[]) => any) | undefined;
    "onUpdate:allowSelectAll"?: ((...args: any[]) => any) | undefined;
    "onUpdate:groupInterval"?: ((...args: any[]) => any) | undefined;
}, {
    allowSearch: boolean;
    allowSelectAll: boolean;
}>;
declare const DxColumnHeaderFilterSearch: import("vue").DefineComponent<{
    editorOptions: {};
    enabled: BooleanConstructor;
    mode: PropType<SearchMode>;
    searchExpr: PropType<string | (string | (() => any))[] | (() => any)>;
    timeout: NumberConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:editorOptions": null;
    "update:enabled": null;
    "update:mode": null;
    "update:searchExpr": null;
    "update:timeout": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    editorOptions: {};
    enabled: BooleanConstructor;
    mode: PropType<SearchMode>;
    searchExpr: PropType<string | (string | (() => any))[] | (() => any)>;
    timeout: NumberConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:enabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:searchExpr"?: ((...args: any[]) => any) | undefined;
    "onUpdate:mode"?: ((...args: any[]) => any) | undefined;
    "onUpdate:editorOptions"?: ((...args: any[]) => any) | undefined;
    "onUpdate:timeout"?: ((...args: any[]) => any) | undefined;
}, {
    enabled: boolean;
}>;
declare const DxContextMenu: import("vue").DefineComponent<{
    enabled: BooleanConstructor;
    items: PropType<(dxGanttContextMenuItem | GanttPredefinedContextMenuItem)[]>;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:enabled": null;
    "update:items": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    enabled: BooleanConstructor;
    items: PropType<(dxGanttContextMenuItem | GanttPredefinedContextMenuItem)[]>;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:enabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:items"?: ((...args: any[]) => any) | undefined;
}, {
    enabled: boolean;
}>;
declare const DxContextMenuItem: import("vue").DefineComponent<{
    beginGroup: BooleanConstructor;
    closeMenuOnClick: BooleanConstructor;
    disabled: BooleanConstructor;
    icon: StringConstructor;
    items: PropType<dxContextMenuItem[]>;
    name: PropType<string>;
    selectable: BooleanConstructor;
    selected: BooleanConstructor;
    template: {};
    text: StringConstructor;
    visible: BooleanConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:beginGroup": null;
    "update:closeMenuOnClick": null;
    "update:disabled": null;
    "update:icon": null;
    "update:items": null;
    "update:name": null;
    "update:selectable": null;
    "update:selected": null;
    "update:template": null;
    "update:text": null;
    "update:visible": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    beginGroup: BooleanConstructor;
    closeMenuOnClick: BooleanConstructor;
    disabled: BooleanConstructor;
    icon: StringConstructor;
    items: PropType<dxContextMenuItem[]>;
    name: PropType<string>;
    selectable: BooleanConstructor;
    selected: BooleanConstructor;
    template: {};
    text: StringConstructor;
    visible: BooleanConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:disabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:name"?: ((...args: any[]) => any) | undefined;
    "onUpdate:template"?: ((...args: any[]) => any) | undefined;
    "onUpdate:text"?: ((...args: any[]) => any) | undefined;
    "onUpdate:visible"?: ((...args: any[]) => any) | undefined;
    "onUpdate:items"?: ((...args: any[]) => any) | undefined;
    "onUpdate:icon"?: ((...args: any[]) => any) | undefined;
    "onUpdate:selected"?: ((...args: any[]) => any) | undefined;
    "onUpdate:beginGroup"?: ((...args: any[]) => any) | undefined;
    "onUpdate:closeMenuOnClick"?: ((...args: any[]) => any) | undefined;
    "onUpdate:selectable"?: ((...args: any[]) => any) | undefined;
}, {
    disabled: boolean;
    visible: boolean;
    selected: boolean;
    beginGroup: boolean;
    closeMenuOnClick: boolean;
    selectable: boolean;
}>;
declare const DxContextMenuItemItem: import("vue").DefineComponent<{
    beginGroup: BooleanConstructor;
    closeMenuOnClick: BooleanConstructor;
    disabled: BooleanConstructor;
    icon: StringConstructor;
    items: PropType<dxContextMenuItem[]>;
    selectable: BooleanConstructor;
    selected: BooleanConstructor;
    template: {};
    text: StringConstructor;
    visible: BooleanConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:beginGroup": null;
    "update:closeMenuOnClick": null;
    "update:disabled": null;
    "update:icon": null;
    "update:items": null;
    "update:selectable": null;
    "update:selected": null;
    "update:template": null;
    "update:text": null;
    "update:visible": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    beginGroup: BooleanConstructor;
    closeMenuOnClick: BooleanConstructor;
    disabled: BooleanConstructor;
    icon: StringConstructor;
    items: PropType<dxContextMenuItem[]>;
    selectable: BooleanConstructor;
    selected: BooleanConstructor;
    template: {};
    text: StringConstructor;
    visible: BooleanConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:disabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:template"?: ((...args: any[]) => any) | undefined;
    "onUpdate:text"?: ((...args: any[]) => any) | undefined;
    "onUpdate:visible"?: ((...args: any[]) => any) | undefined;
    "onUpdate:items"?: ((...args: any[]) => any) | undefined;
    "onUpdate:icon"?: ((...args: any[]) => any) | undefined;
    "onUpdate:selected"?: ((...args: any[]) => any) | undefined;
    "onUpdate:beginGroup"?: ((...args: any[]) => any) | undefined;
    "onUpdate:closeMenuOnClick"?: ((...args: any[]) => any) | undefined;
    "onUpdate:selectable"?: ((...args: any[]) => any) | undefined;
}, {
    disabled: boolean;
    visible: boolean;
    selected: boolean;
    beginGroup: boolean;
    closeMenuOnClick: boolean;
    selectable: boolean;
}>;
declare const DxDependencies: import("vue").DefineComponent<{
    dataSource: PropType<string | any[] | Record<string, any> | DataSource<any, any> | DataSourceOptions<any, any, any, any> | Store<any, any> | null>;
    keyExpr: PropType<string | ((dependency: any) => any)>;
    predecessorIdExpr: PropType<string | ((dependency: any, value: any) => any)>;
    successorIdExpr: PropType<string | ((dependency: any, value: any) => any)>;
    typeExpr: PropType<string | ((dependency: any, value: any) => any)>;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:dataSource": null;
    "update:keyExpr": null;
    "update:predecessorIdExpr": null;
    "update:successorIdExpr": null;
    "update:typeExpr": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    dataSource: PropType<string | any[] | Record<string, any> | DataSource<any, any> | DataSourceOptions<any, any, any, any> | Store<any, any> | null>;
    keyExpr: PropType<string | ((dependency: any) => any)>;
    predecessorIdExpr: PropType<string | ((dependency: any, value: any) => any)>;
    successorIdExpr: PropType<string | ((dependency: any, value: any) => any)>;
    typeExpr: PropType<string | ((dependency: any, value: any) => any)>;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:dataSource"?: ((...args: any[]) => any) | undefined;
    "onUpdate:keyExpr"?: ((...args: any[]) => any) | undefined;
    "onUpdate:typeExpr"?: ((...args: any[]) => any) | undefined;
    "onUpdate:predecessorIdExpr"?: ((...args: any[]) => any) | undefined;
    "onUpdate:successorIdExpr"?: ((...args: any[]) => any) | undefined;
}, {}>;
declare const DxEditing: import("vue").DefineComponent<{
    allowDependencyAdding: BooleanConstructor;
    allowDependencyDeleting: BooleanConstructor;
    allowResourceAdding: BooleanConstructor;
    allowResourceDeleting: BooleanConstructor;
    allowResourceUpdating: BooleanConstructor;
    allowTaskAdding: BooleanConstructor;
    allowTaskDeleting: BooleanConstructor;
    allowTaskResourceUpdating: BooleanConstructor;
    allowTaskUpdating: BooleanConstructor;
    enabled: BooleanConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:allowDependencyAdding": null;
    "update:allowDependencyDeleting": null;
    "update:allowResourceAdding": null;
    "update:allowResourceDeleting": null;
    "update:allowResourceUpdating": null;
    "update:allowTaskAdding": null;
    "update:allowTaskDeleting": null;
    "update:allowTaskResourceUpdating": null;
    "update:allowTaskUpdating": null;
    "update:enabled": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    allowDependencyAdding: BooleanConstructor;
    allowDependencyDeleting: BooleanConstructor;
    allowResourceAdding: BooleanConstructor;
    allowResourceDeleting: BooleanConstructor;
    allowResourceUpdating: BooleanConstructor;
    allowTaskAdding: BooleanConstructor;
    allowTaskDeleting: BooleanConstructor;
    allowTaskResourceUpdating: BooleanConstructor;
    allowTaskUpdating: BooleanConstructor;
    enabled: BooleanConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:enabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:allowDependencyAdding"?: ((...args: any[]) => any) | undefined;
    "onUpdate:allowDependencyDeleting"?: ((...args: any[]) => any) | undefined;
    "onUpdate:allowResourceAdding"?: ((...args: any[]) => any) | undefined;
    "onUpdate:allowResourceDeleting"?: ((...args: any[]) => any) | undefined;
    "onUpdate:allowResourceUpdating"?: ((...args: any[]) => any) | undefined;
    "onUpdate:allowTaskAdding"?: ((...args: any[]) => any) | undefined;
    "onUpdate:allowTaskDeleting"?: ((...args: any[]) => any) | undefined;
    "onUpdate:allowTaskResourceUpdating"?: ((...args: any[]) => any) | undefined;
    "onUpdate:allowTaskUpdating"?: ((...args: any[]) => any) | undefined;
}, {
    enabled: boolean;
    allowDependencyAdding: boolean;
    allowDependencyDeleting: boolean;
    allowResourceAdding: boolean;
    allowResourceDeleting: boolean;
    allowResourceUpdating: boolean;
    allowTaskAdding: boolean;
    allowTaskDeleting: boolean;
    allowTaskResourceUpdating: boolean;
    allowTaskUpdating: boolean;
}>;
declare const DxFilterRow: import("vue").DefineComponent<{
    betweenEndText: StringConstructor;
    betweenStartText: StringConstructor;
    operationDescriptions: PropType<Record<string, any> | dxGanttFilterRowOperationDescriptions>;
    resetOperationText: StringConstructor;
    showAllText: StringConstructor;
    showOperationChooser: BooleanConstructor;
    visible: BooleanConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:betweenEndText": null;
    "update:betweenStartText": null;
    "update:operationDescriptions": null;
    "update:resetOperationText": null;
    "update:showAllText": null;
    "update:showOperationChooser": null;
    "update:visible": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    betweenEndText: StringConstructor;
    betweenStartText: StringConstructor;
    operationDescriptions: PropType<Record<string, any> | dxGanttFilterRowOperationDescriptions>;
    resetOperationText: StringConstructor;
    showAllText: StringConstructor;
    showOperationChooser: BooleanConstructor;
    visible: BooleanConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:visible"?: ((...args: any[]) => any) | undefined;
    "onUpdate:betweenEndText"?: ((...args: any[]) => any) | undefined;
    "onUpdate:betweenStartText"?: ((...args: any[]) => any) | undefined;
    "onUpdate:operationDescriptions"?: ((...args: any[]) => any) | undefined;
    "onUpdate:resetOperationText"?: ((...args: any[]) => any) | undefined;
    "onUpdate:showAllText"?: ((...args: any[]) => any) | undefined;
    "onUpdate:showOperationChooser"?: ((...args: any[]) => any) | undefined;
}, {
    visible: boolean;
    showOperationChooser: boolean;
}>;
declare const DxFormat: import("vue").DefineComponent<{
    currency: StringConstructor;
    formatter: PropType<(value: number | Date) => string>;
    parser: PropType<(value: string) => number | Date>;
    precision: NumberConstructor;
    type: PropType<string>;
    useCurrencyAccountingStyle: BooleanConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:currency": null;
    "update:formatter": null;
    "update:parser": null;
    "update:precision": null;
    "update:type": null;
    "update:useCurrencyAccountingStyle": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    currency: StringConstructor;
    formatter: PropType<(value: number | Date) => string>;
    parser: PropType<(value: string) => number | Date>;
    precision: NumberConstructor;
    type: PropType<string>;
    useCurrencyAccountingStyle: BooleanConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:type"?: ((...args: any[]) => any) | undefined;
    "onUpdate:currency"?: ((...args: any[]) => any) | undefined;
    "onUpdate:formatter"?: ((...args: any[]) => any) | undefined;
    "onUpdate:parser"?: ((...args: any[]) => any) | undefined;
    "onUpdate:precision"?: ((...args: any[]) => any) | undefined;
    "onUpdate:useCurrencyAccountingStyle"?: ((...args: any[]) => any) | undefined;
}, {
    useCurrencyAccountingStyle: boolean;
}>;
declare const DxGanttHeaderFilter: import("vue").DefineComponent<{
    allowSearch: BooleanConstructor;
    allowSelectAll: BooleanConstructor;
    height: NumberConstructor;
    search: PropType<Record<string, any> | HeaderFilterSearchConfig>;
    searchTimeout: NumberConstructor;
    texts: PropType<Record<string, any> | dxGanttHeaderFilterTexts>;
    visible: BooleanConstructor;
    width: NumberConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:allowSearch": null;
    "update:allowSelectAll": null;
    "update:height": null;
    "update:search": null;
    "update:searchTimeout": null;
    "update:texts": null;
    "update:visible": null;
    "update:width": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    allowSearch: BooleanConstructor;
    allowSelectAll: BooleanConstructor;
    height: NumberConstructor;
    search: PropType<Record<string, any> | HeaderFilterSearchConfig>;
    searchTimeout: NumberConstructor;
    texts: PropType<Record<string, any> | dxGanttHeaderFilterTexts>;
    visible: BooleanConstructor;
    width: NumberConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:height"?: ((...args: any[]) => any) | undefined;
    "onUpdate:width"?: ((...args: any[]) => any) | undefined;
    "onUpdate:visible"?: ((...args: any[]) => any) | undefined;
    "onUpdate:searchTimeout"?: ((...args: any[]) => any) | undefined;
    "onUpdate:allowSearch"?: ((...args: any[]) => any) | undefined;
    "onUpdate:search"?: ((...args: any[]) => any) | undefined;
    "onUpdate:allowSelectAll"?: ((...args: any[]) => any) | undefined;
    "onUpdate:texts"?: ((...args: any[]) => any) | undefined;
}, {
    visible: boolean;
    allowSearch: boolean;
    allowSelectAll: boolean;
}>;
declare const DxGanttHeaderFilterSearch: import("vue").DefineComponent<{
    editorOptions: {};
    enabled: BooleanConstructor;
    mode: PropType<SearchMode>;
    timeout: NumberConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:editorOptions": null;
    "update:enabled": null;
    "update:mode": null;
    "update:timeout": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    editorOptions: {};
    enabled: BooleanConstructor;
    mode: PropType<SearchMode>;
    timeout: NumberConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:enabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:mode"?: ((...args: any[]) => any) | undefined;
    "onUpdate:editorOptions"?: ((...args: any[]) => any) | undefined;
    "onUpdate:timeout"?: ((...args: any[]) => any) | undefined;
}, {
    enabled: boolean;
}>;
declare const DxHeaderFilter: import("vue").DefineComponent<{
    allowSearch: BooleanConstructor;
    allowSelectAll: BooleanConstructor;
    dataSource: PropType<any[] | Record<string, any> | DataSourceOptions<any, any, any, any> | Store<any, any> | ((options: {
        component: Record<string, any>;
        dataSource: DataSourceOptions | null;
    }) => void) | null>;
    groupInterval: PropType<number | (string | number)[] | HeaderFilterGroupInterval>;
    height: (NumberConstructor | StringConstructor)[];
    search: PropType<Record<string, any> | HeaderFilterSearchConfig | ColumnHeaderFilterSearchConfig>;
    searchMode: PropType<SearchMode>;
    searchTimeout: NumberConstructor;
    texts: PropType<Record<string, any> | dxGanttHeaderFilterTexts>;
    visible: BooleanConstructor;
    width: (NumberConstructor | StringConstructor)[];
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:allowSearch": null;
    "update:allowSelectAll": null;
    "update:dataSource": null;
    "update:groupInterval": null;
    "update:height": null;
    "update:search": null;
    "update:searchMode": null;
    "update:searchTimeout": null;
    "update:texts": null;
    "update:visible": null;
    "update:width": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    allowSearch: BooleanConstructor;
    allowSelectAll: BooleanConstructor;
    dataSource: PropType<any[] | Record<string, any> | DataSourceOptions<any, any, any, any> | Store<any, any> | ((options: {
        component: Record<string, any>;
        dataSource: DataSourceOptions | null;
    }) => void) | null>;
    groupInterval: PropType<number | (string | number)[] | HeaderFilterGroupInterval>;
    height: (NumberConstructor | StringConstructor)[];
    search: PropType<Record<string, any> | HeaderFilterSearchConfig | ColumnHeaderFilterSearchConfig>;
    searchMode: PropType<SearchMode>;
    searchTimeout: NumberConstructor;
    texts: PropType<Record<string, any> | dxGanttHeaderFilterTexts>;
    visible: BooleanConstructor;
    width: (NumberConstructor | StringConstructor)[];
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:height"?: ((...args: any[]) => any) | undefined;
    "onUpdate:width"?: ((...args: any[]) => any) | undefined;
    "onUpdate:visible"?: ((...args: any[]) => any) | undefined;
    "onUpdate:dataSource"?: ((...args: any[]) => any) | undefined;
    "onUpdate:searchMode"?: ((...args: any[]) => any) | undefined;
    "onUpdate:searchTimeout"?: ((...args: any[]) => any) | undefined;
    "onUpdate:allowSearch"?: ((...args: any[]) => any) | undefined;
    "onUpdate:search"?: ((...args: any[]) => any) | undefined;
    "onUpdate:allowSelectAll"?: ((...args: any[]) => any) | undefined;
    "onUpdate:texts"?: ((...args: any[]) => any) | undefined;
    "onUpdate:groupInterval"?: ((...args: any[]) => any) | undefined;
}, {
    visible: boolean;
    allowSearch: boolean;
    allowSelectAll: boolean;
}>;
declare const DxItem: import("vue").DefineComponent<{
    beginGroup: BooleanConstructor;
    closeMenuOnClick: BooleanConstructor;
    cssClass: StringConstructor;
    disabled: BooleanConstructor;
    html: StringConstructor;
    icon: StringConstructor;
    items: PropType<dxContextMenuItem[]>;
    locateInMenu: PropType<LocateInMenuMode>;
    location: PropType<ToolbarItemLocation>;
    menuItemTemplate: {};
    name: PropType<string>;
    options: {};
    selectable: BooleanConstructor;
    selected: BooleanConstructor;
    showText: PropType<ShowTextMode>;
    template: {};
    text: StringConstructor;
    visible: BooleanConstructor;
    widget: PropType<ToolbarItemComponent>;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:beginGroup": null;
    "update:closeMenuOnClick": null;
    "update:cssClass": null;
    "update:disabled": null;
    "update:html": null;
    "update:icon": null;
    "update:items": null;
    "update:locateInMenu": null;
    "update:location": null;
    "update:menuItemTemplate": null;
    "update:name": null;
    "update:options": null;
    "update:selectable": null;
    "update:selected": null;
    "update:showText": null;
    "update:template": null;
    "update:text": null;
    "update:visible": null;
    "update:widget": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    beginGroup: BooleanConstructor;
    closeMenuOnClick: BooleanConstructor;
    cssClass: StringConstructor;
    disabled: BooleanConstructor;
    html: StringConstructor;
    icon: StringConstructor;
    items: PropType<dxContextMenuItem[]>;
    locateInMenu: PropType<LocateInMenuMode>;
    location: PropType<ToolbarItemLocation>;
    menuItemTemplate: {};
    name: PropType<string>;
    options: {};
    selectable: BooleanConstructor;
    selected: BooleanConstructor;
    showText: PropType<ShowTextMode>;
    template: {};
    text: StringConstructor;
    visible: BooleanConstructor;
    widget: PropType<ToolbarItemComponent>;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:disabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:name"?: ((...args: any[]) => any) | undefined;
    "onUpdate:template"?: ((...args: any[]) => any) | undefined;
    "onUpdate:text"?: ((...args: any[]) => any) | undefined;
    "onUpdate:visible"?: ((...args: any[]) => any) | undefined;
    "onUpdate:items"?: ((...args: any[]) => any) | undefined;
    "onUpdate:html"?: ((...args: any[]) => any) | undefined;
    "onUpdate:location"?: ((...args: any[]) => any) | undefined;
    "onUpdate:options"?: ((...args: any[]) => any) | undefined;
    "onUpdate:icon"?: ((...args: any[]) => any) | undefined;
    "onUpdate:selected"?: ((...args: any[]) => any) | undefined;
    "onUpdate:cssClass"?: ((...args: any[]) => any) | undefined;
    "onUpdate:locateInMenu"?: ((...args: any[]) => any) | undefined;
    "onUpdate:menuItemTemplate"?: ((...args: any[]) => any) | undefined;
    "onUpdate:showText"?: ((...args: any[]) => any) | undefined;
    "onUpdate:widget"?: ((...args: any[]) => any) | undefined;
    "onUpdate:beginGroup"?: ((...args: any[]) => any) | undefined;
    "onUpdate:closeMenuOnClick"?: ((...args: any[]) => any) | undefined;
    "onUpdate:selectable"?: ((...args: any[]) => any) | undefined;
}, {
    disabled: boolean;
    visible: boolean;
    selected: boolean;
    beginGroup: boolean;
    closeMenuOnClick: boolean;
    selectable: boolean;
}>;
declare const DxOperationDescriptions: import("vue").DefineComponent<{
    between: StringConstructor;
    contains: StringConstructor;
    endsWith: StringConstructor;
    equal: StringConstructor;
    greaterThan: StringConstructor;
    greaterThanOrEqual: StringConstructor;
    lessThan: StringConstructor;
    lessThanOrEqual: StringConstructor;
    notContains: StringConstructor;
    notEqual: StringConstructor;
    startsWith: StringConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:between": null;
    "update:contains": null;
    "update:endsWith": null;
    "update:equal": null;
    "update:greaterThan": null;
    "update:greaterThanOrEqual": null;
    "update:lessThan": null;
    "update:lessThanOrEqual": null;
    "update:notContains": null;
    "update:notEqual": null;
    "update:startsWith": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    between: StringConstructor;
    contains: StringConstructor;
    endsWith: StringConstructor;
    equal: StringConstructor;
    greaterThan: StringConstructor;
    greaterThanOrEqual: StringConstructor;
    lessThan: StringConstructor;
    lessThanOrEqual: StringConstructor;
    notContains: StringConstructor;
    notEqual: StringConstructor;
    startsWith: StringConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:between"?: ((...args: any[]) => any) | undefined;
    "onUpdate:contains"?: ((...args: any[]) => any) | undefined;
    "onUpdate:endsWith"?: ((...args: any[]) => any) | undefined;
    "onUpdate:equal"?: ((...args: any[]) => any) | undefined;
    "onUpdate:greaterThan"?: ((...args: any[]) => any) | undefined;
    "onUpdate:greaterThanOrEqual"?: ((...args: any[]) => any) | undefined;
    "onUpdate:lessThan"?: ((...args: any[]) => any) | undefined;
    "onUpdate:lessThanOrEqual"?: ((...args: any[]) => any) | undefined;
    "onUpdate:notContains"?: ((...args: any[]) => any) | undefined;
    "onUpdate:notEqual"?: ((...args: any[]) => any) | undefined;
    "onUpdate:startsWith"?: ((...args: any[]) => any) | undefined;
}, {}>;
declare const DxResourceAssignments: import("vue").DefineComponent<{
    dataSource: PropType<string | any[] | Record<string, any> | DataSource<any, any> | DataSourceOptions<any, any, any, any> | Store<any, any> | null>;
    keyExpr: PropType<string | ((resourceAssignment: any) => any)>;
    resourceIdExpr: PropType<string | ((resourceAssignment: any, value: any) => any)>;
    taskIdExpr: PropType<string | ((resourceAssignment: any, value: any) => any)>;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:dataSource": null;
    "update:keyExpr": null;
    "update:resourceIdExpr": null;
    "update:taskIdExpr": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    dataSource: PropType<string | any[] | Record<string, any> | DataSource<any, any> | DataSourceOptions<any, any, any, any> | Store<any, any> | null>;
    keyExpr: PropType<string | ((resourceAssignment: any) => any)>;
    resourceIdExpr: PropType<string | ((resourceAssignment: any, value: any) => any)>;
    taskIdExpr: PropType<string | ((resourceAssignment: any, value: any) => any)>;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:dataSource"?: ((...args: any[]) => any) | undefined;
    "onUpdate:keyExpr"?: ((...args: any[]) => any) | undefined;
    "onUpdate:resourceIdExpr"?: ((...args: any[]) => any) | undefined;
    "onUpdate:taskIdExpr"?: ((...args: any[]) => any) | undefined;
}, {}>;
declare const DxResources: import("vue").DefineComponent<{
    colorExpr: PropType<string | ((resource: any, value: any) => any)>;
    dataSource: PropType<string | any[] | Record<string, any> | DataSource<any, any> | DataSourceOptions<any, any, any, any> | Store<any, any> | null>;
    keyExpr: PropType<string | ((resource: any) => any)>;
    textExpr: PropType<string | ((resource: any, value: any) => string)>;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:colorExpr": null;
    "update:dataSource": null;
    "update:keyExpr": null;
    "update:textExpr": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    colorExpr: PropType<string | ((resource: any, value: any) => any)>;
    dataSource: PropType<string | any[] | Record<string, any> | DataSource<any, any> | DataSourceOptions<any, any, any, any> | Store<any, any> | null>;
    keyExpr: PropType<string | ((resource: any) => any)>;
    textExpr: PropType<string | ((resource: any, value: any) => string)>;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:dataSource"?: ((...args: any[]) => any) | undefined;
    "onUpdate:keyExpr"?: ((...args: any[]) => any) | undefined;
    "onUpdate:textExpr"?: ((...args: any[]) => any) | undefined;
    "onUpdate:colorExpr"?: ((...args: any[]) => any) | undefined;
}, {}>;
declare const DxScaleTypeRange: import("vue").DefineComponent<{
    max: PropType<GanttScaleType>;
    min: PropType<GanttScaleType>;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:max": null;
    "update:min": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    max: PropType<GanttScaleType>;
    min: PropType<GanttScaleType>;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:max"?: ((...args: any[]) => any) | undefined;
    "onUpdate:min"?: ((...args: any[]) => any) | undefined;
}, {}>;
declare const DxSearch: import("vue").DefineComponent<{
    editorOptions: {};
    enabled: BooleanConstructor;
    mode: PropType<SearchMode>;
    searchExpr: PropType<string | (string | (() => any))[] | (() => any)>;
    timeout: NumberConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:editorOptions": null;
    "update:enabled": null;
    "update:mode": null;
    "update:searchExpr": null;
    "update:timeout": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    editorOptions: {};
    enabled: BooleanConstructor;
    mode: PropType<SearchMode>;
    searchExpr: PropType<string | (string | (() => any))[] | (() => any)>;
    timeout: NumberConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:enabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:searchExpr"?: ((...args: any[]) => any) | undefined;
    "onUpdate:mode"?: ((...args: any[]) => any) | undefined;
    "onUpdate:editorOptions"?: ((...args: any[]) => any) | undefined;
    "onUpdate:timeout"?: ((...args: any[]) => any) | undefined;
}, {
    enabled: boolean;
}>;
declare const DxSorting: import("vue").DefineComponent<{
    ascendingText: StringConstructor;
    clearText: StringConstructor;
    descendingText: StringConstructor;
    mode: PropType<string>;
    showSortIndexes: BooleanConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:ascendingText": null;
    "update:clearText": null;
    "update:descendingText": null;
    "update:mode": null;
    "update:showSortIndexes": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    ascendingText: StringConstructor;
    clearText: StringConstructor;
    descendingText: StringConstructor;
    mode: PropType<string>;
    showSortIndexes: BooleanConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:mode"?: ((...args: any[]) => any) | undefined;
    "onUpdate:ascendingText"?: ((...args: any[]) => any) | undefined;
    "onUpdate:clearText"?: ((...args: any[]) => any) | undefined;
    "onUpdate:descendingText"?: ((...args: any[]) => any) | undefined;
    "onUpdate:showSortIndexes"?: ((...args: any[]) => any) | undefined;
}, {
    showSortIndexes: boolean;
}>;
declare const DxStripLine: import("vue").DefineComponent<{
    cssClass: StringConstructor;
    end: PropType<string | number | Date | (() => Date | number | string)>;
    start: PropType<string | number | Date | (() => Date | number | string)>;
    title: StringConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:cssClass": null;
    "update:end": null;
    "update:start": null;
    "update:title": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    cssClass: StringConstructor;
    end: PropType<string | number | Date | (() => Date | number | string)>;
    start: PropType<string | number | Date | (() => Date | number | string)>;
    title: StringConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:title"?: ((...args: any[]) => any) | undefined;
    "onUpdate:cssClass"?: ((...args: any[]) => any) | undefined;
    "onUpdate:start"?: ((...args: any[]) => any) | undefined;
    "onUpdate:end"?: ((...args: any[]) => any) | undefined;
}, {}>;
declare const DxTasks: import("vue").DefineComponent<{
    colorExpr: PropType<string | ((task: any, value: any) => any)>;
    dataSource: PropType<string | any[] | Record<string, any> | DataSource<any, any> | DataSourceOptions<any, any, any, any> | Store<any, any> | null>;
    endExpr: PropType<string | ((task: any, value: any) => any)>;
    keyExpr: PropType<string | ((task: any) => any)>;
    parentIdExpr: PropType<string | ((task: any, value: any) => any)>;
    progressExpr: PropType<string | ((task: any, value: any) => any)>;
    startExpr: PropType<string | ((task: any, value: any) => any)>;
    titleExpr: PropType<string | ((task: any, value: any) => any)>;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:colorExpr": null;
    "update:dataSource": null;
    "update:endExpr": null;
    "update:keyExpr": null;
    "update:parentIdExpr": null;
    "update:progressExpr": null;
    "update:startExpr": null;
    "update:titleExpr": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    colorExpr: PropType<string | ((task: any, value: any) => any)>;
    dataSource: PropType<string | any[] | Record<string, any> | DataSource<any, any> | DataSourceOptions<any, any, any, any> | Store<any, any> | null>;
    endExpr: PropType<string | ((task: any, value: any) => any)>;
    keyExpr: PropType<string | ((task: any) => any)>;
    parentIdExpr: PropType<string | ((task: any, value: any) => any)>;
    progressExpr: PropType<string | ((task: any, value: any) => any)>;
    startExpr: PropType<string | ((task: any, value: any) => any)>;
    titleExpr: PropType<string | ((task: any, value: any) => any)>;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:dataSource"?: ((...args: any[]) => any) | undefined;
    "onUpdate:keyExpr"?: ((...args: any[]) => any) | undefined;
    "onUpdate:parentIdExpr"?: ((...args: any[]) => any) | undefined;
    "onUpdate:colorExpr"?: ((...args: any[]) => any) | undefined;
    "onUpdate:endExpr"?: ((...args: any[]) => any) | undefined;
    "onUpdate:progressExpr"?: ((...args: any[]) => any) | undefined;
    "onUpdate:startExpr"?: ((...args: any[]) => any) | undefined;
    "onUpdate:titleExpr"?: ((...args: any[]) => any) | undefined;
}, {}>;
declare const DxTexts: import("vue").DefineComponent<{
    cancel: StringConstructor;
    emptyValue: StringConstructor;
    ok: StringConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:cancel": null;
    "update:emptyValue": null;
    "update:ok": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    cancel: StringConstructor;
    emptyValue: StringConstructor;
    ok: StringConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:cancel"?: ((...args: any[]) => any) | undefined;
    "onUpdate:emptyValue"?: ((...args: any[]) => any) | undefined;
    "onUpdate:ok"?: ((...args: any[]) => any) | undefined;
}, {}>;
declare const DxToolbar: import("vue").DefineComponent<{
    items: PropType<(GanttPredefinedToolbarItem | dxGanttToolbarItem)[]>;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:items": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    items: PropType<(GanttPredefinedToolbarItem | dxGanttToolbarItem)[]>;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:items"?: ((...args: any[]) => any) | undefined;
}, {}>;
declare const DxToolbarItem: import("vue").DefineComponent<{
    cssClass: StringConstructor;
    disabled: BooleanConstructor;
    html: StringConstructor;
    locateInMenu: PropType<LocateInMenuMode>;
    location: PropType<ToolbarItemLocation>;
    menuItemTemplate: {};
    name: PropType<string>;
    options: {};
    showText: PropType<ShowTextMode>;
    template: {};
    text: StringConstructor;
    visible: BooleanConstructor;
    widget: PropType<ToolbarItemComponent>;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:cssClass": null;
    "update:disabled": null;
    "update:html": null;
    "update:locateInMenu": null;
    "update:location": null;
    "update:menuItemTemplate": null;
    "update:name": null;
    "update:options": null;
    "update:showText": null;
    "update:template": null;
    "update:text": null;
    "update:visible": null;
    "update:widget": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    cssClass: StringConstructor;
    disabled: BooleanConstructor;
    html: StringConstructor;
    locateInMenu: PropType<LocateInMenuMode>;
    location: PropType<ToolbarItemLocation>;
    menuItemTemplate: {};
    name: PropType<string>;
    options: {};
    showText: PropType<ShowTextMode>;
    template: {};
    text: StringConstructor;
    visible: BooleanConstructor;
    widget: PropType<ToolbarItemComponent>;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:disabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:name"?: ((...args: any[]) => any) | undefined;
    "onUpdate:template"?: ((...args: any[]) => any) | undefined;
    "onUpdate:text"?: ((...args: any[]) => any) | undefined;
    "onUpdate:visible"?: ((...args: any[]) => any) | undefined;
    "onUpdate:html"?: ((...args: any[]) => any) | undefined;
    "onUpdate:location"?: ((...args: any[]) => any) | undefined;
    "onUpdate:options"?: ((...args: any[]) => any) | undefined;
    "onUpdate:cssClass"?: ((...args: any[]) => any) | undefined;
    "onUpdate:locateInMenu"?: ((...args: any[]) => any) | undefined;
    "onUpdate:menuItemTemplate"?: ((...args: any[]) => any) | undefined;
    "onUpdate:showText"?: ((...args: any[]) => any) | undefined;
    "onUpdate:widget"?: ((...args: any[]) => any) | undefined;
}, {
    disabled: boolean;
    visible: boolean;
}>;
declare const DxValidation: import("vue").DefineComponent<{
    autoUpdateParentTasks: BooleanConstructor;
    enablePredecessorGap: BooleanConstructor;
    validateDependencies: BooleanConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:autoUpdateParentTasks": null;
    "update:enablePredecessorGap": null;
    "update:validateDependencies": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    autoUpdateParentTasks: BooleanConstructor;
    enablePredecessorGap: BooleanConstructor;
    validateDependencies: BooleanConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:autoUpdateParentTasks"?: ((...args: any[]) => any) | undefined;
    "onUpdate:enablePredecessorGap"?: ((...args: any[]) => any) | undefined;
    "onUpdate:validateDependencies"?: ((...args: any[]) => any) | undefined;
}, {
    autoUpdateParentTasks: boolean;
    enablePredecessorGap: boolean;
    validateDependencies: boolean;
}>;
export default DxGantt;
export { DxGantt, DxColumn, DxColumnHeaderFilter, DxColumnHeaderFilterSearch, DxContextMenu, DxContextMenuItem, DxContextMenuItemItem, DxDependencies, DxEditing, DxFilterRow, DxFormat, DxGanttHeaderFilter, DxGanttHeaderFilterSearch, DxHeaderFilter, DxItem, DxOperationDescriptions, DxResourceAssignments, DxResources, DxScaleTypeRange, DxSearch, DxSorting, DxStripLine, DxTasks, DxTexts, DxToolbar, DxToolbarItem, DxValidation };
import type * as DxGanttTypes from "devextreme/ui/gantt_types";
export { DxGanttTypes };
