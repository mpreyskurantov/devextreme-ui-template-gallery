/*!
 * devextreme-vue
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

import { PropType } from "vue";
import Validator, { Properties } from "devextreme/ui/validator";
import { DisposingEvent, InitializedEvent, OptionChangedEvent, ValidatedEvent } from "devextreme/ui/validator";
import { ValidationRuleType, ComparisonOperator } from "devextreme/common";
import * as CommonTypes from "devextreme/common";
type AccessibleOptions = Pick<Properties, "adapter" | "elementAttr" | "height" | "name" | "onDisposing" | "onInitialized" | "onOptionChanged" | "onValidated" | "validationGroup" | "validationRules" | "width">;
interface DxValidator extends AccessibleOptions {
    readonly instance?: Validator;
}
declare const DxValidator: import("vue").DefineComponent<{
    adapter: PropType<Record<string, any>>;
    elementAttr: PropType<Record<string, any>>;
    height: (NumberConstructor | StringConstructor)[];
    name: StringConstructor;
    onDisposing: PropType<(e: DisposingEvent) => void>;
    onInitialized: PropType<(e: InitializedEvent) => void>;
    onOptionChanged: PropType<(e: OptionChangedEvent) => void>;
    onValidated: PropType<(validatedInfo: ValidatedEvent) => void>;
    validationGroup: StringConstructor;
    validationRules: PropType<CommonTypes.ValidationRule[]>;
    width: (NumberConstructor | StringConstructor)[];
}, unknown, unknown, {
    instance(): Validator;
}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:adapter": null;
    "update:elementAttr": null;
    "update:height": null;
    "update:name": null;
    "update:onDisposing": null;
    "update:onInitialized": null;
    "update:onOptionChanged": null;
    "update:onValidated": null;
    "update:validationGroup": null;
    "update:validationRules": null;
    "update:width": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    adapter: PropType<Record<string, any>>;
    elementAttr: PropType<Record<string, any>>;
    height: (NumberConstructor | StringConstructor)[];
    name: StringConstructor;
    onDisposing: PropType<(e: DisposingEvent) => void>;
    onInitialized: PropType<(e: InitializedEvent) => void>;
    onOptionChanged: PropType<(e: OptionChangedEvent) => void>;
    onValidated: PropType<(validatedInfo: ValidatedEvent) => void>;
    validationGroup: StringConstructor;
    validationRules: PropType<CommonTypes.ValidationRule[]>;
    width: (NumberConstructor | StringConstructor)[];
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:elementAttr"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onDisposing"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onInitialized"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onOptionChanged"?: ((...args: any[]) => any) | undefined;
    "onUpdate:height"?: ((...args: any[]) => any) | undefined;
    "onUpdate:name"?: ((...args: any[]) => any) | undefined;
    "onUpdate:width"?: ((...args: any[]) => any) | undefined;
    "onUpdate:adapter"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onValidated"?: ((...args: any[]) => any) | undefined;
    "onUpdate:validationGroup"?: ((...args: any[]) => any) | undefined;
    "onUpdate:validationRules"?: ((...args: any[]) => any) | undefined;
}, {}>;
declare const DxAdapter: import("vue").DefineComponent<{
    applyValidationResults: PropType<() => void>;
    bypass: PropType<() => void>;
    focus: PropType<() => void>;
    getValue: PropType<() => void>;
    reset: PropType<() => void>;
    validationRequestsCallbacks: PropType<(() => void)[]>;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:applyValidationResults": null;
    "update:bypass": null;
    "update:focus": null;
    "update:getValue": null;
    "update:reset": null;
    "update:validationRequestsCallbacks": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    applyValidationResults: PropType<() => void>;
    bypass: PropType<() => void>;
    focus: PropType<() => void>;
    getValue: PropType<() => void>;
    reset: PropType<() => void>;
    validationRequestsCallbacks: PropType<(() => void)[]>;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:applyValidationResults"?: ((...args: any[]) => any) | undefined;
    "onUpdate:bypass"?: ((...args: any[]) => any) | undefined;
    "onUpdate:focus"?: ((...args: any[]) => any) | undefined;
    "onUpdate:getValue"?: ((...args: any[]) => any) | undefined;
    "onUpdate:reset"?: ((...args: any[]) => any) | undefined;
    "onUpdate:validationRequestsCallbacks"?: ((...args: any[]) => any) | undefined;
}, {}>;
declare const DxAsyncRule: import("vue").DefineComponent<{
    ignoreEmptyValue: BooleanConstructor;
    message: StringConstructor;
    reevaluate: BooleanConstructor;
    type: PropType<ValidationRuleType>;
    validationCallback: PropType<(options: {
        column: Record<string, any>;
        data: Record<string, any>;
        formItem: Record<string, any>;
        rule: Record<string, any>;
        validator: Record<string, any>;
        value: any;
    }) => any>;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:ignoreEmptyValue": null;
    "update:message": null;
    "update:reevaluate": null;
    "update:type": null;
    "update:validationCallback": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    ignoreEmptyValue: BooleanConstructor;
    message: StringConstructor;
    reevaluate: BooleanConstructor;
    type: PropType<ValidationRuleType>;
    validationCallback: PropType<(options: {
        column: Record<string, any>;
        data: Record<string, any>;
        formItem: Record<string, any>;
        rule: Record<string, any>;
        validator: Record<string, any>;
        value: any;
    }) => any>;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:type"?: ((...args: any[]) => any) | undefined;
    "onUpdate:ignoreEmptyValue"?: ((...args: any[]) => any) | undefined;
    "onUpdate:message"?: ((...args: any[]) => any) | undefined;
    "onUpdate:reevaluate"?: ((...args: any[]) => any) | undefined;
    "onUpdate:validationCallback"?: ((...args: any[]) => any) | undefined;
}, {
    ignoreEmptyValue: boolean;
    reevaluate: boolean;
}>;
declare const DxCompareRule: import("vue").DefineComponent<{
    comparisonTarget: PropType<() => any>;
    comparisonType: PropType<ComparisonOperator>;
    ignoreEmptyValue: BooleanConstructor;
    message: StringConstructor;
    type: PropType<ValidationRuleType>;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:comparisonTarget": null;
    "update:comparisonType": null;
    "update:ignoreEmptyValue": null;
    "update:message": null;
    "update:type": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    comparisonTarget: PropType<() => any>;
    comparisonType: PropType<ComparisonOperator>;
    ignoreEmptyValue: BooleanConstructor;
    message: StringConstructor;
    type: PropType<ValidationRuleType>;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:type"?: ((...args: any[]) => any) | undefined;
    "onUpdate:ignoreEmptyValue"?: ((...args: any[]) => any) | undefined;
    "onUpdate:message"?: ((...args: any[]) => any) | undefined;
    "onUpdate:comparisonTarget"?: ((...args: any[]) => any) | undefined;
    "onUpdate:comparisonType"?: ((...args: any[]) => any) | undefined;
}, {
    ignoreEmptyValue: boolean;
}>;
declare const DxCustomRule: import("vue").DefineComponent<{
    ignoreEmptyValue: BooleanConstructor;
    message: StringConstructor;
    reevaluate: BooleanConstructor;
    type: PropType<ValidationRuleType>;
    validationCallback: PropType<(options: {
        column: Record<string, any>;
        data: Record<string, any>;
        formItem: Record<string, any>;
        rule: Record<string, any>;
        validator: Record<string, any>;
        value: any;
    }) => boolean>;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:ignoreEmptyValue": null;
    "update:message": null;
    "update:reevaluate": null;
    "update:type": null;
    "update:validationCallback": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    ignoreEmptyValue: BooleanConstructor;
    message: StringConstructor;
    reevaluate: BooleanConstructor;
    type: PropType<ValidationRuleType>;
    validationCallback: PropType<(options: {
        column: Record<string, any>;
        data: Record<string, any>;
        formItem: Record<string, any>;
        rule: Record<string, any>;
        validator: Record<string, any>;
        value: any;
    }) => boolean>;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:type"?: ((...args: any[]) => any) | undefined;
    "onUpdate:ignoreEmptyValue"?: ((...args: any[]) => any) | undefined;
    "onUpdate:message"?: ((...args: any[]) => any) | undefined;
    "onUpdate:reevaluate"?: ((...args: any[]) => any) | undefined;
    "onUpdate:validationCallback"?: ((...args: any[]) => any) | undefined;
}, {
    ignoreEmptyValue: boolean;
    reevaluate: boolean;
}>;
declare const DxEmailRule: import("vue").DefineComponent<{
    ignoreEmptyValue: BooleanConstructor;
    message: StringConstructor;
    type: PropType<ValidationRuleType>;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:ignoreEmptyValue": null;
    "update:message": null;
    "update:type": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    ignoreEmptyValue: BooleanConstructor;
    message: StringConstructor;
    type: PropType<ValidationRuleType>;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:type"?: ((...args: any[]) => any) | undefined;
    "onUpdate:ignoreEmptyValue"?: ((...args: any[]) => any) | undefined;
    "onUpdate:message"?: ((...args: any[]) => any) | undefined;
}, {
    ignoreEmptyValue: boolean;
}>;
declare const DxNumericRule: import("vue").DefineComponent<{
    ignoreEmptyValue: BooleanConstructor;
    message: StringConstructor;
    type: PropType<ValidationRuleType>;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:ignoreEmptyValue": null;
    "update:message": null;
    "update:type": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    ignoreEmptyValue: BooleanConstructor;
    message: StringConstructor;
    type: PropType<ValidationRuleType>;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:type"?: ((...args: any[]) => any) | undefined;
    "onUpdate:ignoreEmptyValue"?: ((...args: any[]) => any) | undefined;
    "onUpdate:message"?: ((...args: any[]) => any) | undefined;
}, {
    ignoreEmptyValue: boolean;
}>;
declare const DxPatternRule: import("vue").DefineComponent<{
    ignoreEmptyValue: BooleanConstructor;
    message: StringConstructor;
    pattern: (StringConstructor | RegExpConstructor)[];
    type: PropType<ValidationRuleType>;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:ignoreEmptyValue": null;
    "update:message": null;
    "update:pattern": null;
    "update:type": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    ignoreEmptyValue: BooleanConstructor;
    message: StringConstructor;
    pattern: (StringConstructor | RegExpConstructor)[];
    type: PropType<ValidationRuleType>;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:type"?: ((...args: any[]) => any) | undefined;
    "onUpdate:ignoreEmptyValue"?: ((...args: any[]) => any) | undefined;
    "onUpdate:message"?: ((...args: any[]) => any) | undefined;
    "onUpdate:pattern"?: ((...args: any[]) => any) | undefined;
}, {
    ignoreEmptyValue: boolean;
}>;
declare const DxRangeRule: import("vue").DefineComponent<{
    ignoreEmptyValue: BooleanConstructor;
    max: (DateConstructor | NumberConstructor | StringConstructor)[];
    message: StringConstructor;
    min: (DateConstructor | NumberConstructor | StringConstructor)[];
    reevaluate: BooleanConstructor;
    type: PropType<ValidationRuleType>;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:ignoreEmptyValue": null;
    "update:max": null;
    "update:message": null;
    "update:min": null;
    "update:reevaluate": null;
    "update:type": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    ignoreEmptyValue: BooleanConstructor;
    max: (DateConstructor | NumberConstructor | StringConstructor)[];
    message: StringConstructor;
    min: (DateConstructor | NumberConstructor | StringConstructor)[];
    reevaluate: BooleanConstructor;
    type: PropType<ValidationRuleType>;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:type"?: ((...args: any[]) => any) | undefined;
    "onUpdate:ignoreEmptyValue"?: ((...args: any[]) => any) | undefined;
    "onUpdate:message"?: ((...args: any[]) => any) | undefined;
    "onUpdate:reevaluate"?: ((...args: any[]) => any) | undefined;
    "onUpdate:max"?: ((...args: any[]) => any) | undefined;
    "onUpdate:min"?: ((...args: any[]) => any) | undefined;
}, {
    ignoreEmptyValue: boolean;
    reevaluate: boolean;
}>;
declare const DxRequiredRule: import("vue").DefineComponent<{
    message: StringConstructor;
    trim: BooleanConstructor;
    type: PropType<ValidationRuleType>;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:message": null;
    "update:trim": null;
    "update:type": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    message: StringConstructor;
    trim: BooleanConstructor;
    type: PropType<ValidationRuleType>;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:type"?: ((...args: any[]) => any) | undefined;
    "onUpdate:message"?: ((...args: any[]) => any) | undefined;
    "onUpdate:trim"?: ((...args: any[]) => any) | undefined;
}, {
    trim: boolean;
}>;
declare const DxStringLengthRule: import("vue").DefineComponent<{
    ignoreEmptyValue: BooleanConstructor;
    max: NumberConstructor;
    message: StringConstructor;
    min: NumberConstructor;
    trim: BooleanConstructor;
    type: PropType<ValidationRuleType>;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:ignoreEmptyValue": null;
    "update:max": null;
    "update:message": null;
    "update:min": null;
    "update:trim": null;
    "update:type": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    ignoreEmptyValue: BooleanConstructor;
    max: NumberConstructor;
    message: StringConstructor;
    min: NumberConstructor;
    trim: BooleanConstructor;
    type: PropType<ValidationRuleType>;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:type"?: ((...args: any[]) => any) | undefined;
    "onUpdate:ignoreEmptyValue"?: ((...args: any[]) => any) | undefined;
    "onUpdate:message"?: ((...args: any[]) => any) | undefined;
    "onUpdate:max"?: ((...args: any[]) => any) | undefined;
    "onUpdate:min"?: ((...args: any[]) => any) | undefined;
    "onUpdate:trim"?: ((...args: any[]) => any) | undefined;
}, {
    trim: boolean;
    ignoreEmptyValue: boolean;
}>;
declare const DxValidationRule: import("vue").DefineComponent<{
    comparisonTarget: PropType<() => any>;
    comparisonType: PropType<ComparisonOperator>;
    ignoreEmptyValue: BooleanConstructor;
    max: (DateConstructor | NumberConstructor | StringConstructor)[];
    message: StringConstructor;
    min: (DateConstructor | NumberConstructor | StringConstructor)[];
    pattern: (StringConstructor | RegExpConstructor)[];
    reevaluate: BooleanConstructor;
    trim: BooleanConstructor;
    type: PropType<ValidationRuleType>;
    validationCallback: PropType<(options: {
        column: Record<string, any>;
        data: Record<string, any>;
        formItem: Record<string, any>;
        rule: Record<string, any>;
        validator: Record<string, any>;
        value: any;
    }) => boolean>;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:comparisonTarget": null;
    "update:comparisonType": null;
    "update:ignoreEmptyValue": null;
    "update:max": null;
    "update:message": null;
    "update:min": null;
    "update:pattern": null;
    "update:reevaluate": null;
    "update:trim": null;
    "update:type": null;
    "update:validationCallback": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    comparisonTarget: PropType<() => any>;
    comparisonType: PropType<ComparisonOperator>;
    ignoreEmptyValue: BooleanConstructor;
    max: (DateConstructor | NumberConstructor | StringConstructor)[];
    message: StringConstructor;
    min: (DateConstructor | NumberConstructor | StringConstructor)[];
    pattern: (StringConstructor | RegExpConstructor)[];
    reevaluate: BooleanConstructor;
    trim: BooleanConstructor;
    type: PropType<ValidationRuleType>;
    validationCallback: PropType<(options: {
        column: Record<string, any>;
        data: Record<string, any>;
        formItem: Record<string, any>;
        rule: Record<string, any>;
        validator: Record<string, any>;
        value: any;
    }) => boolean>;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:type"?: ((...args: any[]) => any) | undefined;
    "onUpdate:ignoreEmptyValue"?: ((...args: any[]) => any) | undefined;
    "onUpdate:message"?: ((...args: any[]) => any) | undefined;
    "onUpdate:reevaluate"?: ((...args: any[]) => any) | undefined;
    "onUpdate:validationCallback"?: ((...args: any[]) => any) | undefined;
    "onUpdate:comparisonTarget"?: ((...args: any[]) => any) | undefined;
    "onUpdate:comparisonType"?: ((...args: any[]) => any) | undefined;
    "onUpdate:pattern"?: ((...args: any[]) => any) | undefined;
    "onUpdate:max"?: ((...args: any[]) => any) | undefined;
    "onUpdate:min"?: ((...args: any[]) => any) | undefined;
    "onUpdate:trim"?: ((...args: any[]) => any) | undefined;
}, {
    trim: boolean;
    ignoreEmptyValue: boolean;
    reevaluate: boolean;
}>;
export default DxValidator;
export { DxValidator, DxAdapter, DxAsyncRule, DxCompareRule, DxCustomRule, DxEmailRule, DxNumericRule, DxPatternRule, DxRangeRule, DxRequiredRule, DxStringLengthRule, DxValidationRule };
import type * as DxValidatorTypes from "devextreme/ui/validator_types";
export { DxValidatorTypes };
