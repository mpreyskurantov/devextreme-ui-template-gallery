/*!
 * devextreme-vue
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

import { PropType } from "vue";
import Sortable, { Properties } from "devextreme/ui/sortable";
import { DragDirection, DragHighlight, Orientation } from "devextreme/common";
import { AddEvent, DisposingEvent, DragChangeEvent, DragEndEvent, DragMoveEvent, DragStartEvent, InitializedEvent, OptionChangedEvent, RemoveEvent, ReorderEvent } from "devextreme/ui/sortable";
type AccessibleOptions = Pick<Properties, "allowDropInsideItem" | "allowReordering" | "autoScroll" | "boundary" | "container" | "cursorOffset" | "data" | "dragDirection" | "dragTemplate" | "dropFeedbackMode" | "elementAttr" | "filter" | "group" | "handle" | "height" | "itemOrientation" | "moveItemOnDrop" | "onAdd" | "onDisposing" | "onDragChange" | "onDragEnd" | "onDragMove" | "onDragStart" | "onInitialized" | "onOptionChanged" | "onRemove" | "onReorder" | "rtlEnabled" | "scrollSensitivity" | "scrollSpeed" | "width">;
interface DxSortable extends AccessibleOptions {
    readonly instance?: Sortable;
}
declare const DxSortable: import("vue").DefineComponent<{
    allowDropInsideItem: BooleanConstructor;
    allowReordering: BooleanConstructor;
    autoScroll: BooleanConstructor;
    boundary: {};
    container: {};
    cursorOffset: PropType<string | Record<string, any>>;
    data: {};
    dragDirection: PropType<DragDirection>;
    dragTemplate: {};
    dropFeedbackMode: PropType<DragHighlight>;
    elementAttr: PropType<Record<string, any>>;
    filter: StringConstructor;
    group: StringConstructor;
    handle: StringConstructor;
    height: (NumberConstructor | StringConstructor)[];
    itemOrientation: PropType<Orientation>;
    moveItemOnDrop: BooleanConstructor;
    onAdd: PropType<(e: AddEvent) => void>;
    onDisposing: PropType<(e: DisposingEvent) => void>;
    onDragChange: PropType<(e: DragChangeEvent) => void>;
    onDragEnd: PropType<(e: DragEndEvent) => void>;
    onDragMove: PropType<(e: DragMoveEvent) => void>;
    onDragStart: PropType<(e: DragStartEvent) => void>;
    onInitialized: PropType<(e: InitializedEvent) => void>;
    onOptionChanged: PropType<(e: OptionChangedEvent) => void>;
    onRemove: PropType<(e: RemoveEvent) => void>;
    onReorder: PropType<(e: ReorderEvent) => void>;
    rtlEnabled: BooleanConstructor;
    scrollSensitivity: NumberConstructor;
    scrollSpeed: NumberConstructor;
    width: (NumberConstructor | StringConstructor)[];
}, unknown, unknown, {
    instance(): Sortable;
}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:allowDropInsideItem": null;
    "update:allowReordering": null;
    "update:autoScroll": null;
    "update:boundary": null;
    "update:container": null;
    "update:cursorOffset": null;
    "update:data": null;
    "update:dragDirection": null;
    "update:dragTemplate": null;
    "update:dropFeedbackMode": null;
    "update:elementAttr": null;
    "update:filter": null;
    "update:group": null;
    "update:handle": null;
    "update:height": null;
    "update:itemOrientation": null;
    "update:moveItemOnDrop": null;
    "update:onAdd": null;
    "update:onDisposing": null;
    "update:onDragChange": null;
    "update:onDragEnd": null;
    "update:onDragMove": null;
    "update:onDragStart": null;
    "update:onInitialized": null;
    "update:onOptionChanged": null;
    "update:onRemove": null;
    "update:onReorder": null;
    "update:rtlEnabled": null;
    "update:scrollSensitivity": null;
    "update:scrollSpeed": null;
    "update:width": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    allowDropInsideItem: BooleanConstructor;
    allowReordering: BooleanConstructor;
    autoScroll: BooleanConstructor;
    boundary: {};
    container: {};
    cursorOffset: PropType<string | Record<string, any>>;
    data: {};
    dragDirection: PropType<DragDirection>;
    dragTemplate: {};
    dropFeedbackMode: PropType<DragHighlight>;
    elementAttr: PropType<Record<string, any>>;
    filter: StringConstructor;
    group: StringConstructor;
    handle: StringConstructor;
    height: (NumberConstructor | StringConstructor)[];
    itemOrientation: PropType<Orientation>;
    moveItemOnDrop: BooleanConstructor;
    onAdd: PropType<(e: AddEvent) => void>;
    onDisposing: PropType<(e: DisposingEvent) => void>;
    onDragChange: PropType<(e: DragChangeEvent) => void>;
    onDragEnd: PropType<(e: DragEndEvent) => void>;
    onDragMove: PropType<(e: DragMoveEvent) => void>;
    onDragStart: PropType<(e: DragStartEvent) => void>;
    onInitialized: PropType<(e: InitializedEvent) => void>;
    onOptionChanged: PropType<(e: OptionChangedEvent) => void>;
    onRemove: PropType<(e: RemoveEvent) => void>;
    onReorder: PropType<(e: ReorderEvent) => void>;
    rtlEnabled: BooleanConstructor;
    scrollSensitivity: NumberConstructor;
    scrollSpeed: NumberConstructor;
    width: (NumberConstructor | StringConstructor)[];
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:elementAttr"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onDisposing"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onInitialized"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onOptionChanged"?: ((...args: any[]) => any) | undefined;
    "onUpdate:rtlEnabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:data"?: ((...args: any[]) => any) | undefined;
    "onUpdate:height"?: ((...args: any[]) => any) | undefined;
    "onUpdate:width"?: ((...args: any[]) => any) | undefined;
    "onUpdate:container"?: ((...args: any[]) => any) | undefined;
    "onUpdate:group"?: ((...args: any[]) => any) | undefined;
    "onUpdate:allowReordering"?: ((...args: any[]) => any) | undefined;
    "onUpdate:boundary"?: ((...args: any[]) => any) | undefined;
    "onUpdate:allowDropInsideItem"?: ((...args: any[]) => any) | undefined;
    "onUpdate:autoScroll"?: ((...args: any[]) => any) | undefined;
    "onUpdate:cursorOffset"?: ((...args: any[]) => any) | undefined;
    "onUpdate:dragDirection"?: ((...args: any[]) => any) | undefined;
    "onUpdate:dragTemplate"?: ((...args: any[]) => any) | undefined;
    "onUpdate:dropFeedbackMode"?: ((...args: any[]) => any) | undefined;
    "onUpdate:filter"?: ((...args: any[]) => any) | undefined;
    "onUpdate:handle"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onAdd"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onDragChange"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onDragEnd"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onDragMove"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onDragStart"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onRemove"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onReorder"?: ((...args: any[]) => any) | undefined;
    "onUpdate:scrollSensitivity"?: ((...args: any[]) => any) | undefined;
    "onUpdate:scrollSpeed"?: ((...args: any[]) => any) | undefined;
    "onUpdate:itemOrientation"?: ((...args: any[]) => any) | undefined;
    "onUpdate:moveItemOnDrop"?: ((...args: any[]) => any) | undefined;
}, {
    rtlEnabled: boolean;
    allowReordering: boolean;
    allowDropInsideItem: boolean;
    autoScroll: boolean;
    moveItemOnDrop: boolean;
}>;
declare const DxCursorOffset: import("vue").DefineComponent<{
    x: NumberConstructor;
    y: NumberConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:x": null;
    "update:y": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    x: NumberConstructor;
    y: NumberConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:x"?: ((...args: any[]) => any) | undefined;
    "onUpdate:y"?: ((...args: any[]) => any) | undefined;
}, {}>;
export default DxSortable;
export { DxSortable, DxCursorOffset };
import type * as DxSortableTypes from "devextreme/ui/sortable_types";
export { DxSortableTypes };
