/*!
 * devextreme-vue
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

import { PropType } from "vue";
import Sankey, { Properties } from "devextreme/viz/sankey";
import DataSource from "devextreme/data/data_source";
import { VerticalAlignment, ExportFormat, HorizontalAlignment, VerticalEdge } from "devextreme/common";
import { DataSourceOptions } from "devextreme/common/data";
import { Store } from "devextreme/data/store";
import { DisposingEvent, DrawnEvent, ExportedEvent, ExportingEvent, FileSavingEvent, IncidentOccurredEvent, InitializedEvent, LinkClickEvent, LinkHoverEvent, NodeClickEvent, NodeHoverEvent, OptionChangedEvent, dxSankeyNode, SankeyColorMode } from "devextreme/viz/sankey";
import { Palette, PaletteExtensionMode, Theme, DashStyle, HatchDirection, Font, TextOverflow, WordWrap } from "devextreme/common/charts";
type AccessibleOptions = Pick<Properties, "adaptiveLayout" | "alignment" | "dataSource" | "disabled" | "elementAttr" | "encodeHtml" | "export" | "hoverEnabled" | "label" | "link" | "loadingIndicator" | "margin" | "node" | "onDisposing" | "onDrawn" | "onExported" | "onExporting" | "onFileSaving" | "onIncidentOccurred" | "onInitialized" | "onLinkClick" | "onLinkHoverChanged" | "onNodeClick" | "onNodeHoverChanged" | "onOptionChanged" | "palette" | "paletteExtensionMode" | "pathModified" | "redrawOnResize" | "rtlEnabled" | "size" | "sortData" | "sourceField" | "targetField" | "theme" | "title" | "tooltip" | "weightField">;
interface DxSankey extends AccessibleOptions {
    readonly instance?: Sankey;
}
declare const DxSankey: import("vue").DefineComponent<{
    adaptiveLayout: PropType<Record<string, any>>;
    alignment: PropType<VerticalAlignment | VerticalAlignment[]>;
    dataSource: PropType<string | any[] | Record<string, any> | DataSource<any, any> | DataSourceOptions<any, any, any, any> | Store<any, any> | null>;
    disabled: BooleanConstructor;
    elementAttr: PropType<Record<string, any>>;
    encodeHtml: BooleanConstructor;
    export: PropType<Record<string, any>>;
    hoverEnabled: BooleanConstructor;
    label: PropType<Record<string, any>>;
    link: PropType<Record<string, any>>;
    loadingIndicator: PropType<Record<string, any>>;
    margin: PropType<Record<string, any>>;
    node: PropType<Record<string, any>>;
    onDisposing: PropType<(e: DisposingEvent) => void>;
    onDrawn: PropType<(e: DrawnEvent) => void>;
    onExported: PropType<(e: ExportedEvent) => void>;
    onExporting: PropType<(e: ExportingEvent) => void>;
    onFileSaving: PropType<(e: FileSavingEvent) => void>;
    onIncidentOccurred: PropType<(e: IncidentOccurredEvent) => void>;
    onInitialized: PropType<(e: InitializedEvent) => void>;
    onLinkClick: PropType<(e: LinkClickEvent) => void>;
    onLinkHoverChanged: PropType<(e: LinkHoverEvent) => void>;
    onNodeClick: PropType<(e: NodeClickEvent) => void>;
    onNodeHoverChanged: PropType<(e: NodeHoverEvent) => void>;
    onOptionChanged: PropType<(e: OptionChangedEvent) => void>;
    palette: PropType<string[] | Palette>;
    paletteExtensionMode: PropType<PaletteExtensionMode>;
    pathModified: BooleanConstructor;
    redrawOnResize: BooleanConstructor;
    rtlEnabled: BooleanConstructor;
    size: PropType<Record<string, any>>;
    sortData: {};
    sourceField: StringConstructor;
    targetField: StringConstructor;
    theme: PropType<Theme>;
    title: PropType<string | Record<string, any>>;
    tooltip: PropType<Record<string, any>>;
    weightField: StringConstructor;
}, unknown, unknown, {
    instance(): Sankey;
}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:adaptiveLayout": null;
    "update:alignment": null;
    "update:dataSource": null;
    "update:disabled": null;
    "update:elementAttr": null;
    "update:encodeHtml": null;
    "update:export": null;
    "update:hoverEnabled": null;
    "update:label": null;
    "update:link": null;
    "update:loadingIndicator": null;
    "update:margin": null;
    "update:node": null;
    "update:onDisposing": null;
    "update:onDrawn": null;
    "update:onExported": null;
    "update:onExporting": null;
    "update:onFileSaving": null;
    "update:onIncidentOccurred": null;
    "update:onInitialized": null;
    "update:onLinkClick": null;
    "update:onLinkHoverChanged": null;
    "update:onNodeClick": null;
    "update:onNodeHoverChanged": null;
    "update:onOptionChanged": null;
    "update:palette": null;
    "update:paletteExtensionMode": null;
    "update:pathModified": null;
    "update:redrawOnResize": null;
    "update:rtlEnabled": null;
    "update:size": null;
    "update:sortData": null;
    "update:sourceField": null;
    "update:targetField": null;
    "update:theme": null;
    "update:title": null;
    "update:tooltip": null;
    "update:weightField": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    adaptiveLayout: PropType<Record<string, any>>;
    alignment: PropType<VerticalAlignment | VerticalAlignment[]>;
    dataSource: PropType<string | any[] | Record<string, any> | DataSource<any, any> | DataSourceOptions<any, any, any, any> | Store<any, any> | null>;
    disabled: BooleanConstructor;
    elementAttr: PropType<Record<string, any>>;
    encodeHtml: BooleanConstructor;
    export: PropType<Record<string, any>>;
    hoverEnabled: BooleanConstructor;
    label: PropType<Record<string, any>>;
    link: PropType<Record<string, any>>;
    loadingIndicator: PropType<Record<string, any>>;
    margin: PropType<Record<string, any>>;
    node: PropType<Record<string, any>>;
    onDisposing: PropType<(e: DisposingEvent) => void>;
    onDrawn: PropType<(e: DrawnEvent) => void>;
    onExported: PropType<(e: ExportedEvent) => void>;
    onExporting: PropType<(e: ExportingEvent) => void>;
    onFileSaving: PropType<(e: FileSavingEvent) => void>;
    onIncidentOccurred: PropType<(e: IncidentOccurredEvent) => void>;
    onInitialized: PropType<(e: InitializedEvent) => void>;
    onLinkClick: PropType<(e: LinkClickEvent) => void>;
    onLinkHoverChanged: PropType<(e: LinkHoverEvent) => void>;
    onNodeClick: PropType<(e: NodeClickEvent) => void>;
    onNodeHoverChanged: PropType<(e: NodeHoverEvent) => void>;
    onOptionChanged: PropType<(e: OptionChangedEvent) => void>;
    palette: PropType<string[] | Palette>;
    paletteExtensionMode: PropType<PaletteExtensionMode>;
    pathModified: BooleanConstructor;
    redrawOnResize: BooleanConstructor;
    rtlEnabled: BooleanConstructor;
    size: PropType<Record<string, any>>;
    sortData: {};
    sourceField: StringConstructor;
    targetField: StringConstructor;
    theme: PropType<Theme>;
    title: PropType<string | Record<string, any>>;
    tooltip: PropType<Record<string, any>>;
    weightField: StringConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:disabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:elementAttr"?: ((...args: any[]) => any) | undefined;
    "onUpdate:encodeHtml"?: ((...args: any[]) => any) | undefined;
    "onUpdate:export"?: ((...args: any[]) => any) | undefined;
    "onUpdate:loadingIndicator"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onDisposing"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onDrawn"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onExported"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onExporting"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onFileSaving"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onIncidentOccurred"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onInitialized"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onOptionChanged"?: ((...args: any[]) => any) | undefined;
    "onUpdate:pathModified"?: ((...args: any[]) => any) | undefined;
    "onUpdate:redrawOnResize"?: ((...args: any[]) => any) | undefined;
    "onUpdate:rtlEnabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:size"?: ((...args: any[]) => any) | undefined;
    "onUpdate:theme"?: ((...args: any[]) => any) | undefined;
    "onUpdate:title"?: ((...args: any[]) => any) | undefined;
    "onUpdate:tooltip"?: ((...args: any[]) => any) | undefined;
    "onUpdate:margin"?: ((...args: any[]) => any) | undefined;
    "onUpdate:dataSource"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoverEnabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:label"?: ((...args: any[]) => any) | undefined;
    "onUpdate:palette"?: ((...args: any[]) => any) | undefined;
    "onUpdate:paletteExtensionMode"?: ((...args: any[]) => any) | undefined;
    "onUpdate:alignment"?: ((...args: any[]) => any) | undefined;
    "onUpdate:adaptiveLayout"?: ((...args: any[]) => any) | undefined;
    "onUpdate:link"?: ((...args: any[]) => any) | undefined;
    "onUpdate:node"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onLinkClick"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onLinkHoverChanged"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onNodeClick"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onNodeHoverChanged"?: ((...args: any[]) => any) | undefined;
    "onUpdate:sortData"?: ((...args: any[]) => any) | undefined;
    "onUpdate:sourceField"?: ((...args: any[]) => any) | undefined;
    "onUpdate:targetField"?: ((...args: any[]) => any) | undefined;
    "onUpdate:weightField"?: ((...args: any[]) => any) | undefined;
}, {
    disabled: boolean;
    encodeHtml: boolean;
    pathModified: boolean;
    redrawOnResize: boolean;
    rtlEnabled: boolean;
    hoverEnabled: boolean;
}>;
declare const DxAdaptiveLayout: import("vue").DefineComponent<{
    height: NumberConstructor;
    keepLabels: BooleanConstructor;
    width: NumberConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:height": null;
    "update:keepLabels": null;
    "update:width": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    height: NumberConstructor;
    keepLabels: BooleanConstructor;
    width: NumberConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:height"?: ((...args: any[]) => any) | undefined;
    "onUpdate:width"?: ((...args: any[]) => any) | undefined;
    "onUpdate:keepLabels"?: ((...args: any[]) => any) | undefined;
}, {
    keepLabels: boolean;
}>;
declare const DxBorder: import("vue").DefineComponent<{
    color: StringConstructor;
    dashStyle: PropType<DashStyle>;
    opacity: NumberConstructor;
    visible: BooleanConstructor;
    width: NumberConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:color": null;
    "update:dashStyle": null;
    "update:opacity": null;
    "update:visible": null;
    "update:width": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    color: StringConstructor;
    dashStyle: PropType<DashStyle>;
    opacity: NumberConstructor;
    visible: BooleanConstructor;
    width: NumberConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:color"?: ((...args: any[]) => any) | undefined;
    "onUpdate:opacity"?: ((...args: any[]) => any) | undefined;
    "onUpdate:width"?: ((...args: any[]) => any) | undefined;
    "onUpdate:dashStyle"?: ((...args: any[]) => any) | undefined;
    "onUpdate:visible"?: ((...args: any[]) => any) | undefined;
}, {
    visible: boolean;
}>;
declare const DxExport: import("vue").DefineComponent<{
    backgroundColor: StringConstructor;
    enabled: BooleanConstructor;
    fileName: StringConstructor;
    formats: PropType<ExportFormat[]>;
    margin: NumberConstructor;
    printingEnabled: BooleanConstructor;
    svgToCanvas: PropType<(svg: any, canvas: any) => any>;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:backgroundColor": null;
    "update:enabled": null;
    "update:fileName": null;
    "update:formats": null;
    "update:margin": null;
    "update:printingEnabled": null;
    "update:svgToCanvas": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    backgroundColor: StringConstructor;
    enabled: BooleanConstructor;
    fileName: StringConstructor;
    formats: PropType<ExportFormat[]>;
    margin: NumberConstructor;
    printingEnabled: BooleanConstructor;
    svgToCanvas: PropType<(svg: any, canvas: any) => any>;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:enabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:margin"?: ((...args: any[]) => any) | undefined;
    "onUpdate:backgroundColor"?: ((...args: any[]) => any) | undefined;
    "onUpdate:fileName"?: ((...args: any[]) => any) | undefined;
    "onUpdate:formats"?: ((...args: any[]) => any) | undefined;
    "onUpdate:printingEnabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:svgToCanvas"?: ((...args: any[]) => any) | undefined;
}, {
    enabled: boolean;
    printingEnabled: boolean;
}>;
declare const DxFont: import("vue").DefineComponent<{
    color: StringConstructor;
    family: StringConstructor;
    opacity: NumberConstructor;
    size: (NumberConstructor | StringConstructor)[];
    weight: NumberConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:color": null;
    "update:family": null;
    "update:opacity": null;
    "update:size": null;
    "update:weight": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    color: StringConstructor;
    family: StringConstructor;
    opacity: NumberConstructor;
    size: (NumberConstructor | StringConstructor)[];
    weight: NumberConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:size"?: ((...args: any[]) => any) | undefined;
    "onUpdate:color"?: ((...args: any[]) => any) | undefined;
    "onUpdate:opacity"?: ((...args: any[]) => any) | undefined;
    "onUpdate:family"?: ((...args: any[]) => any) | undefined;
    "onUpdate:weight"?: ((...args: any[]) => any) | undefined;
}, {}>;
declare const DxFormat: import("vue").DefineComponent<{
    currency: StringConstructor;
    formatter: PropType<(value: number | Date) => string>;
    parser: PropType<(value: string) => number | Date>;
    precision: NumberConstructor;
    type: PropType<string>;
    useCurrencyAccountingStyle: BooleanConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:currency": null;
    "update:formatter": null;
    "update:parser": null;
    "update:precision": null;
    "update:type": null;
    "update:useCurrencyAccountingStyle": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    currency: StringConstructor;
    formatter: PropType<(value: number | Date) => string>;
    parser: PropType<(value: string) => number | Date>;
    precision: NumberConstructor;
    type: PropType<string>;
    useCurrencyAccountingStyle: BooleanConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:type"?: ((...args: any[]) => any) | undefined;
    "onUpdate:currency"?: ((...args: any[]) => any) | undefined;
    "onUpdate:formatter"?: ((...args: any[]) => any) | undefined;
    "onUpdate:parser"?: ((...args: any[]) => any) | undefined;
    "onUpdate:precision"?: ((...args: any[]) => any) | undefined;
    "onUpdate:useCurrencyAccountingStyle"?: ((...args: any[]) => any) | undefined;
}, {
    useCurrencyAccountingStyle: boolean;
}>;
declare const DxHatching: import("vue").DefineComponent<{
    direction: PropType<HatchDirection>;
    opacity: NumberConstructor;
    step: NumberConstructor;
    width: NumberConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:direction": null;
    "update:opacity": null;
    "update:step": null;
    "update:width": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    direction: PropType<HatchDirection>;
    opacity: NumberConstructor;
    step: NumberConstructor;
    width: NumberConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:opacity"?: ((...args: any[]) => any) | undefined;
    "onUpdate:width"?: ((...args: any[]) => any) | undefined;
    "onUpdate:direction"?: ((...args: any[]) => any) | undefined;
    "onUpdate:step"?: ((...args: any[]) => any) | undefined;
}, {}>;
declare const DxHoverStyle: import("vue").DefineComponent<{
    border: PropType<Record<string, any>>;
    color: StringConstructor;
    hatching: PropType<Record<string, any>>;
    opacity: NumberConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:border": null;
    "update:color": null;
    "update:hatching": null;
    "update:opacity": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    border: PropType<Record<string, any>>;
    color: StringConstructor;
    hatching: PropType<Record<string, any>>;
    opacity: NumberConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:border"?: ((...args: any[]) => any) | undefined;
    "onUpdate:color"?: ((...args: any[]) => any) | undefined;
    "onUpdate:opacity"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hatching"?: ((...args: any[]) => any) | undefined;
}, {}>;
declare const DxLabel: import("vue").DefineComponent<{
    border: PropType<Record<string, any>>;
    customizeText: PropType<(itemInfo: dxSankeyNode) => string>;
    font: PropType<Record<string, any> | Font>;
    horizontalOffset: NumberConstructor;
    overlappingBehavior: PropType<TextOverflow>;
    shadow: PropType<Record<string, any>>;
    useNodeColors: BooleanConstructor;
    verticalOffset: NumberConstructor;
    visible: BooleanConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:border": null;
    "update:customizeText": null;
    "update:font": null;
    "update:horizontalOffset": null;
    "update:overlappingBehavior": null;
    "update:shadow": null;
    "update:useNodeColors": null;
    "update:verticalOffset": null;
    "update:visible": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    border: PropType<Record<string, any>>;
    customizeText: PropType<(itemInfo: dxSankeyNode) => string>;
    font: PropType<Record<string, any> | Font>;
    horizontalOffset: NumberConstructor;
    overlappingBehavior: PropType<TextOverflow>;
    shadow: PropType<Record<string, any>>;
    useNodeColors: BooleanConstructor;
    verticalOffset: NumberConstructor;
    visible: BooleanConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:border"?: ((...args: any[]) => any) | undefined;
    "onUpdate:font"?: ((...args: any[]) => any) | undefined;
    "onUpdate:shadow"?: ((...args: any[]) => any) | undefined;
    "onUpdate:visible"?: ((...args: any[]) => any) | undefined;
    "onUpdate:customizeText"?: ((...args: any[]) => any) | undefined;
    "onUpdate:horizontalOffset"?: ((...args: any[]) => any) | undefined;
    "onUpdate:overlappingBehavior"?: ((...args: any[]) => any) | undefined;
    "onUpdate:useNodeColors"?: ((...args: any[]) => any) | undefined;
    "onUpdate:verticalOffset"?: ((...args: any[]) => any) | undefined;
}, {
    visible: boolean;
    useNodeColors: boolean;
}>;
declare const DxLink: import("vue").DefineComponent<{
    border: PropType<Record<string, any>>;
    color: StringConstructor;
    colorMode: PropType<SankeyColorMode>;
    hoverStyle: PropType<Record<string, any>>;
    opacity: NumberConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:border": null;
    "update:color": null;
    "update:colorMode": null;
    "update:hoverStyle": null;
    "update:opacity": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    border: PropType<Record<string, any>>;
    color: StringConstructor;
    colorMode: PropType<SankeyColorMode>;
    hoverStyle: PropType<Record<string, any>>;
    opacity: NumberConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:border"?: ((...args: any[]) => any) | undefined;
    "onUpdate:color"?: ((...args: any[]) => any) | undefined;
    "onUpdate:opacity"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoverStyle"?: ((...args: any[]) => any) | undefined;
    "onUpdate:colorMode"?: ((...args: any[]) => any) | undefined;
}, {}>;
declare const DxLoadingIndicator: import("vue").DefineComponent<{
    backgroundColor: StringConstructor;
    enabled: BooleanConstructor;
    font: PropType<Record<string, any> | Font>;
    show: BooleanConstructor;
    text: StringConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:backgroundColor": null;
    "update:enabled": null;
    "update:font": null;
    "update:show": null;
    "update:text": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    backgroundColor: StringConstructor;
    enabled: BooleanConstructor;
    font: PropType<Record<string, any> | Font>;
    show: BooleanConstructor;
    text: StringConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:font"?: ((...args: any[]) => any) | undefined;
    "onUpdate:text"?: ((...args: any[]) => any) | undefined;
    "onUpdate:enabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:backgroundColor"?: ((...args: any[]) => any) | undefined;
    "onUpdate:show"?: ((...args: any[]) => any) | undefined;
}, {
    enabled: boolean;
    show: boolean;
}>;
declare const DxMargin: import("vue").DefineComponent<{
    bottom: NumberConstructor;
    left: NumberConstructor;
    right: NumberConstructor;
    top: NumberConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:bottom": null;
    "update:left": null;
    "update:right": null;
    "update:top": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    bottom: NumberConstructor;
    left: NumberConstructor;
    right: NumberConstructor;
    top: NumberConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:bottom"?: ((...args: any[]) => any) | undefined;
    "onUpdate:left"?: ((...args: any[]) => any) | undefined;
    "onUpdate:right"?: ((...args: any[]) => any) | undefined;
    "onUpdate:top"?: ((...args: any[]) => any) | undefined;
}, {}>;
declare const DxNode: import("vue").DefineComponent<{
    border: PropType<Record<string, any>>;
    color: StringConstructor;
    hoverStyle: PropType<Record<string, any>>;
    opacity: NumberConstructor;
    padding: NumberConstructor;
    width: NumberConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:border": null;
    "update:color": null;
    "update:hoverStyle": null;
    "update:opacity": null;
    "update:padding": null;
    "update:width": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    border: PropType<Record<string, any>>;
    color: StringConstructor;
    hoverStyle: PropType<Record<string, any>>;
    opacity: NumberConstructor;
    padding: NumberConstructor;
    width: NumberConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:border"?: ((...args: any[]) => any) | undefined;
    "onUpdate:color"?: ((...args: any[]) => any) | undefined;
    "onUpdate:opacity"?: ((...args: any[]) => any) | undefined;
    "onUpdate:width"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoverStyle"?: ((...args: any[]) => any) | undefined;
    "onUpdate:padding"?: ((...args: any[]) => any) | undefined;
}, {}>;
declare const DxSankeyborder: import("vue").DefineComponent<{
    color: StringConstructor;
    visible: BooleanConstructor;
    width: NumberConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:color": null;
    "update:visible": null;
    "update:width": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    color: StringConstructor;
    visible: BooleanConstructor;
    width: NumberConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:color"?: ((...args: any[]) => any) | undefined;
    "onUpdate:width"?: ((...args: any[]) => any) | undefined;
    "onUpdate:visible"?: ((...args: any[]) => any) | undefined;
}, {
    visible: boolean;
}>;
declare const DxShadow: import("vue").DefineComponent<{
    blur: NumberConstructor;
    color: StringConstructor;
    offsetX: NumberConstructor;
    offsetY: NumberConstructor;
    opacity: NumberConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:blur": null;
    "update:color": null;
    "update:offsetX": null;
    "update:offsetY": null;
    "update:opacity": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    blur: NumberConstructor;
    color: StringConstructor;
    offsetX: NumberConstructor;
    offsetY: NumberConstructor;
    opacity: NumberConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:color"?: ((...args: any[]) => any) | undefined;
    "onUpdate:offsetX"?: ((...args: any[]) => any) | undefined;
    "onUpdate:offsetY"?: ((...args: any[]) => any) | undefined;
    "onUpdate:opacity"?: ((...args: any[]) => any) | undefined;
    "onUpdate:blur"?: ((...args: any[]) => any) | undefined;
}, {}>;
declare const DxSize: import("vue").DefineComponent<{
    height: NumberConstructor;
    width: NumberConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:height": null;
    "update:width": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    height: NumberConstructor;
    width: NumberConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:height"?: ((...args: any[]) => any) | undefined;
    "onUpdate:width"?: ((...args: any[]) => any) | undefined;
}, {}>;
declare const DxSubtitle: import("vue").DefineComponent<{
    font: PropType<Record<string, any> | Font>;
    offset: NumberConstructor;
    text: StringConstructor;
    textOverflow: PropType<TextOverflow>;
    wordWrap: PropType<WordWrap>;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:font": null;
    "update:offset": null;
    "update:text": null;
    "update:textOverflow": null;
    "update:wordWrap": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    font: PropType<Record<string, any> | Font>;
    offset: NumberConstructor;
    text: StringConstructor;
    textOverflow: PropType<TextOverflow>;
    wordWrap: PropType<WordWrap>;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:font"?: ((...args: any[]) => any) | undefined;
    "onUpdate:text"?: ((...args: any[]) => any) | undefined;
    "onUpdate:textOverflow"?: ((...args: any[]) => any) | undefined;
    "onUpdate:wordWrap"?: ((...args: any[]) => any) | undefined;
    "onUpdate:offset"?: ((...args: any[]) => any) | undefined;
}, {}>;
declare const DxTitle: import("vue").DefineComponent<{
    font: PropType<Record<string, any> | Font>;
    horizontalAlignment: PropType<HorizontalAlignment>;
    margin: PropType<number | Record<string, any>>;
    placeholderSize: NumberConstructor;
    subtitle: PropType<string | Record<string, any>>;
    text: StringConstructor;
    textOverflow: PropType<TextOverflow>;
    verticalAlignment: PropType<VerticalEdge>;
    wordWrap: PropType<WordWrap>;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:font": null;
    "update:horizontalAlignment": null;
    "update:margin": null;
    "update:placeholderSize": null;
    "update:subtitle": null;
    "update:text": null;
    "update:textOverflow": null;
    "update:verticalAlignment": null;
    "update:wordWrap": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    font: PropType<Record<string, any> | Font>;
    horizontalAlignment: PropType<HorizontalAlignment>;
    margin: PropType<number | Record<string, any>>;
    placeholderSize: NumberConstructor;
    subtitle: PropType<string | Record<string, any>>;
    text: StringConstructor;
    textOverflow: PropType<TextOverflow>;
    verticalAlignment: PropType<VerticalEdge>;
    wordWrap: PropType<WordWrap>;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:font"?: ((...args: any[]) => any) | undefined;
    "onUpdate:text"?: ((...args: any[]) => any) | undefined;
    "onUpdate:textOverflow"?: ((...args: any[]) => any) | undefined;
    "onUpdate:wordWrap"?: ((...args: any[]) => any) | undefined;
    "onUpdate:horizontalAlignment"?: ((...args: any[]) => any) | undefined;
    "onUpdate:margin"?: ((...args: any[]) => any) | undefined;
    "onUpdate:verticalAlignment"?: ((...args: any[]) => any) | undefined;
    "onUpdate:placeholderSize"?: ((...args: any[]) => any) | undefined;
    "onUpdate:subtitle"?: ((...args: any[]) => any) | undefined;
}, {}>;
declare const DxTooltip: import("vue").DefineComponent<{
    arrowLength: NumberConstructor;
    border: PropType<Record<string, any>>;
    color: StringConstructor;
    container: {};
    cornerRadius: NumberConstructor;
    customizeLinkTooltip: PropType<(info: {
        source: string;
        target: string;
        weight: number;
    }) => Record<string, any>>;
    customizeNodeTooltip: PropType<(info: {
        label: string;
        title: string;
        weightIn: number;
        weightOut: number;
    }) => Record<string, any>>;
    enabled: BooleanConstructor;
    font: PropType<Record<string, any> | Font>;
    format: PropType<string | Record<string, any> | import("devextreme/common/core/localization").FormatObject | ((value: number | Date) => string) | ((value: Date) => string) | ((value: number) => string) | Intl.DateTimeFormatOptions | Intl.NumberFormatOptions | ((value: number | Date) => string) | undefined>;
    linkTooltipTemplate: {};
    nodeTooltipTemplate: {};
    opacity: NumberConstructor;
    paddingLeftRight: NumberConstructor;
    paddingTopBottom: NumberConstructor;
    shadow: PropType<Record<string, any>>;
    zIndex: NumberConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:arrowLength": null;
    "update:border": null;
    "update:color": null;
    "update:container": null;
    "update:cornerRadius": null;
    "update:customizeLinkTooltip": null;
    "update:customizeNodeTooltip": null;
    "update:enabled": null;
    "update:font": null;
    "update:format": null;
    "update:linkTooltipTemplate": null;
    "update:nodeTooltipTemplate": null;
    "update:opacity": null;
    "update:paddingLeftRight": null;
    "update:paddingTopBottom": null;
    "update:shadow": null;
    "update:zIndex": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    arrowLength: NumberConstructor;
    border: PropType<Record<string, any>>;
    color: StringConstructor;
    container: {};
    cornerRadius: NumberConstructor;
    customizeLinkTooltip: PropType<(info: {
        source: string;
        target: string;
        weight: number;
    }) => Record<string, any>>;
    customizeNodeTooltip: PropType<(info: {
        label: string;
        title: string;
        weightIn: number;
        weightOut: number;
    }) => Record<string, any>>;
    enabled: BooleanConstructor;
    font: PropType<Record<string, any> | Font>;
    format: PropType<string | Record<string, any> | import("devextreme/common/core/localization").FormatObject | ((value: number | Date) => string) | ((value: Date) => string) | ((value: number) => string) | Intl.DateTimeFormatOptions | Intl.NumberFormatOptions | ((value: number | Date) => string) | undefined>;
    linkTooltipTemplate: {};
    nodeTooltipTemplate: {};
    opacity: NumberConstructor;
    paddingLeftRight: NumberConstructor;
    paddingTopBottom: NumberConstructor;
    shadow: PropType<Record<string, any>>;
    zIndex: NumberConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:arrowLength"?: ((...args: any[]) => any) | undefined;
    "onUpdate:border"?: ((...args: any[]) => any) | undefined;
    "onUpdate:color"?: ((...args: any[]) => any) | undefined;
    "onUpdate:font"?: ((...args: any[]) => any) | undefined;
    "onUpdate:opacity"?: ((...args: any[]) => any) | undefined;
    "onUpdate:paddingLeftRight"?: ((...args: any[]) => any) | undefined;
    "onUpdate:paddingTopBottom"?: ((...args: any[]) => any) | undefined;
    "onUpdate:shadow"?: ((...args: any[]) => any) | undefined;
    "onUpdate:cornerRadius"?: ((...args: any[]) => any) | undefined;
    "onUpdate:enabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:container"?: ((...args: any[]) => any) | undefined;
    "onUpdate:zIndex"?: ((...args: any[]) => any) | undefined;
    "onUpdate:format"?: ((...args: any[]) => any) | undefined;
    "onUpdate:customizeLinkTooltip"?: ((...args: any[]) => any) | undefined;
    "onUpdate:customizeNodeTooltip"?: ((...args: any[]) => any) | undefined;
    "onUpdate:linkTooltipTemplate"?: ((...args: any[]) => any) | undefined;
    "onUpdate:nodeTooltipTemplate"?: ((...args: any[]) => any) | undefined;
}, {
    enabled: boolean;
}>;
declare const DxTooltipBorder: import("vue").DefineComponent<{
    color: StringConstructor;
    dashStyle: PropType<DashStyle>;
    opacity: NumberConstructor;
    visible: BooleanConstructor;
    width: NumberConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:color": null;
    "update:dashStyle": null;
    "update:opacity": null;
    "update:visible": null;
    "update:width": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    color: StringConstructor;
    dashStyle: PropType<DashStyle>;
    opacity: NumberConstructor;
    visible: BooleanConstructor;
    width: NumberConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:color"?: ((...args: any[]) => any) | undefined;
    "onUpdate:opacity"?: ((...args: any[]) => any) | undefined;
    "onUpdate:width"?: ((...args: any[]) => any) | undefined;
    "onUpdate:dashStyle"?: ((...args: any[]) => any) | undefined;
    "onUpdate:visible"?: ((...args: any[]) => any) | undefined;
}, {
    visible: boolean;
}>;
export default DxSankey;
export { DxSankey, DxAdaptiveLayout, DxBorder, DxExport, DxFont, DxFormat, DxHatching, DxHoverStyle, DxLabel, DxLink, DxLoadingIndicator, DxMargin, DxNode, DxSankeyborder, DxShadow, DxSize, DxSubtitle, DxTitle, DxTooltip, DxTooltipBorder };
import type * as DxSankeyTypes from "devextreme/viz/sankey_types";
export { DxSankeyTypes };
