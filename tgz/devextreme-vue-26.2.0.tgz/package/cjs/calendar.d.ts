/*!
 * devextreme-vue
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

import { PropType } from "vue";
import Calendar, { Properties } from "devextreme/ui/calendar";
import { DisabledDate, CalendarZoomLevel, DisposingEvent, InitializedEvent, OptionChangedEvent, ValueChangedEvent, CalendarSelectionMode, WeekNumberRule } from "devextreme/ui/calendar";
import { DayOfWeek, ValidationMessageMode, Position, ValidationStatus } from "devextreme/common";
type AccessibleOptions = Pick<Properties, "accessKey" | "activeStateEnabled" | "cellTemplate" | "dateSerializationFormat" | "disabled" | "disabledDates" | "elementAttr" | "firstDayOfWeek" | "focusStateEnabled" | "height" | "hint" | "hoverStateEnabled" | "isDirty" | "isValid" | "max" | "maxZoomLevel" | "min" | "minZoomLevel" | "name" | "onDisposing" | "onInitialized" | "onOptionChanged" | "onValueChanged" | "readOnly" | "rtlEnabled" | "selectionMode" | "selectWeekOnClick" | "showTodayButton" | "showWeekNumbers" | "tabIndex" | "todayButtonText" | "validationError" | "validationErrors" | "validationMessageMode" | "validationMessagePosition" | "validationStatus" | "value" | "visible" | "weekNumberRule" | "width" | "zoomLevel">;
interface DxCalendar extends AccessibleOptions {
    readonly instance?: Calendar;
}
declare const DxCalendar: import("vue").DefineComponent<{
    accessKey: StringConstructor;
    activeStateEnabled: BooleanConstructor;
    cellTemplate: {};
    dateSerializationFormat: StringConstructor;
    disabled: BooleanConstructor;
    disabledDates: PropType<Date[] | ((data: DisabledDate) => boolean) | null>;
    elementAttr: PropType<Record<string, any>>;
    firstDayOfWeek: PropType<DayOfWeek>;
    focusStateEnabled: BooleanConstructor;
    height: (NumberConstructor | StringConstructor)[];
    hint: StringConstructor;
    hoverStateEnabled: BooleanConstructor;
    isDirty: BooleanConstructor;
    isValid: BooleanConstructor;
    max: PropType<string | number | Date | null>;
    maxZoomLevel: PropType<CalendarZoomLevel>;
    min: PropType<string | number | Date | null>;
    minZoomLevel: PropType<CalendarZoomLevel>;
    name: StringConstructor;
    onDisposing: PropType<(e: DisposingEvent) => void>;
    onInitialized: PropType<(e: InitializedEvent) => void>;
    onOptionChanged: PropType<(e: OptionChangedEvent) => void>;
    onValueChanged: PropType<(e: ValueChangedEvent) => void>;
    readOnly: BooleanConstructor;
    rtlEnabled: BooleanConstructor;
    selectionMode: PropType<CalendarSelectionMode>;
    selectWeekOnClick: BooleanConstructor;
    showTodayButton: BooleanConstructor;
    showWeekNumbers: BooleanConstructor;
    tabIndex: NumberConstructor;
    todayButtonText: StringConstructor;
    validationError: {};
    validationErrors: PropType<any[] | null>;
    validationMessageMode: PropType<ValidationMessageMode>;
    validationMessagePosition: PropType<Position>;
    validationStatus: PropType<ValidationStatus>;
    value: PropType<string | number | Date | (string | number | Date | null)[] | null>;
    visible: BooleanConstructor;
    weekNumberRule: PropType<WeekNumberRule>;
    width: (NumberConstructor | StringConstructor)[];
    zoomLevel: PropType<CalendarZoomLevel>;
}, unknown, unknown, {
    instance(): Calendar;
}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:accessKey": null;
    "update:activeStateEnabled": null;
    "update:cellTemplate": null;
    "update:dateSerializationFormat": null;
    "update:disabled": null;
    "update:disabledDates": null;
    "update:elementAttr": null;
    "update:firstDayOfWeek": null;
    "update:focusStateEnabled": null;
    "update:height": null;
    "update:hint": null;
    "update:hoverStateEnabled": null;
    "update:isDirty": null;
    "update:isValid": null;
    "update:max": null;
    "update:maxZoomLevel": null;
    "update:min": null;
    "update:minZoomLevel": null;
    "update:name": null;
    "update:onDisposing": null;
    "update:onInitialized": null;
    "update:onOptionChanged": null;
    "update:onValueChanged": null;
    "update:readOnly": null;
    "update:rtlEnabled": null;
    "update:selectionMode": null;
    "update:selectWeekOnClick": null;
    "update:showTodayButton": null;
    "update:showWeekNumbers": null;
    "update:tabIndex": null;
    "update:todayButtonText": null;
    "update:validationError": null;
    "update:validationErrors": null;
    "update:validationMessageMode": null;
    "update:validationMessagePosition": null;
    "update:validationStatus": null;
    "update:value": null;
    "update:visible": null;
    "update:weekNumberRule": null;
    "update:width": null;
    "update:zoomLevel": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    accessKey: StringConstructor;
    activeStateEnabled: BooleanConstructor;
    cellTemplate: {};
    dateSerializationFormat: StringConstructor;
    disabled: BooleanConstructor;
    disabledDates: PropType<Date[] | ((data: DisabledDate) => boolean) | null>;
    elementAttr: PropType<Record<string, any>>;
    firstDayOfWeek: PropType<DayOfWeek>;
    focusStateEnabled: BooleanConstructor;
    height: (NumberConstructor | StringConstructor)[];
    hint: StringConstructor;
    hoverStateEnabled: BooleanConstructor;
    isDirty: BooleanConstructor;
    isValid: BooleanConstructor;
    max: PropType<string | number | Date | null>;
    maxZoomLevel: PropType<CalendarZoomLevel>;
    min: PropType<string | number | Date | null>;
    minZoomLevel: PropType<CalendarZoomLevel>;
    name: StringConstructor;
    onDisposing: PropType<(e: DisposingEvent) => void>;
    onInitialized: PropType<(e: InitializedEvent) => void>;
    onOptionChanged: PropType<(e: OptionChangedEvent) => void>;
    onValueChanged: PropType<(e: ValueChangedEvent) => void>;
    readOnly: BooleanConstructor;
    rtlEnabled: BooleanConstructor;
    selectionMode: PropType<CalendarSelectionMode>;
    selectWeekOnClick: BooleanConstructor;
    showTodayButton: BooleanConstructor;
    showWeekNumbers: BooleanConstructor;
    tabIndex: NumberConstructor;
    todayButtonText: StringConstructor;
    validationError: {};
    validationErrors: PropType<any[] | null>;
    validationMessageMode: PropType<ValidationMessageMode>;
    validationMessagePosition: PropType<Position>;
    validationStatus: PropType<ValidationStatus>;
    value: PropType<string | number | Date | (string | number | Date | null)[] | null>;
    visible: BooleanConstructor;
    weekNumberRule: PropType<WeekNumberRule>;
    width: (NumberConstructor | StringConstructor)[];
    zoomLevel: PropType<CalendarZoomLevel>;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:disabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:elementAttr"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onDisposing"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onInitialized"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onOptionChanged"?: ((...args: any[]) => any) | undefined;
    "onUpdate:rtlEnabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:height"?: ((...args: any[]) => any) | undefined;
    "onUpdate:name"?: ((...args: any[]) => any) | undefined;
    "onUpdate:width"?: ((...args: any[]) => any) | undefined;
    "onUpdate:visible"?: ((...args: any[]) => any) | undefined;
    "onUpdate:selectionMode"?: ((...args: any[]) => any) | undefined;
    "onUpdate:max"?: ((...args: any[]) => any) | undefined;
    "onUpdate:min"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoverStateEnabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:accessKey"?: ((...args: any[]) => any) | undefined;
    "onUpdate:activeStateEnabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:focusStateEnabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hint"?: ((...args: any[]) => any) | undefined;
    "onUpdate:tabIndex"?: ((...args: any[]) => any) | undefined;
    "onUpdate:isDirty"?: ((...args: any[]) => any) | undefined;
    "onUpdate:isValid"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onValueChanged"?: ((...args: any[]) => any) | undefined;
    "onUpdate:readOnly"?: ((...args: any[]) => any) | undefined;
    "onUpdate:validationError"?: ((...args: any[]) => any) | undefined;
    "onUpdate:validationErrors"?: ((...args: any[]) => any) | undefined;
    "onUpdate:validationMessageMode"?: ((...args: any[]) => any) | undefined;
    "onUpdate:validationMessagePosition"?: ((...args: any[]) => any) | undefined;
    "onUpdate:validationStatus"?: ((...args: any[]) => any) | undefined;
    "onUpdate:value"?: ((...args: any[]) => any) | undefined;
    "onUpdate:dateSerializationFormat"?: ((...args: any[]) => any) | undefined;
    "onUpdate:cellTemplate"?: ((...args: any[]) => any) | undefined;
    "onUpdate:firstDayOfWeek"?: ((...args: any[]) => any) | undefined;
    "onUpdate:disabledDates"?: ((...args: any[]) => any) | undefined;
    "onUpdate:maxZoomLevel"?: ((...args: any[]) => any) | undefined;
    "onUpdate:minZoomLevel"?: ((...args: any[]) => any) | undefined;
    "onUpdate:selectWeekOnClick"?: ((...args: any[]) => any) | undefined;
    "onUpdate:showTodayButton"?: ((...args: any[]) => any) | undefined;
    "onUpdate:showWeekNumbers"?: ((...args: any[]) => any) | undefined;
    "onUpdate:todayButtonText"?: ((...args: any[]) => any) | undefined;
    "onUpdate:weekNumberRule"?: ((...args: any[]) => any) | undefined;
    "onUpdate:zoomLevel"?: ((...args: any[]) => any) | undefined;
}, {
    disabled: boolean;
    rtlEnabled: boolean;
    visible: boolean;
    hoverStateEnabled: boolean;
    activeStateEnabled: boolean;
    focusStateEnabled: boolean;
    isDirty: boolean;
    isValid: boolean;
    readOnly: boolean;
    selectWeekOnClick: boolean;
    showTodayButton: boolean;
    showWeekNumbers: boolean;
}>;
export default DxCalendar;
export { DxCalendar };
import type * as DxCalendarTypes from "devextreme/ui/calendar_types";
export { DxCalendarTypes };
