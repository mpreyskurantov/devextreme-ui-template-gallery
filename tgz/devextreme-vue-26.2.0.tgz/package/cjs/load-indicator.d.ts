/*!
 * devextreme-vue
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

import { PropType } from "vue";
import LoadIndicator, { Properties } from "devextreme/ui/load_indicator";
import { LoadingAnimationType, ContentReadyEvent, DisposingEvent, InitializedEvent, OptionChangedEvent } from "devextreme/ui/load_indicator";
type AccessibleOptions = Pick<Properties, "animationType" | "elementAttr" | "height" | "hint" | "indicatorSrc" | "onContentReady" | "onDisposing" | "onInitialized" | "onOptionChanged" | "rtlEnabled" | "visible" | "width">;
interface DxLoadIndicator extends AccessibleOptions {
    readonly instance?: LoadIndicator;
}
declare const DxLoadIndicator: import("vue").DefineComponent<{
    animationType: PropType<LoadingAnimationType>;
    elementAttr: PropType<Record<string, any>>;
    height: (NumberConstructor | StringConstructor)[];
    hint: StringConstructor;
    indicatorSrc: StringConstructor;
    onContentReady: PropType<(e: ContentReadyEvent) => void>;
    onDisposing: PropType<(e: DisposingEvent) => void>;
    onInitialized: PropType<(e: InitializedEvent) => void>;
    onOptionChanged: PropType<(e: OptionChangedEvent) => void>;
    rtlEnabled: BooleanConstructor;
    visible: BooleanConstructor;
    width: (NumberConstructor | StringConstructor)[];
}, unknown, unknown, {
    instance(): LoadIndicator;
}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:animationType": null;
    "update:elementAttr": null;
    "update:height": null;
    "update:hint": null;
    "update:indicatorSrc": null;
    "update:onContentReady": null;
    "update:onDisposing": null;
    "update:onInitialized": null;
    "update:onOptionChanged": null;
    "update:rtlEnabled": null;
    "update:visible": null;
    "update:width": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    animationType: PropType<LoadingAnimationType>;
    elementAttr: PropType<Record<string, any>>;
    height: (NumberConstructor | StringConstructor)[];
    hint: StringConstructor;
    indicatorSrc: StringConstructor;
    onContentReady: PropType<(e: ContentReadyEvent) => void>;
    onDisposing: PropType<(e: DisposingEvent) => void>;
    onInitialized: PropType<(e: InitializedEvent) => void>;
    onOptionChanged: PropType<(e: OptionChangedEvent) => void>;
    rtlEnabled: BooleanConstructor;
    visible: BooleanConstructor;
    width: (NumberConstructor | StringConstructor)[];
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:elementAttr"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onDisposing"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onInitialized"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onOptionChanged"?: ((...args: any[]) => any) | undefined;
    "onUpdate:rtlEnabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:height"?: ((...args: any[]) => any) | undefined;
    "onUpdate:width"?: ((...args: any[]) => any) | undefined;
    "onUpdate:visible"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onContentReady"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hint"?: ((...args: any[]) => any) | undefined;
    "onUpdate:animationType"?: ((...args: any[]) => any) | undefined;
    "onUpdate:indicatorSrc"?: ((...args: any[]) => any) | undefined;
}, {
    rtlEnabled: boolean;
    visible: boolean;
}>;
export default DxLoadIndicator;
export { DxLoadIndicator };
import type * as DxLoadIndicatorTypes from "devextreme/ui/load_indicator_types";
export { DxLoadIndicatorTypes };
