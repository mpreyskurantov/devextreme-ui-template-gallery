/*!
 * devextreme-vue
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

export { ExplicitTypes } from "devextreme/ui/tabs";
import { PropType } from "vue";
import Tabs, { Properties } from "devextreme/ui/tabs";
import DataSource from "devextreme/data/data_source";
import { ContentReadyEvent, DisposingEvent, InitializedEvent, ItemClickEvent, ItemContextMenuEvent, ItemHoldEvent, ItemRenderedEvent, OptionChangedEvent, SelectionChangedEvent, SelectionChangingEvent } from "devextreme/ui/tabs";
import { DataSourceOptions } from "devextreme/common/data";
import { Store } from "devextreme/data/store";
import { TabsIconPosition, Orientation, SingleOrMultiple, TabsStyle } from "devextreme/common";
type AccessibleOptions = Pick<Properties, "accessKey" | "dataSource" | "disabled" | "elementAttr" | "focusStateEnabled" | "height" | "hint" | "hoverStateEnabled" | "iconPosition" | "itemHoldTimeout" | "items" | "itemTemplate" | "keyExpr" | "noDataText" | "onContentReady" | "onDisposing" | "onInitialized" | "onItemClick" | "onItemContextMenu" | "onItemHold" | "onItemRendered" | "onOptionChanged" | "onSelectionChanged" | "onSelectionChanging" | "orientation" | "repaintChangesOnly" | "rtlEnabled" | "scrollByContent" | "scrollingEnabled" | "selectedIndex" | "selectedItem" | "selectedItemKeys" | "selectedItems" | "selectionMode" | "showNavButtons" | "stylingMode" | "tabIndex" | "visible" | "width">;
interface DxTabs extends AccessibleOptions {
    readonly instance?: Tabs;
}
declare const DxTabs: import("vue").DefineComponent<{
    accessKey: StringConstructor;
    dataSource: PropType<string | any[] | Record<string, any> | DataSource<any, any> | DataSourceOptions<any, any, any, any> | Store<any, any> | null>;
    disabled: BooleanConstructor;
    elementAttr: PropType<Record<string, any>>;
    focusStateEnabled: BooleanConstructor;
    height: (NumberConstructor | StringConstructor)[];
    hint: StringConstructor;
    hoverStateEnabled: BooleanConstructor;
    iconPosition: PropType<TabsIconPosition>;
    itemHoldTimeout: NumberConstructor;
    items: PropType<any[]>;
    itemTemplate: {};
    keyExpr: PropType<string | ((item: any) => any) | null>;
    noDataText: StringConstructor;
    onContentReady: PropType<(e: ContentReadyEvent) => void>;
    onDisposing: PropType<(e: DisposingEvent) => void>;
    onInitialized: PropType<(e: InitializedEvent) => void>;
    onItemClick: PropType<(e: ItemClickEvent) => void>;
    onItemContextMenu: PropType<(e: ItemContextMenuEvent) => void>;
    onItemHold: PropType<(e: ItemHoldEvent) => void>;
    onItemRendered: PropType<(e: ItemRenderedEvent) => void>;
    onOptionChanged: PropType<(e: OptionChangedEvent) => void>;
    onSelectionChanged: PropType<(e: SelectionChangedEvent) => void>;
    onSelectionChanging: PropType<(e: SelectionChangingEvent) => void>;
    orientation: PropType<Orientation>;
    repaintChangesOnly: BooleanConstructor;
    rtlEnabled: BooleanConstructor;
    scrollByContent: BooleanConstructor;
    scrollingEnabled: BooleanConstructor;
    selectedIndex: NumberConstructor;
    selectedItem: {};
    selectedItemKeys: PropType<any[]>;
    selectedItems: PropType<any[]>;
    selectionMode: PropType<SingleOrMultiple>;
    showNavButtons: BooleanConstructor;
    stylingMode: PropType<TabsStyle>;
    tabIndex: NumberConstructor;
    visible: BooleanConstructor;
    width: (NumberConstructor | StringConstructor)[];
}, unknown, unknown, {
    instance(): Tabs;
}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:accessKey": null;
    "update:dataSource": null;
    "update:disabled": null;
    "update:elementAttr": null;
    "update:focusStateEnabled": null;
    "update:height": null;
    "update:hint": null;
    "update:hoverStateEnabled": null;
    "update:iconPosition": null;
    "update:itemHoldTimeout": null;
    "update:items": null;
    "update:itemTemplate": null;
    "update:keyExpr": null;
    "update:noDataText": null;
    "update:onContentReady": null;
    "update:onDisposing": null;
    "update:onInitialized": null;
    "update:onItemClick": null;
    "update:onItemContextMenu": null;
    "update:onItemHold": null;
    "update:onItemRendered": null;
    "update:onOptionChanged": null;
    "update:onSelectionChanged": null;
    "update:onSelectionChanging": null;
    "update:orientation": null;
    "update:repaintChangesOnly": null;
    "update:rtlEnabled": null;
    "update:scrollByContent": null;
    "update:scrollingEnabled": null;
    "update:selectedIndex": null;
    "update:selectedItem": null;
    "update:selectedItemKeys": null;
    "update:selectedItems": null;
    "update:selectionMode": null;
    "update:showNavButtons": null;
    "update:stylingMode": null;
    "update:tabIndex": null;
    "update:visible": null;
    "update:width": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    accessKey: StringConstructor;
    dataSource: PropType<string | any[] | Record<string, any> | DataSource<any, any> | DataSourceOptions<any, any, any, any> | Store<any, any> | null>;
    disabled: BooleanConstructor;
    elementAttr: PropType<Record<string, any>>;
    focusStateEnabled: BooleanConstructor;
    height: (NumberConstructor | StringConstructor)[];
    hint: StringConstructor;
    hoverStateEnabled: BooleanConstructor;
    iconPosition: PropType<TabsIconPosition>;
    itemHoldTimeout: NumberConstructor;
    items: PropType<any[]>;
    itemTemplate: {};
    keyExpr: PropType<string | ((item: any) => any) | null>;
    noDataText: StringConstructor;
    onContentReady: PropType<(e: ContentReadyEvent) => void>;
    onDisposing: PropType<(e: DisposingEvent) => void>;
    onInitialized: PropType<(e: InitializedEvent) => void>;
    onItemClick: PropType<(e: ItemClickEvent) => void>;
    onItemContextMenu: PropType<(e: ItemContextMenuEvent) => void>;
    onItemHold: PropType<(e: ItemHoldEvent) => void>;
    onItemRendered: PropType<(e: ItemRenderedEvent) => void>;
    onOptionChanged: PropType<(e: OptionChangedEvent) => void>;
    onSelectionChanged: PropType<(e: SelectionChangedEvent) => void>;
    onSelectionChanging: PropType<(e: SelectionChangingEvent) => void>;
    orientation: PropType<Orientation>;
    repaintChangesOnly: BooleanConstructor;
    rtlEnabled: BooleanConstructor;
    scrollByContent: BooleanConstructor;
    scrollingEnabled: BooleanConstructor;
    selectedIndex: NumberConstructor;
    selectedItem: {};
    selectedItemKeys: PropType<any[]>;
    selectedItems: PropType<any[]>;
    selectionMode: PropType<SingleOrMultiple>;
    showNavButtons: BooleanConstructor;
    stylingMode: PropType<TabsStyle>;
    tabIndex: NumberConstructor;
    visible: BooleanConstructor;
    width: (NumberConstructor | StringConstructor)[];
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:disabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:elementAttr"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onDisposing"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onInitialized"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onOptionChanged"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onSelectionChanged"?: ((...args: any[]) => any) | undefined;
    "onUpdate:rtlEnabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:height"?: ((...args: any[]) => any) | undefined;
    "onUpdate:width"?: ((...args: any[]) => any) | undefined;
    "onUpdate:visible"?: ((...args: any[]) => any) | undefined;
    "onUpdate:dataSource"?: ((...args: any[]) => any) | undefined;
    "onUpdate:selectionMode"?: ((...args: any[]) => any) | undefined;
    "onUpdate:orientation"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoverStateEnabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:items"?: ((...args: any[]) => any) | undefined;
    "onUpdate:itemTemplate"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onContentReady"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onItemClick"?: ((...args: any[]) => any) | undefined;
    "onUpdate:accessKey"?: ((...args: any[]) => any) | undefined;
    "onUpdate:focusStateEnabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hint"?: ((...args: any[]) => any) | undefined;
    "onUpdate:itemHoldTimeout"?: ((...args: any[]) => any) | undefined;
    "onUpdate:keyExpr"?: ((...args: any[]) => any) | undefined;
    "onUpdate:noDataText"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onItemContextMenu"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onItemHold"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onItemRendered"?: ((...args: any[]) => any) | undefined;
    "onUpdate:tabIndex"?: ((...args: any[]) => any) | undefined;
    "onUpdate:stylingMode"?: ((...args: any[]) => any) | undefined;
    "onUpdate:repaintChangesOnly"?: ((...args: any[]) => any) | undefined;
    "onUpdate:scrollingEnabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:scrollByContent"?: ((...args: any[]) => any) | undefined;
    "onUpdate:iconPosition"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onSelectionChanging"?: ((...args: any[]) => any) | undefined;
    "onUpdate:selectedIndex"?: ((...args: any[]) => any) | undefined;
    "onUpdate:selectedItem"?: ((...args: any[]) => any) | undefined;
    "onUpdate:showNavButtons"?: ((...args: any[]) => any) | undefined;
    "onUpdate:selectedItems"?: ((...args: any[]) => any) | undefined;
    "onUpdate:selectedItemKeys"?: ((...args: any[]) => any) | undefined;
}, {
    disabled: boolean;
    rtlEnabled: boolean;
    visible: boolean;
    hoverStateEnabled: boolean;
    focusStateEnabled: boolean;
    repaintChangesOnly: boolean;
    scrollingEnabled: boolean;
    scrollByContent: boolean;
    showNavButtons: boolean;
}>;
declare const DxItem: import("vue").DefineComponent<{
    badge: StringConstructor;
    disabled: BooleanConstructor;
    html: StringConstructor;
    icon: StringConstructor;
    template: {};
    text: StringConstructor;
    visible: BooleanConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:badge": null;
    "update:disabled": null;
    "update:html": null;
    "update:icon": null;
    "update:template": null;
    "update:text": null;
    "update:visible": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    badge: StringConstructor;
    disabled: BooleanConstructor;
    html: StringConstructor;
    icon: StringConstructor;
    template: {};
    text: StringConstructor;
    visible: BooleanConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:disabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:template"?: ((...args: any[]) => any) | undefined;
    "onUpdate:text"?: ((...args: any[]) => any) | undefined;
    "onUpdate:visible"?: ((...args: any[]) => any) | undefined;
    "onUpdate:html"?: ((...args: any[]) => any) | undefined;
    "onUpdate:icon"?: ((...args: any[]) => any) | undefined;
    "onUpdate:badge"?: ((...args: any[]) => any) | undefined;
}, {
    disabled: boolean;
    visible: boolean;
}>;
export default DxTabs;
export { DxTabs, DxItem };
import type * as DxTabsTypes from "devextreme/ui/tabs_types";
export { DxTabsTypes };
