/*!
 * devextreme-vue
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

import { PropType } from "vue";
import SpeedDialAction, { Properties } from "devextreme/ui/speed_dial_action";
import { ClickEvent, ContentReadyEvent, DisposingEvent, InitializedEvent, OptionChangedEvent } from "devextreme/ui/speed_dial_action";
type AccessibleOptions = Pick<Properties, "accessKey" | "activeStateEnabled" | "elementAttr" | "focusStateEnabled" | "hint" | "hoverStateEnabled" | "icon" | "index" | "label" | "onClick" | "onContentReady" | "onDisposing" | "onInitialized" | "onOptionChanged" | "rtlEnabled" | "tabIndex" | "visible">;
interface DxSpeedDialAction extends AccessibleOptions {
    readonly instance?: SpeedDialAction;
}
declare const DxSpeedDialAction: import("vue").DefineComponent<{
    accessKey: StringConstructor;
    activeStateEnabled: BooleanConstructor;
    elementAttr: PropType<Record<string, any>>;
    focusStateEnabled: BooleanConstructor;
    hint: StringConstructor;
    hoverStateEnabled: BooleanConstructor;
    icon: StringConstructor;
    index: NumberConstructor;
    label: StringConstructor;
    onClick: PropType<(e: ClickEvent) => void>;
    onContentReady: PropType<(e: ContentReadyEvent) => void>;
    onDisposing: PropType<(e: DisposingEvent) => void>;
    onInitialized: PropType<(e: InitializedEvent) => void>;
    onOptionChanged: PropType<(e: OptionChangedEvent) => void>;
    rtlEnabled: BooleanConstructor;
    tabIndex: NumberConstructor;
    visible: BooleanConstructor;
}, unknown, unknown, {
    instance(): SpeedDialAction;
}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:accessKey": null;
    "update:activeStateEnabled": null;
    "update:elementAttr": null;
    "update:focusStateEnabled": null;
    "update:hint": null;
    "update:hoverStateEnabled": null;
    "update:icon": null;
    "update:index": null;
    "update:label": null;
    "update:onClick": null;
    "update:onContentReady": null;
    "update:onDisposing": null;
    "update:onInitialized": null;
    "update:onOptionChanged": null;
    "update:rtlEnabled": null;
    "update:tabIndex": null;
    "update:visible": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    accessKey: StringConstructor;
    activeStateEnabled: BooleanConstructor;
    elementAttr: PropType<Record<string, any>>;
    focusStateEnabled: BooleanConstructor;
    hint: StringConstructor;
    hoverStateEnabled: BooleanConstructor;
    icon: StringConstructor;
    index: NumberConstructor;
    label: StringConstructor;
    onClick: PropType<(e: ClickEvent) => void>;
    onContentReady: PropType<(e: ContentReadyEvent) => void>;
    onDisposing: PropType<(e: DisposingEvent) => void>;
    onInitialized: PropType<(e: InitializedEvent) => void>;
    onOptionChanged: PropType<(e: OptionChangedEvent) => void>;
    rtlEnabled: BooleanConstructor;
    tabIndex: NumberConstructor;
    visible: BooleanConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:elementAttr"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onClick"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onDisposing"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onInitialized"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onOptionChanged"?: ((...args: any[]) => any) | undefined;
    "onUpdate:rtlEnabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:visible"?: ((...args: any[]) => any) | undefined;
    "onUpdate:label"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoverStateEnabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onContentReady"?: ((...args: any[]) => any) | undefined;
    "onUpdate:accessKey"?: ((...args: any[]) => any) | undefined;
    "onUpdate:activeStateEnabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:focusStateEnabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hint"?: ((...args: any[]) => any) | undefined;
    "onUpdate:tabIndex"?: ((...args: any[]) => any) | undefined;
    "onUpdate:icon"?: ((...args: any[]) => any) | undefined;
    "onUpdate:index"?: ((...args: any[]) => any) | undefined;
}, {
    rtlEnabled: boolean;
    visible: boolean;
    hoverStateEnabled: boolean;
    activeStateEnabled: boolean;
    focusStateEnabled: boolean;
}>;
export default DxSpeedDialAction;
export { DxSpeedDialAction };
import type * as DxSpeedDialActionTypes from "devextreme/ui/speed_dial_action_types";
export { DxSpeedDialActionTypes };
