/*!
 * devextreme-vue
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

import { PropType } from "vue";
import Draggable, { Properties } from "devextreme/ui/draggable";
import { DragDirection } from "devextreme/common";
import { DisposingEvent, DragEndEvent, DragMoveEvent, DragStartEvent, InitializedEvent, OptionChangedEvent } from "devextreme/ui/draggable";
type AccessibleOptions = Pick<Properties, "autoScroll" | "boundary" | "clone" | "container" | "cursorOffset" | "data" | "dragDirection" | "dragTemplate" | "elementAttr" | "group" | "handle" | "height" | "onDisposing" | "onDragEnd" | "onDragMove" | "onDragStart" | "onInitialized" | "onOptionChanged" | "rtlEnabled" | "scrollSensitivity" | "scrollSpeed" | "width">;
interface DxDraggable extends AccessibleOptions {
    readonly instance?: Draggable;
}
declare const DxDraggable: import("vue").DefineComponent<{
    autoScroll: BooleanConstructor;
    boundary: {};
    clone: BooleanConstructor;
    container: {};
    cursorOffset: PropType<string | Record<string, any>>;
    data: {};
    dragDirection: PropType<DragDirection>;
    dragTemplate: {};
    elementAttr: PropType<Record<string, any>>;
    group: StringConstructor;
    handle: StringConstructor;
    height: (NumberConstructor | StringConstructor)[];
    onDisposing: PropType<(e: DisposingEvent) => void>;
    onDragEnd: PropType<(e: DragEndEvent) => void>;
    onDragMove: PropType<(e: DragMoveEvent) => void>;
    onDragStart: PropType<(e: DragStartEvent) => void>;
    onInitialized: PropType<(e: InitializedEvent) => void>;
    onOptionChanged: PropType<(e: OptionChangedEvent) => void>;
    rtlEnabled: BooleanConstructor;
    scrollSensitivity: NumberConstructor;
    scrollSpeed: NumberConstructor;
    width: (NumberConstructor | StringConstructor)[];
}, unknown, unknown, {
    instance(): Draggable;
}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:autoScroll": null;
    "update:boundary": null;
    "update:clone": null;
    "update:container": null;
    "update:cursorOffset": null;
    "update:data": null;
    "update:dragDirection": null;
    "update:dragTemplate": null;
    "update:elementAttr": null;
    "update:group": null;
    "update:handle": null;
    "update:height": null;
    "update:onDisposing": null;
    "update:onDragEnd": null;
    "update:onDragMove": null;
    "update:onDragStart": null;
    "update:onInitialized": null;
    "update:onOptionChanged": null;
    "update:rtlEnabled": null;
    "update:scrollSensitivity": null;
    "update:scrollSpeed": null;
    "update:width": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    autoScroll: BooleanConstructor;
    boundary: {};
    clone: BooleanConstructor;
    container: {};
    cursorOffset: PropType<string | Record<string, any>>;
    data: {};
    dragDirection: PropType<DragDirection>;
    dragTemplate: {};
    elementAttr: PropType<Record<string, any>>;
    group: StringConstructor;
    handle: StringConstructor;
    height: (NumberConstructor | StringConstructor)[];
    onDisposing: PropType<(e: DisposingEvent) => void>;
    onDragEnd: PropType<(e: DragEndEvent) => void>;
    onDragMove: PropType<(e: DragMoveEvent) => void>;
    onDragStart: PropType<(e: DragStartEvent) => void>;
    onInitialized: PropType<(e: InitializedEvent) => void>;
    onOptionChanged: PropType<(e: OptionChangedEvent) => void>;
    rtlEnabled: BooleanConstructor;
    scrollSensitivity: NumberConstructor;
    scrollSpeed: NumberConstructor;
    width: (NumberConstructor | StringConstructor)[];
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:elementAttr"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onDisposing"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onInitialized"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onOptionChanged"?: ((...args: any[]) => any) | undefined;
    "onUpdate:rtlEnabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:data"?: ((...args: any[]) => any) | undefined;
    "onUpdate:height"?: ((...args: any[]) => any) | undefined;
    "onUpdate:width"?: ((...args: any[]) => any) | undefined;
    "onUpdate:container"?: ((...args: any[]) => any) | undefined;
    "onUpdate:group"?: ((...args: any[]) => any) | undefined;
    "onUpdate:boundary"?: ((...args: any[]) => any) | undefined;
    "onUpdate:autoScroll"?: ((...args: any[]) => any) | undefined;
    "onUpdate:cursorOffset"?: ((...args: any[]) => any) | undefined;
    "onUpdate:dragDirection"?: ((...args: any[]) => any) | undefined;
    "onUpdate:dragTemplate"?: ((...args: any[]) => any) | undefined;
    "onUpdate:handle"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onDragEnd"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onDragMove"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onDragStart"?: ((...args: any[]) => any) | undefined;
    "onUpdate:scrollSensitivity"?: ((...args: any[]) => any) | undefined;
    "onUpdate:scrollSpeed"?: ((...args: any[]) => any) | undefined;
    "onUpdate:clone"?: ((...args: any[]) => any) | undefined;
}, {
    rtlEnabled: boolean;
    autoScroll: boolean;
    clone: boolean;
}>;
declare const DxCursorOffset: import("vue").DefineComponent<{
    x: NumberConstructor;
    y: NumberConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:x": null;
    "update:y": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    x: NumberConstructor;
    y: NumberConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:x"?: ((...args: any[]) => any) | undefined;
    "onUpdate:y"?: ((...args: any[]) => any) | undefined;
}, {}>;
export default DxDraggable;
export { DxDraggable, DxCursorOffset };
import type * as DxDraggableTypes from "devextreme/ui/draggable_types";
export { DxDraggableTypes };
