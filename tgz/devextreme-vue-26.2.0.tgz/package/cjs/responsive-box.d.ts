/*!
 * devextreme-vue
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

export { ExplicitTypes } from "devextreme/ui/responsive_box";
import { PropType } from "vue";
import ResponsiveBox, { Properties } from "devextreme/ui/responsive_box";
import DataSource from "devextreme/data/data_source";
import { ContentReadyEvent, DisposingEvent, InitializedEvent, ItemClickEvent, ItemContextMenuEvent, ItemHoldEvent, ItemRenderedEvent, OptionChangedEvent } from "devextreme/ui/responsive_box";
import { DataSourceOptions } from "devextreme/common/data";
import { Store } from "devextreme/data/store";
type AccessibleOptions = Pick<Properties, "cols" | "dataSource" | "disabled" | "elementAttr" | "height" | "hoverStateEnabled" | "itemHoldTimeout" | "items" | "itemTemplate" | "onContentReady" | "onDisposing" | "onInitialized" | "onItemClick" | "onItemContextMenu" | "onItemHold" | "onItemRendered" | "onOptionChanged" | "rows" | "rtlEnabled" | "screenByWidth" | "singleColumnScreen" | "visible" | "width">;
interface DxResponsiveBox extends AccessibleOptions {
    readonly instance?: ResponsiveBox;
}
declare const DxResponsiveBox: import("vue").DefineComponent<{
    cols: PropType<Record<string, any>[]>;
    dataSource: PropType<string | any[] | Record<string, any> | DataSource<any, any> | DataSourceOptions<any, any, any, any> | Store<any, any> | null>;
    disabled: BooleanConstructor;
    elementAttr: PropType<Record<string, any>>;
    height: (NumberConstructor | StringConstructor)[];
    hoverStateEnabled: BooleanConstructor;
    itemHoldTimeout: NumberConstructor;
    items: PropType<any[]>;
    itemTemplate: {};
    onContentReady: PropType<(e: ContentReadyEvent) => void>;
    onDisposing: PropType<(e: DisposingEvent) => void>;
    onInitialized: PropType<(e: InitializedEvent) => void>;
    onItemClick: PropType<(e: ItemClickEvent) => void>;
    onItemContextMenu: PropType<(e: ItemContextMenuEvent) => void>;
    onItemHold: PropType<(e: ItemHoldEvent) => void>;
    onItemRendered: PropType<(e: ItemRenderedEvent) => void>;
    onOptionChanged: PropType<(e: OptionChangedEvent) => void>;
    rows: PropType<Record<string, any>[]>;
    rtlEnabled: BooleanConstructor;
    screenByWidth: PropType<() => void>;
    singleColumnScreen: StringConstructor;
    visible: BooleanConstructor;
    width: (NumberConstructor | StringConstructor)[];
}, unknown, unknown, {
    instance(): ResponsiveBox;
}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:cols": null;
    "update:dataSource": null;
    "update:disabled": null;
    "update:elementAttr": null;
    "update:height": null;
    "update:hoverStateEnabled": null;
    "update:itemHoldTimeout": null;
    "update:items": null;
    "update:itemTemplate": null;
    "update:onContentReady": null;
    "update:onDisposing": null;
    "update:onInitialized": null;
    "update:onItemClick": null;
    "update:onItemContextMenu": null;
    "update:onItemHold": null;
    "update:onItemRendered": null;
    "update:onOptionChanged": null;
    "update:rows": null;
    "update:rtlEnabled": null;
    "update:screenByWidth": null;
    "update:singleColumnScreen": null;
    "update:visible": null;
    "update:width": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    cols: PropType<Record<string, any>[]>;
    dataSource: PropType<string | any[] | Record<string, any> | DataSource<any, any> | DataSourceOptions<any, any, any, any> | Store<any, any> | null>;
    disabled: BooleanConstructor;
    elementAttr: PropType<Record<string, any>>;
    height: (NumberConstructor | StringConstructor)[];
    hoverStateEnabled: BooleanConstructor;
    itemHoldTimeout: NumberConstructor;
    items: PropType<any[]>;
    itemTemplate: {};
    onContentReady: PropType<(e: ContentReadyEvent) => void>;
    onDisposing: PropType<(e: DisposingEvent) => void>;
    onInitialized: PropType<(e: InitializedEvent) => void>;
    onItemClick: PropType<(e: ItemClickEvent) => void>;
    onItemContextMenu: PropType<(e: ItemContextMenuEvent) => void>;
    onItemHold: PropType<(e: ItemHoldEvent) => void>;
    onItemRendered: PropType<(e: ItemRenderedEvent) => void>;
    onOptionChanged: PropType<(e: OptionChangedEvent) => void>;
    rows: PropType<Record<string, any>[]>;
    rtlEnabled: BooleanConstructor;
    screenByWidth: PropType<() => void>;
    singleColumnScreen: StringConstructor;
    visible: BooleanConstructor;
    width: (NumberConstructor | StringConstructor)[];
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:disabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:elementAttr"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onDisposing"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onInitialized"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onOptionChanged"?: ((...args: any[]) => any) | undefined;
    "onUpdate:rtlEnabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:height"?: ((...args: any[]) => any) | undefined;
    "onUpdate:width"?: ((...args: any[]) => any) | undefined;
    "onUpdate:visible"?: ((...args: any[]) => any) | undefined;
    "onUpdate:dataSource"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoverStateEnabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:items"?: ((...args: any[]) => any) | undefined;
    "onUpdate:itemTemplate"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onContentReady"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onItemClick"?: ((...args: any[]) => any) | undefined;
    "onUpdate:itemHoldTimeout"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onItemContextMenu"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onItemHold"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onItemRendered"?: ((...args: any[]) => any) | undefined;
    "onUpdate:screenByWidth"?: ((...args: any[]) => any) | undefined;
    "onUpdate:cols"?: ((...args: any[]) => any) | undefined;
    "onUpdate:rows"?: ((...args: any[]) => any) | undefined;
    "onUpdate:singleColumnScreen"?: ((...args: any[]) => any) | undefined;
}, {
    disabled: boolean;
    rtlEnabled: boolean;
    visible: boolean;
    hoverStateEnabled: boolean;
}>;
declare const DxCol: import("vue").DefineComponent<{
    baseSize: (NumberConstructor | StringConstructor)[];
    ratio: NumberConstructor;
    screen: StringConstructor;
    shrink: NumberConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:baseSize": null;
    "update:ratio": null;
    "update:screen": null;
    "update:shrink": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    baseSize: (NumberConstructor | StringConstructor)[];
    ratio: NumberConstructor;
    screen: StringConstructor;
    shrink: NumberConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:baseSize"?: ((...args: any[]) => any) | undefined;
    "onUpdate:ratio"?: ((...args: any[]) => any) | undefined;
    "onUpdate:screen"?: ((...args: any[]) => any) | undefined;
    "onUpdate:shrink"?: ((...args: any[]) => any) | undefined;
}, {}>;
declare const DxItem: import("vue").DefineComponent<{
    disabled: BooleanConstructor;
    html: StringConstructor;
    location: PropType<Record<string, any> | Record<string, any>[]>;
    template: {};
    text: StringConstructor;
    visible: BooleanConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:disabled": null;
    "update:html": null;
    "update:location": null;
    "update:template": null;
    "update:text": null;
    "update:visible": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    disabled: BooleanConstructor;
    html: StringConstructor;
    location: PropType<Record<string, any> | Record<string, any>[]>;
    template: {};
    text: StringConstructor;
    visible: BooleanConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:disabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:template"?: ((...args: any[]) => any) | undefined;
    "onUpdate:text"?: ((...args: any[]) => any) | undefined;
    "onUpdate:visible"?: ((...args: any[]) => any) | undefined;
    "onUpdate:html"?: ((...args: any[]) => any) | undefined;
    "onUpdate:location"?: ((...args: any[]) => any) | undefined;
}, {
    disabled: boolean;
    visible: boolean;
}>;
declare const DxLocation: import("vue").DefineComponent<{
    col: NumberConstructor;
    colspan: NumberConstructor;
    row: NumberConstructor;
    rowspan: NumberConstructor;
    screen: StringConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:col": null;
    "update:colspan": null;
    "update:row": null;
    "update:rowspan": null;
    "update:screen": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    col: NumberConstructor;
    colspan: NumberConstructor;
    row: NumberConstructor;
    rowspan: NumberConstructor;
    screen: StringConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:screen"?: ((...args: any[]) => any) | undefined;
    "onUpdate:col"?: ((...args: any[]) => any) | undefined;
    "onUpdate:colspan"?: ((...args: any[]) => any) | undefined;
    "onUpdate:row"?: ((...args: any[]) => any) | undefined;
    "onUpdate:rowspan"?: ((...args: any[]) => any) | undefined;
}, {}>;
declare const DxRow: import("vue").DefineComponent<{
    baseSize: (NumberConstructor | StringConstructor)[];
    ratio: NumberConstructor;
    screen: StringConstructor;
    shrink: NumberConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:baseSize": null;
    "update:ratio": null;
    "update:screen": null;
    "update:shrink": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    baseSize: (NumberConstructor | StringConstructor)[];
    ratio: NumberConstructor;
    screen: StringConstructor;
    shrink: NumberConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:baseSize"?: ((...args: any[]) => any) | undefined;
    "onUpdate:ratio"?: ((...args: any[]) => any) | undefined;
    "onUpdate:screen"?: ((...args: any[]) => any) | undefined;
    "onUpdate:shrink"?: ((...args: any[]) => any) | undefined;
}, {}>;
export default DxResponsiveBox;
export { DxResponsiveBox, DxCol, DxItem, DxLocation, DxRow };
import type * as DxResponsiveBoxTypes from "devextreme/ui/responsive_box_types";
export { DxResponsiveBoxTypes };
