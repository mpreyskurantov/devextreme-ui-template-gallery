/*!
 * devextreme-vue
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

import { PropType } from "vue";
import Pagination, { Properties } from "devextreme/ui/pagination";
import DOMComponent from "devextreme/core/dom_component";
import { DisplayMode } from "devextreme/common";
import { EventInfo } from "devextreme/common/core/events";
import { Component } from "devextreme/core/component";
type AccessibleOptions = Pick<Properties, "accessKey" | "activeStateEnabled" | "allowedPageSizes" | "disabled" | "displayMode" | "elementAttr" | "focusStateEnabled" | "height" | "hint" | "hoverStateEnabled" | "infoText" | "itemCount" | "label" | "onContentReady" | "onDisposing" | "onInitialized" | "onOptionChanged" | "pageIndex" | "pageSize" | "rtlEnabled" | "showInfo" | "showNavigationButtons" | "showPageSizeSelector" | "tabIndex" | "visible" | "width">;
interface DxPagination extends AccessibleOptions {
    readonly instance?: Pagination;
}
declare const DxPagination: import("vue").DefineComponent<{
    accessKey: StringConstructor;
    activeStateEnabled: BooleanConstructor;
    allowedPageSizes: PropType<(string | number)[]>;
    disabled: BooleanConstructor;
    displayMode: PropType<DisplayMode>;
    elementAttr: PropType<Record<string, any>>;
    focusStateEnabled: BooleanConstructor;
    height: (NumberConstructor | StringConstructor)[];
    hint: StringConstructor;
    hoverStateEnabled: BooleanConstructor;
    infoText: StringConstructor;
    itemCount: NumberConstructor;
    label: StringConstructor;
    onContentReady: PropType<(e: EventInfo<any>) => void>;
    onDisposing: PropType<(e: EventInfo<any>) => void>;
    onInitialized: PropType<(e: {
        component: Component<any>;
        element: any;
    }) => void>;
    onOptionChanged: PropType<(e: {
        component: DOMComponent;
        element: any;
        fullName: string;
        model: any;
        name: string;
        previousValue: any;
        value: any;
    }) => void>;
    pageIndex: NumberConstructor;
    pageSize: NumberConstructor;
    rtlEnabled: BooleanConstructor;
    showInfo: BooleanConstructor;
    showNavigationButtons: BooleanConstructor;
    showPageSizeSelector: PropType<boolean | "auto">;
    tabIndex: NumberConstructor;
    visible: BooleanConstructor;
    width: (NumberConstructor | StringConstructor)[];
}, unknown, unknown, {
    instance(): Pagination;
}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:accessKey": null;
    "update:activeStateEnabled": null;
    "update:allowedPageSizes": null;
    "update:disabled": null;
    "update:displayMode": null;
    "update:elementAttr": null;
    "update:focusStateEnabled": null;
    "update:height": null;
    "update:hint": null;
    "update:hoverStateEnabled": null;
    "update:infoText": null;
    "update:itemCount": null;
    "update:label": null;
    "update:onContentReady": null;
    "update:onDisposing": null;
    "update:onInitialized": null;
    "update:onOptionChanged": null;
    "update:pageIndex": null;
    "update:pageSize": null;
    "update:rtlEnabled": null;
    "update:showInfo": null;
    "update:showNavigationButtons": null;
    "update:showPageSizeSelector": null;
    "update:tabIndex": null;
    "update:visible": null;
    "update:width": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    accessKey: StringConstructor;
    activeStateEnabled: BooleanConstructor;
    allowedPageSizes: PropType<(string | number)[]>;
    disabled: BooleanConstructor;
    displayMode: PropType<DisplayMode>;
    elementAttr: PropType<Record<string, any>>;
    focusStateEnabled: BooleanConstructor;
    height: (NumberConstructor | StringConstructor)[];
    hint: StringConstructor;
    hoverStateEnabled: BooleanConstructor;
    infoText: StringConstructor;
    itemCount: NumberConstructor;
    label: StringConstructor;
    onContentReady: PropType<(e: EventInfo<any>) => void>;
    onDisposing: PropType<(e: EventInfo<any>) => void>;
    onInitialized: PropType<(e: {
        component: Component<any>;
        element: any;
    }) => void>;
    onOptionChanged: PropType<(e: {
        component: DOMComponent;
        element: any;
        fullName: string;
        model: any;
        name: string;
        previousValue: any;
        value: any;
    }) => void>;
    pageIndex: NumberConstructor;
    pageSize: NumberConstructor;
    rtlEnabled: BooleanConstructor;
    showInfo: BooleanConstructor;
    showNavigationButtons: BooleanConstructor;
    showPageSizeSelector: PropType<boolean | "auto">;
    tabIndex: NumberConstructor;
    visible: BooleanConstructor;
    width: (NumberConstructor | StringConstructor)[];
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:disabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:elementAttr"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onDisposing"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onInitialized"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onOptionChanged"?: ((...args: any[]) => any) | undefined;
    "onUpdate:rtlEnabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:height"?: ((...args: any[]) => any) | undefined;
    "onUpdate:width"?: ((...args: any[]) => any) | undefined;
    "onUpdate:visible"?: ((...args: any[]) => any) | undefined;
    "onUpdate:label"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoverStateEnabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onContentReady"?: ((...args: any[]) => any) | undefined;
    "onUpdate:accessKey"?: ((...args: any[]) => any) | undefined;
    "onUpdate:activeStateEnabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:focusStateEnabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hint"?: ((...args: any[]) => any) | undefined;
    "onUpdate:tabIndex"?: ((...args: any[]) => any) | undefined;
    "onUpdate:allowedPageSizes"?: ((...args: any[]) => any) | undefined;
    "onUpdate:displayMode"?: ((...args: any[]) => any) | undefined;
    "onUpdate:infoText"?: ((...args: any[]) => any) | undefined;
    "onUpdate:showInfo"?: ((...args: any[]) => any) | undefined;
    "onUpdate:showNavigationButtons"?: ((...args: any[]) => any) | undefined;
    "onUpdate:showPageSizeSelector"?: ((...args: any[]) => any) | undefined;
    "onUpdate:pageIndex"?: ((...args: any[]) => any) | undefined;
    "onUpdate:pageSize"?: ((...args: any[]) => any) | undefined;
    "onUpdate:itemCount"?: ((...args: any[]) => any) | undefined;
}, {
    disabled: boolean;
    rtlEnabled: boolean;
    visible: boolean;
    hoverStateEnabled: boolean;
    activeStateEnabled: boolean;
    focusStateEnabled: boolean;
    showInfo: boolean;
    showNavigationButtons: boolean;
}>;
export default DxPagination;
export { DxPagination };
import type * as DxPaginationTypes from "devextreme/ui/pagination_types";
export { DxPaginationTypes };
