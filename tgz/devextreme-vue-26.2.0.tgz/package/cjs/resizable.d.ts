/*!
 * devextreme-vue
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

import { PropType } from "vue";
import Resizable, { Properties } from "devextreme/ui/resizable";
import { DisposingEvent, InitializedEvent, OptionChangedEvent, ResizeEvent, ResizeEndEvent, ResizeStartEvent } from "devextreme/ui/resizable";
type AccessibleOptions = Pick<Properties, "area" | "elementAttr" | "handles" | "height" | "keepAspectRatio" | "maxHeight" | "maxWidth" | "minHeight" | "minWidth" | "onDisposing" | "onInitialized" | "onOptionChanged" | "onResize" | "onResizeEnd" | "onResizeStart" | "rtlEnabled" | "width">;
interface DxResizable extends AccessibleOptions {
    readonly instance?: Resizable;
}
declare const DxResizable: import("vue").DefineComponent<{
    area: {};
    elementAttr: PropType<Record<string, any>>;
    handles: PropType<string>;
    height: (NumberConstructor | StringConstructor)[];
    keepAspectRatio: BooleanConstructor;
    maxHeight: NumberConstructor;
    maxWidth: NumberConstructor;
    minHeight: NumberConstructor;
    minWidth: NumberConstructor;
    onDisposing: PropType<(e: DisposingEvent) => void>;
    onInitialized: PropType<(e: InitializedEvent) => void>;
    onOptionChanged: PropType<(e: OptionChangedEvent) => void>;
    onResize: PropType<(e: ResizeEvent) => void>;
    onResizeEnd: PropType<(e: ResizeEndEvent) => void>;
    onResizeStart: PropType<(e: ResizeStartEvent) => void>;
    rtlEnabled: BooleanConstructor;
    width: (NumberConstructor | StringConstructor)[];
}, unknown, unknown, {
    instance(): Resizable;
}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:area": null;
    "update:elementAttr": null;
    "update:handles": null;
    "update:height": null;
    "update:keepAspectRatio": null;
    "update:maxHeight": null;
    "update:maxWidth": null;
    "update:minHeight": null;
    "update:minWidth": null;
    "update:onDisposing": null;
    "update:onInitialized": null;
    "update:onOptionChanged": null;
    "update:onResize": null;
    "update:onResizeEnd": null;
    "update:onResizeStart": null;
    "update:rtlEnabled": null;
    "update:width": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    area: {};
    elementAttr: PropType<Record<string, any>>;
    handles: PropType<string>;
    height: (NumberConstructor | StringConstructor)[];
    keepAspectRatio: BooleanConstructor;
    maxHeight: NumberConstructor;
    maxWidth: NumberConstructor;
    minHeight: NumberConstructor;
    minWidth: NumberConstructor;
    onDisposing: PropType<(e: DisposingEvent) => void>;
    onInitialized: PropType<(e: InitializedEvent) => void>;
    onOptionChanged: PropType<(e: OptionChangedEvent) => void>;
    onResize: PropType<(e: ResizeEvent) => void>;
    onResizeEnd: PropType<(e: ResizeEndEvent) => void>;
    onResizeStart: PropType<(e: ResizeStartEvent) => void>;
    rtlEnabled: BooleanConstructor;
    width: (NumberConstructor | StringConstructor)[];
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:elementAttr"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onDisposing"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onInitialized"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onOptionChanged"?: ((...args: any[]) => any) | undefined;
    "onUpdate:rtlEnabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:height"?: ((...args: any[]) => any) | undefined;
    "onUpdate:width"?: ((...args: any[]) => any) | undefined;
    "onUpdate:minWidth"?: ((...args: any[]) => any) | undefined;
    "onUpdate:maxHeight"?: ((...args: any[]) => any) | undefined;
    "onUpdate:maxWidth"?: ((...args: any[]) => any) | undefined;
    "onUpdate:minHeight"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onResize"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onResizeEnd"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onResizeStart"?: ((...args: any[]) => any) | undefined;
    "onUpdate:area"?: ((...args: any[]) => any) | undefined;
    "onUpdate:handles"?: ((...args: any[]) => any) | undefined;
    "onUpdate:keepAspectRatio"?: ((...args: any[]) => any) | undefined;
}, {
    rtlEnabled: boolean;
    keepAspectRatio: boolean;
}>;
export default DxResizable;
export { DxResizable };
import type * as DxResizableTypes from "devextreme/ui/resizable_types";
export { DxResizableTypes };
