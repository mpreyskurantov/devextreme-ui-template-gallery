/*!
 * devextreme-vue
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

import { PropType } from "vue";
import PieChart, { Properties } from "devextreme/viz/pie_chart";
import DataSource from "devextreme/data/data_source";
import { dxPieChartAnnotationConfig, dxPieChartCommonAnnotationConfig, DisposingEvent, DoneEvent, DrawnEvent, ExportedEvent, ExportingEvent, FileSavingEvent, IncidentOccurredEvent, InitializedEvent, LegendClickEvent, OptionChangedEvent, PointClickEvent, PointHoverChangedEvent, PointSelectionChangedEvent, TooltipHiddenEvent, TooltipShownEvent, PieChartSegmentDirection, PieChartSeries, PieChartType, PieChartAnnotationLocation, PieChartSeriesInteractionMode, PieChartLegendItem, PieChartLegendHoverMode, SmallValuesGroupingMode, dxPieChartPointInfo } from "devextreme/viz/pie_chart";
import { SeriesLabel, SeriesPoint, Palette, PaletteExtensionMode, ShiftLabelOverlap, Theme, AnimationEaseMode, Font, TextOverflow, AnnotationType, WordWrap, DashStyle, ChartsDataType, ChartsColor, HatchDirection, LabelPosition } from "devextreme/common/charts";
import { DataSourceOptions } from "devextreme/common/data";
import { Store } from "devextreme/data/store";
import { SingleOrMultiple, ExportFormat, HorizontalAlignment, Position, Orientation, VerticalEdge } from "devextreme/common";
type AccessibleOptions = Pick<Properties, "adaptiveLayout" | "animation" | "annotations" | "centerTemplate" | "commonAnnotationSettings" | "commonSeriesSettings" | "customizeAnnotation" | "customizeLabel" | "customizePoint" | "dataSource" | "diameter" | "disabled" | "elementAttr" | "encodeHtml" | "export" | "innerRadius" | "legend" | "loadingIndicator" | "margin" | "minDiameter" | "onDisposing" | "onDone" | "onDrawn" | "onExported" | "onExporting" | "onFileSaving" | "onIncidentOccurred" | "onInitialized" | "onLegendClick" | "onOptionChanged" | "onPointClick" | "onPointHoverChanged" | "onPointSelectionChanged" | "onTooltipHidden" | "onTooltipShown" | "palette" | "paletteExtensionMode" | "pathModified" | "pointSelectionMode" | "redrawOnResize" | "resolveLabelOverlapping" | "rtlEnabled" | "segmentsDirection" | "series" | "seriesTemplate" | "size" | "sizeGroup" | "startAngle" | "theme" | "title" | "tooltip" | "type">;
interface DxPieChart extends AccessibleOptions {
    readonly instance?: PieChart;
}
declare const DxPieChart: import("vue").DefineComponent<{
    adaptiveLayout: PropType<Record<string, any>>;
    animation: PropType<boolean | Record<string, any>>;
    annotations: PropType<any[]>;
    centerTemplate: {};
    commonAnnotationSettings: PropType<Record<string, any> | dxPieChartCommonAnnotationConfig>;
    commonSeriesSettings: {};
    customizeAnnotation: PropType<(annotation: dxPieChartAnnotationConfig | any) => dxPieChartAnnotationConfig>;
    customizeLabel: PropType<(pointInfo: any) => SeriesLabel>;
    customizePoint: PropType<(pointInfo: any) => SeriesPoint>;
    dataSource: PropType<string | any[] | Record<string, any> | DataSource<any, any> | DataSourceOptions<any, any, any, any> | Store<any, any> | null>;
    diameter: NumberConstructor;
    disabled: BooleanConstructor;
    elementAttr: PropType<Record<string, any>>;
    encodeHtml: BooleanConstructor;
    export: PropType<Record<string, any>>;
    innerRadius: NumberConstructor;
    legend: PropType<Record<string, any>>;
    loadingIndicator: PropType<Record<string, any>>;
    margin: PropType<Record<string, any>>;
    minDiameter: NumberConstructor;
    onDisposing: PropType<(e: DisposingEvent) => void>;
    onDone: PropType<(e: DoneEvent) => void>;
    onDrawn: PropType<(e: DrawnEvent) => void>;
    onExported: PropType<(e: ExportedEvent) => void>;
    onExporting: PropType<(e: ExportingEvent) => void>;
    onFileSaving: PropType<(e: FileSavingEvent) => void>;
    onIncidentOccurred: PropType<(e: IncidentOccurredEvent) => void>;
    onInitialized: PropType<(e: InitializedEvent) => void>;
    onLegendClick: PropType<(e: LegendClickEvent) => void>;
    onOptionChanged: PropType<(e: OptionChangedEvent) => void>;
    onPointClick: PropType<(e: PointClickEvent) => void>;
    onPointHoverChanged: PropType<(e: PointHoverChangedEvent) => void>;
    onPointSelectionChanged: PropType<(e: PointSelectionChangedEvent) => void>;
    onTooltipHidden: PropType<(e: TooltipHiddenEvent) => void>;
    onTooltipShown: PropType<(e: TooltipShownEvent) => void>;
    palette: PropType<string[] | Palette>;
    paletteExtensionMode: PropType<PaletteExtensionMode>;
    pathModified: BooleanConstructor;
    pointSelectionMode: PropType<SingleOrMultiple>;
    redrawOnResize: BooleanConstructor;
    resolveLabelOverlapping: PropType<ShiftLabelOverlap>;
    rtlEnabled: BooleanConstructor;
    segmentsDirection: PropType<PieChartSegmentDirection>;
    series: PropType<Record<string, any> | PieChartSeries | PieChartSeries[]>;
    seriesTemplate: PropType<Record<string, any>>;
    size: PropType<Record<string, any>>;
    sizeGroup: StringConstructor;
    startAngle: NumberConstructor;
    theme: PropType<Theme>;
    title: PropType<string | Record<string, any>>;
    tooltip: PropType<Record<string, any>>;
    type: PropType<PieChartType>;
}, unknown, unknown, {
    instance(): PieChart;
}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:adaptiveLayout": null;
    "update:animation": null;
    "update:annotations": null;
    "update:centerTemplate": null;
    "update:commonAnnotationSettings": null;
    "update:commonSeriesSettings": null;
    "update:customizeAnnotation": null;
    "update:customizeLabel": null;
    "update:customizePoint": null;
    "update:dataSource": null;
    "update:diameter": null;
    "update:disabled": null;
    "update:elementAttr": null;
    "update:encodeHtml": null;
    "update:export": null;
    "update:innerRadius": null;
    "update:legend": null;
    "update:loadingIndicator": null;
    "update:margin": null;
    "update:minDiameter": null;
    "update:onDisposing": null;
    "update:onDone": null;
    "update:onDrawn": null;
    "update:onExported": null;
    "update:onExporting": null;
    "update:onFileSaving": null;
    "update:onIncidentOccurred": null;
    "update:onInitialized": null;
    "update:onLegendClick": null;
    "update:onOptionChanged": null;
    "update:onPointClick": null;
    "update:onPointHoverChanged": null;
    "update:onPointSelectionChanged": null;
    "update:onTooltipHidden": null;
    "update:onTooltipShown": null;
    "update:palette": null;
    "update:paletteExtensionMode": null;
    "update:pathModified": null;
    "update:pointSelectionMode": null;
    "update:redrawOnResize": null;
    "update:resolveLabelOverlapping": null;
    "update:rtlEnabled": null;
    "update:segmentsDirection": null;
    "update:series": null;
    "update:seriesTemplate": null;
    "update:size": null;
    "update:sizeGroup": null;
    "update:startAngle": null;
    "update:theme": null;
    "update:title": null;
    "update:tooltip": null;
    "update:type": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    adaptiveLayout: PropType<Record<string, any>>;
    animation: PropType<boolean | Record<string, any>>;
    annotations: PropType<any[]>;
    centerTemplate: {};
    commonAnnotationSettings: PropType<Record<string, any> | dxPieChartCommonAnnotationConfig>;
    commonSeriesSettings: {};
    customizeAnnotation: PropType<(annotation: dxPieChartAnnotationConfig | any) => dxPieChartAnnotationConfig>;
    customizeLabel: PropType<(pointInfo: any) => SeriesLabel>;
    customizePoint: PropType<(pointInfo: any) => SeriesPoint>;
    dataSource: PropType<string | any[] | Record<string, any> | DataSource<any, any> | DataSourceOptions<any, any, any, any> | Store<any, any> | null>;
    diameter: NumberConstructor;
    disabled: BooleanConstructor;
    elementAttr: PropType<Record<string, any>>;
    encodeHtml: BooleanConstructor;
    export: PropType<Record<string, any>>;
    innerRadius: NumberConstructor;
    legend: PropType<Record<string, any>>;
    loadingIndicator: PropType<Record<string, any>>;
    margin: PropType<Record<string, any>>;
    minDiameter: NumberConstructor;
    onDisposing: PropType<(e: DisposingEvent) => void>;
    onDone: PropType<(e: DoneEvent) => void>;
    onDrawn: PropType<(e: DrawnEvent) => void>;
    onExported: PropType<(e: ExportedEvent) => void>;
    onExporting: PropType<(e: ExportingEvent) => void>;
    onFileSaving: PropType<(e: FileSavingEvent) => void>;
    onIncidentOccurred: PropType<(e: IncidentOccurredEvent) => void>;
    onInitialized: PropType<(e: InitializedEvent) => void>;
    onLegendClick: PropType<(e: LegendClickEvent) => void>;
    onOptionChanged: PropType<(e: OptionChangedEvent) => void>;
    onPointClick: PropType<(e: PointClickEvent) => void>;
    onPointHoverChanged: PropType<(e: PointHoverChangedEvent) => void>;
    onPointSelectionChanged: PropType<(e: PointSelectionChangedEvent) => void>;
    onTooltipHidden: PropType<(e: TooltipHiddenEvent) => void>;
    onTooltipShown: PropType<(e: TooltipShownEvent) => void>;
    palette: PropType<string[] | Palette>;
    paletteExtensionMode: PropType<PaletteExtensionMode>;
    pathModified: BooleanConstructor;
    pointSelectionMode: PropType<SingleOrMultiple>;
    redrawOnResize: BooleanConstructor;
    resolveLabelOverlapping: PropType<ShiftLabelOverlap>;
    rtlEnabled: BooleanConstructor;
    segmentsDirection: PropType<PieChartSegmentDirection>;
    series: PropType<Record<string, any> | PieChartSeries | PieChartSeries[]>;
    seriesTemplate: PropType<Record<string, any>>;
    size: PropType<Record<string, any>>;
    sizeGroup: StringConstructor;
    startAngle: NumberConstructor;
    theme: PropType<Theme>;
    title: PropType<string | Record<string, any>>;
    tooltip: PropType<Record<string, any>>;
    type: PropType<PieChartType>;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:annotations"?: ((...args: any[]) => any) | undefined;
    "onUpdate:commonAnnotationSettings"?: ((...args: any[]) => any) | undefined;
    "onUpdate:customizeAnnotation"?: ((...args: any[]) => any) | undefined;
    "onUpdate:disabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:elementAttr"?: ((...args: any[]) => any) | undefined;
    "onUpdate:encodeHtml"?: ((...args: any[]) => any) | undefined;
    "onUpdate:export"?: ((...args: any[]) => any) | undefined;
    "onUpdate:loadingIndicator"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onDisposing"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onDrawn"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onExported"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onExporting"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onFileSaving"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onIncidentOccurred"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onInitialized"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onOptionChanged"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onTooltipHidden"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onTooltipShown"?: ((...args: any[]) => any) | undefined;
    "onUpdate:pathModified"?: ((...args: any[]) => any) | undefined;
    "onUpdate:redrawOnResize"?: ((...args: any[]) => any) | undefined;
    "onUpdate:rtlEnabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:size"?: ((...args: any[]) => any) | undefined;
    "onUpdate:theme"?: ((...args: any[]) => any) | undefined;
    "onUpdate:title"?: ((...args: any[]) => any) | undefined;
    "onUpdate:tooltip"?: ((...args: any[]) => any) | undefined;
    "onUpdate:type"?: ((...args: any[]) => any) | undefined;
    "onUpdate:margin"?: ((...args: any[]) => any) | undefined;
    "onUpdate:dataSource"?: ((...args: any[]) => any) | undefined;
    "onUpdate:palette"?: ((...args: any[]) => any) | undefined;
    "onUpdate:paletteExtensionMode"?: ((...args: any[]) => any) | undefined;
    "onUpdate:animation"?: ((...args: any[]) => any) | undefined;
    "onUpdate:adaptiveLayout"?: ((...args: any[]) => any) | undefined;
    "onUpdate:commonSeriesSettings"?: ((...args: any[]) => any) | undefined;
    "onUpdate:series"?: ((...args: any[]) => any) | undefined;
    "onUpdate:seriesTemplate"?: ((...args: any[]) => any) | undefined;
    "onUpdate:customizeLabel"?: ((...args: any[]) => any) | undefined;
    "onUpdate:customizePoint"?: ((...args: any[]) => any) | undefined;
    "onUpdate:legend"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onDone"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onLegendClick"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onPointClick"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onPointHoverChanged"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onPointSelectionChanged"?: ((...args: any[]) => any) | undefined;
    "onUpdate:pointSelectionMode"?: ((...args: any[]) => any) | undefined;
    "onUpdate:resolveLabelOverlapping"?: ((...args: any[]) => any) | undefined;
    "onUpdate:startAngle"?: ((...args: any[]) => any) | undefined;
    "onUpdate:centerTemplate"?: ((...args: any[]) => any) | undefined;
    "onUpdate:diameter"?: ((...args: any[]) => any) | undefined;
    "onUpdate:innerRadius"?: ((...args: any[]) => any) | undefined;
    "onUpdate:minDiameter"?: ((...args: any[]) => any) | undefined;
    "onUpdate:segmentsDirection"?: ((...args: any[]) => any) | undefined;
    "onUpdate:sizeGroup"?: ((...args: any[]) => any) | undefined;
}, {
    disabled: boolean;
    encodeHtml: boolean;
    pathModified: boolean;
    redrawOnResize: boolean;
    rtlEnabled: boolean;
}>;
declare const DxAdaptiveLayout: import("vue").DefineComponent<{
    height: NumberConstructor;
    keepLabels: BooleanConstructor;
    width: NumberConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:height": null;
    "update:keepLabels": null;
    "update:width": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    height: NumberConstructor;
    keepLabels: BooleanConstructor;
    width: NumberConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:height"?: ((...args: any[]) => any) | undefined;
    "onUpdate:width"?: ((...args: any[]) => any) | undefined;
    "onUpdate:keepLabels"?: ((...args: any[]) => any) | undefined;
}, {
    keepLabels: boolean;
}>;
declare const DxAnimation: import("vue").DefineComponent<{
    duration: NumberConstructor;
    easing: PropType<AnimationEaseMode>;
    enabled: BooleanConstructor;
    maxPointCountSupported: NumberConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:duration": null;
    "update:easing": null;
    "update:enabled": null;
    "update:maxPointCountSupported": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    duration: NumberConstructor;
    easing: PropType<AnimationEaseMode>;
    enabled: BooleanConstructor;
    maxPointCountSupported: NumberConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:enabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:duration"?: ((...args: any[]) => any) | undefined;
    "onUpdate:easing"?: ((...args: any[]) => any) | undefined;
    "onUpdate:maxPointCountSupported"?: ((...args: any[]) => any) | undefined;
}, {
    enabled: boolean;
}>;
declare const DxAnnotation: import("vue").DefineComponent<{
    allowDragging: BooleanConstructor;
    argument: (DateConstructor | NumberConstructor | StringConstructor)[];
    arrowLength: NumberConstructor;
    arrowWidth: NumberConstructor;
    border: PropType<Record<string, any>>;
    color: StringConstructor;
    customizeTooltip: PropType<(annotation: dxPieChartAnnotationConfig | any) => Record<string, any>>;
    data: {};
    description: StringConstructor;
    font: PropType<Record<string, any> | Font>;
    height: NumberConstructor;
    image: PropType<string | Record<string, any>>;
    location: PropType<PieChartAnnotationLocation>;
    name: StringConstructor;
    offsetX: NumberConstructor;
    offsetY: NumberConstructor;
    opacity: NumberConstructor;
    paddingLeftRight: NumberConstructor;
    paddingTopBottom: NumberConstructor;
    series: StringConstructor;
    shadow: PropType<Record<string, any>>;
    template: {};
    text: StringConstructor;
    textOverflow: PropType<TextOverflow>;
    tooltipEnabled: BooleanConstructor;
    tooltipTemplate: {};
    type: PropType<AnnotationType>;
    width: NumberConstructor;
    wordWrap: PropType<WordWrap>;
    x: NumberConstructor;
    y: NumberConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:allowDragging": null;
    "update:argument": null;
    "update:arrowLength": null;
    "update:arrowWidth": null;
    "update:border": null;
    "update:color": null;
    "update:customizeTooltip": null;
    "update:data": null;
    "update:description": null;
    "update:font": null;
    "update:height": null;
    "update:image": null;
    "update:location": null;
    "update:name": null;
    "update:offsetX": null;
    "update:offsetY": null;
    "update:opacity": null;
    "update:paddingLeftRight": null;
    "update:paddingTopBottom": null;
    "update:series": null;
    "update:shadow": null;
    "update:template": null;
    "update:text": null;
    "update:textOverflow": null;
    "update:tooltipEnabled": null;
    "update:tooltipTemplate": null;
    "update:type": null;
    "update:width": null;
    "update:wordWrap": null;
    "update:x": null;
    "update:y": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    allowDragging: BooleanConstructor;
    argument: (DateConstructor | NumberConstructor | StringConstructor)[];
    arrowLength: NumberConstructor;
    arrowWidth: NumberConstructor;
    border: PropType<Record<string, any>>;
    color: StringConstructor;
    customizeTooltip: PropType<(annotation: dxPieChartAnnotationConfig | any) => Record<string, any>>;
    data: {};
    description: StringConstructor;
    font: PropType<Record<string, any> | Font>;
    height: NumberConstructor;
    image: PropType<string | Record<string, any>>;
    location: PropType<PieChartAnnotationLocation>;
    name: StringConstructor;
    offsetX: NumberConstructor;
    offsetY: NumberConstructor;
    opacity: NumberConstructor;
    paddingLeftRight: NumberConstructor;
    paddingTopBottom: NumberConstructor;
    series: StringConstructor;
    shadow: PropType<Record<string, any>>;
    template: {};
    text: StringConstructor;
    textOverflow: PropType<TextOverflow>;
    tooltipEnabled: BooleanConstructor;
    tooltipTemplate: {};
    type: PropType<AnnotationType>;
    width: NumberConstructor;
    wordWrap: PropType<WordWrap>;
    x: NumberConstructor;
    y: NumberConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:allowDragging"?: ((...args: any[]) => any) | undefined;
    "onUpdate:arrowLength"?: ((...args: any[]) => any) | undefined;
    "onUpdate:arrowWidth"?: ((...args: any[]) => any) | undefined;
    "onUpdate:border"?: ((...args: any[]) => any) | undefined;
    "onUpdate:color"?: ((...args: any[]) => any) | undefined;
    "onUpdate:customizeTooltip"?: ((...args: any[]) => any) | undefined;
    "onUpdate:data"?: ((...args: any[]) => any) | undefined;
    "onUpdate:description"?: ((...args: any[]) => any) | undefined;
    "onUpdate:font"?: ((...args: any[]) => any) | undefined;
    "onUpdate:height"?: ((...args: any[]) => any) | undefined;
    "onUpdate:image"?: ((...args: any[]) => any) | undefined;
    "onUpdate:name"?: ((...args: any[]) => any) | undefined;
    "onUpdate:offsetX"?: ((...args: any[]) => any) | undefined;
    "onUpdate:offsetY"?: ((...args: any[]) => any) | undefined;
    "onUpdate:opacity"?: ((...args: any[]) => any) | undefined;
    "onUpdate:paddingLeftRight"?: ((...args: any[]) => any) | undefined;
    "onUpdate:paddingTopBottom"?: ((...args: any[]) => any) | undefined;
    "onUpdate:shadow"?: ((...args: any[]) => any) | undefined;
    "onUpdate:template"?: ((...args: any[]) => any) | undefined;
    "onUpdate:text"?: ((...args: any[]) => any) | undefined;
    "onUpdate:textOverflow"?: ((...args: any[]) => any) | undefined;
    "onUpdate:tooltipEnabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:tooltipTemplate"?: ((...args: any[]) => any) | undefined;
    "onUpdate:type"?: ((...args: any[]) => any) | undefined;
    "onUpdate:width"?: ((...args: any[]) => any) | undefined;
    "onUpdate:wordWrap"?: ((...args: any[]) => any) | undefined;
    "onUpdate:x"?: ((...args: any[]) => any) | undefined;
    "onUpdate:y"?: ((...args: any[]) => any) | undefined;
    "onUpdate:location"?: ((...args: any[]) => any) | undefined;
    "onUpdate:series"?: ((...args: any[]) => any) | undefined;
    "onUpdate:argument"?: ((...args: any[]) => any) | undefined;
}, {
    allowDragging: boolean;
    tooltipEnabled: boolean;
}>;
declare const DxAnnotationBorder: import("vue").DefineComponent<{
    color: StringConstructor;
    cornerRadius: NumberConstructor;
    dashStyle: PropType<DashStyle>;
    opacity: NumberConstructor;
    visible: BooleanConstructor;
    width: NumberConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:color": null;
    "update:cornerRadius": null;
    "update:dashStyle": null;
    "update:opacity": null;
    "update:visible": null;
    "update:width": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    color: StringConstructor;
    cornerRadius: NumberConstructor;
    dashStyle: PropType<DashStyle>;
    opacity: NumberConstructor;
    visible: BooleanConstructor;
    width: NumberConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:color"?: ((...args: any[]) => any) | undefined;
    "onUpdate:opacity"?: ((...args: any[]) => any) | undefined;
    "onUpdate:width"?: ((...args: any[]) => any) | undefined;
    "onUpdate:cornerRadius"?: ((...args: any[]) => any) | undefined;
    "onUpdate:dashStyle"?: ((...args: any[]) => any) | undefined;
    "onUpdate:visible"?: ((...args: any[]) => any) | undefined;
}, {
    visible: boolean;
}>;
declare const DxArgumentFormat: import("vue").DefineComponent<{
    currency: StringConstructor;
    formatter: PropType<(value: number | Date) => string>;
    parser: PropType<(value: string) => number | Date>;
    precision: NumberConstructor;
    type: PropType<string>;
    useCurrencyAccountingStyle: BooleanConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:currency": null;
    "update:formatter": null;
    "update:parser": null;
    "update:precision": null;
    "update:type": null;
    "update:useCurrencyAccountingStyle": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    currency: StringConstructor;
    formatter: PropType<(value: number | Date) => string>;
    parser: PropType<(value: string) => number | Date>;
    precision: NumberConstructor;
    type: PropType<string>;
    useCurrencyAccountingStyle: BooleanConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:type"?: ((...args: any[]) => any) | undefined;
    "onUpdate:currency"?: ((...args: any[]) => any) | undefined;
    "onUpdate:formatter"?: ((...args: any[]) => any) | undefined;
    "onUpdate:parser"?: ((...args: any[]) => any) | undefined;
    "onUpdate:precision"?: ((...args: any[]) => any) | undefined;
    "onUpdate:useCurrencyAccountingStyle"?: ((...args: any[]) => any) | undefined;
}, {
    useCurrencyAccountingStyle: boolean;
}>;
declare const DxBorder: import("vue").DefineComponent<{
    color: StringConstructor;
    cornerRadius: NumberConstructor;
    dashStyle: PropType<DashStyle>;
    opacity: NumberConstructor;
    visible: BooleanConstructor;
    width: NumberConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:color": null;
    "update:cornerRadius": null;
    "update:dashStyle": null;
    "update:opacity": null;
    "update:visible": null;
    "update:width": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    color: StringConstructor;
    cornerRadius: NumberConstructor;
    dashStyle: PropType<DashStyle>;
    opacity: NumberConstructor;
    visible: BooleanConstructor;
    width: NumberConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:color"?: ((...args: any[]) => any) | undefined;
    "onUpdate:opacity"?: ((...args: any[]) => any) | undefined;
    "onUpdate:width"?: ((...args: any[]) => any) | undefined;
    "onUpdate:cornerRadius"?: ((...args: any[]) => any) | undefined;
    "onUpdate:dashStyle"?: ((...args: any[]) => any) | undefined;
    "onUpdate:visible"?: ((...args: any[]) => any) | undefined;
}, {
    visible: boolean;
}>;
declare const DxColor: import("vue").DefineComponent<{
    base: StringConstructor;
    fillId: StringConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:base": null;
    "update:fillId": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    base: StringConstructor;
    fillId: StringConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:base"?: ((...args: any[]) => any) | undefined;
    "onUpdate:fillId"?: ((...args: any[]) => any) | undefined;
}, {}>;
declare const DxCommonAnnotationSettings: import("vue").DefineComponent<{
    allowDragging: BooleanConstructor;
    argument: (DateConstructor | NumberConstructor | StringConstructor)[];
    arrowLength: NumberConstructor;
    arrowWidth: NumberConstructor;
    border: PropType<Record<string, any>>;
    color: StringConstructor;
    customizeTooltip: PropType<(annotation: dxPieChartAnnotationConfig | any) => Record<string, any>>;
    data: {};
    description: StringConstructor;
    font: PropType<Record<string, any> | Font>;
    height: NumberConstructor;
    image: PropType<string | Record<string, any>>;
    location: PropType<PieChartAnnotationLocation>;
    offsetX: NumberConstructor;
    offsetY: NumberConstructor;
    opacity: NumberConstructor;
    paddingLeftRight: NumberConstructor;
    paddingTopBottom: NumberConstructor;
    series: StringConstructor;
    shadow: PropType<Record<string, any>>;
    template: {};
    text: StringConstructor;
    textOverflow: PropType<TextOverflow>;
    tooltipEnabled: BooleanConstructor;
    tooltipTemplate: {};
    type: PropType<AnnotationType>;
    width: NumberConstructor;
    wordWrap: PropType<WordWrap>;
    x: NumberConstructor;
    y: NumberConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:allowDragging": null;
    "update:argument": null;
    "update:arrowLength": null;
    "update:arrowWidth": null;
    "update:border": null;
    "update:color": null;
    "update:customizeTooltip": null;
    "update:data": null;
    "update:description": null;
    "update:font": null;
    "update:height": null;
    "update:image": null;
    "update:location": null;
    "update:offsetX": null;
    "update:offsetY": null;
    "update:opacity": null;
    "update:paddingLeftRight": null;
    "update:paddingTopBottom": null;
    "update:series": null;
    "update:shadow": null;
    "update:template": null;
    "update:text": null;
    "update:textOverflow": null;
    "update:tooltipEnabled": null;
    "update:tooltipTemplate": null;
    "update:type": null;
    "update:width": null;
    "update:wordWrap": null;
    "update:x": null;
    "update:y": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    allowDragging: BooleanConstructor;
    argument: (DateConstructor | NumberConstructor | StringConstructor)[];
    arrowLength: NumberConstructor;
    arrowWidth: NumberConstructor;
    border: PropType<Record<string, any>>;
    color: StringConstructor;
    customizeTooltip: PropType<(annotation: dxPieChartAnnotationConfig | any) => Record<string, any>>;
    data: {};
    description: StringConstructor;
    font: PropType<Record<string, any> | Font>;
    height: NumberConstructor;
    image: PropType<string | Record<string, any>>;
    location: PropType<PieChartAnnotationLocation>;
    offsetX: NumberConstructor;
    offsetY: NumberConstructor;
    opacity: NumberConstructor;
    paddingLeftRight: NumberConstructor;
    paddingTopBottom: NumberConstructor;
    series: StringConstructor;
    shadow: PropType<Record<string, any>>;
    template: {};
    text: StringConstructor;
    textOverflow: PropType<TextOverflow>;
    tooltipEnabled: BooleanConstructor;
    tooltipTemplate: {};
    type: PropType<AnnotationType>;
    width: NumberConstructor;
    wordWrap: PropType<WordWrap>;
    x: NumberConstructor;
    y: NumberConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:allowDragging"?: ((...args: any[]) => any) | undefined;
    "onUpdate:arrowLength"?: ((...args: any[]) => any) | undefined;
    "onUpdate:arrowWidth"?: ((...args: any[]) => any) | undefined;
    "onUpdate:border"?: ((...args: any[]) => any) | undefined;
    "onUpdate:color"?: ((...args: any[]) => any) | undefined;
    "onUpdate:customizeTooltip"?: ((...args: any[]) => any) | undefined;
    "onUpdate:data"?: ((...args: any[]) => any) | undefined;
    "onUpdate:description"?: ((...args: any[]) => any) | undefined;
    "onUpdate:font"?: ((...args: any[]) => any) | undefined;
    "onUpdate:height"?: ((...args: any[]) => any) | undefined;
    "onUpdate:image"?: ((...args: any[]) => any) | undefined;
    "onUpdate:offsetX"?: ((...args: any[]) => any) | undefined;
    "onUpdate:offsetY"?: ((...args: any[]) => any) | undefined;
    "onUpdate:opacity"?: ((...args: any[]) => any) | undefined;
    "onUpdate:paddingLeftRight"?: ((...args: any[]) => any) | undefined;
    "onUpdate:paddingTopBottom"?: ((...args: any[]) => any) | undefined;
    "onUpdate:shadow"?: ((...args: any[]) => any) | undefined;
    "onUpdate:template"?: ((...args: any[]) => any) | undefined;
    "onUpdate:text"?: ((...args: any[]) => any) | undefined;
    "onUpdate:textOverflow"?: ((...args: any[]) => any) | undefined;
    "onUpdate:tooltipEnabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:tooltipTemplate"?: ((...args: any[]) => any) | undefined;
    "onUpdate:type"?: ((...args: any[]) => any) | undefined;
    "onUpdate:width"?: ((...args: any[]) => any) | undefined;
    "onUpdate:wordWrap"?: ((...args: any[]) => any) | undefined;
    "onUpdate:x"?: ((...args: any[]) => any) | undefined;
    "onUpdate:y"?: ((...args: any[]) => any) | undefined;
    "onUpdate:location"?: ((...args: any[]) => any) | undefined;
    "onUpdate:series"?: ((...args: any[]) => any) | undefined;
    "onUpdate:argument"?: ((...args: any[]) => any) | undefined;
}, {
    allowDragging: boolean;
    tooltipEnabled: boolean;
}>;
declare const DxCommonSeriesSettings: import("vue").DefineComponent<{
    argumentField: StringConstructor;
    argumentType: PropType<ChartsDataType>;
    border: PropType<Record<string, any>>;
    color: PropType<string | Record<string, any> | ChartsColor>;
    hoverMode: PropType<PieChartSeriesInteractionMode>;
    hoverStyle: PropType<Record<string, any>>;
    label: PropType<Record<string, any>>;
    maxLabelCount: NumberConstructor;
    minSegmentSize: NumberConstructor;
    selectionMode: PropType<PieChartSeriesInteractionMode>;
    selectionStyle: PropType<Record<string, any>>;
    smallValuesGrouping: PropType<Record<string, any>>;
    tagField: StringConstructor;
    valueField: StringConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:argumentField": null;
    "update:argumentType": null;
    "update:border": null;
    "update:color": null;
    "update:hoverMode": null;
    "update:hoverStyle": null;
    "update:label": null;
    "update:maxLabelCount": null;
    "update:minSegmentSize": null;
    "update:selectionMode": null;
    "update:selectionStyle": null;
    "update:smallValuesGrouping": null;
    "update:tagField": null;
    "update:valueField": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    argumentField: StringConstructor;
    argumentType: PropType<ChartsDataType>;
    border: PropType<Record<string, any>>;
    color: PropType<string | Record<string, any> | ChartsColor>;
    hoverMode: PropType<PieChartSeriesInteractionMode>;
    hoverStyle: PropType<Record<string, any>>;
    label: PropType<Record<string, any>>;
    maxLabelCount: NumberConstructor;
    minSegmentSize: NumberConstructor;
    selectionMode: PropType<PieChartSeriesInteractionMode>;
    selectionStyle: PropType<Record<string, any>>;
    smallValuesGrouping: PropType<Record<string, any>>;
    tagField: StringConstructor;
    valueField: StringConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:border"?: ((...args: any[]) => any) | undefined;
    "onUpdate:color"?: ((...args: any[]) => any) | undefined;
    "onUpdate:label"?: ((...args: any[]) => any) | undefined;
    "onUpdate:selectionMode"?: ((...args: any[]) => any) | undefined;
    "onUpdate:valueField"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoverStyle"?: ((...args: any[]) => any) | undefined;
    "onUpdate:selectionStyle"?: ((...args: any[]) => any) | undefined;
    "onUpdate:argumentField"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoverMode"?: ((...args: any[]) => any) | undefined;
    "onUpdate:maxLabelCount"?: ((...args: any[]) => any) | undefined;
    "onUpdate:tagField"?: ((...args: any[]) => any) | undefined;
    "onUpdate:argumentType"?: ((...args: any[]) => any) | undefined;
    "onUpdate:minSegmentSize"?: ((...args: any[]) => any) | undefined;
    "onUpdate:smallValuesGrouping"?: ((...args: any[]) => any) | undefined;
}, {}>;
declare const DxConnector: import("vue").DefineComponent<{
    color: StringConstructor;
    visible: BooleanConstructor;
    width: NumberConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:color": null;
    "update:visible": null;
    "update:width": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    color: StringConstructor;
    visible: BooleanConstructor;
    width: NumberConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:color"?: ((...args: any[]) => any) | undefined;
    "onUpdate:width"?: ((...args: any[]) => any) | undefined;
    "onUpdate:visible"?: ((...args: any[]) => any) | undefined;
}, {
    visible: boolean;
}>;
declare const DxExport: import("vue").DefineComponent<{
    backgroundColor: StringConstructor;
    enabled: BooleanConstructor;
    fileName: StringConstructor;
    formats: PropType<ExportFormat[]>;
    margin: NumberConstructor;
    printingEnabled: BooleanConstructor;
    svgToCanvas: PropType<(svg: any, canvas: any) => any>;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:backgroundColor": null;
    "update:enabled": null;
    "update:fileName": null;
    "update:formats": null;
    "update:margin": null;
    "update:printingEnabled": null;
    "update:svgToCanvas": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    backgroundColor: StringConstructor;
    enabled: BooleanConstructor;
    fileName: StringConstructor;
    formats: PropType<ExportFormat[]>;
    margin: NumberConstructor;
    printingEnabled: BooleanConstructor;
    svgToCanvas: PropType<(svg: any, canvas: any) => any>;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:enabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:margin"?: ((...args: any[]) => any) | undefined;
    "onUpdate:backgroundColor"?: ((...args: any[]) => any) | undefined;
    "onUpdate:fileName"?: ((...args: any[]) => any) | undefined;
    "onUpdate:formats"?: ((...args: any[]) => any) | undefined;
    "onUpdate:printingEnabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:svgToCanvas"?: ((...args: any[]) => any) | undefined;
}, {
    enabled: boolean;
    printingEnabled: boolean;
}>;
declare const DxFont: import("vue").DefineComponent<{
    color: StringConstructor;
    family: StringConstructor;
    opacity: NumberConstructor;
    size: (NumberConstructor | StringConstructor)[];
    weight: NumberConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:color": null;
    "update:family": null;
    "update:opacity": null;
    "update:size": null;
    "update:weight": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    color: StringConstructor;
    family: StringConstructor;
    opacity: NumberConstructor;
    size: (NumberConstructor | StringConstructor)[];
    weight: NumberConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:size"?: ((...args: any[]) => any) | undefined;
    "onUpdate:color"?: ((...args: any[]) => any) | undefined;
    "onUpdate:opacity"?: ((...args: any[]) => any) | undefined;
    "onUpdate:family"?: ((...args: any[]) => any) | undefined;
    "onUpdate:weight"?: ((...args: any[]) => any) | undefined;
}, {}>;
declare const DxFormat: import("vue").DefineComponent<{
    currency: StringConstructor;
    formatter: PropType<(value: number | Date) => string>;
    parser: PropType<(value: string) => number | Date>;
    precision: NumberConstructor;
    type: PropType<string>;
    useCurrencyAccountingStyle: BooleanConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:currency": null;
    "update:formatter": null;
    "update:parser": null;
    "update:precision": null;
    "update:type": null;
    "update:useCurrencyAccountingStyle": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    currency: StringConstructor;
    formatter: PropType<(value: number | Date) => string>;
    parser: PropType<(value: string) => number | Date>;
    precision: NumberConstructor;
    type: PropType<string>;
    useCurrencyAccountingStyle: BooleanConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:type"?: ((...args: any[]) => any) | undefined;
    "onUpdate:currency"?: ((...args: any[]) => any) | undefined;
    "onUpdate:formatter"?: ((...args: any[]) => any) | undefined;
    "onUpdate:parser"?: ((...args: any[]) => any) | undefined;
    "onUpdate:precision"?: ((...args: any[]) => any) | undefined;
    "onUpdate:useCurrencyAccountingStyle"?: ((...args: any[]) => any) | undefined;
}, {
    useCurrencyAccountingStyle: boolean;
}>;
declare const DxHatching: import("vue").DefineComponent<{
    direction: PropType<HatchDirection>;
    opacity: NumberConstructor;
    step: NumberConstructor;
    width: NumberConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:direction": null;
    "update:opacity": null;
    "update:step": null;
    "update:width": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    direction: PropType<HatchDirection>;
    opacity: NumberConstructor;
    step: NumberConstructor;
    width: NumberConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:opacity"?: ((...args: any[]) => any) | undefined;
    "onUpdate:width"?: ((...args: any[]) => any) | undefined;
    "onUpdate:direction"?: ((...args: any[]) => any) | undefined;
    "onUpdate:step"?: ((...args: any[]) => any) | undefined;
}, {}>;
declare const DxHoverStyle: import("vue").DefineComponent<{
    border: PropType<Record<string, any>>;
    color: PropType<string | Record<string, any> | ChartsColor>;
    hatching: PropType<Record<string, any>>;
    highlight: BooleanConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:border": null;
    "update:color": null;
    "update:hatching": null;
    "update:highlight": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    border: PropType<Record<string, any>>;
    color: PropType<string | Record<string, any> | ChartsColor>;
    hatching: PropType<Record<string, any>>;
    highlight: BooleanConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:border"?: ((...args: any[]) => any) | undefined;
    "onUpdate:color"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hatching"?: ((...args: any[]) => any) | undefined;
    "onUpdate:highlight"?: ((...args: any[]) => any) | undefined;
}, {
    highlight: boolean;
}>;
declare const DxImage: import("vue").DefineComponent<{
    height: NumberConstructor;
    url: StringConstructor;
    width: NumberConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:height": null;
    "update:url": null;
    "update:width": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    height: NumberConstructor;
    url: StringConstructor;
    width: NumberConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:height"?: ((...args: any[]) => any) | undefined;
    "onUpdate:width"?: ((...args: any[]) => any) | undefined;
    "onUpdate:url"?: ((...args: any[]) => any) | undefined;
}, {}>;
declare const DxLabel: import("vue").DefineComponent<{
    argumentFormat: PropType<string | Record<string, any> | import("devextreme/common/core/localization").FormatObject | ((value: number | Date) => string) | ((value: Date) => string) | ((value: number) => string) | Intl.DateTimeFormatOptions | Intl.NumberFormatOptions | ((value: number | Date) => string) | undefined>;
    backgroundColor: StringConstructor;
    border: PropType<Record<string, any>>;
    connector: PropType<Record<string, any>>;
    customizeText: PropType<(pointInfo: any) => string>;
    displayFormat: StringConstructor;
    font: PropType<Record<string, any> | Font>;
    format: PropType<string | Record<string, any> | import("devextreme/common/core/localization").FormatObject | ((value: number | Date) => string) | ((value: Date) => string) | ((value: number) => string) | Intl.DateTimeFormatOptions | Intl.NumberFormatOptions | ((value: number | Date) => string) | undefined>;
    position: PropType<LabelPosition>;
    radialOffset: NumberConstructor;
    rotationAngle: NumberConstructor;
    textOverflow: PropType<TextOverflow>;
    visible: BooleanConstructor;
    wordWrap: PropType<WordWrap>;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:argumentFormat": null;
    "update:backgroundColor": null;
    "update:border": null;
    "update:connector": null;
    "update:customizeText": null;
    "update:displayFormat": null;
    "update:font": null;
    "update:format": null;
    "update:position": null;
    "update:radialOffset": null;
    "update:rotationAngle": null;
    "update:textOverflow": null;
    "update:visible": null;
    "update:wordWrap": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    argumentFormat: PropType<string | Record<string, any> | import("devextreme/common/core/localization").FormatObject | ((value: number | Date) => string) | ((value: Date) => string) | ((value: number) => string) | Intl.DateTimeFormatOptions | Intl.NumberFormatOptions | ((value: number | Date) => string) | undefined>;
    backgroundColor: StringConstructor;
    border: PropType<Record<string, any>>;
    connector: PropType<Record<string, any>>;
    customizeText: PropType<(pointInfo: any) => string>;
    displayFormat: StringConstructor;
    font: PropType<Record<string, any> | Font>;
    format: PropType<string | Record<string, any> | import("devextreme/common/core/localization").FormatObject | ((value: number | Date) => string) | ((value: Date) => string) | ((value: number) => string) | Intl.DateTimeFormatOptions | Intl.NumberFormatOptions | ((value: number | Date) => string) | undefined>;
    position: PropType<LabelPosition>;
    radialOffset: NumberConstructor;
    rotationAngle: NumberConstructor;
    textOverflow: PropType<TextOverflow>;
    visible: BooleanConstructor;
    wordWrap: PropType<WordWrap>;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:border"?: ((...args: any[]) => any) | undefined;
    "onUpdate:font"?: ((...args: any[]) => any) | undefined;
    "onUpdate:textOverflow"?: ((...args: any[]) => any) | undefined;
    "onUpdate:wordWrap"?: ((...args: any[]) => any) | undefined;
    "onUpdate:visible"?: ((...args: any[]) => any) | undefined;
    "onUpdate:backgroundColor"?: ((...args: any[]) => any) | undefined;
    "onUpdate:customizeText"?: ((...args: any[]) => any) | undefined;
    "onUpdate:format"?: ((...args: any[]) => any) | undefined;
    "onUpdate:position"?: ((...args: any[]) => any) | undefined;
    "onUpdate:argumentFormat"?: ((...args: any[]) => any) | undefined;
    "onUpdate:connector"?: ((...args: any[]) => any) | undefined;
    "onUpdate:displayFormat"?: ((...args: any[]) => any) | undefined;
    "onUpdate:rotationAngle"?: ((...args: any[]) => any) | undefined;
    "onUpdate:radialOffset"?: ((...args: any[]) => any) | undefined;
}, {
    visible: boolean;
}>;
declare const DxLegend: import("vue").DefineComponent<{
    backgroundColor: StringConstructor;
    border: PropType<Record<string, any>>;
    columnCount: NumberConstructor;
    columnItemSpacing: NumberConstructor;
    customizeHint: PropType<(pointInfo: {
        pointColor: string;
        pointIndex: number;
        pointName: any;
    }) => string>;
    customizeItems: PropType<(items: Array<PieChartLegendItem>) => Array<PieChartLegendItem>>;
    customizeText: PropType<(pointInfo: {
        pointColor: string;
        pointIndex: number;
        pointName: any;
    }) => string>;
    font: PropType<Record<string, any> | Font>;
    horizontalAlignment: PropType<HorizontalAlignment>;
    hoverMode: PropType<PieChartLegendHoverMode>;
    itemsAlignment: PropType<HorizontalAlignment>;
    itemTextPosition: PropType<Position>;
    margin: PropType<number | Record<string, any>>;
    markerSize: NumberConstructor;
    markerTemplate: {};
    orientation: PropType<Orientation>;
    paddingLeftRight: NumberConstructor;
    paddingTopBottom: NumberConstructor;
    rowCount: NumberConstructor;
    rowItemSpacing: NumberConstructor;
    title: PropType<string | Record<string, any>>;
    verticalAlignment: PropType<VerticalEdge>;
    visible: BooleanConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:backgroundColor": null;
    "update:border": null;
    "update:columnCount": null;
    "update:columnItemSpacing": null;
    "update:customizeHint": null;
    "update:customizeItems": null;
    "update:customizeText": null;
    "update:font": null;
    "update:horizontalAlignment": null;
    "update:hoverMode": null;
    "update:itemsAlignment": null;
    "update:itemTextPosition": null;
    "update:margin": null;
    "update:markerSize": null;
    "update:markerTemplate": null;
    "update:orientation": null;
    "update:paddingLeftRight": null;
    "update:paddingTopBottom": null;
    "update:rowCount": null;
    "update:rowItemSpacing": null;
    "update:title": null;
    "update:verticalAlignment": null;
    "update:visible": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    backgroundColor: StringConstructor;
    border: PropType<Record<string, any>>;
    columnCount: NumberConstructor;
    columnItemSpacing: NumberConstructor;
    customizeHint: PropType<(pointInfo: {
        pointColor: string;
        pointIndex: number;
        pointName: any;
    }) => string>;
    customizeItems: PropType<(items: Array<PieChartLegendItem>) => Array<PieChartLegendItem>>;
    customizeText: PropType<(pointInfo: {
        pointColor: string;
        pointIndex: number;
        pointName: any;
    }) => string>;
    font: PropType<Record<string, any> | Font>;
    horizontalAlignment: PropType<HorizontalAlignment>;
    hoverMode: PropType<PieChartLegendHoverMode>;
    itemsAlignment: PropType<HorizontalAlignment>;
    itemTextPosition: PropType<Position>;
    margin: PropType<number | Record<string, any>>;
    markerSize: NumberConstructor;
    markerTemplate: {};
    orientation: PropType<Orientation>;
    paddingLeftRight: NumberConstructor;
    paddingTopBottom: NumberConstructor;
    rowCount: NumberConstructor;
    rowItemSpacing: NumberConstructor;
    title: PropType<string | Record<string, any>>;
    verticalAlignment: PropType<VerticalEdge>;
    visible: BooleanConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:title"?: ((...args: any[]) => any) | undefined;
    "onUpdate:border"?: ((...args: any[]) => any) | undefined;
    "onUpdate:font"?: ((...args: any[]) => any) | undefined;
    "onUpdate:paddingLeftRight"?: ((...args: any[]) => any) | undefined;
    "onUpdate:paddingTopBottom"?: ((...args: any[]) => any) | undefined;
    "onUpdate:visible"?: ((...args: any[]) => any) | undefined;
    "onUpdate:horizontalAlignment"?: ((...args: any[]) => any) | undefined;
    "onUpdate:margin"?: ((...args: any[]) => any) | undefined;
    "onUpdate:verticalAlignment"?: ((...args: any[]) => any) | undefined;
    "onUpdate:backgroundColor"?: ((...args: any[]) => any) | undefined;
    "onUpdate:columnCount"?: ((...args: any[]) => any) | undefined;
    "onUpdate:columnItemSpacing"?: ((...args: any[]) => any) | undefined;
    "onUpdate:customizeHint"?: ((...args: any[]) => any) | undefined;
    "onUpdate:customizeItems"?: ((...args: any[]) => any) | undefined;
    "onUpdate:customizeText"?: ((...args: any[]) => any) | undefined;
    "onUpdate:itemsAlignment"?: ((...args: any[]) => any) | undefined;
    "onUpdate:itemTextPosition"?: ((...args: any[]) => any) | undefined;
    "onUpdate:markerSize"?: ((...args: any[]) => any) | undefined;
    "onUpdate:markerTemplate"?: ((...args: any[]) => any) | undefined;
    "onUpdate:orientation"?: ((...args: any[]) => any) | undefined;
    "onUpdate:rowCount"?: ((...args: any[]) => any) | undefined;
    "onUpdate:rowItemSpacing"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoverMode"?: ((...args: any[]) => any) | undefined;
}, {
    visible: boolean;
}>;
declare const DxLegendTitle: import("vue").DefineComponent<{
    font: PropType<Record<string, any> | Font>;
    horizontalAlignment: PropType<HorizontalAlignment>;
    margin: PropType<Record<string, any>>;
    placeholderSize: NumberConstructor;
    subtitle: PropType<string | Record<string, any>>;
    text: StringConstructor;
    verticalAlignment: PropType<VerticalEdge>;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:font": null;
    "update:horizontalAlignment": null;
    "update:margin": null;
    "update:placeholderSize": null;
    "update:subtitle": null;
    "update:text": null;
    "update:verticalAlignment": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    font: PropType<Record<string, any> | Font>;
    horizontalAlignment: PropType<HorizontalAlignment>;
    margin: PropType<Record<string, any>>;
    placeholderSize: NumberConstructor;
    subtitle: PropType<string | Record<string, any>>;
    text: StringConstructor;
    verticalAlignment: PropType<VerticalEdge>;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:font"?: ((...args: any[]) => any) | undefined;
    "onUpdate:text"?: ((...args: any[]) => any) | undefined;
    "onUpdate:horizontalAlignment"?: ((...args: any[]) => any) | undefined;
    "onUpdate:margin"?: ((...args: any[]) => any) | undefined;
    "onUpdate:verticalAlignment"?: ((...args: any[]) => any) | undefined;
    "onUpdate:placeholderSize"?: ((...args: any[]) => any) | undefined;
    "onUpdate:subtitle"?: ((...args: any[]) => any) | undefined;
}, {}>;
declare const DxLegendTitleSubtitle: import("vue").DefineComponent<{
    font: PropType<Record<string, any> | Font>;
    offset: NumberConstructor;
    text: StringConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:font": null;
    "update:offset": null;
    "update:text": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    font: PropType<Record<string, any> | Font>;
    offset: NumberConstructor;
    text: StringConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:font"?: ((...args: any[]) => any) | undefined;
    "onUpdate:text"?: ((...args: any[]) => any) | undefined;
    "onUpdate:offset"?: ((...args: any[]) => any) | undefined;
}, {}>;
declare const DxLoadingIndicator: import("vue").DefineComponent<{
    backgroundColor: StringConstructor;
    enabled: BooleanConstructor;
    font: PropType<Record<string, any> | Font>;
    show: BooleanConstructor;
    text: StringConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:backgroundColor": null;
    "update:enabled": null;
    "update:font": null;
    "update:show": null;
    "update:text": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    backgroundColor: StringConstructor;
    enabled: BooleanConstructor;
    font: PropType<Record<string, any> | Font>;
    show: BooleanConstructor;
    text: StringConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:font"?: ((...args: any[]) => any) | undefined;
    "onUpdate:text"?: ((...args: any[]) => any) | undefined;
    "onUpdate:enabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:backgroundColor"?: ((...args: any[]) => any) | undefined;
    "onUpdate:show"?: ((...args: any[]) => any) | undefined;
}, {
    enabled: boolean;
    show: boolean;
}>;
declare const DxMargin: import("vue").DefineComponent<{
    bottom: NumberConstructor;
    left: NumberConstructor;
    right: NumberConstructor;
    top: NumberConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:bottom": null;
    "update:left": null;
    "update:right": null;
    "update:top": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    bottom: NumberConstructor;
    left: NumberConstructor;
    right: NumberConstructor;
    top: NumberConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:bottom"?: ((...args: any[]) => any) | undefined;
    "onUpdate:left"?: ((...args: any[]) => any) | undefined;
    "onUpdate:right"?: ((...args: any[]) => any) | undefined;
    "onUpdate:top"?: ((...args: any[]) => any) | undefined;
}, {}>;
declare const DxPieChartTitle: import("vue").DefineComponent<{
    font: PropType<Record<string, any> | Font>;
    horizontalAlignment: PropType<HorizontalAlignment>;
    margin: PropType<number | Record<string, any>>;
    placeholderSize: NumberConstructor;
    subtitle: PropType<string | Record<string, any>>;
    text: StringConstructor;
    textOverflow: PropType<TextOverflow>;
    verticalAlignment: PropType<VerticalEdge>;
    wordWrap: PropType<WordWrap>;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:font": null;
    "update:horizontalAlignment": null;
    "update:margin": null;
    "update:placeholderSize": null;
    "update:subtitle": null;
    "update:text": null;
    "update:textOverflow": null;
    "update:verticalAlignment": null;
    "update:wordWrap": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    font: PropType<Record<string, any> | Font>;
    horizontalAlignment: PropType<HorizontalAlignment>;
    margin: PropType<number | Record<string, any>>;
    placeholderSize: NumberConstructor;
    subtitle: PropType<string | Record<string, any>>;
    text: StringConstructor;
    textOverflow: PropType<TextOverflow>;
    verticalAlignment: PropType<VerticalEdge>;
    wordWrap: PropType<WordWrap>;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:font"?: ((...args: any[]) => any) | undefined;
    "onUpdate:text"?: ((...args: any[]) => any) | undefined;
    "onUpdate:textOverflow"?: ((...args: any[]) => any) | undefined;
    "onUpdate:wordWrap"?: ((...args: any[]) => any) | undefined;
    "onUpdate:horizontalAlignment"?: ((...args: any[]) => any) | undefined;
    "onUpdate:margin"?: ((...args: any[]) => any) | undefined;
    "onUpdate:verticalAlignment"?: ((...args: any[]) => any) | undefined;
    "onUpdate:placeholderSize"?: ((...args: any[]) => any) | undefined;
    "onUpdate:subtitle"?: ((...args: any[]) => any) | undefined;
}, {}>;
declare const DxPieChartTitleSubtitle: import("vue").DefineComponent<{
    font: PropType<Record<string, any> | Font>;
    offset: NumberConstructor;
    text: StringConstructor;
    textOverflow: PropType<TextOverflow>;
    wordWrap: PropType<WordWrap>;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:font": null;
    "update:offset": null;
    "update:text": null;
    "update:textOverflow": null;
    "update:wordWrap": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    font: PropType<Record<string, any> | Font>;
    offset: NumberConstructor;
    text: StringConstructor;
    textOverflow: PropType<TextOverflow>;
    wordWrap: PropType<WordWrap>;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:font"?: ((...args: any[]) => any) | undefined;
    "onUpdate:text"?: ((...args: any[]) => any) | undefined;
    "onUpdate:textOverflow"?: ((...args: any[]) => any) | undefined;
    "onUpdate:wordWrap"?: ((...args: any[]) => any) | undefined;
    "onUpdate:offset"?: ((...args: any[]) => any) | undefined;
}, {}>;
declare const DxSelectionStyle: import("vue").DefineComponent<{
    border: PropType<Record<string, any>>;
    color: PropType<string | Record<string, any> | ChartsColor>;
    hatching: PropType<Record<string, any>>;
    highlight: BooleanConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:border": null;
    "update:color": null;
    "update:hatching": null;
    "update:highlight": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    border: PropType<Record<string, any>>;
    color: PropType<string | Record<string, any> | ChartsColor>;
    hatching: PropType<Record<string, any>>;
    highlight: BooleanConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:border"?: ((...args: any[]) => any) | undefined;
    "onUpdate:color"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hatching"?: ((...args: any[]) => any) | undefined;
    "onUpdate:highlight"?: ((...args: any[]) => any) | undefined;
}, {
    highlight: boolean;
}>;
declare const DxSeries: import("vue").DefineComponent<{
    argumentField: StringConstructor;
    argumentType: PropType<ChartsDataType>;
    border: PropType<Record<string, any>>;
    color: PropType<string | Record<string, any> | ChartsColor>;
    hoverMode: PropType<PieChartSeriesInteractionMode>;
    hoverStyle: PropType<Record<string, any>>;
    label: PropType<Record<string, any>>;
    maxLabelCount: NumberConstructor;
    minSegmentSize: NumberConstructor;
    name: StringConstructor;
    selectionMode: PropType<PieChartSeriesInteractionMode>;
    selectionStyle: PropType<Record<string, any>>;
    smallValuesGrouping: PropType<Record<string, any>>;
    tag: {};
    tagField: StringConstructor;
    valueField: StringConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:argumentField": null;
    "update:argumentType": null;
    "update:border": null;
    "update:color": null;
    "update:hoverMode": null;
    "update:hoverStyle": null;
    "update:label": null;
    "update:maxLabelCount": null;
    "update:minSegmentSize": null;
    "update:name": null;
    "update:selectionMode": null;
    "update:selectionStyle": null;
    "update:smallValuesGrouping": null;
    "update:tag": null;
    "update:tagField": null;
    "update:valueField": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    argumentField: StringConstructor;
    argumentType: PropType<ChartsDataType>;
    border: PropType<Record<string, any>>;
    color: PropType<string | Record<string, any> | ChartsColor>;
    hoverMode: PropType<PieChartSeriesInteractionMode>;
    hoverStyle: PropType<Record<string, any>>;
    label: PropType<Record<string, any>>;
    maxLabelCount: NumberConstructor;
    minSegmentSize: NumberConstructor;
    name: StringConstructor;
    selectionMode: PropType<PieChartSeriesInteractionMode>;
    selectionStyle: PropType<Record<string, any>>;
    smallValuesGrouping: PropType<Record<string, any>>;
    tag: {};
    tagField: StringConstructor;
    valueField: StringConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:border"?: ((...args: any[]) => any) | undefined;
    "onUpdate:color"?: ((...args: any[]) => any) | undefined;
    "onUpdate:name"?: ((...args: any[]) => any) | undefined;
    "onUpdate:label"?: ((...args: any[]) => any) | undefined;
    "onUpdate:selectionMode"?: ((...args: any[]) => any) | undefined;
    "onUpdate:valueField"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoverStyle"?: ((...args: any[]) => any) | undefined;
    "onUpdate:selectionStyle"?: ((...args: any[]) => any) | undefined;
    "onUpdate:argumentField"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoverMode"?: ((...args: any[]) => any) | undefined;
    "onUpdate:maxLabelCount"?: ((...args: any[]) => any) | undefined;
    "onUpdate:tagField"?: ((...args: any[]) => any) | undefined;
    "onUpdate:tag"?: ((...args: any[]) => any) | undefined;
    "onUpdate:argumentType"?: ((...args: any[]) => any) | undefined;
    "onUpdate:minSegmentSize"?: ((...args: any[]) => any) | undefined;
    "onUpdate:smallValuesGrouping"?: ((...args: any[]) => any) | undefined;
}, {}>;
declare const DxSeriesBorder: import("vue").DefineComponent<{
    color: StringConstructor;
    dashStyle: PropType<DashStyle>;
    visible: BooleanConstructor;
    width: NumberConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:color": null;
    "update:dashStyle": null;
    "update:visible": null;
    "update:width": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    color: StringConstructor;
    dashStyle: PropType<DashStyle>;
    visible: BooleanConstructor;
    width: NumberConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:color"?: ((...args: any[]) => any) | undefined;
    "onUpdate:width"?: ((...args: any[]) => any) | undefined;
    "onUpdate:dashStyle"?: ((...args: any[]) => any) | undefined;
    "onUpdate:visible"?: ((...args: any[]) => any) | undefined;
}, {
    visible: boolean;
}>;
declare const DxSeriesTemplate: import("vue").DefineComponent<{
    customizeSeries: PropType<(seriesName: any) => PieChartSeries>;
    nameField: StringConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:customizeSeries": null;
    "update:nameField": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    customizeSeries: PropType<(seriesName: any) => PieChartSeries>;
    nameField: StringConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:customizeSeries"?: ((...args: any[]) => any) | undefined;
    "onUpdate:nameField"?: ((...args: any[]) => any) | undefined;
}, {}>;
declare const DxShadow: import("vue").DefineComponent<{
    blur: NumberConstructor;
    color: StringConstructor;
    offsetX: NumberConstructor;
    offsetY: NumberConstructor;
    opacity: NumberConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:blur": null;
    "update:color": null;
    "update:offsetX": null;
    "update:offsetY": null;
    "update:opacity": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    blur: NumberConstructor;
    color: StringConstructor;
    offsetX: NumberConstructor;
    offsetY: NumberConstructor;
    opacity: NumberConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:color"?: ((...args: any[]) => any) | undefined;
    "onUpdate:offsetX"?: ((...args: any[]) => any) | undefined;
    "onUpdate:offsetY"?: ((...args: any[]) => any) | undefined;
    "onUpdate:opacity"?: ((...args: any[]) => any) | undefined;
    "onUpdate:blur"?: ((...args: any[]) => any) | undefined;
}, {}>;
declare const DxSize: import("vue").DefineComponent<{
    height: NumberConstructor;
    width: NumberConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:height": null;
    "update:width": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    height: NumberConstructor;
    width: NumberConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:height"?: ((...args: any[]) => any) | undefined;
    "onUpdate:width"?: ((...args: any[]) => any) | undefined;
}, {}>;
declare const DxSmallValuesGrouping: import("vue").DefineComponent<{
    groupName: StringConstructor;
    mode: PropType<SmallValuesGroupingMode>;
    threshold: NumberConstructor;
    topCount: NumberConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:groupName": null;
    "update:mode": null;
    "update:threshold": null;
    "update:topCount": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    groupName: StringConstructor;
    mode: PropType<SmallValuesGroupingMode>;
    threshold: NumberConstructor;
    topCount: NumberConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:mode"?: ((...args: any[]) => any) | undefined;
    "onUpdate:groupName"?: ((...args: any[]) => any) | undefined;
    "onUpdate:threshold"?: ((...args: any[]) => any) | undefined;
    "onUpdate:topCount"?: ((...args: any[]) => any) | undefined;
}, {}>;
declare const DxSubtitle: import("vue").DefineComponent<{
    font: PropType<Record<string, any> | Font>;
    offset: NumberConstructor;
    text: StringConstructor;
    textOverflow: PropType<TextOverflow>;
    wordWrap: PropType<WordWrap>;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:font": null;
    "update:offset": null;
    "update:text": null;
    "update:textOverflow": null;
    "update:wordWrap": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    font: PropType<Record<string, any> | Font>;
    offset: NumberConstructor;
    text: StringConstructor;
    textOverflow: PropType<TextOverflow>;
    wordWrap: PropType<WordWrap>;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:font"?: ((...args: any[]) => any) | undefined;
    "onUpdate:text"?: ((...args: any[]) => any) | undefined;
    "onUpdate:textOverflow"?: ((...args: any[]) => any) | undefined;
    "onUpdate:wordWrap"?: ((...args: any[]) => any) | undefined;
    "onUpdate:offset"?: ((...args: any[]) => any) | undefined;
}, {}>;
declare const DxTitle: import("vue").DefineComponent<{
    font: PropType<Record<string, any> | Font>;
    horizontalAlignment: PropType<HorizontalAlignment>;
    margin: PropType<number | Record<string, any>>;
    placeholderSize: NumberConstructor;
    subtitle: PropType<string | Record<string, any>>;
    text: StringConstructor;
    textOverflow: PropType<TextOverflow>;
    verticalAlignment: PropType<VerticalEdge>;
    wordWrap: PropType<WordWrap>;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:font": null;
    "update:horizontalAlignment": null;
    "update:margin": null;
    "update:placeholderSize": null;
    "update:subtitle": null;
    "update:text": null;
    "update:textOverflow": null;
    "update:verticalAlignment": null;
    "update:wordWrap": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    font: PropType<Record<string, any> | Font>;
    horizontalAlignment: PropType<HorizontalAlignment>;
    margin: PropType<number | Record<string, any>>;
    placeholderSize: NumberConstructor;
    subtitle: PropType<string | Record<string, any>>;
    text: StringConstructor;
    textOverflow: PropType<TextOverflow>;
    verticalAlignment: PropType<VerticalEdge>;
    wordWrap: PropType<WordWrap>;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:font"?: ((...args: any[]) => any) | undefined;
    "onUpdate:text"?: ((...args: any[]) => any) | undefined;
    "onUpdate:textOverflow"?: ((...args: any[]) => any) | undefined;
    "onUpdate:wordWrap"?: ((...args: any[]) => any) | undefined;
    "onUpdate:horizontalAlignment"?: ((...args: any[]) => any) | undefined;
    "onUpdate:margin"?: ((...args: any[]) => any) | undefined;
    "onUpdate:verticalAlignment"?: ((...args: any[]) => any) | undefined;
    "onUpdate:placeholderSize"?: ((...args: any[]) => any) | undefined;
    "onUpdate:subtitle"?: ((...args: any[]) => any) | undefined;
}, {}>;
declare const DxTooltip: import("vue").DefineComponent<{
    argumentFormat: PropType<string | Record<string, any> | import("devextreme/common/core/localization").FormatObject | ((value: number | Date) => string) | ((value: Date) => string) | ((value: number) => string) | Intl.DateTimeFormatOptions | Intl.NumberFormatOptions | ((value: number | Date) => string) | undefined>;
    arrowLength: NumberConstructor;
    border: PropType<Record<string, any>>;
    color: StringConstructor;
    container: {};
    contentTemplate: {};
    cornerRadius: NumberConstructor;
    customizeTooltip: PropType<(pointInfo: dxPieChartPointInfo) => Record<string, any>>;
    enabled: BooleanConstructor;
    font: PropType<Record<string, any> | Font>;
    format: PropType<string | Record<string, any> | import("devextreme/common/core/localization").FormatObject | ((value: number | Date) => string) | ((value: Date) => string) | ((value: number) => string) | Intl.DateTimeFormatOptions | Intl.NumberFormatOptions | ((value: number | Date) => string) | undefined>;
    interactive: BooleanConstructor;
    opacity: NumberConstructor;
    paddingLeftRight: NumberConstructor;
    paddingTopBottom: NumberConstructor;
    shadow: PropType<Record<string, any>>;
    shared: BooleanConstructor;
    zIndex: NumberConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:argumentFormat": null;
    "update:arrowLength": null;
    "update:border": null;
    "update:color": null;
    "update:container": null;
    "update:contentTemplate": null;
    "update:cornerRadius": null;
    "update:customizeTooltip": null;
    "update:enabled": null;
    "update:font": null;
    "update:format": null;
    "update:interactive": null;
    "update:opacity": null;
    "update:paddingLeftRight": null;
    "update:paddingTopBottom": null;
    "update:shadow": null;
    "update:shared": null;
    "update:zIndex": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    argumentFormat: PropType<string | Record<string, any> | import("devextreme/common/core/localization").FormatObject | ((value: number | Date) => string) | ((value: Date) => string) | ((value: number) => string) | Intl.DateTimeFormatOptions | Intl.NumberFormatOptions | ((value: number | Date) => string) | undefined>;
    arrowLength: NumberConstructor;
    border: PropType<Record<string, any>>;
    color: StringConstructor;
    container: {};
    contentTemplate: {};
    cornerRadius: NumberConstructor;
    customizeTooltip: PropType<(pointInfo: dxPieChartPointInfo) => Record<string, any>>;
    enabled: BooleanConstructor;
    font: PropType<Record<string, any> | Font>;
    format: PropType<string | Record<string, any> | import("devextreme/common/core/localization").FormatObject | ((value: number | Date) => string) | ((value: Date) => string) | ((value: number) => string) | Intl.DateTimeFormatOptions | Intl.NumberFormatOptions | ((value: number | Date) => string) | undefined>;
    interactive: BooleanConstructor;
    opacity: NumberConstructor;
    paddingLeftRight: NumberConstructor;
    paddingTopBottom: NumberConstructor;
    shadow: PropType<Record<string, any>>;
    shared: BooleanConstructor;
    zIndex: NumberConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:arrowLength"?: ((...args: any[]) => any) | undefined;
    "onUpdate:border"?: ((...args: any[]) => any) | undefined;
    "onUpdate:color"?: ((...args: any[]) => any) | undefined;
    "onUpdate:customizeTooltip"?: ((...args: any[]) => any) | undefined;
    "onUpdate:font"?: ((...args: any[]) => any) | undefined;
    "onUpdate:opacity"?: ((...args: any[]) => any) | undefined;
    "onUpdate:paddingLeftRight"?: ((...args: any[]) => any) | undefined;
    "onUpdate:paddingTopBottom"?: ((...args: any[]) => any) | undefined;
    "onUpdate:shadow"?: ((...args: any[]) => any) | undefined;
    "onUpdate:cornerRadius"?: ((...args: any[]) => any) | undefined;
    "onUpdate:enabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:container"?: ((...args: any[]) => any) | undefined;
    "onUpdate:contentTemplate"?: ((...args: any[]) => any) | undefined;
    "onUpdate:zIndex"?: ((...args: any[]) => any) | undefined;
    "onUpdate:format"?: ((...args: any[]) => any) | undefined;
    "onUpdate:interactive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:argumentFormat"?: ((...args: any[]) => any) | undefined;
    "onUpdate:shared"?: ((...args: any[]) => any) | undefined;
}, {
    enabled: boolean;
    interactive: boolean;
    shared: boolean;
}>;
declare const DxTooltipBorder: import("vue").DefineComponent<{
    color: StringConstructor;
    dashStyle: PropType<DashStyle>;
    opacity: NumberConstructor;
    visible: BooleanConstructor;
    width: NumberConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:color": null;
    "update:dashStyle": null;
    "update:opacity": null;
    "update:visible": null;
    "update:width": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    color: StringConstructor;
    dashStyle: PropType<DashStyle>;
    opacity: NumberConstructor;
    visible: BooleanConstructor;
    width: NumberConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:color"?: ((...args: any[]) => any) | undefined;
    "onUpdate:opacity"?: ((...args: any[]) => any) | undefined;
    "onUpdate:width"?: ((...args: any[]) => any) | undefined;
    "onUpdate:dashStyle"?: ((...args: any[]) => any) | undefined;
    "onUpdate:visible"?: ((...args: any[]) => any) | undefined;
}, {
    visible: boolean;
}>;
export default DxPieChart;
export { DxPieChart, DxAdaptiveLayout, DxAnimation, DxAnnotation, DxAnnotationBorder, DxArgumentFormat, DxBorder, DxColor, DxCommonAnnotationSettings, DxCommonSeriesSettings, DxConnector, DxExport, DxFont, DxFormat, DxHatching, DxHoverStyle, DxImage, DxLabel, DxLegend, DxLegendTitle, DxLegendTitleSubtitle, DxLoadingIndicator, DxMargin, DxPieChartTitle, DxPieChartTitleSubtitle, DxSelectionStyle, DxSeries, DxSeriesBorder, DxSeriesTemplate, DxShadow, DxSize, DxSmallValuesGrouping, DxSubtitle, DxTitle, DxTooltip, DxTooltipBorder };
import type * as DxPieChartTypes from "devextreme/viz/pie_chart_types";
export { DxPieChartTypes };
