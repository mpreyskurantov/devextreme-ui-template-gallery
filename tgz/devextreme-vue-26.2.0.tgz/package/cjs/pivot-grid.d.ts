/*!
 * devextreme-vue
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

import { PropType } from "vue";
import PivotGrid, { Properties } from "devextreme/ui/pivot_grid";
import PivotGridDataSource from "devextreme/ui/pivot_grid/data_source";
import { PivotGridDataFieldArea, CellClickEvent, CellPreparedEvent, ContentReadyEvent, ContextMenuPreparingEvent, DisposingEvent, ExportingEvent, InitializedEvent, OptionChangedEvent, PivotGridRowHeaderLayout, PivotGridTotalDisplayMode } from "devextreme/ui/pivot_grid";
import { PivotGridDataSourceOptions } from "devextreme/ui/pivot_grid/data_source";
import { ApplyChangesMode, HeaderFilterSearchConfig, StateStoreType } from "devextreme/common/grids";
import { FieldChooserLayout, ScrollMode, SearchMode } from "devextreme/common";
type AccessibleOptions = Pick<Properties, "allowExpandAll" | "allowFiltering" | "allowSorting" | "allowSortingBySummary" | "dataFieldArea" | "dataSource" | "disabled" | "elementAttr" | "encodeHtml" | "export" | "fieldChooser" | "fieldPanel" | "headerFilter" | "height" | "hideEmptySummaryCells" | "hint" | "loadPanel" | "onCellClick" | "onCellPrepared" | "onContentReady" | "onContextMenuPreparing" | "onDisposing" | "onExporting" | "onInitialized" | "onOptionChanged" | "rowHeaderLayout" | "rtlEnabled" | "scrolling" | "showBorders" | "showColumnGrandTotals" | "showColumnTotals" | "showRowGrandTotals" | "showRowTotals" | "showTotalsPrior" | "stateStoring" | "tabIndex" | "texts" | "visible" | "width" | "wordWrapEnabled">;
interface DxPivotGrid extends AccessibleOptions {
    readonly instance?: PivotGrid;
}
declare const DxPivotGrid: import("vue").DefineComponent<{
    allowExpandAll: BooleanConstructor;
    allowFiltering: BooleanConstructor;
    allowSorting: BooleanConstructor;
    allowSortingBySummary: BooleanConstructor;
    dataFieldArea: PropType<PivotGridDataFieldArea>;
    dataSource: PropType<any[] | PivotGridDataSource | PivotGridDataSourceOptions | null>;
    disabled: BooleanConstructor;
    elementAttr: PropType<Record<string, any>>;
    encodeHtml: BooleanConstructor;
    export: PropType<Record<string, any>>;
    fieldChooser: PropType<Record<string, any>>;
    fieldPanel: PropType<Record<string, any>>;
    headerFilter: PropType<Record<string, any>>;
    height: (NumberConstructor | StringConstructor)[];
    hideEmptySummaryCells: BooleanConstructor;
    hint: StringConstructor;
    loadPanel: PropType<Record<string, any>>;
    onCellClick: PropType<(e: CellClickEvent) => void>;
    onCellPrepared: PropType<(e: CellPreparedEvent) => void>;
    onContentReady: PropType<(e: ContentReadyEvent) => void>;
    onContextMenuPreparing: PropType<(e: ContextMenuPreparingEvent) => void>;
    onDisposing: PropType<(e: DisposingEvent) => void>;
    onExporting: PropType<(e: ExportingEvent) => void>;
    onInitialized: PropType<(e: InitializedEvent) => void>;
    onOptionChanged: PropType<(e: OptionChangedEvent) => void>;
    rowHeaderLayout: PropType<PivotGridRowHeaderLayout>;
    rtlEnabled: BooleanConstructor;
    scrolling: PropType<Record<string, any>>;
    showBorders: BooleanConstructor;
    showColumnGrandTotals: BooleanConstructor;
    showColumnTotals: BooleanConstructor;
    showRowGrandTotals: BooleanConstructor;
    showRowTotals: BooleanConstructor;
    showTotalsPrior: PropType<PivotGridTotalDisplayMode>;
    stateStoring: PropType<Record<string, any>>;
    tabIndex: NumberConstructor;
    texts: PropType<Record<string, any>>;
    visible: BooleanConstructor;
    width: (NumberConstructor | StringConstructor)[];
    wordWrapEnabled: BooleanConstructor;
}, unknown, unknown, {
    instance(): PivotGrid;
}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:allowExpandAll": null;
    "update:allowFiltering": null;
    "update:allowSorting": null;
    "update:allowSortingBySummary": null;
    "update:dataFieldArea": null;
    "update:dataSource": null;
    "update:disabled": null;
    "update:elementAttr": null;
    "update:encodeHtml": null;
    "update:export": null;
    "update:fieldChooser": null;
    "update:fieldPanel": null;
    "update:headerFilter": null;
    "update:height": null;
    "update:hideEmptySummaryCells": null;
    "update:hint": null;
    "update:loadPanel": null;
    "update:onCellClick": null;
    "update:onCellPrepared": null;
    "update:onContentReady": null;
    "update:onContextMenuPreparing": null;
    "update:onDisposing": null;
    "update:onExporting": null;
    "update:onInitialized": null;
    "update:onOptionChanged": null;
    "update:rowHeaderLayout": null;
    "update:rtlEnabled": null;
    "update:scrolling": null;
    "update:showBorders": null;
    "update:showColumnGrandTotals": null;
    "update:showColumnTotals": null;
    "update:showRowGrandTotals": null;
    "update:showRowTotals": null;
    "update:showTotalsPrior": null;
    "update:stateStoring": null;
    "update:tabIndex": null;
    "update:texts": null;
    "update:visible": null;
    "update:width": null;
    "update:wordWrapEnabled": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    allowExpandAll: BooleanConstructor;
    allowFiltering: BooleanConstructor;
    allowSorting: BooleanConstructor;
    allowSortingBySummary: BooleanConstructor;
    dataFieldArea: PropType<PivotGridDataFieldArea>;
    dataSource: PropType<any[] | PivotGridDataSource | PivotGridDataSourceOptions | null>;
    disabled: BooleanConstructor;
    elementAttr: PropType<Record<string, any>>;
    encodeHtml: BooleanConstructor;
    export: PropType<Record<string, any>>;
    fieldChooser: PropType<Record<string, any>>;
    fieldPanel: PropType<Record<string, any>>;
    headerFilter: PropType<Record<string, any>>;
    height: (NumberConstructor | StringConstructor)[];
    hideEmptySummaryCells: BooleanConstructor;
    hint: StringConstructor;
    loadPanel: PropType<Record<string, any>>;
    onCellClick: PropType<(e: CellClickEvent) => void>;
    onCellPrepared: PropType<(e: CellPreparedEvent) => void>;
    onContentReady: PropType<(e: ContentReadyEvent) => void>;
    onContextMenuPreparing: PropType<(e: ContextMenuPreparingEvent) => void>;
    onDisposing: PropType<(e: DisposingEvent) => void>;
    onExporting: PropType<(e: ExportingEvent) => void>;
    onInitialized: PropType<(e: InitializedEvent) => void>;
    onOptionChanged: PropType<(e: OptionChangedEvent) => void>;
    rowHeaderLayout: PropType<PivotGridRowHeaderLayout>;
    rtlEnabled: BooleanConstructor;
    scrolling: PropType<Record<string, any>>;
    showBorders: BooleanConstructor;
    showColumnGrandTotals: BooleanConstructor;
    showColumnTotals: BooleanConstructor;
    showRowGrandTotals: BooleanConstructor;
    showRowTotals: BooleanConstructor;
    showTotalsPrior: PropType<PivotGridTotalDisplayMode>;
    stateStoring: PropType<Record<string, any>>;
    tabIndex: NumberConstructor;
    texts: PropType<Record<string, any>>;
    visible: BooleanConstructor;
    width: (NumberConstructor | StringConstructor)[];
    wordWrapEnabled: BooleanConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:disabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:elementAttr"?: ((...args: any[]) => any) | undefined;
    "onUpdate:encodeHtml"?: ((...args: any[]) => any) | undefined;
    "onUpdate:export"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onDisposing"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onExporting"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onInitialized"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onOptionChanged"?: ((...args: any[]) => any) | undefined;
    "onUpdate:rtlEnabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:height"?: ((...args: any[]) => any) | undefined;
    "onUpdate:width"?: ((...args: any[]) => any) | undefined;
    "onUpdate:visible"?: ((...args: any[]) => any) | undefined;
    "onUpdate:dataSource"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onContentReady"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hint"?: ((...args: any[]) => any) | undefined;
    "onUpdate:tabIndex"?: ((...args: any[]) => any) | undefined;
    "onUpdate:headerFilter"?: ((...args: any[]) => any) | undefined;
    "onUpdate:loadPanel"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onCellClick"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onCellPrepared"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onContextMenuPreparing"?: ((...args: any[]) => any) | undefined;
    "onUpdate:scrolling"?: ((...args: any[]) => any) | undefined;
    "onUpdate:showBorders"?: ((...args: any[]) => any) | undefined;
    "onUpdate:stateStoring"?: ((...args: any[]) => any) | undefined;
    "onUpdate:wordWrapEnabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:allowFiltering"?: ((...args: any[]) => any) | undefined;
    "onUpdate:allowSorting"?: ((...args: any[]) => any) | undefined;
    "onUpdate:texts"?: ((...args: any[]) => any) | undefined;
    "onUpdate:allowExpandAll"?: ((...args: any[]) => any) | undefined;
    "onUpdate:allowSortingBySummary"?: ((...args: any[]) => any) | undefined;
    "onUpdate:dataFieldArea"?: ((...args: any[]) => any) | undefined;
    "onUpdate:fieldChooser"?: ((...args: any[]) => any) | undefined;
    "onUpdate:fieldPanel"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hideEmptySummaryCells"?: ((...args: any[]) => any) | undefined;
    "onUpdate:rowHeaderLayout"?: ((...args: any[]) => any) | undefined;
    "onUpdate:showColumnGrandTotals"?: ((...args: any[]) => any) | undefined;
    "onUpdate:showColumnTotals"?: ((...args: any[]) => any) | undefined;
    "onUpdate:showRowGrandTotals"?: ((...args: any[]) => any) | undefined;
    "onUpdate:showRowTotals"?: ((...args: any[]) => any) | undefined;
    "onUpdate:showTotalsPrior"?: ((...args: any[]) => any) | undefined;
}, {
    disabled: boolean;
    encodeHtml: boolean;
    rtlEnabled: boolean;
    visible: boolean;
    showBorders: boolean;
    wordWrapEnabled: boolean;
    allowFiltering: boolean;
    allowSorting: boolean;
    allowExpandAll: boolean;
    allowSortingBySummary: boolean;
    hideEmptySummaryCells: boolean;
    showColumnGrandTotals: boolean;
    showColumnTotals: boolean;
    showRowGrandTotals: boolean;
    showRowTotals: boolean;
}>;
declare const DxExport: import("vue").DefineComponent<{
    enabled: BooleanConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:enabled": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    enabled: BooleanConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:enabled"?: ((...args: any[]) => any) | undefined;
}, {
    enabled: boolean;
}>;
declare const DxFieldChooser: import("vue").DefineComponent<{
    allowSearch: BooleanConstructor;
    applyChangesMode: PropType<ApplyChangesMode>;
    enabled: BooleanConstructor;
    height: (NumberConstructor | StringConstructor)[];
    layout: PropType<FieldChooserLayout>;
    searchTimeout: NumberConstructor;
    texts: PropType<Record<string, any>>;
    title: StringConstructor;
    width: (NumberConstructor | StringConstructor)[];
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:allowSearch": null;
    "update:applyChangesMode": null;
    "update:enabled": null;
    "update:height": null;
    "update:layout": null;
    "update:searchTimeout": null;
    "update:texts": null;
    "update:title": null;
    "update:width": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    allowSearch: BooleanConstructor;
    applyChangesMode: PropType<ApplyChangesMode>;
    enabled: BooleanConstructor;
    height: (NumberConstructor | StringConstructor)[];
    layout: PropType<FieldChooserLayout>;
    searchTimeout: NumberConstructor;
    texts: PropType<Record<string, any>>;
    title: StringConstructor;
    width: (NumberConstructor | StringConstructor)[];
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:title"?: ((...args: any[]) => any) | undefined;
    "onUpdate:height"?: ((...args: any[]) => any) | undefined;
    "onUpdate:width"?: ((...args: any[]) => any) | undefined;
    "onUpdate:enabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:searchTimeout"?: ((...args: any[]) => any) | undefined;
    "onUpdate:allowSearch"?: ((...args: any[]) => any) | undefined;
    "onUpdate:texts"?: ((...args: any[]) => any) | undefined;
    "onUpdate:layout"?: ((...args: any[]) => any) | undefined;
    "onUpdate:applyChangesMode"?: ((...args: any[]) => any) | undefined;
}, {
    enabled: boolean;
    allowSearch: boolean;
}>;
declare const DxFieldChooserTexts: import("vue").DefineComponent<{
    allFields: StringConstructor;
    columnFields: StringConstructor;
    dataFields: StringConstructor;
    filterFields: StringConstructor;
    rowFields: StringConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:allFields": null;
    "update:columnFields": null;
    "update:dataFields": null;
    "update:filterFields": null;
    "update:rowFields": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    allFields: StringConstructor;
    columnFields: StringConstructor;
    dataFields: StringConstructor;
    filterFields: StringConstructor;
    rowFields: StringConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:allFields"?: ((...args: any[]) => any) | undefined;
    "onUpdate:columnFields"?: ((...args: any[]) => any) | undefined;
    "onUpdate:dataFields"?: ((...args: any[]) => any) | undefined;
    "onUpdate:filterFields"?: ((...args: any[]) => any) | undefined;
    "onUpdate:rowFields"?: ((...args: any[]) => any) | undefined;
}, {}>;
declare const DxFieldPanel: import("vue").DefineComponent<{
    allowFieldDragging: BooleanConstructor;
    showColumnFields: BooleanConstructor;
    showDataFields: BooleanConstructor;
    showFilterFields: BooleanConstructor;
    showRowFields: BooleanConstructor;
    texts: PropType<Record<string, any>>;
    visible: BooleanConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:allowFieldDragging": null;
    "update:showColumnFields": null;
    "update:showDataFields": null;
    "update:showFilterFields": null;
    "update:showRowFields": null;
    "update:texts": null;
    "update:visible": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    allowFieldDragging: BooleanConstructor;
    showColumnFields: BooleanConstructor;
    showDataFields: BooleanConstructor;
    showFilterFields: BooleanConstructor;
    showRowFields: BooleanConstructor;
    texts: PropType<Record<string, any>>;
    visible: BooleanConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:visible"?: ((...args: any[]) => any) | undefined;
    "onUpdate:texts"?: ((...args: any[]) => any) | undefined;
    "onUpdate:allowFieldDragging"?: ((...args: any[]) => any) | undefined;
    "onUpdate:showColumnFields"?: ((...args: any[]) => any) | undefined;
    "onUpdate:showDataFields"?: ((...args: any[]) => any) | undefined;
    "onUpdate:showFilterFields"?: ((...args: any[]) => any) | undefined;
    "onUpdate:showRowFields"?: ((...args: any[]) => any) | undefined;
}, {
    visible: boolean;
    allowFieldDragging: boolean;
    showColumnFields: boolean;
    showDataFields: boolean;
    showFilterFields: boolean;
    showRowFields: boolean;
}>;
declare const DxFieldPanelTexts: import("vue").DefineComponent<{
    columnFieldArea: StringConstructor;
    dataFieldArea: StringConstructor;
    filterFieldArea: StringConstructor;
    rowFieldArea: StringConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:columnFieldArea": null;
    "update:dataFieldArea": null;
    "update:filterFieldArea": null;
    "update:rowFieldArea": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    columnFieldArea: StringConstructor;
    dataFieldArea: StringConstructor;
    filterFieldArea: StringConstructor;
    rowFieldArea: StringConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:dataFieldArea"?: ((...args: any[]) => any) | undefined;
    "onUpdate:columnFieldArea"?: ((...args: any[]) => any) | undefined;
    "onUpdate:filterFieldArea"?: ((...args: any[]) => any) | undefined;
    "onUpdate:rowFieldArea"?: ((...args: any[]) => any) | undefined;
}, {}>;
declare const DxHeaderFilter: import("vue").DefineComponent<{
    allowSearch: BooleanConstructor;
    allowSelectAll: BooleanConstructor;
    height: NumberConstructor;
    search: PropType<Record<string, any> | HeaderFilterSearchConfig>;
    searchTimeout: NumberConstructor;
    showRelevantValues: BooleanConstructor;
    texts: PropType<Record<string, any>>;
    width: NumberConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:allowSearch": null;
    "update:allowSelectAll": null;
    "update:height": null;
    "update:search": null;
    "update:searchTimeout": null;
    "update:showRelevantValues": null;
    "update:texts": null;
    "update:width": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    allowSearch: BooleanConstructor;
    allowSelectAll: BooleanConstructor;
    height: NumberConstructor;
    search: PropType<Record<string, any> | HeaderFilterSearchConfig>;
    searchTimeout: NumberConstructor;
    showRelevantValues: BooleanConstructor;
    texts: PropType<Record<string, any>>;
    width: NumberConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:height"?: ((...args: any[]) => any) | undefined;
    "onUpdate:width"?: ((...args: any[]) => any) | undefined;
    "onUpdate:searchTimeout"?: ((...args: any[]) => any) | undefined;
    "onUpdate:allowSearch"?: ((...args: any[]) => any) | undefined;
    "onUpdate:search"?: ((...args: any[]) => any) | undefined;
    "onUpdate:allowSelectAll"?: ((...args: any[]) => any) | undefined;
    "onUpdate:texts"?: ((...args: any[]) => any) | undefined;
    "onUpdate:showRelevantValues"?: ((...args: any[]) => any) | undefined;
}, {
    allowSearch: boolean;
    allowSelectAll: boolean;
    showRelevantValues: boolean;
}>;
declare const DxHeaderFilterTexts: import("vue").DefineComponent<{
    cancel: StringConstructor;
    emptyValue: StringConstructor;
    ok: StringConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:cancel": null;
    "update:emptyValue": null;
    "update:ok": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    cancel: StringConstructor;
    emptyValue: StringConstructor;
    ok: StringConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:cancel"?: ((...args: any[]) => any) | undefined;
    "onUpdate:emptyValue"?: ((...args: any[]) => any) | undefined;
    "onUpdate:ok"?: ((...args: any[]) => any) | undefined;
}, {}>;
declare const DxLoadPanel: import("vue").DefineComponent<{
    enabled: BooleanConstructor;
    height: NumberConstructor;
    indicatorSrc: StringConstructor;
    shading: BooleanConstructor;
    shadingColor: StringConstructor;
    showIndicator: BooleanConstructor;
    showPane: BooleanConstructor;
    text: StringConstructor;
    width: NumberConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:enabled": null;
    "update:height": null;
    "update:indicatorSrc": null;
    "update:shading": null;
    "update:shadingColor": null;
    "update:showIndicator": null;
    "update:showPane": null;
    "update:text": null;
    "update:width": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    enabled: BooleanConstructor;
    height: NumberConstructor;
    indicatorSrc: StringConstructor;
    shading: BooleanConstructor;
    shadingColor: StringConstructor;
    showIndicator: BooleanConstructor;
    showPane: BooleanConstructor;
    text: StringConstructor;
    width: NumberConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:height"?: ((...args: any[]) => any) | undefined;
    "onUpdate:text"?: ((...args: any[]) => any) | undefined;
    "onUpdate:width"?: ((...args: any[]) => any) | undefined;
    "onUpdate:enabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:shading"?: ((...args: any[]) => any) | undefined;
    "onUpdate:shadingColor"?: ((...args: any[]) => any) | undefined;
    "onUpdate:indicatorSrc"?: ((...args: any[]) => any) | undefined;
    "onUpdate:showIndicator"?: ((...args: any[]) => any) | undefined;
    "onUpdate:showPane"?: ((...args: any[]) => any) | undefined;
}, {
    enabled: boolean;
    shading: boolean;
    showIndicator: boolean;
    showPane: boolean;
}>;
declare const DxPivotGridTexts: import("vue").DefineComponent<{
    collapseAll: StringConstructor;
    dataNotAvailable: StringConstructor;
    expandAll: StringConstructor;
    exportToExcel: StringConstructor;
    grandTotal: StringConstructor;
    noData: StringConstructor;
    removeAllSorting: StringConstructor;
    showFieldChooser: StringConstructor;
    sortColumnBySummary: StringConstructor;
    sortRowBySummary: StringConstructor;
    total: StringConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:collapseAll": null;
    "update:dataNotAvailable": null;
    "update:expandAll": null;
    "update:exportToExcel": null;
    "update:grandTotal": null;
    "update:noData": null;
    "update:removeAllSorting": null;
    "update:showFieldChooser": null;
    "update:sortColumnBySummary": null;
    "update:sortRowBySummary": null;
    "update:total": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    collapseAll: StringConstructor;
    dataNotAvailable: StringConstructor;
    expandAll: StringConstructor;
    exportToExcel: StringConstructor;
    grandTotal: StringConstructor;
    noData: StringConstructor;
    removeAllSorting: StringConstructor;
    showFieldChooser: StringConstructor;
    sortColumnBySummary: StringConstructor;
    sortRowBySummary: StringConstructor;
    total: StringConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:collapseAll"?: ((...args: any[]) => any) | undefined;
    "onUpdate:dataNotAvailable"?: ((...args: any[]) => any) | undefined;
    "onUpdate:expandAll"?: ((...args: any[]) => any) | undefined;
    "onUpdate:exportToExcel"?: ((...args: any[]) => any) | undefined;
    "onUpdate:grandTotal"?: ((...args: any[]) => any) | undefined;
    "onUpdate:noData"?: ((...args: any[]) => any) | undefined;
    "onUpdate:removeAllSorting"?: ((...args: any[]) => any) | undefined;
    "onUpdate:showFieldChooser"?: ((...args: any[]) => any) | undefined;
    "onUpdate:sortColumnBySummary"?: ((...args: any[]) => any) | undefined;
    "onUpdate:sortRowBySummary"?: ((...args: any[]) => any) | undefined;
    "onUpdate:total"?: ((...args: any[]) => any) | undefined;
}, {}>;
declare const DxScrolling: import("vue").DefineComponent<{
    mode: PropType<ScrollMode>;
    useNative: PropType<boolean | "auto">;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:mode": null;
    "update:useNative": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    mode: PropType<ScrollMode>;
    useNative: PropType<boolean | "auto">;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:mode"?: ((...args: any[]) => any) | undefined;
    "onUpdate:useNative"?: ((...args: any[]) => any) | undefined;
}, {}>;
declare const DxSearch: import("vue").DefineComponent<{
    editorOptions: {};
    enabled: BooleanConstructor;
    mode: PropType<SearchMode>;
    timeout: NumberConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:editorOptions": null;
    "update:enabled": null;
    "update:mode": null;
    "update:timeout": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    editorOptions: {};
    enabled: BooleanConstructor;
    mode: PropType<SearchMode>;
    timeout: NumberConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:enabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:mode"?: ((...args: any[]) => any) | undefined;
    "onUpdate:editorOptions"?: ((...args: any[]) => any) | undefined;
    "onUpdate:timeout"?: ((...args: any[]) => any) | undefined;
}, {
    enabled: boolean;
}>;
declare const DxStateStoring: import("vue").DefineComponent<{
    customLoad: PropType<() => any>;
    customSave: PropType<(state: any) => void>;
    enabled: BooleanConstructor;
    savingTimeout: NumberConstructor;
    storageKey: StringConstructor;
    type: PropType<StateStoreType>;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:customLoad": null;
    "update:customSave": null;
    "update:enabled": null;
    "update:savingTimeout": null;
    "update:storageKey": null;
    "update:type": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    customLoad: PropType<() => any>;
    customSave: PropType<(state: any) => void>;
    enabled: BooleanConstructor;
    savingTimeout: NumberConstructor;
    storageKey: StringConstructor;
    type: PropType<StateStoreType>;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:type"?: ((...args: any[]) => any) | undefined;
    "onUpdate:enabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:customLoad"?: ((...args: any[]) => any) | undefined;
    "onUpdate:customSave"?: ((...args: any[]) => any) | undefined;
    "onUpdate:savingTimeout"?: ((...args: any[]) => any) | undefined;
    "onUpdate:storageKey"?: ((...args: any[]) => any) | undefined;
}, {
    enabled: boolean;
}>;
declare const DxTexts: import("vue").DefineComponent<{
    allFields: StringConstructor;
    cancel: StringConstructor;
    collapseAll: StringConstructor;
    columnFieldArea: StringConstructor;
    columnFields: StringConstructor;
    dataFieldArea: StringConstructor;
    dataFields: StringConstructor;
    dataNotAvailable: StringConstructor;
    emptyValue: StringConstructor;
    expandAll: StringConstructor;
    exportToExcel: StringConstructor;
    filterFieldArea: StringConstructor;
    filterFields: StringConstructor;
    grandTotal: StringConstructor;
    noData: StringConstructor;
    ok: StringConstructor;
    removeAllSorting: StringConstructor;
    rowFieldArea: StringConstructor;
    rowFields: StringConstructor;
    showFieldChooser: StringConstructor;
    sortColumnBySummary: StringConstructor;
    sortRowBySummary: StringConstructor;
    total: StringConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:allFields": null;
    "update:cancel": null;
    "update:collapseAll": null;
    "update:columnFieldArea": null;
    "update:columnFields": null;
    "update:dataFieldArea": null;
    "update:dataFields": null;
    "update:dataNotAvailable": null;
    "update:emptyValue": null;
    "update:expandAll": null;
    "update:exportToExcel": null;
    "update:filterFieldArea": null;
    "update:filterFields": null;
    "update:grandTotal": null;
    "update:noData": null;
    "update:ok": null;
    "update:removeAllSorting": null;
    "update:rowFieldArea": null;
    "update:rowFields": null;
    "update:showFieldChooser": null;
    "update:sortColumnBySummary": null;
    "update:sortRowBySummary": null;
    "update:total": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    allFields: StringConstructor;
    cancel: StringConstructor;
    collapseAll: StringConstructor;
    columnFieldArea: StringConstructor;
    columnFields: StringConstructor;
    dataFieldArea: StringConstructor;
    dataFields: StringConstructor;
    dataNotAvailable: StringConstructor;
    emptyValue: StringConstructor;
    expandAll: StringConstructor;
    exportToExcel: StringConstructor;
    filterFieldArea: StringConstructor;
    filterFields: StringConstructor;
    grandTotal: StringConstructor;
    noData: StringConstructor;
    ok: StringConstructor;
    removeAllSorting: StringConstructor;
    rowFieldArea: StringConstructor;
    rowFields: StringConstructor;
    showFieldChooser: StringConstructor;
    sortColumnBySummary: StringConstructor;
    sortRowBySummary: StringConstructor;
    total: StringConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:cancel"?: ((...args: any[]) => any) | undefined;
    "onUpdate:emptyValue"?: ((...args: any[]) => any) | undefined;
    "onUpdate:ok"?: ((...args: any[]) => any) | undefined;
    "onUpdate:dataFieldArea"?: ((...args: any[]) => any) | undefined;
    "onUpdate:allFields"?: ((...args: any[]) => any) | undefined;
    "onUpdate:columnFields"?: ((...args: any[]) => any) | undefined;
    "onUpdate:dataFields"?: ((...args: any[]) => any) | undefined;
    "onUpdate:filterFields"?: ((...args: any[]) => any) | undefined;
    "onUpdate:rowFields"?: ((...args: any[]) => any) | undefined;
    "onUpdate:columnFieldArea"?: ((...args: any[]) => any) | undefined;
    "onUpdate:filterFieldArea"?: ((...args: any[]) => any) | undefined;
    "onUpdate:rowFieldArea"?: ((...args: any[]) => any) | undefined;
    "onUpdate:collapseAll"?: ((...args: any[]) => any) | undefined;
    "onUpdate:dataNotAvailable"?: ((...args: any[]) => any) | undefined;
    "onUpdate:expandAll"?: ((...args: any[]) => any) | undefined;
    "onUpdate:exportToExcel"?: ((...args: any[]) => any) | undefined;
    "onUpdate:grandTotal"?: ((...args: any[]) => any) | undefined;
    "onUpdate:noData"?: ((...args: any[]) => any) | undefined;
    "onUpdate:removeAllSorting"?: ((...args: any[]) => any) | undefined;
    "onUpdate:showFieldChooser"?: ((...args: any[]) => any) | undefined;
    "onUpdate:sortColumnBySummary"?: ((...args: any[]) => any) | undefined;
    "onUpdate:sortRowBySummary"?: ((...args: any[]) => any) | undefined;
    "onUpdate:total"?: ((...args: any[]) => any) | undefined;
}, {}>;
export default DxPivotGrid;
export { DxPivotGrid, DxExport, DxFieldChooser, DxFieldChooserTexts, DxFieldPanel, DxFieldPanelTexts, DxHeaderFilter, DxHeaderFilterTexts, DxLoadPanel, DxPivotGridTexts, DxScrolling, DxSearch, DxStateStoring, DxTexts };
import type * as DxPivotGridTypes from "devextreme/ui/pivot_grid_types";
export { DxPivotGridTypes };
