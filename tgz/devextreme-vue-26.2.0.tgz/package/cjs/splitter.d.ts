/*!
 * devextreme-vue
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

export { ExplicitTypes } from "devextreme/ui/splitter";
import { PropType } from "vue";
import Splitter, { Properties } from "devextreme/ui/splitter";
import DataSource from "devextreme/data/data_source";
import { dxSplitterItem, ContentReadyEvent, DisposingEvent, InitializedEvent, ItemClickEvent, ItemCollapsedEvent, ItemContextMenuEvent, ItemExpandedEvent, ItemRenderedEvent, OptionChangedEvent, ResizeEvent, ResizeEndEvent, ResizeStartEvent, dxSplitterOptions } from "devextreme/ui/splitter";
import { DataSourceOptions } from "devextreme/common/data";
import { Store } from "devextreme/data/store";
import { Orientation } from "devextreme/common";
type AccessibleOptions = Pick<Properties, "allowKeyboardNavigation" | "dataSource" | "disabled" | "elementAttr" | "height" | "hoverStateEnabled" | "items" | "itemTemplate" | "onContentReady" | "onDisposing" | "onInitialized" | "onItemClick" | "onItemCollapsed" | "onItemContextMenu" | "onItemExpanded" | "onItemRendered" | "onOptionChanged" | "onResize" | "onResizeEnd" | "onResizeStart" | "orientation" | "rtlEnabled" | "separatorSize" | "visible" | "width">;
interface DxSplitter extends AccessibleOptions {
    readonly instance?: Splitter;
}
declare const DxSplitter: import("vue").DefineComponent<{
    allowKeyboardNavigation: BooleanConstructor;
    dataSource: PropType<string | Record<string, any> | DataSource<any, any> | DataSourceOptions<any, any, any, any> | Store<any, any> | dxSplitterItem<any>[] | null>;
    disabled: BooleanConstructor;
    elementAttr: PropType<Record<string, any>>;
    height: (NumberConstructor | StringConstructor)[];
    hoverStateEnabled: BooleanConstructor;
    items: PropType<dxSplitterItem<any>[]>;
    itemTemplate: {};
    onContentReady: PropType<(e: ContentReadyEvent) => void>;
    onDisposing: PropType<(e: DisposingEvent) => void>;
    onInitialized: PropType<(e: InitializedEvent) => void>;
    onItemClick: PropType<(e: ItemClickEvent) => void>;
    onItemCollapsed: PropType<(e: ItemCollapsedEvent) => void>;
    onItemContextMenu: PropType<(e: ItemContextMenuEvent) => void>;
    onItemExpanded: PropType<(e: ItemExpandedEvent) => void>;
    onItemRendered: PropType<(e: ItemRenderedEvent) => void>;
    onOptionChanged: PropType<(e: OptionChangedEvent) => void>;
    onResize: PropType<(e: ResizeEvent) => void>;
    onResizeEnd: PropType<(e: ResizeEndEvent) => void>;
    onResizeStart: PropType<(e: ResizeStartEvent) => void>;
    orientation: PropType<Orientation>;
    rtlEnabled: BooleanConstructor;
    separatorSize: NumberConstructor;
    visible: BooleanConstructor;
    width: (NumberConstructor | StringConstructor)[];
}, unknown, unknown, {
    instance(): Splitter;
}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:allowKeyboardNavigation": null;
    "update:dataSource": null;
    "update:disabled": null;
    "update:elementAttr": null;
    "update:height": null;
    "update:hoverStateEnabled": null;
    "update:items": null;
    "update:itemTemplate": null;
    "update:onContentReady": null;
    "update:onDisposing": null;
    "update:onInitialized": null;
    "update:onItemClick": null;
    "update:onItemCollapsed": null;
    "update:onItemContextMenu": null;
    "update:onItemExpanded": null;
    "update:onItemRendered": null;
    "update:onOptionChanged": null;
    "update:onResize": null;
    "update:onResizeEnd": null;
    "update:onResizeStart": null;
    "update:orientation": null;
    "update:rtlEnabled": null;
    "update:separatorSize": null;
    "update:visible": null;
    "update:width": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    allowKeyboardNavigation: BooleanConstructor;
    dataSource: PropType<string | Record<string, any> | DataSource<any, any> | DataSourceOptions<any, any, any, any> | Store<any, any> | dxSplitterItem<any>[] | null>;
    disabled: BooleanConstructor;
    elementAttr: PropType<Record<string, any>>;
    height: (NumberConstructor | StringConstructor)[];
    hoverStateEnabled: BooleanConstructor;
    items: PropType<dxSplitterItem<any>[]>;
    itemTemplate: {};
    onContentReady: PropType<(e: ContentReadyEvent) => void>;
    onDisposing: PropType<(e: DisposingEvent) => void>;
    onInitialized: PropType<(e: InitializedEvent) => void>;
    onItemClick: PropType<(e: ItemClickEvent) => void>;
    onItemCollapsed: PropType<(e: ItemCollapsedEvent) => void>;
    onItemContextMenu: PropType<(e: ItemContextMenuEvent) => void>;
    onItemExpanded: PropType<(e: ItemExpandedEvent) => void>;
    onItemRendered: PropType<(e: ItemRenderedEvent) => void>;
    onOptionChanged: PropType<(e: OptionChangedEvent) => void>;
    onResize: PropType<(e: ResizeEvent) => void>;
    onResizeEnd: PropType<(e: ResizeEndEvent) => void>;
    onResizeStart: PropType<(e: ResizeStartEvent) => void>;
    orientation: PropType<Orientation>;
    rtlEnabled: BooleanConstructor;
    separatorSize: NumberConstructor;
    visible: BooleanConstructor;
    width: (NumberConstructor | StringConstructor)[];
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:disabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:elementAttr"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onDisposing"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onInitialized"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onOptionChanged"?: ((...args: any[]) => any) | undefined;
    "onUpdate:rtlEnabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:height"?: ((...args: any[]) => any) | undefined;
    "onUpdate:width"?: ((...args: any[]) => any) | undefined;
    "onUpdate:visible"?: ((...args: any[]) => any) | undefined;
    "onUpdate:dataSource"?: ((...args: any[]) => any) | undefined;
    "onUpdate:orientation"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoverStateEnabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:items"?: ((...args: any[]) => any) | undefined;
    "onUpdate:itemTemplate"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onContentReady"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onItemClick"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onItemCollapsed"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onItemContextMenu"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onItemExpanded"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onItemRendered"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onResize"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onResizeEnd"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onResizeStart"?: ((...args: any[]) => any) | undefined;
    "onUpdate:allowKeyboardNavigation"?: ((...args: any[]) => any) | undefined;
    "onUpdate:separatorSize"?: ((...args: any[]) => any) | undefined;
}, {
    disabled: boolean;
    rtlEnabled: boolean;
    visible: boolean;
    hoverStateEnabled: boolean;
    allowKeyboardNavigation: boolean;
}>;
declare const DxItem: import("vue").DefineComponent<{
    collapsed: BooleanConstructor;
    collapsedSize: (NumberConstructor | StringConstructor)[];
    collapsible: BooleanConstructor;
    maxSize: (NumberConstructor | StringConstructor)[];
    minSize: (NumberConstructor | StringConstructor)[];
    resizable: BooleanConstructor;
    size: (NumberConstructor | StringConstructor)[];
    splitter: PropType<Record<string, any> | dxSplitterOptions<any, any>>;
    template: {};
    text: StringConstructor;
    visible: BooleanConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:collapsed": null;
    "update:collapsedSize": null;
    "update:collapsible": null;
    "update:maxSize": null;
    "update:minSize": null;
    "update:resizable": null;
    "update:size": null;
    "update:splitter": null;
    "update:template": null;
    "update:text": null;
    "update:visible": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    collapsed: BooleanConstructor;
    collapsedSize: (NumberConstructor | StringConstructor)[];
    collapsible: BooleanConstructor;
    maxSize: (NumberConstructor | StringConstructor)[];
    minSize: (NumberConstructor | StringConstructor)[];
    resizable: BooleanConstructor;
    size: (NumberConstructor | StringConstructor)[];
    splitter: PropType<Record<string, any> | dxSplitterOptions<any, any>>;
    template: {};
    text: StringConstructor;
    visible: BooleanConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:size"?: ((...args: any[]) => any) | undefined;
    "onUpdate:template"?: ((...args: any[]) => any) | undefined;
    "onUpdate:text"?: ((...args: any[]) => any) | undefined;
    "onUpdate:visible"?: ((...args: any[]) => any) | undefined;
    "onUpdate:maxSize"?: ((...args: any[]) => any) | undefined;
    "onUpdate:minSize"?: ((...args: any[]) => any) | undefined;
    "onUpdate:collapsed"?: ((...args: any[]) => any) | undefined;
    "onUpdate:collapsedSize"?: ((...args: any[]) => any) | undefined;
    "onUpdate:collapsible"?: ((...args: any[]) => any) | undefined;
    "onUpdate:resizable"?: ((...args: any[]) => any) | undefined;
    "onUpdate:splitter"?: ((...args: any[]) => any) | undefined;
}, {
    visible: boolean;
    collapsed: boolean;
    collapsible: boolean;
    resizable: boolean;
}>;
export default DxSplitter;
export { DxSplitter, DxItem };
import type * as DxSplitterTypes from "devextreme/ui/splitter_types";
export { DxSplitterTypes };
