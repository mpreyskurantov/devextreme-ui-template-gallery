/*!
 * devextreme-vue
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

import { PropType } from "vue";
import Switch, { Properties } from "devextreme/ui/switch";
import { ContentReadyEvent, DisposingEvent, InitializedEvent, OptionChangedEvent, ValueChangedEvent } from "devextreme/ui/switch";
import { ValidationMessageMode, Position, ValidationStatus } from "devextreme/common";
type AccessibleOptions = Pick<Properties, "accessKey" | "activeStateEnabled" | "disabled" | "elementAttr" | "focusStateEnabled" | "height" | "hint" | "hoverStateEnabled" | "isDirty" | "isValid" | "name" | "onContentReady" | "onDisposing" | "onInitialized" | "onOptionChanged" | "onValueChanged" | "readOnly" | "rtlEnabled" | "switchedOffText" | "switchedOnText" | "tabIndex" | "validationError" | "validationErrors" | "validationMessageMode" | "validationMessagePosition" | "validationStatus" | "value" | "visible" | "width">;
interface DxSwitch extends AccessibleOptions {
    readonly instance?: Switch;
}
declare const DxSwitch: import("vue").DefineComponent<{
    accessKey: StringConstructor;
    activeStateEnabled: BooleanConstructor;
    disabled: BooleanConstructor;
    elementAttr: PropType<Record<string, any>>;
    focusStateEnabled: BooleanConstructor;
    height: (NumberConstructor | StringConstructor)[];
    hint: StringConstructor;
    hoverStateEnabled: BooleanConstructor;
    isDirty: BooleanConstructor;
    isValid: BooleanConstructor;
    name: StringConstructor;
    onContentReady: PropType<(e: ContentReadyEvent) => void>;
    onDisposing: PropType<(e: DisposingEvent) => void>;
    onInitialized: PropType<(e: InitializedEvent) => void>;
    onOptionChanged: PropType<(e: OptionChangedEvent) => void>;
    onValueChanged: PropType<(e: ValueChangedEvent) => void>;
    readOnly: BooleanConstructor;
    rtlEnabled: BooleanConstructor;
    switchedOffText: StringConstructor;
    switchedOnText: StringConstructor;
    tabIndex: NumberConstructor;
    validationError: {};
    validationErrors: PropType<any[] | null>;
    validationMessageMode: PropType<ValidationMessageMode>;
    validationMessagePosition: PropType<Position>;
    validationStatus: PropType<ValidationStatus>;
    value: BooleanConstructor;
    visible: BooleanConstructor;
    width: (NumberConstructor | StringConstructor)[];
}, unknown, unknown, {
    instance(): Switch;
}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:accessKey": null;
    "update:activeStateEnabled": null;
    "update:disabled": null;
    "update:elementAttr": null;
    "update:focusStateEnabled": null;
    "update:height": null;
    "update:hint": null;
    "update:hoverStateEnabled": null;
    "update:isDirty": null;
    "update:isValid": null;
    "update:name": null;
    "update:onContentReady": null;
    "update:onDisposing": null;
    "update:onInitialized": null;
    "update:onOptionChanged": null;
    "update:onValueChanged": null;
    "update:readOnly": null;
    "update:rtlEnabled": null;
    "update:switchedOffText": null;
    "update:switchedOnText": null;
    "update:tabIndex": null;
    "update:validationError": null;
    "update:validationErrors": null;
    "update:validationMessageMode": null;
    "update:validationMessagePosition": null;
    "update:validationStatus": null;
    "update:value": null;
    "update:visible": null;
    "update:width": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    accessKey: StringConstructor;
    activeStateEnabled: BooleanConstructor;
    disabled: BooleanConstructor;
    elementAttr: PropType<Record<string, any>>;
    focusStateEnabled: BooleanConstructor;
    height: (NumberConstructor | StringConstructor)[];
    hint: StringConstructor;
    hoverStateEnabled: BooleanConstructor;
    isDirty: BooleanConstructor;
    isValid: BooleanConstructor;
    name: StringConstructor;
    onContentReady: PropType<(e: ContentReadyEvent) => void>;
    onDisposing: PropType<(e: DisposingEvent) => void>;
    onInitialized: PropType<(e: InitializedEvent) => void>;
    onOptionChanged: PropType<(e: OptionChangedEvent) => void>;
    onValueChanged: PropType<(e: ValueChangedEvent) => void>;
    readOnly: BooleanConstructor;
    rtlEnabled: BooleanConstructor;
    switchedOffText: StringConstructor;
    switchedOnText: StringConstructor;
    tabIndex: NumberConstructor;
    validationError: {};
    validationErrors: PropType<any[] | null>;
    validationMessageMode: PropType<ValidationMessageMode>;
    validationMessagePosition: PropType<Position>;
    validationStatus: PropType<ValidationStatus>;
    value: BooleanConstructor;
    visible: BooleanConstructor;
    width: (NumberConstructor | StringConstructor)[];
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:disabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:elementAttr"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onDisposing"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onInitialized"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onOptionChanged"?: ((...args: any[]) => any) | undefined;
    "onUpdate:rtlEnabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:height"?: ((...args: any[]) => any) | undefined;
    "onUpdate:name"?: ((...args: any[]) => any) | undefined;
    "onUpdate:width"?: ((...args: any[]) => any) | undefined;
    "onUpdate:visible"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoverStateEnabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onContentReady"?: ((...args: any[]) => any) | undefined;
    "onUpdate:accessKey"?: ((...args: any[]) => any) | undefined;
    "onUpdate:activeStateEnabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:focusStateEnabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hint"?: ((...args: any[]) => any) | undefined;
    "onUpdate:tabIndex"?: ((...args: any[]) => any) | undefined;
    "onUpdate:isDirty"?: ((...args: any[]) => any) | undefined;
    "onUpdate:isValid"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onValueChanged"?: ((...args: any[]) => any) | undefined;
    "onUpdate:readOnly"?: ((...args: any[]) => any) | undefined;
    "onUpdate:validationError"?: ((...args: any[]) => any) | undefined;
    "onUpdate:validationErrors"?: ((...args: any[]) => any) | undefined;
    "onUpdate:validationMessageMode"?: ((...args: any[]) => any) | undefined;
    "onUpdate:validationMessagePosition"?: ((...args: any[]) => any) | undefined;
    "onUpdate:validationStatus"?: ((...args: any[]) => any) | undefined;
    "onUpdate:value"?: ((...args: any[]) => any) | undefined;
    "onUpdate:switchedOffText"?: ((...args: any[]) => any) | undefined;
    "onUpdate:switchedOnText"?: ((...args: any[]) => any) | undefined;
}, {
    value: boolean;
    disabled: boolean;
    rtlEnabled: boolean;
    visible: boolean;
    hoverStateEnabled: boolean;
    activeStateEnabled: boolean;
    focusStateEnabled: boolean;
    isDirty: boolean;
    isValid: boolean;
    readOnly: boolean;
}>;
export default DxSwitch;
export { DxSwitch };
import type * as DxSwitchTypes from "devextreme/ui/switch_types";
export { DxSwitchTypes };
