/*!
 * devextreme-vue
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

export { ExplicitTypes } from "devextreme/ui/toolbar";
import { PropType } from "vue";
import Toolbar, { Properties } from "devextreme/ui/toolbar";
import DataSource from "devextreme/data/data_source";
import { ContentReadyEvent, DisposingEvent, InitializedEvent, ItemClickEvent, ItemContextMenuEvent, ItemHoldEvent, ItemRenderedEvent, OptionChangedEvent, LocateInMenuMode, ShowTextMode } from "devextreme/ui/toolbar";
import { DataSourceOptions } from "devextreme/common/data";
import { Store } from "devextreme/data/store";
import { ToolbarItemLocation, ToolbarItemComponent } from "devextreme/common";
type AccessibleOptions = Pick<Properties, "allowKeyboardNavigation" | "dataSource" | "disabled" | "elementAttr" | "hint" | "hoverStateEnabled" | "itemHoldTimeout" | "items" | "itemTemplate" | "menuItemTemplate" | "multiline" | "noDataText" | "onContentReady" | "onDisposing" | "onInitialized" | "onItemClick" | "onItemContextMenu" | "onItemHold" | "onItemRendered" | "onOptionChanged" | "rtlEnabled" | "visible" | "width">;
interface DxToolbar extends AccessibleOptions {
    readonly instance?: Toolbar;
}
declare const DxToolbar: import("vue").DefineComponent<{
    allowKeyboardNavigation: BooleanConstructor;
    dataSource: PropType<string | any[] | Record<string, any> | DataSource<any, any> | DataSourceOptions<any, any, any, any> | Store<any, any> | null>;
    disabled: BooleanConstructor;
    elementAttr: PropType<Record<string, any>>;
    hint: StringConstructor;
    hoverStateEnabled: BooleanConstructor;
    itemHoldTimeout: NumberConstructor;
    items: PropType<any[]>;
    itemTemplate: {};
    menuItemTemplate: {};
    multiline: BooleanConstructor;
    noDataText: StringConstructor;
    onContentReady: PropType<(e: ContentReadyEvent) => void>;
    onDisposing: PropType<(e: DisposingEvent) => void>;
    onInitialized: PropType<(e: InitializedEvent) => void>;
    onItemClick: PropType<(e: ItemClickEvent) => void>;
    onItemContextMenu: PropType<(e: ItemContextMenuEvent) => void>;
    onItemHold: PropType<(e: ItemHoldEvent) => void>;
    onItemRendered: PropType<(e: ItemRenderedEvent) => void>;
    onOptionChanged: PropType<(e: OptionChangedEvent) => void>;
    rtlEnabled: BooleanConstructor;
    visible: BooleanConstructor;
    width: (NumberConstructor | StringConstructor)[];
}, unknown, unknown, {
    instance(): Toolbar;
}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:allowKeyboardNavigation": null;
    "update:dataSource": null;
    "update:disabled": null;
    "update:elementAttr": null;
    "update:hint": null;
    "update:hoverStateEnabled": null;
    "update:itemHoldTimeout": null;
    "update:items": null;
    "update:itemTemplate": null;
    "update:menuItemTemplate": null;
    "update:multiline": null;
    "update:noDataText": null;
    "update:onContentReady": null;
    "update:onDisposing": null;
    "update:onInitialized": null;
    "update:onItemClick": null;
    "update:onItemContextMenu": null;
    "update:onItemHold": null;
    "update:onItemRendered": null;
    "update:onOptionChanged": null;
    "update:rtlEnabled": null;
    "update:visible": null;
    "update:width": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    allowKeyboardNavigation: BooleanConstructor;
    dataSource: PropType<string | any[] | Record<string, any> | DataSource<any, any> | DataSourceOptions<any, any, any, any> | Store<any, any> | null>;
    disabled: BooleanConstructor;
    elementAttr: PropType<Record<string, any>>;
    hint: StringConstructor;
    hoverStateEnabled: BooleanConstructor;
    itemHoldTimeout: NumberConstructor;
    items: PropType<any[]>;
    itemTemplate: {};
    menuItemTemplate: {};
    multiline: BooleanConstructor;
    noDataText: StringConstructor;
    onContentReady: PropType<(e: ContentReadyEvent) => void>;
    onDisposing: PropType<(e: DisposingEvent) => void>;
    onInitialized: PropType<(e: InitializedEvent) => void>;
    onItemClick: PropType<(e: ItemClickEvent) => void>;
    onItemContextMenu: PropType<(e: ItemContextMenuEvent) => void>;
    onItemHold: PropType<(e: ItemHoldEvent) => void>;
    onItemRendered: PropType<(e: ItemRenderedEvent) => void>;
    onOptionChanged: PropType<(e: OptionChangedEvent) => void>;
    rtlEnabled: BooleanConstructor;
    visible: BooleanConstructor;
    width: (NumberConstructor | StringConstructor)[];
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:disabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:elementAttr"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onDisposing"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onInitialized"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onOptionChanged"?: ((...args: any[]) => any) | undefined;
    "onUpdate:rtlEnabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:width"?: ((...args: any[]) => any) | undefined;
    "onUpdate:visible"?: ((...args: any[]) => any) | undefined;
    "onUpdate:dataSource"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoverStateEnabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:items"?: ((...args: any[]) => any) | undefined;
    "onUpdate:itemTemplate"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onContentReady"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onItemClick"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hint"?: ((...args: any[]) => any) | undefined;
    "onUpdate:itemHoldTimeout"?: ((...args: any[]) => any) | undefined;
    "onUpdate:noDataText"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onItemContextMenu"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onItemHold"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onItemRendered"?: ((...args: any[]) => any) | undefined;
    "onUpdate:menuItemTemplate"?: ((...args: any[]) => any) | undefined;
    "onUpdate:allowKeyboardNavigation"?: ((...args: any[]) => any) | undefined;
    "onUpdate:multiline"?: ((...args: any[]) => any) | undefined;
}, {
    disabled: boolean;
    rtlEnabled: boolean;
    visible: boolean;
    hoverStateEnabled: boolean;
    allowKeyboardNavigation: boolean;
    multiline: boolean;
}>;
declare const DxItem: import("vue").DefineComponent<{
    cssClass: StringConstructor;
    disabled: BooleanConstructor;
    html: StringConstructor;
    locateInMenu: PropType<LocateInMenuMode>;
    location: PropType<ToolbarItemLocation>;
    menuItemTemplate: {};
    options: {};
    showText: PropType<ShowTextMode>;
    template: {};
    text: StringConstructor;
    visible: BooleanConstructor;
    widget: PropType<ToolbarItemComponent>;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:cssClass": null;
    "update:disabled": null;
    "update:html": null;
    "update:locateInMenu": null;
    "update:location": null;
    "update:menuItemTemplate": null;
    "update:options": null;
    "update:showText": null;
    "update:template": null;
    "update:text": null;
    "update:visible": null;
    "update:widget": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    cssClass: StringConstructor;
    disabled: BooleanConstructor;
    html: StringConstructor;
    locateInMenu: PropType<LocateInMenuMode>;
    location: PropType<ToolbarItemLocation>;
    menuItemTemplate: {};
    options: {};
    showText: PropType<ShowTextMode>;
    template: {};
    text: StringConstructor;
    visible: BooleanConstructor;
    widget: PropType<ToolbarItemComponent>;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:disabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:template"?: ((...args: any[]) => any) | undefined;
    "onUpdate:text"?: ((...args: any[]) => any) | undefined;
    "onUpdate:visible"?: ((...args: any[]) => any) | undefined;
    "onUpdate:html"?: ((...args: any[]) => any) | undefined;
    "onUpdate:location"?: ((...args: any[]) => any) | undefined;
    "onUpdate:options"?: ((...args: any[]) => any) | undefined;
    "onUpdate:cssClass"?: ((...args: any[]) => any) | undefined;
    "onUpdate:locateInMenu"?: ((...args: any[]) => any) | undefined;
    "onUpdate:menuItemTemplate"?: ((...args: any[]) => any) | undefined;
    "onUpdate:showText"?: ((...args: any[]) => any) | undefined;
    "onUpdate:widget"?: ((...args: any[]) => any) | undefined;
}, {
    disabled: boolean;
    visible: boolean;
}>;
export default DxToolbar;
export { DxToolbar, DxItem };
import type * as DxToolbarTypes from "devextreme/ui/toolbar_types";
export { DxToolbarTypes };
