/*!
 * devextreme-vue
 * Version: 26.2.0
 * Build date: Fri Sep 11 2026
 *
 * Copyright (c) 2012 - 2026 Developer Express Inc. ALL RIGHTS RESERVED
 *
 * This software may be modified and distributed under the terms
 * of the MIT license. See the LICENSE file in the root of the project for details.
 *
 * https://github.com/DevExpress/DevExtreme
 */

import { PropType } from "vue";
import TreeMap, { Properties } from "devextreme/viz/tree_map";
import DataSource from "devextreme/data/data_source";
import { DataSourceOptions } from "devextreme/common/data";
import { Store } from "devextreme/data/store";
import { TreeMapLayoutAlgorithm, TreeMapLayoutDirection, ClickEvent, DisposingEvent, DrawnEvent, DrillEvent, ExportedEvent, ExportingEvent, FileSavingEvent, HoverChangedEvent, IncidentOccurredEvent, InitializedEvent, NodesInitializedEvent, NodesRenderingEvent, OptionChangedEvent, SelectionChangedEvent, TreeMapColorizerType, dxTreeMapNode } from "devextreme/viz/tree_map";
import { SingleMultipleOrNone, ExportFormat, HorizontalAlignment, VerticalEdge } from "devextreme/common";
import { Theme, DashStyle, Palette, PaletteExtensionMode, Font, TextOverflow, WordWrap } from "devextreme/common/charts";
type AccessibleOptions = Pick<Properties, "childrenField" | "colorField" | "colorizer" | "dataSource" | "disabled" | "elementAttr" | "encodeHtml" | "export" | "group" | "hoverEnabled" | "idField" | "interactWithGroup" | "labelField" | "layoutAlgorithm" | "layoutDirection" | "loadingIndicator" | "maxDepth" | "onClick" | "onDisposing" | "onDrawn" | "onDrill" | "onExported" | "onExporting" | "onFileSaving" | "onHoverChanged" | "onIncidentOccurred" | "onInitialized" | "onNodesInitialized" | "onNodesRendering" | "onOptionChanged" | "onSelectionChanged" | "parentField" | "pathModified" | "redrawOnResize" | "rtlEnabled" | "selectionMode" | "size" | "theme" | "tile" | "title" | "tooltip" | "valueField">;
interface DxTreeMap extends AccessibleOptions {
    readonly instance?: TreeMap;
}
declare const DxTreeMap: import("vue").DefineComponent<{
    childrenField: StringConstructor;
    colorField: StringConstructor;
    colorizer: PropType<Record<string, any>>;
    dataSource: PropType<string | any[] | Record<string, any> | DataSource<any, any> | DataSourceOptions<any, any, any, any> | Store<any, any> | null>;
    disabled: BooleanConstructor;
    elementAttr: PropType<Record<string, any>>;
    encodeHtml: BooleanConstructor;
    export: PropType<Record<string, any>>;
    group: PropType<Record<string, any>>;
    hoverEnabled: BooleanConstructor;
    idField: StringConstructor;
    interactWithGroup: BooleanConstructor;
    labelField: StringConstructor;
    layoutAlgorithm: PropType<((e: {
        items: Array<any>;
        rect: Array<number>;
        sum: number;
    }) => void) | TreeMapLayoutAlgorithm>;
    layoutDirection: PropType<TreeMapLayoutDirection>;
    loadingIndicator: PropType<Record<string, any>>;
    maxDepth: NumberConstructor;
    onClick: PropType<(e: ClickEvent) => void>;
    onDisposing: PropType<(e: DisposingEvent) => void>;
    onDrawn: PropType<(e: DrawnEvent) => void>;
    onDrill: PropType<(e: DrillEvent) => void>;
    onExported: PropType<(e: ExportedEvent) => void>;
    onExporting: PropType<(e: ExportingEvent) => void>;
    onFileSaving: PropType<(e: FileSavingEvent) => void>;
    onHoverChanged: PropType<(e: HoverChangedEvent) => void>;
    onIncidentOccurred: PropType<(e: IncidentOccurredEvent) => void>;
    onInitialized: PropType<(e: InitializedEvent) => void>;
    onNodesInitialized: PropType<(e: NodesInitializedEvent) => void>;
    onNodesRendering: PropType<(e: NodesRenderingEvent) => void>;
    onOptionChanged: PropType<(e: OptionChangedEvent) => void>;
    onSelectionChanged: PropType<(e: SelectionChangedEvent) => void>;
    parentField: StringConstructor;
    pathModified: BooleanConstructor;
    redrawOnResize: BooleanConstructor;
    rtlEnabled: BooleanConstructor;
    selectionMode: PropType<SingleMultipleOrNone>;
    size: PropType<Record<string, any>>;
    theme: PropType<Theme>;
    tile: PropType<Record<string, any>>;
    title: PropType<string | Record<string, any>>;
    tooltip: PropType<Record<string, any>>;
    valueField: StringConstructor;
}, unknown, unknown, {
    instance(): TreeMap;
}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:childrenField": null;
    "update:colorField": null;
    "update:colorizer": null;
    "update:dataSource": null;
    "update:disabled": null;
    "update:elementAttr": null;
    "update:encodeHtml": null;
    "update:export": null;
    "update:group": null;
    "update:hoverEnabled": null;
    "update:idField": null;
    "update:interactWithGroup": null;
    "update:labelField": null;
    "update:layoutAlgorithm": null;
    "update:layoutDirection": null;
    "update:loadingIndicator": null;
    "update:maxDepth": null;
    "update:onClick": null;
    "update:onDisposing": null;
    "update:onDrawn": null;
    "update:onDrill": null;
    "update:onExported": null;
    "update:onExporting": null;
    "update:onFileSaving": null;
    "update:onHoverChanged": null;
    "update:onIncidentOccurred": null;
    "update:onInitialized": null;
    "update:onNodesInitialized": null;
    "update:onNodesRendering": null;
    "update:onOptionChanged": null;
    "update:onSelectionChanged": null;
    "update:parentField": null;
    "update:pathModified": null;
    "update:redrawOnResize": null;
    "update:rtlEnabled": null;
    "update:selectionMode": null;
    "update:size": null;
    "update:theme": null;
    "update:tile": null;
    "update:title": null;
    "update:tooltip": null;
    "update:valueField": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    childrenField: StringConstructor;
    colorField: StringConstructor;
    colorizer: PropType<Record<string, any>>;
    dataSource: PropType<string | any[] | Record<string, any> | DataSource<any, any> | DataSourceOptions<any, any, any, any> | Store<any, any> | null>;
    disabled: BooleanConstructor;
    elementAttr: PropType<Record<string, any>>;
    encodeHtml: BooleanConstructor;
    export: PropType<Record<string, any>>;
    group: PropType<Record<string, any>>;
    hoverEnabled: BooleanConstructor;
    idField: StringConstructor;
    interactWithGroup: BooleanConstructor;
    labelField: StringConstructor;
    layoutAlgorithm: PropType<((e: {
        items: Array<any>;
        rect: Array<number>;
        sum: number;
    }) => void) | TreeMapLayoutAlgorithm>;
    layoutDirection: PropType<TreeMapLayoutDirection>;
    loadingIndicator: PropType<Record<string, any>>;
    maxDepth: NumberConstructor;
    onClick: PropType<(e: ClickEvent) => void>;
    onDisposing: PropType<(e: DisposingEvent) => void>;
    onDrawn: PropType<(e: DrawnEvent) => void>;
    onDrill: PropType<(e: DrillEvent) => void>;
    onExported: PropType<(e: ExportedEvent) => void>;
    onExporting: PropType<(e: ExportingEvent) => void>;
    onFileSaving: PropType<(e: FileSavingEvent) => void>;
    onHoverChanged: PropType<(e: HoverChangedEvent) => void>;
    onIncidentOccurred: PropType<(e: IncidentOccurredEvent) => void>;
    onInitialized: PropType<(e: InitializedEvent) => void>;
    onNodesInitialized: PropType<(e: NodesInitializedEvent) => void>;
    onNodesRendering: PropType<(e: NodesRenderingEvent) => void>;
    onOptionChanged: PropType<(e: OptionChangedEvent) => void>;
    onSelectionChanged: PropType<(e: SelectionChangedEvent) => void>;
    parentField: StringConstructor;
    pathModified: BooleanConstructor;
    redrawOnResize: BooleanConstructor;
    rtlEnabled: BooleanConstructor;
    selectionMode: PropType<SingleMultipleOrNone>;
    size: PropType<Record<string, any>>;
    theme: PropType<Theme>;
    tile: PropType<Record<string, any>>;
    title: PropType<string | Record<string, any>>;
    tooltip: PropType<Record<string, any>>;
    valueField: StringConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:disabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:elementAttr"?: ((...args: any[]) => any) | undefined;
    "onUpdate:encodeHtml"?: ((...args: any[]) => any) | undefined;
    "onUpdate:export"?: ((...args: any[]) => any) | undefined;
    "onUpdate:loadingIndicator"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onClick"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onDisposing"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onDrawn"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onExported"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onExporting"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onFileSaving"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onIncidentOccurred"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onInitialized"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onOptionChanged"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onSelectionChanged"?: ((...args: any[]) => any) | undefined;
    "onUpdate:pathModified"?: ((...args: any[]) => any) | undefined;
    "onUpdate:redrawOnResize"?: ((...args: any[]) => any) | undefined;
    "onUpdate:rtlEnabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:size"?: ((...args: any[]) => any) | undefined;
    "onUpdate:theme"?: ((...args: any[]) => any) | undefined;
    "onUpdate:title"?: ((...args: any[]) => any) | undefined;
    "onUpdate:tooltip"?: ((...args: any[]) => any) | undefined;
    "onUpdate:dataSource"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoverEnabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:selectionMode"?: ((...args: any[]) => any) | undefined;
    "onUpdate:childrenField"?: ((...args: any[]) => any) | undefined;
    "onUpdate:colorField"?: ((...args: any[]) => any) | undefined;
    "onUpdate:colorizer"?: ((...args: any[]) => any) | undefined;
    "onUpdate:group"?: ((...args: any[]) => any) | undefined;
    "onUpdate:idField"?: ((...args: any[]) => any) | undefined;
    "onUpdate:interactWithGroup"?: ((...args: any[]) => any) | undefined;
    "onUpdate:labelField"?: ((...args: any[]) => any) | undefined;
    "onUpdate:layoutAlgorithm"?: ((...args: any[]) => any) | undefined;
    "onUpdate:layoutDirection"?: ((...args: any[]) => any) | undefined;
    "onUpdate:maxDepth"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onDrill"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onHoverChanged"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onNodesInitialized"?: ((...args: any[]) => any) | undefined;
    "onUpdate:onNodesRendering"?: ((...args: any[]) => any) | undefined;
    "onUpdate:parentField"?: ((...args: any[]) => any) | undefined;
    "onUpdate:tile"?: ((...args: any[]) => any) | undefined;
    "onUpdate:valueField"?: ((...args: any[]) => any) | undefined;
}, {
    disabled: boolean;
    encodeHtml: boolean;
    pathModified: boolean;
    redrawOnResize: boolean;
    rtlEnabled: boolean;
    hoverEnabled: boolean;
    interactWithGroup: boolean;
}>;
declare const DxBorder: import("vue").DefineComponent<{
    color: StringConstructor;
    dashStyle: PropType<DashStyle>;
    opacity: NumberConstructor;
    visible: BooleanConstructor;
    width: NumberConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:color": null;
    "update:dashStyle": null;
    "update:opacity": null;
    "update:visible": null;
    "update:width": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    color: StringConstructor;
    dashStyle: PropType<DashStyle>;
    opacity: NumberConstructor;
    visible: BooleanConstructor;
    width: NumberConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:color"?: ((...args: any[]) => any) | undefined;
    "onUpdate:opacity"?: ((...args: any[]) => any) | undefined;
    "onUpdate:width"?: ((...args: any[]) => any) | undefined;
    "onUpdate:dashStyle"?: ((...args: any[]) => any) | undefined;
    "onUpdate:visible"?: ((...args: any[]) => any) | undefined;
}, {
    visible: boolean;
}>;
declare const DxColorizer: import("vue").DefineComponent<{
    colorCodeField: StringConstructor;
    colorizeGroups: BooleanConstructor;
    palette: PropType<string[] | Palette>;
    paletteExtensionMode: PropType<PaletteExtensionMode>;
    range: PropType<number[]>;
    type: PropType<TreeMapColorizerType>;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:colorCodeField": null;
    "update:colorizeGroups": null;
    "update:palette": null;
    "update:paletteExtensionMode": null;
    "update:range": null;
    "update:type": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    colorCodeField: StringConstructor;
    colorizeGroups: BooleanConstructor;
    palette: PropType<string[] | Palette>;
    paletteExtensionMode: PropType<PaletteExtensionMode>;
    range: PropType<number[]>;
    type: PropType<TreeMapColorizerType>;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:type"?: ((...args: any[]) => any) | undefined;
    "onUpdate:palette"?: ((...args: any[]) => any) | undefined;
    "onUpdate:colorCodeField"?: ((...args: any[]) => any) | undefined;
    "onUpdate:colorizeGroups"?: ((...args: any[]) => any) | undefined;
    "onUpdate:paletteExtensionMode"?: ((...args: any[]) => any) | undefined;
    "onUpdate:range"?: ((...args: any[]) => any) | undefined;
}, {
    colorizeGroups: boolean;
}>;
declare const DxExport: import("vue").DefineComponent<{
    backgroundColor: StringConstructor;
    enabled: BooleanConstructor;
    fileName: StringConstructor;
    formats: PropType<ExportFormat[]>;
    margin: NumberConstructor;
    printingEnabled: BooleanConstructor;
    svgToCanvas: PropType<(svg: any, canvas: any) => any>;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:backgroundColor": null;
    "update:enabled": null;
    "update:fileName": null;
    "update:formats": null;
    "update:margin": null;
    "update:printingEnabled": null;
    "update:svgToCanvas": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    backgroundColor: StringConstructor;
    enabled: BooleanConstructor;
    fileName: StringConstructor;
    formats: PropType<ExportFormat[]>;
    margin: NumberConstructor;
    printingEnabled: BooleanConstructor;
    svgToCanvas: PropType<(svg: any, canvas: any) => any>;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:enabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:margin"?: ((...args: any[]) => any) | undefined;
    "onUpdate:backgroundColor"?: ((...args: any[]) => any) | undefined;
    "onUpdate:fileName"?: ((...args: any[]) => any) | undefined;
    "onUpdate:formats"?: ((...args: any[]) => any) | undefined;
    "onUpdate:printingEnabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:svgToCanvas"?: ((...args: any[]) => any) | undefined;
}, {
    enabled: boolean;
    printingEnabled: boolean;
}>;
declare const DxFont: import("vue").DefineComponent<{
    color: StringConstructor;
    family: StringConstructor;
    opacity: NumberConstructor;
    size: (NumberConstructor | StringConstructor)[];
    weight: NumberConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:color": null;
    "update:family": null;
    "update:opacity": null;
    "update:size": null;
    "update:weight": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    color: StringConstructor;
    family: StringConstructor;
    opacity: NumberConstructor;
    size: (NumberConstructor | StringConstructor)[];
    weight: NumberConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:size"?: ((...args: any[]) => any) | undefined;
    "onUpdate:color"?: ((...args: any[]) => any) | undefined;
    "onUpdate:opacity"?: ((...args: any[]) => any) | undefined;
    "onUpdate:family"?: ((...args: any[]) => any) | undefined;
    "onUpdate:weight"?: ((...args: any[]) => any) | undefined;
}, {}>;
declare const DxFormat: import("vue").DefineComponent<{
    currency: StringConstructor;
    formatter: PropType<(value: number | Date) => string>;
    parser: PropType<(value: string) => number | Date>;
    precision: NumberConstructor;
    type: PropType<string>;
    useCurrencyAccountingStyle: BooleanConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:currency": null;
    "update:formatter": null;
    "update:parser": null;
    "update:precision": null;
    "update:type": null;
    "update:useCurrencyAccountingStyle": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    currency: StringConstructor;
    formatter: PropType<(value: number | Date) => string>;
    parser: PropType<(value: string) => number | Date>;
    precision: NumberConstructor;
    type: PropType<string>;
    useCurrencyAccountingStyle: BooleanConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:type"?: ((...args: any[]) => any) | undefined;
    "onUpdate:currency"?: ((...args: any[]) => any) | undefined;
    "onUpdate:formatter"?: ((...args: any[]) => any) | undefined;
    "onUpdate:parser"?: ((...args: any[]) => any) | undefined;
    "onUpdate:precision"?: ((...args: any[]) => any) | undefined;
    "onUpdate:useCurrencyAccountingStyle"?: ((...args: any[]) => any) | undefined;
}, {
    useCurrencyAccountingStyle: boolean;
}>;
declare const DxGroup: import("vue").DefineComponent<{
    border: PropType<Record<string, any>>;
    color: StringConstructor;
    headerHeight: NumberConstructor;
    hoverEnabled: BooleanConstructor;
    hoverStyle: PropType<Record<string, any>>;
    label: PropType<Record<string, any>>;
    padding: NumberConstructor;
    selectionStyle: PropType<Record<string, any>>;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:border": null;
    "update:color": null;
    "update:headerHeight": null;
    "update:hoverEnabled": null;
    "update:hoverStyle": null;
    "update:label": null;
    "update:padding": null;
    "update:selectionStyle": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    border: PropType<Record<string, any>>;
    color: StringConstructor;
    headerHeight: NumberConstructor;
    hoverEnabled: BooleanConstructor;
    hoverStyle: PropType<Record<string, any>>;
    label: PropType<Record<string, any>>;
    padding: NumberConstructor;
    selectionStyle: PropType<Record<string, any>>;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:border"?: ((...args: any[]) => any) | undefined;
    "onUpdate:color"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoverEnabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:label"?: ((...args: any[]) => any) | undefined;
    "onUpdate:headerHeight"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoverStyle"?: ((...args: any[]) => any) | undefined;
    "onUpdate:padding"?: ((...args: any[]) => any) | undefined;
    "onUpdate:selectionStyle"?: ((...args: any[]) => any) | undefined;
}, {
    hoverEnabled: boolean;
}>;
declare const DxGroupLabel: import("vue").DefineComponent<{
    font: PropType<Record<string, any> | Font>;
    textOverflow: PropType<TextOverflow>;
    visible: BooleanConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:font": null;
    "update:textOverflow": null;
    "update:visible": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    font: PropType<Record<string, any> | Font>;
    textOverflow: PropType<TextOverflow>;
    visible: BooleanConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:font"?: ((...args: any[]) => any) | undefined;
    "onUpdate:textOverflow"?: ((...args: any[]) => any) | undefined;
    "onUpdate:visible"?: ((...args: any[]) => any) | undefined;
}, {
    visible: boolean;
}>;
declare const DxHoverStyle: import("vue").DefineComponent<{
    border: PropType<Record<string, any>>;
    color: StringConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:border": null;
    "update:color": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    border: PropType<Record<string, any>>;
    color: StringConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:border"?: ((...args: any[]) => any) | undefined;
    "onUpdate:color"?: ((...args: any[]) => any) | undefined;
}, {}>;
declare const DxLabel: import("vue").DefineComponent<{
    font: PropType<Record<string, any> | Font>;
    textOverflow: PropType<TextOverflow>;
    visible: BooleanConstructor;
    wordWrap: PropType<WordWrap>;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:font": null;
    "update:textOverflow": null;
    "update:visible": null;
    "update:wordWrap": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    font: PropType<Record<string, any> | Font>;
    textOverflow: PropType<TextOverflow>;
    visible: BooleanConstructor;
    wordWrap: PropType<WordWrap>;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:font"?: ((...args: any[]) => any) | undefined;
    "onUpdate:textOverflow"?: ((...args: any[]) => any) | undefined;
    "onUpdate:wordWrap"?: ((...args: any[]) => any) | undefined;
    "onUpdate:visible"?: ((...args: any[]) => any) | undefined;
}, {
    visible: boolean;
}>;
declare const DxLoadingIndicator: import("vue").DefineComponent<{
    backgroundColor: StringConstructor;
    enabled: BooleanConstructor;
    font: PropType<Record<string, any> | Font>;
    show: BooleanConstructor;
    text: StringConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:backgroundColor": null;
    "update:enabled": null;
    "update:font": null;
    "update:show": null;
    "update:text": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    backgroundColor: StringConstructor;
    enabled: BooleanConstructor;
    font: PropType<Record<string, any> | Font>;
    show: BooleanConstructor;
    text: StringConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:font"?: ((...args: any[]) => any) | undefined;
    "onUpdate:text"?: ((...args: any[]) => any) | undefined;
    "onUpdate:enabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:backgroundColor"?: ((...args: any[]) => any) | undefined;
    "onUpdate:show"?: ((...args: any[]) => any) | undefined;
}, {
    enabled: boolean;
    show: boolean;
}>;
declare const DxMargin: import("vue").DefineComponent<{
    bottom: NumberConstructor;
    left: NumberConstructor;
    right: NumberConstructor;
    top: NumberConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:bottom": null;
    "update:left": null;
    "update:right": null;
    "update:top": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    bottom: NumberConstructor;
    left: NumberConstructor;
    right: NumberConstructor;
    top: NumberConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:bottom"?: ((...args: any[]) => any) | undefined;
    "onUpdate:left"?: ((...args: any[]) => any) | undefined;
    "onUpdate:right"?: ((...args: any[]) => any) | undefined;
    "onUpdate:top"?: ((...args: any[]) => any) | undefined;
}, {}>;
declare const DxSelectionStyle: import("vue").DefineComponent<{
    border: PropType<Record<string, any>>;
    color: StringConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:border": null;
    "update:color": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    border: PropType<Record<string, any>>;
    color: StringConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:border"?: ((...args: any[]) => any) | undefined;
    "onUpdate:color"?: ((...args: any[]) => any) | undefined;
}, {}>;
declare const DxShadow: import("vue").DefineComponent<{
    blur: NumberConstructor;
    color: StringConstructor;
    offsetX: NumberConstructor;
    offsetY: NumberConstructor;
    opacity: NumberConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:blur": null;
    "update:color": null;
    "update:offsetX": null;
    "update:offsetY": null;
    "update:opacity": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    blur: NumberConstructor;
    color: StringConstructor;
    offsetX: NumberConstructor;
    offsetY: NumberConstructor;
    opacity: NumberConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:color"?: ((...args: any[]) => any) | undefined;
    "onUpdate:offsetX"?: ((...args: any[]) => any) | undefined;
    "onUpdate:offsetY"?: ((...args: any[]) => any) | undefined;
    "onUpdate:opacity"?: ((...args: any[]) => any) | undefined;
    "onUpdate:blur"?: ((...args: any[]) => any) | undefined;
}, {}>;
declare const DxSize: import("vue").DefineComponent<{
    height: NumberConstructor;
    width: NumberConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:height": null;
    "update:width": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    height: NumberConstructor;
    width: NumberConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:height"?: ((...args: any[]) => any) | undefined;
    "onUpdate:width"?: ((...args: any[]) => any) | undefined;
}, {}>;
declare const DxSubtitle: import("vue").DefineComponent<{
    font: PropType<Record<string, any> | Font>;
    offset: NumberConstructor;
    text: StringConstructor;
    textOverflow: PropType<TextOverflow>;
    wordWrap: PropType<WordWrap>;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:font": null;
    "update:offset": null;
    "update:text": null;
    "update:textOverflow": null;
    "update:wordWrap": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    font: PropType<Record<string, any> | Font>;
    offset: NumberConstructor;
    text: StringConstructor;
    textOverflow: PropType<TextOverflow>;
    wordWrap: PropType<WordWrap>;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:font"?: ((...args: any[]) => any) | undefined;
    "onUpdate:text"?: ((...args: any[]) => any) | undefined;
    "onUpdate:textOverflow"?: ((...args: any[]) => any) | undefined;
    "onUpdate:wordWrap"?: ((...args: any[]) => any) | undefined;
    "onUpdate:offset"?: ((...args: any[]) => any) | undefined;
}, {}>;
declare const DxTile: import("vue").DefineComponent<{
    border: PropType<Record<string, any>>;
    color: StringConstructor;
    hoverStyle: PropType<Record<string, any>>;
    label: PropType<Record<string, any>>;
    selectionStyle: PropType<Record<string, any>>;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:border": null;
    "update:color": null;
    "update:hoverStyle": null;
    "update:label": null;
    "update:selectionStyle": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    border: PropType<Record<string, any>>;
    color: StringConstructor;
    hoverStyle: PropType<Record<string, any>>;
    label: PropType<Record<string, any>>;
    selectionStyle: PropType<Record<string, any>>;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:border"?: ((...args: any[]) => any) | undefined;
    "onUpdate:color"?: ((...args: any[]) => any) | undefined;
    "onUpdate:label"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoverStyle"?: ((...args: any[]) => any) | undefined;
    "onUpdate:selectionStyle"?: ((...args: any[]) => any) | undefined;
}, {}>;
declare const DxTileLabel: import("vue").DefineComponent<{
    font: PropType<Record<string, any> | Font>;
    textOverflow: PropType<TextOverflow>;
    visible: BooleanConstructor;
    wordWrap: PropType<WordWrap>;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:font": null;
    "update:textOverflow": null;
    "update:visible": null;
    "update:wordWrap": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    font: PropType<Record<string, any> | Font>;
    textOverflow: PropType<TextOverflow>;
    visible: BooleanConstructor;
    wordWrap: PropType<WordWrap>;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:font"?: ((...args: any[]) => any) | undefined;
    "onUpdate:textOverflow"?: ((...args: any[]) => any) | undefined;
    "onUpdate:wordWrap"?: ((...args: any[]) => any) | undefined;
    "onUpdate:visible"?: ((...args: any[]) => any) | undefined;
}, {
    visible: boolean;
}>;
declare const DxTitle: import("vue").DefineComponent<{
    font: PropType<Record<string, any> | Font>;
    horizontalAlignment: PropType<HorizontalAlignment>;
    margin: PropType<number | Record<string, any>>;
    placeholderSize: NumberConstructor;
    subtitle: PropType<string | Record<string, any>>;
    text: StringConstructor;
    textOverflow: PropType<TextOverflow>;
    verticalAlignment: PropType<VerticalEdge>;
    wordWrap: PropType<WordWrap>;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:font": null;
    "update:horizontalAlignment": null;
    "update:margin": null;
    "update:placeholderSize": null;
    "update:subtitle": null;
    "update:text": null;
    "update:textOverflow": null;
    "update:verticalAlignment": null;
    "update:wordWrap": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    font: PropType<Record<string, any> | Font>;
    horizontalAlignment: PropType<HorizontalAlignment>;
    margin: PropType<number | Record<string, any>>;
    placeholderSize: NumberConstructor;
    subtitle: PropType<string | Record<string, any>>;
    text: StringConstructor;
    textOverflow: PropType<TextOverflow>;
    verticalAlignment: PropType<VerticalEdge>;
    wordWrap: PropType<WordWrap>;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:font"?: ((...args: any[]) => any) | undefined;
    "onUpdate:text"?: ((...args: any[]) => any) | undefined;
    "onUpdate:textOverflow"?: ((...args: any[]) => any) | undefined;
    "onUpdate:wordWrap"?: ((...args: any[]) => any) | undefined;
    "onUpdate:horizontalAlignment"?: ((...args: any[]) => any) | undefined;
    "onUpdate:margin"?: ((...args: any[]) => any) | undefined;
    "onUpdate:verticalAlignment"?: ((...args: any[]) => any) | undefined;
    "onUpdate:placeholderSize"?: ((...args: any[]) => any) | undefined;
    "onUpdate:subtitle"?: ((...args: any[]) => any) | undefined;
}, {}>;
declare const DxTooltip: import("vue").DefineComponent<{
    arrowLength: NumberConstructor;
    border: PropType<Record<string, any>>;
    color: StringConstructor;
    container: {};
    contentTemplate: {};
    cornerRadius: NumberConstructor;
    customizeTooltip: PropType<(info: {
        node: dxTreeMapNode;
        value: number;
        valueText: string;
    }) => Record<string, any>>;
    enabled: BooleanConstructor;
    font: PropType<Record<string, any> | Font>;
    format: PropType<string | Record<string, any> | import("devextreme/common/core/localization").FormatObject | ((value: number | Date) => string) | ((value: Date) => string) | ((value: number) => string) | Intl.DateTimeFormatOptions | Intl.NumberFormatOptions | ((value: number | Date) => string) | undefined>;
    opacity: NumberConstructor;
    paddingLeftRight: NumberConstructor;
    paddingTopBottom: NumberConstructor;
    shadow: PropType<Record<string, any>>;
    zIndex: NumberConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:arrowLength": null;
    "update:border": null;
    "update:color": null;
    "update:container": null;
    "update:contentTemplate": null;
    "update:cornerRadius": null;
    "update:customizeTooltip": null;
    "update:enabled": null;
    "update:font": null;
    "update:format": null;
    "update:opacity": null;
    "update:paddingLeftRight": null;
    "update:paddingTopBottom": null;
    "update:shadow": null;
    "update:zIndex": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    arrowLength: NumberConstructor;
    border: PropType<Record<string, any>>;
    color: StringConstructor;
    container: {};
    contentTemplate: {};
    cornerRadius: NumberConstructor;
    customizeTooltip: PropType<(info: {
        node: dxTreeMapNode;
        value: number;
        valueText: string;
    }) => Record<string, any>>;
    enabled: BooleanConstructor;
    font: PropType<Record<string, any> | Font>;
    format: PropType<string | Record<string, any> | import("devextreme/common/core/localization").FormatObject | ((value: number | Date) => string) | ((value: Date) => string) | ((value: number) => string) | Intl.DateTimeFormatOptions | Intl.NumberFormatOptions | ((value: number | Date) => string) | undefined>;
    opacity: NumberConstructor;
    paddingLeftRight: NumberConstructor;
    paddingTopBottom: NumberConstructor;
    shadow: PropType<Record<string, any>>;
    zIndex: NumberConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:arrowLength"?: ((...args: any[]) => any) | undefined;
    "onUpdate:border"?: ((...args: any[]) => any) | undefined;
    "onUpdate:color"?: ((...args: any[]) => any) | undefined;
    "onUpdate:customizeTooltip"?: ((...args: any[]) => any) | undefined;
    "onUpdate:font"?: ((...args: any[]) => any) | undefined;
    "onUpdate:opacity"?: ((...args: any[]) => any) | undefined;
    "onUpdate:paddingLeftRight"?: ((...args: any[]) => any) | undefined;
    "onUpdate:paddingTopBottom"?: ((...args: any[]) => any) | undefined;
    "onUpdate:shadow"?: ((...args: any[]) => any) | undefined;
    "onUpdate:cornerRadius"?: ((...args: any[]) => any) | undefined;
    "onUpdate:enabled"?: ((...args: any[]) => any) | undefined;
    "onUpdate:container"?: ((...args: any[]) => any) | undefined;
    "onUpdate:contentTemplate"?: ((...args: any[]) => any) | undefined;
    "onUpdate:zIndex"?: ((...args: any[]) => any) | undefined;
    "onUpdate:format"?: ((...args: any[]) => any) | undefined;
}, {
    enabled: boolean;
}>;
declare const DxTooltipBorder: import("vue").DefineComponent<{
    color: StringConstructor;
    dashStyle: PropType<DashStyle>;
    opacity: NumberConstructor;
    visible: BooleanConstructor;
    width: NumberConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:color": null;
    "update:dashStyle": null;
    "update:opacity": null;
    "update:visible": null;
    "update:width": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    color: StringConstructor;
    dashStyle: PropType<DashStyle>;
    opacity: NumberConstructor;
    visible: BooleanConstructor;
    width: NumberConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:color"?: ((...args: any[]) => any) | undefined;
    "onUpdate:opacity"?: ((...args: any[]) => any) | undefined;
    "onUpdate:width"?: ((...args: any[]) => any) | undefined;
    "onUpdate:dashStyle"?: ((...args: any[]) => any) | undefined;
    "onUpdate:visible"?: ((...args: any[]) => any) | undefined;
}, {
    visible: boolean;
}>;
declare const DxTreeMapborder: import("vue").DefineComponent<{
    color: StringConstructor;
    width: NumberConstructor;
}, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:isActive": null;
    "update:hoveredElement": null;
    "update:color": null;
    "update:width": null;
}, string, import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, Readonly<import("vue").ExtractPropTypes<{
    color: StringConstructor;
    width: NumberConstructor;
}>> & {
    "onUpdate:isActive"?: ((...args: any[]) => any) | undefined;
    "onUpdate:hoveredElement"?: ((...args: any[]) => any) | undefined;
    "onUpdate:color"?: ((...args: any[]) => any) | undefined;
    "onUpdate:width"?: ((...args: any[]) => any) | undefined;
}, {}>;
export default DxTreeMap;
export { DxTreeMap, DxBorder, DxColorizer, DxExport, DxFont, DxFormat, DxGroup, DxGroupLabel, DxHoverStyle, DxLabel, DxLoadingIndicator, DxMargin, DxSelectionStyle, DxShadow, DxSize, DxSubtitle, DxTile, DxTileLabel, DxTitle, DxTooltip, DxTooltipBorder, DxTreeMapborder };
import type * as DxTreeMapTypes from "devextreme/viz/tree_map_types";
export { DxTreeMapTypes };
